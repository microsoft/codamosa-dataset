

# Generated at 2022-06-23 02:45:04.270574
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("I am an Exception")
    except ValueError as e:
        value = get_exception()
    assert value == e


# Generated at 2022-06-23 02:45:06.333184
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('fake exception')
    except Exception as e:
        saved_e = get_exception()
    assert saved_e == e

# Generated at 2022-06-23 02:45:10.007471
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:45:15.646846
# Unit test for function get_exception
def test_get_exception():
    tt = type('t', (object,), {})

    try:
        raise tt()
    except tt:
        assert get_exception()

    try:
        raise tt()
    except:  # noqa
        assert get_exception()

# Generated at 2022-06-23 02:45:19.840829
# Unit test for function get_exception
def test_get_exception():
    ''' Test the functionality of get_exception '''

    # Try/except block to test get_exception with default arguments
    try:
        # Raise exception to be captured by get_exception
        raise Exception('This is a test exception')
    except Exception:
        e = get_exception()
        if not isinstance(e, Exception):
            raise Exception('Tested exception does not match the captured exception')


# Generated at 2022-06-23 02:45:28.253407
# Unit test for function get_exception
def test_get_exception():
    import string


# Generated at 2022-06-23 02:45:30.987207
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        pass
    finally:
        assert isinstance(get_exception(), Exception)

# Generated at 2022-06-23 02:45:35.162639
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:45:45.726235
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-argument,no-self-use
    import types
    import ansible.module_utils.six

    # pylint: disable=missing-docstring
    class TestError(Exception):
        pass

    class TestClass:
        def get_exception(self):
            return self.get_exception_real()

        def get_exception_real(self):
            try:
                raise TestError()
            except Exception as e:
                return e
            else:
                return None

    # Test that the real get_exception has the same signature as the
    # fake get_exception.

# Generated at 2022-06-23 02:45:48.152254
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A fake exception')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:45:53.235234
# Unit test for function get_exception
def test_get_exception():
    """
    Verify that get_exception() returns the correct exception.

    Python 2.4:

    def test_get_exception():
        try:
                raise Exception('foo')
        except:
                assert get_exception() == Exception('foo')
    """
    try:
        raise Exception('foo')
    except:
        result = get_exception()
        assert isinstance(result, Exception)
        assert result.args == ('foo', )



# Generated at 2022-06-23 02:45:55.958105
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('the message')
    except:
        exc = get_exception()
        assert str(exc) == 'the message'



# Generated at 2022-06-23 02:45:59.036335
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            [][0]
        except IndexError:
            e = get_exception()
            return type(e)

    assert f() == IndexError
    assert get_exception() is None

# Generated at 2022-06-23 02:46:04.144540
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring
    try:
        raise RuntimeError('a message')
    except RuntimeError:
        e = get_exception()
    assert e.args[0] == 'a message'


# Generated at 2022-06-23 02:46:06.816696
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:46:14.997050
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception returns the current exception

    Create a function that raises an exception containing a message.
    Catch the exception and check the message.
    """
    def test():
        """Inner function that raises an exception"""
        raise Exception("foo")

    try:
        test()
    except: # pylint: disable=bare-except
        # Use literal_eval to work on python 2.4
        result = literal_eval("get_exception()")

    assert result.message == "foo"

# Generated at 2022-06-23 02:46:17.830731
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Unit Test')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:46:23.614858
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'This is a test'
        import sys as _sys
        assert e.__class__.__module__ == _sys.exc_info()[0].__module__
        assert e.__class__.__name__ == _sys.exc_info()[0].__name__

# Generated at 2022-06-23 02:46:26.440540
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'test exception'

# Generated at 2022-06-23 02:46:33.491366
# Unit test for function get_exception
def test_get_exception():
    def f():
        x = 1
        y = 0
        z = x / y
    try:
        f()
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError), 'Did not find the correct exception'
        assert str(e) == 'integer division or modulo by zero', "Didn't find the correct exception string"
        print('get_exception: Success')
    else:
        raise AssertionError('Function did not raise ZeroDivisionError as expected')

# Generated at 2022-06-23 02:46:40.741151
# Unit test for function get_exception
def test_get_exception():
    import errno
    try:
        do_something_that_may_fail()
    except OSError as e:
        assert e == get_exception()
        assert e.errno == errno.EAGAIN
        assert get_exception().strerror == 'Resource temporarily unavailable'



# Generated at 2022-06-23 02:46:43.540893
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exception = get_exception()
    assert 'foo' in str(exception)

# Generated at 2022-06-23 02:46:45.848965
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:48.958523
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'foo'
        return True
    return False

# Generated at 2022-06-23 02:46:52.737682
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "Test exception"

# Generated at 2022-06-23 02:46:55.342514
# Unit test for function get_exception
def test_get_exception():
    def throws():
        raise ValueError("Test exception")

    try:
        throws()
    except Exception:
        caught = get_exception()
    assert caught.args[0] == "Test exception"

# Generated at 2022-06-23 02:46:57.829458
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError:
        exc = get_exception()
        assert str(exc) == "Test exception"



# Generated at 2022-06-23 02:47:01.414472
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass

    try:
        raise CustomException('test_get_exception()')
    except Exception:
        e = get_exception()
        assert e.__str__() == 'test_get_exception()'

# Generated at 2022-06-23 02:47:11.747040
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception returns the expected exception"""
    import types
    import random

    def test_get_exception_sub():
        """Test get_exception in a subroutine"""
        try:
            raise Exception('This is a test.')
        except Exception:
            e = get_exception()
            # Just make sure it's an Exception, we don't care which
            assert isinstance(e, Exception)
            # Make sure it's the same exception, not a new one by comparing the
            # attributes
            assert e.args == ('This is a test.',)

    test_get_exception_sub()

    # Now test that it works with different exceptions
    exception_classes = sys.exc_info()[0].__subclasses__()
    # We don't care about bogus exceptions (base class=None)
    exception

# Generated at 2022-06-23 02:47:14.425706
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        assert get_exception().args == (u'Test exception',)



# Generated at 2022-06-23 02:47:16.882951
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError as e:
        pass
    assert get_exception() == e



# Generated at 2022-06-23 02:47:19.283298
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        assert get_exception().args == ('test',)


# Generated at 2022-06-23 02:47:22.938293
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boo')
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'Exception'
        assert str(e) == 'boo'



# Generated at 2022-06-23 02:47:25.859704
# Unit test for function get_exception
def test_get_exception():
    """Check to make sure get_exception can get exceptions."""
    try:
        raise Exception('a')
    except Exception as e:
        ge = get_exception()
        assert ge is e



# Generated at 2022-06-23 02:47:28.854280
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Some exception.')
    except Exception:
        e = get_exception()
    assert str(e) == 'Some exception.'


# Generated at 2022-06-23 02:47:36.481301
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name
    try:
        raise RuntimeError("Hello, world")
    except Exception:
        # This has to be e to test the 6to3 compatibility magic
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == "Hello, world"


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:47:40.862651
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Expected exception")
    except RuntimeError:
        exc = get_exception()
    assert str(exc) == "Expected exception"


# Generated at 2022-06-23 02:47:43.754500
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()

    assert e.args[0] == 'foo'
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:47:47.196460
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IndexError("test exception")
    except:
        pass
    e = get_exception()
    assert isinstance(e, IndexError)
    assert str(e) == "test exception"


# Generated at 2022-06-23 02:47:52.200994
# Unit test for function get_exception
def test_get_exception():
    """Assert that get_exception works"""
    def assert_get_exception_works(func):
        try:
            func()
        except Exception:
            result = get_exception()

        assert isinstance(result, Exception), 'Incorrect exception type'
    assert_get_exception_works(lambda: 'abc'.index('d'))
    assert_get_exception_works(lambda: 1 / 0)

# Generated at 2022-06-23 02:47:55.193769
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("test exception")
    except RuntimeError:
        test_exception = get_exception()
        assert test_exception.args == ("test exception",)


# Generated at 2022-06-23 02:47:58.495695
# Unit test for function get_exception
def test_get_exception():
    def inner():
        raise ValueError("The exception message")
    def outer():
        inner()

    try:
        outer()
    except Exception: # pylint: disable=broad-except
        e = get_exception()
        return str(e) == str("The exception message")
    return False


# Generated at 2022-06-23 02:48:04.327517
# Unit test for function get_exception
def test_get_exception():
    try:
        z = 1 + 'a'
        assert False
    except:
        # Python 2.4 through 2.7
        assert get_exception().__class__.__name__ == 'TypeError'
        # Python 3
        assert get_exception().__class__.__name__ == 'TypeError'


# Generated at 2022-06-23 02:48:14.690729
# Unit test for function get_exception
def test_get_exception():
    import sys
    import six
    import unittest

    class TestGetException(unittest.TestCase):
        """Unit test for the get_exception function"""
        def test_get_exception(self):
            """Try to get the current exception and make sure it is None when there
            is no current exception.
            """
            try:
                exc = get_exception()
            except Exception as e:  # pylint: disable=locally-disabled, broad-except
                sys.stderr.write('get_exception raised an exception: {0!r}'.format(e))
                raise
            self.assertIs(exc, None)

        def test_get_exception_raised(self):
            """This should raise the ZeroDivisionError"""

# Generated at 2022-06-23 02:48:17.420253
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('Test',)

# Generated at 2022-06-23 02:48:24.071824
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("testing get_exception")
    except Exception:
        e = get_exception()
        if e.__class__ != ValueError:
            # We want to raise an exception in the test code, not just return
            # false.
            raise AssertionError("get_exception doesn't fetch the right exception")


# Generated at 2022-06-23 02:48:27.289866
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        assert str(get_exception()) == 'test'

# Generated at 2022-06-23 02:48:36.363103
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestCase(unittest.TestCase):

        def test_get_exception(self):
            import ansible.module_utils.basic
            self.assertEqual(ansible.module_utils.basic.get_exception(), None)

            try:
                raise Exception("foo")
            except Exception:
                e = get_exception()
                self.assertEqual(e.args, ("foo",))

    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 02:48:38.915050
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Watch out for the asteroids!')
    except Exception:
        e = get_exception()
    assert str(e) == 'Watch out for the asteroids!'


# Generated at 2022-06-23 02:48:41.767175
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(1)
    except:
        e = get_exception()

    assert e is not None
    assert isinstance(e, ValueError)
    assert e.args[0] == 1

# Generated at 2022-06-23 02:48:47.116997
# Unit test for function get_exception
def test_get_exception():
    class MyClass(object):
        pass
    try:
        raise MyClass()
    except:
        exception = get_exception()
        assert isinstance(exception, MyClass)

# vim:set shiftwidth=4 tabstop=4 expandtab textwidth=79:

# Generated at 2022-06-23 02:48:50.443441
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e
    else:
        assert False, 'No exception thrown'


# Generated at 2022-06-23 02:48:55.253684
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception('foo')

    def f2():
        try:
            f()
        except Exception:
            e = get_exception()
            print(e)
            return e

    e = f2()
    assert e.args == ('foo',)


# Generated at 2022-06-23 02:48:58.712615
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test exception!")
    except:
        err = get_exception()
    assert "test exception!" in str(err), \
        "get_exception() should return the current exception"


# Generated at 2022-06-23 02:49:04.485983
# Unit test for function get_exception
def test_get_exception():
    def raise_get_exception(foo):
        try:
            raise Exception("Something went wrong")
        except Exception:
            e = get_exception()
        return e

    e = raise_get_exception("fred")
    assert "Something went wrong" in str(e)



# Generated at 2022-06-23 02:49:08.167850
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise RuntimeError('Test exception')
    try:
        f()
    except:
        e = get_exception()
        assert e.args[0] == 'Test exception'
    else:
        assert False, "Failed to throw exception"


# Generated at 2022-06-23 02:49:12.660917
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works"""
    try:
        raise AssertionError('test exception')
    except AssertionError:
        e = get_exception()
        assert str(e) == 'test exception'

# Generated at 2022-06-23 02:49:23.307447
# Unit test for function get_exception
def test_get_exception():
    raises_syntax_error = False
    try:
        exec('"test"')
    except SyntaxError:
        raises_syntax_error = True

    if not raises_syntax_error:
        sys.stderr.write('test_get_exception(): test skipped because there is a bug in Python < 2.6.2 (http://bugs.python.org/issue4980)\n')
        return

    try:
        exec('"test"')
    except:
        exc_info = sys.exc_info()
        assert exc_info[0] == SyntaxError
        assert get_exception() == exc_info[1]

# Generated at 2022-06-23 02:49:27.555840
# Unit test for function get_exception
def test_get_exception():
    ex = None
    try:
        raise ValueError('foo')
    except ValueError:
        ex = get_exception()

    assert ex is not None, "Exception raised but get_exception did not return anything"
    assert str(ex) == 'foo', "Exception raised but get_exception did not return it"

# Generated at 2022-06-23 02:49:30.940062
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
        assert 'foo' in str(exc)


# Generated at 2022-06-23 02:49:34.381825
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing exception retrieval')
    except Exception:
        e = get_exception()
    if type(e) is not ValueError or str(e) != 'testing exception retrieval':
        raise AssertionError()


# Generated at 2022-06-23 02:49:39.234909
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        e2 = get_exception()
    assert e == e2



# Generated at 2022-06-23 02:49:42.722597
# Unit test for function get_exception
def test_get_exception():
    try:
        'abc'.count(1)
    except TypeError:
        assert 'abc'.count(1) == get_exception()
    else:
        raise AssertionError('TypeError was not raised')

# Generated at 2022-06-23 02:49:51.277337
# Unit test for function get_exception
def test_get_exception():
    try:
        # Try to get the exception.  This will succeed if we're in the 'except'
        # clause of this try-except statement.
        get_exception()
    except:
        # This is where we expect to be called.  Make sure it does what we
        # expect.
        e = get_exception()
        assert e.args == ('test exception',)
    else:
        # The 'get_exception' function is only useful in the exception clause.
        raise AssertionError('get_exception called outside of exception clause')

# Generated at 2022-06-23 02:49:54.202505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
        if str(e) != 'foobar':
            raise AssertionError("Exception wasn't caught properly")

# Generated at 2022-06-23 02:49:57.837802
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
        assert str(e) == 'test exception'

# Generated at 2022-06-23 02:50:05.612033
# Unit test for function get_exception
def test_get_exception():
    """Verify that we get the current exception"""
    def test_function():
        """Raise an exception"""
        raise RuntimeError('test exception')
    try:
        try:
            test_function()
        except:
            exception = get_exception()
        assert exception.args[0] == 'test exception'
    except AssertionError:
        print('#' * 60)
        print('get_exception is broken!')
        print('#' * 60)
        raise

# Generated at 2022-06-23 02:50:09.142167
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError('test_get_exception')
        except Exception:
            e = get_exception()
            assert e.args[0] == 'test_get_exception'
    f()

# Generated at 2022-06-23 02:50:12.481132
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise TypeError()
        except Exception as e:
            raise e
    except Exception as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:50:14.944834
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-23 02:50:17.678889
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('This is a test exception')
    except TypeError:
        pass
    assert get_exception().message == 'This is a test exception'



# Generated at 2022-06-23 02:50:20.099666
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-23 02:50:24.256582
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise TypeError('test exception')
        except TypeError:
            e = get_exception()
            assert isinstance(e, TypeError)
            assert e.args[0] == 'test exception'
    except AssertionError:
        raise

# Generated at 2022-06-23 02:50:30.189635
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=redefined-outer-name
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError as e:
        assert e is get_exception()
    except:  # noqa: pylint=bare-except
        assert False, "Unexpected error type"

# Generated at 2022-06-23 02:50:32.150359
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test error')
    except RuntimeError:
        assert get_exception()

# Generated at 2022-06-23 02:50:36.660476
# Unit test for function get_exception
def test_get_exception():
    # This test only works if we're not already in an except block!
    try:
        raise Exception('Test Exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test Exception'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:50:41.316131
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert(isinstance(e, ValueError))
        assert(e.args == ('foo',))
    else:
        assert(False)  # pragma: no cover (This code should never be called)

# Generated at 2022-06-23 02:50:43.942111
# Unit test for function get_exception
def test_get_exception():
    # Check that the function grabs the current exception
    try:
        raise ValueError(u'An error occurred')
    except ValueError:
        assert get_exception()


# Generated at 2022-06-23 02:50:46.302242
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Test message')
    except TypeError:
        e = get_exception()

    assert type(e) == TypeError
    assert 'Test message' in str(e)

# Generated at 2022-06-23 02:50:51.418221
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError), "get_exception doesn't provide an exception"
    assert str(exc) == 'foo', "get_exception's exception isn't the correct exception"

# unit test for function literal_eval

# Generated at 2022-06-23 02:50:55.516199
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:50:59.714345
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = sys.exc_info()[1]
        assert get_exception() is e


# Generated at 2022-06-23 02:51:09.586889
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is an expected error")
    except ValueError as err:
        assert type(err) is ValueError
        assert err.args == ("This is an expected error",)

if __name__ == '__main__':
    def test_literal_eval():
        case_input = {
            "foo": "bar",
            'a': 'b',
            '4': 5,
            '5': '4',
            '6': [1, 2, 3, 4],
            '7': (1, 2, 3, 4),
            '8': {'foo': 'bar'},
            '9': [{'one': 1, 'two': 2}],
            '10': {'a': [1,2,3]}
            }

# Generated at 2022-06-23 02:51:11.181568
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert get_exception() is not None

# Generated at 2022-06-23 02:51:13.852736
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "Test exception"



# Generated at 2022-06-23 02:51:16.796967
# Unit test for function get_exception
def test_get_exception():
    try:
        return get_exception()
    except TypeError:
        pass

# Generated at 2022-06-23 02:51:24.770971
# Unit test for function get_exception
def test_get_exception():
    # Try to create a NameError
    try:
        foo
    except Exception:
        e = get_exception()
        assert isinstance(e, NameError)

    # Try to create a ZeroDivisionError
    try:
        1/0
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

    # Try to create a ValueError
    try:
        int('asdf')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:51:29.584087
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            g()
        except Exception:
            e = get_exception()
            return e
    def g():
        raise Exception('test_exception')
    e = f()
    assert str(e) == 'test_exception'

# Generated at 2022-06-23 02:51:35.824222
# Unit test for function get_exception
def test_get_exception():
    # This will only work on Python 2.4+
    try:
        raise TypeError('My error')
    except Exception:
        e = get_exception()
        assert isinstance(e, TypeError)
        assert "My error" in str(e)


# Generated at 2022-06-23 02:51:46.048745
# Unit test for function get_exception
def test_get_exception():

    # Python 2.4 version of assertRaises doesn't provide the context manager
    if sys.version_info[:2] == (2, 4):
        import unittest2 as unittest
    else:
        import unittest

    class Test(unittest.TestCase):

        def test_it(self):
            def f():
                raise Exception()
            try:
                f()
            except:
                e = get_exception()
            self.assertEqual(type(e), Exception)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 02:51:50.004499
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except Exception:
        assert isinstance(get_exception(), ZeroDivisionError)



# Generated at 2022-06-23 02:51:52.437458
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        if e is not get_exception():
            raise AssertionError()

# Generated at 2022-06-23 02:52:02.187928
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=invalid-name
    # pylint: disable=no-member
    # pylint: disable=too-few-public-methods
    class Error(Exception):
        pass


# Generated at 2022-06-23 02:52:10.485660
# Unit test for function get_exception
def test_get_exception():
    ''' ansible.module_utils.common.get_exception '''
    import ansible.module_utils.common as common

    def raise_exception(x):
        raise x

    try:
        raise_exception(Exception('foo'))
    except Exception:
        if common.get_exception() is None: # pylint: disable=no-member
            raise AssertionError('got no exception')
        else:
            return True
    else:
        raise AssertionError('did not raise exception')

# Generated at 2022-06-23 02:52:14.638407
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        exc = get_exception()

    assert isinstance(exc, RuntimeError)
    assert str(exc) == 'foo'



# Generated at 2022-06-23 02:52:17.516036
# Unit test for function get_exception
def test_get_exception():
    foo = None
    try:
        raise RuntimeError("A test error")
    except:
        foo = get_exception()
    assert foo.message == "A test error"


# Generated at 2022-06-23 02:52:21.768395
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 + "one"
    except:
        # Python 2: get_exception() returns a string that says "TypeError: unsupported operand type(s)..."
        # Python 3: get_exception() returns a TypeError object.
        assert get_exception()

# Generated at 2022-06-23 02:52:25.116498
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('test',)


# Generated at 2022-06-23 02:52:30.009555
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Sample exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'Sample exception'
    assert type(e) == ValueError
    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert e is None

# Generated at 2022-06-23 02:52:34.604603
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        ex = get_exception()
        assert ex.__class__.__name__ == 'Exception'
    try:
        raise Exception('test')
    except Exception:
        ex = get_exception()
        assert ex.__class__.__name__ == 'Exception'
        assert str(ex) == 'test'

# Generated at 2022-06-23 02:52:36.383312
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("some exception")
    except Exception:
        assert get_exception()

# Generated at 2022-06-23 02:52:39.287897
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('example')
    except RuntimeError:
        exc = get_exception()
    assert str(exc) == 'example'
    assert exc.args == ('example',)


# Generated at 2022-06-23 02:52:45.089319
# Unit test for function get_exception
def test_get_exception():
    try:
        # This call will raise a KeyError
        raise KeyError
    except:
        # A bare except will catch all exceptions.  This is required
        # because we need to be able to catch the KeyError on Python 2.4.
        # We can get the more specific exception from get_exception
        e = get_exception()
        assert isinstance(e, KeyError)


# Generated at 2022-06-23 02:52:47.763808
# Unit test for function get_exception
def test_get_exception():
    # This is a simple function, just check that it doesn't throw errors
    try:
        raise TypeError('foo')
    except TypeError:
        get_exception()


# Generated at 2022-06-23 02:52:50.637303
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise ValueError('testing')

    try:
        test()
    except:
        e = get_exception()
    assert type(e) is ValueError and e.args[0] == 'testing'


# Generated at 2022-06-23 02:52:56.634556
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=undefined-variable
        x = some_undefined_variable_here
        x = 1
    except Exception:
        print(get_exception())

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:53:00.349417
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError:
        e = get_exception()
    return e

# Generated at 2022-06-23 02:53:03.764482
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError("This is a test exception.")
        except:
            return get_exception()
    test_exc = foo()
    assert isinstance(test_exc, ValueError)
    assert str(test_exc) == "This is a test exception."

# Generated at 2022-06-23 02:53:13.705638
# Unit test for function get_exception
def test_get_exception():
    import os

    class CustomError(Exception):
        pass

    def raise_exception(e):
        raise e

    # Make sure that get_exception() returns the right exception
    try:
        raise_exception(CustomError())
    except Exception:
        exc = get_exception()

    assert isinstance(exc, CustomError)

    # Make sure that get_exception() doesn't return a different exception
    try:
        raise_exception(CustomError())
    except Exception:
        exc = get_exception()

    assert not isinstance(exc, OSError)


# Unit tests for function literal_eval()

# Generated at 2022-06-23 02:53:16.205577
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An exception to be picked up')
    except ValueError as e:
        assert get_exception() == e


# Generated at 2022-06-23 02:53:18.475589
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('test')
    except MyException:
        exc = get_exception()
        assert exc.args[0] == 'test'
        assert isinstance(exc, MyException)

# Generated at 2022-06-23 02:53:22.072412
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('raised exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'raised exception'



# Generated at 2022-06-23 02:53:26.974671
# Unit test for function get_exception
def test_get_exception():
    # Note: the ordering is correct.  The function get_exception() grabs everything at once.
    try:
        raise Exception("This is an exception")
    except Exception:
        result = get_exception()
    assert result.args[0] == "This is an exception"



# Generated at 2022-06-23 02:53:33.471711
# Unit test for function get_exception
def test_get_exception():
    class A():
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc_inst, exc_tb):
            assert exc_inst is None
    a = A()
    try:
        with a as b:
            raise ValueError('test')
    except:
        ret = get_exception()

    assert ret is not None
    assert isinstance(ret, ValueError)
    assert ret.args == ('test',)

# Generated at 2022-06-23 02:53:38.096906
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise RuntimeError('Konstantin')
    except RuntimeError:
        e = get_exception()
    assert e.args[0] == 'Konstantin', 'get_exception() did not return the exception we raised'


# Generated at 2022-06-23 02:53:40.014917
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:53:42.917823
# Unit test for function get_exception
def test_get_exception():
    # check that get_exception works as expected
    try:
        raise Exception('This is a test exception')
    except Exception as e:
        assert get_exception() is e
    try:
        raise Exception('This is a test exception')
    except Exception:
        assert get_exception() is not None

# Generated at 2022-06-23 02:53:45.238062
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing get_exception')
    except Exception:
        e = get_exception()
        assert e.args == ('Testing get_exception',)


# Generated at 2022-06-23 02:53:48.317023
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('A test error.')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('A test error.',)

# Generated at 2022-06-23 02:53:54.234606
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("e")
    except ValueError:
        # In the context of an exception, the variable 'e' is bound to
        # the exception object.
        e = get_exception()
        assert str(e) == 'e'
    else:
        # tb is undefined
        assert False, "Should have raised an exception"

# Generated at 2022-06-23 02:53:56.740755
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        assert e.args == ("Test exception",)


# Generated at 2022-06-23 02:53:59.382135
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass
    try:
        raise CustomException
    except:
        assert get_exception().__class__ == CustomException


# Generated at 2022-06-23 02:54:04.506493
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    exception = None

    try:
        raise TestException('This is a test.')
    except TestException:
        exception = get_exception()
        pass  # Need the pass here since we're using except: pass to avoid pylint warnings.

    assert isinstance(exception, TestException)
    assert 'This is a test.' == str(exception)

# Generated at 2022-06-23 02:54:06.936994
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError:
        exc = get_exception()
    assert str(exc) == "Test exception"


# Generated at 2022-06-23 02:54:10.012272
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert str(e) == 'test'



# Generated at 2022-06-23 02:54:14.126219
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'This is a test'
        assert e.__class__.__name__ == 'RuntimeError'

# Generated at 2022-06-23 02:54:17.533821
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
        assert e.args == ('test exception',), 'Got exception: %s' % (e,)



# Generated at 2022-06-23 02:54:22.995784
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise ValueError('1')
        except:
            try:
                raise ValueError('2')
            except:
                e = get_exception()
                if e.args[0] != '2':
                    raise AssertionError("get_exception() got the wrong exception")
    except AssertionError as e:
        print(e)


# Generated at 2022-06-23 02:54:29.589376
# Unit test for function get_exception
def test_get_exception():

    import traceback

    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        formatted_tb = traceback.format_exc()

    assert str(e) == 'foo'
    assert formatted_tb == 'Traceback (most recent call last):\n  File "%s", line 6, in test_get_exception\n    raise ValueError(\'foo\')\nValueError: foo\n' % (__file__,)

# Generated at 2022-06-23 02:54:34.520394
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name, missing-docstring
    def test():
        1/0

    try:
        test()
    except:
        e = get_exception()
        if not isinstance(e, ZeroDivisionError):
            raise AssertionError("Got wrong exception %r" % e)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:54:38.400439
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('')
    except TestException:
        e = get_exception()

    assert isinstance(e, TestException)

# Generated at 2022-06-23 02:54:42.483806
# Unit test for function get_exception
def test_get_exception():
    try:
        dict()[0]
    except Exception:
        exc = get_exception()
        assert isinstance(exc, KeyError)
        assert exc.args == (0,)



# Generated at 2022-06-23 02:54:45.864008
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            g()
        except Exception:
            e = get_exception()
            assert e is not None
            return e

    def g():
        raise ValueError()

    assert f() == g()

# Generated at 2022-06-23 02:54:48.187222
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
    assert exc.args[0] == "foo"

# Generated at 2022-06-23 02:54:53.998278
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception as e:
        assert e is get_exception()
    try:
        1/0
    except:
        assert isinstance(get_exception(), ZeroDivisionError)
    try:
        1/0
    except:
        ex = get_exception()
        assert isinstance(ex, ZeroDivisionError)
        assert 'division by zero' in str(ex)

# Test for literal_eval

# Generated at 2022-06-23 02:54:58.332257
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing get_exception')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'Testing get_exception'



# Generated at 2022-06-23 02:55:04.137184
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('TestException')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('TestException',)

if __name__ == '__main__':
    test_get_exception()