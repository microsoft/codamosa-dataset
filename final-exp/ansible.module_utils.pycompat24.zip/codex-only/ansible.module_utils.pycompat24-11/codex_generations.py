

# Generated at 2022-06-23 02:45:04.909679
# Unit test for function get_exception
def test_get_exception():
    def raise_type(t):
        raise t('an exception')

    try:
        raise_type(RuntimeError)
    except RuntimeError:
        extype = get_exception().__class__
        assert extype == RuntimeError


# Generated at 2022-06-23 02:45:08.773120
# Unit test for function get_exception
def test_get_exception():
    # This function throws an exception.  We cover the case where we catch an exception
    # in case the caller is manipulating their exception context
    try:
        raise RuntimeError('We failed!')
    except RuntimeError:
        e = get_exception()

    assert str(e) == 'We failed!'


# Generated at 2022-06-23 02:45:11.560316
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('Test')
    except Exception:
        exception = get_exception()
        assert exception.args == ('Test',)



# Generated at 2022-06-23 02:45:15.079003
# Unit test for function get_exception
def test_get_exception():
    '''Test that get_exception works'''
    try:
        raise Exception("BOOM")
    except:
        e = get_exception()
        assert("BOOM" in str(e))

# Generated at 2022-06-23 02:45:21.080009
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Some value')
    except Exception:
        e = get_exception()
        assert type(e) == ValueError
        assert text_type(e) == 'Some value'
        assert e.args == ('Some value',)

# Generated at 2022-06-23 02:45:23.926528
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except:
        e = get_exception()
    assert isinstance(e, Exception)

# Generated at 2022-06-23 02:45:27.490931
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-23 02:45:34.183483
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring

    import io
    import sys

    class TestException(Exception):
        pass

    with io.BytesIO() as buf:
        try:
            raise TestException
        except TestException:
            tb = sys.exc_info()[2]

        def exception_repr(exc):
            return 'type: {}, value: {}, traceback: {}'.format(
                type(exc), exc, tb)

        try:
            raise TestException
        except TestException:
            e = get_exception()

        print('raise: {}'.format(exception_repr(e)), file=buf)


# Generated at 2022-06-23 02:45:35.857794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        e = get_exception()
        assert e.message == "Test Exception"

# Generated at 2022-06-23 02:45:39.542729
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:45:42.622053
# Unit test for function get_exception
def test_get_exception():
    """Return the current exception."""

    try:
        raise ValueError("test")
    except:  # noqa
        e = get_exception()

    assert str(e) == "test"

# Generated at 2022-06-23 02:45:48.577625
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise RuntimeError('Error one')
        except RuntimeError:
            raise Exception('Error two')
    except Exception as e:
        assert e == get_exception()
    try:
        try:
            raise RuntimeError('Error one')
        except RuntimeError:
            raise Exception('Error two')
    except Exception:
        e = get_exception()
        assert e == 'Error two'
        assert isinstance(e, Exception)



# Generated at 2022-06-23 02:45:52.565503
# Unit test for function get_exception
def test_get_exception():
    try:
        int("lalala")
        assert(False)
    except:
        assert(isinstance(get_exception(), ValueError))
        e = get_exception()
        assert(isinstance(e, ValueError))
        assert(str(e) == 'invalid literal for int() with base 10: \'lalala\'')



# Generated at 2022-06-23 02:45:59.386384
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert isinstance(e, ZeroDivisionError)
    # Test the unit test
    try:
        test_get_exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert isinstance(e, RuntimeError)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:46:03.050745
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        err = get_exception()
        assert err.args == ('foobar',)

# Generated at 2022-06-23 02:46:05.320072
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        res = get_exception()
    assert type(res) == ZeroDivisionError


# Generated at 2022-06-23 02:46:09.581616
# Unit test for function get_exception
def test_get_exception():
    try:
        int("not a number")
        raise Exception("Failed to get exception")
    except:
        foo = get_exception()
    assert isinstance(foo, ValueError)
    assert foo.args[0] == 'invalid literal for int() with base 10: \'not a number\''

# Generated at 2022-06-23 02:46:13.419022
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works as expected."""

# Generated at 2022-06-23 02:46:17.202280
# Unit test for function get_exception
def test_get_exception():
    """Test that we can get the current exception."""
    try:
        raise ValueError('test exception')
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'test exception'

# Generated at 2022-06-23 02:46:20.350413
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        error = get_exception()

    assert error.__class__ == ValueError

# vim: set et sw=4 ts=4 sts=4

# Generated at 2022-06-23 02:46:22.904462
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Foo')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('Foo',)

# Generated at 2022-06-23 02:46:26.213271
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('error message')
    except RuntimeError:
        err = get_exception()
    assert isinstance(err, RuntimeError)
    assert str(err) == 'error message'



# Generated at 2022-06-23 02:46:29.980915
# Unit test for function get_exception
def test_get_exception():
    e = get_exception()
    assert e is None
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:46:34.239625
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except AssertionError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:46:37.380996
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("hi")
    except Exception:
        e = get_exception()
        if e.args != ('hi',):
            print("Error: unexpected exception", e)
            return False

    return True

# Generated at 2022-06-23 02:46:39.522207
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:43.754085
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('The should be raised exception')
    except:
        exc = get_exception()
    assert exc.args == ('The should be raised exception',)

# Generated at 2022-06-23 02:46:47.317269
# Unit test for function get_exception
def test_get_exception():
    err = None
    try:
        raise RuntimeError('Test exception')
    except Exception:
        err = get_exception()
    assert err
    assert isinstance(err, RuntimeError)
    assert str(err) == 'Test exception'

# Generated at 2022-06-23 02:46:51.091696
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test exception'


# Generated at 2022-06-23 02:46:54.656712
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except:
        e = get_exception()
    assert e.__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-23 02:46:56.457309
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:59.667740
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        foo_exception = get_exception()
    assert foo_exception.args == ('foo',)
    assert foo_exception.__str__() == 'foo'

# Generated at 2022-06-23 02:47:02.709706
# Unit test for function get_exception
def test_get_exception():
    exception_string = 'this is an exception'

    try:
        raise Exception(exception_string)
    except:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == exception_string

# Generated at 2022-06-23 02:47:15.481143
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)



# Generated at 2022-06-23 02:47:21.759329
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        try:
            raise RuntimeError('get_exception')
        except Exception as e:
            assert e is get_exception()
        try:
            raise RuntimeError('get_exception')
        except Exception:
            e = get_exception()
            assert str(e) == 'get_exception'
            assert e.__class__.__name__ == 'RuntimeError'
    test_func()

# Generated at 2022-06-23 02:47:24.482811
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('MyException: test_get_exception')
    except MyException:
        e = get_exception()
    assert isinstance(e, MyException)
    assert str(e) == 'MyException: test_get_exception'

# Generated at 2022-06-23 02:47:28.797372
# Unit test for function get_exception
def test_get_exception():
    def fail():
        try:
            1 / 0
        except Exception:
            return get_exception()

    result = fail()
    assert str(result) == 'division by zero'
    assert result.__class__.__name__ == 'ZeroDivisionError'
    assert type(result) is ZeroDivisionError


# Generated at 2022-06-23 02:47:31.996998
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except ValueError:
        exc = get_exception()
    assert exc.args == ('Test',)


# Generated at 2022-06-23 02:47:34.753406
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:47:38.560586
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Hello')
    except Exception as e:
        e2 = get_exception()
    assert e is e2



# Generated at 2022-06-23 02:47:40.963143
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        exc = get_exception()

    assert str(exc) == 'test'



# Generated at 2022-06-23 02:47:44.779605
# Unit test for function get_exception
def test_get_exception():
    '''get_exception should return the correct exception'''

    try:
        raise SyntaxError
    except Exception:
        e = get_exception()

    assert isinstance(e, SyntaxError), 'get_exception() failed to return the current exception'



# Generated at 2022-06-23 02:47:48.590443
# Unit test for function get_exception
def test_get_exception():
    ''' Test get_exception '''
    def raise_exception():
        ''' Inner function to test exception '''
        raise Exception('Test exception')

    try:
        raise_exception()
    except Exception:
        result = get_exception()
        assert 'Test exception' in str(result)
    else:
        raise Exception('Test exception not raised')

# Generated at 2022-06-23 02:47:51.141970
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except Exception:
        err = get_exception()
        assert (str(err) == 'test')

# Unit test to make sure literal_eval can handle the
# types we expect

# Generated at 2022-06-23 02:47:53.832697
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-23 02:47:56.988734
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        rv = get_exception()
        assert rv is e
        assert str(rv) == 'foo'

# Generated at 2022-06-23 02:47:59.984425
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:48:03.278032
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'foo', "got %s" % exc



# Generated at 2022-06-23 02:48:10.390485
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert(e.args[0] == 'Test exception')

    # Make sure we can get a subclassed exception
    class MyException(Exception):
        pass
    try:
        raise MyException('Test exception')
    except Exception:
        e = get_exception()
        assert(isinstance(e, MyException))
        assert(e.args[0] == 'Test exception')


# Generated at 2022-06-23 02:48:13.017921
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'



# Generated at 2022-06-23 02:48:16.144255
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:48:18.599859
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a')
    except ValueError as e:
        assert get_exception() is e
    else:
        assert False, 'Exception not raised'



# Generated at 2022-06-23 02:48:23.547484
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:27.284061
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert str(e) == 'test'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:48:30.933023
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        if str(e) != 'foo':
            raise Exception('Expected "foo" got {}'.format(str(e)))


# Generated at 2022-06-23 02:48:34.189529
# Unit test for function get_exception
def test_get_exception():
    import pytest
    e = None
    try:
        raise ValueError('foobar')
    except ValueError:
        e = get_exception()

    assert e.args[0] == 'foobar'
    assert type(e) == ValueError

# Generated at 2022-06-23 02:48:38.664384
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exception = get_exception()
        assert exception.__class__ is ZeroDivisionError


# Generated at 2022-06-23 02:48:41.860831
# Unit test for function get_exception
def test_get_exception():
    assert literal_eval('1') == 1
    assert literal_eval('False') is False
    assert literal_eval('{}') == {}
    assert literal_eval('[]') == []
    assert literal_eval('"foo"') == "foo"



# Generated at 2022-06-23 02:48:49.183540
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError as e:
        e1 = e
    try:
        raise ValueError("bar")
    except ValueError as e:
        e2 = e

    assert get_exception() == e2
    if sys.version_info[0] < 3:
        assert sys.exc_info() == (RuntimeError, e1, None)
    else:
        assert sys.exc_info() == (RuntimeError, e1)
    assert get_exception() == e2
    import traceback
    assert traceback.format_exc() == ''
    try:
        get_exception()
    except ValueError as e:
        assert e == e2

# Generated at 2022-06-23 02:48:51.371563
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test exception'

# Generated at 2022-06-23 02:48:55.481241
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('x')
    except ValueError:
        exception = get_exception()
        assert exception.args == ('x',)

    # TODO: add a test for `sys.exc_info`



# Generated at 2022-06-23 02:48:58.122301
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert e
        assert e.args == ('test',)



# Generated at 2022-06-23 02:49:02.141548
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        return_value = get_exception()
        assert return_value.args == ('test',)

# Generated at 2022-06-23 02:49:07.831541
# Unit test for function get_exception
def test_get_exception():
    # Test works by simply making sure that get_exception doesn't fail when
    # it's called.
    try:
        raise Exception('Test')
    except Exception as e:
        exc = get_exception()
        if str(e) != str(exc):
            raise Exception('Unexpected result from get_exception: %s != %s' % (e, exc))

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:49:12.159833
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        assert e == get_exception()



# Generated at 2022-06-23 02:49:14.399470
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:49:18.936810
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert type(e) == Exception, "Exception found is not the current exception"
    assert e.__name__ == "Exception", "Unexpected Exception type"

# Generated at 2022-06-23 02:49:21.488003
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this')
    except:
        exc = get_exception()
    assert exc.args == ('this',)

# Generated at 2022-06-23 02:49:25.596980
# Unit test for function get_exception
def test_get_exception():
    '''Test that the get_exception function returns the currently handled exception.'''

    err = None
    try:
        raise ValueError()
    except ValueError:
        err = get_exception()

    assert(type(err) is ValueError)



# Generated at 2022-06-23 02:49:29.275099
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise TypeError('foo')
        except Exception:
            e = get_exception()
            return str(e)
    if f() != 'foo':
        raise AssertionError("assertion failed: " + repr(f()))

# Generated at 2022-06-23 02:49:42.139178
# Unit test for function get_exception
def test_get_exception():
    # Subset of the tests in Python's Lib/test/test_exceptions.py

    def test_raise_catch(e):
        """Catch an exception and verify that the caught exception equals the
        exception that was raised.
        """
        try:
            raise e
        except BaseException as ex:
            assert ex == e
            assert ex is not e
            assert type(ex) == type(e)
            assert ex.__class__ == e.__class__
            assert type(ex) is type(e)
            assert ex.__class__ is e.__class__
            assert ex.args == e.args

    # pylint: disable=too-many-branches,too-many-statements
    def test_exception(klass, args, str_repr):
        """Subclass of BaseException"""
        e

# Generated at 2022-06-23 02:49:47.633509
# Unit test for function get_exception
def test_get_exception():
    def raises_exception():
        try:
            1/0  # pylint: disable=pointless-statement
        except:
            return get_exception()
    try:
        raises_exception()
    except Exception:
        # We don't care what kind of exception it is
        # But if this fails then we're in big trouble
        assert True


# Generated at 2022-06-23 02:49:53.995337
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass


# Generated at 2022-06-23 02:49:56.628381
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test")
    except Exception:
        e = get_exception()
        assert(str(e)) == "test"



# Generated at 2022-06-23 02:50:00.394337
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo bar')
    except Exception:
        e = get_exception()
    assert e.args == ('foo bar',)


# Generated at 2022-06-23 02:50:05.163337
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except Exception:
        e = get_exception()
    assert type(e) == ValueError
    assert e.args[0] == 'invalid literal for int() with base 10: \'a\''


# Generated at 2022-06-23 02:50:07.726003
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise ValueError(1, 2, 3)
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:50:13.999853
# Unit test for function get_exception
def test_get_exception():
    import pytest
    def test_raiser():
        raise ValueError('test')
    def test_raiser_no_args():
        raise ValueError()
    try:
        test_raiser()
    except ValueError as e:
        assert e == get_exception()
    try:
        test_raiser_no_args()
    except ValueError as e:
        assert e == get_exception()

# Generated at 2022-06-23 02:50:17.741611
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a test exception')
    except ValueError:
        result = get_exception()
    assert isinstance(result, ValueError)
    assert 'a test exception' in str(result) or 'a test exception' in result.args

# Generated at 2022-06-23 02:50:19.493089
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception as e:
        pass
    assert get_exception() == e

# Generated at 2022-06-23 02:50:22.097892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test value")
    except:
        exc = get_exception()
        pass

    assert str(exc) == 'test value'


# Generated at 2022-06-23 02:50:26.834244
# Unit test for function get_exception
def test_get_exception():
    import pytest
    def f1():
        raise ValueError('this is the error')
    def f2():
        try:
            f1()
        except Exception:
            e = get_exception()
            return e
    exc = f2()
    assert exc.args[0] == 'this is the error'
    assert isinstance(exc, ValueError)
    assert exc.__class__.__name__ == 'ValueError'


# Generated at 2022-06-23 02:50:31.767767
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foo')
    except ValueError as e:
        return_value = get_exception()
        assert return_value is e
    except Exception:
        return 0
    else:
        return 0
    assert 0, "Didn't raise an exception"
test_get_exception()


# Generated at 2022-06-23 02:50:33.771099
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An error occurred')
    except:
        e = get_exception()
        assert str(e) == 'An error occurred'

# Generated at 2022-06-23 02:50:36.655240
# Unit test for function get_exception
def test_get_exception():
    class FakeException(Exception):
        pass

    try:
        raise FakeException('Fake Exception')
    except Exception:
        assert type(get_exception()) == FakeException

# Generated at 2022-06-23 02:50:40.446398
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('exceptional')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'exceptional'
    assert isinstance(e, Exception)

# Generated at 2022-06-23 02:50:43.498187
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test error")
    except:
        exc = get_exception()
    assert isinstance(exc, RuntimeError)
    assert str(exc) == "Test error"

# Generated at 2022-06-23 02:50:51.210289
# Unit test for function get_exception
def test_get_exception():
    import os.path
    # Simple vanilla test
    try:
        raise Exception('failure')
    except Exception:
        e = get_exception()
        if e.args != ('failure',):
            raise AssertionError('Unexpected exception: %r' % e)
    # Test with some chained exceptions
    try:
        a = 1/0
    except Exception:
        # This is a Python 2.x syntax
        e = get_exception()
        try:
            b = os.path.join(*('a', 'b'))
        except Exception:
            try:
                c = e+1
            except Exception:
                e = get_exception()
                if e.args != ((1, 0),):
                    raise AssertionError('Unexpected exception: %r' % e)
    # Test with some

# Generated at 2022-06-23 02:50:55.767723
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise Exception("Foo")
    try:
        test()
    except Exception:
        e = get_exception()
    assert str(e) == "Foo"



# Generated at 2022-06-23 02:51:00.349123
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('My exception')
    except:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'My exception'


# Generated at 2022-06-23 02:51:04.385477
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A value error')
    except Exception:
        e = sys.exc_info()[1]
        got_exception = get_exception()
        assert e == got_exception


# Generated at 2022-06-23 02:51:06.845920
# Unit test for function get_exception
def test_get_exception():
    try:
        l = []
        l[1]
    except IndexError:
        assert(get_exception())


# Generated at 2022-06-23 02:51:08.590232
# Unit test for function get_exception
def test_get_exception():

    try:
        raise ValueError()
    except:
        assert isinstance(get_exception(), ValueError)

# Generated at 2022-06-23 02:51:11.780537
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except Exception:
        assert get_exception().args[0] == 'test exception'


# Generated at 2022-06-23 02:51:17.311225
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'foo'
test_get_exception()
del test_get_exception



# Generated at 2022-06-23 02:51:20.169608
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'



# Generated at 2022-06-23 02:51:22.457722
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Hello")
    except ValueError:
        e = get_exception()
    assert e.args == ('Hello',)

# Generated at 2022-06-23 02:51:25.269922
# Unit test for function get_exception
def test_get_exception():
    try:
        raise _TestException()
    except Exception:
        e = get_exception()
        assert isinstance(e, _TestException), "get_exception should catch the last exception raised"



# Generated at 2022-06-23 02:51:26.988113
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        exc = get_exception()
        assert isinstance(exc, Exception)


# Generated at 2022-06-23 02:51:29.069579
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=invalid-name
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:51:32.255675
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing exception')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'testing exception'

# Generated at 2022-06-23 02:51:34.886509
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except Exception:
        tb_info = get_exception()
        return tb_info.args[0] == "Test exception"

# Generated at 2022-06-23 02:51:38.393452
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-23 02:51:44.133563
# Unit test for function get_exception
def test_get_exception():
    # Make sure that get_exception is imported correctly
    try:
        raise RuntimeError("This is an exception")
    except:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert "This is an exception" in str(e)

# Generated at 2022-06-23 02:51:46.510606
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        assert get_exception().args == ('foo',)

# Generated at 2022-06-23 02:51:52.099881
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils._text import to_bytes
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert 'This is an exception' in to_bytes(e)



# Generated at 2022-06-23 02:51:56.001425
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Error')
    except:
        exc = get_exception()
        assert isinstance(exc, RuntimeError)
        assert str(exc) == 'Error'

test_get_exception()

# Generated at 2022-06-23 02:52:07.922200
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    # Dummy function for testing get_exception()
    def do_something(arg1):
        raise ValueError(to_native(arg1))

    # Unit test for get_exception().  Only run when this file is executed directly.
    module = AnsibleModule(
        argument_spec=dict(
            arg1=dict(),
        )
    )

    try:
        do_something(module.params['arg1'])
    except Exception:
        e = get_exception()
    module.exit_json(msg=to_native(e))

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:52:11.765355
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
    else:
        raise AssertionError('ZeroDivisionError not raised')


# Generated at 2022-06-23 02:52:15.851349
# Unit test for function get_exception
def test_get_exception():
    class MyError(Exception):
        pass

    def func_with_exception():
        try:
            raise MyError("This error is expected")
        except Exception:
            e = get_exception()
            return e

    assert func_with_exception().__class__ == MyError
    assert func_with_exception().args == ("This error is expected",)

# Generated at 2022-06-23 02:52:19.208711
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test error')
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.message == 'test error'



# Generated at 2022-06-23 02:52:24.226468
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception() function.

    Test that get_exception gets the last exception.  We do this by
    testing the function with a try/except block where we raise the
    exception.
    """
    try:
        raise ModuleError('error message')
    except BaseException:
        e = get_exception()

    assert str(e) == 'error message'

# Generated at 2022-06-23 02:52:26.316399
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        return get_exception()



# Generated at 2022-06-23 02:52:28.743085
# Unit test for function get_exception
def test_get_exception():
    try:
        raise(TypeError)
    except Exception:
        e = get_exception()
    assert isinstance(e, TypeError)


# Generated at 2022-06-23 02:52:30.426322
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        assert get_exception()

# Generated at 2022-06-23 02:52:32.574077
# Unit test for function get_exception

# Generated at 2022-06-23 02:52:36.381940
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name,invalid-name,redefined-builtin,too-few-public-methods
    try:
        raise ValueError
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.__class__ == ValueError

# Generated at 2022-06-23 02:52:37.794818
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('err')
    except Exception:
        e = get_exception()
        assert 'err' in str(e)

# Generated at 2022-06-23 02:52:39.898345
# Unit test for function get_exception
def test_get_exception():
    def function():
        try:
            1/0
        except:
            assert get_exception() is not None

    function()

# Generated at 2022-06-23 02:52:41.971839
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing...')
    except RuntimeError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:52:50.802488
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import ansible.module_utils.basic

    class TestGetException(unittest.TestCase):
        ''' Test get_exception. '''
        # pylint: disable=no-self-use
        def test_get_exception(self):
            ''' Test get_exception. '''
            try:
                raise RuntimeError('foo')
            except RuntimeError:
                got = ansible.module_utils.basic.get_exception()
                self.assertEqual(got, 'foo')

    unittest.main(defaultTest='TestGetException.test_get_exception')



# Generated at 2022-06-23 02:52:55.519416
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert(str(e) == 'Test exception')



# Generated at 2022-06-23 02:52:58.491558
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception message.')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'An exception message.'


# Generated at 2022-06-23 02:53:04.102040
# Unit test for function get_exception
def test_get_exception():
    def raise_test_exception(first, second):
        raise ValueError("testing")
    try:
        raise_test_exception("first", "second")
    except:
        e = get_exception()
    assert str(e) == "testing"



# Generated at 2022-06-23 02:53:10.075900
# Unit test for function get_exception
def test_get_exception():
    try:
        raise type('FooError', (Exception,), dict(foo='bar'))
    except:
        e = get_exception()
    print(e)
    assert e.foo == 'bar', "Exception was not correctly raised"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:53:12.335428
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AttributeError("Error message")
    except AttributeError as e:
        assert(get_exception() == e)

# Generated at 2022-06-23 02:53:14.974315
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Bang!")
    except ValueError:
        e = get_exception()
        assert Exception("Bang!") == e, e


# Generated at 2022-06-23 02:53:23.536400
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise ValueError("Inner")
        except:
            e = get_exception()
            assert str(e) == "Inner"
            return e

    try:
        raise ValueError("Outer")
    except Exception as e:
        assert str(e) == "Outer"
        assert repr(e) == "ValueError('Outer',)"
        assert e == inner()

# Generated at 2022-06-23 02:53:26.341064
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SystemError()
    except:
        e = get_exception()
    assert sys.exc_info()[1] == e

# Generated at 2022-06-23 02:53:30.727934
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        err = get_exception()
        assert isinstance(err, ValueError)
        assert err is not None



# Generated at 2022-06-23 02:53:38.042219
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exc = get_exception()

    # check the Exception object
    assert exc.args == ('test exception',)
    assert str(exc) == 'test exception'

    # check if get_exception() returned the most recent exception
    try:
        raise Exception('another exception')
    except Exception:
        assert get_exception() is not exc

# Generated at 2022-06-23 02:53:41.565245
# Unit test for function get_exception

# Generated at 2022-06-23 02:53:44.406039
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        assert get_exception() is e

    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()

    assert isinstance(e, RuntimeError)
    assert str(e) == 'test'

# Generated at 2022-06-23 02:53:47.422438
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()
        assert exc.args[0] == 'foo'



# Generated at 2022-06-23 02:53:50.611010
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('xxx')
    except Exception:
        exception = get_exception()
        assert str(exception) == 'xxx'
        assert type(exception) is Exception

# Generated at 2022-06-23 02:54:01.441284
# Unit test for function get_exception
def test_get_exception():
    'Subclass instance exception testing'
    class MyException(Exception):
        'Subclass of Exception'
        def __init__(self, message, errno=None):
            self.message = message
            self.errno = errno

    def raise_my_exception(message, errno=None):
        'Raise an instance of MyException'
        raise MyException(message, errno)

    import sys
    try:
        raise_my_exception('My message')
    except:
        exc_info = sys.exc_info()

    _, exc, _ = exc_info
    assert exc.message == 'My message'
    assert isinstance(exc, MyException)

    _, exc, _ = exc_info
    assert str(exc) == 'My message'
    assert exc.errno is None

# Generated at 2022-06-23 02:54:04.992829
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is an exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception) and str(e) == 'this is an exception'



# Generated at 2022-06-23 02:54:07.741751
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("error message")
    except Exception:
        assert get_exception().args[0] == "error message"

# Generated at 2022-06-23 02:54:13.003423
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert e == get_exception()

# needs unittest2 for python 2.6
try:
    import unittest2 as unittest
except ImportError:
    import unittest


# Generated at 2022-06-23 02:54:17.768754
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

    try:
        raise KeyError
    except KeyError:
        e = get_exception()
        assert isinstance(e, KeyError)

# Generated at 2022-06-23 02:54:20.896715
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise Exception('Test exception')

    try:
        test()
    except Exception:
        e = get_exception()
        assert e.args[0] == text_type('Test exception')

# Generated at 2022-06-23 02:54:24.266573
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("this is an error")
    except ValueError:
        e = get_exception()

    assert str(e) == "this is an error"

# Generated at 2022-06-23 02:54:27.095766
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception function."""
    try:
        raise Exception()
    except Exception:
        test_exc = get_exception()
    assert test_exc is not None

# Generated at 2022-06-23 02:54:31.994760
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException
    except TestException:
        e = get_exception()
    assert isinstance(e, TestException)
    try:
        raise TestException('argh!')
    except TestException:
        e = get_exception()
    assert str(e) == 'argh!'



# Generated at 2022-06-23 02:54:36.894753
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError as e:
        assert get_exception() == e
    try:
        1/0
    except ZeroDivisionError as e:
        assert get_exception() == e


# Generated at 2022-06-23 02:54:42.427012
# Unit test for function get_exception
def test_get_exception():
    class FooException(Exception):
        pass
    try:
        raise FooException('test_get_exception')
    except FooException:
        the_exception = get_exception()
    assert isinstance(the_exception, FooException)
    assert the_exception.args == ('test_get_exception',)

# Generated at 2022-06-23 02:54:46.163750
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise ValueError('Testing exception')
    except ValueError:
        e = get_exception()
    assert type(e) is ValueError
    assert e.args == ('Testing exception',)


# Generated at 2022-06-23 02:54:47.676471
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise ValueError('Invalid value')
        except Exception:
            e = get_exception()
            assert e.args[0] == 'Invalid value'
    test()


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:54:50.746143
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo'
    assert repr(e) == 'RuntimeError(\'foo\',)'

# Generated at 2022-06-23 02:54:57.135757
# Unit test for function get_exception
def test_get_exception():
    # Test that when an exception is thrown, it is returned by
    # get_exception()
    try:
        raise Exception("Fake exception")
    except Exception:
        e = get_exception()
    assert str(e) == "Fake exception"


# Generated at 2022-06-23 02:55:05.109787
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('value is wrong')
    except:
        (etype, value, traceback) = sys.exc_info()
        try:
            exc = get_exception()
        except:
            (etype2, value2, traceback2) = sys.exc_info()
            print("get_exception raised: %s" % value2)
            assert False
        assert exc == value