

# Generated at 2022-06-23 02:45:02.339845
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        e = get_exception()
    assert str(e) == 'test exception'



# Generated at 2022-06-23 02:45:05.451487
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__ is ZeroDivisionError



# Generated at 2022-06-23 02:45:07.852950
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        exception = get_exception()
    assert str(exception) == 'foo'


# Generated at 2022-06-23 02:45:10.779732
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert 'foo' in str(e)


# Generated at 2022-06-23 02:45:13.694408
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
        print(e)
        assert type(e) == RuntimeError
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:45:21.276133
# Unit test for function get_exception
def test_get_exception():
    import traceback
    def inner():
        try:
            raise KeyError()
        except:
            return get_exception()

    def outer():
        try:
            return inner()
        except:
            return get_exception()

    exception = outer()
    assert isinstance(exception, KeyError)
    assert traceback.format_exc() == str(exception)

# Generated at 2022-06-23 02:45:27.530353
# Unit test for function get_exception
def test_get_exception():
    # It should return the current exception
    # In this case, this is a NameError
    try:
        raise NameError("Exception raised on purpose for test")
    except NameError:
        the_exception = get_exception()
    assert isinstance(the_exception, NameError)
    assert the_exception.args[0] == "Exception raised on purpose for test"

    # If there is no exception, it should return None
    assert get_exception() is None



# Generated at 2022-06-23 02:45:30.079269
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('this should get caught')
    except AssertionError:
        e = get_exception()
        assert e.args[0] == 'this should get caught'
        return e



# Generated at 2022-06-23 02:45:34.951566
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:41.913572
# Unit test for function get_exception
def test_get_exception():
    import pytest

    try:
        1/0
    except Exception as e:
        # pytest does a repr() on it's arguments.  And repr() can sometime be
        # different between Python 2 and Python 3.  So we need to assert that
        # the repr() of the objects are the same across Python versions
        # regardless of the raw exception.
        assert repr(get_exception()) == repr(e)
    else:
        pytest.fail('1/0 did not raise an exception!')

# Generated at 2022-06-23 02:45:44.780279
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    def foo():
        try:
            raise Exception('e')
        except:
            return get_exception()
    assert foo().args == ('e',)


# Generated at 2022-06-23 02:45:47.182772
# Unit test for function get_exception
def test_get_exception():
    '''test function get_exception'''
    try:
        raise ValueError()
    except:
        exception = get_exception()
        assert isinstance(exception, ValueError)

# Generated at 2022-06-23 02:45:49.675948
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:55.732708
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    exception = None
    try:
        1 / 0
    except Exception:
        exception = get_exception()
    assert isinstance(exception, ZeroDivisionError)


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:46:01.442264
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function

    This is a very simple function so we don't have to do much here.  Mostly just
    check that we get something back.
    """
    e = None
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('test',)


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:46:09.198390
# Unit test for function get_exception
def test_get_exception():
    old_exc_info = sys.exc_info()
    try:
        raise Exception('foo')
        assert False, 'Should have raised exception'
    except Exception:
        try:
            exc = get_exception()
            assert str(exc) == 'foo'
            assert isinstance(exc, Exception)
        finally:
            # Make sure we can clear the exception type so that the unit test framework
            # does not see it and bark about an unhandled exception
            sys.exc_clear()
    finally:
        assert sys.exc_info() == old_exc_info


# Generated at 2022-06-23 02:46:12.928861
# Unit test for function get_exception
def test_get_exception():
    class WeirdException(Exception):
        pass

    try:
        raise WeirdException('foo')
    except WeirdException:
        e = get_exception()

    assert e.args == ('foo', )



# Generated at 2022-06-23 02:46:16.726141
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        assert str(get_exception()) == 'test'


# vim: set noexpandtab ts=4 sw=4:

# Generated at 2022-06-23 02:46:27.678776
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception.

    This function is tricky to test.  We need to verify that it returns
    the right exception even when called inside an except clause.  We
    also need to verify that it doesn't return anything when called
    outside of an except clause.

    This test is significantly different from other tests because it
    runs the code rather than testing the results.  This means that it
    is easy to have false positives where the test succeeds but the
    code fails.  To prevent that, it uses a special variable that does
    not exist in the function under test.  If any part of this test
    fails, it puts that variable into the outer scope and then fails.
    The other tests will then pick up the variable and fail.  This way
    these tests will report the problems they find.
    """
    # pylint: disable=unused-argument

# Generated at 2022-06-23 02:46:31.640835
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:34.655100
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('ok')
    except ValueError:
        e = get_exception()
        assert e.args == ('ok', )
    else:
        raise AssertionError('should never get here')

# Generated at 2022-06-23 02:46:38.067259
# Unit test for function get_exception
def test_get_exception():
    try:
        5/0
    except:
        e = get_exception()
        # Only check for the message since 2.4 through 2.6 have different
        # messages
        assert 'integer division or modulo by zero' in str(e)



# Generated at 2022-06-23 02:46:42.041021
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'This is a test'
        assert e.args == ('This is a test',)
    else:
        raise AssertionError('No exception caught')



# Generated at 2022-06-23 02:46:45.445620
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:46:48.597327
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        e = get_exception()

    assert str(e) == 'Foo'


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:46:59.443720
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

if sys.version_info < (3, 3):
    def get_type_args(t):
        """Get all arguments of a generic type.

        This function works on Python 2 and Python 3 without the need to install
        packages like `typing`
        """
        if t.__module__ == 'typing' and t.__name__ == 'Type':
            return ()
        elif hasattr(t, '__parameters__'):
            return t.__parameters__
        elif hasattr(t, '__args__'):
            return t.__args__
        else:
            return ()

# Generated at 2022-06-23 02:47:06.570473
# Unit test for function get_exception
def test_get_exception():
    """Test that the code to get the exception works in Python 2.4-3.x"""
    try:
        raise RuntimeError('This should be caught by get_exception')
    except RuntimeError:
        exc = get_exception()
        assert str(exc) == 'This should be caught by get_exception'


# Generated at 2022-06-23 02:47:09.354262
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:47:11.961954
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Hello World")
    except:
        e = get_exception()
    assert str(e) == "Hello World"



# Generated at 2022-06-23 02:47:15.518404
# Unit test for function get_exception
def test_get_exception():
    def f1(e):
        try:
            raise e
        except Exception:
            return get_exception()

    e = Exception()
    assert f1(e) is e

# Unit test literal_eval

# Generated at 2022-06-23 02:47:22.804664
# Unit test for function get_exception
def test_get_exception():
    # We can only test when the interpreter is called with -O to disable
    # optimizations.  This is the default in ansible's __main__.py.
    # (__debug__ is False when called with -O)
    if __debug__:
        return

    def gen_exception():
        try:
            raise RuntimeError('foo')
        except RuntimeError:
            e = get_exception()
            if sys.version_info[0] >= 3:
                raise e from None
            else:
                raise e

    try:
        gen_exception()
    except RuntimeError as e:
        assert e.args[0] == 'foo'
        assert e.__context__ is None
    else:
        assert False, 'No exception was raised'

# Generated at 2022-06-23 02:47:25.731208
# Unit test for function get_exception
def test_get_exception():
    '''Test function get_exception'''
    try:
        raise RuntimeError('This is a test exception')
    except Exception:
        assert get_exception().args[0] == 'This is a test exception'

# Generated at 2022-06-23 02:47:28.984704
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
        assert e.args == ('test exception',)

# Generated at 2022-06-23 02:47:34.650995
# Unit test for function get_exception
def test_get_exception():
    import errno

    try:
        raise OSError(errno.ENOENT, os.strerror(errno.ENOENT))
    except OSError:
        e = get_exception()
        assert e.errno == errno.ENOENT
        assert e.filename == 'foo'



# Generated at 2022-06-23 02:47:39.152857
# Unit test for function get_exception
def test_get_exception():
    # Python 2.4 raises "Exception" not "<type 'exceptions.Exception'>"
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert(str(e) == 'Exception')



# Generated at 2022-06-23 02:47:42.911311
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('What is this')
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)
        assert e.args == ('What is this',)

# Generated at 2022-06-23 02:47:47.007996
# Unit test for function get_exception
def test_get_exception():
    def my_func(arg):
        if arg:
            raise RuntimeError('Test exception')
        else:
            return True

    try:
        my_func(True)
        assert False
    except Exception:
        ex = get_exception()
        assert ex.__class__ == RuntimeError
        assert str(ex) == 'Test exception'

    assert my_func(False) is True

# Generated at 2022-06-23 02:47:52.519791
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
    assert e.args[0] == 'test'
    assert str(e) == 'test'

# Generated at 2022-06-23 02:47:55.650867
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo bar')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'Foo bar'



# Generated at 2022-06-23 02:47:57.974126
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:48:00.895117
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('dummy exception')
    except ValueError:
        e = get_exception()

    assert str(e) == 'dummy exception'


# Generated at 2022-06-23 02:48:05.946673
# Unit test for function get_exception
def test_get_exception():
    '''validate that get_exception returns the correct exception'''
    good_string = "123"
    bad_string = "foo"
    try:
        literal_eval(bad_string)
        return False
    except ValueError as e:
        pass
    except Exception:
        return False
    return e == get_exception()

# Generated at 2022-06-23 02:48:14.524170
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError as e:
        assert e == get_exception()

    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        assert ZeroDivisionError == type(get_exception())

    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        assert 'division by zero' == str(get_exception())


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:48:23.546120
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six.moves import cStringIO

    class MyException(Exception):
        pass

    try:
        raise MyException('Module test throws exception')
    except MyException:
        (exception_type, exception_value, exception_traceback) = sys.exc_info()
        try:
            (exception_type_local, exception_value_local) = get_exception()
        except ValueError:
            (exception_type_local, exception_value_local, exception_traceback_local) = sys.exc_info()
        assert exception_type_local is exception_type
        assert exception_value_local is exception_value
        assert exception_traceback_local is exception_traceback


# Generated at 2022-06-23 02:48:26.442086
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-23 02:48:31.305468
# Unit test for function get_exception
def test_get_exception():
    try:
        int(x)
    except Exception:
        e = get_exception()
    assert isinstance(e, NameError)
    try:
        int(x)
    except Exception:
        e = get_exception()
        pass
    assert isinstance(e, NameError)

# unit test for function literal_eval

# Generated at 2022-06-23 02:48:34.189991
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert str(exc) == 'Foo'


# Generated at 2022-06-23 02:48:36.261499
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:38.872537
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:41.362929
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A test exception')
    except Exception:
        e = get_exception()
        assert(e.args == ('A test exception',))



# Generated at 2022-06-23 02:48:43.346678
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('bar')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('bar',)

# Generated at 2022-06-23 02:48:45.939291
# Unit test for function get_exception
def test_get_exception():
    '''Test get_exception function'''
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-23 02:48:48.831760
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()

    assert isinstance(e, RuntimeError)


# Generated at 2022-06-23 02:48:51.557609
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:48:56.822032
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NotImplementedError('test exception')
    except NotImplementedError as e:
        assert isinstance(get_exception(), NotImplementedError)
        assert e == get_exception()
    else:
        raise AssertionError("get_exception failed to raise an exception")


# Generated at 2022-06-23 02:49:00.803456
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    exc = None
    try:
        raise MyException('foo')
    except MyException:
        exc = get_exception()

    # When Python 2.6 is no longer supported, we can make this better
    assert str(exc) == 'foo'

# Generated at 2022-06-23 02:49:05.242802
# Unit test for function get_exception
def test_get_exception():
    '''Test the get_exception function'''
    e = None

    try:
        raise ValueError("some error")
    except Exception:
        e = get_exception()
    assert e is not None
    assert str(e) == "some error"

# Generated at 2022-06-23 02:49:09.046214
# Unit test for function get_exception
def test_get_exception():
    try:
        int('hello')
    except ValueError:
        result = get_exception()
    else:
        assert False, "Should have seen a ValueError"
    assert isinstance(result, ValueError), \
        "Should be able to get the exception.  Got %r instead" % result


# Generated at 2022-06-23 02:49:13.440738
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError as e:
        if get_exception() != e:
            raise Exception('get_exception() returned something different from the raised exception.')



# Generated at 2022-06-23 02:49:18.349260
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Intentional Exception')
    except RuntimeError:
        exc = get_exception()
        try:
            raise exc
        except RuntimeError as e:
            assert str(e) == 'Intentional Exception'



# Generated at 2022-06-23 02:49:22.273630
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test_get_exception")
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == "test_get_exception"


# Generated at 2022-06-23 02:49:28.882109
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test1")
    except:
        e = get_exception()
        assert str(e) == "Test1"


if sys.version_info[0] == 2:
    def _to_unicode(val):
        return unicode(val)  # noqa
else:
    def _to_unicode(val):
        if isinstance(val, bytes):
            return val.decode('utf-8')
        return str(val)



# Generated at 2022-06-23 02:49:32.519859
# Unit test for function get_exception
def test_get_exception():
    try:
        a_global_variable  # pylint: disable=undefined-variable
    except NameError:
        e = get_exception()
        assert e.args[0] == "global name 'a_global_variable' is not defined"
    else:
        assert False, 'Expected NameError not raised'

# Generated at 2022-06-23 02:49:35.364477
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
        assert e is not None
        assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:49:39.014524
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()

    assert_raises(ValueError, e)

# Generated at 2022-06-23 02:49:42.044792
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise RuntimeError('foobar')
        except Exception:
            exception = get_exception()
            return exception
    assert f() == "foobar"

# Generated at 2022-06-23 02:49:46.548195
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert exc.args == ('foo',)
    assert str(exc) == 'foo'



# Generated at 2022-06-23 02:49:52.294765
# Unit test for function get_exception
def test_get_exception():
    """
    A unit test of get_exception() that also serves as a test of the
    function's documentation.  It's silly to write unit tests of functions
    that just return the result of a function call, but this way we can make
    sure the documentation and the function prototype match.
    """
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:49:54.400677
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception behaves as expected"""
    try:
        foo
    except NameError as e:
        assert e == get_exception()


# Generated at 2022-06-23 02:49:58.061751
# Unit test for function get_exception
def test_get_exception():

    class Ham(Exception):
        pass

    def func():
        try:
            raise Ham('egg')
        except:
            return get_exception()
    assert repr(func()) == repr(Ham('egg'))

# Generated at 2022-06-23 02:50:02.598786
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test error')
    except RuntimeError as e:
        got_exception = get_exception()
        if e is not got_exception:  # pylint: disable=unidiomatic-typecheck
            raise AssertionError(
                "get_exception() returned the wrong exception.  "
                "Expected %r, got %r" % (e, got_exception))

# Generated at 2022-06-23 02:50:04.625328
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)



# Generated at 2022-06-23 02:50:07.881182
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc) == 'Test exception'


# Generated at 2022-06-23 02:50:19.080846
# Unit test for function get_exception
def test_get_exception():
    # Check that our get_exception works
    try:
        raise RuntimeError("You are so busted")
    except RuntimeError:
        exc = get_exception()

    if exc is None:
        sys.exit("get_exception didn't return a value")
    if not isinstance(exc, RuntimeError):
        sys.exit("get_exception didn't return a RuntimeError")
    if str(exc) != "You are so busted":
        sys.exit("get_exception didn't return the right exception value")

    # Check that the builtin get_exception works
    try:
        raise RuntimeError("You are so busted")
    except RuntimeError as e:
        if e is None:
            sys.exit("get_exception didn't return a value")

# Generated at 2022-06-23 02:50:30.964156
# Unit test for function get_exception
def test_get_exception():
    """Return the current exception.

    The function will return an exception for any of these cases:
    - no exception is raised
    - an exception happens within a try/except block
    - an exception is caught and a new exception is raised
    - an exception is caught and code raises exit_json or fail_json
    - an exception is caught, code returns a value, and no exception is raised
    """
    import sys

    # no exception is raised
    # this case is used in the other tests
    def do_nothing():
        pass

    # exception happens within a try/except block
    def try_except():
        try:
            raise RuntimeError()
        except RuntimeError:
            pass

    # exception is caught and a new exception is raised
    # this should return the exception that was caught

# Generated at 2022-06-23 02:50:36.291663
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('test exception')
    except TestException:
        exc = get_exception()
        assert type(exc) == TestException
        assert str(exc) == 'test exception'



# Generated at 2022-06-23 02:50:46.493866
# Unit test for function get_exception

# Generated at 2022-06-23 02:50:51.174039
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    try:
        raise ValueError('test_get_exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'test_get_exception'

# Generated at 2022-06-23 02:50:56.628473
# Unit test for function get_exception
def test_get_exception():
    try:
        int('this is clearly not going to work')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc).startswith("invalid literal for int() with base 10: ")


# Generated at 2022-06-23 02:51:00.652369
# Unit test for function get_exception
def test_get_exception():
    # one way to use the function
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',), e.args


# Generated at 2022-06-23 02:51:04.169264
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:08.188472
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ("test",)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:51:10.888802
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('some error')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'some error'


# Generated at 2022-06-23 02:51:13.217663
# Unit test for function get_exception
def test_get_exception():
    """Make sure get_exception works"""
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()



# Generated at 2022-06-23 02:51:17.988437
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('test',)

# Generated at 2022-06-23 02:51:20.223124
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)



# Generated at 2022-06-23 02:51:27.855420
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:39.610669
# Unit test for function get_exception
def test_get_exception():
    import sys
    import io

    def check_get_exception(stderr_message):
        old_stderr = sys.stderr
        try:
            sys.stderr = io.StringIO()
            try:
                raise Exception(stderr_message)
            except Exception:
                e = get_exception()
            assert sys.stderr.getvalue() == stderr_message + '\n', \
                'stderr should have captured: %r' % stderr_message
            assert str(e) == stderr_message, \
                'get_exception() should have captured: %r' % stderr_message
        finally:
            sys.stderr = old_stderr

    for stderr_message in ('', 'foo'):
        yield check_get

# Generated at 2022-06-23 02:51:42.661321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise
    except:
        assert sys.exc_info()[1] == get_exception()

# Generated at 2022-06-23 02:51:46.722287
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:51:51.543369
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Foo')
    except:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.args == ('Foo',)

# Generated at 2022-06-23 02:51:54.893700
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('Never use assertions for control flow')
    except AssertionError:
        e = get_exception()

    assert e.args[0] == 'Never use assertions for control flow'

# Generated at 2022-06-23 02:51:58.178290
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert 'Test exception' in str(exc)

# Generated at 2022-06-23 02:52:00.674633
# Unit test for function get_exception
def test_get_exception():
    try:
        foo
    except NameError:
        exc = get_exception()
    assert exc.__class__ == NameError



# Generated at 2022-06-23 02:52:03.993031
# Unit test for function get_exception
def test_get_exception():

    try:
        raise Exception("testing")
    except Exception:
        e = get_exception()

    assert e.args[0] == "testing"


# Generated at 2022-06-23 02:52:07.177543
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        pass

    assert e is get_exception()


# Generated at 2022-06-23 02:52:11.765357
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert get_exception() is e
    try:
        raise ValueError()
    except ValueError:
        assert get_exception() is sys.exc_info()[1]

# unit test for function literal_eval

# Generated at 2022-06-23 02:52:19.043525
# Unit test for function get_exception
def test_get_exception():
    '''Test getting the exception'''
    def raiser():
        '''raise an exception and return the value'''
        try:
            raise Exception('a test exception')
            # pylint: disable=unreachable
        except Exception:
            return True
        else:
            return False

    raise_result = raiser()
    assert raise_result
    # pylint: disable=undefined-variable
    assert e.message == 'a test exception'



# Generated at 2022-06-23 02:52:22.268181
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'This is a test'


# Generated at 2022-06-23 02:52:25.268892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test of get_exception")
    except ValueError:
        e = get_exception()
        print(e)

# Generated at 2022-06-23 02:52:27.882163
# Unit test for function get_exception
def test_get_exception():
    fake_module = dict()
    try:
        raise Exception
    except Exception:
        fake_module['e'] = get_exception()
    assert isinstance(fake_module['e'], Exception)



# Generated at 2022-06-23 02:52:31.864436
# Unit test for function get_exception
def test_get_exception():
    def get_exc(arg):
        try:
            raise ValueError('test')
        except:
            e = get_exception()
        return e
    assert str(get_exc('test')) == 'test'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 02:52:37.752276
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Ansible')
    except Exception:
        e = get_exception()
    assert str(e) == 'Ansible'
    assert unicode(e) == u'Ansible'
    assert repr(e) == "Exception('Ansible',)"


# Generated at 2022-06-23 02:52:42.993946
# Unit test for function get_exception
def test_get_exception():
    def test_get_exception():
        try:
            raise ValueError(1)
        except:
            e = get_exception()
            assert e.args == (1,)
            assert str(e) == '1'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:52:45.753479
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-23 02:52:47.611760
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        return get_exception()


# Generated at 2022-06-23 02:52:50.761683
# Unit test for function get_exception
def test_get_exception():
    class MyCustomException(IOError):
        pass
    try:
        raise MyCustomException
    except Exception:
        e = get_exception()
    assert isinstance(e, MyCustomException), repr(e)


# Generated at 2022-06-23 02:52:55.061773
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
    assert type(e) is TypeError

# Generated at 2022-06-23 02:53:00.197687
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError('foo')
        except Exception:
            e = get_exception()
        else:
            assert False, 'Exception not raised'
        assert isinstance(e, ValueError)
        assert e.args == ('foo',)
    foo()



# Generated at 2022-06-23 02:53:04.891370
# Unit test for function get_exception
def test_get_exception():
    # Make sure that it works with a caught exception
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert e.args == ('foo',)

    # Make sure that it works without an exception
    try:
        e = get_exception()
    except:
        e = get_exception()
    assert e is None


# Generated at 2022-06-23 02:53:08.467031
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert 'test exception' in str(e)


# Generated at 2022-06-23 02:53:18.254604
# Unit test for function get_exception
def test_get_exception():
    # Test that we can get the correct exception
    try:
        raise ValueError("foobar")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("foobar",)

    # Test that we support string exceptions
    try:
        raise ValueError("foobar")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("foobar",)

    # Test for success on python 2.4.  Python 2.4 doesn't have an ast module,
    # so we have to manually mock any imports of it.
    sys_modules = sys.modules.copy()
    sys.modules['ast'] = None

# Generated at 2022-06-23 02:53:22.718399
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo', "get_exception didn't return the exception that was raised"


# Generated at 2022-06-23 02:53:25.301890
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'test exception'

# Generated at 2022-06-23 02:53:28.638792
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test get_exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test get_exception'



# Generated at 2022-06-23 02:53:34.286348
# Unit test for function get_exception
def test_get_exception():
    '''
    Test that get_exception obtains the exception.
    '''

    try:
        raise Exception
    except Exception:
        exc_info = get_exception()

    assert isinstance(exc_info, Exception)
    assert isinstance(getattr(get_exception, '__code__', None), type(test_get_exception.__code__))


# Generated at 2022-06-23 02:53:39.700353
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception e')
    except Exception:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise AssertionError('get_exception did not return ValueError: %s' % e)
        if 'Test exception e' not in e.args:
            raise AssertionError('get_exception did not return correctly formed ValueError: %s' % e)

# Generated at 2022-06-23 02:53:42.860425
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> try:
    ...     raise RuntimeError('Failed')
    ... except:
    ...     ret = get_exception()
    >>> ret.args
    ('Failed',)
    '''
    pass

# Generated at 2022-06-23 02:53:46.029585
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    def raiser():
        raise MyException('foo')

    try:
        raiser()
    except:
        e = get_exception()

    assert isinstance(e, MyException)
    assert 'foo' in str(e)

# Generated at 2022-06-23 02:53:49.040798
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError
    except KeyError:
        exc = get_exception()
        assert isinstance(exc, KeyError)


# Generated at 2022-06-23 02:53:53.468104
# Unit test for function get_exception
def test_get_exception():
    try:
        int('elephant')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError), 'get_exception() returned something other than an exception'

# Generated at 2022-06-23 02:53:54.810971
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except NameError:
        e = get_exception()

    assert isinstance(e, NameError)
    assert e.args == ('foo',)


# Generated at 2022-06-23 02:53:57.372180
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    try:
        raise Exception('a bad thing happened')
    except Exception:
        e = get_exception()
        assert 'bad' in str(e)

# Generated at 2022-06-23 02:54:07.109273
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:16.225622
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except,too-few-public-methods
    def raise_exc():
        try:
            raise RuntimeError('foo')
        except:
            return get_exception()

    class MyException(Exception):
        pass

    def raise_unexpected():
        try:
            raise MyException()
        except:
            return get_exception()

    assert raise_exc() is not None
    assert isinstance(raise_exc(), RuntimeError)
    assert str(raise_exc()) == "foo"
    assert raise_exc().__class__.__name__ == 'RuntimeError'
    assert raise_exc().__class__.__module__ == 'exceptions'
    assert raise_unexpected().__class__.__name__ == 'MyException'
    assert raise_unexpected().__class__.__

# Generated at 2022-06-23 02:54:19.302391
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("This is a test.")
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert str(e) == "This is a test."


# Generated at 2022-06-23 02:54:22.661595
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:26.902113
# Unit test for function get_exception
def test_get_exception():
    def test_try():
        try:
            raise TypeError('foo')
        except:
            return get_exception()

    exc = test_try()
    assert isinstance(exc, TypeError)
    assert str(exc) == 'foo'



# Generated at 2022-06-23 02:54:30.436432
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'test'

# Generated at 2022-06-23 02:54:32.364155
# Unit test for function get_exception
def test_get_exception():
    # Test getting a real exception
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
    assert 'foo' in str(exc)
    # Test getting no exception
    assert get_exception() is None

# Generated at 2022-06-23 02:54:44.973305
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError()
    except TypeError:
        assert get_exception().__class__ == TypeError

    # Test that the current exception is not consumed and we can raise it
    # again
    try:
        raise TypeError()
    except TypeError:
        ex = get_exception()
        assert ex.__class__ == TypeError
        try:
            raise ex
        except TypeError:
            pass

    try:
        raise TypeError()
    except TypeError:
        ex = get_exception()
        assert ex.__class__ == TypeError
        try:
            raise TypeError('Test message')
        except TypeError:
            nex = get_exception()
            assert nex.__class__ == TypeError
            assert nex.message != ex.message



# Generated at 2022-06-23 02:54:49.964252
# Unit test for function get_exception
def test_get_exception():
    """Test exception getting"""
    try:
        raise Exception("this is a test")
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert("this is a test" in str(e))

if __name__ == "__main__":
    # Unit test for function get_exception
    test_get_exception()

# Generated at 2022-06-23 02:54:52.053061
# Unit test for function get_exception
def test_get_exception():

    try:
        raise TypeError
    except TypeError:
        e = get_exception()
        assert isinstance(e, TypeError)

# Generated at 2022-06-23 02:54:55.297933
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError("I'm an AssertionError")
    except Exception:
        exc = get_exception()
        assert isinstance(exc, AssertionError)
        assert exc.args == ("I'm an AssertionError",)


# Generated at 2022-06-23 02:54:58.475006
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        ex = get_exception()
        assert ex.__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-23 02:55:03.182202
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception()
    try:
        raise_exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
