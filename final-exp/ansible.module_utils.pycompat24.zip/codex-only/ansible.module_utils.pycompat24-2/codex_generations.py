

# Generated at 2022-06-23 02:45:03.531745
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception

    try:
        raise_exception()
    except:  # pylint: disable=bare-except
        e = get_exception()
    assert e.__class__ is Exception


# Generated at 2022-06-23 02:45:06.113028
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Throw me")
    except Exception:
        tb = get_exception()

    assert str(tb) == "Throw me"



# Generated at 2022-06-23 02:45:10.235338
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception('foo')
    try:
        foo()
        assert False, "foo() didn't raise an exception"
    except:  # noqa, pylint: disable=bare-except
        e = get_exception()
        assert e.args == ('foo',)
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:45:14.669102
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("An exception")
    except RuntimeError:
        e = get_exception()

    assert e.args[0] == "An exception"

# Generated at 2022-06-23 02:45:19.278605
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name
    e = RuntimeError('test error')
    try:
        raise e
    except RuntimeError:
        assert get_exception() is e


# Generated at 2022-06-23 02:45:22.348389
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() works"""
    try:
        int('spam')
    except Exception as e:
        exception = e  # pylint: disable=unused-variable

    assert get_exception().args == exception.args


# Generated at 2022-06-23 02:45:24.862774
# Unit test for function get_exception
def test_get_exception():
    """Function get_exception()"""
    assert get_exception().__class__.__name__ == 'AssertionError'

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:45:30.513388
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
    except:
        e = get_exception()
    try:
        raise e
    except ValueError:
        pass

test_get_exception()

# Generated at 2022-06-23 02:45:35.162501
# Unit test for function get_exception
def test_get_exception():
    # Make sure that we can raise an exception with get_exception()
    try:
        raise Exception()
    except:
        exc = get_exception()
        assert isinstance(exc, Exception)



# Generated at 2022-06-23 02:45:42.523879
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise RuntimeError(u'\u6a19\u6e96\u30c4\u30fc\u30eb\u30c7\u30fc\u30bf')
    try:
        raise_exception()
    except RuntimeError:
        exc = get_exception()
        assert exc.args == (u'\u6a19\u6e96\u30c4\u30fc\u30eb\u30c7\u30fc\u30bf',)


# Generated at 2022-06-23 02:45:45.529608
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is an exception")
    except Exception:
        e = get_exception()
        assert e.args[0] == "This is an exception"



# Generated at 2022-06-23 02:45:47.549828
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        e = get_exception()
    assert isinstance(e, ValueError), e


# Generated at 2022-06-23 02:45:53.037643
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise RuntimeError('From unit test')
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.args == ('From unit test',)

    try:
        import foo
        pytest.fail('This should have raised an ImportError')
    except ImportError:
        e = get_exception()
        assert isinstance(e, ImportError)
        assert e.args == ('No module named foo',)



# Generated at 2022-06-23 02:45:57.660916
# Unit test for function get_exception
def test_get_exception():
    def _inner_raise(e):
        raise e

    class MyException(Exception):
        pass

    try:
        _inner_raise(MyException('Hello World'))
    except:
        e = get_exception()
        assert type(e) == MyException and e.args[0] == 'Hello World'

# Generated at 2022-06-23 02:46:04.716698
# Unit test for function get_exception
def test_get_exception():
    # Code up some exception raising code.
    try:
        try:
            raise ValueError('foo')
        # We can use the modern syntax in our test
        except ValueError as e:
            # Test that the exception we got is the correct one
            assert e.args[0] == 'foo'
            # Code up another exception raising code.
            try:
                raise ValueError('bar')
            except ValueError:
                # Check that this is the exception we got
                assert get_exception().args[0] == 'bar'
    except AssertionError:
        raise get_exception()

# Generated at 2022-06-23 02:46:10.216659
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception as e:
        assert e is get_exception()
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
    try:
        raise Exception()
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:46:14.118862
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception('Test')

    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert(e.args[0] == 'Test')

# Generated at 2022-06-23 02:46:19.600516
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise ValueError("get_exception was not working")
        except Exception:
            e = get_exception()

    try:
        inner()
    except ValueError:
        pass
    else:
        raise AssertionError("get_exception was not properly getting the exception")


# Generated at 2022-06-23 02:46:22.145621
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert str(get_exception()) == 'foo'



# Generated at 2022-06-23 02:46:24.930046
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
        pass

    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:46:27.550283
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert type(e) is ValueError



# Generated at 2022-06-23 02:46:33.937489
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError) and e.args[0] == 'integer division or modulo by zero'

    try:
        raise SyntaxError('Does it work?')
    except SyntaxError:
        e = get_exception()
        assert isinstance(e, SyntaxError) and e.args[0] == 'Does it work?'



# Generated at 2022-06-23 02:46:36.458053
# Unit test for function get_exception
def test_get_exception():
    try:
        foo = 1/0
    except ZeroDivisionError:
        e = get_exception()

    assert type(e) == ZeroDivisionError

# Generated at 2022-06-23 02:46:43.700505
# Unit test for function get_exception
def test_get_exception():

    try:
        raise ValueError('Val')
    except:
        e = get_exception()

    assert str(e) == 'Val'
    assert e.__class__.__name__ == 'ValueError'

# Generated at 2022-06-23 02:46:52.395255
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() is e
        # Make sure the two exceptions are the same thing (comparing the
        # exception doesn't work on Py3)
        assert id(get_exception()) == id(e)
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('foo',)
        # Make sure the two exceptions are the same thing (comparing the
        # exception doesn't work on Py3)
        assert id(get_exception()) == id(e)



# Generated at 2022-06-23 02:46:54.786180
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert 'foo' in str(exc)

# Generated at 2022-06-23 02:46:59.948722
# Unit test for function get_exception
def test_get_exception():

    # this is a native python exception
    try:
        raise KeyError
    except KeyError as e:
        e2 = get_exception()
        assert e is e2

    # this is a C extension exception
    try:
        x = {}
        x[0]
    except KeyError as e:
        e2 = get_exception()
        assert e is e2



# Generated at 2022-06-23 02:47:09.335621
# Unit test for function get_exception
def test_get_exception():
    def inner_func():
        try:
            raise ValueError('inner value error')
        except ValueError:
            inner_exception = get_exception()
        try:
            raise RuntimeError('outer runtime error')
        except RuntimeError:
            outer_exception = get_exception()
        return outer_exception, inner_exception
    outer_exception, inner_exception = inner_func()
    assert type(outer_exception) is RuntimeError
    assert outer_exception.args == ('outer runtime error',)
    assert type(inner_exception) is ValueError
    assert inner_exception.args == ('inner value error',)

# Generated at 2022-06-23 02:47:11.588809
# Unit test for function get_exception
def test_get_exception():
    try:
        5/0
    except Exception:
        pass
    assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-23 02:47:15.137412
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works"""
    try:
        raise Exception('boom')
    except Exception:
        ex = get_exception()
    assert ex.args[0] == 'boom'

# Generated at 2022-06-23 02:47:26.617724
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestGetExc(unittest.TestCase):
        """
        Test class to ensure that the get_exception function works properly.
        """
        def test_get_exception(self):
            """Ensure that the get_exception function works properly.

            The function is meant to get the current exception.  So we cause
            an exception, get the exception, and ensure that the exception is
            the exception we wanted.
            """
            try:
                raise RuntimeError('Test')
            except Exception:
                exc = get_exception()
                # pylint: disable=E1101
                self.assertIsInstance(exc, RuntimeError, 'get_exception retrieved wrong type of exception')
                self.assertEqual(exc.args, ('Test',), 'get_exception retrieved wrong exception')

    test

# Generated at 2022-06-23 02:47:30.741181
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Unit test exception")
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        message = str(exc)
        assert 'Unit test exception' == message


# Generated at 2022-06-23 02:47:37.476416
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert get_exception() is not None
        # Python 3.x: <class 'Exception'>
        # Python 2.x: <type 'exceptions.Exception'>
        assert get_exception().__class__.__name__ == 'Exception'

# Generated at 2022-06-23 02:47:41.830931
# Unit test for function get_exception
def test_get_exception():
    try:
        this_var_does_not_exist  # pylint: disable=undefined-variable
    except Exception:
        e = get_exception()
        assert e.__class__ == NameError


# Generated at 2022-06-23 02:47:44.477792
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('My exception')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'My exception'



# Generated at 2022-06-23 02:47:47.101611
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('Test',)

# Generated at 2022-06-23 02:47:50.380210
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exc = get_exception()
    else:
        raise AssertionError("Should have raised ZeroDivisionError")
    assert isinstance(exc, ZeroDivisionError)

# Generated at 2022-06-23 02:47:57.227210
# Unit test for function get_exception
def test_get_exception():
    try:
        pass
    except:
        exc = get_exception()
    assert exc is None

    try:
        raise ValueError('test')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'test'

    try:
        raise 'test'
    except:
        exc = get_exception()
    assert isinstance(exc, str)
    assert str(exc) == 'test'

# Generated at 2022-06-23 02:47:59.077448
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:48:04.053670
# Unit test for function get_exception
def test_get_exception():
    def test_exception(exception):
        try:
            raise exception
        except:
            e = get_exception()
        return e

    assert isinstance(test_exception(ValueError()), ValueError)
    assert isinstance(test_exception(ImportError()), ImportError)

# Generated at 2022-06-23 02:48:09.070537
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        e = get_exception()
        print('Got Exception: ' + str(e))
        assert str(e) == 'Test Exception'

# Generated at 2022-06-23 02:48:12.897153
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception()')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert unicode(e) == u'testing get_exception()'

# Generated at 2022-06-23 02:48:18.092402
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:23.152084
# Unit test for function get_exception
def test_get_exception():
    try:
        # This is the most common exception type in Ansible code
        raise IOError()
    except:
        e = get_exception()
        assert e is not None
        assert isinstance(e, IOError)


# Generated at 2022-06-23 02:48:34.715868
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name, w0702, broad-except
    def test(e):
        try:
            raise e
        except:
            pass
        try:
            get_exception()
        except e:
            return
        sys.stdout.write('Failed to raise exception\n')

    test(Exception('Test exception'))
    test(ZeroDivisionError)
    test(SystemError)
    test(IOError)
    test(NotImplementedError)  # pylint: disable=undefined-variable

# Generated at 2022-06-23 02:48:37.787148
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Error message")
    except ValueError:
        e = get_exception()
    assert(isinstance(e, ValueError))
    assert( e.args[0] == "Error message")

# Generated at 2022-06-23 02:48:43.401619
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An error occurred')
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == 'An error occurred'


# Generated at 2022-06-23 02:48:45.917436
# Unit test for function get_exception
def test_get_exception():
    # Tests that this works both on the current exception and older exception
    try:
        raise Exception
    except Exception:
        current_exception = get_exception()

    try:
        raise current_exception
    except Exception:
        assert current_exception == get_exception()


# Generated at 2022-06-23 02:48:49.607849
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test.")
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ("This is a test.",)



# Generated at 2022-06-23 02:48:54.427141
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            g()
        except Exception:
            return get_exception()

    def g():
        raise RuntimeError(42)

    e = f()
    assert isinstance(e, RuntimeError)
    assert e.args == (42,)

# Generated at 2022-06-23 02:49:04.299502
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    def func():
        raise MyException()

    try:
        func()
    except Exception as e:
        _e = e
    assert _e is not None

    try:
        func()
    except Exception:
        _e = get_exception()
    assert _e is not None

## Unit test for function literal_eval
#def test_literal_eval():
#    assert literal_eval('True') is True
#    assert literal_eval('False') is False
#    assert literal_eval('None') is None
#    assert literal_eval('1') == 1
#    assert literal_eval('1.1') == 1.1
#    assert literal_eval('"True"') == 'True'
#    assert literal_eval("'True'") == 'True'
#

# Generated at 2022-06-23 02:49:07.279599
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception()
        except Exception:
            return get_exception()

    e = f()
    assert isinstance(e, Exception)



# Generated at 2022-06-23 02:49:12.106937
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:16.561830
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise ValueError('test')
    ... except Exception:
    ...     e = get_exception()
    ...     print(isinstance(e, ValueError))
    ...     print(str(e))
    True
    test
    """

# Generated at 2022-06-23 02:49:19.171054
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert sys.exc_info()[1] == get_exception()  # pylint: disable=no-member

# Generated at 2022-06-23 02:49:23.169356
# Unit test for function get_exception
def test_get_exception():
    def raise_exception(msg):
        class TestException(Exception):
            pass
        raise TestException(msg)

    try:
        raise_exception("Test message")
    except Exception as e:
        assert e == get_exception()

# Generated at 2022-06-23 02:49:27.020501
# Unit test for function get_exception
def test_get_exception():
    def func():
        try:
            raise IOError('test exception')
        except Exception:
            return get_exception()

    ex_object = func()
    assert type(ex_object) == IOError
    assert str(ex_object) == 'test exception'

# Generated at 2022-06-23 02:49:30.384473
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-variable
    import sys

    try:
        try:
            raise ValueError('foo')
        except ValueError:
            ex = get_exception()
            assert ex.args == ('foo', )
    except Exception:
        raise
    try:
        raise ValueError('foo')
    except ValueError:
        try:
            sys.exc_clear()
            ex = get_exception()
            assert ex is None
        except Exception:
            raise
    except Exception:
        raise

# Generated at 2022-06-23 02:49:37.065153
# Unit test for function get_exception
def test_get_exception():
    # Test that we can get an exception
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'
        assert repr(e) == 'Exception(\'Test exception\',)'

    # Test that we can get exception chained exceptions
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        e.child = Exception('Child exception')
        assert str(e) == 'Test exception: Child exception'
        assert repr(e) == "Exception('Test exception: Child exception',)"

# Generated at 2022-06-23 02:49:43.885284
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert get_exception()
        assert isinstance(get_exception(), ZeroDivisionError)
        assert get_exception().__class__ == ZeroDivisionError

# Generated at 2022-06-23 02:49:47.846098
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('just testing')
    except Exception:
        e = get_exception()
        assert('just testing' in str(e))



# Generated at 2022-06-23 02:49:53.888527
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        def __init__(self, message):
            super(MyException, self).__init__(message)
            self.message = message
    try:
        raise MyException('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, MyException)
        assert e.message == 'foo'


# Generated at 2022-06-23 02:50:00.925239
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert e.args[0] == 'foo'


# Generated at 2022-06-23 02:50:05.658413
# Unit test for function get_exception
def test_get_exception():

    def func1():
        raise ValueError('This is a test exception')

    try:
        func1()
    except ValueError:
        test = get_exception()
        assert test.args[0] == 'This is a test exception'


# Generated at 2022-06-23 02:50:16.986139
# Unit test for function get_exception
def test_get_exception():
    got_exception = False
    try:
        raise Exception('foo')
    except Exception:
        got_exception = True
        e = get_exception()

    assert got_exception
    assert e.args and e.args[0] == 'foo'


if __name__ == '__main__':
    # For backwards compatibility with Ansible versions < 2.3
    # we need to make these names available in the ansible.module_utils namespace
    # inside the old utils.py module.
    # pylint: disable=wrong-import-position,import-error
    import ansible.module_utils.six
    # pylint: disable=undefined-variable
    if PY3:
        import builtins
    else:
        import __builtin__ as builtins

    builtins.__dict__.set

# Generated at 2022-06-23 02:50:22.934348
# Unit test for function get_exception
def test_get_exception():
    try:
        raise BaseException('Test exception')
    except BaseException as e:
        ex = get_exception()
        assert e is ex



# Generated at 2022-06-23 02:50:28.711724
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('test')
    except Exception:
        exc = get_exception()
    assert exc.__str__() == 'test'
    assert repr(exc) == 'NameError("test",)'
    assert str(exc) == "NameError('test',)"



# Generated at 2022-06-23 02:50:33.260366
# Unit test for function get_exception
def test_get_exception():
    # This doesn't test much but it exercises the code and improves code coverage of the module
    import pytest
    try:
        raise ValueError("test")
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert "test" in str(e)

# Generated at 2022-06-23 02:50:36.548161
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()

        assert isinstance(e, ValueError)
        assert 'test exception' in repr(e)

# Generated at 2022-06-23 02:50:39.930601
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0
    except Exception:
        e = get_exception()

    assert str(e) == 'integer division or modulo by zero'
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:50:42.906652
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        exception = get_exception()

    assert exception[0] is ZeroDivisionError


# Generated at 2022-06-23 02:50:45.963693
# Unit test for function get_exception
def test_get_exception():
    try:
        [][2]
    except Exception:
        e = get_exception()
        assert str(e) == 'list index out of range'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:50:54.558377
# Unit test for function get_exception
def test_get_exception():
    # Python 2.x compatible
    try:
        raise Exception('test')
    except Exception:
        assert get_exception().args[0] == "test", "get_exception() failed"
    # Python 3.x compatible
    try:
        raise Exception('test')
    except Exception:
        assert get_exception().args[0] == 'test', "get_exception() failed"
    try:
        raise ValueError('my_bad', 1, 2)
    except Exception:
        assert get_exception().args == ('my_bad', 1, 2), "get_exception() failed"

# Generated at 2022-06-23 02:50:57.617954
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:51:01.558095
# Unit test for function get_exception
def test_get_exception():
    """Assert that get_exception() works"""
    try:
        1/0
    except Exception:
        e = get_exception()
    assert 'ZeroDivision' == e.__class__.__name__

# Generated at 2022-06-23 02:51:07.098390
# Unit test for function get_exception
def test_get_exception():
    """
    Test that the get_exception function works as expected
    """

    def trap():
        '''
        Raises a ValueError exception
        '''
        raise ValueError()
    try:
        trap()
    except:
        (exception_type, exception_value, traceback_object) = sys.exc_info()
        assert(exception_value == get_exception())

# Generated at 2022-06-23 02:51:12.004601
# Unit test for function get_exception
def test_get_exception():
    # Raise an exception and catch it with get_exception
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert e.args == ('test',)



# Generated at 2022-06-23 02:51:19.975924
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:25.136092
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        assert str(e) == 'foo'
        assert repr(e) == "ValueError('foo',)"
    try:
        raise ValueError
    except:
        e = get_exception()
        assert str(e) == ''
        assert repr(e) == "ValueError()"

# Generated at 2022-06-23 02:51:27.118302
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        exc = get_exception()
    assert exc.args[0] == 'test'

# Generated at 2022-06-23 02:51:34.596915
# Unit test for function get_exception
def test_get_exception():
    '''
    Unit test for function get_exception
    '''
    try:
        raise Exception('Test exception')
    except Exception:
        exception = get_exception()
        assert exception.__str__() == 'Test exception'



# Generated at 2022-06-23 02:51:46.266380
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:51.946821
# Unit test for function get_exception
def test_get_exception():
    # Python 2.4 and 2.5 don't have the 'as' keyword
    # pylint: disable=redefined-variable-type
    try:
        raise TypeError
    except Exception:
        assert type(get_exception()) == TypeError



# Generated at 2022-06-23 02:51:53.644743
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError()
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:51:59.425115
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception()
    try:
        raise_exception()
    except:
        exc = get_exception()
    if exc is None:
        raise AssertionError('get_exception() failed to return an exception')
    if not isinstance(exc, Exception):
        raise AssertionError('get_exception() returned a non-exception: {0}'.format(exc))

# Generated at 2022-06-23 02:52:02.634362
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boom')
    except Exception:
        e = get_exception()
        assert str(e) == 'boom'



# Generated at 2022-06-23 02:52:07.809525
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('Here is my exception')
    except:
        e = get_exception()
        assert e.args == ('Here is my exception',)

# Generated at 2022-06-23 02:52:10.973879
# Unit test for function get_exception
def test_get_exception():
    def raise_and_catch():
        try:
            raise ValueError()
        except ValueError:
            e = get_exception()
        return e

    assert raise_and_catch().__class__ == ValueError

# Generated at 2022-06-23 02:52:14.587791
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
        # Make sure we got a traceback
        assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:52:19.699756
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NotImplementedError("I'm not an actual exception")
    except Exception:
        e = get_exception()
    try:
        raise e
    except NotImplementedError:
        pass
    except Exception:
        raise AssertionError("Should have caught the NotImplementedError that was raised")

# Generated at 2022-06-23 02:52:23.679002
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert(isinstance(e, Exception))
    assert(str(e) == 'foo')


# Generated at 2022-06-23 02:52:32.481480
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    # pylint: disable=protected-access
    try:
        raise ValueError("This is a test")
    except:
        e = __class__.get_exception()

    assert e.message == "This is a test"
    try:
        raise ValueError("This is a test")
    except:
        e = __class__.get_exception()

    try:
        raise ValueError("This is another test")
    except:
        e2 = __class__.get_exception()

    assert e.message == "This is a test"
    assert e2.message == "This is another test"

# Generated at 2022-06-23 02:52:34.769572
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        assert get_exception()
    try:
        raise TypeError()
    except:
        assert get_exception()

# Generated at 2022-06-23 02:52:37.294198
# Unit test for function get_exception
def test_get_exception():
    """Unit testing for function get_exception."""
    try:
        raise ValueError('Test error message')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test error message'


# Generated at 2022-06-23 02:52:48.708197
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    def f1():
        try:
            raise ValueError('aaa')
        except Exception:
            e = get_exception()
        return e
    assert isinstance(f1(), ValueError)
    assert f1().args == ('aaa',)
    assert 'aaa' in str(f1())

    def f2(x):
        try:
            y = x['undefined']
        except Exception:
            e = get_exception()
        return e
    assert isinstance(f2({}), KeyError)


# Generated at 2022-06-23 02:52:52.397017
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test_get_exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test_get_exception'

# Generated at 2022-06-23 02:52:59.577585
# Unit test for function get_exception
def test_get_exception():
    # raises exception and calls get_exception to get the exception
    def test(n):
        try:
            raise Exception('Hello')
        except Exception:
            e = get_exception()
            assert e.args[0] == 'Hello'

    # test() is called five times to make sure Python 2.4 doesn't
    # reuse the same object
    for i in range(5):
        test(i)

# Generated at 2022-06-23 02:53:03.911687
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Module test for function literal_eval

# Generated at 2022-06-23 02:53:06.167542
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:53:08.228955
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:53:10.640539
# Unit test for function get_exception
def test_get_exception():
    '''Check that function get_exception works'''
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception()
        assert repr(get_exception()) == 'Exception(\'foo\',)'

# Generated at 2022-06-23 02:53:13.301106
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise ValueError('test')
    except ValueError:
        assert get_exception().args == ('test',)



# Generated at 2022-06-23 02:53:17.266278
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception): pass
    try:
        raise MyException("test")
    except MyException:
        print(get_exception())

# test for literal_eval. This is a cut/paste/simplify from
# test_ast.py from the python 2.6 ast module.

# Generated at 2022-06-23 02:53:19.627751
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("FooBar")
    except RuntimeError:
        e = get_exception()
    assert (e.args[0] == 'FooBar')


# Generated at 2022-06-23 02:53:24.914366
# Unit test for function get_exception
def test_get_exception():
    # Python 2.4 doesn't have sys.exc_value
    exc_value = sys.exc_value
    del sys.exc_value
    try:
        raise ValueError('testing')
    except ValueError:
        assert exc_value == get_exception()
    finally:
        sys.exc_value = exc_value

# Generated at 2022-06-23 02:53:27.848179
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except: # pylint: disable=bare-except
        e = __all__[0]()
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:53:34.338941
# Unit test for function get_exception
def test_get_exception():
    def _failing_func():
        raise NameError(u'\u1234')
    try:
        _failing_func()
    except Exception:
        e = get_exception()
        if isinstance(e, NameError) and six.text_type(e) == u'\u1234':
            print('OK')
        else:
            print('FAIL')

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:53:37.698162
# Unit test for function get_exception

# Generated at 2022-06-23 02:53:41.601680
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as exc:
        # This is the only way I know to check for a match between two
        # exceptions in python 2.4+.  The equality operators were not added
        # until 2.6.
        assert id(exc) == id(get_exception())

# Generated at 2022-06-23 02:53:47.732169
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a test exception')
    except RuntimeError:
        exc = get_exception()
        assert str(exc) == 'This is a test exception'

# Generated at 2022-06-23 02:53:57.808717
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    import sys
    import pytest
    def raiseit():
        raise RuntimeError('bar')
    try:
        raiseit()
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        assert exc_type == RuntimeError
        assert exc_value.args == ('bar',)
        assert exc_traceback is not None
        exc = get_exception()
        assert exc == exc_value
        assert get_exception() is exc_value

    def assert_none():
        try:
            raiseit()
        except:
            assert get_exception() is None
    assert_none()

# Generated at 2022-06-23 02:54:01.184560
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception(42)
        except Exception:
            e = get_exception()

        return e

    assert isinstance(f(), Exception)
    assert f().args[0] == 42



# Generated at 2022-06-23 02:54:03.638934
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
        assert e.__class__ == TypeError


# Generated at 2022-06-23 02:54:05.738430
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test this")
    except:
        assert sys.exc_info()[1] == get_exception()


# Generated at 2022-06-23 02:54:08.809036
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:54:13.460131
# Unit test for function get_exception
def test_get_exception():
    '''Test that get_exception() returns the exception we expect'''

# Generated at 2022-06-23 02:54:16.504844
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except:
        exc = get_exception()
        assert exc.args == ('foo',)

# Generated at 2022-06-23 02:54:19.220727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('an exception')
    except Exception:
        e = get_exception()
    expected = 'an exception'
    assert str(e) == expected


# Generated at 2022-06-23 02:54:22.911182
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'foo'
        assert exc.__str__() == 'foo'



# Generated at 2022-06-23 02:54:25.388257
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError as e:
        assert e is get_exception()



# Generated at 2022-06-23 02:54:27.683019
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo bar')
    except RuntimeError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:54:32.790705
# Unit test for function get_exception
def test_get_exception():
    import os

    if os.getenv('DEBUG_UNITTEST'):
        os.system('which python2 python3')
        print('PATH=', os.environ['PATH'])

    try:
        raise ValueError('test exception')
    except:
        e = get_exception()

    assert e.__class__ == ValueError
    assert text_type(e) == 'test exception'


# Generated at 2022-06-23 02:54:36.289641
# Unit test for function get_exception
def test_get_exception():
    try:
        x = y
    except Exception:
        failure = get_exception()

    assert failure.args[0] == "name 'y' is not defined"


# Generated at 2022-06-23 02:54:38.943532
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('a message')
    except RuntimeError:
        assert 'a message' in str(get_exception())



# Generated at 2022-06-23 02:54:43.407116
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=invalid-name
    def f():
        return 1 / 0

    try:
        f()
    except:
        e = get_exception()
        assert e.args[0] == 'integer division or modulo by zero'

# Generated at 2022-06-23 02:54:48.012034
# Unit test for function get_exception
def test_get_exception():
    # test that we get the exception for any exception thrown
    try:
        raise ValueError('Testing Exception')
    except Exception:
        e = get_exception()
        if e != ValueError('Testing Exception'):
            raise AssertionError('get_exception did not return the exception')


# Generated at 2022-06-23 02:54:50.649101
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError as ex:
        assert ex == get_exception(), 'get_exception should get the current exception'



# Generated at 2022-06-23 02:54:53.022006
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except AssertionError:
        e = get_exception()
        assert e.args == ('foo',)



# Generated at 2022-06-23 02:54:59.583852
# Unit test for function get_exception
def test_get_exception():

    def some_func():
        try:
            1 / 0
        except ZeroDivisionError:
            return get_exception()

    try:
        some_func()
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
    else:
        raise AssertionError("Expected ZeroDivisionError")