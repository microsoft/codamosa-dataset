

# Generated at 2022-06-23 02:45:04.309205
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('test exception')
    except AssertionError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:45:09.263199
# Unit test for function get_exception
def test_get_exception():
    result = get_exception()
    assert result is None
    try:
        raise TypeError("blah!")
    except TypeError:
        e = get_exception()
        assert isinstance(e, TypeError)
    assert e.args[0] == "blah!"

# Generated at 2022-06-23 02:45:11.745704
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        exc = get_exception()
    assert exc.args == ('test',)



# Generated at 2022-06-23 02:45:13.496346
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:45:19.233075
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Something happened.')
    except ValueError:
        exc = get_exception()
    assert exc.args[0] == 'Something happened.'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-23 02:45:26.005505
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        def __repr__(self):
            return '<Custom Exception>'

    def do_stuff():
        raise CustomException('arg')

    try:
        do_stuff()
    except CustomException as e:
        print('Test 1', e)
        assert e is get_exception()
        return

    assert False, 'Test 1 failed: no exception was raised'


# Generated at 2022-06-23 02:45:32.151555
# Unit test for function get_exception
def test_get_exception():
    class MyTestError(Exception):
        pass
    try:
        raise MyTestError('a message') # pylint: disable=undefined-variable
    except Exception:
        e = get_exception()
    assert isinstance(e, MyTestError)
    assert str(e) == 'a message'


# Generated at 2022-06-23 02:45:36.344674
# Unit test for function get_exception
def test_get_exception():
    def do_raise():
        raise RuntimeError('test1')

    try:
        do_raise()
    except Exception:
        e = get_exception()
        assert str(e) == 'test1'

# Generated at 2022-06-23 02:45:44.130322
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        try:
            str(get_exception())
        except UnicodeEncodeError:
            # Python 2.4 UnicodeEncodeError on msg.__str__()
            pass
        except TypeError:
            # Python 2.5 TypeError on msg.__str__()
            pass
        except AttributeError:
            # Python 2.4 AttributeError on msg.__str__()
            pass

# Generated at 2022-06-23 02:45:53.070406
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=too-many-locals
    import sys
    import types
    import unittest

    class _test(Exception):
        pass

    def _raise0():
        raise _test()

    def _raise1(arg):
        raise _test(arg)

    def _raise2(arg1, arg2):
        raise _test(arg1, arg2)

    def _raise3(arg1, arg2, arg3):
        raise _test(arg1, arg2, arg3)

    def _raise4(arg1, arg2, arg3, arg4):
        raise _test(arg1, arg2, arg3, arg4)


# Generated at 2022-06-23 02:45:55.464091
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('error')
    except Exception:
        e = get_exception()
        assert str(e) == 'error'

# Generated at 2022-06-23 02:45:59.674817
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTest(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise Exception('foo')
            except Exception:
                self.assertEquals('foo', get_exception().args[0])
    unittest.main()

# Generated at 2022-06-23 02:46:06.255746
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
    if not isinstance(exc, ValueError):
        raise Exception('get_exception returned %s instead of ValueError' % exc)
    if str(exc) != 'foo':
        raise Exception('get_exception returned %s instead of "foo"' % exc)



# Generated at 2022-06-23 02:46:08.858486
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        e2 = get_exception()
        assert e2 is e


# Generated at 2022-06-23 02:46:12.928521
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Error message')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.args == ('Error message',)



# Generated at 2022-06-23 02:46:17.930967
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception returns the current exception
    try:
        raise Exception("Exception Message")
    except Exception:
        ret_exception = get_exception()
    # Check that the exception message is the same
    assert ret_exception.args[0] == "Exception Message"


# Generated at 2022-06-23 02:46:26.089445
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)

    try:
        raise TypeError
    except TypeError:
        e = get_exception()
    assert e.args == tuple()

    try:
        raise
    except:
        e = get_exception()
    assert e.args == tuple()

    try:
        raise SyntaxError(1)
    except:
        e = get_exception()
    assert e.args == (1,)


# Generated at 2022-06-23 02:46:29.459730
# Unit test for function get_exception
def test_get_exception():
    try:
        3 / 0
    except Exception:
        expected = get_exception()
    try:
        3 / 0
    except Exception:
        assert get_exception() is expected


# Generated at 2022-06-23 02:46:33.966063
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:36.577421
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("Hello")
    except TypeError:
        exc = get_exception()
    assert str(exc) == "Hello"


# Generated at 2022-06-23 02:46:44.222729
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'foo'
    assert repr(exc) == 'ValueError(\'foo\',)'


# Generated at 2022-06-23 02:46:48.921383
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("foo")
    except Exception:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert str(e) == "foo"


# Generated at 2022-06-23 02:46:51.815321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except RuntimeError as e:
        assert e == get_exception()



# Generated at 2022-06-23 02:46:55.245920
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:57.657411
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:47:06.447927
# Unit test for function get_exception
def test_get_exception():
    # Test when there is no current exception
    try:
        1/0
    except ZeroDivisionError:
        exc1 = get_exception()
    assert exc1 is None

    # Test when there is a current exception
    try:
        1/0
    except ZeroDivisionError:
        exc2 = get_exception()
    assert exc2 is not None

# Generated at 2022-06-23 02:47:10.142356
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=missing-docstring
    try:
        raise Exception()
    except Exception:
        assert get_exception() is sys.exc_info()[1], 'get_exception() failed'

# Generated at 2022-06-23 02:47:13.926639
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        exc = get_exception()
    assert exc.__class__.__name__ == 'ZeroDivisionError'
    assert str(exc) == 'integer division or modulo by zero'

# Generated at 2022-06-23 02:47:17.700694
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise RuntimeError('Testing get_exception')

    try:
        raise_exception()
    except:
        e = get_exception()
        return str(e) == 'Testing get_exception'

# Generated at 2022-06-23 02:47:22.268841
# Unit test for function get_exception

# Generated at 2022-06-23 02:47:25.772486
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert 'test' in str(e)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:47:28.984805
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('A bad thing happened')
    except RuntimeError as e:
        assert get_exception() is e

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:47:36.601389
# Unit test for function get_exception
def test_get_exception():
    import mock
    try:
        raise Exception('Test exception')
    except:
        with mock.patch('ansible.module_utils.basic.sys.exc_info') as mock_exc_info:
            mock_exc_info.return_value = (None, Exception('Test exception'), None)
            e = get_exception()
            assert e.args[0] == 'Test exception'



# Generated at 2022-06-23 02:47:39.515250
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Fake exception')
    except:
        exc = get_exception()
        assert type(exc) == type(Exception())
        assert str(exc) == str(Exception('Fake exception'))

# Generated at 2022-06-23 02:47:45.269068
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.six as six

    try:
        raise ValueError(u'\u2318')
    except ValueError:
        e = ansible.module_utils.splitter.get_exception()
        if six.PY2:
            test_msg = u'\u2318'.encode('utf-8')
        else:
            test_msg = u'\u2318'
        assert e.args[0] == test_msg

# Generated at 2022-06-23 02:47:46.706283
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert get_exception() is not None

# Generated at 2022-06-23 02:47:51.593378
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except:
        exc = get_exception()
        assert str(exc) == "Test Exception"

# Generated at 2022-06-23 02:47:53.836758
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError as e:
        assert(get_exception() == e)

# Generated at 2022-06-23 02:47:56.890890
# Unit test for function get_exception
def test_get_exception():
    """Test that the exception is retrieved"""

    try:
        raise ValueError('deliberate error')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'deliberate error'
        assert type(e) == ValueError


# Generated at 2022-06-23 02:47:59.875451
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-23 02:48:03.358444
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise Exception("Test exception")
    except:
        e = get_exception()
        assert e.message == "Test exception"
        assert isinstance(e, Exception)


# Generated at 2022-06-23 02:48:05.789495
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert type(get_exception()) == ZeroDivisionError


# Generated at 2022-06-23 02:48:09.415022
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a bug')
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert exc.args == ('a bug',)


# Generated at 2022-06-23 02:48:11.598610
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        exc = get_exception()
        assert e == exc

# Generated at 2022-06-23 02:48:14.096358
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foon')
    except ValueError as e:
        ex = get_exception()
    assert ex == e


# Generated at 2022-06-23 02:48:17.857724
# Unit test for function get_exception
def test_get_exception():
    was_caught = False
    ex = Exception('test get exception')
    try:
        raise ex
    except Exception:
        was_caught = True
        assert get_exception() is ex
    assert was_caught


# Generated at 2022-06-23 02:48:23.319251
# Unit test for function get_exception
def test_get_exception():
    """Test for get_exception"""
    def _test_func():
        try:
            exec('raise Exception(1)')
        except Exception:
            e = get_exception()
            assert e.args[0] == 1

    _test_func()



# Generated at 2022-06-23 02:48:26.655559
# Unit test for function get_exception
def test_get_exception():
    """Test code to test the get_exception function"""
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test'

# Generated at 2022-06-23 02:48:32.950045
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception as e:
        exc = get_exception()

    assert isinstance(exc, ZeroDivisionError)

# Generated at 2022-06-23 02:48:35.249477
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError

# Generated at 2022-06-23 02:48:41.269522
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u"\u6b4c\u821e\u4f0e\u5ea7")
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception), "get_exception did not get the exception"
        assert u"\u6b4c\u821e\u4f0e\u5ea7" in str(e), "get_exception did not get the right exception"


# Generated at 2022-06-23 02:48:45.653269
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-variable
    """Unit test for function get_exception."""
    from ansible.module_utils.six import reraise
    try:
        raise RuntimeError('Boom!')
    except RuntimeError:
        e = get_exception()
        reraise(RuntimeError, 'Boom!', sys.exc_info()[2])


# Generated at 2022-06-23 02:48:48.412487
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('sample')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'sample'

# Generated at 2022-06-23 02:48:52.489661
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        assert e

        try:
            raise e
        except Exception:
            e2 = get_exception()
            assert e2 and e2 == e



# Generated at 2022-06-23 02:48:55.122294
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Foo")
    except RuntimeError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:48:57.625285
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:49:02.226925
# Unit test for function get_exception
def test_get_exception():
    def i_throw_an_exception():
        raise RuntimeError('foo')

    try:
        i_throw_an_exception()
        assert False
    except:
        my_exception = get_exception()
    assert isinstance(my_exception, RuntimeError)
    assert my_exception.args[0] == 'foo'


# Generated at 2022-06-23 02:49:04.074514
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Foo")
    except:
        assert get_exception().args[0] == "Foo"

# Generated at 2022-06-23 02:49:06.314509
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('some fake exception')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:49:08.975809
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u'some text')
    except Exception:
        e = get_exception()
    assert(isinstance(e, Exception))
    assert(e.args[0] == u'some text')

# Generated at 2022-06-23 02:49:13.060103
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception_message')
    except:
        e = get_exception()

    assert e.args[0] == 'test_get_exception_message'

# Generated at 2022-06-23 02:49:15.752211
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise Exception('foo')
    except Exception:
        assert 'foo' in get_exception()



# Generated at 2022-06-23 02:49:19.580845
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError("some key")
    except KeyError:
        e = get_exception()
        assert isinstance(e, KeyError)
        assert e.message == "some key"

# Generated at 2022-06-23 02:49:21.708910
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:24.603319
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        x = get_exception()
        assert str(x) == "foo"


# Generated at 2022-06-23 02:49:32.259691
# Unit test for function get_exception
def test_get_exception():
    def this_throws():
        raise ValueError('foo')

    try:
        this_throws()
    except:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise AssertionError('get_exception() didn\'t return the exception that was thrown: %r' % e)


# Generated at 2022-06-23 02:49:35.891738
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        return get_exception()

e = test_get_exception()
if isinstance(e, ValueError) and e.args[0] == 'test':
    pass
else:
    raise ImportError('Unable to import get_exception()')

# Generated at 2022-06-23 02:49:41.984778
# Unit test for function get_exception
def test_get_exception():
    def callfunc():
        raise ValueError('test error')
    try:
        callfunc()
    except:
        exc = get_exception()
        assert exc.__class__ == ValueError, '%s != ValueError' % exc.__class__
        assert str(exc) == 'test error', '%s != test error' % str(exc)

# Generated at 2022-06-23 02:49:47.840664
# Unit test for function get_exception
def test_get_exception():
    """Call get_exception and verify that it returns the current exception.

    This test is useful in verifying that get_exception is working
    and that it is capable of fetching the current exception.
    """
    try:
        raise Exception

    except:
        e = get_exception()
        return e

# Generated at 2022-06-23 02:49:53.272607
# Unit test for function get_exception
def test_get_exception():
    try:
        1.0/0
    except ZeroDivisionError as e:
        assert e == get_exception()
    # And some self-referential tests
    try:
        raise ZeroDivisionError('Testing')
    except Exception:
        assert 'Testing' in "%s" % get_exception()

# Generated at 2022-06-23 02:49:58.364365
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'test'
    # ensure we didn't break built in exceptions.
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-23 02:50:00.296293
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:50:04.147145
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:  # noqa: E722
        e = get_exception()
    assert e.args == ('test',)

# Generated at 2022-06-23 02:50:07.371479
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('exception description')
    except:
        ex = get_exception()
    assert ex.args[0] == 'exception description'

# Generated at 2022-06-23 02:50:11.205320
# Unit test for function get_exception
def test_get_exception():
    try:
        # It will fail because the class 'Foo' is not defined
        e = Foo()
    except Exception:
        e = get_exception()
    assert isinstance(e, NameError)



# Generated at 2022-06-23 02:50:21.538488
# Unit test for function get_exception
def test_get_exception():
    import types
    import unittest
    try:
        from unittest.mock import Mock
        from unittest.mock import patch
    except ImportError:
        from mock import Mock
        from mock import patch

    from ansible.module_utils.basic import get_exception

    class get_exception_case(unittest.TestCase):
        def test_get_exception(self):
            e = get_exception()
            #AnsibleModule.exit_json() will raise this exception
            self.assertIsInstance(e, SystemExit)
            self.assertEqual(e.code, 0)

    #Somehow unittest.main() won't pickup the above test case without this
    def load_tests(loader, tests, pattern):
        suite = unittest.TestSuite()

# Generated at 2022-06-23 02:50:26.456154
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        assert get_exception().args[0] == 'test'


if __name__ == '__main__':
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-23 02:50:29.358589
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'test'

# Generated at 2022-06-23 02:50:35.968609
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() returns current exception."""
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception() is not None, \
            "get_exception() should return current exception."
        assert str(get_exception()) == 'foo', \
            "get_exception() should return current exception."


# Generated at 2022-06-23 02:50:39.771070
# Unit test for function get_exception
def test_get_exception():

    class MyException(Exception):
        pass

    try:
        raise MyException('test')
    except Exception:
        result = get_exception()
        assert result.__class__ == MyException
        assert str(result) == 'test'

# Generated at 2022-06-23 02:50:42.390000
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:50:44.966325
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'



# Generated at 2022-06-23 02:50:51.222853
# Unit test for function get_exception
def test_get_exception():
    def func():
        raise ValueError('dummy error')

    try:
        func()
    except ValueError:
        e = get_exception()
        assert(e)
        assert(e.__class__.__name__ == 'ValueError')
        assert(str(e) == 'dummy error')
        assert(e.args == ('dummy error',))


# Generated at 2022-06-23 02:50:58.515407
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('foo')
    except:
        # pylint: disable=bare-except
        exc = get_exception()
        # This should be exc_info[1] (the second element)
        assert exc.args[0] == 'foo'
        # This should be exc_info[0] (the first element)
        assert isinstance(exc, MyException)


# Generated at 2022-06-23 02:51:00.343986
# Unit test for function get_exception
def test_get_exception():
    # Need tests here
    pass


# Generated at 2022-06-23 02:51:02.566990
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except:
        e = get_exception()
        assert isinstance(e, RuntimeError)


# Generated at 2022-06-23 02:51:06.915186
# Unit test for function get_exception
def test_get_exception():

    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert exc == sys.exc_info()[1]

    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert exc == sys.exc_info()[1]

# Generated at 2022-06-23 02:51:11.243336
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IndexError()
    except:
        e = get_exception()
        assert type(e) == IndexError


# Generated at 2022-06-23 02:51:13.560044
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:51:17.569171
# Unit test for function get_exception
def test_get_exception():
    try:
        __builtins__.raise_an_exception
    except Exception:
        e = get_exception()
        assert isinstance(e, NameError)

# Generated at 2022-06-23 02:51:19.810603
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        e = get_exception()
    assert str(e) == 'Test exception'

# Generated at 2022-06-23 02:51:28.595473
# Unit test for function get_exception
def test_get_exception():
    # Python 3.5 wants to support bare 'except:' but when we do that, Python 2.6
    # thrashes as it tries to pull in a whole set of libraries which don't exist
    # on Python 2.6.  So we do it this way so that Python 2.6 doesn't even parse
    # the except line and thus doesn't raise a syntax error that we can't catch.
    #
    # This will fail if a later version of Python decides to make bare 'except:'
    # illegal syntax.
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()

    assert e.args == ('foo',)



# Generated at 2022-06-23 02:51:38.201006
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is the message")
    except Exception:
        e = get_exception()
        assert str(e) == 'This is the message'
        assert e.args == ('This is the message',)
        assert e.__class__.__name__ == 'RuntimeError'
    try:
        raise TypeError("This is the message")
    except Exception:
        e = get_exception()
        assert str(e) == 'This is the message'
        assert e.args == ('This is the message',)
        assert e.__class__.__name__ == 'TypeError'

# Generated at 2022-06-23 02:51:44.768920
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception as e:
        assert get_exception() is e

    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'test exception'



# Generated at 2022-06-23 02:51:47.308839
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        assert get_exception() is sys.exc_info()[1]


# Generated at 2022-06-23 02:51:51.524886
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == "foo"


# Generated at 2022-06-23 02:51:55.309853
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception('foo')
    try:
        f()
    except:
        exc = get_exception()
        assert('foo' == str(exc))
        assert(Exception == exc.__class__)



# Generated at 2022-06-23 02:51:59.259963
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        if get_exception() is not None:
            sys.exit(1)
    sys.exit(0)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:52:03.771801
# Unit test for function get_exception
def test_get_exception():
    def outer():
        def inner():
            try:
                raise Exception('foo')
            except Exception:
                e = get_exception()
                assert str(e) == 'foo'
                assert type(e) is Exception
        inner()
    outer()


# Generated at 2022-06-23 02:52:08.451471
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception), str(type(exc))
        assert str(exc) == "foo"


# Generated at 2022-06-23 02:52:12.806838
# Unit test for function get_exception
def test_get_exception():
    def some_exception(msg):
        try:
            raise Exception(msg)
        except Exception as e:
            return e
        except:  # pylint: disable=bare-except
            return get_exception()

    assert 'message' == some_exception('message').args[0]


# Generated at 2022-06-23 02:52:15.426190
# Unit test for function get_exception
def test_get_exception():
    '''Test that get_exception returns the current exception.'''
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
    assert e.args == ('test exception', )

# Generated at 2022-06-23 02:52:17.913107
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        assert str(get_exception()) == 'Test exception'


# Generated at 2022-06-23 02:52:20.789416
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is a test")
    except:
        exception = get_exception()
    assert exception.args[0] == "This is a test"

# Generated at 2022-06-23 02:52:23.485082
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        if not isinstance(e, ZeroDivisionError):
            raise Exception

# Generated at 2022-06-23 02:52:32.803425
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestException(Exception):
        pass

    class TestCase(unittest.TestCase):
        def test_exception_pass(self):
            try:
                raise TestException('foo')
            except TestException:
                exc = get_exception()
                self.assertTrue(isinstance(exc, TestException))
                self.assertEqual(exc.args[0], 'foo')

    import ansible.module_utils.six
    if not ansible.module_utils.six.PY3:
        test_cases = [TestCase]
        from ansible.module_utils.six.moves import unittest
        unittest.main(verbosity=0, failfast=True)

# Generated at 2022-06-23 02:52:34.911202
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('an error')
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'an error'

# Generated at 2022-06-23 02:52:37.034103
# Unit test for function get_exception

# Generated at 2022-06-23 02:52:42.186627
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
        assert True, "get_exception() returned True instead of raising an exception"
    assert e.__class__ is ValueError, "get_exception() didn't return the right exception"

# Generated at 2022-06-23 02:52:45.235511
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:52:47.922361
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception')
    except:
        e = get_exception()
    assert e.message == 'An exception'


# Generated at 2022-06-23 02:52:55.726383
# Unit test for function get_exception
def test_get_exception():
    # Ensure this runs on Python 2.4-2.7 and Python 3.x
    # pylint: disable=undefined-variable
    if sys.version_info[0] < 3:
        from StringIO import StringIO
        import io

        def _binary_type(x):
            return io.BytesIO(x)
    else:
        from io import StringIO
        import _io as io

        def _binary_type(x):
            return StringIO(x)

    # We need to import this from pytest here so that we can run this module's
    # tests on Travis-CI.
    from pytest import raises

    # Test Python's built-in exceptions
    try:
        raise ValueError
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)

    # Test

# Generated at 2022-06-23 02:52:59.838792
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise ValueError("This is a test")
    ... except Exception:
    ...     e = get_exception()
    ...
    >>> e.args[0]
    'This is a test'
    """
    pass

# Generated at 2022-06-23 02:53:02.006227
# Unit test for function get_exception
def test_get_exception():
    e = 'Test exception'
    try:
        raise RuntimeError(e)
    except RuntimeError:
        assert e == get_exception()



# Generated at 2022-06-23 02:53:04.497014
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    except Exception:
        pass
    assert e.args == ('test',)

# Generated at 2022-06-23 02:53:15.808849
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.pycompat24 import literal_eval

    m = AnsibleModule(argument_spec=dict(
        arg=dict(required=False, type='str'),
    ))
    m.argument_spec = dict()

    # SyntaxError: invalid syntax
    try:
        m.fail_json(msg=get_exception())
    except SystemExit:
        pass
    # KeyError: missing
    try:
        raise KeyError('missing')
    except KeyError:
        m.fail_json(msg=get_exception())
    # KeyError: nothing
    try:
        raise KeyError('nothing')
    except KeyError:
        m.fail

# Generated at 2022-06-23 02:53:22.476594
# Unit test for function get_exception

# Generated at 2022-06-23 02:53:26.972982
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Boo!")
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == "Boo!"
test_get_exception.__test__ = False


# Generated at 2022-06-23 02:53:31.520637
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('foo')
    except:
        exc = get_exception()
        assert isinstance(exc, TestException)
        assert str(exc) == 'foo'

# Generated at 2022-06-23 02:53:33.418658
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()

    assert e is not None

# Generated at 2022-06-23 02:53:36.047536
# Unit test for function get_exception
def test_get_exception():
    e = Exception("My exception")
    try:
        raise e
    except:
        ge = get_exception()

    assert e is ge
    assert e.args == ge.args

# Generated at 2022-06-23 02:53:44.574192
# Unit test for function get_exception
def test_get_exception():
    import traceback
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert e.__str__() == 'test exception'
        # Ensure we have the __traceback__ attribute

        try:
            e.__traceback__
        except AttributeError:
            if sys.version_info[0] == 2 and sys.version_info[1] < 7:
                raise Exception('Python version too old: {0}.{1}'.format(sys.version_info[0],
                                                                         sys.version_info[1]))
            raise Exception('__traceback__ attribute not set on exception: {0}'.format(traceback.print_exc()))


# Generated at 2022-06-23 02:53:48.493552
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()

    if e is not None:
        print("Exception {0}".format(repr(e)))
    else:
        print("No exception")



# Generated at 2022-06-23 02:53:52.405155
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except:
        e = get_exception()
    assert e.message == 'test_get_exception'



# Generated at 2022-06-23 02:53:54.900735
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        e = get_exception()
    assert e.message == 'Foo'

# Generated at 2022-06-23 02:53:58.838451
# Unit test for function get_exception
def test_get_exception():
    success = False
    try:
        raise RuntimeError('expected exception')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'expected exception'
        success = True
    assert success, 'get_exception failed to grab the exception'

# Generated at 2022-06-23 02:54:00.992536
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:04.548587
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-23 02:54:07.265218
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-23 02:54:09.656996
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except RuntimeError as e:
        assert get_exception() == e


# Generated at 2022-06-23 02:54:12.951627
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
        # Shouldn't get here
        assert False
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:54:16.864797
# Unit test for function get_exception
def test_get_exception():
    def raises(s):
        """Throw a ValueError."""
        raise ValueError(s)
    try:
        raises("Bar")
    except Exception:
        e = get_exception()
        assert str(e) == "Bar"

# Generated at 2022-06-23 02:54:21.285412
# Unit test for function get_exception
def test_get_exception():
    "Test function get_exception"
    class TestException(Exception):
        pass

    try:
        raise TestException('the message')
    except TestException:
        e = get_exception()

    assert 'the message' == str(e)
    assert 'TestException' == e.__class__.__name__

# Generated at 2022-06-23 02:54:25.039214
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a runtime error')
    except RuntimeError:
        exc = get_exception()
        assert 'This is a runtime error' in str(exc)


# Generated at 2022-06-23 02:54:28.172648
# Unit test for function get_exception
def test_get_exception():
    '''Nothing is raised'''
    try:
        raise ValueError("Something not to be worried about")
    except:
        e = get_exception()

    assert str(e) == "Something not to be worried about"

# Generated at 2022-06-23 02:54:36.081485
# Unit test for function get_exception
def test_get_exception():

    """Test function get_exception().

    This test is meant to be run using nose.
    """

    def assert_equals(x, y):
        """Compare x and y and raise an exception if they aren't equal.

        This is a helper function for the unit test.  It is used instead of
        calling test asserts inside of a try block because the asserts in nose
        don't print informative messages when they fail.
        """
        if x != y:
            raise AssertionError('Test failed: %s != %s' % (x, y))

    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()
        assert_equals(type(e), RuntimeError)

# Generated at 2022-06-23 02:54:39.188734
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('value error')
    except ValueError as e:
        assert get_exception() == e
        return
    assert False


# Generated at 2022-06-23 02:54:43.208442
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert str(exc) == "Test Exception"


# Generated at 2022-06-23 02:54:49.080022
# Unit test for function get_exception
def test_get_exception():
    def test():
        def inner():
            return 1 / 0
        inner()
    try:
        test()
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ZeroDivisionError)
        try:
            raise exc
        except ZeroDivisionError:
            pass
        else:
            assert False, '__class__ of exc was %r' % type(exc)

# Generated at 2022-06-23 02:54:51.976949
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable,expression-not-assigned
    try:
        raise ValueError
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:54:54.897226
# Unit test for function get_exception
def test_get_exception():
    class TestError(Exception):
        """Test exception."""

    try:
        raise TestError("We have a problem")
    except TestError:
        result = get_exception()
        assert isinstance(result, TestError)

# Generated at 2022-06-23 02:54:57.941660
# Unit test for function get_exception

# Generated at 2022-06-23 02:55:03.440676
# Unit test for function get_exception
def test_get_exception():
    # Arrange
    class MyException(Exception):
        pass

    # Act & Assert
    try:
        raise MyException("Oops")
    except Exception:
        e = get_exception()
        assert str(e) == "Oops"