

# Generated at 2022-06-23 02:45:03.854715
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'
        assert repr(e) == "ValueError('foo',)"

# Generated at 2022-06-23 02:45:05.685591
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        assert get_exception()



# Generated at 2022-06-23 02:45:08.452026
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert text_type(e) == 'foo'


# Generated at 2022-06-23 02:45:10.599479
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:45:20.131147
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception function

    When running in a python that has the syntax, "except Exception as e:", we
    need to be sure that we're able to handle the error and get the exception
    object in a way that is compatible with python 2.4 and python 3.x.
    """
    class What(Exception):
        pass
    try:
        raise What("This is an exception")
    except What:
        e = get_exception()
    assert isinstance(e, What)
    assert e.args == ('This is an exception',)


# Generated at 2022-06-23 02:45:24.709006
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing get_exception')
    except Exception:
        # get_exception works like Python 3.x's "as"
        e = get_exception()
        assert str(e) == 'Testing get_exception'
        return e

# Generated at 2022-06-23 02:45:27.577118
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except Exception as e:  # noqa
        pass
    except Exception:
        e = get_exception()
    assert e.args == ("foo",)


# Generated at 2022-06-23 02:45:29.570315
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'

# Generated at 2022-06-23 02:45:32.845218
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_get_exception')
    except ValueError:
        e = get_exception()
    assert "test_get_exception" in str(e)
    assert "test_get_exception" in repr(e)
    assert e.args[0] == "test_get_exception"

# Generated at 2022-06-23 02:45:36.296162
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert 'foo' in str(exc)

# Generated at 2022-06-23 02:45:39.542523
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=missing-docstring
    try:
        raise ValueError("I'm an exception")
    except:
        assert ValueError("I'm an exception") == get_exception()

# Generated at 2022-06-23 02:45:49.423407
# Unit test for function get_exception
def test_get_exception():
    # This function should always return the current exception
    def raiser0():
        raise ValueError('This is the exception')

    try:
        raiser0()
        assert False, 'Function raiser0 should have raised an exception'
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'This is the exception', \
            'Function get_exception did not return the current exception'

    # This function should return the exception that was active when it
    # was called even if it is no longer the current exception by the
    # time we leave the function
    exc = ValueError('This is the exception')
    def raiser1():
        return get_exception()


# Generated at 2022-06-23 02:45:56.093018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        e = get_exception()
        assert str(e) == 'foo'
    try:
        raise Exception("bar")
    except:
        e = get_exception()
        assert str(e) == 'bar'


# Generated at 2022-06-23 02:46:00.332328
# Unit test for function get_exception
def test_get_exception():

    class TestException(Exception):
        pass

    try:
        raise TestException('testing')
    except TestException as e:
        if str(e) != get_exception():
            raise AssertionError('Expected "%s" but got "%s"' % (e, get_exception()))



# Generated at 2022-06-23 02:46:03.786484
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("This is a test")
    except:
        assert 'This is a test' in str(get_exception())

# Generated at 2022-06-23 02:46:10.073797
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:14.011391
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('test')
    except MyException:
        e = get_exception()
        assert e.args == ('test',)

# Generated at 2022-06-23 02:46:17.824135
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test message')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'test message'



# Generated at 2022-06-23 02:46:20.050091
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Unit Test')
    except:
        assert 'Unit Test' in get_exception().message



# Generated at 2022-06-23 02:46:23.821680
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        e = get_exception()
        assert e.__class__ == TestException


# Generated at 2022-06-23 02:46:26.275000
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        exc = get_exception()
        assert isinstance(exc, ZeroDivisionError)

# Generated at 2022-06-23 02:46:28.837041
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:46:35.516592
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('just testing')
    except ValueError as e:
        assert e is get_exception()
    try:
        raise ValueError('just testing')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == 'just testing'

# Generated at 2022-06-23 02:46:50.012511
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import traceback

    try:
        raise RuntimeError("Exception to get")
    except:
        exception = get_exception()
        tb_string = ''.join(traceback.format_list(traceback.extract_tb(sys.exc_info()[2])))

    class MockModule(object):
        def __init__(self, result):
            self.result = result

        def fail_json(self, **args):
            self.result['failed'] = True
            for key in args:
                self.result[key] = args[key]

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            result = {}
            module = MockModule(result)

# Generated at 2022-06-23 02:46:52.445679
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()

    assert e.message == 'test exception'

# Generated at 2022-06-23 02:46:55.102828
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert exc.args == ('foo',)
        assert str(exc) == 'foo'

# Generated at 2022-06-23 02:47:02.388755
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        exc = get_exception()


# Generated at 2022-06-23 02:47:05.044452
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo bar')
    except ValueError as e:
        assert get_exception() is e



# Generated at 2022-06-23 02:47:07.364841
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception"""
    try:
        raise Exception("Test Exception")
    except Exception:
        e = get_exception()

    assert e.args[0] == "Test Exception", "get_exception did not raise the exception we expected"


# Generated at 2022-06-23 02:47:09.903788
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()

    assert e.__class__ == Exception
    assert str(e)

# Generated at 2022-06-23 02:47:12.594182
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('hello')
    except Exception:
        e = get_exception()
    assert e.args == ('hello',)


# Generated at 2022-06-23 02:47:17.921061
# Unit test for function get_exception
def test_get_exception():
    '''
    get_exception is used in all python scripts and unit tests to get exception
    This is a unit test for get_exception
    '''
    try:
        raise Exception('testing 123')
    except Exception:
        _, ex, _ = sys.exc_info()
        assert get_exception() == ex


# Generated at 2022-06-23 02:47:26.445026
# Unit test for function get_exception
def test_get_exception():
    """Ensure that get_exception will work in all versions of Python"""
    try:
        raise TypeError('This is an error to test with')
    except:
        # Cannot use 'except Exception, e' in Python 3.x
        e = get_exception()
    assert e
    # The get_exception function should not clobber the full exception
    # info
    try:
        raise TypeError('This is an error to test with')
    except:
        exc = sys.exc_info()
        e = get_exception()
        exc2 = sys.exc_info()
    assert e is exc[1]
    assert exc == exc2

# Generated at 2022-06-23 02:47:29.837854
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except Exception:
        e = get_exception()
    if str(e) != 'test':
        raise AssertionError('get_exception failed {}'.format(e))

# Generated at 2022-06-23 02:47:32.046825
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e is not None

# Generated at 2022-06-23 02:47:37.487421
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('No answer to everything')
    except Exception:
        e = get_exception()

    if not isinstance(e, ValueError):
        raise AssertionError('Wrong type: %s instead of ValueError' % type(e))
    if str(e) != 'No answer to everything':
        raise AssertionError('Wrong exception: %s instead of "No answer to everything"' % e)



# Generated at 2022-06-23 02:47:45.268684
# Unit test for function get_exception
def test_get_exception():
    # This is tricky to test, because we don't want to access the import in
    # this module from other code.  So, we defer the import until we're inside
    # the function.
    from ansible.module_utils.compat import get_exception
    try:
        raise Exception("foo")
    except:
        import sys
        e = get_exception()
        if sys.version_info[0] == 2:
            assert isinstance(e, Exception)
        else:
            assert isinstance(e, BaseException)
        assert str(e) == "foo"
        assert repr(e) == "<class 'Exception'>: foo"

# Generated at 2022-06-23 02:47:47.198999
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo', )


# Generated at 2022-06-23 02:47:51.644378
# Unit test for function get_exception
def test_get_exception():  # pragma no cover
    try:
        raise Exception()
    except Exception as e:
        assert e == get_exception()


# Generated at 2022-06-23 02:47:55.423039
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    assert repr(e) == 'ZeroDivisionError()'
    assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-23 02:48:00.427688
# Unit test for function get_exception
def test_get_exception():
    # Setup
    exception_message = u'Cannot do this'
    def fail():
        raise Exception(exception_message)

    # Test the desired functionality
    try:
        fail()
    except:
        e = get_exception()
        assert e.args[0] == exception_message

    # Test a syntax error
    try:
        literal_eval('{1')
    except:
        e = get_exception()
        assert isinstance(e, SyntaxError)


# Generated at 2022-06-23 02:48:03.278039
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        try:
            raise Exception('foo')
        except:
            assert 'foo' == get_exception().args[0]

    test_func()

# Generated at 2022-06-23 02:48:09.818466
# Unit test for function get_exception
def test_get_exception():
    """Test for exceptions.get_exception"""
    try:
        raise RuntimeError(u'Some error message')
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert u'Some error message' == str(e)


# Generated at 2022-06-23 02:48:12.869478
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise RuntimeError('Bad egg')
    try:
        test()
    except Exception:
        e = get_exception()
    assert str(e) == 'Bad egg'


# Generated at 2022-06-23 02:48:16.932904
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e1 = get_exception()
        assert str(e1) == 'Test exception'


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:48:18.940616
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert e.args == ('test',)

# Generated at 2022-06-23 02:48:24.368988
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:28.991727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a test')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('This is a test',)


# Generated at 2022-06-23 02:48:32.301162
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
        if isinstance(e, ValueError):
            pass
        else:
            raise AssertionError('get_exception() did not correctly get the current exception')

# Generated at 2022-06-23 02:48:34.796417
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:48:39.000440
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert str(e) == 'integer division or modulo by zero'
    else:
        assert False, 'get_exception has raised no exception'

# Generated at 2022-06-23 02:48:42.971820
# Unit test for function get_exception
def test_get_exception():
    def test_get_exception(level=0):
        try:
            try:
                raise Exception('Testing {}'.format(level))
            except:
                return get_exception()
        except Exception as e:
            if level > 1:
                return e
            return test_get_exception(level + 1)

    e = test_get_exception()
    assert e.args[0] == 'Testing 0'

# Generated at 2022-06-23 02:48:46.841183
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException("foo")
    except TestException:
        e = get_exception()
        assert e.args[0] == "foo"


# Generated at 2022-06-23 02:48:49.145181
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-23 02:48:50.951561
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert e == g

# Generated at 2022-06-23 02:49:01.439042
# Unit test for function get_exception
def test_get_exception():

    # test the try/except block from the docstring:
    try:
        raise Exception('this is an example exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'this is an example exception'

    # Be sure to restore the old exception
    try:
        raise e
    except:
        pass

    # Test having a secondary exception raised and caught
    try:
        try:
            raise Exception('this is an example exception')
        except:
            try:
                raise KeyError('this is a secondary exception')
            except:
                e = get_exception()
                assert str(e) == 'this is a secondary exception'
    except:
        pass

    # Be sure to restore the old exception
    try:
        raise e
    except:
        pass

# Unit tests for function

# Generated at 2022-06-23 02:49:06.004190
# Unit test for function get_exception
def test_get_exception():
    """
    Unit test for function get_exception
    """
    try:
        int('a')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-23 02:49:11.006720
# Unit test for function get_exception
def test_get_exception():
    # Python 2.4 and 2.5 don't have the try/except/finally statement,
    # so we have to do a hack to test the function
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'

if __name__ == '__main__':
    # Unit test for function literal_eval
    test_get_exception()
    from nose import runmodule
    runmodule()

# Generated at 2022-06-23 02:49:13.903550
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
    assert(e.__class__.__name__ == 'Exception')


# Generated at 2022-06-23 02:49:18.204989
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert repr(e) == repr(Exception('foo'))
    assert get_exception() is None

# Generated at 2022-06-23 02:49:24.358329
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert type(e) is ZeroDivisionError
        assert str(e) == 'integer division or modulo by zero'
        try:
            1/0
        except:
            e = get_exception()
            assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-23 02:49:28.950001
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:32.462581
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('oops1')
    except Exception:
        e = get_exception()
    assert str(e) == 'oops1'
    assert repr(e) == "RuntimeError('oops1',)"

# Generated at 2022-06-23 02:49:35.300733
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test error')
    except ValueError:
        got_exc = get_exception()
        assert(isinstance(got_exc, ValueError))
        assert(got_exc.args[0] == 'test error')

# Generated at 2022-06-23 02:49:39.936976
# Unit test for function get_exception
def test_get_exception():
    import pytest

    with pytest.raises(ValueError) as exc_info:
        raise ValueError('hi')
    assert exc_info.value == get_exception()


# Generated at 2022-06-23 02:49:42.501685
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:48.975671
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError:
        ex_info = get_exception()
        assert ex_info.args == ('foobar',)
        # This is a test of get_exception, but it's easier to put it here
        # than somewhere else...
        assert str(ex_info) == 'foobar'


# Generated at 2022-06-23 02:49:52.134713
# Unit test for function get_exception
def test_get_exception():
    try:
        int('hello world')
    except:
        e = get_exception()
    assert e.args == ('invalid literal for int() with base 10: \'hello world\'',)

# Generated at 2022-06-23 02:49:55.784240
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('foo')
    except MyException:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:49:57.699378
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("something")
    except ValueError as e:
        err = get_exception()
    assert e == err

# Generated at 2022-06-23 02:50:00.974950
# Unit test for function get_exception
def test_get_exception():
    def _raise():
        try:
            raise Exception('foo')
        except Exception:
            return get_exception()
    assert _raise() == 'foo'


# Generated at 2022-06-23 02:50:04.149379
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:50:08.184093
# Unit test for function get_exception
def test_get_exception():
    def test_exception():
        try:
            raise Exception("This is a test exception")
        except Exception:
            return get_exception()
    assert repr(test_exception()) == "Exception('This is a test exception',)"

# Generated at 2022-06-23 02:50:12.629619
# Unit test for function get_exception
def test_get_exception():

    class TestException(Exception):
        pass

    try:
        raise TestException("Unit Test")
    except TestException:
        e = get_exception()
        assert str(e) == "Unit Test"
        assert isinstance(e, TestException)


# Generated at 2022-06-23 02:50:16.002537
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is an expected exception')
    except RuntimeError:
        exc = get_exception()
        assert exc.args == ('This is an expected exception',)


# Generated at 2022-06-23 02:50:18.981435
# Unit test for function get_exception

# Generated at 2022-06-23 02:50:20.874043
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Some Error")
    except ValueError:
        e = get_exception()
    assert e.args[0] == "Some Error"

# Generated at 2022-06-23 02:50:26.288518
# Unit test for function get_exception
def test_get_exception():
    try:
        error = get_exception()
        assert error is None, "error should have been None"
        1 / 0
    except:
        error = get_exception()

    assert error is not None, "error should not have been None"

# Generated at 2022-06-23 02:50:31.711939
# Unit test for function get_exception
def test_get_exception():
    if sys.version_info[0] < 3:
        assert get_exception() is None

# Generated at 2022-06-23 02:50:35.573306
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        raise ValueError()

    try:
        test_func()
    except:
        e = get_exception()

    assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:50:38.481372
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException
    except Exception:
        e = get_exception()
    assert isinstance(e, TestException)

# Generated at 2022-06-23 02:50:41.616908
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert type(e) == Exception
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:50:44.572584
# Unit test for function get_exception
def test_get_exception():
    test_string = "this is not a valid string literal"
    try:
        literal_eval(test_string)
    except SyntaxError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:50:47.859258
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        assert get_exception()


# Generated at 2022-06-23 02:50:50.298620
# Unit test for function get_exception
def test_get_exception():
    try:
        int('garbage')
    except Exception as e:
        e2 = get_exception()
        assert e == e2


# Generated at 2022-06-23 02:50:54.600091
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:50:57.275195
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Fake error')
    except RuntimeError:
        exc = get_exception()
    assert str(exc) == 'Fake error', exc


# Generated at 2022-06-23 02:51:02.012065
# Unit test for function get_exception
def test_get_exception():
    def passthrough():  # pylint: disable=missing-docstring
        try:
            raise ValueError('foo')
        except ValueError:
            e = get_exception()
            return e
    assert 'foo' in str(passthrough())


# Generated at 2022-06-23 02:51:05.101568
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError), 'Test failed.  Returned exception is not a RuntimeError'



# Generated at 2022-06-23 02:51:08.702360
# Unit test for function get_exception
def test_get_exception():
    try:
        print(range(10)[20])
    except:
        e = get_exception()
        assert e.args[0] == 'list index out of range'
    else:
        raise AssertionError('Did not get an exception')


# Generated at 2022-06-23 02:51:11.820648
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test exception'



# Generated at 2022-06-23 02:51:15.272638
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        assert str(get_exception()) == 'foo'



# Generated at 2022-06-23 02:51:16.574231
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'

# Generated at 2022-06-23 02:51:22.586573
# Unit test for function get_exception
def test_get_exception():
    # This one raises an error.
    try:
        raise SyntaxError('foo')
    except SyntaxError:
        e = get_exception()
        assert isinstance(e, SyntaxError)

    # This one doesn't.
    try:
        pass
    except:
        e = get_exception()
        assert e is None



# Generated at 2022-06-23 02:51:25.039506
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'
test_get_exception()

# Generated at 2022-06-23 02:51:28.557690
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1/0
    except Exception:
        e = get_exception()
        assert e.__class__ is ZeroDivisionError


# Generated at 2022-06-23 02:51:34.638629
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise NameError('test')

# Generated at 2022-06-23 02:51:38.576728
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert e.args == ('foo',)



# Generated at 2022-06-23 02:51:44.675445
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException(1, "me")
    except Exception:
        t, v, b = sys.exc_info()
        assert v.args == (1, "me")
        assert get_exception().args == (1, "me")

# Generated at 2022-06-23 02:51:46.952968
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:51:51.691114
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a test')
    except RuntimeError:
        error = get_exception()
    assert error.args == ('This is a test', )


# Generated at 2022-06-23 02:51:54.102309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Example exception')
    except:
        exc = get_exception()
        assert exc.message == 'Example exception'

# Generated at 2022-06-23 02:51:59.771295
# Unit test for function get_exception
def test_get_exception():
    # This function has been really well tested by the unit tests for
    # the module_utils/exception_handling.py file.  It's virtually impossible
    # to test without coverage since it needs to raise an exception and
    # then check it.  We'll just check that the function can be called.
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception() is not None

# Generated at 2022-06-23 02:52:03.014110
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception()
    try:
        f()
    except:
        e = get_exception()
        assert True
    else:
        assert False

# Generated at 2022-06-23 02:52:06.023021
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('bork')
    except TypeError:
        exc = get_exception()
        assert exc.args[0] == 'bork'


# Generated at 2022-06-23 02:52:10.744009
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        try:
            raise Exception('bar')
        except Exception:
            e = get_exception()
            assert repr(e) == 'Exception(bar)'



# Generated at 2022-06-23 02:52:14.904721
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except:
        e = get_exception()
        assert type(e) is RuntimeError
        assert str(e) == 'test'



# Generated at 2022-06-23 02:52:17.347675
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        assert get_exception()
    raise AssertionError("Shouldn't get here")

# Generated at 2022-06-23 02:52:20.253074
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:52:29.827607
# Unit test for function get_exception

# Generated at 2022-06-23 02:52:35.095923
# Unit test for function get_exception
def test_get_exception():
    """This function is used by test_utils to ensure that the get_exception function
    works as expected.

    :returns: ``True`` if the get_exception function works as expected.
    """
    try:
        raise Exception('test_get_exception')
    except Exception:
        e = get_exception()
    return isinstance(e, Exception) and e.args[0] == 'test_get_exception'

# Generated at 2022-06-23 02:52:45.255117
# Unit test for function get_exception
def test_get_exception():
    def test_exception(exname):
        class Ex(Exception):
            pass
        try:
            raise Ex()
        except:
            ex = get_exception()
            assert isinstance(ex, Ex)
        try:
            raise Ex()
        except Ex:
            ex = get_exception()
            assert isinstance(ex, Ex)
        try:
            raise Ex()
        except Exception:
            ex = get_exception()
            assert isinstance(ex, Ex)
    test_exception('get_exception')



# Generated at 2022-06-23 02:52:50.844721
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("I raise error")
    except Exception:
        e = get_exception()
    assert str(e) == 'I raise error'

    class SomeError(Exception):
        pass

    try:
        raise SomeError("I raise some error")
    except Exception:
        e = get_exception()
    assert isinstance(e, SomeError)
    assert str(e) == 'I raise some error'

# Generated at 2022-06-23 02:52:55.580810
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("An exception")
    except Exception:
        e = get_exception()
        assert e.args[0] == "An exception"


# Generated at 2022-06-23 02:52:57.768457
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        assert get_exception() is not None



# Generated at 2022-06-23 02:53:05.726436
# Unit test for function get_exception
def test_get_exception():
    # Top-level call
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'foo'
    # Nested call
    try:
        try:
            try:
                raise ValueError('foo')
            except ValueError:
                e = get_exception()
                raise ValueError('bar')
        except ValueError:
            e = get_exception()
    except ValueError:
        pass
    assert isinstance(e, ValueError)
    assert str(e) == 'bar'



# Generated at 2022-06-23 02:53:08.877169
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('t')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:53:11.033683
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)


# Generated at 2022-06-23 02:53:14.840627
# Unit test for function get_exception
def test_get_exception():
    # Nothing to test. The name is either accurate or not and we see if it raises.
    try:
        raise Exception("Testing testing")
    except Exception:
        e = __import__(__name__).get_exception()
        assert e.args == ("Testing testing",)

# Generated at 2022-06-23 02:53:16.845569
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:53:20.557955
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("testing!")
    except ValueError:
        e = get_exception()
        assert e.args == ("testing!",)


# Generated at 2022-06-23 02:53:23.552422
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:53:27.655473
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None    # nothing was raised

# Generated at 2022-06-23 02:53:31.286198
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise RuntimeError("bar")
    try:
        foo()
    except Exception:
        e = get_exception()
        assert e.args == ("bar",)
        assert str(e) == "bar"

# Generated at 2022-06-23 02:53:37.573344
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def test_function():
        1/0

    try:
        test_function()
    except ZeroDivisionError:
        exc = get_exception()
        assert exc
        assert 'ZeroDivisionError' in str(exc)

        # Test that the exception when raised again behaves correctly
        with pytest.raises(ZeroDivisionError):
            raise exc
    else:
        raise AssertionError("ZeroDivisionError exception not raised")

# Generated at 2022-06-23 02:53:41.528041
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise ValueError("This is an example exception")
    ... except ValueError:
    ...     e = get_exception()
    >>> bool(e)
    True
    >>> isinstance(e, ValueError)
    True
    """
    pass



# Generated at 2022-06-23 02:53:44.287500
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=no-self-use
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'test'



# Generated at 2022-06-23 02:53:47.374138
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:53:51.358860
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError()
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert e.__class__.__name__ == 'ZeroDivisionError'

# Generated at 2022-06-23 02:53:55.917850
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Deliberate exception")
    except Exception:
        e = get_exception()
        if str(e) != "Deliberate exception":
            raise AssertionError("get_exception() returned unexpected exception: %s" % str(e))

# Generated at 2022-06-23 02:53:59.722166
# Unit test for function get_exception
def test_get_exception():
    try:
        print('foo') + 1
    except TypeError:
        e = get_exception()
        print(e)
        assert repr(e) == "'unsupported operand type(s) for +: 'str' and 'int''"


# Generated at 2022-06-23 02:54:02.922385
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('failed')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'failed'
    assert e.__class__.__name__ == 'RuntimeError'

# Generated at 2022-06-23 02:54:07.844114
# Unit test for function get_exception
def test_get_exception():
    import sys
    try:
        raise Exception('foo')
    except Exception as e:
        if sys.version_info[0] < 3:
            assert e is get_exception()
        else:
            assert e is not get_exception()  # pylint: disable=comparison-with-callable

# Generated at 2022-06-23 02:54:14.886386
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('value')
    except Exception as e:
        e1 = e
    except:  # noqa: E722
        e1 = get_exception()
    try:
        raise 1
    except:  # noqa: E722
        e2 = get_exception()
    assert isinstance(e1, Exception)
    assert isinstance(e2, int)



# Generated at 2022-06-23 02:54:19.440138
# Unit test for function get_exception
def test_get_exception():
    def raise_exception(message):
        class MyException(Exception):
            pass
        raise MyException(message)

    try:
        raise_exception('message')
    except Exception:
        exception = get_exception()
    assert exception.args == ('message',)

# Generated at 2022-06-23 02:54:28.477798
# Unit test for function get_exception
def test_get_exception():
    def test_try():
        try:
            raise Exception('hi')
        except Exception:
            return get_exception()

    class TestException(Exception):
        pass

    def test_try_newstyle():
        try:
            raise TestException('hi')
        except Exception:
            return get_exception()

    def test_try_except():
        try:
            raise Exception('hi')
        except Exception:
            e = get_exception()

        return e

    def test_try_except_newstyle():
        try:
            raise TestException('hi')
        except Exception:
            e = get_exception()

        return e

    def test_try_finally():
        try:
            raise Exception('hi')
        finally:
            return get_exception()


# Generated at 2022-06-23 02:54:31.051389
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is the test exception")
    except:
        e = get_exception()
    assert "This is the test exception" == str(e)

# Generated at 2022-06-23 02:54:35.612376
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=undefined-variable
        x = y
    except NameError as e:
        assert str(e) == "global name 'y' is not defined"
        assert get_exception() == e
        assert get_exception().message == str(e)
    else:
        raise AssertionError('Failed to raise NameError')


# Generated at 2022-06-23 02:54:38.125720
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Simulated exception for unit test")
    except Exception:
        assert (get_exception() is sys.exc_info()[1])

# Generated at 2022-06-23 02:54:45.820728
# Unit test for function get_exception
def test_get_exception():
    class FooException(Exception): pass
    try:
        raise FooException('Test')
    except FooException:
        exc = get_exception()
        if not isinstance(exc, FooException):
            raise AssertionError('get_exception() did not return FooException')
        if str(exc) != 'Test':
            raise AssertionError('get_exception() did not return FooException(Test)')

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:54:48.514074
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        assert get_exception() == sys.exc_info()[1]

# Generated at 2022-06-23 02:54:52.427334
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('hi')
    except Exception:
        e = get_exception()
        if e.__str__() != 'hi':
            raise AssertionError('__str__ of exception incorrect')
        if e.message != 'hi':
            raise AssertionError('message of exception incorrect')


# Generated at 2022-06-23 02:54:56.877396
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('abc')
    except RuntimeError:
        assert 'abc' in str(get_exception())



# Generated at 2022-06-23 02:55:02.657944
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing get_exception()')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'Testing get_exception()'


# Unit tests for function literal_eval