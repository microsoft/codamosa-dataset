

# Generated at 2022-06-23 02:45:06.333411
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() works"""
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:45:08.727271
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("get_exception")
    except TypeError:
        e = get_exception()
        assert e.__str__() == "get_exception"

# Generated at 2022-06-23 02:45:10.780699
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:16.032749
# Unit test for function get_exception
def test_get_exception():
    def f():
        x = 1/0
    try:
        f()
    except Exception:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError

    try:
        literal_eval(1)
    except Exception:
        e = get_exception()
        assert e.__class__ == TypeError

# Generated at 2022-06-23 02:45:20.129017
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert 'foo' in str(exc)


# Generated at 2022-06-23 02:45:24.245257
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except ZeroDivisionError:
        if not isinstance(get_exception(), ZeroDivisionError):
            raise Exception('get_exception() did not return the expected exception')
    else:
        raise Exception('get_exception() should have raised a ZeroDivisionError')

# Generated at 2022-06-23 02:45:26.507875
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Expected exception')
    except ValueError as exc:
        assert exc == get_exception()
        return
    assert False


# Generated at 2022-06-23 02:45:32.212405
# Unit test for function get_exception
def test_get_exception():
    def test_function(value):
        try:
            raise RuntimeError('Error message: %s' % value)
        except Exception:
            e = get_exception()
            return e.args
    assert test_function(42) == ('Error message: 42',)
    assert test_function('foo') == ('Error message: foo',)


# Generated at 2022-06-23 02:45:40.257614
# Unit test for function get_exception
def test_get_exception():
    import pytest

    # This test will fail if python gets a new syntax to raise exceptions in the future
    with pytest.raises(SyntaxError):
        # This should raise a SyntaxError because it should be "as" instead
        raise Exception("test")

    try:
        # This should raise a SyntaxError because it should be "as" instead
        raise Exception("test")
    except Exception:
        e = get_exception()
        assert e.__str__() == "test"



# Generated at 2022-06-23 02:45:42.571463
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        assert(get_exception().args[0] == 'Test exception')

# Generated at 2022-06-23 02:45:46.760979
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'foo'
    except Exception:
        assert False

if __name__ == '__main__':
    # Unit test for function get_exception
    test_get_exception()

# Generated at 2022-06-23 02:45:49.263521
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("an exception happened")
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)
    assert str(e) == "an exception happened"

# Generated at 2022-06-23 02:45:57.075751
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import PY3
    err = None
    try:
        raise ValueError("Test error for get_exception")
    except Exception:
        err = get_exception()

    if PY3:
        assert type(err) is ValueError
    else:
        assert type(err) is Exception
    assert str(err) == "Test error for get_exception"

# Generated at 2022-06-23 02:46:00.592540
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert e.__str__().find('ZeroDivisionError') > -1
    else:
        raise AssertionError("Should not get here")

# Generated at 2022-06-23 02:46:06.304953
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception returns the exception object."""

    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'test'
    assert repr(e) == 'ValueError(\'test\',)'



# Generated at 2022-06-23 02:46:12.439476
# Unit test for function get_exception
def test_get_exception():
    def function1(arg1):
        return function2(arg1)

    def function2(arg1):
        return float(arg1)

    try:
        function1('spam')
        assert False, 'function1 should raise an exception when arg1 is not a number'
    except TypeError as e:
        assert e == get_exception(), 'get_exception should return the same thing as TypeError instance'
    except:
        assert False, 'function1 should raise a TypeError when arg1 is not a number'

# Generated at 2022-06-23 02:46:14.879040
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('info')
    except TypeError as e:
        assert get_exception() == e


# Generated at 2022-06-23 02:46:20.532137
# Unit test for function get_exception
def test_get_exception():
    ''' Ensure exception can be caught and returned.'''
    class GetExceptionError(Exception):
        pass

    try:
        raise GetExceptionError('Test')
    except Exception:
        exc = get_exception()
    try:
        raise exc
    except GetExceptionError:
        pass


# unit test for function literal_eval

# Generated at 2022-06-23 02:46:28.457550
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        e1 = get_exception()
        assert e is e1, "get_exception() didn't get the exception"

    try:
        raise ValueError('bar')
    except ValueError:
        e2 = get_exception()
        assert isinstance(e2, ValueError), "get_exception() didn't catch an exception"
        assert e2.args[0] == 'bar', "get_exception() didn't preserve the exception args"



# Generated at 2022-06-23 02:46:31.172889
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("I'm an exception")
    except:
        assert ValueError("I'm an exception") == get_exception()


# Generated at 2022-06-23 02:46:37.178113
# Unit test for function get_exception
def test_get_exception():
    # from http://stackoverflow.com/a/21486097/5195840
    try:
        raise IndexError
    except:
        assert sys.exc_info() == get_exception()
    # from https://github.com/python/cpython/blob/master/Lib/test/test_pep352.py
    try:
        exec('raise ValueError')
    except:
        assert sys.exc_info() == get_exception()

# Generated at 2022-06-23 02:46:42.709422
# Unit test for function get_exception
def test_get_exception():
    # Check if the function exists
    try:
        get_exception
    except NameError:
        print("SKIP: Could not find function get_exception")
        exit(0)

    # Call function get_exception
    try:
        n = 1/0
    except:
        e = get_exception()

    # Check if we get the right type of exception
    if not isinstance(e, ZeroDivisionError):
        print("FAIL: Expected ZeroDivisionError, got: %s" % type(e))
        exit(1)

# Generated at 2022-06-23 02:46:46.031706
# Unit test for function get_exception
def test_get_exception():
    '''Test that we can get the current exception being raised.'''
    exc = None
    try:
        raise ValueError("Test get_exception")
    except Exception:
        exc = get_exception()
    if not isinstance(exc, ValueError) or exc.args[0] != "Test get_exception":
        raise Exception("get_exception didn't return the current exception: %s" % exc)

# Generated at 2022-06-23 02:46:51.168142
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=using-constant-test
    # pylint: disable=invalid-name
    class Foo(Exception):
        pass

    try:
        raise Foo
    except Exception:
        e = get_exception()
        assert isinstance(e, Foo)
    else:
        raise AssertionError("Failed to catch exception")


# Generated at 2022-06-23 02:46:53.939284
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("Error Message")
    except TypeError:
        error = get_exception()
        assert str(error) == "Error Message"

# Generated at 2022-06-23 02:46:56.104480
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        print(e)
    assert str(e) == 'test'

# Generated at 2022-06-23 02:47:09.371587
# Unit test for function get_exception
def test_get_exception():
    def bar():
        try:
            raise ValueError('hello')
        except Exception:
            e = get_exception()
            return e

    def foo():
        try:
            raise IOError('there')
        except Exception:
            e = get_exception()
            return e

    try:
        raise SyntaxError('this is a test')
    except Exception:
        e = get_exception()
        assert isinstance(e, SyntaxError)
        assert str(e) == 'this is a test'

    assert isinstance(foo(), IOError)
    assert str(foo()) == 'there'
    assert isinstance(bar(), ValueError)
    assert str(bar()) == 'hello'

# Generated at 2022-06-23 02:47:13.416953
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == "Test exception"
        assert repr(e) == "ValueError('Test exception',)"

# Generated at 2022-06-23 02:47:16.330539
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'



# Generated at 2022-06-23 02:47:18.738013
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:47:22.291090
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, MyException)

# Generated at 2022-06-23 02:47:26.915789
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is a test")
    except:
        e = get_exception()

    assert isinstance(e, Exception)
    assert 'test_utils.py' in str(e)
    assert 'Exception' in str(e)
    assert 'This is a test' in str(e)


# Generated at 2022-06-23 02:47:32.204614
# Unit test for function get_exception
def test_get_exception():
    """Test that we can capture exceptions"""
    def raise_exception():
        raise Exception('This is the exception you are interested in')
    try:
        raise_exception()
    except:
        ex = get_exception()
        assert ex.args[0] == 'This is the exception you are interested in'

# Generated at 2022-06-23 02:47:36.892846
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            (1, 2)[3]
        except Exception:
            e = get_exception()
            return e
    assert isinstance(f(), IndexError)



# Generated at 2022-06-23 02:47:42.085012
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except:
        returned_exception = get_exception()

    assert isinstance(returned_exception, ValueError)
    assert returned_exception.args[0] == 'This is a test'


# Generated at 2022-06-23 02:47:44.735419
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise RuntimeError()
        except Exception:
            return get_exception()
    assert isinstance(f(), RuntimeError)


# Generated at 2022-06-23 02:47:48.560414
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise ValueError("This is an exception")
    except ValueError as e:
        assert get_exception() == e
    else:
        raise AssertionError("This test is supposed to raise an exception")

# Generated at 2022-06-23 02:47:52.676002
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works"""

# Generated at 2022-06-23 02:48:00.716178
# Unit test for function get_exception
def test_get_exception():

    # Helper function to test that get_exception() raises an exception when it is missing
    def get_exception_raise_exception(e_name):
        class RaiseException:
            def __str__(self):
                return self.__class__.__name__

# Generated at 2022-06-23 02:48:03.558513
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'


# Generated at 2022-06-23 02:48:10.292942
# Unit test for function get_exception
def test_get_exception():

    def raises_exception():
        try:
            raise Exception("Foo")
        except Exception:
            e = get_exception()
        return e
    assert str(raises_exception()) == "Foo"

    def doesnt_raise_exception():
        try:
            raise Exception("Foo")
        except Exception:
            e = get_exception()
        return str(e)
    assert doesnt_raise_exception() == "Foo"

# Generated at 2022-06-23 02:48:14.983886
# Unit test for function get_exception
def test_get_exception():
    # Python 2.6+
    import unittest2 as unittest


# Generated at 2022-06-23 02:48:21.775750
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=too-many-branches
    '''test get_exception'''
    try:
        raise ValueError('')
    except Exception:
        assert isinstance(get_exception(), ValueError)

    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'

    # test an exception subclass
    class MyException(Exception):
        def __init__(self, foo, bar=None):
            super(MyException, self).__init__()
            self.args = (foo, bar)
    try:
        raise MyException('foo', 'bar')
    except Exception:
        obj = get_exception()
        assert isinstance(obj, MyException)
        assert obj.args[0] == 'foo'
        assert obj.args

# Generated at 2022-06-23 02:48:36.179435
# Unit test for function get_exception
def test_get_exception():
    class DummyException(Exception):
        pass

    try:
        raise DummyException()
    except DummyException:
        exc = get_exception()
        assert isinstance(exc, DummyException)
        assert str(exc) == ''

    try:
        raise DummyException('Foo')
    except DummyException:
        exc = get_exception()
        assert isinstance(exc, DummyException)
        assert str(exc) == 'Foo'

    try:
        raise DummyException('Foo')
    except DummyException as e:
        assert isinstance(e, DummyException)
        assert str(e) == 'Foo'


# Generated at 2022-06-23 02:48:45.571031
# Unit test for function get_exception
def test_get_exception():
    """Catch the exception when it's not specified in the except clause."""
    try:
        raise ValueError('a different exception')
    except ValueError:
        e = get_exception()
    if not isinstance(e, ValueError):
        raise AssertionError('get_exception() [1] failed: %r' % e)
    if e.args[0] != 'a different exception':
        raise AssertionError('get_exception() [2] failed: %r' % e)

    """Catch the exception when it's specified in the except clause."""
    try:
        raise ValueError('another different exception')
    except ValueError as e:
        if not isinstance(e, ValueError):
            raise AssertionError('get_exception() [3] failed: %r' % e)

# Generated at 2022-06-23 02:48:48.306277
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NotImplementedError('fubar')
    except:
        pass
    assert isinstance(get_exception(), NotImplementedError)

# Generated at 2022-06-23 02:48:54.892181
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    try:
        try:
            raise ValueError
        except:
            e = get_exception()
    except:
        pass
    else:
        raise AssertionError("get_exception() should die with ValueError")
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:48:57.975845
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass
    try:
        raise CustomException
    except Exception:
        e = get_exception()
    assert isinstance(e, CustomException)



# Generated at 2022-06-23 02:49:01.851739
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert str(e) == 'test'

    try:
        raise Exception('test')
    except Exception:
        e = sys.exc_info()[1]
    assert str(e) == 'test'


# Generated at 2022-06-23 02:49:07.423535
# Unit test for function get_exception
def test_get_exception():
    if sys.version_info[0] < 3:
        x = "Hello"

# Generated at 2022-06-23 02:49:12.883406
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        e = get_exception()
        assert e.__class__ is ValueError
        assert str(e) == 'test exception'
test_get_exception()


# Generated at 2022-06-23 02:49:18.330021
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Expected exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError), 'Expected RuntimeError, got %r' % e
        assert e.args == ('Expected exception',), 'Expected ("Expected exception",), got %r' % e.args


# Generated at 2022-06-23 02:49:20.885451
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-23 02:49:25.056691
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'foo'
        assert repr(e) == "Exception('foo',)"
test_get_exception()

# Generated at 2022-06-23 02:49:32.709754
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert type(e) == ZeroDivisionError

    # Define an exception and make sure get_exception catches it
    class MyExcept(Exception):
        pass

    try:
        raise MyExcept()
    except:
        e = get_exception()
        assert type(e) == MyExcept

# Generated at 2022-06-23 02:49:40.231677
# Unit test for function get_exception
def test_get_exception():
    '''Test the get_exception function'''
    try:
        raise RuntimeError('This is a test exception')
    except Exception:
        e = sys.exc_info()[1]
        e2 = get_exception()
    assert e.__class__ == e2.__class__ == RuntimeError
    assert str(e) == str(e2) == 'This is a test exception'


# Generated at 2022-06-23 02:49:43.207683
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert exc.args == ('foo',), exc.args


# Generated at 2022-06-23 02:49:48.385622
# Unit test for function get_exception
def test_get_exception():
    try:
        a = get_exception()
    except:  # noqa
        # We can't expect the call to work, but we can test the import
        if get_exception() != sys.exc_info()[1]:
            raise



# Generated at 2022-06-23 02:49:52.319298
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError:
        e = get_exception()
    assert e.args[0] == "foo"

# Generated at 2022-06-23 02:49:55.058318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        assert get_exception() is sys.exc_info()[1]



# Generated at 2022-06-23 02:50:06.515738
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing get_exception')
    except Exception:
        exc = get_exception()
        if str(exc) != 'Testing get_exception':
            assert False, 'get_exception returned wrong exception: ' + str(exc)
    try:
        raise LookupError('Testing get_exception')
    except LookupError:
        exc = get_exception()
        if str(exc) != 'Testing get_exception':
            assert False, 'get_exception returned wrong exception: ' + str(exc)
        exc = get_exception()
        if str(exc) != 'Testing get_exception':
            assert False, 'get_exception returned wrong exception: ' + str(exc)



# Generated at 2022-06-23 02:50:08.709161
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'This is an exception'

# Generated at 2022-06-23 02:50:16.375504
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception returns the exception with the appropriate
    # traceback
    global __file__
    __file__ = '/foo/bar/baz.py'
    try:
        1/0
    except:
        e = get_exception()
        assert e.__traceback__.tb_lineno == sys.exc_info()[2].tb_lineno
        assert e.__traceback__.tb_frame.f_code.co_filename == __file__



# Generated at 2022-06-23 02:50:18.983109
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        ex = get_exception()
    assert 'Test exception' == str(ex)


# Generated at 2022-06-23 02:50:23.818429
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise Exception('foo')
    ... except Exception:
    ...     e = get_exception()
    ...
    >>> str(e)
    'foo'
    """
    pass



# Generated at 2022-06-23 02:50:29.833223
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception to make sure it works on all versions of python.

    Taken from a 2.6 version of ast.literal_eval.
    """
    try:
        literal_eval('test')
    except ValueError as e:
        test_exception = e
    assert get_exception() is test_exception

# Generated at 2022-06-23 02:50:33.504933
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=missing-docstring
    e = None
    try:
        raise RuntimeError('This exception should be caught')
    except RuntimeError:
        e = get_exception()

    assert str(e) == 'This exception should be caught'

# Generated at 2022-06-23 02:50:36.396308
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('get_exception')
    except Exception:
        assert get_exception().args[0] == 'get_exception'



# Generated at 2022-06-23 02:50:42.582431
# Unit test for function get_exception
def test_get_exception():
    # Create a local function that will raise an exception to be caught.
    def test_exception():
        raise Exception("This is a test for get_exception")
    # Call the function and expect to get an exception
    try:
        test_exception()
    except:
        # Assert that we were able to get the exception and that it's the one we expected
        assert get_exception() == Exception("This is a test for get_exception")

# Generated at 2022-06-23 02:50:45.364203
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'test_get_exception', exc


# Generated at 2022-06-23 02:50:47.466475
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Exception')
    except ValueError:
        e = get_exception()

    assert str(e) == 'Test Exception'



# Generated at 2022-06-23 02:50:50.635920
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
    except Exception:
        e = get_exception()
    assert str(e) == "'foo' is not a valid literal for int() with base 10: 'foo'"



# Generated at 2022-06-23 02:50:56.310724
# Unit test for function get_exception
def test_get_exception():
    """Verify that the get_exception function gets the right exception"""

    try:
        raise RuntimeError('testing')
    except Exception:
        e = get_exception()
        assert str(e) == 'testing'


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:50:58.471242
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IndexError("This is a test exception")
    except IndexError as e:
        exc = get_exception()
    assert e == exc

# Generated at 2022-06-23 02:51:01.557204
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        exc = get_exception()

    assert str(exc) == "Test Exception"

# Generated at 2022-06-23 02:51:04.653887
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foobar'


# Generated at 2022-06-23 02:51:08.277844
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert e.__class__.__name__ == 'TypeError'


# Generated at 2022-06-23 02:51:15.401540
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=no-self-use
    """Return the current exception.

    This code needs to work on Python 2.4 through 3.x, so we cannot use
    "except Exception, e:" (SyntaxError on Python 3.x) nor
    "except Exception as e:" (SyntaxError on Python 2.4-2.5).
    Instead we must use "except Exception: e = get_exception()"

    This is a unit test for the get_exception function.
    """
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:51:18.009260
# Unit test for function get_exception
def test_get_exception():
    """Ensure that get_exception() returns the current exception"""

    def raise_exception():
        try:
            raise ValueError('Raise an exception for unit testing')
        except ValueError as e:
            return get_exception()

    e = raise_exception()
    assert e.args[0] == 'Raise an exception for unit testing'

# Generated at 2022-06-23 02:51:21.510612
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except Exception:
        e = get_exception()
    assert str(e) == 'integer division or modulo by zero'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:51:25.803255
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise Exception('get_exception exception')
        except Exception:
            e = get_exception()
    except Exception:
        e = get_exception()
    assert str(e) == 'get_exception exception'
test_get_exception()



# Generated at 2022-06-23 02:51:29.260794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'test_get_exception'


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:51:32.959743
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('foo',)


# Generated at 2022-06-23 02:51:35.211908
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('bazinga')
    except ValueError as e:
        assert e is get_exception()



# Generated at 2022-06-23 02:51:37.296340
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)


# Generated at 2022-06-23 02:51:42.298087
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is a test")
    except Exception:
        exc = get_exception()
    assert str(exc) == "This is a test"

# Generated at 2022-06-23 02:51:44.532095
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:51:51.389566
# Unit test for function get_exception
def test_get_exception():
    try:
        for i in range(5):
            pass
        else:
            raise ValueError("My Exception")
    except ValueError:
        e = get_exception()
        assert e.args[0] == "My Exception", "TEST FAILED! Incorrect exception message."
        assert type(e) is ValueError, "TEST FAILED! Incorrect exception type."

# Generated at 2022-06-23 02:51:55.750007
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:59.692962
# Unit test for function get_exception
def test_get_exception():
    expected_exception = ZeroDivisionError
    try:
        raise expected_exception
    except:
        e = get_exception()
        assert e.__class__ is expected_exception

# Generated at 2022-06-23 02:52:01.976182
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:52:12.983632
# Unit test for function get_exception
def test_get_exception():

    # Verify that an exception with arguments that have a repr
    # that is different from their str will not cause problems
    # when stringifying.
    class StrWithRepr(str):
        def __repr__(self):
            return 'repr: %s' % self

    def cause_exception(x, y):
        raise ValueError('test', '%s: %s' % (x, y))

    try:
        cause_exception(StrWithRepr('hi'), 'bye')
        # This should raise an exception but sometimes the debugger
        # will stop on the error and then you can't get to this line
        # to verify that it failed.
        assert False
    except Exception:
        e = get_exception()

    # Check that stringifying an exception with arguments that have
    # a repr()/str() mismatch doesn't

# Generated at 2022-06-23 02:52:16.514586
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except NameError:
        name_error = get_exception()
    assert name_error.args[0] == 'foo'



# Generated at 2022-06-23 02:52:17.982168
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('some exception')
    except Exception:
        e = get_exception()
    assert e.args == (u'some exception',)

# Generated at 2022-06-23 02:52:19.417751
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError
    except:
        get_exception()

# Generated at 2022-06-23 02:52:22.648544
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        e2 = get_exception()

    assert e2 is e


# unit test for function literal_eval

# Generated at 2022-06-23 02:52:28.007478
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise Exception('a test error')

    try:
        test()
    except Exception:
        e = get_exception()
        if e.args[0] != 'a test error':
            print('Failed to get the correct exception')
            raise

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:52:30.784287
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert exc.args == ('test',)

# Generated at 2022-06-23 02:52:33.969878
# Unit test for function get_exception
def test_get_exception():
    def divide_by_zero():
        return 1 / 0
    try:
        divide_by_zero()
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:52:36.228361
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        ex = get_exception()
        assert ex.args == ('foo',)


# Generated at 2022-06-23 02:52:40.768348
# Unit test for function get_exception
def test_get_exception():
    try:
        int('x')
    except Exception:
        e = get_exception()
        assert e is not None
        assert 'invalid literal' in str(e)


# Generated at 2022-06-23 02:52:46.013617
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'foo' in str(e)

    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'foo' in str(e)

# Generated at 2022-06-23 02:52:49.045485
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise Exception('Testing')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Testing'


# Generated at 2022-06-23 02:52:51.248320
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)
        assert isinstance(e, Exception)


# Generated at 2022-06-23 02:52:56.062291
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        assert e.__class__ == ValueError


# Generated at 2022-06-23 02:53:00.475596
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
    except Exception:
        assert isinstance(get_exception(), ValueError)
    else:
        raise AssertionError('Should have raised exception')


# Generated at 2022-06-23 02:53:04.007049
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('some message')
    except TestException as e:
        assert get_exception() == e
        assert str(get_exception()) == 'some message'

# Generated at 2022-06-23 02:53:06.781490
# Unit test for function get_exception
def test_get_exception():
    try:
        raising_function()
    except:
        exception = get_exception()
        print(exception)



# Generated at 2022-06-23 02:53:13.513719
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception does what we expect."""
    import unittest
    try:
        raise ZeroDivisionError()
    except ZeroDivisionError:
        e = get_exception()

    class TestGetException(unittest.TestCase):
        """Ensure that get_exception returns the correct values.

        get_exception() is used in all of our modules to work with versions
        of python that don't support 'except Exception, e' syntax.  We want
        to ensure that the code we use for that works properly.  This test
        is run with all supported versions of Python.

        """
        def setUp(self):
            self.e = e

        def tearDown(self):
            self.e = None


# Generated at 2022-06-23 02:53:15.918640
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
        assert ex
        assert str(ex) == 'foo'

# Generated at 2022-06-23 02:53:23.254884
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            v = ValueError('test')
            try:
                raise v
            except ValueError:
                e = get_exception()
                self.assertEquals(v, e)
    unittest.main()


# Generated at 2022-06-23 02:53:28.175877
# Unit test for function get_exception
def test_get_exception():
    '''
    Test for function get_exception.
    '''
    try:
        raise Exception("Simulated error")
    except Exception:
        ex = get_exception()
        assert str(ex) == "Simulated error"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:53:33.471950
# Unit test for function get_exception
def test_get_exception():
    ''' Test that get_exception returns the expected exception object '''
    try:
        raise RuntimeError('test exception')
    except RuntimeError as e:
        assert get_exception() == e

    # Test that get_exception does not mask a different exception
    try:
        raise ValueError('another test exception')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:53:38.096107
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('test message')
    except MyException:
        e = get_exception()

    assert isinstance(e, MyException)
    assert e.args == ('test message',)



# Generated at 2022-06-23 02:53:43.212137
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    def raise_exception(e):
        raise e

    class TestException(Exception):
        pass


# Generated at 2022-06-23 02:53:46.521892
# Unit test for function get_exception
def test_get_exception():
    """ansible.module_utils.basic.get_exception - unit tests"""
    class my_exc(Exception):
        pass

    try:
        raise my_exc('foo')
    except Exception:
        x = get_exception()
        assert isinstance(x, my_exc)
        assert x.args == ('foo',)


# Generated at 2022-06-23 02:53:55.971635
# Unit test for function get_exception
def test_get_exception():
    """Test compatibility of get_exception() with older Python versions
    """
    try:
        1/0  # pylint: disable=pointless-statement
    except Exception:
        e = get_exception()

    if e is None:
        raise ValueError("get_exception() should have returned an exception")
    if str(e) != 'integer division or modulo by zero':
        raise ValueError("get_exception() should have returned the current exception,"
                         " instead it returned: %s" % e)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:53:59.017050
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception')
    except ValueError:
        e = get_exception()
    assert e.args == ('testing get_exception',)


# Generated at 2022-06-23 02:54:02.353174
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)

# Generated at 2022-06-23 02:54:08.843713
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("test")
    except RuntimeError as e:
        got_exception = get_exception()
        assert isinstance(got_exception, RuntimeError)
        assert got_exception is e, "except RuntimeError as e; got %r; expected %r" % \
            (got_exception, e)
    try:
        raise RuntimeError("test")
    except:
        got_exception = get_exception()
        assert isinstance(got_exception, RuntimeError)
        assert str(got_exception) == 'test', "except ...; got %r; expected 'test'" % got_exception


# Generated at 2022-06-23 02:54:11.853029
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing exception')
    except ValueError:
        assert get_exception() == 'testing exception'

# Generated at 2022-06-23 02:54:18.776834
# Unit test for function get_exception
def test_get_exception():
    # This is a bit odd, but if it's not odd, then there's a good chance that
    # the code below works even on older python versions where it shouldn't
    raise RuntimeError("testing get_exception")

try:
    get_exception()
except:
    if get_exception() is not get_exception():
        raise AssertionError("get_exception should return the same object every time it's called in an except block")


# Generated at 2022-06-23 02:54:22.967888
# Unit test for function get_exception
def test_get_exception():
    class DummyException(Exception):
        pass
    try:
        raise DummyException("this is a dummy exception")
    except Exception:
        exc = get_exception()
    assert exc.args[0] == "this is a dummy exception"



# Generated at 2022-06-23 02:54:25.445827
# Unit test for function get_exception
def test_get_exception():
    try:
        fred
    except NameError as e:
        exc = get_exception()
    assert e is exc



# Generated at 2022-06-23 02:54:28.124724
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError(1)
    except AssertionError:
        e = get_exception()

    assert e.args == (1, )


# Generated at 2022-06-23 02:54:29.851918
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is only a test')
    except:
        assert isinstance(get_exception(), RuntimeError)

# Generated at 2022-06-23 02:54:32.530488
# Unit test for function get_exception
def test_get_exception():
    "Test that we are able to handle Python exception syntax changes."
    try:
        raise ValueError("Testing")
    except ValueError:
        e = get_exception()
    assert e.args[0] == "Testing"



# Generated at 2022-06-23 02:54:36.941758
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("An exception")
    except ValueError:
        e = get_exception()
        assert e.__class__.__name__ == 'ValueError'
        assert str(e) == "An exception"

# Generated at 2022-06-23 02:54:41.005181
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise ValueError('This is an error')
    ... except Exception:
    ...     e = get_exception()
    ...     print(e)
    This is an error
    """

# Generated at 2022-06-23 02:54:45.117849
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        assert get_exception() == e

    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:54:47.259754
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Fishy')
    except Exception as e:
        assert e == get_exception()



# Generated at 2022-06-23 02:54:50.703332
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        pass

    e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('foo',)



# Generated at 2022-06-23 02:54:54.734300
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise Exception('This is just a test')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert hasattr(e, 'args')
        assert len(e.args) == 1
        assert e.args[0] == 'This is just a test'



# Generated at 2022-06-23 02:54:57.391763
# Unit test for function get_exception
def test_get_exception():
    try:
        int('oops')
    except:
        assert isinstance(get_exception(), ValueError)


# Generated at 2022-06-23 02:55:02.828279
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is an exception')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'This is an exception'


# Generated at 2022-06-23 02:55:08.395379
# Unit test for function get_exception
def test_get_exception():
    # no exception set
    try:
        get_exception()
        assert False, "get_exception() called when no exception is set."

    # exception is set
    except AssertionError:
        e = get_exception()
        assert str(e) == "get_exception() called when no exception is set.", "get_exception() unable to return exception when one is set."

