

# Generated at 2022-06-23 02:45:11.531920
# Unit test for function get_exception
def test_get_exception():
    '''Tests the get_exception function'''
    try:
        1/0
    except ZeroDivisionError:
        exc = get_exception()
    assert isinstance(exc, ZeroDivisionError), 'Did not return the right exception'
    try:
        raise ZeroDivisionError
    except ZeroDivisionError:
        exc = get_exception()
    assert isinstance(exc, ZeroDivisionError), 'Did not return the right exception'
    try:
        1/'1'
    except TypeError:
        exc = get_exception()
    assert isinstance(exc, TypeError), 'Did not return the right exception'
    try:
        raise TypeError
    except TypeError:
        exc = get_exception()
    assert isinstance(exc, TypeError), 'Did not return the right exception'



# Generated at 2022-06-23 02:45:24.796103
# Unit test for function get_exception
def test_get_exception():
    # Test all different possible exception patters
    def _test_get_exception(val):
        try:
            raise val
        except:
            exc = get_exception()
            assert exc is val
            assert type(exc) is type(val)
            assert str(exc) == str(val)

    _test_get_exception(Exception())
    _test_get_exception(RuntimeError())
    _test_get_exception(OSError())
    _test_get_exception(IOError())

    _test_get_exception(Exception('foo'))
    _test_get_exception(RuntimeError('foo'))
    _test_get_exception(OSError('foo'))
    _test_get_exception(IOError('foo'))


# Generated at 2022-06-23 02:45:26.621856
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('blah blah blah')
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:45:30.947309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a message')
    except ValueError as e:
        exception = get_exception()
        assert e.args[0] == exception.args[0]

# Generated at 2022-06-23 02:45:36.341842
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception), 'Expected exception got %s' % repr(e)
    assert e.args == ('test',), 'Expected test exception'


# Generated at 2022-06-23 02:45:38.650783
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        exc = get_exception()
    assert exc.__class__ is ZeroDivisionError
    assert str(exc) == 'integer division or modulo by zero'



# Generated at 2022-06-23 02:45:40.880569
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:49.111335
# Unit test for function get_exception
def test_get_exception():
    import traceback

    def f(x, y):
        try:
            return x + y
        except:  # pylint: disable=bare-except
            return get_exception()

    def g(x, y):
        return x + y

    try:
        r = f(1, "foo")
    except TypeError:
        print('Exception traceback:')
        traceback.print_exc()
    else:
        print('no TypeError')
    try:
        r = g(1, "foo")
        print('no TypeError')
    except TypeError:
        print('Exception traceback:')
        traceback.print_exc()

# Generated at 2022-06-23 02:45:54.238218
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    # The current exception should be an AssertionError
    assert 'AssertionError' in get_exception().__str__()

# Generated at 2022-06-23 02:45:58.491791
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        res = get_exception()
    assert isinstance(res, Exception) and res.args == ("Test exception",)
    # Test that it is the same exception object
    try:
        raise res
    except Exception as e:
        assert e is res

# Generated at 2022-06-23 02:46:00.690825
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:46:08.712962
# Unit test for function get_exception
def test_get_exception():
    class ConcreteException(Exception):
        """Concrete exception raised in the test."""
        pass

    try:
        try:
            raise ConcreteException()
        except Exception as e:
            # The assertion fails if the exception isn't the one that we raised
            assert e.__class__ == ConcreteException
            raise
    except Exception as e:
        # The assertion fails if the exception isn't the one that we raised
        assert e.__class__ == ConcreteException
        e = get_exception()
        assert e.__class__ == ConcreteException

# Generated at 2022-06-23 02:46:11.166322
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("123")
    except ValueError:
        e = get_exception()
    assert e == ValueError("123")


# Generated at 2022-06-23 02:46:17.505500
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
        raise
    assert isinstance(e, ValueError)
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
        try:
            raise IndexError()
        except Exception:
            e2 = get_exception()
        assert isinstance(e, ValueError)
        assert isinstance(e2, IndexError)
        raise
    assert False

# Generated at 2022-06-23 02:46:20.231476
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Error raised")
    except:
        exc = get_exception()
        assert str(exc) == "Error raised"


# Generated at 2022-06-23 02:46:23.589977
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert e.args == ('Test exception',)


# Generated at 2022-06-23 02:46:27.141588
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e == sys.exc_info()[1]

# Generated at 2022-06-23 02:46:31.429417
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test exception'
    # Make sure literal_eval works
    assert literal_eval('{"a":1, "b":2}') == {"a":1, "b":2}

# Generated at 2022-06-23 02:46:35.893993
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'Test exception'



# Generated at 2022-06-23 02:46:47.624443
# Unit test for function get_exception
def test_get_exception():
    """
    Function get_exception() Unit test

    We have to do this test outside of the function because we are testing it
    for use in an except clause.  We need to test both that the function can
    be called and that it gets the exception and not some other value on the
    stack.

    If this test fails then the function cannot be called from an except clause.
    """
    try:
        raise ValueError('This is an exception')  # pylint: disable=undefined-variable
    except:
        assert get_exception().args == ('This is an exception',)



# Generated at 2022-06-23 02:46:51.091165
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        de = get_exception()

    assert de is e


# Generated at 2022-06-23 02:46:53.793184
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            1/0
        except Exception:
            return get_exception()

    assert test().args == (
            'integer division or modulo by zero',)



# Generated at 2022-06-23 02:46:56.327750
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        assert 'Test exception' in str(get_exception()), "get exception is not working as expected"


# Generated at 2022-06-23 02:47:00.325072
# Unit test for function get_exception
def test_get_exception():
    try:
        int("1a")
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)

# Use unit test if module is called directly
if __name__ == '__main__':
    test_get_exception()
    print("SUCCESS getting exception.")

# Generated at 2022-06-23 02:47:02.629099
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError
        except:
            e = get_exception()
        return e

    assert f().__class__ is ValueError



# Generated at 2022-06-23 02:47:09.603981
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test get_exception')
    except RuntimeError as e:
        if get_exception() is not e:
            raise AssertionError("get_exception does not work")

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:47:12.254137
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException
    except:
        exc = get_exception()
    assert isinstance(exc, TestException)

# Generated at 2022-06-23 02:47:14.967311
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:                                             # noqa
        assert str(get_exception()) == 'foo'

# Generated at 2022-06-23 02:47:19.557016
# Unit test for function get_exception
def test_get_exception():
    """Make sure get_exception returns the current exception."""
    try:
        raise ValueError('thrown exception')
    except ValueError:
        e = get_exception()
        assert type(e) is ValueError
        assert str(e) == 'thrown exception'



# Generated at 2022-06-23 02:47:22.236650
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("This is an error")
    except TypeError as e1:
        assert e1 == get_exception()



# Generated at 2022-06-23 02:47:25.277499
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('bar')
    except KeyError as e:
        exc = get_exception()
        assert e == exc
        assert e.args == exc.args



# Generated at 2022-06-23 02:47:28.113542
# Unit test for function get_exception
def test_get_exception():
    # Setup

    # Exercise
    try:
        raise TypeError()
    except TypeError:
        e = get_exception()
    # Verify
    assert isinstance(e, TypeError)



# Generated at 2022-06-23 02:47:34.803892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test")
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == "This is a test"
        assert repr(e) == "ValueError('This is a test',)"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:47:38.947664
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        1/0 # NOQA
    except ZeroDivisionError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:47:42.537676
# Unit test for function get_exception
def test_get_exception():
    """
    >>> test_get_exception()
    """
    try:
        raise ValueError(1)
    except:
        e = get_exception()
        assert type(e) == ValueError
        assert e.args[0] == 1

# Generated at 2022-06-23 02:47:45.600570
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:47:47.449690
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError('foo')
        except Exception:
            e = get_exception()

    f()



# Generated at 2022-06-23 02:47:56.886004
# Unit test for function get_exception

# Generated at 2022-06-23 02:47:59.573765
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test'



# Generated at 2022-06-23 02:48:10.641794
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable

    # Assert that we don't have an exception
    try:
        assert get_exception() is None
    except AssertionError:
        e = get_exception()
        raise AssertionError('get_exception() returns %r instead of None' % e)

    # Assert that we can catch an exception using the function and then reraise
    # it
    try:
        raise ValueError('Some error')
    except ValueError:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise AssertionError('get_exception() returns %s instead of ValueError' % type(e))
        raise

    # Assert that we can catch an exception and the reraise it

# Generated at 2022-06-23 02:48:13.609758
# Unit test for function get_exception
def test_get_exception():
    try:
        int('hello')
    except Exception as e:
        assert get_exception() == e


# Literal eval tests from the python standard library.  Added the last one to
# account for our fix.

# Generated at 2022-06-23 02:48:17.722056
# Unit test for function get_exception
def test_get_exception():
    """
    Check that get_exception works when called directly
    """
    assert get_exception() is None
    try:
        1/0
    except ZeroDivisionError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:48:20.537634
# Unit test for function get_exception
def test_get_exception():
    class Derp(Exception):
        pass

    try:
        raise Derp()
    except:
        assert type(get_exception()) == Derp

# Generated at 2022-06-23 02:48:24.653945
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test get_exception')
    except:
        if str(get_exception()) == 'Test get_exception':
            return True
        else:
            return False


# Generated at 2022-06-23 02:48:27.923371
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-23 02:48:30.836590
# Unit test for function get_exception
def test_get_exception():
    def exception():
        try:
            raise Exception("Test exception")
        except Exception:
            ex = get_exception()
        assert str(ex) == "Test exception"
    exception()

# Generated at 2022-06-23 02:48:34.095343
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == 'test exception'


# Generated at 2022-06-23 02:48:36.705000
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('blew up')
    except Exception:
        e = get_exception()
        assert e.__str__() == 'blew up'

# Generated at 2022-06-23 02:48:38.904782
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception as e:
        exception = get_exception()

    assert exception is e


# Generated at 2022-06-23 02:48:43.416309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert e.args == ('foo',)
    try:
        raise Exception('foo', 'bar')
    except:
        e = get_exception()
    assert e.args == ('foo', 'bar')
    try:
        eval('{')
    except:
        e = get_exception()
    assert isinstance(e, SyntaxError)


# Generated at 2022-06-23 02:48:45.943930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('ponies')
    except ValueError:
        test_exception = get_exception()

    assert isinstance(test_exception, ValueError)
    assert 'ponies' == str(test_exception)

# Test for literal_eval when the compiler module is present and good

# Generated at 2022-06-23 02:48:48.830484
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test exception")
    except Exception:
        e = get_exception()
    assert e.args[0] == "test exception"


# Generated at 2022-06-23 02:48:52.085970
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this should work')
    except:
        exc = get_exception()
        # Ensure we got the right exception
        assert exc.args[0] == 'this should work'



# Generated at 2022-06-23 02:48:56.954950
# Unit test for function get_exception
def test_get_exception():
    def get_func_exception():
        try:
            return 1 / 0
        except Exception:
            return get_exception()

    try:
        get_func_exception()
    except ZeroDivisionError:
        return
    raise Exception('Should have raised a ZeroDivisionError')


# Generated at 2022-06-23 02:49:02.033278
# Unit test for function get_exception
def test_get_exception():
    def try_exception(e):
        try:
            raise e
        except Exception:
            return get_exception()

    assert TryTestClass("answer") == try_exception(TryTestClass("answer"))
    assert TryTestClass("42") == try_exception(TryTestClass("42"))
    assert TryTestClass("6*9") == try_exception(TryTestClass("6*9"))



# Generated at 2022-06-23 02:49:06.703784
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable

    try:
        raise ValueError('A message')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'A message'

# Generated at 2022-06-23 02:49:11.021479
# Unit test for function get_exception
def test_get_exception():
    """Test for the utility function get_exception

    This is not a complete unit test, but it does test that the function is
    doing something reasonable.  It can be invoked via

        python library/python.py

    """
    try:
        raise OSError('foo')
    except OSError:
        e = get_exception()
        print(e.args)

# Generated at 2022-06-23 02:49:21.488520
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception().args == ('foo',)
    try:
        raise Exception('bar', 'baz')
    except:
        assert get_exception().args == ('bar', 'baz')
    try:
        raise Exception('bar', 1, 2.0)
    except:
        assert get_exception().args == ('bar', 1, 2.0)
    try:
        raise Exception(1, 2.0)
    except:
        assert get_exception().args == (1, 2.0)
    try:
        raise Exception()
    except:
        assert get_exception().args == ()


# Generated at 2022-06-23 02:49:23.956336
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:49:33.828920
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:39.348806
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()

    assert e.args == ("Test exception",)
    assert str(e) == "Test exception"


# Generated at 2022-06-23 02:49:43.260948
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()

    assert str(e) == "foo"

import sys
sys.modules[__name__] = __import__(__name__)

# Generated at 2022-06-23 02:49:46.704276
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        assert isinstance(get_exception(), ValueError)


# Generated at 2022-06-23 02:49:49.917613
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'foo'

# Generated at 2022-06-23 02:50:01.171399
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SystemExit("test")
    except SystemExit as e:
        new_e = get_exception()
        if new_e != e:
            raise AssertionError("Retrieved exception is not the same as "
                    "the one that was raised: %r != %r" % (new_e, e))

        if not isinstance(new_e, SystemExit):
            raise AssertionError("Retrieved exception is not of the same "
                    "type as the one that was raised: %r != %r" % (type(new_e),
                        type(e)))

        exit_code = new_e.args[0]

# Generated at 2022-06-23 02:50:08.302917
# Unit test for function get_exception

# Generated at 2022-06-23 02:50:15.943901
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            1/0
        except Exception as e:
            return e
        except:
            pass

    def outer():
        try:
            inner()
        except Exception as e:
            return e

    e = inner()
    if not isinstance(e, ZeroDivisionError):
        raise AssertionError('Failed to get exception')

    e = outer()
    if not isinstance(e, ZeroDivisionError):
        raise AssertionError('Failed to get exception from nested function')

# Generated at 2022-06-23 02:50:24.724547
# Unit test for function get_exception
def test_get_exception():
    def passes():
        pass

    def passes_with_arg(arg):
        pass

    def raises_type_error():
        raise TypeError

    def raises_value_error():
        raise ValueError


# Generated at 2022-06-23 02:50:36.496999
# Unit test for function get_exception
def test_get_exception():
    def _test_get_exception(exception_type):
        try:
            raise exception_type('This is a test exception')
        except:
            assert isinstance(get_exception(), exception_type)

    # This uses the list of builtin exceptions because showing all the exceptions
    # here would make the test take forever to run.
    # pylint: disable=undefined-variable
    exceptions = [getattr(__builtin__, x) for x in dir(__builtin__)
                  if isinstance(getattr(__builtin__, x), type) and issubclass(getattr(__builtin__, x), Exception)]
    # Pylint doesn't know about the builtin exceptions since they're built for each
    # python interpreter
    # pylint: disable=no-member

# Generated at 2022-06-23 02:50:40.293017
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('this is a test')
    except TypeError:
        exc = get_exception()
        assert isinstance(exc, TypeError)
        assert exc.args[0] == 'this is a test'



# Generated at 2022-06-23 02:50:47.121123
# Unit test for function get_exception
def test_get_exception():
   # test that we can get an exception raised in a different thread
    import random
    import threading
    found_exception = None
    def run_func():
        try:
            raise ValueError('xyz')
        except ValueError:
            e = sys.exc_info()[1]
            found_exception.append(e)

    found_exception = []
    t = threading.Thread(target=run_func)
    t.start()
    t.join()
    assert found_exception[0].args[0] == 'xyz'


# Generated at 2022-06-23 02:50:49.364086
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('a test exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'a test exception'

# Generated at 2022-06-23 02:50:55.192478
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError as e:
        if get_exception() is not e:
            raise AssertionError('get_exception: exception did not match')



# Generated at 2022-06-23 02:50:59.820365
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=redefined-outer-name
    try:
        raise ValueError('some value error')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:51:10.549652
# Unit test for function get_exception
def test_get_exception():
    # Basic usage
    try:
        raise Exception('foobar')
    except:
        # pylint: disable=bare-except
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('foobar',)

    # When there is no active exception
    try:
        e = get_exception()
    except Exception as e:
        pass
    assert isinstance(e, RuntimeError)
    assert 'No active exception' in e.args[0]

    # When the builtin is overridden by a module

# Generated at 2022-06-23 02:51:12.739954
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        raise


# Generated at 2022-06-23 02:51:16.796844
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('The Exception')
    except:
        e = get_exception()
        assert unicode(e) == u'The Exception'

# Generated at 2022-06-23 02:51:24.068801
# Unit test for function get_exception
def test_get_exception():
    def method(s):
        try:
            raise Exception(s)
        except Exception:
            e = get_exception()
            return e
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        if e.args != ():
            raise AssertionError()
    msg = 'Unit tests are important'
    e = method(msg)
    if e.args != (msg,):
        raise AssertionError()

# Generated at 2022-06-23 02:51:28.121160
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:34.401553
# Unit test for function get_exception
def test_get_exception():
    # Fail intentionally
    try:
        1/0
    except:
        e = get_exception()
    # Verify that we get the ZeroDivisionError back
    assert(type(e) == ZeroDivisionError)

# Generated at 2022-06-23 02:51:36.514740
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError

# Test for function literal_eval

# Generated at 2022-06-23 02:51:41.781354
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)
    assert isinstance(literal_eval('True'), bool)

# Generated at 2022-06-23 02:51:44.817638
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert type(e) is ZeroDivisionError
    assert 'integer division or modulo by zero' in str(e)

# Generated at 2022-06-23 02:51:50.929672
# Unit test for function get_exception
def test_get_exception():
    def test():
        x = 1
        y = 0
        z = x / y
    try:
        test()
    except Exception as e:
        assert e.args == (u'division by zero',)
    except Exception:
        assert get_exception().args == (u'division by zero',)

# Generated at 2022-06-23 02:51:55.947717
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:51:58.609782
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is a test')
    except RuntimeError:
        return get_exception()

# Generated at 2022-06-23 02:52:03.900321
# Unit test for function get_exception
def test_get_exception():
    def test_func(n):
        try:
            raise ValueError(n)
        except ValueError:
            assert isinstance(get_exception(), ValueError)
            assert get_exception().args == (n,)

    numbers = [0, 1, 2, 3, -1, -2, -3]
    for n in numbers:
        test_func(n)
    for s in ['string', '', 'a', ' ']:
        test_func(s)

# Generated at 2022-06-23 02:52:07.030824
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:52:15.883826
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise ValueError("This is the message")

    try:
        raise_exception()
    except ValueError as e:
        assert literal_eval("{'msg': 'This is the message'}") == e.args
    except Exception:
        assert False, "ValueError not raised"
    else:
        assert False, "ValueError not raised"

    try:
        raise_exception()
    except ValueError:
        e = get_exception()
        assert literal_eval("{'msg': 'This is the message'}") == e.args
    except Exception:
        assert False, "ValueError not raised"
    else:
        assert False, "ValueError not raised"

# Generated at 2022-06-23 02:52:18.356708
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a test')
    except Exception as e:
        assert e is get_exception()



# Generated at 2022-06-23 02:52:22.115752
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("some exception")
    except NameError:
        e = get_exception()
    if e.args[0] != "some exception":
        raise AssertionError('get_exception() returned wrong exception value')

# Generated at 2022-06-23 02:52:25.810394
# Unit test for function get_exception
def test_get_exception():
    """Test whether get_exception() works"""
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'test'


# Generated at 2022-06-23 02:52:28.395677
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        exc = get_exception()
        assert isinstance(exc, ZeroDivisionError)

# Generated at 2022-06-23 02:52:35.414880
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError as e:
        assert e is get_exception()
    try:
        raise ZeroDivisionError('msg')
    except ZeroDivisionError as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:52:40.619546
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('example exception for unit test')
    except RuntimeError as e:
        exc = e
        pass
    assert exc == get_exception()

# Generated at 2022-06-23 02:52:46.804251
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
        assert str(e) == 'integer division or modulo by zero'
        assert repr(e) == 'ZeroDivisionError("integer division or modulo by zero",)'
    else:
        assert False


# Generated at 2022-06-23 02:52:50.065757
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e, 'get_exception() did not return the exception that was raised'

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:52:52.804060
# Unit test for function get_exception
def test_get_exception():
    """Get the current exception."""
    try:
        raise ValueError('Test exception')
    except ValueError:
        exception = get_exception()
    assert exception is not None
    assert isinstance(exception, ValueError)


# Generated at 2022-06-23 02:52:59.968564
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTests(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise ValueError(42)
            except:
                the_exception = get_exception()
            self.assertEqual(str(the_exception), '42')
            self.assertEqual(the_exception.__class__, ValueError)

    unittest.main()



# Generated at 2022-06-23 02:53:04.323755
# Unit test for function get_exception
def test_get_exception():
    try:
        # Should cause an exception
        import foo
    except ImportError:
        e = get_exception()
        assert e is not None
        assert isinstance(e, ImportError)

    # Try without an exception
    assert get_exception() is None



# Generated at 2022-06-23 02:53:07.823880
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except Exception:
        test_exception = get_exception()
    assert test_exception.args == ('This is a test exception',)
    assert 'ValueError: This is a test exception' in str(test_exception)

# Generated at 2022-06-23 02:53:12.347414
# Unit test for function get_exception
def test_get_exception():
    # Need to create a class to test because exceptions must be
    # catchable, and builtin exceptions can be caught.
    class TestException(Exception):
        pass

    try:
        raise TestException('test_get_exception')
    except TestException as e:
        assert e is get_exception()
        try:
            raise
        except TestException as e2:
            assert e is e2

# Generated at 2022-06-23 02:53:17.237644
# Unit test for function get_exception
def test_get_exception():

    def test(fn):
        try:
            fn()
        except:
            e = get_exception()
            assert e is not None
            assert e.args == ('test exception',)

    test(lambda: 1/0)
    test(lambda: [][1])
    test(lambda: {}['key'])
    test(lambda: 's'[1])
    test(lambda: int('foo'))

# Generated at 2022-06-23 02:53:20.456785
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert e is get_exception()



# Generated at 2022-06-23 02:53:24.989650
# Unit test for function get_exception
def test_get_exception():
    '''This raises an exception then catches it and returns it'''
    try:
        raise ValueError('Testing')
    except Exception:
        return get_exception()
assert test_get_exception().args[0] == 'Testing'


# Generated at 2022-06-23 02:53:35.047734
# Unit test for function get_exception
def test_get_exception():
    # Test that we can catch an exception and then catch that exception.
    # If this works then get_exception is doing its job.
    #
    # This test isn't written in a unit test way because then get_exception
    # would not be able to catch it.
    try:
        try:
            raise Exception()
        except Exception:
            e = get_exception()
            if isinstance(e, Exception):
                sys.stderr.write('Unit test for get_exception(): pass\n')
            else:
                sys.stderr.write('Unit test for get_exception(): fail\n')
    except Exception:
        sys.stderr.write('Unit test for get_exception(): fail\n')


# Generated at 2022-06-23 02:53:38.691110
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test exception")
    except RuntimeError:
        exctype, excvalue, tb = sys.exc_info()
        assert get_exception() == excvalue


# Generated at 2022-06-23 02:53:42.003628
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works
    """
    def foo(x):
        raise Exception()

    try:
        foo(5)
    except:
        ex = get_exception()
    assert None is not ex


# Generated at 2022-06-23 02:53:45.014436
# Unit test for function get_exception
def test_get_exception():
    # Test that the return value is the same as sys.exc_info returns
    assert get_exception() is None
    try:
        raise Exception("Test exception")
    except Exception as e:
        assert get_exception() is e
    assert get_exception() is None



# Generated at 2022-06-23 02:53:49.200051
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Unit test exception")
    except ValueError:
        e = get_exception()
    assert type(e) == ValueError
    assert e.args[0] == 'Unit test exception'



# Generated at 2022-06-23 02:53:54.294819
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == 'Test', 'get_exception returns the wrong exception object'


# Generated at 2022-06-23 02:53:58.349461
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except ValueError:
        got_exception = get_exception()
    result = 'testing' in repr(got_exception)
    assert result, 'get_exception() did not return expected output, got: %s' % got_exception

# Generated at 2022-06-23 02:54:00.944486
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test")
    except Exception:
        e = get_exception()

    assert e.args == ("This is a test",)

# Generated at 2022-06-23 02:54:07.151067
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception returns the same thing as sys.exc_info()

    This test is here purely because Python 2.4 and 2.5 chokes on
    try/except/else and doesn't like `except Exception as e:`.
    """
    try:
        int('This is not a number')
        assert False
    except ValueError as e:
        assert get_exception() is e  # pylint: disable=comparison-with-itself
    else:
        assert False

# Generated at 2022-06-23 02:54:08.874812
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert str(e) == 'test'

# Generated at 2022-06-23 02:54:13.883541
# Unit test for function get_exception
def test_get_exception():
    def testfunc():
        try:
            raise ValueError('test')
        except Exception:
            e = get_exception()
            if not e or e.args != ('test',):
                raise Exception('get_exception failed')
    testfunc()



# Generated at 2022-06-23 02:54:17.395080
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
    assert e.args == ('test exception',)



# Generated at 2022-06-23 02:54:21.877631
# Unit test for function get_exception
def test_get_exception():
    try:
        foo = bar
    except Exception:
        e = get_exception()
        assert type(e) == NameError
        assert str(e) == "name 'bar' is not defined"

# Generated at 2022-06-23 02:54:26.162859
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception() function."""

    class MyException(object):
        pass

    try:
        raise MyException()
    except Exception:
        assert get_exception().__class__.__name__ == 'MyException'


# Generated at 2022-06-23 02:54:29.181440
# Unit test for function get_exception
def test_get_exception():
    class SomeException(Exception):
        pass

    try:
        raise SomeException('An error message')
    except SomeException as e:
        pass
    assert e == get_exception()



# Generated at 2022-06-23 02:54:32.086498
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'test'


# Generated at 2022-06-23 02:54:40.763349
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        error_me
    except NameError:
        e = get_exception()
        assert(type(e) == NameError)
        assert(e.args == (u'name \'error_me\' is not defined',))

    try:
        raise TestException('testing')
    except TestException:
        e = get_exception()
        assert(type(e) == TestException)
        assert(e.args == ('testing',))


# Generated at 2022-06-23 02:54:53.093070
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception and the try/except wrapper work correctly"""
    def test_ex(arg1, arg2, arg3=None):
        """Test non-exceptional behavior for the function"""
        return (arg1, arg2, arg3)

    def test_ex2(arg1, arg2, arg3=None):
        """Test exceptional behavior for the function"""
        raise NameError('test_exception')

    try:
        test_ex2(1, 2)
    except Exception: # pylint: disable=broad-except
        e = get_exception()
        eq = test_ex(1, 2)
        assert(str(e) != str(eq))
        assert(len(e.args) == 1 and e.args[0] == 'test_exception')
    else:
        raise Ass

# Generated at 2022-06-23 02:55:00.458216
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A test')
    except ValueError:
        assert repr(get_exception()) == repr(sys.exc_info()[1])


import json
import os

from ansible.module_utils.six import string_types, text_type
from ansible.module_utils.six.moves import shlex_quote

# Taken from python 2.7.10 to ensure backwards compat
_have_unicode = False
if sys.version_info[0] < 3:
    try:
        _have_unicode = bool(type(unicode))  # pylint: disable=undefined-variable
    except NameError:
        pass

_native_value_types = (bool, dict, float, int, list, text_type, type(None))
_native_value_type_map = dict

# Generated at 2022-06-23 02:55:06.337317
# Unit test for function get_exception
def test_get_exception():
    def get_exception_test():
        raise RuntimeError("foo")

    try:
        get_exception_test()
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.message == "foo"
        assert unicode(e) == "foo"