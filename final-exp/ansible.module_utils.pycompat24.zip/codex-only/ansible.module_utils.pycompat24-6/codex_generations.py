

# Generated at 2022-06-23 02:45:07.671607
# Unit test for function get_exception
def test_get_exception():
    """Test to ensure that get_exception returns the proper exception"""

    # Create a fake exception object
    class FakeException(Exception):
        pass

    try:
        raise FakeException()
    except:
        # Get the exception object
        ex = get_exception()

    assert isinstance(ex, FakeException)

# Generated at 2022-06-23 02:45:10.575577
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:14.456512
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:45:22.033541
# Unit test for function get_exception
def test_get_exception():
    import inspect

    def raise_exception():
        try:
            raise Exception('an exception')
        except Exception:
            e = get_exception()
            if inspect.currentframe().f_back.f_locals['e'].args[0] != 'an exception':
                raise Exception('get_exception function fails')

    raise_exception()



# Generated at 2022-06-23 02:45:25.931174
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=undefined-variable
        raise NameError("Kaboom")
    except NameError:
        e = get_exception()
    assert isinstance(e, NameError), e
    assert e.args[0] == "Kaboom", e


# Generated at 2022-06-23 02:45:31.138452
# Unit test for function get_exception
def test_get_exception():
    # Trigger a ValueError and then make sure that it is returned
    try:
        int('a')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:45:35.675993
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException
    except:
        e = get_exception()
    assert isinstance(e, MyException)


# Generated at 2022-06-23 02:45:38.916841
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        assert e.args == ("Test exception",)
        assert str(e) == "Test exception"



# Generated at 2022-06-23 02:45:46.414186
# Unit test for function get_exception
def test_get_exception():
    # Check that we get everything we need to get
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)
    assert str(e) == 'foo'

    # Make sure we don't accidentally do something like 'exception as e'
    # We're testing this because not all python versions support that
    # statement and it will break older versions.  We can't use that
    # statement here because we have to support python <= 2.4
    assert 'as' not in get_exception.__doc__

# Generated at 2022-06-23 02:45:49.935735
# Unit test for function get_exception
def test_get_exception(): # pragma: no cover
    def bar():
        return 1/0

    def foo():
        try:
            bar()
        except:
            e = get_exception()
            print(e)

    foo()



# Generated at 2022-06-23 02:45:51.774298
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('bogus')
    except:
        assert isinstance(get_exception(), ValueError)



# Generated at 2022-06-23 02:45:57.030765
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception("This is a test exception")
    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert(str(e)=="This is a test exception")
        assert(e.__class__.__name__=="Exception")


# Generated at 2022-06-23 02:45:59.436418
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:05.163949
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError("testing 1 2 3")
        except ValueError:
            e = get_exception()
            return e

    f()
    try:
        f()
    except ValueError as e:
        assert str(e) == "testing 1 2 3"


# Generated at 2022-06-23 02:46:08.218104
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:46:10.920001
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        try:
            raise ValueError('foo')
        except ValueError:
            e = get_exception()
            assert e.args[0] == 'foo'
    test_func()

# Generated at 2022-06-23 02:46:14.757476
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'test'



# Generated at 2022-06-23 02:46:18.673857
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('I love to raise exceptions')
    except Exception:
        e = get_exception()

    assert str(e) == 'I love to raise exceptions'


# Generated at 2022-06-23 02:46:22.289682
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo bar')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('foo bar',)
        assert str(e) == 'foo bar'


# Generated at 2022-06-23 02:46:30.486860
# Unit test for function get_exception
def test_get_exception():
    # Test without exception
    try:
        get_exception()
    except:
        assert False, 'get_exception failed to return None when no exception present'

    # Test with simple exception
    try:
        raise Exception
    except Exception:
        if not get_exception():
            assert False, 'get_exception failed to return non-None object when exception present'

    # Test with exception with arguments
    try:
        raise Exception('test message')
    except Exception:
        e = get_exception()
        if not e.args[0] == 'test message':
            assert False, 'get_exception failed to return exception message'


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-23 02:46:35.390400
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("unit test exception")
    except:
        exc = get_exception()
        assert str(exc) == "unit test exception"


# Generated at 2022-06-23 02:46:42.684112
# Unit test for function get_exception
def test_get_exception():
    '''get_exception()'''
    try:
        raise RuntimeError('get_exception test')
    except RuntimeError:
        e = get_exception()
        assert(e.args[0] == 'get_exception test')


# Generated at 2022-06-23 02:46:46.380957
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is an exception")
    except Exception:
        exc = get_exception()
        if str(exc) != "This is an exception":
            raise Exception("Raised exception does not have the expected value")


# Generated at 2022-06-23 02:46:53.922656
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert str(e) == ''
        try:
            raise Exception(1)
        except Exception:
            e = get_exception()
            assert str(e) == '1'
            try:
                raise Exception(1, 2)
            except Exception:
                e = get_exception()
                assert str(e) == '(1, 2)'
                try:
                    raise Exception(1, 2, 3)
                except Exception:
                    e = get_exception()
                    assert str(e) == '(1, 2, 3)'

# Generated at 2022-06-23 02:46:59.476810
# Unit test for function get_exception
def test_get_exception():
    def do_nothing():
        try:
            1/0
        except ZeroDivisionError:
            try:
                return get_exception()
            except NameError:
                return None
    e = do_nothing()
    if isinstance(e, ZeroDivisionError):
        return True
    else:
        raise TypeError('function get_exception returned {} instead of ZeroDivisionError'.format(e))


# Generated at 2022-06-23 02:47:07.565522
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise KeyError(1)
    ... except KeyError:
    ...     e = get_exception()
    >>> e
    1
    """


if __name__ == '__main__':
    import doctest
    import ansible.module_utils.basic
    results = doctest.testmod(ansible.module_utils.basic)
    if results.failed:
        sys.exit(1)

# Generated at 2022-06-23 02:47:10.850671
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception('Something went wrong')

    try:
        f()
    except:
        err = get_exception()
        assert err.args[0] == 'Something went wrong'


# Generated at 2022-06-23 02:47:15.426261
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=too-few-public-methods
    class SomeException(Exception):
        pass

    try:
        raise SomeException()
    except SomeException:
        exception = get_exception()
        assert isinstance(exception, SomeException)



# Generated at 2022-06-23 02:47:20.430806
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foo!')
    except ValueError:
        e = get_exception()
        assert e.args == ('Foo!',)
    # Test that it doesn't get a new exception
    try:
        raise ValueError('Bar!')
    except ValueError:
        assert e.args == ('Foo!',)

# Generated at 2022-06-23 02:47:24.408167
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError as exc1:
        assert get_exception() is exc1

    try:
        raise RuntimeError
    except RuntimeError:
        exc2 = get_exception()

    assert type(exc2) is RuntimeError


# Generated at 2022-06-23 02:47:26.915340
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception as e:
        assert isinstance(e, ValueError)
        assert str(get_exception()) == 'foo'

# Generated at 2022-06-23 02:47:36.717438
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception() function.

    We don't test the name of the exception, just that it returns an
    exception.

    """
    # FIXME: I'd love to use unittest, but that was introduced in Python
    # 2.7 and we need to work on 2.4...
    try:
        raise Exception('Test exception.')
    except Exception:
        e = get_exception()
        assert 'Exception' == e.__class__.__name__
        assert 'Test exception.' == str(e)


# Generated at 2022-06-23 02:47:40.163675
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception')
    except ValueError:
        exc = get_exception()

    assert str(exc) == 'testing get_exception'

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:47:50.335187
# Unit test for function get_exception
def test_get_exception():
    # Unit tests for function get_exception.
    #
    # Trying to be a good citizen in the code, but that causes problems if we
    # try to write sane unit tests against it.  This function is meant to be
    # used inside an exception handling block, but it is hard to trigger
    # exceptions while still having unit tests pass.

    # pylint: disable=unused-variable,invalid-name


    # First check that we get the right thing out if we're in an exception
    try:
        raise ValueError('test_get_exception')
    except Exception:
        ex = get_exception()
        assert isinstance(ex, ValueError)
        assert ex.message == 'test_get_exception'

    # and now check that we can call it without an exception
    ex = get_exception()

# Generated at 2022-06-23 02:47:59.733690
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError as e:
        e2 = get_exception()
        assert e == e2



# Generated at 2022-06-23 02:48:03.446121
# Unit test for function get_exception
def test_get_exception():
    '''
    Test get_exception function
    '''
    try:
        raise Exception('Test exception')
    except:
        e = get_exception()

    assert isinstance(e, Exception)


# Generated at 2022-06-23 02:48:08.014083
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Message')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'Message'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 02:48:09.936508
# Unit test for function get_exception

# Generated at 2022-06-23 02:48:12.494959
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise ValueError('exception message')
        except:
            return get_exception()

    assert inner().args[0] == 'exception message'

# Generated at 2022-06-23 02:48:16.445119
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:48:18.887283
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError:
        e = get_exception()
    assert str(e) == "foo"


# Generated at 2022-06-23 02:48:24.309108
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            bar = 42
            bar/0
        except ZeroDivisionError:
            return get_exception()

    assert isinstance(foo(), ZeroDivisionError)
    assert foo().args == ('integer division or modulo by zero',)


# Generated at 2022-06-23 02:48:30.154694
# Unit test for function get_exception
def test_get_exception():
    # Just verify that this function doesn't error out.  If it does, the traceback's
    # output will indicate a failure even though the test would pass.  We could
    # improve this function to test for certain exception classes.
    try:
        raise Exception("Foo!")
    except:
        get_exception()

# Generated at 2022-06-23 02:48:33.450649
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foobar')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:48:36.008145
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'foo'

# Generated at 2022-06-23 02:48:38.607450
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException
    except Exception:
        e = get_exception()
    assert isinstance(e, MyException)



# Generated at 2022-06-23 02:48:40.298033
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('This is a KeyError')
    except:
        assert isinstance(get_exception(), KeyError)

# Generated at 2022-06-23 02:48:45.691354
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError()
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)



# Generated at 2022-06-23 02:48:55.676874
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert e.args == ('test',)
    assert str(e) == 'test'
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
    assert e.args == ()
    assert str(e) == ''
    try:
        raise ValueError('one', 'two', 'three')
    except ValueError:
        e = get_exception()
    assert e.args == ('one', 'two', 'three')
    assert str(e) == "('one', 'two', 'three')"



# Generated at 2022-06-23 02:48:58.331136
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        e = get_exception()
        assert e.__class__ is TestException

# Generated at 2022-06-23 02:49:01.152009
# Unit test for function get_exception
def test_get_exception():
    try:
        # pep-8: don't raise exception in a function which doesn't have a name
        raise Exception("Foo")
    except:
        assert get_exception().args[0] == "Foo"

# Generated at 2022-06-23 02:49:06.759625
# Unit test for function get_exception
def test_get_exception():
    # python 2.4 doesn't have the with statement.  So fake it
    def raises_err(*args):
        try:
            raise ValueError('foo')
        except Exception:
            e = get_exception()
            if e.args != args:
                raise AssertionError('Expected exception did not match what was raised. Expected %s, got %s' % (e.args, args))

    raises_err('foo')



# Generated at 2022-06-23 02:49:13.016578
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except Exception:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise AssertionError("get_exception returned {}, should have returned ValueError".format(e))


# Generated at 2022-06-23 02:49:22.637104
# Unit test for function get_exception
def test_get_exception():
    # Python 2.4 cannot raise an exception using raise Exception("msg")
    # We must raise an exception using raise Exception, "msg"
    # Therefore, we can't use try/except/raise for unit testing get_exception
    try:
        raise "Test message for get_exception"
    except Exception:
        exc = get_exception()
        assert exc == "Test message for get_exception" or exc.args == ("Test message for get_exception",)

    # This isn't actually necessary, it's just a hint to the pyflakes linter
    assert {'exc': exc, 'get_exception': get_exception}

# Generated at 2022-06-23 02:49:29.440236
# Unit test for function get_exception
def test_get_exception():
    class E(Exception):
        pass

    try:
        raise E('a')
    except:
        e = get_exception()
        assert e.__class__ is E
        assert str(e) == 'a'

# Generated at 2022-06-23 02:49:31.764137
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Kaboom')
    except Exception as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:49:34.752951
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("oops")
    except RuntimeError as e:
        if get_exception() != e:
            raise AssertionError("get_exception didn't return the exception being handled!")

# Generated at 2022-06-23 02:49:40.349371
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils import basic

    try:
        raise ValueError("Unit test exception")
    except:
        e = get_exception()
    basic.assert_equal(e.args[0], "Unit test exception")

# Generated at 2022-06-23 02:49:44.160484
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SyntaxError('You done goofed')
    except SyntaxError:
        e = get_exception()
    assert isinstance(e, SyntaxError)
    assert str(e) == 'You done goofed'



# Generated at 2022-06-23 02:49:47.201966
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'Test'


# Generated at 2022-06-23 02:49:49.818632
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
        assert exc.args == ('foo',)
        assert str(exc) == 'foo'

# Generated at 2022-06-23 02:49:51.708667
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing get_exception')
    except Exception:
        e = get_exception()

    assert str(e) == 'Testing get_exception'

# Generated at 2022-06-23 02:49:55.008106
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Example Exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'Example Exception'

# Generated at 2022-06-23 02:49:57.223528
# Unit test for function get_exception
def test_get_exception():
    class ExcTest(Exception):
        pass

    try:
        raise ExcTest('test message')
    except ExcTest:
        e = get_exception()
    assert str(e) == 'test message'


# Generated at 2022-06-23 02:50:03.263045
# Unit test for function get_exception
def test_get_exception():
    '''Unit test for function get_exception'''
    try:
        raise RuntimeError("test")
    except RuntimeError:
        exc = get_exception()
        assert exc.__class__ == RuntimeError
        assert str(exc) == "test"
        assert repr(exc) == "test"



# Generated at 2022-06-23 02:50:08.263281
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    class ExceptionA(Exception):
        pass
    class ExceptionB(ExceptionA):
        pass

    def raise_exception(exception):
        """Helper for raising an exception in the context of get_exception"""
        try:
            raise exception()
        except ExceptionA:
            return get_exception()

    assert isinstance(raise_exception(ExceptionA), ExceptionA)

# Generated at 2022-06-23 02:50:12.290887
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        e = get_exception()
        # In python 3, exception get reraised. Reset it so we can continue.
        sys.exc_clear()
    assert isinstance(e, Exception)

# Generated at 2022-06-23 02:50:14.775235
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foo')
    except ValueError:
        assert(get_exception() == ValueError('Foo'))

# Generated at 2022-06-23 02:50:18.693093
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        def __init__(self):
            Exception.__init__(self, 'test')
    try:
        raise MyException()
    except Exception:
        assert str(get_exception()) == 'test'


# Generated at 2022-06-23 02:50:25.374928
# Unit test for function get_exception
def test_get_exception():
    # This fails under 2.4
    try:
        get_exception()
    except NameError:
        pass
    except Exception as e:
        assert False, 'get_exception failed when it should not have {0}'.format(str(e))

    try:
        1/0
    except Exception as e:
        e2 = get_exception()
        assert isinstance(e2, type(e))

# Generated at 2022-06-23 02:50:29.328540
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:50:32.606946
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError('test')
    except ZeroDivisionError:
        e = get_exception()

    assert e.args[0] == 'test'


# Generated at 2022-06-23 02:50:41.912361
# Unit test for function get_exception
def test_get_exception():
    # Make sure that when an exception is thrown it is the correct one.
    # In python3.3+ there are explicit tests in the stdlib.  In 2.x,
    # we'll just do some basic smoke tests
    try:
        1 / 0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert 'foo' in str(e)
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:50:45.177725
# Unit test for function get_exception
def test_get_exception():
    import pytest
    def raise_exception():
        raise Exception()

    with pytest.raises(Exception):
        raise_exception()
    e = get_exception()
    assert isinstance(e, Exception)



# Generated at 2022-06-23 02:50:48.905219
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError('Hi')
        except:
            return get_exception()
    assert f().args[0] == 'Hi'



# Generated at 2022-06-23 02:50:52.729992
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise ValueError('some message')
        except ValueError:
            e = get_exception()
            assert e.args[0] == 'some message'

    test()


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:50:55.556908
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('xyzzy')
    except Exception:
        e = get_exception()
    assert str(e) == 'xyzzy'

# Generated at 2022-06-23 02:51:01.005094
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()
    assert isinstance(e, ValueError)

    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:51:10.554267
# Unit test for function get_exception
def test_get_exception():
    # I don't know how to test that this works with python 2.4-2.6
    # In Python 2.4-2.6, there's only sys.exc_info()[0], which is the type
    # of the exception.  We always return sys.exc_info()[1]

    # I also don't know how to test that this works with python 3.x
    # In Python 3.x, sys.exc_info()[0] is the type of the exception and
    # sys.exc_info()[1] is None.  The value of the exception is
    # sys.exc_info()[2].

    try:
        raise Exception('test_get_exception')
    except:
        try:
            raise
        except:
            e = get_exception()

# Generated at 2022-06-23 02:51:16.954626
# Unit test for function get_exception
def test_get_exception():
    class ExceptionStub(Exception):
       pass

    def f():
        raise ExceptionStub('test error')

    try:
        f()
    except:
        exception = get_exception()
        # The value of exception should be of the type of the exception we raised
        assert isinstance(exception, ExceptionStub)
        assert str(exception) == 'test error'

# Generated at 2022-06-23 02:51:21.302255
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Exception to get')
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args == ('Exception to get',)


# Generated at 2022-06-23 02:51:24.999555
# Unit test for function get_exception
def test_get_exception():
    class Exception1(Exception):
        pass
    class Exception2(Exception1):
        pass
    try:
        raise Exception2("Test")
    except Exception:
        e = get_exception()
    assert type(e) == Exception2
    assert str(e) == "Test"

# Generated at 2022-06-23 02:51:29.626323
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Get exception looks like it works')
    except:
        exception = get_exception()
        assert isinstance(exception, ValueError)
        assert str(exception) == 'Get exception looks like it works'



# Generated at 2022-06-23 02:51:35.223239
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'test exception'


# Generated at 2022-06-23 02:51:43.893587
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:47.481520
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
        assert isinstance(e, TypeError)


# Generated at 2022-06-23 02:51:50.049981
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except:
        test_exception = get_exception()
        assert test_exception.args[0] == 'foo'
        assert isinstance(test_exception, TypeError)

# Generated at 2022-06-23 02:51:52.489567
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:55.900806
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test")
    except Exception:
        exception_obj = get_exception()
    assert("This is a test" == str(exception_obj))


# Generated at 2022-06-23 02:52:05.206209
# Unit test for function get_exception
def test_get_exception():
    """
    A unit test for function get_exception that does nothing but assert that the
    function gets the error message correctly.  We do not test for all possible
    Python versions atm.  Instead, we assume that if it works on modern Python 2
    and Python 3 that it'll work in the versions that ansible support.
    """
    try:
        raise Exception('Kilroy was here.')
    except:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert str(exc) == 'Kilroy was here.'


# Generated at 2022-06-23 02:52:10.622336
# Unit test for function get_exception
def test_get_exception():

    try:
        raise ValueError('Just a test')
    except:
        e = get_exception()
        assert str(e) == 'Just a test'


# Generated at 2022-06-23 02:52:14.748114
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    try:
        1/0
    except ZeroDivisionError:
        error = get_exception()
    assert isinstance(error, ZeroDivisionError)



# Generated at 2022-06-23 02:52:19.426420
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
        if exc.args[0] != 'foo':
            raise AssertionError('get_exception() did not return exception')
    else:
        raise AssertionError('get_exception() did not raise exception')

# Generated at 2022-06-23 02:52:25.519763
# Unit test for function get_exception
def test_get_exception():
    """Unit tests for function get_exception"""
    try:
        raise Exception("Test exception")
    except Exception:
        exc = get_exception()
        assert exc.args == ("Test exception",)


# Test literal_eval

# Generated at 2022-06-23 02:52:28.931366
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        e = get_exception()

    assert isinstance(e, TypeError)
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:52:31.769640
# Unit test for function get_exception
def test_get_exception():
    def testfunc(a,b):
        return a/b
    try:
        testfunc(1,0)
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:52:43.266643
# Unit test for function get_exception
def test_get_exception():

    # Note: Newer versions of pytest will warn about an unused fixture named 'e'. That
    # is correct, that variable is only used for the assersion.

    # Test get_exception returns the exception we raise
    try:
        raise ValueError("A test exception")
    except Exception as e:
        raised = get_exception()
        assert raised == e, "get_exception returned wrong exception"

    # Make sure we didn't clobber the exception
    assert e is not get_exception(), "get_exception clobbered exception"

    # Test that get_exception raised AttributeError if no exception is raised
    try:
        get_exception()
        assert False, "get_exception succeeded when it should have thrown"
    except AttributeError:
        pass

# Generated at 2022-06-23 02:52:45.841120
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        assert str(e) == "Test exception"

# Generated at 2022-06-23 02:52:48.112048
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:52:50.154073
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo bar')
    except Exception as e:
        assert e == get_exception()


# Generated at 2022-06-23 02:52:54.192918
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()
        assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:53:01.127242
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Some error')
    except Exception:  # pylint: disable=broad-except
        try:
            raise TypeError('Some other error')
        except Exception:  # pylint: disable=broad-except
            e = get_exception()
            assert isinstance(e, TypeError)
            assert str(e) == 'Some other error'
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'Some error'

# Generated at 2022-06-23 02:53:03.682702
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert 'Test exception' in str(e)
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:53:11.261467
# Unit test for function get_exception
def test_get_exception():
    errmsg = 'This is a test exception'

    try:
        raise Exception(errmsg)
    except:
        e = get_exception()

    assert type(e) == Exception
    assert e.__str__() == errmsg
    assert e.args[0] == errmsg

    try:
        eval('{')
    except:
        e = get_exception()

    assert type(e) == SyntaxError


# Generated at 2022-06-23 02:53:15.492571
# Unit test for function get_exception
def test_get_exception():
    " This will test our get_exception funtion "
    try:
        raise NameError("Test Exception")
    except:
        error = get_exception()
    if not isinstance(error, NameError):
        raise AssertionError("Unexpected error type %r" % type(error))



# Generated at 2022-06-23 02:53:20.396432
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise ValueError('something')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:53:26.814415
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTester(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise RuntimeError('foo')
            except RuntimeError:
                self.assertEqual(get_exception().args, ('foo',))

    test = GetExceptionTester()
    test.test_get_exception()

# Generated at 2022-06-23 02:53:32.479452
# Unit test for function get_exception
def test_get_exception():
    try:
        # raise a ValueError to get a traceback
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()

    # look at the exception and traceback to ensure that it's what
    # we want
    assert 'foo' in str(exc)
    assert exc.__traceback__
    assert 'raise ValueError' in str(exc.__traceback__)

# Generated at 2022-06-23 02:53:34.741924
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert type(e) == ValueError



# Generated at 2022-06-23 02:53:38.151440
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert str(exc) == 'test exception'


# Generated at 2022-06-23 02:53:40.673026
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("example error")
    except RuntimeError as e:
        e_mod = get_exception()
    assert e == e_mod

# Generated at 2022-06-23 02:53:42.819521
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            return get_exception()
        except:
            return get_exception()

    assert isinstance(f(), ValueError)



# Generated at 2022-06-23 02:53:44.545206
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)



# Generated at 2022-06-23 02:53:47.055897
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        pass
    assert e == get_exception()


# Generated at 2022-06-23 02:53:50.030553
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        the_exception = get_exception()
    assert the_exception.args == ('foo',)



# Generated at 2022-06-23 02:53:56.234937
# Unit test for function get_exception

# Generated at 2022-06-23 02:53:58.400044
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        assert get_exception() is not None


# Generated at 2022-06-23 02:54:01.984335
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('x')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'x'

# Generated at 2022-06-23 02:54:05.349436
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception()

    try:
        raise_exception()
    except Exception:
        assert True is get_exception()

    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert Exception() is e


# Generated at 2022-06-23 02:54:12.393140
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Just testing")
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.args == ("Just testing",)
        assert e.message == "Just testing"  # pylint: disable=no-member
        assert str(e) == "Just testing"
    else:
        raise AssertionError("Did not trigger exception")


# Generated at 2022-06-23 02:54:15.829084
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Spam')
    except ValueError:
        assert get_exception().args[0] == 'Spam'



# Generated at 2022-06-23 02:54:19.740062
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is a test')
    except ValueError as e:
        assert get_exception() is e
        assert get_exception() == e
        assert get_exception().args == ('this is a test',)



# Generated at 2022-06-23 02:54:23.934846
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            1 / 0
        except Exception:
            return get_exception()

    try:
        1 / 0
    except:
        assert get_exception()

    assert f() is not None


# Generated at 2022-06-23 02:54:28.367316
# Unit test for function get_exception
def test_get_exception():
    # There's no point in testing that this function can get
    # exceptions.  We only need to test it when we're getting mixed
    # versions of python.
    try:
        raise NameError
    except Exception:
        e = get_exception()
        assert isinstance(e, NameError)



# Generated at 2022-06-23 02:54:31.331313
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception('foo')
    try:
        f()
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)



# Generated at 2022-06-23 02:54:39.064603
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return repr(self.value)

    try:
        raise MyException('test exception')
    except MyException:
        e = get_exception()
    assert repr(e) == repr('test exception')


if __name__ == '__main__':
    import pytest

    pytest.main(['-vvs'])

# Generated at 2022-06-23 02:54:43.170497
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('simulated error')
    except RuntimeError as e:
        assert get_exception() is e
        assert get_exception().args == ('simulated error',)

# Generated at 2022-06-23 02:54:46.615521
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("I'm a banana!")
    except NameError:
        e = get_exception()
        assert e.args[0] == "I'm a banana!"
    return e

import unittest


# Generated at 2022-06-23 02:54:49.643318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except RuntimeError:
        e = get_exception()
        assert e.message == "This is a test"



# Generated at 2022-06-23 02:54:55.022603
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('ignored')
    except Exception:
        e = get_exception()
    assert e.args == ('ignored',)



# Generated at 2022-06-23 02:54:59.495335
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception('foo')

    try:
        raise_exception()
    except:
        e = get_exception()
    assert e.args == ('foo',)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:55:02.142456
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError
    except:
        assert get_exception().__class__ == KeyError

# Generated at 2022-06-23 02:55:06.532066
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
    else:
        assert False, 'should not have reached here'
