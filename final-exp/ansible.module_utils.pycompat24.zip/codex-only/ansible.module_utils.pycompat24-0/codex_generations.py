

# Generated at 2022-06-23 02:45:07.131462
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is an exception")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "This is an exception"


# Generated at 2022-06-23 02:45:09.944222
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this should be caught')
    except Exception:
        e = get_exception()
        assert e.args == ('this should be caught',)
        assert str(e)  == 'this should be caught'

# Generated at 2022-06-23 02:45:14.668830
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('some error')
    except RuntimeError as e:
        e2 = get_exception()
    assert e is e2


# Generated at 2022-06-23 02:45:24.489307
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import sys

    class GetExceptionTest(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise RuntimeError('foo')
            except RuntimeError:
                exc = get_exception()
            self.assertEquals(str(exc), 'foo')

    suite = unittest.TestLoader().loadTestsFromTestCase(GetExceptionTest)
    unittest.TextTestRunner(verbosity=3).run(suite)


# Generated at 2022-06-23 02:45:26.531393
# Unit test for function get_exception
def test_get_exception():
    #pylint: disable=invalid-name
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:45:32.683307
# Unit test for function get_exception
def test_get_exception():
    def raise_something():
        raise ValueError('something')

    try:
        raise_something()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)

    try:
        raise_something()
    except ValueError:
        e = sys.exc_info()[1]
    assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:45:36.185259
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Fake error')
    except TypeError:
        e = get_exception()

    assert e.args == ('Fake error',)



# Generated at 2022-06-23 02:45:39.017699
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:42.923325
# Unit test for function get_exception
def test_get_exception():
    """Return a test function for get_exception"""
    try:
        raise ValueError("Test exception")
    except ValueError:
        exc = get_exception()
        assert exc.args == ("Test exception",), "get_exception does not return the correct exception"



# Generated at 2022-06-23 02:45:45.140518
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test 42')
    except:
        assert get_exception() == Exception('test 42')



# Generated at 2022-06-23 02:45:50.489232
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)

        # Get the exception again, make sure it is the same
        e2 = get_exception()
        assert isinstance(e2, ValueError)
        assert id(e) == id(e2)
    # Make sure that outside an except block the last exception is None
    assert get_exception() is None



# Generated at 2022-06-23 02:45:55.865786
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise IndexError("This is an exception")
    try:
        raise_exception()
    except:
        exc = get_exception()
    assert isinstance(exc, IndexError)
    assert exc.args == (u'This is an exception',)

# Generated at 2022-06-23 02:46:02.337223
# Unit test for function get_exception
def test_get_exception():
    # This test needs to be run with python -O so that we don't get the
    # Exception ignored: ...
    # message.  Otherwise, we'll have to find a way to silence that message
    # as well.
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo'


if __name__ == '__main__':
    import pytest
    pytest.main(sys.argv[1:])

# Generated at 2022-06-23 02:46:04.603506
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exception = get_exception()
    assert exception.args == ('foo',)

# Generated at 2022-06-23 02:46:07.276600
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError:
        e = get_exception()

    assert str(e) == "foo"



# Generated at 2022-06-23 02:46:11.648875
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        tb_str = repr(get_exception())
        tb_str_lines = tb_str.splitlines()
        assert tb_str_lines[0].startswith("ZeroDivisionError('integer division or modulo by zero',")


# Generated at 2022-06-23 02:46:14.323810
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An error has occurred')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'An error has occurred'
    else:
        assert False, 'An exception was not raised'

# Generated at 2022-06-23 02:46:17.542381
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert e.args == ('test',)
    try:
        raise ValueError(1,2,3)
    except:
        e = get_exception()
    assert e.args == (1,2,3)

# Generated at 2022-06-23 02:46:19.460044
# Unit test for function get_exception
def test_get_exception():
    # Will succeed
    try:
        raise Exception
    except Exception:
        assert(get_exception() is not None)

# Generated at 2022-06-23 02:46:22.456065
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("testing")
    except:
        e = get_exception()
        assert "testing" in str(e)



# Generated at 2022-06-23 02:46:26.172542
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Five is right out')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'Five is right out'


# Generated at 2022-06-23 02:46:29.048362
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("erroooor")
    except Exception:
        e = get_exception()
        assert e.message == "erroooor"

# Generated at 2022-06-23 02:46:34.530814
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing!')
    except:
        e = get_exception()
    assert str(e) == 'Testing!'

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-23 02:46:39.046028
# Unit test for function get_exception
def test_get_exception():
    # use try: except: finally: to make sure that the line number info is correct
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == 'foo'
        try:
            raise ValueError('bar')
        except:
            assert get_exception() is not e
    finally:
        pass

# Generated at 2022-06-23 02:46:44.172888
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:49.362329
# Unit test for function get_exception
def test_get_exception():
    e = get_exception()
    if e is None:
        raise Exception('Unexpected None')
    if not isinstance(e, ValueError):
        raise Exception('Unexpected type: %s' % type(e))
    if not str(e) == "test message":
        raise Exception('Unexpected message: %s' % str(e))


# Generated at 2022-06-23 02:46:53.053821
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Fake Exception')
    except:
        assert get_exception().args[0] == 'Fake Exception'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:46:54.929228
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("this is an exception")
    except Exception as e:
        assert(get_exception() is e)

# Generated at 2022-06-23 02:47:00.467370
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'test exception'
    # Test with failure to get exception
    try:
        raise Exception('test exception')
    except Exception:
        try:
            raise AssertionError('Another exception')
        except AssertionError:
            e = get_exception()
    assert str(e) == 'test exception'

# Generated at 2022-06-23 02:47:04.349868
# Unit test for function get_exception
def test_get_exception():
    '''Ensure that get_exception works correctly'''
    class MyException(Exception):
        pass

    try:
        raise MyException('Some exception')
    except Exception:
        result = get_exception()

    assert isinstance(result, MyException)
    assert str(result) == 'Some exception'



# Generated at 2022-06-23 02:47:09.402712
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'



# Generated at 2022-06-23 02:47:12.873892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('exception in try block')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
    assert e.args == ('exception in try block',)



# Generated at 2022-06-23 02:47:16.673345
# Unit test for function get_exception
def test_get_exception():
    "This tests that get_exception returns the right exception"
    class TestException(Exception):
        pass
    try:
        raise TestException()
    except Exception:
        exc = get_exception()
        assert isinstance(exc, TestException), "Did not get the right exception"


# Generated at 2022-06-23 02:47:21.228464
# Unit test for function get_exception
def test_get_exception():
    # Can we actually get an exception
    try:
        raise TypeError("This is just a test.")
    except TypeError:
        e = get_exception()
        assert(str(e) == "This is just a test.")
    else:
        raise AssertionError("Did not get the exception")

# Generated at 2022-06-23 02:47:23.598919
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:47:25.732319
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception')
    except ValueError:
        assert get_exception()


# Generated at 2022-06-23 02:47:29.710542
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "invalid literal for int() with base 10: 'a'"

# Generated at 2022-06-23 02:47:34.077337
# Unit test for function get_exception
def test_get_exception():
    exceptionMessage = 'real test exception message'
    try:
        raise RuntimeError(exceptionMessage)
    except RuntimeError:
        exception = get_exception()
    assert exception.args[0] == exceptionMessage



# Generated at 2022-06-23 02:47:39.030413
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        # This is the code we're trying to test so all we need to do is make
        # sure it doesn't raise an exception.
        e = get_exception()
        assert (e.args == ("foo", ))

# Generated at 2022-06-23 02:47:43.053653
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except NameError:
        pass
    exc_info = get_exception()
    assert 'NameError' == exc_info.__class__.__name__
    assert "'foo'" == str(exc_info)

# Generated at 2022-06-23 02:47:45.704237
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
    assert str(exc) == "foo"


# Generated at 2022-06-23 02:47:50.952610
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        e2 = get_exception()
    assert e == e2
    assert str(e) == str(e2)

# Generated at 2022-06-23 02:47:53.610144
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 + 'hello'
    except:
        ex = get_exception()
    assert str(ex) == "invalid literal for int() with base 10: 'hello'"



# Generated at 2022-06-23 02:47:56.277739
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> try:
    ...     raise Exception('foo')
    ... except:
    ...     get_exception().message
    'foo'
    '''

# Generated at 2022-06-23 02:47:58.533976
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:48:03.075466
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert get_exception() == e
    try:
        raise ValueError()
    except:
        assert get_exception() is not None


# Generated at 2022-06-23 02:48:08.068739
# Unit test for function get_exception
def test_get_exception():
    try:
        def foo(a):
            """Return the given argument.

            :arg a: The argument to return.
            :returns: The argument.
            """
            return a
        foo()
    except:
        e = get_exception()
        assert isinstance(e, TypeError), "get_exception returned the wrong type of exception"

# Generated at 2022-06-23 02:48:13.829304
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() gives the current exception."""
    import random, string
    import nose.tools
    try:
        # raise a random kind of error
        random.choice([1, 'hello', [1, 2]])[3]
    except:
        nose.tools.ok_(get_exception() is sys.exc_info()[1])
        return
    # We should never get here, cause an assertion error if we do
    assert False

# Generated at 2022-06-23 02:48:15.461007
# Unit test for function get_exception
def test_get_exception():
   raise Exception(u'💩')

# Generated at 2022-06-23 02:48:21.465744
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == 'foo'
    else:
        assert False, 'should have raised a RuntimeError'
    try:
        raise RuntimeError('foo', 'bar', 'baz')
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == 'foo'
        assert e.args[1] == 'bar'
        assert e.args[2] == 'baz'
    else:
        assert False, 'should have raised a RuntimeError'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:48:25.741182
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1/0
        assert False, 'ZeroDivisionError not raised'
    except ZeroDivisionError:
        e = get_exception()
        print(e)
        assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:48:31.832470
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:48:35.208527
# Unit test for function get_exception
def test_get_exception():
    '''get_exception should return the Exception'''
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'



# Generated at 2022-06-23 02:48:37.415569
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        exception = get_exception()
    assert isinstance(exception, RuntimeError)

# Generated at 2022-06-23 02:48:39.954792
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is a test')
    except Exception:
        e = get_exception()
        assert e.args == ('this is a test', )


# Generated at 2022-06-23 02:48:45.690481
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:48:48.939318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()

    assert isinstance(e, Exception)
    assert str(e) == 'foo'



# Generated at 2022-06-23 02:48:51.439219
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:48:54.011406
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
    assert e is not None



# Generated at 2022-06-23 02:48:56.384702
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing get_exception')
    except Exception:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-23 02:48:58.846009
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-23 02:49:02.190516
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Foo!')
    except RuntimeError as e:
        e2 = get_exception()
        assert e is e2

# Generated at 2022-06-23 02:49:05.141642
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert str(e) == 'integer division or modulo by zero'


# Generated at 2022-06-23 02:49:09.699220
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('message')
    except Exception:
        e = get_exception()
        assert str(e) == 'message', "get_exception() returned an unexpected exception"
    try:
        raise Exception(('message',))
    except Exception:
        e = get_exception()
        assert str(e) == '(\'message\',)', "get_exception() returned an unexpected exception"

# Generated at 2022-06-23 02:49:12.709412
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:17.106786
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('some exception')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'some exception'

# Generated at 2022-06-23 02:49:21.380757
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test")
    except RuntimeError:
        e = get_exception()
        if str(e) != "Test":
            print("Unexpected exception: %s" % str(e))
            sys.exit(1)


# Generated at 2022-06-23 02:49:23.549849
# Unit test for function get_exception
def test_get_exception():
    try:
        raise StandardError('foo')
    except StandardError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:49:32.969538
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import ansible.module_utils.basic

    class TestGetException(unittest.TestCase):

        def _test_get_exception(self, obj):
            """Unit test for function get_exception

            :arg object,str obj: Argument to the function.  If it is an instance of
                Exception then the appropriate Exception will be raised.  Otherwise,
                the value will be used to construct the message for a ValueError to
                be raised.
            """
            try:
                if isinstance(obj, Exception):
                    raise obj
                else:
                    raise ValueError(obj)
            except Exception:
                e = ansible.module_utils.basic.get_exception()
                if not isinstance(e, ValueError):
                    self.fail("get_exception should return a ValueError")
                self

# Generated at 2022-06-23 02:49:36.922431
# Unit test for function get_exception
def test_get_exception():

    try:
        raise Exception('random exception')
    except:
        ex = get_exception()
        assert(repr(ex) == "'random exception'")


# Generated at 2022-06-23 02:49:42.921034
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('abc')
    except ValueError:
        e = get_exception()
    assert 'abc' in str(e)

# Generated at 2022-06-23 02:49:44.725896
# Unit test for function get_exception
def test_get_exception():
    assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-23 02:49:49.133415
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        exc = get_exception()
    assert exc.args[0] == 'test', 'get_exception did not get the exception'
    assert isinstance(exc, ValueError)

# Generated at 2022-06-23 02:49:53.272276
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('foo',)


# Generated at 2022-06-23 02:49:55.882790
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Just a test exception')
    except RuntimeError:
        e = get_exception()
        assert(isinstance(e, RuntimeError))

# Generated at 2022-06-23 02:49:59.552922
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test error")
    except ValueError:
        e = get_exception()

    assert str(e) == "test error"

# Generated at 2022-06-23 02:50:03.897099
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        err = e
    assert get_exception() == err



# Generated at 2022-06-23 02:50:07.269907
# Unit test for function get_exception
def test_get_exception():
    # Test that something is defined
    try:
        raise Exception()
    except Exception:
        exception = get_exception()
        assert exception != None


# Generated at 2022-06-23 02:50:09.822296
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        assert get_exception() is sys.exc_info()[1]



# Generated at 2022-06-23 02:50:12.251772
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as z:
        e = get_exception()
        assert e == z



# Generated at 2022-06-23 02:50:16.056662
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test_get_exception")
    except:
        e = get_exception()
        assert e.args[0] == "test_get_exception"
        assert literal_eval("42") == 42

# Generated at 2022-06-23 02:50:19.037377
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('A type error occurred.')
    except TypeError:
        e = get_exception()
        assert isinstance(e, TypeError)
        assert 'occurred' in str(e)



# Generated at 2022-06-23 02:50:22.246721
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        tb = get_exception()
        assert 'ValueError' in str(tb)
    else:
        raise AssertionError('ValueError not raised')

# Generated at 2022-06-23 02:50:27.264439
# Unit test for function get_exception
def test_get_exception():
    try:
        0/0
    except:
        assert type(get_exception()) is ZeroDivisionError
    try:
        {}['foo']
    except:
        assert type(get_exception()) is KeyError


# Generated at 2022-06-23 02:50:30.138768
# Unit test for function get_exception
def test_get_exception():
    """Function get_exception should return the current exception"""

# Generated at 2022-06-23 02:50:33.409170
# Unit test for function get_exception
def test_get_exception():
    __tracebackhide__ = True

    try:
        raise Exception('test exception')
    except:
        e = get_exception()

    assert(str(e) == 'test exception')


# Generated at 2022-06-23 02:50:44.308960
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('This is a message')
    except TestException as e:
        e_from_except = e

    def test_func():
        try:
            raise TestException('This is a message')
        except TestException as e:
            e_from_except = e
            raise
    try:
        test_func()
    except TestException as e:
        e_from_except_and_raise = e

    def test_func2():
        try:
            raise TestException('This is a message')
        except TestException as e:
            e_from_except = e
        raise TestException('This is a message')
    try:
        test_func2()
    except TestException as e:
        e_from_except_and_raise_indirect

# Generated at 2022-06-23 02:50:50.730118
# Unit test for function get_exception
def test_get_exception():
    """Unit test to check that get_exception() returns the exception found in an except block"""
    try:
        raise Exception("This is an exception")
        # pylint: disable=unreachable
    except Exception:
        e = get_exception()
    assert e.args == ("This is an exception",)


# Generated at 2022-06-23 02:50:54.652987
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()

    assert(e.args[0] == 'test')

# Generated at 2022-06-23 02:50:57.709561
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except Exception:
        exc = get_exception()
        if str(exc) != 'test_get_exception':
            raise AssertionError

# Generated at 2022-06-23 02:51:02.465087
# Unit test for function get_exception
def test_get_exception():
    errstr = 'This is a fake error'
    try:
        raise RuntimeError(errstr)
    except RuntimeError:
        e = get_exception()
    assert str(e) == errstr
    assert e.__class__.__name__ == 'RuntimeError'

# Generated at 2022-06-23 02:51:11.802270
# Unit test for function get_exception
def test_get_exception():
    # Python 2.x, syntax error
    try:
        exec('raise ValueError()')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

    # Python 3.x, syntax error
    try:
        exec('raise ValueError()')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

    # Python 2.x, exception
    try:
        raise ValueError()
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

    # Python 3.x, exception
    try:
        raise ValueError()
    except:
        e = get_exception()
        assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:51:16.539321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'foo'



# Generated at 2022-06-23 02:51:26.942027
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:29.408727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
        assert str(ex) == 'foo'



# Generated at 2022-06-23 02:51:34.401230
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('abc')
    except RuntimeError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:51:36.800418
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise ValueError
        except:
            e = get_exception()
            assert isinstance(e, ValueError)
            raise
    except ValueError:
        pass

# Generated at 2022-06-23 02:51:44.034994
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    try:
        raise RuntimeError('Output')
    except RuntimeError:
        e = get_exception()
        mod.exit_json(failed=False, stdout=e.args[0])



# Generated at 2022-06-23 02:51:48.837926
# Unit test for function get_exception
def test_get_exception():
    def test_func(test_exception):
        try:
            raise test_exception
        except:
            e = get_exception()
        assert e is test_exception

    test_func(LookupError('test'))
    test_func(ValueError('test'))

# Generated at 2022-06-23 02:51:51.664422
# Unit test for function get_exception
def test_get_exception():

    try:
        raise ValueError('Ansible exception')
    except Exception:
        e = get_exception()
        print("%s" % e)
        print("%s" % e.args)

# Generated at 2022-06-23 02:51:55.642750
# Unit test for function get_exception
def test_get_exception():
    # TODO: Maybe we should subclass Exception to get a more unique error that
    # we can be sure is the one we raised
    try:
        raise Exception('foo')
    except Exception:
        assert 'foo' == get_exception().message



# Generated at 2022-06-23 02:51:59.603002
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("test",)

# Generated at 2022-06-23 02:52:03.286888
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException
    except:
        e = get_exception()
    assert type(e) == TestException



# Generated at 2022-06-23 02:52:06.370801
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        val = get_exception()
    assert val.args == ('test',)

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:52:09.983552
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()

# Generated at 2022-06-23 02:52:15.452601
# Unit test for function get_exception
def test_get_exception():
    try:
        1234 / 0
    except:
        e = get_exception()
        print('Python exception module: ' + str(e.__class__.__module__))
        print('The name of the exception class: ' + type(e).__name__)
        print(str(e))

# Generated at 2022-06-23 02:52:16.863309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("error")
    except:
        assert get_exception().args[0] == "error"


# Generated at 2022-06-23 02:52:21.055667
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("My Testing Exception")
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args[0] == "My Testing Exception"
        assert e.args[1:] == tuple()



# Generated at 2022-06-23 02:52:23.563970
# Unit test for function get_exception

# Generated at 2022-06-23 02:52:27.342222
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('bogus')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'bogus'



# Generated at 2022-06-23 02:52:30.111313
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        assert e
        assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:52:33.332791
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing get_exception')
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'Testing get_exception'


# Generated at 2022-06-23 02:52:38.263899
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    # get_exception() should return the same object on exception re-raise
    try:
        raise e
    except:
        f = get_exception()
    assert e is f

# Generated at 2022-06-23 02:52:40.956549
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=invalid-name
    try:
        raise Exception('Moop')
    except Exception:
        e = get_exception()
        assert e.args == ('Moop',)


# Generated at 2022-06-23 02:52:45.839357
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise Exception('foo')
    except:
        e = get_exception()

    # pylint: disable=deprecated-method
    if 'foo' == e.message:
        assert True
    else:
        # Python 3
        assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:52:48.062498
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is an exception')
    except Exception:
        assert 'This is an exception' == get_exception().args[0]

# Generated at 2022-06-23 02:52:52.657548
# Unit test for function get_exception
def test_get_exception():
    """Verify that get_exception returns the current exception"""
    def foo():
        try:
            bar(baz)
        except:
            return get_exception()

    try:
        bar(baz)
    except:
        expected = get_exception()

    e = foo()
    assert e.__class__ is expected.__class__
    assert e.args == expected.args



# Generated at 2022-06-23 02:52:56.999942
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('this is an exception')
    except Exception:
        e = get_exception()
        assert e.args == ('this is an exception',)

# unit test for literal_eval function

# Generated at 2022-06-23 02:53:00.755381
# Unit test for function get_exception
def test_get_exception():
    class Derp(Exception):
        pass

    try:
        raise Derp('foo')
    except Exception:
        assert get_exception().args == ('foo',)


# Generated at 2022-06-23 02:53:03.331599
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("doom")
    except:
        old_exc = get_exception()

    assert old_exc.args[0] == "doom"

# Generated at 2022-06-23 02:53:09.465113
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)
    try:
        raise AssertionError
    except AssertionError:
        e = get_exception()
        assert isinstance(e, AssertionError)

# Generated at 2022-06-23 02:53:13.001270
# Unit test for function get_exception
def test_get_exception():
    assert not get_exception()
    try:
        raise Exception('foo')
    except:
        ex = get_exception()
        assert isinstance(ex, Exception)
        assert 'foo' == str(ex)

# Generated at 2022-06-23 02:53:15.193556
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:53:18.714444
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    try:
        raise ValueError('A bunny ate my answer')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'A bunny ate my answer'



# Generated at 2022-06-23 02:53:26.359372
# Unit test for function get_exception
def test_get_exception():
    import traceback
    try:
        raise RuntimeError("Foo")
    except Exception:
        exc_info = get_exception()
    assert exc_info.__class__ is RuntimeError
    assert str(exc_info) == "Foo"
    # The traceback module doesn't work on Python 2.4
    try:
        traceback.print_tb(sys.exc_info()[2], limit=1)
    except AttributeError:
        pass


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:53:28.692102
# Unit test for function get_exception

# Generated at 2022-06-23 02:53:32.689632
# Unit test for function get_exception
def test_get_exception():
    """Check that we can get the exceptions"""
    try:
        raise ValueError("A ValueError exception")
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc) == "A ValueError exception"


# Generated at 2022-06-23 02:53:39.794618
# Unit test for function get_exception
def test_get_exception():
    import unittest

    try:
        raise Exception('Test exception')
    except Exception:
        exc = get_exception()

    class TestGetException(unittest.TestCase):
        """Unit tests for function get_exception"""

        def test_exc_message(self):
            self.assertEqual(exc.args, ('Test exception',))

    return TestGetException


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:53:41.981303
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("It's just a test, relax")
    except Exception:
        e = get_exception()
        assert str(e) == "It's just a test, relax"


# Generated at 2022-06-23 02:53:47.996409
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except:
        exc = get_exception()
        assert exc.args == ('Test exception',)


# Generated at 2022-06-23 02:53:50.699189
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exception = get_exception()
    assert exception.args == ('foo',)

# Generated at 2022-06-23 02:53:54.551740
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        assert(get_exception().__class__.__name__ == 'ValueError')
    else:
        assert False, 'Exception not raised'



# Generated at 2022-06-23 02:54:00.374515
# Unit test for function get_exception
def test_get_exception():
    def f1():
        try:
            raise SyntaxError
        except:
            return get_exception()

    e1 = f1()
    assert isinstance(e1, SyntaxError)


# Generated at 2022-06-23 02:54:08.610802
# Unit test for function get_exception
def test_get_exception():
    a = 1
    try:
        1/0
    except ZeroDivisionError as e:
        f = e
    try:
        1/0
    except:
        g = get_exception()
        h = sys.exc_info()[1]
    assert f == g == h
    try:
        1/0
    except:
        i = get_exception()
        j = sys.exc_info()[1]
    assert i == j

# Generated at 2022-06-23 02:54:11.702057
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        exc = e
    assert exc == get_exception()

# Generated at 2022-06-23 02:54:14.687816
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Foo")
    except:
        e = get_exception()
    assert str(e) == "Foo"

# Generated at 2022-06-23 02:54:19.387117
# Unit test for function get_exception
def test_get_exception():
    try:
        i = 1/0
    except Exception:
        e = get_exception()
        assert(e.args == ('integer division or modulo by zero',))
    else:
        print("I shouldn't be able to divide by zero")



# Generated at 2022-06-23 02:54:22.629043
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Message')
    except Exception:
        e = get_exception()
    assert str(e) == 'Message'



# Generated at 2022-06-23 02:54:26.012699
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Broken')
    except:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'Broken'


# Generated at 2022-06-23 02:54:28.634755
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('get_exception test')
    except:
        exc = get_exception()
    assert exc.args == ('get_exception test',)

# Generated at 2022-06-23 02:54:31.191682
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('fake exception')
    except Exception:
        e = get_exception()
    assert(str(e) == 'fake exception')



# Generated at 2022-06-23 02:54:33.753964
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:54:46.206537
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


"""
This module contains helper functions for the ansible cli scripts
"""

# import os
# import pwd
# import subprocess
# import sys
import os
import pwd
import subprocess
import sys
import datetime
import json
import time
import tempfile
import re
import codecs
import codecs
import requests
import getpass

from six import PY3
from distutils.spawn import find_executable

if PY3:
    def to_bytes(s):
        if isinstance(s, str):
            return s.encode('utf-8', 'strict')
        return s

# Generated at 2022-06-23 02:54:51.227357
# Unit test for function get_exception
def test_get_exception():
    class SomeException(Exception):
        def __init__(self, msg=''):
            self.msg = msg

        def __str__(self):
            return self.msg

    try:
        raise SomeException("foobar")
    except Exception:
        e = get_exception()
        assert e.msg == "foobar"
    else:
        assert False

# Generated at 2022-06-23 02:54:56.930909
# Unit test for function get_exception
def test_get_exception():
    exc_info = (None, None, None)
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    assert get_exception() is exc_info[1]


# Generated at 2022-06-23 02:55:03.234482
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name,redefined-outer-name,unused-variable
    assert '__main__' == __name__

# Generated at 2022-06-23 02:55:07.390460
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise AssertionError('get_exception returned wrong type: %s' % type(e))

