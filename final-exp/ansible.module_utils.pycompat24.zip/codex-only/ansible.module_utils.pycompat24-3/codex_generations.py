

# Generated at 2022-06-23 02:45:05.539959
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('1')
    except RuntimeError:
        exc = get_exception()
        assert exc is not None
        assert str(exc) == '1'



# Generated at 2022-06-23 02:45:09.810699
# Unit test for function get_exception
def test_get_exception():
    import unittest

    def f_throwing_exception():
        raise ValueError("Exception")

    try:
        f_throwing_exception()
        return False
    except:
        e = get_exception()
    assert isinstance(e, ValueError)


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-23 02:45:16.229632
# Unit test for function get_exception
def test_get_exception():
    try:
        blah
    except NameError:
        exc = get_exception()
    if not isinstance(exc, NameError):
        raise AssertionError

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-23 02:45:20.406191
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('value error')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'value error'


# Generated at 2022-06-23 02:45:22.913638
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('aieee!')
    except:
        e = get_exception()
    assert e.args[0] == 'aieee!'


# Generated at 2022-06-23 02:45:25.008794
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        assert True is not False
    else:
        assert True is not True

# Generated at 2022-06-23 02:45:26.913591
# Unit test for function get_exception
def test_get_exception():
    e = 'my exception'
    try:
        raise e
    except:
        assert get_exception() == e



# Generated at 2022-06-23 02:45:31.105348
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test")
    except Exception:
        e = get_exception()
        assert repr(e) == "Exception('test',)"


# Generated at 2022-06-23 02:45:35.263919
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError("foo")
    except:
        ex = get_exception()
    assert ex.args == ("foo",)



# Generated at 2022-06-23 02:45:43.419080
# Unit test for function get_exception
def test_get_exception():
    """Get the current exception.

    This code needs to work on Python 2.4 through 3.x, so we cannot use
    "except Exception, e:" (SyntaxError on Python 3.x) nor
    "except Exception as e:" (SyntaxError on Python 2.4-2.5).
    Instead we must use ::

        except Exception:
            e = get_exception()

    """
    try:
        raise ValueError('testing get_exception')
    except Exception as e:
        e2 = get_exception()
    if e is not e2:
        raise Exception('get_exception returned wrong exception')

# Generated at 2022-06-23 02:45:48.241903
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)
        if sys.version_info >= (3, ):
            assert 'This is an exception' == exc.args[0]
        else:
            assert 'This is an exception' == exc.message


# Generated at 2022-06-23 02:45:50.791795
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Some problem')
    except:
        assert get_exception().args[0] == 'Some problem'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:45:55.554742
# Unit test for function get_exception
def test_get_exception():
    def check_raise(e):
        try:
            raise e
        except Exception:
            assert e is get_exception()
    check_raise(Exception())
    check_raise(ArithmeticError())
    check_raise(KeyError())



# Generated at 2022-06-23 02:45:58.492226
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:46:04.500502
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception")
    except RuntimeError as e:
        if get_exception() is not e:
            raise AssertionError("Unexpected result from get_exception(): %r" % (get_exception()))

test_get_exception()

# Generated at 2022-06-23 02:46:06.764546
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("An exception")
    except Exception:
        e = get_exception()
        assert (e.args == ("An exception",))

# Generated at 2022-06-23 02:46:09.837062
# Unit test for function get_exception
def test_get_exception():
    """Simple unit tests for the get_exception function."""
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:46:12.082027
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hi')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'hi'



# Generated at 2022-06-23 02:46:14.744528
# Unit test for function get_exception
def test_get_exception():
    try:
        a = int('five')
    except:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise Exception("Expected ValueError, found: %s" % str(e))



# Generated at 2022-06-23 02:46:17.823670
# Unit test for function get_exception
def test_get_exception():
    class FakeException:
        pass
    try:
        raise FakeException
    except:
        exc = get_exception()
        assert FakeException is exc

# Generated at 2022-06-23 02:46:23.685549
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise TypeError("boo")
    try:
        raise_exception()
    except TypeError:
        e = get_exception()
        assert(e.__class__ == TypeError)
        assert(str(e) == "boo")
        assert(e.__str__() == "boo")


# Generated at 2022-06-23 02:46:26.214159
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('stack trace')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('stack trace',)


# Generated at 2022-06-23 02:46:29.980490
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Testing exception")
    except:
        e = get_exception()
        assert e.__class__.__name__ == 'ValueError'
        assert str(e) == "Testing exception"



# Generated at 2022-06-23 02:46:34.269594
# Unit test for function get_exception
def test_get_exception():
    '''test_get_exception
    Test the get_exception function.  It's a simple function so the test is
    trivial.
    '''
    try:
        raise ValueError('test error')
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:46:36.735577
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception')
    except Exception:
        e = get_exception()
        assert 'An exception' == str(e)



# Generated at 2022-06-23 02:46:44.854110
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise ValueError('This is the error message')
    try:
        foo()
    except Exception:
        e = get_exception()
    assert 'ValueError' in str(e)
    assert 'This is the error message' in str(e)



# Generated at 2022-06-23 02:46:50.525916
# Unit test for function get_exception
def test_get_exception():
    def fn1():
        raise ValueError('blah')

    def fn2():
        try:
            raise ValueError('blah')
        except Exception:
            return get_exception()

    assert fn2().args[0] == 'blah'
    try:
        fn1()
    except Exception as e:
        assert e.args[0] == 'blah'

# Generated at 2022-06-23 02:46:53.313005
# Unit test for function get_exception
def test_get_exception():
    def oops():
        raise Exception("Bad stuff happened")

    try:
        oops()
    except:
        got = get_exception()
    assert got.args[0] == "Bad stuff happened"

# Generated at 2022-06-23 02:46:55.740361
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exception = get_exception()

    assert isinstance(exception, ValueError)
    assert str(exception) == 'foo'


# Generated at 2022-06-23 02:47:03.321444
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:47:10.242982
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('foo')
    except KeyError:
        the_exception = get_exception()
        assert the_exception.args == ('foo',)
    else:
        assert False, 'Should not get here'



# Generated at 2022-06-23 02:47:13.596926
# Unit test for function get_exception

# Generated at 2022-06-23 02:47:17.428398
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except ZeroDivisionError:
        ex = get_exception()

    if isinstance(ex, ZeroDivisionError):
        return True
    raise RuntimeError('get_exception is broken')


# Generated at 2022-06-23 02:47:24.053854
# Unit test for function get_exception
def test_get_exception():
    def do_raise(e):
        raise e

    # Just check that these don't blow up
    try:
        1 / 0
    except Exception:
        get_exception()
    try:
        do_raise(ValueError('some randomly specified error'))
    except Exception:
        get_exception()
    try:
        do_raise(RuntimeError('some other error'))
    except Exception:
        assert 'other error' in str(get_exception())



# Generated at 2022-06-23 02:47:28.020833
# Unit test for function get_exception
def test_get_exception():
    def get_exception_helper():
        """Helper function to test get_exception"""
        try:
            1 / 0
        except ZeroDivisionError:
            return get_exception()
    assert isinstance(get_exception_helper(), ZeroDivisionError)


# Generated at 2022-06-23 02:47:39.988871
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        "Unit test exception class"

    # Test no exception
    try:
        pass
    except:
        assert False, 'get_exception got an exception when there was no exception'
    else:
        e = get_exception()
        assert e is None, 'get_exception did not return None when there was no exception'

    # Test exception class
    try:
        raise TestException()
    except:
        pass
    else:
        assert False, 'get_exception was not able to get an exception'
    e = get_exception()
    assert isinstance(e, TestException), 'get_exception did not return a TestException when one was raised'


# Generated at 2022-06-23 02:47:43.828912
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test exception'
        assert isinstance(e, Exception)
        assert e.__class__.__name__ == 'Exception'



# Generated at 2022-06-23 02:47:46.075794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:47:49.795861
# Unit test for function get_exception
def test_get_exception():
    # The standard way to check for exceptions doesn't work on 2.4
    try:
        raise RuntimeError('fail')
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'fail'



# Generated at 2022-06-23 02:47:53.461967
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except MyException:
        e = get_exception()

    assert isinstance(e, MyException)
    assert repr(type(e)) == "<type 'exceptions.MyException'>"



# Generated at 2022-06-23 02:47:56.627342
# Unit test for function get_exception
def test_get_exception():
    def foo():
        return get_exception()

    try:
        raise Exception('bar')
    except Exception:
        assert foo() is not None
        assert str(foo()) == 'bar'

# Generated at 2022-06-23 02:48:00.493685
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        raise Exception('foo')

    try:
        test_func()
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-23 02:48:07.271368
# Unit test for function get_exception
def test_get_exception():

    def this_raise():
        '''inner function used by get_exception test'''
        raise TypeError('test_get_exception')

    try:
        this_raise()
    except Exception:
        exc = get_exception()
        assert isinstance(exc, TypeError)
        assert exc.args[0] == 'test_get_exception'
        pass
    else:
        assert False, 'get_exception did not work'


# Generated at 2022-06-23 02:48:11.481180
# Unit test for function get_exception
def test_get_exception():
    # This function should return the most recent exception that was raised.
    # We need to test it right after and exception is raised, so we'll run it inline
    try:
        raise Exception('this is a test exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'this is a test exception'

# Generated at 2022-06-23 02:48:13.647321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo bar")
    except Exception:
        e = get_exception()
    assert e.args == ("foo bar",)

# Generated at 2022-06-23 02:48:15.415572
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:48:18.347149
# Unit test for function get_exception
def test_get_exception():
    def throw_exception():
        try:
            raise Exception('ansible')
        except Exception:
            return get_exception()
    assert throw_exception().args[0] == 'ansible'

# Generated at 2022-06-23 02:48:20.915088
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        assert get_exception()


# Generated at 2022-06-23 02:48:31.970331
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Sample Exception')
    except RuntimeError:
        type, value, trace = sys.exc_info()

    try:
        raise TypeError('Sample Exception 2')
    except TypeError:
        got_exc = get_exception()
        assert isinstance(got_exc, TypeError)
        assert got_exc.args == ('Sample Exception 2',)
        assert str(got_exc) == 'Sample Exception 2'
        assert repr(got_exc) == 'Sample Exception 2'


# Generated at 2022-06-23 02:48:34.475798
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception"""
    try:
        raise Exception("my exception")
    except Exception:
        e = get_exception()
        assert str(e) == "my exception"

# Generated at 2022-06-23 02:48:40.037129
# Unit test for function get_exception
def test_get_exception():
    # Setup test class
    class FooError(Exception):
        pass

    # Simulate a try block
    try:
        raise FooError('This is a simulated exception')
    except FooError:
        # Make sure that get_exception returns an object
        exc = get_exception()
        assert exc
        assert isinstance(exc, FooError)
        assert isinstance(str(exc), str)
        # One more test for good measure
        assert len(str(exc)) > 0


# Generated at 2022-06-23 02:48:46.941745
# Unit test for function get_exception
def test_get_exception():
    '''
    Testing to make sure get_exception() works on all supported python interpreters.
    '''
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'test' in str(e)

# Generated at 2022-06-23 02:48:50.651101
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foobarize the goop')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'Foobarize the goop'


# Generated at 2022-06-23 02:48:54.422674
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise RuntimeError('foo')
    try:
        raise_exception()
    except Exception:
        exc = get_exception()
        assert exc.args[0] == 'foo'


# Generated at 2022-06-23 02:48:57.572168
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Hello World")
    except RuntimeError:
        e = get_exception()
        assert str(e) == "Hello World"
        assert type(e) == RuntimeError



# Generated at 2022-06-23 02:48:59.694797
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        ex = get_exception()
    assert ex is not None


# Generated at 2022-06-23 02:49:01.726150
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:49:04.225250
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert str(exc) == 'test'

#

# Generated at 2022-06-23 02:49:07.195066
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except Exception:
        e = get_exception()
        if not isinstance(e, RuntimeError) or str(e) != 'This is a test':
            raise AssertionError("get_exception didn't work")

# Generated at 2022-06-23 02:49:12.519732
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:49:17.053510
# Unit test for function get_exception
def test_get_exception():
    exception_text = "some exception text"
    try:
        raise Exception(exception_text)
    except Exception:
        e = get_exception()
        assert e.__class__.__name__  == "Exception"
        assert e.__str__() == exception_text

# Generated at 2022-06-23 02:49:19.216197
# Unit test for function get_exception
def test_get_exception():
    def foo():
        return get_exception()
    try:
        1 / 0
    except:
        assert foo()



# Generated at 2022-06-23 02:49:21.380636
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        assert get_exception()



# Generated at 2022-06-23 02:49:26.661995
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.basic

    def raise_exception():
        raise Exception('This is a test')

    try:
        raise_exception()
    except Exception:
        e = ansible.module_utils.basic.get_exception()
        assert 'This is a test' in str(e)
        assert e.__class__.__name__ == 'Exception'

# Generated at 2022-06-23 02:49:28.226494
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Hi')
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'Hi'

# Generated at 2022-06-23 02:49:30.544739
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except:
        e = get_exception()
        assert e.args[0] == 'test'


# Generated at 2022-06-23 02:49:33.741395
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def foo(x):
        raise Exception("Hello world!: {0}".format(x))

    try:
        foo("abc")
    except Exception:
        e = get_exception()
        assert str(e) == "Hello world!: abc"

# Generated at 2022-06-23 02:49:38.392744
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:49:41.938685
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:49:47.359791
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AttributeError('test_get_exception')
    except AttributeError:
        ex = get_exception()
        if ex.args != ('test_get_exception',):
            raise AssertionError(ex)



# Generated at 2022-06-23 02:49:50.119419
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        err = get_exception()
        assert isinstance(err, RuntimeError)


# Generated at 2022-06-23 02:49:53.558343
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=missing-docstring
    try:
        raise RuntimeError('get_exception')
    except RuntimeError as e:
        if get_exception() != e:
            raise AssertionError()
    assert get_exception() is None

# Generated at 2022-06-23 02:49:56.656579
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test")
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ("test", )



# Generated at 2022-06-23 02:50:00.393414
# Unit test for function get_exception
def test_get_exception():
    """Quick unit test to run with nose framework"""
    try:
        raise Exception("Some Exception Text")
    except Exception:
        assert str(get_exception()) == "Some Exception Text"

# Generated at 2022-06-23 02:50:04.782279
# Unit test for function get_exception
def test_get_exception():
    e = get_exception()
    assert not e
    try:
        1/0  # Divide by zero error
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:50:06.874532
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert exc

# Generated at 2022-06-23 02:50:09.821602
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Oops!')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'Oops!'

# Generated at 2022-06-23 02:50:17.946933
# Unit test for function get_exception
def test_get_exception():
    def do_nothing():
        return 0

    def raise_it():
        raise RuntimeError('hello')

    try:
        do_nothing()
    except Exception:
        e = get_exception()
    assert e is None, e

    try:
        raise_it()
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args == ('hello',)

if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-23 02:50:22.705527
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:50:27.154028
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except:
        err = get_exception()
    assert isinstance(err, AssertionError)
    assert err.args == ('foo',)

# Generated at 2022-06-23 02:50:30.439262
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> try:
    ...   raise RuntimeError('the error')
    ... except:
    ...   e = get_exception()
    ...   assert e.args == ('the error',)
    '''

# Generated at 2022-06-23 02:50:34.065086
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:50:36.444589
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:50:38.531770
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except:
        assert get_exception()


# Generated at 2022-06-23 02:50:41.667236
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('A test')
    except ValueError:
        e = get_exception()
        assert repr(e) == repr(ValueError('A test'))


# Generated at 2022-06-23 02:50:43.893564
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:50:47.731721
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTests(unittest.TestCase):
        def test_get_exception_exception(self):
            try:
                raise Exception
            except Exception:
                e = get_exception()
                self.assertIsInstance(e, Exception)

#  Unit test for function literal_eval

# Generated at 2022-06-23 02:50:50.297635
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:50:55.454321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('example')
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert exc.args == ('example',)


# Generated at 2022-06-23 02:51:00.498865
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Expected unit test exception')
    except:
        exception = get_exception()
        assert isinstance(exception, RuntimeError)
        assert 'Expected unit test exception' == str(exception)


# Generated at 2022-06-23 02:51:02.319170
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        assert get_exception()


# Generated at 2022-06-23 02:51:05.051336
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        assert get_exception().args[0] == 'foo', 'get_exception() missed the exception'



# Generated at 2022-06-23 02:51:07.615821
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception) is True



# Generated at 2022-06-23 02:51:10.033142
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        exc = get_exception()
        assert str(exc) == 'test'

# Generated at 2022-06-23 02:51:12.101987
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        exc = get_exception()
        assert exc.__str__ == 'Test exception'



# Generated at 2022-06-23 02:51:20.029397
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=invalid-name,missing-docstring
    try:
        5/0  # pylint: disable=pointless-statement

    except:
        e = get_exception()
        assert str(e) == 'integer division or modulo by zero'
        assert type(e) is ZeroDivisionError

    else:
        assert False, "should have thrown an exception"



# Generated at 2022-06-23 02:51:26.439852
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:28.968879
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception')
    except Exception:
        tb = get_exception()
    assert tb.args[0] == 'An exception'


# Generated at 2022-06-23 02:51:32.665664
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
        assert exc.args == ("foo",), "Exception args: %r, expected: ('foo',)" % (exc.args,)

# Generated at 2022-06-23 02:51:35.718552
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:51:43.691030
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
        if not isinstance(e, Exception):
            from distutils.version import LooseVersion
            if LooseVersion(sys.version) >= LooseVersion('3.0.0'):
                raise Exception()
        else:
            pass
    # Make pylint shut up
    return e

# Generated at 2022-06-23 02:51:48.211634
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            self.assertEqual(get_exception(), None)
            try:
                raise Exception('message')
            except:
                e = get_exception()
                self.assertEqual(str(e), 'message')

    unittest.main()

# Generated at 2022-06-23 02:51:51.832382
# Unit test for function get_exception
def test_get_exception():
    def raises_exc():
        raise NameError('bob')

    try:
        raises_exc()
    except:
        e = get_exception()
        assert isinstance(e, NameError)
        assert e.args == ('bob',)



# Generated at 2022-06-23 02:51:54.259088
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:51:57.495322
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=too-many-locals
    try:
        raise ValueError("test")
    except ValueError:
        e = get_exception()
    assert str(e) == 'test'

# Generated at 2022-06-23 02:52:01.200517
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('exception text')
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert 'exception text' in str(exc)


# Generated at 2022-06-23 02:52:05.295936
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test exception")
    except ValueError:
        exc = get_exception()
    assert exc.__class__.__name__ == 'ValueError'
    assert str(exc) == 'This is a test exception'


# Generated at 2022-06-23 02:52:09.388169
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception"""
    try:
        raise Exception('test exception')
    except Exception:
        exc = get_exception()
        assert exc.args == ('test exception', )


# Generated at 2022-06-23 02:52:13.609823
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError as e:
        if e is not get_exception():
            raise ValueError("exception is not get_exception()")

# Generated at 2022-06-23 02:52:17.120136
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Hello')
    except Exception:
        e = get_exception()
    if e.args[0] != 'Hello':
        raise AssertionError('Did not catch the right exception')

# Generated at 2022-06-23 02:52:22.573923
# Unit test for function get_exception
def test_get_exception():
    """
    Just to make sure that get_exception imported properly.

    Note: This test is of limited value since it's hard to test that
    get_exception works when called inside of an except block.
    """
    try:
        raise NameError('foo')
    except NameError:
        ret = get_exception()
    assert isinstance(ret, NameError)

# Generated at 2022-06-23 02:52:26.110804
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise RuntimeError("A test exception")
    except RuntimeError as e2:
        e = get_exception()
        assert e == e2



# Generated at 2022-06-23 02:52:29.292232
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Invalid Value")
    except ValueError:
        e = get_exception()
    assert type(e) is ValueError
    assert e.args[0] == 'Invalid Value'

# Generated at 2022-06-23 02:52:32.458423
# Unit test for function get_exception
def test_get_exception():
    # Test that we can catch the current exception
    try:
        raise ValueError('testing get exception')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'testing get exception'
    return

# Generated at 2022-06-23 02:52:36.335095
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        assert type(get_exception()) == type(ValueError('test'))



# Generated at 2022-06-23 02:52:39.248409
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('Oops!')
    except TestException as e:
        assert e == get_exception()


# Generated at 2022-06-23 02:52:41.884146
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:52:46.549545
# Unit test for function get_exception
def test_get_exception():
    """
    >>> def callf():
    ...     try:
    ...         raise TypeError
    ...     except Exception:
    ...         return get_exception()
    >>> callf()
    Traceback (most recent call last):
        ...
    TypeError
    """

# Generated at 2022-06-23 02:52:50.553123
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise TypeError('bad mojo')
    ... except Exception:
    ...     e = get_exception()
    >>> isinstance(e, TypeError)
    True
    >>> e.args[0]
    'bad mojo'
    """
    pass

# Generated at 2022-06-23 02:52:56.116603
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert e.args[0] == "integer division or modulo by zero"

# Generated at 2022-06-23 02:53:02.298559
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        def __init__(self, param):
            self.param = param # pylint: disable=super-init-not-called
    try:
        raise TestException(u'\N{SNOWMAN}')
    except TestException:
        e = get_exception()
    assert type(e) == TestException
    assert isinstance(e.param, string_types)
    assert e.param == u'\N{SNOWMAN}'


# Generated at 2022-06-23 02:53:04.756980
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()

    assert e is not None
    assert isinstance(e, Exception)


# Generated at 2022-06-23 02:53:16.073315
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unreachable,exec-used
    import os
    import pickle
    import random
    import string
    import tempfile
    import traceback
    import unittest
    import sys
    import platform

    import _ast

    def find_exception_class(name, index=0):
        for class_name in dir(__import__(name)):
            if class_name.endswith('Exception'):
                if index == 0:
                    return class_name, getattr(__import__(name), class_name)
                index -= 1
        raise KeyError('Could not find exception for index=%s' % index)

    class ExceptionTest(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__

# Generated at 2022-06-23 02:53:23.636374
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except Exception:
        e = get_exception()

    if not isinstance(e, TestException):
        raise AssertionError('e does not have the correct type')
    if sys.exc_info()[1] is not e:
        raise AssertionError('e is not the current exception')


# Generated at 2022-06-23 02:53:27.279270
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except:
        e = get_exception()
        # Check for a valid exception without Traceback
        assert(str(e) == "Test exception")


# Generated at 2022-06-23 02:53:32.109566
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
    try:
        raise Exception('bar')
    except Exception as e:
        assert str(e) == 'bar'
        e2 = get_exception()
        assert e2 == e


# Generated at 2022-06-23 02:53:42.133918
# Unit test for function get_exception
def test_get_exception():
    # Test it fails if there is no exception
    try:
        get_exception()
        assert False, "Should not be able to get exception without an exception occurring"
    except RuntimeError:
        # that's what we expect, go on
        pass

    # Make sure we can get the current exception
    try:
        a = b
    except NameError:
        e = get_exception()
        assert isinstance(e, NameError), "get_exception did not return the current exception (NameError)"

    # Make sure that we can get an exception when chaining
    try:
        1 / 0
    except ZeroDivisionError:
        try:
            a = b
        except NameError:
            e = get_exception()

# Generated at 2022-06-23 02:53:43.984150
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e is not None



# Generated at 2022-06-23 02:53:48.317369
# Unit test for function get_exception
def test_get_exception():
    """Test if we can get the exception info properly.
    """
    try:
        raise RuntimeError("This is an error")
    except Exception:
        e = get_exception()

    assert str(e) == "This is an error", str(e)



# Generated at 2022-06-23 02:53:53.414857
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("test")
    except Exception:
        try:
            raise get_exception()
        except RuntimeError as e:
            assert str(e) == "test"
            return
    raise AssertionError("did not get a RuntimeError exception")


# Generated at 2022-06-23 02:53:55.912400
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("A fake error")
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:54:04.942960
# Unit test for function get_exception
def test_get_exception():
    import random
    import string

    def _get_random_string(length):
        """Create a random string with ascii letters and digits."""
        # pick from ascii_letters and digits
        pool = string.ascii_letters + string.digits
        return ''.join(random.choice(pool) for i in range(length))

    def _is_exception(exception):
        """Function which returns whether an object is an exception."""
        try:
            raise exception
        except:
            return True
        else:
            return False

    def _generate_random_exception():
        """Create a random 'exception'."""
        num_attributes = random.randint(0, 20)
        if num_attributes == 0:
            return Exception()


# Generated at 2022-06-23 02:54:08.808691
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'foo', 'Got %s instead of foo' % str(e)



# Generated at 2022-06-23 02:54:11.852403
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:16.629396
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e
    try:
        raise ValueError('foo')
    except ValueError:
        assert get_exception().args == ('foo',)



# Generated at 2022-06-23 02:54:22.230871
# Unit test for function get_exception
def test_get_exception():
    """Verify that we can get the current exception"""
    # pylint: disable=unused-variable
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError), \
        'Did not receive a ValueError exception'
    assert e.args == ('test',), \
        'Exception did not have the right args'



# Generated at 2022-06-23 02:54:25.674339
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise KeyboardInterrupt()
        except:
            raise ValueError('b')
    except ValueError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:54:28.316898
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('abc')
    except:
        e = get_exception()
    assert e.args[0] == 'abc'


# Generated at 2022-06-23 02:54:30.121222
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError
    except:
        assert get_exception()



# Generated at 2022-06-23 02:54:35.193935
# Unit test for function get_exception
def test_get_exception():
    class A(Exception):
        pass
    class B(Exception):
        pass
    try:
        raise A
    except Exception:
        a = get_exception()
    try:
        raise B
    except Exception:
        b = get_exception()
    assert isinstance(a, A)
    assert isinstance(b, B)
    assert str(a) == str(a)
    assert str(b) == str(b)

# Generated at 2022-06-23 02:54:37.849018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        x = get_exception()
        assert x.args == ('foo',)

# Generated at 2022-06-23 02:54:42.889377
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is only a test")
    except ValueError as e:
        assert str(e) == 'This is only a test'
        assert isinstance(get_exception(), ValueError)
        assert get_exception() is e


# Generated at 2022-06-23 02:54:46.292846
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test value')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'test value' in str(e)


# Generated at 2022-06-23 02:54:49.747700
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        """Test Exception"""
        pass

    try:
        raise TestException
    except TestException:
        exc = get_exception()
    assert type(exc) == TestException



# Generated at 2022-06-23 02:54:57.078322
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('Message')
    except Exception:
        e = get_exception()
        if e.args[0] != 'Message':
            raise AssertionError('get_exception() failed to get the right message')
        if type(e) != type(TestException()):
            raise AssertionError('get_exception() failed to get the right exception type')

    try:
        raise TestException()
    except Exception:
        e = get_exception()
        if type(e) != type(TestException()):
            raise AssertionError('get_exception() failed to get the right exception type')

# Generated at 2022-06-23 02:55:01.679806
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except:
        e = get_exception()
    assert e.args == ('This is an exception',)


# unit test for function literal_eval

# Generated at 2022-06-23 02:55:04.804007
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError as e:
        assert e == get_exception()
