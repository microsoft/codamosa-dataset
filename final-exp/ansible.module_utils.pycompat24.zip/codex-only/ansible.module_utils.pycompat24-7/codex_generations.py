

# Generated at 2022-06-23 02:45:09.109900
# Unit test for function get_exception
def test_get_exception():
    '''
    Unit test for function get_exception.

    This test should be run with Python 2.4, 2.5, 2.6, 2.7, 3.x
    '''

    class FakeException(Exception):
        pass

    try:
        raise FakeException('foo', {'bar': 'baz'})
    except FakeException:
        e = get_exception()
        assert str(e) == "foo"
        assert e.args == ({'bar': 'baz'},)


# Generated at 2022-06-23 02:45:11.300499
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)


# Generated at 2022-06-23 02:45:13.834213
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-23 02:45:19.234223
# Unit test for function get_exception

# Generated at 2022-06-23 02:45:22.752418
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('My exception')
    except:
        e = get_exception()
        assert e.args[0] == 'My exception'

# Generated at 2022-06-23 02:45:25.136124
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is really a testing message')
    except Exception:
        assert get_exception() == Exception('This is really a testing message')

# Generated at 2022-06-23 02:45:33.302769
# Unit test for function get_exception
def test_get_exception():
    import cStringIO
    import sys

    try:
        raise Exception('oops')
    except:
        sys.stdout = cStringIO.StringIO()
        print(get_exception())
        s = sys.stdout.getvalue()
        assert s == "Exception('oops',)\n", s

    try:
        raise Exception('oops')
    except:
        sys.stdout = cStringIO.StringIO()
        print(get_exception().args)
        s = sys.stdout.getvalue()
        assert s == "('oops',)\n", s

# Generated at 2022-06-23 02:45:43.024266
# Unit test for function get_exception
def test_get_exception():
    def _fn_that_raises_RuntimeError():
        raise RuntimeError('Just testing')

    try:
        _fn_that_raises_RuntimeError()
    except RuntimeError as e:
        e1_t, e1_v, e1_tb = sys.exc_info()
        del e1_tb
        if e1_t is not e1_v.__class__:
            raise AssertionError('sys.exc_info() is returning inconsistent results')
        e2 = get_exception()
        if e1_v is not e2:
            raise AssertionError('get_exception returned a different exception: {0}'.format(e2))

# Generated at 2022-06-23 02:45:46.413825
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('foobar')
    except TestException as e:
        e2 = get_exception()
        assert e2 == e
        assert e2.args == ('foobar',)

# Generated at 2022-06-23 02:45:51.441760
# Unit test for function get_exception
def test_get_exception():
    class FooException(Exception):
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar
            super(FooException, self).__init__()

    try:
        raise FooException('abc', 123)
    except:
        e = get_exception()
        assert e.foo == 'abc'
        assert e.bar == 123
        assert str(e) == "FooException('abc', 123)"

# Generated at 2022-06-23 02:45:55.285983
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'
    assert get_exception() is None



# Generated at 2022-06-23 02:45:58.630285
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise Exception()
        except Exception:
            e = get_exception()
            assert isinstance(e, Exception)
            raise
    try:
        test()
    except Exception as e:
        assert e == e

# Generated at 2022-06-23 02:46:03.136900
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception), 'get_exception() should have returned the raised exception'
    assert str(e) == 'foo', 'get_exception() should have returned the raised exception'

# TODO: Test literal_eval

# Generated at 2022-06-23 02:46:06.666845
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("something went wrong")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert "something went wrong" == str(e)



# Generated at 2022-06-23 02:46:10.443878
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("An exception")
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == "An exception"
    assert e.args == ("An exception",)


# Generated at 2022-06-23 02:46:14.123518
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is the error message')
    except Exception:
        e = get_exception()

    # Simple test to check that it's the right exception and with the right message
    assert isinstance(e, RuntimeError)
    assert str(e) == 'This is the error message'

# Tests for function literal_eval

# Generated at 2022-06-23 02:46:17.994628
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e1 = get_exception()
    try:
        raise e1
    except Exception:
        assert e1 == get_exception()

# Generated at 2022-06-23 02:46:21.783605
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        try:
            raise KeyError()
        except KeyError:
            assert e is not get_exception()

# Generated at 2022-06-23 02:46:26.290444
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0  # pylint: disable=pointless-statement
    except:
        e2 = get_exception()
    try:
        1 / 0  # pylint: disable=pointless-statement
    except ZeroDivisionError as e1:
        assert e1 is e2

# Generated at 2022-06-23 02:46:28.836848
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
        assert exc.args[0] == 'foo'

# Generated at 2022-06-23 02:46:32.763309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
        correct = RuntimeError('foo')
        if e is not correct:
            raise AssertionError("e: (%r) != correct: (%r)" % (e, correct))


# Generated at 2022-06-23 02:46:35.135517
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception
        except Exception:
            return get_exception()

    assert f().__class__ == Exception



# Generated at 2022-06-23 02:46:37.176445
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-23 02:46:44.118093
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(u'simulated value error')
    except:
        e = get_exception()
        assert u'simulated value error' == unicode(e)



# Generated at 2022-06-23 02:46:48.087198
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    e = None
    try:
        raise TestException('test')
    except TestException:
        e = get_exception()

    assert isinstance(e, TestException)
    assert str(e) == 'test'

# Generated at 2022-06-23 02:46:59.428809
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise Exception('Test get_exception')
    ... except Exception:
    ...     e = get_exception()
    ...
    >>> str(e)
    'Test get_exception'

    >>> literal_eval('''{'foo': 'bar',}''') == {'foo': 'bar',}
    True

    >>> literal_eval('''{'foo': 'bar',}''') == {'foo': 'bar'}
    False

    >>> literal_eval('''{'foo': 'bar',}''')
    {'foo': 'bar'}

    >>> literal_eval('''{'foo': 'bar',}''')  == eval('''{'foo': 'bar',}''')
    True
    """


# Generated at 2022-06-23 02:47:04.473292
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except Exception:
        exc = get_exception()
        assert isinstance(exc, RuntimeError)


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:47:07.516467
# Unit test for function get_exception
def test_get_exception():
    # This is only a stub since we don't want to include the entire
    # testing framework for just one method
    try:
        a = 'x'
        b = int(a)
    except Exception:
        e = get_exception()
    assert type(e) == ValueError

# Generated at 2022-06-23 02:47:10.844053
# Unit test for function get_exception
def test_get_exception():
    try:
        1//0
    except Exception as e:
        assert get_exception() is e
    try:
        1/0
    except Exception as e:
        assert get_exception() is e
    try:
        1/1
    except Exception:
        assert get_exception() is None

# Generated at 2022-06-23 02:47:13.981887
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boom')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'boom'


# Generated at 2022-06-23 02:47:17.754854
# Unit test for function get_exception
def test_get_exception():

    def t():
        try:
            raise ValueError('test')
        except:  # noqa  (we want to check the exception)
            e = get_exception()
        return e

    assert isinstance(t(), ValueError)

# Generated at 2022-06-23 02:47:24.753223
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        ex = get_exception()

    # On Python 2 this will be a string and on Python 3 we get an Exception object
    assert isinstance(ex, basestring) or isinstance(ex, Exception)

    try:
        1/0
    except:
        ex = get_exception()

    # On Python 2 this will be a string and on Python 3 we get an Exception object
    assert isinstance(ex, basestring) or isinstance(ex, Exception)

# Generated at 2022-06-23 02:47:27.257477
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert 'foo' in str(e)


# Generated at 2022-06-23 02:47:30.165459
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except RuntimeError as e:
        assert get_exception() is e


# Generated at 2022-06-23 02:47:38.199366
# Unit test for function get_exception
def test_get_exception():
    try:
        master_password = input('Enter master password: ')
        if master_password == 'swordfish':
            raise RuntimeError('You typed the wrong answer...')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.args == ('You typed the wrong answer...',)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:47:44.811762
# Unit test for function get_exception
def test_get_exception():
    def _test_get_exception(val):
        try:
            raise Exception(val)
        except Exception:
            e = get_exception()
            assert isinstance(e, Exception)
            assert e.args == (val, )
            assert str(e) == str(val)
            assert repr(e) == repr(val)
    _test_get_exception('testing')
    _test_get_exception(('testing', 'testing'))
    _test_get_exception(['testing', 'testing'])

# Generated at 2022-06-23 02:47:45.532681
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        assert isinstance(get_exception(), ValueError)

# Generated at 2022-06-23 02:47:48.151467
# Unit test for function get_exception

# Generated at 2022-06-23 02:47:53.535680
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=unreachable
        assert False
    except:
        # pylint: enable=unreachable
        e = get_exception()
        assert e.__class__.__name__ == 'AssertionError'

# Generated at 2022-06-23 02:47:56.693044
# Unit test for function get_exception
def test_get_exception():
    """Ensure get_exception works"""
    try:
        raise Exception('foo')
    except:
        exception = get_exception()
        assert exception.__str__() == 'foo'


# Generated at 2022-06-23 02:48:00.155252
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError


# Generated at 2022-06-23 02:48:03.891669
# Unit test for function get_exception
def test_get_exception():
    try:
        print("about to raise exception")
        raise Exception("foo!")
    except Exception:
        e = get_exception()
        print("got exception: %s" % e)
        assert("foo!" in str(e))

# Generated at 2022-06-23 02:48:07.162210
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException()
    except Exception:
        exc = get_exception()
    assert isinstance(exc, MyException)


# Generated at 2022-06-23 02:48:10.341156
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc) == 'Test exception'



# Generated at 2022-06-23 02:48:12.862618
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Hai i am exception")
    except:
        e = get_exception()
        assert str(e) == "Hai i am exception"



# Generated at 2022-06-23 02:48:16.541303
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Test exception'

# Generated at 2022-06-23 02:48:18.641368
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise TypeError
        except:
            return get_exception()
    assert isinstance(foo(), TypeError)

# Generated at 2022-06-23 02:48:24.993197
# Unit test for function get_exception
def test_get_exception():
    def raise_exception(a, b):
        try:
            raise RuntimeError('foo')
        except:
            ex = get_exception()
            assert ex.args == ('foo',)
            assert ex.message == 'foo'
            assert str(ex) == 'foo'
    raise_exception(1, 2)

# Generated at 2022-06-23 02:48:29.077223
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('an exception message')
    except:
        e = get_exception()
    assert e.args == ('an exception message', )
    assert str(e) == 'an exception message'

# Generated at 2022-06-23 02:48:31.589103
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('dummy exception')
    except Exception:
        e = get_exception()
        assert e.message == 'dummy exception'
    return True

# Generated at 2022-06-23 02:48:34.464231
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Some message")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.message == "Some message"


# Generated at 2022-06-23 02:48:37.511677
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.message == 'Test'


# Generated at 2022-06-23 02:48:42.606002
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def my_except(e):
        return e

    try:
        raise Exception('test exception')
    except:
        assert my_except(get_exception()) == my_except(sys.exc_info()[1])
    try:
        import raise_me
    except:
        assert my_except(get_exception()) == my_except(sys.exc_info()[1])



# Generated at 2022-06-23 02:48:46.791805
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except Exception:
        e = get_exception()
        assert str(e) == 'integer division or modulo by zero'
    else:
        assert False



# Generated at 2022-06-23 02:48:50.496413
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a')
    except ValueError:
        e = get_exception()
    assert 'a' in str(e)


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-23 02:48:52.800500
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()

    assert exc.args == ('foo',)

# Generated at 2022-06-23 02:48:56.431058
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert e is not None
        assert repr(e).startswith("ZeroDivisionError(")


# Generated at 2022-06-23 02:49:02.640496
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    def _raise_exception():
        raise TestException('testing exception')

    try:
        _raise_exception()
    except:
        # Cannot use `except TestException:` because Python 2.4 does not support that syntax
        exc = get_exception()
        assert isinstance(exc, TestException), "get_exception does not return the current exception"
        assert str(exc) == 'testing exception', "get_exception does not return the current exception"



# Generated at 2022-06-23 02:49:05.667623
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'testing get_exception'



# Generated at 2022-06-23 02:49:13.407070
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=too-many-branches,no-self-use,too-many-statements,too-many-locals,invalid-name
    from ansible.module_utils._text import to_bytes

    class FooError(Exception):
        def __init__(self, arg):
            self.arg = arg

        def __str__(self):
            return repr(self.arg)


# Generated at 2022-06-23 02:49:17.913878
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Boom!')
    except Exception:
        exc_info = get_exception()

    assert str(exc_info) == 'Boom!'


# Generated at 2022-06-23 02:49:20.944856
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError), 'Wrong exception type returned.'


# Generated at 2022-06-23 02:49:24.700979
# Unit test for function get_exception
def test_get_exception():
    class Foo(Exception):
        pass

    try:
        raise Foo('Foo!')
        assert False
    except:
        e = get_exception()
        assert isinstance(e, Foo)
        assert 'Foo!' == str(e)

# Generated at 2022-06-23 02:49:29.390748
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert id(e) == id(get_exception())



# Generated at 2022-06-23 02:49:32.509809
# Unit test for function get_exception
def test_get_exception():
    # Test that it runs properly
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
    assert e.args == ('Test',)


# Generated at 2022-06-23 02:49:35.075408
# Unit test for function get_exception
def test_get_exception():
    # test the function of the function, not the implementation
    try:
        raise RuntimeError('An exception')
    except RuntimeError as e:
        assert e is get_exception()


# Generated at 2022-06-23 02:49:47.156609
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise RuntimeError('test exception')
    except:  # noqa
        exception = get_exception()
        assert str(exception) == 'test exception'
    try:
        raise RuntimeError()
    except:  # noqa
        with pytest.raises(ValueError):
            str(get_exception())
    assert get_exception() is None

    # Make sure that we can get the exception even if another one is
    # raised in the try block
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        try:
            raise ValueError('test exception 2')
        except:  # noqa
            assert str(get_exception()) == 'test exception 2'



# Generated at 2022-06-23 02:49:52.495611
# Unit test for function get_exception
def test_get_exception():
    class ZeroDivisionRaised(Exception):
        pass

    def function_with_exception():
        try:
            raise ZeroDivisionRaised()
        except:
            exception = get_exception()
            assert exception.__class__ == ZeroDivisionRaised
            assert isinstance(exception, ZeroDivisionRaised)
    function_with_exception()


# Generated at 2022-06-23 02:50:00.393950
# Unit test for function get_exception

# Generated at 2022-06-23 02:50:03.809395
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
        print(e)


# Generated at 2022-06-23 02:50:11.150855
# Unit test for function get_exception
def test_get_exception():
    # An exception caused by calling this function with too few arguments
    try:
        get_exception()
    except TypeError as e:
        ex = get_exception()
        assert e is ex
    else:
        assert False

    # An exception caused by calling this function with too many arguments
    try:
        get_exception(0)
    except TypeError as e:
        ex = get_exception()
        assert e is ex
    else:
        assert False

# Generated at 2022-06-23 02:50:15.944346
# Unit test for function get_exception
def test_get_exception():
    # Given
    def raise_exception():
        raise ValueError('foo')

    # When
    try:
        raise_exception()
    except:
        e = get_exception()

    # Then
    assert isinstance(e, ValueError)
    assert unicode(e) == u'foo'


# Generated at 2022-06-23 02:50:23.860430
# Unit test for function get_exception
def test_get_exception():
    def f1():
        raise RuntimeError("foo")

    def f2():
        try:
            raise RuntimeError("foo")
        except:
            return get_exception()


# Generated at 2022-06-23 02:50:28.014583
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:50:32.707117
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foobar')
    except ValueError:
        err = get_exception()
        assert err.args[0] == 'Foobar'
        assert isinstance(err, ValueError)
    else:
        assert False, 'Exception not caught'


# Generated at 2022-06-23 02:50:37.469640
# Unit test for function get_exception
def test_get_exception():
    try:
        foo
    except NameError:
        exception = get_exception()
        assert isinstance(exception, NameError)
    else:
        exception = None
        assert False


# Unit tests for literal_eval

# Generated at 2022-06-23 02:50:39.397557
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Bad mojo')
    except RuntimeError:
        assert get_exception()

# Generated at 2022-06-23 02:50:42.915514
# Unit test for function get_exception

# Generated at 2022-06-23 02:50:45.102398
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('example exception')
    except ValueError:
        exc = get_exception()
    assert exc.args[0] == 'example exception'

# Generated at 2022-06-23 02:50:48.020094
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test exception")
    except:
        assert get_exception()



# Generated at 2022-06-23 02:50:50.334987
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)

# Generated at 2022-06-23 02:50:56.639330
# Unit test for function get_exception
def test_get_exception():
    try:
        exec("raise SyntaxError('just testing')")
    except SyntaxError as e:
        # This should raise a SyntaxError.  The comparison below will work
        # if we get the right exception type.
        assert True
        assert get_exception() == e


# Generated at 2022-06-23 02:50:59.305993
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('error')
    except:
        e = get_exception()
    assert 'error' in str(e)


# Generated at 2022-06-23 02:51:02.846018
# Unit test for function get_exception
def test_get_exception():
    try:
        1 // 0
    except ZeroDivisionError as e:
        if get_exception() is not e:
            raise
    else:
        raise AssertionError("Nothing raised")

# Generated at 2022-06-23 02:51:07.568102
# Unit test for function get_exception
def test_get_exception():
    """Make a try/catch block, raise an exception in the except block,
    and check that the current exception is correctly retrieved.
    """
    try:
        raise ValueError('Test')
    except Exception:
        e = get_exception()
        assert e.args == ('Test',), "get_exception() didn't return the right exception"

# Generated at 2022-06-23 02:51:13.089904
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('hello')
    except Exception:
        # Make sure we get the current exception
        assert sys.exc_info() ==  sys.exc_info()
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'hello'

# Generated at 2022-06-23 02:51:17.060100
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()
        assert type(e) == RuntimeError



# Generated at 2022-06-23 02:51:21.406824
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'test exception'
    assert repr(e) == 'RuntimeError("test exception",)'


# Generated at 2022-06-23 02:51:30.331372
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is an exception")
    except ValueError:
        e = get_exception()
        assert e.__str__() == "This is an exception"

    try:
        raise ValueError("This is another exception")
    except ValueError:
        e = get_exception()
        assert e.__str__() == "This is another exception"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:51:36.439829
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
        assert type(e) is ZeroDivisionError
        assert str(e) == 'integer division or modulo by zero'


# Generated at 2022-06-23 02:51:41.295290
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert 'foo' in str(e)

# Generated at 2022-06-23 02:51:42.693047
# Unit test for function get_exception
def test_get_exception():
    """Sanity check get_exception"""
    try:
        raise Exception
    except Exception as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:51:47.044656
# Unit test for function get_exception
def test_get_exception():
    import io
    try:
        io.open('/doesnotexist', 'r')
    except IOError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:51:52.643981
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException()
    except:
        e = get_exception()

    assert isinstance(e, MyException)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:51:56.437789
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Here's an exception")
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.message == "Here's an exception"



# Generated at 2022-06-23 02:52:01.803146
# Unit test for function get_exception
def test_get_exception():
    """Test getting the current exception

    We can't really test the functionality since it's the exception that's
    caught by the unit test harness.  But we can test that the syntax is
    valid.
    """
    try:
        foo = bar
    except:
        get_exception()

# Generated at 2022-06-23 02:52:03.630868
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-23 02:52:11.211831
# Unit test for function get_exception
def test_get_exception():
    class ExceptionToRaise(Exception):
        pass

# Generated at 2022-06-23 02:52:14.356947
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('foo')
    except TestException:
        e = get_exception()
    assert isinstance(e, TestException)
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:52:17.685115
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('get_exception test')
    except:
        exception_inst = get_exception()
    assert 'get_exception test' == str(exception_inst)


# Generated at 2022-06-23 02:52:22.704310
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    def test_function():
        try:
            raise TestException('This is a test')
        except TestException:
            tb = get_exception()
            assert tb.args == ('This is a test',)
            assert type(tb) is TestException
    test_function()



# Generated at 2022-06-23 02:52:27.147944
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('foo')
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)
        assert e.args == ('foo',)


# Generated at 2022-06-23 02:52:32.773857
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception"""
    def _test():
        """Test that get_exception returns the correct object"""
        # pylint: disable=unused-variable
        obj = object()
        try:
            raise obj
        except Exception:
            e = get_exception()
            if id(e) == id(obj):
                return True
            else:
                raise
        return False

    assert _test()

# Generated at 2022-06-23 02:52:35.943158
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)

    try:
        raise ValueError()
    except ValueError as e:
        pass
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:52:40.717314
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-23 02:52:48.062907
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import sys

    class TestException(Exception):
        pass

    class TestGetException(unittest.TestCase):
        def test_exclude_exception(self):
            try:
                raise TestException("Test")
            except TestException as e:
                self.assertEqual(get_exception(), e)
                self.assertEqual(get_exception(), sys.exc_info()[1])

    unittest.main()

# Generated at 2022-06-23 02:52:50.272468
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception actually works
    try:
        raise Exception("Test exception")
    except Exception:
        assert(get_exception() == "Test exception")



# Generated at 2022-06-23 02:52:54.945975
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test")
    except:
        e = get_exception()
        assert e.args[0] == "Test"


# Generated at 2022-06-23 02:52:58.726490
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__ is ZeroDivisionError
    else:
        assert False, 'ZeroDivisionError should have been raised'


# Generated at 2022-06-23 02:53:03.767717
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise ValueError('test')

    try:
        test()
    except Exception as e:
        pass
    else:
        assert False, 'Did not raise'
    assert get_exception()  == e

# Generated at 2022-06-23 02:53:11.665477
# Unit test for function get_exception
def test_get_exception():
    # Test 1: Test that an exception is returned
    try:
        raise RuntimeError("test")
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)

    # Test 2: Make sure that we can return the exception if using a
    # different exception
    try:
        raise ValueError("test2")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:53:14.296779
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('My Message')
    except Exception:
        e = get_exception()
        assert str(e) == 'My Message'


# Generated at 2022-06-23 02:53:16.757787
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo bar')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo bar'

# Generated at 2022-06-23 02:53:22.961331
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == "Test exception"
        assert repr(e) == "Exception('Test exception',)"
    else:
        raise Exception("Failed to get exception")



# Generated at 2022-06-23 02:53:26.604901
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert type(e) is ValueError
    assert str(e) == 'foo'



# Generated at 2022-06-23 02:53:28.102602
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo', e.args

# Generated at 2022-06-23 02:53:37.787471
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule
    # There are three kinds of exceptions -- Python builtin exceptions,
    # user raised exceptions, and module generated exceptions.  We
    # need to make sure that we find the right one and can set the
    # exception message.
    with AnsibleModule(argument_spec=dict()) as am:
        try:
            raise Exception('test exception')
        except Exception:
            e = get_exception()
            am.fail_json(msg=str(e))
        try:
            raise TypeError('test type error')
        except TypeError:
            e = get_exception()
            am.fail_json(msg=str(e))
        try:
            am.fail_json(msg='test am.fail_json')
        except TypeError:
            e = get_ex

# Generated at 2022-06-23 02:53:40.040957
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exception = get_exception()
    assert exception.args == ('foo',)

# Generated at 2022-06-23 02:53:43.830468
# Unit test for function get_exception
def test_get_exception():
    # This should not raise an exception.  If it does then we have a problem with
    # get_exception
    try:
        try:
            raise IndexError()
        except Exception:
            get_exception()
    except Exception:
        raise AssertionError("get_exception() cannot get an exception")



# Generated at 2022-06-23 02:53:50.601209
# Unit test for function get_exception
def test_get_exception():
    try:
        some_undefined_variable
        __tracebackhide__ = True # pylint: disable=anomalous-backslash-in-string
        raise AssertionError("Shouldn't get here")
    except:
        e = get_exception()
    assert hasattr(e, 'args')
    assert e.args[0] == "name 'some_undefined_variable' is not defined"



# Generated at 2022-06-23 02:53:53.983525
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("An error")
    except RuntimeError:
        exc = get_exception()
        assert str(exc) == "An error"


# Generated at 2022-06-23 02:53:56.885681
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test_get_exception")
    except:
        e = get_exception()
        assert str(e) == "test_get_exception"
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:54:03.752555
# Unit test for function get_exception
def test_get_exception():
    def a():
        def b():
            def c():
                def d():
                    def e():
                        def f():
                            def g():
                                def h():
                                    def i():
                                        raise RuntimeError
                                        try:
                                            i()
                                        except Exception:
                                            exception = get_exception()
                                            assert type(exception) == RuntimeError
                                            return exception
                                    return h()
                                return g()
                            return f()
                        return e()
                    return d()
                return c()
            return b()
        return a()

# Generated at 2022-06-23 02:54:06.811611
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        e = get_exception()
        assert e.args == ('Foo',)


# Generated at 2022-06-23 02:54:14.026584
# Unit test for function get_exception
def test_get_exception():

    try:
        x = unknown
    except NameError as e:
        assert e == get_exception()
        assert repr(e) == "NameError('name 'unknown' is not defined',)"
    else:
        assert False, "expected exception"

    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()
        assert repr(e) == "ValueError('foo',)"
    else:
        assert False, "expected exception"

# Generated at 2022-06-23 02:54:18.568750
# Unit test for function get_exception
def test_get_exception():
    def divide(a, b):
        return a / b
    try:
        divide(1, 0)
    except:
        exc = get_exception()

    assert isinstance(exc, ZeroDivisionError)
    assert unicode(exc) == u'integer division or modulo by zero'



# Generated at 2022-06-23 02:54:21.465999
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        if get_exception() is None:
            raise AssertionError('get_exception() should not return None')

# Generated at 2022-06-23 02:54:23.462532
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import PY3

    try:
        raise RuntimeError("this is a test exception")
    except RuntimeError:
        if PY3:
            assert str(get_exception()) == "'this is a test exception'"
        else:
            assert str(get_exception()) == "this is a test exception"


# Generated at 2022-06-23 02:54:27.189294
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("This is a test of get_exception")
    except TypeError:
        e = get_exception()
        assert str(e) == "This is a test of get_exception"


# Generated at 2022-06-23 02:54:36.217019
# Unit test for function get_exception
def test_get_exception():
    """Test that the get_exception() function returns the expected value."""
    def inner_exception_test(func, arg_list, exc_type, exc_value):
        for arg in arg_list:
            try:
                func(arg)
            except Exception:
                e = get_exception()
                assert not isinstance(e, exc_type), ('get_exception() failed to return exception:'
                                                     '\nExpected: %s\nGot: %s\n' % (exc_value, e))
                break
            else:
                raise AssertionError('%s not raised' % exc_value)

    def inner_nested_exception_test(func, arg_list, exc_value):
        """Test nested exceptions."""

# Generated at 2022-06-23 02:54:47.069481
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    # The get_exception() function is used inside the except block to
    # make sure we get the right exception
    try:
        raise ValueError('blah')
    except:
        e = get_exception()
        assert e.args[0] == 'blah'
        assert 'ValueError' in str(e)
        assert 'test_utils.test_get_exception()' in str(e)

    try:
        raise TypeError
    except:
        e = get_exception()
        assert not e.args
        assert 'TypeError' in str(e)
        assert 'test_utils.test_get_exception()' in str(e)



# Generated at 2022-06-23 02:54:50.558743
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo bar')
    except RuntimeError as e:
        assert get_exception() == e
    try:
        raise RuntimeError('foo bar')
    except RuntimeError:
        assert get_exception()

# Generated at 2022-06-23 02:54:54.287162
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass

    def getfailed():
        raise CustomException("Expected failure")

    try:
        getfailed()
    except Exception:
        e = get_exception()
    assert isinstance(e, CustomException)
    assert str(e) == "Expected failure"


# Generated at 2022-06-23 02:54:57.001119
# Unit test for function get_exception
def test_get_exception():
    def raise_exc(exc):
        raise exc

    try:
        raise_exc(TypeError)
    except:
        exc = get_exception()
    assert(isinstance(exc, TypeError))



# Generated at 2022-06-23 02:55:03.287321
# Unit test for function get_exception
def test_get_exception():
        old_exception = get_exception()
        try:
            raise Exception('new exception')
        except Exception:
            new_exception = get_exception()
            assert old_exception is not new_exception
            assert str(new_exception) == 'new exception'

