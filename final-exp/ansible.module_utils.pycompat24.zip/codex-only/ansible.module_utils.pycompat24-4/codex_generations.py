

# Generated at 2022-06-23 02:45:04.502359
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('key')
    except:
        e = get_exception()

    if isinstance(e, KeyError) and str(e) == 'key':
        print('get_exception() works')
    else:
        print('get_exception() does not work')

# Generated at 2022-06-23 02:45:12.238978
# Unit test for function get_exception
def test_get_exception():
    import six
    import traceback

    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        # Ensure we get the same exception back
        assert e is get_exception()
        assert str(e) == 'foo'
        assert six.text_type(e) == u'foo'
        assert getattr(e, '__str__', None) != getattr(e, '__unicode__', None)
        assert b'foo' in traceback.format_exception(type(e), e, None)

    try:
        raise Exception('bar')
    except Exception:
        # Each exception is different
        e = get_exception()
        assert str(e) == 'bar'
        assert six.text_type(e) == u'bar'

# Generated at 2022-06-23 02:45:15.123337
# Unit test for function get_exception
def test_get_exception():
    """Verify get exception returns the current exception"""
    try:
        raise Exception('Test exception')
    except Exception:
        exc = get_exception()
        assert exc.args == ('Test exception',)

# Generated at 2022-06-23 02:45:19.009899
# Unit test for function get_exception
def test_get_exception():
    def f():
        """Function to test get_exception"""
        raise Exception('Test')

    try:
        f()
    except Exception:
        assert get_exception()
    else:
        assert not "get_exception does not work"


# Generated at 2022-06-23 02:45:23.107438
# Unit test for function get_exception
def test_get_exception():
    try:
        int('bogus')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ("invalid literal for int() with base 10: 'bogus'",)


# Generated at 2022-06-23 02:45:26.808809
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 + 'foo'
    except Exception:
        e = get_exception()
        assert str(e) == "unsupported operand type(s) for +: 'int' and 'str'"
    else:
        raise Exception("Shouldn't get here")



# Generated at 2022-06-23 02:45:31.025055
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:45:34.791263
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is the message")
    except:
        assert get_exception().message == "This is the message"


# Generated at 2022-06-23 02:45:37.244237
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Testing exception")
    except:
        e = get_exception()
        assert (str(e) == "Testing exception")

# Generated at 2022-06-23 02:45:39.589751
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)



# Generated at 2022-06-23 02:45:43.072242
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0  # noqa
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
    else:
        assert False, "ZeroDivisionError was not raised"


# Generated at 2022-06-23 02:45:47.976690
# Unit test for function get_exception
def test_get_exception():
    def test1():
        try:
            raise ValueError('1')
        except Exception:
            return get_exception()

    def test2():
        return get_exception()

    assert test1().args == ('1',)
    try:
        test2()
        raise AssertionError('Did not raise an exception')
    except Exception:
        pass

# Generated at 2022-06-23 02:45:50.165298
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
    assert e.args[0] == 'test'


# Generated at 2022-06-23 02:45:51.971118
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        assert get_exception().args[0] == 'foo'

# Generated at 2022-06-23 02:45:57.166851
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('frodo')
    except NameError:
        e = get_exception()
    assert str(e) == 'frodo'
    try:
        exec('print(')
    except SyntaxError:
        e = get_exception()
    assert str(e).startswith('invalid syntax')

# Generated at 2022-06-23 02:45:59.976123
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()
        assert e.args == ("test exception", )


# Generated at 2022-06-23 02:46:09.434241
# Unit test for function get_exception
def test_get_exception():
    def cause_exception():
        try:
            raise ValueError('42')
        except Exception:
            return get_exception()
    assert cause_exception().args[0] == '42'

    def cause_exception2():
        try:
            raise ValueError('42')
        except:
            return get_exception()
    assert cause_exception2().args[0] == '42'


# These tests were taken from https://hg.python.org/cpython/file/2.7/Lib/test/test_ast.py
# and modified to suit python 2.4's compiler module

# Generated at 2022-06-23 02:46:21.681495
# Unit test for function get_exception
def test_get_exception():

    import sys
    import traceback

    def test_function(a):
        if a == 0:
            raise ValueError("oops")

    try:
        test_function(0)
    except:
        try:
            e = get_exception()
            if e.__class__ != ValueError:
                raise AssertionError("get_exception didn't return the last exception")
        finally:
            del e

    try:
        test_function(1)
    except:
        try:
            e = get_exception()
            tb = sys.exc_info()[2]
            raise AssertionError("get_exception returned an exception with no traceback: %s" % (traceback.format_exception(e.__class__, e, tb), ))
        finally:
            del e


# Generated at 2022-06-23 02:46:25.812402
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('test exception',)

# Generated at 2022-06-23 02:46:29.250321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('test')
    except NameError:
        e = get_exception()
    assert isinstance(e, NameError)
    assert str(e) == 'test'

# Generated at 2022-06-23 02:46:35.506068
# Unit test for function get_exception
def test_get_exception():
    # Also a test for the syntax error handling at the top of this file
    # Should raise NameError because the exception doesn't exist
    def foo():
        raise Bar
    try:
        foo()
    except:
        e = get_exception()
    assert(isinstance(e, NameError))
    assert(not isinstance(e, Bar))
    assert(e.args == ("name 'Bar' is not defined",))

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:46:41.336492
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        assert isinstance(get_exception(), ZeroDivisionError)


# Generated at 2022-06-23 02:46:46.905179
# Unit test for function get_exception
def test_get_exception():
    # Test the case that no exception is raised
    try:
        get_exception()
        assert False
    except:
        assert False

    # Test the case where an exception is raised
    try:
        raise ValueError('some test exception')
    except:
        actual = get_exception()
    expected = ValueError('some test exception')
    assert actual == expected



# Generated at 2022-06-23 02:46:52.282640
# Unit test for function get_exception
def test_get_exception():
    def test():
        class Foo(Exception):
            pass
        try:
            raise Foo('test')
        except:
            assert get_exception()
            assert get_exception().args[0] == 'test'  # pylint: disable=no-member
    test()

# Generated at 2022-06-23 02:47:01.967315
# Unit test for function get_exception
def test_get_exception():
    # Test the most basic use case
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert e is not None, "get_exception failed to retrieve exception"

    # Test a non-basic use case: call another function that raises an
    # exception
    def foo():
        raise Exception()
    try:
        foo()
    except Exception:
        e = get_exception()
    assert e is not None, "get_exception failed to retrieve exception raised in other function"

    # Test the innermost exception in chained exceptions
    try:
        try:
            raise Exception()
        except Exception:
            raise Exception()
    except Exception:
        e = get_exception()
    assert 'Exception' in str(e)

    # Test get_exception to see it will not retrieve exceptions


# Generated at 2022-06-23 02:47:07.473155
# Unit test for function get_exception
def test_get_exception():
    is_python2 = sys.version_info[0] == 2
    if is_python2:
        import __builtin__ as builtins
    else:
        import builtins
    try:
        builtins.raise_an_exception
    except AttributeError:
        pass
    else:
        raise AssertionError('raise_an_exception should not exist')
    try:
        raise_an_exception()
    except NameError as e:
        pass
    else:
        raise AssertionError('Should have raised a NameError')
    exc = get_exception()
    if is_python2:
        assert type(exc) is NameError
    else:
        assert type(exc) is NameError
        assert exc.__class__ is NameError

# Generated at 2022-06-23 02:47:11.979836
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise RuntimeError('I am an exception!')

    try:
        raise_exception()
    except: # pylint: disable=bare-except
        e = get_exception()

    assert isinstance(e, RuntimeError)
    assert str(e) == 'I am an exception!'

# Generated at 2022-06-23 02:47:14.696286
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-23 02:47:25.523601
# Unit test for function get_exception
def test_get_exception():

    # Get exception that is set normally
    try:
        raise ValueError()
    except ValueError:
        value_error = get_exception()
        assert value_error is not None
        assert isinstance(value_error, ValueError)

    # Get exception that is set via chained exceptions
    try:
        try:
            raise ValueError()
        except ValueError:
            raise TypeError()
    except TypeError:
        type_error = get_exception()
        assert type_error is not None
        assert isinstance(type_error, TypeError)

    # Get exception that was cleared by a prior exception handler

# Generated at 2022-06-23 02:47:28.897897
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test")
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)
    assert str(e) == "Test"



# Generated at 2022-06-23 02:47:31.578749
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError as e:
        assert e is get_exception()


# Generated at 2022-06-23 02:47:36.233368
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        foo = 0
        raise MyException
    except Exception:
        e = get_exception()
    assert isinstance(e, MyException)

# Generated at 2022-06-23 02:47:40.576933
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        assert ValueError == get_exception().__class__


# Generated at 2022-06-23 02:47:46.480788
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    class MyException2(MyException):
        pass
    try:
        raise MyException()
    except:
        exception = get_exception()
    assert isinstance(exception, MyException)
    try:
        raise MyException2()
    except:
        exception = get_exception()
    assert isinstance(exception, MyException)
    assert isinstance(exception, MyException2)

# Generated at 2022-06-23 02:47:53.032370
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert e.args == ('foo', )
    # pylint: disable=bare-except
    except:
        assert False, 'get_exception loop failed'

# Generated at 2022-06-23 02:47:55.193757
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-23 02:47:58.332717
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test_get_exception')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('test_get_exception',)

# Generated at 2022-06-23 02:48:05.032032
# Unit test for function get_exception
def test_get_exception():
    # Test two different ways of raising an exception
    try:
        raise ValueError
    except Exception:
        e = get_exception()
        assert type(e) is ValueError

    try:
        raise ValueError('Test exception')
    except Exception:
        e = get_exception()
        assert type(e) is ValueError
        assert e.args == ('Test exception',)


# Generated at 2022-06-23 02:48:09.022705
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('hi')
    except Exception:
        e = get_exception()
    return e


# Generated at 2022-06-23 02:48:11.704152
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:48:13.683050
# Unit test for function get_exception
def test_get_exception():

    def method():
        try:
            raise Exception('test')
        except Exception:
            e = get_exception()
            assert e.args[0] == 'test'
            assert str(e) == 'test'

    method()


# Generated at 2022-06-23 02:48:18.298981
# Unit test for function get_exception
def test_get_exception():
    """Verify that get_exception works correctly.

    It's hard to test directly that get_exception works correctly because there's
    no way to raise an exception directly from within the module.
    :returns: True if get_exception worked correctly, False if there was a failure
    :rtype: bool
    """
    try:
        print(__file__)
    except:
        if get_exception():
            return True
        return False

# Generated at 2022-06-23 02:48:20.915775
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        return get_exception()



# Generated at 2022-06-23 02:48:35.487526
# Unit test for function get_exception
def test_get_exception():
    """This is a test function for get_exception()."""
    # pylint: disable=unused-argument, redefined-outer-name
    #         function appears unused, but it's needed to cause a test failure
    def function(first_arg, second_arg, third_arg):
        """This is a test function for get_exception()."""
        # pylint: disable=invalid-name, redefined-outer-name,
        #         expression-not-assigned
        #         None of these are illegal
        bool(first_arg + second_arg)
        bool(first_arg + third_arg)

    function(3, 4, True)


# from python 2.7: subprocess.py, subprocess.check_output
# all hail to the Python Gods

# Generated at 2022-06-23 02:48:39.128998
# Unit test for function get_exception
def test_get_exception():
    try:
        this_should_raise()
    except NameError as e:
        exc = get_exception()
        assert e.args == exc.args

# Generated at 2022-06-23 02:48:45.108411
# Unit test for function get_exception
def test_get_exception():
    def f(x):
        raise ValueError('Invalid')

    def test():
        try:
            f(1)
        except:
            return get_exception()

    assert isinstance(test(), ValueError)

# Generated at 2022-06-23 02:48:47.195497
# Unit test for function get_exception
def test_get_exception():
    try:
        foo = bar
        assert False, 'foo and bar are not defined, this line should not be reached.'
    except NameError:
        assert True

# Generated at 2022-06-23 02:48:50.078468
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:48:53.661346
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        import types
        x = get_exception()
        assert isinstance(x, ValueError)
        assert type(x) is not types.InstanceType


# Generated at 2022-06-23 02:48:57.301408
# Unit test for function get_exception
def test_get_exception():

    class TestException(Exception):
        pass

    try:
        raise TestException('TEST EXCEPTION')
    except TestException:
        e = get_exception()
        assert e.args == ('TEST EXCEPTION',)

# Generated at 2022-06-23 02:49:00.208290
# Unit test for function get_exception
def test_get_exception():
    class TestError(Exception):
        pass
    try:
        raise TestError()
    except TestError:
        e = get_exception()
        assert isinstance(e, TestError)



# Generated at 2022-06-23 02:49:03.087924
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except:
        e = get_exception()

    assert e.args and e.args[0] == 'test'

# Generated at 2022-06-23 02:49:07.280901
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('error 1')
    except ValueError as e:
        try:
            raise ValueError('error 2')
        except ValueError:
            e2 = get_exception()
            assert e2.args == ('error 2',)
    assert e.args == ('error 1',)

# Generated at 2022-06-23 02:49:11.684382
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:14.305315
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bad')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'bad'


# Generated at 2022-06-23 02:49:18.488096
# Unit test for function get_exception
def test_get_exception():
    class Foo(Exception):
        pass

    try:
        raise Foo('Test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Foo)
    assert str(e) == 'Test exception'


# Generated at 2022-06-23 02:49:25.005774
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Exception for unit test")
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'Exception for unit test'
    try:
        raise IndexError("Exception for unit test")
    except IndexError:
        e = get_exception()
        assert isinstance(e, IndexError)
        assert str(e) == 'Exception for unit test'

# Generated at 2022-06-23 02:49:30.501884
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'Test'
        assert exc.__class__.__name__ == 'Exception'


# Generated at 2022-06-23 02:49:32.968434
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a')
    except ValueError:
        e = get_exception()
    assert e.args == ('a',)

# Generated at 2022-06-23 02:49:41.640587
# Unit test for function get_exception
def test_get_exception():
    # No exception raised
    try:
        get_exception()
        assert False, 'get_exception() should raise'
    except ValueError:
        pass

    # Exception raised
    def raise_exception():
        try:
            raise ValueError('this is the exception')
        except ValueError:
            ret = get_exception()
        return ret

    ret = raise_exception()
    assert ret.args == ('this is the exception',), 'get_exception() returned wrong exception'



# Generated at 2022-06-23 02:49:44.796930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Hello")
    except Exception:
        e = get_exception()
    assert str(e) == "Hello"


# Generated at 2022-06-23 02:49:48.330742
# Unit test for function get_exception
def test_get_exception():
    e = RuntimeError('foo')
    try:
        raise e
    except RuntimeError:
        e2 = get_exception()
    assert e2 is e


# Generated at 2022-06-23 02:49:51.507558
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()
    assert type(e) is ValueError
    assert e.args[0] == 'test'


# Generated at 2022-06-23 02:49:53.510517
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:50:02.598048
# Unit test for function get_exception
def test_get_exception():
    # Test for the general case
    try:
        raise Exception('test')
    except Exception as e:
        e2 = get_exception()
    assert type(e) is type(e2)
    assert e.args == e2.args

    # Test that *args still works
    try:
        raise Exception('test2', 'test3')
    except Exception as e:
        e2 = get_exception()
    assert type(e) is type(e2)
    assert e.args == e2.args

    # Test that **kwargs still works
    try:
        raise Exception(argname='testkwarg')
    except Exception as e:
        e2 = get_exception()
    assert type(e) is type(e2)
    assert e.args == e2.args
    assert e.argname

# Generated at 2022-06-23 02:50:05.316934
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert e.__class__.__name__ == 'ZeroDivisionError'

# Generated at 2022-06-23 02:50:13.255154
# Unit test for function get_exception
def test_get_exception():
    """
    Test that get_exception() handles the various forms of exceptions that python can
    throw.
    """

    # Test exceptions defined by python
    class PythonException(Exception):
        pass

    class PythonExceptionSubclass(PythonException):
        pass

    # Test exceptions defined by a third party library
    class ThirdPartyException(object):
        pass

    class ThirdPartyExceptionSubclass(ThirdPartyException):
        pass

    # Test exceptions defined by the module under test
    class AnsibleException(Exception):
        pass

    class AnsibleExceptionSubclass(AnsibleException):
        pass

    # Test exceptions defined by the unit test
    class UnitTestException(object):
        pass

    class UnitTestExceptionSubclass(UnitTestException):
        pass

    # Test a string exception
    StringException = 'foo'


# Generated at 2022-06-23 02:50:16.164824
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert exc.args == ('foo',)

# Generated at 2022-06-23 02:50:18.739961
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception')
    except Exception:
        e = get_exception()
        assert 'An exception' in str(e)

# Generated at 2022-06-23 02:50:22.793754
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'foo'

# Generated at 2022-06-23 02:50:29.469697
# Unit test for function get_exception
def test_get_exception():
    exception = get_exception()
    print("exception = {0}".format(exception))
    # That will print:
    # exception = None
    raise RuntimeError("exception")
    exception = get_exception()
    print("exception = {0}".format(exception))
    # That will print:
    # exception = RuntimeError('exception')


# Generated at 2022-06-23 02:50:32.665142
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert get_exception()


# Generated at 2022-06-23 02:50:35.763910
# Unit test for function get_exception
def test_get_exception():
    def _expect(value):
        try:
            raise KeyError(value)
        except KeyError as e:
            assert e == get_exception()
    _expect('foo')
    _expect(1)

# Generated at 2022-06-23 02:50:38.946639
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        exc = get_exception()
    assert exc.args == ('test exception',)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 02:50:42.056645
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Bang!')
    except Exception:
        e = get_exception()

    # Check the correct exception is captured
    assert str(e) == 'Bang!'


# Generated at 2022-06-23 02:50:47.544030
# Unit test for function get_exception
def test_get_exception():

    class E(Exception):  # pylint: disable=too-few-public-methods
        def __init__(self, message):
            super(E, self).__init__(message)
            self.message = message

    try:
        raise E('hello world')
    except E:
        e = get_exception()
        assert e.message == 'hello world'
        assert str(e) == 'hello world'
        assert repr(e) == 'hello world'

# Generated at 2022-06-23 02:50:55.767740
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('nope')
    except:
        e = get_exception()
        assert str(e) == 'nope'

if __name__ == '__main__':
    for test in [m for m in dir(sys.modules[__name__]) if m.startswith('test_')]:
        getattr(sys.modules[__name__], test)()

# Generated at 2022-06-23 02:51:00.754082
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test exception'


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-23 02:51:03.808751
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert 'Test exception' in str(e)


# Generated at 2022-06-23 02:51:07.669580
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError as e:
        ex = get_exception()
        assert e is ex, '%r vs %r' % (e, ex)
    else:
        raise AssertionError('Should have raised an exception')

# Generated at 2022-06-23 02:51:09.824210
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo message')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo message'

# Generated at 2022-06-23 02:51:15.406705
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTests(unittest.TestCase):
        def test_get_exception(self):
            try:
                1 / 0
            except ZeroDivisionError:
                e = get_exception()
            self.assertEqual(e.__class__.__name__, 'ZeroDivisionError')

    suite = unittest.TestLoader().loadTestsFromTestCase(GetExceptionTests)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 02:51:17.302520
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:51:27.958024
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is the value")
    except:
        e = get_exception()

    assert e.args == ('This is the value',), \
        "get_exception does not return expected exception.  Found: {0}".format(e)
    assert e.__class__ is ValueError, \
        "get_exception does not return the exception class.  Found: {0}".format(e.__class__)

    try:
        try:
            raise ValueError("This is a value")
        except:
            e = get_exception()
            raise ValueError("This is another value")
    except:
        e = get_exception()


# Generated at 2022-06-23 02:51:33.811237
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise NameError('foo')
    try:
        test()
    except NameError as e:
        assert get_exception() == e


# Generated at 2022-06-23 02:51:36.174973
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IOError('File not found')
    except IOError:
        e = get_exception()
    assert e.args == ('File not found',)

# Generated at 2022-06-23 02:51:41.513442
# Unit test for function get_exception
def test_get_exception():
    try:
        int('q')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:51:43.794093
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('serious problem')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)

# Generated at 2022-06-23 02:51:46.953275
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    assert str(e) == 'integer division or modulo by zero'


# Generated at 2022-06-23 02:51:51.691344
# Unit test for function get_exception
def test_get_exception():
    def f(x):
        raise ValueError("test")
    try:
        f(42)
    except:
        e = get_exception()
    assert e.args == ('test', )



# Generated at 2022-06-23 02:51:55.711716
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert repr(e) == repr(get_exception())
    else:
        assert False, 'get_exception() did not get the exception'



# Generated at 2022-06-23 02:51:59.237633
# Unit test for function get_exception
def test_get_exception():
    '''Test function get_exception'''
    try:
        'foo'.index('t')
    except ValueError as e:
        pass
    assert get_exception() is e

# Generated at 2022-06-23 02:52:02.415198
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:52:05.393507
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Test Error')
    except Exception:
        error = get_exception()
    assert isinstance(error, TypeError), error


# Generated at 2022-06-23 02:52:07.728772
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test exception'

# Generated at 2022-06-23 02:52:10.476704
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'This is an exception'

# Generated at 2022-06-23 02:52:13.111761
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except:
        ret = get_exception()
    assert type(ret) == Exception

# Generated at 2022-06-23 02:52:17.967006
# Unit test for function get_exception
def test_get_exception():
    # Note: this is not a unit test that can be run directly.  It can only
    # be called from a unit test.

    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:52:21.703914
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except:
        exc = get_exception()
    assert exc.__class__ is RuntimeError
    assert exc.args[0] == 'test'
    assert exc.args[1:] == ()



# Generated at 2022-06-23 02:52:27.035489
# Unit test for function get_exception
def test_get_exception():
    def f1():
        try:
            raise Exception('the error')
        except Exception:
            e1 = get_exception()
        return e1
    e1 = f1()
    assert isinstance(e1, Exception)
    assert e1.args == ('the error',)



# Generated at 2022-06-23 02:52:29.290755
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Unit test")
    except Exception:
        e = get_exception()
    assert str(e) == "Unit test"

# Generated at 2022-06-23 02:52:37.765477
# Unit test for function get_exception
def test_get_exception():
    try:
        # Try to cause an exception to be raised.  Let's ask for a non-existent
        # module.
        import i_dont_exist
        # If this next line runs, we've failed to raise an exception
        raise Exception("Couldn't raise an exception")
    except:
        # We don't know what exception we're getting.  If we try to catch it with
        # a named exception, the test will still succeed if we're not getting the
        # named exception.  Let's use the utility function to get the exception.
        e = get_exception()
        # Now we can do what we want with the exception
        assert "i_dont_exist" in str(e)
        assert isinstance(e, ImportError)
        return True

# Generated at 2022-06-23 02:52:41.209748
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('testing')
    except RuntimeError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:52:44.604803
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()

    assert e.__class__ is Exception
    assert e.args == ()

# Generated at 2022-06-23 02:52:47.100708
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        e = get_exception()
        assert(str(e) == 'Test exception')


# Generated at 2022-06-23 02:52:51.636440
# Unit test for function get_exception

# Generated at 2022-06-23 02:52:57.614553
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        """Exception class for testing get_exception"""

    try:
        raise MyException("test exception")
    except Exception:
        e = get_exception()
    assert e.__class__ == MyException
    assert str(e) == 'test exception'

# Generated at 2022-06-23 02:53:00.196889
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('test')
    except AssertionError:
        assert get_exception()

# Generated at 2022-06-23 02:53:07.449289
# Unit test for function get_exception
def test_get_exception():

    # The following try...except is stolen from the Python's stdlib's tests/test_import.py
    # It is a very good way to check that get_exception() is working.
    def raises(exc, obj, msg=None):
        try:
            obj
        except exc as detail:
            if msg is not None and msg != str(detail):
                raise AssertionError("%s != %s" % (msg, detail))
        else:
            if hasattr(exc, '__name__'): excName = exc.__name__
            else: excName = str(exc)
            raise AssertionError("%s not raised" % excName)

    raises(ImportError,
           get_exception(),
           ("expected ImportError, got none"))

# Generated at 2022-06-23 02:53:09.592530
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    try:
        raise ValueError('test')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:53:14.075828
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foo')
    except:
        e = get_exception()

    assert(e)
    assert(isinstance(e, ValueError))
    assert(e.args[0] == 'Foo')

# Generated at 2022-06-23 02:53:17.217643
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Something happened")
    except Exception:
        e = get_exception()

    assert str(e) == 'Something happened', \
            "get_exception() returned %r instead of 'Something happened'" % e

# Generated at 2022-06-23 02:53:26.087675
# Unit test for function get_exception
def test_get_exception():
    """
    >>> import traceback

    >>> try:
    ...   raise Exception()
    ... except Exception:
    ...   t, v, tb = sys.exc_info()
    ...   formatted_tb = traceback.extract_tb(tb)
    >>> t
    <type 'exceptions.Exception'>
    >>> v
    <Exception instance at 0x...)>
    >>> formatted_tb[-1][2] == 'get_exception'
    True
    >>> get_exception()
    <Exception instance at 0x...)>
    """



# Generated at 2022-06-23 02:53:28.916392
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise RuntimeError("to be captured")
        except Exception:
            e = get_exception()
            assert "to be captured" in str(e), "exception message is not present in the captured exception: %s" % str(e)

    foo()

# Generated at 2022-06-23 02:53:34.065619
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('an exception')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'an exception'
    else:
        assert False  # pragma: no cover



# Generated at 2022-06-23 02:53:38.151018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'foo'
    assert e.args == ('foo',)



# Generated at 2022-06-23 02:53:42.833210
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=too-many-branches
    try:
        try:
            raise ValueError('Nested')
        except Exception:  # pylint: disable=broad-except
            e = get_exception()
            if not isinstance(e, ValueError):
                raise Exception('Did not get ValueError exception, but %s' % type(e))
            if str(e) != 'Nested':
                raise Exception('Did not get exception with text "Nested", but "%s"' % str(e))
    except Exception:  # pylint: disable=broad-except
        e = get_exception()
        if not isinstance(e, Exception):
            raise Exception('Did not get Exception exception, but %s' % type(e))
    finally:
        e = get_exception()

# Generated at 2022-06-23 02:53:44.360463
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise Exception('test')
        except Exception:
            e = get_exception()
    test()

# Generated at 2022-06-23 02:53:48.213174
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
    except:
        res = get_exception()

    assert isinstance(res, ValueError)
    assert str(res) == "invalid literal for int() with base 10: 'foo'"

# Generated at 2022-06-23 02:53:55.812615
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test error')
    except:
        exc = get_exception()
        assert exc.args[0] == 'test error'

    try:
        raise RuntimeError('test error', 'another error')
    except:
        exc = get_exception()
        assert exc.args[0] == 'test error'
        assert exc.args[1] == 'another error'
        assert len(exc.args) == 2


# Generated at 2022-06-23 02:53:58.883491
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == 'Test'

# Generated at 2022-06-23 02:54:03.069007
# Unit test for function get_exception
def test_get_exception():
    '''get_exception is working'''
    try:
        1/0
    except:
        a_e = get_exception()
    assert a_e.__class__.__name__ == 'ZeroDivisionError'



# Generated at 2022-06-23 02:54:05.220994
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert e is not None

# Generated at 2022-06-23 02:54:07.603794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError
    except NameError:
        ex = get_exception()
    assert ex.__class__.__name__ == 'NameError'



# Generated at 2022-06-23 02:54:11.139919
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    try:
        raise Exception('Dummy Error')
    except Exception:
        exc = get_exception()
    assert 'Dummy Error' in str(exc)


# Generated at 2022-06-23 02:54:15.878977
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e
    # Test that it works when there is no exception
    try:
        return
    except ValueError as e:
        assert get_exception() is None

# Generated at 2022-06-23 02:54:19.342012
# Unit test for function get_exception
def test_get_exception():
    def bad_function():
        raise TypeError("bad function")

    try:
        bad_function()
    except:
        e = get_exception()

    assert isinstance(e, TypeError)
    assert str(e) == "bad function"



# Generated at 2022-06-23 02:54:23.483226
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test_get_exception")
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == "test_get_exception"

# Generated at 2022-06-23 02:54:25.786714
# Unit test for function get_exception
def test_get_exception():
    """Make sure that get_exception works as expected"""
    try:
        raise NameError('Test exception')
    except NameError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:54:28.834981
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a test')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'a test'

# Generated at 2022-06-23 02:54:31.724850
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('name')
    except NameError as e:
        assert get_exception() is e
        assert get_exception() == e
        assert str(get_exception()) == str(e)

# Generated at 2022-06-23 02:54:33.782342
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception().args[0] == 'foo'

# Generated at 2022-06-23 02:54:38.883916
# Unit test for function get_exception
def test_get_exception():
    try:
        int('hello')
        assert False, 'Int() should throw a ValueError'
    except ValueError:
        assert type(get_exception()) is ValueError


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-23 02:54:45.683362
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 5
        x.foo
    except Exception:
        e = get_exception()
    assert type(e) == AttributeError
    assert e.args[0] == "'int' object has no attribute 'foo'"

    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
    assert type(e) == Exception
    assert e.args[0] == "foo"


# Generated at 2022-06-23 02:54:48.412872
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("raise an exception")
    except Exception:
        e = get_exception()
    assert str(e) == 'raise an exception'



# Generated at 2022-06-23 02:54:51.409270
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Exception test')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args == ('Exception test',)


# Generated at 2022-06-23 02:55:00.347085
# Unit test for function get_exception
def test_get_exception():
    try:
        exec('foo()')
    except NameError:
        assert type(get_exception()) is NameError
    except SyntaxError:
        # Python3 throws a SyntaxError for a foo()
        pass

    try:
        exec('1/0')
    except ZeroDivisionError:
        assert type(get_exception()) is ZeroDivisionError

    try:
        raise ZeroDivisionError
    except ZeroDivisionError:
        assert type(get_exception()) is ZeroDivisionError

