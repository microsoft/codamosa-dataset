

# Generated at 2022-06-23 02:45:05.052615
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'Exception'


# Generated at 2022-06-23 02:45:09.391942
# Unit test for function get_exception
def test_get_exception():
    '''
    Test the get_exception function.
    '''
    def correct_exception():
        '''
        Raise an exception that get_exception should return
        '''
        raise RuntimeError("Get Exception Test")

    try:
        correct_exception()
    except Exception:  # pylint: disable=broad-except
        assert(isinstance(get_exception(), RuntimeError))

# Generated at 2022-06-23 02:45:11.804034
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IndexError
    except IndexError:
        e = get_exception()
    assert isinstance(e, IndexError)

# unit tests for function literal_eval

# Generated at 2022-06-23 02:45:14.388304
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
        assert e.args == ('test',)



# Generated at 2022-06-23 02:45:19.039802
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except Exception:
        e = get_exception()

    assert e.__class__ == ZeroDivisionError


# Generated at 2022-06-23 02:45:24.488761
# Unit test for function get_exception
def test_get_exception():
    # This can't be in a docstring because doctests doesn't like the
    # except Exception syntax
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foobar'

# Generated at 2022-06-23 02:45:26.756482
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('something')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'something'



# Generated at 2022-06-23 02:45:30.985967
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        valueError = get_exception()
    assert valueError.__class__ is ValueError



# Generated at 2022-06-23 02:45:34.740572
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('my exception')
    except Exception:
        assert str(get_exception()) == 'my exception'



# Generated at 2022-06-23 02:45:38.812132
# Unit test for function get_exception
def test_get_exception():
    def method():
        raise ValueError('Test of get_exception')
    try:
        method()
    except:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == 'Test of get_exception'


# Generated at 2022-06-23 02:45:41.754361
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(1)
    except:
        exc = get_exception()

    assert isinstance(exc, ValueError)
    assert exc.args == (1,)

# Generated at 2022-06-23 02:45:45.623727
# Unit test for function get_exception
def test_get_exception():
    call_me = ()

    def caller():
        call_me(1, 2, 3)

    try:
        caller()
    except Exception:
        e = get_exception()
        assert type(e) == TypeError
        print('function get_exception(): assertion passed')



# Generated at 2022-06-23 02:45:54.034215
# Unit test for function get_exception
def test_get_exception():

    class MockException(Exception):
        pass

    class StubModule(object):
        pass

    class StubConnection(object):
        def __init__(self, module):
            self.module = module
            self.called = False

        def exec_command(self, *args, **kwargs):
            self.called = True
            raise MockException("Message")  # pylint: disable=redefined-variable-type

    try:
        raise Exception("Message")
    except Exception as e:
        assert get_exception() is e

    # When executing an Ansible module and the module uses get_exception
    #  the exception raised should be available via the system_warnings
    #  list in the module.
    m = StubModule()
    c = StubConnection(m)

# Generated at 2022-06-23 02:45:59.971805
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        assert get_exception() == e

    def foo():
        try:
            raise Exception('bar')
        except Exception:
            e = get_exception()
            if e.message != 'bar':
                raise Exception('expected exception message to be bar but it was %s' % e.message)

    foo()
    print('test_get_exception: ok')

# Generated at 2022-06-23 02:46:05.777734
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=redefined-outer-name
    import pytest
    try:
        raise Exception('myerror')
    except Exception: # pylint: disable=broad-except
        e = get_exception()
        pytest.approx(e, 'myerror')



# Generated at 2022-06-23 02:46:07.630367
# Unit test for function get_exception
def test_get_exception():
    try:
        x = y
    except NameError as e:
        assert e == get_exception()


# Generated at 2022-06-23 02:46:09.836555
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is a test")
    except Exception:
        assert str(get_exception()) == "This is a test"

# Generated at 2022-06-23 02:46:16.603580
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        got_exception = get_exception()

    expected_exception = RuntimeError('foo')

    try:
        assert got_exception == expected_exception
        assert type(got_exception) is type(expected_exception)
        assert isinstance(got_exception, RuntimeError)
    except AssertionError:
        print('AssertionError: ')
        print('Got exception      : %r' % got_exception)
        print('Expected exception : %r' % expected_exception)
        raise

# Generated at 2022-06-23 02:46:20.179750
# Unit test for function get_exception
def test_get_exception():
    # This test should always pass no matter what.
    try:
        raise ValueError('Test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
test_get_exception()

# Generated at 2022-06-23 02:46:22.301915
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert get_exception() is e



# Generated at 2022-06-23 02:46:26.050757
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        if not str(e).startswith('foo'):
            raise AssertionError("Unexpected Exception: %s" % e)

# Generated at 2022-06-23 02:46:32.302307
# Unit test for function get_exception
def test_get_exception():

    e = ValueError('Test exception')
    try:
        raise e
    except ValueError:
        try:
            raise
        except Exception:
            assert e == get_exception()
    else:
        raise AssertionError('Did not get exception')

    try:
        raise e
    except Exception:
        assert e == get_exception()
    else:
        raise AssertionError('Did not get exception')


# Generated at 2022-06-23 02:46:36.096152
# Unit test for function get_exception
def test_get_exception():
    try:
        print(bar)
    except:
        e = get_exception()
    assert 'global name' in str(e)
    assert 'not defined' in str(e)

# Generated at 2022-06-23 02:46:44.486152
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Expected exception')
    except ValueError as exc:
        func_exc = get_exception()
    if exc is not func_exc:
        raise AssertionError('Expected {0!r}, got {0!r}'.format(exc, func_exc))

# Generated at 2022-06-23 02:46:49.252482
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            raise Exception()
        except Exception:
            return get_exception()

    assert raise_exception() is not None
    assert type(raise_exception()) is Exception


# Generated at 2022-06-23 02:46:55.345597
# Unit test for function get_exception
def test_get_exception():
    if not sys.platform.startswith('java'):
        # Jython's sys.exc_info() is broken, see
        # https://bugs.jython.org/issue2266 for details.
        try:
            raise RuntimeError('Exception message')
        except:
            exc_info = sys.exc_info()
        assert get_exception() is exc_info[1]


# Generated at 2022-06-23 02:47:03.310710
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()

    assert str(e) == 'test exception'

# Generated at 2022-06-23 02:47:08.940023
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test123')
    except ValueError:
        ex = get_exception()
        assert str(ex) == 'test123'

# Generated at 2022-06-23 02:47:12.029299
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('No reason')
    except RuntimeError:
        exc = get_exception()
        assert str(exc) == 'No reason'
        assert isinstance(exc, RuntimeError)

# Generated at 2022-06-23 02:47:16.946304
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException
    except:
        e = get_exception()
    if not isinstance(e, TestException):
        raise AssertionError('get_exception() returned %r, expected %r' % (e, TestException))


# Generated at 2022-06-23 02:47:22.375352
# Unit test for function get_exception
def test_get_exception():
    '''Test function get_exception for python 2.4-3.x compatibility'''
    try:
        raise Exception('An exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'An exception'


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-23 02:47:29.935328
# Unit test for function get_exception
def test_get_exception():
    """Make sure that get_exception gives us the right exceptions"""
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError), repr(e)
    else:
        raise AssertionError("Didn't get Exception")

    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError), repr(e)
        assert str(e) == 'foo', repr(e)
    else:
        raise AssertionError("Didn't get Exception")

# Generated at 2022-06-23 02:47:42.086445
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestExceptions(Exception):
        pass

    class GetExceptionTests(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise TestExceptions()
            except:
                exc = get_exception()
                self.assertEqual(exc.__class__, TestExceptions)

    # This function name is a common convention for modules that provide tests.
    # It allows the tests to be run automatically when the module is imported
    # or when python -m ansible.module_utils.six is run.

# Generated at 2022-06-23 02:47:48.001069
# Unit test for function get_exception
def test_get_exception():
    """Basic test case for get_exception.

    This code is copied in the docstring for get_exception to make sure that if we
    modify the code in the docstring that it still works.
    """
    try:
        raise ValueError('foo')
    except Exception:  # pylint: disable=broad-except
        e = get_exception()
        assert type(e) is ValueError
        assert e.message == 'foo'

# Generated at 2022-06-23 02:47:51.395157
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        assert get_exception() is not None

# Generated at 2022-06-23 02:47:54.075373
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
    assert str(ex) == 'foo', ex


# Generated at 2022-06-23 02:47:56.330373
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-23 02:47:59.165329
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Some string')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Some string'



# Generated at 2022-06-23 02:48:02.594093
# Unit test for function get_exception
def test_get_exception():
    '''Test the get_exception function of module_utils/basic.py'''

    # Test exception is captured and returned
    try:
        raise Exception('TEST EXCEPTION')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'TEST EXCEPTION'

    # Test non-exception is returned as is
    e = get_exception()
    assert e == None


# Generated at 2022-06-23 02:48:04.600130
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except: # NOQA
        assert get_exception()

# Generated at 2022-06-23 02:48:13.277310
# Unit test for function get_exception
def test_get_exception():
    import pytest
    class TestException(Exception):
        pass
    def test():
        try:
            raise TestException('Should get this')
        except:
            e = get_exception()
            assert e.message == 'Should get this'
            assert isinstance(e, TestException)

    def test_no_exception():
        try:
            pass
        except:
            e = get_exception()
            assert e is None

    test()
    test_no_exception()

# Generated at 2022-06-23 02:48:17.420563
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception', '%r != Test exception' % str(e)
        assert isinstance(e, Exception)

# Generated at 2022-06-23 02:48:20.123351
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except:
        assert get_exception().args[0] == "Test exception"


# Generated at 2022-06-23 02:48:26.441929
# Unit test for function get_exception
def test_get_exception():
    """Ensure that get_exception() works."""
    try:
        raise ValueError()
    except ValueError:
        exc = get_exception()

    # Validate the exception and ensure that we got a proper type back
    assert isinstance(exc, ValueError)

    # Always returning exc ensures that the exception is propagated to the
    # caller in Ansible
    return exc

# Generated at 2022-06-23 02:48:29.370487
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('My exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'My exception'



# Generated at 2022-06-23 02:48:32.635836
# Unit test for function get_exception
def test_get_exception():
    # No try/catch needed - py.test collects the errors from failed tests
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:48:37.141505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError), \
            "Got exception %s instead of ValueError" % type(e)
        assert str(e) == 'foo', \
            "Got exception %s instead of 'foo'" % e



# Generated at 2022-06-23 02:48:40.416739
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 5 + 'string'  # pylint: disable=unsupported-binary-operation
        assert(False)
    except:
        e = get_exception()
    assert(isinstance(e, TypeError))


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:48:46.224044
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception('foo')

    def bar():
        try:
            foo()
        except Exception as e:
            return e

    assert bar() is get_exception()



# Generated at 2022-06-23 02:48:49.090172
# Unit test for function get_exception
def test_get_exception():

    try:
        raise NameError('This is a name error')
    except NameError as exception:
        result = get_exception()
        assert(exception == result)

# Generated at 2022-06-23 02:48:51.651921
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a fake exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'This is a fake exception'

# Generated at 2022-06-23 02:48:56.132156
# Unit test for function get_exception
def test_get_exception():
    # Test that the function returns the current exception on the stack
    try:
        raise RuntimeError('This is a test')
    except RuntimeError as e:
        ret = get_exception()

    assert ret is e

# vim: set et sw=4 ts=4:

# Generated at 2022-06-23 02:48:59.789279
# Unit test for function get_exception
def test_get_exception():
    def call_get_exception():
        def call_raise():
            raise RuntimeError('hai')
        try:
            call_raise()
        finally:
            return get_exception()
    assert call_get_exception().args == ('hai', )



# Generated at 2022-06-23 02:49:03.142474
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'Test'

# Generated at 2022-06-23 02:49:05.767030
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert e.args == ('foo',)


# Generated at 2022-06-23 02:49:10.263498
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works"""
    # Check that get_exception is a function
    assert callable(get_exception)

    # Check that it works with an exception
    try:
        raise Exception('Testing get_exception')
    except Exception:
        result = get_exception()
        assert result
        assert result.args == ('Testing get_exception',)

# Generated at 2022-06-23 02:49:16.691055
# Unit test for function get_exception
def test_get_exception():
    # see https://bugs.python.org/issue12182
    def test_get_exception_inner(e):
        try:
            raise e
        except e.__class__:
            return get_exception()
    class TestException(Exception):
        pass
    e1 = TestException
    e2 = TestException('whoa!')
    try:
        raise TestException('whoa!')
    except Exception:
        e3 = get_exception()
    for e in (e1, e2, e3):
        assert e is test_get_exception_inner(e)

# Generated at 2022-06-23 02:49:26.861665
# Unit test for function get_exception
def test_get_exception():
    # Test 1:
    # Test that we get the last exception
    def foo():
        raise AssertionError('foo raised')

    def bar():
        try:
            foo()
            raise AssertionError('bar raised')
        except AssertionError:
            return get_exception()

    assert bar().args[0] == 'foo raised'

    # Test 2:
    # Test that we always get an Exception, even when we have
    # an error obtaining the exception
    def foo():
        raise AssertionError('foo raised')

    def bar():
        try:
            foo()
        except Exception as e:
            try:
                raise AssertionError('bar raised')
            except Exception:
                return get_exception(), e

    e1, e2 = bar()

# Generated at 2022-06-23 02:49:28.139770
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        exc = get_exception()
    assert exc.__class__ == Exception



# Generated at 2022-06-23 02:49:31.882323
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('foo')
    except:
        assert get_exception() == sys.exc_info()[1]



# Generated at 2022-06-23 02:49:34.384777
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'Test exception'

# Generated at 2022-06-23 02:49:38.882449
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bork')
    except:
        e = get_exception()
    assert e.args[0] == 'bork'

# Generated at 2022-06-23 02:49:42.386192
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test get_exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'Test get_exception'


# Generated at 2022-06-23 02:49:47.112140
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     e = 1/0
    ... except Exception:
    ...     e = get_exception()
    ...     assert True
    ...
    """
    pass

if __name__ == "__main__":
    __import__('doctest').testmod()

# Generated at 2022-06-23 02:49:49.492162
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
    assert "foo" in str(e)


# Generated at 2022-06-23 02:49:52.294856
# Unit test for function get_exception
def test_get_exception():
    try:
        int('hello')
    except ValueError:
        exc = get_exception()

    assert str(exc) == "invalid literal for int() with base 10: 'hello'"

# Generated at 2022-06-23 02:49:56.771847
# Unit test for function get_exception

# Generated at 2022-06-23 02:50:08.304380
# Unit test for function get_exception
def test_get_exception():
    # Code to generate the exception we wish to catch.  We have to do this
    # here because we might be running this on Python 3 which doesn't have
    # the error type we want to throw.
    try:
        exec("2 / 0")
    except ZeroDivisionError as e:
        expected_exception = e
    del expected_exception
    # Code to catch the exception and check that it's what we expect
    try:
        exec("2 / 0")
    except Exception:
        assert sys.exc_info()[1] == get_exception()
        e = get_exception()
        assert type(e) is expected_exception.__class__
        assert e.args == expected_exception.args
        assert str(e) == str(expected_exception)


# Generated at 2022-06-23 02:50:13.723864
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test get_exception')
    except Exception:
        ex = get_exception()
    assert str(ex) == 'Test get_exception'
    try:
        1/0
    except Exception:
        ex = get_exception()
    assert str(ex).startswith('integer division or modulo by zero')
    try:
        1 + '1'
    except Exception:
        ex = get_exception()
    assert str(ex) == "unsupported operand type(s) for +: 'int' and 'str'"

# Generated at 2022-06-23 02:50:17.281343
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Test exception', "get_exception doesn't actually get the exception!"

# Generated at 2022-06-23 02:50:23.288248
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        e = get_exception()
        assert e.args == ('This is a test exception',)



# Generated at 2022-06-23 02:50:26.714126
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert e.args == ('test',)

# Generated at 2022-06-23 02:50:34.904558
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception gets the current exception

    In Python 3.x, we can't catch an exception and use it as a variable name.
    Just make sure that get_exception() returns the current exception.

    This function is already covered by test_utils.TestUtils.testException
    but it's useful to have a test here since it's the first thing that will
    be imported and run if someone imports this file directly.
    """
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert e.args == ('test exception',)

# Generated at 2022-06-23 02:50:38.268741
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:50:40.598914
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-23 02:50:44.044138
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('Test exception',)

# Generated at 2022-06-23 02:50:48.382677
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is an error")
    except Exception:
        assert str(sys.exc_info()[1]) == str(get_exception())

# Generated at 2022-06-23 02:50:51.502472
# Unit test for function get_exception
def test_get_exception():
    def func():
        raise Exception()

    try:
        func()
    except:
        exc = get_exception()
        assert(exc.__class__ == Exception)



# Generated at 2022-06-23 02:50:57.179777
# Unit test for function get_exception
def test_get_exception():
    '''Function get_exception returns the current exception'''
    # pylint: disable=unused-variable
    try:
        raise ValueError('foo')
    except ValueError:
        exception = get_exception()
    assert str(exception) == 'foo'

# Unit tests for function literal_eval

# Generated at 2022-06-23 02:51:02.318843
# Unit test for function get_exception
def test_get_exception():
    class MyError(Exception):
        pass
    try:
        raise MyError('foo')
    except MyError:
        exc = get_exception()
        assert exc.args[0] == 'foo'
        #ret = exc.__repr__()
        #assert ret == "'foo'"

# Generated at 2022-06-23 02:51:05.002298
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('boo')
    except:
        e = get_exception()
    assert e.args == ('boo',)



# Generated at 2022-06-23 02:51:08.000325
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is a test exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'this is a test exception', e



# Generated at 2022-06-23 02:51:12.438949
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'test exception'
        assert exc.__class__.__name__ == 'Exception'


# Generated at 2022-06-23 02:51:16.850078
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('a random exception')
    except Exception:
        e = get_exception()

    assert str(e) == 'a random exception'

# Generated at 2022-06-23 02:51:20.238068
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-23 02:51:22.645785
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Boom')
    except Exception:
        e = get_exception()
        assert str(e) == 'Boom'

# Generated at 2022-06-23 02:51:25.690173
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('get_exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'get_exception', 'get_exception() returns the wrong exception'

# Generated at 2022-06-23 02:51:32.144315
# Unit test for function get_exception
def test_get_exception():
    class Raiser:
        def __init__(self, n):
            self.n = n

        def __getitem__(self, index):
            if index == self.n:
                raise KeyError('foo')
            return index

    try:
        Raiser(0)[0][1]
    except KeyError as e:
        assert 0, 'Did not get exception'
    except:  # pylint: disable=bare-except
        pass
    else:
        assert 0, 'Did not get exception'

    try:
        Raiser(0)[0][1]
    except:  # pylint: disable=bare-except
        e = get_exception()
    else:
        assert 0, 'Did not get exception'

    assert isinstance(e, KeyError), 'Exception is not KeyError'
    assert e

# Generated at 2022-06-23 02:51:33.656059
# Unit test for function get_exception
def test_get_exception():
    import exceptions

# Generated at 2022-06-23 02:51:37.749126
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception has occured')
    except Exception:
        try:
            e = get_exception()
            err = str(e)
        except:
            raise Exception('get_exception failed to get an exception')
        if err != 'An exception has occured':
            raise Exception('get_exception failed to return the correct exception')



# Generated at 2022-06-23 02:51:42.143274
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:51:50.733575
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Foo'

try:
    # Python 2.6+
    from collections import MutableMapping
except ImportError:
    # a version of MutableMapping that works with python 2.4.  From:
    # https://stackoverflow.com/a/3348985/987757
    from UserDict import DictMixin


# Generated at 2022-06-23 02:51:55.730964
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ArithmeticError:
        assert(type(get_exception()) is ZeroDivisionError)

# Generated at 2022-06-23 02:52:00.517232
# Unit test for function get_exception
def test_get_exception():
    def do_raise():
        raise Exception('foo')
    try:
        do_raise()
    except Exception:
        ex = get_exception()
        assert ex.args[0] == 'foo'
    else:
        raise Exception("We should have caught the exception")


# Generated at 2022-06-23 02:52:04.216929
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("foo",)



# Generated at 2022-06-23 02:52:10.378983
# Unit test for function get_exception
def test_get_exception():
    '''Make sure that get_exception returns errors'''
    try:
        raise ValueError('bar')
    except:
        e = get_exception()
    assert e, 'get_exception failed to return the exception'
    assert str(e) == 'bar', 'get_exception does not return the correct exception'


# Generated at 2022-06-23 02:52:14.528070
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = 1/0  # pylint: disable=unused-variable
    assert e == get_exception()


# Generated at 2022-06-23 02:52:16.509913
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-23 02:52:19.424769
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-23 02:52:24.234355
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_message')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:52:31.487667
# Unit test for function get_exception
def test_get_exception():
    a = 1
    try:
        try:
            raise Exception('foobar')
        except Exception:
            e = get_exception()
            if str(e) == 'foobar':
                a = 0
            else:
                raise Exception('%r != %r' % (str(e), 'foobar'))
    except Exception as e:
        raise Exception('%r != %r' % (str(e), 'foobar'))
    if a != 0:
        raise Exception('%r != %r' % (a, 0))

# Generated at 2022-06-23 02:52:32.742004
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:52:35.296910
# Unit test for function get_exception
def test_get_exception():
    import StringIO
    import sys
    try:
        raise Exception()
    except:
        e = get_exception()
        assert e
        assert isinstance(e, Exception)


# Generated at 2022-06-23 02:52:39.843081
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('hi')
    except:
        exc = get_exception()

    assert exc.args == ('hi',)

# Generated at 2022-06-23 02:52:42.951613
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("Testing")
    except Exception:
        err = get_exception()
    assert isinstance(err, TypeError)
    assert str(err) == "Testing"

# Generated at 2022-06-23 02:52:46.188801
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except:
        assert isinstance(get_exception(), ZeroDivisionError)


# Generated at 2022-06-23 02:52:51.245066
# Unit test for function get_exception
def test_get_exception():
    # Test the success case
    try:
        raise RuntimeError("testing")
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == "testing"

    # Test the fail case
    try:
        raise RuntimeError("testing")
    except RuntimeError:
        e = get_exception()
        assert e.args[0] != "something wrong"


# Generated at 2022-06-23 02:52:56.062013
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        if get_exception() != e:
            raise Exception('get_exception did not get the right exception')

# Generated at 2022-06-23 02:52:59.353059
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        assert get_exception().__class__ is ZeroDivisionError



# Generated at 2022-06-23 02:53:05.258801
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('foo')
    except Exception:
        e = get_exception()

        import logging
        logging.basicConfig()
        logging.getLogger('test_get_exception').debug('%s' % (e))

        assert str(e) == 'foo'



# Generated at 2022-06-23 02:53:08.827219
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'Test exception'


# Generated at 2022-06-23 02:53:11.928330
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        e = get_exception()
        assert type(e) is ValueError
        assert str(e) == "test"

# Generated at 2022-06-23 02:53:16.357317
# Unit test for function get_exception
def test_get_exception():
    # Should succeed
    try:
        raise RuntimeError('test')
    except:
        tb = get_exception()
    assert isinstance(tb, RuntimeError)
    assert str(tb) == 'test'

    # Should fail
    try:
        raise RuntimeError('test')
    except:
        tb = get_exception()
    assert not isinstance(tb, ValueError)

# Generated at 2022-06-23 02:53:20.002655
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        assert get_exception()
        assert isinstance(get_exception(), ZeroDivisionError)

# Generated at 2022-06-23 02:53:22.816702
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert(str(e) == 'test exception')

# Generated at 2022-06-23 02:53:30.658503
# Unit test for function get_exception
def test_get_exception():
    def inner1():
        try:
            raise ValueError('testing')
        except:
            return get_exception()

    def inner2():
        try:
            raise ValueError('testing')
        except Exception:
            return get_exception()

    def inner3():
        try:
            raise ValueError('testing')
        except Exception as exc:
            return exc

    assert inner1().args == ('testing',)
    assert inner2().args == ('testing',)
    assert inner3().args == ('testing',)


# Generated at 2022-06-23 02:53:33.856948
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert get_exception() is not None


# Generated at 2022-06-23 02:53:37.282001
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test of get_exception")
    except ValueError:
        exc = get_exception()
    assert str(exc) == "This is a test of get_exception"



# Generated at 2022-06-23 02:53:45.977603
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    try:
        raise ZeroDivisionError('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)
    assert e.args[0] == 'test'
    try:
        [][1]
    except Exception:
        e = get_exception()
    assert isinstance(e, IndexError)
    assert str(e) == 'list index out of range'
    assert (1, 'two') == literal_eval('(1, "two")')
    assert 1 == literal_eval('1')
    assert None is literal_eval('None')
    assert True is literal_eval('True')
    assert False is literal

# Generated at 2022-06-23 02:53:48.493600
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:53:51.562394
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except ValueError as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:53:55.379560
# Unit test for function get_exception
def test_get_exception():
    __tracebackhide__ = True
    try:
        __tracebackhide__ = False
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
    assert e.args == ('Test exception',)



# Generated at 2022-06-23 02:53:58.805823
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("error message")
    except RuntimeError:
        e = get_exception()
        assert str(e) == "error message", "get_exception did not return the correct exception"



# Generated at 2022-06-23 02:54:02.831212
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-argument
    from ansible.module_utils._text import to_text

    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert to_text(e) == 'foo'

# Generated at 2022-06-23 02:54:08.519300
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception pulls out the current exception
    try:
        # pylint: disable=undefined-variable
        # We're creating an exception here to test that get_exception works
        raise exception
    except:
        exc = get_exception()
    if not isinstance(exc, NameError):
        raise AssertionError('Did not pull out the exception that was raised')

# Generated at 2022-06-23 02:54:09.667254
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:12.951322
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:54:16.478413
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()
        assert isinstance(e, TypeError)
    except Exception:
        assert False, "Raised the wrong exception"



# Generated at 2022-06-23 02:54:20.147141
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception."""
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'test exception'



# Generated at 2022-06-23 02:54:23.044931
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'invalid literal for int() with base 10: \'a\''



# Generated at 2022-06-23 02:54:24.675843
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:54:34.559212
# Unit test for function get_exception
def test_get_exception():
    # We're testing that get_exception works with the syntax 'except:'.
    # Testing that get_exception works with 'except Exception:' would be
    # redundant, so we disable that warning.
    # pylint: disable=bare-except

    try:
        raise AssertionError('foo')
    except:
        e = get_exception()
    assert isinstance(e, AssertionError)
    assert 'foo' in str(e)

    try:
        raise SyntaxError('bar')
    except:
        e = get_exception()
    assert isinstance(e, SyntaxError)
    assert 'bar' in str(e)

    try:
        raise ValueError('baz')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-23 02:54:37.181969
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Unit test")
    except:
        exception = get_exception()
        assert isinstance(exception, ValueError)
        assert 'Unit test' in str(exception)
        assert "No module named 'foo'" == literal_eval("'No module named %r'" % 'foo')
        try:
            literal_eval("1 + 'foo'")
            assert False
        except ValueError:
            pass #exception

# Generated at 2022-06-23 02:54:43.991169
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:52.937434
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import sys
    class TestException(unittest.TestCase):
        def setUp(self):
            # Just to make sure the tests don't raise an exception and thus never
            # assertTrue
            self.e = None

        def tearDown(self):
            self.assertTrue(self.e is not None)

        def test_get_exception(self):
            try:
                raise RuntimeError('foo')
            except RuntimeError:
                self.e = get_exception()
                self.assertTrue(str(self.e) == 'foo')
    unittest.main()

# Generated at 2022-06-23 02:54:56.930544
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() == e


# Generated at 2022-06-23 02:55:00.227407
# Unit test for function get_exception
def test_get_exception():
    try:
        x = {}['key']
    except Exception:
        x = get_exception()
    return x


# Generated at 2022-06-23 02:55:04.561930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('some text')
    except TypeError:
        assert get_exception()
        exc = get_exception()
        assert str(exc) == 'some text'