

# Generated at 2022-06-23 02:45:05.821529
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Error message")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert "Error message" in str(e)
    assert e.__class__.__name__ == "ValueError"
    assert str(e) == "Error message"



# Generated at 2022-06-23 02:45:08.952517
# Unit test for function get_exception
def test_get_exception():
    '''Ensure that the get_exception function returns useful exception data'''
    try:
        raise Exception('foo')
    except:
        got_exception = get_exception()
    assert 'foo' == got_exception.args[0]

# Generated at 2022-06-23 02:45:21.416091
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.basic

    def raises():
        raise RuntimeError('Intentional boom')

    def doesnt_raise():
        return True

    def caught():
        try:
            raises()
        except RuntimeError as e:
            return e
        except:
            ansible.module_utils.basic.AnsibleModule.fail_json()
        ansible.module_utils.basic.AnsibleModule.fail_json()

    def caught_get_exception():
        try:
            raises()
        except:
            return get_exception()
        ansible.module_utils.basic.AnsibleModule.fail_json()

    def caught_no_exception():
        try:
            doesnt_raise()
        except RuntimeError as e:
            assert False, 'This should not happen'

# Generated at 2022-06-23 02:45:26.384387
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        exc = get_exception()
        assert(isinstance(exc, TestException))

    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert(isinstance(exc, Exception))

# Generated at 2022-06-23 02:45:31.209470
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception for get_exception')
    except RuntimeError:
        exc = get_exception()
        assert exc.args[0] == 'test exception for get_exception', exc

# Generated at 2022-06-23 02:45:35.371683
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test')
    except Exception:
        e = get_exception()
        assert str(e) == 'This is a test'



# Generated at 2022-06-23 02:45:41.913156
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring
    def test_function():
        try:
            raise Exception('test exception')
        except:
            return get_exception()
    try:
        e = test_function()
        if not e.args[0] == 'test exception':
            raise Exception('Exception %s does not match "test exception"' % e)
    except Exception as ex:
        raise Exception('get_exception failed: %s' % ex)


# Generated at 2022-06-23 02:45:44.158004
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert e.__class__ == ZeroDivisionError

# Generated at 2022-06-23 02:45:46.289793
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-23 02:45:48.770241
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is the exception")
    except:
        e = get_exception()
        assert(str(e) == "This is the exception")
        assert(type(e) is RuntimeError)

# Generated at 2022-06-23 02:45:50.938878
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exc = get_exception()
        assert isinstance(exc, RuntimeError)



# Generated at 2022-06-23 02:45:54.574034
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test message')
    except Exception:
        exc = get_exception()
        assert exc.message == 'test message'



# Generated at 2022-06-23 02:45:57.903959
# Unit test for function get_exception
def test_get_exception():
    """Ensure that get_exception() returns the correct exception"""
    try:
        raise Exception('This is the exception we want to catch')
    except Exception:
        e = get_exception()
        if str(e) != 'This is the exception we want to catch':
            raise Exception('get_exception() failed to get exception: %s' % str(e))



# Generated at 2022-06-23 02:46:01.675293
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test exception")
    except  ValueError:
        e = get_exception()
    assert e.args[0] == "This is a test exception"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-23 02:46:05.625611
# Unit test for function get_exception
def test_get_exception():
    """Make sure we can always retrieve the current exception"""
    try:
        raise ValueError("test exception")
    except Exception:
        exc = get_exception()
        assert type(exc) == ValueError
        assert str(exc) == "test exception"



# Generated at 2022-06-23 02:46:10.617533
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        try:
            raise ValueError('test2')
        except Exception:
            e2 = get_exception()
    e1 = get_exception()

    assert((e1.args[0] == 'test' and e2.args[0] == 'test2'))
    print("success")



# Generated at 2022-06-23 02:46:14.591939
# Unit test for function get_exception
def test_get_exception():
    # check that the function behaves as expected on a dummy exception under Python 2.4-3.x
    e = get_exception()
    assert e is None
    try:
        raise RuntimeError('dummy')
    except:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'dummy'


# Generated at 2022-06-23 02:46:20.780866
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        exc = get_exception()
        assert exc is not None, "get_exception returned None"
        assert type(exc) is type(Exception()), "get_exception returned %s instead of %s" \
            % (type(exc), type(Exception()))

# Unit test literal_eval when it's the real thing

# Generated at 2022-06-23 02:46:24.177866
# Unit test for function get_exception

# Generated at 2022-06-23 02:46:34.983837
# Unit test for function get_exception
def test_get_exception():
    try:
        raise IOError
    except IOError:
        assert get_exception()

    try:
        raise IOError()
    except IOError:
        e = get_exception()
        assert e.__class__ == IOError
        assert repr(e) == "IOError()"
        assert str(e) == ""

    try:
        raise IOError("Error string")
    except IOError:
        e = get_exception()
        assert e.__class__ == IOError
        assert repr(e) == "IOError('Error string',)"
        assert str(e) == "Error string"

    try:
        raise IOError(2, "Error string")
    except IOError:
        e = get_exception()
        assert e.__class__ == IOError

# Generated at 2022-06-23 02:46:43.437770
# Unit test for function get_exception
def test_get_exception():
    import os
    # Necessary because we need the test to fail on Python 2.6 where os.chmod
    # isn't an importable function
    if hasattr(os, 'chmod'):
        # Check that plain exception is returned
        try:
            os.chmod('/doesnt/exist', 0)
        except OSError:
            exc = get_exception()
        else:
            assert False, "This shouldn't happen"

        try:
            raise KeyError('foo')
        except KeyError:
            exc = get_exception()
        else:
            assert False, "This shouldn't happen"

        # Check that exception with string formatting works
        try:
            raise KeyError('%s' % 'foo')
        except KeyError:
            exc = get_exception()

# Generated at 2022-06-23 02:46:49.640503
# Unit test for function get_exception
def test_get_exception():
    """Test getting the exception from an exception handler."""
    def raises():
        raise RuntimeError('This is an error')

    def get_exception_handler():
        try:
            raises()
        except Exception:
            return get_exception()

    assert str(get_exception_handler()) == 'This is an error'

# Generated at 2022-06-23 02:46:51.816707
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a fake exception for testing')
    except:
        assert get_exception()



# Generated at 2022-06-23 02:46:54.472136
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('<test exception>')
    except RuntimeError:
        e = get_exception()
        assert str(e) == '<test exception>'



# Generated at 2022-06-23 02:46:56.278960
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('testing')
    except TypeError as e:
        assert get_exception() is e

# Generated at 2022-06-23 02:47:04.602946
# Unit test for function get_exception
def test_get_exception():
    """ Unit test for function get_exception """
    try:
        raise ValueError()
    except:
        e = get_exception()
    assert e.__class__.__name__ == 'ValueError'


# Generated at 2022-06-23 02:47:09.853283
# Unit test for function get_exception
def test_get_exception():
    try:
        print(foo)
    except Exception:
        e = get_exception()
    assert e.__name__ == 'NameError'
    assert str(e) == "global name 'foo' is not defined"

# Generated at 2022-06-23 02:47:14.201010
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Hai')
    except ValueError as e:
        got_exception = get_exception()

    assert id(e) == id(got_exception), 'Did not get the same exception'
    del got_exception
    del e


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:47:23.647806
# Unit test for function get_exception
def test_get_exception():
    import tempfile
    name = tempfile.mktemp()
    fp = file(name, "wb")
    fp.write("Hello World");
    fp.close()
    fp = file(name, "rb")
    try:
        raise RuntimeError("This is a test exception")
    except:
        e = get_exception()
    assert "This is a test exception" in str(e)
    assert "RuntimeError" in str(e)
    # Cleanup
    fp = file(name, "wb")
    fp.write("")
    fp.close()

# Generated at 2022-06-23 02:47:29.469640
# Unit test for function get_exception
def test_get_exception():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    try:
        raise builtins.ValueError('test_get_exception: error')
    except Exception:
        e = get_exception()
        assert e.__class__ == builtins.ValueError
        assert str(e) == 'test_get_exception: error'


# Generated at 2022-06-23 02:47:41.768590
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function.

    Verify that we get the right exception back regardless of the version of
    Python.
    """

    import six
    try:
        int('foo')
    except:
        e = get_exception()
        assert isinstance(e, ValueError), e.__class__

        # Now with the "as" syntax
    try:
        int('foo')
    except:
        e = get_exception()
        assert isinstance(e, ValueError), e.__class__

    # Verify that get_exception() returns the right exception even when
    # wrapped in an except block.
    try:
        try:
            int('foo')
        except:
            e = get_exception()
            assert isinstance(e, ValueError), e.__class__
    except:
        e

# Generated at 2022-06-23 02:47:43.892681
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('My test exception')
    except:
        assert str(get_exception()) == 'My test exception'

# Generated at 2022-06-23 02:47:47.554862
# Unit test for function get_exception
def test_get_exception():
    # A simple function that raises an exception
    def func():
        raise ValueError("Test")

    try:
        func()
    except ValueError:
        e = get_exception()
    assert str(e) == "Test"
    assert repr(e) == "ValueError('Test',)"


# Unit tests for function literal_eval

# Generated at 2022-06-23 02:47:51.737965
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('blah')
    except ValueError as e:
        ge = get_exception()
        assert ge is e

# Generated at 2022-06-23 02:47:54.763522
# Unit test for function get_exception
def test_get_exception():
    def get_it():
        try:
            int('asdf')
        except:
            return get_exception()
    exc = get_it()
    assert isinstance(exc, ValueError)

# Generated at 2022-06-23 02:47:56.678458
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception().args[0] == 'foo'

# Generated at 2022-06-23 02:47:58.880482
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError:
        assert get_exception() is not None



# Generated at 2022-06-23 02:48:10.441162
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=too-many-branches,too-many-statements,too-many-locals,undefined-variable,too-many-nested-blocks
    # pylint: disable=bare-except,invalid-name,import-error,no-name-in-module,no-member,unused-variable,unused-import
    import unittest
    import sys

    # Unit test class
    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            def _get_exception_test(test_class, expected_exception, expected_exception_name, expected_exception_msg):
                """Runs the tests for get_exception"""

# Generated at 2022-06-23 02:48:18.977930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert type(e) is Exception
#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Ansible module to manage CheckPoint Firewall (c) 2019
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have

# Generated at 2022-06-23 02:48:25.689331
# Unit test for function get_exception
def test_get_exception():
    def raise_a_test_exception(message):
        class TestException(Exception):
            pass
        raise TestException(message)

    try:
        raise_a_test_exception('Test Message')
    except:
        ex = get_exception()
        assert ex.args[0] == 'Test Message', "Didn't get the right exception back"

# Generated at 2022-06-23 02:48:31.845379
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
    assert str(e) == 'test exception'



# Generated at 2022-06-23 02:48:33.954650
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args == ('foo',)


# Generated at 2022-06-23 02:48:37.740150
# Unit test for function get_exception
def test_get_exception():
    try:
        assert False, 'always fails'
    except AssertionError:
        assert get_exception().args[0] == 'always fails'
    else:
        assert False, 'It should have failed!'

test_get_exception()
del test_get_exception

# Generated at 2022-06-23 02:48:47.496029
# Unit test for function get_exception
def test_get_exception():
    try:
        testvar = "foo"
        testvar[5]  # make an index error on purpose
    except IndexError as e:
        if type(e) != type(get_exception()):
            raise AssertionError("Expected exception type %s but got %s" % (type(e), type(get_exception())))
        if str(e) != str(get_exception()):
            raise AssertionError("Expected exception string %s but got %s" % (str(e), str(get_exception())))


# Generated at 2022-06-23 02:48:54.058004
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:  # noqa  pylint: disable=bare-except
        e = get_exception()
        assert e.args == ('test',)

    try:
        raise Exception('test', 'oops')
    except:  # noqa  pylint: disable=bare-except
        e = get_exception()
        assert e.args == ('test', 'oops')

# Generated at 2022-06-23 02:48:57.027033
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boo')
    except:
        e = get_exception()
    assert str(e) == 'boo'



# Generated at 2022-06-23 02:48:59.626512
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    return e



# Generated at 2022-06-23 02:49:02.310428
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('testing')
    except RuntimeError as e:
        result = get_exception()
        assert result == e, 'get_exception() did not return the expected exception'


# Generated at 2022-06-23 02:49:04.808204
# Unit test for function get_exception

# Generated at 2022-06-23 02:49:11.737079
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'test'
    assert repr(e) == "<type 'exceptions.RuntimeError'>: test"

# Generated at 2022-06-23 02:49:14.352342
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert e is not None
    assert isinstance(e, Exception)


# Generated at 2022-06-23 02:49:17.320446
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('dummy error')
    except Exception:
        e = get_exception()
    return e is not None

# Generated at 2022-06-23 02:49:21.600331
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e1 = get_exception()
        e2 = sys.exc_info()[1]
        assert e1.args == e2.args == ('foo',)
        assert e1 is e2

# Generated at 2022-06-23 02:49:24.904827
# Unit test for function get_exception
def test_get_exception():
    try:
        1 + 'x'
    except TypeError:
        pass
    assert get_exception().args == ("unsupported operand type(s) for +: 'int' and 'str'",)

# Generated at 2022-06-23 02:49:36.458265
# Unit test for function get_exception
def test_get_exception():
    """Ensure that get_exception works correctly."""
    import re
    import six

    def check(thing):
        try:
            raise RuntimeError(thing)
        except RuntimeError:
            e = get_exception()
            assert e.args == (thing,)
            return e

    # Ensure that things that don't implement __str__ don't error out
    if not six.PY3:
        class MyClass(object):
            def __unicode__(self):
                return u'unicode string'
            def __str__(self):
                return u'str'

        check(MyClass())

    # Ensure that args containing non-ascii stuff makes it through correctly
    check(u'\u2603')

    # Ensure that args containing weird stuff (re, set) makes it through
    # Does not work on Python

# Generated at 2022-06-23 02:49:41.867856
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        assert e == get_exception()

    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-23 02:49:48.563727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert e.__class__ is ValueError
    assert str(e) == 'test'
    # test that the exception was not consumed
    try:
        print(e)
        raise ValueError('another test')
    except:
        e = get_exception()
    assert e.__class__ is ValueError
    assert str(e) == 'another test'

# Generated at 2022-06-23 02:49:50.858756
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:49:54.138699
# Unit test for function get_exception
def test_get_exception():
    '''Make sure we can get the current exception'''
    try:
        raise Exception('foo bar')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo bar'
test_get_exception()

# Generated at 2022-06-23 02:49:57.465892
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('foo')
    except:
        e = get_exception()
    assert e.args == ('foo',)
    assert isinstance(e, MyException)


# Generated at 2022-06-23 02:50:02.911349
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Testing")
    except:
        exception = get_exception()
        if str(exception) != "Testing":
            raise TypeError("%s is not a ValueError!" % exception)
        return isinstance(exception, ValueError)

# Generated at 2022-06-23 02:50:10.961497
# Unit test for function get_exception
def test_get_exception():
    def raiser():
        raise ValueError('This should be caught')
    try:
        raiser()
    except ValueError as e:
        exception = get_exception()
        got = str(exception)
        assert got == str(e), 'Expected exception %r but got %r instead' % (e, exception)

    try:
        raise ValueError('This is an exception')
    except ValueError as e:
        exception = get_exception()
        got = str(exception)
        assert got == str(e), 'Expected exception %r but got %r instead' % (e, exception)



# Generated at 2022-06-23 02:50:14.442313
# Unit test for function get_exception
def test_get_exception():
    assert sys.version_info < (3,)
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert repr(exc) == "Exception('foo',)"



# Generated at 2022-06-23 02:50:17.629878
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("This is a test exception.")
    except:
        e = get_exception()
        assert e.args[0] == "This is a test exception."


# Generated at 2022-06-23 02:50:23.891612
# Unit test for function get_exception
def test_get_exception():
    import random
    import traceback
    errors = []
    try:
        random.choice([])
    except:
        try:
            raise
        # pylint: disable=bare-except
        except:
            exc_info = sys.exc_info()
            errors.append(exc_info[1])
            errors.append(get_exception())
    for err in errors:
        try:
            raise err
        # pylint: disable=bare-except
        except:
            traceback.print_exc()
            assert sys.exc_info() == exc_info

# Generated at 2022-06-23 02:50:27.209946
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-23 02:50:38.003712
# Unit test for function get_exception
def test_get_exception():
    """
    Test that get_exception works in the vast majority of cases.
    """
    # Make sure get_exception does not fail when no exception is currently
    # defined
    try:
        get_exception()
    # This should error out because the exception is None.
    except TypeError:
        raise AssertionError("get_exception doesn't return None when there isn't an exception")

    # Make sure that get_exception works for the most common case
    # of having an exception
    try:
        raise Exception('chunky bacon')
    except Exception:
        e = get_exception()
    if e.args != ('chunky bacon',):
        raise AssertionError("get_exception doesn't return the most recent exception")

    # Make sure that get_exception works when the exception is a tuple
    # of

# Generated at 2022-06-23 02:50:40.177500
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'foobar'

# Generated at 2022-06-23 02:50:46.152914
# Unit test for function get_exception
def test_get_exception():
    class FooClass(object):
        def func1(self, *args):
            return self.func2(*args)

        def func2(self, *args):
            return self.func3(*args)

        def func3(self, *args):
            1/0

    try:
        FooClass().func1()
    except:
        assert get_exception().__class__.__name__ == "ZeroDivisionError"

# Generated at 2022-06-23 02:50:53.713859
# Unit test for function get_exception
def test_get_exception():
    class FooException(Exception):
        pass
    try:
        raise FooException('foo')
    except Exception:
        ex_type, ex, tb = sys.exc_info()
        assert ex_type == FooException
        assert ex.args[0] == 'foo'
        assert get_exception() is ex
    try:
        raise FooException('foo')
    except Exception:
        ex = get_exception()
        assert isinstance(ex, FooException)
        assert ex.args[0] == 'foo'

# Generated at 2022-06-23 02:50:57.273933
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception('exception')
        except Exception:
            e = get_exception()
            return e
    assert f().args == ('exception',)
    assert f().__class__.__name__ == 'Exception'

# Generated at 2022-06-23 02:50:59.238938
# Unit test for function get_exception

# Generated at 2022-06-23 02:51:09.795425
# Unit test for function get_exception
def test_get_exception():
    import copy
    import types

    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)

    def f():
        raise ValueError('foo')

    def g():
        f()


# Generated at 2022-06-23 02:51:12.442303
# Unit test for function get_exception
def test_get_exception():
    def run():
        raise Exception('Boom')
    try:
        run()
    except Exception:
        e = get_exception()
    assert 'Boom' in str(e)


# Generated at 2022-06-23 02:51:16.429336
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError as e:
        assert get_exception() == e



# Generated at 2022-06-23 02:51:21.201145
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_get_exception')
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ValueError'
        assert e.message == 'test_get_exception'



# Generated at 2022-06-23 02:51:27.252891
# Unit test for function get_exception
def test_get_exception():
    """
    Tests for get_exception().
    """
    try:
        raise Exception()
    except:
        e = get_exception()
    assert isinstance(e, Exception)



# Generated at 2022-06-23 02:51:35.305481
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except:
        e = get_exception()
    assert e is not None, "The function get_exception didn't return an exception"
    assert type(e) == ValueError, "The exception type of get_exception isn't ValueError"



# Generated at 2022-06-23 02:51:41.513101
# Unit test for function get_exception
def test_get_exception():
    try:
        int("asdf")
    except:
        exc = get_exception()
        assert type(exc) == ValueError
        assert str(exc) == "invalid literal for int() with base 10: 'asdf'"


# Generated at 2022-06-23 02:51:46.510900
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise ValueError('foo')
        except Exception:
            return get_exception()
    assert f().args == ('foo',)

# Generated at 2022-06-23 02:51:50.876930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('test')
    except:
        e = get_exception()
        assert type(e) == KeyError
        assert str(e) == "'test'"

# Generated at 2022-06-23 02:51:54.519255
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception: # pylint: disable=bare-except
        e = get_exception()
    assert str(e) == 'foo', 'get_exception() did not catch the exception'

# Generated at 2022-06-23 02:51:58.321478
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise Exception('foo')
        except Exception:
            e = get_exception()
            if e.args[0] != 'foo':
                raise Exception('foo exception')

    foo()



# Generated at 2022-06-23 02:52:02.030419
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        e = get_exception()
        assert str(e) == 'This is a test'



# Generated at 2022-06-23 02:52:04.965065
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Foo")
    except Exception:
        e = get_exception()
        assert "Foo" in str(e)


# Generated at 2022-06-23 02:52:07.868600
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test Error')
    except RuntimeError as e:
        assert get_exception() == e

# Generated at 2022-06-23 02:52:09.680616
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert str(get_exception()) == 'foo'

# Generated at 2022-06-23 02:52:16.676463
# Unit test for function get_exception
def test_get_exception():
    '''Call a function that throws an exception, catch the exception and verify
    that get_exception returns the exception we caught.
    '''
    def myfunc():
        raise ValueError('An exception!')

    try:
        myfunc()
    except Exception:
        e = get_exception()
        assert e
        assert isinstance(e, ValueError)
        assert unicode(e) == 'An exception!'

# Generated at 2022-06-23 02:52:22.166935
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError as e1:
        assert e1 == get_exception()
        try:
            raise TypeError('nested exception')
        except TypeError as e2:
            assert e2 == get_exception()
            raise
        assert e1 == get_exception()
    assert None is get_exception()

# Generated at 2022-06-23 02:52:25.482689
# Unit test for function get_exception

# Generated at 2022-06-23 02:52:35.377389
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=no-init, wildcard-import, unused-import
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, call, patch
    from ansible.compat.tests.mock import NO_MOCK, NO_MOCK_REASON

    class TestException(Exception):
        pass

    class AnotherException(Exception):
        pass

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            def foo():
                try:
                    self.assertTrue(False)
                except:
                    exception = get_exception()
                return exception

            exception = foo()
            self.assertTrue(isinstance(exception, AssertionError))

    # We'll execute the unit tests while mocking out everything

# Generated at 2022-06-23 02:52:44.545200
# Unit test for function get_exception
def test_get_exception():
    '''Check that get_exception can catch exceptions.

    This test is in this file to prevent a circular import.
    '''
    def throw(msg):
        raise RuntimeError(msg)

    try:
        throw('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError), 'get_exception did not get the exception'
    assert e.args[0] == 'foo', 'get_exception did not get the right exception'


# Generated at 2022-06-23 02:52:48.782413
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    def f1():
        return get_exception()

    def f2():
        try:
            raise MyException
        except Exception:
            return get_exception()

    assert f1() is None
    assert isinstance(f2(), MyException)

# Generated at 2022-06-23 02:52:52.385006
# Unit test for function get_exception
def test_get_exception():
    exc = None

    try:
        1/0
    except:
        exc = get_exception()

    # Python 3.x version
    if sys.version_info[0] >= 3:
        assert isinstance(exc, ZeroDivisionError)
    # Python 2 version
    else:
        assert str(exc) == 'integer division or modulo by zero'

# Generated at 2022-06-23 02:52:56.947784
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=redefined-builtin
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-23 02:53:00.708767
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('unit test exception')
    except:
        e = get_exception()
        assert 'unit test exception' == str(e)


# Generated at 2022-06-23 02:53:03.294380
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(1, 2, 3)
    except Exception:
        e = get_exception()
        assert e.args == (1, 2, 3)

# Generated at 2022-06-23 02:53:06.159191
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert e is get_exception()

# Generated at 2022-06-23 02:53:09.667074
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        exception = get_exception()
    assert exception.__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-23 02:53:13.261855
# Unit test for function get_exception
def test_get_exception():
    """Function to test get_exception."""
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',), e.args



# Generated at 2022-06-23 02:53:16.886688
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise RuntimeError('some error')

    def get_exception_wrapper():
        try:
            raise_exception()
        except:
            return get_exception()

    assert get_exception_wrapper() == RuntimeError('some error')



# Generated at 2022-06-23 02:53:27.433468
# Unit test for function get_exception
def test_get_exception():
    """Make sure that get_exception collects the current exception"""
    failing = None
    try:
        failing = 7 / 0
    except Exception:
        e = get_exception()
        assert(e.__class__.__name__ == 'ZeroDivisionError')
    assert(failing is None)

    def get_exception_inner():
        """Inner function with exception"""
        failing = None
        try:
            failing = 7 / 0
        except Exception:
            e = get_exception()
            return e
        assert(failing is None)

    raise_exception = get_exception_inner()
    assert(raise_exception.__class__.__name__ == 'ZeroDivisionError')

# Generated at 2022-06-23 02:53:30.199028
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        exc = get_exception()
    assert exc.__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-23 02:53:32.892881
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('a')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'a'

# Generated at 2022-06-23 02:53:42.381951
# Unit test for function get_exception
def test_get_exception():
    try:
        raise
    except:
        # Running on Python 3, we can always use sys.exc_info() to fetch
        # the exception
        expected_exc = sys.exc_info()[1]
        actual_exc = get_exception()
        assert expected_exc is actual_exc

    if sys.version_info[0] < 3:
        try:
            raise
        except:
            # Running on Python 2.4-2.7, the sys.exc_info() call could have
            # been inside a function on the stack
            expected_exc = sys.exc_info()[1]
            actual_exc = get_exception()
            assert expected_exc is actual_exc

# Generated at 2022-06-23 02:53:47.077466
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args[0] == 'foo'

    def test():
        try:
            raise ValueError('foo')
        except Exception:
            e = get_exception()
            return e

    e = test()
    assert isinstance(e, ValueError)
    assert e.args[0] == 'foo'


# Generated at 2022-06-23 02:53:50.030283
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise Exception("test")
        except Exception:
            e = get_exception()
        assert e.message == "test"

    foo()

# Generated at 2022-06-23 02:53:54.551316
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.six

    try:
        x = 5
        y = x/0
    except ZeroDivisionError:
        e = get_exception()
    assert(isinstance(e, ZeroDivisionError))

# Generated at 2022-06-23 02:53:57.656733
# Unit test for function get_exception

# Generated at 2022-06-23 02:54:00.499144
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        ex = get_exception()
    assert 'foo' == str(ex)
    assert Exception == type(ex)


# Generated at 2022-06-23 02:54:04.148078
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-23 02:54:07.640501
# Unit test for function get_exception
def test_get_exception():
    result = False
    try:
        x = []
        x[0]
    except:
        result = get_exception()
        print(result)

    assert result is not False



# Generated at 2022-06-23 02:54:16.527400
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError(u'Hello')
        except Exception:
            e = get_exception()
            assert not isinstance(e, ValueError)
            assert isinstance(e, Exception)
            assert str(e) == u'Hello'

    foo()

    def bar():
        try:
            raise ValueError(u'World')
        except:
            e = get_exception()
            assert not isinstance(e, ValueError)
            assert isinstance(e, Exception)
            assert str(e) == u'World'

    bar()

# Generated at 2022-06-23 02:54:19.387342
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except:
        e = get_exception()
        assert e.args == ('Test exception',)



# Generated at 2022-06-23 02:54:23.091880
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except (ValueError, AttributeError):
        ex = get_exception()
    else:
        assert False, 'Should raise exception'
    assert ex.args == ('test', ), 'Exception has wrong contents'


# Generated at 2022-06-23 02:54:26.413445
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Something went wrong')
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert isinstance(e, ValueError)


# Generated at 2022-06-23 02:54:29.380520
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1
        y = x + 'foo'
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'TypeError'



# Generated at 2022-06-23 02:54:31.903454
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1
        y = 2
        z = x + y
    except Exception:
        z = get_exception()
    assert z is not None

# Generated at 2022-06-23 02:54:35.426225
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test Exception')
    except:
        e = get_exception()
        assert e.message == 'Test Exception'



# Generated at 2022-06-23 02:54:39.076498
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()

    assert isinstance(exc, ValueError)
    assert str(exc) == 'foo'

# Generated at 2022-06-23 02:54:42.658164
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-23 02:54:44.873407
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert 'foo' in str(e)

# Generated at 2022-06-23 02:54:48.220612
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'
    else:
        assert False, 'get_exception did not catch the exception'

# Generated at 2022-06-23 02:54:51.178889
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'test exception'


# Generated at 2022-06-23 02:54:55.770456
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        (etype, value, trace) = sys.exc_info()
        exception = get_exception()
        if exception != value:
            raise RuntimeError('get_exception() did not return the right exception value')
        if type(exception) != etype:
            raise RuntimeError('get_exception() did not return the right exception class')


# Generated at 2022-06-23 02:55:05.061597
# Unit test for function get_exception
def test_get_exception():
    def do_raise():
        raise RuntimeError('foo')

    def do_get_exception():
        try:
            raise RuntimeError('foo')
        except Exception:
            e = get_exception()

        return e

    if get_exception() is not None:
        raise SyntaxError('get_exception expected None when not in an exception handler')

    if do_raise().__str__() != do_get_exception().__str__():
        raise SyntaxError('get_exception and explicit raise do not match')