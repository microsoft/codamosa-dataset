

# Generated at 2022-06-11 06:18:05.649471
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test")
    except Exception:
        e = get_exception()
        assert(str(e) == "Test")



# Generated at 2022-06-11 06:18:09.667811
# Unit test for function get_exception

# Generated at 2022-06-11 06:18:12.359821
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:18:15.155327
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise Exception('Foo')
        except Exception:
            e = get_exception()
            assert 'Foo' in str(e)

    test()

# Generated at 2022-06-11 06:18:17.902001
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        assert e.__class__ == ValueError



# Generated at 2022-06-11 06:18:22.856678
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception

    This test is separated out into a function rather than a module so it
    can be run by the existing unit tests.
    """
    # pylint: disable=import-error,no-name-in-module
    try:
        raise TypeError('bogus_error')
    except Exception:
        e = get_exception()

    assert e.args == ('bogus_error',)

# Generated at 2022-06-11 06:18:26.786982
# Unit test for function get_exception
def test_get_exception():
    def raise_error():
        raise RuntimeError('testing')


# Generated at 2022-06-11 06:18:30.015545
# Unit test for function get_exception
def test_get_exception():
    # Raising RuntimeError just to test that we get the right exception back
    try:
        raise RuntimeError('fun')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)

# Generated at 2022-06-11 06:18:34.962168
# Unit test for function get_exception
def test_get_exception():
    """ Test get_exception() for KeyError

    This is a good basic test for get_exception()
    """
    assert get_exception() is None
    try:
        {}['foo']
    except KeyError:
        assert get_exception() is not None
        assert type(get_exception()) is KeyError



# Generated at 2022-06-11 06:18:39.589171
# Unit test for function get_exception
def test_get_exception():
    def testfunc():
        raise Exception

    try:
        testfunc()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

    # Test that the exception is the same all the way up the stack

# Generated at 2022-06-11 06:18:50.884351
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-11 06:18:53.946910
# Unit test for function get_exception
def test_get_exception():
    try:
        [][1]
    except Exception:
        assert get_exception().args[0] == 'list index out of range'


# Generated at 2022-06-11 06:18:57.398438
# Unit test for function get_exception
def test_get_exception():
    def inner_function():
        try:
            raise Exception('foo')
        except:
            return get_exception()

    e = inner_function()
    assert str(e) == 'foo'
    assert repr(e) == "Exception('foo',)"



# Generated at 2022-06-11 06:19:01.589342
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=unreachable
        int('a')
    except:
        e = get_exception()
        assert str(e) == 'invalid literal for int() with base 10: \'a\''

# Generated at 2022-06-11 06:19:07.025917
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("unit test")
    except RuntimeError:
        exc = get_exception()
        if exc.__str__() != "unit test":
            raise AssertionError('Expecting RuntimeError("unit test").  Got %s.' % exc)
    else:
        raise AssertionError('Did not raise expected exception.')

# Generated at 2022-06-11 06:19:10.539291
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('This is a test exception.')
    except TestException as e:
        assert e == get_exception()



# Generated at 2022-06-11 06:19:15.302101
# Unit test for function get_exception
def test_get_exception():
    """Make sure that we're getting the right information back."""
    def _raise_exception():
        raise ValueError("Some error for test_get_exception")

    try:
        _raise_exception()
    except Exception:
        exc_info = get_exception()
    assert isinstance(exc_info, ValueError)
    assert "Some error for test_get_exception" == str(exc_info)



# Generated at 2022-06-11 06:19:18.438672
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
    else:
        assert False, 'Exception not raised'



# Generated at 2022-06-11 06:19:23.790657
# Unit test for function get_exception
def test_get_exception():
    try:
        f = open('/this/does/not/exist')
    except Exception:
        e = get_exception()
        assert e.args[0] == 2
    else:
        assert False, 'Expected to see an exception'

# Unit tests for literal_eval

# Generated at 2022-06-11 06:19:26.430813
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('ValueError exception')
    except:
        e = get_exception()
    assert str(e) == 'ValueError exception'

# Generated at 2022-06-11 06:19:47.613122
# Unit test for function get_exception

# Generated at 2022-06-11 06:19:49.573235
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)

# Generated at 2022-06-11 06:19:53.154982
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        exc = get_exception()
        exc.args = ('Test exception',)
        assert exc == Exception('Test exception'), "'exc' is '%s' instead of '%s'" % (exc, Exception('Test exception'))

# Generated at 2022-06-11 06:19:55.295269
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("boo")
    except Exception:
        assert isinstance(get_exception(), Exception)
    assert get_exception() is None

# Generated at 2022-06-11 06:19:57.089667
# Unit test for function get_exception
def test_get_exception():
    try:
        int("blah")
    except Exception:
        ex = get_exception()
    assert isinstance(ex, ValueError)


# Generated at 2022-06-11 06:20:00.285640
# Unit test for function get_exception
def test_get_exception():

    def raise_exception(msg):
        try:
            raise Exception(msg)
        except Exception:
            e = get_exception()
            return e

    result = raise_exception('test')
    assert result.args == ('test',)



# Generated at 2022-06-11 06:20:03.456685
# Unit test for function get_exception
def test_get_exception():
    def raise_it(arg):
        raise AttributeError(arg)

    try:
        raise_it('foo')
    except:
        e = get_exception()
        assert e.args[0] == 'foo'



# Generated at 2022-06-11 06:20:05.212967
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("TEST")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)


# Generated at 2022-06-11 06:20:09.251495
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        exc = get_exception()
        # Make sure the the returned type matches what we raised
        assert isinstance(exc, ValueError)
    try:
        1/0
    except:
        exc = get_exception()
        # Make sure we can use the exception
        assert 'divide' in str(exc)

# Generated at 2022-06-11 06:20:18.554869
# Unit test for function get_exception
def test_get_exception():
    # This will fail if one of these modules is missing but that's okay.  We'll
    # catch the exception later.
    import errno
    import ansible.module_utils.six
    # Suppress these exceptions: pylint: disable=import-error, no-name-in-module
    from ansible.module_utils.six.moves import builtins

    # Make sure that get_exception returns the current exception
    try:
        raise Exception()
    except Exception:
        assert get_exception() is sys.exc_info()[1]

    # Make sure that get_exception works on different exception types
    try:
        raise Exception()
    except Exception:
        assert get_exception() is sys.exc_info()[1]

    try:
        raise ValueError()
    except Exception:
        assert get_

# Generated at 2022-06-11 06:20:56.887946
# Unit test for function get_exception
def test_get_exception():
    # call a function that generates an exception
    def test_func():
        raise RuntimeError("test exception")
    # call the function and capture the exception
    try:
        test_func()
    except Exception:
        exc = get_exception()
    # confirm we captured the exception
    if not isinstance(exc, RuntimeError):
        raise RuntimeError("get_exception failed")
    if str(exc) != "test exception":
        raise RuntimeError("get_exception capture failed")

# Generated at 2022-06-11 06:21:01.561929
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        # If this gets output then the function isn't working
        raise TestException('This should not be visible')
    except Exception:
        err = get_exception()
    print(err)
    assert isinstance(err, TestException)
    assert str(err) == 'This should not be visible'


# Generated at 2022-06-11 06:21:05.581065
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'test_get_exception'

    try:
        literal_eval('test_get_exception')
    except Exception:
        e = get_exception()
    assert str(e) == "malformed string"

# Generated at 2022-06-11 06:21:10.160172
# Unit test for function get_exception
def test_get_exception():
    """UnitTest for function get_exception"""
    try:
        raise RuntimeError("foo")
    except:
        if get_exception().message != "foo":
            raise AssertionError("returned wrong message")
        if get_exception().__class__.__name__ != "RuntimeError":
            raise AssertionError("returned wrong class")

# Generated at 2022-06-11 06:21:16.709862
# Unit test for function get_exception
def test_get_exception():
    try:
        test_var = 1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert type(e) is ZeroDivisionError

    try:
        test_var = 1 / '0'
    except TypeError:
        e = get_exception()
        assert type(e) is TypeError

    try:
        raise ValueError('test123')
    except ValueError:
        e = get_exception()
        assert str(e) == 'test123'

# Generated at 2022-06-11 06:21:22.043564
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> get_exception() is None
    True
    >>> try:
    ...     a = 1 + '1'
    ... except Exception:
    ...     e = get_exception()
    ...     str(e) == 'unsupported operand type(s) for +: \\'int\\' and \\'str\\''
    True
    >>> get_exception() is None
    True
    '''
    pass


# Generated at 2022-06-11 06:21:23.908938
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    t = None
    try:
        raise ValueError('foo')
    except Exception:
        t = get_exception()
    assert str(t) == 'foo'

# Generated at 2022-06-11 06:21:26.391982
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException()
    except Exception:
        e = get_exception()
    assert isinstance(e, MyException)
    assert str(e) is not ''

# Generated at 2022-06-11 06:21:28.648717
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
        assert str(e) == 'test'


# Generated at 2022-06-11 06:21:31.732511
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'Test Exception' in str(e)


# Generated at 2022-06-11 06:22:38.049232
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('my error')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('my error', )

# Generated at 2022-06-11 06:22:40.454412
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except RuntimeError:
        e = get_exception()
    assert e.args[0] == "This is a test"


# Generated at 2022-06-11 06:22:50.324916
# Unit test for function get_exception
def test_get_exception():
    import six
    import random
    import pytest

    # No exception
    try:
        exception = get_exception()
        assert exception is None
    except:
        assert False, "Got an exception when one wasn't raised"

    # Some exception
    try:
        raise ValueError("Boom")
    except:
        exception = get_exception()
    assert isinstance(exception, ValueError), "Got the wrong exception back"
    assert exception.args[0] == "Boom"

    # Try a few other exception types
    for exception_class in (TypeError, IOError, six.builtins.OSError,
            zero_div_error, random.Random, pytest.fail.Exception):
        try:
            raise exception_class("Boom")
        except:
            exception = get_exception()

# Generated at 2022-06-11 06:22:54.875443
# Unit test for function get_exception
def test_get_exception():
    def _raise_exception():
        raise Exception('hello')

    try:
        _raise_exception()
    except:
        got_exception = get_exception()

    assert got_exception
    assert isinstance(got_exception, Exception)
    assert got_exception.args == ('hello',)


# Generated at 2022-06-11 06:22:57.085430
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        exc = get_exception()
        assert exc.__str__() == "foo"

# Generated at 2022-06-11 06:23:01.755346
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        assert get_exception() is e
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert repr(e) == repr(RuntimeError('test'))


# Generated at 2022-06-11 06:23:07.741637
# Unit test for function get_exception
def test_get_exception():
    def test(msg):
        try:
            raise Exception(msg)
        except:
            ex = get_exception()
            if ex.__str__() == msg:
                print('Success: "{0}" matches "{1}"'.format(ex.__str__(), msg))
            else:
                print('Failure: "{0}" does not match "{1}"'.format(ex.__str__(), msg))
    test('test')

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:23:10.782306
# Unit test for function get_exception
def test_get_exception():
    # Does try/except/re-raise work?
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert e.args == ('foo',)
        raise
    assert False, 'Should not have gotten here'


# Generated at 2022-06-11 06:23:12.907554
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testing')
    except:
        res = get_exception()
    assert res.args == ('testing',)

# Generated at 2022-06-11 06:23:17.530625
# Unit test for function get_exception
def test_get_exception():
    for exception in (ValueError, TypeError, KeyError, IndexError):
        try:
            raise exception
        except Exception:
            e = get_exception()
        if not isinstance(e, exception):
            raise AssertionError('Got %s instead of %s' % (e.__class__.__name__, exception.__name__))
    return True



# Generated at 2022-06-11 06:25:43.224375
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception
    """
    try:
        a = 1/0
    except ZeroDivisionError:
        e = get_exception()
    assert e.args[0] == "integer division or modulo by zero"

# Generated at 2022-06-11 06:25:47.109423
# Unit test for function get_exception
def test_get_exception():
    """test for function get_exception"""
    try:
        raise RuntimeError('test_get_exception')
    except:
        exception = get_exception()
    assert isinstance(exception, RuntimeError)
    assert str(exception) == 'test_get_exception'



# Generated at 2022-06-11 06:25:49.234417
# Unit test for function get_exception
def test_get_exception():
    # get_exception should not raise an exception
    try:
        raise ValueError('test')
    except ValueError:
        get_exception()



# Generated at 2022-06-11 06:25:51.157216
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)

# Generated at 2022-06-11 06:25:54.526144
# Unit test for function get_exception
def test_get_exception():
    """
    Function get_exception tests.

    :return:
              None
    """
    try:
        raise IndexError('Hand-raised error')
    except:
        e = get_exception()
        if not isinstance(e, IndexError):
            raise Exception('get_exception() did not return the right Exception')

# Generated at 2022-06-11 06:25:56.176751
# Unit test for function get_exception
def test_get_exception():
    try:
        print(10 / 0)
    except Exception:
        e = get_exception()
    
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-11 06:25:59.689709
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=pointless-statement
        [][1]
    except Exception:
        exc = get_exception()
        assert isinstance(str(exc), str)
        assert isinstance(unicode(exc), unicode)
        assert isinstance(repr(exc), str)

# Generated at 2022-06-11 06:26:07.119957
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import reraise

    try:
        raise ValueError
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)

    try:
        raise ValueError
    except:
        try:
            reraise(TypeError, "oops")
        except TypeError as exc:
            assert isinstance(exc, TypeError)
        else:
            assert False, "should have raised"

    try:
        raise ValueError
    except:
        try:
            reraise(TypeError, "oops", get_exception())
        except TypeError as exc:
            assert isinstance(exc, TypeError)
            assert isinstance(exc.__cause__, ValueError)
        else:
            assert False, "should have raised"


# Generated at 2022-06-11 06:26:09.208463
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
    assert e.__class__.__name__ == 'RuntimeError'


# Generated at 2022-06-11 06:26:10.910707
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('helloworld')
    except:
        assert get_exception().args[0] == 'helloworld'