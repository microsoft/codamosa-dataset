

# Generated at 2022-06-11 06:18:04.487097
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Fake exception')
    except:
        assert isinstance(get_exception(), ValueError)

# Generated at 2022-06-11 06:18:06.381943
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except:
        e = get_exception()
    return e


# Generated at 2022-06-11 06:18:17.168912
# Unit test for function get_exception
def test_get_exception():
    """
    Test that get_exception returns a correct exception

    The test should work by making a try/except block that catches an exception,
    runs get_exception and verifies that the exception was the one that was
    caught.

    It's not obvious how to do that because you can't inspect an exception
    without another try/except block.  So this test works by raising a
    TestException (a class defined below) and catching that exception.  Then
    we raise the get_exception returned value and catch that exception.  If
    that exception was a TestException and was the same exception value that
    was raised earlier then the test passes.
    """
    class TestException(Exception):
        """Exception class to test get_exception"""

    # pylint: disable=invalid-name

# Generated at 2022-06-11 06:18:20.352037
# Unit test for function get_exception
def test_get_exception():
    import pytest

    class MyException(Exception):
        pass

    exc = MyException('This is a test')

    try:
        raise exc
    except MyException:
        e = get_exception()
        assert e == exc



# Generated at 2022-06-11 06:18:24.612848
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)

    try:
        raise ValueError('foo')
    except Exception:
        pass

    e = get_exception()
    assert e is None

# Generated at 2022-06-11 06:18:36.396028
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.basic
    # create a test class
    class TestException(Exception):
        def __init__(self, test1, test2):
            self.test1 = test1
            self.test2 = test2
        def __str__(self):
            return "test string"

    # raise an exception
    try:
        raise TestException('1', '2')
    except Exception:
        e = get_exception()

    # see if we can access the exception class

# Generated at 2022-06-11 06:18:41.236789
# Unit test for function get_exception
def test_get_exception():
    def a():
        try:
            raise ValueError('foo')
        except ValueError as e:
            return e
        except:
            pass
        return None
    def b():
        try:
            raise ValueError('foo')
        except ValueError:
            return get_exception()
        except:
            pass
        return None
    assert a() == b()

# Generated at 2022-06-11 06:18:53.632598
# Unit test for function get_exception
def test_get_exception():
    def f1():
        try:
            raise RuntimeError
        except RuntimeError:
            return get_exception()
    exc = f1()
    assert isinstance(exc, RuntimeError)
    assert f1() is exc

    def f2():
        try:
            raise KeyError
        except:
            return get_exception()
    exc = f2()
    assert isinstance(exc, KeyError)
    assert f2() is exc

    def f3():
        try:
            raise KeyError
        except RuntimeError:
            pass
        except:
            return get_exception()
    exc = f3()
    assert isinstance(exc, KeyError)
    assert f3() is exc

    def f4():
        try:
            raise KeyError
        except (RuntimeError, KeyError):
            return get_

# Generated at 2022-06-11 06:18:57.250368
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    def f1():
        raise MyException('the exception')

    try:
        f1()
    except Exception:
        tb = get_exception()
    assert isinstance(tb, MyException)
    assert tb.args == ('the exception',)

# Generated at 2022-06-11 06:19:00.449367
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None

    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:19:12.174916
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test exception")
    except ValueError:
        e = get_exception()
        assert str(e) == "This is a test exception"


# Generated at 2022-06-11 06:19:22.236140
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function.

    This function is only used in place of except Exception: except Exception, e:

    The code using this function will look like ::

        def f():
            pass

        try:
            f()
        except Exception:
            e = get_exception()
            if isinstance(e, MyError):
                raise

    We need to verify that the get_exception() function returns the exception
    raised by the f() function.
    """
    class TestError(Exception):
        pass

    def f():
        raise TestError('Exception raised in f()')

    try:
        f()
    except Exception:
        e = get_exception()
    assert isinstance(e, TestError)



# Generated at 2022-06-11 06:19:24.527354
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert(str(e)) == 'foo'

# Generated at 2022-06-11 06:19:27.127955
# Unit test for function get_exception
def test_get_exception():
    import doctest
    import ansible.module_utils.basic

    results = doctest.testmod(ansible.module_utils.basic)
    assert results.failed == 0

# Generated at 2022-06-11 06:19:30.661157
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("testing")
    except Exception:
        e = get_exception()
        assert str(e) == "testing"
        assert e.__class__ == Exception
    print("OK")


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:19:32.869725
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except:
        e = get_exception()
    assert e.args == ('Test',)
test_get_exception()

# Generated at 2022-06-11 06:19:35.847459
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("An exception")
    except Exception as e:
        assert e == get_exception()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 06:19:38.277864
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)


# Generated at 2022-06-11 06:19:41.447638
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        result = get_exception()
        assert isinstance(result, RuntimeError)
        assert result.args == ('foo',)


# Generated at 2022-06-11 06:19:44.745087
# Unit test for function get_exception
def test_get_exception():
    def one():
        raise RuntimeError("This is a test")

    def two():
        one()

    try:
        two()
    except:
        e = get_exception()

    assert(str(e) == "This is a test")


# Generated at 2022-06-11 06:19:56.435727
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException("foo")
    except TestException as e:
        e2 = get_exception()
        assert e is e2
        assert TestException is e2.__class__
        assert "foo" == str(e2)



# Generated at 2022-06-11 06:19:59.488254
# Unit test for function get_exception
def test_get_exception():
    class OkException(Exception):
        pass

    def bork():
        raise OkException()

    try:
        bork()
    except OkException as e:
        assert e is get_exception()
    except:
        assert False, "Test raised the wrong exception"

# Generated at 2022-06-11 06:20:02.687274
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo', 'Exception value mismatch: %r' % (e.args)


# Generated at 2022-06-11 06:20:05.966942
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test error')
    except Exception:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'test error'

# vim: set sts=4 ts=4 sw=4 et:

# Generated at 2022-06-11 06:20:11.446875
# Unit test for function get_exception
def test_get_exception():
    # The type of exception generated by a raise statement depends on the Python
    # version.  We need to make sure that we're able to get it no matter what
    # Python version we're on.  This means that our unit test for this function
    # will itself generate an exception in order to test that it works correctly.

    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('foo',)

# Generated at 2022-06-11 06:20:20.109291
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception can get the current exception"""
    import nose

    def should_raise():
        raise ValueError('invalid value')

    try:
        should_raise()
    except ValueError:
        raise nose.SkipTest('bug in Python; http://bugs.python.org/issue14965')

    try:
        should_raise()
    except ValueError:
        try:
            nose.tools.assert_equal(get_exception().message, 'invalid value')
        except AttributeError:
            nose.tools.assert_equal(get_exception().args[0], 'invalid value')
    else:
        nose.tools.assert_false(True, 'should raise exception')


# Generated at 2022-06-11 06:20:23.091979
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
        assert 'foo' in str(e)


# Generated at 2022-06-11 06:20:32.630061
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e == get_exception()

if __name__ == '__main__':
    if sys.version_info[0] == 2:
        # py.test does not get the exception information if we do not do this.
        # This has something to do with how Python 2.x handles exceptions.
        # http://stackoverflow.com/questions/1697438/in-python-why-does-a-generator-function-need-to-be-called-for-an-exception-to-be
        test_get_exception()
    else:
        test_get_exception()

# Generated at 2022-06-11 06:20:37.868814
# Unit test for function get_exception

# Generated at 2022-06-11 06:20:41.076432
# Unit test for function get_exception
def test_get_exception():
    '''Unit test for exception handling'''

    try:
        raise TypeError('This is a test')
    except TypeError:
        assert get_exception() is not None


# Generated at 2022-06-11 06:20:51.722118
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('a bad thing happened')
    except Exception:
        assert get_exception().args[0] == 'a bad thing happened'

# Generated at 2022-06-11 06:20:54.028241
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        ex = get_exception()
    assert ex.args == ('foo',)



# Generated at 2022-06-11 06:20:56.656007
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Dummy')
    except:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'Dummy'

# Generated at 2022-06-11 06:20:59.152869
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError
    except Exception:
        e = get_exception()
    assert type(e) is ZeroDivisionError



# Generated at 2022-06-11 06:21:01.863144
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)
    assert 'integer' in e.args[0]

# Generated at 2022-06-11 06:21:04.711812
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Unittest exception')
    except ValueError:
        pass
    e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('Unittest exception',)



# Generated at 2022-06-11 06:21:12.284105
# Unit test for function get_exception
def test_get_exception():
    """Verify that get_exception returns the last exception raised.

    Create a function that always raises an exception that can be caught.
    Then call it and verify that the exception you caught is what you asked
    it to raise.
    """
    class TestException(Exception):
        """Dummy Exception to throw and catch"""
        pass

    def throwit():
        """Throw an exception"""
        raise TestException()

    try:
        throwit()
    except Exception:
        e = get_exception()
        assert type(e) == TestException, 'Wrong exception type returned by get_exception'


# Generated at 2022-06-11 06:21:14.485713
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("eh!")
    except:
        exc = get_exception()
    assert str(exc) == "eh!"

# Generated at 2022-06-11 06:21:17.964034
# Unit test for function get_exception
def test_get_exception():
    assert None is get_exception()
    try:
        raise RuntimeError("test exception")
    except:
        e = get_exception()
    assert None is not e
    assert "test exception" == str(e)


# Generated at 2022-06-11 06:21:22.495260
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'foo'
    try:
        raise Exception('bar')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'bar'


# Generated at 2022-06-11 06:21:33.475163
# Unit test for function get_exception
def test_get_exception():
    class FooBar(Exception):
        pass
    try:
        raise FooBar()
    except:
        exc1 = get_exception()
    assert isinstance(exc1, FooBar)


# Generated at 2022-06-11 06:21:40.319775
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise RuntimeError('An exception')
        except RuntimeError:
            return get_exception()

    def g():
        try:
            raise RuntimeError('An exception')
        except RuntimeError as e:
            return e

    e0 = f()
    e1 = g()

    assert e0.__class__ == RuntimeError
    assert e0.args == ('An exception',)

    assert e1.__class__ == RuntimeError
    assert e1.args == ('An exception',)


# Generated at 2022-06-11 06:21:46.276004
# Unit test for function get_exception
def test_get_exception():

    # First test
    try:
        raise TypeError("This is a test exception")
    except Exception:
        e = get_exception()
        assert getattr(e, "args", False)
        assert type(e) == TypeError

    # Second test
    try:
        raise ValueError("This is a test exception")
    except Exception:
        e = get_exception()
        assert getattr(e, "args", False)
        assert type(e) == ValueError

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:21:52.927628
# Unit test for function get_exception
def test_get_exception():
    test_exception_message = 'test exception'
    try:
        raise Exception(test_exception_message)
    except Exception:
        exc = get_exception()
        assert hasattr(exc, 'message'), "Exception has no 'message' attribute"
        assert exc.message == test_exception_message, "Exception message doesn't match. %s != %s" % (exc.message != test_exception_message)
test_get_exception()

# Generated at 2022-06-11 06:21:55.956010
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == "foo"

# Generated at 2022-06-11 06:21:58.837694
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        type_of_e = type(e)

    assert type_of_e is type(Exception())

# Generated at 2022-06-11 06:22:03.357334
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception), ('get_exception() returned %s instead of an exception object' % e)
    assert str(e) == 'test', ('get_exception() returned %s instead of an exception object' % e)


# Generated at 2022-06-11 06:22:11.190134
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    # Simple verify that it works
    try:
        raise TypeError("example")
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert e.args == ("example", )

    # Verify that it resets the exception state
    assert sys.exc_info() == (None, None, None)

    # Verify that it can be nested
    try:
        try:
            raise TypeError("example")
        except TypeError:
            e = get_exception()
        assert isinstance(e, TypeError)
        assert e.args == ("example", )

        # Verify that it resets the exception state
        assert sys.exc_info() == (None, None, None)
    except TypeError:
        pass

# Generated at 2022-06-11 06:22:12.877952
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:22:15.963282
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        exception = get_exception()
        assert exception.args[0] == 'foo'
    return True


# Generated at 2022-06-11 06:22:34.118313
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Error')
    except Exception:
        e = get_exception()
        assert e.message == 'Test Error'

# Generated at 2022-06-11 06:22:36.075748
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert str(e) == 'test exception'

# Generated at 2022-06-11 06:22:38.553953
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    else:
        e = None

    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-11 06:22:40.490058
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
    assert str(e) == 'test exception'



# Generated at 2022-06-11 06:22:42.610260
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
    assert repr(e) == "Exception('foobar',)"

# Generated at 2022-06-11 06:22:44.559956
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-11 06:22:46.744844
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError
    except NameError:
        e = get_exception()
    assert isinstance(e, NameError)

# Generated at 2022-06-11 06:22:51.416736
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AttributeError('bogus attribute')
    except:
        e = get_exception()
    if not isinstance(e, AttributeError):
        # This would mean we failed to get the exception
        raise AssertionError('get_exception did not return AttributeError')

# Generated at 2022-06-11 06:22:53.896394
# Unit test for function get_exception
def test_get_exception():

    try:
        1 / 0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-11 06:22:57.301460
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test exception")
    except Exception:
        exception = get_exception()
        assert exception.args == ("test exception",)
    else:
        assert False, "Exception was not raised"


# Generated at 2022-06-11 06:23:36.759790
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('foo')
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)
        assert e.args == ('foo',)
    else:
        assert False, 'Exception not raised'

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:23:40.565448
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception()

    This is a simple unit test that exercises the function get_exception.
    """
    try:
        raise RuntimeError("Bad Bad Bad")
    except:
        assert get_exception().args[0] == "Bad Bad Bad"



# Generated at 2022-06-11 06:23:42.945193
# Unit test for function get_exception
def test_get_exception():
    try:
        5 / 0
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-11 06:23:45.293368
# Unit test for function get_exception
def test_get_exception():
    def foo():
        a = b
    try:
        foo()
    except:
        e = get_exception()
    assert isinstance(e, NameError)



# Generated at 2022-06-11 06:23:47.415623
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError
    except NameError as e:
        assert e == get_exception()


# Generated at 2022-06-11 06:23:50.333046
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise TypeError('foo')

    try:
        test()
    except TypeError as e:
        assert id(e) == id(get_exception())



# Generated at 2022-06-11 06:23:54.578839
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 0
        assert 1/a == float('inf')  # noqa: F821
    except:
        e = get_exception()

    assert e.message == 'integer division or modulo by zero'
# End unit test for function get_exception


# Generated at 2022-06-11 06:23:57.908873
# Unit test for function get_exception
def test_get_exception():
    def do_raise():
        raise RuntimeError('Test exception')
    try:
        do_raise()
    except RuntimeError:
        err = get_exception()
    assert str(err) == 'Test exception'



# Generated at 2022-06-11 06:24:01.196964
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        name, msg, traceback = sys.exc_info()
        assert e == msg
        assert msg.args == ('foo',)



# Generated at 2022-06-11 06:24:03.034266
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert type(get_exception()) == Exception


# Generated at 2022-06-11 06:24:39.904353
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test'


# Generated at 2022-06-11 06:24:44.728604
# Unit test for function get_exception
def test_get_exception():
    exception_str = 'This is an exception'
    try:
        raise Exception(exception_str)
    except Exception:
        e = get_exception()
        if isinstance(e, Exception) and str(e) == exception_str:
            return
        else:
            raise AssertionError('test_get_exception: not a valid exception')


# Generated at 2022-06-11 06:24:47.340706
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert "foo" in str(e)



# Generated at 2022-06-11 06:24:49.393422
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except ValueError as e:
        assert e == get_exception()


# Generated at 2022-06-11 06:24:52.833606
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    else:
        assert False, "Exception wasn't raised.  Test failure"

    assert isinstance(e, Exception), "No exception was raised"
    assert get_exception()



# Generated at 2022-06-11 06:24:54.699596
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'


# Generated at 2022-06-11 06:24:58.174644
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert type(e) in (type(ZeroDivisionError()), type(ZeroDivisionError)), 'Expected ZeroDivisionError, got {0} instead'.format(type(e))

# Generated at 2022-06-11 06:25:03.344695
# Unit test for function get_exception
def test_get_exception():
    import traceback
    class CustomException(Exception):
        pass

    test_exception = CustomException('This is a test')
    try:
        raise test_exception
    except Exception:
        caught_exception = get_exception()

    try:
        assert caught_exception == test_exception
    except AssertionError:
        print(traceback.format_exc())
        raise


# Generated at 2022-06-11 06:25:07.271964
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_get_exception')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'test_get_exception'


# Generated at 2022-06-11 06:25:09.766197
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('fake exception')
    except Exception:
        e = get_exception()
    try:
        raise Exception('fake exception')
    except Exception as e:
        pass



# Generated at 2022-06-11 06:26:36.514760
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        if e.__class__ == Exception:
            print('get_exception passed unit test')


# Generated at 2022-06-11 06:26:39.139373
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0
    except:
        exc = get_exception()
    assert type(exc) == ZeroDivisionError
    assert str(exc) == 'division by zero'

# Generated at 2022-06-11 06:26:42.097905
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise ValueError("foo")
    try:
        foo()
    except ValueError as e:
        assert get_exception() is e
    else:
        raise AssertionError('An exception should have been raised')

# Generated at 2022-06-11 06:26:44.937245
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def f():
        try:
            raise "Test exception"
        except:
            return get_exception()

    assert f() == "Test exception"

# Generated at 2022-06-11 06:26:46.463522
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError()
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:26:49.441448
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert e.args[0] == 'foo'

    # Now make sure that the local variable is cleaned up by the function
    # call so we don't leak it
    assert 'e' not in locals()

# Generated at 2022-06-11 06:26:51.389596
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except:
        e = get_exception()
    assert e.args[0] == 'Test exception'

# Generated at 2022-06-11 06:26:53.482636
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'


# Generated at 2022-06-11 06:26:55.821243
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('ValueError')
    except ValueError:
        e = get_exception()
    print(e)
    assert e.message == 'ValueError'


# Generated at 2022-06-11 06:26:59.425937
# Unit test for function get_exception
def test_get_exception():
    try:
        # pylint: disable=undefined-variable
        raise AttributeError('This is a test')
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'AttributeError'
        assert str(e) == 'This is a test'

