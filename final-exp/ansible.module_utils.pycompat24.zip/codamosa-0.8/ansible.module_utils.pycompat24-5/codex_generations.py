

# Generated at 2022-06-11 06:18:08.546246
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        exception2 = get_exception()
        assert exception2 is e

# Generated at 2022-06-11 06:18:11.220336
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception.')
    except:
        e = get_exception()
        assert(isinstance(e, Exception))
        assert(str(e) == 'Test exception.')


# Generated at 2022-06-11 06:18:15.105414
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('dummy_execption')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('dummy_execption',)

# Generated at 2022-06-11 06:18:18.161816
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Hello")
    except RuntimeError as e:
        e2 = get_exception()
        assert e2 is e, "get_exception didn't return the current exception"


# Generated at 2022-06-11 06:18:21.176375
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('This is the error message')
    except:
        exception = get_exception()
        assert isinstance(exception, TestException)
        assert str(exception) == 'This is the error message'

# Generated at 2022-06-11 06:18:24.276558
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert e.args == ("This is a test", )

# Generated at 2022-06-11 06:18:28.121531
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Failing hard')
    except Exception:
        exc = get_exception()

    assert isinstance(exc, Exception)
    assert str(exc) == 'Failing hard'


# Generated at 2022-06-11 06:18:32.254971
# Unit test for function get_exception
def test_get_exception():
    got_exception = None
    try:
        raise Exception('Error message')
    except Exception:
        got_exception = get_exception()

    assert isinstance(got_exception, Exception)
    assert 'Error message' in str(got_exception)

# Generated at 2022-06-11 06:18:35.491216
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('message')
    except TypeError:
        exc = get_exception()
        assert isinstance(exc, TypeError)
        assert str(exc) == 'message'


# Generated at 2022-06-11 06:18:37.840490
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('test_exception')
    except KeyError as e:
        assert e == get_exception()


# Generated at 2022-06-11 06:18:49.737452
# Unit test for function get_exception

# Generated at 2022-06-11 06:18:52.211525
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        assert(get_exception() is not None)

# Generated at 2022-06-11 06:18:57.911609
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=protected-access
    exception_name = 'TestException'
    exception_instance = sys.modules[__name__].__dict__[exception_name]()
    try:
        raise exception_instance
    except:
        exc_info = sys.exc_info()
        get_exc_info = get_exception()

    assert exc_info[1] is get_exc_info
    assert str(get_exc_info) == exception_name


# Generated at 2022-06-11 06:19:02.152984
# Unit test for function get_exception
def test_get_exception():
    # Ensure we get the same error back that we raise
    try:
        raise NameError('testing')
    except NameError:
        e = get_exception()
    assert isinstance(e, NameError)
    assert 'testing' in str(e)

# Generated at 2022-06-11 06:19:06.316608
# Unit test for function get_exception
def test_get_exception():
    try:
        int('not an integer')
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.message == 'invalid literal for int() with base 10: \'not an integer\''

# Generated at 2022-06-11 06:19:08.797776
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        assert 'test' == get_exception().args[0]



# Generated at 2022-06-11 06:19:10.971440
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-11 06:19:13.743404
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass


# Generated at 2022-06-11 06:19:16.423263
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('failure')
    except Exception:
        e = get_exception()
        assert str(e) == 'failure'

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-11 06:19:18.486101
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        assert get_exception() is e

# Generated at 2022-06-11 06:19:30.280383
# Unit test for function get_exception
def test_get_exception():
    # Note: Cannot use pytest for this because Python 2.4 will not
    # run pytest
    try:
        raise Exception('hello')
    except:
        e = get_exception()

    assert str(e) == 'hello'
    assert isinstance(e, Exception)

# Generated at 2022-06-11 06:19:34.569832
# Unit test for function get_exception
def test_get_exception():
    def test_get_exception_func1():
        raise ValueError()

    def test_get_exception_func2():
        try:
            test_get_exception_func1()
        except Exception:
            e = get_exception()
            return e.__class__

    assert test_get_exception_func2() is ValueError


# Generated at 2022-06-11 06:19:36.638560
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        x = get_exception()
    assert isinstance(x, ZeroDivisionError)

# Generated at 2022-06-11 06:19:38.632966
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('fake name error')
    except NameError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:19:45.220807
# Unit test for function get_exception
def test_get_exception():
    foo = 1

    # Just check that this code is syntactically valid
    try:
        raise RuntimeError('test error')
    except Exception:
        e = get_exception()

    try:
        raise RuntimeError('test error')
    except Exception:
        e = get_exception()
        raise e

    # The same error should be raised again
    try:
        raise RuntimeError('test error')
    except Exception:
        e = get_exception()
        raise e
    except RuntimeError as new_e:
        assert e is new_e

# Generated at 2022-06-11 06:19:47.432063
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
        assert e.args == ("foo",)

# Generated at 2022-06-11 06:19:51.175601
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Testing exception stack retrieval")
    except RuntimeError as e:
        e2 = get_exception()
        assert e2 is e, "get_exception() failed to return the current exception"
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise

# Generated at 2022-06-11 06:19:53.323529
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Value error happened')
    except ValueError as e:
        assert get_exception() == e


# Generated at 2022-06-11 06:19:55.142390
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('unsupported operand type')
    except TypeError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:19:57.101938
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Test error')
    except TypeError:
        e = get_exception()
    assert str(e) == 'Test error'



# Generated at 2022-06-11 06:20:17.709098
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except:
        e = get_exception()
        if 'Test exception' not in str(e):
            raise AssertionError(
                'Unexpected return value {} from get_exception'.format(e))

# Generated at 2022-06-11 06:20:22.210335
# Unit test for function get_exception
def test_get_exception():
    try:
        int('hello')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == "invalid literal for int() with base 10: 'hello'"
    else:
        assert False, 'get_exception failed'


# Generated at 2022-06-11 06:20:25.141215
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exception = get_exception()

    assert isinstance(exception, RuntimeError)


# Unit tests for literal_eval

# Generated at 2022-06-11 06:20:31.004331
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('error')
    except TestException:
        e = get_exception()
        assert e.__str__() == 'error'
        assert e.__class__ == TestException
    except:
        raise AssertionError("get_exception didn't return the current exception")

# Generated at 2022-06-11 06:20:35.639751
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        e = get_exception()
    assert e.__class__.__name__ == 'RuntimeError'

    try:
        raise 1
    except:  # noqa
        e = get_exception()
    assert e.__class__.__name__ == 'int'

# Generated at 2022-06-11 06:20:38.258661
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()

    assert e.__class__ == ValueError

# Generated at 2022-06-11 06:20:41.868731
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except Exception:
        current_exception = get_exception()
        assert isinstance(current_exception, ValueError)
        assert current_exception.args == ("Test exception",)


# Generated at 2022-06-11 06:20:45.332538
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import ansible.module_utils.basic
    test_case = unittest.TestLoader().loadTestsFromModule(ansible.module_utils.basic)
    unittest.TextTestRunner().run(test_case)

# Generated at 2022-06-11 06:20:48.012862
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # noqa
    except:
        assert get_exception().__class__ == ZeroDivisionError  # noqa


# Generated at 2022-06-11 06:20:53.778203
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:  # pylint: disable=undefined-variable
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert e.__class__.__name__ == 'ZeroDivisionError'
        return True
    assert False, "No exception thrown by '1/0'"

# Generated at 2022-06-11 06:21:36.882331
# Unit test for function get_exception
def test_get_exception():
    import six

    import tempfile
    test_file = tempfile.NamedTemporaryFile(mode='w')

# Generated at 2022-06-11 06:21:37.732821
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        e2 = get_exception()
    assert e is e2



# Generated at 2022-06-11 06:21:38.690214
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test")
    except:
        e = get_exception()
    assert str(e) == "Test"

# vim: set et sw=4:

# Generated at 2022-06-11 06:21:41.451830
# Unit test for function get_exception
def test_get_exception():
    def test_function():
        try:
            raise ValueError

        except Exception:
            exception = get_exception()
            assert(exception.__class__.__name__ == 'ValueError')
            assert(exception.__class__ == ValueError)
            return

    try:
        test_function()
    except AssertionError:
        print('Error in get_exception')
        raise

# Generated at 2022-06-11 06:21:43.429546
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:21:45.300365
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('The actual exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'The actual exception'

# Generated at 2022-06-11 06:21:49.462410
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert str(e) == 'integer division or modulo by zero'
    else:
        raise AssertionError("ZeroDivisionError not raised!")


# Generated at 2022-06-11 06:21:52.667764
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        e = get_exception()
        assert e.args==('This is a test', )


# Generated at 2022-06-11 06:21:56.160110
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        exc = get_exception()
        assert exc.__str__() == 'This is a test exception'

# Generated at 2022-06-11 06:21:59.449545
# Unit test for function get_exception
def test_get_exception():
    """Test that the get_exception function returns the right exception"""
    try:
        raise RuntimeError('test')
    except Exception:
        assert get_exception() == sys.exc_info()[1]



# Generated at 2022-06-11 06:23:07.260844
# Unit test for function get_exception
def test_get_exception():
    try:
      3 / 0
    except:
      e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:23:10.099553
# Unit test for function get_exception
def test_get_exception():
    def divide(numerator, denominator):
        return numerator / denominator

    try:
        divide(1, 0)
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ZeroDivisionError)



# Generated at 2022-06-11 06:23:14.666240
# Unit test for function get_exception
def test_get_exception():
    def f1():
        try:
            raise Exception('test exception')
        except Exception:
            assert get_exception()

    def f2():
        try:
            raise Exception('test exception')
        except Exception:
            try:
                raise Exception('test exception2')
            except Exception:
                assert get_exception()

    f1()
    f2()



# Generated at 2022-06-11 06:23:20.548989
# Unit test for function get_exception
def test_get_exception():
    def exception_raiser():
        raise Exception("foo")

    try:
        exception_raiser()
    except Exception:
        exception = get_exception()
        print("%s raised: %s" % (Exception.__name__, exception))
        if exception.args[0] != 'foo':
            raise Exception("get_exception() returns the wrong exception")
        print("ok")


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:23:23.875236
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('hi')
    except:
        assert get_exception().args == ('hi',)


if __name__ == "__main__":
    from ansible.module_utils import basic
    basic.main(module=None)

# Generated at 2022-06-11 06:23:28.055057
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testing 1 2 3')
    except Exception:  # pylint: disable=broad-except
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert exc.args == ('testing 1 2 3',)


# Test the literal_eval function

# Generated at 2022-06-11 06:23:30.508285
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
        assert e.__class__.__name__ == 'ValueError'



# Generated at 2022-06-11 06:23:33.074977
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException()
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)

# Generated at 2022-06-11 06:23:35.461714
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('unit test exception')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:23:38.798190
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception as e:
        orig_e = e
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert orig_e is e

# Generated at 2022-06-11 06:26:10.948377
# Unit test for function get_exception
def test_get_exception():
    def raise_exc():
        raise Exception("foo")
    try:
        raise_exc()
    except Exception as e:
        assert e == get_exception()



# Generated at 2022-06-11 06:26:12.731815
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('blah')
    except RuntimeError as e:
        assert e == get_exception()


# Generated at 2022-06-11 06:26:16.720339
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test_get_exception")
    except:
        exc = get_exception()
        # need to compare the string because the same exception will
        # appear twice in long tracebacks
        assert str(exc) == "test_get_exception"
        assert exc.__class__ == Exception


# Generated at 2022-06-11 06:26:19.975745
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()

    assert e
    assert 'test exception' in str(e)
    assert type(e) is ValueError



# Generated at 2022-06-11 06:26:21.325337
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-11 06:26:28.112506
# Unit test for function get_exception
def test_get_exception():
    def good_func():
        return 'foo'

    def bad_func():
        1/0

    try:
        good_func()
    except Exception:
        print('We should not catch good_func: %s %s %s' % sys.exc_info())

    try:
        bad_func()
    except Exception:
        print('We should catch bad_func: %s %s %s' % sys.exc_info())

    try:
        bad_func()
    except Exception:
        e = get_exception()
        print('We should catch bad_func: %s %s %s' % (type(e), e, e.args))
        if sys.version_info < (3, ):
            the_args = e.args
        else:
            the_args = e.args[0]
       

# Generated at 2022-06-11 06:26:30.004839
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('TEST')
    except Exception:
        e = get_exception()
        assert e.args == ('TEST',)

# Generated at 2022-06-11 06:26:32.984160
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise KeyError('this is a test exception')
        except:
            return get_exception()

    ex = inner()
    assert ex.__str__() == 'this is a test exception'


# Generated at 2022-06-11 06:26:39.139780
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException("Test exception")
    except TestException as e:
        assert get_exception() == e

    try:
        raise TestException("Test exception")
    except TestException:
        e = get_exception()
        assert e != None
        assert isinstance(e, TestException)

    try:
        raise TestException("Test exception")
    except Exception:
        e = get_exception()
        assert e != None
        assert isinstance(e, TestException)

# Generated at 2022-06-11 06:26:46.342695
# Unit test for function get_exception
def test_get_exception():
    # It would be nice to be able to test get_exception directly, but it's
    # not possible to catch an uncaught exception.  So, define a function
    # that will raise an exception, catch that exception, then call
    # get_exception and make sure we get the same exception back.
    def raise_exception(msg):
        raise RuntimeError(msg)
    try:
        raise_exception("Testing exception handling")
    except Exception:
        got_exc = get_exception()
    assert isinstance(got_exc, RuntimeError)
    assert got_exc.args[0] == "Testing exception handling"