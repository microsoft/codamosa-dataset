

# Generated at 2022-06-11 06:18:08.995235
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise Exception()
    except:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-11 06:18:19.509754
# Unit test for function get_exception
def test_get_exception():
    # Test that a regular exception works
    try:
        raise ValueError("This is an intentional exception")
    except ValueError:
        e = get_exception()
        assert str(e) == "This is an intentional exception"

    # Test that a chained exception works
    class UserError(Exception):
        pass
    class InternalError(Exception):
        pass

    try:
        try:
            raise UserError("A user did something wrong")
        except UserError:
            raise InternalError("An internal error occured while handling the user error")
    except InternalError:
        e = get_exception()
        assert str(e) == "An internal error occured while handling the user error"
        assert str(e.__context__) == "A user did something wrong"

    # Test that another chained exception works

# Generated at 2022-06-11 06:18:21.773115
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
    assert e.args[0] == 'test'



# Generated at 2022-06-11 06:18:30.443289
# Unit test for function get_exception
def test_get_exception():
    try:
        assert False
    except AssertionError as e:
        assert get_exception() is e

    # It also works when the exception has been caught and re-raised
    try:
        try:
            assert False
        except AssertionError as e:
            raise Exception('inner')
    except Exception as e:
        assert get_exception() is e

    # Of course, we can also catch the exception
    try:
        assert False
    except AssertionError as e:
        assert get_exception() is e
        ex = e
    assert ex is e

# Generated at 2022-06-11 06:18:36.687911
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(b"\x8a\xbc")
    except Exception:
        exception = get_exception()
    assert exception != None
    assert isinstance(exception, Exception)
    assert isinstance(exception, str)
    assert isinstance(exception, bytes)
    assert str(exception) == b"\x8a\xbc"
    assert bytes(exception) == b"\x8a\xbc"

# Generated at 2022-06-11 06:18:38.541653
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        print('Caught exception:', get_exception())

# Generated at 2022-06-11 06:18:41.659255
# Unit test for function get_exception

# Generated at 2022-06-11 06:18:47.968329
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception('foo')
    try:
        raise_exception()
        assert False, 'test_get_exception should have raised an exception'
    except Exception:
        e = get_exception()
        assert str(e) == 'foo', 'test_get_exception should have caught the exception raised'



# Generated at 2022-06-11 06:18:51.282998
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception('Failed')

    try:
        raise_exception()
    except Exception:
        assert str(get_exception()) == 'Failed'

# Generated at 2022-06-11 06:18:53.897939
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ZeroDivisionError("foo")
    except ZeroDivisionError as e:
        assert get_exception() is e

# Generated at 2022-06-11 06:19:05.720078
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        try:
            raise TypeError('bar')
        except TypeError:
            assert get_exception() == e

# Generated at 2022-06-11 06:19:12.540596
# Unit test for function get_exception
def test_get_exception():
    class SomeException(Exception):
        pass


# Generated at 2022-06-11 06:19:19.614715
# Unit test for function get_exception
def test_get_exception():
    import pytest
    handler = pytest.skip.Exception

    class MyException(Exception):
        pass

    def f():
        try:
            raise handler
        except:
            e = get_exception()
            assert isinstance(e, handler)
            return
        assert False, "Shouldn't get here"

    def g():
        try:
            raise MyException
        except:
            e = get_exception()
            assert isinstance(e, MyException)
            return
        assert False, "Shouldn't get here"

    f()
    g()

# Generated at 2022-06-11 06:19:23.316650
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'



# Generated at 2022-06-11 06:19:25.483326
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError
    except RuntimeError:
        assert get_exception() is sys.exc_info()[1]

# Generated at 2022-06-11 06:19:27.749335
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        assert isinstance(get_exception(), ZeroDivisionError)


# Generated at 2022-06-11 06:19:30.824719
# Unit test for function get_exception
def test_get_exception():
    """Test that we can get the exception"""
    try:
        raise Exception("test exception")
    except:
        e = get_exception()
    assert e.__class__.__name__ == 'Exception'
    assert e.args == ('test exception',)


# Generated at 2022-06-11 06:19:34.149982
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0  # pylint:disable=unused-variable
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-11 06:19:37.243961
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError("test_get_exception")
    except KeyError:
        e = get_exception()
        if e.args[0] != "test_get_exception":
            raise



# Generated at 2022-06-11 06:19:38.975932
# Unit test for function get_exception

# Generated at 2022-06-11 06:19:49.164517
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('oops')
    except RuntimeError:
        e = get_exception()
    assert e is not None, "get_exception() did not return an exception"


# Generated at 2022-06-11 06:19:53.070238
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test error")
    except Exception:
        e = get_exception()
        if str(e) != "Test error":
            raise Exception("get_exception() returned an exception with a wrong message:\n '%s'" % e.message)
    else:
        raise Exception("Exception not raised")

# Generated at 2022-06-11 06:19:54.585716
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        e = get_exception()
    assert e.args == ('foo',)



# Generated at 2022-06-11 06:19:56.304178
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('test')
    except:
        e = get_exception()
    assert str(e) == 'test'



# Generated at 2022-06-11 06:19:58.463628
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("test error")
    except NameError:
        e = get_exception()
    assert(str(e) == "test error")

# Generated at 2022-06-11 06:20:01.902031
# Unit test for function get_exception
def test_get_exception():
    # Just make sure that simple things work
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'This is an exception'


# Generated at 2022-06-11 06:20:05.926271
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('xyz')
    except Exception:
        e = get_exception()
    assert e.args == ('xyz',)

    try:
        raise Exception('xyz', 1)
    except Exception:
        e = get_exception()
    assert e.args == ('xyz', 1)


# Generated at 2022-06-11 06:20:08.774406
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(text_type('test'))
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert isinstance(e, text_type)


# Generated at 2022-06-11 06:20:14.734645
# Unit test for function get_exception
def test_get_exception():
    def check_exception(e):
        if sys.version_info[:2] == (2, 4):
            return e.__class__, e.args
        return type(e), e.args

    class MyException(Exception):
        pass
    result = MyException('foo')
    try:
        raise result
    except MyException:
        assert check_exception(get_exception()) == check_exception(result)

    result = Exception('bar')
    try:
        raise result
    except Exception:
        assert check_exception(get_exception()) == check_exception(result)



# Generated at 2022-06-11 06:20:18.060259
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception returns the current exception."""
    try:
        print('This is', 'a test')
    except TypeError as e:
        assert e is get_exception()
        raise

# Generated at 2022-06-11 06:20:35.361355
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:20:39.369168
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception: %s", "This is so cool")
    except Exception:
        exc = get_exception()

    if not isinstance(exc, Exception):
        raise AssertionError("get_exception did not return an exception")
    if exc.args != ("Test exception: %s", "This is so cool"):
        raise AssertionError("get_exception did not return the correct exception")

# Generated at 2022-06-11 06:20:43.696631
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1/0
    except Exception:
        e = get_exception()

    assert isinstance(e, ZeroDivisionError)
    assert str(e) == 'integer division or modulo by zero'


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:20:47.216115
# Unit test for function get_exception
def test_get_exception():
    """Function to unit test get_exception"""
    ex = Exception('Test exception')
    try:
        raise ex
    except Exception:
        ex2 = get_exception()
    assert ex is ex2


# Generated at 2022-06-11 06:20:50.009351
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Exception')
    except:
        e = get_exception()
        assert e.args == ('Exception',)


# Generated at 2022-06-11 06:20:51.985954
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError as exc:
        assert exc == get_exception()

# Generated at 2022-06-11 06:21:01.864593
# Unit test for function get_exception
def test_get_exception():
    import pytest

    try:
        raise Exception('abc')
    except:
        e = get_exception()
    assert str(e) == 'abc'
    try:
        raise Exception(2)
    except:
        e = get_exception()
    assert '2' in str(e)
    try:
        raise 1
    except TypeError:
        e = get_exception()
    assert 'exceptions must be old-style classes or derived from BaseException' in str(e)
    try:
        raise
    except:
        e = get_exception()
    assert '1' in str(e)
    try:
        raise RuntimeError
    except:
        e = get_exception()
    assert 'RuntimeError' in str(e)

# Generated at 2022-06-11 06:21:07.862993
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils import basic
    def test():
        raise basic.AnsibleError('foo')

    try:
        test()
        print('Failed: did not get expected exception')
    except basic.AnsibleError as e:
        if str(e) != 'foo':
            print('Failed: got exception but not with the right message: %s' % e)
    else:
        print('Failed: did not get expected exception')


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:21:12.111717
# Unit test for function get_exception
def test_get_exception():
    try:
        foo
    except NameError:
        e = get_exception()
        assert isinstance(e, NameError)
        assert e.args == ("global name 'foo' is not defined",)
    else:
        assert False, 'Previous statement should have thrown an exception'


# Generated at 2022-06-11 06:21:14.257181
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('a')
    except:
        e = get_exception()
    assert str(e) == 'a'

# Generated at 2022-06-11 06:21:48.594151
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert e is get_exception()



# Generated at 2022-06-11 06:21:51.833753
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('fake error')
    except:
        exc = get_exception()
    assert exc.args[0] == 'fake error'


# Generated at 2022-06-11 06:21:54.273430
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        exc = get_exception()
        assert isinstance(exc, Exception)


# Generated at 2022-06-11 06:21:56.360729
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        assert get_exception() is not None

# Generated at 2022-06-11 06:21:58.881062
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('It works')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'It works'



# Generated at 2022-06-11 06:22:02.615334
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()

    assert e is not None, "get_exception didn't return an exception"
    assert isinstance(e, ValueError), "get_exception didn't return the right exception"

# Generated at 2022-06-11 06:22:05.202054
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('ansible')
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == 'ansible'



# Generated at 2022-06-11 06:22:11.368869
# Unit test for function get_exception
def test_get_exception():
    import unittest

    try:
        1 / 0
    except:
        exc = get_exception()

        class TestGetException(unittest.TestCase):

            def runTest(self):
                self.assertTrue(isinstance(exc, ZeroDivisionError))

        if __name__ == '__main__':
            from ansible.module_utils.pycompat24 import get_exception
            get_exception()
            print('get_exception() succeded')

# Generated at 2022-06-11 06:22:14.357756
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a unit test')
    except RuntimeError:
        exc = get_exception()
        assert exc.args[0] == 'This is a unit test'


# Generated at 2022-06-11 06:22:17.211529
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('just testing')
    except ValueError:
        e = get_exception()
    assert 'testing' in str(e)


# Generated at 2022-06-11 06:23:24.415600
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Hello')
    except:
        exc = get_exception()
        if not isinstance(exc, ValueError) or str(exc) != 'Hello':
            raise AssertionError('got %r' % (exc,))

# Generated at 2022-06-11 06:23:27.550817
# Unit test for function get_exception
def test_get_exception():
    # pragma: no cover
    try:
        raise KeyError("I like turtles")
    except KeyError:
        e = get_exception()
        assert 'turtles' in str(e)


# Generated at 2022-06-11 06:23:30.336621
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo', 'get_exception() did not return the original exception'

# Generated at 2022-06-11 06:23:33.261306
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Hello world')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('Hello world',)

# Generated at 2022-06-11 06:23:36.109689
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test message')
    except ValueError:
        exc = get_exception()
        assert exc.message == 'Test message'


# Generated at 2022-06-11 06:23:42.443676
# Unit test for function get_exception
def test_get_exception():
    def test_raise():
        raise Exception('This is an error')

    exp = None
    try:
        test_raise()
    except Exception:
        exp = get_exception()

    assert exp, "get_exception didn't return anything"

    try:
        test_raise()
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception), "get_exception didn't return an Exception"
        assert "This is an error" == exc.args[0], "get_exception didn't return the correct exception"



# Generated at 2022-06-11 06:23:50.974592
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception properly gets the exception information."""
    # This test seems silly but is necessary to make sure that the
    # get_exception function works under a variety of Python versions:
    # 2.3 doesn't have sys.exc_info(), 2.6 has exc_type() but doesn't have
    # sys.exc_clear(), and 2.7 has sys.exc_clear().
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'
        if hasattr(sys, 'exc_clear'):
            sys.exc_clear()
        else:
            e = None

# Generated at 2022-06-11 06:23:54.377639
# Unit test for function get_exception
def test_get_exception():
    if sys.version_info < (2,5):
        return
    try:
        raise RuntimeError("An error")
    except RuntimeError:
        e = get_exception()
    assert str(e) == "An error"


# Generated at 2022-06-11 06:23:57.733520
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    try:
        raise RuntimeError('test exception')
    except RuntimeError as e:
        # test that the exception is the same as the one we saved.
        assert e is get_exception()

# Generated at 2022-06-11 06:23:59.815438
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('foo')
    except NameError:
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-11 06:26:33.714029
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        import traceback
        assert str(e) in traceback.format_exc()

# Generated at 2022-06-11 06:26:35.751599
# Unit test for function get_exception

# Generated at 2022-06-11 06:26:38.037812
# Unit test for function get_exception
def test_get_exception():
    try:
        a = dict[123]
    except Exception:
        assert get_exception()


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:26:39.588397
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as exc:
        assert get_exception() == exc

# Generated at 2022-06-11 06:26:46.962608
# Unit test for function get_exception
def test_get_exception():
    def test_exception(e):
        """Test that the exception returned by get_exception is the same as
        the one we expect"""
        try:
            raise e
        except:
            assert e is get_exception(), '%s is not returned by get_exception()' % e

    class TestException(Exception):
        def __init__(self, arg=0):
            self.arg = arg

        def __str__(self):
            return 'TestException object, arg=%s' % self.arg

    test_exception(TestException('foo'))
    test_exception(TestException())

# Testing for function literal_eval

# Generated at 2022-06-11 06:26:48.594790
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        assert str(get_exception()) == "Test Exception"



# Generated at 2022-06-11 06:26:52.364145
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

    try:
        x = 1
        x[1] = 2
    except:
        e = get_exception()
    assert isinstance(e, TypeError)



# Generated at 2022-06-11 06:26:55.644512
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception"""
    try:
        raise NameError('My name is not NameError')
    except NameError:
        e = get_exception()

    assert isinstance(e, NameError)
    assert 'My name is not NameError' == str(e)


# Generated at 2022-06-11 06:27:01.760689
# Unit test for function get_exception
def test_get_exception():
    from nose.tools import assert_equal, assert_raises

    def raise_exc():
        raise BaseException("Testing")

    assert_raises(BaseException, raise_exc)
    e = get_exception()
    assert_equal("Testing", e.args[0])

    # See if we can get an exception nested inside a get_exception()
    def raise_exc():
        e = get_exception()
        assert_equal("Testing", e.args[0])
        raise BaseException("Testing")

    assert_raises(BaseException, raise_exc)

# Generated at 2022-06-11 06:27:04.590862
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()

    if str(e) != 'test':
        raise AssertionError('get_exception() seems broken')

test_get_exception()