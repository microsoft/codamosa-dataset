

# Generated at 2022-06-11 06:18:06.911229
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('test')
    except TestException:
        exc = get_exception()
    assert isinstance(exc, TestException)
    assert str(exc) == 'test'

# Generated at 2022-06-11 06:18:09.503028
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-11 06:18:12.620550
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'


# Generated at 2022-06-11 06:18:18.639814
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError("test")
        except Exception:
            e = get_exception()
            if not isinstance(e, ValueError):
                raise ValueError('Expected ValueError, got %s' % repr(e))
            if e.message != 'test':
                raise ValueError('Expected message to be test, got %s' % e.message)
    foo()


# Generated at 2022-06-11 06:18:29.267517
# Unit test for function get_exception
def test_get_exception():

    def raise_exception(exception):
        # Get the last frame of the current stack.  We do this
        # to make sure that the frame for this function is not
        # included in the traceback when we get the exception
        stack = sys._getframe()
        while stack.f_back is not None:
            stack = stack.f_back
        try:
            raise exception
        except:  # pylint: disable=bare-except
            # This will be the last frame of the last traceback
            # that we want to reference
            stack.f_globals['__last_traceback'] = sys.exc_info()[2]

    class MyException(Exception):
        pass

    raise_exception(MyException('Hello World!'))

# Generated at 2022-06-11 06:18:32.095080
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert(e.args[0] == 'foo')


# Generated at 2022-06-11 06:18:35.333802
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo bar')
    except:
        exc = get_exception()

    assert isinstance(exc, RuntimeError)
    assert exc.args[0] == 'foo bar'


# Generated at 2022-06-11 06:18:40.149023
# Unit test for function get_exception
def test_get_exception():
    try:
        1 + "one"
    except TypeError:
        assert isinstance(get_exception(), TypeError)
    try:
        raise ValueError('foo')
    except ValueError as value_exc:
        assert isinstance(value_exc, ValueError)
        try:
            1 + "one"
        except TypeError:
            assert value_exc == get_exception()
    try:
        raise ValueError('foo')
    except ValueError:
        try:
            1 + "one"
        except TypeError as type_exc:
            assert type_exc == get_exception()
    try:
        raise ValueError('foo')
    except ValueError:
        pass
    try:
        1 + "one"
    except TypeError as type_exc:
        assert type_exc == get_exception()

# Generated at 2022-06-11 06:18:42.969654
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("A message")
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert "A message" in str(e)


# Generated at 2022-06-11 06:18:50.489206
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    # First, test in the normal case that gets the exception
    try:
        raise TestException('test')
    except TestException:
        e = get_exception()
    assert isinstance(e, TestException)
    assert e.args == ('test', )

    # Now, test that we don't get an exception when there is no exception
    e = get_exception()
    assert e is None

# Generated at 2022-06-11 06:19:02.532596
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('Test')
    except TestException:
        exc = get_exception()
        assert exc.__class__ == TestException

# Generated at 2022-06-11 06:19:05.720252
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError
        except Exception:
            e = get_exception()
        return e
    assert isinstance(foo(), ValueError)

# Generated at 2022-06-11 06:19:08.698846
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass

    try:
        raise CustomException()
    except Exception:
        assert isinstance(get_exception(), CustomException)



# Generated at 2022-06-11 06:19:11.624500
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo_bar')
    except Exception:
        e = get_exception()
        assert 'foo_bar' == str(e)

# Generated at 2022-06-11 06:19:18.039313
# Unit test for function get_exception
def test_get_exception():
    def test_get_exception_in_function(foo):
        try:
            1 / foo
        except:
            return get_exception()

    try:
        test_get_exception_in_function(0)
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError), \
            'get_exception returned %r instead of %r' % (e, ZeroDivisionError)
        return
    raise AssertionError('get_exception did not raise')


# Generated at 2022-06-11 06:19:29.224393
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is an error")
    except RuntimeError as exc:
        exc2 = get_exception()

    assert exc is exc2, "get_exception() should return a reference to the current exception"

if __name__ == '__main__':
    # Unit tests for function literal_eval
    assert literal_eval("1 + 2") == 3, "literal_eval('1 + 2') should return 3"
    assert literal_eval("'1 + 2'") == '1 + 2', "literal_eval(\"'1 + 2'\") should return '1 + 2'"
    assert literal_eval("(1, 2, 3)") == (1, 2, 3), "literal_eval('(1, 2, 3)') should return (1, 2, 3)"

# Generated at 2022-06-11 06:19:31.273520
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError()
    except TypeError:
        assert isinstance(get_exception(), TypeError)


# Generated at 2022-06-11 06:19:40.769834
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() works"""
    # pylint: disable=import-error
    import ast
    import pickle
    # pylint: enable=import-error
    # Use exec to avoid leaving this code in the module global scope
    exec('''
if True:
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
''')
    exec('''
if True:
    try:
        raise pickle.PickleError('bar')
    except Exception:
        e = get_exception()
        assert str(e) == 'bar'
''')

# Generated at 2022-06-11 06:19:44.852076
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('not the message you are looking for')
    except Exception:
        exception = get_exception()
        assert exception is not None
        assert str(exception) == 'not the message you are looking for'
        assert isinstance(exception, RuntimeError)
    else:
        assert False, 'Should have thrown exception'

# Generated at 2022-06-11 06:19:48.107763
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable

    try:
        raise ValueError('Test')
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.args == ('Test',)

# Generated at 2022-06-11 06:20:06.631614
# Unit test for function get_exception
def test_get_exception():
    # Does get_exception work?
    try:
        raise ValueError('Test exception message')
    except ValueError:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'Test exception message'



# Generated at 2022-06-11 06:20:09.339935
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except Exception:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'Test exception'

# Generated at 2022-06-11 06:20:14.180409
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

if __name__ == '__main__':
    """Run unit tests on the  get_exception function"""
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None    # pylint: disable=protected-access
    test_get_exception()

# Generated at 2022-06-11 06:20:18.162544
# Unit test for function get_exception
def test_get_exception():
    # Test exception handling Python 2.4 style
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:20:21.425677
# Unit test for function get_exception
def test_get_exception():
    exc = None
    try:
        raise ValueError('foo')
    except:
        exc = get_exception()

    assert isinstance(exc, ValueError) and str(exc) == 'foo'

# Generated at 2022-06-11 06:20:32.445268
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        assert(get_exception().message == "Test Exception")

    try:
        raise Exception("Test Exception 2")
    except Exception:
        e = get_exception()
        assert(e.message == "Test Exception 2")
        assert(str(e) == "Test Exception 2")

    try:
        raise Exception("Test Exception 3")
    except Exception as err:
        assert(err.message == "Test Exception 3")

    try:
        raise Exception("Test Exception 4")
    except Exception:
        e = get_exception()
        e.attribute = "test"
        assert(e.message == "Test Exception 4")
        assert(e.attribute == "test")
        e.attribute2 = "test2"

# Generated at 2022-06-11 06:20:38.025003
# Unit test for function get_exception
def test_get_exception():
    def test_raises_that_get_exception_works():
        try:
            raise ValueError('A message')
        except ValueError:
            exc = get_exception()
            if exc and not exc.args[0] == 'A message':
                raise AssertionError('get_exception() failed to capture the exception raised.  Expected: %s. Got: %s' % ('A message', exc.args[0]))

    test_raises_that_get_exception_works()

# Generated at 2022-06-11 06:20:40.763732
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:  # pylint: disable=bare-except
        exc = get_exception()

    assert isinstance(exc, ValueError)

# Generated at 2022-06-11 06:20:49.323271
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        import traceback
        exc = get_exception()
        # Make sure that the exception is the same as Python's system exception
        assert exc is sys.exc_info()[1]
        # Make sure that the exception actually has the same traceback.  An
        # instance dict comparison is done because python stores the traceback
        # in the instance dict.  We can't use .tb_frame because even though
        # the tracebacks are the same, the frame may be in a different place.
        assert exc.__dict__ == traceback.format_exc(exc).__dict__



# Generated at 2022-06-11 06:20:53.778931
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test error')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'test error'
    else:
        raise AssertionError

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:21:28.681706
# Unit test for function get_exception

# Generated at 2022-06-11 06:21:32.132851
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
        assert str(e) == 'integer division or modulo by zero'

# Generated at 2022-06-11 06:21:41.787374
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import six

    class Foo(Exception):
        pass

    class TestGetException(unittest.TestCase):
        def test_get_exception(self):
            try:
                raise Foo('example message')
            except:
                self.assertIsInstance(get_exception(), Foo)
                self.assertEqual(get_exception().__class__.__name__, 'Foo')
                self.assertEqual(get_exception().message, 'example message')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGetException)

    # Unit test for function literal_eval

# Generated at 2022-06-11 06:21:45.196869
# Unit test for function get_exception
def test_get_exception():
    # These tests exist in a function so we can do this in one test file
    # without having these test cases run on every python version

    class SomeError(Exception):
        pass

    error = SomeError('test message')
    try:
        raise error
    except:
        assert error is get_exception()


# Generated at 2022-06-11 06:21:56.408956
# Unit test for function get_exception
def test_get_exception():
    '''
    AnsibleError is a general purpose error that does not take arguments.
    '''
    try:
        raise AnsibleError()
    except AnsibleError:
        e = get_exception()

    assert isinstance(e, AnsibleError)
    assert str(e) == 'AnsibleError()'

    '''
    Passing arguments to AnsibleError sets the exception's message.
    '''
    try:
        raise AnsibleError('error message')
    except AnsibleError:
        e = get_exception()

    assert isinstance(e, AnsibleError)
    assert str(e) == 'AnsibleError("error message")'

    '''
    Passing arguments to some other exception sets the exception's message.
    '''

# Generated at 2022-06-11 06:21:58.152987
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('foo')
    except:
        return get_exception()


# Generated at 2022-06-11 06:22:01.099905
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('my test error')
    except Exception:
        # Check for the error message, not the type
        assert 'test error' in str(get_exception())



# Generated at 2022-06-11 06:22:03.996616
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == "test"



# Generated at 2022-06-11 06:22:06.815239
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a unit test exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'This is a unit test exception'

# Generated at 2022-06-11 06:22:09.158730
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert e.args == ('test',)


# Generated at 2022-06-11 06:22:48.910932
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name
    try:
        raise Exception('foo')
    except Exception as e:
        ansible_e = e
    except:  # noqa
        ansible_e = get_exception()
    try:
        raise Exception('foo')
    except:  # noqa
        py_e = get_exception()
    assert(str(ansible_e))
    assert(str(py_e))
    assert(str(ansible_e) == str(py_e))
    assert(repr(ansible_e))
    assert(repr(py_e))
    assert(repr(ansible_e) == repr(py_e))

# Generated at 2022-06-11 06:22:52.324776
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == '', 'get_exception did not work'


# Generated at 2022-06-11 06:22:55.062740
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        e = get_exception()
    assert "foo" == str(e)


# Generated at 2022-06-11 06:22:57.257366
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'test'

# Generated at 2022-06-11 06:23:06.433521
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise ValueError('foo')
    try:
        f()
        assert False, 'Should have raised an exception'
    except:
        e = get_exception()
        assert isinstance(e, ValueError), 'Type of e should be ValueError'
        assert str(e) == 'foo', 'Exception should be ValueError with string foo'

    class MyException(Exception):
        pass
    def g():
        raise MyException('bar')

    try:
        g()
        assert False, 'Should have raised an exception'
    except:
        e = get_exception()
        assert isinstance(e, MyException), 'Type of e should be MyException'
        assert str(e) == 'bar', 'Exception should be MyException with string bar'


# Generated at 2022-06-11 06:23:07.892300
# Unit test for function get_exception

# Generated at 2022-06-11 06:23:10.583775
# Unit test for function get_exception
def test_get_exception():
    """
    Check that get_exception() returns the currently active exception.
    """
    try:
        1/0  # pylint: disable=pointless-statement
    except Exception:
        exc = get_exception()
        assert exc is not None

# Generated at 2022-06-11 06:23:12.674712
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test exception")
    except Exception:
        assert get_exception() is not None


# Generated at 2022-06-11 06:23:15.042271
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()

    assert repr(e) == repr(Exception('test'))

# Generated at 2022-06-11 06:23:17.892323
# Unit test for function get_exception
def test_get_exception():
    try:
        int('spam')
    except ValueError:
        e = get_exception()
        assert(isinstance(e, ValueError))
    else:
        assert(False)

# Generated at 2022-06-11 06:23:56.308664
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception(u'\N{SNOWMAN}')
    except Exception:
        e = get_exception()

    if e.__class__.__name__ != 'Exception':
        raise AssertionError("get_exception did not get proper exception")
    if u'\N{SNOWMAN}' not in '%s' % (e,):
        raise AssertionError("get_exception did not get proper exception")

# Generated at 2022-06-11 06:23:58.741829
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert str(e) == 'test'


# Generated at 2022-06-11 06:24:05.655667
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name,unused-variable
    def code(x):
        try:
            raise ValueError("Exception text")
        except Exception:
            e = get_exception()
            return e
    try:
        raise ValueError("Exception text")
    except Exception:
        e1 = get_exception()

    assert isinstance(e1, ValueError)
    assert isinstance(code("x"), ValueError)
    assert code("x").message == "Exception text"



# Generated at 2022-06-11 06:24:09.490096
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('trouble')
    except ValueError:
        e = get_exception()
        assert e.args == ('trouble',)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-11 06:24:14.430459
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=C0103
    """Check that get_exception really returns exceptions.

    I was going to use doctest, but the traceback printing makes it
    a real pain to write stable doctests for.
    """
    import traceback
    try:
        1 / 0
    except Exception:
        tb = traceback.format_exc()
        exc = get_exception()
        assert isinstance(exc, ZeroDivisionError)
        assert str(exc) in tb, tb

# Generated at 2022-06-11 06:24:18.887018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError(u'\N{SNOWMAN}')
    except TypeError:
        e = get_exception()
        assert isinstance(e, TypeError)
        assert u'\N{SNOWMAN}' in str(e)

# Generated at 2022-06-11 06:24:21.992891
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a test')
    except Exception:
        e = get_exception()
    assert type(e) is RuntimeError
    assert str(e) == 'This is a test'

# Generated at 2022-06-11 06:24:24.545803
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bogus exception')
    except Exception:
        e = get_exception()
        assert e.message == 'bogus exception', e

# Generated at 2022-06-11 06:24:27.213024
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('bad value')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('bad value',)
    assert str(e) == 'bad value'

# Generated at 2022-06-11 06:24:36.745805
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError:
        e = get_exception()  # noqa
        assert e.args == ("foo",)
    try:
        try:
            raise ValueError("bar")
        except ValueError:
            raise ValueError("foo")
    except ValueError:
        e = get_exception()  # noqa
        assert e.args == ("foo",)
    try:
        try:
            raise ValueError("bar")
        except:
            raise ValueError("foo")
    except ValueError:
        e = get_exception()  # noqa
        assert e.args == ("foo",)
    e = None

# Generated at 2022-06-11 06:25:53.179776
# Unit test for function get_exception
def test_get_exception():
    # just test that we can call it without crashing
    try:
        assert False
    except Exception:
        get_exception()

# Generated at 2022-06-11 06:25:56.147975
# Unit test for function get_exception
def test_get_exception():
    def get_exception_test():
        try:
            raise Exception('bim')
        except:
            return get_exception()
    e = get_exception_test()
    assert isinstance(e, Exception)
    assert e.args == ('bim',)



# Generated at 2022-06-11 06:25:58.680457
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except:
        assert str(get_exception()) == "invalid literal for int() with base 10: 'a'"

# pylint: disable=unused-argument

# Generated at 2022-06-11 06:26:03.977510
# Unit test for function get_exception
def test_get_exception():
    # Check that get_exception returns a bare Exception
    # This is important so that we can use it as the context when constructing
    # a subclassed exception and have it not get formatted as the string
    # version of Exception(Exception(...))
    try:
        raise Exception()
    except Exception:
        e = get_exception()

    assert not hasattr(e, '__traceback__')
    assert str(e) == "<class 'Exception'>"



# Generated at 2022-06-11 06:26:05.434820
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Exception raised")
    except RuntimeError as e:
        val = get_exception()
        assert(val == e)

# Generated at 2022-06-11 06:26:08.303702
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('hello world')
    except MyException:
        e = get_exception()

    assert isinstance(e, MyException)
    assert str(e) == 'hello world'


# Generated at 2022-06-11 06:26:10.318112
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except ValueError:
        exc = sys.exc_info()[1]
        assert(exc == get_exception())


# Generated at 2022-06-11 06:26:12.166972
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-11 06:26:15.144352
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Something bad")
    except Exception:
        e = get_exception()
        assert str(e) == 'Something bad'
        assert isinstance(e, ValueError)
        return True
    return False

# Generated at 2022-06-11 06:26:16.964407
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        e = get_exception()
    assert(str(e) == "foo")

# Generated at 2022-06-11 06:27:42.304504
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
        assert str(e) == 'test'

# Generated at 2022-06-11 06:27:46.586708
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception works even if we don't have the right version of Python
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    if e.args != ('foo',):
        raise AssertionError('get_exception() returns the wrong exception')


# Generated at 2022-06-11 06:27:51.026621
# Unit test for function get_exception
def test_get_exception():
    def test_func():
        try:
            raise MyException(2)
        except Exception:
            exc = get_exception()
            if exc.args != (2,):
                raise
            return exc
    exc = test_func()
    if exc.args != (2,):
        raise AssertionError('Exception args: %r' % exc.args)
