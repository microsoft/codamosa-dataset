

# Generated at 2022-06-11 06:18:05.813149
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'


# Generated at 2022-06-11 06:18:13.465613
# Unit test for function get_exception
def test_get_exception():
    '''Test that get_exception returns the current exception in function context'''

    try:
        raise Exception('first')
    except:
        try:
            raise Exception('second')
        except:
            assert get_exception().args[0] == 'second'

    try:
        raise Exception('first')
    except:
        try:
            try:
                raise Exception('inner')
            except:
                assert get_exception().args[0] == 'inner'
            raise Exception('second')
        except:
            assert get_exception().args[0] == 'second'

# Generated at 2022-06-11 06:18:16.012113
# Unit test for function get_exception

# Generated at 2022-06-11 06:18:18.554577
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert exc.args[0] == 'foo'



# Generated at 2022-06-11 06:18:20.228635
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
        assert e.args[0] == 'test'

# Generated at 2022-06-11 06:18:23.478354
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('fake exception')
    except:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'fake exception'

# Unit tests for function literal_eval

# Generated at 2022-06-11 06:18:27.483508
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('The answer is 42')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'The answer is 42'

# Generated at 2022-06-11 06:18:30.335765
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'



# Generated at 2022-06-11 06:18:32.693926
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test')
    except:
        assert str(get_exception()) == 'This is a test'

# Generated at 2022-06-11 06:18:35.954004
# Unit test for function get_exception
def test_get_exception():
    """Function get_exception raises appropriate exceptions"""
    try:
        raise RuntimeError("Test Error")
    except Exception:
        e = get_exception()
        assert str(e) == "Test Error"

# Generated at 2022-06-11 06:18:46.951869
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("An exception message")
    except Exception:
        assert str(get_exception()) == "An exception message"



# Generated at 2022-06-11 06:18:51.640361
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name
    try:
        raise ValueError()
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    # pylint: enable=invalid-name


# Generated at 2022-06-11 06:18:59.016194
# Unit test for function get_exception
def test_get_exception():
    """Ensure that get_exception works on a variety of python versions."""
    global get_exception  # pylint: disable=global-statement

    try:
        int('notanumber')
    except Exception as e:
        # Python 2.6+ have access to the exception in the except block
        assert e == get_exception()
    else:
        assert 0, 'Expected an Exception but none was raised'

    try:
        int('notanumber')
    except Exception:
        # Python 2.4-2.5 have to use get_exception to get the exception
        assert get_exception()
    else:
        assert 0, 'Expected an Exception but none was raised'

# Generated at 2022-06-11 06:19:01.784052
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("bananas")
    except Exception:
        assert get_exception().args[0] == "bananas"

# Generated at 2022-06-11 06:19:03.839873
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(42)
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:19:07.432238
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        retval = get_exception()
    assert retval.args[0] == 'foo'
    assert isinstance(retval, TypeError)

# Generated at 2022-06-11 06:19:09.187949
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        exc = get_exception()
        assert exc.__class__ is Exception
        assert sys.exc_info()[1] is exc

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 06:19:14.270062
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTestCase(unittest.TestCase):
        def test_exception_is_set_in_except(self):
            try:
                raise RuntimeError("Artificial RuntimeError")
            except Exception:
                self.assertTrue(get_exception() is not None)

    return unittest.TestLoader().loadTestsFromTestCase(GetExceptionTestCase)

# Generated at 2022-06-11 06:19:16.285135
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("exception")
    except ValueError:
        assert isinstance(get_exception(), ValueError)


# Generated at 2022-06-11 06:19:23.419785
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError:
        e = get_exception()
        exception = repr(e)
    try:
        raise RuntimeError('Another test exception')
    except RuntimeError:
        e = get_exception()
        exception = exception + ' - ' + repr(e)
    assert exception == "RuntimeError('Test exception',) - RuntimeError('Another test exception',)"


# Generated at 2022-06-11 06:19:38.631993
# Unit test for function get_exception
def test_get_exception():
    import traceback

    try:
        raise Exception("Some message")
    except Exception:
        exc = get_exception()
        exception_msg = traceback.format_exc()
        if not exc:
            print("get_exception returned None, should not happen")
            print("exception_msg: " + exception_msg)
            print("sys.exc_info()[1]: " + str(sys.exc_info()[1]))
            sys.exit(1)
    print("OK")


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:19:43.136391
# Unit test for function get_exception
def test_get_exception():
    try:
        int('qwer')
    except:
        e = get_exception()
        assert str(e) == 'invalid literal for int() with base 10: \'qwer\''

# Unit test based on testing literal_eval.test_literal_eval.LiteralEvalTest.test_safe_eval

# Generated at 2022-06-11 06:19:48.107609
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("Whoah")
    except NameError:
        e = get_exception()
        assert str(e) == "Whoah", "%r != %r" % (str(e), "Whoah")
        assert isinstance(e, NameError)
    else:
        raise AssertionError("get_exception() didn't raise an exception!")


# Generated at 2022-06-11 06:19:50.737711
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("An exception")
    except:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert e.message == "An exception"

# Generated at 2022-06-11 06:19:54.865402
# Unit test for function get_exception
def test_get_exception():
    if sys.version_info < (2, 6):
        raise Exception('This has not been tested in Python < 2.6')
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'

# Unit test function literal_eval is kept in ast.py

# Generated at 2022-06-11 06:19:57.899831
# Unit test for function get_exception
def test_get_exception():
    # On Python 2.4-2.7, this gets an empty tuple
    assert not get_exception()
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == 'foo'

# Generated at 2022-06-11 06:20:01.675485
# Unit test for function get_exception
def test_get_exception():
    def raise_some_exception():
        raise Exception('Some Exception')

    try:
        raise_some_exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert 'Some Exception' == str(e)


# Generated at 2022-06-11 06:20:06.658243
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception functionality."""
    # pylint: disable=unused-variable
    def function():
        """This function is used to test get_exception"""
        # pylint: disable=unreachable
        return None

    try:
        raise ValueError
    except ValueError:
        assert get_exception()
        try:
            function()
        except SyntaxError:
            assert get_exception()

# Generated at 2022-06-11 06:20:11.896195
# Unit test for function get_exception
def test_get_exception():
    '''
    Do we pick up the correct exception in the case of a 'except Exception'
    statement?
    :return: True if we pass the test, False otherwise.
    :rtype: bool
    '''
    try:
        raise NameError('test')
    except NameError:
        e = get_exception()
    except Exception:
        return False
    if e.args[0] == 'test':
        return True
    return False


# Generated at 2022-06-11 06:20:14.019332
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'foo'



# Generated at 2022-06-11 06:20:24.875746
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert str(exc) == 'foo'
        assert unicode(exc) == u'foo'

# Generated at 2022-06-11 06:20:32.446232
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        exception = get_exception()
        assert exception.args[0] == ('This is a test')
    try:
        raise TypeError('This is a test') from exception
    except TypeError:
        exception = get_exception()
        assert exception.args[0] == ('This is a test')
        assert 'Traceback (most recent call last):\n' in text_type(exception)


# Generated at 2022-06-11 06:20:34.526591
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception), "get_exception() didn't raise an Exception"
    assert e.args == ('test',), "get_exception() didn't raise the right Exception"

# Generated at 2022-06-11 06:20:41.045313
# Unit test for function get_exception
def test_get_exception():
    try:
        int('foo')
        assert False, 'int("foo") should raise a ValueError'
    except:
        e = get_exception()
        assert isinstance(e, ValueError), 'Wrong exception type raised: %s' % e
        assert str(e) == "invalid literal for int() with base 10: 'foo'", 'Wrong exception raised: %s' % e

if __name__ == '__main__':
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))))
    from test.lib import *  # pylint: disable=wildcard-import,unused-wildcard-import
    test_get_

# Generated at 2022-06-11 06:20:44.538797
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    try:
        raise Exception('Testing')
    except Exception:
        assert get_exception() == 'Testing'
        return
    assert False, "Exception not raised"



# Generated at 2022-06-11 06:20:46.805557
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('xyz')
    except:
        assert get_exception() == ValueError('xyz')

# Generated at 2022-06-11 06:20:51.774893
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        fetched_exception = get_exception()

    try:
        raise fetched_exception
    except Exception as e:
        assert 'foo' in str(e)

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-11 06:21:01.691558
# Unit test for function get_exception
def test_get_exception():
    '''Test the get_exception function'''
    import sys
    import traceback
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    def _test_str():
        return AnsibleModule(
            argument_spec={},
        ).fail_json(msg="This is a test")

    def _test_exception():
        raise Exception("This is a test")

    # Convert all "standard" strings in the exception to bytes so we can test
    # the exception contains the expected string.
    py2 = sys.version_info[0] == 2
    environ_io = StringIO()
    module_io = StringIO()
    err_io = StringIO()
    sys.stder

# Generated at 2022-06-11 06:21:04.642093
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
        assert str(e) == 'integer division or modulo by zero'


# Generated at 2022-06-11 06:21:08.213985
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise ValueError('foo')

    try:
        foo()
    except Exception:
        e = get_exception()

    assert 'ValueError' == e.__class__.__name__
    assert 'foo' == str(e)


# Generated at 2022-06-11 06:21:19.745575
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test exception")
    except ValueError:
        e = get_exception()
        print(e)
        assert isinstance(e, ValueError)
        assert str(e) == "This is a test exception"



# Generated at 2022-06-11 06:21:22.456786
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        pass
    e = get_exception()
    assert isinstance(e, ZeroDivisionError), "get_exception didn't return the correct error"

# Generated at 2022-06-11 06:21:24.834288
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is a test')
    except RuntimeError:
        exc = get_exception()
    assert str(exc) == 'this is a test'
    assert exc.__class__ == RuntimeError


# Generated at 2022-06-11 06:21:27.372565
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception()
        except Exception:
            e = get_exception()
            return e
    e = f()
    assert isinstance(e, Exception)

    def f():
        return get_exception()
    assert f() is None

# Generated at 2022-06-11 06:21:33.176264
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise Exception('This is a test exception.')
        except Exception:
            exc = get_exception()
            return exc
    exc = foo()
    assert exc.__class__ == Exception, 'Unexpected class: %s' % exc.__class__
    assert str(exc) == 'This is a test exception.', 'Unexpected exception string: %s' % str(exc)

# Generated at 2022-06-11 06:21:36.032648
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'test'



# Generated at 2022-06-11 06:21:38.535342
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exc = get_exception()
        assert isinstance(exc, RuntimeError)


# Generated at 2022-06-11 06:21:46.917763
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function.

    The function is tested by verifying that it can return an exception that is
    caught using a variety of different except clauses.
    """
    def a_function():
        """A function that throws an exception"""
        raise Exception(u'this is a test exception')

    try:
        a_function()
    except Exception:
        e = get_exception()
        assert type(e) is Exception
        assert u'this is a test exception' in e.args
    try:
        a_function()
    except:
        e = get_exception()
        assert type(e) is Exception
        assert u'this is a test exception' in e.args
    try:
        a_function()
    except (Exception):
        e = get_exception()
        assert type(e) is Exception

# Generated at 2022-06-11 06:21:52.989193
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() == e
        assert sys.exc_info()[1] == e
        assert sys.exc_info() == ('test_module_utils_basic.test_get_exception.<locals>.<lambda>', 'foo', e)
        return
    assert 0, 'should have raised'


# Generated at 2022-06-11 06:21:56.009153
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('this is a test exception')
    except TypeError:
        assert isinstance(get_exception(), TypeError)



# Generated at 2022-06-11 06:22:06.593190
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('no')
    except NameError:
        e = get_exception()
        if str(e) != 'no':
            raise AssertionError


# Generated at 2022-06-11 06:22:08.741051
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-11 06:22:10.707701
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        assert get_exception().args[0] == 'test exception'

# Generated at 2022-06-11 06:22:13.205781
# Unit test for function get_exception
def test_get_exception():
    try:
        int('This is not an int')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-11 06:22:16.941773
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        assert 'foo' in str(get_exception())

    try:
        raise ValueError('foo')
    except ValueError as e:
        assert 'foo' in str(e)

# Generated at 2022-06-11 06:22:19.755296
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert e.message == 'This is an exception'


# Generated at 2022-06-11 06:22:22.008640
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        assert get_exception() == sys.exc_info()[1]

# Generated at 2022-06-11 06:22:24.899541
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('abc')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ('abc',)

# Generated at 2022-06-11 06:22:27.165642
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test error message')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:22:30.445635
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.__class__ == Exception
    assert e.message == 'foo'



# Generated at 2022-06-11 06:22:41.505459
# Unit test for function get_exception
def test_get_exception():

    def raise_exc():
        try:
            raise Exception("Yet another exception.")
        except:
            return get_exception()

    e = raise_exc()
    assert(isinstance(e, Exception))
    assert(e.args[0].startswith("Yet another exception."))


# Generated at 2022-06-11 06:22:47.442615
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception.  Import this as it's primary unit test to import the
    function into any tests that need it.
    """

    def test_get_exception_raise():
        raise Exception('test exception')
    try:
        test_get_exception_raise()
    except Exception:
        exception = get_exception()
        assert exception.args == ('test exception',)
    else:
        assert False, 'test_get_exception_raise failed to raise an exception'

# Generated at 2022-06-11 06:22:57.690319
# Unit test for function get_exception
def test_get_exception():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Try to raise an exception and get the exception.
    try:
        raise AnsibleError('Test')
    except Exception:
        raised_exception = get_exception()

    assert isinstance(raised_exception, AnsibleError)
    assert 'Test' in raised_exception.message

    # Try to raise an exception with a unicode string
    try:
        raise AnsibleError(u'Test')
    except Exception:
        raised_exception = get_exception()

    if sys.version < '3':
        assert isinstance(raised_exception, AnsibleError)
        assert isinstance(raised_exception.message, unicode)
        assert u'Test' in raised

# Generated at 2022-06-11 06:23:00.228204
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('error')
    except:
        e = get_exception()
    assert e.args[0] == 'error'


# Generated at 2022-06-11 06:23:08.993045
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name,redefined-outer-name,unused-variable
    # pylint: disable=unnecessary-lambda,expression-not-assigned

    # Ensure that if there isn't an exception, get_exception returns None
    try:
        None
    except:
        e = get_exception()
        assert e is not None

    # Ensure that get_exception returns the correct exception.  Use a plain
    # Exception
    try:
        raise Exception("Incorrect exception")
    except:
        e = get_exception()
        assert str(e) == "Incorrect exception"

    # Check that it works with a derived exception
    try:
        raise ValueError("Incorrect exception")
    except:
        e = get_exception()

# Generated at 2022-06-11 06:23:11.518186
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'Foo'


# Unit tests for function literal_eval

# Generated at 2022-06-11 06:23:13.700846
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except Exception:
        e = get_exception()
    assert e.args == ('test',)

# Generated at 2022-06-11 06:23:16.355609
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        exc = get_exception()
        if type(exc) != ZeroDivisionError:
            raise Exception('Expected ZeroDivisionError, instead got: %s', exc)

# Generated at 2022-06-11 06:23:18.817118
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('AnsiballZ something something')
    except MyException as e:
        assert e == get_exception()

# Generated at 2022-06-11 06:23:21.543742
# Unit test for function get_exception
def test_get_exception():
    try:
        int(b'a')
    except TypeError:
        e = get_exception()

    assert isinstance(e, TypeError)



# Generated at 2022-06-11 06:23:39.800978
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException
    except:
        exception_instance = get_exception()

    if exception_instance is None:
        raise AssertionError("get_exception() returned None")
    if not isinstance(exception_instance, TestException):
        raise AssertionError("get_exception() did not return exception instance")

    try:
        raise TestException()
    except:
        exception_instance = get_exception()

    if exception_instance is None:
        raise AssertionError("get_exception() returned None")
    if not isinstance(exception_instance, TestException):
        raise AssertionError("get_exception() did not return exception instance")

# Generated at 2022-06-11 06:23:43.984427
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException()
    except TestException:
        exc = get_exception()
    assert isinstance(exc, TestException)

if __name__ == '__main__':
    import nose
    nose.run_exit(argv=[__file__, '-v'])

# Generated at 2022-06-11 06:23:46.679971
# Unit test for function get_exception
def test_get_exception():
    import pytest

    try:
        x = int('foo')
    except:
        exc = get_exception()
        assert isinstance(exc, ValueError)


# Unit tests for function literal_eval

# Generated at 2022-06-11 06:23:51.677518
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Error')
    except Exception:
        e = get_exception()
    assert e.__class__.__name__ == 'ValueError', '%s != ValueError' % e.__class__.__name__
    assert str(e) == 'Test Error', '%s != Test Error' % str(e)

# Generated at 2022-06-11 06:23:53.476571
# Unit test for function get_exception

# Generated at 2022-06-11 06:23:56.085534
# Unit test for function get_exception

# Generated at 2022-06-11 06:24:00.061990
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""

    try:
        raise Exception('test exception')
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert e.args[0] == 'test exception'
        assert str(e) == 'test exception'

# Generated at 2022-06-11 06:24:02.223315
# Unit test for function get_exception

# Generated at 2022-06-11 06:24:05.655313
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        e = get_exception()

    assert isinstance(e, RuntimeError)
    assert 'test exception' == str(e)

# Generated at 2022-06-11 06:24:10.208807
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError as e:
        ansible_exception = get_exception()
        if e == ansible_exception:
            return True
    raise AssertionError('Exceptions do not match: {0} != {1}'.format(e, ansible_exception))

# Generated at 2022-06-11 06:24:27.341188
# Unit test for function get_exception

# Generated at 2022-06-11 06:24:30.664997
# Unit test for function get_exception
def test_get_exception():
    # Just test that this returns something
    sys.exc_info = lambda: (None, Exception('test'), None)
    e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'test'


# Generated at 2022-06-11 06:24:33.602895
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     'foo'['bar']
    ... except:
    ...     a = get_exception()
    >>> a.args[0]
    'string index out of range'
    """

# Generated at 2022-06-11 06:24:36.920318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('some exception')
    except RuntimeError:
        e = get_exception()
    if str(e) != 'some exception':
        raise AssertionError('Expected "some exception" instead of "%s"' % str(e))

# Generated at 2022-06-11 06:24:39.102483
# Unit test for function get_exception
def test_get_exception():
    try:
        {}['']
    except KeyError as e:
        if e != get_exception():
            raise


# Generated at 2022-06-11 06:24:49.138329
# Unit test for function get_exception
def test_get_exception():
    import inspect
    import sys
    from ansible.module_utils._text import to_bytes

    class TestException(Exception):
        pass

    def throws():
        raise TestException('hi')

    def does_not_throw():
        return 'hello'

    failures = []

    for func in (throws, does_not_throw):
        try:
            func()
        except TestException as e:
            if e is not get_exception():
                failures.append(('function %s did not get the same exception'
                                 'as was raised' % (func.__name__)))
                failures.append(('  func: %s' % inspect.getsource(func)))
                failures.append(('  raised: %r' % e))

# Generated at 2022-06-11 06:24:51.899389
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works"""
    try:
        raise RuntimeError('This is a test exception')
    except RuntimeError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:24:54.535851
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Unit Test Exception")
    except:
        exc_info = get_exception()
    assert("Unit Test Exception" == exc_info.args[0])

# Generated at 2022-06-11 06:24:56.614966
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
    assert type(e) is ZeroDivisionError

# Generated at 2022-06-11 06:24:58.214892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test error')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:25:19.778079
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        assert type(get_exception()) == type(RuntimeError())
    try:
        raise ValueError()
    except ValueError:
        assert type(get_exception()) == type(ValueError())

# Generated at 2022-06-11 06:25:23.292764
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test error')
    except Exception:
        import traceback
        e = get_exception()
        stack = traceback.format_exc()
        assert 'ValueError: Test error' in stack
        assert e.args == ('Test error', )


# Generated at 2022-06-11 06:25:28.369957
# Unit test for function get_exception
def test_get_exception():
    dummyvar = None
    try:
        dummyvar = 1/0
    except ZeroDivisionError as e:
        pass
    except Exception as e:
        assert False, "dummyvar failed to trigger a ZeroDivisionError, instead: %s" % str(e)
    assert e == get_exception(), "Did not get the current exception from get_exception: %s != %s" % (str(e), str(get_exception()))



# Generated at 2022-06-11 06:25:30.561444
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
    assert('test exception' in str(e))


# Generated at 2022-06-11 06:25:33.471357
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert e.__class__.__name__ == 'ZeroDivisionError'
    assert str(e) == 'integer division or modulo by zero'



# Generated at 2022-06-11 06:25:43.070380
# Unit test for function get_exception
def test_get_exception():  # pragma: no cover
    # pylint: disable=redefined-outer-name
    # pylint: disable=missing-docstring

    def test_get_exception_caught_exception():
        try:
            raise ValueError
        except ValueError:
            e = get_exception()
        return e

    def test_get_exception_not_caught_exception():
        e = ValueError
        return e

    try:
        assert test_get_exception_caught_exception()
    except AssertionError:
        print('test_get_exception_caught_exception() failed')


# Generated at 2022-06-11 06:25:48.888276
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('test')
    except MyException:
        e = get_exception()
    assert isinstance(e, MyException)
    assert e.args == ('test',)

    try:
        # Python 3 does not let us raise bare strings.  Python 2 does.
        raise MyException('test')
    except MyException:
        e = get_exception()
    assert isinstance(e, MyException)
    assert e.args == ('test',)

# Generated at 2022-06-11 06:25:52.388929
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('The root password is still "letmein"')
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError) and \
            exc.args[0] == 'The root password is still "letmein"'


# Generated at 2022-06-11 06:25:54.862257
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Shaalug')
    except:
        exception = get_exception()
    assert exception.args[0] == 'Shaalug'



# Generated at 2022-06-11 06:25:56.694745
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test get_exception")
    except Exception:
        e = get_exception()
        assert e.args[0] == "Test get_exception"


# Generated at 2022-06-11 06:26:38.653489
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception to ensure it works appropriately"""
    try:
        raise AssertionError('test error')
    except AssertionError as e:
        assert get_exception() is e

# unit test for function literal_eval

# Generated at 2022-06-11 06:26:42.628362
# Unit test for function get_exception
def test_get_exception():
    e1 = RuntimeError('test1')
    try:
        raise e1
    except RuntimeError:
        # On some versions, e1 is not the same as the exception that is
        # currently being handled.  This can lead to confusion when
        # debugging, so we want to make sure that this always works.
        assert get_exception() is e1

# Generated at 2022-06-11 06:26:45.455371
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception), "get_exception didn't return an exception!"

# Generated at 2022-06-11 06:26:47.527997
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test_get_exception")
    except ValueError:
        e = get_exception()
        assert str(e) == "test_get_exception"


# Generated at 2022-06-11 06:26:48.910936
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test message')
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-11 06:26:51.466100
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        exception = get_exception()
    assert exception.args[0] == 'This is an exception'


# Generated at 2022-06-11 06:26:53.625724
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foobar'


# Generated at 2022-06-11 06:26:55.929210
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('That did not work')
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert str(e) == 'That did not work'

# Generated at 2022-06-11 06:26:58.582269
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except:
        try:
            raise get_exception()
        except Exception as e:
            return e
    assert False


# Generated at 2022-06-11 06:27:00.033108
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test")
    except:
        assert get_exception() == Exception("Test")

# Generated at 2022-06-11 06:27:44.674910
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test value error')
    except ValueError:
        assert get_exception().args[0] == 'test value error'


# Generated at 2022-06-11 06:27:50.026596
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

    try:
        1/0
    except Exception:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

    try:
        1/0
    except:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)