

# Generated at 2022-06-11 06:18:05.852792
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except:
        e = get_exception()
        assert e.args == ('test',)

# Generated at 2022-06-11 06:18:09.211490
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        if str(e) != 'foo':
            raise Exception('Got wrong exception: %s' % e)


# Generated at 2022-06-11 06:18:12.999089
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0  # pylint: disable=pointless-statement
    except:
        exc = get_exception()
        if isinstance(exc, ZeroDivisionError):
            return True
    return False



# Generated at 2022-06-11 06:18:15.855408
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
        assert exc.args == ('foo',)



# Generated at 2022-06-11 06:18:18.773620
# Unit test for function get_exception
def test_get_exception():
    ''' Test get_exception() '''
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert e.__class__ == ValueError



# Generated at 2022-06-11 06:18:21.597453
# Unit test for function get_exception
def test_get_exception():
    def fn():
        raise RuntimeError('message')
    try:
        fn()
    except Exception:
        e = get_exception()
        assert e.__class__ == RuntimeError
        assert text_type(e) == "message"

# Generated at 2022-06-11 06:18:25.152860
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert e.args == ('test', ), 'test raised exception has wrong args'
        assert e != None, 'test exception was None'

# Generated at 2022-06-11 06:18:29.104424
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception("foo")

    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert e.args[0] == "foo"

# Generated at 2022-06-11 06:18:31.937221
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('example')
    except RuntimeError:
        e = get_exception()
    assert e.args == ('example',)


# Generated at 2022-06-11 06:18:34.335221
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:18:55.027427
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        try:
            raise TypeError('bar')
        except TypeError:
            e = get_exception()
            assert str(e) == 'bar'
            assert type(e) == TypeError


# Generated at 2022-06-11 06:18:56.299019
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        assert get_exception()


# Generated at 2022-06-11 06:18:58.224095
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('dummy')
    except:
        exc = get_exception()
    assert str(exc) == 'dummy'

# Generated at 2022-06-11 06:19:01.709644
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("This is a test.")
    except TypeError:
        exc = get_exception()
    assert exc.args == ("This is a test.",)

# Generated at 2022-06-11 06:19:04.680581
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("dummy")
    except ValueError:
        e = get_exception()
        assert e.args[0] == "dummy"



# Generated at 2022-06-11 06:19:09.818248
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('1')
    except RuntimeError:
        e = get_exception()
        assert str(e) == '1'
        assert repr(e) == "RuntimeError('1',)"
        assert type(e) == RuntimeError
        assert e.__class__ == RuntimeError

# Generated at 2022-06-11 06:19:13.717834
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('test')
    except MyException as e:
        assert e is get_exception()
    try:
        raise MyException('test')
    except Exception as e:
        assert e is get_exception()



# Generated at 2022-06-11 06:19:16.743721
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('This is a test')
    except TestException:
        e = get_exception()
    assert 'This is a test' in e.message


# Generated at 2022-06-11 06:19:24.783918
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args == ('foo',)
    # Do it again to make sure we can call get_exception() twice in a single
    # exception block
    try:
        raise Exception('bar')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert e.args == ('bar',)



# Generated at 2022-06-11 06:19:27.841967
# Unit test for function get_exception
def test_get_exception():
    try:
        raise KeyError('Key not found', 'a')
    except:
        e = get_exception()
    assert type(e) == KeyError
    assert e.args == ('Key not found', 'a')

# Generated at 2022-06-11 06:20:03.139885
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('testing')
    except MyException:
        assert get_exception() is sys.exc_info()[1]



# Generated at 2022-06-11 06:20:05.399153
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test")
    except:
        valerr = __import__('exceptions').ValueError
        assert type(get_exception()) == valerr

# Generated at 2022-06-11 06:20:07.241758
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
    assert e.args[0] == 'test exception'


# Generated at 2022-06-11 06:20:10.338585
# Unit test for function get_exception
def test_get_exception():
    # Ensure that the function works
    try:
        raise RuntimeError('Ansible')
    except RuntimeError:
        ex = get_exception()
    assert ex.args == ('Ansible', )
    assert str(ex) == 'Ansible'

# Generated at 2022-06-11 06:20:11.888973
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        assert get_exception()

# Generated at 2022-06-11 06:20:13.718090
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e



# Generated at 2022-06-11 06:20:15.578940
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        exc = get_exception()

    assert exc.args[0] == 'test'

# Generated at 2022-06-11 06:20:20.407711
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception message')
    except RuntimeError:
        ex = get_exception()
        assert str(ex) == 'Test exception message'
        assert repr(ex) == "RuntimeError('Test exception message',)"
        assert type(ex) == RuntimeError



# Generated at 2022-06-11 06:20:23.782359
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception()

    try:
        foo()
    except:
        assert get_exception().__class__ is Exception


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:20:27.015009
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    try:
        raise RuntimeError("Test exception")
    except Exception as e:
        assert get_exception() == e
        assert repr(get_exception()) == repr(e)



# Generated at 2022-06-11 06:21:01.991513
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise Exception('This is an exception')
        except Exception:
            e = get_exception()
            assert e.args == ('This is an exception',)
            assert str(e) == 'This is an exception'
    finally:
        del e

# Generated at 2022-06-11 06:21:10.258382
# Unit test for function get_exception
def test_get_exception():
    print(get_exception)
    try:
        raise TypeError('This message is from the test')
    except:
        exc = get_exception()
        print('type(get_exception()): %s' % type(exc))
        print('get_exception(): %s' % exc)
        print('dir(get_exception()): %s' % str(dir(exc)))
        if hasattr(exc, 'message'):
            print('get_exception().message: %s' % exc.message)
        print('get_exception().args[0]: %s' % exc.args[0])

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:21:12.336694
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('x')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'x'



# Generated at 2022-06-11 06:21:17.831207
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        # This is the classic way to get the exception.  We use this for comparison
        e = sys.exc_info()[1]
        assert isinstance(e, ZeroDivisionError)

        # This is what we want to test:
        assert get_exception() == e
    else:
        assert False, "We should be in this code path"

# Generated at 2022-06-11 06:21:22.372251
# Unit test for function get_exception
def test_get_exception():
    try:
        'bad_type'.split(3)
    except Exception:
        e = get_exception()
    if not isinstance(e, TypeError):
        raise AssertionError('Exception is not of type TypeError')
    if str(e) != "'int' object is not callable":
        raise AssertionError('Exception string is not the expected one')


# Generated at 2022-06-11 06:21:25.795254
# Unit test for function get_exception
def test_get_exception():
    # No exception raised by this function
    assert get_exception() is None
    # After this one, there should be an exception
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
        assert isinstance(ex, Exception)
        assert str(ex) == 'foo'
    assert get_exception() is None



# Generated at 2022-06-11 06:21:28.541505
# Unit test for function get_exception
def test_get_exception():
    def raise_exc():
        try:
            raise RuntimeError('foo')
        except RuntimeError:
            e = get_exception()
            assert str(e) == 'foo'

    raise_exc()

# Generated at 2022-06-11 06:21:30.446868
# Unit test for function get_exception
def test_get_exception():
    try: 1/0
    except ZeroDivisionError as e:
        assert e is get_exception()

# Generated at 2022-06-11 06:21:35.455398
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('This is a unit test exception')
    except TypeError as exc:
        assert get_exception() is exc
    try:
        raise TypeError('This is a second unit test exception')
    except TypeError:
        exc = get_exception()
        assert str(exc) == 'This is a second unit test exception'

# Unit tests for the literal_eval replacement.

# Generated at 2022-06-11 06:21:38.886511
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-variable
    try:
        1/0  # pylint: disable=pointless-statement
    except:
        assert get_exception() is sys.exc_info()[1]


# Generated at 2022-06-11 06:22:46.659064
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'Exception'
    try:
        raise Exception('ohhai')
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'Exception'
        assert e.args == ('ohhai',)



# Generated at 2022-06-11 06:22:57.216643
# Unit test for function get_exception
def test_get_exception():
    attrs = ('__getitem__', '__getslice__', '__contains__', '__iter__',
                            '__int__', '__index__', '__len__', '__nonzero__')
    class BadDict:
        def __getitem__(self, key):
            raise KeyError(key)


# Generated at 2022-06-11 06:23:06.012725
# Unit test for function get_exception
def test_get_exception():
    def test_exception(test_func):
        try:
            test_func()
        except Exception:
            test_exception = get_exception()
            print("Caught exception: %s" % test_exception)
            assert(test_exception == 'test exception')

    def test_exception_raise():
        raise Exception('test exception')
    test_exception(test_exception_raise)

    def test_exception_finally():
        try:
            raise Exception('test exception')
        finally:
            # Ensure that we still get the correct exception despite the finally clause
            pass
    test_exception(test_exception_finally)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:23:08.789121
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.pycompat24 import StringIO
    sys.stderr = StringIO()
    try:
        raise RuntimeError('Failed')
    except RuntimeError as e:
        if get_exception() != e:
            raise Exception('get_exception() did not return the same exception instance')

# Generated at 2022-06-11 06:23:11.013056
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)



# Generated at 2022-06-11 06:23:13.903442
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Some random exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Some random exception'

# unit test for function literal_eval

# Generated at 2022-06-11 06:23:15.874557
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        assert True == isinstance(get_exception(), Exception)


# Generated at 2022-06-11 06:23:18.040412
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)



# Generated at 2022-06-11 06:23:22.227455
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise Exception('test exception')
    except:
        ex = get_exception()
        assert isinstance(ex, Exception)
        assert ex.args == ('test exception',)
    assert get_exception() is None


# Generated at 2022-06-11 06:23:24.254910
# Unit test for function get_exception
def test_get_exception():
    def test_get_exception_helper():
        raise Exception('foo')
    try:
        test_get_exception_helper()
    except:
        assert str(get_exception()) == 'foo'


# Generated at 2022-06-11 06:24:32.988074
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        err = get_exception()
        assert isinstance(err, ValueError)
        assert str(err) == '', 'get_exception did not re-raise the exception'


# Generated at 2022-06-11 06:24:35.352570
# Unit test for function get_exception
def test_get_exception():
    try:
        int(u'4')
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ValueError'

# Generated at 2022-06-11 06:24:38.132149
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing get_exception')
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'Testing get_exception'

# Generated at 2022-06-11 06:24:40.830190
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("this is a test exception")
    except Exception as test_exception:
        assert test_exception == get_exception()


# Generated at 2022-06-11 06:24:50.699533
# Unit test for function get_exception
def test_get_exception():
    import random
    import time

    def bye():
        try:
            raise NameError('Olsen')
        except NameError as e:
            assert e is get_exception()
            raise

    def hello(name):
        try:
            bye()
        except NameError as e:
            assert e is get_exception()
            raise ValueError(name)

    # We need a sure fire way to get the function name, which is
    # different on Python 2 and Python 3 so we use sys._getframe.
    # This is only available on CPython, so we need to protect it.
    try:
        calling_funcname = sys._getframe(1).f_code.co_name
    except AttributeError:
        calling_funcname = 'unknown function'


# Generated at 2022-06-11 06:24:52.370716
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        assert get_exception().args == ("foo",)

# Generated at 2022-06-11 06:24:56.159386
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError('Foo')
        except ValueError as e:
            return e
    e1 = foo()
    e2 = get_exception()
    assert str(e1) == "Foo"
    assert str(e2) == "Foo"



# Generated at 2022-06-11 06:24:58.496984
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('error message')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'error message'


# Generated at 2022-06-11 06:25:04.449713
# Unit test for function get_exception
def test_get_exception():
    def this_function_raises_an_exception():
        raise ValueError('An exception')

    try:
        this_function_raises_an_exception()
    except Exception:
        exception = get_exception()
        assert(isinstance(exception, ValueError))
        assert(exception.args[0] == 'An exception')
        assert(str(exception) == 'An exception')
    else:
        assert(False)



# Generated at 2022-06-11 06:25:08.236949
# Unit test for function get_exception
def test_get_exception():
    msg = 'This is a message!'

    try:
        raise Exception(msg)
    except Exception as e:
        assert msg == str(e)
        assert msg == str(get_exception())
        assert e.args == get_exception().args
