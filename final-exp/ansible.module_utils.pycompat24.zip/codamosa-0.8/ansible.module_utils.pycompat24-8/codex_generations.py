

# Generated at 2022-06-11 06:18:08.245374
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception as e:
        assert e == get_exception()


# Generated at 2022-06-11 06:18:12.954153
# Unit test for function get_exception
def test_get_exception():
    import random
    import string

    random.seed()
    try:
        raise ValueError(50)
    except ValueError:
        e = get_exception()
        assert e.args == (50,)
        return

    raise AssertionError("Should not reach this point")


# Generated at 2022-06-11 06:18:16.223719
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bogus')
    except Exception:
        e = get_exception()

    assert str(e) == 'bogus'

# Unit tests for function literal_eval

# Generated at 2022-06-11 06:18:22.125768
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception works in non-exception conditons
    try:
        raise RuntimeError()
    except RuntimeError:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'Unknown exception'

    # Test that it works in exception conditions
    try:
        try:
            raise RuntimeError()
        except RuntimeError:
            e = get_exception()
    except TypeError:
        pass
    assert isinstance(e, RuntimeError)
    assert str(e) == 'Unknown exception'

# Unit tests for literal_eval

# Generated at 2022-06-11 06:18:24.907009
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception('test')
        except Exception:
            return get_exception()

    assert f().args == ('test',)



# Generated at 2022-06-11 06:18:33.177038
# Unit test for function get_exception
def test_get_exception():
    # This requires a text diffing function for test_get_excepion to work
    # Ensure that we can get the exception even if it has a long, multi-line string for
    # the traceback.
    e = get_exception()

    try:
        raise ValueError('hello')
    except ValueError as e2:
        if e2 != get_exception():
            raise Exception("Error: get_exception did not return the current exception")

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:18:36.443803
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except: # pylint: disable=bare-except
        e = get_exception()
    assert e.args[0] == 'test'

# Generated at 2022-06-11 06:18:44.949001
# Unit test for function get_exception
def test_get_exception():
    # Common case - we have an exception and we want to catch it and get a
    # traceback
    try:
        raise RuntimeError('Raising for unit test')
    except:
        # pylint: disable=bare-except
        # We want bare except so that we get the exception.  The other
        # case happens when we're run by a test framework and we don't want
        # to alter the test framework's exception handling
        e = get_exception()
        assert str(e) == 'Raising for unit test'

    # No exception case - we want to catch and store the exception so we can
    # continue on.
    try:
        pass
    except:
        # pylint: disable=bare-except
        e = get_exception()
        assert e is None

    # Other case - we want to collect the exception

# Generated at 2022-06-11 06:18:52.264549
# Unit test for function get_exception
def test_get_exception():
    # Zero division exception
    try:
        1 / 0
    except Exception:
        e = get_exception()

    assert hasattr(e, 'message')
    assert isinstance(e.message, str)


    # Value error
    try:
        literal_eval('foo')
    except Exception:
        e = get_exception()

    assert hasattr(e, 'message')
    assert isinstance(e.message, str)

# Generated at 2022-06-11 06:18:54.851505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is an exception')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:19:10.088513
# Unit test for function get_exception
def test_get_exception():
    """Test to ensure get_exception returns the current exceptions

    This test uses a try/except block to set the value of exc to the exception
    being thrown.  We then use get_exception to see if we get the same value out.
    """
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        exc = get_exception()

    assert exc.__class__ is RuntimeError
    assert exc.args == ('foo',)


# Generated at 2022-06-11 06:19:13.616661
# Unit test for function get_exception
def test_get_exception():
    def raise_exc():
        raise RuntimeError("Test Exception")

    try:
        raise_exc()
        assert False, "Exception not raised"
    except RuntimeError as e:
        e2 = get_exception()
        assert e == e2



# Generated at 2022-06-11 06:19:21.920176
# Unit test for function get_exception
def test_get_exception():
    def raise_exc(exc):
        raise exc

    # No exception raised
    try:
        raise_exc(None)
    except:
        assert None == get_exception()

    # Exception raised and caught
    try:
        raise_exc(ValueError)
    except:
        assert ValueError == get_exception()
        assert ValueError == type(get_exception())

    # Exception raised, caught, and ignored
    try:
        raise_exc(ValueError)
    except ValueError:
        pass
    except:
        assert None == get_exception()

# Generated at 2022-06-11 06:19:28.580274
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('Foo')
    except NameError:
        e = get_exception()
    assert e.args[0] == 'Foo'
    assert repr(e) == "NameError('Foo',)"


# Generated at 2022-06-11 06:19:33.382778
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass

    try:
        raise CustomException()
    except Exception:
        e = get_exception()

    assert isinstance(e, CustomException)

    try:
        raise CustomException()
    except Exception:
        e = get_exception()
        raise

    assert isinstance(e, CustomException)



# Generated at 2022-06-11 06:19:35.378979
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise Exception('foo')
    except:
        assert get_exception()



# Generated at 2022-06-11 06:19:37.801275
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('error message text')
    except:
        exc = get_exception()
        assert str(exc) == 'error message text'

# Generated at 2022-06-11 06:19:41.355952
# Unit test for function get_exception
def test_get_exception():
    def raise_exc():
        raise ValueError('testing get_exception')
    try:
        raise_exc()
    except ValueError:
        e = get_exception()
    assert e.args[0] == 'testing get_exception'

# Generated at 2022-06-11 06:19:44.685162
# Unit test for function get_exception
def test_get_exception():
    # Python 3.x does not have StandardError.  Test that we get the correct
    # exception object as long as StandardError is still in the inheritance
    # path
    exception = get_exception()
    assert exception.__class__ in StandardError.__mro__



# Generated at 2022-06-11 06:19:47.568425
# Unit test for function get_exception
def test_get_exception():
    try:
        s = "Hello World"
        s[100]
        assert False, "Exception not raised"
    except Exception:
        e = get_exception()
        assert isinstance(e, IndexError)

# Generated at 2022-06-11 06:19:59.488804
# Unit test for function get_exception
def test_get_exception():
    raise RuntimeError('foo')


try:
    result = get_exception()
except:  # noqa
    result = 'foo'

if result != 'foo':
    msg = "get_exception() failed: expected {0} got {1}".format(
            'foo', repr(result))
    raise AssertionError(msg)

# Generated at 2022-06-11 06:20:01.944336
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e_value:
        e_get = get_exception()
        assert e_value is e_get


# Generated at 2022-06-11 06:20:09.527871
# Unit test for function get_exception
def test_get_exception():
    # Test that we can get an exception
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'foo'

    # Test that we can get the exception from an inner block
    try:
        try:
            raise Exception('bar')
        except Exception:
            e = get_exception()
    except Exception:
        pass
    assert e.args[0] == 'bar'

    # Test that we can get the exception from a function
    def inner():
        try:
            raise Exception('baz')
        except Exception:
            e = get_exception()
        return e
    try:
        e = inner()
    except Exception:
        pass
    assert e.args[0] == 'baz'

# Generated at 2022-06-11 06:20:18.673548
# Unit test for function get_exception

# Generated at 2022-06-11 06:20:21.525912
# Unit test for function get_exception

# Generated at 2022-06-11 06:20:24.466104
# Unit test for function get_exception
def test_get_exception():
    class Except(Exception):
        pass

    try:
        raise Except('Here is the issue')
    except Except:
        e = get_exception()
    assert 'Here is the issue' in str(e)

# Generated at 2022-06-11 06:20:26.111522
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert get_exception() is e

# Generated at 2022-06-11 06:20:28.470306
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testerr')
    except:
        assert get_exception().args[0] == 'testerr'


# Generated at 2022-06-11 06:20:38.117783
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        exc = get_exception()
    assert isinstance(exc, ZeroDivisionError)

    try:
        litereval("1+1")
    except SyntaxError:
        exc = get_exception()
    assert isinstance(exc, SyntaxError)

    # For Python 2.4, literal_eval doesn't raise the correct exception
    try:
        literal_eval("1+1")
    except ValueError:
        exc = get_exception()
    if sys.version_info[:2] == (2, 4):
        assert isinstance(exc, SyntaxError)
    else:
        assert isinstance(exc, ValueError), exc

# Generated at 2022-06-11 06:20:41.228774
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test")
    except Exception:
        e = get_exception()
        assert type(e) == type(ValueError("test"))
        assert e.args == ("test", )


# Generated at 2022-06-11 06:20:51.877300
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo bar baz')
    except ValueError:
        e = get_exception()
    assert 'foo bar baz' in str(e)



# Generated at 2022-06-11 06:20:54.592756
# Unit test for function get_exception
def test_get_exception():
    def func():
        try:
            raise StopIteration
        except StopIteration:
            return get_exception()

    assert isinstance(func(), StopIteration)

# Generated at 2022-06-11 06:20:57.507138
# Unit test for function get_exception
def test_get_exception():
    def get_exception_inner():
        try:
            raise ValueError('foo')
        except:
            return get_exception()

    assert get_exception_inner().args == ('foo',)


# Generated at 2022-06-11 06:21:04.483286
# Unit test for function get_exception
def test_get_exception():
    # This function needs to work on Python 2.4 through 3.x, so we cannot use
    # "except Exception, e:" (SyntaxError on Python 3.x) nor
    # "except Exception as e:" (SyntaxError on Python 2.4-2.5).
    # Instead we must use ::
    #
    #     except Exception:
    #         e = get_exception()

    try:
        raise Exception("This is the exception we're looking for!")
    except:
        e = get_exception()
    assert "This is the exception we're looking for!" in str(e)

# Generated at 2022-06-11 06:21:08.003387
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Thou shalt not pass!")
    except Exception:
        e = get_exception()
    if e.args != ("Thou shalt not pass!",):
        raise AssertionError("Wrong error: %r" % (e,))


# Generated at 2022-06-11 06:21:10.729959
# Unit test for function get_exception
def test_get_exception():
    try:
        (1, 2, 3)[4]
    except Exception:
        e = get_exception()
    assert isinstance(e, IndexError)


# Generated at 2022-06-11 06:21:16.968254
# Unit test for function get_exception
def test_get_exception():
    '''
    Ensure that get_exception returns the correct data for various exception types
    and that it doesn't throw any exceptions
    '''
    try:
        raise Exception('This is a Exception')
    except Exception:
        assert get_exception().args[0] == 'This is a Exception'

    try:
        raise ValueError('This is a ValueError')
    except Exception:
        assert get_exception().args[0] == 'This is a ValueError'


# Generated at 2022-06-11 06:21:19.436924
# Unit test for function get_exception
def test_get_exception():
    def inner():
        try:
            raise RuntimeError('foo')
        except RuntimeError as e:
            assert get_exception() == e

    inner()



# Generated at 2022-06-11 06:21:21.507077
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('one')
    except:
        exception = get_exception()
    assert exception.args[0] == 'one'

# Generated at 2022-06-11 06:21:23.065009
# Unit test for function get_exception

# Generated at 2022-06-11 06:21:40.255606
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert get_exception().args[0] == 'foo'


# Generated at 2022-06-11 06:21:42.962989
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception('raised Exception')

    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert str(e) == 'raised Exception'

# Generated at 2022-06-11 06:21:51.943848
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=function-redefined
    import ansible.module_utils.basic
    ansible.module_utils.basic.get_exception = get_exception
    import ansible.module_utils.basic
    reload(ansible.module_utils.basic)
    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModule  # pylint: disable=redefined-variable-type
    # Check that get_exception is the version in module_utils.basic
    assert ansible.module_utils.basic.get_exception is get_exception
    # Run the unit test in module_utils.basic
    ansible.module_utils.basic.test_get_exception()

# Generated at 2022-06-11 06:21:54.382896
# Unit test for function get_exception
def test_get_exception():
    import doctest
    return doctest.run_docstring_examples(get_exception, globals())


# Generated at 2022-06-11 06:21:57.655002
# Unit test for function get_exception
def test_get_exception():
    try:
        int("spam")
    except:
        # Check that this does not fail
        e = get_exception()
        try:
            raise e
        except ValueError:
            # success
            pass

# Generated at 2022-06-11 06:22:01.368100
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=undefined-variable
    try:
        raise ValueError('Error 1')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('Error 1',)


# Generated at 2022-06-11 06:22:03.454305
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-11 06:22:05.556785
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('qwerty')
    except RuntimeError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:22:11.753967
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except:
        e = get_exception()
    assert isinstance(e, ValueError)

    try:
        raise ValueError(1)
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == (1, )

    try:
        raise ValueError()
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == tuple()

    try:
        raise ValueError(1, 2)
    except:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == (1, 2)

# Generated at 2022-06-11 06:22:15.595690
# Unit test for function get_exception
def test_get_exception():
    '''Test function get_exception'''
    try:
        raise ValueError("Test exception")
    except Exception:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == "Test exception"


# Generated at 2022-06-11 06:22:33.724855
# Unit test for function get_exception
def test_get_exception():
    class Test(Exception):
        pass

    try:
        raise Test()
    except Exception:
        e = get_exception()
        assert e and isinstance(e, Test)

# Generated at 2022-06-11 06:22:40.048218
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        # On python2.4 and python2.5, sys.exc_info() returns (None, None, None)
        # if there's no current exception.
        if sys.exc_info() == (None, None, None):
            e = None
        else:
            e = get_exception()
    if e is None:
        return False

    if str(e) != 'foo':
        return False

    try:
        raise Exception(u'bar')
    except Exception:
        # On python2.4 and python2.5, sys.exc_info() returns (None, None, None)
        # if there's no current exception.
        if sys.exc_info() == (None, None, None):
            e = None
        else:
            e

# Generated at 2022-06-11 06:22:41.955121
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        e = get_exception()
    assert type(e) is ValueError


# Generated at 2022-06-11 06:22:44.986339
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test exception')
    except RuntimeError:
        if get_exception().args[0] != 'test exception':
            raise AssertionError("Unexpected exception args: %r" % get_exception())

# Generated at 2022-06-11 06:22:47.441881
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:22:49.423312
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SystemError('fake error')
    except SystemError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:22:52.668226
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Hi')  # pylint: disable=undefined-variable
    except TypeError:
        e = get_exception()
    print(e)
    assert e.args == ('Hi',)



# Generated at 2022-06-11 06:22:55.444995
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException
    except: # noqa
        err = get_exception()

    assert isinstance(err, TestException)

# Generated at 2022-06-11 06:22:57.927999
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a test')
    except RuntimeError:
        exc = get_exception()
    assert exc.args[0] == 'This is a test'

# Generated at 2022-06-11 06:23:03.365719
# Unit test for function get_exception
def test_get_exception():
    """
    >>> try:
    ...     raise SyntaxError("Foo bar baz")
    ... except Exception:
    ...     e = get_exception()
    ...     msg = str(e)
    >>> msg
    'Foo bar baz'
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS, verbose=False)

# Generated at 2022-06-11 06:23:39.885441
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert str(exc) == 'test exception'

# Generated at 2022-06-11 06:23:41.904902
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
    assert isinstance(e, Exception)



# Generated at 2022-06-11 06:23:44.270090
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    e = MyException()
    try:
        raise e
    except MyException:
        got = get_exception()
    assert e is got

# Generated at 2022-06-11 06:23:46.586274
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-11 06:23:49.148243
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('an exception')
    except TypeError as e:
        the_exception = get_exception()
    assert the_exception is e

# Generated at 2022-06-11 06:23:52.122605
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Test exception'

# Generated at 2022-06-11 06:23:59.717324
# Unit test for function get_exception

# Generated at 2022-06-11 06:24:01.861525
# Unit test for function get_exception

# Generated at 2022-06-11 06:24:07.188839
# Unit test for function get_exception
def test_get_exception():
    import pytest
    from ansible.module_utils.six import reraise
    def g():
        e = None
        try:
            raise Exception('test_get_exception')
        except Exception:
            e = get_exception()
            reraise(Exception, e, sys.exc_info()[2])
    with pytest.raises(Exception):
        g()

# Generated at 2022-06-11 06:24:09.541759
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:25:20.007162
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=unused-argument
    try:
        1/0  # pylint: disable=pointless-statement
    except:
        assert type(get_exception()) is ZeroDivisionError, "get_exception() did not return ZeroDivisionError"
    else:
        raise AssertionError("No exception caught, this should not be possible")


# Generated at 2022-06-11 06:25:23.129655
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception('foo')

    try:
        raise_exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args[0] == 'foo'



# Generated at 2022-06-11 06:25:25.265267
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        exception = get_exception()
    assert exception.args[0] == 'foo'



# Generated at 2022-06-11 06:25:28.822856
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils._text import to_text
    try:
        raise RuntimeError(u'\u6d4b\u8bd5')
    except:
        exc = get_exception()
        assert to_text(exc) == u'\u6d4b\u8bd5'



# Generated at 2022-06-11 06:25:30.900723
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test exception')
    except:
        ex = get_exception()
        assert str(ex) == 'This is a test exception'

# Generated at 2022-06-11 06:25:34.227166
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('Test name error')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'Test name error'
        assert e.__class__.__name__ == 'NameError'



# Generated at 2022-06-11 06:25:36.519860
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)


# Generated at 2022-06-11 06:25:41.254577
# Unit test for function get_exception
def test_get_exception():
    def _test(e):
        try:
            raise e
        except Exception:
            f = get_exception()
            assert isinstance(f, type(e))
            assert f.args == e.args
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        _test(e)

    _test(Exception())

# Generated at 2022-06-11 06:25:44.010007
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(18)
    except ValueError as e:
        mye = get_exception()
    assert mye == e



# Generated at 2022-06-11 06:25:46.421102
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test Exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'Test Exception'