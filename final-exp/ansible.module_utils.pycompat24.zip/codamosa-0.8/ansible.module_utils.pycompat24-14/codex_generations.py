

# Generated at 2022-06-11 06:18:04.870312
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foobar')
    except ValueError:
        e = get_exception()
        assert e.args == ('foobar',)

# Generated at 2022-06-11 06:18:14.609102
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing')
    except:
        try:
            raise ValueError('A different exception')
        except:
            pass
    e1 = get_exception()
    try:
        raise ValueError('A different exception')
    except:
        pass
    e2 = get_exception()
    try:
        raise ValueError('A different exception')
    except ValueError as e3:
        pass
    assert str(e1) == 'Testing'
    assert str(e2) == 'A different exception'
    assert str(e3) == 'A different exception'
    assert e1.__class__ is e2.__class__
    assert e1.__class__ is e3.__class__

# Generated at 2022-06-11 06:18:19.132053
# Unit test for function get_exception
def test_get_exception():
    class CustomException(Exception):
        pass
    try:
        raise CustomException()
    except:
        e = get_exception()
    assert type(e) is CustomException
    try:
        raise CustomException()
    except Exception:
        e = get_exception()
    assert type(e) is CustomException


# Generated at 2022-06-11 06:18:21.685103
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        ex = get_exception()
    assert ex.args[0] == 'foo'
    assert type(ex) == RuntimeError

# Generated at 2022-06-11 06:18:32.469467
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception

    This is covered in more detail in the tests that import this function.  Those tests
    are in the test/units/utils directory. This test just provides a basic sanity check.

    The point of this test is to make sure that get_exception is callable and returns
    a valid exception.  The only tricky thing is that we need to raise the exception
    inside an exec statement to get it to propagate.  This is done so that the test
    runs properly inside python2.4.

    :returns: bool.  True if the function executes properly, False otherwise.
    """
    a = 0
    b = 1
    try:
        exec("c = a + b")
    except Exception:
        return bool(get_exception())

# Generated at 2022-06-11 06:18:36.589995
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception('testing exception')
    try:
        f()
    except Exception:
        e = get_exception()
    assert str(e) == 'testing exception'
    assert e.args == ('testing exception',)



# Generated at 2022-06-11 06:18:43.809221
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            raise Exception('test')
        except Exception:
            e = get_exception()
            # Make sure it returns the same object we just threw
            assert id(e) == id(sys.exc_info()[1])
            raise

    def fail_exception():
        try:
            raise_exception()
        except Exception:
            e = get_exception()
            # Make sure it returns the same object we just threw
            assert id(e) == id(sys.exc_info()[1])
            assert e.__str__() == 'test'

    fail_exception()

# Generated at 2022-06-11 06:18:46.233465
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()

    assert 'foo' in str(e)

# Generated at 2022-06-11 06:18:51.109405
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)
    assert str(e) == "Test exception"


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:18:54.130711
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-11 06:19:14.384878
# Unit test for function get_exception
def test_get_exception():
    def get_exception_test():
        raise ValueError('Test message')

    try:
        get_exception_test()
    except:  # pylint: disable=bare-except
        e = get_exception()

    assert(e.args[0] == 'Test message')

# Generated at 2022-06-11 06:19:21.971318
# Unit test for function get_exception
def test_get_exception():
    # Test with a try block that raises an exception
    try:
        raise ValueError("Something's wrong")
    except ValueError:
        e = get_exception()

    assert e.args[0] == "Something's wrong", 'Got wrong exception back'

    # Test with a basic exception

# Generated at 2022-06-11 06:19:25.960003
# Unit test for function get_exception
def test_get_exception():
    '''Test the get_exception() function'''
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'foo' in str(e)



# Generated at 2022-06-11 06:19:29.466645
# Unit test for function get_exception
def test_get_exception():

    def test_error():
        try:
            raise ValueError('test_message')
        except Exception:
            e = get_exception()
        if str(e) == 'test_message':
            assert True
        else:
            assert False

    test_error()


# Generated at 2022-06-11 06:19:31.837746
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)


# Generated at 2022-06-11 06:19:35.547783
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('dummy exception')
    except Exception:
        exc = get_exception()
        exc.__str__()
    except: # pylint: disable=bare-except
        raise Exception('get_exception() did not return a real exception')

# Literal Eval unit test

# Generated at 2022-06-11 06:19:37.286329
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e is get_exception()

# Generated at 2022-06-11 06:19:43.643762
# Unit test for function get_exception
def test_get_exception():
    def divide(a, b):
        try:
            return a / b
        except Exception:
            e = get_exception()
            print(e.__class__.__name__)
            raise

    try:
        divide(1, 0)
    except Exception as e:
        assert e.__class__.__name__ == 'ZeroDivisionError'

    try:
        divide('asdf', 3)
    except Exception as e:
        assert e.__class__.__name__ == 'TypeError'

# Generated at 2022-06-11 06:19:53.028931
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import mock

    from ansible.module_utils._text import to_bytes

    class TestException(Exception):

        def __init__(self, foo, bar=None):
            Exception.__init__(self)
            self.foo = foo
            self.bar = bar

        def __unicode__(self):
            return u"%s: foo=%s bar=%s" % (
                self.__class__.__name__,
                self.foo,
                self.bar
            )

        def __str__(self):
            if sys.version_info < (3,):
                return self.__unicode__()
            else:
                return self.__unicode__().encode('utf-8')


# Generated at 2022-06-11 06:19:57.988110
# Unit test for function get_exception
def test_get_exception():

    def testit(func):
        try:
            func()
        except Exception:
            exception = get_exception()
            if sys.version_info[0] == 2:
                assert isinstance(exception, SyntaxError)
            else:
                assert isinstance(exception, (NameError, SyntaxError))
        else:
            assert 0, 'should have had an exception'

    testit(lambda: eval('raise NameError()'))
    testit(lambda: exec('raise SyntaxError()'))

# Generated at 2022-06-11 06:20:18.975864
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise RuntimeError('foo')
        except RuntimeError:
            exc = get_exception()
            assert exc.args == ('foo',)
    except AssertionError:
        raise AssertionError('Unable to retrieve exception')


# Generated at 2022-06-11 06:20:22.266883
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is a test')
    except:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'this is a test'

# Generated at 2022-06-11 06:20:28.399820
# Unit test for function get_exception
def test_get_exception():
    def f():
        g()

    def g():
        h()

    def h():
        raise Exception("exception in h()")

    try:
        f()
    except:
        e = get_exception()
        assert str(e) == 'exception in h()', "function get_exception() returned '%s', expected 'exception in h()'" % str(e)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:20:32.287735
# Unit test for function get_exception
def test_get_exception():
    import uuid

    try:
        raise RuntimeError(uuid.uuid4())
    except Exception:
        e = get_exception()

    assert e.args[0] == get_exception().args[0]

# Generated at 2022-06-11 06:20:37.220495
# Unit test for function get_exception
def test_get_exception():
    '''Test function get_exception

    This function is rather simple (just grabs the exception from the stack)
    so we test it by checking if it makes a valid comparison to another exception
    of the same type.'''
    try:
        raise Exception('This is the message of the exception for the test')
    except Exception:
        assert get_exception() == Exception('This is the message of the exception for the test')


# Generated at 2022-06-11 06:20:40.450686
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('test')
    except NameError:
        e = get_exception()

    assert type(e) == NameError
    assert e.args == ('test',)

# Generated at 2022-06-11 06:20:42.694018
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test'



# Generated at 2022-06-11 06:20:44.972341
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        assert str(get_exception()) == "Test exception"


# Generated at 2022-06-11 06:20:48.489290
# Unit test for function get_exception
def test_get_exception():
    def raise_exc(arg):
        raise arg

    test_exc = ValueError()
    try:
        raise_exc(test_exc)
    except:
        exc = get_exception()
    assert test_exc == exc

# Generated at 2022-06-11 06:20:53.384881
# Unit test for function get_exception
def test_get_exception():
    """Make sure get_exception returns something we can use"""
    try:
        raise ValueError('testing')
    except:
        new_exception = get_exception()
        assert new_exception is not None
        assert isinstance(new_exception, ValueError)
        assert 'testing' in str(new_exception)

# Generated at 2022-06-11 06:21:30.358794
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        x = get_exception()
        assert str(x) == 'foo'

# Unit tests for function literal_eval

# Generated at 2022-06-11 06:21:38.363587
# Unit test for function get_exception
def test_get_exception():
    import tempfile
    try:
        raise Exception('An exception')
    except Exception:
        e1 = get_exception()
    assert str(e1) == 'An exception'
    try:
        raise Exception('Another exception')
    except Exception:
        e1 = None
        e2 = get_exception()
    assert str(e2) == 'Another exception'
    try:
        with tempfile.TemporaryFile() as f:
            raise Exception('Yet another exception')
    except Exception:
        e1 = None
        e2 = None
        e3 = get_exception()
    assert str(e3) == 'Yet another exception'


# Generated at 2022-06-11 06:21:39.603059
# Unit test for function get_exception
def test_get_exception():
    try:
        int("foo")
        assert False, "Expected an exception"
    except Exception:
        e = get_exception()

    assert str(e) == "invalid literal for int() with base 10: 'foo'"


# Generated at 2022-06-11 06:21:41.640909
# Unit test for function get_exception
def test_get_exception():

    try:
        raise ValueError('Test exception')
    except ValueError:
        assert (get_exception()).message == 'Test exception'

# Generated at 2022-06-11 06:21:43.550563
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('testing')
    except Exception:
        ex = get_exception()
    assert str(ex) == 'testing'

# Generated at 2022-06-11 06:21:46.016515
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except:
        e = get_exception()
        assert 'test_get_exception' in repr(e)
test_get_exception()


# Generated at 2022-06-11 06:21:48.708502
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Test Exception')
    except TypeError:
        assert get_exception().args[0] == 'Test Exception'



# Generated at 2022-06-11 06:21:50.804513
# Unit test for function get_exception
def test_get_exception():
    try:
        int('asdf')
    except Exception:
        assert isinstance(get_exception(), ValueError)

# Generated at 2022-06-11 06:21:53.891460
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('testing')
    except:
        exc = get_exception()
    assert isinstance(exc, RuntimeError)
    assert exc.args == ('testing',)

# Generated at 2022-06-11 06:21:56.008689
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception()



# Generated at 2022-06-11 06:23:03.946939
# Unit test for function get_exception
def test_get_exception():
    def f():
        try:
            raise Exception('Test Exception')
        except Exception:
            return get_exception()
    assert 'Test Exception' == repr(f())

# Generated at 2022-06-11 06:23:06.781376
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert str(e) == 'foo'
        assert isinstance(e, Exception)


# Generated at 2022-06-11 06:23:08.825103
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 + 'b'
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'TypeError'


# Generated at 2022-06-11 06:23:11.364737
# Unit test for function get_exception
def test_get_exception():
    class TestException():
        pass
    try:
        raise TestException
    except:
        assert get_exception().__class__ == TestException, get_exception().__class__


# Generated at 2022-06-11 06:23:17.208099
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-import
    try:
        import bogusmodule  # noqa
    except Exception as e:
        our_e = e
    except Exception:
        our_e = get_exception()

    try:
        raise Exception('this is for testing')
    except Exception as e:
        their_e = e
    except Exception:
        their_e = get_exception()

    assert our_e.__class__ == their_e.__class__

# Generated at 2022-06-11 06:23:19.631388
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('TEST EXCEPTION')
    except Exception:
        x = get_exception()
        assert 'TEST EXCEPTION' in str(x)

# Generated at 2022-06-11 06:23:24.898985
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception returns the correct exception"""
    try:
        raise RuntimeError('test exception')
    except Exception:
        e = get_exception()
        assert unicode(e) == u'test exception', unicode(e)
        assert str(e) == 'test exception', str(e)
        assert repr(e) == 'RuntimeError(\'test exception\',)', repr(e)

# Generated at 2022-06-11 06:23:27.811142
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception works."""
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'foo'


# Generated at 2022-06-11 06:23:31.667426
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException('Testing')
    except:
        exc = get_exception()
    assert isinstance(exc, TestException)
    assert repr(exc) == repr(TestException('Testing'))
    assert str(exc) == str(TestException('Testing'))

# Generated at 2022-06-11 06:23:41.399732
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception")
    except RuntimeError:
        exc = get_exception()
        expected = "RuntimeError: 'Test exception'"
        got = "'%s: %s'" % (exc.__class__.__name__, exc)

        ### Dont' use assertEquals here because it'll call __eq__ for the Exc
        ### and pass if it's a string.  We want to make sure we got the Exc.
        if expected != got:
            raise AssertionError("Got wrong exception, expected %s but got %s" % (expected, got))

if __name__ == '__main__':
    try:
        test_get_exception()
    except AssertionError as err:
        print('FAIL: %s' % err)

# Generated at 2022-06-11 06:26:19.853602
# Unit test for function get_exception
def test_get_exception():
    # Test when there is no exception
    try:
        e = get_exception()
    except Exception:
        raise AssertionError('get_exception() raised an exception when there was no exception?')
    assert e is None, 'get_exception() did not return None when there was no exception'

    # Test when there is an exception
    try:
        raise ValueError()
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == '', 'get_exception() did not return the correct exception'



# Generated at 2022-06-11 06:26:21.418135
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('blah')
    except:
        e = get_exception()
        assert str(e) == 'blah'


# Generated at 2022-06-11 06:26:23.029954
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'

# Generated at 2022-06-11 06:26:25.470842
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('testing')
    except RuntimeError:
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'testing'



# Generated at 2022-06-11 06:26:28.114370
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test_get_exception")
    except ValueError as ex:
        assert get_exception() is ex


# Generated at 2022-06-11 06:26:30.017804
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        exc = get_exception()
        return (isinstance(exc, Exception) and exc is not None)

# Generated at 2022-06-11 06:26:31.954945
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:26:34.993734
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test exception")
    except:
        e = get_exception()
        if str(e) != "test exception":
            raise AssertionError("test_get_exception() returned wrong string")

# Generated at 2022-06-11 06:26:42.782257
# Unit test for function get_exception
def test_get_exception():
    failed = 0
    try:
        raise Exception('Testing')
    except:
        try:
            test_val = None
            assert test_val is not None
        except AssertionError:
            test_val = get_exception()

    if test_val.message != 'Testing':
        print("get_exception() test failed due to unexpected exception message:")
        print("Expected: %s" % "Testing")
        print("Received: %s" % test_val.message)
        failed += 1

    if failed > 0:
        exit(255)
    else:
        exit(0)


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:26:45.246121
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
    assert (exc.args == ('foo',))