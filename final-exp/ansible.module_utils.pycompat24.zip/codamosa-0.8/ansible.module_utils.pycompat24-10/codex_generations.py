

# Generated at 2022-06-11 06:18:06.138063
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('some random error')
    except:
        assert get_exception().args[0] == 'some random error'

# Generated at 2022-06-11 06:18:08.178461
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("something")
    except Exception:
        e = get_exception()
    assert str(e) == "something"

# Generated at 2022-06-11 06:18:15.443664
# Unit test for function get_exception
def test_get_exception():  # noqa pylint: disable=unused-variable
    try:
        1/0
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

    try:
        {}['a']
    except Exception:
        e = get_exception()
        assert isinstance(e, KeyError)

    try:
        1 + 'a'
    except Exception:
        e = get_exception()
        assert isinstance(e, TypeError)

# Generated at 2022-06-11 06:18:17.370874
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError
    except AssertionError:
        assert get_exception()

# Generated at 2022-06-11 06:18:28.174781
# Unit test for function get_exception
def test_get_exception():
    """
    This is a test to make sure that the get_exception function works on
    python 2.4 through python 3 and all code paths.

    It doesn't use unitest and will simply print the expected versus
    actual output of the get_exception function.  If the two match then
    the main function will return 0 and otherwise it will return a 1
    """
    try:
        raise NameError
    except:
        expected = sys.exc_info()[1]
        post_exception = get_exception()

    if expected == post_exception:
        print("Passed!")
        return 0
    else:
        print("Expected: %s, got %s" % (expected, post_exception))
        return 1



# Generated at 2022-06-11 06:18:33.610387
# Unit test for function get_exception
def test_get_exception():
    # The get_exception function can be used to get the exception out of the
    # except: clause so that the exception can be used in a re-raise.
    try:
        raise RuntimeError("Test")
    except RuntimeError:
        e = get_exception()
        assert("Test" in str(e))
        try:
            raise e
        except:
            pass

# Generated at 2022-06-11 06:18:39.648733
# Unit test for function get_exception
def test_get_exception():
    class Foo(Exception):
        pass

    try:
        raise Foo('testexception')
    except Exception:
        e = get_exception()

    assert isinstance(e, Foo), ("Exception should be of type Foo but is {0}".format(type(e)))
    assert str(e) == 'testexception', ("Exception message should be 'testexception' but is '{0}'".format(str(e)))


# Generated at 2022-06-11 06:18:43.706855
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is an exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'This is an exception'
        assert type(e) == Exception
        try:
            raise IndexError
        except IndexError:
            e = get_exception()
            assert type(e) == IndexError



# Generated at 2022-06-11 06:18:46.763927
# Unit test for function get_exception
def test_get_exception():
    def f():
        raise Exception
    try:
        f()
    except:
        assert get_exception() == sys.exc_info()[1]


# Generated at 2022-06-11 06:18:52.585424
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except:
        e = get_exception()
        assert e.args == ('test',)
    try:
        raise Exception('testing', 'string arguments')
    except:
        e = get_exception()
        assert e.args == ('testing', 'string arguments')


# Generated at 2022-06-11 06:19:05.720709
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception message')
    except:
        exc = get_exception()
        assert str(exc) == 'Test exception message'
        assert repr(exc) == "<class 'exceptions.ValueError'>: Test exception message"
        assert isinstance(exc, ValueError)



# Generated at 2022-06-11 06:19:09.104098
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
        assert str(e) == "foo"



# Generated at 2022-06-11 06:19:13.055603
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'foo'
    assert repr(e) == 'Exception(\'foo\',)'



# Generated at 2022-06-11 06:19:15.045659
# Unit test for function get_exception
def test_get_exception():
    try:
        int("this is a string")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:19:18.955285
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()

    if not (isinstance(e, Exception) and str(e) == 'Test exception'):
        raise AssertionError('get_exception() does not get the current exception')

# Generated at 2022-06-11 06:19:23.103201
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.message == "foo"



# Generated at 2022-06-11 06:19:25.310056
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:19:31.790502
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    def test_function():
        try:
            raise ValueError()
        except ValueError:
            e = get_exception()
            return e

    result = module.from_json(module.run_command(cmd=['python', '-c', "import %s; print(%s.literal_eval('{\"foo\": \"bar\"}'))" % (__name__, __name__)]))
    module.exit_json(result=result)



# Generated at 2022-06-11 06:19:34.157428
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-11 06:19:43.729298
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> test_get_exception()
    Exception example:
    	NameError: testing
    Exception example:
    	TypeError: cannot concatenate 'str' and 'int' objects
    '''
    import doctest

    exception_example = ['NameError: testing', 'TypeError: cannot concatenate \'str\' and \'int\' objects']

    print('Exception example:')
    try:
        eval(exception_example[0])
    except NameError:
        print('\t' + str(get_exception()))

    print('Exception example:')
    try:
        'value' + 1
    except TypeError:
        print('\t' + str(get_exception()))

    return True

if __name__ == '__main__':
    import doctest
    doctest.test

# Generated at 2022-06-11 06:20:06.582522
# Unit test for function get_exception
def test_get_exception():
    # If we get an AttributeError in get_exception(), we'll raise
    # an AttributeError in the caller.  So, what do we get if we raise
    # an exception?
    try:
        raise AttributeError('foo')
    except AttributeError:
        exc_class, exc, tb = sys.exc_info()
        assert get_exception().args == ('foo',)
        exc_class2, exc2, tb2 = sys.exc_info()
        assert exc is exc2
        assert tb is tb2


# Generated at 2022-06-11 06:20:14.406055
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import sys

    class GetExceptionTestCase(unittest.TestCase):
        def setUp(self):
            self._saved_exc_info = sys.exc_info()

        def tearDown(self):
            sys.exc_info_ = self._saved_exc_info

        def test_get_exception(self):
            try:
                int('1a')
            except ValueError:
                e = get_exception()
            self.assertTrue(isinstance(e, ValueError))

        def test_get_exception_no_exception(self):
            e = get_exception()
            self.assertTrue(e is None)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(GetExceptionTestCase))
    un

# Generated at 2022-06-11 06:20:17.199406
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert str(e) == 'foo'


# Generated at 2022-06-11 06:20:19.863140
# Unit test for function get_exception
def test_get_exception():
    # Should have a better unit test here.  Right now, all this test does is
    # verify that we don't have a SyntaxError when loading this module.
    assert 1

# Generated at 2022-06-11 06:20:25.582852
# Unit test for function get_exception
def test_get_exception():
    def foo():
        return get_exception()

    try:
        raise Exception('This should be printed.')
    except Exception:
        e = foo()
        if not isinstance(e, Exception):
            raise ValueError('get_exception returned a non-exception')
        if str(e) != 'This should be printed.':
            raise ValueError('get_exception returned an exception other than the one we threw')



# Generated at 2022-06-11 06:20:27.713024
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'Test exception'

# Generated at 2022-06-11 06:20:30.548319
# Unit test for function get_exception
def test_get_exception():
    """
    >>> print(get_exception())
    None
    """
    pass


# Generated at 2022-06-11 06:20:34.557226
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        a = 1
        if a != 1:
            raise Exception()
        return True

    try:
        raise_exception()
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)

# Generated at 2022-06-11 06:20:38.763130
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing123')
    except:
        assert get_exception() == ValueError('testing123')
    try:
        1/0
    except:
        assert get_exception() == ZeroDivisionError('integer division or modulo by zero')


# Generated at 2022-06-11 06:20:41.495828
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except Exception:
        e = get_exception()
        if str(e) != "Test Exception":
            raise


# Generated at 2022-06-11 06:21:16.759555
# Unit test for function get_exception
def test_get_exception():
    # Make a try block that raises an exception
    try:
        raise RuntimeError("Foobar")
    except:
        exception = get_exception()

    assert exception
    assert exception.args == ("Foobar",)

# Generated at 2022-06-11 06:21:17.929301
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        e = get_exception()
    assert str(e) == "foo"



# Generated at 2022-06-11 06:21:23.057687
# Unit test for function get_exception

# Generated at 2022-06-11 06:21:25.509756
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        exception = get_exception()
    print(exception)
    assert(str(exception) == 'This is a test')


# Generated at 2022-06-11 06:21:27.521104
# Unit test for function get_exception
def test_get_exception():
    try:
        [][1]
    except:
        e = get_exception()
        assert isinstance(e, IndexError)
        assert 'list index out of range' in str(e)

# Generated at 2022-06-11 06:21:31.189943
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test Error')
    except Exception:
        e = get_exception()
    assert isinstance(e, RuntimeError)
    assert str(e) == 'Test Error'

# Generated at 2022-06-11 06:21:40.863076
# Unit test for function get_exception
def test_get_exception():
    # These are verbs that aren't allowed in the dictionary.  This should raise an
    # exception.
    bad_verbs = ['random', 'sunset']

    try:
        dictionary = {'Verb': bad_verbs[0]}
        raise TypeError('invalid key ' + dictionary['Verb'])
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert str(e) == "invalid key " + bad_verbs[0]

    try:
        dictionary = {'Verb': bad_verbs[1]}
        raise TypeError('invalid key ' + dictionary['Verb'])
    except TypeError:
        e = get_exception()
    assert isinstance(e, TypeError)

# Generated at 2022-06-11 06:21:48.251471
# Unit test for function get_exception
def test_get_exception():
    """Function to test get_exception"""
    # Test 1: test get_exception in a function that raises an exception
    def test_func():
        """Function to test get_exception"""
        try:
            raise RuntimeError('get_exception')
        except Exception:
            return get_exception()

    # Run test
    result = test_func()
    assert isinstance(result, RuntimeError)
    assert str(result) == 'get_exception'
    assert result.args == ('get_exception',)

    # Test 2: test get_exception in a function that doesn't raise an exception
    def test_func_noexception():
        """Function to test get_exception"""
        try:
            pass
        except Exception:
            return get_exception()

    # Run test
    result = test_

# Generated at 2022-06-11 06:21:56.008057
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('banana')
    except:
        e = get_exception()
    assert e.args == ('banana',)
    try:
        raise ValueError('kiwi')
    except:
        import traceback
        # Verify that the exception object is the same object that the
        # stack trace refers to
        stack = traceback.format_exc()
        e = get_exception()
    assert e.args == ('kiwi',)
    assert str(e) in stack



# Generated at 2022-06-11 06:22:04.728901
# Unit test for function get_exception
def test_get_exception():
    assert 'test_get_exception' == get_exception().args[0]
    try:
        assert 'test_get_exception' == get_exception().args[0]
    except AssertionError as e:
        assert 'test_get_exception' == e.args[0]
    else:
        raise AssertionError("Didn't raise an AssertionError!")
    try:
        assert 'failing_test' == get_exception().args[0]
    except AssertionError as e:
        assert 'failing_test' == e.args[0]
    else:
        raise AssertionError("Didn't raise an AssertionError!")



# Generated at 2022-06-11 06:23:10.976622
# Unit test for function get_exception
def test_get_exception():
    def inner_func():
        try:
            raise ValueError()
        except ValueError:
            e = get_exception()
            print(e)
            return e
    e = inner_func()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:23:14.911212
# Unit test for function get_exception
def test_get_exception():
    try:
        some_var  # pylint: disable=undefined-variable
    except NameError:
        e = get_exception()
        if str(e) != "name 'some_var' is not defined":
            raise Exception("get_exception() didn't return the current exception")

# Generated at 2022-06-11 06:23:16.964910
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except:
        e = get_exception()
    assert type(e) == ValueError

# Generated at 2022-06-11 06:23:19.919061
# Unit test for function get_exception
def test_get_exception():
    class Oops(Exception):
        pass

    try:
        raise Oops('went boom')
    except Exception:
        exception = get_exception()
    assert isinstance(exception, Oops)


# Generated at 2022-06-11 06:23:22.139161
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        got = get_exception().args[0]
    assert got == 'foo'

# Generated at 2022-06-11 06:23:24.717797
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception')
    except:  # noqa
        exc = get_exception()
    assert 'An exception' == str(exc)

    try:
        raise Exception('A different exception')
    except:  # noqa
        exc = get_exception()
    assert 'A different exception' == str(exc)

# Generated at 2022-06-11 06:23:27.355185
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Testing')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'Testing'


# Generated at 2022-06-11 06:23:30.510254
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise ValueError()

    def test2():
        e = get_exception()
        return e

    try:
        test()
    except Exception:
        e = test2()
        assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:23:33.075486
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        ex = get_exception()
    assert str(ex) == 'test'



# Generated at 2022-06-11 06:23:39.969527
# Unit test for function get_exception
def test_get_exception():
    import unittest
    class GetExceptionTestCase(unittest.TestCase):  # pylint: disable=too-few-public-methods
        def runTest(self):  # pylint: disable=missing-docstring,no-self-use
            try:
                raise ValueError('test')
            except ValueError:
                e = get_exception()
                assert(str(e) == 'test')
    testcase = GetExceptionTestCase()
    testcase.runTest()

# Generated at 2022-06-11 06:26:13.298361
# Unit test for function get_exception
def test_get_exception():
    # Test that we can catch a generic exception and get it from the function
    try:
        raise ValueError("This is a ValueError")
    except Exception:
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == "This is a ValueError"

    # Test that the function doesn't break when there's no exception happening
    assert get_exception() is None

    # Test we can catch a specific exception and get it from the function
    try:
        raise ValueError("This is a ValueError")
    except (TypeError, IOError):
        exc = get_exception()
    assert isinstance(exc, ValueError)
    assert str(exc) == "This is a ValueError"

# Generated at 2022-06-11 06:26:15.295246
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError as e:
        assert e == get_exception()


# Generated at 2022-06-11 06:26:18.587710
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == "Test exception"

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:26:20.914381
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exception = get_exception()
        assert str(exception) == 'test exception'



# Generated at 2022-06-11 06:26:23.664169
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test')
    except:
        e = get_exception()
        assert(e.message == 'Test')

if __name__ == "__main__":
    import nose
    import ansible.module_utils.basic
    nose.run(argv=[__file__, '-v', '-s', 'test_get_exception'])

# Generated at 2022-06-11 06:26:25.876992
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except AssertionError:
        assert get_exception() is not None

# Generated at 2022-06-11 06:26:28.510506
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("testing")
    except Exception:
        e = get_exception()
    assert e.args == ("testing",)


# Generated at 2022-06-11 06:26:31.387470
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test.')
    except Exception:
        e = get_exception()
        if not isinstance(e, RuntimeError) or e.args != ('Test.',):
            raise



# Generated at 2022-06-11 06:26:33.668393
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('get_exception() test')
    except:
        exc = get_exception()
        assert exc.args[0] == 'get_exception() test'

# Generated at 2022-06-11 06:26:36.415710
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boom')
    except Exception:
        err = get_exception()
        assert str(err) == 'boom'
        assert repr(err) == "Exception('boom',)"