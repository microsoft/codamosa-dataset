

# Generated at 2022-06-11 06:18:06.581674
# Unit test for function get_exception
def test_get_exception():
    """
    >>> test_get_exception()
    c
    """
    try:
        raise Exception("c")
    except Exception:
        e = get_exception()
        print(e)

# Generated at 2022-06-11 06:18:08.827713
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        pass
    e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:18:19.363586
# Unit test for function get_exception
def test_get_exception():
    dummy_module = {'foo': None}

    # Test that we can catch an exception
    try:
        # This will throw an exception
        dummy_module['foo']
    except:
        exc = get_exception()
        assert type(exc) == AttributeError

    # Test that we can catch an exception and that the exception instance is
    # the same
    try:
        # This will throw an exception
        dummy_module['foo']
    except:
        exc = get_exception()
        try:
            # This will throw an exception
            dummy_module['foo']
        except:
            exc2 = get_exception()
            if exc is exc2:
                assert True
            else:
                assert False

    # Test that the exception is the exception we raised

# Generated at 2022-06-11 06:18:21.984049
# Unit test for function get_exception
def test_get_exception():
    def x():
        raise Exception('x')
    def y():
        try:
            x()
        except Exception:
            e = get_exception()
            assert e.args == ('x',)
    y()

# Generated at 2022-06-11 06:18:27.217916
# Unit test for function get_exception
def test_get_exception():
    import traceback

    try:
        raise ValueError("test exception")
    except Exception:
        e = get_exception()
        assert e.args == ("test exception", )
        tb = traceback.format_exc()
        assert "raise ValueError(\"test exception\")" in tb


# Generated at 2022-06-11 06:18:29.585365
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('example')
    except Exception:
        e = get_exception()
    assert str(e) == 'example'

# Generated at 2022-06-11 06:18:34.595981
# Unit test for function get_exception
def test_get_exception():
    # This test needs to be in its own function for py.test to correctly capture
    # the exception we raise
    try:
        raise Exception()
    except Exception:
        exc = get_exception()
        assert exc
        # This also tests that this works under py.test.  Do not remove!
        assert exc.__class__ == Exception

# Generated at 2022-06-11 06:18:35.984964
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception() is not None

# Generated at 2022-06-11 06:18:40.231117
# Unit test for function get_exception
def test_get_exception():
        class TestException(Exception):
            pass

        try:
            raise TestException("EXCEPTION")
        except TestException:
            assert get_exception() is not None
            assert get_exception().__class__ is TestException
            assert get_exception().message == "EXCEPTION"


# Generated at 2022-06-11 06:18:41.988536
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
        assert str(e) == 'foo'



# Generated at 2022-06-11 06:18:56.498688
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception

    >>> try:
    ...     1/0
    ... except:
    ...     try:
    ...         raise 1
    ...     except:
    ...         raise get_exception()
    Traceback (most recent call last):
    ...
    ZeroDivisionError: integer division or modulo by zero
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 06:19:00.448721
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("EvilUnitTestException")
    except Exception:
        e = get_exception()
    assert(isinstance(e, ValueError))
    assert(str(e) == "EvilUnitTestException")


# Generated at 2022-06-11 06:19:02.779352
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        pass
    e = get_exception()
    assert e.message == 'foo'

# Generated at 2022-06-11 06:19:07.434042
# Unit test for function get_exception
def test_get_exception():
    import traceback
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert(e.args == ('foo',))
        assert(len(traceback.extract_tb(sys.exc_info()[2])) == 1)

# Generated at 2022-06-11 06:19:08.606564
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()

    assert e.__class__ == ZeroDivisionError

# Generated at 2022-06-11 06:19:13.647226
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Some error")
    except: # pylint: disable=bare-except
        # Get the exception object
        e1 = get_exception()
        # Make sure it's the exception we expect
        assert "Some error" in str(e1)
        # Make sure we get the same exception if we do a second pass immediately
        assert e1 == get_exception()

# Generated at 2022-06-11 06:19:17.088807
# Unit test for function get_exception
def test_get_exception():
    """ansible.module_utils.basic.py: Test get_exception"""

    # Covers all Python versions
    try:
        int('notanumber')
    except Exception:
        result = get_exception()

    assert isinstance(result, ValueError)



# Generated at 2022-06-11 06:19:20.389921
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        assert get_exception() is not None
        assert type(get_exception()) is ZeroDivisionError


# Generated at 2022-06-11 06:19:23.734461
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An error occurred')
    except ValueError as e:
        assert get_exception() == e


# Generated at 2022-06-11 06:19:26.006698
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exception = get_exception()
    assert exception.message == 'foo'



# Generated at 2022-06-11 06:19:36.230644
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception as e:
        if get_exception() != e:
            raise AssertionError('get_exception() != e')

# Generated at 2022-06-11 06:19:37.885679
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0
    except Exception:
        assert True, get_exception()


# Generated at 2022-06-11 06:19:43.894744
# Unit test for function get_exception
def test_get_exception():
    def func_that_raises_error_1():
        raise Exception()

    def func_that_raises_error_2():
        try:
            func_that_raises_error_1()
        except Exception:
            raise Exception()

    try:
        func_that_raises_error_2()
    except Exception:
        exc_info = sys.exc_info()
        e = get_exception()
    assert e == exc_info[1]



# Generated at 2022-06-11 06:19:46.898748
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('hi')
    except RuntimeError:
        e = get_exception()
        assert e.args == ('hi',)

# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-11 06:19:49.988379
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise Exception("Expected exception")
    except Exception:
        exc = get_exception()
    assert isinstance(exc, Exception)
    assert "Expected exception" == str(exc)


# Generated at 2022-06-11 06:19:51.645872
# Unit test for function get_exception
def test_get_exception():
    import pytest

    with pytest.raises(ValueError):
        assert literal_eval('a')

# Generated at 2022-06-11 06:19:55.064923
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        pass
    g = get_exception()
    assert g.args == e.args
    assert str(g) == str(e)
    assert repr(g) == repr(e)



# Generated at 2022-06-11 06:19:57.556367
# Unit test for function get_exception

# Generated at 2022-06-11 06:19:59.405661
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        assert e is get_exception()



# Generated at 2022-06-11 06:20:06.008445
# Unit test for function get_exception
def test_get_exception():
    # This would be an easier test if we could just raise an exception, but
    # get_exception() doesn't work that way.  It needs to be called from an
    # exception handler.
    #
    # It would be easier to not call this a test, but then we wouldn't get any
    # coverage information on this function.
    try:
        raise ValueError("Testing get_exception")
    except ValueError:
        e = get_exception()
        assert e.args == ("Testing get_exception",), e.args

# unit test for function literal_eval

# Generated at 2022-06-11 06:20:16.901032
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Message")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "Message"


# Generated at 2022-06-11 06:20:21.023368
# Unit test for function get_exception
def test_get_exception():
    """Test that we can find and return the last exception that was thrown.
    """
    try:
        raise RuntimeError('This is an error')
    except RuntimeError:
        e = get_exception()
    assert str(e) == 'This is an error'



# Generated at 2022-06-11 06:20:23.591594
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("This is a test")
    except:
        e = get_exception()
    assert str(e) == "This is a test"


# Generated at 2022-06-11 06:20:26.363851
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception')
    except Exception:  # pylint: disable=W0703
        e = get_exception()
    assert str(e) == 'Test exception'

# Generated at 2022-06-11 06:20:30.701009
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Bad Value")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'Bad Value'


# Generated at 2022-06-11 06:20:33.577311
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('exception thrown')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'exception thrown'


# Generated at 2022-06-11 06:20:36.586029
# Unit test for function get_exception
def test_get_exception():
    def raise_test():
        raise ValueError()

    try:
        raise_test()
    except Exception as e:
        assert e is get_exception()

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-11 06:20:38.815558
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Error!")
    except ValueError:
        assert get_exception()



# Generated at 2022-06-11 06:20:41.127970
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert e.__class__ == Exception

# Generated at 2022-06-11 06:20:49.277715
# Unit test for function get_exception
def test_get_exception():
    # This test is only applicable to Python 2.x
    # Trivia mode: Python 2.4 does not have exceptions in the builtins module.
    if sys.version_info[0] < 3 and 'exceptions' not in __builtins__:
        return
    try:
        1 / 0
        raise AssertionError("Division by zero didn't raise ZeroDivisionError")
    except ZeroDivisionError:
        e = get_exception()
        if not isinstance(e, ZeroDivisionError):
            raise AssertionError("get_exception() didn't get the exception")


# Generated at 2022-06-11 06:21:08.103984
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('test',)
    else:
        assert False, 'Expected ValueError'

# Generated at 2022-06-11 06:21:11.499544
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("you're it")
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == "you're it"


# Generated at 2022-06-11 06:21:15.816371
# Unit test for function get_exception

# Generated at 2022-06-11 06:21:21.628445
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=no-self-use
    """Test function to get the exception that's occurring

    This is a function so that it can live in the same file as the function it's
    testing, but because it's a unit test it can't be part of the same test
    suite.
    """
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:21:23.377273
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Unit Test")
    except:
        exc = get_exception()
        assert isinstance(exc, RuntimeError)
        assert str(exc) == "Unit Test"

# Generated at 2022-06-11 06:21:25.626352
# Unit test for function get_exception
def test_get_exception():
    def test_function():
        try:
            raise ValueError('test exception')
        except ValueError:
            return get_exception()
    assert 'test exception' == str(test_function())

# Generated at 2022-06-11 06:21:34.369254
# Unit test for function get_exception
def test_get_exception():
    # Test 1: Make sure we catch exceptions and get the message out
    try:
        x = 1/0
    except:
        message = str(get_exception())
        if 'division by zero' not in message:
            print("Failed to catch the exception")

    # Test 2: Make sure we catch exceptions and can get the original exception from them
    try:
        x = 1/0
    except Exception as e:
        message = str(get_exception())
        if 'division by zero' not in message:
            print("Failed to catch the exception")
        if e != get_exception():
            print("Failed to get the original exception")

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:21:38.363116
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception() function.

    This function doesn't require a database, so we don't have to mock a
    database connection.
    """
    try:
        raise Exception('something bad happened')
    except Exception:
        e = get_exception()
        assert e.args == ('something bad happened',)

# Generated at 2022-06-11 06:21:42.086179
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError('some_name')
    except NameError:
        # If we can't get the exception, this will re-raise the NameError
        exception = get_exception()
    assert exception.args == ('some_name',)


# Generated at 2022-06-11 06:21:44.574727
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An exception')
    except ValueError:
        tb = get_exception()
        assert tb.args[0] == 'An exception'
    assert get_exception() is None

# Generated at 2022-06-11 06:22:02.021892
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hi')
    except Exception:
        assert get_exception() != None


# Generated at 2022-06-11 06:22:05.645888
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exc = get_exception()

    assert isinstance(exc, RuntimeError)

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 06:22:07.621707
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
    assert str(exc) == 'foo'



# Generated at 2022-06-11 06:22:17.559091
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestCase(unittest.TestCase):
        """Unit test for function get_exception"""

        def test_get_exception(self):
            """get_exception returns the correct exception"""

            try:
                raise ValueError(u'\u1234')
            except Exception:
                self.assertRaises(UnicodeEncodeError, str, get_exception())
                # e = get_exception()
                # str(e)
            except ValueError:
                self.fail('second handler should not be called')

    try:
        test_suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
        unittest.TextTestRunner(verbosity=2).run(test_suite)
    except Exception:
        pass


# Generated at 2022-06-11 06:22:20.417846
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        exc = get_exception()
        assert exc.args[0] == "Test exception"

# Generated at 2022-06-11 06:22:23.477830
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('example')
    except:
        e = get_exception()
    assert type(e) is ValueError
    assert e.args[0] == 'example'

# Generated at 2022-06-11 06:22:29.465842
# Unit test for function get_exception
def test_get_exception():
    def function(arg1, arg2):
        try:
            float(arg1) * float(arg2)
        except Exception:
            return get_exception()
    e = function(1, 2)
    assert isinstance(e, TypeError)
    assert e.__class__.__name__ == "TypeError"
    assert str(e) == "unsupported operand type(s) for *: 'int' and 'int'"

# Generated at 2022-06-11 06:22:32.971440
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        exc = get_exception()
        try:
            raise exc
        except ZeroDivisionError:
            pass


# Generated at 2022-06-11 06:22:35.011875
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        assert get_exception().args[0] == 'foo'
        raise



# Generated at 2022-06-11 06:22:36.842663
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('This is a fake exception')
    except RuntimeError as rte:
        assert rte == get_exception()

# Generated at 2022-06-11 06:22:54.727692
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("testing")
    except Exception:
        e = get_exception()
    assert "testing" == str(e)


# Generated at 2022-06-11 06:22:58.311329
# Unit test for function get_exception
def test_get_exception():
    '''Test whether get_exception catches exceptions properly.'''
    from ansible.module_utils import basic
    try:
        raise Exception('test exception')
    except:
        e = get_exception()
    basic.fail_json(msg='test exception', exception=e)

# Generated at 2022-06-11 06:23:01.206411
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise ValueError("foo")
    except Exception:
        e = get_exception()
        assert e.args[0] == "foo"



# Generated at 2022-06-11 06:23:03.280065
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except:
        e = get_exception()

    assert e.args[0] == 'test exception'

# Generated at 2022-06-11 06:23:08.588006
# Unit test for function get_exception
def test_get_exception():
    import sys

    bad_var = 42
    try:
        bad_var['hand']
    except:
        exc = get_exception()
    if sys.version_info < (3, 0):
        assert type(exc) is type(IndexError()), "Exception type is %s, not IndexError" % type(exc)
    else:
        assert type(exc) is type(IndexError), "Exception type is %s, not IndexError" % type(exc)

# Generated at 2022-06-11 06:23:10.503432
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        exc = get_exception()
        assert str(exc) == "foo"



# Generated at 2022-06-11 06:23:13.699707
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except ValueError as e:
        assert get_exception() is e

if __name__ == '__main__':
    test_get_exception()
# vi: ts=4 expandtab

# Generated at 2022-06-11 06:23:15.658408
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        assert 'foo' == get_exception().args[0]

# Generated at 2022-06-11 06:23:18.193097
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("I am an Exception")
    except Exception:
        exc_object = get_exception()
    assert exc_object.args == ("I am an Exception",)

# Generated at 2022-06-11 06:23:21.216335
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test.')
    except ValueError:
        e = get_exception()
        assert e.args == ('This is a test.',)


# Generated at 2022-06-11 06:23:56.259416
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('catch me')
    except:
        e = get_exception()
        assert str(e) == 'catch me'



# Generated at 2022-06-11 06:24:01.000824
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=invalid-name
    """test_get_exception"""
    from ansible.module_utils import compat

    class FooException(Exception):
        pass

    try:
        raise FooException('foo')
    except Exception:
        ex = compat.get_exception()

    assert isinstance(ex, FooException)
    assert ex.message == 'foo'

# Generated at 2022-06-11 06:24:04.160547
# Unit test for function get_exception
def test_get_exception():
    def thrower():
        try:
            raise Exception('test')
        except:
            exc = get_exception()
            return exc
    assert thrower().args[0] == 'test'



# Generated at 2022-06-11 06:24:10.460728
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestGetException(unittest.TestCase):
        def test_simple(self):
            try:
                raise Exception('foo')
            except Exception:
                e = get_exception()
                self.assertEqual('foo', str(e))

        def test_none(self):
            self.assertRaises(ValueError, lambda: literal_eval(None))

    unittest.main(module=__name__)

# Generated at 2022-06-11 06:24:11.347685
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError as e:
        assert e == get_exception()

# Generated at 2022-06-11 06:24:12.189926
# Unit test for function get_exception
def test_get_exception():
    """This intentionally raises an exception
    """
    raise Exception('Test')



# Generated at 2022-06-11 06:24:20.616487
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    def inner_func():
        """This is where the exception will be raised"""
        raise ValueError("Exception")
    def outer_func():
        """We're going to catch the exception"""
        try:
            inner_func()
        except Exception:
            return get_exception()
    exception = outer_func()
    assert isinstance(exception, Exception)
    assert isinstance(exception, ValueError)
    assert str(exception) == "Exception"


# Generated at 2022-06-11 06:24:23.492663
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        pass
    assert str(e) == 'integer division or modulo by zero'


# Generated at 2022-06-11 06:24:25.569327
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('intentional error')
    except RuntimeError as e:
        assert e is get_exception(), 'get_exception() should return the RuntimeError'

# Generated at 2022-06-11 06:24:27.715173
# Unit test for function get_exception
def test_get_exception():
    e = None
    try:
        raise Exception()
    except Exception:
        e = get_exception()

    assert e is not None


# Generated at 2022-06-11 06:25:01.405322
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    def raise_exception(val):
        raise RuntimeError('val')
    try:
        raise_exception()
    except:
        e = get_exception()
        assert str(e) == 'val'



# Generated at 2022-06-11 06:25:05.274978
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=bare-except
    try:
        raise ValueError("Can't touch this")
    except:  # noqa
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert str(exc) == "Can't touch this"

# Generated at 2022-06-11 06:25:07.885642
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Doh')
    except ValueError:
        exc = get_exception()
        assert 'Doh' in str(exc)

# Generated at 2022-06-11 06:25:12.029735
# Unit test for function get_exception
def test_get_exception():
    class TestError(Exception):
        pass
    try:
        raise TestError
    except:  # pylint: disable=bare-except
        assert get_exception() is not None

    # Make sure it works even if you don't catch an exception
    try:
        raise TestError
    except:  # pylint: disable=bare-except
        assert get_exception() is not None  # This can only fail if the above except fails



# Generated at 2022-06-11 06:25:15.265269
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('This is a test')
    except:
        e = get_exception()

    assert type(e) is Exception
    assert 'This is a test' in str(e)

if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-11 06:25:23.163511
# Unit test for function get_exception
def test_get_exception():
    import os
    import random
    # On python2.7 and python3.6 there's a chance that some system call will
    # return -1 and set errno to ENOENT which we'll then get as an exception
    # the first time through the loop.  So we'll instead try this 100 times
    # before we give up
    for i in range(100):
        try:
            fd = os.open('/nonexistentfile', os.O_WRONLY)
            os.close(fd)
        except OSError as e:
            e = get_exception()
            assert isinstance(e, OSError)
            break
    else:
        raise AssertionError('Failed to get OSError in test')

# Generated at 2022-06-11 06:25:27.315321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SyntaxError('Bwahaha!')
    except SyntaxError:
        e = get_exception()
        if not isinstance(e, SyntaxError) or str(e) != 'Bwahaha!':
            raise AssertionError('get_exception() did not return the exception that was raised: %r'
                                 % e)

# Generated at 2022-06-11 06:25:33.108709
# Unit test for function get_exception
def test_get_exception():
    inner = 'foo'
    outer = 'bar'

    def inner_func():
        raise NameError(inner)

    def outer_func():
        try:
            inner_func()
        except Exception:
            e = get_exception()
            raise NameError(outer)

    try:
        outer_func()
    except NameError as e:
        res = e
    assert str(res) == outer
    assert res.__cause__.__class__ == NameError
    assert str(res.__cause__) == inner

# Generated at 2022-06-11 06:25:36.435852
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Exception')
    except:
        returned_exception = get_exception()
    assert isinstance(returned_exception, ValueError)
    assert str(returned_exception) == 'Test Exception'


# Generated at 2022-06-11 06:25:44.098452
# Unit test for function get_exception
def test_get_exception():
    def foo(bar):
        # check that get_exception works
        try:
            raise Exception('baz')
        except Exception:
            e = get_exception()
            if 'baz' not in str(e):
                raise Exception('get_exception is broken')
            # return a nested exception
            try:
                raise Exception(bar)
            except Exception:
                return get_exception()
    try:
        foo('bar')
    except Exception:
        e = get_exception()
    if 'bar' not in str(e):
        raise Exception('get_exception is broken')



# Generated at 2022-06-11 06:26:27.101273
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test')
    except ValueError:
        e = get_exception()

    assert e.args == ('This is a test',)



# Generated at 2022-06-11 06:26:30.977925
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Throwing an exception is a good thing to do when you want to test exception handling")
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == "Throwing an exception is a good thing to do when you want to test exception handling"

# Generated at 2022-06-11 06:26:34.695764
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    def test_function():
        """Function we call to get the exception"""
        raise Exception('test exception')
    try:
        test_function()
    except:
        assert get_exception().args[0] == 'test exception'


# Generated at 2022-06-11 06:26:37.028235
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        exc = get_exception()
    assert exc.args == ('test',)


# Generated at 2022-06-11 06:26:40.696245
# Unit test for function get_exception
def test_get_exception():
    import unittest.mock as mock
    from ansible.module_utils.six.moves import builtins

    def test_func():
        raise ValueError()

    with mock.patch('sys.exc_info', return_value=(ValueError, ValueError(), None)):
        assert get_exception() == ValueError()

# Generated at 2022-06-11 06:26:44.449702
# Unit test for function get_exception
def test_get_exception():
    def foo():
        try:
            raise ValueError("custom exception message")
        except Exception:
            e = get_exception()
        return e

    e = foo()
    assert isinstance(e, ValueError)
    assert e.__str__() == "custom exception message"

# Generated at 2022-06-11 06:26:50.435704
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError
    except AssertionError:
        e = get_exception()
    assert isinstance(e, AssertionError)

    def raises_in_finally():
        try:
            raise AssertionError
        finally:
            raise IndexError

# Generated at 2022-06-11 06:26:52.439269
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert e is not None
        assert isins

# Generated at 2022-06-11 06:26:54.209150
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError)



# Generated at 2022-06-11 06:26:55.893787
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test")
    except Exception:
        e = get_exception()
    assert e is not None