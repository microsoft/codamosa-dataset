

# Generated at 2022-06-11 06:18:10.653919
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Failed to connect to foo")
    except:
        # Test that we have the exception
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert repr(exc) == "ValueError('Failed to connect to foo',)"
        assert str(exc) == "Failed to connect to foo"



# Generated at 2022-06-11 06:18:15.751095
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('invalid value')
    except:
        e = get_exception()
    assert isinstance(e, ValueError)

    try:
        raise TypeError('invalid type')
    except:
        e = get_exception()
    assert isinstance(e, TypeError)

# Generated at 2022-06-11 06:18:19.013812
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('canary')
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args == ('canary',)


# Unit tests for function literal_eval

# Generated at 2022-06-11 06:18:24.857780
# Unit test for function get_exception
def test_get_exception():
    # Test when no exception is set
    try:
        get_exception()
    except Exception as e:
        assert False, "get_exception() raised an exception: %s" % e

    # Test when an exception is set
    try:
        raise ValueError()
    except ValueError:
        exc = get_exception()
        assert isinstance(exc, ValueError), "get_exception() didn't return a ValueError instance: %s" % exc


# Generated at 2022-06-11 06:18:28.334567
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is a unit test exception')
    except ValueError:
        ret = get_exception()
        assert isinstance(ret, ValueError)

# Generated at 2022-06-11 06:18:31.617019
# Unit test for function get_exception
def test_get_exception():
    assert get_exception() is None
    try:
        raise Exception('test exception')
    except Exception:
        assert get_exception().args[0] == 'test exception'



# Generated at 2022-06-11 06:18:34.860645
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:18:36.715457
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo', 'Got exception %s instead of ValueError(foo)' % e

# Generated at 2022-06-11 06:18:40.133457
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('testing')
    except TypeError:
        e = get_exception()
    if not isinstance(e, TypeError):
        raise AssertionError("Expected TypeError, got %r" % e)

# Generated at 2022-06-11 06:18:42.063802
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:19:06.906964
# Unit test for function get_exception
def test_get_exception():
    try:
        try:
            raise ValueError('foo')
        except ValueError:
            e = get_exception()
            raise RuntimeError('test')
    except RuntimeError as re:
        assert e.args[0] == 'foo', 'get_exception did not return the original exception'
        assert re.args[0] == 'test', 'get_exception did not let the exception be raised'
    else:
        raise RuntimeError('get_exception did not catch the exception we raised')

# Generated at 2022-06-11 06:19:10.413424
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo', e.args[0]


# Generated at 2022-06-11 06:19:15.174383
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name
    def f():
        raise ValueError("test exception")

    try:
        f()
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

        import traceback
        try:
            __traceback_hide__ = True
            f()
        except:
            e = get_exception()
            assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:19:18.703590
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('oops')
    except:
        last_exception = get_exception()
    assert isinstance(last_exception, ValueError)
    assert last_exception.args == ('oops',)


# Generated at 2022-06-11 06:19:24.037060
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test Exception')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception), "get_exception() did not return an Exception instance"
        assert 'Test Exception' == str(exc), "get_exception() did not contain the correct Exception"



# Generated at 2022-06-11 06:19:26.290628
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except ValueError as e:
        assert get_exception() == e


# Generated at 2022-06-11 06:19:28.755713
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('something went wrong')
    except ValueError:
        e = get_exception()
        assert str(e) == 'something went wrong'



# Generated at 2022-06-11 06:19:31.111480
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test123")
    except:
        e = get_exception()
    assert str(e) == "test123"

# Generated at 2022-06-11 06:19:33.344368
# Unit test for function get_exception
def test_get_exception():

    def inner():
        raise RuntimeError('Dummy Exception')

    try:
        inner()
    except Exception:
        err = get_exception()

    assert err is not None

# Generated at 2022-06-11 06:19:35.674813
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("FAIL")
    except Exception:
        assert type(get_exception()) is Exception
        assert str(get_exception()) == "FAIL"

# Generated at 2022-06-11 06:19:54.666034
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Example exception')
    except:
        ex = get_exception()
        assert ex.args == ('Example exception',)
    assert ex.args[0] == 'Example exception'


# Generated at 2022-06-11 06:19:56.905601
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert str(e) == 'test'


# Generated at 2022-06-11 06:19:58.986856
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except ValueError:
        e = get_exception()
        assert str(e) == 'test exception'


# Generated at 2022-06-11 06:20:03.229795
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        try:
            raise TestException('inner')
        except Exception:
            e = get_exception()
            raise TestException('outer')
    except TestException as e:
        assert str(e) == 'outer'
    assert str(e) == 'inner'



# Generated at 2022-06-11 06:20:07.014131
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Invalid Thing")
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError), 'get_exception() did not return a ValueError instance'
    assert str(e) == 'Invalid Thing', 'get_exception() did not return the exception instance'



# Generated at 2022-06-11 06:20:09.466206
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        exc = get_exception()
    assert str(exc) == 'foo'



# Generated at 2022-06-11 06:20:11.922679
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert sys.exc_info()[1] == e
        assert get_exception() == e



# Generated at 2022-06-11 06:20:14.355762
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("hello")
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == "hello"


# Generated at 2022-06-11 06:20:17.141532
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
    assert type(e) is Exception
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:20:20.407685
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            raise ValueError
        except ValueError:
            return get_exception()
    e = raise_exception()
    assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:20:39.530902
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function."""
    try:
        raise ValueError('foo')
    except ValueError:
        exc = get_exception()
    assert exc.args == ('foo',)



# Generated at 2022-06-11 06:20:43.019040
# Unit test for function get_exception
def test_get_exception():
    '''Test our get_exception replacement to ensure that it works correctly'''

    try:
        raise Exception('Test exception')
    except Exception:
        e = get_exception()
        assert e.args == ('Test exception',)



# Generated at 2022-06-11 06:20:45.778388
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        e2 = get_exception()
    assert e == e2


# Generated at 2022-06-11 06:20:48.120429
# Unit test for function get_exception
def test_get_exception():
    try:
        raise SystemExit
    except:
        e = get_exception()
    assert isinstance(e, SystemExit)

# Generated at 2022-06-11 06:20:58.553636
# Unit test for function get_exception
def test_get_exception():
    # Test a base exception
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'test exception'

    # Test a base exception with a custom class
    class MyException(Exception):
        pass
    try:
        raise MyException('test exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, MyException)
        assert str(e) == 'test exception'

    # Test a derived exception
    try:
        try:
            raise Exception('Nested exception')
        except:  # pylint: disable=W0702
            e = get_exception()
            raise MyException('test exception') from e
    except Exception:
        e = get_exception()

# Generated at 2022-06-11 06:21:00.684626
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("testing")
    except Exception:
        e = get_exception()

    assert str(e) == "testing"

# Generated at 2022-06-11 06:21:02.165780
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test exception')
    except:
        assert 'This is a test exception' in str(get_exception())



# Generated at 2022-06-11 06:21:03.497475
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Exception')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:21:06.640413
# Unit test for function get_exception
def test_get_exception():
    try:
        5/0
    except Exception:
        e = get_exception()
        assert 'division by zero' in str(e)
    else:
        raise AssertionError('Should have raised an exception')


# Generated at 2022-06-11 06:21:12.477784
# Unit test for function get_exception
def test_get_exception():
    '''
    Tests to make sure that get_exception returns the correct type
    '''

    class FakeException(Exception):
        '''
        Helper exception to make it clear in the code that something is being
        checked to be of a specific type
        '''

    try:
        raise FakeException
    except:
        ex = get_exception()

    assert type(ex) == FakeException, 'get_exception does not return the correct type'

# Generated at 2022-06-11 06:21:30.564498
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)



# Generated at 2022-06-11 06:21:33.304752
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert e.args[0] == 'Test exception'

# Generated at 2022-06-11 06:21:40.148585
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Test exception')
    except TypeError as e:
        assert e is get_exception()
    try:
        raise ValueError('Test exception')
    except (TypeError, ValueError) as e:
        assert e is get_exception()
    # Test with a custom exception class
    class MyExc():
        def __init__(self, val):
            self.val = val
    try:
        raise MyExc("Test")
    except MyExc as e:
        assert e is get_exception()


# Generated at 2022-06-11 06:21:44.465113
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('some error message')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError), 'Expected ValueError, got %s' % e
    assert e.args[0] == 'some error message', 'Expected "some error message", got "%s"' % e.args[0]


# Generated at 2022-06-11 06:21:46.790425
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'Foo'



# Generated at 2022-06-11 06:21:53.349016
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class ExceptionTests(unittest.TestCase):
        def test_exception(self):
            """unit test for the get_exception function"""
            try:
                raise Exception("testing")
            except Exception:
                e = get_exception()
            self.assertIsInstance(e, Exception)
            self.assertEqual(str(e), "testing")

    return unittest.TestSuite([ExceptionTests()])

# Generated at 2022-06-11 06:21:57.510186
# Unit test for function get_exception
def test_get_exception():
    def testme():
        try:
            [][1]
            assert(False)  # Should not happen
        except:
            return get_exception()
    e = testme()
    assert(str(e).startswith('list index out of range'))

# Generated at 2022-06-11 06:21:59.255786
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:22:01.830679
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException
    except TestException as e:
        got_exc = get_exception()
    assert e is got_exc

# Generated at 2022-06-11 06:22:04.248735
# Unit test for function get_exception
def test_get_exception():
    try:
        2 + 'foo'
    except TypeError as e:
        if get_exception() is not e:
            raise Exception("get_exception didn't return the exception")

# Generated at 2022-06-11 06:22:36.704493
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('My Exception')
    except Exception:
        e = get_exception()
    assert e.__str__() == str(e) == 'My Exception'

# Unit tests for function literal_eval

# Generated at 2022-06-11 06:22:40.010994
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        raise Exception("AN EXCEPTION")

    try:
        raise_exception()
    except Exception:
        e1 = get_exception()

    try:
        raise Exception("AN EXCEPTION")
    except Exception:
        e2 = get_exception()

    assert str(e1) == "AN EXCEPTION"
    assert str(e2) == "AN EXCEPTION"

# Generated at 2022-06-11 06:22:43.005527
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception"""
    try:
        raise ValueError('This is a test exception')
    except ValueError:
        e = get_exception()
    assert str(e) == 'This is a test exception'

# Generated at 2022-06-11 06:22:47.064399
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        exc = get_exception()
        assert exc.args == ('foo',)

    try:
        raise RuntimeError('foo', 'bar')
    except Exception:
        exc = get_exception()
        assert exc.args == ('foo', 'bar')

# Generated at 2022-06-11 06:22:49.945061
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test message')
    except ValueError:
        e = get_exception()
    assert "Test message" == str(e)



# Generated at 2022-06-11 06:22:59.917350
# Unit test for function get_exception
def test_get_exception():
    """
    :func:`get_exception` works in the case of uncaught exceptions and caught exceptions.
    :func:`get_exception` works in the case of nested exceptions.
    """
    class TestException(Exception):
        def __init__(self, msg, value=None):
            self.msg = msg
            self.value = value

        def __str__(self):
            return self.msg

    try:
        raise TestException('Generic exception')
    except TestException:
        e = get_exception()
        assert isinstance(e, TestException)
        assert 'Generic exception' == e.msg

    try:
        raise TestException('Caught exception')
    except TestException as e:
        assert isinstance(e, TestException)
        assert 'Caught exception' == e.msg


# Generated at 2022-06-11 06:23:01.925916
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        assert get_exception() == sys.exc_info()[1]


# Generated at 2022-06-11 06:23:03.990302
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Unittest seems to be working')
    except RuntimeError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:23:06.477712
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except:
        exc = get_exception()
        assert str(exc) == 'foo'


# Generated at 2022-06-11 06:23:07.950444
# Unit test for function get_exception
def test_get_exception():
    try:
        int('a')
    except Exception:
        e = get_exception()
        assert(isinstance(e, ValueError))

# Generated at 2022-06-11 06:23:44.352572
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.message == 'foo'


# Generated at 2022-06-11 06:23:46.730770
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:23:51.279886
# Unit test for function get_exception
def test_get_exception():
    """
    Catch an exception and ensure that get_exception returns the same
    exception.
    """
    try:
        raise RuntimeError('test get_exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test get_exception'



# Generated at 2022-06-11 06:23:55.050247
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test exception.")
    except ValueError:
        exc = get_exception()
        assert exc.args[0] == "This is a test exception.", \
            "get_exception() did not return the expected value."


# Generated at 2022-06-11 06:23:58.392321
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    if not isinstance(e, Exception):
        raise AssertionError("Raising an exception didn't give us the exception back")


# Generated at 2022-06-11 06:24:08.858072
# Unit test for function get_exception
def test_get_exception():
    # On python 2.4, we must use exec to process an 'except' statement
    exec("""try:
        1 / 0
    except Exception:
        e = get_exception()""")
    assert e.__class__ is ZeroDivisionError
    assert 'integer' in text_type(e)

    # On python 2.5, we can use the 'as' syntax
    try:
        1 / 0
    except Exception as e:
        pass
    assert e.__class__ is ZeroDivisionError
    assert 'integer' in text_type(e)

    # On python 2.6, we can use the 'as' syntax
    try:
        1 / 0
    except Exception as e:
        pass
    assert e.__class__ is ZeroDivisionError
    assert 'integer' in text_type(e)

   

# Generated at 2022-06-11 06:24:10.005416
# Unit test for function get_exception
def test_get_exception():
    def test():
        try:
            raise ValueError('Foo')
        except Exception:
            e = get_exception()
            return e.args[0] == 'Foo'

    assert test()

# Generated at 2022-06-11 06:24:14.031094
# Unit test for function get_exception
def test_get_exception():
    # Make sure the function doesn't fail if there isn't an exception
    get_exception()
    # Make sure it properly gets an exception
    def foo():
        raise ValueError('message')
    try:
        foo()
    except ValueError:
        e = get_exception()
    assert "ValueError('message',)" == repr(e)
    assert "message" == str(e)



# Generated at 2022-06-11 06:24:18.639125
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This exception should be caught')
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert 'This exception should be caught' in str(e)

# Unit tests for function literal_eval

# Generated at 2022-06-11 06:24:20.862928
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception:
        assert get_exception().message == 'foo'



# Generated at 2022-06-11 06:25:42.560629
# Unit test for function get_exception
def test_get_exception():
    """
    Ensure that get_exception works within a try/except.

    This is a bit meta, because we have to catch an exception in the test.
    Fortunately, the types of exceptions we can raise, while they're
    different between Python 2 and Python 3, are the same within each Python
    version.
    """
    # Test a known python 2 exception
    try:
        raise TypeError('This is a type error')
    except:
        exc = get_exception()
        # If we pass, the syntax works
        assert True
        assert type(exc) == TypeError
        assert exc.args == ('This is a type error', )

    # Test a known python 3 exception
    try:
        raise RuntimeError('This is a runtime error')
    except:
        exc = get_exception()
        assert True

# Generated at 2022-06-11 06:25:49.419396
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()
    except:
        raise
    # The first frame of the traceback is this function's test() function
    # The second frame of the traceback is the get_exception() function
    # The third frame of the traceback is this block's raise ValueError
    # The fourth frame of the traceback is this block's except
    # The fifth frame of the traceback is the except block of the test() function
    print(repr(e.args))
    print(repr(e))



# Generated at 2022-06-11 06:25:53.946854
# Unit test for function get_exception
def test_get_exception():
    # This should always work!
    try:
        sys.exc_info()[1]
    except:  # pylint: disable=bare-except
        assert False, 'This test shouldn\'t fail'

    try:
        raise ValueError('This is a unit test')
    except:  # pylint: disable=bare-except
        e = get_exception()
        assert str(e) == 'This is a unit test'

# Generated at 2022-06-11 06:25:56.428734
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('Foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'Foo'
        assert isinstance(e, MyException)

# Generated at 2022-06-11 06:25:58.642022
# Unit test for function get_exception
def test_get_exception():
    try:
        raise NameError("Test")
    except NameError:
        e = get_exception()
    assert id(e) == id(sys.exc_info()[1])

# Generated at 2022-06-11 06:26:00.939635
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exception = get_exception()

    assert str(exception) == 'test exception'


# Generated at 2022-06-11 06:26:04.399718
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils.basic
    try:
        raise Exception('Test exception')
    except Exception:
        ansible.module_utils.basic._ansible_exception = get_exception()
        assert ansible.module_utils.basic._ansible_exception.args[0] == 'Test exception'

# Generated at 2022-06-11 06:26:07.401662
# Unit test for function get_exception
def test_get_exception():
    # Example from https://docs.python.org/2/tutorial/errors.html
    try:
        raise Exception('spam', 'eggs')
    except:
        exc = get_exception()
    assert str(exc) == "('spam', 'eggs')"


# Generated at 2022-06-11 06:26:09.761757
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert e.args == ('test',)


# Generated at 2022-06-11 06:26:13.465286
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class TestGetException(unittest.TestCase):
        class Error(Exception):
            pass

        def test_get_exception(self):
            try:
                raise self.Error('message')
            except:
                e = get_exception()
            self.assertEqual(str(e), 'message')