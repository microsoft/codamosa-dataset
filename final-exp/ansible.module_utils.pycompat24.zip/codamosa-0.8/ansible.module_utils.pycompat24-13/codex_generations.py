

# Generated at 2022-06-11 06:18:04.905735
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() == e


# Generated at 2022-06-11 06:18:07.328289
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('An exception is here')
    except:
        e = get_exception()
        assert e.__str__() == 'An exception is here'

# Generated at 2022-06-11 06:18:11.220273
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Hello world')
    except Exception:
        e = get_exception()
    assert type(e) == Exception
    assert e.args == ('Hello world',)


if __name__ == '__main__':
    for func in (test_get_exception,):
        func()

# Generated at 2022-06-11 06:18:15.104895
# Unit test for function get_exception
def test_get_exception():
    def i_raise():
        raise RuntimeError('powered by python')
    try:
        i_raise()
    except RuntimeError as e:
        assert(get_exception() == e)


# Generated at 2022-06-11 06:18:19.170386
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=invalid-name
    try:
        # pylint: disable=undefined-variable
        a
    except NameError as e:
        assert get_exception() is e
    else:
        raise AssertionError('Should have raised NameError in test_get_exception')


# Generated at 2022-06-11 06:18:23.285064
# Unit test for function get_exception
def test_get_exception():
    def test1():
        try:
            raise RuntimeError('test exception')
        except Exception:
            e = get_exception()
            return False
    def test2():
        try:
            raise RuntimeError('test exception')
        except Exception:
            return True
    assert test2()==True
    assert test1()==False

# Generated at 2022-06-11 06:18:25.650714
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert type(e) is Exception



# Generated at 2022-06-11 06:18:30.177361
# Unit test for function get_exception
def test_get_exception():
    '''Test we can get the exception that was raised'''
    try:
        raise ValueError("Foo went bar")
    except ValueError:
        e = get_exception()
        assert e.args[0] == "Foo went bar"

# Generated at 2022-06-11 06:18:32.523480
# Unit test for function get_exception
def test_get_exception():
    try:
        int("sixteens")
    except:
        assert isinstance(get_exception(), ValueError)


# Generated at 2022-06-11 06:18:35.794612
# Unit test for function get_exception
def test_get_exception():
    # Try a function that raises an exception
    try:
        int("")
    except:
        e = get_exception()
    assert(isinstance(e, ValueError))


# Generated at 2022-06-11 06:18:46.285253
# Unit test for function get_exception
def test_get_exception():
    '''
    Dummy function for testing get_exception
    '''
    try:
        raise Exception
    except Exception:
        assert True

# Generated at 2022-06-11 06:18:49.146505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

# Generated at 2022-06-11 06:18:54.536736
# Unit test for function get_exception
def test_get_exception():
    try:
        # This will raise a syntax error since python3 does not allow second
        # except clauses to be bare except clauses.
        # pylint: disable=bare-except
        exec('except: pass')
    except:
        e = get_exception()
        assert 'second' in e.args[0]

# Generated at 2022-06-11 06:18:57.682681
# Unit test for function get_exception
def test_get_exception():
    def raises():
        try:
            raise ValueError("Foo")
        except:
            return get_exception()

    exc = raises()
    assert isinstance(exc, ValueError)
    assert str(exc) == "Foo"
    raises()


# Generated at 2022-06-11 06:19:01.114064
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
    assert exc.args[0] == 'foo'


# Generated at 2022-06-11 06:19:05.432769
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('1')
    except Exception as e:
        ex = e

    try:
        raise RuntimeError('2')
    except Exception:
        ex2 = get_exception()

    assert ex.message == ex2.message


# Generated at 2022-06-11 06:19:10.861683
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=too-few-public-methods
    class MyException(Exception):
        pass

    try:
        raise MyException('very specific message')
    except MyException:
        e = get_exception()
        assert isinstance(e, MyException)
        assert 'very specific message' in str(e)



# Generated at 2022-06-11 06:19:14.342960
# Unit test for function get_exception
def test_get_exception():
    class Foo(Exception):
        pass
    try:
        raise Foo()
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Foo)
        assert str(exc) == '()'
    else:
        assert False, 'no exception was raised'


# Generated at 2022-06-11 06:19:16.322039
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)

# Generated at 2022-06-11 06:19:19.151248
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except:
        e = get_exception()
        assert e
        assert e.message == 'Test Exception'


# Generated at 2022-06-11 06:19:37.928014
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Nope nope nope")
    except Exception:
        ex = get_exception()
        assert ex.args[0] == "Nope nope nope"



# Generated at 2022-06-11 06:19:47.296920
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import subprocess
    class MyException(Exception):
        pass
    class GetExceptionTest(unittest.TestCase):
        def setUp(self):
            # Raise an exception inside a separate process
            try:
                subprocess.check_output(['python', '-c', 'raise MyException("test message")'], stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as e:
                self.exception = get_exception()
        def test_message(self):
            self.assertEqual(self.exception.message, "test message")
        def test_type(self):
            self.assertTrue(isinstance(self.exception, MyException))
    unittest.main(argv=['prog'])

# Generated at 2022-06-11 06:19:50.522758
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('First')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert 'First' in str(e)

    try:
        raise ValueError('Second')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert 'Second' in str(e)

# Generated at 2022-06-11 06:19:53.403319
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test Exception')
    except Exception:
        exc = get_exception()
        if 'Test Exception' in str(exc):
            return True
    return False


# Generated at 2022-06-11 06:19:56.434165
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable

    try:
        assert 0
    except AssertionError:
        e = get_exception()
    from ansible.module_utils.six import assertCountEqual
    assertCountEqual(1, 1)



# Generated at 2022-06-11 06:19:58.149917
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-11 06:20:04.110291
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
        if e.__class__.__name__ != 'ZeroDivisionError':
            raise AssertionError('Got %r instead of ZeroDivisionError' % e)
        if str(e) != 'integer division or modulo by zero':
            raise AssertionError('ZeroDivisionError has unexpected message %r' % str(e))
    else:
        raise AssertionError('ZeroDivisionError not raised')

# Generated at 2022-06-11 06:20:08.857193
# Unit test for function get_exception
def test_get_exception():
    import ansible.module_utils
    ansible.module_utils.basic = sys.modules[__name__]

    import ansible.modules.system.setup
    test_exception = Exception()
    try:
        raise test_exception
    except Exception:
        exception = ansible.modules.system.setup.get_exception()
        if exception is not test_exception:
            raise Exception('get_exception did not retrieve the correct exception')



# Generated at 2022-06-11 06:20:11.672630
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("hi")
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError

# Test for literal_eval.  Test cases from the cpython docstring.

# Generated at 2022-06-11 06:20:15.064853
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('an exception')
    except Exception:
        e = get_exception()
        assert str(e), 'an exception'

    try:
        [][2]
    except Exception:
        e = get_exception()
        assert str(e).startswith('list index out of range')

# Generated at 2022-06-11 06:20:33.531849
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
    assert ex.args[0] == 'foo'


# Generated at 2022-06-11 06:20:35.546553
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('exception 1')
    except Exception as e:
        return get_exception() == e
    return False


# Generated at 2022-06-11 06:20:38.663305
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test_get_exception')
    except ValueError as e:
        assert get_exception() == e


# Generated at 2022-06-11 06:20:39.964998
# Unit test for function get_exception

# Generated at 2022-06-11 06:20:44.252256
# Unit test for function get_exception
def test_get_exception():
    try:
        f = open('/does/not/exist')
    except Exception:
        exc = get_exception()
        assert exc.errno == 2
        assert 'No such file or directory' in str(exc)
    else:
        raise AssertionError('Expected get_exception to raise an exception')

# Generated at 2022-06-11 06:20:50.354888
# Unit test for function get_exception
def test_get_exception():
    # These call get_exception
    try: raise RuntimeError
    except: assert isinstance(get_exception(), RuntimeError)

# Generated at 2022-06-11 06:20:53.139869
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('boom')
    except Exception:
        e = get_exception()
        assert str(e) == 'boom'


# Generated at 2022-06-11 06:20:55.001113
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()


# Generated at 2022-06-11 06:20:59.095532
# Unit test for function get_exception
def test_get_exception():
    def test_function():
        try:
            raise TypeError('This is a test exception')
        except:
            return get_exception()

    test_exception = test_function()
    assert isinstance(test_exception, Exception)
    assert test_exception.args[0] == 'This is a test exception'

# Generated at 2022-06-11 06:21:00.771202
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Foo')
    except ValueError as e:
        assert get_exception() == e

# Generated at 2022-06-11 06:21:20.306294
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing get_exception')
    except ValueError:
        e = get_exception()
        assert e.args[0] == 'testing get_exception'
    else:
        raise AssertionError('This should not have happened')

# Generated at 2022-06-11 06:21:22.612697
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test Exception')
    except Exception:
        exception = get_exception()
        if str(exception) == 'Test Exception':
            return True
    return False

# Generated at 2022-06-11 06:21:24.017854
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('boo')
    except Exception as e:
        assert e is get_exception()



# Generated at 2022-06-11 06:21:27.307853
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-argument
    def foo(arg1, arg2):
        raise ValueError('bar')
    try:
        foo('x', 'y')
    except:  # Catch all exceptions
        # Get the current exception
        e = get_exception()
        assert str(e) == 'bar'

# Generated at 2022-06-11 06:21:31.322831
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('this is a test')
    except RuntimeError:
        ex = get_exception()

    assert str(ex) == 'this is a test'
    assert isinstance(ex, RuntimeError)



# Generated at 2022-06-11 06:21:34.051635
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception() works."""
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()

    assert e.args == ('foo',)

# Generated at 2022-06-11 06:21:36.872440
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        # pylint: disable=no-member
        e = get_exception()
    assert e.args == ('foo',)

# Generated at 2022-06-11 06:21:40.699730
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        ex = get_exception()
    assert str(ex) == 'integer division or modulo by zero'
    assert ex.__class__.__name__ == 'ZeroDivisionError'


# Generated at 2022-06-11 06:21:47.953756
# Unit test for function get_exception
def test_get_exception():
    def success():
        raise Exception()
    def failure():
        return 'FAIL'

    try:
        success()
    except:
        e = get_exception()
    assert isinstance(e, Exception)


# Generated at 2022-06-11 06:21:52.822327
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception), "get_exception did not return an Exception instance"
    assert 'test exception' in str(e), "get_exception returned wrong exception: %s" % e


# Generated at 2022-06-11 06:22:28.917052
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Just for testing.')
    except Exception:
        e = get_exception()
    assert str(e) == 'Just for testing.'
    assert repr(e) == "ValueError('Just for testing.',)"


# Generated at 2022-06-11 06:22:32.547505
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Unit test get_exception")
    except:
        exception = get_exception()
        if str(exception) != "Unit test get_exception":
            raise AssertionError("Wrong exception")

# Generated at 2022-06-11 06:22:41.052832
# Unit test for function get_exception
def test_get_exception():

    err_msg = "Unable to contact server, is it really running?"

    try:
        import myhost  # pylint: disable=unused-import
    except ImportError:
        pass
    else:
        raise AssertionError("Did not raise expected exception")

    try:
        import myhost  # pylint: disable=unused-import
    except ImportError:
        e = get_exception()
        assert str(e) == 'No module named myhost'

    try:
        import myhost  # pylint: disable=unused-import
    except ImportError:
        e = get_exception()
        assert str(e) == 'No module named myhost'

    try:
        raise RuntimeError(err_msg)
    except RuntimeError:
        e = get_exception()

# Generated at 2022-06-11 06:22:42.966678
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException("test")
    except:
        assert get_exception()



# Generated at 2022-06-11 06:22:46.530600
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test Get Exception")
    except:
        got_exception = get_exception()
        assert str(got_exception) == "Test Get Exception"
        assert got_exception.__class__.__name__ == "ValueError"

# Generated at 2022-06-11 06:22:52.981893
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring,too-few-public-methods,no-self-use
    class ExampleException(Exception):
        def __init__(self, message):
            self.message = message
        def __str__(self):
            return 'ExampleException: %s' % self.message
    try:
        raise ExampleException('oh noes!')
    except ExampleException:
        e = get_exception()
        assert e.message == 'oh noes!'

# Generated at 2022-06-11 06:22:56.206398
# Unit test for function get_exception
def test_get_exception():
    try:
       raise Exception('mytestexception')
    except Exception:
       e = get_exception()
    assert e.__str__() == 'mytestexception'



# Generated at 2022-06-11 06:22:58.183375
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except:
        exc = get_exception()
    assert isinstance(exc, ValueError)

# Generated at 2022-06-11 06:23:01.796615
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
    assert type(e) in (type(ZeroDivisionError()), ZeroDivisionError)
    assert str(e) in ('integer division or modulo by zero', 'division by zero')

# Generated at 2022-06-11 06:23:04.589554
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise Exception('get_exception() did not return the exception instance')

# Generated at 2022-06-11 06:24:12.320834
# Unit test for function get_exception
def test_get_exception():
    def func():
        try:
            raise Exception('faked exception')
        except Exception:
            e = get_exception()
            return e

    assert 'faked exception' in str(func())

# Generated at 2022-06-11 06:24:17.834706
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable,expression-not-assigned,unused-argument

    def test_function():
        raise Exception("testing get_exception()")

    # Verify that get_exception works when called in the responsible manner
    try:
        test_function()
    except Exception:
        e = get_exception()
        assert str(e) == "testing get_exception()"
        assert repr(e) == "Exception('testing get_exception()',)"
        assert type(e) == type(Exception("testing get_exception()"))

    # Verify that get_exception() works when called as a bare raise
    try:
        raise get_exception()
    except Exception:
        e = get_exception()
        assert str(e) == "testing get_exception()"

# Generated at 2022-06-11 06:24:22.646109
# Unit test for function get_exception
def test_get_exception():
    def a():
        return b()

    def b():
        return c()

    def c():
        1 / 0  # pylint: disable=pointless-statement
    try:
        a()
    except:  # pylint: disable=bare-except
        e = get_exception()
    assert type(e) is ZeroDivisionError

# Generated at 2022-06-11 06:24:25.169890
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert 'foo' in str(e)
        assert e is not None


# Unit tests for literal_eval(s)

# Generated at 2022-06-11 06:24:29.395852
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        assert get_exception() == e
    try:
        raise RuntimeError('test')
    except RuntimeError:
        assert get_exception() is not None
        e = get_exception()
        assert isinstance(e, RuntimeError)
        assert str(e) == 'test'

# Generated at 2022-06-11 06:24:32.066843
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert e.args == ('test exception',)


# Generated at 2022-06-11 06:24:34.173616
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Testing exception handling")
    except RuntimeError as e:
        assert e == get_exception()

# Generated at 2022-06-11 06:24:36.447713
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError as e:
        e2 = get_exception()
        assert e is e2


# Generated at 2022-06-11 06:24:38.576430
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except Exception as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:24:44.352423
# Unit test for function get_exception
def test_get_exception():

    # Test that get_exception on no exception does not raise an
    # exception
    try:
        get_exception()
    except Exception as e:
        print('get_exception() raised an exception: {}'.format(e))
        raise

    # Test that get_exception returns the exception
    try:
        raise Exception('Test exception')
    except Exception:
        assert get_exception().args[0] == 'Test exception'

# Generated at 2022-06-11 06:27:27.741263
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()

    assert e.args == ('foo',)


# Generated at 2022-06-11 06:27:33.732290
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(42)
    except Exception:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == (42,)
    try:
        raise ValueError(42)
    except Exception as e:
        e2 = e
    assert isinstance(e2, ValueError)
    assert e2.args == (42,)


# Unit tests for function literal_eval

# Generated at 2022-06-11 06:27:38.540177
# Unit test for function get_exception
def test_get_exception():
    import pytest
    from ansible.module_utils._text import to_bytes

    def f():
        return to_bytes('foo') + 42

    try:
        f()
    except TypeError:
        e = get_exception()
    assert e.args == (to_bytes("unsupported operand type(s) for +: 'bytes' and 'int'"),)
    assert isinstance(e, TypeError)


# Generated at 2022-06-11 06:27:41.671776
# Unit test for function get_exception
def test_get_exception():
    """Test that when an exception is raised, get_exception gets the exception."""
    try:
        raise ValueError("foo")
    except ValueError:
        e = get_exception()
        assert e.args == ("foo",), e.args


# Generated at 2022-06-11 06:27:51.098301
# Unit test for function get_exception
def test_get_exception():
    def throw(exception):
        try:
            raise exception
        except:
            e = get_exception()
            if not isinstance(e, exception):
                raise AssertionError('"%r" is not a "%r", it is a "%r"' % (e, exception, type(e)))

    class TestException(Exception):
        pass

    try:
        foo
    except:
        e = get_exception()
        if not isinstance(e, NameError):
            raise AssertionError('NameError not caught')
    throw(TestException())

    t1 = (1,2)
    t2 = literal_eval(repr(t1))