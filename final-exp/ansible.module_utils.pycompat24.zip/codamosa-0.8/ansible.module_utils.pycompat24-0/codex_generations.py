

# Generated at 2022-06-11 06:18:04.368609
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test')
    except Exception:
        err = get_exception()
    assert 'test' in str(err)

# Generated at 2022-06-11 06:18:06.954245
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        try:
            raise get_exception()
        except Exception as e:
            return e.args[0] == 'foo'
    return False

# Generated at 2022-06-11 06:18:09.166852
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError(42)
    except RuntimeError as exc:
        assert get_exception() is exc


# Generated at 2022-06-11 06:18:13.327095
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException("testing...")
    except Exception:
        exception = get_exception()
        assert 'testing' in str(exception)
        assert isinstance(exception, MyException) is True

# Generated at 2022-06-11 06:18:19.249776
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Some random ValueError")
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError), 'get_exception did not return ValueError'
        assert e.message == "Some random ValueError", 'get_exception did not return the correct exception message'
        assert repr(e) == repr(ValueError("Some random ValueError")), 'get_exception did not return the correct exception object'

# Generated at 2022-06-11 06:18:21.964209
# Unit test for function get_exception
def test_get_exception():
    def foo():
        return 1 // 0
    try:
        foo()
    except ZeroDivisionError:
        assert isinstance(get_exception(), ZeroDivisionError)


# Generated at 2022-06-11 06:18:25.153420
# Unit test for function get_exception
def test_get_exception():
    """Unit test for get_exception"""
    try:
        raise AssertionError('test error')
    except AssertionError:
        err = get_exception()
        assert 'test error' in str(err)

# Generated at 2022-06-11 06:18:30.867874
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> class CustomException(Exception):
    ...     pass
    ...
    >>> def do_raise():
    ...     raise CustomException()
    ...
    >>> try:
    ...     do_raise()
    ... except:
    ...     assert isinstance(get_exception(), CustomException)
    ...
    '''



# Generated at 2022-06-11 06:18:33.230201
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'foo'

# Generated at 2022-06-11 06:18:36.055354
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test get_exception')
    except Exception:
        e = get_exception()
    assert e.args == ('Test get_exception',)

# Generated at 2022-06-11 06:18:46.128197
# Unit test for function get_exception
def test_get_exception():
    try:
        x
    except Exception:
        assert 'x' in str(get_exception())



# Generated at 2022-06-11 06:18:53.850055
# Unit test for function get_exception
def test_get_exception():
    def test_f():
        raise Exception('bob')

    # Assert that get_exception returns the right exception type
    try:
        test_f()
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)

    # Assert that get_exception returns the right exception value
    try:
        test_f()
    except Exception:
        e = get_exception()
        assert e.args == ('bob',)

# Generated at 2022-06-11 06:18:56.072330
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foobar')
    except Exception:
        e = get_exception()
        assert 'foobar' in str(e)

# Generated at 2022-06-11 06:18:59.823612
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('test message')
    except:
        exc = get_exception()
    assert exc.__class__ == MyException
    assert str(exc) == 'test message'

# Generated at 2022-06-11 06:19:04.057636
# Unit test for function get_exception
def test_get_exception(): # pylint: disable=no-self-use, unused-argument
    try:
        raise Exception("test_get_exception")
    except Exception:
        e = get_exception()
        assert str(e) == "test_get_exception"


# Generated at 2022-06-11 06:19:06.647744
# Unit test for function get_exception
def test_get_exception():
    "Running some tests to make sure you get an exception"
    try:
        a = 1 / 0  # pylint: disable=unused-variable
    except:
        exception = get_exception()
    assert exception.__str__() == "integer division or modulo by zero"

if __name__ == '__main__':
    # Run the unit tests
    test_get_exception()

# Generated at 2022-06-11 06:19:09.696628
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-11 06:19:12.718425
# Unit test for function get_exception
def test_get_exception():
    try:
        print(1/0)
    except:
        exc = get_exception()
        assert exc.args[0] == 'integer division or modulo by zero'



# Generated at 2022-06-11 06:19:16.054999
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Unit test.')
    except ValueError as e:
        if get_exception() != e:
            raise Exception('Expected e to equal get_exception()')
    else:
        raise Exception('Expected the exception to happen.  It did not')

# Generated at 2022-06-11 06:19:19.730205
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise RuntimeError("hello")

    try:
        test()
    except:
        exc = get_exception()

    assert exc is not None
    assert exc.__str__ == "hello"


# Generated at 2022-06-11 06:19:38.277372
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except Exception:
        e = get_exception()
    assert e.args[0] == "foo"


# Generated at 2022-06-11 06:19:47.960076
# Unit test for function get_exception
def test_get_exception():
    class BaseException(Exception):
        pass

    class DerivedException(BaseException):
        pass

    def raiser1():
        raise DerivedException('foo')

    def raiser2():
        try:
            raise DerivedException('foo')
        except BaseException:
            return get_exception()

    def reraiser():
        try:
            raiser1()
        except BaseException:
            raise

    try:
        raise DerivedException('foo')
    except BaseException:
        e1 = get_exception()

    try:
        raiser1()
    except BaseException:
        e2 = get_exception()

    try:
        raise DerivedException('foo')
    except DerivedException:
        e3 = get_exception()

    e4 = reraiser()

    e5 = ra

# Generated at 2022-06-11 06:19:51.645440
# Unit test for function get_exception
def test_get_exception():
    # Python 2.6 doesn't have try except else support
    try:
        raise ValueError('foo')
    except Exception:
        e = get_exception()
        if not isinstance(e, ValueError):
            raise Exception(
                "get_exception() didn't store a ValueError")

# Generated at 2022-06-11 06:19:57.895487
# Unit test for function get_exception
def test_get_exception():
    if get_exception() is not None:
        raise Exception('get_exception should be return None when no exception')

    # Python 2.4

# Generated at 2022-06-11 06:20:01.309402
# Unit test for function get_exception
def test_get_exception():
    _ = get_exception

# Generated at 2022-06-11 06:20:03.365198
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except Exception:
        e = get_exception()
    assert e is not None


# Generated at 2022-06-11 06:20:05.273119
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()

    assert e.__class__ is ValueError

# Generated at 2022-06-11 06:20:07.132036
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('error message')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'error message'


# Generated at 2022-06-11 06:20:09.886635
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test Exception")
    except ValueError:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == "Test Exception"

# Generated at 2022-06-11 06:20:11.991206
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        assert get_exception() == e
        assert sys.exc_info()[1] == e

# Generated at 2022-06-11 06:20:46.054381
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError as e:
        assert e is get_exception()



# Generated at 2022-06-11 06:20:48.387246
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('bad')
    except:
        assert get_exception().args[0] == 'bad'



# Generated at 2022-06-11 06:20:51.578391
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except Exception:
        e = get_exception()

    assert(isinstance(e, RuntimeError))
    assert(e.args == ('foo',))



# Generated at 2022-06-11 06:20:55.088123
# Unit test for function get_exception

# Generated at 2022-06-11 06:20:57.962297
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Zoot")
    except Exception:
        e = get_exception()

    assert isinstance(e, Exception)
    assert str(e) == "Zoot"

# Generated at 2022-06-11 06:21:02.607275
# Unit test for function get_exception
def test_get_exception():
    # Test that get_exception does the same thing as extracting the exception
    # from the sys.exc_info() tuple
    try:
        raise ValueError('TEST-EXCEPTION')
    except ValueError:
        exc_info = sys.exc_info()
        check = get_exception()
    assert exc_info[1] is check



# Generated at 2022-06-11 06:21:04.437350
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('An exception')
    except RuntimeError as e:
        ex = get_exception()
        assert ex is e

# Generated at 2022-06-11 06:21:07.119198
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("This is a test")
    except Exception:
        exc = get_exception()
        assert isinstance(exc, ValueError)
        assert "This is a test" in str(exc)

# Generated at 2022-06-11 06:21:10.627160
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    try:
        raise MyException('foo')
    except Exception:
        e = get_exception()
        assert isinstance(e, MyException)
        assert str(e) == 'foo'

# Generated at 2022-06-11 06:21:20.555475
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("A test exception to confirm that it's returned")
    except Exception:
        e = get_exception()
        assert e
        if isinstance(e, Exception):
            assert e.args[0] == "A test exception to confirm that it's returned"
        else:
            assert False, 'get_exception() did not return an Exception'

    # In a function
    def fn():
        try:
            raise ValueError("A test exception to confirm that it's returned")
        except Exception:
            e = get_exception()
            assert e
            if isinstance(e, Exception):
                assert e.args[0] == "A test exception to confirm that it's returned"
            else:
                assert False, 'get_exception() did not return an Exception'
    fn()

# Generated at 2022-06-11 06:21:54.328755
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert str(e) == 'test exception'


# Generated at 2022-06-11 06:22:00.987722
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass
    def function():
        try:
            raise MyException('This is my exception')
        except Exception:
            e = get_exception()
        return e
    e = function()
    assert isinstance(e, MyException), (
            "get_exception() returned %r instead of instance of MyException" % e)
    assert str(e) == 'This is my exception', (
            "get_exception() returned exception %r which doesn't match expected"
            % e)

# Generated at 2022-06-11 06:22:03.158810
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError
    except AssertionError:
        assert get_exception() is not None


# Generated at 2022-06-11 06:22:05.292364
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)

# Generated at 2022-06-11 06:22:07.947731
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test_get_exception')
    except RuntimeError:
        e = get_exception()
        assert str(e) == 'test_get_exception'


# Generated at 2022-06-11 06:22:14.136631
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('foo')
    except:
        exc = get_exception()

    if not isinstance(exc, AssertionError):
        raise AssertionError('Expected AssertionError from get_exception, got %s' % exc.__class__.__name__)

    if str(exc) != 'foo':
        raise AssertionError('Expected "foo" from get_exception, got %s' % str(exc))



# Generated at 2022-06-11 06:22:18.712873
# Unit test for function get_exception
def test_get_exception():

    class TestException(Exception):
        pass

    try:
        raise TestException("Testing get_exception")
    except Exception:
        ex = get_exception()
    assert isinstance(ex, TestException)
    assert str(ex) == 'Testing get_exception'



# Generated at 2022-06-11 06:22:23.788730
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("foo")
    except RuntimeError as e:
        assert get_exception() == e
        assert get_exception().args == e.args

    try:
        raise RuntimeError("foo")
    except RuntimeError:
        e = get_exception()
        assert get_exception() == e
        assert get_exception().args == e.args

# Generated at 2022-06-11 06:22:26.862857
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception('hello')
    try:
        foo()
    except Exception:
        e = get_exception()
    assert isinstance(e, Exception)
    assert 'hello' in str(e)

# Generated at 2022-06-11 06:22:29.265714
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError:
        exc = get_exception()
        assert str(exc) == 'foo'

# Generated at 2022-06-11 06:23:04.373284
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException('This is a test exception')
    except TestException:
        exc = get_exception()
        assert(isinstance(exc, TestException))
        assert(exc.args == ('This is a test exception',))

# Generated at 2022-06-11 06:23:07.777068
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        raise RuntimeError("Test error")
    except RuntimeError as e:
        exc_info = get_exception()
        assert exc_info == e
        assert exc_info.args[0] == 'Test error'



# Generated at 2022-06-11 06:23:10.820504
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError("blah blah")
    except:
        e = get_exception()
    assert isinstance(e, TypeError)
    assert "TypeError" in str(e)
    assert "blah blah" in str(e)



# Generated at 2022-06-11 06:23:12.950405
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception")
    except Exception:
        exc = get_exception()
    assert str(exc) == "Test exception"

# Generated at 2022-06-11 06:23:16.020523
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An exception message')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert unicode(e) == u'An exception message'



# Generated at 2022-06-11 06:23:20.464836
# Unit test for function get_exception
def test_get_exception():
    # In case this is called from inside test_get_exception,
    # we need to do a little extra work.
    try:
        raise ValueError()
    except ValueError:
        assert(get_exception() is sys.exc_info()[1])

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:23:29.394345
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('This is a test message')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'This is a test message'


b_STATUS_OK = b'{"changed": true, "failed": false}'
b_STATUS_ERR = (b'{"changed": true, "failed": false}\n{'
          b' "changed": false, "failed": true, "module_stderr": "", "module_stdout": "", "msg": "non-zero return code"}')

u_STATUS_OK = u'{"changed": true, "failed": false}'

# Generated at 2022-06-11 06:23:36.057460
# Unit test for function get_exception
def test_get_exception():
    '''Test get_exception() for exceptions'''
    try:
        raise ValueError('Error value')
    except:
        exc = get_exception()
    assert(str(exc) == 'Error value')

    try:
        raise Exception
    except:
        exc = get_exception()
    assert(str(exc) == 'Exception()')

    try:
        raise Exception
    except:
        exc = get_exception()
    assert(str(exc) == 'Exception()')


# Generated at 2022-06-11 06:23:40.912077
# Unit test for function get_exception
def test_get_exception():
    try:
        # UnknownAttributeError defined here so that the module loading code doesn't
        # depend on jinja2.  The jinja2 code is just testing that the function works
        raise UnknownAttributeError('foo')
    except UnknownAttributeError as e:
        assert get_exception() is e
        return
    assert False  # we should never get here


# Generated at 2022-06-11 06:23:42.617169
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        print(e)

# Generated at 2022-06-11 06:24:52.674060
# Unit test for function get_exception
def test_get_exception():
    # This function is used in the form
    #
    # except Exception, e:
    #     e = get_exception()
    #
    # When exceptions are not thrown, we can verify that this works by seeing if
    # get_exception throws an exception or not.
    #
    # Processing:
    #   First time, e is in the local namespace.  get_exception has no idea
    #   what the values are.  So it throws a NameError.  We catch this and move
    #   on.
    #   Second time, there is no e defined.  This is what we want and we should
    #   get None back.

    # Ensure that calling it the first time when there's no exception in flight
    # still throws.
    try:
        get_exception()
    except NameError:
        pass
   

# Generated at 2022-06-11 06:24:56.837648
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('An error message')
    except Exception:
        err = get_exception()
        if str(err) != 'An error message':
            raise AssertionError('The error string is wrong')
        if type(err) is not RuntimeError:
            raise AssertionError('The error type is wrong')

# Generated at 2022-06-11 06:24:59.166394
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('testing')
    except Exception:
        e = get_exception()
        assert type(e) == ValueError
        assert str(e) == 'testing'

# Generated at 2022-06-11 06:25:01.254618
# Unit test for function get_exception
def test_get_exception():
    """Unit test for function get_exception

    This function is tested implicitly in modules/system/stat.py
    """
    pass



# Generated at 2022-06-11 06:25:06.401344
# Unit test for function get_exception
def test_get_exception():
    import pytest

    def foo():
        try:
            raise Exception('foo')
        except Exception:
            return get_exception()

    # Make sure that get_exception returns the current exception and
    # also can be wrapped in a lambda and still do the right thing.
    # Also make sure that we get a string as the output
    assert 'foo' in str(foo())


# Generated at 2022-06-11 06:25:08.796443
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("exception")
    except ValueError:
        exc = get_exception()
    assert exc.args == ("exception",)



# Generated at 2022-06-11 06:25:10.744391
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, Exception)
        assert str(exc) == 'foo'

# Generated at 2022-06-11 06:25:12.937377
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("foo")
    except:
        (exc_type, exc_value, exc_traceback) = sys.exc_info()
        assert exc_value == get_exception()



# Generated at 2022-06-11 06:25:15.071077
# Unit test for function get_exception
def test_get_exception():
    try:
        int('q')
    except Exception:
        exc = get_exception()
        assert str(exc) == "invalid literal for int() with base 10: 'q'"

# Generated at 2022-06-11 06:25:19.971776
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=redefined-outer-name,too-few-public-methods
    class TestingException(Exception):
        pass