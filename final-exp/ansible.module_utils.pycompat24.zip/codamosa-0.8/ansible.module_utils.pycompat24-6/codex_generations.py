

# Generated at 2022-06-11 06:18:10.653861
# Unit test for function get_exception
def test_get_exception():
    # Test that we can get an exception
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()

    assert e.args[0] == 'test'
    assert isinstance(e, RuntimeError)

    # Test that we can reraise the exception
    try:
        raise e
    except RuntimeError:
        e2 = get_exception()

    assert e2.args[0] == 'test'
    assert isinstance(e2, RuntimeError)



# Generated at 2022-06-11 06:18:14.515218
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('bad')
    except Exception:
        exc = get_exception()
        if str(exc) != 'bad':
            raise AssertionError('exception not captured correctly')


# Generated at 2022-06-11 06:18:17.220207
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        assert str(e) == 'foo'


# Generated at 2022-06-11 06:18:19.502853
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except:
        exc = get_exception()
        assert repr(exc) == "Exception('foo',)"

# Generated at 2022-06-11 06:18:28.809933
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("test")
    except Exception:
        e = get_exception()
        assert e.args[0] == "test"

    try:
        raise RuntimeError(42)
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == 42

    try:
        try:
            raise Exception("test")
        except Exception:
            raise
    except Exception:
        e = get_exception()
        assert e.args[0] == "test"


# Generated at 2022-06-11 06:18:32.960687
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert e.args == ('foo',)
        assert repr(e) == 'Exception(\'foo\',)'
        assert str(e) == 'foo'



# Generated at 2022-06-11 06:18:35.791004
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception.
    """

    try:
        raise RuntimeError()
    except Exception:
        e = get_exception()
    assert type(e) is RuntimeError

# Generated at 2022-06-11 06:18:38.880044
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Testing get_exception()')
    except Exception:
        e = get_exception()
        assert str(e) == 'Testing get_exception()'



# Generated at 2022-06-11 06:18:42.562608
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError
    except TypeError:
        e = get_exception()

    if not isinstance(e, TypeError):
        raise AssertionError("get_exception() didn't return the exception that was raised")

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:18:53.744504
# Unit test for function get_exception
def test_get_exception():
    def test_exception(exception, exc_type):
        try:
            raise exception('error message')
        except exc_type:
            e = get_exception()

        assert (isinstance(e, exc_type))
        assert (e.args == ('error message', ))

    for exception in ValueError, RuntimeError:
        for exc_type in Exception, BaseException:
            test_exception(exception, exc_type)

if __name__ == '__main__':
    # Execute the test suite
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    unittest.main()

# Generated at 2022-06-11 06:19:12.404893
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test")
    except RuntimeError:
        assert RuntimeError("Test") == get_exception()

# Generated at 2022-06-11 06:19:21.707843
# Unit test for function get_exception
def test_get_exception():
    def _inner_exception():
        try:
            raise ValueError()
        except:
            inner_exc = get_exception()
            # Make sure that it's the same exception we raised
            assert isinstance(inner_exc, ValueError)
            assert inner_exc.__class__.__name__ == 'ValueError'
            return inner_exc

    try:
        raise AttributeError()
    except:
        outer_exc = get_exception()
        assert isinstance(outer_exc, AttributeError)
        assert outer_exc.__class__.__name__ == 'AttributeError'

    assert outer_exc is not _inner_exception()



# Generated at 2022-06-11 06:19:25.200348
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise Exception("test_get_exception")

    try:
        foo()
    except:
        e = get_exception()
    assert repr(e) == repr(Exception('test_get_exception'))

# Generated at 2022-06-11 06:19:27.440432
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:19:30.592374
# Unit test for function get_exception
def test_get_exception():
    try:
        0/0
    except Exception:
        exc = get_exception()
        if exc is None:
            assert False, "get_exception returned None instead of the exception"
    else:
        assert False, "get_exception failed with no exception"


# Generated at 2022-06-11 06:19:35.933419
# Unit test for function get_exception
def test_get_exception():
    def test():
        raise Exception("foo")

    def test_decorator(func):
        def inner(*args, **kwargs):
            try:
                func(*args, **kwargs)
            except:
                return get_exception()
            else:
                return None
        return inner
    decorated_test = test_decorator(test)
    e = decorated_test()
    assert isinstance(e, Exception)
    assert str(e) == 'foo'

# Generated at 2022-06-11 06:19:45.507472
# Unit test for function get_exception

# Generated at 2022-06-11 06:19:50.505035
# Unit test for function get_exception
def test_get_exception():
    # Just make sure this runs without causing a traceback
    try:
        raise Exception('foo')
    except:
        e = get_exception()
        if not isinstance(e, Exception):
            raise AssertionError('get_exception did not return an exception.')
        if str(e) != 'foo':
            raise AssertionError('get_exception did not return the correct exception.')



# Generated at 2022-06-11 06:19:55.296308
# Unit test for function get_exception
def test_get_exception():
    import mock
    e = get_exception()
    assert not e
    with mock.patch('ansible.module_utils.six.reraise') as m:
        try:
            a = 1 / 0
        except ZeroDivisionError:
            e = get_exception()
            assert isinstance(e, ZeroDivisionError)
            m.called_once_with(e)


# Generated at 2022-06-11 06:20:01.239172
# Unit test for function get_exception
def test_get_exception():
    import unittest
    import traceback
    class TestCase(unittest.TestCase):
        def test_try_except(self):
            try:
                raise ValueError('foo')
            except Exception:
                e = get_exception()
            self.assertEqual(str(e), 'foo')

        def test_try_except_finally(self):
            try:
                raise ValueError('foo')
            except Exception:
                e = get_exception()
            finally:
                e2 = get_exception()
                exc_type, exc_value, exc_traceback = sys.exc_info()
            self.assertEqual(str(e), 'foo')
            self.assertEqual(e, e2)
            self.assertEqual(e, exc_value)
            self.assertEqual

# Generated at 2022-06-11 06:20:19.467569
# Unit test for function get_exception
def test_get_exception():
    try:
        int('not an integer')
    except:
        e = get_exception()
        assert isinstance(e, ValueError)

# Generated at 2022-06-11 06:20:22.300313
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test exception')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'Test exception'

# Generated at 2022-06-11 06:20:24.875932
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-11 06:20:27.355438
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError(u'This is a test')
    except Exception:
        e = get_exception()
        assert u'This is a test' in str(e)

# Generated at 2022-06-11 06:20:33.982390
# Unit test for function get_exception
def test_get_exception():
    """Test the function get_exception"""
    had_exception = False
    try:
        raise ValueError('here is an exception')
    except ValueError:
        had_exception = True
        exception_raised = get_exception()
        assert isinstance(exception_raised, ValueError)
        assert str(exception_raised) == 'here is an exception'
    assert had_exception



# Generated at 2022-06-11 06:20:38.563398
# Unit test for function get_exception
def test_get_exception():
    def try_except():
        # pylint: disable=bare-except
        try:
            raise RuntimeError('dummy exception')
        except:
            return get_exception()
    dummy_exc = try_except()
    assert isinstance(dummy_exc, RuntimeError)
    assert str(dummy_exc) == 'dummy exception'
    return True

# Generated at 2022-06-11 06:20:43.292420
# Unit test for function get_exception
def test_get_exception():  # pylint: disable=missing-docstring
    import sys

    def test_it(func):
        try:
            func()
        except IndexError:
            e = get_exception()
            assert isinstance(e, IndexError)
            assert sys.exc_info()[1] is e

    test_it(lambda: [][0])

# Generated at 2022-06-11 06:20:49.818715
# Unit test for function get_exception
def test_get_exception():
    try:
        raise AssertionError('assertion error')
    except AssertionError as e:
        # Python 3.x
        assert e is get_exception()
    try:
        raise AssertionError('assertion error')
    except AssertionError:
        # Python 2.x
        e = get_exception()
        assert isinstance(e, AssertionError)
        assert 'assertion error' in str(e)



# Generated at 2022-06-11 06:20:54.283897
# Unit test for function get_exception
def test_get_exception():
    try:
        x = 1 / 0  # pylint: disable=pointless-statement
    except Exception:
        e = get_exception()
        assert str(e) == 'integer division or modulo by zero'
    else:
        raise RuntimeError('No exception raised')



# Generated at 2022-06-11 06:20:58.731232
# Unit test for function get_exception
def test_get_exception():
    def something_bad():
        raise ValueError('foobar')
    try:
        something_bad()
    except Exception:
        # The following three lines are identical in Python 2.4 through 3.x
        e = get_exception()
        assert e.args == ('foobar',)
        assert str(e) == 'foobar'


# Generated at 2022-06-11 06:21:33.790740
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('test exception')
    except Exception:
        e = get_exception()
        assert e.__class__ == ValueError
        assert e.args == ('test exception',)



# Generated at 2022-06-11 06:21:36.583491
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        e = get_exception()

    assert isinstance(e, ValueError)
    assert e.message == 'foo'



# Generated at 2022-06-11 06:21:39.299205
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TestException('This is a test')
    except TestException:
        e = get_exception()
    assert e.args == ('This is a test',)

# Generated at 2022-06-11 06:21:43.466499
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test runtime error')
    except:
        exc = get_exception()
        if ((isinstance(exc, Exception) and str(exc) == 'test runtime error')):
            exit(0)
        else:
            exit(1)

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:21:45.912658
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('Test exception')
    except Exception:
        e = get_exception()
    assert e.args == ('Test exception',)

# Compat shim
python_2_unicode_compatible = str

# Generated at 2022-06-11 06:21:48.304212
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        e = get_exception()
    assert isinstance(e, Exception)

# Generated at 2022-06-11 06:21:56.870508
# Unit test for function get_exception

# Generated at 2022-06-11 06:22:00.175298
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1 / 0
    except ZeroDivisionError:
        exception = get_exception()
    try:
        assert a
    except AssertionError:
        assert exception is not None


# Generated at 2022-06-11 06:22:03.059567
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        ex = get_exception()

    assert ex.args == ('test',)
    assert str(ex) == 'test'


# Generated at 2022-06-11 06:22:11.029042
# Unit test for function get_exception

# Generated at 2022-06-11 06:23:16.469029
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        1/0
    except Exception:
        the_exception = get_exception()
    assert isinstance(the_exception, ZeroDivisionError)

# Generated at 2022-06-11 06:23:22.870764
# Unit test for function get_exception
def test_get_exception():
    '''
    This function is used to test the get_exception function

    This returns True if the function works, False if it doesn't.
    '''

    def function_that_raises_exception():
        '''
        This function is used for testing get_exception.
        '''
        raise NameError("get_exception test")

    try:
        function_that_raises_exception()
    except Exception:
        return get_exception() is sys.exc_info()[1]

# Generated at 2022-06-11 06:23:24.695524
# Unit test for function get_exception
def test_get_exception():
    def pr():
        try:
            raise Exception('boom')
        except Exception:
            e = get_exception()
        return e
    assert 'Exception: boom' in repr(pr())
    assert 'Exception: boom' in str(pr())

# Generated at 2022-06-11 06:23:25.284380
# Unit test for function get_exception
def test_get_exception():
    pass

# Generated at 2022-06-11 06:23:28.090186
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Hello, World!")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("Hello, World!",)

# Generated at 2022-06-11 06:23:30.873826
# Unit test for function get_exception
def test_get_exception():
    """Test the get_exception function"""
    try:
        raise RuntimeError('This is a test')
    except RuntimeError as e:
        error = e
    assert error == get_exception()

# Generated at 2022-06-11 06:23:37.708391
# Unit test for function get_exception
def test_get_exception():
    class MockException():
        pass


# Generated at 2022-06-11 06:23:40.011143
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('oof')
    except RuntimeError as e:
        assert e == get_exception()



# Generated at 2022-06-11 06:23:42.355132
# Unit test for function get_exception
def test_get_exception():
    """Test function get_exception()"""

# Generated at 2022-06-11 06:23:44.725301
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('this is the exception')
    except ValueError as e:
        e1 = e
        e2 = get_exception()
        assert e1 is e2

# Generated at 2022-06-11 06:26:15.658875
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert str(e) == 'foo'



# Generated at 2022-06-11 06:26:17.483499
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:26:19.720293
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        assert get_exception().args[0] == 'test exception'


# Generated at 2022-06-11 06:26:22.323049
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("This is a test")
    except Exception:
        e = get_exception()
        assert e.message == "This is a test"

if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:26:25.260198
# Unit test for function get_exception
def test_get_exception():
    def sample_function():
        try:
            int(text='Not an integer')
        except:
            return get_exception()

    result = sample_function()
    assert('ValueError' in result.__str__())



# Generated at 2022-06-11 06:26:28.854539
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except: # Note: Python 2.4 does not support "except ValueError as e"
        e = get_exception()

    assert isinstance(e, ValueError)
    assert 'foo' in str(e)


# Generated at 2022-06-11 06:26:31.130302
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except Exception:
        e = get_exception()
    assert(isinstance(e, ZeroDivisionError))


# Generated at 2022-06-11 06:26:33.756683
# Unit test for function get_exception
def test_get_exception():
    """Test get_exception"""
    try:
        raise AttributeError('test_get_exception')
    except:
        assert get_exception() == AttributeError('test_get_exception')

# Generated at 2022-06-11 06:26:39.546640
# Unit test for function get_exception
def test_get_exception():
    # try:
    #     'test'.test()
    # except Exception as e:
    #     got_exception = e
    # try:
    #     'test'.test()
    # except Exception, e:
    #     got_exception_old = e
    try:
        'test'.test()
    except Exception:
        got_exception = get_exception()
    # assert got_exception == got_exception_old
    assert isinstance(got_exception, AttributeError)

# Generated at 2022-06-11 06:26:41.831229
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except Exception:
        assert get_exception() is not None
        assert isinstance(get_exception(), ZeroDivisionError)

