

# Generated at 2022-06-11 06:18:06.142434
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Testing')
    except Exception:
        e = get_exception()
        assert 'Testing' in str(e)


# Generated at 2022-06-11 06:18:09.804530
# Unit test for function get_exception
def test_get_exception():

    class MyException(Exception):
        pass

    try:
        raise MyException('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
        assert e.__class__ == MyException

# Test the literal eval function

# Generated at 2022-06-11 06:18:17.609858
# Unit test for function get_exception
def test_get_exception():
    # Verify that we get back what we throw
    try:
        raise ValueError('test')
    except ValueError:
        e = get_exception()
    assert e.__class__ is ValueError
    assert str(e) == 'test'

    # We should get back the last exception on the stack, not the current one
    try:
        try:
            raise ValueError('test')
        except ValueError:
            e = get_exception()
    except ValueError:
        pass
    assert e.__class__ is ValueError



# Generated at 2022-06-11 06:18:22.805694
# Unit test for function get_exception
def test_get_exception():
    class DummyException(Exception):
        pass

    try:
        raise DummyException("test message")
    except:
        e = get_exception()
    if isinstance(e, DummyException):
        print('test_get_exception works')
    else:
        print('test_get_exception failed: %r' % (e,))

if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:18:29.748410
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring,too-few-public-methods
    def f1():
        raise Exception("hi")
    try:
        f1()
    except Exception:
        e = get_exception()
        assert str(e) == "hi"
        assert repr(e) == "<class 'Exception'>: hi"
    else:
        raise AssertionError("f1() failed to raise an exception")



# Generated at 2022-06-11 06:18:38.130923
# Unit test for function get_exception
def test_get_exception():
    e1 = None
    try:
        raise ValueError
        assert False, "Shouldn't get here.  Exception not raised."
    except Exception:
        e1 = get_exception()
    assert isinstance(e1, ValueError)

    e1 = None
    try:
        class Foo(object):  # pylint: disable=too-few-public-methods
            pass
        raise Foo
        assert False, "Shouldn't get here.  Exception not raised."
    except Exception:
        e1 = get_exception()
    assert isinstance(e1, Foo)



# Generated at 2022-06-11 06:18:40.631179
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception("Test Exception")
    except:
        exception = get_exception()
        assert exception.args[0] == "Test Exception"


# Generated at 2022-06-11 06:18:43.753550
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:  # pylint: disable=broad-except
        e = get_exception()
    assert e.args[0] == 'Test'

# Generated at 2022-06-11 06:18:50.435112
# Unit test for function get_exception
def test_get_exception():
    try:
        raise UnicodeError("testing")
    except UnicodeError:
        e = get_exception()
        assert e.message == 'testing'


# Generated at 2022-06-11 06:18:53.161485
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test_get_exception')
    except Exception:
        e = get_exception()
        raise e

# Generated at 2022-06-11 06:19:12.929264
# Unit test for function get_exception
def test_get_exception():
    def exception_subroutine():
        raise Exception("test exception")

    try:
        exception_subroutine()
    except Exception:
        e = get_exception()

    assert(e.args == ("test exception",))

# Generated at 2022-06-11 06:19:15.217486
# Unit test for function get_exception
def test_get_exception():
    def foo():
        1/0
    try:
        foo()
    except:
        exc = get_exception()
        assert isinstance(exc, ZeroDivisionError)


# Generated at 2022-06-11 06:19:18.751665
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        e = get_exception()
        assert type(e) == ZeroDivisionError
        assert str(e) == 'integer division or modulo by zero'



# Generated at 2022-06-11 06:19:26.944600
# Unit test for function get_exception
def test_get_exception():
    # Test to make sure that get_exception() raises the same exception
    def bar(x, y):
        foo(x, y)
    def foo(x, y):
        raise ValueError()

    try:
        bar(1, 2)
    except:
        assert get_exception() == sys.exc_info()[1]
    # Make sure that we can still do regular exception handling
    try:
        bar(1, 2)
    except:
        assert sys.exc_info()[1]



# Generated at 2022-06-11 06:19:33.929547
# Unit test for function get_exception

# Generated at 2022-06-11 06:19:37.416234
# Unit test for function get_exception
def test_get_exception():
    class MyError(Exception):
        pass

    try:
        raise MyError('some message')
    except Exception as e:
        if get_exception() is not e:
            raise AssertionError("get_exception() should return the current exception")



# Generated at 2022-06-11 06:19:40.917432
# Unit test for function get_exception
def test_get_exception():
    # Make sure that the get_exception function throws an exception
    try:
        raise Exception('foo')
    except Exception:
        ex = get_exception()
    assert ex.args == ('foo',)


# Generated at 2022-06-11 06:19:44.267923
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        pass
    assert e == get_exception()
    try:
        raise TypeError('bar')
    except TypeError as e:
        pass
    assert e == get_exception()



# Generated at 2022-06-11 06:19:46.530622
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Catch me')
    except Exception:
        the_exception = get_exception()
        assert the_exception.message == 'Catch me'

# Generated at 2022-06-11 06:19:50.461656
# Unit test for function get_exception
def test_get_exception():
    """Check that get_exception works correctly"""
    try:
        raise AttributeError('Boom!')
    except AttributeError:
        e = get_exception()
    assert e
    assert isinstance(e, AttributeError)
    assert str(e) == 'Boom!'


# Generated at 2022-06-11 06:20:12.076553
# Unit test for function get_exception
def test_get_exception():
    '''
    This tests the get_exception function.  It's important that the function
    be right.  If it's not then the tracebacks will be missing information
    needed to figure out what was wrong.
    '''
    try:
        int('bogus')
    except:
        (exctype, exc, tb) = sys.exc_info()
        exc2 = get_exception()
        x = exc == exc2
    else:
        x = False
    assert x, 'get_exception returned unexpected value'

# Generated at 2022-06-11 06:20:14.207309
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('hello')
    except:
        e = get_exception()
        assert e.args[0] == 'hello'



# Generated at 2022-06-11 06:20:17.356211
# Unit test for function get_exception
def test_get_exception():
    def dummy():
        try:
            raise ValueError('My Exception')
        except ValueError:
            e = get_exception()
            assert e.args[0] == 'My Exception'

    dummy()

# Generated at 2022-06-11 06:20:21.426104
# Unit test for function get_exception
def test_get_exception():

    def raise_exception():
        raise ValueError("test_exception")

    try:
        raise_exception()
    except Exception:
        e = get_exception()
        assert isinstance(e, ValueError)
        assert str(e) == "test_exception"

# Generated at 2022-06-11 06:20:23.591842
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("test_get_exception: an error")
    except ValueError as e:
        assert e == get_exception()

# Generated at 2022-06-11 06:20:26.363325
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Testing')
    except Exception:
        exc = get_exception()
        assert isinstance(exc, TypeError)
        assert str(exc) == 'Testing'



# Generated at 2022-06-11 06:20:37.187030
# Unit test for function get_exception
def test_get_exception():
    from ansible.module_utils.six import PY2

    try:
        raise Exception("frob")
    except Exception:
        ex = get_exception()
        assert ex.args[0] == "frob"

    try:
        raise Exception("frob", 42)
    except Exception:
        ex = get_exception()
        if PY2:
            assert ex.args[0] == "frob"
            assert ex.args[1] == 42
        else:
            assert ex.args == ("frob", 42)

    try:
        raise Exception("frob")
    except Exception:
        ex = get_exception()
        assert str(ex) == "frob"

    try:
        raise Exception("frob", 42)
    except Exception:
        ex = get_exception()
       

# Generated at 2022-06-11 06:20:39.958689
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test')
    except Exception:
        e = get_exception()
        assert str(e) == 'test'



# Generated at 2022-06-11 06:20:42.647519
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Test exception")
    except:
        e = get_exception()
    assert e.args == (u'Test exception',)

# Generated at 2022-06-11 06:20:48.226159
# Unit test for function get_exception
def test_get_exception():
    # mypy doesn't understand that this is supposed to be returning sys.exc_info
    # pylint: disable=unsubscriptable-object
    try:
        raise RuntimeError('test_get_exception')
    except Exception:
        e = get_exception()
        assert isinstance(e, Exception)
        assert str(e) == 'test_get_exception'



# Generated at 2022-06-11 06:21:22.494990
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
        assert str(e) == 'foo'
        del e

# Generated at 2022-06-11 06:21:23.913224
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        assert get_exception() is e


# Generated at 2022-06-11 06:21:30.447856
# Unit test for function get_exception
def test_get_exception():
    """Test that get_exception function properly gets the exception.

    :returns:  True if tests succeed or False if any of them fail.
    :rtype: bool
    """
    # Define the Exception class.
    class ExceptionClass(Exception):
        pass

    # Create an instance of the Exception class.
    exc_instance = ExceptionClass()

    # Get the exception and compare.
    try:
        raise exc_instance
    except ExceptionClass:
        e = get_exception()

    if e is not exc_instance:
        return False

    return True

# Generated at 2022-06-11 06:21:32.501566
# Unit test for function get_exception
def test_get_exception():
    try:
        1/0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:21:35.307301
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception): pass

    try:
        raise TestException
    except TestException as e:
        e = get_exception()
    assert isinstance(e, TestException)



# Generated at 2022-06-11 06:21:37.322318
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)


# Generated at 2022-06-11 06:21:39.625742
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('Test Exception')
    except ValueError as e:
        assert e is get_exception()



# Generated at 2022-06-11 06:21:41.681009
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        exc = get_exception()
    assert isinstance(exc, Exception)

# Generated at 2022-06-11 06:21:43.258197
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('an error')
    except:
        assert get_exception() is not None

# Generated at 2022-06-11 06:21:53.192757
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError()
    except ValueError:
        exc = get_exception()
    assert exc.__class__ == ValueError

if "__main__" == __name__:
    import sys
    import unittest
    # Since we're doing unit testing, let's add "debug" to the default set of plugins
    sys.modules['ansible.plugins.callback'].DEFAULT_PLUGINS.append('debug')
    # Just show the unit test output:
    # ansible.plugins.callback.default.CallbackModule = ansible.plugins.callback.debug.CallbackModule
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = basic.AnsibleModuleArgSpec(
        argument_spec={},
        supports_check_mode=False,
    )
    unittest.main()

# Generated at 2022-06-11 06:22:28.116476
# Unit test for function get_exception
def test_get_exception():
    def raise_exception(some_text):
        raise Exception(some_text)

    try:
        raise_exception('some text')
    except Exception:
        e = get_exception()
    assert e.args[0] == 'some text'

# Generated at 2022-06-11 06:22:32.492264
# Unit test for function get_exception
def test_get_exception():
    import unittest

    class GetExceptionTest(unittest.TestCase):
        def testException(self):
            try:
                raise Exception('Test exception')
            except:
                self.assertEqual(str(get_exception()), 'Test exception')

    unittest.main(module=__name__)

# Generated at 2022-06-11 06:22:36.521908
# Unit test for function get_exception
def test_get_exception():
    import pytest

    try:
        raise Exception('foo')
    except Exception:
        x = get_exception()
    assert x.args[0] == 'foo'
    try:
        raise ValueError('bar')
    except Exception:
        y = get_exception()
    assert y.args[0] == 'bar'

# Generated at 2022-06-11 06:22:38.985517
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        assert type(get_exception()) == Exception
        assert str(get_exception()) == 'foo'

# Generated at 2022-06-11 06:22:40.841261
# Unit test for function get_exception
def test_get_exception():
    def outer():
        def inner():
            return
        try:
            inner()
        except:
            return get_exception()

    assert outer() is None



# Generated at 2022-06-11 06:22:43.087550
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception:
        e = get_exception()
    assert e.args == ('foo',)


# Generated at 2022-06-11 06:22:45.707664
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0  # pylint: disable=pointless-statement
    except ZeroDivisionError:
        e = get_exception()
    assert isinstance(e, ZeroDivisionError)

# Generated at 2022-06-11 06:22:48.633894
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError("Test exception")
    except:
        e = get_exception()
    assert e.args[0] == "Test exception"

# Generated at 2022-06-11 06:22:52.106461
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError as e:
        the_exception = get_exception()
        assert(isinstance(the_exception, RuntimeError))
        assert(str(e) == str(the_exception))

# Generated at 2022-06-11 06:22:56.108750
# Unit test for function get_exception
def test_get_exception():
    """Test to make sure that get_exception works"""
    try:
        raise Exception('Testing get_exception')
    except Exception:
        exception = get_exception()
    assert exception.args[0] == 'Testing get_exception'


# Generated at 2022-06-11 06:23:30.915830
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except Exception:
        e = get_exception()
        assert type(e) == TypeError
        assert e.args == ('foo',)


# Generated at 2022-06-11 06:23:33.126791
# Unit test for function get_exception
def test_get_exception():
    try:
        a = 1
        b = c
    except:
        assert get_exception()
        return True

    assert False

# Generated at 2022-06-11 06:23:37.173045
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('get_exception test')
    except:
        e = get_exception()
        if str(e) is not '[Errno 5] get_exception test':
            raise AssertionError('get_exception test failed')

# Generated at 2022-06-11 06:23:40.212591
# Unit test for function get_exception
def test_get_exception():
    class MyException(Exception):
        pass

    try:
        raise MyException('foobar')
    except:
        exc = get_exception()
        assert str(exc) == 'foobar'

# Generated at 2022-06-11 06:23:49.622441
# Unit test for function get_exception
def test_get_exception():
    def foo():
        raise ValueError

    def bar(e):
        """Helper function to verify that e is the current exception"""
        if e is not get_exception():
            raise TypeError('e is not the current exception')

    try:
        foo()
    except ValueError:
        e = get_exception()
        bar(e)

    try:
        raise ValueError
    except ValueError:
        e = get_exception()
        bar(e)

    # Monkeypatch sys.exc_info so that we can test that get_exception works
    # even if sys.exc_info is None
    try:
        foo()
    except ValueError:
        e = get_exception()
        bar(e)
        old_exc_info = sys.exc_info()

# Generated at 2022-06-11 06:23:52.565355
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("Exception") # pylint: disable=raising-bad-type
    except:
        assert isinstance(get_exception(), ValueError)


# Generated at 2022-06-11 06:23:57.210049
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('An exception')
    except ValueError:
        e = get_exception()
        if e.__str__() != 'An exception':
            raise AssertionError('Unexpected exception thrown: %s', e.__str__())
    else:
        raise AssertionError('There should have been an exception...')

# Generated at 2022-06-11 06:24:01.970522
# Unit test for function get_exception
def test_get_exception():
    # the exception in this code block should not be caught by the outer block
    # so if it does get caught, we'll trigger an AssertionError.
    try:
        try:
            try:
                raise IOError()
            finally:
                e = get_exception()
        except Exception:
            pass
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-11 06:24:06.537475
# Unit test for function get_exception
def test_get_exception():
    try:
        1 / 0
    except:
        e = get_exception()
        assert isinstance(e, ZeroDivisionError)
    else:
        assert False, "ZeroDivisionError not raised"


if __name__ == '__main__':
    test_get_exception()

# Generated at 2022-06-11 06:24:09.615183
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('foo')
    except TypeError as e:
        e2 = get_exception()

    assert(str(e) == str(e2))



# Generated at 2022-06-11 06:24:46.476116
# Unit test for function get_exception
def test_get_exception():
    # Must be a class because we raise it in the function
    class MyException(Exception):
        pass
    def raise_my_exception():
        raise MyException("Raised!")

    def do_test():
        try:
            raise_my_exception()
        except:
            e = get_exception()
            assert e.args[0] == "Raised!"
            assert isinstance(e, MyException)

    do_test()

# Generated at 2022-06-11 06:24:49.307872
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('foo')
    except:
        e = get_exception()
        assert e.args[0] == "foo"
        assert type(e) == ValueError

# Generated at 2022-06-11 06:24:51.000463
# Unit test for function get_exception

# Generated at 2022-06-11 06:24:56.205589
# Unit test for function get_exception
def test_get_exception():
    """ Unit test for get_exception()

    :return:
    """
    def raiser():
        raise RuntimeError("This code is tested.")  # noqa # pylint: disable=undefined-variable
    try:
        raiser()
    except:
        e = get_exception()
        assert e.__str__() == "This code is tested."


if __name__ == "__main__":
    test_get_exception()

# Generated at 2022-06-11 06:24:57.499578
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception()
    except:
        assert get_exception()

# Generated at 2022-06-11 06:24:59.439986
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('a message')
    except:
        exc = get_exception()
    assert 'a message' in str(exc)

# Generated at 2022-06-11 06:25:01.619464
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-11 06:25:04.536930
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test')
    except Exception:
        assert sys.exc_info()[1] == get_exception()

# pylint: disable=redefined-outer-name

# Generated at 2022-06-11 06:25:09.304539
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('foo')
    except Exception as e:
        if get_exception() is not e:
            raise Exception('get_exception() did not return the same '
                            'object that was caught')
    except:
        raise Exception('get_exception() did not return the same '
                        'object that was caught')



# Generated at 2022-06-11 06:25:17.452446
# Unit test for function get_exception
def test_get_exception():
    # With no exception set:
    assert get_exception() is None

    try:
        x = 1 / 0
    except ZeroDivisionError:
        # With an exception set, but with the exception caught elsewhere:
        assert get_exception() is None

    try:
        x = 1 / 0
    except ZeroDivisionError as zero_exception:
        # With the exception set and caught in this block:
        try:
            raise RuntimeError('Foo')
        except RuntimeError as runtime_exception:
            # And with another exception set:
            assert get_exception() == runtime_exception
        # This exception should still be set:
        assert get_exception() == runtime_exception

        # The original exception should've been set by this point:
        assert get_exception() == zero_exception

    assert get_

# Generated at 2022-06-11 06:25:58.873091
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('thrown exception')
    except Exception:
        e = get_exception()
        assert e.args[0] == 'thrown exception'

# Generated at 2022-06-11 06:26:05.241329
# Unit test for function get_exception
def test_get_exception():
    '''
    >>> test_get_exception()
    '''
    import traceback
    try:
        raise Exception('test_get_exception')
    except:
        exc = get_exception()
    tb = ''.join(traceback.format_exception(*sys.exc_info()))
    assert 'test_get_exception' in str(exc), "get_exception() did not return the exception being handled: %s" % tb
    assert 'test_get_exception' in tb, "get_exception() did not preserve the exception trace: %s" % tb



# Generated at 2022-06-11 06:26:13.100988
# Unit test for function get_exception
def test_get_exception():
    import pytest
    # first piece is the type of exception
    # second piece is the exception instance
    try:
        raise ValueError("test exception 1")
    except Exception:
        ex1 = get_exception()

    try:
        raise TypeError("test exception 2")
    except ValueError:
        pytest.fail("Should not have caught the wrong exception here")
    except Exception:
        ex2 = get_exception()

    try:
        raise TypeError("test exception 2")
    except (ValueError, TypeError):
        ex3 = get_exception()

    try:
        raise ValueError("test exception 1")
    except (TypeError, ValueError):
        ex4 = get_exception()

    assert isinstance(ex1, ValueError)
    assert isinstance(ex2, TypeError)

# Generated at 2022-06-11 06:26:15.460105
# Unit test for function get_exception

# Generated at 2022-06-11 06:26:18.431886
# Unit test for function get_exception
def test_get_exception():
    def foo(x):
        try:
            raise ValueError('foo')
        except ValueError:
            e = get_exception()
            assert type(e) is ValueError
            assert "foo" in str(e)

    foo(1)

# Generated at 2022-06-11 06:26:20.827249
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError('oops!')
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)



# Generated at 2022-06-11 06:26:23.002549
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('hello')
    except Exception:
        e = get_exception()

    assert isinstance(e, RuntimeError)
    assert 'hello' in str(e)
    assert e.__class__.__name__ == 'RuntimeError'



# Generated at 2022-06-11 06:26:25.798870
# Unit test for function get_exception
def test_get_exception():
    def _do_test_get_exception(exc):
        try:
            raise exc
        except Exception:
            return get_exception()
    assert _do_test_get_exception(RuntimeError('foo')) is not None

# Generated at 2022-06-11 06:26:28.176789
# Unit test for function get_exception
def test_get_exception():
    import pytest
    try:
        assert 1 == 2
    except AssertionError:
        assert get_exception()


# Generated at 2022-06-11 06:26:30.443626
# Unit test for function get_exception
def test_get_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        e = get_exception()
        assert e.args[0] == 'test'


# Generated at 2022-06-11 06:27:15.988720
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=missing-docstring
    def check(e, type_, value=None, traceback=None):
        if e is None:
            assert sys.exc_info()[0] == type_
            assert sys.exc_info()[1] == value
            assert sys.exc_info()[2] == traceback
        else:
            assert e is sys.exc_info()[1]
            assert type(e) is type_
            assert e.args == (value,)
            assert e.__traceback__ is traceback

    def check_none():
        check(None, None)  # pylint: disable=no-value-for-parameter

    def check_zero():
        try:
            int('zero')
        except Exception:
            e = get_exception()

# Generated at 2022-06-11 06:27:23.834289
# Unit test for function get_exception
def test_get_exception():
    # pylint: disable=unused-variable
    try:
        a = 1
        b = 2
        c = a / b
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
        assert str(e) == "integer division or modulo by zero"

    # pylint: disable=unused-variable
    try:
        a = 1
        b = 0
        c = a / b
    except Exception:
        e = get_exception()
        assert e.__class__.__name__ == 'ZeroDivisionError'
        assert str(e) == "integer division or modulo by zero"

# Generated at 2022-06-11 06:27:25.880279
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('test exception')
    except Exception:
        e = get_exception()
        assert e.__str__() == 'test exception'

# Generated at 2022-06-11 06:27:27.884993
# Unit test for function get_exception
def test_get_exception():
    try:
        raise Exception('Test exception foobar')
    except Exception:
        exception = get_exception()
    assert exception.args == ('Test exception foobar',)

# Generated at 2022-06-11 06:27:31.797010
# Unit test for function get_exception
def test_get_exception():
    try:
        raise TypeError('Test exception')
    except TypeError as e:
        if type(e) != type(get_exception()):
            raise AssertionError('get_exception did not provide an exception of the same type as was raised.')

# Generated at 2022-06-11 06:27:35.219084
# Unit test for function get_exception
def test_get_exception():
    try:
        int('not-an-integer')
    except Exception:
        e = get_exception()
        if isinstance(e, ValueError):
            return True
        else:
            # This will fail the unit test
            raise e


# Generated at 2022-06-11 06:27:39.175863
# Unit test for function get_exception
def test_get_exception():
    class TestException(Exception):
        def __init__(self, val):
            self.val = val

    try:
        raise TestException('get_exception')
    except Exception:
        e = get_exception()
        assert e.val == 'get_exception'
    else:
        raise AssertionError('Expected exception')


# Generated at 2022-06-11 06:27:42.753618
# Unit test for function get_exception
def test_get_exception():
    def raise_exception():
        try:
            raise ValueError('testing')
        except Exception:
            return get_exception()
    ex = raise_exception()
    assert ex.args == ('testing',)
    assert type(ex) == ValueError


# Generated at 2022-06-11 06:27:45.438792
# Unit test for function get_exception
def test_get_exception():
    try:
        raise ValueError("foo")
    except ValueError:
        e = get_exception()
    assert isinstance(e, ValueError)
    assert e.args == ("foo",)

# Generated at 2022-06-11 06:27:53.112833
# Unit test for function get_exception
def test_get_exception():
    def foo():
        bar()
    def bar():
        baz()
    def baz():
        try:
            raise RuntimeError('This is a test')
        except:
            # pylint: disable=bare-except
            # Shouldn't do this in real code
            exc = get_exception()
            return exc

    exc = baz()
    assert exc.args[0] == 'This is a test', "%s != 'This is a test'" % exc.args[0]
    exc = bar()
    assert exc.args[0] == 'This is a test', "%s != 'This is a test'" % exc.args[0]
    exc = foo()
    assert exc.args[0] == 'This is a test', "%s != 'This is a test'" % exc.args[0]