

# Generated at 2022-06-12 03:06:53.879415
# Unit test for function init_settings
def test_init_settings():
    args_input = Namespace(debug = False)
    init_settings(args_input)
    assert settings.debug == False

    args_input = Namespace(debug = True)
    init_settings(args_input)
    assert settings.debug == True

# Generated at 2022-06-12 03:06:59.356706
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settin

# Generated at 2022-06-12 03:07:01.372404
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, port=9999)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:05.284571
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:07:08.698700
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:12.330637
# Unit test for function init_settings
def test_init_settings():
    setattr(settings, 'debug', False)
    args1 = Namespace(debug=False)
    args2 = Namespace(debug=True)
    init_settings(args1)
    assert settings.debug == False
    init_settings(args2)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:14.309375
# Unit test for function init_settings
def test_init_settings():
    class Args(object):
        debug = True

    init_settings(Args())

    assert settings.debug == True

# Generated at 2022-06-12 03:07:18.656365
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True
    test_args.debug = False
    init_settings(test_args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:20.583923
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:21.816104
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:27.129042
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:32.505963
# Unit test for function init_settings
def test_init_settings():

    args_1 = Namespace(debug = True)
    init_settings(args_1)
    assert settings.debug

    args_2 = Namespace(debug = False)
    init_settings(args_2)
    assert not settings.debug
    
    args_3 = Namespace()
    init_settings(args_3)
    assert not settings.debug

test_init_settings()

# Generated at 2022-06-12 03:07:33.715171
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:34.997066
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert(settings.debug)

# Generated at 2022-06-12 03:07:37.368253
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:42.803676
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False

    argv = ["faketest.py", "--debug"]
    args = parse_args(argv)
    init_settings(args)

    assert settings.debug is True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:07:45.446034
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug



# Generated at 2022-06-12 03:07:46.676943
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:49.011427
# Unit test for function init_settings
def test_init_settings():
    init_settings(argparse.Namespace(debug=True))
    assert settings.debug == True

    init_settings(argparse.Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-12 03:07:50.336174
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:58.305976
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:00.424222
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:02.858387
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:08:05.011815
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:11.798674
# Unit test for function init_settings
def test_init_settings():
    arg_list = [
        Namespace(debug=True, verbose=False, output_path=None, generators=None),
        Namespace(debug=False, verbose=True, output_path=None, generators=None),
        Namespace(debug=True, verbose=True, output_path=None, generators=None),
        Namespace(debug=False, verbose=False, output_path=None, generators=None)
    ]
    for args in arg_list:
        init_settings(args)
        assert args.debug == settings.debug



# Generated at 2022-06-12 03:08:13.194620
# Unit test for function init_settings
def test_init_settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug is True



# Generated at 2022-06-12 03:08:14.925709
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:19.077343
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert not settings.debug

    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-12 03:08:20.813355
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-12 03:08:25.653417
# Unit test for function init_settings
def test_init_settings():
    """
    Test the init_settings function
    """
    args = default_args()
    init_settings(args)
    assert not settings.debug
    args = default_args(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-12 03:08:38.112000
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

test_init_settings()

# Generated at 2022-06-12 03:08:40.831803
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug # true
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug # true


# Generated at 2022-06-12 03:08:41.290971
# Unit test for function init_settings
def test_init_settings():
    test_args = Tag

# Generated at 2022-06-12 03:08:44.126320
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True



# Generated at 2022-06-12 03:08:47.207037
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:08:51.720677
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False, log=None)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-d", "--debug", action="store_true", help="run in debug mode")
    args = parser.parse_args()
    init_settings(args)

    print(settings.debug)

# Generated at 2022-06-12 03:08:58.139621
# Unit test for function init_settings
def test_init_settings():
    parser = arguments.create_parser()
    if settings.debug == False:
        assert True
    else:
        assert False
    args = parser.parse_args(["--debug"])
    init_settings(args)
    if settings.debug == True:
        assert True
    else:
        assert False


if __name__ == "__main__":
    parser = arguments.create_parser()
    args = parser.parse_args()
    init_settings(args)
    if settings.debug:
        print(f"debug is {settings.debug}")

# Generated at 2022-06-12 03:08:59.875166
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-12 03:09:02.683153
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:05.054604
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:29.163376
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:33.062099
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(prog="PROG")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:35.276524
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args2 = Namespace(debug=False)
    init_settings(args2)
    assert not settings.debug

# Generated at 2022-06-12 03:09:38.197381
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:09:40.468231
# Unit test for function init_settings
def test_init_settings():
    init_settings(
        Namespace(debug=True)
    )

    assert settings.debug is True

    init_settings(
        Namespace(debug=False)
    )

    assert settings.debug is False

# Generated at 2022-06-12 03:09:42.622516
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace(debug = True)
    init_settings(args = args)
    assert settings.debug == True


# Generated at 2022-06-12 03:09:44.665494
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False, 'Expected False - Got ' + str(settings.debug)



# Generated at 2022-06-12 03:09:48.128327
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:50.529470
# Unit test for function init_settings
def test_init_settings():
    import random
    import string

    random_debug = random.randint(0, 1)
    args = Namespace()

    args.debug = random_debug
    init_settings(args)
    assert settings.debug == random_debug

# Generated at 2022-06-12 03:09:52.771027
# Unit test for function init_settings
def test_init_settings():
    try:
        init_settings(Namespace(debug=True))
    except Exception as e:
        assert False, "Failed to init settings. Error: {}".format(str(e))
    assert settings.debug == True



# Generated at 2022-06-12 03:10:39.274419
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:40.731252
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:42.647894
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:48.472514
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    arg_parser = argparse.ArgumentParser(description='Process command line args')
    arg_parser.add_argument('-d',
                            '--debug',
                            help='Use debug mode',
                            default=False,
                            action='store_true')
    args = arg_parser.parse_args()
    init_settings(args)
    print(args.debug)
    print(settings.debug)

# Generated at 2022-06-12 03:10:50.097318
# Unit test for function init_settings
def test_init_settings():

    from argparse import Namespace

    args = Namespace(debug = True)

    init_settings(args)
    test = settings.debug

    assert test == True



# Generated at 2022-06-12 03:10:51.535712
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


# if __name__ == '__main__':
#     test_init_settings()

# Generated at 2022-06-12 03:10:53.605154
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:10:55.421817
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:59.218686
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", help="debug mode",
                        action='store_true')
    args = parser.parse_args()

    init_settings(args)
    print(settings.debug)

    # python3 settings.py -d
    # True

# Generated at 2022-06-12 03:11:00.316271
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-12 03:12:29.855469
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:12:31.209697
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:12:32.226129
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:12:33.681955
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:12:35.224550
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-12 03:12:37.326332
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:38.513743
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=True)
    args2 = Namespace(debug=False)
    init_setti

# Generated at 2022-06-12 03:12:42.151167
# Unit test for function init_settings
def test_init_settings():
    class DummyArgs:
        def __init__(self) -> None:
            self.debug = False

    args = DummyArgs()
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:12:43.851193
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:12:46.016572
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# unit test for function init_settings

# Generated at 2022-06-12 03:15:44.827220
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:15:48.050003
# Unit test for function init_settings
def test_init_settings():
    args = None
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:15:50.129299
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # Test debug arg
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:15:51.662015
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:15:54.712408
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)
    args = Namespace(debug=False)
    init_settings(args)
    assert(settings.debug == False)


if __name__ == "__main__":
    test_init_settings()
    print("Everything passed")

# Generated at 2022-06-12 03:15:56.308789
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:15:57.505342
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

# Generated at 2022-06-12 03:15:58.487471
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:16:02.111873
# Unit test for function init_settings
def test_init_settings():
    args_debug = Namespace(debug = True)
    args_no_debug = Namespace(debug = False)
    init_settings(args_no_debug)
    assert(settings.debug == False)
    init_settings(args_debug)
    assert(settings.debug == True)


# Generated at 2022-06-12 03:16:03.534672
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True