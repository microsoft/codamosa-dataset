

# Generated at 2022-06-12 03:07:06.552629
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, 'debug', False)
    init_settings(args)
    assert settings.debug == False

    setattr(args, 'debug', True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:10.211514
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:07:12.391537
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:07:17.215780
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug
    args = Namespace
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:07:21.626998
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:27.738468
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:07:31.432907
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:32.483601
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:33.713948
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:36.323470
# Unit test for function init_settings
def test_init_settings():
    global args, settings
    args = Namespace()
    settings = Settings()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:40.158183
# Unit test for function init_settings
def test_init_settings():
    setargs = Namespace()
    setargs.debug = True
    init_settings(setargs)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:41.520084
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    actual = settings.debug
    expected = True
    assert actual == expected

# Generated at 2022-06-12 03:07:45.376620
# Unit test for function init_settings
def test_init_settings():
    argv = ['./test', '-d']
    ap = argparse.ArgumentParser()
    ap.add_argument('-d', dest='debug', action='store_true')
    args = ap.parse_args(argv)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:50.128907
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:54.129488
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-12 03:07:58.444306
# Unit test for function init_settings
def test_init_settings():
    settings = init_settings(Namespace(debug=False))
    assert settings.debug == False
    settings = init_settings(Namespace(debug=True))
    assert settings.debug == True
    try:
        settings = init_settings(Namespace(debug=0))
        raise AssertionError("0 is not a boolean")
    except AssertionError:
        pass

# Generated at 2022-06-12 03:08:01.708943
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False




# Generated at 2022-06-12 03:08:04.931719
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:06.717533
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:09.096850
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug = False)
    init_settings(test_args)
    assert settings.debug == False

test_init_settings()

# Generated at 2022-06-12 03:08:17.987482
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:20.311357
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:08:24.541408
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:25.936790
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:27.328869
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:30.239918
# Unit test for function init_settings
def test_init_settings():
    # arrange
    args = Namespace()

    # act
    init_settings(args)

    # assert
    assert not settings.debug

    # act
    args.debug = True
    init_settings(args)

    # asseert
    assert settings.debug


if __name__ == '__main__':
    init_settings(Namespace())
    test_init_settings()
    print('All tests passed!')

# Generated at 2022-06-12 03:08:33.699818
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:38.234126
# Unit test for function init_settings
def test_init_settings():
    class Args:
        debug = False
    init_settings(Args)
    assert settings.debug == False

    class Args:
        debug = True
    init_settings(Args)
    assert settings.debug == True

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:08:39.550566
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:43.367103
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    print("Settings:", settings)
    args = Namespace(debug=True)
    init_settings(args)
    print("Settings:", settings)

# Generated at 2022-06-12 03:08:55.302552
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    main()

# Generated at 2022-06-12 03:08:57.307833
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:09:01.431340
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    test_init_settings()
    print('All test passed')

# Generated at 2022-06-12 03:09:02.683197
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:04.021142
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:05.244967
# Unit test for function init_settings
def test_init_settings():
    args =  Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:06.522783
# Unit test for function init_settings
def test_init_settings():
    class Args:
        debug = False
    settings.debug = True
    init_settings(Args)
    assert settings.debug == False



# Generated at 2022-06-12 03:09:07.429330
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:09:08.472107
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:09.805879
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, log_level='ERROR')
    init_settings(args)
    assert settings.debug == True
    

# Generated at 2022-06-12 03:09:22.924853
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_settings(args)
    assert settings.debug is True

    args = Namespace(
        debug=False
    )

    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:09:25.431861
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

if __name__ == '__main__':
    print("Testing from module settings")
    test_init_settings()
    print("Done")

# Generated at 2022-06-12 03:09:26.734862
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-12 03:09:28.667689
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:29.673027
# Unit test for function init_settings
def test_init_settings():
    # assert init_settings() == None
    assert False


# Generated at 2022-06-12 03:09:31.635998
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:09:33.542060
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:09:38.158633
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process args.')
    parser.add_argument('--debug', action="store_true",
                        help='Run with debug mode on')
    args = parser.parse_args()
    init_settings(args)



# Generated at 2022-06-12 03:09:39.147205
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:09:42.061217
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

    init_settings(Namespace(debug=None))
    assert settings.debug is False

# Generated at 2022-06-12 03:09:53.379748
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:09:54.765407
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:56.668809
# Unit test for function init_settings
def test_init_settings():
    Namespace1 = Namespace(debug = True)
    Namespace2 = Namespace(debug = False)
    init_settings(Namespace1)
    assert settings.debug is True
    init_settings(Namespace2)
    assert settings.debug is False

# Generated at 2022-06-12 03:09:57.356698
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

# Generated at 2022-06-12 03:09:59.534023
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:01.535055
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:02.908353
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:04.115761
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:10:05.629510
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True


# Generated at 2022-06-12 03:10:08.113537
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:32.257476
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    args2 = Namespace(debug=True)

    init_settings(args1)
    assert not settings.debug

    init_settings(args2)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:10:33.473763
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:34.786784
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:10:39.189969
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert hasattr(settings, 'debug')
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert hasattr(settings, 'debug')
    assert settings.debug

# Generated at 2022-06-12 03:10:40.667778
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:48.968941
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == '__main__':
    import sys
    from os import path
    from json import load

    # Get the root path
    root_path = path.dirname(path.dirname(path.abspath(__file__)))
    folder_path = sys.path[0]

    # Get the path to the config file
    config_path = path.join(root_path, 'config.ini')
    text_path = path.join(root_path, 'config.txt')
    json_path = path.join(root_path, 'config.json')

    # Load the config file
    with open(json_path, 'r') as json_file:
        json_dict = load(json_file)


# Generated at 2022-06-12 03:10:50.616830
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:10:51.612809
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:54.235821
# Unit test for function init_settings
def test_init_settings():
    
    args = ('debug')
    init_settings(args)
    assert settings.debug == True
    print("Unit test for function init_settings passed")

test_init_settings()

# Generated at 2022-06-12 03:10:55.559231
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert args.debug == settings.debug

# Generated at 2022-06-12 03:11:37.052861
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:38.433602
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:11:39.486467
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()

# Generated at 2022-06-12 03:11:41.725144
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(mode='dev', debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:43.154978
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-12 03:11:46.209511
# Unit test for function init_settings
def test_init_settings():
    #  Function init_settings is called in the main function, we will test the
    #  boolean value of settings.debug to ensure that the function was called
    #  correctly
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:50.599683
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    init_settings(args)

    args = Namespace
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    init_settings(args)

    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    init_settings(args)

# Generated at 2022-06-12 03:11:52.449250
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True
    init_settings(args)
    assert settings.debug == True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:54.733623
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-12 03:11:56.193446
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:13:13.779278
# Unit test for function init_settings
def test_init_settings():
    # Test that defualts are correct
    args = Namespace()
    init_settings(args)
    assert not settings.debug
    # Test that --debug sets debug to true
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:13:15.273298
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True) # type: ignore
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:13:16.486972
# Unit test for function init_settings
def test_init_settings():
    import argparse
    arguments = argparse.Namespace()
    arguments.debug = True
    init_settings(arguments)
    assert settings.debug == True



# Generated at 2022-06-12 03:13:17.401178
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

# Generated at 2022-06-12 03:13:18.378684
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    
    assert settings.debug == True

# Generated at 2022-06-12 03:13:21.045488
# Unit test for function init_settings
def test_init_settings():
    class Args:
        def __init__(self) -> None:
            self.debug = False

        def __repr__(self) -> str:
            return f'debug={self.debug}'

    args = Args()

    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:13:23.557603
# Unit test for function init_settings
def test_init_settings():
    # default settings
    args = Namespace()
    init_settings(args)
    assert settings.debug == False
    # args.debug set to true
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:13:25.679114
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:13:32.325365
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:13:33.748922
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:16:12.081379
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-12 03:16:14.798915
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:16:15.558086
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:16:18.250647
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:16:18.652722
# Unit test for function init_settings
def test_init_settings():
    init_settings()

# Generated at 2022-06-12 03:16:20.089731
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-12 03:16:22.088486
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace()
    args.debug = True
    # Act
    init_settings(args)
    # Assert
    assert settings.debug is True

# Generated at 2022-06-12 03:16:24.050496
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True, program_name='test_init_settings'))
    assert settings.debug is True

# Generated at 2022-06-12 03:16:26.376684
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:16:28.190017
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))

    # Test debug value
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()