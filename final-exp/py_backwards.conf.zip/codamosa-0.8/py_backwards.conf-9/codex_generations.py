

# Generated at 2022-06-12 03:07:10.817281
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:07:12.788771
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(**{"debug": True}))
    assert settings.debug == True

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:07:14.390343
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:07:17.642038
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:23.100322
# Unit test for function init_settings
def test_init_settings():
    init_settings_args = Namespace()
    init_settings_args.debug = False

    init_settings(init_settings_args)

    assert settings.debug == False

    init_settings_args.debug = True

    init_settings(init_settings_args)

    assert settings.debug == True

# Generated at 2022-06-12 03:07:27.118581
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:07:28.794593
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:07:30.111858
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:32.764510
# Unit test for function init_settings
def test_init_settings():
    arguments = Namespace(debug=True)
    init_settings(arguments)
    assert settings.debug == True


# If a.py is run directly
if __name__ == '__main__':
    init_settings(arguments)

# Generated at 2022-06-12 03:07:38.680573
# Unit test for function init_settings
def test_init_settings():
    # Test with debug = True
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    # Test with debug = False
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False


# ****** Main ******
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-debug", action = "store_true")
    args = parser.parse_args()
    init_settings(args)

    # test_init_settings()