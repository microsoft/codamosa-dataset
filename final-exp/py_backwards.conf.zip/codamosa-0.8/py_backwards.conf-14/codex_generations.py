

# Generated at 2022-06-12 03:06:46.278965
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:06:53.004919
# Unit test for function init_settings
def test_init_settings():
    # Setup
    args = Mock()
    args.debug = False
    # Action
    init_settings(args)
    # Assert
    assert settings.debug == False

# Generated at 2022-06-12 03:06:59.163302
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False



# Generated at 2022-06-12 03:07:00.410613
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:05.661444
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:09.943710
# Unit test for function init_settings
def test_init_settings():
    args = Mock(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Mock(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:11.715046
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:13.884277
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True




# Generated at 2022-06-12 03:07:18.866409
# Unit test for function init_settings
def test_init_settings():
    '''
    Unit test for function init_settings
    '''
    args = Namespace(
        debug=True,
        mode=None,
        port=8080,
        policy='drop',
        url=None)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:20.614062
# Unit test for function init_settings
def test_init_settings():

    # test when debug is true
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    # test when debug is false
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:27.610941
# Unit test for function init_settings
def test_init_settings():
    # GIVEN
    args = Namespace(debug=True)

    # WHEN
    init_settings(args)

    # THEN
    assert settings.debug is True

# Generated at 2022-06-12 03:07:30.364907
# Unit test for function init_settings
def test_init_settings():
    class Args:
        def __init__(self) -> None:
            self.debug = False
    args = Args()
    init_settings(args)
    assert(settings.debug == False)

    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-12 03:07:31.545148
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug



# Generated at 2022-06-12 03:07:32.613236
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:33.843169
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:35.134664
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:37.210538
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:48.122729
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings_test = Settings()
    settings_test.debug = True

    init_settings(Namespace(debug='True'))
    assert settings == settings_test


if __name__ == '__main__':
    plot_path = Path('.')

    parser = argparse.ArgumentParser(description='Plot data.')

    parser.add_argument('--debug',
                        help='Enable debug mode.',
                        default='False')

    args = parse_args(parser)
    init_settings(args)

    # Home position data files
    home_pos_files = list(Path('.').glob('home_position/*.csv'))
    # Tasks data files
    rest_files = list(Path('.').glob('rest/*.csv'))

# Generated at 2022-06-12 03:07:49.407127
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:51.089332
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace()
    mock_args.debug = True
    init_settings(mock_args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:06.072279
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


# Main function (if file is run as script)
if __name__ == '__main__':
    # Arguments
    parser = argparse.ArgumentParser(description='Parses a markdown file to an html file')
    parser.add_argument('input_file', help='The input file to parse', metavar='input')
    parser.add_argument('-o', '--output-file', help='The output file to write to', metavar='output')
    parser.add_argument('-d', '--debug', action='store_true', help='Display script information')
    args = parser.parse_args()

    # Init settings
    init_settings(args)

    # Read file

# Generated at 2022-06-12 03:08:07.616548
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:09.362994
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:08:11.000982
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:12.162126
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:15.080228
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:08:19.258460
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    settings.debug = False

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:08:20.665486
# Unit test for function init_settings
def test_init_settings():
    args = {'debug': True}
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:24.558975
# Unit test for function init_settings
def test_init_settings():
    # Just run the function
    args = Namespace(debug=True)
    init_settings(args)
    # Check correctness
    assert settings.debug is True



# Generated at 2022-06-12 03:08:25.971020
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:08:38.780909
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False # Make sure settings.debug is false before running init_settings
    init_settings(Namespace(debug=True)) # inputs to function should be of the form Namespace(debug=<True/False>)
    assert settings.debug == True
    
    


# Generated at 2022-06-12 03:08:41.174721
# Unit test for function init_settings
def test_init_settings():

    args1 = Namespace(debug=True)
    args2 = Namespace(debug=False)

    init_settings(args1)
    init_settings(args2)

    assert settings.debug == True
    assert settings.debug == False

# Generated at 2022-06-12 03:08:44.920131
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, 'debug', True)

    init_settings(args)
    assert settings.debug

    args = Namespace()
    setattr(args, 'debug', False)

    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:08:48.229022
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True # we have to use true if we want to trigger the debug code
    init_settings(args)
    assert settings.debug == True

test_init_settings()


# Generated at 2022-06-12 03:08:49.620998
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:52.690881
# Unit test for function init_settings
def test_init_settings():
    settings_backup = Settings()
    settings_backup.debug = settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

    settings.debug = settings_backup.debug

# Generated at 2022-06-12 03:08:54.497217
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug



# Generated at 2022-06-12 03:08:56.918444
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:57.940789
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:09:04.503693
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=None)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    # -b  -- run unit tests
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--test', help="run unit tests only",
                        action='store_true')

    args = parser.parse_args()
    if args.test:
        test_init_settings()
        sys.exit()

    # run main...

# Generated at 2022-06-12 03:09:31.596428
# Unit test for function init_settings
def test_init_settings():
    # Create the parser
    parser = argparse.ArgumentParser(
        description='Test the init_settings function.'
    )

    # Add the arguments
    parser.add_argument('-d', '--debug', action='store_true',
                        help='Display debug messages.')

    # Parse the command line arguments
    args = parser.parse_args()

    init_settings(args)

    if settings.debug:
        print(f'Debug is on.')
    else:
        print(f'Debug is off.')


# Execute the unit test
if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:09:33.187266
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:09:34.545478
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:38.596741
# Unit test for function init_settings
def test_init_settings():
    arg_list = ["--debug"]
    args = arg_parser.parse_args(arg_list)
    res = init_settings(args)
    print("settings.debug =", settings.debug)
    assert settings.debug == True


################################################################################


# Test
if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:09:42.307035
# Unit test for function init_settings
def test_init_settings():
    args_dict = {'debug': False}
    args = Namespace(**args_dict)
    init_settings(args)
    assert settings.debug == False

    args_dict = {'debug': True}
    args = Namespace(**args_dict)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:43.870839
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-12 03:09:46.495462
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:48.590910
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:49.943701
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:52.638158
# Unit test for function init_settings
def test_init_settings():
    global settings
    # Test case for "normal" configuration
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # Test case for "debug" configuration
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True