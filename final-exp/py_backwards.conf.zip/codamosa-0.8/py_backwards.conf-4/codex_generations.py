

# Generated at 2022-06-12 03:06:59.156936
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description='test')

    parser.add_argument('--debug', action="store_true", default=False,
                        help='run in debug mode')
    parser.add_argument('--f1', action="store", default=0.0, dest='f1', type=float,
                        help='float value for testing')
    parser.add_argument('--f2', action="store", default=0.0, dest='f2', type=float,
                        help='float value for testing')
    args = parser.parse_args()

    # check that all settings are set to their defaults
    assert settings.debug == False

    # set some values
    args.debug = True

    # initialize the settings
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-12 03:07:02.943717
# Unit test for function init_settings
def test_init_settings():
    # Create a test argparse namespace
    args = Namespace()
    args.debug = True

    # Call the function with the test argparse namespace
    init_settings(args)

    # Check that settings.deubg is True
    assert settings.debug

# Generated at 2022-06-12 03:07:05.648078
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-12 03:07:10.302292
# Unit test for function init_settings
def test_init_settings():
    debug_args = Namespace(debug=True)
    init_settings(debug_args)
    assert settings.debug is True

    debug_args = Namespace(debug=False)
    init_settings(debug_args)
    assert settings.debug is False

# Generated at 2022-06-12 03:07:13.895698
# Unit test for function init_settings
def test_init_settings():
    args = Namespace

    args.debug = None
    init_settings(args)
    assert settings.debug == False

    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True


test_init_settings()

# Generated at 2022-06-12 03:07:18.118547
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:24.646070
# Unit test for function init_settings
def test_init_settings():
    import sys

    sys.argv.append('--debug')
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True


# Parsing command line arguments
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument('-d', '--debug', action='store_true')
args = parser.parse_args()
init_settings(args)

from pydantic import BaseModel, constr
from typing import List


# Generated at 2022-06-12 03:07:30.311552
# Unit test for function init_settings
def test_init_settings():
    testargs = ['--debug']
    with patch('sys.argv', testargs):
        from ymci.commandline import commandline_parser
        args = commandline_parser()
        init_settings(args)
        assert settings.debug is True
    testargs = ['']
    with patch('sys.argv', testargs):
        from ymci.commandline import commandline_parser
        args = commandline_parser()
        init_settings(args)
        assert settings.debug is False

# Generated at 2022-06-12 03:07:33.873247
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Command line interface for the Stochastic Petri Net Analyser')
    parser.add_argument('-d', '--debug', action='store_true', help='Enables debug mode')
    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-12 03:07:37.077412
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    #  assert args.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:07:40.893963
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:42.252985
# Unit test for function init_settings
def test_init_settings():
    args_test = Namespace(debug=True)
    init_settings(args_test)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:45.877562
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert(settings.debug == False)
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

    # Add more unit tests when you've got more functionality

# Generated at 2022-06-12 03:07:50.129148
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:51.532545
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:54.349077
# Unit test for function init_settings
def test_init_settings():
    arguments = Namespace(debug=True)
    init_settings(arguments)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:57.449899
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:00.687229
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:02.114175
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug

# Generated at 2022-06-12 03:08:05.872291
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True
    test_args2 = Namespace()
    init_settings(test_args2)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:13.660458
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug==False

    init_settings(Namespace(debug=True))
    assert settings.debug==True

if __name__ == '__main__':
    exit("error: catch exception")

# Generated at 2022-06-12 03:08:17.129887
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    assert(settings.debug == False)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-12 03:08:18.782239
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:25.761473
# Unit test for function init_settings
def test_init_settings():
    """
    Verify that the settings are initialized correctly, i.e. the debug flag is set to True or False.
    """
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False

    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:27.144522
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:08:29.423764
# Unit test for function init_settings
def test_init_settings():
    args_debug = Namespace(debug = True)
    args_nodebug = Namespace(debug = False)
    init_settings(args_debug)
    assert settings.debug == True
    init_settings(args_nodebug)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:32.279778
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:34.402739
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:37.236480
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:39.445449
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:08:53.493698
# Unit test for function init_settings
def test_init_settings():
    from mock import patch
    from sys import argv
    from argparse import ArgumentParser
    from argparse import Namespace

    with patch.object(ArgumentParser, 'parse_args', return_value=Namespace(debug=True)):
        init_settings(argv)
        assert settings.debug == True

# Generated at 2022-06-12 03:08:57.197818
# Unit test for function init_settings
def test_init_settings():
    # Case 1
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    # Case 2
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:08:58.437051
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-12 03:08:59.839781
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:09:02.106703
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-12 03:09:05.740760
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    settings.debug = True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:08.771565
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("--debug", action="store_true")
    args, unknown = parser.parse_known_args()
    init_settings(args)

    unittest.main()

# Generated at 2022-06-12 03:09:10.530126
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True
    assert settings.debug == True

# Generated at 2022-06-12 03:09:11.779797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:12.779167
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:09:35.451213
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:09:37.476392
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:39.820315
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:41.601397
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-12 03:09:43.473798
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    assert settings.debug is False
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:44.731477
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:09:47.644186
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-12 03:09:48.883277
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:53.702652
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args("--debug".split())
    init_settings(args)

    assert settings.debug

if __name__ == "__main__":
    for test in dir():
        if test.startswith("test_"):
            try:
              globals()[test]()
              print("Test", test, "succeeded")
            except:
              print("Test", test, "FAILED")
              raise

# Generated at 2022-06-12 03:09:55.150652
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    a = Namespace()
    a.debug = True
    init_settings(a)
    assert settings.debug is True

test_init_settings()

# Generated at 2022-06-12 03:10:41.306280
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    return

# Generated at 2022-06-12 03:10:45.826167
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug','-d', help='Enable exercise of debugging code', action='store_true')
    args = parser.parse_args()

    #Check that boolean is set to false initially
    assert settings.debug == False

    init_settings(args)

    #Check that boolean value is changed when a valid argument is passed
    assert settings.debug == True

# Generated at 2022-06-12 03:10:47.396174
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:48.690430
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:10:49.606948
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:50.690003
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:54.297223
# Unit test for function init_settings
def test_init_settings():
    from settings import settings
    from argparse import Namespace

    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-12 03:10:55.392956
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug


# Generated at 2022-06-12 03:10:56.823018
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:57.942456
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

