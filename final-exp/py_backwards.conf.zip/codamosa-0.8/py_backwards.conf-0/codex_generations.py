

# Generated at 2022-06-12 03:06:59.486345
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:07:02.284930
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    settings.debug == True



# Generated at 2022-06-12 03:07:06.552215
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(argparse.Namespace(debug=False))
    assert settings.debug == args.debug
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:07:11.440706
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:20.610874
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    # Note: we don't want to import the file we are testing
    import sys
    import os
    # Insert the parent directory into the path so we can import the code to be tested
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    import unittest
    from unittest import TestCase
    from unittest.mock import patch


# Generated at 2022-06-12 03:07:26.888977
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:29.380446
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    init_settings(Namespace(debug=False))
    assert settings.debug == False


if __name__ == '__main__':
    p

# Generated at 2022-06-12 03:07:32.186160
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    args = Namespace(debug=False)
    init_settings(args)

# Generated at 2022-06-12 03:07:33.360452
# Unit test for function init_settings
def test_init_settings():
    _args = Namespace(debug=True)
    init_settings(_args)

    assert settings.debug == True


# Generated at 2022-06-12 03:07:35.169457
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import Mock

    args = Mock(debug=True)

    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-12 03:07:42.335418
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace()
    args.debug = False
    init_settings(args)

    assert settings.debug == False

    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:07:44.145812
# Unit test for function init_settings
def test_init_settings():
    args_t = Namespace(debug=True)
    init_settings(args_t)
    assert settings.debug == True
    

# Generated at 2022-06-12 03:07:50.026761
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:54.726895
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:57.049759
# Unit test for function init_settings
def test_init_settings():
    testargs = Namespace(debug=True)
    init_settings(testargs)
    assert settings.debug is True, "Settings.debug should be True"



# Generated at 2022-06-12 03:07:58.481527
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:08:00.574797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:08:03.635920
# Unit test for function init_settings
def test_init_settings():
    nsp = Namespace(debug=True)
    init_settings(nsp)
    assert settings.debug == True
    nsp = Namespace(debug=False)
    init_settings(nsp)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:07.058109
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:09.438211
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-12 03:08:13.364525
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:15.272858
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:18.216400
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:08:20.553398
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:08:24.775284
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 03:08:26.805009
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True


init_settings(Namespace(debug=True))
print(settings.debug)

# Generated at 2022-06-12 03:08:28.993627
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True

if __name__ == '__main__':
    args = Namespace()
    test_init_settings()

# Generated at 2022-06-12 03:08:30.110262
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-12 03:08:32.202164
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=1)
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-12 03:08:34.081072
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:44.660627
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--debug",
        type=bool,
        default=False,
        help="Bool to enable debug mode")
    args = parser.parse_args()
    assert args.debug == False
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:46.807626
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Unit tests for class Settings

# Generated at 2022-06-12 03:08:48.325603
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:49.730635
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:53.080803
# Unit test for function init_settings
def test_init_settings():
    import sys

    # Set arguments for testing function
    sys.argv = [sys.argv[0], '--debug']

    # Read arguments
    args = read_args()

    # Initialize the settings
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:08:56.809561
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args = Namespace()
    args.debug = False 
    init_settings(args)
    assert settings.debug is False


# Generated at 2022-06-12 03:08:58.105696
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:09:01.391304
# Unit test for function init_settings
def test_init_settings():
    """
    This function test init_settings function
    """
    args = Namespace()

    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:04.311243
# Unit test for function init_settings
def test_init_settings():
    mock_args = MagicMock()
    mock_args.debug = False
    init_settings(mock_args)
    assert settings.debug == mock_args.debug
    mock_args.debug = True
    init_settings(mock_args)
    assert settings.debug == mock_args.debug

# Generated at 2022-06-12 03:09:05.739754
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:16.464270
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))

    assert settings.debug == True

# Generated at 2022-06-12 03:09:17.758964
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:21.527611
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())

    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

if __name__ == "__main__":
    init_settings(Namespace(debug=True))
    print("Settings debug mode:", settings.debug)

# Generated at 2022-06-12 03:09:23.959393
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:25.095228
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:09:26.134861
# Unit test for function init_settings
def test_init_settings():
    args = init_settings(Namespace(debug=True))
    assert args.debug is True

# Generated at 2022-06-12 03:09:27.474809
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:09:29.198602
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:32.045009
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:38.630784
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True


if __name__ == "__main__":
    parser = argparse.ArgumentParser("The script for the main app")
    parser.add_argument("-d", "--debug", help="Debug mode", action="store_true")
    args = parser.parse_args()

    if args.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    init_settings(args)

    app.run()

# Generated at 2022-06-12 03:09:59.468502
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:02.332744
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:03.858418
# Unit test for function init_settings
def test_init_settings():
    fake_args = Namespace()
    fake_args.debug = True

    init_settings(fake_args)

    assert settings.debug

# Generated at 2022-06-12 03:10:05.364652
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


# Generated at 2022-06-12 03:10:12.025282
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:10:13.089466
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:15.802988
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:17.467899
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:18.675863
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:19.747629
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:11:00.945171
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug

    class Args:
        debug = True

    init_settings(Args)

    assert settings.debug

# Generated at 2022-06-12 03:11:02.626481
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:11:04.638162
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    # debug was set to True
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    # debug was set to False
    assert settings.debug == False

# Generated at 2022-06-12 03:11:05.553181
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:07.133142
# Unit test for function init_settings
def test_init_settings():
    argparse.init_settings(Namespace(debug=True))
    assert(settings.debug)

# Generated at 2022-06-12 03:11:10.304954
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 03:11:15.413656
# Unit test for function init_settings
def test_init_settings():
    # Tests settings.debug
    args_debug_false = Namespace(debug=False)
    assert settings.debug == False
    init_settings(args_debug_false)
    assert settings.debug == False
    args_debug_true = Namespace(debug=True)
    init_settings(args_debug_true)
    assert settings.debug == True
    print("Test test_init_settings finished")

# Run test_init_settings
test_init_settings()

# Generated at 2022-06-12 03:11:18.166424
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:11:22.288347
# Unit test for function init_settings
def test_init_settings():
    class args:
        def __init__(self) -> None:
            self.debug = True
    init_settings(args)
    assert settings.debug is True
    class args:
        def __init__(self) -> None:
            self.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:11:25.736901
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', default=False, type=bool)
    args = parser.parse_args()
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-12 03:12:47.873237
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:12:48.942318
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:12:50.185115
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:12:51.350859
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:12:53.587656
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:12:57.884301
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    test_settings = Settings()
    test_settings.debug = True
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug == test_settings.debug

# Generated at 2022-06-12 03:12:59.737296
# Unit test for function init_settings
def test_init_settings():
    settings = init_settings("")
    assert settings.args.debug == False

    settings = init_settings("-d")
    assert settings.args.debug == True


# Generated at 2022-06-12 03:13:03.229285
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:13:04.321205
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:13:05.859834
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:15:51.104948
# Unit test for function init_settings
def test_init_settings():
    f = lambda args: init_settings(args)

    assert(settings.debug == False)

    args = Namespace(debug=True)
    f(args)
    assert(settings.debug == True)

    args = Namespace(debug=False)
    f(args)
    assert(settings.debug == False)

    args = Namespace()
    f(args)
    assert(settings.debug == False)

# Generated at 2022-06-12 03:15:52.753157
# Unit test for function init_settings
def test_init_settings():
    debug = True
    args = Namespace(
        debug=debug,
    )
    init_settings(args)
    assert settings.debug == debug

# Generated at 2022-06-12 03:15:54.267249
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace(debug=True)
    init_settings(namespace)
    assert settings.debug == True



# Generated at 2022-06-12 03:15:55.812895
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:15:57.760275
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(args)
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:16:00.580840
# Unit test for function init_settings
def test_init_settings():
    args = type("Namespace", (), {})
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:16:01.657967
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:16:03.011810
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-12 03:16:07.777604
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    sys.exit(0)

# Unit test
if __name__ == '__main__':
    test_init_settings()

# EOF

# Generated at 2022-06-12 03:16:09.621019
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert settings.debug is True