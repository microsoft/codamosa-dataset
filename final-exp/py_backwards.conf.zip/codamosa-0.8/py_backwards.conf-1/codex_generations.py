

# Generated at 2022-06-12 03:06:58.560613
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:07:00.345435
# Unit test for function init_settings
def test_init_settings():
    try:
        init_settings(Namespace(debug=True))
    except NameError as exc:
        raise exc
    assert settings.debug == True



# Generated at 2022-06-12 03:07:03.649942
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:07:06.323766
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:09.156789
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:12.145911
# Unit test for function init_settings
def test_init_settings():
    print("Test init_settings")
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:07:15.127027
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = False))
    assert settings.debug == False
    init_settings(Namespace(debug = True))
    assert settings.debug == True

# Generated at 2022-06-12 03:07:18.317790
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:21.955912
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug, 'Should not be in debug mode'

    init_settings(Namespace(debug=True))
    assert settings.debug, 'Should be in debug mode'

# Generated at 2022-06-12 03:07:26.933096
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:32.907505
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug
    init_settings(Namespace(debug = False))
    assert not settings.debug


if __name__ == "__main__":
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-12 03:07:34.120681
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:38.235740
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="ToDo CLI")
    parser.add_argument("--debug", action="store_true", help="Режим отладки")
    args = parser.parse_args()
    init_settings(args)
    assert(settings.debug == args.debug)
# --Unit test for function init_settings

# Generated at 2022-06-12 03:07:40.244994
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:41.426816
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug


# Generated at 2022-06-12 03:07:46.383019
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    print('Running in debug mode: {}'.format(settings.debug))

# Generated at 2022-06-12 03:07:48.122330
# Unit test for function init_settings
def test_init_settings():
    testArgs = {
        "debug": True
    }
    init_settings(testArgs)
    assert settings.debug == True


# Generated at 2022-06-12 03:07:51.732543
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=0))
    assert settings.debug == False
    init_settings(Namespace(debug=1))
    assert settings.debug == True



# Generated at 2022-06-12 03:07:55.042522
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-12 03:07:56.732199
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:05.996575
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", help="output debugging information")

    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False
    print("test_init_settings: passed")


# Generated at 2022-06-12 03:08:10.674291
# Unit test for function init_settings
def test_init_settings():
    args: Namespace = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--debug", type=bool, nargs="?", const=True, default=False)
    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-12 03:08:12.852425
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug==True
    args.debug = False
    init_settings(args)
    assert settings.debug==False

# Generated at 2022-06-12 03:08:14.925775
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    settings.debug = False

# Generated at 2022-06-12 03:08:17.872788
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:19.303340
# Unit test for function init_settings
def test_init_settings():
    args = prepare_test_args()
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:20.702360
# Unit test for function init_settings
def test_init_settings():
    arguments = Namespace(debug=True)
    init_settings(arguments)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:25.531636
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert(not settings.debug)
    init_settings(args)
    assert(not settings.debug)
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-12 03:08:28.002763
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()

    test_settings = Settings()
    test_settings.debug = True

    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:29.327039
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))

    assert settings.debug == True
    assert settings.debug != False

# Generated at 2022-06-12 03:08:41.794493
# Unit test for function init_settings
def test_init_settings():
    _args = Namespace(debug=True)
    init_settings(_args)
    if not settings.debug:
        assert False

# Generated at 2022-06-12 03:08:43.971521
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace(debug=True)
    init_settings(mock_args)
    assert settings.debug == True



# Generated at 2022-06-12 03:08:45.997634
# Unit test for function init_settings
def test_init_settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug == True
    init_settings(args=Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-12 03:08:48.516157
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:48.991769
# Unit test for function init_settings
def test_init_settings():
    pass

# Generated at 2022-06-12 03:08:50.774692
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True,
                     verbose=False)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:08:53.459600
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:54.995357
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:56.953434
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:58.506519
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:10.575222
# Unit test for function init_settings
def test_init_settings():
    namespaces = Namespace(debug=True)
    init_settings(namespaces)
    assert settings.debug
    assert settings.debug == True

# Generated at 2022-06-12 03:09:12.014360
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
# End Unit test for function init_settings

# Generated at 2022-06-12 03:09:12.998876
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:14.978503
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:18.953389
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-12 03:09:20.419678
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:24.088876
# Unit test for function init_settings
def test_init_settings():
    # Test if the debug mode is initiated correctly.
    arg = Namespace(debug=True)
    init_settings(arg)
    assert settings.debug == True
    # Test if the debug mode is initiated correctly.
    arg = Namespace(debug=False)
    init_settings(arg)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:26.254756
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:27.960980
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:33.691528
# Unit test for function init_settings
def test_init_settings():
    # Case 1: Argument namespace contains debug=False
    args_false = Namespace(debug=False)
    init_settings(args_false)
    # verify debug is False
    assert settings.debug == args_false.debug
    # Case 2: Argument namespace contains debug=True
    args_true = Namespace(debug=True)
    init_settings(args_true)
    # verify debug is True
    assert settings.debug == args_true.debug

test_init_settings()

# Generated at 2022-06-12 03:09:55.633023
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:57.925820
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.get_debug() == False
    args.debug = True
    init_settings(args)
    assert settings.get_debug() == True

# Generated at 2022-06-12 03:10:00.279023
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:03.010355
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:04.216797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:08.149773
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True, use_gpu=True,
                          min_loss_diff=0.03, loss_threshold=0.25)
    init_settings(test_args)

    assert settings.debug


# Generated at 2022-06-12 03:10:10.684528
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    assert settings.debug == False

    # Check that it's working on a real dict
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:12.869836
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:14.411198
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug is True

# Generated at 2022-06-12 03:10:16.297835
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:10:59.512394
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:11:00.861980
# Unit test for function init_settings
def test_init_settings():
    vargs = Namespace(debug=True)
    init_settings(vargs)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:01.920079
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:11:03.786844
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

test_init_settings()

# Generated at 2022-06-12 03:11:05.250353
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-12 03:11:05.993658
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

# Generated at 2022-06-12 03:11:06.887045
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:11:07.754464
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:10.304905
# Unit test for function init_settings
def test_init_settings():
    """
    Test whether the settings object is correctly made in function init_settings()
    """
    global settings
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:11:12.049095
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug

import sys


# Generated at 2022-06-12 03:12:43.339788
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-12 03:12:46.170886
# Unit test for function init_settings
def test_init_settings():
    # Test if setting is set to true when debug is true
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    # Test if setting is set to false when debug is false
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-12 03:12:48.117525
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:12:49.401425
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug


# Run tests
test_init_settings()

# Generated at 2022-06-12 03:12:52.847249
# Unit test for function init_settings
def test_init_settings():
    class TestArgumentParser(argparse.ArgumentParser):
        args = []

        def parse_known_args(self, *args, **kwargs):
            return self, self.args

    args = TestArgumentParser()
    args.add_argument("--debug", help="Turn on debug mode.", action="store_true")

    # args.debug = False
    init_settings(args)
    assert not settings.debug

    # args.debug = True
    args.args = ["--debug"]
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:12:54.543933
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert not settings.debug
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:12:57.228166
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:12:59.790300
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:13:02.285281
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:13:03.875463
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


# Generated at 2022-06-12 03:15:58.875471
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:16:01.323135
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    print(settings.debug)

# Generated at 2022-06-12 03:16:02.890838
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug



# Generated at 2022-06-12 03:16:06.749768
# Unit test for function init_settings
def test_init_settings():
    args_list = [Namespace(debug=False), Namespace(debug=True)]
    for args in args_list:
        init_settings(args)
        assert settings.debug is args.debug

# Generated at 2022-06-12 03:16:09.087083
# Unit test for function init_settings
def test_init_settings():
    """Test function init_settings"""
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:16:11.270504
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:16:13.769250
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:16:15.487192
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:16:16.832156
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug

    args = Namespace(debug=False)

    init_settings(args)

    assert not settings.debug

# Generated at 2022-06-12 03:16:18.159632
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug
