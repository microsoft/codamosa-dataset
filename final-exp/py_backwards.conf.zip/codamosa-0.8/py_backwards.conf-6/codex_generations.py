

# Generated at 2022-06-12 03:06:46.279161
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:06:52.532819
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:06:59.149531
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:02.915614
# Unit test for function init_settings
def test_init_settings():
    # Setup
    args = Namespace(debug=True)

    # Expected result
    settings.debug = True

    # Testing
    init_settings(args)

    # Assertion
    assert settings.debug == True



# Generated at 2022-06-12 03:07:11.581238
# Unit test for function init_settings
def test_init_settings():
    # Setup
    args = Namespace()
    args.debug = True
    
    # Test
    init_settings(args)
    
    # Verify
    assert settings.debug

if __name__ == '__main__':
    args = argparse.ArgumentParser(description='A script to create a ukulele tab from a MIDI file')
    args.add_argument('--debug', action='store_true', help='Print debug messages')
    
    args = args.parse_args()
    init_settings(args)
    
    print(settings.debug)

# Generated at 2022-06-12 03:07:13.240591
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == args.debug)

# Generated at 2022-06-12 03:07:18.807207
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(
        mode='test',
        length=10,
        count=10,
        charset='ABC',
        filename='some.txt',
        debug=True
    )
    init_settings(test_args)
    if settings.debug:
        print("OK")

# Generated at 2022-06-12 03:07:20.320806
# Unit test for function init_settings
def test_init_settings():
    for _ in range(10):
        _args = Mock()
        _args.debug = random.choice([True, False])

        init_settings(_args)
        assert settings.debug == _args.debug


# Generated at 2022-06-12 03:07:21.627033
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:26.519735
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace()
    namespace.debug = True
    init_settings(namespace)
    assert settings.debug

# Generated at 2022-06-12 03:07:30.364778
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:31.371442
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:32.437299
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:07:33.903326
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-12 03:07:35.203769
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:07:37.947596
# Unit test for function init_settings
def test_init_settings():
    x = Namespace(debug = True)
    init_settings(x)
    assert settings.debug == True
    y = Namespace(debug = False)
    init_settings(y)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:39.661699
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-12 03:07:40.814340
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:42.943423
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = True
    init_settings(args)
    assert settings.debug

    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:07:45.341154
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:54.567330
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

    args.debug = False
    init_settings(args)
    assert not settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:07:56.109425
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:58.100540
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:08:00.160534
# Unit test for function init_settings
def test_init_settings():

    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:08:01.844041
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:08:05.370068
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:09.680912
# Unit test for function init_settings
def test_init_settings():
    args_cls = namedtuple('args', ['debug'])
    args = args_cls(debug=False)
    init_settings(args)
    assert not settings.debug
    args = args_cls(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:11.738451
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-12 03:08:13.125988
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:13.793218
# Unit test for function init_settings
def test_init_settings():
    assert False

# Generated at 2022-06-12 03:08:19.836613
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:21.412629
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:24.734432
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:26.449069
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:28.463081
# Unit test for function init_settings
def test_init_settings():
    ns = Namespace(debug=True)
    init_settings(ns)
    assert settings.debug == True

    ns = Namespace(debug=False)
    init_settings(ns)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:30.489591
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:33.013874
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:08:34.433145
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:38.403294
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    import pytest
    pytest.main(["-v", "-s", __file__])

# Generated at 2022-06-12 03:08:40.080176
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:51.581648
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    assert settings.debug == False

if __name__ == "__main__":
    test_init_settings()



# Generated at 2022-06-12 03:08:53.323100
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:56.809211
# Unit test for function init_settings
def test_init_settings():
    type(settings).debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:08:59.908830
# Unit test for function init_settings
def test_init_settings():
    args = type('', (object,), {'debug': True})()
    init_settings(args)
    assert settings.debug
    args = type('', (object,), {'debug': False})()
    init_settings(args)
    assert not settings.debug

# Unit test

# Generated at 2022-06-12 03:09:01.944921
# Unit test for function init_settings
def test_init_settings():
    unittest.mock

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-12 03:09:03.242140
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:04.470173
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:05.653143
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:06.937259
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:09:08.819108
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:32.280278
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


if __name__ == '__main__':
    args = Namespace()
    args.debug = True
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-12 03:09:34.331086
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:35.914146
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-12 03:09:38.863516
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 03:09:40.874319
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug is False

    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:44.935602
# Unit test for function init_settings
def test_init_settings():
    print("testing function init_settings")
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", help="enable debug logging")
    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-12 03:09:52.370812
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true', help='Print debug level logs')
    args = parser.parse_args()
    init_settings(args)

    # Create the server, binding to localhost on port 9999
    logging.info('Creating the server')
    server = socketserver.TCPServer(('', 9999), MyTCPHandler)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    logging.info('Serving forever')

# Generated at 2022-06-12 03:09:54.141471
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:09:55.538715
# Unit test for function init_settings
def test_init_settings():
    """Check if all settings are initialized properly"""
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:09:56.826694
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:39.576057
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    assert settings.debug != False


# Generated at 2022-06-12 03:10:41.020074
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args = args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:43.419409
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:10:50.746722
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Solution to puzzle #1 (https://adventofcode.com/2017/day/1)"
    )
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)

    # Read puzzle input
    with open("puzzle01_1.input.txt") as f:
        puzzle_input = f.readline().strip()
    if settings.debug:
        puzzle_input = "1122"

    # Solve puzzle
    puzzle_result = 0

# Generated at 2022-06-12 03:10:54.002019
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:55.721139
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug



# Generated at 2022-06-12 03:10:57.913910
# Unit test for function init_settings
def test_init_settings():
    from unittest import TestCase

    with TestCase().assertRaises(SystemExit):
        init_settings(Namespace())

    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:10:59.247825
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:11:01.244735
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:11:02.495142
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-12 03:12:24.033261
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:12:24.952821
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

# Generated at 2022-06-12 03:12:28.957804
# Unit test for function init_settings
def test_init_settings():
    #tests if the function init_settings will set settings.debug to True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

test_init_settings()



# Generated at 2022-06-12 03:12:30.959866
# Unit test for function init_settings
def test_init_settings():
    parser = create_parser()
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:12:33.231515
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-12 03:12:36.083048
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:12:38.201582
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    
    

# Generated at 2022-06-12 03:12:41.299526
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:12:43.787119
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import Mock
    init_settings(Mock())
    assert isinstance(settings, Settings)
    assert isinstance(settings.debug, bool)

# Function main

# Generated at 2022-06-12 03:12:45.904970
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace(debug=True)

    # Act
    init_settings(args)

    # Assert
    assert settings.debug == True

# Generated at 2022-06-12 03:15:26.662075
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:15:30.813805
# Unit test for function init_settings
def test_init_settings():
    import unittest

    class InitSettingsTest(unittest.TestCase):
        def test_init_settings(self):
            self.assertFalse(settings.debug)

    args = Namespace()
    args.debug = True
    init_settings(args)
    self.assertTrue(settings.debug)



# Generated at 2022-06-12 03:15:34.707946
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()
    print(settings.debug)

# Generated at 2022-06-12 03:15:36.511690
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:15:37.607949
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(NameSpace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:15:40.286541
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not settings.debug

# Generated at 2022-06-12 03:15:41.852928
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:15:43.484392
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:15:44.793214
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:15:46.288234
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
