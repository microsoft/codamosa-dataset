

# Generated at 2022-06-12 03:06:46.278792
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    check = settings.debug
    assert check == True
    
if __name__ == "__main__":
    init_settings()

# Generated at 2022-06-12 03:06:52.532549
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:06:54.376765
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:06:59.685412
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:07:02.474909
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:04.239404
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:07.962664
# Unit test for function init_settings
def test_init_settings():
    global settings

    args = Namespace()
    args.debug = False
    settings = Settings()
    init_settings(args)
    assert not settings.debug

    args.debug = True
    settings = Settings()
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:13.985624
# Unit test for function init_settings
def test_init_settings():
    # Test --debug mode
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

    # Test without debug mode
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:17.611722
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-12 03:07:20.909797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:28.110963
# Unit test for function init_settings
def test_init_settings():
    from unittest import mock
    from tempfile import NamedTemporaryFile
    from shutil import copy

    args = mock.MagicMock()
    for debug in [True, False]:
        args.debug = debug
        init_settings(args)
        assert settings.debug == debug



# Generated at 2022-06-12 03:07:29.829609
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-12 03:07:31.497371
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:32.549696
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:33.778719
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:36.398103
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:42.773393
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-12 03:07:45.134643
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:50.265644
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert settings.debug == True

# Generated at 2022-06-12 03:07:54.647027
# Unit test for function init_settings
def test_init_settings():
    #test debug is False as default
    init_settings(argparse.Namespace(**{}))
    assert not settings.debug
    #test debug is True when debug is set to True
    init_settings(argparse.Namespace(**{'debug': True}))
    assert settings.debug

# Generated at 2022-06-12 03:08:05.333515
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace())
    assert settings.debug == False
    init_settings(Namespace(debug=0))
    assert settings.debug == False
    init_settings(Namespace(debug=1))
    assert settings.debug == True

# Generated at 2022-06-12 03:08:07.440950
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace(debug=True)
    init_settings(mock_args)

    assert settings.debug == True



# Generated at 2022-06-12 03:08:09.843519
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    settings.debug = False



# Generated at 2022-06-12 03:08:11.855619
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    assert hasattr(args, 'debug')
    assert args.debug == True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:19.764272
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# First test the unit test
test_init_settings()

# Then the application
parser = argparse.ArgumentParser()
parser.add_argument("-d", "--debug", action="store_true", help="run in debug mode")
args = parser.parse_args()
init_settings(args)

# Since the command line argument not used, settings.debug will be False by default
print(settings.debug)

# Run the app as
# $ main.py -d
# True

# Generated at 2022-06-12 03:08:24.559079
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', default=False,
                        help='Debug mode')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:08:30.217748
# Unit test for function init_settings
def test_init_settings():
    #Given
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    #When
    init_settings(args)
    #Then
    assert settings.debug == False

    #Given
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--debug", action="store_true")
    args = parser.parse_args("--debug".split())

    #When
    init_settings(args)
    #Then
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-12 03:08:33.384541
# Unit test for function init_settings
def test_init_settings():
    args = {'debug': False}
    init_settings(args)
    assert not args.debug

args = {'debug': None}
init_settings(args)
assert args.debug

# Generated at 2022-06-12 03:08:37.005444
# Unit test for function init_settings
def test_init_settings():
    args = mock.Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:08:38.920762
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# run unit test
test_init_settings()

# Generated at 2022-06-12 03:08:50.492195
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:52.319460
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:08:53.824452
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:55.371487
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:57.839456
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True, "Debug should have been set to True"

init_settings(Namespace(debug=True))

# Generated at 2022-06-12 03:09:01.105983
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-12 03:09:03.207400
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:05.213023
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:09:06.496060
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:09:08.670221
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    # check if debug is set
    args.debug = True
    init_settings(args)
    assert settings.debug

    # check if debug is unset
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:09:33.269079
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    # Confirm default
    assert not settings.debug

    # Confirm init_settings() set debug setting
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:34.613111
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:36.218791
# Unit test for function init_settings
def test_init_settings():
    args = type('args', (object,), {'debug': True})()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:39.993297
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug, "debug should be Falses"

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, "debug should be True"

test_init_settings()

# Generated at 2022-06-12 03:09:41.277468
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:09:44.303974
# Unit test for function init_settings
def test_init_settings():
    argv = sys.argv
    sys.argv = ["asdf", "--debug"]
    args = parse_args()
    assert args.debug == True
    init_settings(args)
    assert settings.debug == True
    sys.argv = argv

# Generated at 2022-06-12 03:09:46.211729
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:09:48.884339
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = False
    init_settings(test_args)
    assert settings.debug is test_args.debug
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug is test_args.debug

# Generated at 2022-06-12 03:09:51.226789
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    args2 = Namespace(debug=True)
    init_settings(args1)
    assert settings.debug == False
    init_settings(args2)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:54.326914
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    print("Running settings.py with doctests")
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 03:10:39.795492
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-12 03:10:43.419499
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Unit testing for the class Settings

# Generated at 2022-06-12 03:10:44.883898
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:46.585369
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-12 03:10:49.926723
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)
    args = Namespace(debug=False)
    init_settings(args)
    assert(settings.debug == False)


if __name__ == "__main__":
    args = Namespace(debug=True)
    init_settings(args)

# Generated at 2022-06-12 03:10:51.587360
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    
    init_settings(args)
    assert settings.debug == False
    
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:54.483405
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:55.532664
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:57.497665
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:58.621161
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:24.560617
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:25.815201
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-12 03:12:27.916121
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:29.169534
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:12:31.459573
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:12:32.809052
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:37.223332
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug

    args = Namespace()
    init_settings(args)
    assert not settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Run unittest
if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:12:38.401723
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert True == settings.debug

# Generated at 2022-06-12 03:12:40.412582
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug, "debug should be True"

# Generated at 2022-06-12 03:12:42.207973
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-12 03:15:36.776547
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:15:38.230380
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True,
    )

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:15:40.498830
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:15:42.059210
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True



# Generated at 2022-06-12 03:15:44.827381
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-12 03:15:46.022174
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-12 03:15:47.672113
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:15:48.866797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:15:50.930894
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:15:51.847806
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug