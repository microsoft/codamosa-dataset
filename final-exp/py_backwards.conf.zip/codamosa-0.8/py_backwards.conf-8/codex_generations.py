

# Generated at 2022-06-12 03:07:06.248748
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

test_init_settings()

# Generated at 2022-06-12 03:07:10.903070
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Start program
if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-12 03:07:12.839991
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    print ('test init_settings passed')

test_init_settings()

# Generated at 2022-06-12 03:07:15.361905
# Unit test for function init_settings
def test_init_settings():
    args = mock.Mock()
    args.debug = True

    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:20.991242
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:23.257673
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:26.965096
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:28.485422
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert setti

# Generated at 2022-06-12 03:07:32.528954
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:33.745709
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:38.615935
# Unit test for function init_settings
def test_init_settings():
    # Test if not given args
    original_settings = deepcopy(settings)
    init_settings(Namespace())
    assert settings == original_settings
    # Test given args, debug=True
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:07:39.800896
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:43.511030
# Unit test for function init_settings
def test_init_settings():
	class FakeArgs(argparse.Namespace):
		def __init__(self, debug:bool):
			self.debug = debug
			
	args1 = FakeArgs(False)
	args2 = FakeArgs(True)
	
	init_settings(args1)
	if settings.debug == True:
		print("init_settings: FAILED -- setting incorrect value for debug")
		exit(-1)
		
	init_settings(args2)
	if settings.debug == False:
		print("init_settings: FAILED -- setting incorrect value for debug")
		exit(-1)

# Generated at 2022-06-12 03:07:46.519290
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:07:49.087925
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', dest='debug', action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:50.711625
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_settings(args)

    assert settings.debug



# Generated at 2022-06-12 03:07:54.386370
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:57.487517
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:08:00.120189
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == test_args.debug

# Generated at 2022-06-12 03:08:04.809536
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    #Case 1
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    #Case 2
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

test_init_settings()

# Generated at 2022-06-12 03:08:11.708942
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    args.quiet = False

    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-12 03:08:13.091049
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:14.855932
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:17.793274
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:20.129581
# Unit test for function init_settings
def test_init_settings():
    # Given
    class MockArgs:
        def __init__(self):
            self.debug = True

    # When
    init_settings(MockArgs())

    # Then
    assert settings.debug == True

# Generated at 2022-06-12 03:08:24.637433
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False


    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:26.005522
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-12 03:08:28.373431
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    if settings.debug == False:
        print('test init_settings() Pass')
    else:
        print('test init_settings() Fail')


# Generated at 2022-06-12 03:08:30.041157
# Unit test for function init_settings
def test_init_settings():
    # arrange
    args = Namespace(
        debug=True
    )

    # act
    init_settings(args)

    # assert
    assert settings.debug == True

# Generated at 2022-06-12 03:08:38.170818
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    args.database_uri = "unit_test_database"
    args.host = "unit_test_host"
    args.port = 12345
    args.redis_uri = "unit_test_redis"

    init_settings(args)
    assert settings.debug is True
    assert settings.database_uri == "unit_test_database"
    assert settings.host == "unit_test_host"
    assert settings.port == 12345
    assert settings.redis_uri == "unit_test_redis"



# Generated at 2022-06-12 03:08:50.111139
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Unit tests
# TODO: Write more unit tests

# Generated at 2022-06-12 03:08:51.868601
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:54.012668
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    print(settings.debug)
    assert settings.debug

test_init_settings()

# Generated at 2022-06-12 03:08:57.341731
# Unit test for function init_settings
def test_init_settings():
    # Testing debug False
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

    # Testing debug True
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:08:58.659910
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:02.141568
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:03.752526
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

    args = Namespace(
        debug=True
    )
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-12 03:09:05.712247
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:07.019888
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-12 03:09:08.321255
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-12 03:09:32.084304
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    import sys
    import pytest

    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-12 03:09:33.943696
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:35.241801
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:09:37.856458
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:09:40.976893
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-12 03:09:44.016323
# Unit test for function init_settings
def test_init_settings():
    args_test1 = Namespace(debug=True)
    args_test2 = Namespace(debug=False)
    init_settings(args_test1)
    assert (settings.debug == True)
    init_settings(args_test2)
    assert (settings.debug == False)

# Generated at 2022-06-12 03:09:45.215463
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)


# Generated at 2022-06-12 03:09:47.942791
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert True == settings.debug
    
    
    
    
    
    
    
    
    



# Generated at 2022-06-12 03:09:50.062705
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=False))
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-12 03:09:52.226827
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-12 03:10:33.518236
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:10:35.967057
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    args2 = Namespace(debug=True)
    init_settings(args1)
    init_settings(args2)
    assert settings.debug is True

test_init_settings()

# Generated at 2022-06-12 03:10:38.618399
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-12 03:10:39.997501
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:41.765108
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:43.284694
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:44.846961
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:10:46.551454
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:10:47.721499
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:10:49.866649
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=1)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=0)
    init_settings(args)
    assert settings.debug == False
    return

# Generated at 2022-06-12 03:12:13.042757
# Unit test for function init_settings
def test_init_settings():
    args = Namespace();
    args.debug = True;

    init_settings(args)

    assert settings.debug == True
    assert args.debug == True

# Generated at 2022-06-12 03:12:15.417043
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-12 03:12:17.868917
# Unit test for function init_settings
def test_init_settings():
    command_args = Namespace(debug=True)
    init_settings(command_args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:20.384411
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': False})
    init_settings(args)
    assert settings.debug == False
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:22.318876
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:23.550737
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:24.952333
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:12:29.952866
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    settings.debug = False
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TODO')
    parser.add_argument('-d', '--debug', action='store_true', help='Debug mode')

    args = parser.parse_args()
    init_settings(args)

    sys.exit(0)

# Generated at 2022-06-12 03:12:31.603525
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:12:34.304888
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

