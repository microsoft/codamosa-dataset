

# Generated at 2022-06-12 03:06:52.774384
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    eq_(True, settings.debug)

# Generated at 2022-06-12 03:06:58.209648
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:06:59.487579
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:02.284268
# Unit test for function init_settings
def test_init_settings():
    test = Namespace(debug=True)
    init_settings(test)
    assert settings.debug is True

# Generated at 2022-06-12 03:07:04.694724
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert se

# Generated at 2022-06-12 03:07:06.438392
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debu

# Generated at 2022-06-12 03:07:10.427404
# Unit test for function init_settings
def test_init_settings():
    testargs = Namespace(debug=True)
    init_settings(testargs)
    assert settings.debug

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-12 03:07:12.736204
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    init_settings(args1)
    assert settings.debug == False

    args2 = Namespace(debug=True)
    init_settings(args2)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:15.045437
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:18.217924
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(compile_all=False, debug=True, name=None, path=None))
    assert settings.debug

# Generated at 2022-06-12 03:07:21.771026
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_s

# Generated at 2022-06-12 03:07:26.640967
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug='True')
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:29.671472
# Unit test for function init_settings
def test_init_settings():
    """ Tests that the init_settings fn sets the debug var to true or false """

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-12 03:07:32.235783
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# EOF

# Generated at 2022-06-12 03:07:33.455463
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    
    init_settings(args)
    
    assert se

# Generated at 2022-06-12 03:07:34.708780
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:37.606992
# Unit test for function init_settings
def test_init_settings():
    """Test for function init_settings."""
    settings = Settings()
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:41.343371
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-12 03:07:42.969935
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-12 03:07:46.677404
# Unit test for function init_settings
def test_init_settings():
    args_debug = Namespace(debug=True)
    init_settings(args_debug)
    assert settings.debug == True

    args_not_debug = Namespace(debug=False)
    init_settings(args_not_debug)
    assert settings.debug == False

# Generated at 2022-06-12 03:07:54.534354
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-12 03:07:56.068933
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-12 03:07:57.488869
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:07:58.518684
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-12 03:08:00.647873
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-12 03:08:06.945573
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    # Set up command line arguments
    parser = argparse.ArgumentParser(description="Controls the behavior of the application")
    parser.add_argument("--debug", help="Turn on debug mode", default=False, action="store_true")
    args = parser.parse_args()

    init_settings(args)

# Generated at 2022-06-12 03:08:10.004961
# Unit test for function init_settings
def test_init_settings():
    a = Namespace()
    a.debug = True
    init_settings(a)
    assert settings.debug
    a.debug = False
    init_settings(a)
    assert not settings.debug

# Generated at 2022-06-12 03:08:11.951489
# Unit test for function init_settings
def test_init_settings():
    d = {'debug': True}
    args = Namespace(**d)
    init_settings(args)
    assert settings.debug == True, 'debug mode should be true'



# Generated at 2022-06-12 03:08:16.852050
# Unit test for function init_settings
def test_init_settings():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        args = Namespace(debug=False)
        init_settings(args=args)

        assert settings.debug == False

        args = Namespace(debug=True)
        init_settings(args=args)

        assert settings.debug == True

# Generated at 2022-06-12 03:08:19.117088
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import Mock
    # The module namespace is set to a mock instance
    init_settings(Mock(debug=True))
    assert settings.debug