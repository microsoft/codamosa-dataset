

# Generated at 2022-06-21 17:12:53.638995
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:12:56.142853
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-21 17:12:57.954801
# Unit test for constructor of class Settings
def test_Settings():
    # init settings with no arguments
    settings = Settings()
    # Assert that the settings are set to default values
  

# Generated at 2022-06-21 17:12:59.474811
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:01.108855
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:13:04.029126
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:05.468725
# Unit test for function init_settings
def test_init_settings():
    # TODO implement unit test
    pass

# Generated at 2022-06-21 17:13:06.657933
# Unit test for constructor of class Settings
def test_Settings():
    assert settings != None

# Generated at 2022-06-21 17:13:07.383073
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:08.983618
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-21 17:13:13.433793
# Unit test for function init_settings
def test_init_settings():
    """
    Test function init_settings
    """
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-21 17:13:14.291934
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None, 'No instance created for settings!'

# Generated at 2022-06-21 17:13:15.517144
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.debug == False


# Generated at 2022-06-21 17:13:17.076128
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:18.524546
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:13:19.769638
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:21.277710
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Unit tests for init_settings()

# Generated at 2022-06-21 17:13:22.335152
# Unit test for constructor of class Settings
def test_Settings():
    result = Settings()
    assert result.debug == False



# Generated at 2022-06-21 17:13:23.705189
# Unit test for function init_settings
def test_init_settings():
    # Test init_settings with default None
    init_settings(None)
    assert settings.debug is False



# Generated at 2022-06-21 17:13:24.475619
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:27.589984
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:30.697176
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:32.622301
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:13:35.191480
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:36.854596
# Unit test for constructor of class Settings
def test_Settings():
    sample_settings = Settings()
    assert not sample_settings.debug, "Settings test failed"


# Generated at 2022-06-21 17:13:40.462584
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-21 17:13:41.857637
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False



# Generated at 2022-06-21 17:13:45.166776
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Unit test to verify if we're getting a boolean value in the init_settings function

# Generated at 2022-06-21 17:13:47.609381
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Test for function init_settings

# Generated at 2022-06-21 17:13:51.473874
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:14:01.055958
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(
        debug=True)
    init_settings(args)
    assert settings.debug == True

    args = argparse.Namespace(
        debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:02.257930
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-21 17:14:03.727477
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-21 17:14:06.144507
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:08.494993
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:14:11.176107
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:12.481329
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, True

# Generated at 2022-06-21 17:14:15.583232
# Unit test for function init_settings
def test_init_settings():
    args_true = Namespace()
    args_true.debug = True
    args_false = Namespace()
    args_false.debug = False
    init_settings(args_true)
    init_settings(args_false)
    assert settings.debug is True
    assert not settings.debug is False

#test_init_settings()

# Generated at 2022-06-21 17:14:19.172731
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace()
    mock_args.debug = True

    init_settings(mock_args)

    assert settings.debug == True

# Generated at 2022-06-21 17:14:20.632985
# Unit test for constructor of class Settings
def test_Settings():
    # Test for true
    settings = Settings()
    assert settings.debug == False

    # Test for false
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:14:32.379593
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:14:34.630253
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', default=False, help='Debug mode', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:36.873412
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:39.440963
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:14:41.775853
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:14:44.866778
# Unit test for constructor of class Settings
def test_Settings():
    test_setting = Settings()
    # Check if the setting is initialised to the right value
    assertFalse(test_setting.debug)


# Generated at 2022-06-21 17:14:47.284876
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace()
    args.debug = False

    # Act
    init_settings(args)

    # Assert
    assert settings.debug == False



# Generated at 2022-06-21 17:14:50.327444
# Unit test for function init_settings
def test_init_settings():
    argv = ["-d"]
    args = parse_args(argv)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:51.035630
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:52.965024
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-21 17:15:14.883531
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:16.482100
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert not test.debug
    assert test != None


# Generated at 2022-06-21 17:15:19.908236
# Unit test for function init_settings
def test_init_settings():
    func = init_settings
    args = argparse.Namespace()
    args.debug = True  # type: ignore
    args_debug_false = argparse.Namespace()
    args_debug_false.debug = False
    func(args)
    assert settings.debug is True
    func(args_debug_false)
    assert settings.debug is False

# Generated at 2022-06-21 17:15:22.370397
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:15:24.551754
# Unit test for constructor of class Settings
def test_Settings():
    # New Settings
    obj = Settings()
    assert obj.debug == False

# Generated at 2022-06-21 17:15:27.544317
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, "Debug was not enabled"
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug, "Debug was not disabled"


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-21 17:15:28.401830
# Unit test for constructor of class Settings
def test_Settings():
    ss = Settings()
    assert ss.debug == False


# Generated at 2022-06-21 17:15:34.804608
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:15:35.847071
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:15:36.538166
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-21 17:16:19.271603
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:16:20.859257
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:16:22.059535
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:16:24.336653
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:16:29.411218
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-21 17:16:31.733177
# Unit test for function init_settings
def test_init_settings():

    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Test for S3_Keys

# Generated at 2022-06-21 17:16:35.447758
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-21 17:16:37.863606
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:16:41.282037
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:16:45.233962
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:18:14.027725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:18:16.790465
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings
    assert settings.debug == False

# Generated at 2022-06-21 17:18:18.273908
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:18:19.614747
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:18:23.004029
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:18:25.281219
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug is False
    assert new_settings



# Generated at 2022-06-21 17:18:27.158737
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-21 17:18:28.464475
# Unit test for constructor of class Settings
def test_Settings():
    res = Settings()
    assert res.debug == False

# Generated at 2022-06-21 17:18:32.268850
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert settings.debug != False
    assert settings.debug is not False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug != True
    assert settings.debug == False
    assert settings.debug is False


test_init_settings()

# Generated at 2022-06-21 17:18:34.584839
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-21 17:21:35.184129
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-21 17:21:40.462820
# Unit test for function init_settings
def test_init_settings():

    # Test case 1
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug != True

    # Test case 2
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:21:42.691376
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:21:44.215050
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:21:46.362189
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:21:50.953897
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    init_settings(Namespace(debug = True))
    assert settings.debug == True

    init_settings(Namespace(debug = False))
    assert settings.debug == False

# Generated at 2022-06-21 17:21:53.534925
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:21:54.828546
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:21:56.127487
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:21:58.806583
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings
    assert new_settings.debug == False