

# Generated at 2022-06-21 17:12:56.074167
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

test_init_settings()

# Generated at 2022-06-21 17:12:57.374709
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:12:59.084237
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:13:02.707161
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:08.189604
# Unit test for function init_settings
def test_init_settings():
    class TestArgs:
        debug = False

    test_args = TestArgs()
    init_settings(test_args)
    assert not settings.debug

    test_args.debug = True
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-21 17:13:09.982366
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s
    assert not s.debug


# Generated at 2022-06-21 17:13:15.350279
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="JSON-RPC Proxy")
    parser.add_argument("-d", "--debug", action="store_true", help="Debug mode")
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == args.debug
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-21 17:13:16.523617
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:13:17.947298
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False # test for whether or not the value of debug is False


# Generated at 2022-06-21 17:13:19.184325
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:24.414836
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange
    settings_test = Settings()
    # Act
    # Assert
    assert settings_test.debug == False
    # Setters
    settings_test.debug = True
    # Assert
    assert settings_test.debug == True

# Generated at 2022-06-21 17:13:30.040397
# Unit test for function init_settings
def test_init_settings():
    argv = ["test.py", "-d"]
    args = parse_args(argv=argv)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:13:33.698057
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args=Namespace(debug=True)
    init_settings(args)
    assert settings.debug
# Calling the function to run tests
test_init_settings()

# Generated at 2022-06-21 17:13:34.513444
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:36.298162
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:38.811276
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:41.159966
# Unit test for function init_settings
def test_init_settings():
    arguments = Namespace(debug='True')
    init_settings(arguments)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:42.699182
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-21 17:13:44.674724
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:48.629382
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Logging


# Generated at 2022-06-21 17:13:53.296357
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:56.392591
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s is not None
    assert settings.debug == False


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-21 17:14:00.960170
# Unit test for function init_settings
def test_init_settings():
    args_for_func = Namespace(debug=True)
    init_settings(args_for_func)
    assert settings.debug == True
    args_for_func = Namespace(debug=False)
    init_settings(args_for_func)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:02.177343
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:14:04.912383
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:06.517311
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(not settings.debug)


# Generated at 2022-06-21 17:14:07.767334
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:12.674476
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug
    print("test_init_settings OK")


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:14:14.480106
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    # Testing for debug setting
    settings.debug = settings.debug is False
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-21 17:14:15.889577
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-21 17:14:21.676105
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:24.046252
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:25.867375
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-21 17:14:28.721911
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:29.726035
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:33.726046
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:14:34.363048
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:14:35.027553
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:40.217166
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False

    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:42.930331
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not (None)

# Unit tests for init_settings method

# Generated at 2022-06-21 17:14:55.516148
# Unit test for constructor of class Settings
def test_Settings():
    settings_instance = Settings()
    assert settings_instance.debug == False

# Generated at 2022-06-21 17:14:56.574600
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-21 17:15:00.578411
# Unit test for constructor of class Settings
def test_Settings():
    # create Settings object
    settings = Settings()
    
    # check if object was created correctly
    assert settings.debug == False
    
    

# Generated at 2022-06-21 17:15:03.148635
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = 1
    init_settings(args)

    assert(settings.debug == True)

# Generated at 2022-06-21 17:15:07.503733
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    
    
if __name__ == '__main__':
    print("Unit test for function init_settings")
    test_init_settings()
    print("Done")

# Generated at 2022-06-21 17:15:11.595955
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:15:12.899998
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:15:16.027543
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:15:17.183677
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-21 17:15:18.265239
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Test for init_settings method

# Generated at 2022-06-21 17:15:40.389010
# Unit test for constructor of class Settings
def test_Settings():
    ss = Settings()
    assert ss.debug == False


# Generated at 2022-06-21 17:15:43.326037
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True


# Generated at 2022-06-21 17:15:45.240049
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-21 17:15:47.478973
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is not None
    settings.debug = None
    assert settings.debug is None

# Generated at 2022-06-21 17:15:51.030711
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:57.941336
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False, "Expected False, got {0}".format(settings.debug)
    init_settings(Namespace(debug=True))
    assert settings.debug == True, "Expected True, got {0}".format(settings.debug)

# Generated at 2022-06-21 17:15:58.685670
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    Debug.settings_debug(settings)

# Generated at 2022-06-21 17:16:01.793741
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:03.456803
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug ==  False


# Generated at 2022-06-21 17:16:04.997218
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-21 17:16:48.226130
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:51.386438
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:53.235006
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:16:56.707655
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:58.018089
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-21 17:17:02.067694
# Unit test for constructor of class Settings
def test_Settings():
    # Create settings object
    settings = Settings()

    # Check default value of debug is False
    assert(settings.debug == False)


# Generated at 2022-06-21 17:17:05.637105
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert isinstance(args, Namespace)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:17:08.610685
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:17:10.951142
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:17:12.174297
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:18:39.404325
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)

    assert settings.debug is False

# Generated at 2022-06-21 17:18:41.633414
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert type(settings) is Settings


# Generated at 2022-06-21 17:18:46.923322
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug


if __name__ == '__main__':
    import pytest

    pytest.main(['-xrf'])

# Generated at 2022-06-21 17:18:51.410374
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-21 17:18:52.127305
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:18:55.877553
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace()
    namespace.debug = True
    init_settings(namespace)
    assert settings.debug == True

# Generated at 2022-06-21 17:18:57.556167
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:19:00.810222
# Unit test for function init_settings
def test_init_settings():
    assert(not settings.debug)
    init_settings(Namespace(debug = True))
    assert(settings.debug)

# Generated at 2022-06-21 17:19:02.875093
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None
    assert settings.debug is False


# Generated at 2022-06-21 17:19:06.213480
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert isinstance(settings.debug, bool)
    assert settings.debug == True


# Generated at 2022-06-21 17:22:01.755209
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:22:02.890862
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:22:04.206932
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:22:05.386287
# Unit test for constructor of class Settings
def test_Settings():
    expected = Settings()
    assert expected.debug == False

# Generated at 2022-06-21 17:22:08.030490
# Unit test for constructor of class Settings
def test_Settings():
    print("Unit test for constructor of class Settings")
    s = Settings()
    assert not s.debug
    print("Unit test passed")


# Generated at 2022-06-21 17:22:09.126442
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:22:12.205138
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-21 17:22:14.220481
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-21 17:22:16.995161
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    

# Generated at 2022-06-21 17:22:21.301680
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    arg_settings = parser.parse_args()

    init_settings(arg_settings)
    assert settings.debug == arg_settings.debug