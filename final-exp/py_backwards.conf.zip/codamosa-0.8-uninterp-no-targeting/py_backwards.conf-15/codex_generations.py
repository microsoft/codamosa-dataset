

# Generated at 2022-06-21 17:12:54.850026
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:12:58.789922
# Unit test for function init_settings
def test_init_settings():
    # Set args.debug = True
    init_settings(Namespace(debug = True))
    # Check settings.debug = True
    assert settings.debug == True

    # Set args.debug = False
    init_settings(Namespace(debug = False))
    # Check settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-21 17:13:01.108853
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:04.641686
# Unit test for constructor of class Settings
def test_Settings():
    # Initialize Settings
    settings = Settings()

    # Check if the expected value is correct
    assert settings.debug == False


# Generated at 2022-06-21 17:13:09.131747
# Unit test for function init_settings
def test_init_settings():
    settings.debug = True
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:13:11.586920
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:12.727526
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:13:13.653355
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:16.256964
# Unit test for function init_settings
def test_init_settings():
    settings.debug=False
    init_settings(Namespace(debug=True))
    assert settings.debug
    settings.debug=True
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-21 17:13:18.593396
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:21.521070
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:22.311353
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings()


# Generated at 2022-06-21 17:13:23.672686
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, "should be True"

# Generated at 2022-06-21 17:13:25.454750
# Unit test for constructor of class Settings
def test_Settings():
    from unittest import TestCase
    from unittest.mock import Mock
    settings = Settings()
    tc = TestCase()
    assert not settings.debug



# Generated at 2022-06-21 17:13:28.955258
# Unit test for function init_settings
def test_init_settings():
    args = CMDArgs()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:29.716390
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:30.474605
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug


# Generated at 2022-06-21 17:13:33.546399
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:35.872278
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:38.674397
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug==False

# Generated at 2022-06-21 17:13:44.257553
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace()
    mock_args.debug = True
    
    init_settings(mock_args)
    assert settings.debug



# Generated at 2022-06-21 17:13:47.141770
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Test for function init_settings
# Test that arguments are correctly used to initiate the global settings

# Generated at 2022-06-21 17:13:50.095689
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings()
    assert _settings.debug == False


# Generated at 2022-06-21 17:13:53.654072
# Unit test for function init_settings
def test_init_settings():
    class Args: pass
    args = Args()
    args.debug = False
    init_settings(args)
    assert(settings.debug == False)

# Generated at 2022-06-21 17:13:57.299459
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, search_paths=None)
    init_settings(args)

    assert settings.debug == True
test_init_settings()

# Generated at 2022-06-21 17:13:58.897941
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:01.645952
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

#Unit test for the function init_settings

# Generated at 2022-06-21 17:14:04.353980
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:06.144486
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert hasattr(settings, 'debug')


# Generated at 2022-06-21 17:14:07.387018
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == Settings()


# Generated at 2022-06-21 17:14:13.985959
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:15.540498
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:14:16.891051
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:14:22.291358
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    init_settings(Namespace(debug = True))
    assert settings.debug is True
    init_settings(Namespace(debug = False))
    assert settings.debug is False



# Generated at 2022-06-21 17:14:23.429436
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-21 17:14:25.470128
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:14:32.891509
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = False

    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-21 17:14:35.338619
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:36.980807
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:14:39.094248
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)

# Generated at 2022-06-21 17:14:51.093722
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-21 17:14:58.078362
# Unit test for function init_settings
def test_init_settings():
    # SETUP
    parser = argparse.ArgumentParser()
    parser.add_argument("-D", "--debug", action="store_true", dest="debug",
                        help="Set debug mode")

    # TEST
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:59.686434
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:15:01.720181
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:15:03.080506
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:05.090170
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:15:06.147049
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:15:07.009389
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:15:09.000496
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-21 17:15:14.063576
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import MagicMock
    args = MagicMock(spec=Namespace)
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:15:36.865677
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:15:38.452320
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:15:40.659674
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:15:42.458940
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(args)

test_Settings()

# Generated at 2022-06-21 17:15:43.819816
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:45.167217
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:46.147412
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_setti

# Generated at 2022-06-21 17:15:49.885903
# Unit test for function init_settings
def test_init_settings():
    mock_settings = MagicMock(spec_set=Settings)

    mock_args = Namespace()
    mock_args.debug = True

    init_settings(mock_args)

    mock_settings.init.assert_called_once()


# End unit test for init_settings


# Generated at 2022-06-21 17:15:52.654806
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-21 17:16:02.112911
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='SIH2020')
    parser.add_argument(
        '--debug', action='store_true',
        help='Debug mode. Do not close the camera after execution.')
    parser.add_argument(
        '--detector', type=str,
        help='Detector to use. Can be `best`, `haar`, or `ssd`.')
    parser.add_argument(
        '--image', type=str,
        help='An image to run detection upon.')
    parser.add_argument(
        '--video', type=int,
        help='A video stream to run detection upon.')
    args = parser

# Generated at 2022-06-21 17:16:48.827279
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False


# Generated at 2022-06-21 17:16:51.072437
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj.debug is False


# Generated at 2022-06-21 17:16:55.270381
# Unit test for function init_settings
def test_init_settings():
    argparse_namespace = argparse.Namespace(debug=True)
    init_settings(argparse_namespace)
    assert settings.debug is True

# Generated at 2022-06-21 17:16:58.779623
# Unit test for function init_settings
def test_init_settings():
    """Test the init_settings function."""

    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:17:00.968960
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-21 17:17:04.971423
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-21 17:17:08.016088
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:17:11.823773
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:17:14.640860
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug is True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:17:16.555580
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:18:50.596453
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:18:53.114527
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:18:55.702966
# Unit test for constructor of class Settings
def test_Settings():
    theFunc = Settings()
    assert theFunc.debug == False



# Generated at 2022-06-21 17:18:58.506752
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()

    assert settings1 != None
    assert settings1.debug == False


# Generated at 2022-06-21 17:18:59.973909
# Unit test for constructor of class Settings

# Generated at 2022-06-21 17:19:01.619475
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug != False

# Generated at 2022-06-21 17:19:03.779363
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False

# Generated at 2022-06-21 17:19:05.845454
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:19:08.511919
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:19:14.258364
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args()
    args.debug = True
    init_settings(args)
    assert settings.debug == True, 'Init settings function works incorrect'

# Generated at 2022-06-21 17:22:32.845431
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:22:40.069344
# Unit test for function init_settings
def test_init_settings():

    args = Namespace(debug = True)

    init_settings(args)

    assert settings.debug

    args = Namespace(debug = False)

    init_settings(args)

    assert not settings.debug

# Example from inspect.getdoc
# https://docs.python.org/3/library/inspect.html#inspect.getdoc

# Generated at 2022-06-21 17:22:48.111698
# Unit test for function init_settings
def test_init_settings():
    command_line_args = {"debug": True}
    init_settings(Namespace(**command_line_args))
    assert settings.debug == True


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)

    print(settings.debug)

# Generated at 2022-06-21 17:22:53.011390
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True


test_init_settings()