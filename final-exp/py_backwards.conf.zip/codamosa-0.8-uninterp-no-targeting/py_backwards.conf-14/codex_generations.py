

# Generated at 2022-06-21 17:12:51.368065
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:12:55.059980
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:12:56.825826
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-21 17:12:58.497779
# Unit test for constructor of class Settings
def test_Settings():
    global settings

    class TestSettings(Settings):
        def __init__(self):
            self.debug = False

    settings = TestSettings()

    assert not settings.debug



# Generated at 2022-06-21 17:13:08.705097
# Unit test for function init_settings
def test_init_settings():
    argument_parser = ArgumentParser(prog='main.py')
    argument_parser.add_argument('--debug', action='store_true',
                                 help='enable debug message (default: disabled)')
    args = argument_parser.parse_args(['--debug'])
 
    init_settings(args)
 
    assert settings.debug


# test is enabled only if debug is Falses

# Generated at 2022-06-21 17:13:09.750010
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:11.240382
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:17.546920
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true',
                        help='Debug mode')
    args = parser.parse_args()
    init_settings(args)
    app.run(debug=settings.debug, host='0.0.0.0', port=PORT)

# Generated at 2022-06-21 17:13:18.580181
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)



# Generated at 2022-06-21 17:13:19.371152
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:21.871248
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-21 17:13:24.085594
# Unit test for function init_settings
def test_init_settings():
    default = Namespace(debug=False)
    init_settings(default)
    assert settings.debug == False

    custom = Namespace(debug=True)
    init_settings(custom)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:25.304743
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:27.827698
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-21 17:13:29.181647
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    print(settings.debug)



# Generated at 2022-06-21 17:13:29.964749
# Unit test for constructor of class Settings
def test_Settings():
    S = Settings()
    assert S.debug == False



# Generated at 2022-06-21 17:13:31.331291
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:34.075677
# Unit test for function init_settings
def test_init_settings():
    args_dict = {'debug': True}
    args = Namespace(**args_dict)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:37.402457
# Unit test for function init_settings
def test_init_settings():
    parser = ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args("--debug".split())
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:13:38.941127
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
