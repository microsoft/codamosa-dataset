

# Generated at 2022-06-21 17:12:54.850680
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:12:56.505782
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:12:57.888602
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert not a.debug


# Generated at 2022-06-21 17:13:01.476102
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-21 17:13:03.806610
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-21 17:13:05.220942
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:07.034692
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:09.749238
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:13.288825
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:13:14.161489
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:16.636485
# Unit test for constructor of class Settings
def test_Settings():
    st = Settings()
    assert not st.debug



# Generated at 2022-06-21 17:13:17.444723
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:17.947561
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-21 17:13:20.925284
# Unit test for function init_settings
def test_init_settings():
    class Mock(Namespace):
        pass
        
    args = Mock()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:21.971591
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug == False


# Generated at 2022-06-21 17:13:23.247263
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:24.663024
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Unit tests for init_settings

# Generated at 2022-06-21 17:13:27.755719
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings()
    assert _settings.debug is False


# Generated at 2022-06-21 17:13:30.259076
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-21 17:13:33.336345
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug


#
# Main program
#


# Generated at 2022-06-21 17:13:39.090559
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:13:41.441872
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-21 17:13:45.169938
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:47.657014
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)
    settings.debug = True
    assert(settings.debug == True)

# Generated at 2022-06-21 17:13:50.932938
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:56.045790
# Unit test for function init_settings
def test_init_settings():
    # mock object
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False





if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="pyqdac")
    parser.add_argument("--debug", action="store_true", help="Run in debug mode.")
    args = parser.parse_args()
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-21 17:13:57.660122
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert not my_settings.debug


# Generated at 2022-06-21 17:13:58.950074
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) == Settings
    assert settings.debug == False



# Generated at 2022-06-21 17:14:00.915407
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:02.754935
# Unit test for constructor of class Settings
def test_Settings():

    class args(object):
        def __init__(self):
            self.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:10.405029
# Unit test for function init_settings
def test_init_settings():
    args = {'debug': True}
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-21 17:14:12.321700
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings is not None


# Generated at 2022-06-21 17:14:14.294502
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:14:15.294864
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-21 17:14:21.696316
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert(settings.debug == True)
    settings.debug = False
    args = Namespace(debug = False)
    init_settings(args)
    assert(settings.debug == False)

# Generated at 2022-06-21 17:14:23.601946
# Unit test for constructor of class Settings
def test_Settings():
    set1 = Settings()
    assert set1.debug == False



# Generated at 2022-06-21 17:14:25.796845
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("-d","--debug", help="Debug mode",
                        action="store_true", default=False)
    args = parser.parse_args()

    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-21 17:14:28.652063
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:31.659817
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug is False


# Generated at 2022-06-21 17:14:35.203831
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__init__':
    test_init_settings()

# Generated at 2022-06-21 17:14:46.315417
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:48.266213
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-21 17:14:50.258741
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Unit tests for initializing settings

# Generated at 2022-06-21 17:14:56.018237
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
# End unit test



# Generated at 2022-06-21 17:14:56.836527
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-21 17:14:58.887940
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:02.080136
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert not settings.debug
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:15:04.061012
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-21 17:15:05.447117
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:07.033330
# Unit test for constructor of class Settings
def test_Settings():
    # Test for valid input
    settings = Settings()
    assert settings.debug == False

    # Test for invalid input
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:15:27.631566
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:29.839342
# Unit test for function init_settings
def test_init_settings():
    # happy
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    # sad
    init_settings(Namespace(debug=False))
    assert settings.debug == False


if __name__ == '__main__':
    print('not implemented')

# Generated at 2022-06-21 17:15:30.661215
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings.debug == settings_.debug


# Generated at 2022-06-21 17:15:32.972830
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert not settings.debug
    init_settings(args)
    assert settings.debug
    settings.debug = False
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:15:33.992451
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:15:36.464985
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:38.946016
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:15:40.795408
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:15:42.659013
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:15:44.550570
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert not settings.debug