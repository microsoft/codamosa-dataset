

# Generated at 2022-06-21 17:12:50.936189
# Unit test for function init_settings
def test_init_settings():
    setup()
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:12:52.350984
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:12:57.534022
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug


# init_settings test
test_init_settings()

# Generated at 2022-06-21 17:12:58.578156
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-21 17:13:02.184521
# Unit test for function init_settings
def test_init_settings():
    print(settings.debug)
    init_settings(Namespace(debug=True))
    print(settings.debug)


# Generated at 2022-06-21 17:13:06.216984
# Unit test for function init_settings
def test_init_settings():
    debug_args = dict()
    debug_args['debug'] = True
    args = Namespace(**debug_args)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:08.939174
# Unit test for function init_settings
def test_init_settings():
    class Args:
        debug = True
    init_settings(Args)
    assert(settings.debug == True)


# Generated at 2022-06-21 17:13:10.435559
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:13:12.542290
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:15.671405
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:18.921402
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:21.201164
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    settings.debug = True
    init_settings(args=Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-21 17:13:23.118009
# Unit test for function init_settings
def test_init_settings():
    """
    Test function init_settings.
    """
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:25.657698
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=None))
    assert settings.debug == False

# Generated at 2022-06-21 17:13:28.395403
# Unit test for constructor of class Settings
def test_Settings():
    settings_obj = Settings()
    assert settings_obj is not None
    assert not settings_obj.debug


# Generated at 2022-06-21 17:13:29.742604
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:13:31.316957
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:13:34.080148
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == test_args.debug

# Generated at 2022-06-21 17:13:37.700076
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()
# python3 -m doctest -v main.py # to run doctests in verbose mode

# Generated at 2022-06-21 17:13:41.096886
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    assert not settings.debug

    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:44.354356
# Unit test for constructor of class Settings
def test_Settings():
    assert settings

# Generated at 2022-06-21 17:13:45.506148
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:46.548788
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings.debug == False

# Generated at 2022-06-21 17:13:48.290718
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:13:52.201683
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:13:54.986984
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:57.196700
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:59.922690
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:14:01.235064
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:05.772692
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug==False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Configuration for experiment.")

    parser.add_argument(
        "--debug", help="Set debug mode. Default is False.", action="store_true", default=False
    )

    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:13.685764
# Unit test for constructor of class Settings
def test_Settings():
    testSettings = Settings()
    assert testSettings is not None
    assert testSettings.debug == False



# Generated at 2022-06-21 17:14:15.819470
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-21 17:14:17.743750
# Unit test for constructor of class Settings
def test_Settings():
    settings_obj = Settings()
    assert (not settings_obj.debug)

# Generated at 2022-06-21 17:14:23.084773
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    if settings.debug == True:
        print('Test passed')
    else:
        print('Test failed')

test_init_settings()

# Generated at 2022-06-21 17:14:23.768380
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:25.340111
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:27.037852
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:14:29.850767
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:14:31.498051
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:14:32.891267
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-21 17:14:47.880573
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert args.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    assert args.debug == False



# Generated at 2022-06-21 17:14:53.389483
# Unit test for function init_settings
def test_init_settings():
    a = ['--debug']
    args = parser.parse_args(a)
    init_settings(args)
    assert settings.debug == True
    b = []
    args = parser.parse_args(b)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:55.588477
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-21 17:14:56.606528
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:15:00.580337
# Unit test for function init_settings
def test_init_settings():
    test_init_settings_args = Namespace()
    test_init_settings_args.debug = True

# Generated at 2022-06-21 17:15:01.427736
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

# Generated at 2022-06-21 17:15:06.304769
# Unit test for constructor of class Settings
def test_Settings():
    settings_object = Settings()
    if settings_object.debug is False:
        print("Constructor of class Settings is tested")
    else:
        raise AssertionError("Constructor of class Settings is not working.")


# Generated at 2022-06-21 17:15:07.348605
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:15:11.383376
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-21 17:15:13.191287
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:15:35.463892
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:36.608562
# Unit test for constructor of class Settings
def test_Settings():
    with pytest.raises(TypeError):
        settings = Settings()
        assert settings.debug == False



# Generated at 2022-06-21 17:15:37.180502
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:42.393121
# Unit test for constructor of class Settings
def test_Settings():
    def test_defn():
        return Namespace
    args = test_defn()
    args.debug = False
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-21 17:15:46.966691
# Unit test for function init_settings
def test_init_settings():
    ARGS = Namespace(debug=False)
    init_settings(ARGS)
    assert settings.debug == False

    ARGS = Namespace(debug=True)
    init_settings(ARGS)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:48.760631
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:15:52.578341
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:54.709375
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:15:57.305386
# Unit test for function init_settings
def test_init_settings():
    args = {'debug': True}
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:58.304809
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.de

# Generated at 2022-06-21 17:16:47.875450
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:49.932473
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
  

# Generated at 2022-06-21 17:16:51.700050
# Unit test for constructor of class Settings
def test_Settings():
    print('Test constructor of class Settings')
    assert settings.debug == False


# Generated at 2022-06-21 17:16:56.302126
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)

    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:57.550929
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)



# Generated at 2022-06-21 17:17:01.035034
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))

    assert settings.debug == True


# Generated at 2022-06-21 17:17:08.884813
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", help=" prints debug output")
    args = parser.parse_args()
    init_settings(args)




# Generated at 2022-06-21 17:17:11.337394
# Unit test for constructor of class Settings
def test_Settings():
    if settings.debug:
        print("test_Settings")

    settings = Settings()
    assert(settings.debug == False)



# Generated at 2022-06-21 17:17:13.014828
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings, "Settings instantiated"


# Generated at 2022-06-21 17:17:16.839661
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d',
                        '--debug',
                        help='Debug',
                        action='store_true')
    args = parser.parse_args()

    init_settings(args)

    pytest.main()

# Generated at 2022-06-21 17:18:51.689181
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert (settings.debug)

# Generated at 2022-06-21 17:18:52.430729
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-21 17:18:54.892633
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(args=Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:18:58.230088
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    # Init settings
    init_settings(args)

    # Test
    assert settings.debug

# Generated at 2022-06-21 17:19:00.696834
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-21 17:19:02.803438
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:19:05.512384
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:19:08.193454
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False

# Generated at 2022-06-21 17:19:09.448318
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:19:15.109653
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    # Test
    test_init_settings()

# Generated at 2022-06-21 17:22:35.308062
# Unit test for constructor of class Settings
def test_Settings(): 
    assert settings.debug == False


# Generated at 2022-06-21 17:22:38.482269
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert type(settings_test) is Settings
    assert not settings_test.debug


# Generated at 2022-06-21 17:22:41.149238
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    settingsTest.debug = True
    assert settingsTest.debug == True

# Generated at 2022-06-21 17:22:42.122865
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:22:45.200282
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:22:48.854543
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True