

# Generated at 2022-06-21 17:12:55.267701
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# test for init_settings

# Generated at 2022-06-21 17:12:57.566631
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:03.353655
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:13:05.154605
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    if settings.debug is False:
        assert True
    else:
        assert False
        

# Generated at 2022-06-21 17:13:06.958261
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:08.805758
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:13:11.240582
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert 'settings' in globals()
    assert settings.debug == False



# Generated at 2022-06-21 17:13:12.894124
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug is True

# Generated at 2022-06-21 17:13:16.861410
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:13:18.293352
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    a = Settings()
    assert a.debug == False
    

# Generated at 2022-06-21 17:13:20.834476
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

# Generated at 2022-06-21 17:13:22.275799
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:24.475678
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    settings_namespace = Namespace(debug=True)
    init_settings(settings_namespace)
    assert settings.debug


# test execution
test_init_settings()

# Generated at 2022-06-21 17:13:28.325075
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:31.976148
# Unit test for constructor of class Settings
def test_Settings():
    settings_1 = Settings()
    assert settings_1.debug == False

    settings_2 = Settings()
    assert settings_2.debug == False


# Generated at 2022-06-21 17:13:35.136592
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:37.984120
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:13:40.398919
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:44.518234
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Unit tests for init_settings function

# Generated at 2022-06-21 17:13:46.550416
# Unit test for constructor of class Settings
def test_Settings():
    # test default value
    assert settings.debug == False

# Unit test to check if configuration is properly updated

# Generated at 2022-06-21 17:13:51.094353
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:53.296563
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug == False

# Generated at 2022-06-21 17:13:54.689385
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:13:57.434574
# Unit test for constructor of class Settings
def test_Settings():
    # test the constructor
    test = Settings()
    # test that the constructor does not throw any errors
    assert test != None
    return True

# Generated at 2022-06-21 17:13:59.814678
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:03.333106
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-21 17:14:08.139737
# Unit test for function init_settings
def test_init_settings():
    args_with_debug = type('obj', (object,), {'debug': True})
    init_settings(args_with_debug)
    assert settings.debug
    args_without_debug = type('obj', (object,), {'debug': False})
    init_settings(args_without_debug)
    assert not settings.debug

# Generated at 2022-06-21 17:14:09.692423
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:11.065600
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:13.050846
# Unit test for constructor of class Settings
def test_Settings():
    # Test that settings is initialized
    assert settings.debug == False


# Generated at 2022-06-21 17:14:23.347341
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:24.549049
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:25.164273
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:28.582226
# Unit test for function init_settings
def test_init_settings():
    """
    Test for init_settings function
    """
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-21 17:14:32.174218
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:35.203542
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Test for init_settings with assert

# Generated at 2022-06-21 17:14:38.308403
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert  settings.debug == False

# Generated at 2022-06-21 17:14:40.787122
# Unit test for constructor of class Settings
def test_Settings():
    mySettings = Settings()
    assert mySettings.debug == False

# Generated at 2022-06-21 17:14:43.860501
# Unit test for constructor of class Settings
def test_Settings():
    expected = Namespace(debug=True)
    init_settings(expected)

    # Run test
    assert settings.debug == True

# Generated at 2022-06-21 17:14:47.029435
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug

    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:14:58.962376
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:02.153014
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True



# Generated at 2022-06-21 17:15:03.562863
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:06.164725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:15:07.033168
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-21 17:15:08.483042
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False

# Generated at 2022-06-21 17:15:13.516017
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:15:15.737465
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:15:18.111404
# Unit test for constructor of class Settings
def test_Settings():
    """
    Test constructor of class Settings
    """
    s = Settings()
    if (s.debug != False):
        raise Exception("Constructor of class Settings doesn't work")


# Generated at 2022-06-21 17:15:18.868990
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:15:40.187403
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)



# Generated at 2022-06-21 17:15:41.996175
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug



# Generated at 2022-06-21 17:15:43.325876
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:44.409492
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-21 17:15:45.135490
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()



# Generated at 2022-06-21 17:15:49.716138
# Unit test for function init_settings
def test_init_settings():
    parser = get_parser()

    test_args = ["-d"]
    args = parser.parse_args(test_args)
    init_settings(args)
    assert settings.debug

    test_args = [""]
    args = parser.parse_args(test_args)
    init_settings(args)
    assert not settings.debug

# Testing
if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-21 17:15:56.224790
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:15:58.154175
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:15:59.377696
# Unit test for function init_settings
def test_init_settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:16:02.066658
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:16:45.714726
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True




# Generated at 2022-06-21 17:16:49.654470
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    '''
    assert settings.debug == False
    '''



# Generated at 2022-06-21 17:16:51.938669
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange
    settings = Settings()
    assert not settings.debug

    # Act


# Generated at 2022-06-21 17:16:56.571750
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:17:00.034800
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:17:02.936799
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


test_Settings()

# Generated at 2022-06-21 17:17:05.298349
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-21 17:17:10.206271
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    # Test case 1
    init_settings(args)
    assert settings.debug == True
    # Test case 2
    args.debug = False
    # Test case 3
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:17:12.413070
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:17:15.412587
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings.debug == False, 'Incorrect selector of debug mode'
    settings_test = Settings()
    assert settings_test.debug == False, 'Incorrect selector of debug mode'



# Generated at 2022-06-21 17:18:41.663272
# Unit test for constructor of class Settings
def test_Settings():
    def test_settings(debug):
        settings.debug = debug

        assert settings.debug == debug

    test_settings(False)
    test_settings(True)



# Generated at 2022-06-21 17:18:44.347684
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:18:46.629784
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False



# Generated at 2022-06-21 17:18:51.617149
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:18:53.600926
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:18:56.003989
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:18:57.698424
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()


# Generated at 2022-06-21 17:18:59.058010
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:19:04.022968
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:19:07.233767
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:22:05.834323
# Unit test for function init_settings
def test_init_settings():
    init_settings(args = Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:22:07.969568
# Unit test for function init_settings
def test_init_settings():
    args=Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:22:09.065311
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:22:13.389973
# Unit test for function init_settings
def test_init_settings():
    # GIVEN: arguments
    args = Namespace(debug=True)

    # WHEN: init debug
    init_settings(args)

    # THEN: debug is true
    assert settings.debug is True


# Generated at 2022-06-21 17:22:14.716840
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-21 17:22:18.053901
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:22:19.259951
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:22:22.974724
# Unit test for constructor of class Settings
def test_Settings():
    settings_obj = Settings()
    assert isinstance(settings_obj, Settings) == True
    assert settings_obj.debug == False



# Generated at 2022-06-21 17:22:26.913437
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert settings.debug == True


# Creates a new database if it does not exist

# Generated at 2022-06-21 17:22:29.826405
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug is True


test_init_settings()