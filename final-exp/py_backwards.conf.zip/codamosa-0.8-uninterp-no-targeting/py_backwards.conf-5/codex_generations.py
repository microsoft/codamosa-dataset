

# Generated at 2022-06-21 17:12:59.634990
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", type=bool, default=False)
    args = parser.parse_args()

    assert (not settings.debug)
    init_settings(args)
    assert (not settings.debug)

    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", type=bool, default=True)
    args = parser.parse_args()

    assert (not settings.debug)
    init_settings(args)
    assert (settings.debug)



# Generated at 2022-06-21 17:13:02.708009
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:07.034308
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:11.539601
# Unit test for function init_settings
def test_init_settings():
    # Generate arguments
    args = Namespace(debug=True)
    # Set up global settings
    global settings
    settings = Settings()
    # Call init_settings
    init_settings(args)
    # Check for effects
    assert settings.debug == True

# Generated at 2022-06-21 17:13:14.789285
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    init_settings(args1)
    assert settings.debug == False
    args2 = Namespace(debug=True)
    init_settings(args2)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:16.639754
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
# End of unit test

# Generated at 2022-06-21 17:13:19.255071
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    asser

# Generated at 2022-06-21 17:13:20.257403
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-21 17:13:21.445327
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-21 17:13:23.982671
# Unit test for function init_settings
def test_init_settings():
    # Test debug setting
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args2 = Namespace(debug=False)
    init_settings(args2)
    assert not settings.debug

# Generated at 2022-06-21 17:13:29.534951
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-21 17:13:32.622885
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)
    assert bool(s.debug) == False


# Generated at 2022-06-21 17:13:35.193098
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True



# Generated at 2022-06-21 17:13:37.170159
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    
    assert settings.debug

test_init_settings()

# Generated at 2022-06-21 17:13:38.880128
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None



# Generated at 2022-06-21 17:13:43.720312
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-21 17:13:46.175169
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:13:48.032701
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-21 17:13:50.845919
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:53.070710
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug == False



# Generated at 2022-06-21 17:13:56.923392
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-21 17:13:58.460442
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:00.913351
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()

    assert test_settings.debug == False

# Generated at 2022-06-21 17:14:02.755239
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-21 17:14:04.203697
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:14:05.681386
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-21 17:14:06.543912
# Unit test for constructor of class Settings
def test_Settings():
    assert settings


# Generated at 2022-06-21 17:14:09.622525
# Unit test for function init_settings
def test_init_settings():
    app_args = Namespace(debug = True)
    init_settings(app_args)
    assert settings.debug

# Generated at 2022-06-21 17:14:11.545934
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)



# Generated at 2022-06-21 17:14:12.885720
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:20.820966
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s,Settings)



# Generated at 2022-06-21 17:14:22.475225
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == Fa

# Generated at 2022-06-21 17:14:23.565910
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings, "settings object must be initialized"



# Generated at 2022-06-21 17:14:24.979441
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-21 17:14:27.376243
# Unit test for function init_settings
def test_init_settings():
    ns = Namespace()
    setattr(ns, "debug", False)
    init_settings(ns)
    assert settings.debug == False
    ns.debug = True
    init_settings(ns)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:29.132423
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:34.539899
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    assert settings.debug is False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:36.456646
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-21 17:14:39.574870
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing constructor of class Settings")
    test_settings = Settings()
    assert(test_settings.debug == False)



# Generated at 2022-06-21 17:14:41.846463
# Unit test for constructor of class Settings
def test_Settings():
    setts = Settings()
    assert(settings.debug == False)
