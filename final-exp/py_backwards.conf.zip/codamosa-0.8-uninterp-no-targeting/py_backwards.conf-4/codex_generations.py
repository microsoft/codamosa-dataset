

# Generated at 2022-06-21 17:12:53.713505
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:12:55.129128
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:12:56.825402
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:12:58.760983
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, 'settings.debug should be True'



# Generated at 2022-06-21 17:13:01.032992
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-21 17:13:02.616736
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:09.093399
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False, verbose=False, version=False)
    init_settings(args)
    assert settings.debug == False, "test failed"
    args = Namespace(debug=True, verbose=False, version=False)
    init_settings(args)
    assert settings.debug == True, "test failed"

# Generated at 2022-06-21 17:13:11.541199
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)
    assert settings.debug == False

# Generated at 2022-06-21 17:13:13.736184
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    assert args.debug == True

# Generated at 2022-06-21 17:13:15.644518
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-21 17:13:18.764830
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:19.574376
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:13:21.276406
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:22.281225
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug is False


# Generated at 2022-06-21 17:13:23.465687
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:13:24.122947
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings()

# Generated at 2022-06-21 17:13:24.872630
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None


# Generated at 2022-06-21 17:13:27.777828
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:29.742523
# Unit test for constructor of class Settings
def test_Settings():
    print(settings.debug)
    assert settings.debug is False


# Generated at 2022-06-21 17:13:30.498692
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None
    assert settings.debug is False



# Generated at 2022-06-21 17:13:35.669488
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:37.913749
# Unit test for constructor of class Settings
def test_Settings():
    Settings()

# Generated at 2022-06-21 17:13:38.679677
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug != settings.debug

# Generated at 2022-06-21 17:13:40.507410
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert not setting.debug


# Generated at 2022-06-21 17:13:43.769393
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:13:45.762188
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:47.272245
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:51.094970
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:53.295734
# Unit test for constructor of class Settings
def test_Settings():
    settings=Settings()
    assert settings.debug==False


# Generated at 2022-06-21 17:13:56.949891
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True) # The argument object type needed
    init_settings(args)
    assert settings.debug == True # Checks if initialized



# Generated at 2022-06-21 17:14:05.513462
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, silent=False)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-21 17:14:08.293488
# Unit test for function init_settings
def test_init_settings():
    common.__settings = None
    args = Namespace(debug=True)
    init_settings(args)
    assert common.__settings.debug == True
    print('test_init_settings: ok')

test_init_settings()

# Generated at 2022-06-21 17:14:09.253746
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-21 17:14:12.890980
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:14:15.195914
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:16.514934
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:21.825804
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:14:23.150205
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings



# Generated at 2022-06-21 17:14:23.839149
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:14:24.979847
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:14:39.675626
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()

    args = Namespace(debug=False, filename=['testfile1.txt', 'testfile2.txt'])
    init_settings(args)
    assert  settings.debug == False

    args = Namespace(debug=True, filename=['testfile1.txt', 'testfile2.txt'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:42.574241
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:43.241587
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None


# Generated at 2022-06-21 17:14:45.804674
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:46.505033
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert not setting.debug

# Generated at 2022-06-21 17:14:49.645108
# Unit test for function init_settings
def test_init_settings():
    assert(not settings.debug)
    init_settings(Namespace(debug=True))
    assert(settings.debug)

# Generated at 2022-06-21 17:14:50.801221
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    
    
# Unit tests to test init_settings function

# Generated at 2022-06-21 17:14:56.019863
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-21 17:15:00.278751
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not settings.quiet
    assert not settings.force
    args.quiet = True
    init_settings(args)
    assert settings.debug
    assert settings.quiet
    assert not settings.force
    args.force = True
    init_settings(args)
    assert settings.debug
    assert settings.quiet
    assert settings.force

# Generated at 2022-06-21 17:15:02.297733
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)

# Generated at 2022-06-21 17:15:24.541689
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:15:25.533732
# Unit test for constructor of class Settings
def test_Settings():
    set = Settings()
    assert not set.debug


# Generated at 2022-06-21 17:15:26.517410
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:15:27.217913
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:15:29.708820
# Unit test for constructor of class Settings
def test_Settings():
    test_class = Settings()
    
    assert test_class.debug == False
    
    

# Generated at 2022-06-21 17:15:33.070627
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:15:35.020985
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest is not None


# Generated at 2022-06-21 17:15:37.084775
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)

    assert settings.debug


if __name__ == "__main__":
    import pytest

    pytest.main(["-s", __file__])

# Generated at 2022-06-21 17:15:38.421759
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings.debug == settings2.debug


# Generated at 2022-06-21 17:15:41.138767
# Unit test for function init_settings
def test_init_settings():
    args=Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True