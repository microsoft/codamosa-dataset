

# Generated at 2022-06-21 17:12:46.822919
# Unit test for constructor of class Settings
def test_Settings():
    # Create object of class Settings
    settings = Settings()

    assert settings.debug is False

# Generated at 2022-06-21 17:12:54.415100
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    # Create a new instance of the settings class to reset settings.
    settings = Settings()
    assert settings.debug == False

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:12:56.344793
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:12:58.245171
# Unit test for constructor of class Settings
def test_Settings():
    def_settings = Settings()
    assert def_settings.debug is False
    assert def_settings.debug == settings.debug


# Generated at 2022-06-21 17:13:01.108874
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False

test_Settings()


# Generated at 2022-06-21 17:13:03.422296
# Unit test for constructor of class Settings
def test_Settings():
    test_debug = False
    assert settings.debug == test_debug


# Generated at 2022-06-21 17:13:06.123343
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:10.844898
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # case 1: empty args is passed to init_settings
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    # case 2: args with debug set to True is passed to init_settings
    args.debug = True
    settings.debug = False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:15.932915
# Unit test for function init_settings
def test_init_settings():
    """Tests init_settings"""
    from argparse import Namespace
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings.debug = True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    settings.debug = False


# Generated at 2022-06-21 17:13:17.674819
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False, "Should not be in debug mode."


# Generated at 2022-06-21 17:13:20.720119
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:21.870892
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False


# Generated at 2022-06-21 17:13:22.689630
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-21 17:13:23.589519
# Unit test for constructor of class Settings
def test_Settings():
    Settings()
    assert True

# Generated at 2022-06-21 17:13:24.973736
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug != True
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:13:30.040355
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-21 17:13:38.286758
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug


if __name__ == '__main__':
    # Standard Library
    from argparse import ArgumentParser
    from argparse import RawTextHelpFormatter
    from sys import exit

    parser = ArgumentParser(formatter_class=RawTextHelpFormatter)

    parser.add_argument(
        '-d', '--debug',
        action='store_true',
        help='Enable debug')

    args = parser.parse_args()
    exit(main(args))

# Generated at 2022-06-21 17:13:40.506442
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:43.769659
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug = True))
    assert settings.debug == True
    init_settings(Namespace(debug = False))
    assert settings.debug == False

# Generated at 2022-06-21 17:13:48.247941
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(
        debug=False,
    ))
    assert settings.debug == False

    settings.debug = False
    init_settings(Namespace(
        debug=True,
    ))
    assert settings.debug == True

# Generated at 2022-06-21 17:13:54.842181
# Unit test for constructor of class Settings
def test_Settings():
    # This function is called from test only, so pylint
    # warning is not relevant in this case
    # pylint: disable=W0613
    Settings()
    assert True

# Generated at 2022-06-21 17:13:57.858528
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-21 17:14:01.739096
# Unit test for constructor of class Settings
def test_Settings():
    class TestSettings:
        def __init__(self) -> None:
            self.debug = False

    test_settings = TestSettings()
    assert test_settings.debug == False



# Generated at 2022-06-21 17:14:06.021865
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:08.339492
# Unit test for constructor of class Settings
def test_Settings():
    settings_test_case = Settings()
    assert settings_test_case.debug == False


# Generated at 2022-06-21 17:14:13.849437
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug
    assert settings.debug

# Generated at 2022-06-21 17:14:15.819618
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:14:17.227655
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:14:21.442614
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-21 17:14:23.856725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:32.312935
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:36.993755
# Unit test for function init_settings
def test_init_settings():
    # Test with debug set to false
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # Test with debug set to true
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:39.094442
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(settings.debug == False)


# Generated at 2022-06-21 17:14:41.422836
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:14:46.388809
# Unit test for constructor of class Settings
def test_Settings():
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--debug", action='store_true')
    args = arg_parser.parse_args()
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:48.325871
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert(settings.debug == False)


# Generated at 2022-06-21 17:14:49.780588
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:52.289723
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:14:55.228409
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:14:57.293724
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-21 17:15:10.872373
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:15:12.154883
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert type(settings.debug) == bool
    assert settings.debug == False

# Generated at 2022-06-21 17:15:15.201040
# Unit test for constructor of class Settings
def test_Settings():
    # Default settings
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    # Debug mode
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    return

# Generated at 2022-06-21 17:15:17.700012
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:15:19.596423
# Unit test for function init_settings
def test_init_settings():
    # Initialize settings to default values
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-21 17:15:22.049906
# Unit test for function init_settings
def test_init_settings():
    input = Namespace()
    init_settings(input)
    assert settings.debug == False



# Generated at 2022-06-21 17:15:23.273414
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:24.574250
# Unit test for function init_settings
def test_init_settings():

    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-21 17:15:25.300976
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False



# Generated at 2022-06-21 17:15:26.288689
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:15:49.914856
# Unit test for function init_settings
def test_init_settings():
    from pathlib import Path
    from backend.main import main

    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True

    args = Namespace()
    args.debug = False
    init_settings(args)

    assert settings.debug is False

# Generated at 2022-06-21 17:15:52.649983
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)

# Generated at 2022-06-21 17:15:54.208035
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-21 17:15:56.224240
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:15:56.774902
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:58.155569
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:15:59.642189
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False
    assert settings.debug == False


# Generated at 2022-06-21 17:16:01.653631
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-21 17:16:04.450188
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:16:09.428077
# Unit test for constructor of class Settings
def test_Settings():
    args = argparse.Namespace()
    args.debug = False
    args.interactive = False
    args.unit = False
    args.integration = False
    args.ui = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:16:52.837785
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:16:55.895982
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:16:59.363615
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-21 17:17:03.827657
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:17:05.728652
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:17:08.206512
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-21 17:17:10.041578
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:17:11.204651
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:17:12.091167
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:17:14.269614
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert getattr(settings, 'debug') == True

# Generated at 2022-06-21 17:18:44.591852
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-21 17:18:45.592393
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-21 17:18:48.475529
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:18:51.480170
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-21 17:18:54.412985
# Unit test for function init_settings
def test_init_settings():
    args_with_debug = Namespace(debug=True)
    init_settings(args_with_debug)
    assert settings.debug == True

    args_without_debug = Namespace(debug=False)
    init_settings(args_without_debug)
    assert settings.debug == False


# pytest -s -v test_settings.py

# Generated at 2022-06-21 17:18:57.698160
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:19:02.753465
# Unit test for function init_settings
def test_init_settings():
    # debug is false if no argument
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # debug is true if debug set to true in argument
    args = Namespace(debug=True)
    init_se

# Generated at 2022-06-21 17:19:04.306290
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:19:10.451220
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action="store_true")
    args = parser.parse_args()
    settings = Settings()
    init_settings(args)
    assert settings.debug == False

    settings = Settings()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:19:12.987367
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-21 17:22:31.622633
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# SETTINGS ADDITIONAL CONSTANTS (not part of config.json)

SUBDOMAIN_PROPERTY_NAME = "subdomain"
DOMAIN_PROPERTY_NAME = "domain"
MAX_DOMAIN_LENGTH = 64
MAX_SUBDOMAIN_LENGTH = 63 - MAX_DOMAIN_LENGTH  # 63 is max total length

# TODO: check these values. are they reasonable?
MAX_CUSTOM_HEADER_LENGTH = 1024
MAX_CUSTOM_HEADER_COUNT = 50
MAX_QUERY_PARAM_LENGTH = 1024
MAX_QU

# Generated at 2022-06-21 17:22:36.340898
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:22:41.481819
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    # reset
    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:22:44.629750
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True