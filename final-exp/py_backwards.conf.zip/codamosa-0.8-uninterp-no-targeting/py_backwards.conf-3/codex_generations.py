

# Generated at 2022-06-21 17:12:55.060087
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True




# Generated at 2022-06-21 17:12:58.289257
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False, "Debug is False by default"
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True, "Debug is True after init_settings(debug=True)"

# Generated at 2022-06-21 17:13:04.394130
# Unit test for function init_settings
def test_init_settings():
    # Create arguments to init_settings
    args = Namespace(debug=True)
    # Assert that debug flag is false
    assert settings.debug == False
    # Init settings
    init_settings(args)
    # Assert that debug flag is now true
    assert settings.debug == True

# Generated at 2022-06-21 17:13:07.412797
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False, "should be False"


# Generated at 2022-06-21 17:13:09.442026
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-21 17:13:12.224610
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:13.993417
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:15.557644
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:17.669699
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:13:18.427711
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:13:22.275768
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-21 17:13:23.247867
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-21 17:13:24.939590
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)

    assert settings.debug is True

# Generated at 2022-06-21 17:13:27.761577
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = True
    assert settings.debug


# Generated at 2022-06-21 17:13:30.260363
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-21 17:13:31.614801
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:13:33.464318
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)

    init_settings(test_args)

    assert settings.de

# Generated at 2022-06-21 17:13:36.441490
# Unit test for constructor of class Settings
def test_Settings():
    # Initialize the test class
    args = Namespace()
    args.debug = True
    init_settings(args)

    # Test
    assert settings.debug == True



# Generated at 2022-06-21 17:13:42.308714
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:45.712609
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug = False)
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-21 17:13:52.200479
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False, "Initial debug settings is False"



# Generated at 2022-06-21 17:13:54.983747
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:57.858383
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-21 17:14:10.760270
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

#TODO: create documentation for this file
# def get_setting(setting: str) -> Any:
#     return getattr(settings, setting)
#
#
# def set_setting(setting: str, value: Any) -> None:
#     setattr(settings, setting, value)
#
#
# class Settings:
#     def __init__(self, *args: Any, **kwargs: Any) -> None:
#         self.__dict__.update(*args, **kwargs)

# Generated at 2022-06-21 17:14:11.799278
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:14:12.584931
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:14:13.311713
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == Fals

# Generated at 2022-06-21 17:14:15.630099
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:20.298426
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-21 17:14:24.697466
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test settings")
    parser.add_argument("--debug", action="store_true", default=False)
    args = parser.parse_args()
    init_settings(args)
    print("debug:", settings.debug)
    # pytest -v settings_test.py

# Generated at 2022-06-21 17:14:33.093875
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:34.937802
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:14:35.779855
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert (test.debug == False)

# Generated at 2022-06-21 17:14:36.386506
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:14:37.121693
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug

# Generated at 2022-06-21 17:14:39.231182
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-21 17:14:40.925142
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-21 17:14:43.427242
# Unit test for function init_settings
def test_init_settings():
    args = dict()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:14:45.372216
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-21 17:14:47.531004
# Unit test for function init_settings
def test_init_settings():
    from yasmine.app.settings.tests.test_settings import init_settings
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:15:02.009794
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:15:05.735196
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:15:07.398779
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:15:08.876309
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:15:13.377230
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-21 17:15:15.574688
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:16.728732
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:15:19.501319
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:21.002909
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:22.262988
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:15:45.037805
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:46.520768
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug



# Generated at 2022-06-21 17:15:48.447521
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:54.128902
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    init_settings(args1)
    args2 = Namespace(debug=True)
    init_settings(args2)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:56.044808
# Unit test for constructor of class Settings
def test_Settings():
    set1 = Settings()
    assert set1.debug is False



# Generated at 2022-06-21 17:15:57.444325
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:15:58.708645
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:16:02.651234
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:16:04.014507
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-21 17:16:06.255714
# Unit test for constructor of class Settings
def test_Settings():
    # DEBUG
    assert not settings.debug
    # END



# Generated at 2022-06-21 17:16:55.757128
# Unit test for function init_settings
def test_init_settings():
    arg = argparse.Namespace(debug=True)
    init_settings(arg)
    assert settings.debug == True

# Test for setters and getters of class Settings

# Generated at 2022-06-21 17:16:58.530519
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings is not None
    assert settings.debug is False
    assert settings.debug == False



# Generated at 2022-06-21 17:17:04.595135
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-21 17:17:05.932280
# Unit test for constructor of class Settings
def test_Settings():
    assert settings
    assert settings.debug == False

# Generated at 2022-06-21 17:17:06.467377
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:17:10.231240
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-21 17:17:11.713857
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:17:12.677335
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:17:16.482428
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug



# Generated at 2022-06-21 17:17:20.487217
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Unit tests

# Generated at 2022-06-21 17:18:55.147695
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:18:57.541017
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:19:00.029507
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:19:01.618531
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:19:04.380298
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:19:07.036277
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:19:08.395055
# Unit test for constructor of class Settings
def test_Settings():
    set = Settings()
    assert set.debug is False

# Generated at 2022-06-21 17:19:15.884214
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--debug'])
    assert args.debug

    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    print('settings.debug:', settings.debug)

    print()
    print('Unit test:')
    test_init_settings()

# Generated at 2022-06-21 17:19:20.826538
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-21 17:19:25.030402
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-21 17:22:48.041431
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False

# Generated at 2022-06-21 17:22:49.527736
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:22:50.949355
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False