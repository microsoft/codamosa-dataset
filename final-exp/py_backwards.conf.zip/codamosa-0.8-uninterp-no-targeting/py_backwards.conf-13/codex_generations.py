

# Generated at 2022-06-21 17:12:55.669074
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:12:57.422407
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    # Ensures that debug is set to false
    assert settings.debug == False

# Generated at 2022-06-21 17:13:07.186506
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--debug",
        action="store_true",
        help="enable debug mode",
        default=False
    )
    args = parser.parse_args()
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug  == True

# Generated at 2022-06-21 17:13:10.439640
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:13:12.542395
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:15.438179
# Unit test for constructor of class Settings
def test_Settings():
    try:
        assert settings.debug == False
    except AssertionError:
        print("test_Settings failed on line 21")

test_Settings()


# Generated at 2022-06-21 17:13:16.296534
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:18.090823
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False


# Generated at 2022-06-21 17:13:20.319436
# Unit test for constructor of class Settings
def test_Settings():
    # When settings initialized, debug should be False
    assert settings.debug == False



# Generated at 2022-06-21 17:13:22.380765
# Unit test for function init_settings
def test_init_settings():
    # arrange
    args = Namespace()
    setattr(args, "debug", True)

    # act
    init_settings(args)

    # assert
    assert settings.debug