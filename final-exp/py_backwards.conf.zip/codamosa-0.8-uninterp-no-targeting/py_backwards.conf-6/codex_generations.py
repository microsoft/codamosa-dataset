

# Generated at 2022-06-21 17:12:53.125943
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-21 17:12:55.059994
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-21 17:12:56.541508
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug

# Generated at 2022-06-21 17:12:57.838631
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:12:58.896299
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:13:00.570263
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-21 17:13:02.791340
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Unit test  for method init_settings()

# Generated at 2022-06-21 17:13:05.545038
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:13:07.336480
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-21 17:13:11.063398
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    assert settings.debug == False
    init_settings(args=Namespace(debug=True))
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-21 17:13:14.841694
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:17.778537
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True and args.debug == True



# Generated at 2022-06-21 17:13:19.033407
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:20.681974
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug


# Generated at 2022-06-21 17:13:22.415604
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-21 17:13:23.965558
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


# Generated at 2022-06-21 17:13:25.211689
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__init__ != None

if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-21 17:13:25.868174
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:31.397305
# Unit test for function init_settings
def test_init_settings():
    global settings
    # Test 1
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()
    print("All tests passed for " + __file__)

# Generated at 2022-06-21 17:13:32.763811
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

test_Settings()

# Generated at 2022-06-21 17:13:36.582859
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:13:37.476572
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    assert s is not None

# Generated at 2022-06-21 17:13:39.172389
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing Settings")
    init_settings()
    assert(settings is not None)


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-21 17:13:40.961596
# Unit test for constructor of class Settings
def test_Settings():
    from __main__ import settings
    assert settings.debug == False

# Generated at 2022-06-21 17:13:45.712079
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:13:47.988848
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-21 17:13:50.856196
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:54.247138
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-21 17:13:57.264037
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:14:02.450328
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    setattr(test_args, 'debug', True)
    init_settings(test_args)
    assert settings.debug
    test_args = Namespace()
    setattr(test_args, 'debug', False)
    init_settings(test_args)
    assert settings.debug == False