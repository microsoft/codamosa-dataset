

# Generated at 2022-06-21 17:12:55.536364
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:12:56.716346
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-21 17:12:57.600516
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:12:59.838735
# Unit test for constructor of class Settings
def test_Settings():
    test_S = Settings()
    assert (test_S.debug == False)

# Generated at 2022-06-21 17:13:04.712283
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:13:08.233798
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:13:10.037640
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings
    assert not settings.debug



# Generated at 2022-06-21 17:13:11.242544
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:11.869541
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-21 17:13:15.726631
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', help='debug mode')
    parser.set_defaults(func=init_settings)
    args = parser.parse_args()
    args.func(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:18.493923
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:19.721780
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()

    assert settings_test.debug == settings.debug

# Generated at 2022-06-21 17:13:20.920216
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:13:22.346114
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:23.885730
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:25.868601
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(**{'debug': False}))
    assert settings.debug == False
    init_settings(Namespace(**{'debug': True}))
    assert settings.debug == True

# Generated at 2022-06-21 17:13:27.972670
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-21 17:13:30.487793
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-21 17:13:31.563156
# Unit test for function init_settings
def test_init_settings():
    args_mock = Namespace(debug=True)
    init_settings(args_mock)

    settings.debug = False

# Generated at 2022-06-21 17:13:34.306573
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug==True