

# Generated at 2022-06-21 17:12:55.333903
# Unit test for function init_settings
def test_init_settings():
    assert isinstance(settings, Settings)
    assert not settings.debug

    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:12:56.573706
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-21 17:12:59.828498
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert(settings.debug == False)
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)
    print("test_init_settings pass")

# Generated at 2022-06-21 17:13:02.791128
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-21 17:13:04.322179
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:13:10.094432
# Unit test for constructor of class Settings
def test_Settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', dest='debug', action='store_true',
                        help='enable debug mode')
    init_settings(parser.parse_args([]))

    assert(settings.debug == False)

    init_settings(parser.parse_args(['--debug']))

    assert(settings.debug == True)

# Generated at 2022-06-21 17:13:11.284640
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:13:12.780550
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:13:15.093000
# Unit test for function init_settings
def test_init_settings():
    argparse.ArgumentParser()
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:16.600290
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:13:18.965742
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()

    assert settings2.debug == False


# Generated at 2022-06-21 17:13:21.178786
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:22.213188
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None
    assert settings.debug == False

# Generated at 2022-06-21 17:13:22.956270
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:13:24.452314
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:13:32.320809
# Unit test for function init_settings
def test_init_settings():
    args = [
        "--debug"
    ]
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    init_settings(parser.parse_args(args))
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-21 17:13:34.473500
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) is Settings
    assert settings.debug is False

# Generated at 2022-06-21 17:13:35.623876
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-21 17:13:39.004200
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-21 17:13:45.463312
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace()
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-21 17:13:51.976967
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    #pass

# Unit test if debug mode is enabled

# Generated at 2022-06-21 17:13:54.247340
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = False

# Generated at 2022-06-21 17:13:56.346503
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, dry_run=False,
                     enable_inheritance=False, verbose=False)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:13:58.704558
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug is True

# Unit testing for function init_settings

# Generated at 2022-06-21 17:14:01.150763
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug is False

# Generated at 2022-06-21 17:14:02.978002
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    settings2 = Settings()

# Generated at 2022-06-21 17:14:05.681591
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:07.479443
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-21 17:14:09.553533
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-21 17:14:14.364839
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-21 17:14:20.746075
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-21 17:14:23.216361
# Unit test for function init_settings
def test_init_settings():
    args=Namespace
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-21 17:14:24.161459
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-21 17:14:26.164284
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:14:27.747465
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:14:30.786953
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-21 17:14:33.321273
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    #assert settings.debug
    #print('test_Settings passed')

# Generated at 2022-06-21 17:14:36.610815
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=None)
    init_settings(args)
    assert settings.debug == False



if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:14:38.447867
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)



# Generated at 2022-06-21 17:14:45.988624
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    args = Namespace(debug=True)
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-21 17:14:59.615227
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-21 17:15:01.650967
# Unit test for constructor of class Settings
def test_Settings():
    d = Settings()
    assert d.debug == False


# Generated at 2022-06-21 17:15:06.794963
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=False))
    s = Settings()
    assert s.debug == False
    init_settings(Namespace(debug=True))
    s = Settings()
    assert s.debug == True
    print("Test for constructor of class Settings passed")

# Generated at 2022-06-21 17:15:08.236368
# Unit test for constructor of class Settings
def test_Settings():
  set = Settings()
  assert set != None

# Generated at 2022-06-21 17:15:10.423426
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:17.736089
# Unit test for function init_settings
def test_init_settings():
    #input and expected output
    test_args = ["--debug"]
    expected_output = True

    #testing function
    init_settings(test_args)
    actual_output = settings.debug

    #assert test
    assert actual_output == expected_output, "Expected output to be {0}, but got {1}".format(expected_output, actual_output)

#test_init_settings()

# Generated at 2022-06-21 17:15:18.520062
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:20.887273
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=True)
    args2 = Namespace(debug=False)
    init_settings(args1)
    assert settings.debug == True
    init_settings(args2)
    assert settings.debug == False



# Generated at 2022-06-21 17:15:26.062680
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == args.debug



# Generated at 2022-06-21 17:15:29.927418
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('-d', '--debug', action='store_true')
    parser.parse_args(['-d'], namespace=settings)
    init_settings(settings)
    assert settings.debug == True
    print("settings.debug =", settings.debug)

# Generated at 2022-06-21 17:15:37.209088
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    d = dict()
    d['debug'] = True
    args = Namespace(**d)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:38.923483
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    assert settings.debug == False
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-21 17:15:40.253473
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-21 17:15:42.658512
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:15:43.996698
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False

# Generated at 2022-06-21 17:15:47.376803
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True
    
test_init_settings()



# Generated at 2022-06-21 17:15:50.945811
# Unit test for constructor of class Settings
def test_Settings():
    with pytest.raises(TypeError):
        Settings('a', 'b', 'c')



# Generated at 2022-06-21 17:15:58.499083
# Unit test for function init_settings
def test_init_settings():
    # Setup
    parser = argparse.ArgumentParser(description='Sorts a list of numbers')
    parser.add_argument('--debug', '-d', action='store_true', help='debug information')
    args = parser.parse_args([])

    # Exercise
    init_settings(args)

    # Verify
    assert False == settings.debug

# Generated at 2022-06-21 17:15:59.407201
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:00.844470
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-21 17:16:15.126677
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:16:15.883097
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-21 17:16:19.885999
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    print("not running this as module")

# Generated at 2022-06-21 17:16:23.205646
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:25.535925
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:16:28.148793
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:29.480719
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-21 17:16:32.354705
# Unit test for function init_settings
def test_init_settings():
    """
    Test that init_settings properly sets the settings variables
    """
    global settings
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:16:38.537328
# Unit test for function init_settings
def test_init_settings():
    test_args_1 = Namespace()
    test_args_1.debug = False
    init_settings(test_args_1)
    assert not settings.debug
    test_args_2 = Namespace()
    test_args_2.debug = True
    init_settings(test_args_2)
    assert settings.debug

# Generated at 2022-06-21 17:16:40.071142
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-21 17:17:02.058746
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-21 17:17:03.351413
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-21 17:17:05.164176
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-21 17:17:07.402086
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-21 17:17:10.232709
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:17:14.635548
# Unit test for constructor of class Settings
def test_Settings():
    from unittest.mock import Mock
    mocked_argparser = Mock()
    mocked_argparser.debug=True
    init_settings(mocked_argparser)
    assert settings.debug

# Generated at 2022-06-21 17:17:16.556174
# Unit test for function init_settings
def test_init_settings():
    assert init_settings() is None


# Generated at 2022-06-21 17:17:20.128375
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-21 17:17:23.064843
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert not test.debug


# Generated at 2022-06-21 17:17:25.954196
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-21 17:18:12.402899
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:18:17.349702
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-21 17:18:22.114504
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:18:23.592482
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert typ

# Generated at 2022-06-21 17:18:28.001168
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-21 17:18:30.159915
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-21 17:18:38.642238
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    # Act
    init_settings(args)

    # Assert
    assert settings.debug == False

    # Act
    args.debug = True
    init_settings(args)

    # Assert
    assert settings.debug == True

    # Act
    init_settings(args)

    # Assert
    assert settings.debug == True

    print('test_init_settings passed.')



# Generated at 2022-06-21 17:18:48.620195
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='A simple static web site generator.')
    parser.add_argument('-d', '--debug', help='debug mode.',
                        action='store_true')
    args = parser.parse_args()

    init_settings(args)
    main()

# Generated at 2022-06-21 17:18:49.875103
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-21 17:18:51.666320
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-21 17:20:20.069501
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-21 17:20:23.588873
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-21 17:20:26.059222
# Unit test for function init_settings
def test_init_settings():
    my_args = Namespace(debug=True)
    init_settings(my_args)
    assert settings.debug == True

# Generated at 2022-06-21 17:20:27.694935
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-21 17:20:30.778004
# Unit test for constructor of class Settings
def test_Settings():
    print("Test Settings")
    s = Settings()
    assert s.debug == False
    print("passed.")


# Generated at 2022-06-21 17:20:33.060695
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-21 17:20:39.964531
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace()

    init_settings(args)

    assert settings.debug == False

    args.debug = True
    init_settings(args)

    assert settings.debug == True


# Test
if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-21 17:20:42.104267
# Unit test for constructor of class Settings
def test_Settings():
    settings_obj = Settings()
    assert not settings_obj.debug

# Generated at 2022-06-21 17:20:43.673283
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-21 17:20:47.931204
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug, "Debug enabled"

