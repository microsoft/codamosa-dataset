

# Generated at 2022-06-23 22:15:25.621289
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:27.875521
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:29.347282
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:15:35.036529
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', default=False, action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False
    settings.debug = True
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args.de

# Generated at 2022-06-23 22:15:38.926890
# Unit test for constructor of class Settings
def test_Settings():

    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--debug", action="store_true",help="debug mode")

    args = parser.parse_args()

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:15:41.956832
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False, 'settings.debug was not set correctly'

    args.debug = True
    init_settings(args)
    assert settings.debug == True, 'settings.debug was not set correctly'

# Generated at 2022-06-23 22:15:47.902659
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    initial_debug = settings.debug
    init_settings(args)
    assert initial_debug == settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert initial_debug == settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert initial_debug == settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:15:50.651249
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug



# Generated at 2022-06-23 22:15:53.794179
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug == args.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:15:54.694760
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:15:56.141059
# Unit test for constructor of class Settings
def test_Settings():
    settings=Settings()
    assert settings.debug==False



# Generated at 2022-06-23 22:15:57.216276
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    assert settings is not None


# Generated at 2022-06-23 22:15:58.279790
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-23 22:15:59.266758
# Unit test for constructor of class Settings
def test_Settings():
    Settings()


# Generated at 2022-06-23 22:16:03.968850
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # true case
    args.debug = True
    init_settings(args)
    assert settings.debug is True

    # false case
    args.debug = False
    init_settings(args)
    assert settings.debug is False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:16:05.782780
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:06.721578
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:16:07.966051
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False


# Generated at 2022-06-23 22:16:10.904482
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:12.562530
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:16:15.658797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:16:19.331124
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == args.debug
    args = Namespace(
        debug=False
    )
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:16:21.649426
# Unit test for function init_settings
def test_init_settings():
    settings.debug = True
    init_settings(Namespace(debug=False))
    assert settings.debug == False



# Generated at 2022-06-23 22:16:22.998895
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:16:25.061627
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    if settings.debug:
        assert settings.debug == True
    else:
        assert settings.debug == False


# Generated at 2022-06-23 22:16:27.569501
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:28.841886
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:31.038171
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert isinstance(settings_test, Settings)
    assert isinstance(settings_test.debug, bool)

# Generated at 2022-06-23 22:16:33.441569
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:16:38.153332
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=None))
    assert settings.debug == False


# Generated at 2022-06-23 22:16:41.087380
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:16:41.985089
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:44.106501
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)

    assert settings.debug

# Generated at 2022-06-23 22:16:45.702476
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:16:54.307338
# Unit test for function init_settings
def test_init_settings():
    tmp_settings = Settings()
    assert settings == tmp_settings


parser = argparse.ArgumentParser(description="inference program")
parser.add_argument("--input_image", "-i", default="images/", help="path to the input image file")
parser.add_argument("--model_file", "-mf", required=True,
                    help="path to the model file (protobuf format)")
parser.add_argument("--output_folder", "-o", default="output/",
                    help="output folder")
parser.add_argument("--debug", "-d", dest="debug",
                    action="store_true", default=False,
                    help="turn on the debug mode")
parser.add_argument("--image_width", "-w", default=300,
                    help="image width")

# Generated at 2022-06-23 22:16:55.077631
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:16:56.270082
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:16:59.163915
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:00.289470
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:01.437036
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:03.501846
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:04.770134
# Unit test for constructor of class Settings
def test_Settings():
    # settings.debug = True
    assert settings.debug != []
    assert settings.debug != {'a': 2}

test_Settings()

# Generated at 2022-06-23 22:17:07.395466
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False


# Generated at 2022-06-23 22:17:10.253317
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:11.576450
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-23 22:17:13.893011
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest

# Generated at 2022-06-23 22:17:15.277472
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert isinstance(obj, Settings)
    assert not obj.debug

# Generated at 2022-06-23 22:17:17.388860
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:22.874399
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:17:24.107468
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:28.111879
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:17:29.035936
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:17:30.557633
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:33.473605
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings.debug) == bool
    assert type(settings.debug) == bool
    assert not settings.debug
    assert not settings.debug


# Generated at 2022-06-23 22:17:34.321156
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False

# Generated at 2022-06-23 22:17:34.911324
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:17:37.587359
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    obj.debug = False
    assert obj.debug == False


test_Settings()

# Generated at 2022-06-23 22:17:39.281579
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:40.682379
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:17:42.320008
# Unit test for function init_settings
def test_init_settings():
    test_settings = Namespace(debug=False)
    init_settings(test_settings)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:44.151948
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:45.249648
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:17:47.627383
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert(settings.debug == True)


# main function

# Generated at 2022-06-23 22:17:48.160348
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-23 22:17:49.367287
# Unit test for constructor of class Settings
def test_Settings():
    st = Settings()
    assert st.debug is False


# Generated at 2022-06-23 22:17:53.421123
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace())
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:17:54.286986
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:55.651170
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    

    assert settings.debug == True

# Generated at 2022-06-23 22:17:56.880638
# Unit test for function init_settings
def test_init_settings():
    pass


if __name__ == '__main__':
    test_init_settings()
    print('Test passed')

# Generated at 2022-06-23 22:17:57.621996
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:17:58.502093
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug

# Generated at 2022-06-23 22:17:59.394645
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:01.475573
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:18:02.716587
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:18:13.752550
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Alpha:
alpha = 0.5


# Time
timestep = 2.0
time_step_per_update = 2

# Gravity:
gravity = np.array([0., -9.81], dtype=np.float32)

# Path of file storing last game's settings.
last_game_settings_path = "last_game_settings.pkl"

# Colors

# Generated at 2022-06-23 22:18:14.840603
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert False == settings.debug



# Generated at 2022-06-23 22:18:16.249542
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:19.634899
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', help="debug mode", action="store_true")
    args = parser.parse_args(["-d"])
    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    test_init_settings()
    print("All tests passed")

# Generated at 2022-06-23 22:18:22.226776
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    ini_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:24.519212
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:25.665678
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)


# Generated at 2022-06-23 22:18:28.629552
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:18:30.389443
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:18:31.089218
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert not settings.debug


# unit test for method init_settings

# Generated at 2022-06-23 22:18:32.491384
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:33.129627
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:18:38.851313
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', default=False, help="Enable debug output.")
    args = parser.parse_args()
    init_settings(args)
    test_Settings()

# Generated at 2022-06-23 22:18:41.989706
# Unit test for constructor of class Settings
def test_Settings():
  global settings
  settings = Settings()
  if settings.debug:
    print("Debugging is enabled")
  else:
    print("Debugging is disabled")

# Generated at 2022-06-23 22:18:43.474991
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:18:47.340308
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", default=False, help="Turn debugging on")
    args = parser.parse_args(args=["--debug"])
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:48.217571
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:18:50.858144
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    settings2 = Settings()
    assert settings1.debug == False
    assert settings2.debug == False
    assert settings1.debug == settings2.debug


# Generated at 2022-06-23 22:18:52.120132
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:54.563893
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:56.446640
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-23 22:18:58.734964
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False



# Generated at 2022-06-23 22:18:59.743307
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:19:02.654671
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:19:04.555477
# Unit test for constructor of class Settings
def test_Settings():
    test_obj_1 = Settings()
    assert test_obj_1.debug == False


# Generated at 2022-06-23 22:19:07.430541
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:09.588474
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:19:10.688021
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:19:12.325874
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:15.960901
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing constructor of class Settings")
    settings = Settings()
    assert settings.debug == False, "Default value of settings.debug should be False"



# Generated at 2022-06-23 22:19:17.439788
# Unit test for constructor of class Settings
def test_Settings():
    # test instantiation
    assert isinstance(settings, Settings)
    assert settings.debug == True


test_Settings()

# Generated at 2022-06-23 22:19:19.789599
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug = False))
    assert settings.debug == False
    init_settings(Namespace(debug = True))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:20.728611
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug  # assert False

# Generated at 2022-06-23 22:19:21.834319
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:23.560761
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:19:27.740998
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:19:30.214497
# Unit test for function init_settings
def test_init_settings():
    # when
    init_settings(Namespace(debug=True))
    # then
    assert settings.debug



# Generated at 2022-06-23 22:19:31.029621
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:19:31.923379
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:19:33.987278
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, object)

# Generated at 2022-06-23 22:19:35.266876
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Unit test fo

# Generated at 2022-06-23 22:19:37.246202
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:39.555278
# Unit test for constructor of class Settings
def test_Settings():
    with pytest.raises(Exception):
        Settings()



# Generated at 2022-06-23 22:19:41.204444
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug
    assert type(settings) is Settings



# Generated at 2022-06-23 22:19:42.610046
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:19:45.043956
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug 
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:19:45.891339
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:19:50.696632
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug == True
    init_settings(Namespace(debug = False))
    assert settings.debug == False

# test function
import unittest
unittest.main(argv=[''], verbosity=2, exit=False)

# debug
import logging
logging.basicConfig(level=logging.DEBUG)
logging.debug('This is a log message.')

# Generated at 2022-06-23 22:19:52.638874
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings.debug == False

# Generated at 2022-06-23 22:19:53.532150
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == Fal

# Generated at 2022-06-23 22:19:56.059973
# Unit test for function init_settings
def test_init_settings():
    test_class = Settings()

    test_class.init_settings(True)
    assert (test_class.debug == True)

# Generated at 2022-06-23 22:19:59.786116
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="Sample arg")
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args(['-d'])
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:20:00.563948
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings2

# Generated at 2022-06-23 22:20:01.680845
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settin

# Generated at 2022-06-23 22:20:03.470388
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    #
    # reset settings
    #
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:05.401620
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:06.429038
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:09.193361
# Unit test for constructor of class Settings
def test_Settings():
    class Settings:
        def __init__(self) -> None:
            self.debug = False
    test_settings = Settings()
    assert test_settings.debug == False



# Generated at 2022-06-23 22:20:10.853878
# Unit test for function init_settings
def test_init_settings():
    args = ['-d']
    init_settings(args)

# Generated at 2022-06-23 22:20:12.106364
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:13.672939
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:14.788252
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert_true(settings.debug == False)

# Generated at 2022-06-23 22:20:15.817541
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:20:16.825309
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:17.884217
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False



# Generated at 2022-06-23 22:20:19.197389
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:20:22.564954
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    init_settings(Namespace(debug=False))
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:20:25.798844
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, )
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:20:27.626203
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-23 22:20:28.980566
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:30.883324
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:20:32.169736
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:35.687639
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:36.674092
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:40.326968
# Unit test for constructor of class Settings
def test_Settings():
    # Test with debug flag
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

    # Test without debug flag
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:20:41.712470
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:20:44.354997
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    settings.debug = True
    assert settings.debug is True


test_Settings()

# Generated at 2022-06-23 22:20:46.275229
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-23 22:20:47.977162
# Unit test for constructor of class Settings
def test_Settings():
    s=Settings()
    assert s.debug is False
    

# Generated at 2022-06-23 22:20:49.616267
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None


# Generated at 2022-06-23 22:20:53.294139
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True
test_init_settings()

# Generated at 2022-06-23 22:20:56.270422
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:58.419700
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:20:59.889371
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:01.733416
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:05.208585
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:06.560448
# Unit test for constructor of class Settings
def test_Settings(): # Should pass
    assert settings.debug == False




# Generated at 2022-06-23 22:21:07.862955
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:10.204686
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:21:11.524828
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:12.753947
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:14.329514
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug is False

# Generated at 2022-06-23 22:21:15.992310
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:16.698538
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:21:18.231230
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:21:20.992613
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:22.531761
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:21:23.723621
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:21:24.573929
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()


# Generated at 2022-06-23 22:21:26.855800
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug == True
    init_settings(Namespace(debug = False))
    assert settings.debug == False

test_init_settings()

# Generated at 2022-06-23 22:21:29.420246
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # Check if function works with args.debug not set
    init_settings(args)
    assert settings.debug is False

    # Check if function works with args.debug set to True
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:31.783047
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    if s.debug == False:
        print("Test passed! User didn't turn debug mode on!")
    else:
        raise Exception("Test failed! User turned debug mode on!")


# Generated at 2022-06-23 22:21:33.098056
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:34.081738
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:35.085665
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False



# Generated at 2022-06-23 22:21:36.575846
# Unit test for constructor of class Settings
def test_Settings():
    settings_1 = Settings()
    assert settings_1.debug == False


# Generated at 2022-06-23 22:21:40.240679
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=True)
    args2 = Namespace(debug=False)

    init_settings(args1)
    assert settings.debug is True

    init_settings(args2)
    assert settings.debug is False

# Generated at 2022-06-23 22:21:42.015873
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:21:43.837476
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = init_settings()
    assert settings1.debug == False

# Generated at 2022-06-23 22:21:46.492978
# Unit test for function init_settings
def test_init_settings():
    print()
    current_settings = copy.deepcopy(settings)
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings = current_settings



# Generated at 2022-06-23 22:21:48.625287
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:51.069902
# Unit test for function init_settings
def test_init_settings():
    args =  Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:21:55.402793
# Unit test for constructor of class Settings
def test_Settings():
    if settings.debug != True:
        raise Exception("settings.debug:", settings.debug, "Expected: True")

# For later use
# def test_init_settings():
#     if settings.debug != True:
#         raise Exception("settings.debug:", settings.debu

# Generated at 2022-06-23 22:21:58.690001
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    init_settings(Namespace(
        debug=True
    ))

    assert settings.debug == True

# Generated at 2022-06-23 22:21:59.214030
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None

# Generated at 2022-06-23 22:22:00.593563
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False
    assert s

# Generated at 2022-06-23 22:22:01.449216
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:22:02.476859
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:22:04.579165
# Unit test for function init_settings
def test_init_settings():
    global settings
    init_settings(Namespace(debug=True))
    assert settings.debug, "Test init_settings"
    print("Test init_settings passed")

# Generated at 2022-06-23 22:22:06.028226
# Unit test for constructor of class Settings
def test_Settings():
    assert hasattr(settings, 'debug')
    assert settings.debug == False


# Generated at 2022-06-23 22:22:06.822555
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:08.283615
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:11.357812
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)

    assert settings.debug == False
    assert args.debug == False
    assert settings.debug != args.debug
    print('test_init_settings passed')
test_init_settings()

# Generated at 2022-06-23 22:22:15.310073
# Unit test for function init_settings
def test_init_settings():
    # Test case: Ensure the debug argument is not set by default
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # Test case: Ensure the debug argument is set properly
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:16.443494
# Unit test for constructor of class Settings
def test_Settings():
    settings_test=Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:22:20.301509
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug',
                            dest='debug',
                            default=False,
                            action='store_true',
                            help='Enter debug mode')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:23.735436
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:22:24.973980
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:22:26.315286
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False




# Generated at 2022-06-23 22:22:27.621132
# Unit test for constructor of class Settings
def test_Settings():
    settings_1= Settings()
    assert settings_1.debug == False



# Generated at 2022-06-23 22:22:28.443585
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    

# Generated at 2022-06-23 22:22:29.896645
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)
    assert s.debug == False


# Generated at 2022-06-23 22:22:31.806785
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug

# Generated at 2022-06-23 22:22:33.731965
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:35.136689
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:22:37.068741
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

## Unit test for function init_settings

# Generated at 2022-06-23 22:22:39.590822
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:22:42.162638
# Unit test for function init_settings
def test_init_settings(): 
    global settings
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:44.208294
# Unit test for constructor of class Settings
def test_Settings():
    # Test that debug is False
    assert settings.debug == False
    assert settings.debug != True



# Generated at 2022-06-23 22:22:45.180462
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:45.809420
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:22:47.466043
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:50.106859
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:22:51.894157
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:53.146725
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)



# Generated at 2022-06-23 22:22:54.672170
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:22:56.759461
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:58.113191
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)

# Generated at 2022-06-23 22:23:00.419666
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    assert settings.debug is False


# Generated at 2022-06-23 22:23:03.838209
# Unit test for function init_settings
def test_init_settings():
    class Args(Namespace):
        debug = False
        
    args = Args()
    init_settings(args)
    assert not settings.debug
    
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:04.848190
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False




# Generated at 2022-06-23 22:23:06.355130
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:08.554098
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-23 22:23:09.220687
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:23:10.258225
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:11.680930
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()

    assert settings.debug == False


# Generated at 2022-06-23 22:23:12.747297
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Test that the de

# Generated at 2022-06-23 22:23:20.400672
# Unit test for function init_settings
def test_init_settings():
    # Expected behavior
    args = Namespace()
    args.debug = True
    init_settings(args)

    if settings.debug:
        print("DEBUG IS ON")
    else:
        print("ERROR: DEBUG IS OFF")

# Run the unit test here
test_init_settings()

# Generated at 2022-06-23 22:23:22.204545
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-23 22:23:22.830601
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:23:24.670365
# Unit test for function init_settings
def test_init_settings():
    args = []
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:27.192516
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Test for final state of settings object

# Generated at 2022-06-23 22:23:28.829696
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:23:30.982727
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug != True
    assert type(test) is Settings


# Generated at 2022-06-23 22:23:32.737345
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-23 22:23:34.726023
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False
# Test for constructor for init_settings

# Generated at 2022-06-23 22:23:37.493701
# Unit test for function init_settings
def test_init_settings():
    debug = True
    args = Namespace(debug=debug)
    init_settings(args)
    assert settings.debug == debug

# Generated at 2022-06-23 22:23:39.985439
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:23:41.839719
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:42.853823
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:46.291586
# Unit test for function init_settings
def test_init_settings():
    # create an arg namespace
    arg_namespace = Namespace()
    arg_namespace.debug = True
    # invoke init_settings with arg_namespace
    init_settings(arg_namespace)
    # verify that settings.debug is true
    assert settings.debug is True


# Generated at 2022-06-23 22:23:51.812491
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(args)
    assert settings.debug == True
    # clean up after testing
    settings.debug = False


# def test_DebugSettings():
#     args_list = ["--debug"]
#     args = parser.parse_args(args_list)
#     init_settings(args)
#     assert settings.debug == True
#     # clean up after testing
#     settings.debug = False

# Generated at 2022-06-23 22:23:53.174860
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:54.477406
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:57.756425
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:24:00.941491
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Usage: pytest -v test/test_settings.py
# pytest -v -s test/test_settings.py

# Generated at 2022-06-23 22:24:03.424971
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:24:05.563919
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:07.149823
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings.debug == False


# Generated at 2022-06-23 22:24:08.615322
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert hasattr(s, 'debug')

# Generated at 2022-06-23 22:24:10.638127
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace(debug=True)
    init_settings(mock_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:13.006080
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert not settings.debug

# Generated at 2022-06-23 22:24:14.000517
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:15.685224
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:16.489574
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-23 22:24:17.914355
# Unit test for constructor of class Settings
def test_Settings():
    tmp_settings = Settings()
    assert tmp_settings.debug == False

# Generated at 2022-06-23 22:24:20.428965
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:24:24.163144
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace

    init_settings(Namespace())
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:24:25.497850
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:28.382686
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = False
    assert not settings.debug
    init_settings(test_args)
    assert not settings.debug
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:24:29.360625
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:24:32.701058
# Unit test for function init_settings
def test_init_settings():
    class FakeNamespace:
        def __init__(self) -> None:
            self.debug = True
    fake_namespace = FakeNamespace()
    init_settings(fake_namespace)
    assert settings.debug



# Generated at 2022-06-23 22:24:36.436668
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert hasattr(settings, 'debug')
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:38.183363
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:40.587041
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-23 22:24:41.831629
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert(not test.debug)


# Generated at 2022-06-23 22:24:46.262262
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:24:49.337015
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug
    assert not settings.debug

# Generated at 2022-06-23 22:24:51.036047
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:53.755928
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == 0


# Generated at 2022-06-23 22:24:56.499027
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-23 22:24:57.927043
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings()
    assert _settings.debug == False


# Generated at 2022-06-23 22:25:04.948335
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

if __name__ == '__main__':
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-v', '--debug', action='store_true', help='Debug mode', default=False)
    args = parser.parse_args()

    init_settings(args)
    print(settings.debug)
    test_init_settings()

# Generated at 2022-06-23 22:25:07.119753
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:25:10.347328
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:25:12.811137
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:25:14.791790
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=1)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:25:15.901915
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    return


# Generated at 2022-06-23 22:25:17.381062
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

#Unit test for init_settings when debug info is true

# Generated at 2022-06-23 22:25:19.138218
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:25:20.581725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:22.782663
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert hasattr(settings, 'debug')
    assert settings.debug == True

# Generated at 2022-06-23 22:25:23.447954
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:25:25.445179
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == '__main__':
    test_Settings()