

# Generated at 2022-06-23 22:15:26.781867
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:15:29.037713
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert settings.debug == False

# Generated at 2022-06-23 22:15:32.226496
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # Positive test
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    # Negative test
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:15:33.940758
# Unit test for constructor of class Settings
def test_Settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:40.067578
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reads stdin, writes to stdout in reverse")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()
    init_settings(args)
    stdout.write(stdin.read()[::-1])
    if settings.debug:
        stdout.write(str(dict(debug=args.debug)))

# Generated at 2022-06-23 22:15:42.069626
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-23 22:15:44.608015
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:50.222243
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", default=False)
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", default=False)
    args = parser.parse_args()
    init_settings(args)
    print("settings = {}".format(settings.__dict__))

# Generated at 2022-06-23 22:15:52.756054
# Unit test for function init_settings
def test_init_settings():
    args=Namespace(debug=False)
    settings.debug=False
    init_settings(args)
    assert settings.debug==False
    args=Namespace(debug=True)
    settings.debug=False
    init_settings(args)
    assert settings.debug==True

# Generated at 2022-06-23 22:15:54.621782
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:15:55.629348
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:00.353341
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

if __name__ == "__main__":
    import doctest, sys
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-23 22:16:03.845744
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:04.824653
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:16:06.206979
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug == False


# Generated at 2022-06-23 22:16:07.841604
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)

    assert settings.debug == True

# Generated at 2022-06-23 22:16:09.357199
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:10.281691
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:12.216708
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:16:14.172074
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug=False
    assert settings.debug==False
    return "settings unit test passed"


# Generated at 2022-06-23 22:16:15.561806
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:17.452744
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:22.858521
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug == False


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')

    init_settings(parser.parse_args())
    test_init_settings()

# Generated at 2022-06-23 22:16:24.929456
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-23 22:16:30.195221
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(args=[sys.argv[0]])

# Generated at 2022-06-23 22:16:31.745054
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:16:34.777600
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert False == settings.debug
    args.debug = True
    init_settings(args)
    assert True == settings.debug
    print("Pass init_settings")

# Main function

# Generated at 2022-06-23 22:16:36.737478
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:16:37.749794
# Unit test for constructor of class Settings
def test_Settings():
    res = Settings()
    assert res.debug is False

# Generated at 2022-06-23 22:16:41.418746
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug is True
    # Test if one argument is missing
    args = Namespace()
    init_settings(args)
    assert settings.debug is not False
    assert settings.debug is False

# Generated at 2022-06-23 22:16:43.014652
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:43.858798
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:16:45.002140
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None
    assert settings.debug is False



# Generated at 2022-06-23 22:16:47.304773
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:16:52.575163
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = True
    init_settings(args)
    assert settings.debug is True

    args.debug = False
    init_settings(args)
    assert settings.debug is False


# Some handy constants for the program
ONE_DAY_SECONDS = 24 * 3600
ONE_HOUR_SECONDS = 3600
ONE_MINUTE_SECONDS = 60
ONE_SECOND_MILLISECONDS = 1000

# Generated at 2022-06-23 22:16:53.420135
# Unit test for constructor of class Settings
def test_Settings():
    sm = Settings()
    assert sm.debug == False



# Generated at 2022-06-23 22:16:54.446777
# Unit test for constructor of class Settings
def test_Settings():
    foo = Settings()
    assert not foo.debug


# Generated at 2022-06-23 22:16:56.249688
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:16:57.461753
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:16:58.400736
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:59.542135
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-23 22:17:00.840275
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings != None



# Generated at 2022-06-23 22:17:02.550605
# Unit test for constructor of class Settings
def test_Settings(): 
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:17:06.438285
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:17:09.406488
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True, 'Debug mode' + \
        ' has not been set to True'



# Generated at 2022-06-23 22:17:11.501922
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:13.787356
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:17:14.802606
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:17:15.707229
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:19.703774
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description='Command-line options for the tt-client.')
    parser.add_argument('-d', '--debug', action='store_true', default=False,
                        help='enable debugging output')
    args = parser.parse_args()

    init_settings(args)
    assert (settings.debug is True)

# Generated at 2022-06-23 22:17:20.592966
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:24.546322
# Unit test for function init_settings
def test_init_settings():
    test_data = [
        ((Namespace(debug=True)), True),
        ((Namespace(debug=False)), False),
    ]
    print("Testing function init_settings")

    for inp, expected in test_data:
        init_settings(inp)
        assert settings.debug == expected
        print("Passed test")

# Generated at 2022-06-23 22:17:25.752337
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:17:27.666428
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:17:30.635063
# Unit test for constructor of class Settings
def test_Settings():
    from argparse import Namespace
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:17:31.614117
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:17:34.320909
# Unit test for function init_settings
def test_init_settings():
    # Given
    args = Namespace()
    args.debug = True
    settings.debug = False
    # When
    init_settings(args)
    # Then
    assert settings.debug == True

# Generated at 2022-06-23 22:17:35.042688
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:38.221650
# Unit test for constructor of class Settings
def test_Settings():
    # Preamble
    args = Namespace()
    args.debug = True

    # Call function
    init_settings(args)

    # Test
    assert settings.debug is True

# Generated at 2022-06-23 22:17:47.555861
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

if __name__ == "__main__":
    # Running this file will execute all of the docstring examples.
    import doctest
    count, _ = doctest.testmod()
    if count == 0:
        print("*** ALL TESTS PASS ***\nGive someone a HIGH FIVE!")

    # These are the actual tests to check this file.
    init_settings(Namespace())
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    # Script end
    print("*** ALL TESTS PASS ***\nGive someone a HIGH FIVE!")

# Generated at 2022-06-23 22:17:48.770367
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:49.644408
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)



# Generated at 2022-06-23 22:17:52.997740
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False, "settings.debug is not set to debug"

# Generated at 2022-06-23 22:17:54.207723
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:17:55.966990
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:17:56.735203
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:17:58.388422
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True
    print("test_init_settings() passed")

# Generated at 2022-06-23 22:18:03.327356
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert(settings.debug==False)

    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug==True)

# Generated at 2022-06-23 22:18:04.339913
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:18:07.283247
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    assert not settings.debug
    init_settings(args)
    assert settings.debug
    init_settings(Namespace())
    assert not settings.debug

# Generated at 2022-06-23 22:18:08.452818
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:18:10.363499
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


init_settings(Namespace(debug=False))

# Generated at 2022-06-23 22:18:13.369553
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    assert settings.debug == False

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:15.106736
# Unit test for function init_settings
def test_init_settings():
    parsed_args = Namespace(debug=True)
    init_settings(parsed_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:17.102223
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:18:19.656740
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:18:23.594308
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:26.671686
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{"debug": True})
    init_settings(args)
    assert settings.debug == True
    args = Namespace(**{"debug": False})
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:28.043710
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:18:30.246899
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert True == settings.debug

# Generated at 2022-06-23 22:18:32.559391
# Unit test for function init_settings
def test_init_settings():
    testargs = Namespace(debug=True)
    init_settings(testargs)
    assert settings.debug

# Generated at 2022-06-23 22:18:35.289814
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:18:37.490974
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:18:38.891734
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert setting.debug == False


# Generated at 2022-06-23 22:18:42.040736
# Unit test for constructor of class Settings
def test_Settings():
    # test instance of class Settings
    assert isinstance(settings, Settings), "Settings must be an instance of class Settings"


# Generated at 2022-06-23 22:18:45.467794
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    settings.debug = False
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:49.056652
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    # now change the args
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:18:50.345403
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:18:51.824787
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:55.851553
# Unit test for constructor of class Settings
def test_Settings():
    """
    Unit test for constructor of class Settings
    :return: no return value, prints output
    """
    test_settings = Settings()
    test_settings.debug = False
    assert test_settings.debug is False



# Generated at 2022-06-23 22:18:58.167498
# Unit test for function init_settings
def test_init_settings():
    argv = ['-d']
    args = parser.parse_args(argv)
    init_settings()

    assert settings.debug is True

# Generated at 2022-06-23 22:19:01.429986
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:02.551443
# Unit test for constructor of class Settings
def test_Settings():
    temp = Settings()
    assert not temp.debug

# Generated at 2022-06-23 22:19:03.693266
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:04.653326
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:06.344462
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:09.722078
# Unit test for function init_settings
def test_init_settings():
    # arrange
    argv = ['--debug']
    parsed_args = parse_args(argv)
    # action
    init_settings(parsed_args)
    # assert
    assert settings.debug is True


# Generated at 2022-06-23 22:19:11.767914
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:13.000435
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:19.276179
# Unit test for constructor of class Settings
def test_Settings():
    if settings.debug:
        sys.stdout.write("TestSettings: Running unit test for constructor of class Settings...\n")

    Settings()
    assert settings.debug == False

    if settings.debug:
        sys.stdout.write("TestSettings: ...unit test for constructor of class Settings passed.\n")
    else:
        sys.stdout.write("TestSettings: Unit test for constructor of class Settings passed.\n")


# Generated at 2022-06-23 22:19:19.756998
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:19:21.009359
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:22.110102
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-23 22:19:23.059347
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:19:26.868761
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:28.393760
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:19:31.936982
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = 'not set'
    init_settings(args)
    assert settings.debug is False

    args.debug = True
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-23 22:19:34.082809
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:39.477541
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False, "Should be False"
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True, "Should be True"

# Run unit test
test_init_settings()

# Generated at 2022-06-23 22:19:40.820575
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:19:42.671553
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:44.494283
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    my_settings.debug = True
    assert my_settings.debug == True


# Generated at 2022-06-23 22:19:45.491952
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-23 22:19:46.871347
# Unit test for function init_settings
def test_init_settings():
    # given
    args = Namespace(debug=True)
    # when
    init_settings(args)
    # then
    assert args.debug == True

# Generated at 2022-06-23 22:19:48.696937
# Unit test for function init_settings
def test_init_settings():
    # set up
    args = Namespace()
    args.debug = False

    # function call
    init_settings(args)

    # verify
    assert not settings.debug



# Generated at 2022-06-23 22:19:49.443081
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:19:50.498911
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:52.730879
# Unit test for function init_settings
def test_init_settings():
    class stub_args:
        debug = True
    init_settings(stub_args)
    assert settings.debug == True


# Generated at 2022-06-23 22:19:54.529124
# Unit test for constructor of class Settings
def test_Settings():
    debug = False
    assert settings.debug == debug
    init_settings(1)
    assert settings.debug != debug


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:19:58.772170
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:20:00.514555
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:20:02.202003
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    assert settings.extra_args == ""

# Generated at 2022-06-23 22:20:04.502821
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert (not settings.debug)
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:06.787454
# Unit test for constructor of class Settings
def test_Settings():
    try:
        Settings()
        assert True
    except:
        assert False


# Generated at 2022-06-23 22:20:08.720419
# Unit test for function init_settings
def test_init_settings():
    # When
    init_settings(Namespace(debug=True))

    # Then
    assert settings.debug is True

# Generated at 2022-06-23 22:20:10.550724
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()

    assert(settings.debug == False)

# Generated at 2022-06-23 22:20:12.444893
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    settings.debug = True
    assert settings.debug is True


# Generated at 2022-06-23 22:20:13.550947
# Unit test for constructor of class Settings
def test_Settings():
    result = Settings()
    assert result.debug == False


# Generated at 2022-06-23 22:20:15.414678
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:20:16.826009
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-23 22:20:19.871829
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 22:20:21.006067
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:23.419223
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace(debug=True)
    init_settings(mock_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:25.422192
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:27.558493
# Unit test for function init_settings
def test_init_settings():
    parser = init_argparse()
    args = parser.parse_args(['--debug'])
    init_settings(args)
    # TODO check that settings.debug is True



# Generated at 2022-06-23 22:20:29.304548
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:31.272213
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True, "Failed to initialize debug variable"

# Unit tests for settings variable that is global

# Generated at 2022-06-23 22:20:33.454615
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    settings2 = Settings()
    assert settings1.debug == False
    assert settings1.debug == settings2.debug



# Generated at 2022-06-23 22:20:34.544155
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:35.640217
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:20:36.240974
# Unit test for constructor of class Settings

# Generated at 2022-06-23 22:20:38.016389
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:38.843629
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:20:40.142129
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:41.582070
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    
    assert settings.debug is False

# Generated at 2022-06-23 22:20:43.401711
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:20:46.082222
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:20:48.565947
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:20:50.236216
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug is False


# Generated at 2022-06-23 22:20:54.185675
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == args.debug

test_init_settings()

# Generated at 2022-06-23 22:20:57.136086
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert False == s.debug

    s.debug = True
    assert True == s.debug


# Generated at 2022-06-23 22:20:58.420949
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:21:01.501000
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:21:02.438395
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:04.716917
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:21:06.090104
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:07.990579
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:11.003910
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False



# Generated at 2022-06-23 22:21:12.755295
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:21:16.527326
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:21:17.203688
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:20.279289
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = type('', (object,), {"debug": True})()
    # Act
    init_settings(args)
    # Assert
    assert settings.debug is True

# Generated at 2022-06-23 22:21:22.284282
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:21:23.150680
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:24.332691
# Unit test for constructor of class Settings
def test_Settings():
    assert settings

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:21:25.275593
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:27.055845
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:27.933946
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:21:28.809566
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:21:29.720097
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:32.473713
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:33.357823
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:34.145937
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:36.430228
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:39.017157
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:21:40.068307
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:40.927744
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:41.744255
# Unit test for constructor of class Settings
def test_Settings():
    pass


# Generated at 2022-06-23 22:21:43.837513
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug is False


# Generated at 2022-06-23 22:21:45.380773
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:21:48.625115
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:51.070090
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:53.424998
# Unit test for constructor of class Settings
def test_Settings():
    """
    Unit test for constructor of class Settings
    """

    s = Settings()
    assert isinstance(s, Settings)

# Generated at 2022-06-23 22:21:55.109620
# Unit test for constructor of class Settings
def test_Settings():
    settings_ins = Settings()
    assert(settings_ins.debug == False)


# Generated at 2022-06-23 22:21:57.937305
# Unit test for constructor of class Settings
def test_Settings():
    settings0 = Settings()
    assert settings0.debug == False



# Generated at 2022-06-23 22:21:58.814462
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:22:00.837522
# Unit test for constructor of class Settings
def test_Settings():
    test_setting = Settings()
    if test_setting.debug == False:
        return True
    else:
        return False


# Generated at 2022-06-23 22:22:02.856129
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:04.041075
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings

# Generated at 2022-06-23 22:22:05.124984
# Unit test for constructor of class Settings
def test_Settings():
    S = Settings()
    assert not S.debug

# Generated at 2022-06-23 22:22:06.148763
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:07.216588
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    s.debug = False
    assert s.debug == False

# Generated at 2022-06-23 22:22:08.400740
# Unit test for constructor of class Settings
def test_Settings():
    assert settings
    print("Test_Settings: OK")


# Generated at 2022-06-23 22:22:09.458145
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:10.915111
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug is True



# Generated at 2022-06-23 22:22:13.272361
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:22:14.770248
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:18.268371
# Unit test for function init_settings
def test_init_settings():
    # Tests normal conditions
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert not hasattr(settings, 'before')

    # Tests exceptional conditions
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug == False

# Generated at 2022-06-23 22:22:20.110782
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    my_settings.debug = True

    assert my_settings.debug == True


# Generated at 2022-06-23 22:22:20.865149
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:22:22.080763
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:22:24.083326
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:25.079097
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings.debug == False


# Generated at 2022-06-23 22:22:26.391194
# Unit test for constructor of class Settings
def test_Settings():
    newSet = Settings()
    assert newSet.debug == False

# Generated at 2022-06-23 22:22:29.541547
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:22:32.494157
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:34.574529
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:22:36.172416
# Unit test for constructor of class Settings
def test_Settings():
    test_Settings = Settings()
    assert test_Settings.debug is False


# Generated at 2022-06-23 22:22:39.792461
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(
        debug=True
    )
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:48.181366
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Top-level script environment
if __name__ == '__main__':
    # Command-line arguments
    # NOTE: Arguments are parsed in main()
    parser = argparse.ArgumentParser(description='Math 720: Homework 0 - Unit Testing')

    # Optional arguments
    parser.add_argument('-d', '--debug', help='Enable debug mode', action='store_true')

    # Parse arguments
    args = parser.parse_args()

    # Initialize settings
    init_settings(args)

    # Run tests
    main()

# Generated at 2022-06-23 22:22:50.827024
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:22:51.936243
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    asse

# Generated at 2022-06-23 22:22:53.187268
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest.debug == False


# Generated at 2022-06-23 22:22:54.288098
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:22:56.382455
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-23 22:22:58.787714
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 22:23:03.998757
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# ==================================================
#
#    The following part is the main application
#
# ==================================================


# Generated at 2022-06-23 22:23:04.983349
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)


# Generated at 2022-06-23 22:23:10.465989
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Settings")
    parser.add_argument("--debug", help="Print debugging information", action="store_true")
    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-23 22:23:13.482722
# Unit test for function init_settings
def test_init_settings():
    # Test with debug mode is True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    # Test with debug mode is False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:23:15.324508
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:23:18.406049
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace())
    assert not settings.debug

    args1 = Namespace(debug=True)
    init_settings(args1)
    assert settings.debug

# Generated at 2022-06-23 22:23:21.258082
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:23.558686
# Unit test for function init_settings
def test_init_settings():
    parser = settings_parser()
    args = parser.parse_args(['-debug'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:25.393509
# Unit test for function init_settings
def test_init_settings():
    init_args = Namespace(debug=True)
    init_settings(init_args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:28.565163
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert not settings.debug_time
    assert not settings.debug_io

# Generated at 2022-06-23 22:23:30.315858
# Unit test for constructor of class Settings
def test_Settings():
    settings_temp = Settings()
    assert settings_temp.debug == False

# Generated at 2022-06-23 22:23:32.579084
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:23:34.562577
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{"debug": True})
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:35.845914
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert settings == s

# Generated at 2022-06-23 22:23:37.122834
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)



# Generated at 2022-06-23 22:23:39.628672
# Unit test for function init_settings
def test_init_settings():
    class Arguments:
        def __init__(self):
            self.debug = True

    args = Arguments()
    settings.debug = False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:41.857677
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

if __name__ == '__main__':
    args = Namespace(debug=True)
    init_settings(args)
    test_init_settings()

# Generated at 2022-06-23 22:23:44.715672
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:45.558975
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:23:49.222382
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", help="Run app in debug mode.", default=False)
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:50.120064
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:23:51.457979
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:57.187527
# Unit test for function init_settings
def test_init_settings():
    import sys
    import textwrap

    sys.argv = [
        "",
        "",
        "",
        "--debug"
    ]
    init_settings(sys.argv)
    if settings.debug:
        print("The debug is activated.")
    else:
        print("The debug is not activated.")


if __name__ == "__main__":
    import sys
    import textwrap

    sys.argv = sys.argv[1:]

    test_init_settings()

# Generated at 2022-06-23 22:23:59.309627
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    settings = Settings()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:05.286058
# Unit test for function init_settings
def test_init_settings():
    args = namedtuple('Args', ['debug'])
    init_settings(args)
    assert not settings.debug

    args = namedtuple('Args', ['debug'])
    args.debug = True
    init_settings(args)
    assert settings.debug

    # Test default usage
    args = namedtuple('Args', ['debug'])
    settings.debug = False
    init_settings(args)
    assert not settings.debug

    args = namedtuple('Args', ['debug'])
    args.debug = True
    settings.debug = False
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:06.449670
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings.debug, bool)

# Generated at 2022-06-23 22:24:10.479593
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert False == settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert True == settings.debug

test_init_se

# Generated at 2022-06-23 22:24:12.226459
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)



# Generated at 2022-06-23 22:24:13.574550
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:24:16.711822
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:24:18.067258
# Unit test for constructor of class Settings
def test_Settings():
    # Test for successful creation of an object
    assert Settings() is not None


# Generated at 2022-06-23 22:24:19.861352
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings.__class__ is Settings

# Generated at 2022-06-23 22:24:20.918367
# Unit test for constructor of class Settings
def test_Settings():
    set = Settings()
    assert se

# Generated at 2022-06-23 22:24:23.787017
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:26.009303
# Unit test for constructor of class Settings
def test_Settings():
    test_Settings = Settings()
    test_Settings.debug = False
    assert test_Settings.debug == False


# Generated at 2022-06-23 22:24:28.248429
# Unit test for constructor of class Settings
def test_Settings():
    print(settings.debug)  # False
    settings = Settings()
    settings.debug = True
    print(settings.debug)  # True
# test_Settings()



# Generated at 2022-06-23 22:24:30.084331
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:24:34.493645
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert settings.debug == True

# Generated at 2022-06-23 22:24:36.775386
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug == True




# Generated at 2022-06-23 22:24:41.152743
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Main of the program

# Generated at 2022-06-23 22:24:43.392248
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:45.467512
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert args.debug

# Generated at 2022-06-23 22:24:47.895576
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings2.debug == False

# Generated at 2022-06-23 22:24:48.985936
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:52.681934
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace()
    namespace.debug = True
    init_settings(namespace)
    assert settings.debug

    namespace = Namespace()
    namespace.debug = False
    init_settings(namespace)
    assert not settings.debug


# Generated at 2022-06-23 22:24:54.271446
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:55.790833
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:57.897887
# Unit test for function init_settings
def test_init_settings():
    args = []
    args.debug = True
    assert args.debug == True
    init_settings(args)

# Generated at 2022-06-23 22:25:01.271374
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:03.807216
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:25:06.370336
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    func_args = Namespace()
    func_args.debug = True
    init_settings(func_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:07.719559
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:25:10.152025
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug = True
    )
    init_settings(args)

    assert settings.debug == args.debug

test_init_settings()

# Generated at 2022-06-23 22:25:12.528722
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:25:14.231493
# Unit test for constructor of class Settings
def test_Settings():
    expected_debug = False
    settings = Settings()
    assert settings.debug == expected_debug


# Generated at 2022-06-23 22:25:16.057449
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


init_settings(Namespace(debug=True))


# Generated at 2022-06-23 22:25:17.835522
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

test_init_settings()

# Generated at 2022-06-23 22:25:19.563938
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False, "Error: Class Settings does not work properly"


# Generated at 2022-06-23 22:25:20.407681
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:25:21.476430
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False



# Generated at 2022-06-23 22:25:23.522029
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:25:24.532844
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:25:26.623303
# Unit test for constructor of class Settings
def test_Settings():
    parse_args = lambda: (namespace('debug'))
    init_settings(parse_args())
    assert settings.debug == True