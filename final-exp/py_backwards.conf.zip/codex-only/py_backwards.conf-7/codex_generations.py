

# Generated at 2022-06-23 22:15:21.792121
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug



# Generated at 2022-06-23 22:15:23.070485
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:24.005134
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-23 22:15:25.339105
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:15:27.538149
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:15:28.986613
# Unit test for constructor of class Settings
def test_Settings():
    mySettings = Settings()
    assert mySettings.debug == False


# Generated at 2022-06-23 22:15:30.824314
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True) # type: ignore
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:15:32.626134
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug

# Generated at 2022-06-23 22:15:34.318130
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:15:37.784184
# Unit test for function init_settings
def test_init_settings():
    # Test with debug=False
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    # Test with debug=True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:15:40.330960
# Unit test for function init_settings
def test_init_settings():
    fake_args = Namespace()
    fake_args.debug = True

    init_settings(fake_args)

    assert settings.debug == True

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:15:41.082018
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:15:41.829100
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:15:46.891723
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:15:48.287061
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:15:50.698065
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:52.590617
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    settings.debug = True
    assert settings.debug
    settings.debug = False

# Generated at 2022-06-23 22:15:54.466790
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:56.066814
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:57.437630
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug



# Generated at 2022-06-23 22:15:58.523004
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:00.047694
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    print("test_Settings PASSED")



# Generated at 2022-06-23 22:16:02.238190
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    settings.debug = False
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:16:03.597262
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-23 22:16:04.962475
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


test_Settings()

# Generated at 2022-06-23 22:16:07.085923
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing constructor of Settings")
    s = Settings()
    assert s.debug == False
    print("Test completed")


# Generated at 2022-06-23 22:16:08.693647
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

#Unit test for init_setting function

# Generated at 2022-06-23 22:16:10.430415
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:14.497012
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # debugging is off by default
    init_settings(args)
    assert not settings.debug

    # debugging is on if debug argument is passed
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:16.205454
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:16:17.508135
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:19.166386
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:22.312821
# Unit test for constructor of class Settings
def test_Settings():
    """
    Testing the constructor of class Settings
    """
    test_setting = Settings()
    test_setting.debug = False
    assert test_setting.debug == False



# Generated at 2022-06-23 22:16:23.918574
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:16:24.882952
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings != None)

# Generated at 2022-06-23 22:16:27.023629
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:28.665869
# Unit test for constructor of class Settings
def test_Settings():
    test1 = None
    test1 = Settings()

    assert not test1.debug


# Generated at 2022-06-23 22:16:29.336051
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:16:31.054576
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))

    assert settings.debug == True

# Generated at 2022-06-23 22:16:32.239192
# Unit test for constructor of class Settings
def test_Settings():
    config = Settings()
    assert (config.debug == False)



# Generated at 2022-06-23 22:16:33.199986
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:16:35.926168
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:16:36.900478
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:16:37.892170
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:45.286461
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True,
                     alpha=1e-5,
                     beta1=0.9,
                     beta2=0.999,
                     epsilon=1e-8,
                     iterations=200,
                     batch_size=32,
                     learn_rate=0.01,
                     l2_lambda=0,
                     csv_fpath='../diabetes.csv',
                     early_stopping=True,
                     patience=50,
                     get_weights=True,
                     save_fpath='theta.csv'
                     )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:46.672506
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None


# Generated at 2022-06-23 22:16:48.331044
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    s.debug = True
    assert s.debug == True


# Generated at 2022-06-23 22:16:49.255150
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:49.827951
# Unit test for constructor of class Settings
def test_Settings():
    assert settings

# Generated at 2022-06-23 22:16:52.298429
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    settings_content = settings.debug
    assert settings_content is False



# Generated at 2022-06-23 22:16:53.137948
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:54.384206
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:16:57.032002
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug


# End unit test for function init_settings


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:16:58.390467
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug is False


# Generated at 2022-06-23 22:16:59.869372
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:01.228213
# Unit test for constructor of class Settings
def test_Settings():
    # test default values
    assert settings.debug is False

# Generated at 2022-06-23 22:17:03.323976
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:17:05.387067
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:17:07.452640
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:08.135495
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:17:09.675854
# Unit test for constructor of class Settings
def test_Settings():
    testSettings = Settings()
    assert testSettings, "Test failed"


# Generated at 2022-06-23 22:17:11.711209
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:17:13.645203
# Unit test for constructor of class Settings
def test_Settings():
    instance = Settings()
    assert instance is not None

# Generated at 2022-06-23 22:17:15.707981
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    

# Generated at 2022-06-23 22:17:17.665480
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:17:18.544114
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:17:19.786826
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not (s.debug)


# Generated at 2022-06-23 22:17:21.343814
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:22.189080
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:17:23.242828
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:17:23.723931
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:17:33.192344
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Znapping tool.')
    parser.add_argument('-d', '--debug', action='store_true',
                        help='enable debug output')
    parser.add_argument('action', metavar='<ACTION>', type=str,
                        choices=['start', 'stop', 'status'], help='Action to execute.')
    parser.add_argument('jobid', metavar='<JOBID>', type=str, nargs='?',
                        help='Job ID as in the job list.')

# Generated at 2022-06-23 22:17:34.361344
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert not settings1.debug



# Generated at 2022-06-23 22:17:35.300780
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:17:37.626401
# Unit test for function init_settings
def test_init_settings():
    class args:
        debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:39.328365
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:40.727091
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:44.322111
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:53.339660
# Unit test for constructor of class Settings
def test_Settings():
    '''
    @type args: Namespace
    @rtype: None
    '''
    settings.debug = False
    
    parser = argparse.ArgumentParser()
    parser.add_argument("-debug", action="store_true")
    args = parser.parse_args()
    
    init_settings(args)
    
    assert settings.debug == False
    
    args = argparse.Namespace()
    args.debug = False
    
    init_settings(args)
    
    assert settings.debug == False
    
    args = argparse.Namespace()
    args.debug = True
    
    init_settings(args)
    
    assert settings.debug == True
    
# Unit tests for logic of function init_settings

# Generated at 2022-06-23 22:17:57.215153
# Unit test for function init_settings
def test_init_settings():
    from argh import ArghParser
    parser = ArghParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug
    args = parser.parse_args([])
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:17:58.507779
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:01.923485
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:18:05.753765
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description='Unit test for function init_settings')
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:08.097565
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:09.199385
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert(settings.debug == True)

# Generated at 2022-06-23 22:18:13.667295
# Unit test for constructor of class Settings
def test_Settings():
    # Create instances of class Settings
    settings1 = Settings()
    settings2 = Settings()
    assert settings1 is not settings2
    assert isinstance(settings1, Settings)
    assert isinstance(settings2, Settings)

# Generated at 2022-06-23 22:18:15.066894
# Unit test for constructor of class Settings
def test_Settings():
    print("Unit test for constructor of class Settings")
    global settings
    settings = Settings()


# Generated at 2022-06-23 22:18:17.030903
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:18:17.996539
# Unit test for function init_settings
def test_init_settings():
    class args:
        debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:18.606789
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:18:20.232545
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:18:27.984734
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    import sys
    import argparse

    parser = argparse.ArgumentParser(description="Setup python logger")
    parser.add_argument(
        "-d",
        "--debug",
        default=False,
        action="store_true",
        help="Set logging level to DEBUG. Defaults to WARNING.")

    args = parser.parse_args(sys.argv[1:])
    init_settings(args)

# Generated at 2022-06-23 22:18:30.942379
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:18:31.933768
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:32.935132
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:36.529660
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:37.876789
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s is not None


# Generated at 2022-06-23 22:18:40.099139
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:18:42.564823
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:44.947939
# Unit test for constructor of class Settings
def test_Settings():
    old = settings.debug
    settings.debug = True
    assert settings.debug == True
    settings.debug = old
    assert settings.debug == old

# Generated at 2022-06-23 22:18:45.812385
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:47.763180
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True, "expected debug to be True, got False"

# Generated at 2022-06-23 22:18:48.976291
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug

# Generated at 2022-06-23 22:18:50.611622
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-23 22:18:52.076886
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:54.925431
# Unit test for constructor of class Settings
def test_Settings():
    print("Running test for constructor of class Settings")
    assert type(settings) is Settings
    assert settings.debug == False


# Generated at 2022-06-23 22:18:58.476980
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:19:00.295591
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:00.901714
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == Settings()

# Generated at 2022-06-23 22:19:02.611218
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:03.742708
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:19:05.437907
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug




# Generated at 2022-06-23 22:19:06.934189
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:19:08.692242
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:10.365612
# Unit test for constructor of class Settings
def test_Settings():

    settings = Settings()
    assert not settings.debug

    settings.debug = True
    assert settings.debug

# Generated at 2022-06-23 22:19:13.116377
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:15.748503
# Unit test for constructor of class Settings
def test_Settings():
    a=Settings()
    assert not a.debug


# Generated at 2022-06-23 22:19:18.450692
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    print('Test of init_settings passed')

# Generated at 2022-06-23 22:19:19.980847
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:22.912228
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert(not settings.debug)

    args = Namespace(debug = True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-23 22:19:25.863339
# Unit test for function init_settings
def test_init_settings():
    global settings
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    print("test init_settings passed.")

# Generated at 2022-06-23 22:19:27.741477
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:29.797667
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:30.823036
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:19:32.085603
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:34.026312
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-23 22:19:36.543584
# Unit test for function init_settings
def test_init_settings():
    # Given
    args = Namespace(debug=True)

    # When
    init_settings(args)

    # Then
    assert settings.debug == True

# Generated at 2022-06-23 22:19:38.385579
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:40.069558
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:19:41.187601
# Unit test for constructor of class Settings
def test_Settings():
    assert settings != None


# Generated at 2022-06-23 22:19:43.274943
# Unit test for constructor of class Settings
def test_Settings():
    settings_instance = Settings()
    settings_instance.debug = True
    assert settings_instance.debug == True


# Generated at 2022-06-23 22:19:44.422930
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug

# Generated at 2022-06-23 22:19:45.828985
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:46.871190
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False



# Generated at 2022-06-23 22:19:48.451942
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:19:50.782819
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

test_init_settings()

# Generated at 2022-06-23 22:19:52.644273
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:53.784758
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-23 22:19:56.312073
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False



# Generated at 2022-06-23 22:19:58.089445
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    settings.debug = False

# Generated at 2022-06-23 22:20:00.993168
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert True == settings.debug
    #settings.debug = False
    #assert False == settings.debug

# Generated at 2022-06-23 22:20:04.150253
# Unit test for function init_settings
def test_init_settings():
    arg = argparse.ArgumentParser()
    arg.add_argument("--debug",
                     action="store_true", default=False)
    init_settings(arg.parse_args(["--debug"]))
    assert settings.debug is True

# Generated at 2022-06-23 22:20:07.743531
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, 'debug', True)
    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-23 22:20:09.999239
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:20:12.168975
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug


# Generated at 2022-06-23 22:20:13.282882
# Unit test for constructor of class Settings
def test_Settings():  
    settings1 = Settings()
    
    assert not settings.debug



# Generated at 2022-06-23 22:20:15.041210
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    settings_test.debug = False
    assert settings_test.debug == False


# Generated at 2022-06-23 22:20:16.942980
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:20:18.489586
# Unit test for constructor of class Settings
def test_Settings():
    t = Settings()
    assert not t.debug


# Generated at 2022-06-23 22:20:20.732039
# Unit test for function init_settings
def test_init_settings():
    args_debug = Namespace(debug = True)
    init_settings(args_debug)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:21.894615
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:23.368908
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False


# Generated at 2022-06-23 22:20:25.253281
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-23 22:20:26.365664
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:32.737458
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", help="Start server in debug mode.")

    args = parser.parse_args()
    init_settings(args)
    print(settings.debug)

    # Unit test
    test_init_settings()

# Generated at 2022-06-23 22:20:36.723979
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    init_settings(Namespace(debug = False))
    assert settings.debug == False
    init_settings(Namespace(debug = True))
    assert settings.debug == True

# Generated at 2022-06-23 22:20:38.110669
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False


# Generated at 2022-06-23 22:20:40.652616
# Unit test for function init_settings
def test_init_settings():
    # Test
    args = Namespace(
        debug=True
    )

    init_settings(args)

    # Assert
    assert settings.debug == True

# Generated at 2022-06-23 22:20:44.354741
# Unit test for constructor of class Settings
def test_Settings():
    # test with default arguments
    s = Settings()
    assert s.debug is False

    # test constructor with one argument
    s = Settings()
    s.debug = True
    assert s.debug is True



# Generated at 2022-06-23 22:20:45.886467
# Unit test for constructor of class Settings
def test_Settings():
    uut = Settings()
    assert uut.debug == False


# Generated at 2022-06-23 22:20:47.337825
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:20:49.252003
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    assert isinstance(settings, Settings)



# Generated at 2022-06-23 22:20:50.658583
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:20:52.106028
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:53.463482
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:20:56.014274
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:57.848456
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:59.659000
# Unit test for constructor of class Settings
def test_Settings():
    assert settings


# Generated at 2022-06-23 22:21:01.876451
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert not a.debug


# Unit test to test init_settings()

# Generated at 2022-06-23 22:21:04.518274
# Unit test for function init_settings
def test_init_settings():
    kwargs = {"debug": True}
    args = Namespace(**kwargs)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:21:05.109867
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

# Generated at 2022-06-23 22:21:07.955747
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:21:09.551935
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:10.668409
# Unit test for constructor of class Settings
def test_Settings():
    Settings()

# Generated at 2022-06-23 22:21:12.333247
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:21:14.022820
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    print(settings.debug)


# Generated at 2022-06-23 22:21:16.330842
# Unit test for function init_settings
def test_init_settings():
    argv = ['-d','debug']
    args = parse_args(argv)
    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-23 22:21:18.087617
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:19.701447
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:20.574639
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:22.201400
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:26.787069
# Unit test for function init_settings
def test_init_settings():
    # Case: Arguments given
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True, "Debug flag should be set to true"

    # Case: No arguments given
    args = Namespace()
    init_settings(args)
    assert not settings.debug, "Debug flag should be set to false"


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:21:28.649371
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:21:29.553961
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:32.079544
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:21:33.380621
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug and s.__class__.__name__ == 'Settings'

# Generated at 2022-06-23 22:21:34.477569
# Unit test for constructor of class Settings
def test_Settings():
    temp = Settings()
    assert temp.debug == False


# Generated at 2022-06-23 22:21:35.831540
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:21:38.019636
# Unit test for constructor of class Settings
def test_Settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)

# Generated at 2022-06-23 22:21:39.628320
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings != None
    assert test_settings.debug == False


# Generated at 2022-06-23 22:21:40.271385
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:21:42.934655
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{"debug": True})
    init_settings(args)
    assert (settings.debug == True)
    args = Namespace(**{"debug": False})
    init_settings(args)
    assert (settings.debug == False)

# Generated at 2022-06-23 22:21:44.232600
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:21:45.118278
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:46.444732
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:50.116694
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    return


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:21:52.574775
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:21:54.184567
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:55.535393
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug



# Generated at 2022-06-23 22:21:56.487585
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:57.387700
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:58.691027
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)

# Generated at 2022-06-23 22:22:02.519002
# Unit test for function init_settings
def test_init_settings():
    def test_init_settings_debug(args, expected_result):
        init_settings(args)
        assert settings.debug == expected_result

    # Test for debug
    test_init_settings_debug(Namespace(debug=True), True)
    test_init_settings_debug(Namespace(debug=False), False)

# Generated at 2022-06-23 22:22:03.390954
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:04.558668
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-23 22:22:05.687593
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Function to test init_settings

# Generated at 2022-06-23 22:22:08.240662
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

test_init_settings()

# Generated at 2022-06-23 22:22:09.415203
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-23 22:22:11.200858
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

    # Change value of attribute debug from False to True
    settings.debug = True

    assert settings.debug == True

# Generated at 2022-06-23 22:22:12.732794
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:15.228711
# Unit test for function init_settings
def test_init_settings():
    # Create fake argparse namespace
    args = Namespace()
    args.debug = True
    
    # Call test method
    init_settings(args)

    # Assert result
    assert settings.debug



# Generated at 2022-06-23 22:22:20.072726
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

if __name__ == "__main__":
    # execute only if run as a script
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true", help="debug mode")
    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-23 22:22:21.139069
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:22:23.989266
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:27.110626
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:22:28.911328
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


test_init_settings()

# Generated at 2022-06-23 22:22:31.806698
# Unit test for function init_settings
def test_init_settings():
    argv = ['--debug', 'true']
    args = parse_args(argv)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:34.980312
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:22:36.921504
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:42.001446
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug

    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:22:44.407007
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:22:45.763006
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:22:47.801453
# Unit test for function init_settings
def test_init_settings():

    class A:
        pass

    t = A()
    t.debug = True

    init_settings(t)
    assert settings.debug

# Generated at 2022-06-23 22:22:49.011591
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:49.939384
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:22:51.306264
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False



# Generated at 2022-06-23 22:22:52.655588
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:57.539947
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    if settings.debug:
        print("Test")

# Generated at 2022-06-23 22:22:58.642421
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:23:00.606241
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:23:02.277254
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:03.886061
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug != False

# Generated at 2022-06-23 22:23:04.619316
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:08.102591
# Unit test for function init_settings
def test_init_settings():
    # S: Input = Namespace(debug=True)
    # E: Settings.debug = True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:09.494121
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:23:11.320388
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    settings.debug = True
    assert settings.debug is True



# Generated at 2022-06-23 22:23:12.404682
# Unit test for constructor of class Settings
def test_Settings():
    app = Settings()
    assert app.debug == False


# Generated at 2022-06-23 22:23:13.760538
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


if __name__ == "__main__":
    settings = Settings()

# Generated at 2022-06-23 22:23:16.255280
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:23:17.900846
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:23:20.309350
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings == Settings()
    assert not settings.debug
    return


# Generated at 2022-06-23 22:23:21.367014
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:22.423079
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:23.880048
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    assert settings.debug == True

# Generated at 2022-06-23 22:23:27.304309
# Unit test for function init_settings
def test_init_settings():
    import argparse
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    # Set back to default
    settings.debug = False

# Generated at 2022-06-23 22:23:29.900981
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, 'debug', True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:33.557733
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:34.671449
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)



# Generated at 2022-06-23 22:23:37.079013
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:37.984785
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Unit test

# Generated at 2022-06-23 22:23:40.103698
# Unit test for constructor of class Settings
def test_Settings():
    # pylint: disable=no-self-use
    settings = Settings()
    assert settings is not None
    assert settings.debug == False


# Generated at 2022-06-23 22:23:41.829081
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:43.293911
# Unit test for constructor of class Settings
def test_Settings():
    import pytest

    with pytest.raises(TypeError):
        Settings('test')
    assert settings.debug

# Generated at 2022-06-23 22:23:46.089564
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    print("Unit Testing Settings")
    test_init_settings()
    print("Unit Tests Success")

# Generated at 2022-06-23 22:23:46.628749
# Unit test for function init_settings
def test_init_settings():
    pass

# Generated at 2022-06-23 22:23:48.795379
# Unit test for function init_settings
def test_init_settings():
    # settings should be initialized
    args = Namespace()
    args.debug = True

# Generated at 2022-06-23 22:23:49.725790
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:50.649519
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:23:51.961697
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:55.733721
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args = Namespace(debug=False)
    init_settin

# Generated at 2022-06-23 22:23:57.247732
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False



# Generated at 2022-06-23 22:24:01.189740
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    settings = Settings()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True

    test_args.debug = False
    init_settings(test_args)
    assert settings.debug == False


# Generated at 2022-06-23 22:24:05.789300
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    settings.debug = True



# Generated at 2022-06-23 22:24:09.023015
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:10.429021
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:24:11.801858
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:24:12.682049
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == True

# Generated at 2022-06-23 22:24:14.434294
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:17.096685
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:20.566373
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:22.020724
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:24:26.008568
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:27.152274
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:24:29.573095
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:33.534506
# Unit test for function init_settings
def test_init_settings():
    global settings
    parsed_args = Namespace(debug=False)
    init_settings(parsed_args)
    assert settings.debug == False

    parsed_args = Namespace(debug=True)
    init_settings(parsed_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:35.827199
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:24:37.205585
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (isinstance(s, Settings))



# Generated at 2022-06-23 22:24:38.184297
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:24:40.219343
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:43.094281
# Unit test for function init_settings
def test_init_settings():
    # Tests if it can be imported and called
    init_settings(Namespace())
    assert True
    # Tests if it can assign a value to the variables in settings module
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:24:45.508670
# Unit test for function init_settings
def test_init_settings():
    args = type("", (), {})
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:48.342742
# Unit test for function init_settings
def test_init_settings():
    a = Namespace()
    a.debug = True
    init_settings(a)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:50.389549
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

test_init_settings()

# Generated at 2022-06-23 22:24:52.154440
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:54.625779
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:24:56.499020
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:57.927824
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:59.231430
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-23 22:25:03.090190
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:25:05.217245
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:25:13.753683
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert(settings.debug)


if __name__ == '__main__':
    help_text = """This script shows how to parse arguments.
    For example, to set debug mode:
        python args.py -D
    You can add arguments to the parser below"""
    parser = argparse.ArgumentParser(help_text)
    parser.add_argument("-D", "--debug", help="run in debug mode", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    print("You passed args {}".format(args))

# Generated at 2022-06-23 22:25:19.116577
# Unit test for function init_settings
def test_init_settings():
    # Test for different arguments for init_settings().
    class Args:
        def __init__(self):
            self.debug = False
            self.verbose = False
            self.light = False

    args = Args()
    args.debug = True
    init_settings(args)
    # Expected behavior - debug mode on
    assert settings.debug

    args.debug = False
    init_settings(args)
    # Expected behavior - debug mode off
    assert not settings.debug

# Generated at 2022-06-23 22:25:20.265383
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    assert s.debug == False


# Generated at 2022-06-23 22:25:22.051894
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug == True
