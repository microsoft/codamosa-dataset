

# Generated at 2022-06-23 22:15:26.877682
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:15:27.874985
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:15:30.176730
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

test_init_settings()

# Generated at 2022-06-23 22:15:33.200649
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False, "The debug flag should be set to false as default"


# Generated at 2022-06-23 22:15:38.206975
# Unit test for function init_settings
def test_init_settings():

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:15:39.245467
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:42.530407
# Unit test for function init_settings
def test_init_settings():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_known_args()[0]
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:43.728209
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:45.963956
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert(settings.debug)

# Generated at 2022-06-23 22:15:46.854628
# Unit test for constructor of class Settings
def test_Settings():
    tm = Settings()
    assert not tm.debug


# Generated at 2022-06-23 22:15:48.287009
# Unit test for constructor of class Settings
def test_Settings():
    settings=Settings()
    assert settings.debug== False



# Generated at 2022-06-23 22:15:59.267284
# Unit test for function init_settings
def test_init_settings():

    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args()

    init_settings(args)
    assert settings.debug == False

    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args('-d'.split())

    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:16:01.208050
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    settings.debug = False

# Generated at 2022-06-23 22:16:03.336371
# Unit test for constructor of class Settings
def test_Settings():
    with pytest.raises(Exception):
        s = Settings()
        assert (s.debug == False)



# Generated at 2022-06-23 22:16:06.772823
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert settings.debug == False

    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:08.050299
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None
    assert settings.debug is False

# Generated at 2022-06-23 22:16:13.826380
# Unit test for function init_settings
def test_init_settings():
    args = {
        "debug": True,
        "start_date": "2020-08-01",
        "end_date": "2020-08-31",
        "directory": "./data",
        "progress": False
    }
    settings = Settings()
    init_settings(args)
    assert settings.debug == args["debug"]

test_init_settings()

# Generated at 2022-06-23 22:16:14.450487
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:16:15.801139
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False



# Generated at 2022-06-23 22:16:18.207995
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:16:19.845105
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:22.414109
# Unit test for constructor of class Settings
def test_Settings():
    # First parameter is debug
    settings = Settings(True)

    # Checks if debug is true
    settings.debug


# Generated at 2022-06-23 22:16:25.887252
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert args.debug



# Generated at 2022-06-23 22:16:27.525742
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert (settings_test.debug == False)

# Generated at 2022-06-23 22:16:31.161054
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:16:32.788968
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:34.880975
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:40.001498
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# 'Namespace' object has no attribute 'verify'
# def test_init_settings_no_attr():
#     args = Namespace(verify=True)
#     init_settings(args)

# Generated at 2022-06-23 22:16:42.027178
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert(settings.debug == True)

# Generated at 2022-06-23 22:16:44.117405
# Unit test for function init_settings
def test_init_settings():
    # test for setting.debug equals True
    settings.debug=False
    init_settings(Namespace(debug=True))
    assert settings.debug == True


# Generated at 2022-06-23 22:16:44.749028
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:46.848363
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug

# Unit test init_settings

# Generated at 2022-06-23 22:16:49.566562
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:50.466744
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))

# Generated at 2022-06-23 22:16:53.195225
# Unit test for function init_settings
def test_init_settings():
    # create testing arguments
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    # create testing arguments
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:54.724228
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:55.937362
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:16:56.644146
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:17:00.193669
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    # debug flag should be set to False by default
    assert settings.debug == False
    # test when debug flag is False
    init_settings(args)
    assert settings.debug == False

    # test when debug flag is enabled
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:01.335114
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:02.606025
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:04.056183
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:17:07.171538
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Integration test for function get_args and init_settings

# Generated at 2022-06-23 22:17:09.621010
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(
        debug = True,
    )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:13.687991
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:17:15.410451
# Unit test for constructor of class Settings
def test_Settings():
    test_Settings = Settings()
    test_Settings.debug = True
    assert test_Settings.debug == True

# Generated at 2022-06-23 22:17:18.033289
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:19.281651
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(settings.debug == False)

# Generated at 2022-06-23 22:17:20.609031
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:22.609021
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:17:24.215098
# Unit test for function init_settings
def test_init_settings():
    class Args:
        debug = True

    init_settings(Args)
    assert settings.debug is True
#EOF

# Generated at 2022-06-23 22:17:28.111604
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:29.035921
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:17:35.855840
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    # Check that debug is not set to true before
    assert not settings.debug
    init_settings(args)
    # Check if debug is set to true after
    assert settings.debug



# Generated at 2022-06-23 22:17:38.553400
# Unit test for constructor of class Settings
def test_Settings():
    # Create a new instance of class Settings to be used for the test
    settings_instance = Settings()
    # Check if the value of the default attributes are correct
    assert settings_instance.debug == False


# Generated at 2022-06-23 22:17:39.513387
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:41.300826
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:17:42.532398
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:17:46.830719
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', help = "Enable debug")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:48.130545
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug== True

# Generated at 2022-06-23 22:17:49.025967
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:17:50.121947
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:17:52.226408
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:17:55.096728
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:17:56.481918
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:17:57.489111
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True


# Generated at 2022-06-23 22:17:58.777618
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug
    s.debug = True
    assert s.debug

# Generated at 2022-06-23 22:18:00.150593
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:18:01.820833
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:18:04.245283
# Unit test for function init_settings
def test_init_settings():
    args = types.SimpleNamespace(
        debug = True
    )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:05.666552
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:07.107191
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-23 22:18:08.246096
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:11.261342
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert not settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:18:13.667770
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:16.025334
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:18:17.101583
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug is False


# Generated at 2022-06-23 22:18:18.624599
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:18:22.870218
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:24.211377
# Unit test for constructor of class Settings
def test_Settings():
    # no args given default debug is False
    assert not settings.debug

# Generated at 2022-06-23 22:18:26.546862
# Unit test for constructor of class Settings
def test_Settings():
    actual = Settings()
    assert actual is not None, "Settings object is not None"
    assert actual.debug is False, "Debug set to false by default"


# Generated at 2022-06-23 22:18:27.987830
# Unit test for constructor of class Settings
def test_Settings():
    sett = Settings()
    assert sett.debug is False

# Generated at 2022-06-23 22:18:29.067742
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:30.802381
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True


# Generated at 2022-06-23 22:18:32.124188
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj.debug is False


# Generated at 2022-06-23 22:18:34.832987
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug, "debug False"

# Generated at 2022-06-23 22:18:37.460512
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:18:38.892486
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings()
    assert _settings.debug == False



# Generated at 2022-06-23 22:18:42.406194
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_args = Namespace(debug=False)
    init_settings(test_args)

    assert test_settings.debug is False

# Generated at 2022-06-23 22:18:43.250032
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:18:44.405035
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:18:45.607940
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:18:47.553440
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange
    settings = Settings()

    # Act
    actual = settings.debug

    # Assert
    assert actual == False



# Generated at 2022-06-23 22:18:48.766222
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:18:51.678442
# Unit test for constructor of class Settings
def test_Settings():
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from settings import Settings

    assert not Settings().debug



# Generated at 2022-06-23 22:18:55.237613
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:57.128993
# Unit test for constructor of class Settings
def test_Settings():
    import pytest
    with pytest.raises(TypeError):
        Settings('Hello')



# Generated at 2022-06-23 22:18:57.758917
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:59.544341
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Run as script if not imported
if __name__ == "__main__":
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:00.950787
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-23 22:19:03.186306
# Unit test for function init_settings
def test_init_settings():
    global settings

    settings = Settings()
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:07.987258
# Unit test for function init_settings
def test_init_settings():
    cli_args = ["--debug"]
    args = parser.parse_args(cli_args)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:19:09.407063
# Unit test for constructor of class Settings
def test_Settings():
    instance = Settings()

    assert instance is not None



# Generated at 2022-06-23 22:19:14.007977
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test program")
    parser.add_argument('-d', '--debug', action='store_true', help='Enable debug mode')
    args = parser.parse_args()
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-23 22:19:16.853096
# Unit test for constructor of class Settings
def test_Settings():
    temp_args = Namespace()
    temp_args.debug = True
    init_settings(temp_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:18.272918
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:19:20.057743
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = False
    assert test_settings.debug == settings.debug

# Generated at 2022-06-23 22:19:21.010110
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:19:22.500337
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:25.864612
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert not settings.debug
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:19:28.236554
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert type(settings) == Settings
    assert isinstance(settings.debug, bool)


test_Settings()

# Generated at 2022-06-23 22:19:31.017758
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug, "Debug should be True if set by args"



# Generated at 2022-06-23 22:19:33.378107
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-23 22:19:35.422160
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args(['-d'])
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:40.734133
# Unit test for function init_settings
def test_init_settings():
    # Test case 1: test with args.debug set to False.
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # Test case 2: test with args.debug set to True.
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:43.940384
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# -----------------------------------------------------------------------------
# Diagnostics
# -----------------------------------------------------------------------------


# Generated at 2022-06-23 22:19:45.387402
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()  # type: Settings
    assert test_settings.debug is False


# Generated at 2022-06-23 22:19:47.324555
# Unit test for function init_settings
def test_init_settings():
    input_args = Namespace(
        debug=True,
    )
    init_settings(input_args)
    assert(settings.debug)


# TODO: function get_settings()

# Generated at 2022-06-23 22:19:48.099248
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:49.161053
# Unit test for constructor of class Settings
def test_Settings():
    instance = Settings()
    assert instance
    assert not instance.debug

# Generated at 2022-06-23 22:19:51.132639
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Unit tests to test the init_settings() helper method

# Generated at 2022-06-23 22:19:53.784524
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:55.906029
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:58.425623
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:20:00.223789
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:00.700904
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

# Generated at 2022-06-23 22:20:01.508916
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:20:02.909623
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Unit test: Test init_settings function

# Generated at 2022-06-23 22:20:03.821909
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-23 22:20:06.695332
# Unit test for function init_settings
def test_init_settings():
    debug = True
    init_settings(Namespace(debug=debug))
    assert settings.debug == debug

# Generated at 2022-06-23 22:20:08.344733
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False


# Generated at 2022-06-23 22:20:10.144830
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:11.156963
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-23 22:20:13.084674
# Unit test for constructor of class Settings
def test_Settings():
    assert issubclass(Settings, object)
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:20:14.649452
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:16.065316
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Unit tests for init_settings

# Generated at 2022-06-23 22:20:17.078829
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:20:18.162661
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:20:20.401955
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:20:21.520379
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:20:22.394544
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:24.781264
# Unit test for constructor of class Settings
def test_Settings():
    msg = "Incorrect data type in Settings constructor"
    s = Settings()
    assert(isinstance(s.debug, bool)), msg


# Generated at 2022-06-23 22:20:27.365863
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:20:29.120530
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert (settings.debug == False)


# Generated at 2022-06-23 22:20:31.358509
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:20:32.274062
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-23 22:20:34.021857
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False

# Generated at 2022-06-23 22:20:35.591672
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:20:37.150210
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-23 22:20:38.904135
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:20:42.154831
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == False
    #assert settings.debug == True

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:46.225981
# Unit test for constructor of class Settings
def test_Settings():
    # Create an Array
    settings = Settings()
    # Check for debug option
    assert settings.debug == False

    # Unit test for init_settings
    Init_settings(Namespace())
    # Check for debug option
    assert settings.debug == False

# Generated at 2022-06-23 22:20:51.388128
# Unit test for function init_settings
def test_init_settings():
    #return 1
    class FakeArgs:
        def __init__(self):
            self.debug = True
            #self.debug = False

    args = FakeArgs()
    if args.debug:
        settings.debug = True
    init_settings(args)
    assert settings.debug == args.debug

test_init_settings()

# Generated at 2022-06-23 22:20:56.336496
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, filename=None, schema=None, url=None)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False, filename=None, schema=None, url=None)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:20:59.182350
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:01.359410
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:04.028918
# Unit test for function init_settings
def test_init_settings():
    input_values = [
        ['--debug'],
    ]
    for args in input_values:
        result = init_settings(args)
        assert result == None


# Generated at 2022-06-23 22:21:06.561605
# Unit test for constructor of class Settings
def test_Settings():
    if __name__ == "__main__":
        print("test_Settings()")
        settings = Settings()
        print(settings.debug)


# Generated at 2022-06-23 22:21:09.402578
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:21:10.951208
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:12.626901
# Unit test for constructor of class Settings
def test_Settings():
    new_obj = Settings()
    assert new_obj.debug == False

# Generated at 2022-06-23 22:21:13.809966
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:21:16.024652
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug is True


# Generated at 2022-06-23 22:21:17.292169
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:19.320577
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:21:22.364308
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False


# Generated at 2022-06-23 22:21:23.890076
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:24.733388
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-23 22:21:25.863384
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-23 22:21:26.973237
# Unit test for constructor of class Settings
def test_Settings():
    settings=Settings()
    #bool returned for debug object
    assert type(settings.debug)==bool

# Generated at 2022-06-23 22:21:27.979925
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:21:29.262818
# Unit test for function init_settings
def test_init_settings():
    g = globals()
    g['settings'].debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:21:30.227390
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:32.206466
# Unit test for function init_settings
def test_init_settings():
    args=Namespace()
    args.debug=True
    init_settings(args)
    assert settings.debug==True

# Generated at 2022-06-23 22:21:32.973449
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False


# Generated at 2022-06-23 22:21:33.746418
# Unit test for constructor of class Settings
def test_Settings():
    aSetting = Settings()
    assert aSetting


# Generated at 2022-06-23 22:21:34.550848
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:36.576714
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:38.018606
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert not a.debug

# Generated at 2022-06-23 22:21:40.446299
# Unit test for function init_settings
def test_init_settings():
    parser = get_argparser()
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:21:44.363416
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Parse the arguments on the command line
parser = argparse.ArgumentParser()
parser.add_argument('-d', '--debug', help='enable debug mode', action='store_true')
args = parser.parse_args()

init_settings(args)

# Generated at 2022-06-23 22:21:46.769545
# Unit test for function init_settings
def test_init_settings():
    # dummy args
    args = Namespace()

    # Check for debug method
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:49.843116
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-23 22:21:52.893263
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)

test_Settings()


# Generated at 2022-06-23 22:21:53.937708
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)

# Generated at 2022-06-23 22:21:55.534267
# Unit test for constructor of class Settings
def test_Settings():
    settings_obj1 = Settings()
    assert settings_obj1.debug == False


# Generated at 2022-06-23 22:21:57.517949
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False

    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:22:02.772030
# Unit test for function init_settings
def test_init_settings():
    assert init_settings() is None
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True
# Call the unit tests
test_init_settings() # pragma: no cover

"""
# Sample program
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("echo")
args = parser.parse_args()
print(args.echo)
"""

# Generated at 2022-06-23 22:22:03.633395
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:22:05.115746
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug == False
    return True


# Generated at 2022-06-23 22:22:06.215737
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:08.289299
# Unit test for constructor of class Settings
def test_Settings():

    # case 1: test for debug
    settings.debug = False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:22:09.775384
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug == False


# Generated at 2022-06-23 22:22:11.239962
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:22:12.426941
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert False == s.debug



# Generated at 2022-06-23 22:22:15.386525
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:15.932537
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None

# Generated at 2022-06-23 22:22:16.549246
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:22:18.111344
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:22:20.560624
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:23.683820
# Unit test for function init_settings
def test_init_settings():
    settings.debug = True
    #args = Namespace(debug = True)
    #init_settings(args)
    
    assert settings.debug == T

# Generated at 2022-06-23 22:22:26.821379
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert args.debug == settings.debug

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:22:28.011332
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)



# Generated at 2022-06-23 22:22:29.194945
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:22:32.747037
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:36.517640
# Unit test for function init_settings
def test_init_settings():
    settings_debug = Settings()
    settings_debug.debug = True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings == settings_debug 
    
test_init_settings()

# Generated at 2022-06-23 22:22:39.103414
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest


# Generated at 2022-06-23 22:22:43.671302
# Unit test for function init_settings
def test_init_settings():
    """Unit test for init_settings()"""
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

if __name__ == "__main__":
    args = Namespace()
    args.debug = True
    init_settings(args)
    test_init_settings()

# Generated at 2022-06-23 22:22:44.993721
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:22:46.008435
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:22:46.791572
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:22:48.019400
# Unit test for constructor of class Settings
def test_Settings():
    newSettings = Settings()
    assert not newSettings.debug


# Generated at 2022-06-23 22:22:48.895738
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-23 22:22:50.527250
# Unit test for constructor of class Settings
def test_Settings():
    debug_settings = Settings()
    debug_settings.debug = False
    assert debug_settings.debug == False



# Generated at 2022-06-23 22:22:52.741761
# Unit test for function init_settings
def test_init_settings():
    args = parser.parse_args([
        '--debug'
    ])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:53.821004
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:57.054775
# Unit test for function init_settings
def test_init_settings():
    import argparse
    settings = Settings()
    args = argparse.Namespace()
    settings.debug = True
    args.debug = 1
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:58.022126
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:01.033172
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    if not settings.debug:
        print("Settings constructor test passed")
    else:
        print("Settings constructor test failed")


# Generated at 2022-06-23 22:23:01.990419
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:05.154709
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    print(settings.debug)

# Generated at 2022-06-23 22:23:06.065490
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-23 22:23:08.448381
# Unit test for function init_settings
def test_init_settings():
    assert(settings.debug == False)
    args = Namespace()
    setattr(args, 'debug', True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:23:10.483477
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    init_settings(Namespace())
    assert settings.debug is False

# Generated at 2022-06-23 22:23:11.524445
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:23:12.921666
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert settings.debug != True

# Generated at 2022-06-23 22:23:13.994072
# Unit test for constructor of class Settings
def test_Settings():
    settings=Settings()
    assert settings.debug == False




# Generated at 2022-06-23 22:23:16.533859
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:18.351622
# Unit test for constructor of class Settings
def test_Settings():
    """
    Unit test for main.py.settings.Settings
    :return:
    """
    assert settings.debug is False

# Generated at 2022-06-23 22:23:20.783185
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:23.801014
# Unit test for function init_settings
def test_init_settings():
    class Args:
        def __init__(self):
            self.debug = False

    args = Args()
    init_settings(args)
    assert(settings.debug == False)
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:23:27.566228
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-23 22:23:29.250471
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None



# Generated at 2022-06-23 22:23:31.420166
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    # Test default settings
    assert settings.debug == False


# Generated at 2022-06-23 22:23:32.737796
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:35.943760
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:37.823256
# Unit test for constructor of class Settings
def test_Settings():
    Settings()
    assert settings is not None, "Settings are not instantiated!"


# Generated at 2022-06-23 22:23:40.372731
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:23:41.873033
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:43.015258
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug



# Generated at 2022-06-23 22:23:44.511552
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-23 22:23:46.007078
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:47.753299
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:23:49.770443
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:51.034311
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:52.634320
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:00.848606
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    del settings.debug

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='A web crawler for Python',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument('--debug',
                        help='print debug messages',
                        action='store_true',
                        default=False)
    args = parser.parse_args()
    init_settings(args)


# Generated at 2022-06-23 22:24:03.181159
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:04.058391
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:07.416709
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:08.870647
# Unit test for constructor of class Settings
def test_Settings():
    settings_init = Settings()
    assert settings_init.debug == False

# Generated at 2022-06-23 22:24:13.087145
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True


# Test all functions
if __name__ == "__main__":
    test_Settings()
    print("All tests passed")

# Generated at 2022-06-23 22:24:16.955400
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False

    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:18.219935
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert False == settingsTest.debug


# Generated at 2022-06-23 22:24:20.782307
# Unit test for constructor of class Settings
def test_Settings():
    print('test_Settings')
    global settings
    assert settings.debug is False
    settings.debug = True
    assert settings.debug is True



# Generated at 2022-06-23 22:24:23.687817
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:24:25.136435
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert not obj.debug


# Generated at 2022-06-23 22:24:25.644366
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None

# Generated at 2022-06-23 22:24:26.614065
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:24:29.017900
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:24:30.426377
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:24:31.330047
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:24:32.839165
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:24:33.739086
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:24:35.172758
# Unit test for constructor of class Settings
def test_Settings():
    foo = Settings()
    assert foo.debug == False


# Generated at 2022-06-23 22:24:36.154415
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:37.854117
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:39.161385
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:40.919615
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:42.443020
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:44.343397
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:45.754817
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:24:55.831468
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true",
                        help="enable debug mode")
    args = parser.parse_args()
    init_settings(args)
    app = Flask(__name__)
    app.run()

    # Unit test for function init_settings(argparse.Namespace)
    import pytest
    from argparse import Namespace
    from app import init_settings

    def test_init_settings():
        args = Namespace(debug=True)
        init_settings(args)
        assert settings.debug is True

# Generated at 2022-06-23 22:24:57.029849
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:59.091264
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:25:00.391163
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Initializes settings

# Generated at 2022-06-23 22:25:01.878528
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings is not None


# Generated at 2022-06-23 22:25:04.725506
# Unit test for function init_settings
def test_init_settings():
    argv = ["-d"]
    init_settings(parse_args(argv))
    assert settings.debug
    argv = []
    init_settings(parse_args(argv))
    assert settings.debug is False

# Generated at 2022-06-23 22:25:06.566941
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:25:09.774906
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:25:10.718133
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:11.651166
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:13.744723
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:17.419813
# Unit test for function init_settings
def test_init_settings():
    args = lambda : 0  # type: Namespace
    args.debug = False
    args.mode = "dev"
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:19.477639
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:25:21.763249
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    argv = ["", "--debug"]
    args = ArgumentParser().parse_args(argv)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:22.670131
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:25:25.290219
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

