

# Generated at 2022-06-23 22:15:22.901853
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:15:24.496919
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:15:25.567250
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:15:30.332617
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Overwrite module settings when in debug mode
if settings.debug:
    print("Debug mode is set!")


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 22:15:32.050883
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:15:34.891936
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:15:35.714134
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:15:36.206672
# Unit test for function init_settings
def test_init_settings():
    pass

# Generated at 2022-06-23 22:15:38.132294
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:15:40.065941
# Unit test for function init_settings
def test_init_settings():
    stgs = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert stgs.debug == False

# Generated at 2022-06-23 22:15:41.154380
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:15:42.458691
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:15:44.108003
# Unit test for function init_settings
def test_init_settings():
    # Test initialization
    init_settings(Namespace(debug=True))
    assert settings.debug

    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:15:46.083700
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:15:46.740731
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:15:47.900583
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:15:49.795244
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:15:51.291375
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.debug == False


# Generated at 2022-06-23 22:15:52.137122
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings2.debug == False


# Generated at 2022-06-23 22:15:53.252670
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:15:54.725101
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)

# Generated at 2022-06-23 22:15:57.185133
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:59.020915
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)
    assert not settings.debug


# Generated at 2022-06-23 22:16:00.958350
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    settings.debug = True
    assert settings.debug


# Generated at 2022-06-23 22:16:03.876737
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:16:05.249266
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False  # check default value


# Generated at 2022-06-23 22:16:06.629015
# Unit test for constructor of class Settings
def test_Settings():
    assert settings != None
    assert settings.debug != None, "debug expected"

# Generated at 2022-06-23 22:16:07.516945
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings == settings2

# Generated at 2022-06-23 22:16:09.088502
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:16:10.149230
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:15.011568
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

if __name__ == "__main__":
    import pytest
    pytest.main(["-v", "test_settings.py"])

# Generated at 2022-06-23 22:16:16.344913
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:16:19.579480
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    try:
        s.debug
    except:
        raise Exception('debug not declared.')


# Generated at 2022-06-23 22:16:20.300219
# Unit test for constructor of class Settings
def test_Settings():
    settings  = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:22.063236
# Unit test for constructor of class Settings
def test_Settings():
    mySettings = Settings()
    assert(mySettings is not None)

# Generated at 2022-06-23 22:16:24.197447
# Unit test for function init_settings
def test_init_settings():
    fake_args = Namespace(debug=True)
    init_settings(fake_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:26.697532
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:16:28.319125
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:16:29.299519
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:31.035914
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:31.910750
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:33.521041
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:16:36.132360
# Unit test for function init_settings
def test_init_settings():
    fake_args = Namespace(debug=True)
    init_settings(fake_args)
    assert settings.debug is True

# Generated at 2022-06-23 22:16:39.165524
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:16:40.690148
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:43.168774
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True
    assert settings.debug == True

# Generated at 2022-06-23 22:16:45.742803
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:47.652486
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:16:50.304983
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:16:52.423328
# Unit test for function init_settings
def test_init_settings():
    import argparse
    args = argparse.Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == False

    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:53.592558
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:54.621382
# Unit test for constructor of class Settings
def test_Settings():
    expected_settings = Settings()
    assert settings == expected_settings


# Generated at 2022-06-23 22:16:55.329044
# Unit test for constructor of class Settings
def test_Settings():
    Settings()




# Generated at 2022-06-23 22:16:56.032316
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:16:57.107145
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:16:59.084974
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False

    settings.debug = True
    assert settings.debug == True



# Generated at 2022-06-23 22:17:02.995510
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

test_init_settings()

# Generated at 2022-06-23 22:17:04.986939
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Test for method init_settings

# Generated at 2022-06-23 22:17:06.660648
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-23 22:17:07.789303
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:10.211556
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-23 22:17:13.195990
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    del settings.debug

# Generated at 2022-06-23 22:17:16.677350
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    a = Namespace(debug = True)
    init_settings(a)

    assert settings.debug
    # Should also work for other values
    a = Namespace(debug = False)
    init_settings(a)

    assert not settings.debug

# Generated at 2022-06-23 22:17:18.248626
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False
    assert settings.debug == False



# Generated at 2022-06-23 22:17:23.631736
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug
    init_settings(Namespace(debug=None))
    assert not settings.debug
    init_settings(Namespace())
    assert not settings.debug
    init_settings(Namespace(info=True))
    assert not settings.debug
    init_settings(Namespace(debug=True, info=True))
    assert settings.debug

# Generated at 2022-06-23 22:17:25.341819
# Unit test for function init_settings
def test_init_settings():
    Namespace_object = Namespace(debug=True)
    init_settings(Namespace_object)
    assert settings.debug == True
# end of unit test

# Generated at 2022-06-23 22:17:27.666987
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, "Settings.debug should be True"



# Generated at 2022-06-23 22:17:28.653885
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:29.885036
# Unit test for constructor of class Settings
def test_Settings():
    # checking constructor with no arguments
    assert settings.debug is False

# Generated at 2022-06-23 22:17:32.739604
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:33.914952
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert setting.debug == False
    


# Generated at 2022-06-23 22:17:37.663173
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    if settings.debug is False:
        print("Debug False: OK")
    else:
        print("Debug False: FAILED")


# Unit tests for the Settings module

# Generated at 2022-06-23 22:17:39.329887
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:41.489175
# Unit test for constructor of class Settings
def test_Settings():
    # arrange
    s = Settings()
    # assert
    assert settings.debug == False



# Generated at 2022-06-23 22:17:42.695470
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-23 22:17:43.846257
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:46.564445
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:17:47.499494
# Unit test for constructor of class Settings
def test_Settings():
    context = Settings()
    assert context.debug == False

# Generated at 2022-06-23 22:17:54.900073
# Unit test for function init_settings
def test_init_settings():
    # Setup
    arg1 = Namespace()
    arg1.debug = False
    arg2 = Namespace()
    arg2.debug = True

    # Expected results
    expected = Settings()
    expected.debug = False

    # Call the tested function
    init_settings(arg1)

    # Assertion
    assert settings.debug == expected.debug

    # Expected results
    expected = Settings()
    expected.debug = True

    # Call the tested function
    init_settings(arg2)

    # Assertion
    assert settings.debug == expected.debug

# Generated at 2022-06-23 22:17:55.907298
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:17:57.250552
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:58.416502
# Unit test for function init_settings
def test_init_settings():
    args = get_args(['-d'])
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:17:59.554991
# Unit test for constructor of class Settings
def test_Settings():
    # Test default constructor
    settings_test: Settings = Settings()
    assert settings_test.debug == False

# Generated at 2022-06-23 22:18:02.015166
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:03.141476
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:18:05.277636
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, "debug", True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:07.394155
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True, file=None, max_instances=None, parse_only=None)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:08.850367
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:18:09.896404
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:18:11.166482
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    print("test_settings")
    print(s.debug)
    assert s.debug == False

# Generated at 2022-06-23 22:18:12.857434
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    print(settings.debug)

# Generated at 2022-06-23 22:18:15.109868
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    settings2 = Settings()
    settings1.debug = True
    assert settings1.debug == True
    assert settings2.debug == False



# Generated at 2022-06-23 22:18:16.511218
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:17.100451
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:19.657208
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:20.557986
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:22.558581
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == Settings()


# Generated at 2022-06-23 22:18:24.428570
# Unit test for constructor of class Settings
def test_Settings():
    assert str(settings.debug)== "False", "Constructor of Settings did not initialize class correctly"

# Generated at 2022-06-23 22:18:25.364289
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:18:29.528130
# Unit test for constructor of class Settings
def test_Settings():
    
    # Test empty constructor
    settings = Settings()
    assert settings.debug == False

    # Test setting values
    settings = Settings()
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:18:31.224050
# Unit test for constructor of class Settings
def test_Settings():

    class TestSettings(Settings):
        pass

    test = TestSettings()
    assert test.debug is False



# Generated at 2022-06-23 22:18:32.171119
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:35.289164
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:39.240208
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_2 = Settings()
    settings_3 = Settings()

    # Default settings
    init_settings(Namespace(debug=False))
    assert settings.debug == False

    # Activation of debug mode
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    # Restore
    settings_1.debug = False

# Generated at 2022-06-23 22:18:41.566258
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug is False



# Generated at 2022-06-23 22:18:43.856124
# Unit test for function init_settings
def test_init_settings():
    Opt = namedtuple('Opt', ['debug', 'file'])
    args = Opt(debug=True, file='')
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:18:47.257006
# Unit test for function init_settings
def test_init_settings():
    from pprint import pprint
    debug_param = True
    args = Namespace(debug=debug_param)
    init_settings(args)
    print('init_settings:')
    pprint(settings.__dict__)



# Generated at 2022-06-23 22:18:48.471408
# Unit test for function init_settings
def test_init_settings():
    # Not sure how to test this one
    print('test')

# Generated at 2022-06-23 22:18:51.098106
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    init_settings(args)

    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:51.816585
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:18:53.574808
# Unit test for constructor of class Settings
def test_Settings():
    st = Settings()
    assert st.debug is False



# Generated at 2022-06-23 22:18:56.497683
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    Setting_object = Settings()
    init_settings(args)
    assert Setting_object.debug == True


# Generated at 2022-06-23 22:18:57.586222
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:58.792218
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug




# Generated at 2022-06-23 22:19:00.058111
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:03.829673
# Unit test for function init_settings
def test_init_settings():
    """Ensure test_init_settings returns appropriate values"""
    # Ensure not in debug
    assert init_settings([]) == None
    assert settings.debug == False

    # Ensure debug works
    assert init_settings(["--debug"]) == None
    assert settings.debug == True

# Generated at 2022-06-23 22:19:05.536171
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:07.261717
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:19:10.132326
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:12.591261
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Usage: python3 -m pytest debugging.py

# Generated at 2022-06-23 22:19:16.689947
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:17.833466
# Unit test for constructor of class Settings
def test_Settings():
  settings = Settings()
  assert settings.debug == False


# Generated at 2022-06-23 22:19:19.266891
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:19:22.024456
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:24.358109
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:26.353433
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:27.794167
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-23 22:19:29.163454
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True)
    assert args.debug is True
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:19:29.848399
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:31.269363
# Unit test for constructor of class Settings
def test_Settings():
	assert settings.debug == False
	
if __name__ == '__main__':
	test_Settings()

# Generated at 2022-06-23 22:19:34.514744
# Unit test for constructor of class Settings
def test_Settings():
    print("\nUnit test of Settings")
    print("----------------")
    assert isinstance(settings, Settings)
    print("The class Settings has been sucessfully initialized.")
    print("\n------------------")



# Generated at 2022-06-23 22:19:39.332259
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:19:40.244762
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False



# Generated at 2022-06-23 22:19:41.865881
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:43.433797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:44.449504
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:19:45.363233
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:19:46.472496
# Unit test for constructor of class Settings
def test_Settings():
    c = Settings()
    c.debug = True
    assert c.debug == True


# Generated at 2022-06-23 22:19:47.492407
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert type(test) == Settings
    assert test.debug == False


# Generated at 2022-06-23 22:19:48.232419
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:48.876585
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:50.478029
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:51.497029
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:54.968511
# Unit test for constructor of class Settings
def test_Settings():

    print(settings.debug)
    init_settings(Namespace(debug = True))
    print(settings.debug)
    init_settings(Namespace(debug = False))
    print(settings.debug)


# Generated at 2022-06-23 22:19:56.409447
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:20:00.702893
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", help="Debug mode", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:20:01.821036
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:20:02.623264
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:20:03.742092
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:20:05.942515
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-23 22:20:07.239881
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()



# Generated at 2022-06-23 22:20:08.018449
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:20:10.550599
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:20:12.445902
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:14.289884
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:16.875631
# Unit test for function init_settings
def test_init_settings():
    """
    Test for settings initialization
    """
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:18.824531
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:21.064997
# Unit test for constructor of class Settings
def test_Settings():
    test_value = 1
    settings.debug = test_value
    assert settings.debug == test_value


# Generated at 2022-06-23 22:20:23.895528
# Unit test for constructor of class Settings
def test_Settings():
    print("Test Settings")
    settings = Settings()
    assert settings.debug == False


# Initialize settings
init_settings(Namespace(debug=True))


# Generated at 2022-06-23 22:20:25.356459
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:20:26.058487
# Unit test for constructor of class Settings
def test_Settings():
    Settings()

# Generated at 2022-06-23 22:20:27.647066
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:28.795974
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)



# Generated at 2022-06-23 22:20:31.353316
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:20:32.255362
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug)

# Generated at 2022-06-23 22:20:33.969913
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:20:35.992953
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:20:39.335833
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:20:42.871299
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:20:45.389219
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert(settings.debug == False)
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:20:46.415526
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:49.950147
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 22:20:52.107124
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:53.421432
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings
    assert settings.debug == False


# Generated at 2022-06-23 22:20:55.886571
# Unit test for function init_settings
def test_init_settings():
    ns = Namespace()
    ns.debug = True
    init_settings(ns)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:58.908457
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# # Unit test for init_setting() function
# def test_init_setting():
#     init_setting()
#     assert not settings.debug

# Generated at 2022-06-23 22:21:00.772573
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:02.229356
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert settings.debug == test_settings.debug, "Constructor doesn't work"

# Generated at 2022-06-23 22:21:04.912577
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-23 22:21:06.655413
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:21:09.082759
# Unit test for function init_settings
def test_init_settings():
    argparse.ArgumentParser()
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:12.992773
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Run unit tests
test_init_settings()

# Generated at 2022-06-23 22:21:15.210782
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings
    assert test != None



# Generated at 2022-06-23 22:21:16.520491
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:21:19.405635
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:20.706987
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:22.241761
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:21:24.733313
# Unit test for constructor of class Settings
def test_Settings():
    init_settings("")
    assert settings.debug == False
    # if args.debug == True:
    #     settings.debug = True
    # else:
    #     settings.debug = False

# Generated at 2022-06-23 22:21:25.330508
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:21:26.208150
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings
    assert not settings.debug

# Generated at 2022-06-23 22:21:27.266271
# Unit test for constructor of class Settings
def test_Settings():
    Settings()



# Generated at 2022-06-23 22:21:29.442831
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:33.929615
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(task = None,
                            debug = False,
                            train = None,
                            test = None,
                            train_file = None,
                            test_file = None,
                            model_file = None,
                            epochs = None,
                            batch_size = None))
    assert settings.debug == False
    init_settings(Namespace(task = None,
                            debug = True,
                            train = None,
                            test = None,
                            train_file = None,
                            test_file = None,
                            model_file = None,
                            epochs = None,
                            batch_size = None))
    assert settings.debug == True

# Generated at 2022-06-23 22:21:35.246826
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:21:37.692390
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:40.113358
# Unit test for constructor of class Settings
def test_Settings():
    try:
        settings_test = Settings()
        assert settings_test.debug == False
    except AssertionError:
        raise AssertionError("Failed to create Settings")



# Generated at 2022-06-23 22:21:41.278164
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:21:42.684494
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:44.125379
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False


# Generated at 2022-06-23 22:21:46.065904
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:21:50.886139
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


parser = argparse.ArgumentParser(description='Story Generator')

parser.add_argument('--debug', action='store_true', dest='debug',
                    help='print debug information')

parser.set_defaults(func=init_settings)

# Generated at 2022-06-23 22:21:52.893270
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings == settings1



# Generated at 2022-06-23 22:21:54.976264
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:21:57.839018
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:21:59.377083
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:01.080210
# Unit test for constructor of class Settings
def test_Settings():
    set = Settings()
    assert set.debug == False

    set.debug = True
    assert set.debug == True

# Generated at 2022-06-23 22:22:03.103528
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:22:05.533015
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:06.987751
# Unit test for constructor of class Settings
def test_Settings():
    print(settings.debug)


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:22:07.749688
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:09.616566
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:13.566487
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False


if __name__ == "__main__":
    # Run unit tests
    test_init_settings()

# Generated at 2022-06-23 22:22:15.040354
# Unit test for function init_settings
def test_init_settings():
    args = []
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:22:15.541539
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:22:16.369795
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:22:19.643693
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug, "Debug should be True"
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug, "Debug should be False"

# Generated at 2022-06-23 22:22:21.874620
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:22:27.237788
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    assert settings.debug is False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:30.995824
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--debug', help='debug mode')
    args = parser.parse_args()
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-23 22:22:33.969232
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:37.454191
# Unit test for constructor of class Settings
def test_Settings():
    #create an object of class Settings
    obj = Settings()
    #use assertEqual method to check if the value of debug has been initialized to False
    assertEqual(obj.debug, False)

# Generated at 2022-06-23 22:22:40.433515
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace(debug=True)

    # Act
    init_settings(args)

    # Assert
    assert settings.debug is True

# Generated at 2022-06-23 22:22:41.831955
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert settings.debug != True



# Generated at 2022-06-23 22:22:42.451248
# Unit test for function init_settings

# Generated at 2022-06-23 22:22:45.958854
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug, "The settings.debug is not equal to True"
    init_settings(Namespace(debug=False))
    assert not settings.debug, "The settings.debug is not equal to False"

# Generated at 2022-06-23 22:22:47.378922
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s
    assert s.debug is False



# Generated at 2022-06-23 22:22:48.936142
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:22:50.570352
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert type(a.debug) == bool
    assert a.debug == False



# Generated at 2022-06-23 22:22:51.670263
# Unit test for constructor of class Settings
def test_Settings():
    s = settings
    assert s.debug == False

# Generated at 2022-06-23 22:22:52.655447
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-23 22:23:02.365298
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-23 22:23:04.794087
# Unit test for function init_settings
def test_init_settings():
    args=Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:23:06.666038
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:07.999794
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:23:09.373079
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-23 22:23:12.434519
# Unit test for function init_settings
def test_init_settings():
    """Test function init_settings"""
    parser = create_parser()
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:15.587861
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # Case 1. Test default
    init_settings(args)
    assert settings.debug == False

    # Case 2. Test debug mode
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:16.353571
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:18.204881
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    print(settings.debug)
    settings = Settings()
    print(settings.debug)



# Generated at 2022-06-23 22:23:20.203169
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:23:21.682772
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:23:23.954794
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:23:27.307866
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-23 22:23:28.365377
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:31.473474
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace()
    args.debug = True

    # Act
    init_settings(args)

    # Assert
    assert settings.debug

# Generated at 2022-06-23 22:23:33.728744
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:23:39.101520
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description='Short sample app')
    parser.add_argument("-d", "--debug", action="store_true", default=False,
                        help="Enabling debug mode")
    args = parser.parse_args("-d".split())
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:23:39.941834
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None


# Generated at 2022-06-23 22:23:41.792205
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:23:42.622217
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:43.772478
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug is False



# Generated at 2022-06-23 22:23:46.252558
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:23:48.464808
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Unit test to check if the settings are properly initalized

# Generated at 2022-06-23 22:23:50.427144
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:23:53.035791
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj.debug == False
    obj.debug = True
    assert obj.debug == True

# Generated at 2022-06-23 22:23:53.812451
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:58.123300
# Unit test for constructor of class Settings
def test_Settings():
    from unittest.mock import patch
    with patch.object(os, 'environ', {'DEBUG': 'True'}):
        from argparse import Namespace
        args = Namespace(debug=True)
        init_settings(args)
        assert settings.debug is True

# Generated at 2022-06-23 22:23:59.067372
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:24:00.032504
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None

# Generated at 2022-06-23 22:24:01.994984
# Unit test for constructor of class Settings
def test_Settings():
    instance = Settings()
    if instance.debug == False:
        print('test_Settings() passed')
    else:
        print('test_Settings() failed')

# Generated at 2022-06-23 22:24:06.277460
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:24:08.615624
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    a = Namespace()
    a.debug = True
    init_settings(a)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:10.308163
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:24:11.708043
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)


# Generated at 2022-06-23 22:24:13.738087
# Unit test for function init_settings
def test_init_settings():
    testing_args = Namespace()
    testing_args.debug = True
    init_settings(testing_args)

    assert settings.debug is True

# Generated at 2022-06-23 22:24:14.905846
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-23 22:24:15.862843
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:24:17.913941
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange
    settings = Settings()
    settings.debug = False
    # Act and Assert
    assert settings.debug is False

# Generated at 2022-06-23 22:24:19.455498
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()

    assert settings1.debug == False

# Generated at 2022-06-23 22:24:20.565576
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:24:25.085692
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    import pytest
    pytest.main(["-v", __file__])

# Generated at 2022-06-23 22:24:25.831875
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:24:27.216301
# Unit test for constructor of class Settings
def test_Settings():
    newSettings = Settings()
    assert newSettings.debug == False


# Generated at 2022-06-23 22:24:31.924250
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    args = Namespace(debug=True)
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-23 22:24:32.837222
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:34.504232
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:38.277462
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:24:39.850386
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:41.250089
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-23 22:24:43.722262
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:46.108801
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False, "debug mode is failing"

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:24:48.286418
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s != None


# Generated at 2022-06-23 22:24:51.252161
# Unit test for function init_settings
def test_init_settings():
    # set up
    ARGS = Namespace(debug=True)

    # exercise
    init_settings(ARGS)

    # verify
    assert settings.debug == True
    

# Generated at 2022-06-23 22:24:53.293229
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())

    assert(not settings.debug)

    init_settings(Namespace(debug=True))

    assert(settings.debug)

# Generated at 2022-06-23 22:24:56.718147
# Unit test for function init_settings
def test_init_settings():
    # test debug mode is activated
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    # test debug mode is deactivated
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:58.836392
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings.debug == False



# Generated at 2022-06-23 22:25:00.728336
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:25:02.812744
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False
    settings1.debug = True
    assert settings1.debug == True



# Generated at 2022-06-23 22:25:03.842245
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:25:06.431189
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:25:07.767558
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:25:09.503812
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    return

# Generated at 2022-06-23 22:25:11.230875
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:25:12.575909
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:25:13.709808
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:15.649789
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-23 22:25:19.181138
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:25:22.629963
# Unit test for function init_settings
def test_init_settings():
    import unittest
    import sys

    class Test_init_settings(unittest.TestCase):
        def test_debug(self):
            args = Namespace(debug=True)
            init_settings(args)
            assert settings.debug is True

    unittest.main(module=sys.modules[__name__], exit=False)