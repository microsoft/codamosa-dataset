

# Generated at 2022-06-23 22:15:21.258591
# Unit test for constructor of class Settings
def test_Settings():
    class1 = Settings()
    assert not class1.debug

# Generated at 2022-06-23 22:15:22.866089
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:24.437585
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:25.568605
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:15:28.275694
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert settings.debug == True

# Generated at 2022-06-23 22:15:29.710561
# Unit test for constructor of class Settings
def test_Settings():
    tst = Settings()
    assert tst.debug == False

# Generated at 2022-06-23 22:15:32.434333
# Unit test for constructor of class Settings
def test_Settings():
    settings_test_1 = Settings()
    assert not settings_test_1.debug


# Generated at 2022-06-23 22:15:33.847240
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    assert s.debug == False

# Generated at 2022-06-23 22:15:35.602681
# Unit test for constructor of class Settings
def test_Settings():
    from classes.Settings import Settings
    s = Settings()
    assert type(s) == Settings
    assert s.debug == False


# Generated at 2022-06-23 22:15:37.010672
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:41.510670
# Unit test for function init_settings
def test_init_settings():
    # Test setup
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()

    init_settings(args)

    # Test assertions
    assert False is settings.debug

    # Test execution
    args.debug = True

    init_settings(args)

    assert True is settings.debug

    # Test teardown
    del args



# Generated at 2022-06-23 22:15:42.376769
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))

# Generated at 2022-06-23 22:15:47.504575
# Unit test for function init_settings
def test_init_settings():
    """
    Test the function init_settings with the following cases:
    """
    # Case 1 : Default setting
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

    # Case 2 : Debug mode
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:48.759275
# Unit test for constructor of class Settings
def test_Settings():
    data = Settings()
    assert data.debug == False


# Generated at 2022-06-23 22:15:50.365273
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug==False



# Generated at 2022-06-23 22:15:52.284621
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings.debug == False
    assert settings1.debug == False

# Generated at 2022-06-23 22:15:54.574113
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:56.394417
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:58.370686
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    settings.debug = False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:59.367877
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings2 is not None

# Generated at 2022-06-23 22:16:00.915125
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:16:03.827597
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:06.017840
# Unit test for constructor of class Settings
def test_Settings():
    # Creating a settings object
    settings = Settings()
    # Checking the default value of attributes of the object
    assert settings.debug == False


# Generated at 2022-06-23 22:16:06.948958
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert setting.debug == False

# Generated at 2022-06-23 22:16:08.200932
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:11.483002
# Unit test for function init_settings
def test_init_settings():
    # arrange
    args = Namespace()
    args.debug = True

    # act
    init_settings(args)

    # assert
    assert settings.debug == True



# Generated at 2022-06-23 22:16:16.157809
# Unit test for function init_settings
def test_init_settings():
    setattr(settings, "debug", False)
    args = Namespace()
    setattr(args, "debug", False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    setattr(args, "debug", True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:18.471458
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:20.508684
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:22.262030
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:16:25.887126
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:16:27.892108
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:29.285813
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-23 22:16:31.808444
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True)
    init_settings(args)
    
    assert settings.debug == True
    


# Generated at 2022-06-23 22:16:33.018947
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug



# Generated at 2022-06-23 22:16:35.041401
# Unit test for function init_settings
def test_init_settings():
    # Single option
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:36.634308
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:38.054849
# Unit test for constructor of class Settings
def test_Settings():
    def test_settings():
        assert settings.debug == False
        assert settings.debug == False

# Generated at 2022-06-23 22:16:39.473205
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:16:42.602043
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:16:44.812677
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    # Generate exception for testing fail
    #raise RuntimeError

# Generated at 2022-06-23 22:16:46.553254
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:49.608004
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True
test_init_settings()

# Generated at 2022-06-23 22:16:51.147383
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:16:52.297871
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:53.118152
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(not settings.debug)

# Generated at 2022-06-23 22:16:55.178843
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:55.887075
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False

# Generated at 2022-06-23 22:16:57.005882
# Unit test for function init_settings
def test_init_settings():
    input = Namespace(debug=True)
    init_settings(input)
    assert settings.debug


# Generated at 2022-06-23 22:16:57.961928
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings

# Generated at 2022-06-23 22:16:59.202369
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest.debug == False


# Generated at 2022-06-23 22:17:02.716815
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:17:04.162476
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:05.896886
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:08.408166
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    assert settings.debug is False
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:09.064935
# Unit test for function init_settings
def test_init_settings():
    args = Nam

# Generated at 2022-06-23 22:17:11.088497
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:13.732249
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:15.790440
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:17.059193
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:17:17.949293
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:17:18.842167
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:20.756659
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug == True


# Generated at 2022-06-23 22:17:22.275689
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    settings = Settings()
    assert not settings.debug
    
    

# Generated at 2022-06-23 22:17:24.070263
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:25.165841
# Unit test for constructor of class Settings
def test_Settings():
    dbg = Settings()
    assert dbg.debug == False



# Generated at 2022-06-23 22:17:28.822392
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:17:30.672993
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:32.846584
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True


# ---------------

# Generated at 2022-06-23 22:17:41.380756
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    gettext.install("vrt2epub", localedir="locales")
    print(gettext.gettext("Initializing the settings"))
    parser = argparse.ArgumentParser(
        description=gettext.gettext("VRT to EPUB converter"),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help=gettext.gettext("enable debugging messages to be shown"),
    )
    args = parser.parse_args()
    init_settings(args)
    print(gettext.gettext("Settings initialized"))
    print

# Generated at 2022-06-23 22:17:42.232652
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:43.377682
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:45.490978
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

init_settings(args)

# Generated at 2022-06-23 22:17:49.545735
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="run a script to verify that init_settings works")
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()

    init_settings(args)

    assert settings.debug == args.debug

try:
    test_init_settings()
except Exception as err:
    print("Unit test fail: ", err)



# Generated at 2022-06-23 22:17:52.278618
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:53.166387
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:56.806858
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    # All args are the default value, settings.debug should be false
    settings.debug = False
    init_settings(args)
    assert not settings.debug

    # Enable debug, settings.debug should be True
    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:58.643532
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:01.524872
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    settings.debug = True
    assert settings.debug


# Generated at 2022-06-23 22:18:04.750780
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True, "init_settings did not correctly set debug mode"

# Generated at 2022-06-23 22:18:06.703868
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings.debug = False
    settings.debug = True
    assert settings.debug



# Generated at 2022-06-23 22:18:07.502681
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-23 22:18:08.927180
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:10.575816
# Unit test for function init_settings
def test_init_settings():
    argparse_settings = Namespace(debug=True)
    init_settings(argparse_settings)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:11.550319
# Unit test for constructor of class Settings
def test_Settings():
    # testing setter
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:18:13.706435
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:15.107621
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-23 22:18:17.668935
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


if __name__ == '__main__':
    test_init_settings()
    print('All tests passed!')

# Generated at 2022-06-23 22:18:18.913988
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert (test.debug == False)

# Unit test that checks that the settings object is populated correctly

# Generated at 2022-06-23 22:18:20.947712
# Unit test for function init_settings
def test_init_settings():
    """Unit test for function init_settings."""
    args = Namespace(debug=True)
    init_setti

# Generated at 2022-06-23 22:18:23.690355
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-23 22:18:26.461732
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:27.987914
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:18:29.067686
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:30.389126
# Unit test for constructor of class Settings
def test_Settings():
    print('Settings: test_Settings')
    assert settings.debug == False


# Generated at 2022-06-23 22:18:30.953645
# Unit test for constructor of class Settings
def test_Settings():
    newSettings = Settings()
    assert newSettings.debug == False



# Generated at 2022-06-23 22:18:32.493856
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:18:35.246357
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug == False


# Generated at 2022-06-23 22:18:37.994686
# Unit test for constructor of class Settings
def test_Settings():
    tmp_settings  = Settings()
    if tmp_settings.debug != False:
        raise Exception('test_settings')



# Generated at 2022-06-23 22:18:38.892659
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:41.621273
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:18:43.094301
# Unit test for function init_settings
def test_init_settings():
    # Test that function init_settings can set the debug value for settings to True
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug


# Generated at 2022-06-23 22:18:43.975496
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:18:45.853585
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:47.472698
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:18:48.343707
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False

# Generated at 2022-06-23 22:18:52.176501
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

    NS = Namespace()
    NS.debug = False
    assert settings.debug == False
    init_settings(NS)
    assert settings.debug == False

    NS = Namespace()
    NS.debug = True
    assert settings.debug == False
    init_settings(NS)
    assert settings.debug == True



# Generated at 2022-06-23 22:18:59.995373
# Unit test for function init_settings
def test_init_settings():
    # Create a function pointer to init_settings for test purposes
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--debug',
        action='store_true',
        help="turn on debugging mode",
        default=False
    )
    args = parser.parse_args()
    # Test with debug flag on
    init_settings(args)
    assert settings.debug == True
    # Test with debug flag off
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:01.663859
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:03.594863
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:19:04.555492
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:19:07.772211
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:09.541272
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:10.816527
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:19:12.183360
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:19:13.743553
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:19:17.971105
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:19:20.057879
# Unit test for function init_settings
def test_init_settings():
    args = vars(Namespace(debug=True))
    init_settings(Namespace(**args))
    assert settings.debug is True

# Generated at 2022-06-23 22:19:21.010180
# Unit test for constructor of class Settings
def test_Settings():
    Settings()



# Generated at 2022-06-23 22:19:22.866811
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:25.816462
# Unit test for constructor of class Settings
def test_Settings():
    expected = Settings()
    expected.debug = True

    init_settings(Namespace(debug = True))
    assert settings == expected

# Generated at 2022-06-23 22:19:28.163386
# Unit test for function init_settings
def test_init_settings():
    pass
    #args = Namespace(debug=True)
    #init_settings(args)
    #assert settings.debug is True

# Generated at 2022-06-23 22:19:28.848779
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:19:29.953779
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:19:33.917412
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:35.683905
# Unit test for constructor of class Settings
def test_Settings():
    obs = Settings()
    assert obs.debug == False


# Generated at 2022-06-23 22:19:39.472436
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:19:41.163777
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:42.958019
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:44.422727
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:45.889270
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    #assert False

# Generated at 2022-06-23 22:19:48.112397
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:49.107033
# Unit test for function init_settings
def test_init_settings():
    args=Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:19:50.433467
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:19:51.452682
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert not settings.debug

# Generated at 2022-06-23 22:19:53.336506
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False

# Generated at 2022-06-23 22:19:54.549942
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:55.825532
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug == True


# Generated at 2022-06-23 22:19:58.922302
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Unit test to check the output of the class Settings

# Generated at 2022-06-23 22:20:00.166633
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:01.136616
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:20:01.891899
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:20:03.932553
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug


# Generated at 2022-06-23 22:20:06.695038
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:20:09.761895
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:20:13.513291
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:20:14.950509
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:16.370236
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj is not None


# Generated at 2022-06-23 22:20:17.808544
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:20:18.957599
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:20:20.177487
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:20:25.565870
# Unit test for constructor of class Settings
def test_Settings():
    with patch('sys.argv', ['test_settings.py', '--debug']):
        parser = parse_args()
        init_settings(parser)
        assert settings.debug is True
    with patch('sys.argv', ['test_settings.py']):
        parser = parse_args()
        init_settings(parser)
        assert settings.debug is False

# Generated at 2022-06-23 22:20:26.669909
# Unit test for constructor of class Settings
def test_Settings():
    confirm=Settings()
    assert confirm.debug is False

# Generated at 2022-06-23 22:20:28.074632
# Unit test for function init_settings
def test_init_settings():
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:34.441886
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True


# class Settings:
#     """
#     Initialization of the settings.
#     """
#
#     def __init__(self, debug=False):
#         self.debug = debug
#
#
# settings = Settings()



# Generated at 2022-06-23 22:20:35.639787
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:37.433417
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:38.401132
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None


# Generated at 2022-06-23 22:20:39.217638
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:40.825176
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)
    assert hasattr(settings, 'debug')

# Generated at 2022-06-23 22:20:41.953328
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:20:44.113682
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug


# Generated at 2022-06-23 22:20:47.225017
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:20:49.567956
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:20:52.110514
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:20:53.593748
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:20:56.275775
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:59.536140
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:03.391143
# Unit test for constructor of class Settings
def test_Settings():
    print("Test Settings constructor")
    my_settings = Settings()
    assert(my_settings.debug is False)

if __name__ == "__main__":
    test_Settings()
    print("Done!")

# Generated at 2022-06-23 22:21:06.702780
# Unit test for function init_settings
def test_init_settings():
    
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()
    print('Done')

# Generated at 2022-06-23 22:21:07.935369
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    settings.debug = True
    assert settings.debug



# Generated at 2022-06-23 22:21:10.830996
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:21:12.033505
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False

# Generated at 2022-06-23 22:21:13.317819
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:15.254853
# Unit test for constructor of class Settings
def test_Settings():
    settings_new = Settings()
    assert settings_new.debug == False


# Generated at 2022-06-23 22:21:16.550999
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:18.375326
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)
    
    

# Generated at 2022-06-23 22:21:19.621577
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:21.659822
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug



# Generated at 2022-06-23 22:21:22.866688
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:25.012303
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:21:25.854439
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert not settings.debug



# Generated at 2022-06-23 22:21:26.889646
# Unit test for constructor of class Settings
def test_Settings():
    sett = Settings()
    assert sett.debug == False


# Generated at 2022-06-23 22:21:27.642934
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:28.078084
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None

# Generated at 2022-06-23 22:21:29.250788
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    return True


# Generated at 2022-06-23 22:21:30.703262
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:21:32.589419
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:33.105737
# Unit test for constructor of class Settings
def test_Settings():
   assert not settings.debug


# Generated at 2022-06-23 22:21:34.081680
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:35.755033
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings.__init__()

    assert(isinstance(settings.debug, bool))



# Generated at 2022-06-23 22:21:37.924865
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug == False

# Generated at 2022-06-23 22:21:39.541516
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False
    assert repr(settings) == "Settings()"

# Generated at 2022-06-23 22:21:41.199171
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:42.318090
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None


# Generated at 2022-06-23 22:21:45.556494
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:21:46.539684
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:48.952703
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Unit test to check if debug mode is activated when debug argument is passed

# Generated at 2022-06-23 22:21:51.070150
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

    assert settings.debug == False


# Generated at 2022-06-23 22:21:53.038517
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:54.383486
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:57.451095
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:21:59.054891
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug



# Generated at 2022-06-23 22:22:00.756394
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:01.611263
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:03.269125
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:04.748362
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:22:06.111028
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:22:07.175260
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:22:08.361867
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:22:09.784597
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:22:10.914676
# Unit test for constructor of class Settings
def test_Settings():
        settings = Settings()
        assert settings is not None


# Generated at 2022-06-23 22:22:11.764055
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:22:13.487111
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:14.965368
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:16.800740
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, 'debug', True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:22:18.352065
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:19.565320
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:22:20.672836
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:22:23.429072
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = False
    assert settings.debug == False



# Generated at 2022-06-23 22:22:26.623421
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
# End of unit test

# This function is used to access a named setting.

# Generated at 2022-06-23 22:22:28.128151
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:29.895065
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:31.067825
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:34.582044
# Unit test for function init_settings
def test_init_settings():
    import tempfile
    # Test for debug mode
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# TODO(ahe): Test more settings.

# Generated at 2022-06-23 22:22:36.621328
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:38.698695
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:22:40.824119
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:22:41.860943
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:22:42.451301
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:22:43.609094
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:44.248272
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

# Generated at 2022-06-23 22:22:46.342046
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-23 22:22:48.970203
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:22:50.912712
# Unit test for function init_settings
def test_init_settings():
    # TODO: datset
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:54.021809
# Unit test for function init_settings
def test_init_settings():
    args = ArgParse()
    init_settings(args)
    assert settings.debug == False

    args = ArgParse(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:55.095665
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    

# Generated at 2022-06-23 22:22:56.668685
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug is False

# Generated at 2022-06-23 22:22:59.370053
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:23:02.813555
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:23:03.540287
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:23:04.541851
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:14.693829
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #The following code is copied from stackoverflow
#     import smtplib
# import socket
# import re


# def send_email(user, pwd, recipient, subject, body):
#     FROM = user
#     TO = recipient if isinstance(recipient, list) else [recipient]
#     SUBJECT = subject
#     TEXT = body

#     # Prepare actual message
#     message = """From: %s\nTo: %s\nSubject: %s\n\n%s
#     """ % (FR

# Generated at 2022-06-23 22:23:17.002108
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:23:18.001562
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:23:18.777736
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:23:20.202586
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:23:21.681372
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:22.657131
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:23.706809
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:27.457111
# Unit test for function init_settings
def test_init_settings():
    args1 = Namespace(debug=False)
    args2 = Namespace(debug=True)
    init_settings(args1)
    assert settings.debug is False
    init_settings(args2)
    assert settings.debug is True



# Generated at 2022-06-23 22:23:29.580447
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert(settings.debug)



# Generated at 2022-06-23 22:23:33.217590
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug is True

# Unit test code for function init_settings
test_init_settings()

print('Done!')

# Generated at 2022-06-23 22:23:35.199145
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s != None
    assert s.debug != None



# Generated at 2022-06-23 22:23:37.616487
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:40.103153
# Unit test for function init_settings
def test_init_settings():
    a = Namespace(debug=True)
    init_settings(a)
    assert(settings.debug)

    a = Namespace(debug=False)
    init_settings(a)
    assert(not settings.debug)

# Generated at 2022-06-23 22:23:41.630884
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:42.469131
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:44.262334
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:45.112290
# Unit test for constructor of class Settings
def test_Settings():
    Settings()



# Generated at 2022-06-23 22:23:46.339516
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)



# Generated at 2022-06-23 22:23:48.558642
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:50.208729
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:51.665786
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:52.817581
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings == Settings()

# Generated at 2022-06-23 22:23:53.677430
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:23:56.195452
# Unit test for function init_settings
def test_init_settings():
    args = MagicMock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:57.469114
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:58.771534
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:00.870071
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()  # type: Settings

    assert s.debug == False
    s.debug = True
    assert s.debug == True

# Generated at 2022-06-23 22:24:02.528714
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:05.004046
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:06.552115
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:08.986792
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-23 22:24:10.387831
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:12.434335
# Unit test for constructor of class Settings
def test_Settings():
    settings.__init__()
    assert (settings.debug == False)

# Unit tests for function init_settings

# Generated at 2022-06-23 22:24:16.717056
# Unit test for function init_settings
def test_init_settings():
    argv = sys.argv
    sys.argv = ['fitter-web', '--debug']
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True
    sys.argv = argv

# Generated at 2022-06-23 22:24:20.003945
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:21.244604
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:24.932579
# Unit test for constructor of class Settings
def test_Settings():
    # Test if the initialized variables are not None
    assert settings.debug != None

    # To test if the values are assigned correctly, test_init_settings() is used


# Generated at 2022-06-23 22:24:26.421433
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True


settings = Settings()


# Generated at 2022-06-23 22:24:28.244867
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:30.436097
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    # Testing
    assert settings.debug

# Generated at 2022-06-23 22:24:31.924072
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:35.968602
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", help="debug mode", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:40.312233
# Unit test for function init_settings
def test_init_settings():
    import argparse
    args = argparse.Namespace()

    settings.debug = False
    args.debug = False
    init_settings(args)
    assert not settings.debug

    settings.debug = False
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:41.341358
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:43.063771
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug == False

# Generated at 2022-06-23 22:24:44.584849
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:46.883199
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    assert args.debug == True

# Generated at 2022-06-23 22:24:49.085913
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    # Checks whether settings object was initiated
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:24:51.640844
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    # Reset
    settings.debug = False

# Generated at 2022-06-23 22:24:56.248185
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:57.314508
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:25:00.677474
# Unit test for constructor of class Settings
def test_Settings():
    # checking if debug is false as no argument is passed
    assert settings.debug == False

    settings.debug = True

    # checking if debug is true as argument is passed
    assert settings.debug == True

# Generated at 2022-06-23 22:25:02.485747
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:25:03.840556
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(settings.debug == False)



# Generated at 2022-06-23 22:25:04.849801
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:25:06.111846
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_setti

# Generated at 2022-06-23 22:25:07.471873
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:25:08.793973
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug


# Generated at 2022-06-23 22:25:10.150618
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:25:12.148071
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s


# Generated at 2022-06-23 22:25:14.519237
# Unit test for constructor of class Settings
def test_Settings():
    test_data = Settings()

    test_data.debug = True
    assert test_data.debug
    print("Test Settings: constructor passed!")



# Generated at 2022-06-23 22:25:15.517088
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:25:16.795563
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False

# Generated at 2022-06-23 22:25:21.513872
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Unit tests for methods in class Settings
#def test_init_settings():
#    settings = Settings(debug=True)
#    assert settings.debug


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', '-v', __file__])