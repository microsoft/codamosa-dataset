

# Generated at 2022-06-23 22:15:27.972916
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True


from asyncio import get_event_loop



# Generated at 2022-06-23 22:15:29.453104
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug



# Generated at 2022-06-23 22:15:31.268626
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, object)


# Integration test for init_settings

# Generated at 2022-06-23 22:15:32.730465
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:15:38.613777
# Unit test for function init_settings
def test_init_settings():
    """
    Make sure that init_settings will set debug to true if argument --debug
    is used.
    
    """
    parser = Parser()
    args = parser.parse_args(['--debug'])
    init_settings(args)

    assert settings.debug
    import pytest
    print("test passed")

# Generated at 2022-06-23 22:15:40.902624
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:15:44.024817
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", "-d", help="print debug information", action="store_true")
    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-23 22:15:45.521729
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:15:47.430602
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(
        debug=False
    )
    init_settings(args=test_args)
    assert settings.debug == False

# Generated at 2022-06-23 22:15:49.474225
# Unit test for constructor of class Settings
def test_Settings():
    from src.settings import Settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:15:52.749401
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:15:53.381960
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False

# Generated at 2022-06-23 22:15:54.003765
# Unit test for constructor of class Settings
def test_Settings():
    settings 

# Generated at 2022-06-23 22:15:57.023735
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 22:15:58.013145
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:01.556692
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    settings.debug = False
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:02.080949
# Unit test for constructor of class Settings
def test_Settings():
    assert settings != None

# Generated at 2022-06-23 22:16:04.930206
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))    
    assert settings.debug == False

# Generated at 2022-06-23 22:16:06.731929
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:16:08.009377
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:16:10.938185
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true")
    args = parser.parse_args(["-d"])
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:16:14.350566
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:16:17.090283
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:18.841785
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:20.049249
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:23.374391
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:24.699918
# Unit test for constructor of class Settings
def test_Settings():
    settings_object = Settings()
    assert settings_object.debug == False


# Generated at 2022-06-23 22:16:26.159027
# Unit test for constructor of class Settings
def test_Settings():
    settings_object = Settings()
    assert settings_object.debug == False

# Generated at 2022-06-23 22:16:27.434654
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:29.187992
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:32.280290
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug, "Init debug failed."


if __name__ == '__main__':
    test_init_settings()
    print('Test passed')

# Generated at 2022-06-23 22:16:33.567002
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False



# Generated at 2022-06-23 22:16:36.132328
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug is False



# Generated at 2022-06-23 22:16:37.954155
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:38.942681
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:39.928221
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:16:41.290593
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:16:43.537140
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import Mock
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:45.458378
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
test_init_settings()



# Generated at 2022-06-23 22:16:46.703822
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings()
    assert _settings.debug == False

# Generated at 2022-06-23 22:16:47.655918
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:49.255698
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:53.648266
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True,
        quiet=False,
        yes=False,
        output_dir="output",
        config_file="config.ini",
        username=None,
        password=None,
        entity="",
        project="",
        start_date="",
        end_date=""
    )
    init_settings(args)
    settings.debug = True

# Generated at 2022-06-23 22:16:55.454550
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:16:57.048883
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    # Check setting when debug mode is True
    assert settings.debug == True

# Generated at 2022-06-23 22:16:59.689076
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:01.691897
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False




# Generated at 2022-06-23 22:17:02.827249
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:05.321280
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False
    s.debug = True
    assert s.debug == True

# Generated at 2022-06-23 22:17:06.501874
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:10.253391
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert not settings.debug
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:17:14.026230
# Unit test for function init_settings
def test_init_settings():

    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

    args.debug = False
    init_settings(args)

    assert settings.debug == False

# Generated at 2022-06-23 22:17:15.706177
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert settings.debug == False
    assert settings.debug == False

# Generated at 2022-06-23 22:17:18.669440
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:19.914164
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert settings.debug == settings.debug



# Generated at 2022-06-23 22:17:21.786736
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    settings.debug = True
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:23.782587
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)    

    assert settings.debug == True


# Generated at 2022-06-23 22:17:25.558501
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:27.089702
# Unit test for constructor of class Settings
def test_Settings():
    settings_instance = Settings()
    assert settings_instance.debug == False



# Generated at 2022-06-23 22:17:29.166529
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-23 22:17:32.509862
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description='Testing arguments')
    parser.add_argument('-d', '--debug', action='store_true',
                        help='Print debug information')
    args = parser.parse_args(['-d'])
    assert settings.debug is False
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:33.473828
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-23 22:17:34.504151
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:36.961319
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings is not None
    assert not settings.debug

# Generated at 2022-06-23 22:17:38.246949
# Unit test for constructor of class Settings
def test_Settings():
    TEST_SETTINGS = Settings()
    assert TEST_SETTINGS.debug == False

# Generated at 2022-06-23 22:17:39.002124
# Unit test for constructor of class Settings
def test_Settings():
    # Test default value of Settings class
    assert settings.debug == False


# Generated at 2022-06-23 22:17:40.773423
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:42.038492
# Unit test for constructor of class Settings
def test_Settings():
    testsettings = settings()
    assert testsettings.debug == False


# Generated at 2022-06-23 22:17:43.889836
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:45.653374
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:17:46.488173
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:17:47.434475
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug


# Generated at 2022-06-23 22:17:48.309798
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:17:48.773408
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:17:50.290448
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:17:51.536241
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debu

# Generated at 2022-06-23 22:17:54.166168
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:55.334990
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert setting.debug == False



# Generated at 2022-06-23 22:17:56.615631
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:17:58.077202
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug



# Generated at 2022-06-23 22:18:00.462959
# Unit test for function init_settings
def test_init_settings():
    # GIVEN
    args = Namespace(debug=True)

    # WHEN
    init_settings(args)

    # THEN
    assert settings.debug is True

# Generated at 2022-06-23 22:18:01.918011
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) == Settings

# Generated at 2022-06-23 22:18:03.519235
# Unit test for constructor of class Settings
def test_Settings():
    sr = Settings()
    assert sr
    assert sr.debug == False


# Generated at 2022-06-23 22:18:05.276157
# Unit test for constructor of class Settings
def test_Settings():
    set = Settings()
    assert(set.debug == False)

# Testing the init_settings function

# Generated at 2022-06-23 22:18:06.488231
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False



# Generated at 2022-06-23 22:18:08.255437
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:18:09.143944
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-23 22:18:14.208443
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False, "wrong debug state"
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True, "wrong debug state"

# Generated at 2022-06-23 22:18:14.989782
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:18:16.100439
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings,Settings)


# Generated at 2022-06-23 22:18:20.190936
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:24.913961
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    settings.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:18:25.702485
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert not settings2.debug

# Generated at 2022-06-23 22:18:29.066946
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:32.737877
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args1 = Namespace(debug=False)
    init_settings(args1)
    assert settings.debug == False
    args2 = Namespace(debug=True)
    init_settings(args2)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:35.435509
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:37.745726
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug


# Generated at 2022-06-23 22:18:40.004290
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:18:44.991103
# Unit test for function init_settings
def test_init_settings():
    args_for_test = Namespace(debug=True)
    init_settings(args_for_test)
    assert settings.debug is True
    args_for_test = Namespace(debug=False)
    init_settings(args_for_test)
    assert settings.debug is False

# Generated at 2022-06-23 22:18:46.590516
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:48.137058
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:49.015849
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:50.298962
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings();
    assert settings.debug == False;


# Generated at 2022-06-23 22:18:52.615723
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:56.392594
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:18:57.442358
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser

# Generated at 2022-06-23 22:18:59.289329
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:01.510484
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:19:04.653304
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:19:05.582823
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)


# Generated at 2022-06-23 22:19:07.680380
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:19:13.675705
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", default=False, help="enable debug mode")
    args = parser.parse_args()
    init_settings(args)

    # print some settings
    print(settings.debug)

# Generated at 2022-06-23 22:19:16.731619
# Unit test for function init_settings
def test_init_settings():
    test_args = ['-d']
    init_settings(parse_arguments(test_args))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:19.756877
# Unit test for constructor of class Settings
def test_Settings():
    from argparse import Namespace

    args = Namespace()
    args.debug = True
    init_settings(args)
    try:
        assert(settings.debug)
    except AssertionError:
        print("Error: Settings does not work.")

# Generated at 2022-06-23 22:19:22.633129
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:24.611172
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s
    assert not s.debug


# Generated at 2022-06-23 22:19:26.188622
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:30.314829
# Unit test for function init_settings
def test_init_settings():
    # Test debug
    args = Namespace(
        debug=True
    )
    init_settings(args)
    assert settings.debug==True
    args = Namespace(
        debug=False
    )
    init_settings(args)
    assert settings.debug==False

# Generated at 2022-06-23 22:19:31.453492
# Unit test for constructor of class Settings
def test_Settings():
    set = Settings()

    assert set.debug == False



# Generated at 2022-06-23 22:19:33.524571
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    s.debug = True
    assert(s.debug)

# Generated at 2022-06-23 22:19:35.259149
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:19:37.245317
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:19:39.652437
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug = True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:41.329637
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:42.401478
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:19:43.765767
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:52.160490
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Python Giphy API Wrapper - Download Random GIFs'
    )

    parser.add_argument('--debug', dest='debug', action='store_true',
                        help='print debug output')

    args = parser.parse_args()
    init_settings(args)

    config = configparser.ConfigParser()
    config.read('config.ini')

    apikey = config['DEFAULT']['apikey']

    parser = argparse.ArgumentParser(
        description='Python Giphy API Wrapper - Download Random GIFs'
    )


# Generated at 2022-06-23 22:19:52.731122
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    

# Generated at 2022-06-23 22:19:53.817391
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:19:56.753538
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    print(setting.debug)
    setting.debug = True
    print(setting.debug)
    print(settings.debug)


# Generated at 2022-06-23 22:20:07.205964
# Unit test for function init_settings
def test_init_settings():
    # Test that debug is False by default
    args = Namespace()
    msg = "Debug mode is not False by default"
    init_settings(args)
    assert settings.debug is False, msg
    # Test that debug is True if debug is passed
    args = Namespace(debug=True)
    msg = "Debug mode is not True when debug mode passed to init_settings()"
    init_settings(args)
    assert settings.debug is True, msg


test_init_settings()
 
# Create a key
key = Fernet.generate_key()

# Open the file to encrypt
with open('test_file.txt', 'rb') as f:
    data = f.read()

# Encrypt the files
fernet = Fernet(key)
encrypted_data = fernet.encrypt(data)



# Generated at 2022-06-23 22:20:08.862652
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:10.160880
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:20:11.973427
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert isinstance(settings.debug,type(False))


# Generated at 2022-06-23 22:20:13.133266
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:14.685146
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:16.114588
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj.debug == False


# Generated at 2022-06-23 22:20:18.879837
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    assert settings.debug is False
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-23 22:20:21.063773
# Unit test for function init_settings
def test_init_settings():
    args = parse_args(['--debug'])
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:24.737633
# Unit test for constructor of class Settings
def test_Settings():
    try:
        settings = Settings()
        assert settings is not None
        assert settings.debug is False
    except Exception as e:
        print('test_Settings failed')
        print(e)
        assert False



# Generated at 2022-06-23 22:20:28.270528
# Unit test for function init_settings
def test_init_settings():
    args =  Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    sys.exit(pytest.main(["-v", "test_settings.py"]))

# Generated at 2022-06-23 22:20:30.460831
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:20:31.715051
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug is False



# Generated at 2022-06-23 22:20:33.386876
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:20:34.187365
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:20:36.772275
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:20:38.161335
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:41.075873
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:42.561619
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:20:45.047884
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True

    init_settings(test_args)
    assert settings.debug

# Test for function init_settings
test_init_settings()

# Generated at 2022-06-23 22:20:47.382073
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:49.306093
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:20:51.157261
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:52.483873
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:20:53.755013
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:20:55.385287
# Unit test for constructor of class Settings
def test_Settings():
    assert settings != None


# Generated at 2022-06-23 22:20:58.460018
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:59.889805
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:06.138303
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True, "init_settings(): setting debug flag to True"
    args.debug = False
    init_settings(args)
    assert not settings.debug, "init_settings(): setting debug flag to False"
    print("init_settings() is ok")


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:21:06.972627
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:07.934907
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings
    assert settings.debug == False

# Generated at 2022-06-23 22:21:11.302998
# Unit test for function init_settings
def test_init_settings():
    args_default = Namespace(debug=False)
    init_settings(args_default)
    assert settings.debug == False

    args_debug = Namespace(debug=True)
    init_settings(args_debug)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:12.033192
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:21:13.318077
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:21:15.255554
# Unit test for constructor of class Settings
def test_Settings():
    settings.test = 'test'
    assert settings.test == 'test'

# Generated at 2022-06-23 22:21:16.550542
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:18.374988
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:20.324360
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert not settings.debug
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:21.328520
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:24.007910
# Unit test for function init_settings
def test_init_settings():
    # Create a mock arguments to use
    a_test_arg = Namespace(debug=True)
    init_settings(a_test_arg)

    # Expect the debug flag to be True
    assert settings.debug

# Generated at 2022-06-23 22:21:24.723259
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:21:28.044945
# Unit test for constructor of class Settings
def test_Settings():

    assert type(settings.debug) == bool
    assert settings.debug == False
    # test init_settings
    class FakeNamespace:
        def __init__(self) -> None:
            self.debug = True
    fake_args = FakeNamespace()
    init_settings(fake_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:29.636912
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:21:31.909675
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    assert settings == Settings()
    init_settings(args=Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:21:32.919167
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug == False



# Generated at 2022-06-23 22:21:33.649049
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False

# Generated at 2022-06-23 22:21:40.114029
# Unit test for function init_settings
def test_init_settings():
    '''
    We have to test the function init_settings using this way,
    because we could easily test it when we imported argparse to
    get the arguments, however, we wouldn't be able to test it
    if we imported argparse.
    '''

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:41.277667
# Unit test for constructor of class Settings
def test_Settings():
    target = Settings()
    assert target.debug == False



# Generated at 2022-06-23 22:21:43.402858
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:44.555541
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:21:46.207292
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:51.643145
# Unit test for function init_settings
def test_init_settings():
    import sys
    from argparse import Namespace
    settings = Settings()

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    settings.debug = False

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    settings.debug = False


if __name__ == '__main__':
    assert False, 'Not a standalone program'

# Generated at 2022-06-23 22:21:52.401307
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:21:53.624107
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:21:54.618189
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:57.743352
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:58.975027
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:22:00.675412
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:02.936112
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:22:04.027853
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-23 22:22:07.001571
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:22:08.800368
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:09.968971
# Unit test for constructor of class Settings
def test_Settings():
    ts = Settings()
    assert ts.debug == False



# Generated at 2022-06-23 22:22:11.115755
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:13.145252
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:22:14.012643
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == 0

# Generated at 2022-06-23 22:22:17.129408
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Command line tool for Pytorch Transformer for Linguistics")
    parser.add_argument('--debug', action='store_true', help='do debug mode')

    args = parser.parse_args()
    init_settings(args)

# Generated at 2022-06-23 22:22:18.677060
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True



# Generated at 2022-06-23 22:22:19.677840
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:21.078818
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:23.479113
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:22:24.181204
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:22:25.856261
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:30.031766
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    settings2.debug = True
    settings2.debug = True
    settings2.debug = True
    settings2.debug = True
    settings2.debug = True
    settings2.debug = True

    assert settings2.debug is True
    assert settings.debug is False


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:22:34.972587
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description='Run a random walk.')
    parser.add_argument('--debug', dest='debug', action='store_true')
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:22:37.310408
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:39.196710
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug is False



# Generated at 2022-06-23 22:22:41.395198
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:22:42.880218
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert (settings.debug == False)



# Generated at 2022-06-23 22:22:45.473837
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace()
    args.debug = True

    # Initialize
    init_settings(args)

    # Assert
    assert(settings.debug)

# Generated at 2022-06-23 22:22:48.726145
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:50.358981
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:22:53.771499
# Unit test for function init_settings
def test_init_settings():

    args = Namespace()

    args.debug = False

    init_settings(args)

    assert settings.debug == False

    args = Namespace()

    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:22:55.848350
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:57.215321
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False

# Generated at 2022-06-23 22:22:58.538574
# Unit test for constructor of class Settings
def test_Settings():
    settings_instance = Settings()
    assert settings_instance.debug == False



# Generated at 2022-06-23 22:23:00.466712
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug is False



# Generated at 2022-06-23 22:23:01.804520
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug == False


# Generated at 2022-06-23 22:23:04.947849
# Unit test for function init_settings
def test_init_settings():
    # Create fake args
    args = Namespace()
    args.debug = True

    # Run the function
    init_settings(args)

    # Test the function
    assert settings.debug == True

# Generated at 2022-06-23 22:23:05.917914
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:23:07.685929
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:09.313368
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:23:10.762253
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-23 22:23:12.581789
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

# False positive coverage report

# Generated at 2022-06-23 22:23:15.015769
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

    s.debug = True
    assert s.debug
    s.debug = False
    assert not s.debug


# Generated at 2022-06-23 22:23:16.493074
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:23:18.995510
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:23:21.206987
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:23:23.339985
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    assert settings.debug is not False

# Generated at 2022-06-23 22:23:25.186108
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:26.161645
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:27.728569
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:23:29.900195
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:23:31.148661
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:34.231767
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-23 22:23:36.844590
# Unit test for function init_settings
def test_init_settings():
    supersecret_args = Namespace(debug=True)
    init_settings(supersecret_args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:38.047963
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings2.debug is False


# Generated at 2022-06-23 22:23:39.775233
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:41.306096
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:42.777990
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:44.589752
# Unit test for function init_settings
def test_init_settings():
    global settings
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:23:47.857183
# Unit test for constructor of class Settings
def test_Settings():
    settings_1 = Settings()
    settings_2 = Settings()
    settings_1.debug = True
    assert settings_1.debug != settings_2.debug
    # The following test failed, because the variable settings is global
    # and changes for each test.
    # assert settings.debug != settings_2.debug

# Generated at 2022-06-23 22:23:50.209104
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:23:51.121769
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:53.941997
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.d

# Generated at 2022-06-23 22:23:56.817182
# Unit test for function init_settings
def test_init_settings():
    global settings

    settings = Settings()

    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:23:58.551007
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:59.899882
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.debug == False


# Generated at 2022-06-23 22:24:01.508920
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:24:03.839196
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Tests for init_settings()

# Generated at 2022-06-23 22:24:07.640996
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:17.190563
# Unit test for function init_settings
def test_init_settings():
    tests = [
        { "name": "init_settings - debug flag is set",
            "input": Namespace(debug=True),
            "assert_equal": { "settings.debug": True }
        },
        { "name": "init_settings - debug flag is not set",
            "input": Namespace(debug=False),
            "assert_equal": { "settings.debug": False }
        },
    ]
    for test in tests:
        init_settings(test["input"])
        for assert_desc, assert_equal in test["assert_equal"].items():
            if eval(assert_desc) != assert_equal:
                raise Exception("%s: %s: %r != %r" % (test["name"], assert_desc, eval(assert_desc), assert_equal))


test_init_settings()

# Generated at 2022-06-23 22:24:18.291300
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:19.678225
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj.debug == False

# Generated at 2022-06-23 22:24:20.978382
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:24:25.525401
# Unit test for function init_settings
def test_init_settings():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args('--debug'.split())
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:26.556542
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:27.927396
# Unit test for function init_settings
def test_init_settings():
    args = namedtuple('Args', 'debug')(True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:33.795556
# Unit test for function init_settings
def test_init_settings():
    # Test with debug argument
    args = Namespace(debug=True)
    
    init_settings(args)
    
    assert settings.debug == True, "Should set the debug flag to true"

    # Test without debug argument
    args = Namespace(debug=False)
    
    init_settings(args)
    
    assert settings.debug == False, "Should set the debug flag to false"

# Generated at 2022-06-23 22:24:35.657195
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:37.759681
# Unit test for function init_settings
def test_init_settings():
    print("test_init_settings")
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:39.495845
# Unit test for constructor of class Settings
def test_Settings():
    """Tests the Settings class constructor"""
    assert settings.debug == False


# Generated at 2022-06-23 22:24:40.876393
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:42.405312
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:43.641235
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:45.715205
# Unit test for function init_settings
def test_init_settings():
    a = argparse.Namespace(debug=True)
    init_settings(a)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:47.895887
# Unit test for constructor of class Settings
def test_Settings():
    settings_class = Settings()
    assert settings_class.debug == False


# Generated at 2022-06-23 22:24:49.390206
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-23 22:24:51.132937
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:55.225911
# Unit test for constructor of class Settings
def test_Settings():
    app_settings = Settings()
    assert app_settings.debug is False, "Test of the constructor of class Settings failed"

# UNIT TESTS FOR CLASS SETTINGS

# Generated at 2022-06-23 22:24:56.645973
# Unit test for constructor of class Settings
def test_Settings():
    # Check if all variables are initialized
    assert settings.debug == False

# Generated at 2022-06-23 22:25:01.973934
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    print("test_init_settings() passed")


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:25:03.793993
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert isinstance(test_settings, Settings)


# Generated at 2022-06-23 22:25:05.422212
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:25:06.556774
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:25:10.104574
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:12.206875
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    assert settings.debug is False

    settings.debug = True
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:25:14.254349
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert args.debug == settings.debug

# Generated at 2022-06-23 22:25:15.268412
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:25:16.299554
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:21.482335
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    # Call your main app here ...
    print(f"Hello! debug={settings.debug}")

# Generated at 2022-06-23 22:25:22.745374
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    print("test_Settings")

# Generated at 2022-06-23 22:25:25.193167
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True