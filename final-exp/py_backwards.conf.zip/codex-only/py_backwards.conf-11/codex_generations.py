

# Generated at 2022-06-23 22:15:27.251770
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:15:30.333154
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:15:32.433992
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert setting.debug == False


# Generated at 2022-06-23 22:15:36.267924
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

test_init_settings()

# Generated at 2022-06-23 22:15:39.958500
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import Mock
    mock_args = Mock(spec=Namespace)
    mock_args.debug = True
    init_settings(mock_args)
    assert settings.debug is True
    mock_args.debug = False
    init_settings(mock_args)
    assert settings.debug is False

# Generated at 2022-06-23 22:15:40.774829
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug == False

# Generated at 2022-06-23 22:15:42.515624
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:15:45.749007
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    global settings

    settings = Settings()
    init_settings(args)

    assert settings.debug
    # check debug is set

# Generated at 2022-06-23 22:15:47.534969
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug



# Generated at 2022-06-23 22:15:50.129955
# Unit test for function init_settings
def test_init_settings():
    print("Testing function init_settings")

    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:15:52.077021
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:53.950441
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:15:55.782002
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:57.991520
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:02.286914
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

if __name__ == "__main__":
    args = Namespace()
    args.debug = True
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-23 22:16:03.799158
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:16:04.404184
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:16:06.156045
# Unit test for constructor of class Settings
def test_Settings():
    sett = Settings()
    assert sett.debug == False
    assert isinstance(sett, Settings)

# Generated at 2022-06-23 22:16:09.435597
# Unit test for function init_settings
def test_init_settings(): 
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()
    print("Everything passed")


# Generated at 2022-06-23 22:16:15.384819
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


if __name__ == '__main__':
    argument_parser = argparse.ArgumentParser(description='This is the main arg parser')
    argument_parser.add_argument('--debug', action='store_true', help='increase output verbosity')
    args = argument_parser.parse_args()
    init_settings(args)
    if settings.debug:
        print('debug enabled')

# Generated at 2022-06-23 22:16:16.345503
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:16:19.580227
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = False
    assert test_settings.debug == False


# Generated at 2022-06-23 22:16:21.273735
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:16:23.502551
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:24.837497
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:16:28.025081
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(
        debug=True,
    ))
    assert settings.debug is True

    init_settings(Namespace(
        debug=False,
    ))
    assert settings.debug is False

# Generated at 2022-06-23 22:16:29.393787
# Unit test for constructor of class Settings
def test_Settings():
    p=Settings()
    assert p.debug==False

# Generated at 2022-06-23 22:16:32.925138
# Unit test for constructor of class Settings
def test_Settings():
    '''
    Tests if settings.debug is False when it should be.
    '''
    assert settings.debug == False
    print('Test settings.debug = False passed.')


# Generated at 2022-06-23 22:16:35.387726
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    sample_args = Namespace(debug=True)

    # Act
    init_settings(sample_args)

    # Assert
    assert settings.debug is True

# Generated at 2022-06-23 22:16:40.038059
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    print('test_settings')
    test_init_settings()

# Generated at 2022-06-23 22:16:42.764340
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    
    assert settings.debug == True

    args.debug = False
    init_settings(args)

    assert settings.debug == False

# Generated at 2022-06-23 22:16:45.613175
# Unit test for function init_settings
def test_init_settings():
    class argsFake:
        def __init__(self):
            self.debug = False

    args = argsFake()

    assert(settings.debug == False)
    
    init_settings(args)

    assert(settings.debug == False)

    args.debug = True
    init_settings(args)

    assert(settings.debug == True)

# Generated at 2022-06-23 22:16:47.700775
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:16:49.298658
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:52.480828
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert type(settings.debug) == bool
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert type(settings.debug) == bool
    assert settings.debug == True

# Generated at 2022-06-23 22:16:53.915046
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:54.920627
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:16:56.388693
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:16:57.577174
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug;

# Generated at 2022-06-23 22:16:58.476892
# Unit test for constructor of class Settings
def test_Settings():
	assert settings.debug == False

# Generated at 2022-06-23 22:16:59.905057
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False, 'Initial debug value should be False'


# Initialise settings for tests

# Generated at 2022-06-23 22:17:03.161554
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    setattr(args, 'debug', True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:05.674296
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:08.631683
# Unit test for function init_settings
def test_init_settings():
    class Args:
        debug: bool
    args = Args()
    args.debug = False
    init_settings(args)
    assert settings.debug is False


# Generated at 2022-06-23 22:17:11.087730
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:12.877196
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:13.892985
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:15.277884
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:18.609673
# Unit test for constructor of class Settings
def test_Settings():
    print("test_Settings() START")

    settings = Settings()

    if settings.debug:
        print("DEBUG is enabled")
    else:
        print("DEBUG is disabled")

    print("test_Settings() END")



# Generated at 2022-06-23 22:17:19.493210
# Unit test for constructor of class Settings
def test_Settings():
    unit_test = Settings()


# Generated at 2022-06-23 22:17:20.386754
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:20.862193
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

# Generated at 2022-06-23 22:17:22.568672
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:27.414235
# Unit test for constructor of class Settings
def test_Settings():
    global settings

    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Explanation about this script")
    parser.add_argument('-d', '--debug', action='store_true', help="Debug mode")
    args = parser.parse_args()

    init_settings(args)

    if args.debug:
        print(args)

# Generated at 2022-06-23 22:17:28.781794
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:17:29.647730
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:17:31.844495
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:34.521535
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:17:36.598964
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()

    assert test.debug == False

# Generated at 2022-06-23 22:17:39.610972
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    print(settings.debug)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:17:42.777127
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:44.300563
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:45.971591
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:17:48.595706
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    init_settings(Namespace(debug=False))
    assert settings.debug is False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:17:51.079440
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug

    settings.debug = True

    args = Namespace(debug=False)
    init_settings(args)
    
    assert not settings.deb

# Generated at 2022-06-23 22:17:53.124170
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug

# Generated at 2022-06-23 22:17:56.481249
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=None)
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    pytest.main(["-v", "test_settings.py"])

# Generated at 2022-06-23 22:17:57.215705
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:57.928711
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:18:02.953591
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:05.058831
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:18:06.109127
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:18:07.176342
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:18:09.200495
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    
#Unit test for function init_settings

# Generated at 2022-06-23 22:18:10.576686
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:12.054245
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args=args)
    assert settings.debug is True



# Generated at 2022-06-23 22:18:13.241017
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:18:14.362618
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == arg

# Generated at 2022-06-23 22:18:15.162214
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:17.420415
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:18.856959
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:22.226853
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:18:24.115142
# Unit test for constructor of class Settings
def test_Settings():
    assert(Settings() is not None)
    assert(settings.debug == False)



# Generated at 2022-06-23 22:18:25.560858
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:29.384513
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:18:30.343459
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings()



# Generated at 2022-06-23 22:18:31.716772
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:35.790416
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:18:37.511315
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True


# Generated at 2022-06-23 22:18:39.243206
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:42.728241
# Unit test for function init_settings
def test_init_settings():
    with pytest.raises(AttributeError) as excinfo:
        init_settings(Namespace())
    assert 'debug' in str(excinfo.value)



# Generated at 2022-06-23 22:18:45.111673
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:18:46.711676
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    #Test variables initialized correctly
    assert s.debug == False


# Generated at 2022-06-23 22:18:47.593112
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:18:48.471176
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:52.286464
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

if __name__ == '__main__':
    try:
        test_Settings()
        assert False
    except AssertionError:
        print("Case 1: Passed")
    settings.debug = True
    try:
        test_Settings()
    except AssertionError:
        print("Case 2: Passed")

# Generated at 2022-06-23 22:18:55.949365
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, 'debug', True)
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:18:57.025334
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:57.970575
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:18:58.987589
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:00.393981
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:19:01.326625
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert not settings_.debug

# Generated at 2022-06-23 22:19:02.552583
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:19:05.583081
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:06.449807
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:08.871690
# Unit test for function init_settings
def test_init_settings():
    print("\nTest for function: init_settings")
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:10.909343
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:19:12.882867
# Unit test for function init_settings
def test_init_settings():
    class FakeArgs:
        debug = True
    init_settings(FakeArgs())


# Local Variables:
# python-indent: 4
# End:

# Generated at 2022-06-23 22:19:14.943293
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None

# Generated at 2022-06-23 22:19:16.973626
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    
    assert settings.debug == True

# Generated at 2022-06-23 22:19:17.760931
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:19:19.173351
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:20.313183
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:21.866383
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings.debug is False


# Generated at 2022-06-23 22:19:25.967081
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

test_init_settings()

# Generated at 2022-06-23 22:19:28.339139
# Unit test for function init_settings
def test_init_settings():
    parser = get_parser()
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:29.461734
# Unit test for constructor of class Settings
def test_Settings():
    assert hasattr(settings, 'debug')

# Generated at 2022-06-23 22:19:30.261102
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:19:31.794451
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-23 22:19:34.200555
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:35.633637
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:19:38.279548
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:39.609845
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:19:40.608119
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:19:43.260856
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    
    init_settings(Namespace(debug=False))
    assert settings.debug is False
# Unit testing class Settings

# Generated at 2022-06-23 22:19:44.116790
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:19:45.889862
# Unit test for function init_settings
def test_init_settings():
    my_args = Namespace()
    my_args.debug = True
    init_settings(my_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:47.874125
# Unit test for constructor of class Settings
def test_Settings():
    setting_object = Settings()
    assert not setting_object.debug


# Generated at 2022-06-23 22:19:49.235576
# Unit test for constructor of class Settings
def test_Settings():
    # Check if the instance is created properly
    settings_class = Settings()
    assert settings_class



# Generated at 2022-06-23 22:19:51.246376
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:53.818083
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None
    assert settings.debug == False



# Generated at 2022-06-23 22:19:56.359517
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:19:58.920144
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:20:00.316110
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:02.012905
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:03.138975
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False, "should not be debug mode"



# Generated at 2022-06-23 22:20:05.864590
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:07.092704
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:09.192477
# Unit test for constructor of class Settings
def test_Settings():
    # Test constructors starts
    settings = Settings()
    assert settings.debug != True
    # Test constructors ends


# Generated at 2022-06-23 22:20:10.448260
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:20:13.182843
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not settings.debug
    assert not settings.debug

# Generated at 2022-06-23 22:20:14.161076
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:20:15.919525
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:20:17.747357
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:20:22.618844
# Unit test for function init_settings
def test_init_settings():
    argnamespace = argparse.Namespace(debug=True)
    init_settings(argnamespace)
    assert settings.debug == True


'''
This is a module docstring.

@author: katiebrown
@title: Function 1
@description: This function is the first function.
'''


# Generated at 2022-06-23 22:20:24.525096
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:26.469789
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert (my_settings.debug == False)


# Generated at 2022-06-23 22:20:27.525928
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert settings != None


# Generated at 2022-06-23 22:20:31.099421
# Unit test for constructor of class Settings
def test_Settings():
    set_debug = True
    new_settings = Settings()
    new_settings.debug = set_debug
    assert new_settings.debug == set_debug


# Generated at 2022-06-23 22:20:32.375271
# Unit test for constructor of class Settings
def test_Settings():
    testSettings = Settings()
    assert isinstance(testSettings, Settings)

# Generated at 2022-06-23 22:20:36.339224
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:20:38.904338
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    if settings.debug:
        print("Debug mode is on.")



# Generated at 2022-06-23 22:20:41.028443
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:43.142763
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s != None)


# Generated at 2022-06-23 22:20:45.433004
# Unit test for function init_settings
def test_init_settings():
    ARGS = Namespace(debug=True)
    init_settings(ARGS)

    assert settings.debug


# Generated at 2022-06-23 22:20:49.352012
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:20:50.325058
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s


# Generated at 2022-06-23 22:20:52.485853
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:54.382837
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:20:57.890836
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace(
        debug = True
    )

    # Act
    init_settings(args)

    # Assert
    assert settings.debug


# Generated at 2022-06-23 22:21:01.264995
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:21:03.096214
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True




# Generated at 2022-06-23 22:21:04.467388
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:21:06.608256
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug = False))
    assert not settings.debug
    init_settings(Namespace(debug = True))
    assert settings.debug

# Generated at 2022-06-23 22:21:08.126879
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:09.815522
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:13.864994
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:16.057300
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True, password=None, username=None)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:17.012527
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:21:18.699965
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:21:20.278983
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:23.931471
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug
    print("\u001b[32m" + "All passed!" + "\u001b[0m")

# Generated at 2022-06-23 22:21:24.451338
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:21:25.218934
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:21:26.556827
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:21:28.728569
# Unit test for constructor of class Settings
def test_Settings():
    # Create settings object
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:21:29.952657
# Unit test for constructor of class Settings
def test_Settings():
    settings_instance = Settings()
    assert settings_instance.debug is False


# Generated at 2022-06-23 22:21:31.281108
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:21:32.253032
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:33.820655
# Unit test for function init_settings
def test_init_settings():
    """
    Test that settings.debug is set to True when --debug argument is given
    """
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:21:38.103146
# Unit test for function init_settings
def test_init_settings():
    # Default case
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # Case when debug is selected
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:39.017870
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-23 22:21:40.067637
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:21:40.927589
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:41.744965
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:21:43.518702
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:21:45.737212
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:21:47.553377
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None


# Generated at 2022-06-23 22:21:49.114261
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:52.239238
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:53.284619
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:54.264836
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:55.944343
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(settings.debug == False)



# Generated at 2022-06-23 22:21:56.949090
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:59.772678
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    assert args.debug == True



# Generated at 2022-06-23 22:22:02.644493
# Unit test for function init_settings
def test_init_settings():
    arg = Namespace(debug=True)
    init_settings(arg)
    assert settings.debug
    arg = Namespace(debug=False)
    init_settings(arg)
    assert not settings.debug

# Generated at 2022-06-23 22:22:07.855487
# Unit test for function init_settings
def test_init_settings():
    settings.debug = True
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MUD client, that is not yet named.")
    parser.add_argument('-d', '--debug', action='store_true')
    settings.debug = parser.parse_args().debug
    unittest.main(argv=[__file__, '-v'], exit=False)

# Generated at 2022-06-23 22:22:10.917233
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace())
    assert settings.debug == False

# Generated at 2022-06-23 22:22:13.323085
# Unit test for constructor of class Settings
def test_Settings():
    """
    Initiate a Settings class and check the default setting
    """
    print("Testing constructor of class Settings")
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:22:13.847896
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:22:14.691614
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == T

# Generated at 2022-06-23 22:22:15.498573
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:22:18.115348
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    try:
        init_settings(args)
        assert not settings.debug
    except Exception as e:
        print(e)
        assert False
    args.debug = True
    init_settings(args)
    assert settings.debug
    print("test_init_settings() passed")

# Unit tests for module settings

# Generated at 2022-06-23 22:22:19.299093
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:22:20.645580
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False


# Generated at 2022-06-23 22:22:21.705242
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:22:24.529637
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    import sys
    init_settings(Namespace(debug=True))
    print(settings.debug)
    print(test_init_settings())

# Generated at 2022-06-23 22:22:28.051113
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:29.234366
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:32.158283
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:22:35.241699
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert (settings.debug == True)

# Generated at 2022-06-23 22:22:36.769648
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = False
    

# Generated at 2022-06-23 22:22:39.150774
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:41.394678
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:22:46.157239
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

    # CodeBreaker.test_Settings()
    print("test_Settings() passed")

test_Settings()

# Generated at 2022-06-23 22:22:47.504783
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert not my_settings.debug

# Generated at 2022-06-23 22:22:49.065125
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert settings.debug == True

# Generated at 2022-06-23 22:22:50.654956
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert(test != None)
    assert(test.debug == False)



# Generated at 2022-06-23 22:22:54.123236
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:56.968754
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not isinstance(args.debug, bool)

# Generated at 2022-06-23 22:22:59.279289
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:23:01.260902
# Unit test for function init_settings
def test_init_settings():
    options = Namespace(debug=True)
    init_settings(options)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:03.590256
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:23:05.049629
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    

# Generated at 2022-06-23 22:23:06.014672
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Unit tests for debug

# Generated at 2022-06-23 22:23:08.211528
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == args.debug


# Generated at 2022-06-23 22:23:15.425232
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', default=False, help='Turn on debug mode.')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True

    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', default=False, help='Turn on debug mode.')
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:23:16.899013
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:23:19.673707
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    try:
        assert not settings.debug
    except:
        print("Test for constructor of class Settings failed.")


# Generated at 2022-06-23 22:23:21.652469
# Unit test for constructor of class Settings
def test_Settings():
    obj_Settings = Settings()
    assert(obj_Settings.debug == False)


# Generated at 2022-06-23 22:23:22.725668
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:23.908688
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Testing the initialization method of settings using the argparse

# Generated at 2022-06-23 22:23:24.519064
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:23:25.956612
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:27.673728
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:23:28.883012
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:31.055400
# Unit test for constructor of class Settings
def test_Settings():
    # Test for creating an instance of class Settings
    x = Settings()
    assert x != None


# Generated at 2022-06-23 22:23:33.216182
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:35.198612
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    settings_test.debug = True
    assert settings_test.debug



# Generated at 2022-06-23 22:23:36.891922
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:23:39.409416
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True
    assert isinstance(settings.debug, bool)

# Generated at 2022-06-23 22:23:40.618736
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:23:43.693041
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    settings.debug == args.debug


if __name__ == "__main__":
    args = Namespace(debug=False)
    init_settings(args)
    test_init_settings()

# Generated at 2022-06-23 22:23:45.193730
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False
    assert settings.debug == False


# Generated at 2022-06-23 22:23:46.049724
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings

# Generated at 2022-06-23 22:23:47.392038
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:48.369842
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:23:49.282232
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (not s.debug)

# Generated at 2022-06-23 22:23:50.957439
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug

    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:23:52.207100
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:53.487190
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:23:55.084241
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:56.668705
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    my_settings.debug = True
    assert my_settings.debug

# Generated at 2022-06-23 22:23:59.431337
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:02.079149
# Unit test for constructor of class Settings
def test_Settings():
    t1 = Settings()
    assert not t1.debug
    assert len(t1.__dict__) == 1
    assert len(settings.__dict__) == 1
    assert not settings.debug

# Generated at 2022-06-23 22:24:05.902302
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:08.554585
# Unit test for constructor of class Settings
def test_Settings():
    settings.__init__()
    settings.debug
    assert settings.debug == False



# Generated at 2022-06-23 22:24:12.792533
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert isinstance(settings, Settings)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert isinstance(settings, Settings)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:14.141053
# Unit test for function init_settings
def test_init_settings():
    init_settings(['--debug'])

    assert settings.debug

# Generated at 2022-06-23 22:24:16.145087
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:24:17.569101
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert isinstance(test, Settings)



# Generated at 2022-06-23 22:24:19.994053
# Unit test for function init_settings
def test_init_settings():
    obj = Namespace()
    obj.debug = True
    init_settings(obj)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:24:21.245289
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.debug == False


# Generated at 2022-06-23 22:24:24.531203
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:24:25.527437
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:24:26.888978
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:24:29.572796
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:36.390241
# Unit test for constructor of class Settings
def test_Settings():
    def init_settings(self) -> None:
        self.debug = False

    def test_init_settings(self):
        if self.args.debug:
            self.settings.debug = True

    # Unit test for init_settings
    def test_init_settings(self, args: Namespace) -> None:
        if args.debug:
            self.settings.debug = True

    def init_settings(self, args: Namespace) -> None:
        if args.debug:
            self.settings.debug = True

# Generated at 2022-06-23 22:24:38.135389
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:41.711536
# Unit test for function init_settings
def test_init_settings():
    # Setup
    args: Namespace = Namespace()
    args.debug = True

    # Exercise
    init_settings(args)

    # Verify
    assert settings.debug == True

    # Cleanup - none necessary

# Generated at 2022-06-23 22:24:46.553974
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true")
    args = parser.parse_args(["-d"])
    init_settings(args)
    assert settings.debug
    init_settings(Namespace())
    assert not settings.debug



# Generated at 2022-06-23 22:24:48.389916
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert no

# Generated at 2022-06-23 22:24:49.436905
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:24:51.596008
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()

    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:24:55.431571
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:24:57.634105
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:59.723531
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:01.056410
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert True == settings.debug

# Generated at 2022-06-23 22:25:02.887443
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Unit tests for init_settings

# Generated at 2022-06-23 22:25:04.312632
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:25:05.342814
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:25:07.551417
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# unit test for method init_setting() of class Settings

# Generated at 2022-06-23 22:25:08.514146
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()


# Generated at 2022-06-23 22:25:09.446378
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:25:11.560725
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True
    settings.debug = False


# Generated at 2022-06-23 22:25:13.621952
# Unit test for function init_settings
def test_init_settings():
    s = Namespace()
    s.debug = True
    init_settings(s)
    assert(settings.debug == True)



# Generated at 2022-06-23 22:25:14.591043
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:16.385561
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:17.535065
# Unit test for constructor of class Settings
def test_Settings():
    settings_t = Settings()
    assert settings_t.debug == False


# Generated at 2022-06-23 22:25:19.562910
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    assert not hasattr(settings, 'foo')

# Generated at 2022-06-23 22:25:20.810469
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:25:22.052448
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest.debug == False


# Generated at 2022-06-23 22:25:24.028618
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert args.debug

# Generated at 2022-06-23 22:25:25.551426
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:27.265499
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True