

# Generated at 2022-06-23 22:15:21.436250
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:15:22.344416
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:15:23.738371
# Unit test for constructor of class Settings
def test_Settings():
    # GIVEN
    settings = Settings()
    # WHEN
    # THAN
    assert not settings.debug


# Generated at 2022-06-23 22:15:26.276568
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:15:28.331033
# Unit test for function init_settings
def test_init_settings():
    args = 'command line arguments: -debug'
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:15:29.712904
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:15:31.517890
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert isinstance(settings1, Settings) == True



# Generated at 2022-06-23 22:15:32.588244
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_s

# Generated at 2022-06-23 22:15:37.616829
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


if __name__ == "__main__":
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:15:38.972935
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:15:42.564700
# Unit test for function init_settings
def test_init_settings():
    import argparse
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:15:43.519576
# Unit test for constructor of class Settings
def test_Settings():
    assert(isinstance(settings, Settings) == True)


# Generated at 2022-06-23 22:15:46.969931
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:47.945478
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:15:49.842321
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug is False

# Generated at 2022-06-23 22:15:51.766102
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:52.801564
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, object)

# Generated at 2022-06-23 22:15:57.071312
# Unit test for function init_settings
def test_init_settings():
    print(settings.debug)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    init_settings(args)
    assert settings.debug == False
    print(settings.debug)
    return True

test_init_settings()

# Generated at 2022-06-23 22:15:58.308485
# Unit test for constructor of class Settings
def test_Settings():
    answer = Settings()
    assert answer is not None


# Generated at 2022-06-23 22:16:00.250324
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:16:03.196575
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug



if __name__ == '__main__':
    main()

# Generated at 2022-06-23 22:16:05.104869
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:06.858398
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:08.121221
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:16:09.920205
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-23 22:16:11.435264
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:16:12.416985
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:16:14.729881
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    settings_test.debug = True
    assert settings_test.debug == True

#Unit test for init_settings

# Generated at 2022-06-23 22:16:16.069797
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:16:20.306730
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:22.464277
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:23.550340
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False

# Generated at 2022-06-23 22:16:27.116073
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

test_init_settings()

# Generated at 2022-06-23 22:16:28.450229
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)



# Generated at 2022-06-23 22:16:30.326956
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:31.865989
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:34.197471
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    # Test that settings.debug is true
    assert settings.debug



# Generated at 2022-06-23 22:16:35.846800
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:36.766637
# Unit test for constructor of class Settings
def test_Settings():
    assert settings is not None



# Generated at 2022-06-23 22:16:38.202815
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:16:40.251588
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:16:41.334030
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:43.587727
# Unit test for constructor of class Settings
def test_Settings():
    S = Settings()
    assert S.debug == False, 'Settings.debug expected False, got {}'.format(S.debug)



# Generated at 2022-06-23 22:16:45.140257
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:47.582056
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False, "Debug should be off by default"
    settings.debug = True
    assert settings.debug == True, "Debug should be on"
    settings.debug = False

# Generated at 2022-06-23 22:16:48.151578
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings()

# Generated at 2022-06-23 22:16:50.788178
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug = False)
    init_settings(args)
    assert not settings.debug


# Generated at 2022-06-23 22:16:51.931777
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:53.686617
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    
    assert settings.debug == True

# Generated at 2022-06-23 22:16:55.714561
# Unit test for function init_settings
def test_init_settings():
    argv = ["--debug", "0"]
    cmdline_args = parse_cmdline_args(argv)
    init_settings(cmdline_args)

    assert settings.debug == False



# Generated at 2022-06-23 22:16:57.069267
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    assert settings.debug != True


# Generated at 2022-06-23 22:16:59.393011
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:00.652957
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:17:01.944742
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:17:03.049323
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:05.558290
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:11.988077
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run the bot')
    parser.add_argument("--debug", action='store_true', help='Run the bot in debug mode')
    args = parser.parse_args()
    init_settings(args)
    print(settings)

# Generated at 2022-06-23 22:17:14.613642
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:17:15.831074
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:17.102344
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:21.823770
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug == False

# Generated at 2022-06-23 22:17:24.467445
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:17:26.410521
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s.debug, bool)
    assert not s.debug


# Generated at 2022-06-23 22:17:28.028899
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:29.270924
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    assert type(settings) == Settings


# Generated at 2022-06-23 22:17:30.166675
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:17:32.803778
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:17:34.321373
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:17:35.042295
# Unit test for constructor of class Settings
def test_Settings():
    assert hasattr(settings, "debug")

# Generated at 2022-06-23 22:17:37.304378
# Unit test for constructor of class Settings
def test_Settings():
	settings.debug = True
	assert settings.debug == True


# Generated at 2022-06-23 22:17:39.328574
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    assert settings.debug == True

# Generated at 2022-06-23 22:17:40.727598
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:17:41.674406
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:45.067623
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True 
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:17:47.596315
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:49.483447
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:17:50.617883
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:52.746482
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings()
    assert settings2.debug == False

# Generated at 2022-06-23 22:17:55.863106
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert isinstance(settings.debug, bool)
    values = []
    for _ in range(10):
        values.append(settings.debug)
    assert all(v == True for v in values)

# Generated at 2022-06-23 22:17:56.700662
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:58.508012
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:00.107031
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:18:04.005487
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:06.261432
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    print(s.debug)
    assert s.debug == False



# Generated at 2022-06-23 22:18:07.035390
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:18:07.875881
# Unit test for constructor of class Settings
def test_Settings():
    Settings()
    pass


# Generated at 2022-06-23 22:18:10.397904
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

    class Args:
        def __init__(self) -> None:
            self.debug = True

    args = Args()

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:11.103354
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:18:13.555538
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    args = Namespace(debug=False)
    init_settings(args)
    test_init_settings()

# Generated at 2022-06-23 22:18:14.354948
# Unit test for constructor of class Settings
def test_Settings():
    handle = Settings()
    assert handle.debug == False

# Generated at 2022-06-23 22:18:15.464135
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:16.549670
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = False
    asser

# Generated at 2022-06-23 22:18:24.784298
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    import argparse
    arg_parser = argparse.ArgumentParser("sdfsdfs")
    arg_parser.add_argument("--debug", action="store_true")
    arg_namespace = arg_parser.parse_args([])

    # Act
    
    # Assert
    init_settings(arg_namespace)
    assert not settings.debug

    # Act
    init_settings(arg_parser.parse_args(["--debug"]))

    # Assert
    assert settings.debug

# Generated at 2022-06-23 22:18:25.551446
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False



# Generated at 2022-06-23 22:18:29.383972
# Unit test for function init_settings
def test_init_settings():
    """
    Test for init_settings
    """

    init_settings(Namespace(debug=True))

    assert settings.debug is True
    print("test_init_settings is passed")

# Generated at 2022-06-23 22:18:34.584837
# Unit test for function init_settings
def test_init_settings():
    def do_test(args, debug):
        settings.debug = False
        init_settings(args)
        assert settings.debug == debug

    do_test(Namespace(debug=True), True)
    do_test(Namespace(debug=False), False)
    do_test(Namespace(), False)

# Generated at 2022-06-23 22:18:36.195008
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:37.148380
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:37.676941
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug== False

# Generated at 2022-06-23 22:18:38.666673
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:18:40.944357
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:41.457111
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:18:44.948331
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:46.542784
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:47.763468
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-23 22:18:49.307366
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:50.939266
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:52.846193
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:18:56.085866
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)

    init_settings(args)
    assert settings.debug == True
    settings.debug = False

# Generated at 2022-06-23 22:18:58.786522
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:00.735949
# Unit test for constructor of class Settings
def test_Settings(): # pragma: no cover
    assert settings.debug == False


if __name__ == '__main__': # pragma: no cover
    test_Settings()

# Generated at 2022-06-23 22:19:02.188856
# Unit test for function init_settings
def test_init_settings():
    args = fake_args(
        debug=True,
    )

    init_settings(args)

    assert settings.debug == True


# Generated at 2022-06-23 22:19:03.790138
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:06.259072
# Unit test for function init_settings
def test_init_settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:19:08.005774
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:09.026137
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False

# Generated at 2022-06-23 22:19:11.447057
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange
    settings = Settings()

    # Act
    settings.debug = True

    # Assert
    assert settings.debug == True


# Generated at 2022-06-23 22:19:12.763001
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug != True


# Generated at 2022-06-23 22:19:15.799007
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False, "The flag debug should not be set"


# Generated at 2022-06-23 22:19:16.925570
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-23 22:19:19.592246
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, loglevel=30, logfile="", cpus=1, indir="", outdir="")
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:20.386911
# Unit test for constructor of class Settings
def test_Settings():
    assert settings


# Generated at 2022-06-23 22:19:22.680691
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings is not None
    assert test_settings.debug is False


# Generated at 2022-06-23 22:19:25.597337
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:19:27.484238
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:19:30.771703
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    parser = get_argparser()
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:19:33.133807
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:35.128408
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    setattr(settings,"x",0)
    assert settings.debug == True
    assert settings.x == 0

# Generated at 2022-06-23 22:19:36.587326
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:19:41.969886
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert (settings.debug == False)
    args = Namespace(debug=True)
    init_settings(args)
    assert (settings.debug == True)
    print("test init_settings passed!")


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:19:43.198155
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:19:45.619993
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:46.687007
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__dict__ == {'debug': False}



# Generated at 2022-06-23 22:19:47.492185
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:19:48.499836
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-23 22:19:50.434603
# Unit test for function init_settings
def test_init_settings():
    args_obj = Namespace(debug=True)
    init_settings(args_obj)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:53.986344
# Unit test for constructor of class Settings
def test_Settings():
    #test that debug is false if no argument set
    test1 = Settings()
    assert test1.debug == False
    #test that debug is true if argument is set
    args = Namespace()
    args.debug = True
    test2 = Settings()

# Generated at 2022-06-23 22:19:55.261554
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:00.703811
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert(settings.debug == False)

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)
    
    return

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:20:02.152680
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:04.509545
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    if settings.debug != True:
        raise Exception('The debug is not set to true')

# Generated at 2022-06-23 22:20:06.636091
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug


# Generated at 2022-06-23 22:20:09.366692
# Unit test for constructor of class Settings
def test_Settings():
    argv = ['scriptname']
    args = parser.parse_args(argv)
    
    init_settings(args)
    
    assert settings.debug == False

# Generated at 2022-06-23 22:20:10.449435
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:13.573175
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:20:15.465467
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:20:16.875734
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:20:18.384108
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:20:21.518939
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace()
    args.debug = False

    # Act
    init_settings(args)

    # Assert
    assert settings.debug == False

# Generated at 2022-06-23 22:20:22.394518
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:24.313074
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:26.054007
# Unit test for function init_settings
def test_init_settings():
    assert type(init_settings(Namespace(debug=True))) == None
    assert settings.debug == True

# Generated at 2022-06-23 22:20:29.399185
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert (settings.debug)
    args = Namespace(debug=False)
    init_settings(args)
    assert not (settings.debug)


# Main function

# Generated at 2022-06-23 22:20:33.049631
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    init_settings(args)
    assert settings.debug == False

    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:20:36.291895
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:20:37.674906
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))

    assert(settings.debug)

# Generated at 2022-06-23 22:20:38.640364
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-23 22:20:45.502868
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run the validator.')
    parser.add_argument('--explore', action='store_true',
                        help='Run the exploration (scrap all datas on the website)')
    parser.add_argument('--debug', action='store_true', help='Run in debug mode')
    args = parser.parse_args()

    init_settings(args)

    if args.explore:
        print("Exploration")
        exp.explore()
    else:
        print("Match")
        match.match()

# Generated at 2022-06-23 22:20:46.508442
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:20:49.205509
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True
test_init_settings()

# Generated at 2022-06-23 22:20:50.610870
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:52.819170
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)
    assert s.debug == False


# Generated at 2022-06-23 22:20:54.994634
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    
    # Testing for debug
    ini_sett = init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:57.134983
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    assert settings.debug == False, "Settings constructor failed"


# Generated at 2022-06-23 22:21:01.044367
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:21:03.294062
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:04.666141
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug


# Generated at 2022-06-23 22:21:06.044190
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    assert s.debug == False


# Generated at 2022-06-23 22:21:06.977610
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug



# Generated at 2022-06-23 22:21:08.764108
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing constructor of class Settings")
    settings = Settings()
    assert settings.debug == False
    print("Passed\n")


# Generated at 2022-06-23 22:21:10.495787
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:21:12.627379
# Unit test for function init_settings
def test_init_settings():
    args = get_args(['-d'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:14.228890
# Unit test for constructor of class Settings
def test_Settings():
    S = Settings()
    assert S.debug == False


# Generated at 2022-06-23 22:21:16.902194
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert not settings.debug

    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:21:18.514450
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:19.758907
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    return s.debug == False


# Generated at 2022-06-23 22:21:21.077229
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:22.045610
# Unit test for constructor of class Settings
def test_Settings():
    assert (settings.debug == False)


# Generated at 2022-06-23 22:21:24.312124
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:26.926535
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:21:28.968952
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:29.571630
# Unit test for constructor of class Settings
def test_Settings():
    assert getattr(settings, 'debug') == False

# Generated at 2022-06-23 22:21:32.858116
# Unit test for function init_settings
def test_init_settings():
    # test debug enabled
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    # test debug disabled
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:21:33.436664
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:34.457108
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    # assert settings.debug is False



# Generated at 2022-06-23 22:21:35.831962
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug


# Generated at 2022-06-23 22:21:38.708784
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug # debug is false
    settings.debug = True
    assert settings.debug # debug is true

# Generated at 2022-06-23 22:21:40.446379
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:21:41.435732
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:45.423101
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)

    init_settings(test_args)
    assert settings.debug is True

    test_args = Namespace(debug=False)

    init_settings(test_args)
    assert settings.debug is False

# Generated at 2022-06-23 22:21:50.559677
# Unit test for function init_settings
def test_init_settings():
    settings_test = init_test_settings()
    test_args = Namespace(debug = True)
    init_settings(test_args)
    assert settings.debug == True
    assert settings_test.debug == False


# Run all unit tests if the python file is run directly
if __name__ == '__main__':
    settings_test = init_test_settings()
    test_init_settings()

# Generated at 2022-06-23 22:21:51.829502
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:21:52.556626
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:55.436180
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert type(settings) is Settings
    assert settings.debug

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:21:58.691731
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    print('Test init_settings passed.')

# Generated at 2022-06-23 22:22:00.380262
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert not settings.debug, "debug isn't false"


# Generated at 2022-06-23 22:22:04.360586
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", default=False, type=bool)
    args = parser.parse_args()
    if settings.debug is True:
        print(args)
        init_settings(args)
    assert init_settings(args) is None
    assert settings.debug == False

# Generated at 2022-06-23 22:22:05.544482
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert not setting.debug


# Generated at 2022-06-23 22:22:06.469883
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:07.803845
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:22:09.615670
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert setti

# Generated at 2022-06-23 22:22:13.092993
# Unit test for function init_settings
def test_init_settings():
    def check_settings(args: Namespace, expected: Settings) -> None:
        init_settings(args)
        assert settings.debug == expected.debug

    check_settings(Namespace(debug=False), Settings())
    check_settings(Namespace(debug=True), Settings(debug=True))

# Generated at 2022-06-23 22:22:13.932038
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:16.335476
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:19.916707
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    # check that it works with args.debug == False
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:22.118978
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
 

# Generated at 2022-06-23 22:22:25.248945
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    if settings.debug == True:
        print("Debug mode is on")

# Generated at 2022-06-23 22:22:26.944429
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:22:29.427374
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:30.410045
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False

# Generated at 2022-06-23 22:22:32.639347
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    
    assert settings.debug == False

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:22:36.068229
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    try:
        init_settings(args)
        assert settings.debug == True
    except Exception:
        assert False


# Generated at 2022-06-23 22:22:37.117229
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:39.989431
# Unit test for constructor of class Settings
def test_Settings():
    old_settings = settings.debug
    settings.debug = True
    assert settings.debug
    settings.debug = old_settings


# Generated at 2022-06-23 22:22:40.968502
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:44.018728
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(
        debug=True
    )
    init_settings(test_args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_setti

# Generated at 2022-06-23 22:22:44.989223
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:22:46.009383
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:22:47.730465
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:22:49.653006
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:22:50.866946
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:22:54.372773
# Unit test for constructor of class Settings
def test_Settings():
    # Next line simulates creating a program arguments Namespace object
    # with the debug argument set
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


test_Settings()



# Generated at 2022-06-23 22:22:57.205428
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:22:58.156362
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:00.421359
# Unit test for constructor of class Settings
def test_Settings():
    # Act
    s = Settings()
    # Assert
    assert s.debug == False



# Generated at 2022-06-23 22:23:02.910168
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace()
    args.debug = True
    # Act
    init_settings(args)
    # Assert
    assert settings.debug



# Generated at 2022-06-23 22:23:04.853113
# Unit test for function init_settings
def test_init_settings():
    ns = Namespace(debug=True)
    init_settings(ns)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:23:06.364388
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    args = Namespace
    args.debug = True

    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:08.389776
# Unit test for function init_settings
def test_init_settings():
    dummy_args = Namespace(debug=True)
    init_settings(dummy_args)
    assert settings.debug



# Generated at 2022-06-23 22:23:12.645707
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug


if __name__ == "__main__":
    from argparse import ArgumentParser
    parser = ArgumentParser()

    parser.add_argument("-d", "--debug", action="store_true", help="debug logging mode")

    args = parser.parse_args()
    init_settings(args)

    print(settings.debug)

# Generated at 2022-06-23 22:23:13.450499
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings

# Generated at 2022-06-23 22:23:15.323740
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:16.382804
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:19.561584
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    namespace = Namespace(debug=True)

    # Act
    init_settings(namespace)

    # Assert
    assert settings.debug == True



# Generated at 2022-06-23 22:23:20.544348
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.debug == False)

# Generated at 2022-06-23 22:23:23.707720
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:23:25.136253
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False

# Generated at 2022-06-23 22:23:26.377444
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:29.849418
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)

    assert settings.debug == False

# Generated at 2022-06-23 22:23:31.053937
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())



# Generated at 2022-06-23 22:23:33.215912
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True
    )

    init_settings(args)

    assert settings.debug is True

# Generated at 2022-06-23 22:23:34.352538
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:23:43.532813
# Unit test for function init_settings
def test_init_settings():
    # ===> Test for correct functionality
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    # ====> Test for incorrect functionality
    args = Namespace(debug=5)
    with pytest.raises(TypeError):
        init_settings(args)

    args = Namespace(debug=4.4)
    with pytest.raises(TypeError):
        init_settings(args)

    args = Namespace(debug=None)
    with pytest.raises(TypeError):
        init_settings(args)

    args = Namespace(debug=False)
    with pytest.raises(TypeError):
        init_settings(args)

   

# Generated at 2022-06-23 22:23:44.366884
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:45.558498
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:23:47.018099
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:48.840754
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:49.920673
# Unit test for constructor of class Settings
def test_Settings():
    t = Settings()
    assert t.debug == False


# Generated at 2022-06-23 22:23:51.241746
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:52.439542
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:54.662383
# Unit test for function init_settings
def test_init_settings():
    args_mock = Namespace()
    args_mock.debug = False
    init_settings(args_mock)
    assert settings.debug == False
    args_mock.debug = True
    init_settings(args_mock)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:57.116462
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:59.718523
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug
    assert settings.debug is True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:24:00.686708
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:01.547989
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:03.179965
# Unit test for constructor of class Settings
def test_Settings():
    swith = Settings()
    assert swith.debug == False


# Generated at 2022-06-23 22:24:04.048493
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:24:05.632072
# Unit test for constructor of class Settings
def test_Settings():
    print(settings.debug)
    assert settings.debug == False


# Generated at 2022-06-23 22:24:08.875148
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:12.063507
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:24:15.746986
# Unit test for function init_settings
def test_init_settings():
    try:
        assert settings.debug == False
        init_settings(Namespace(debug=True))
        assert settings.debug == True
        init_settings(Namespace(debug=False))
        assert settings.debug == False
    except:
        print("init_settings function is not working")
        assert False

# Generated at 2022-06-23 22:24:16.559082
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False, "Settings class is not initialised correctly"


# Generated at 2022-06-23 22:24:18.888286
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

test_init_settings()

# Generated at 2022-06-23 22:24:21.169006
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:24:22.439929
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:24.054614
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace(debug = True)
    init_settings(mock_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:26.655589
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug == True
    init_settings(args=Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:24:27.463515
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:30.300548
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug
    assert type(test_settings.debug) == bool


# Generated at 2022-06-23 22:24:30.865863
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Setti

# Generated at 2022-06-23 22:24:35.069915
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:24:36.820324
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing Constructor of class Settings")

    settings = Settings()

    assert settings.debug == False

# Generated at 2022-06-23 22:24:39.628094
# Unit test for function init_settings
def test_init_settings():
    cmd_args = ["-d"]
    args = parser.parse_args(cmd_args)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:24:41.384312
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:47.099964
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

if __name__ == '__main__':
    args = argparse.ArgumentParser()
    args.add_argument('--debug', action='store_true')
    args = args.parse_args()
    init_settings(args)

# Generated at 2022-06-23 22:24:48.999571
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:24:50.750152
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:52.531086
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:55.946304
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args.debug=True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:57.831906
# Unit test for function init_settings
def test_init_settings():
    a = Namespace()
    a.debug = False
    init_settings(a)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:59.137684
# Unit test for constructor of class Settings
def test_Settings():
    settingsObj = Settings()
    assert settingsObj.debug == False

# Generated at 2022-06-23 22:25:00.484717
# Unit test for constructor of class Settings
def test_Settings():
    print("test_Settings")
    print(settings.debug)



# Generated at 2022-06-23 22:25:01.964719
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    s.debug = True



# Generated at 2022-06-23 22:25:03.698750
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:06.601803
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    pytest.main(['-q', __file__])

# Generated at 2022-06-23 22:25:08.283921
# Unit test for function init_settings
def test_init_settings():
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:10.340970
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug is True


# Generated at 2022-06-23 22:25:11.652043
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)


# Generated at 2022-06-23 22:25:12.853629
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:14.387518
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:25:15.391880
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:25:20.091248
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:25:21.439237
# Unit test for constructor of class Settings
def test_Settings():
    '''Testing function for constructor of class Settings'''

    settings1 = Settings()
    assert settings1.debug == False