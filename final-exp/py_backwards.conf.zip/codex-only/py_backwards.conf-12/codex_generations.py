

# Generated at 2022-06-23 22:15:19.634651
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:15:22.287794
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="Test argument parser")
    parser.add_argument('--debug', action="store_true")
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:23.272080
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert not settings.debug

# Generated at 2022-06-23 22:15:28.246310
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", default=False, action='store_true')
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False

    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", default=False, action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:15:29.295781
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:15:31.122065
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:15:33.603554
# Unit test for constructor of class Settings
def test_Settings():
    new_debug = True
    assert settings.debug != new_debug
    settings.debug = new_debug
    assert settings.debug == new_debug


# Generated at 2022-06-23 22:15:36.700014
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:37.515687
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

test_Settings()

# Generated at 2022-06-23 22:15:38.331535
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug, f'debug has to be False, but is {settings.debug}'


# Generated at 2022-06-23 22:15:41.736307
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:42.506229
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:15:43.454942
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False


# Generated at 2022-06-23 22:15:44.566778
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:15:45.200414
# Unit test for constructor of class Settings
def test_Settings():
    obj = Settings()
    assert obj.debug == False

# Generated at 2022-06-23 22:15:46.044736
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False, "Fail"


# Generated at 2022-06-23 22:15:46.681427
# Unit test for constructor of class Settings
def test_Settings():
    init_settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:15:48.201031
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert isinstance(settings1, Settings)



# Generated at 2022-06-23 22:15:50.602554
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:15:51.244385
# Unit test for constructor of class Settings

# Generated at 2022-06-23 22:15:54.806127
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-23 22:15:56.350238
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:15:59.730486
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings.debug is True
    args = Namespace(**{'debug': False})
    init_settings(args)
    assert settings.debug is False

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:16:00.757363
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:16:04.545735
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    
    

# Generated at 2022-06-23 22:16:08.416821
# Unit test for function init_settings
def test_init_settings():
    # Reset settings
    settings.debug = False
    # DEBUG
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    # Release
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:16:10.056526
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False


# Generated at 2022-06-23 22:16:12.316863
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:15.461319
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:16:18.559184
# Unit test for function init_settings
def test_init_settings():
    my_args = Namespace(debug=False)
    init_settings(my_args)
    assert not settings.debug

    my_args = Namespace(debug=True)
    init_settings(my_args)
    assert settings.debug

# Generated at 2022-06-23 22:16:19.786612
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:21.958343
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:16:23.302986
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:24.607757
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug is False

# Generated at 2022-06-23 22:16:25.654491
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings


# Generated at 2022-06-23 22:16:28.024541
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    print('Value of debug flag is {}'.format(settings.debug))
    assert settings.debug == False


# Generated at 2022-06-23 22:16:28.929870
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:16:31.370995
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:16:32.237317
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:16:34.244751
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False


test_Settings()

# Generated at 2022-06-23 22:16:37.346546
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:16:39.166352
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:16:46.219242
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(
        debug=True,
        ignore_failures=False,
        nthreads=1,
        number_of_attempts=1,
        clean=False,
        project_path=None,
        skip_config=False,
        skip_manual=False,
        update=None,
        update_on_failure=False,
        variant="default",
        packages=[],
        packages_regex=[],
        ignore_groups=[],
        ignore_packages=[],
        ignore_packages_regex=[],
        only_groups=[],
        only_packages=[],
        only_packages_regex=[],
        no_default_profiles=False,
        profiles=[],
        selectors=[]
    )
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:47.211235
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    

# Generated at 2022-06-23 22:16:49.913882
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:16:52.692880
# Unit test for function init_settings
def test_init_settings():
    args_1 = Namespace(debug=False)
    args_2 = Namespace(debug=True)
    init_settings(args_1)
    assert settings.debug==False
    init_settings(args_2)
    assert settings.debug==True

# Generated at 2022-06-23 22:16:54.094485
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:16:58.805803
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', default=False, const=True, nargs='?', action='store', help='Debug mode')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:02.440725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:04.934619
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:06.125563
# Unit test for constructor of class Settings
def test_Settings():
    assert settings


# Generated at 2022-06-23 22:17:08.573409
# Unit test for constructor of class Settings
def test_Settings():
    print('Test for constructor of class Settings')
    settings = Settings()
    assert(settings.debug == False)



# Generated at 2022-06-23 22:17:09.221151
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:17:12.828240
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

if settings.debug:
    print("Debug is enabled")
else:
    print("Debug is disabled")

# Generated at 2022-06-23 22:17:14.703836
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:17:15.961545
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:17:17.866734
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:19.450663
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:20.340832
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:21.218746
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Generated at 2022-06-23 22:17:22.646354
# Unit test for function init_settings
def test_init_settings():
    settings.debug = True
    assert settings.debug == True
    settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-23 22:17:26.046331
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, packages='', installs='all')
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Skip the tests if nose not installed
if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-23 22:17:29.162996
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False
    
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:30.050139
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:17:31.501841
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:17:38.074063
# Unit test for function init_settings
def test_init_settings():
    testArgs = Namespace(debug=True)
    init_settings(testArgs)
    if settings.debug:
        print("init_settings: Passed")
    else:
        raise Exception("init_settings: Failed")


if __name__ == '__main__':
    assert settings.debug == False
    testArgs = Namespace(debug=True)
    init_settings(testArgs)
    assert settings.debug == True

    print('All tests for module "settings" passed!')

# Generated at 2022-06-23 22:17:39.798208
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert(s.debug == False)

# Unit Test for init_settings

# Generated at 2022-06-23 22:17:41.205898
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:17:44.067592
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:48.656389
# Unit test for function init_settings
def test_init_settings():
    # Initialize namespaces
    args_debug_on = Namespace()
    args_debug_on.debug = True
    args_debug_off = Namespace()
    args_debug_off.debug = False

    # Test if setting is initialized properly
    init_settings(args_debug_on)
    assert settings.debug == True
    init_settings(args_debug_off)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:50.453646
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:52.580879
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:17:55.098016
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:56.197712
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:17:57.687235
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    settings2 = Settings()

    assert settings1.debug is False
    assert settings2.debug is False


# Generated at 2022-06-23 22:17:59.220246
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace(debug=True)
    # Act
    init_settings(args)
    # Assert
    assert(settings.debug)

# Generated at 2022-06-23 22:18:00.240082
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:02.951551
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = 'debug'
    init_settings(args)
    asser

# Generated at 2022-06-23 22:18:03.956744
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:18:06.261137
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:07.986517
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)

    assert settings.debug



# Generated at 2022-06-23 22:18:09.064160
# Unit test for constructor of class Settings
def test_Settings():
    Settings()
    assert settings.debug==False


# Generated at 2022-06-23 22:18:10.147749
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:18:12.683114
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    setattr(args, "debug", False)
    init_settings(args)
    assert settings.debug == False
    setattr(args, "debug", True)
    init_settings(args)
    assert settings.debug == True
#

# Generated at 2022-06-23 22:18:13.375058
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False

# Generated at 2022-06-23 22:18:15.108861
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug, "init_settings test failed"

# Generated at 2022-06-23 22:18:19.737990
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings.debug = True
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    settings.debug = False
    assert settings.debug == False

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:18:22.415921
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:24.259094
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:25.507377
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:18:29.337914
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()

    settings.debug = True
    assert settings.debug == True

    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-23 22:18:32.541619
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:35.246449
# Unit test for constructor of class Settings
def test_Settings():
    init_settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:37.746270
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Unittest for init_settings(args) method

# Generated at 2022-06-23 22:18:39.021799
# Unit test for constructor of class Settings
def test_Settings():
    sett = Settings()
    assert sett.debug is False


# Generated at 2022-06-23 22:18:48.095592
# Unit test for function init_settings
def test_init_settings():
    init_settings_args = Namespace(debug=True)
    init_settings(init_settings_args)
    assert settings.debug == True


'''
Sample output for test_init_settings
=================================== test session starts ====================================
platform linux2 -- Python 2.7.6 -- py-1.4.26 -- pytest-2.7.0
rootdir: /home/Yusuke/Desktop/tokyo_python_meetup/bowling-kata-python, inifile:
collected 1 items

bowling_kata_python/bowling_kata_python_test.py .

============================= 1 passed in 0.05 seconds =============================
'''

# Generated at 2022-06-23 22:18:50.737376
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:02.043076
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    import sys
    import os.path
    import argparse

    parser = argparse.ArgumentParser()

    def add_debug_option(parser: argparse.ArgumentParser) -> None:
        parser.add_argument('-d', '--debug', action='store_true', default=None,
                            help='Enable debug mode.')

    add_debug_option(parser)

    args = parser.parse_args()

    init_settings(args)

    if settings.debug:
        print('You are in debug mode.')
        print(args)

    base_dir = os.path.dirname(__file__)

# Generated at 2022-06-23 22:19:03.645525
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:19:04.978193
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:19:07.502280
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug == False


# Expected output: settings.debug = False
# Actual output: settings.debug = False


# Generated at 2022-06-23 22:19:12.591371
# Unit test for constructor of class Settings
def test_Settings():
    import os
    import shutil
    import sys
    import tempfile

    try:
        temp_dir = tempfile.mkdtemp()
        args = sys.argv
        sys.argv = [args[0], "init", "-d", "debug"]

        import karl

        karl.main()

        assert settings.debug is True
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-23 22:19:16.366707
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = False))
    assert settings.debug == False

    init_settings(Namespace(debug = True))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:20.019240
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace()
    mock_args.debug = False
    settings.debug = False
    init_settings(mock_args)
    assert settings.debug == False

    mock_args.debug = True
    settings.debug = False
    init_settings(mock_args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:21.527248
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:19:23.200363
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:28.764340
# Unit test for function init_settings
def test_init_settings():
    from argparse import Namespace
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument('--debug', action='store_true', default=False)
    args, _ = parser.parse_known_args()
    init_settings(args)
    assert args.debug == False
    assert Settings.debug == False

# Generated at 2022-06-23 22:19:29.652161
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None
    assert settings.debug == False



# Generated at 2022-06-23 22:19:31.065852
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:19:33.478314
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:35.266230
# Unit test for constructor of class Settings
def test_Settings():
    S = Settings()
    assert S.debug == False


# Generated at 2022-06-23 22:19:36.309377
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False

# Generated at 2022-06-23 22:19:40.115687
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:42.276456
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug


# Generated at 2022-06-23 22:19:43.298008
# Unit test for constructor of class Settings
def test_Settings():
    assert_that(settings.debug, is_(False))



# Generated at 2022-06-23 22:19:44.817644
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:45.737247
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)

# Generated at 2022-06-23 22:19:46.793375
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    settings.debug = True
    assert settings.debug == True


# Generated at 2022-06-23 22:19:48.690349
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace(debug=True)
    # Act
    init_settings(args)
    # Assert
    assert settings.debug is True


# Generated at 2022-06-23 22:19:50.609012
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:52.081969
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False


# Generated at 2022-06-23 22:19:55.509334
# Unit test for function init_settings
def test_init_settings():
    settings.debug = ''
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:19:57.398848
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:19:58.771688
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert test.debug == False

test_Settings()

# Generated at 2022-06-23 22:20:01.226387
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()

    try:
        assert s.debug is False
    except:
        raise Exception("Class Settings is not correctly defined")

    print("Test for class Settings is passed")



# Generated at 2022-06-23 22:20:02.877895
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:03.706358
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:05.709852
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:07.386842
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (s.debug == False)

# Generated at 2022-06-23 22:20:12.493106
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', help='Run in debug mode (verbose output, don\'t use real bot accounts, etc)')
    args = parser.parse_args([])
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:14.269016
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:20:15.240633
# Unit test for constructor of class Settings
def test_Settings():
    test = Settings()
    assert not test.debug

# Generated at 2022-06-23 22:20:18.382797
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:20:19.701808
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:22.198725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    # debug option
    assert settings.debug == True

# Generated at 2022-06-23 22:20:23.259813
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:25.154725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-23 22:20:26.671342
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert (not s.debug)


# Generated at 2022-06-23 22:20:27.678702
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:20:29.101566
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None



# Generated at 2022-06-23 22:20:31.354145
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:20:33.223491
# Unit test for function init_settings
def test_init_settings():

    settings.debug = False

    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:20:36.484665
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:20:37.479485
# Unit test for constructor of class Settings
def test_Settings():
  set = Settings()
  assert set.debug == False

# Generated at 2022-06-23 22:20:41.581358
# Unit test for constructor of class Settings
def test_Settings():
    print("Testing constructor of class Settings")
    expected = False
    
    real = Settings()
    
    assert expected == real.debug
    print("Expected output: " + str(expected) + "  Actual output: " + str(real.debug))
    print("Testing completed")
    
    

# Generated at 2022-06-23 22:20:46.275217
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:50.190402
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(daemonize=False, debug=True, host="127.0.0.1", log_file="", port=9991, settings_file="")
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:54.769049
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    parser = argparse.ArgumentParser(description='This is the Recruitment Manager')
    parser.add_argument("-d", "--debug", action = "store_true", help="setting debug to true")
    args = parser.parse_args()

    init_settings(args)

    assert settings.debug == False

# Generated at 2022-06-23 22:20:56.492904
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:20:57.472801
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:20:59.139895
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:20:59.703535
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == Settings()

# Generated at 2022-06-23 22:21:01.123218
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:21:02.944826
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:04.716781
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings
    assert settings.debug == False

# init_settings with None arguments

# Generated at 2022-06-23 22:21:06.090927
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:07.399085
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings) is True
    assert settings.debug == False


# Generated at 2022-06-23 22:21:09.551489
# Unit test for function init_settings
def test_init_settings():
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:13.593958
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:21:15.685813
# Unit test for function init_settings
def test_init_settings():
    arg_namespace = Namespace(debug=True)
    init_settings(arg_namespace)
    assert settings.debug

# Generated at 2022-06-23 22:21:16.920820
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings()
    assert setting.debug == False

# Generated at 2022-06-23 22:21:18.561042
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False



# Generated at 2022-06-23 22:21:20.195847
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:21.198962
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:21:22.405033
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:21:23.345045
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:23.956890
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:21:25.034837
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug # pylint: disable=no-member

# Generated at 2022-06-23 22:21:26.358575
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    settings.init_settings(Namespace(debug=True))
    assert settings.debug == True


# Class Human

# Generated at 2022-06-23 22:21:28.140982
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:21:30.029194
# Unit test for constructor of class Settings
def test_Settings():
    assert(not settings.debug)
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)

# Generated at 2022-06-23 22:21:33.279007
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:21:34.320387
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:35.362978
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:21:35.873383
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()

# Generated at 2022-06-23 22:21:38.752807
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:21:40.812586
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    print("Test passed!")

# Generated at 2022-06-23 22:21:42.241882
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:21:44.193035
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:45.421699
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-23 22:21:48.001100
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug == True



# Generated at 2022-06-23 22:21:49.328889
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False


# Generated at 2022-06-23 22:21:51.025308
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:21:52.990052
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:21:53.952596
# Unit test for constructor of class Settings
def test_Settings():
    assert(not settings.debug)



# Generated at 2022-06-23 22:21:56.903843
# Unit test for function init_settings
def test_init_settings():
    # Initialize settings
    init_settings(Namespace(debug=True))
    # Check settings
    assert settings.debug is True

# Generated at 2022-06-23 22:21:58.447739
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings != None


# Generated at 2022-06-23 22:21:59.614319
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:04.120218
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", help="Run in debug mode.")
    args = parser.parse_args([])
    init_settings(args)
    assert not settings.debug
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:10.511985
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true', help='Debug mode')
    args = parser.parse_args()
    init_settings(args)
    assert settings.debug == False


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true', help='Debug mode')
    args = parser.parse_args()
    init_settings(args)

    print(settings.debug)
    print('Settings is initialized')

# Generated at 2022-06-23 22:22:11.695879
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:22:12.551054
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False

# Generated at 2022-06-23 22:22:13.890989
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)

# Generated at 2022-06-23 22:22:16.294563
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert not settings.debug
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:17.593838
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False


# Generated at 2022-06-23 22:22:19.412514
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert (settings.debug == False)


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:22:21.715028
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:22:23.785714
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:22:25.759366
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:26.805067
# Unit test for constructor of class Settings
def test_Settings():
    # test for creating Settings object
    assert settings == Settings()

# Generated at 2022-06-23 22:22:29.274267
# Unit test for function init_settings
def test_init_settings():
    # Test the default case
    init_settings(Namespace())
    assert not settings.debug
    # Test the debug case
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:22:30.736534
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings



# Generated at 2022-06-23 22:22:31.683182
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:22:35.718669
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace(debug=False)

    init_settings(args)

    assert not settings.debug

    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug

# Generated at 2022-06-23 22:22:45.505245
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


main_parser = argparse.ArgumentParser(description="Captain Repo's tool to manage git repositories")
main_parser.add_argument("-d", "--debug", help="enable debug output", action="store_true")

subparsers: argparse._SubParsersAction = main_parser.add_subparsers(dest="command")

# Parse command: create
create_parser = subparsers.add_parser("create")
create_parser.add_argument("-p", "--path", help="path to repository folder", required=True)
create_parser.add_argument("-e", "--empty", help="disable init: creates an empty repository", action="store_true")

# Parse command: remove
remove_parser = subpars

# Generated at 2022-06-23 22:22:47.421675
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:48.640180
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:22:50.269982
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False, "Debug flag of settings is not initialized to default value"


# Generated at 2022-06-23 22:22:55.342609
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:56.140303
# Unit test for function init_settings
def test_init_settings():
    args = Namesp

# Generated at 2022-06-23 22:22:58.242115
# Unit test for constructor of class Settings
def test_Settings():
    # Initialize Settings
    settings = Settings()
    
    # Test that the settings are defined.
    assert settings.debug == False


# Generated at 2022-06-23 22:22:59.730942
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:23:01.804898
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False

    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True



# Generated at 2022-06-23 22:23:05.406725
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not args.debug


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:23:09.227052
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    # Test for cases where debug is not set
    args.debug = None
    init_settings(args)
    assert not settings.debug

    # Test for cases where debug is set
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:10.257935
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:11.265234
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:23:12.682777
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings.debug == False
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:23:13.646664
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings

# Generated at 2022-06-23 22:23:15.323391
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False

# Generated at 2022-06-23 22:23:16.371542
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False



# Generated at 2022-06-23 22:23:18.683502
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False, 'Settings.debug should be False!'

# Generated at 2022-06-23 22:23:20.570320
# Unit test for constructor of class Settings
def test_Settings():
    x = init_settings(args)
    assert x == None

# Generated at 2022-06-23 22:23:22.886798
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:23.735601
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == False

# Generated at 2022-06-23 22:23:25.185343
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:23:26.437263
# Unit test for constructor of class Settings
def test_Settings():
    assert settings != None


# Generated at 2022-06-23 22:23:32.460480
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="Test settings initialisation")
    parser.add_argument("-debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()
    init_settings(args)
    print("Debug mode: ", settings.debug)


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:23:34.887307
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange

    # Act
    settings = Settings()

    # Assert
    assert settings.debug is False



# Generated at 2022-06-23 22:23:36.982561
# Unit test for constructor of class Settings
def test_Settings():
    S = Settings()
    assert S.debug == False


# Generated at 2022-06-23 22:23:38.298731
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False


# Generated at 2022-06-23 22:23:39.408484
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    asser

# Generated at 2022-06-23 22:23:40.939405
# Unit test for function init_settings
def test_init_settings():
    # initialize fb_params argument
    args = Namespace()
    args.debug = True
    init_settings(args)

# Generated at 2022-06-23 22:23:42.425845
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:44.213049
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:23:45.072773
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:23:46.877943
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:48.093644
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:50.075772
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:51.337545
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:53.278512
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:23:55.212337
# Unit test for constructor of class Settings
def test_Settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_Settings()

# Generated at 2022-06-23 22:23:56.800254
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:23:57.643530
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:23:58.941262
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:00.251921
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert not settings1.debug



# Generated at 2022-06-23 22:24:02.888863
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:05.687800
# Unit test for function init_settings
def test_init_settings():
    arg = argparse.Namespace()
    arg.debug = True
    init_settings(arg)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:06.690542
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-23 22:24:07.998478
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:24:09.022227
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:11.054831
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:24:12.607203
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    settings = Settings()
    init_settings(args)
    assert settings.debug is False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:16.255500
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    assert settings.debug is False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-23 22:24:17.992975
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:19.677915
# Unit test for constructor of class Settings
def test_Settings():
    settingsE = Settings()
    assert settingsE.debug == False



# Generated at 2022-06-23 22:24:21.573567
# Unit test for function init_settings
def test_init_settings():
    t = Namespace()
    t.debug = True
    init_settings(t)
    assert settings.debug

test_init_settings()

# Generated at 2022-06-23 22:24:24.057569
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:24:26.454963
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:28.800314
# Unit test for function init_settings
def test_init_settings():
    # If a string 'debug' is passed as an argument, then debug should be true
    args = Namespace()
    args.debug = 'debug'
    init_settings(args)
    assert settings.debug == True

    # If a string 'debug' is not passed as an argument, then debug should be false
    args = Namespace()
    args.debug = 'verbose'
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-23 22:24:29.832418
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:24:30.727705
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:32.609915
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:35.173188
# Unit test for constructor of class Settings
def test_Settings():
    # Arrange
    st = Settings()

    # Act
    debug = st.debug

    # Assert
    assert debug == False

# Generated at 2022-06-23 22:24:37.288584
# Unit test for function init_settings
def test_init_settings():
        
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:24:38.983557
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:24:41.792223
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:24:44.744893
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = False
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:46.030247
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:24:49.075060
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:24:50.457834
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:24:51.500678
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:24:54.851167
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:56.692728
# Unit test for constructor of class Settings
def test_Settings():
    print("Unit Test for constructor of class Settings")
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:25:04.849009
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace()
    mock_args.debug = True

    # Run function
    init_settings(mock_args)

    # Check settings are correct
    assert settings.debug


if __name__ == "__main__":
    print("Running settings module as main")
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", help="Enable Debug Mode",
                        action="store_true")
    args = parser.parse_args()

    init_settings(args)
    pytest.main(args=['./other_tests'])

# Generated at 2022-06-23 22:25:05.731248
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:25:08.002801
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False

    # Unit test for function init_settings (1)

# Generated at 2022-06-23 22:25:09.976745
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:25:12.801264
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:25:14.842969
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:25:18.133678
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug is False
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:25:19.521823
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
