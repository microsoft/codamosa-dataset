

# Generated at 2022-06-23 22:15:27.252220
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:15:28.679421
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:15:30.923044
# Unit test for constructor of class Settings
def test_Settings():
    settings_initialize = Settings()
    assert settings_initialize
    assert settings_initialize.debug == False



# Generated at 2022-06-23 22:15:34.227731
# Unit test for function init_settings
def test_init_settings():
    init_settings(args = Namespace(debug = True))
    assert settings.debug == True
    init_settings(args = Namespace(debug = False))
    assert settings.debug == False
    return True

# Generated at 2022-06-23 22:15:36.168764
# Unit test for constructor of class Settings
def test_Settings():
    # test the constructor of the class
    s = Settings()
    assert s.debug is False

# Generated at 2022-06-23 22:15:37.132953
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:15:38.718135
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    init_settings(test_args)
    assert settings.debug == False



# Generated at 2022-06-23 22:15:41.577334
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:42.296779
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:15:43.515751
# Unit test for constructor of class Settings
def test_Settings():
    test_Settings = Settings()
    assert test_Settings.debug == False


# Generated at 2022-06-23 22:15:44.394170
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)


# Generated at 2022-06-23 22:15:46.735598
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:15:50.394860
# Unit test for function init_settings
def test_init_settings():
    # Given
    from sys import argv
    args = Namespace()
    argv.append('--debug')

    # When
    init_settings(args)

    # Assert
    assert settings.debug == True

# Generated at 2022-06-23 22:15:52.285388
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:15:55.018951
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:15:56.683409
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:15:58.761954
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:16:00.706047
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:02.087772
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert settings.debug == True



# Generated at 2022-06-23 22:16:04.930514
# Unit test for constructor of class Settings
def test_Settings():
    newSettings = init_settings(Namespace(debug=True))
    assert newSettings.debug == True
    newSettings2 = init_settings(Namespace(debug=False))
    assert newSettings2.debug == False

# Generated at 2022-06-23 22:16:07.797627
# Unit test for constructor of class Settings
def test_Settings():
    args = ''.split()
    init_settings(args)
    assert settings.debug == False
    args = 'a --debug'.split()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:11.968821
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:15.891508
# Unit test for function init_settings
def test_init_settings():
    class Args:
        def __init__(self, debug=False):
            self.debug = debug


    init_settings(Args())
    assert settings.debug == False

    init_settings(Args(True))
    assert settings.debug == True


# Generated at 2022-06-23 22:16:18.475504
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:16:20.100088
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug == False


# Generated at 2022-06-23 22:16:20.808104
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:25.242790
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=False)
    init_settings(test_args)
    assert settings.debug == False

    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug == True



# Generated at 2022-06-23 22:16:26.976355
# Unit test for constructor of class Settings
def test_Settings():
    x = Settings()
    assert x.debug == False



# Generated at 2022-06-23 22:16:28.259200
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:16:29.758797
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False

# Read command line options

# Generated at 2022-06-23 22:16:33.627882
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False    
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:35.185578
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False



# Generated at 2022-06-23 22:16:36.737451
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:16:40.690626
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", dest="debug", help="Debug mode")
    args = parser.parse_args()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:16:43.820369
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:16:45.742149
# Unit test for constructor of class Settings
def test_Settings():
    # Constructor
    a = Settings()

    # Test if the values of the attributes are set correctly
    assert a.debug == False

# Generated at 2022-06-23 22:16:47.476441
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:49.827420
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:16:51.027151
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:16:52.809262
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:16:53.914376
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:16:58.185468
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)

    # Unit test for constructor of class Settings
    test_Settings()

    print(settings.debug)

# Generated at 2022-06-23 22:16:59.761353
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:02.221584
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings.debug = True
    assert test_settings.debug


# Generated at 2022-06-23 22:17:04.108460
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False and settings.debug == 0


# Generated at 2022-06-23 22:17:05.849476
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(settings.debug == False)

# Generated at 2022-06-23 22:17:07.004208
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:17:09.461933
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True, seed=123)
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:17:13.196834
# Unit test for constructor of class Settings
def test_Settings():
    # test that instance of Settings class is created
    settings = Settings()
    assert type(settings) is Settings
    # test that property debug is equal to False
    assert settings.debug == False


# Generated at 2022-06-23 22:17:15.321392
# Unit test for function init_settings
def test_init_settings():

    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:17:17.536065
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:17:21.861217
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:17:29.731092
# Unit test for function init_settings
def test_init_settings():
    # set debug to false, args has debug = true
    settings.debug = False
    args = Namespace()  # type: Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug is True

    # set debug to true, args has debug = false
    settings.debug = True
    args = Namespace()  # type: Namespace
    args.debug = False
    init_settings(args)
    assert settings.debug is False

    # set debug to true, args has debug = true
    settings.debug = True
    args = Namespace()  # type: Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug is True

    # set debug to false, args has debug = false
    settings.debug = False
    args = Namespace()  # type: Names

# Generated at 2022-06-23 22:17:31.643000
# Unit test for function init_settings
def test_init_settings():
    # Test for a valid setting
    args: Namespace = Namespace(debug=True)
    init_settings(args)
    assert getattr(settings, 'debug') is True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:17:33.055391
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False


# Generated at 2022-06-23 22:17:34.562526
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:17:36.647262
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:17:38.600133
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    init_settings(args=Namespace(debug=True))
    assert settings.debug == True


# Generated at 2022-06-23 22:17:40.775024
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-23 22:17:46.202686
# Unit test for constructor of class Settings
def test_Settings():
    from unittest import TestCase
    import sys

    class Test(TestCase):
        def test_Settings(self):
            global settings

            self.assertFalse(settings.debug)
            init_settings(Namespace(debug=True))
            self.assertTrue(settings.debug)
            init_settings(Namespace(debug=False))
            self.assertFalse(settings.debug)

    sys.modules[__name__ + ".Settings"] = Test()

# Generated at 2022-06-23 22:17:47.301531
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:17:50.410749
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    # just for test
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:52.538365
# Unit test for constructor of class Settings
def test_Settings():
    my_settings = Settings()
    assert my_settings.debug == False

# Generated at 2022-06-23 22:17:54.362288
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:17:55.843228
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:17:57.335544
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:17:58.375073
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:00.180801
# Unit test for function init_settings
def test_init_settings():
    args_ok = Namespace(debug=True)
    init_settings(args_ok)
    assert settings.debug

    args_nok = Namespace(debug=False)
    init_settings(args_nok)
    assert (not settings.debug)

# Generated at 2022-06-23 22:18:05.147701
# Unit test for function init_settings
def test_init_settings():
    # Naming rule: "test_" followed by a function, then the function name you want to test.

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:06.411069
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:08.133399
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:18:09.507681
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:11.832306
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug = True)
    print(test_args.debug)
    init_settings(test_args)
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:18:12.778018
# Unit test for constructor of class Settings
def test_Settings():
    # settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:13.938404
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:18:16.140957
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

if __name__ == "__main__":
    args = Namespace(debug=True)
    init_settings(args)
    print(settings.debug)

# Generated at 2022-06-23 22:18:18.805495
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:20.105747
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:18:23.694215
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:26.461277
# Unit test for function init_settings
def test_init_settings():
    """settings.debug is false and should become true when passed as args"""

    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:18:28.825222
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug
    settings.debug = True
    assert settings.debug

# Generated at 2022-06-23 22:18:34.266263
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()
    init_settings(args)

    # ...

# Generated at 2022-06-23 22:18:35.041104
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:35.859032
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug

# Generated at 2022-06-23 22:18:36.807932
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    return True

# Generated at 2022-06-23 22:18:38.098086
# Unit test for constructor of class Settings
def test_Settings():
    set1 = Settings()
    assert set1



# Generated at 2022-06-23 22:18:39.334460
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:18:40.945581
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:42.564882
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:18:43.692065
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:18:45.404090
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert not settings_test.debug

# Generated at 2022-06-23 22:18:46.671477
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False
    

# Generated at 2022-06-23 22:18:48.218239
# Unit test for function init_settings
def test_init_settings():
    args = argparse.Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:18:51.788482
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()

    args.debug = None
    init_settings(args)
    assert not settings.debug

    args.debug = False
    init_settings(args)
    assert not settings.debug

    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:54.146153
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:18:57.287181
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug



# Generated at 2022-06-23 22:18:57.998671
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:18:59.605560
# Unit test for function init_settings
def test_init_settings():
    from unittest.mock import Mock
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:00.202103
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug


# Generated at 2022-06-23 22:19:01.428853
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:19:02.551342
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:06.733402
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Test the module level

test_init_settings()

# Generated at 2022-06-23 22:19:08.078006
# Unit test for constructor of class Settings
def test_Settings():
    test_instance = Settings()

    assert test_instance is not None

# Generated at 2022-06-23 22:19:10.689156
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:19:11.989376
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False
    settings.debug = True
    assert settings.debug is True

# Generated at 2022-06-23 22:19:15.790887
# Unit test for constructor of class Settings
def test_Settings():
    cls_settings = Settings()
    assert cls_settings.debug == False


# Unit test of function init_settings which initializes the settings variable

# Generated at 2022-06-23 22:19:17.292243
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-23 22:19:18.050573
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:20.688206
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:21.212684
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug

# Generated at 2022-06-23 22:19:25.267093
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


"""
###############################################
                                                #
    Unit test for the function                 #
    init_settings of class Settings           #
                                                #
###############################################
"""



# Generated at 2022-06-23 22:19:26.338443
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert not settings.debug

    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:19:27.794153
# Unit test for constructor of class Settings
def test_Settings():
    import pytest
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:19:31.455938
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert settings.debug == False

    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:35.575799
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug is False

    args.debug = True
    init_settings(args)
    assert settings.debug is True

if __name__ == "__main__":
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:19:37.117866
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings.debug == False

# Generated at 2022-06-23 22:19:39.973651
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:19:41.246416
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False

# Generated at 2022-06-23 22:19:43.317840
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-23 22:19:44.808686
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:19:50.165736
# Unit test for constructor of class Settings
def test_Settings():
    from unittest.mock import patch
    from argparse import Namespace
    import sys

    with patch.object(sys, 'argv', ['main.py', '--debug']):
        args = parser.parse_args()
        init_settings(args)
        assert settings.debug == True

    with patch.object(sys, 'argv', ['main.py', '--no-debug']):
        args = parser.parse_args()
        init_settings(args)
        assert settings.debug == False

# Generated at 2022-06-23 22:19:51.211121
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug

# Generated at 2022-06-23 22:19:53.817234
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-23 22:19:57.552476
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True


if __name__ == "__main__":

    import pytest
    pytest.main(['-s', '-v'])

# Generated at 2022-06-23 22:19:58.575210
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:19:59.540793
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()



# Generated at 2022-06-23 22:20:09.723394
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=True))
    assert settings.debug == True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Create and manage Azure secure file shares')
    parser.add_argument('--debug', action='store_true', help='Enable debugging messages')
    args = parser.parse_args()
    init_settings(args)

    print('Azure secure file share access management')


# Generated at 2022-06-23 22:20:12.292819
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:20:13.331090
# Unit test for constructor of class Settings
def test_Settings():
    name = Settings()
    assert name.debug == False

# Generated at 2022-06-23 22:20:15.070110
# Unit test for function init_settings
def test_init_settings():
    global settings

    settings = Settings()
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:16.519079
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest
    assert not settingsTest.debug

# Generated at 2022-06-23 22:20:18.434409
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.d

# Generated at 2022-06-23 22:20:19.759282
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:22.249459
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:20:24.578712
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    assert not hasattr(settings, "other")

# Generated at 2022-06-23 22:20:25.387467
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = True
    assert settings.debug == True

# Generated at 2022-06-23 22:20:28.127552
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings()
    assert settings.debug is False
    global settings
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:20:28.909874
# Unit test for constructor of class Settings
def test_Settings():
    Settings()



# Generated at 2022-06-23 22:20:31.484759
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:32.709282
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-23 22:20:35.133777
# Unit test for constructor of class Settings
def test_Settings():
    p = Settings()
    assert p is not None


# Generated at 2022-06-23 22:20:37.010641
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:39.145082
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:20:40.888613
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a.debug == False


# Test init_settings method

# Generated at 2022-06-23 22:20:41.800168
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:44.934692
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-23 22:20:47.138132
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    assert settings.debug is not False

# Generated at 2022-06-23 22:20:48.901790
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False

# Generated at 2022-06-23 22:20:50.789615
# Unit test for constructor of class Settings
def test_Settings():
    """
    Check constructor of Settings class
    """
    assert settings.debug == False



# Generated at 2022-06-23 22:20:52.532373
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug is False



# Generated at 2022-06-23 22:20:53.464658
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:20:56.014280
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace()
    namespace.debug = True
    init_settings(namespace)
    assert settings.debug == True

# Generated at 2022-06-23 22:20:57.846454
# Unit test for constructor of class Settings
def test_Settings():
    print('test_Settings')
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:21:02.894533
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    assert not settings.debug
    init_settings(args)
    assert not settings.debug

    args = Namespace(debug=True)
    assert not settings.debug
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:05.061636
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-23 22:21:06.417572
# Unit test for constructor of class Settings
def test_Settings():
    sett = Settings()
    assert sett.debug == False



# Generated at 2022-06-23 22:21:06.926697
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False




# Generated at 2022-06-23 22:21:08.235970
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert not test_settings.debug


# Generated at 2022-06-23 22:21:09.584122
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:21:11.589927
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings()
    assert settings_.debug is False



# Generated at 2022-06-23 22:21:13.323287
# Unit test for constructor of class Settings
def test_Settings():
    settings_object = Settings()
    assert settings_object.debug == False


# Generated at 2022-06-23 22:21:15.925347
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-23 22:21:16.667838
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:21:17.448976
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:21:23.642386
# Unit test for function init_settings
def test_init_settings():
    from argparse import ArgumentParser
    parser = ArgumentParser(description="Test settings")
    parser.add_argument("-d", "--debug", dest="debug", action="store_true")
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False

    args = parser.parse_args(["-d"])
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:21:26.052246
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True) # type: ignore
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:21:27.063507
# Unit test for constructor of class Settings
def test_Settings():
    settingsForTest = Settings()
    assert settingsForTest.debug == False


# Generated at 2022-06-23 22:21:28.116855
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:30.889153
# Unit test for function init_settings
def test_init_settings():
    # Normal
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    # Exception
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:21:32.236888
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug is False


# Generated at 2022-06-23 22:21:33.274477
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings()
    assert settings_test.debug == False

# Generated at 2022-06-23 22:21:34.891020
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert not settings.debug
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:37.323948
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:21:39.318082
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-23 22:21:40.691663
# Unit test for constructor of class Settings
def test_Settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:21:43.641210
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:21:45.161328
# Unit test for constructor of class Settings
def test_Settings():
    try:
        Settings()
        assert True
    except Exception: 
        assert False



# Generated at 2022-06-23 22:21:46.492303
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:21:48.911790
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug
    settings.debug = True
    assert settings.debug
    settings.debug = False
    assert not settings.debug


# Generated at 2022-06-23 22:21:56.219266
# Unit test for function init_settings
def test_init_settings():
    # Make sure empty dict does not throw
    init_settings(argparse.Namespace())
    assert settings.debug == False

    # Make sure setting valid arguments works
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

if __name__ == "__main__":
    # unit tests
    init_settings(argparse.Namespace())
    settings.debug = True
    assert settings.debug

    print("All tests passed")

# Generated at 2022-06-23 22:21:58.528758
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:21:59.378016
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:00.756214
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) == Settings
    assert settings.debug == False


# Generated at 2022-06-23 22:22:03.431780
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:05.934232
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:22:06.629443
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Generated at 2022-06-23 22:22:08.044410
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:11.114222
# Unit test for constructor of class Settings
def test_Settings():
    from tempfile import TemporaryDirectory
    from os import path
    with TemporaryDirectory() as tmpdirname:
        settings.debug = True
        assert settings.debug == True

        settings.debug = False
        assert settings.debug == False


# Generated at 2022-06-23 22:22:14.135110
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

    settings.debug = False
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:15.272734
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings()
    assert settings1.debug == False



# Generated at 2022-06-23 22:22:15.896528
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings() != None



# Generated at 2022-06-23 22:22:17.474618
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:19.643462
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:22:20.686814
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    # Testing for default value
    assert settings.debug == False

# Generated at 2022-06-23 22:22:21.943869
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:22:27.320826
# Unit test for function init_settings
def test_init_settings():
    import argparse
    args = argparse.Namespace(debug=False)
    init_settings(args)
    assert not settings.debug
    args = argparse.Namespace(debug=True)
    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:22:28.793039
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:34.069095
# Unit test for function init_settings
def test_init_settings():

    args = Namespace(debug="True")
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug="False")
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug="Ture")
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:22:35.873983
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug == False


# Generated at 2022-06-23 22:22:36.570743
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-23 22:22:39.540194
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:22:44.561312
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    print('settings.debug: ', settings.debug)
    init_settings(Namespace(debug=True))
    print('settings.debug: ', settings.debug)
    init_settings(Namespace(debug=False))
    print('settings.debug: ', settings.debug)


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-23 22:22:46.297760
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:22:47.212300
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:22:47.767660
# Unit test for constructor of class Settings
def test_Settings():
    Settings()

# Generated at 2022-06-23 22:22:49.726246
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:22:52.259224
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    ini

# Generated at 2022-06-23 22:22:54.864604
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-23 22:22:56.860042
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-23 22:22:59.198399
# Unit test for function init_settings
def test_init_settings():
    for debug in [True, False]:
        args = Namespace(debug=debug)
        init_settings(args)
        assert settings.debug == debug



# Generated at 2022-06-23 22:23:03.739153
# Unit test for function init_settings
def test_init_settings():
    testArgs = Namespace(debug=True)
    init_settings(testArgs)
    assert settings.debug == True
    testArgs.debug = False
    init_settings(testArgs)
    assert not settings.debug


init_settings = init_settings
test_init_settings = test_init_settings

# Generated at 2022-06-23 22:23:05.550267
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:08.300427
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:23:09.700400
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug='True'))
    assert settings.debug

# Generated at 2022-06-23 22:23:11.117263
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:23:13.312289
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-23 22:23:16.099241
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-23 22:23:17.559584
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False


# Unit tests for init_settings()

# Generated at 2022-06-23 22:23:20.898825
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

    args = Namespace(debug=False)
    init_settings(args)
    assert not settings.debug

    args = Namespace()
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-23 22:23:22.345447
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:24.201242
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:24.963546
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    return None

# Test for init_settings

# Generated at 2022-06-23 22:23:28.277032
# Unit test for constructor of class Settings
def test_Settings():
    # Вернулось ли значение по умолчанию - False
    s = Settings()
    assert s.debug is False
    # Тест возвращает ожидаемое значение - True
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-23 22:23:31.473848
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-23 22:23:35.397403
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == '__main__':
    pytest.main(['-qq', '-x', '-s', __file__])

# Generated at 2022-06-23 22:23:40.246686
# Unit test for function init_settings
def test_init_settings():
    args = parser.parse_args(['--debug', 'true'])
    init_settings(args)
    assert settings.debug == True


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', default=False)

    args = parser.parse_args()

    init_settings(args)

# Generated at 2022-06-23 22:23:41.102266
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:23:42.896653
# Unit test for function init_settings
def test_init_settings():
    data = {"debug":True}
    args = Namespace(**data)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:23:44.368503
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:23:45.519933
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False, "Constructor failed"


# Generated at 2022-06-23 22:23:46.677742
# Unit test for constructor of class Settings
def test_Settings():
    assert_raises(TypeError, Settings, True)



# Generated at 2022-06-23 22:23:48.465741
# Unit test for constructor of class Settings
def test_Settings():
    settingsTest = Settings()
    assert settingsTest.debug is False

# Generated at 2022-06-23 22:23:50.427132
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    assert not settings.debug

# Generated at 2022-06-23 22:23:51.683775
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False


# Generated at 2022-06-23 22:23:53.278203
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert type(a) is Settings
    assert a.debug is False


# Generated at 2022-06-23 22:23:55.732713
# Unit test for function init_settings
def test_init_settings():
    mock_args = Namespace()
    mock_args.debug = True
    init_settings(mock_args)
    assert settings.debug

# Generated at 2022-06-23 22:23:57.247617
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug



# Generated at 2022-06-23 22:24:00.478972
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-23 22:24:01.329950
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-23 22:24:02.840374
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert not s.debug


# Generated at 2022-06-23 22:24:04.777399
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:24:06.807292
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:24:08.295788
# Unit test for constructor of class Settings
def test_Settings():
    settings.debug = False
    assert False == settings.debug



# Generated at 2022-06-23 22:24:11.371229
# Unit test for constructor of class Settings
def test_Settings():
    print("Unit test of class Settings")
    print()

    test = Settings()
    assert not test.debug
    test.debug = True
    assert test.debug

    print("Pass test")
    print()

# Generated at 2022-06-23 22:24:13.187510
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:14.894392
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-23 22:24:20.446124
# Unit test for function init_settings
def test_init_settings():
    print("test_init_settings:", end=" ")
    args = Namespace()
    args.debug= False
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    print("passed")

# End of unit test


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Extract information from the comment.')
    parser.add_argument('--debug', action='store_true',
                        help='display information for debugging')
    args = parser.parse_args()
    init_settings(args)
    test_init_settings()

# Generated at 2022-06-23 22:24:21.916227
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-23 22:24:24.369750
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings is not None


# Generated at 2022-06-23 22:24:25.730935
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:27.672250
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:29.128770
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.debug



# Generated at 2022-06-23 22:24:30.865820
# Unit test for function init_settings
def test_init_settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-23 22:24:33.443770
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-23 22:24:36.153767
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:37.901169
# Unit test for constructor of class Settings
def test_Settings():
    with pytest.raises(TypeError):
        Settings.__init__()



# Generated at 2022-06-23 22:24:39.586075
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:24:41.341578
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-23 22:24:43.392824
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert not settings.debug


# Generated at 2022-06-23 22:24:46.703191
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    success = settings.debug
    settings.debug = False

    assert success


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:24:50.121436
# Unit test for function init_settings
def test_init_settings():
    # check if settings are being changed to the values of the namespace
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:51.927742
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:55.018502
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:24:59.153070
# Unit test for function init_settings
def test_init_settings():
    arg1 = Namespace(debug=True)
    arg2 = Namespace(debug=False)
    init_settings(arg1)
    init_settings(arg2)
    assert settings.debug == True
    assert settings.debug == False

# Generated at 2022-06-23 22:25:01.774327
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.de

# Generated at 2022-06-23 22:25:02.746270
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.debug == False

# Generated at 2022-06-23 22:25:04.816497
# Unit test for function init_settings
def test_init_settings():
    args: Namespace = MagicMock(debug = True)
    init_settings(args = args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:05.866801
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:09.217419
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert se

# Generated at 2022-06-23 22:25:12.438586
# Unit test for function init_settings
def test_init_settings():
    argparse.Namespace(debug=True)
    # settings.debug was not set
    assert not settings.debug
    init_settings(argparse.Namespace(debug=True))
    # settings.debug was set to True
    assert settings.debug

# Generated at 2022-06-23 22:25:16.219700
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True
    args.debug = False
    init_settings(args)
    assert settings.debug is False


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-23 22:25:17.380918
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings.debug == False

# Generated at 2022-06-23 22:25:19.478143
# Unit test for function init_settings
def test_init_settings():
    init_settings(True)
    assert settings.debug == True
    init_settings(False)
    assert settings.debug == False

# Generated at 2022-06-23 22:25:20.591502
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

#Unit test for function init_settings

# Generated at 2022-06-23 22:25:21.402406
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.debug is False

# Generated at 2022-06-23 22:25:22.670035
# Unit test for constructor of class Settings
def test_Settings():
    settings
    assert settings.debug == False



# Generated at 2022-06-23 22:25:23.333907
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.debug == False

# Generated at 2022-06-23 22:25:25.013820
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-23 22:25:29.815366
# Unit test for function init_settings
def test_init_settings():
    arg_list = []
    arg_list.append(argparse.Namespace(debug=False))
    arg_list.append(argparse.Namespace(debug=True))
    arg_list.append(argparse.Namespace(debug=None))
    for args in arg_list:
        init_settings(args)
        assert ((not args.debug) or settings.debug)

    print('All tests passed\n')
    # end unit test for function init_settings
