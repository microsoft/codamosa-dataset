

# Generated at 2022-06-25 21:45:44.873293
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-25 21:45:46.337697
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-25 21:45:51.485945
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert not settings.debug
    args_1 = Namespace()
    args_1.debug = True
    init_settings(args_1)
    assert settings.debug

# Generated at 2022-06-25 21:45:53.133855
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:45:56.078818
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    assert settings.debug == settings_1.debug

#test_case_0()

test_init_settings()

# Generated at 2022-06-25 21:45:58.511788
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    args = Namespace(debug=True)
    # Call function init_settings
    init_settings(args)
    assert settings_0.debug == True

# Generated at 2022-06-25 21:46:00.786275
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:03.522757
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    init_settings(Namespace(debug=False))
    assert settings_0.debug == settings.debug



# Generated at 2022-06-25 21:46:08.566167
# Unit test for function init_settings
def test_init_settings():
    # Test with debug flag on
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    # Test with debug flag off
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    # Reset settings to default values
    settings.debug = False

# Generated at 2022-06-25 21:46:11.046907
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)
    settings.debug = settings_0.debug

    assert settings.debug == True

# Generated at 2022-06-25 21:46:16.012082
# Unit test for function init_settings
def test_init_settings():
    test_init_settings_args = Namespace(debug=True)
    settings_0 = settings
    test_init_settings(test_init_settings_args)
    assert settings.debug == True
    assert settings_0 == settings

# Generated at 2022-06-25 21:46:17.808695
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug is True

# Generated at 2022-06-25 21:46:20.862962
# Unit test for function init_settings
def test_init_settings():
    class FakeArgparseNamespace(object):
        def __init__(self, debug=False):
            self.debug = debug
    required = "Required attribute 'debug' missing from Settings"
    args = FakeArgparseNamespace(debug=True)
    init_settings(args)
    assert settings.debug, required

test_case_0()
test_init_settings()

# Generated at 2022-06-25 21:46:22.082439
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.init_settings()


# Generated at 2022-06-25 21:46:25.405763
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    assert settings_0.debug == False

    args = parse_args(['--debug'])
    init_settings(args)

    assert settings_0.debug == True

# Generated at 2022-06-25 21:46:28.345868
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    settings_0.debug = True
    init_settings(Namespace(debug=True))
    assert settings.debug == settings_0.debug


# Generated at 2022-06-25 21:46:29.998184
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:34.160012
# Unit test for function init_settings
def test_init_settings():
    cli_args = Namespace()
    init_settings(cli_args)
    assert settings.debug is False
    cli_args.debug = True
    init_settings(cli_args)
    assert settings.debug is True



# Generated at 2022-06-25 21:46:38.427890
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    parser_0 = ArgumentParser()
    parser_0.add_argument('--debug', dest='debug', action='store_true',help="debug mode")
    args = parser_0.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:46:40.895969
# Unit test for function init_settings
def test_init_settings():
    args_0 = ['--debug']
    settings_0 = Settings()
    settings_0.debug = True
    args_0 = argparse.Namespace(debug=True)

    assert settings_0.debug == init_settings(args_0)

# Generated at 2022-06-25 21:46:49.292009
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


test_case_0()
test_init_settings()
print("Everything passed")

# Generated at 2022-06-25 21:46:51.917561
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug

# Generated at 2022-06-25 21:46:58.910806
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    m_0_0 = settings.debug
    test_0_0 = True
    assert m_0_0 == test_0_0
    
    
    
    args_1 = Namespace(debug=False)
    init_settings(args_1)
    m_1_0 = settings.debug
    test_1_0 = False
    assert m_1_0 == test_1_0
    
    
    

# Generated at 2022-06-25 21:47:05.143299
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    arg_dict = {'debug': False}
    for key, val in arg_dict.items():
        setattr(args, key, val)
    init_settings(args)
    assert settings.debug == False
    args = Namespace()
    arg_dict = {'debug': True}
    for key, val in arg_dict.items():
        setattr(args, key, val)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-25 21:47:07.768429
# Unit test for function init_settings
def test_init_settings():
    # args = Namespace()
    # args.debug = False
    # init_settings(args)
    # assert settings.debug == False
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-25 21:47:13.112114
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings_0.debug == False
    init_settings(args_0)
    assert settings_0.debug == False



# Generated at 2022-06-25 21:47:21.838371
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0_debug = settings_0.debug
    args = Namespace(debug=False)
    init_settings(args)
    settings_1 = Settings()
    settings_1_debug = settings_1.debug
    assert settings_0 == settings_1
    args = Namespace(debug=True)
    init_settings(args)
    settings_2 = Settings()
    settings_2_debug = settings_2.debug
    assert settings_0 != settings_2
    assert settings_1 != settings_2
    assert settings_2.debug
    assert settings_0_debug == False
    assert settings_1_debug == False
    assert settings_2_debug == True


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 21:47:25.478198
# Unit test for function init_settings
def test_init_settings():
    print('Testing init_settings')

    settings_0 = Settings()
    test_init_settings_0 = Namespace()
    test_init_settings_0.debug = False
    init_settings(test_init_settings_0)
    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:47:27.027551
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug is True

# Generated at 2022-06-25 21:47:35.757877
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings_0.debug == True


# Generated at 2022-06-25 21:47:47.677072
# Unit test for function init_settings
def test_init_settings():
    # Test case 0: no args
    init_settings(Namespace())
    assert not (settings.debug)
    test_case_0()
    # Test case 1: debug flag
    init_settings(Namespace(debug=True))
    assert settings.debug
    test_case_0()

# Generated at 2022-06-25 21:47:52.657847
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


test_case_0()
test_init_settings()

# Generated at 2022-06-25 21:47:54.964787
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    init_settings(Namespace(debug=False))
    assert settings.debug == settings_1.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-25 21:47:57.520225
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:00.091582
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-25 21:48:04.199113
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:07.036988
# Unit test for function init_settings
def test_init_settings():
    class Namespace:
        def __init__(self, **kwargs) -> None:
            self.__dict__.update(kwargs)
    
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    

# Generated at 2022-06-25 21:48:16.747576
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    init_settings(Namespace(debug=True))
    # Assert statement to verify that members of settings are identical to members of settings_1
    try:
        assert (settings.debug == settings_1.debug)
    except AssertionError:
        print("ERROR: settings.debug != settings_1.debug")
    else:
        print("Verified: settings.debug == settings_1.debug")
    try:
        assert (settings.debug == True)
    except AssertionError:
        print("ERROR: settings.debug != True")
    else:
        print("Verified: settings.debug == True")
    try:
        assert (settings.debug == True)
    except AssertionError:
        print("ERROR: settings.debug != True")
   

# Generated at 2022-06-25 21:48:18.107635
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:48:21.886235
# Unit test for function init_settings
def test_init_settings():
    
    parsed_args = Namespace()

    # Test that an empty Namespace results in defaults being used
    init_settings(parsed_args)
    assert settings.debug == False

    # Test that debug=True results in debug being enabled
    parsed_args.debug = True
    init_settings(parsed_args)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:44.708359
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    args1 = Namespace(debug= True)
    init_settings(args1)
    assert(settings.debug == True)
    settings_0.debug = False
    args2 = Namespace(debug= False)
    init_settings(args2)
    assert(settings.debug == False)


# Generated at 2022-06-25 21:48:49.165359
# Unit test for function init_settings
def test_init_settings():

    # Save initial settings
    settings_initial = copy.deepcopy(settings)

    # Setup args
    args = Namespace()
    args.debug = True

    # Call init_settings
    init_settings(args)

    # Verify initial settings have been restored
    assert settings_initial == settings

    # Verify settings.debug
    assert settings.debug is True



# Generated at 2022-06-25 21:48:50.874814
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    assert settings_1.debug == True


# Generated at 2022-06-25 21:48:54.126023
# Unit test for function init_settings
def test_init_settings():
    args_0 = argparse.Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug is True

# Generated at 2022-06-25 21:48:55.638352
# Unit test for function init_settings
def test_init_settings():
    args = Namespace
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:59.971169
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true")
    args = parser.parse_args("-d".split())
    init_settings(args)
    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:49:02.537259
# Unit test for function init_settings
def test_init_settings():
    refresh_settings = Settings()
    refresh_settings.debug = True
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == refresh_settings.debug

# Generated at 2022-06-25 21:49:05.136026
# Unit test for function init_settings
def test_init_settings():
    # Create the argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument("-d", "--debug", action="store_true", help="set the debug level")
    args = parser.parse_args()

    init_settings(parser)


# Generated at 2022-06-25 21:49:08.522542
# Unit test for function init_settings
def test_init_settings():
    # Case 0
    settings_0 = Settings()
    init_settings(Namespace(debug=True))
    assert settings_0.debug == True
    # Case 1
    settings_1 = Settings()
    init_settings(Namespace(debug=False))
    assert settings_1.debug == False

# Generated at 2022-06-25 21:49:11.855795
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert(settings.debug == False)

    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug == True)

# Generated at 2022-06-25 21:49:53.525032
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', help = 'Debug mode', action = 'store_true')
    args = parser.parse_args()

    init_settings(args)

    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:49:57.038950
# Unit test for function init_settings
def test_init_settings():
    args = parse_args(['--debug'])
    test_case_0()
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:50:02.530332
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_1.debug = True
    args = Namespace(debug=True)
    init_settings(args)

    assert settings_0 != settings_1
    assert settings != settings_0



# Generated at 2022-06-25 21:50:06.388778
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings_0.debug == True


# Generated at 2022-06-25 21:50:09.377919
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug is True


# Generated at 2022-06-25 21:50:10.067878
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False


# Generated at 2022-06-25 21:50:15.086287
# Unit test for function init_settings
def test_init_settings():

    # Build ArgParse to parse any passed arguements
    parser = argparse.ArgumentParser('Test LSP')
    parser.add_argument("-d", "--debug", action="store_true",
                        help="Activates debug mode")

    # Capture arguements
    args = parser.parse_args()

    # Add settings for unit test
    args.debug = True

    # Call the function
    init_settings(args)

    # Test that the function set the settings correctly
    assert settings.debug == True



# Generated at 2022-06-25 21:50:16.553969
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)

    assert settings.debug == True


# Generated at 2022-06-25 21:50:18.389147
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    settings_0.debug = False

    args = Namespace(debug=True)
    init_settings(args)

    assert settings_0.debug == True



# Generated at 2022-06-25 21:50:21.554947
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert settings.debug == False



# Generated at 2022-06-25 21:51:03.337139
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:51:05.337227
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:51:09.339047
# Unit test for function init_settings
def test_init_settings():
    namespace_0 = Namespace()
    namespace_0.debug = False
    init_settings(namespace_0)
if __name__ == '__main__':
    test_case_0()
    test_init_settings()
    print("Test completed")

# Generated at 2022-06-25 21:51:12.542447
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:51:13.794687
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:51:15.944987
# Unit test for function init_settings
def test_init_settings():
    module_0 = reload(module_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

test_init_settings()

# Generated at 2022-06-25 21:51:16.405567
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    return True

# Generated at 2022-06-25 21:51:16.930946
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


# Generated at 2022-06-25 21:51:17.484380
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:51:19.441918
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False
    dict_0 = {}
    dict_0['debug'] = True
    namespace_0 = module_0.Namespace(**dict_0)
    init_settings(namespace_0)
    assert settings.debug == True


# Generated at 2022-06-25 21:52:46.736352
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:52:47.762960
# Unit test for function init_settings
def test_init_settings():
    # Undefined test
    test_case_0()


# Generated at 2022-06-25 21:52:48.405091
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:52:49.478856
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:52:51.167755
# Unit test for function init_settings
def test_init_settings():
    dict_0 = {}
    namespace_0 = module_0.Namespace(**dict_0)
    init_settings(namespace_0)



# Generated at 2022-06-25 21:52:51.994524
# Unit test for function init_settings
def test_init_settings():
    return

# Option parser for this class

# Generated at 2022-06-25 21:52:54.750622
# Unit test for function init_settings
def test_init_settings():
    if settings.debug:
        print("Testing function init_settings...")
    test_case_0()
    if settings.debug:
        print("Testing complete.")


# Generated at 2022-06-25 21:52:56.621978
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == "__main__":
    import sys
    import json
    print("Hello")

    test_init_settings()

# Generated at 2022-06-25 21:52:58.024061
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:52:59.143225
# Unit test for function init_settings
def test_init_settings():
    test_case_0()