

# Generated at 2022-06-25 21:45:45.590237
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    test_case_0()

# Generated at 2022-06-25 21:45:47.147474
# Unit test for function init_settings
def test_init_settings():
    # arrange
    args = Namespace(debug=True)

    # act
    init_settings(args)

    # assert
    assert settings.debu

# Generated at 2022-06-25 21:45:56.622639
# Unit test for function init_settings
def test_init_settings():
    def test_case_0():
        args_0 = Namespace(debug=False)
        init_settings(args_0)
        assert(settings.debug == False)

    def test_case_1():
        args_1 = Namespace(debug=True)
        init_settings(args_1)
        assert(settings.debug == True)

    def test_case_2():
        args_2 = Namespace(debug=True)
        init_settings(args_2)
        assert(settings.debug == True)

    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 21:45:58.077978
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

test_init_settings()

# Generated at 2022-06-25 21:46:00.402729
# Unit test for function init_settings
def test_init_settings():
    class Args:
        pass
    args = Args()
    args.debug = True
    init_settings(args)
    assert settings.debug

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 21:46:03.639929
# Unit test for function init_settings
def test_init_settings():
    init_settings(argparse.Namespace(debug=False))
    assert not settings.debug

    init_settings(argparse.Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-25 21:46:07.016511
# Unit test for function init_settings
def test_init_settings():
    parser = create_parser()
    args = parser.parse_args(['-d'])
    init_settings(args)

    actual = settings.debug
    expected = True

    assert actual == expected


# Generated at 2022-06-25 21:46:08.887701
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug



# Generated at 2022-06-25 21:46:14.212158
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    settings_2 = Settings()
    init_settings(Namespace(debug=True))
    assert settings.debug == settings_1.debug
    assert settings.debug != settings_2.debug

    init_settings(Namespace(debug=False))
    assert settings.debug == settings_2.debug
    assert settings.debug != settings_1.debug

# Generated at 2022-06-25 21:46:17.384762
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = 0
    init_settings(args_0)
    assert settings.debug == False
    args_1 = Namespace()
    args_1.debug = 1
    init_settings(args_1)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:21.972952
# Unit test for function init_settings
def test_init_settings():
    settings_dict = vars(settings)
    for key, item in settings_dict.items():
        assert item == False
        settings_dict[key] = True
    assert settings.debug == True



# Generated at 2022-06-25 21:46:24.476524
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:27.347348
# Unit test for function init_settings
def test_init_settings():

    arg_0 = {'debug': True}
    arg_0 = Namespace(**arg_0)

    test_case_0()
    init_settings(arg_0)

    assert settings.debug == True

# Generated at 2022-06-25 21:46:30.782851
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings_0 == settings


# Generated at 2022-06-25 21:46:36.813244
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    assert args.debug == True, "Error in args.debug"
    init_settings(args)
    assert settings.debug == True, "Error in settings.debug"


if __name__ == '__main__':
    print('Testing')
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True, "Error in settings.debug"
    print('Passed!')

# Generated at 2022-06-25 21:46:38.272270
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    assert settings_0.debug == False

# Generated at 2022-06-25 21:46:40.764323
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == '__main__':
    init_test_logger()

    # Unit testing
    test_init_settings()

    # Unit testing end
    logging.warning('Test finished')

# Generated at 2022-06-25 21:46:44.540762
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = False

    args_1 = Namespace()
    args_1.debug = False

    init_settings(args_1)
    assert settings_1.__dict__ == settings.__dict__

# Generated at 2022-06-25 21:46:49.471854
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    # Test for positive condition
    init_settings(Namespace(debug=True))
    assert  settings_0.debug == True
    init_settings(Namespace(debug=False))
    assert settings_0.debug == True



# Generated at 2022-06-25 21:46:51.545100
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True