

# Generated at 2022-06-25 21:45:42.510182
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:45:43.553274
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:45:51.632506
# Unit test for function init_settings
def test_init_settings():

    settings.debug = False

    settings_0 = Settings()
    settings_0.debug = False
    arg_0 = Namespace(debug=False)

    settings_1 = Settings()
    settings_1.debug = True
    arg_1 = Namespace(debug=True)

    settings_2 = Settings()
    settings_2.debug = False
    arg_2 = Namespace(debug=False)

    settings_3 = Settings()
    settings_3.debug = True
    arg_3 = Namespace(debug=True)


test_case_0()
test_init_settings()
test_case_0()

# Generated at 2022-06-25 21:45:53.955361
# Unit test for function init_settings
def test_init_settings():
    arg_0 = Namespace()
    arg_0.debug = True
    test_case_0()
    init_settings(arg_0)
    assert settings.debug



# Generated at 2022-06-25 21:45:56.236667
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.init_settings(args)



# Generated at 2022-06-25 21:45:58.634595
# Unit test for function init_settings
def test_init_settings():
    # initialize settings with debug = True
    init_settings(Namespace(debug = True))
    settings.debug = False

    assert settings.debug == False
    assert settings_0.debug == False



# Generated at 2022-06-25 21:46:04.436271
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", help="debug mode", action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug is True



# Generated at 2022-06-25 21:46:08.728296
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:14.687236
# Unit test for function init_settings
def test_init_settings():
    # Setup
    testargs = ["prog"]
    with patch.object(sys, 'argv', testargs):
        args = docopt(__doc__, version="Test")
    # Exercise
    init_settings(args)
    # Verify
    assert settings == settings_0
    # Cleanup - none necessary



# Generated at 2022-06-25 21:46:18.345065
# Unit test for function init_settings
def test_init_settings():
    # test case 1
    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert settings.debug == False

    # test case 2
    args_1 = Namespace()
    args_1.debug = True
    init_settings(args_1)
    assert settings.debug == True



# Generated at 2022-06-25 21:46:24.106539
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True


# Generated at 2022-06-25 21:46:25.480328
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug

# Generated at 2022-06-25 21:46:27.462025
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-25 21:46:32.286431
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)

    init_settings(args_0)

    # test that debug is True
    assert settings.debug == True


if __name__ == "__main__":
    test_init_settings()
    test_case_0()

# Generated at 2022-06-25 21:46:34.827985
# Unit test for function init_settings
def test_init_settings():
    args_mock = Mock(debug=True)
    init_settings(args_mock)
    assert settings.debug == True


settings_1 = Settings()
settings_1.debug = False


# Generated at 2022-06-25 21:46:37.841267
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=False)
    init_settings(args_0)
    assert settings.debug == False

    args_1 = Namespace(debug=True)
    init_settings(args_1)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:41.176136
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    parser_1 = argparse.ArgumentParser(description="Test settings")
    parser_1.add_argument('--debug', action='store_true')
    args = parser_1.parse_args(["--debug"])
    init_settings(args)
    assert settings_1.debug == True



# Generated at 2022-06-25 21:46:43.521146
# Unit test for function init_settings
def test_init_settings():
    # arguments
    args = Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-25 21:46:46.390442
# Unit test for function init_settings
def test_init_settings():
    # Create a fake command line argument
    args = Namespace(debug=True)

    # Init settings
    init_settings(args)

    # Check if settings is properly initiating
    assert settings.debug == True

# Generated at 2022-06-25 21:46:52.099510
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


if __name__ == "__main__":
    # Unit test for function init_settings
    pytest.main(["-v", "test_settings.py::test_init_settings"])

# Generated at 2022-06-25 21:46:57.529778
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug = False)
    init_settings(args_0)

    assert settings.debug == False

    args_1 = Namespace(debug = True)
    init_settings(args_1)

    assert settings.debug == True


# Generated at 2022-06-25 21:47:00.998654
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-25 21:47:05.386522
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)

    # No assert needed here, because any failed asserts will be caught during
    # execution anyway


if __name__ == '__main__':
    print('Running unit tests')
    test_init_settings()
    print('settings.debug is True. This is expected')
    print('settings_0.debug is False. This is expected')
    print('Unit tests completed')

# Generated at 2022-06-25 21:47:11.360284
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', default=False)
    args = parser.parse_args()

    init_settings(args)
    assert settings.debug == args.debug



# Generated at 2022-06-25 21:47:13.052008
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    assert settings_0.debug is False

# Generated at 2022-06-25 21:47:20.990708
# Unit test for function init_settings
def test_init_settings():

    # Test with debug=False
    parser = argparse.ArgumentParser(description="Piggy Bank")
    parser.add_argument('--debug', action="store_true")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True

    # Test with debug=True
    parser = argparse.ArgumentParser(description="Piggy Bank")
    parser.add_argument('--debug', action="store_false")
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == False


# Generated at 2022-06-25 21:47:26.668962
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False

    settings_1 = Settings()
    settings_1.debug = True

    args_0 = Namespace()
    args_0.debug = False

    args_1 = Namespace()
    args_1.debug = True

    init_settings(args_0)
    assert settings.debug == settings_0.debug

    init_settings(args_1)
    assert settings.debug == settings_1.debug

# Generated at 2022-06-25 21:47:34.814389
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:47:40.210641
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Settings for the Telgram bot')
    parser.add_argument("--debug", "-d",
                        help="enable debug mode",
                        action="store_true")

    args = parser.parse_args()

    init_settings(args)
    bot = telebot.TeleBot("TOKEN")


# TeleBot Commands


# Generated at 2022-06-25 21:47:43.556675
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    init_settings(
        Namespace(
            debug=True,
        ),
    )

    assert(settings_1.debug == False)
    assert(settings.debug == True)

# Generated at 2022-06-25 21:47:50.196806
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    init_settings(args_0)


# Generated at 2022-06-25 21:47:53.196769
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args=args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args=args)
    assert settings.debug == False

# Generated at 2022-06-25 21:47:59.858208
# Unit test for function init_settings
def test_init_settings():

    # Test case 1
    settings_1 = Settings()
    settings_1.debug = True
    init_settings(Namespace(debug=True))
    assert settings.debug == settings_1.debug

    # Test case 2
    settings_2 = Settings()
    settings_2.debug = False
    init_settings(Namespace(debug=False))
    assert settings.debug == settings_2.debug

    # Run the test case
    test_case_0()
    test_init_settings()
    print("Success: Test settings.py")


# Global parameters for settings

# Generated at 2022-06-25 21:48:01.952192
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    settings_0 = settings

    init_settings(args)

    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:48:06.928600
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-25 21:48:12.895820
# Unit test for function init_settings
def test_init_settings():
    # Create new settings object (should be empty)
    settings_0 = Settings()

    # Set up a command line argument parser with a known argument
    parser = ArgumentParser(prog="test parser")
    parser.add_argument("--debug", action="store_true")

    # Create known arguments to pass in
    args = parser.parse_args("--debug")

    # Run the init_settings function
    init_settings(args)

    # Check if debug is now set
    assert settings_0.debug is True

# Generated at 2022-06-25 21:48:16.786308
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    settings_0 = Settings()
    settings_0.debug = True
    init_settings(args_0)
    e1 = settings_0.debug
    a1 = settings.debug
    assert e1 == a1

# Generated at 2022-06-25 21:48:19.566561
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="initialize settings")
    parser.add_argument("--debug", action="store_true", help="use debug mode")
    args = parser.parse_args()

    init_settings(args)

    assert settings.debug == args.debug

# Generated at 2022-06-25 21:48:21.631964
# Unit test for function init_settings
def test_init_settings():
    # test case 0
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-25 21:48:23.812942
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert settings.debug == False

# Generated at 2022-06-25 21:48:35.837842
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    test_case_0()

# Generated at 2022-06-25 21:48:42.920487
# Unit test for function init_settings
def test_init_settings():
    parser_0 = argparse.ArgumentParser()
    parser_0.add_argument("-d", "--debug", action="store_true", help="Debug")
    args_0 = parser_0.parse_args([])
    init_settings(args_0)
    assert settings.debug is False, "Failed assertion: settings.debug is False"
    args_1 = parser_0.parse_args(["--debug"])
    init_settings(args_1)
    assert settings.debug is True, "Failed assertion: settings.debug is True"

# Generated at 2022-06-25 21:48:46.300249
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Unit test for main module')
    parser.add_argument('--debug', '-d', action='store_true')
    args = parser.parse_args()
    init_settings(args)
    test_init_settings()

# Generated at 2022-06-25 21:48:52.806515
# Unit test for function init_settings
def test_init_settings():
    # Test settings.debug = False
    init_settings(namespace)
    assert settings.debug == False
    test_case_0()

    print(settings.debug)

    # Test settings.debug = True
    test_case_0()
    namespace.debug = True
    init_settings(namespace)
    assert settings.debug == True


namespace = Namespace(debug=False)
if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:48:53.889603
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:48:58.928608
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == settings_1.debug
    settings_2 = Settings()
    settings_2.debug = False
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == settings_2.debug



# Generated at 2022-06-25 21:49:01.755476
# Unit test for function init_settings
def test_init_settings():

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False
    
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    

# Generated at 2022-06-25 21:49:03.437914
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug = True))
    assert isinstance(settings.debug, bool)
    assert settings.debug == True



# Generated at 2022-06-25 21:49:05.536512
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    arguments_0 = Namespace()
    arguments_0.debug = True
    init_settings(arguments_0)
    assert settings.debug == True

# Generated at 2022-06-25 21:49:06.688564
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 21:49:37.210013
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    args = Namespace(debug=True)
    init_settings(args)
    assert settings_1.debug == settings.debug


# Generated at 2022-06-25 21:49:47.852283
# Unit test for function init_settings
def test_init_settings():
    assert settings_0.debug == False
    args = Namespace(debug = True)
    init_settings(args)
    assert settings_0.debug == True
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-25 21:49:50.513128
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    assert settings_0.debug == False
    settings_0.init_settings(True)
    assert settings_0.debug == True
    print("Test function init_settings")

# Generated at 2022-06-25 21:49:53.984288
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

if __name__ == '__main__':
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 21:49:58.555556
# Unit test for function init_settings
def test_init_settings():
    args0 = Namespace()
    args0.debug = False
    init_settings(args0)
    assert not settings.debug

    args1 = Namespace()
    args1.debug = True
    init_settings(args1)
    assert settings.debug

# Generated at 2022-06-25 21:50:00.239787
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug == True, "function init_settings does not properly set debug state"

# Generated at 2022-06-25 21:50:02.324287
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    argparse.Namespace()
    argparse.Namespace.debug = True



# Generated at 2022-06-25 21:50:07.481614
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert_equals(settings.debug, True)
    settings_0 = Settings()
    args_0.debug = False
    init_settings(args_0)
    assert_equals(settings.debug, False)


# Generated at 2022-06-25 21:50:12.893203
# Unit test for function init_settings
def test_init_settings():
    parser = lambda: None
    parser.add_argument = lambda *args, **kwargs: None
    parser.parse_args = lambda *args, **kwargs: Namespace(debug=True)

    init_settings(parser.parse_args)
    assert settings.debug is True
    settings.debug = False

    parser = lambda: None
    parser.add_argument = lambda *args, **kwargs: None
    parser.parse_args = lambda *args, **kwargs: Namespace(debug=False)

    init_settings(parser.parse_args)
    assert settings.debug is False

# Generated at 2022-06-25 21:50:15.045017
# Unit test for function init_settings
def test_init_settings():
    init_settings(namespace(debug=False))
    assert settings_0.debug == False
    init_settings(namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-25 21:51:04.273084
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))

    assert settings.debug is False

    init_settings(Namespace(debug=True))

    assert settings.debug is True


if __name__ == "__main__":
    pytest.main(["-v", "-s", __file__])
    # pytest.main(["-v", "--log-cli-level=DEBUG", "-s", __file__])

# Generated at 2022-06-25 21:51:06.581285
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert(settings.debug)

    args.debug = False
    init_settings(args)
    assert(not settings.debug)

# Generated at 2022-06-25 21:51:11.324120
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    args_1 = Namespace(debug=False)
    init_settings(args_1)
    assert settings_1.debug == settings.debug
    settings_2 = Settings()
    args_2 = Namespace(debug=True)
    init_settings(args_2)
    assert settings_2.debug == settings.debug

# Generated at 2022-06-25 21:51:14.502208
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == args.debug

    args.debug = True
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-25 21:51:16.544989
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    args.debug = False
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-25 21:51:17.088668
# Unit test for function init_settings
def test_init_settings():
    assert settings_0.debug == False

# Generated at 2022-06-25 21:51:18.241674
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug == True
    settings_0 = Settings()

# Generated at 2022-06-25 21:51:20.643879
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    print("start")
    init_settings(args)
    # Actual assertion code
    assert settings.debug



# Generated at 2022-06-25 21:51:22.457373
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    init_settings(Namespace(debug=False))
    assert not settings_0.debug

    init_settings(Namespace(debug=True))
    assert settings_0.debug

# Generated at 2022-06-25 21:51:27.497218
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    settings_0 = Namespace()
    init_settings(args_0)
    settings_0.debug = settings.debug
    assert settings_0.debug == settings_0.debug
    args_1 = Namespace(debug=False)
    settings_1 = Namespace()
    init_settings(args_1)
    settings_1.debug = settings.debug
    assert settings_1.debug == settings_1.debug


# Generated at 2022-06-25 21:52:18.787590
# Unit test for function init_settings
def test_init_settings():
    # Initialize args
    args = module_0.Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    # Initialize args
    args = module_0.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:52:20.864271
# Unit test for function init_settings
def test_init_settings():
    namespace_0 = module_0.Namespace()
    namespace_0.debug = False
    init_settings(namespace_0)
    assert namespace_0.debug == False



# Generated at 2022-06-25 21:52:21.637044
# Unit test for function init_settings
def test_init_settings():
    # test case 0
    test_case_0()

# Generated at 2022-06-25 21:52:22.376794
# Unit test for function init_settings
def test_init_settings():
    init_settings(None)


# Generated at 2022-06-25 21:52:24.411331
# Unit test for function init_settings
def test_init_settings():
    namespace_0 = module_0.Namespace()
    init_settings(namespace_0)


if __name__ == '__main__':
    test_case_0()
    test_init_settings()

# Generated at 2022-06-25 21:52:28.483663
# Unit test for function init_settings
def test_init_settings():
    init_settings(namespace)
    assert not settings.debug

    args = module_0.Namespace()
    init_settings(args)
    assert not settings.debug

    args = module_0.Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:52:30.215701
# Unit test for function init_settings
def test_init_settings():
    import argparse as module_0
    namespace_0 = module_0.Namespace()
    init_settings(namespace_0)



# Generated at 2022-06-25 21:52:38.235917
# Unit test for function init_settings
def test_init_settings():
    module_0.Namespace.debug = False
    test_case_0()


if __name__ == '__main__':
    module_0.Namespace.debug = False
    test_case_0()

# Generated at 2022-06-25 21:52:41.683571
# Unit test for function init_settings
def test_init_settings():
    args = module_0.Namespace()
    init_settings(args)
    assert settings.debug == False

    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-25 21:52:44.808813
# Unit test for function init_settings
def test_init_settings():
    # Case 1
    args_1 = module_0.Namespace()

    init_settings(args_1)

    # Case 2
    args_2 = module_0.Namespace()
    args_2.debug = True

    init_settings(args_2)


# Generated at 2022-06-25 21:54:32.974207
# Unit test for function init_settings
def test_init_settings():
    namespace_0: module_0.Namespace = module_0.Namespace()
    init_settings(namespace_0)


# Generated at 2022-06-25 21:54:35.221670
# Unit test for function init_settings
def test_init_settings():
    import argparse as module_0
    namespace_0 = module_0.Namespace()
    init_settings(namespace_0)
    # Assert: settings.debug == False


# Generated at 2022-06-25 21:54:36.723514
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


# End of test cases

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:54:37.840951
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


# Generated at 2022-06-25 21:54:40.817564
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    init_settings(module_0.Namespace(**{'debug': True}))
    init_settings(module_0.Namespace())
    init_settings(module_0.Namespace(**{'debug': True}))
    init_settings(module_0.Namespace())


import argparse as module_1


# Generated at 2022-06-25 21:54:46.289998
# Unit test for function init_settings
def test_init_settings():
    # Setup
    module_0.ArgumentParser.parse_args.__dict__.__setitem__('stypy_localization', module_0.ArgumentParser.parse_args.__dict__.__getitem__('stypy_localization') or {})
    module_0.ArgumentParser.parse_args.__dict__.__setitem__('stypy_type_store', module_0.ArgumentParser.parse_args.__dict__.__getitem__('stypy_type_store') or {})
    from argparse import ArgumentParser
    from argparse import Namespace
    namespace_0 = Namespace()
    module_0.ArgumentParser.parse_args.__dict__.__setitem__('stypy_localization', {'debug': 'debug'})
    module_0.ArgumentParser

# Generated at 2022-06-25 21:54:47.390642
# Unit test for function init_settings
def test_init_settings():
    init_settings(module_0.Namespace())
    init_settings(module_0.Namespace(debug=True))

# Generated at 2022-06-25 21:54:50.678713
# Unit test for function init_settings
def test_init_settings():
    # In this example we have a function init_settings where you have to set
    # some global settings from a Namespace object.
    #
    # The test should work even if the implementation changes, for example it
    # should work if you add an additional argument to init_settings.
    #
    # Furthermore it should give good error messages when the test fails.
    test_case_0()

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:54:51.505729
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 21:54:52.549153
# Unit test for function init_settings
def test_init_settings():
    init_settings(module_0.Namespace())
    init_settings(module_0.Namespace(debug=True))
