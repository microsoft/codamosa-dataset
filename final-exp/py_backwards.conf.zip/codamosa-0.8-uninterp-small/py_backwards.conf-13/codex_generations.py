

# Generated at 2022-06-25 21:45:42.281891
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args=args)
    assert settings.debug == True

# Generated at 2022-06-25 21:45:43.527955
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:45:45.311534
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    assert settings_0.debug is False

# Generated at 2022-06-25 21:45:51.833625
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    settings_1 = Settings()
    settings_1.debug = True

    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert settings.debug is False

    args_1 = Namespace()
    args_1.debug = True
    init_settings(args_1)
    assert settings.debug is True



# Generated at 2022-06-25 21:45:56.582891
# Unit test for function init_settings
def test_init_settings():
    args = mock.Mock()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    
    args = mock.Mock()
    args.debug=True
    init_settings(args)
    assert settings.debug == True

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:46:01.023519
# Unit test for function init_settings
def test_init_settings():
    settings2 = Settings()
    settings2.debug = True
    settings_before = Settings()
    settings_before.debug = False
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings2.debug == settings.debug
    assert settings_before.debug != settings.debug

# Generated at 2022-06-25 21:46:03.228436
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:06.695324
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = False
    settings_0 = Settings()
    settings_0.debug = False
    init_settings(args_0)
    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:46:09.537808
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    # Test case where debug = False
    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-25 21:46:12.654459
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)

    init_settings(test_args)
    assert settings.debug == True

    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:15.874788
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:46:17.490178
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    args = Namespace(debug=False)
    init_settings(args)
    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:46:19.563920
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    assert not settings_1.debug

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings_1.debug



# Generated at 2022-06-25 21:46:24.624455
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()

    settings_0.debug = True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings_0.debug == settings_1.debug

    settings_0.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings_0.debug == settings_1.debug

# Generated at 2022-06-25 21:46:27.540293
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug
    args.debug = False
    init_settings(args)
    assert not settings.debug

# Generated at 2022-06-25 21:46:33.673589
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True

    settings_1 = Settings()
    settings_1.debug = False

    # Test debug is False when not specified
    init_settings(Namespace(debug=False))
    assert not settings.debug

    # Test debug is True when specified
    init_settings(Namespace(debug=True))
    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:46:39.600247
# Unit test for function init_settings
def test_init_settings():
    test_case_params = [
        [[]],
    ]

    test_case_expected_results = [
        [None],
    ]
    for test_case_id, (params, expected_results) in enumerate(zip(test_case_params, test_case_expected_results)):
        params = Namespace(*params)
        init_settings(*params)
        test_case_id += 1
        print(f"Test Case {test_case_id}")
        assert settings == expected_results[0]



# Generated at 2022-06-25 21:46:42.945650
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_1.debug = True
    init_settings(Namespace(debug=True))
    assert settings.debug != settings_0.debug
    assert settings.debug == settings_1.debug


if __name__ == '__main__':
    # A way to get the settings accessible in other modules

    # Testing
    import pytest
    pytest.main(['--capture=sys'])

# Generated at 2022-06-25 21:46:47.099845
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser(description="Test for method init_settings")

    args = parser.parse_args([])
    init_settings(args)
    assert settings.debug == False
 
    args = parser.parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:50.499821
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False



# Generated at 2022-06-25 21:46:56.064619
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-25 21:47:01.950505
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False
    settings_0 = settings
    init_settings(Namespace(debug=True))
    assert settings.debug is True
    assert settings_0 is settings

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_init_settings()

# Generated at 2022-06-25 21:47:03.722006
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace(debug=True)
    init_settings(namespace)
    assert settings.debug
    test_case_0()



# Generated at 2022-06-25 21:47:06.841880
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug',
                        default=False,
                        type=bool,
                        help='Run in debug mode?')
    args = parser.parse_args()
    init_settings(args)
    assert settings_0.debug != settings.debug



# Generated at 2022-06-25 21:47:12.020975
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


test_init_settings()

# Generated at 2022-06-25 21:47:17.405561
# Unit test for function init_settings
def test_init_settings():
    # Test 0
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True

    # Test 1
    settings_1 = Settings()

    args = Namespace(debug = False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-25 21:47:22.539072
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=False)
    init_settings(args_0)
    assert settings.debug == False

    args_1 = Namespace(debug=True)
    init_settings(args_1)
    assert settings.debug == True



# Generated at 2022-06-25 21:47:25.865860
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True

    args_1 = Namespace()
    args_1.debug = True

    init_settings(args_1)
    assert settings_1.debug == settings.debug


# Generated at 2022-06-25 21:47:27.886842
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-25 21:47:29.844517
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    init_settings(Namespace(debug=True))
    assert settings_1.debug == settings.debug

# Generated at 2022-06-25 21:47:43.200994
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    settings_1 = Settings()

    args = Namespace(debug=True)

    init_settings(args)

    assert settings.debug == settings_0.debug
    assert settings.debug == settings_1.debug
    assert settings.debug != settings_1.debug

# Generated at 2022-06-25 21:47:47.448035
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_1.debug = True
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action='store_true', help="debug mode")
    args = parser.parse_args()
    init_settings(args)
    assert settings_0.debug == False
    settings_0.debug = True
    assert settings_0.debug == settings_1.debug

# Generated at 2022-06-25 21:47:52.698393
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    init_settings(args_0)
    assert settings.debug == False
    args_0.debug = False
    init_settings(args_0)
    assert settings.debug == False
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug == True
    assert issubclass(Settings, object)
    assert isinstance(test_case_0(), object)
    assert isinstance(test_init_settings(), object)

# Generated at 2022-06-25 21:47:57.984046
# Unit test for function init_settings
def test_init_settings():
    # Create mock args
    args = Namespace()
    # Configure args with debug mode
    args.debug = False
    # Call function using mock args
    init_settings(args)
    # Assert settings is not debug
    assert settings.debug == False
    # Configure args without debug mode
    args.debug = True
    # Call function using mock args
    init_settings(args)
    # Assert settings is debug
    assert settings.debug == True
    # Reset settings back to normal
    settings.debug = False

# Generated at 2022-06-25 21:47:59.857411
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-25 21:48:02.498926
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug='true'))
    assert settings.debug


if __name__ == '__main__':
    # test_init_settings()
    test_case_0()
    print('test_settings.py: all tests passed')

# Generated at 2022-06-25 21:48:06.010375
# Unit test for function init_settings
def test_init_settings():
    # Set the function parameters as follows
    args = Namespace(debug=True)

    # Run the function
    init_settings(args)

    assert settings.debug is True


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 21:48:07.719631
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    assert settings.debug == settings_1.debug



# Generated at 2022-06-25 21:48:09.535543
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug
    settings_0 = Settings()

# Generated at 2022-06-25 21:48:11.034710
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 21:48:35.588205
# Unit test for function init_settings
def test_init_settings():
    argv_0 = ['main', '-d']
    argv_1 = ['main']
    
    # Case 0
    init_settings(argparse.Namespace(debug=False))
    assert not settings.debug
    init_settings(argparse.Namespace(debug=True))
    assert settings.debug
    
    # Case 1
    init_settings(argparse.Namespace(debug=False))
    assert not settings.debug

# Generated at 2022-06-25 21:48:37.049262
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-25 21:48:40.079200
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    init_settings(Namespace(debug=True))
    assert settings_1 == settings

# Generated at 2022-06-25 21:48:41.404414
# Unit test for function init_settings
def test_init_settings():
    # Set up
    args = Namespace()
    args.debug = False
    # Exercise
    init_settings(args)
    # Verify
    assert settings.debug == False

    # Exercise
    Settings.debug = True
    # Verify
    assert settings.debug == True

# Generated at 2022-06-25 21:48:42.259864
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:48:45.575031
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False

    settings = Settings()
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True


# Test for functions in module
# Test for init_settings()

# Generated at 2022-06-25 21:48:49.903321
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    args = Namespace()
    args.debug = False

    init_settings(args)
    assert settings.debug == settings_0.debug

    args.debug = True

    init_settings(args)
    assert settings.debug == args.debug

if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:48:54.957259
# Unit test for function init_settings
def test_init_settings():
    # Create argument namespace as if it were generated by ArgumentParser
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

    # Create argument namespace as if it were generated by ArgumentParser
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-25 21:48:57.381569
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:49:03.083076
# Unit test for function init_settings
def test_init_settings():

    # Test case 0:
    settings_0 = Settings()
    settings_0.debug = True
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug == settings_0.debug

    # Test case 1:
    settings_1 = Settings()
    settings_1.debug = False
    args_1 = Namespace(debug=False)
    init_settings(args_1)
    assert settings.debug == settings_1.debug

# Generated at 2022-06-25 21:49:46.209104
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = False
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings_1.debug == settings.debug
    settings_2 = Settings()
    settings_2.debug = True
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings_2.debug == settings.debug

# Generated at 2022-06-25 21:49:51.369770
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug', action='store_true', help='print debug')
    args = parser.parse_args(['--debug'])
    init_settings(args)
    assert settings.debug is True
    init_settings(parser.parse_args([]))
    assert settings.debug is False

# Generated at 2022-06-25 21:49:52.807039
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:49:54.682736
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    init_settings(Namespace(debug=True))
    assert settings.debug == settings_1.debug



# Generated at 2022-06-25 21:49:59.420505
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False


# Test cases for code coverage.

# Generated at 2022-06-25 21:50:01.703075
# Unit test for function init_settings
def test_init_settings():
    # case 0:
    args_0 = Namespace(debug=False)
    init_settings(args_0)
    assert settings.debug is False

    # case 1:
    args_1 = Namespace(debug=True)
    init_settings(args_1)
    assert settings.debug is True

# Generated at 2022-06-25 21:50:04.268089
# Unit test for function init_settings
def test_init_settings():
    # create the mock argparse namspace
    args = Namespace()
    args.debug = True

    # run the settings initialization
    init_settings(args)

    # check if args.debug was copied to settings.debug
    assert settings.debug is True

# Generated at 2022-06-25 21:50:08.412712
# Unit test for function init_settings
def test_init_settings():
	# Test 1:
	settings_0 = Settings()
	settings_0.debug = False
	init_args = Namespace(debug=True)
	init_settings(init_args)

	assert settings_0.debug == True


# Generated at 2022-06-25 21:50:13.307663
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    assert settings_0.debug is False
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings_0.debug is False
    assert settings.debug is True

if __name__ == "__main__":
    import os
    import sys
    path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(path)
    from py_implementation.utilities import main
    main(__file__)

# Generated at 2022-06-25 21:50:15.746728
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False

# Generated at 2022-06-25 21:51:45.086124
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)

    assert settings.debug == True

    args = Namespace()
    args.debug = False
    init_settings(args)

    assert settings.debug == False



# Generated at 2022-06-25 21:51:47.325283
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:51:49.776224
# Unit test for function init_settings
def test_init_settings():
    

    test_args = Namespace()
    init_settings(test_args)
    assert settings.debug == False
    

    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-25 21:51:51.418114
# Unit test for function init_settings
def test_init_settings():
    assert not settings.debug
    init_settings(Namespace(debug=False))
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-25 21:51:55.240690
# Unit test for function init_settings
def test_init_settings():
    # Case 1
    settings_1 = Settings()
    settings_1.debug = False
    args = Namespace(debug=True)
    init_settings(args)

    assert settings_1.debug is False
    assert settings.debug is True

    # Case 2
    settings_2 = Settings()
    settings_2.debug = True

# Generated at 2022-06-25 21:51:56.908837
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    assert settings_0.debug == False

    assert settings_1.debug == True


# Generated at 2022-06-25 21:52:00.923461
# Unit test for function init_settings
def test_init_settings():
    global settings
    settings = Settings()
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    assert settings == Settings()
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    settings_0 = Settings()
    settings_0.debug = False
    assert settings == Settings()
    test_case_0()
    
    
if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:52:02.431445
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    # args.debug = True
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-25 21:52:03.639814
# Unit test for function init_settings
def test_init_settings():
    init_settings(parse_args([""]))
    assert settings is not settings_0

# Generated at 2022-06-25 21:52:06.616968
# Unit test for function init_settings
def test_init_settings():

    # Check that debug is not activated
    assert not settings.debug

    # Init settings
    init_settings(Namespace(debug=True))
    
    # Check that debug is activated
    assert settings.debug

# Generated at 2022-06-25 21:55:20.468848
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    settings_0 = Settings()
    settings_1 = Settings()
    init_settings(args_0)
    assert settings_0.debug == settings_1.debug


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:55:21.790480
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert not settings.debug
    init_settings(Namespace(debug=True))
    assert settings.debug


# Generated at 2022-06-25 21:55:26.111736
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true', help='Print additional debugging information')
    args = parser.parse_args(['-d'])
    init_settings(args)
    assert settings.debug



# Generated at 2022-06-25 21:55:28.683620
# Unit test for function init_settings
def test_init_settings():
    from unittest import mock

    mock_args = mock.Mock()

    # Default state
    test_case_0()

    # Set debug
    mock_args.debug = True
    init_settings(mock_args)
    assert settings.debug

    # Reset state
    settings_0.__dict__ = settings.__dict__.copy()

# Generated at 2022-06-25 21:55:29.231498
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()


# Generated at 2022-06-25 21:55:30.443551
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    test_case_0()
    assert settings_0.debug == settings.debug



# Generated at 2022-06-25 21:55:31.957068
# Unit test for function init_settings
def test_init_settings():
    expected_settings_0 = Settings()
    expected_settings_0.debug = True
    settings_0 = Settings()
    settings_0.debug = True
    init_settings("--debug")
    assert settings == expected_settings_0

# Generated at 2022-06-25 21:55:32.936399
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings_0.debug


# Generated at 2022-06-25 21:55:34.431253
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:55:36.610860
# Unit test for function init_settings
def test_init_settings():
    test_args0 = Namespace(debug=False)
    test_args1 = Namespace(debug=True)
    init_settings(test_args0)
    assert not settings.debug
    init_settings(test_args1)
    assert settings.debug