

# Generated at 2022-06-25 21:45:42.878581
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug is True


if __name__ == '__main__':
    pass

# Generated at 2022-06-25 21:45:44.501455
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug == True

    init_settings(Namespace(debug=False))
    assert settings.debug == False



# Generated at 2022-06-25 21:45:45.859196
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=False)
    init_settings(args_0)



# Generated at 2022-06-25 21:45:48.062488
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug is False

    init_settings(Namespace(debug=False))
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-25 21:45:51.911378
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug



# Generated at 2022-06-25 21:45:55.662594
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == settings_1.debug


# Generated at 2022-06-25 21:45:58.432311
# Unit test for function init_settings
def test_init_settings():
    # If the function modifies the global settings, we can
    # use the above fixture, settings_0, to check for side effects
    init_settings(Namespace(debug=True))
    assert settings.debug
    assert settings is not settings_0

# Generated at 2022-06-25 21:46:01.468557
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug == True
    args_1 = Namespace()
    args_1.debug = None
    init_settings(args_1)
    assert settings.debug == False

# Generated at 2022-06-25 21:46:03.443809
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args=args)

    assert settings.debug == True

# Generated at 2022-06-25 21:46:06.052274
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    if not settings.debug:
        print('Test failed')
        exit(2)



# Generated at 2022-06-25 21:46:11.047522
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-25 21:46:14.090026
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False

    args_0 = Namespace()
    args_0.debug = False

    init_settings(args_0)

    assert settings.debug == False


# Generated at 2022-06-25 21:46:15.521685
# Unit test for function init_settings
def test_init_settings():
    init_settings(args=Namespace(debug=True))
    assert settings.debug



# Generated at 2022-06-25 21:46:18.274715
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = False)
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug = True)
    assert settings.debug == False
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:19.987334
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True


test_case_0()
test_init_settings()

# Generated at 2022-06-25 21:46:21.677712
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-25 21:46:24.106419
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    

# Generated at 2022-06-25 21:46:25.180476
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug


# Generated at 2022-06-25 21:46:29.167106
# Unit test for function init_settings
def test_init_settings():

    # Testing with argparse.Namespace(attr1=attr1_val, attr2=attr2_val, ...)
    args = Namespace(debug=True)
    init_settings(args)
    # assert ...
    assert settings.debug   #=> True



# Generated at 2022-06-25 21:46:38.077775
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    args = Namespace(debug=True)

    # Act
    init_settings(args)

    # Assert
    assert settings.debug == True

# Generated at 2022-06-25 21:46:44.616265
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-25 21:46:50.238442
# Unit test for function init_settings
def test_init_settings():
    # test empty arg
    args_0 = Namespace()
    init_settings(args_0)
    assert settings_0.debug == False
    # test case 0
    settings_0 = Settings()
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings_0.debug == True


# Generated at 2022-06-25 21:46:52.483305
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)



# Generated at 2022-06-25 21:46:55.656245
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()

    args_0.debug = True

    expected_settings_0 = Settings()
    expected_settings_0.debug = True

    init_settings(args_0)

    assert settings.debug == expected_settings_0.debug

# Generated at 2022-06-25 21:47:05.421462
# Unit test for function init_settings
def test_init_settings():
    # [0] Check that it sets debug to True if args.debug is True

    parser_0 = argparse.ArgumentParser()
    parser_0.add_argument("--debug", help="Display debugger during execution", action="store_true")
    args_0 = parser_0.parse_args(['--debug'])
    
    init_settings(args_0)
    
    assert settings.debug == True, 'Expected settings.debug to be True'
    
    # [1] Check that it sets debug to False if args.debug is False

    parser_1 = argparse.ArgumentParser()
    parser_1.add_argument("--debug", help="Display debugger during execution", action="store_true")
    args_1 = parser_1.parse_args([])
    
    init_settings(args_1)
    


# Generated at 2022-06-25 21:47:07.527763
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-25 21:47:13.183535
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-25 21:47:18.966896
# Unit test for function init_settings
def test_init_settings():
    debug_0 = False
    args_0 = Namespace(debug=debug_0)

    init_settings(args_0)
    assert settings.debug == debug_0

    debug_1 = True
    args_1 = Namespace(debug=debug_1)

    init_settings(args_1)
    assert settings.debug == debug_1


# Generated at 2022-06-25 21:47:21.545649
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:47:23.070972
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    test_case_0()

# Generated at 2022-06-25 21:47:34.523779
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    init_settings(args_0)


# Generated at 2022-06-25 21:47:39.066721
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug = False)
    settings_0 = Settings()
    init_settings(args_0)
    assert (settings_0.debug is settings.debug)
    args_0 = Namespace(debug = True)
    settings_0 = Settings()
    init_settings(args_0)
    assert (settings_0.debug is settings.debug)

# Verification test

# Generated at 2022-06-25 21:47:41.018083
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    init_settings(Namespace(debug=True))
    assert settings.debug == True

# Generated at 2022-06-25 21:47:44.008831
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-25 21:47:45.626549
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-25 21:47:48.289842
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_2 = Settings()

    assert not settings_1.debug

    args = Namespace(debug=True)

    init_settings(args)

    assert settings_1.debug

    assert not settings_2.debug

# Generated at 2022-06-25 21:47:51.399474
# Unit test for function init_settings
def test_init_settings():
    settings_init = Settings()
    settings_init.debug = True
    assert not settings.debug
    ar = Namespace(debug=True, source=None, target=None)
    init_settings(ar)
    assert settings.debug
    assert not settings_init.debug


# Generated at 2022-06-25 21:47:53.836684
# Unit test for function init_settings
def test_init_settings():
    # Init default settings
    init_settings(Namespace())
    assert settings.debug == False

    # Init with args
    init_settings(Namespace(debug = True))
    assert settings.debug == True


# Generated at 2022-06-25 21:47:57.290154
# Unit test for function init_settings
def test_init_settings():
    if settings.debug:
        print('\nTEST: Init settings')

    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug is False

# Generated at 2022-06-25 21:47:59.442752
# Unit test for function init_settings
def test_init_settings():
    
    # Expected result:
    assert settings_0.debug == False


# Generated at 2022-06-25 21:48:11.110636
# Unit test for function init_settings
def test_init_settings():


    test_cases = [
        test_case_0,
    ]

    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 21:48:14.481536
# Unit test for function init_settings
def test_init_settings():
    namespace_1 = Namespace()
    init_settings(namespace_1)
    assert type(settings) == Settings
    namespace_2 = Namespace(debug = True)
    init_settings(namespace_2)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:16.900182
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    namespace_0 = Namespace(debug=True)
    init_settings(namespace_0)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:17.672255
# Unit test for function init_settings
def test_init_settings():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 21:48:18.992840
# Unit test for function init_settings
def test_init_settings():
    namespace_1 = Namespace(**{"debug": True})
    init_settings(namespace_1)

# Generated at 2022-06-25 21:48:27.483899
# Unit test for function init_settings
def test_init_settings():
    assert settings.debug == False, "Test failed."
    test_case_0()
    assert settings.debug == False, "Test failed."

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process command line arguments.")
    parser.add_argument("-d", "--debug", default=False, dest="debug", action="store_true",
                        help="turn on debug mode.")
    args = parser.parse_args()
    init_settings(args)
    logging.info("FizzBuzz")
    if args.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)
    logging.debug("Start of FizzBuzz")

# Generated at 2022-06-25 21:48:28.951493
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == "__main__":
    test_init_settings()

# Generated at 2022-06-25 21:48:30.245838
# Unit test for function init_settings
def test_init_settings():
    test_case_0()


if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:48:34.288583
# Unit test for function init_settings
def test_init_settings():
    # Success - default
    namespace_1 = Namespace()
    init_settings(namespace_1)
    assert settings.debug == False

    # Success - debug=True
    namespace_2 = Namespace()
    namespace_2.debug = True
    init_settings(namespace_2)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:43.853644
# Unit test for function init_settings
def test_init_settings():
    import random

    namespace_1 = random.randint(0, 10)
    init_settings(namespace_1)

# ----------------------------
# Outputs:
# ----------------------------
# test_case_0()
# ----------------------------
# TypeError: 'int' object is not callable
# ----------------------------

# test_init_settings()
# ----------------------------
# TypeError: 'int' object is not callable
# ----------------------------


# It seems that the "args" argument
#   is not initialized in the init_settings function.
# It is being passed as a random integer in this case.
# The random integer is because of the use of random.randint(0, 10)

# init_settings() function expected an object of type "Namespace" as an argument,
#   but got an integer. That's why the TypeError.