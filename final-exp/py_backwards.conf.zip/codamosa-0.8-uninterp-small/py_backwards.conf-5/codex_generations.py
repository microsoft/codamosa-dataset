

# Generated at 2022-06-25 21:45:40.150538
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug == True


# Generated at 2022-06-25 21:45:41.392736
# Unit test for function init_settings
def test_init_settings():
    print("Running test case 0...")
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-25 21:45:42.434845
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-25 21:45:43.476256
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-25 21:45:46.020304
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_1.debug = True
    expected_result = settings_1

    init_settings(Namespace(debug=True))

    assert settings.debug == expected_result.debug

# Generated at 2022-06-25 21:45:52.057078
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    test_settings = Settings()
    test_parser = argparse.ArgumentParser(description="Description")
    test_parser.parse_args()
    test_args = test_parser.parse_args()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug != test_settings.debug

# Generated at 2022-06-25 21:45:55.754724
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug = True)
    args_1 = Namespace(debug = False)
    init_settings(args_0)
    assert settings.debug == True
    init_settings(args_1)
    assert settings.debug == False

# Generated at 2022-06-25 21:46:00.055494
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    init_settings(Namespace(debug=True))
    assert settings_0.debug == True

    settings_0 = Settings()
    init_settings(Namespace(debug=False))
    assert settings_0.debug == None

    settings_0 = Settings()
    init_settings(Namespace(debug=True))
    assert settings_0.debug == None


# Generated at 2022-06-25 21:46:05.270292
# Unit test for function init_settings
def test_init_settings():
    class TestArgParse:
        def __init__(self, debug: bool) -> None:
            self.debug = debug
    test_args = TestArgParse(True)
    test_case_0()
    init_settings(test_args)
    assert settings_0.debug == False
    assert settings.debug == True

# Generated at 2022-06-25 21:46:07.330947
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:46:13.966591
# Unit test for function init_settings
def test_init_settings():
    test_case_0()
    settings_1 = Settings()
    settings_1.debug = True
    test_args_1 = Namespace(debug=False)
    init_settings(test_args_1)
    assert settings_1.debug == settings.debug
    test_args_2 = Namespace(debug=True)
    init_settings(test_args_2)
    assert settings_1.debug != settings.debug

# Generated at 2022-06-25 21:46:15.666523
# Unit test for function init_settings
def test_init_settings():
    init_settings(argparse.Namespace(debug=True))
    assert settings.debug


if __name__ == '__main__':
    init_settings(argparse.Namespace(debug=True))
    print('debug = {}'.format(settings.debug))
    print('end of test_settings.py')

# Generated at 2022-06-25 21:46:17.032419
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:46:18.309569
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:20.017780
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-25 21:46:23.147664
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    args_1 = Namespace(debug=True)
    init_settings(args_1)
    assert settings_1.debug == settings.debug
    settings_1.debug = False



# Generated at 2022-06-25 21:46:25.255310
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=False)
    init_settings(args_0)
    assert settings.debug == False



# Generated at 2022-06-25 21:46:34.553010
# Unit test for function init_settings
def test_init_settings():
    # Setup
    settings_0 = Settings()
    settings_0.debug = False
    settings_0.out_path = None
    settings_0.in_path = None
    settings_0.input_files = []
    settings_0.word_file = None
    settings_0.word_file_flag = False
    settings_0.start_index = 0
    settings_0.word_file_start_index = 0
    settings_0.zip_name = None
    args_0 = Namespace(debug=False)

    # Invoke
    init_settings(args_0)
    # Verficiation
    assert settings_0.debug == False

# Generated at 2022-06-25 21:46:37.881654
# Unit test for function init_settings
def test_init_settings():

    # test case 1
    args_1 = Namespace(debug=True)
    init_settings(args_1)

    expected_0_1 = True
    assert settings.debug == expected_0_1


test_case_0()
test_init_settings()

# Generated at 2022-06-25 21:46:43.044933
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

    args.debug = False
    init_settings(args)
    assert settings.debug == False
    return None


if __name__ == "__main__":
    # create a new parser object
    parser = ArgumentParser(description="Python module")

    # add optional arguments
    parser.add_argument("-d", "--debug", help="print debugging information",
                        action="store_true")

    # get arguments from command line
    args = parser.parse_args()

    init_settings(args)

    test_init_settings()

# Generated at 2022-06-25 21:46:50.684927
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    assert settings_0.debug == False

    args = Namespace(debug=True)

    settings_1 = Settings()
    settings_1.debug = True
    init_settings(args)
    assert settings_1.debug == True

# Generated at 2022-06-25 21:46:56.104334
# Unit test for function init_settings
def test_init_settings():
        with patch("argparse.Namespace") as argparse_namespace_mock:
            argparse_namespace_mock.return_value = argparse_namespace_mock
            argparse_namespace_mock.debug = False
            init_settings(argparse_namespace_mock)
            assert_is(settings.debug, False)


# Generated at 2022-06-25 21:47:05.814536
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings_0.debug == False
    assert settings.debug == True

if __name__ == '__main__':
    print(settings.debug)
    args = Namespace()
    args.debug = True
    init_settings(args)
    print(args.debug)

# Generated at 2022-06-25 21:47:19.449049
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    test_args.debug = True
    init_settings(test_args)
    assert settings.debug == True

    # Tokenize the string using shlex.split()
    lines = shlex.split('''
            [sec-0]
            key1="val1"
            key2=val2
            key3=val3=junk
            key4=val4
            [sec-1]
            key5="val5"
            key6=val6
            key7=val7=junk
            key8=val8
    ''')
    print(lines)
    # Create empty section in the config
    config = ConfigObj()
    # Create an empty section in the config
    config['sec-0'] = {}
    # Create a section in the config

# Generated at 2022-06-25 21:47:23.370995
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", help="Enable debugging mode", action="store_true")
    args = parser.parse_args()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:47:26.587469
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = False
    args_1 = Namespace()
    args_1.debug = True
    init_settings(args_1)
    assert settings_1.debug == settings.debug

# Generated at 2022-06-25 21:47:34.370088
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_1.debug = True
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:47:37.210954
# Unit test for function init_settings
def test_init_settings():
    # Arrange
    settings_0 = Settings()

    # Act
    init_settings(Namespace(debug=True))

    # Assert
    assert settings_0.debug is False
    assert settings.debug is True



# Generated at 2022-06-25 21:47:39.102617
# Unit test for function init_settings
def test_init_settings():
    # Case 0
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug

# Generated at 2022-06-25 21:47:43.202678
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True

    settings_1 = Settings()
    settings_1.debug = False

    settings_1.debug = True

    settings_0.debug = False
# Output: settings_1.debug modified

    settings_0.debug = True
# Output: settings_0.debug modified



# Generated at 2022-06-25 21:47:54.701446
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

    init_settings(Namespace(debug=False))
    assert not settings.debug


if __name__ == "__main__":
    argparser = argparse.ArgumentParser(description="")
    argparser.add_argument("-d", "--debug", action="store_true", help="enable debug output")
    args = argparser.parse_args()

    init_settings(args)

    print(f"settings.debug = {settings.debug}")

    test_case_0()
    test_init_settings()

# Generated at 2022-06-25 21:47:56.096232
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug


# Generated at 2022-06-25 21:47:58.063185
# Unit test for function init_settings
def test_init_settings():
    args0 = Namespace()
    args0.debug = False

    init_settings(args0)

    assert settings.debug == False



# Generated at 2022-06-25 21:48:00.372443
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:48:04.159589
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert settings.debug == False

    args_1 = Namespace()
    args_1.debug = True
    init_settings(args_1)
    assert settings.debug == True

# Generated at 2022-06-25 21:48:05.803772
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    args = Namespace(debug=False)
    init_settings(args)
    assert settings_0.debug == settings.debug

# Generated at 2022-06-25 21:48:07.179203
# Unit test for function init_settings
def test_init_settings():
    # Case 0: disabled debug
    test_case_0()
    assert settings_0.debug == False

# Generated at 2022-06-25 21:48:08.891425
# Unit test for function init_settings
def test_init_settings():
    namespace = Namespace()
    namespace.debug = True
    init_settings(namespace)
    assert settings.debug == namespace.debug



# Generated at 2022-06-25 21:48:12.694542
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    args = Namespace(debug = True)
    init_settings(args)
    assert settings_0.debug == True
    args = Namespace(debug = False)
    init_settings(args)
    assert settings_0.debug == False

# Generated at 2022-06-25 21:48:15.412422
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace())
    assert settings.debug == False

    init_settings(Namespace(debug=True))
    assert settings.debug == True

    test_case_0()

# Generated at 2022-06-25 21:48:29.797682
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(**{
        'debug': False
    })
    init_settings(args)
    assert settings.debug == args.debug
    args = Namespace(**{
        'debug': True
    })
    init_settings(args)
    assert settings.debug == args.debug

# Generated at 2022-06-25 21:48:30.800732
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-25 21:48:32.080747
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    init_settings(args)
    assert settings.debug == False



# Generated at 2022-06-25 21:48:35.136902
# Unit test for function init_settings
def test_init_settings():
    settings = Settings()
    settings.debug = False
    args = Namespace()
    args.debug = True

    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-25 21:48:35.983690
# Unit test for function init_settings
def test_init_settings():
    test_case_0()

# Generated at 2022-06-25 21:48:37.478346
# Unit test for function init_settings
def test_init_settings():
    init_settings(None)
    print("test_init_settings() PASSED")



# Generated at 2022-06-25 21:48:40.201002
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True

    init_settings(args)

    assert settings.debug == True

# Generated at 2022-06-25 21:48:45.423262
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    assert settings_0.debug == False
    settings_0.debug = True
    assert settings_0.debug == True
    settings_1 = Settings()
    assert settings_1.debug == False
    init_settings(Namespace(debug=True))
    assert settings_1.debug == True
    settings_2 = Settings()
    settings_2.debug = True
    assert settings_2.debug == True
    settings_2.debug = False
    assert settings_2.debug == False



# Generated at 2022-06-25 21:48:54.917812
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=False)
    settings_0 = Settings()
    init_settings(args_0)
    assert settings_0.debug == False

    args_1 = Namespace(debug=True)
    settings_1 = Settings()
    init_settings(args_1)
    assert settings_1.debug == True


if __name__ == '__main__':
    # Run unit tests
    test_init_settings()

    # Parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-debug', action='store_true', help='Turn on debug mode')
    args = parser.parse_args()

    # Set settings based on command line arguments
    init_settings(args)

# Generated at 2022-06-25 21:48:57.343013
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    test_args = Namespace(debug = True)
    init_settings(test_args)
    assert(settings_1.debug == settings.debug)