

# Generated at 2022-06-25 21:45:47.247145
# Unit test for function init_settings
def test_init_settings():
    # test case 1
    init_settings(Namespace(debug=False))
    assert settings.debug == False
    # test case 2
    init_settings(Namespace(debug=True))
    assert settings.debug == True
    init_settings(Namespace(debug=False))
    assert settings.debug == False



# Generated at 2022-06-25 21:45:58.593207
# Unit test for function init_settings
def test_init_settings():
    global settings
    args = Mock()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:02.549860
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings_0.debug




# Generated at 2022-06-25 21:46:07.011428
# Unit test for function init_settings
def test_init_settings():
    args_1 = Namespace()
    args_1.debug = True

    init_settings(args_1)
    assert settings.debug == True

    args_2 = Namespace()
    args_2.debug = False

    init_settings(args_2)
    assert settings.debug == False

# Generated at 2022-06-25 21:46:08.526859
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace(debug=True)
    init_settings(test_args)
    assert settings.debug is True

# Generated at 2022-06-25 21:46:12.858497
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings.debug == False
    assert settings_0.debug == False
    args.debug = True
    init_settings(args)
    assert settings.debug == True
    assert settings_0.debug == False

# Generated at 2022-06-25 21:46:19.497439
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    assert settings_0.debug == False

    args = Namespace()
    args.debug = False
    init_settings(args)
    assert settings_0.debug == False

    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings_0.debug == True


# Code to execute if this file is called directly
if __name__ == '__main__':
    print(f'Starting execution of {__file__}')
    print('Running test cases')
    print('Test case 0')
    test_case_0()
    print('Testing function init_settings')
    test_init_settings()
    print('Done')

# Generated at 2022-06-25 21:46:21.249079
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug is True

    init_settings(Namespace(debug=False))
    assert settings.debug is False

# Generated at 2022-06-25 21:46:25.031108
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=False)
    init_settings(args)
    assert settings.debug == False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-25 21:46:28.982529
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = True
    settings_object_0 = Namespace()
    settings_object_0.debug = True
    init_settings(settings_object_0)
    assert settings == settings_1



# Generated at 2022-06-25 21:46:34.478049
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    init_settings(Namespace(debug=False))
    assert settings_0 == settings
    init_settings(Namespace(debug=True))
    assert settings.debug

# Generated at 2022-06-25 21:46:37.801687
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    argparse.Namespace = argparse.Namespace()
    argparse.Namespace.debug = True
    init_settings(argparse.Namespace)
    assert settings_0.debug == True

# Generated at 2022-06-25 21:46:43.302874
# Unit test for function init_settings
def test_init_settings():
    class Parser:
        def __init__(self) -> None:
            self.debug = False

    parser = Parser()

    test_data = [
        # debug = False
        [parser, False],
        # debug = True
        [parser, True]
    ]
    for [parser, expected_debug] in test_data:
        settings_1 = Settings()
        # Expected result:
        test_init_settings_1 = Settings()
        test_init_settings_1.debug = expected_debug
        # Test method:
        init_settings(parser)
        # Actual result:
        assert settings_1.debug == test_init_settings_1.debug, "Wrong init_settings result."

# Generated at 2022-06-25 21:46:45.362678
# Unit test for function init_settings
def test_init_settings():
    test_settings = Settings()
    init_settings(Namespace(debug = True))
    assert settings.debug == True


# Generated at 2022-06-25 21:46:54.765564
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    settings_1.debug = False
    args_1 = Namespace()
    args_1.debug = False
    init_settings(args_1)
    assert(settings_1.debug == settings.debug)
    settings_2 = Settings()
    settings_2.debug = False
    args_2 = Namespace()
    args_2.debug = True
    init_settings(args_2)
    assert(settings_2.debug == settings.debug)


if __name__ == "__main__":
    test_init_settings()
    print("All Test Cases Passed!")

# Generated at 2022-06-25 21:46:55.922315
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:46:59.066139
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = True
    args = parse_args(["-d"])
    init_settings(args)

    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:47:02.215713
# Unit test for function init_settings
def test_init_settings():
    args = {"debug": True}
    init_settings(args)
    assert settings.debug == True

# Integration test for function init_settings, and class Settings

# Generated at 2022-06-25 21:47:03.974513
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True


# Generated at 2022-06-25 21:47:05.283681
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-25 21:47:14.645199
# Unit test for function init_settings
def test_init_settings():
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action='store_true')
    args = Namespace(debug=True)
    init_settings(args)
    assert settings is not settings_0
    assert settings.debug


parser = argparse.ArgumentParser()
parser.add_argument("--debug", action='store_true')
args = parser.parse_args()
init_settings(args)

# Generated at 2022-06-25 21:47:17.106596
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    test_case_0()
    assert settings.debug == False

# Generated at 2022-06-25 21:47:19.933727
# Unit test for function init_settings
def test_init_settings():
    test_case = Namespace(debug=True)
    init_settings(test_case)
    assert settings.debug == True
    test_case = Namespace(debug=False)
    init_settings(test_case)
    assert settings.debug == False

# Generated at 2022-06-25 21:47:22.344292
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    settings_0 = Settings()
    init_settings(args)
    assert settings_0.debug == False
    assert settings.debug == True

# Generated at 2022-06-25 21:47:26.046566
# Unit test for function init_settings
def test_init_settings():
    test_args_0 = {
        'debug': True,
    }
    test_args_0 = Namespace(**test_args_0)
    settings_0 = Settings()

    init_settings(test_args_0)

    assert settings.debug == settings_0.debug

# Generated at 2022-06-25 21:47:28.030998
# Unit test for function init_settings
def test_init_settings():
    args = parse_args(["--debug"])
    init_settings(args)
    assert settings.debug == True



# Generated at 2022-06-25 21:47:29.702098
# Unit test for function init_settings
def test_init_settings():
    # Nothing else to test here
    init_settings(Namespace(debug=True))
    assert settings.debug == True



# Generated at 2022-06-25 21:47:32.402945
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug

# Generated at 2022-06-25 21:47:37.635996
# Unit test for function init_settings
def test_init_settings():
    test_parser = argparse.ArgumentParser()
    test_parser.add_argument("--debug", help="debug mode", action="store_true")
    test_args = test_parser.parse_args("")
    init_settings(test_args)
    assert settings.debug == False
    test_args = test_parser.parse_args("--debug")
    init_settings(test_args)
    assert settings.debug == True

# Generated at 2022-06-25 21:47:40.621987
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=False)
    assert init_settings(args_0) is None
    assert settings.debug == False

    args_1 = Namespace(debug=True)
    assert init_settings(args_1) is None
    assert settings.debug == True