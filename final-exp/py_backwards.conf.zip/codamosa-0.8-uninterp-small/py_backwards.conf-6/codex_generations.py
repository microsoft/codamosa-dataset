

# Generated at 2022-06-25 21:45:43.978627
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    assert settings_0.debug == False, "settings_0.debug == False"
    settings_0.debug = True
    args_0 = Namespace()
    args_0.debug = True
    init_settings(args_0)
    assert settings_0.debug == True, "settings_0.debug == True"
    return


# Generated at 2022-06-25 21:45:46.824444
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace(debug=True)
    init_settings(args_0)
    assert settings.debug == True
    args_1 = Namespace(debug=False)
    init_settings(args_1)
    assert settings.debug == False


# Generated at 2022-06-25 21:45:50.620330
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    args = Namespace(**{'debug': True})
    init_settings(args)
    assert settings_0.debug == True


# Generated at 2022-06-25 21:45:52.176552
# Unit test for function init_settings
def test_init_settings():
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:45:55.532559
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    args = Namespace(debug = True)
    init_settings(args)
    assert settings.debug == True
    assert settings_1.debug == False


# Generated at 2022-06-25 21:45:57.368826
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True


# Generated at 2022-06-25 21:46:01.831609
# Unit test for function init_settings
def test_init_settings():
    global settings

    settings = Settings()
    init_settings(Namespace(debug=True))

    assert settings.debug is True


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--debug', action='store_true',
                        help=('If true, will print extra debugging output.'))

    args = parser.parse_args()

    init_settings(args)

    sys.exit(0)

# Generated at 2022-06-25 21:46:03.521806
# Unit test for function init_settings
def test_init_settings():
    init_settings(
        Namespace(debug=True)
    )
    assert settings.debug



# Generated at 2022-06-25 21:46:06.695987
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_0.debug = True
    args = Namespace(debug = "")
    init_settings(args)
    assert settings_0.debug == False

# Generated at 2022-06-25 21:46:14.409195
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true", help="Turn on debugging")

    args = parser.parse_args()

    init_settings(args)

    assert settings_0.debug == False
    assert settings.debug == False

    args.debug = True

    init_settings(args)

    assert settings_0.debug == False
    assert settings.debug == True

    print("\n")
    print("SUCCESS")
    print("\n")


if __name__ == "__main__":
    test_init_settings()