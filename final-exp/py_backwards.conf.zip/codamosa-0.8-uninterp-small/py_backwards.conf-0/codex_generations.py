

# Generated at 2022-06-25 21:45:40.150496
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert(settings.debug)



# Generated at 2022-06-25 21:45:42.043281
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = False
    init_settings(args_0)
    assert settings.debug is False
    args_0.debug = True
    init_settings(args_0)
    assert settings.debug is True

# Generated at 2022-06-25 21:45:43.328641
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:45:44.531820
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()

    assert settings is settings_0
    return True



# Generated at 2022-06-25 21:45:45.859104
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug

# Generated at 2022-06-25 21:45:47.764316
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=False))
    assert settings.debug is False

    init_settings(Namespace(debug=True))
    assert settings.debug is True

# Generated at 2022-06-25 21:45:55.208147
# Unit test for function init_settings
def test_init_settings():
    args_0 = None
    args_0 = Namespace()
    args_0.debug = None
    assert(not hasattr(args_0, 'debug'))
    assert(not hasattr(settings, 'debug'))
    init_settings(args_0)
    assert(not hasattr(args_0, 'debug'))
    assert(not hasattr(settings, 'debug'))



# Generated at 2022-06-25 21:45:56.778426
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:45:58.553370
# Unit test for function init_settings
def test_init_settings():
    init_args = Namespace(debug=True)
    init_settings(init_args)

    assert settings.debug  == True



# Generated at 2022-06-25 21:46:01.296073
# Unit test for function init_settings
def test_init_settings():
    sys.argv = ["foo.py", "--debug"]
    settings_from_args = Namespace(debug=True)
    from_args = init_settings(settings_from_args)
    assert settings_from_args.debug == True



# Generated at 2022-06-25 21:46:09.134899
# Unit test for function init_settings
def test_init_settings():
    args = Namespace()
    args.debug = True
    init_settings(args)
    assert settings.debug is True, "settings.debug = {} (expected True)".format(settings.debug)

    # Change to False by calling init_settings with different arguments
    args.debug = False
    init_settings(args)
    assert settings.debug is False, "settings.debug = {} (expected False)".format(settings.debug)

# Generated at 2022-06-25 21:46:11.178082
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug == True

# Generated at 2022-06-25 21:46:13.236241
# Unit test for function init_settings
def test_init_settings():
    settings.debug = False
    args = Namespace(debug=True)
    init_settings(args)
    assert settings.debug is True

# Generated at 2022-06-25 21:46:15.935329
# Unit test for function init_settings
def test_init_settings():
    test_args = Namespace()
    setattr(test_args, 'debug', True)
    init_settings(test_args)
    assert settings.debug == True
    # Ensure settings is unchanged
    test_case_0()


# Generated at 2022-06-25 21:46:17.829845
# Unit test for function init_settings
def test_init_settings():
    expected_debug = False
    assert settings.debug == expected_debug

    init_settings(Namespace(debug=True))

    expected_debug = True
    assert settings.debug == expected_debug

# Generated at 2022-06-25 21:46:20.629882
# Unit test for function init_settings
def test_init_settings():
    settings_1 = Settings()
    args = Namespace(debug=True)
    init_settings(args)
    if settings_1.debug != settings_1.debug == settings.debug:
        raise Exception(
            f'"init_settings" function failed: settings.debug = {settings.debug}, expected output is {settings_1.debug}.'
        )

# Generated at 2022-06-25 21:46:25.292692
# Unit test for function init_settings
def test_init_settings():
    args_0 = Namespace()
    args_0.debug = True

    args_1 = Namespace()
    args_1.debug = False

    test_case_0()
    init_settings(args_0)
    init_settings(args_1)

    assert settings.debug == True
    assert settings_0.debug == False

# Generated at 2022-06-25 21:46:32.179317
# Unit test for function init_settings
def test_init_settings():
    settings_0 = Settings()
    settings_0.debug = False
    settings_1 = Settings()
    settings_1.debug = True

    init_settings(Namespace(debug=False))
    assert settings.debug == settings_0.debug
    init_settings(Namespace(debug=True))
    assert settings.debug == settings_1.debug

if __name__ == '__main__':
    test_init_settings()

# Generated at 2022-06-25 21:46:34.435268
# Unit test for function init_settings
def test_init_settings():
    args = Namespace(debug=True)
    init_settings(args)

    assert settings.debug == True


# Check to make sure our settings object hasn't been modified by init_settings

# Generated at 2022-06-25 21:46:35.572871
# Unit test for function init_settings
def test_init_settings():
    init_settings(Namespace(debug=True))
    assert settings.debug

