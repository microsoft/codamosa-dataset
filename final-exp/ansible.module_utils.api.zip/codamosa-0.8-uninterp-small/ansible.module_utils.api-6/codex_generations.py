

# Generated at 2022-06-24 20:01:50.295510
# Unit test for function rate_limit
def test_rate_limit():
    # Generates a rate-limited function
    @rate_limit(rate=1, rate_limit=1)
    def foo():
        """A rate-limited function"""
        return

    test_case_0()
    return True



# Generated at 2022-06-24 20:01:53.144217
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Create a function that returns same sequence every time
    def generate():
        return (1, 2, 3)
    # Call the functions you want to test
    test_case_0()
    # Assert
    assert generate() == (1, 2, 3)

# Generated at 2022-06-24 20:02:00.380810
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    var_0 = retry_with_delays_and_condition(generate_jittered_backoff(1))

    # If we want to run the decorated function once
    # It should raise an exception because the iterator is empty
    try:
        var_0()
    except Exception:
        pass
    else:
        raise Exception('This function should raise an exception')

    # If we want to run the decorated function twice
    # It should raise an exception because the iterator is empty
    try:
        var_0()
    except Exception:
        pass
    else:
        raise Exception('This function should raise an exception')

# Generated at 2022-06-24 20:02:02.016089
# Unit test for function retry
def test_retry():
    @retry()
    def add(a, b):
        return a + b

    assert add("1", "2") == "12"

# Generated at 2022-06-24 20:02:05.208137
# Unit test for function retry
def test_retry():
    should_retry_error = retry_never

    @retry(retries=10, retry_pause=1)
    def add_1(x):
        return x + 1

    assert(add_1(41) == 42)


# Generated at 2022-06-24 20:02:11.600148
# Unit test for function retry
def test_retry():
    @retry(retries=5)
    def foo():
        return True
    assert foo()

    @retry(retries=3, retry_pause=2)
    def foo2():
        raise Exception()
    assert not foo2()


# Test for limit rate

# Generated at 2022-06-24 20:02:15.445655
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    var_0 = generate_jittered_backoff(retries=10, delay_base=4)
    assert len(var_0) == 10
    assert max(var_0) <= 16
    assert min(var_0) >= 0
    assert sum(var_0) <= 80



# Generated at 2022-06-24 20:02:19.029326
# Unit test for function retry
def test_retry():
    test_var_0 = random.randint(10, 15)
    @retry(retries=test_var_0)
    def retried():
        assert True
    retried()



# Generated at 2022-06-24 20:02:20.698555
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    var_0 = generate_jittered_backoff()
    assert list(var_0) == [0, 3, 3, 6, 0, 12, 12, 12, 9, 6]

# Generated at 2022-06-24 20:02:25.356938
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # test multiple tries
    # Ref: https://www.awsarchitectureblog.com/2015/03/backoff.html
    it = generate_jittered_backoff()

    retry_count = 0
    for x in it:
        retry_count += 1
        assert retry_count <= 10
        if retry_count > 2:
            break
        assert 0 <= x <= 3

    # test retry forever
    retry_count = 0
    it = generate_jittered_backoff(retries=122)

    for retry_count, x in enumerate(it):
        assert 0 <= x <= 3
        if retry_count >= 120:
            break
    assert retry_count == 120

    # test retry forever, with longer delay
    retry_count = 0
    it = generate_jittered

# Generated at 2022-06-24 20:02:34.040303
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    print("TODO: Implement function test_retry_with_delays_and_condition")
    return True

# Generated at 2022-06-24 20:02:41.625777
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    # Test case 0, no retry
    try:
        test_case_0()
    except Exception as e:
        print(e)

    # Test case 1, no retry
    try:
        var_1 = 1
        var_1 += 1
    except Exception as e:
        print(e)

    # Test case 2, no retry
    try:
        var_2 = generate_jittered_backoff()
        for var_3 in var_2:
            print(var_3)
    except Exception as e:
        print(e)

    # Test case 3, no retry
    try:
        var_3 = generate_jittered_backoff()
        var_4 = list(var_3)
        print(var_4)
    except Exception as e:
        print(e)

    print

# Generated at 2022-06-24 20:02:51.748529
# Unit test for function retry
def test_retry():
    # test case for retry 1
    def test_retry_1():
        @retry(retries=2, retry_pause=0.1)
        def fail_first_time():
            print('fail_first_time')
            if fail_first_time.call_count == 0:
                fail_first_time.call_count += 1
                raise Exception
            return True

        fail_first_time.call_count = 0
        result = fail_first_time()
        assert result

    test_retry_1()

    # test case for retry 2
    def test_retry_2():
        @retry(retries=2, retry_pause=0.1)
        def fail_second_time():
            print('fail_second_time')

# Generated at 2022-06-24 20:03:02.171874
# Unit test for function retry
def test_retry():
    from ansible.module_utils.basic import AnsibleModule

    def f1(t):
        return t

    def f0(t):
        raise ValueError("t")

    for t1, t2 in zip(retry(retries=None, retry_pause=0)(f1)(1),
                      retry(retries=None, retry_pause=0)(f1)(2)):
        assert t1 == t2

    for t1, t2 in zip(retry(retries=None, retry_pause=0)(f1)(1),
                      retry(retries=None, retry_pause=0)(f1)(None)):
        assert t1 == t2

    t1 = retry(retries=None, retry_pause=0)(f1)(1)

# Generated at 2022-06-24 20:03:11.446720
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    retry_with_delays_and_condition unit test
    """
    # Create method data
    var_0 = generate_jittered_backoff()
    var_1 = retry_never
    var_2 = object()

    # Try to call method without error
    try:
        function_0 = retry_with_delays_and_condition(var_0, var_1)
        function_0(var_2)
    except Exception as e:
        assert False, "Exception raised in retry_with_delays_and_condition: %s" % e

# Generated at 2022-06-24 20:03:17.126313
# Unit test for function rate_limit
def test_rate_limit():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.common.utils import AnsibleModule

    class MockModule(AnsibleModule):
        def __init__(self, rate=None, rate_limit=None):
            super(MockModule, self).__init__()
            self.params = dict(rate=rate, rate_limit=rate_limit)

    @rate_limit(rate=1, rate_limit=1)
    def call(use_delay):
        return time.time()


# Generated at 2022-06-24 20:03:23.393063
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def test_func():
        pass
    result_decorator = retry_with_delays_and_condition(generate_jittered_backoff(2, 3, 60))
    result = result_decorator(test_func)
    assert result() is None



# Generated at 2022-06-24 20:03:25.052646
# Unit test for function rate_limit
def test_rate_limit():
    var_0 = rate_limit(rate=10, rate_limit=10)
    assert var_0(lambda: None)() is None


# Generated at 2022-06-24 20:03:34.236003
# Unit test for function rate_limit
def test_rate_limit():
    assert True
    test_count = 100

    def test_rate_limit_inner(rate=None, rate_limit=None):
        max_rate = 0.0
        min_rate = 2
        start_time = time.time()
        for _ in range(test_count):
            time.sleep(1)
        end_time = time.time()
        rate = float(test_count) / (end_time - start_time)
        max_rate = rate
        assert(rate) < min_rate
        return rate
    rate_limit_decorator = rate_limit(rate=10, rate_limit=60)
    rate = rate_limit_decorator(test_rate_limit_inner)(rate=10, rate_limit=60)
    assert rate < 10

# Generated at 2022-06-24 20:03:41.773839
# Unit test for function rate_limit
def test_rate_limit():

    #
    # Test rate limit function
    #
    def test_f():
        time.sleep(0.1)

    test_rate_limit = rate_limit(10, 1)
    test_rate_limit(test_f)()
    test_rate_limit(test_f)()
    test_rate_limit(test_f)()

    #
    # Test decorator
    #
    @rate_limit(10, 1)
    def r_test_f():
        time.sleep(0.1)
    r_test_f()
    r_test_f()
    r_test_f()



# Generated at 2022-06-24 20:03:58.200381
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit"""

    def __test_rate_limit(rate, rate_limit):
        global rate_limit_last
        rate_limit_last = 0.0

        @rate_limit(rate, rate_limit)
        def test_rate_limit_inner():
            global rate_limit_last
            rate_limit_last += 1
            return rate_limit_last

        test_rate_limit_inner()
        if sys.version_info >= (3, 8):
            real_time = time.process_time
        else:
            real_time = time.clock
        return real_time() - test_rate_limit_inner.last[0]

    real = __test_rate_limit(1, 1)
    assert real > 0 and abs(real - 1) < 0.1



# Generated at 2022-06-24 20:04:03.466741
# Unit test for function rate_limit
def test_rate_limit():
    # Verify the example
    var_0 = rate_limit(rate=None, rate_limit=None)
    # rate_limit(rate=None, rate_limit=None) = <function rate_limit.<locals>.wrapper(f)>
    # assert type(var_0) == <class 'function'>, "rate_limit should return a 'function' but returned '{0}'".format(type(var_0))
    var_1 = retry_argument_spec()


# Generated at 2022-06-24 20:04:08.836112
# Unit test for function rate_limit
def test_rate_limit():
    spec = rate_limit_argument_spec()
    module = MagicMock(spec_set=spec)
    module.rate = 10
    module.rate_limit = 5

    @rate_limit(rate=module.rate, rate_limit=module.rate_limit)
    def my_func():
        return {
            'rate': module.rate,
            'rate_limit': module.rate_limit,
            'time': time.time()
        }

    result = my_func()
    assert type(result) == dict


# Generated at 2022-06-24 20:04:14.469624
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Module has a dependency on __builtin__, but we don't need that in our test
    orig_builtin = __builtin__
    if '__builtin__' in sys.modules:
        del sys.modules['__builtin__']
    try:
        import api as api_mod
    finally:
        sys.modules['__builtin__'] = orig_builtin

    if hasattr(api_mod, '__version__') and api_mod.__version__ < '2.0':
        raises_exception_api_mod = api_mod.raises_exception_2x
    else:
        raises_exception_api_mod = api_mod.raises_exception


# Generated at 2022-06-24 20:04:19.029318
# Unit test for function rate_limit
def test_rate_limit():
    arg_0 = 10
    arg_1 = 60
    rate_limit(arg_0, arg_1)



# Generated at 2022-06-24 20:04:20.084423
# Unit test for function rate_limit
def test_rate_limit():
    var_0 = rate_limit(10, 60)
    assert var_0 is not None


# Generated at 2022-06-24 20:04:27.118059
# Unit test for function retry
def test_retry():
    var_0 = retry(retries=3, retry_pause=2)
    def test_function():
        print("Unit test for function retry")
    retried_function = var_0(test_function)
    retried_function()


# Generated at 2022-06-24 20:04:29.445543
# Unit test for function retry
def test_retry():
    # Verify that retry function call works and has no exceptions
    retry(retries=None, retry_pause=1)


# Generated at 2022-06-24 20:04:33.941011
# Unit test for function retry
def test_retry():
    """Test the retry decorator"""
    def dummy_func(a, b):
        return a * b

    decorated = retry(retries=3)(dummy_func)

    assert decorated(2, 3) == 6



# Generated at 2022-06-24 20:04:34.997209
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    assert callable(retry_with_delays_and_condition)


# Generated at 2022-06-24 20:04:51.295211
# Unit test for function rate_limit
def test_rate_limit():
    """
    Placeholder for rate_limit unit test
    """
    pass

# Generated at 2022-06-24 20:04:54.504538
# Unit test for function retry
def test_retry():
    @retry(3)
    def failing_function(a):
        if a > 0:
            raise Exception()
        return True

    # Test success
    assert failing_function(0)

    # Test retry limit
    try:
        failing_function(1)
        raise Exception("should have thrown an exception")
    except Exception:
        pass

# Generated at 2022-06-24 20:04:55.891138
# Unit test for function rate_limit
def test_rate_limit():
    x = rate_limit(rate=None, rate_limit=None)
    assert isinstance(x, type(test_case_0)) == True



# Generated at 2022-06-24 20:04:58.893026
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def call_with_retries():
        return 42

    assert(call_with_retries() == 42)



# Generated at 2022-06-24 20:04:59.472221
# Unit test for function retry
def test_retry():
    pass

# Generated at 2022-06-24 20:05:03.606435
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    with pytest.raises(Exception) as e_info:
        retry_with_delays_and_condition()

    assert e_info.type == TypeError
    # assert e_info.value.args[0] == "test_retry_with_delays_and_condition() missing 1 required positional argument: 'a_date_string'"


# Generated at 2022-06-24 20:05:10.103710
# Unit test for function retry
def test_retry():
    @retry(retries = 2, retry_pause = 1)
    def func(argument_0 = True):
        if not argument_0:
            raise Exception('retry test')
        return argument_0
    assert(func() is True)
    assert(func(False) is True)
    try:
        assert(func(False) is True)
    except Exception:
        return True

# Generated at 2022-06-24 20:05:15.352623
# Unit test for function retry
def test_retry():
    class TestClass:
        def test_0():
            pass
    TestClass.test_0()

    retries = 5
    retry_pause = 5

    TestClass.test_0 = retry_with_delays_and_condition(generate_jittered_backoff(retries=retries, delay_base=retry_pause))(TestClass.test_0)
    TestClass.test_0()

# Generated at 2022-06-24 20:05:22.743609
# Unit test for function rate_limit
def test_rate_limit():
    try:
        func = rate_limit_argument_spec()
        delay = 2
        if sys.version_info < (2, 7):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                func(None)
                assert issubclass(w[-1].category, DeprecationWarning)
        else:
            with pytest.raises(TypeError):
                func(None)
    except Exception as e:
        print('Caught exception: ' + str(e))
        assert False


# Generated at 2022-06-24 20:05:30.534585
# Unit test for function retry
def test_retry():
    """
    This is a test for the retry decorator.
    """

    retries = 5
    success = False

    @retry(retries=retries)
    def test_function(success):
        if not success:
            raise Exception("Fail")
        else:
            return True

    with pytest.raises(Exception, match='Retry limit exceeded: 5'):
        test_function(success)

    success = True

    assert test_function(success)

# Generated at 2022-06-24 20:06:06.417939
# Unit test for function rate_limit
def test_rate_limit():
    assert var_0
    assert 'rate' in var_0
    assert var_0['rate']
    assert var_0['rate']['type'] == 'int'
    assert 'rate_limit' in var_0
    assert var_0['rate_limit']
    assert var_0['rate_limit']['type'] == 'int'


# Generated at 2022-06-24 20:06:16.331725
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def function_that_fails_immediately():
        raise RuntimeError('function_that_fails_immediately')

    with pytest.raises(RuntimeError) as error:
        function_that_fails_immediately()

    assert error.value.args[0] == 'function_that_fails_immediately'

    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def function_that_succeeds_immediately():
        return 'function_that_succeeds_immediately'

    assert function_that_succeeds_immediately() == 'function_that_succeeds_immediately'


# Generated at 2022-06-24 20:06:23.121626
# Unit test for function retry
def test_retry():
    print("HINT: If you need to use actual Azure ARM resources, you will need to supply your own `subscription_id`")
    # This is a call to a protected method, disable the warning
    # pylint: disable=protected-access
    import random
    import string
    random_str = ''.join(random.choice(string.ascii_letters) for _ in range(32))
    retries = random.randint(0, 20)
    retry_pause = random.uniform(0.0, 1.0)
    retry_count = 0
    # This will be called for each retry attempt
    def retried(*args, **kwargs):
        """Keep track of the retry count and fail of the specified retries"""
        # This is a protected member, disable the warning
        # pylint: disable=

# Generated at 2022-06-24 20:06:32.095624
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global total_calls
    total_calls = 0
    def bad_function(arg):
        nonlocal total_calls
        total_calls += 1
        if arg:
            raise Exception()
        return True

    retry_bad_function = retry_with_delays_and_condition(generate_jittered_backoff())(bad_function)
    assert retry_bad_function(False) == True
    assert total_calls == 1
    assert retry_bad_function(True) == None
    assert total_calls == 11



# Generated at 2022-06-24 20:06:38.877790
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    try:
        # Test function to be decorated
        @retry_with_delays_and_condition(generate_jittered_backoff(retries=5, delay_base=2.5, delay_threshold=30))
        def retryable_function():
            raise Exception('This function will be retried')

        retryable_function()

        # Should not reach this line
        raise Exception('Test failed: Function was not retried.')
    except Exception:
        pass



# Generated at 2022-06-24 20:06:50.023203
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Asserts for the retry decorator with delays
    delays = [0, 1, 2, 3]
    # Number of times that the function should execute
    times_to_execute = len(delays)
    times_the_func_was_called = 0

    def should_retry(exception_or_result=None):
        return True

    # Unit test for function retry_with_delays_and_condition
    @retry_with_delays_and_condition(backoff_iterator=delays, should_retry_error=should_retry)
    def dummy_func():
        global times_the_func_was_called
        times_the_func_was_called += 1

    dummy_func()
    assert times_the_func_was_called == times_to_execute



# Generated at 2022-06-24 20:06:56.147789
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def function_to_retry():
        return 1

    decorated_function = retry_with_delays_and_condition((2, 3))(function_to_retry)

    assert decorated_function() == 1     # no exception
    assert decorated_function() == 1     # no exception
    assert decorated_function() == 1     # no exception
    assert decorated_function() == 1     # no exception
    assert decorated_function() == 1     # no exception



# Generated at 2022-06-24 20:06:59.291710
# Unit test for function rate_limit
def test_rate_limit():
    try:
        assert callable(rate_limit)
    except AssertionError:
        raise AssertionError('function rate_limit does not exist!')
    try:
        assert rate_limit(rate=None, rate_limit=None)
    except AssertionError:
        raise AssertionError('function rate_limit does not work as expected!')


# Generated at 2022-06-24 20:07:01.817540
# Unit test for function rate_limit
def test_rate_limit():
    # Init
    var_0 = rate_limit_argument_spec()

    # Call function
    ret_val = rate_limit()
    assert ret_val is not None

    # Call function
    ret_val = rate_limit(rate=var_0)
    assert ret_val is not None

    # Call function
    ret_val = rate_limit(rate_limit=var_0)
    assert ret_val is not None


# Generated at 2022-06-24 20:07:03.799799
# Unit test for function retry
def test_retry():
    assert retry(retries=1, retry_pause=1)(lambda x, y: x * y)(3, 5) == 15



# Generated at 2022-06-24 20:08:28.843963
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    assert(not retry_never(None))
    assert(retry_never(True))

    counter = 0
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=5), should_retry_error=retry_never)
    def test_func(raise_exception=False, return_value=None):
        global counter
        if raise_exception:
            raise Exception('Test Exception')
        if return_value or counter == 0:
            counter += 1
            return return_value
        return None

    try:
        test_func(raise_exception=True)
        assert(False)
    except Exception as e:
        assert(str(e) == 'Test Exception')


# Generated at 2022-06-24 20:08:35.296852
# Unit test for function retry
def test_retry():
    import unittest
    import inspect

    def try_default(num_retries, pause, success_on_try=None):
        @retry(retries=num_retries, retry_pause=pause)
        def do_retry(arg):
            nonlocal failures
            failures += 1
            if failures == success_on_try:
                return True
            return False
        failures = 0
        do_retry(1)
        return failures

    class TestRateLimit(unittest.TestCase):
        def test_retry_default(self):
            self.assertEqual(try_default(None, 0), 0)
            self.assertEqual(try_default(0, 0), 0)
            self.assertEqual(try_default(1, 0), 1)

# Generated at 2022-06-24 20:08:36.044316
# Unit test for function rate_limit
def test_rate_limit():
    var_0 = rate_limit_argument_spec()


# Generated at 2022-06-24 20:08:40.225315
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def test_fixture(delay_amount=0):
        def function_with_delay(delay_amount):
            time.sleep(delay_amount)
            return True

        # Add the retry decorator with 2 attempts and a 2 second delay.
        run_function_with_delay = retry_with_delays_and_condition(
            [2, 2],
            should_retry_error=retry_never
        )(function_with_delay)
        # Run the function without parameters.
        return run_function_with_delay(delay_amount)

    function_result = test_fixture(delay_amount=3)
    assert function_result is True, "The test failed to return true. The fixture was not retried."



# Generated at 2022-06-24 20:08:41.481020
# Unit test for function rate_limit
def test_rate_limit():
    unit_test_case_0()


# Generated at 2022-06-24 20:08:45.733478
# Unit test for function rate_limit
def test_rate_limit():
    assert callable(rate_limit)


if __name__ == "__main__":
    test_case_0()
    test_rate_limit()

# Generated at 2022-06-24 20:08:54.714145
# Unit test for function retry
def test_retry():
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock
    num_iterations = 10

    # define a rate limitable function
    @retry(retries=num_iterations, retry_pause=2)
    def test_rate_limitable_function(retries=None, retry_pause=2):
        retries = 1
        retry_pause = 15
        num_iterations = 10
        for i in range(0, num_iterations):
            if i > retries:
                raise Exception("Retry limit exceeded: %d" % i)
            time.sleep(retry_pause)
        return True

    # run it, should succeed
    test_rate_limitable_function()

    # run it,

# Generated at 2022-06-24 20:08:59.811560
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    retries = 10
    delay_base = 3
    delay_threshold = 60

    backoff_iterator = generate_jittered_backoff(
        retries, delay_base, delay_threshold)

    should_retry_error = retry_never

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def do_something():
        raise Exception('This function shall not be retried')

    try:
        do_something()
    except Exception as e:
        assert str(e) == 'This function shall not be retried'
    else:
        raise AssertionError('This function shall not be retried')



# Generated at 2022-06-24 20:09:08.166596
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    function_called = [0]

    def should_retry_error(e):
        return True

    def raise_exception(*args, **kwargs):
        function_called[0] += 1
        raise Exception("Call #{0}".format(function_called[0]))

    backoff_iterator = [1]

    retried_function = retry_with_delays_and_condition(backoff_iterator, should_retry_error)

    with pytest.raises(Exception) as exc:
        retried_function(raise_exception)

    assert "Call #2" in str(exc.value)
    assert function_called[0] == 2


# Generated at 2022-06-24 20:09:11.505053
# Unit test for function rate_limit
def test_rate_limit():
    rate = None
    rate_limit = None
    assert rate_limit(rate, rate_limit)

