

# Generated at 2022-06-24 20:01:55.495361
# Unit test for function rate_limit
def test_rate_limit():
  from ansible.module_utils.basic import AnsibleModule

  ansible_module = AnsibleModule(
    argument_spec=dict(
      rate=dict(required=True, type='int'),
      rate_limit=dict(required=True, type='float'),
      url=dict(required=True, type='str'),
    )
  )
  test_case_0()


# Run the tests
test_rate_limit()

# Generated at 2022-06-24 20:01:57.498616
# Unit test for function rate_limit
def test_rate_limit():
    var_0 = rate_limit_argument_spec()
    assert var_0 == (
        {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}},
    )


# Generated at 2022-06-24 20:02:01.665721
# Unit test for function retry
def test_retry():
    @retry(retries=2, retry_pause=1)
    def f1():
        return "alpha"
    @retry(retries=2, retry_pause=2)
    def f2():
        return "beta"

    assert f1() == 'alpha'
    assert f2() == 'beta'


# Generated at 2022-06-24 20:02:05.430977
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    retries=10
    delay_base=3
    delay_threshold=60
    for retry in range(0, retries):
        yield random.randint(0, min(delay_threshold, delay_base * 2 ** retry))

test_case_0()
test_generate_jittered_backoff()

# Generated at 2022-06-24 20:02:07.725183
# Unit test for function rate_limit
def test_rate_limit():
    var_1 = 0
    var_2 = var_1
    var_3 = 0
    var_4 = rate_limit(var_1, var_3)
    var_5 = random.randint(var_1, var_2)
    var_6 = var_4(var_5)
    assert var_5 == var_6


# Generated at 2022-06-24 20:02:12.918978
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    retries = 10
    delay_base = 3
    delay_threshold = 60
    backoff_iterator = generate_jittered_backoff(retries, delay_base, delay_threshold)
    sum_backoff_iterator = 0
    min_backoff_iterator = delay_threshold
    max_backoff_iterator = 0
    for backoff in backoff_iterator:
        sum_backoff_iterator += backoff
        min_backoff_iterator = min(min_backoff_iterator, backoff)
        max_backoff_iterator = max(max_backoff_iterator, backoff)
    assert sum_backoff_iterator != 0
    assert min_backoff_iterator != 0
    assert max_backoff_iterator != 0



# Generated at 2022-06-24 20:02:15.657218
# Unit test for function retry
def test_retry():
    try:
        raise Exception("Test exception")
    except:
        print("Test exception raised")

if __name__ == "__main__":
    test_case_0()
    test_retry()

# Generated at 2022-06-24 20:02:20.869174
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(4))
    def func_that_succeeds():
        return True

    @retry_with_delays_and_condition(generate_jittered_backoff(3))
    def func_that_fails_by_throwing_exception():
        raise Exception()

    @retry_with_delays_and_condition(generate_jittered_backoff(6))
    def func_that_fails():
        return False

    @retry_with_delays_and_condition(generate_jittered_backoff(3), retry_never)
    def func_that_fails_by_throwing_exception_but_never_retries():
        raise Exception()


# Generated at 2022-06-24 20:02:24.858525
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # iterate over test_cases:
    for test_params, expected_result in test_cases:
        actual_result = generate_jittered_backoff(test_params)
        print('input: {}, expected: {}, actual: {}'.format(test_params, expected_result, actual_result))
        assert(actual_result == expected_result)


test_cases = [
    (test_case_0,
     [
         {
             'rate': {'default': None, 'required': False, 'type': 'int'},
             'rate_limit': {'default': None, 'required': False, 'type': 'int'},
         },
     ]),
]

# Generated at 2022-06-24 20:02:26.609202
# Unit test for function retry
def test_retry():
    @retry()
    def retried(*args, **kwargs):
        pass

    retried()


# Generated at 2022-06-24 20:02:42.995352
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    print("\nStarting unit test for function retry_with_delays_and_condition.\n")
    var_0 = retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=2, delay_base=2, delay_threshold=10))
    def test_function_0(*args, **kwargs):
        return 1
    var_1 = var_0(test_function_0)
    print(var_1())
    print("\nUnit test for function retry_with_delays_and_condition complete.\n")

if __name__ == "__main__":
    test_case_0()
    test_retry_with_delays_and_condition()

# Generated at 2022-06-24 20:02:47.245089
# Unit test for function retry
def test_retry():
    def _inner_method(*a, **k):
        print(a)
        print(k)
        if a[0] < 0:
            raise Exception('nope')
        return True

    do_retry = retry(retries=3, retry_pause=1)
    orig = do_retry(_inner_method)
    assert orig(2, b='3')
    try:
        orig(-2, b='3')
    except Exception as e:
        assert e.args[0] == 'Retry limit exceeded: 3'
    assert orig(4, b='5')



# Generated at 2022-06-24 20:02:48.394625
# Unit test for function rate_limit
def test_rate_limit():
    assert rate_limit is not None


# Generated at 2022-06-24 20:02:51.850206
# Unit test for function rate_limit
def test_rate_limit():
    try:
        res = rate_limit()
    except Exception as exc:
        assert False, "rate_limit() raised Exception '{0}'".format(exc)
    assert True



# Generated at 2022-06-24 20:02:59.471272
# Unit test for function retry
def test_retry():
    import unittest
    class Test_retry(unittest.TestCase):
        def test_retry_exception_0(self):
            retries = 1
            retry_pause = 1.0
            @retry(retries=retries, retry_pause=retry_pause)
            def test_function():
                raise Exception('test msg')
            with self.assertRaisesRegexp(Exception, 'test msg'):
                test_function()

    unittest.main()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:03:09.628874
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    import operator

    class TestClass(unittest.TestCase):
        def test_function_called_once(self):
            @retry_with_delays_and_condition(generate_jittered_backoff(retries=0))
            def generate_42():
                return 42

            result_42 = generate_42()
            self.assertEqual(result_42, 42)

        def test_function_called_three_times_with_retries(self):
            @retry_with_delays_and_condition(generate_jittered_backoff(retries=2), operator.not_)
            def generate_42():
                return False

            result_42 = generate_42()
            self.assertFalse(result_42)


# Generated at 2022-06-24 20:03:12.772043
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Initialize the test environment
    backoff_iterator = [1, 2, 3]
    should_retry_error = retry_never
    function = lambda: 1
    test_case_name = 'test_case_0'
    test_case_0()



# Generated at 2022-06-24 20:03:17.244509
# Unit test for function retry
def test_retry():
    var_1 = retry(0, 1)
    var_2 = retry(3, 1)
    var_3 = retry(3, 0.5)


# Generated at 2022-06-24 20:03:18.658015
# Unit test for function rate_limit
def test_rate_limit():
    pass # Check that function does not return None.


# Generated at 2022-06-24 20:03:19.489221
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    assert(2 == 2)

test_case_0()

# Generated at 2022-06-24 20:03:38.702944
# Unit test for function retry
def test_retry():
    """Test unit for function retry"""

    def do_nothing():
        pass

    result = retry()(do_nothing)()
    assert result is None



# Generated at 2022-06-24 20:03:40.374053
# Unit test for function rate_limit
def test_rate_limit():
    var_1 = rate_limit_argument_spec(spec=None)
    assert var_1 == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}


# Generated at 2022-06-24 20:03:42.646525
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    result = retry_with_delays_and_condition(backoff_iterator=None, should_retry_error=None)
    assert result is not None


# Generated at 2022-06-24 20:03:44.764520
# Unit test for function rate_limit
def test_rate_limit():
    # No values provided
    test_case_0()

# Use module name to call, in this case 'api'
test_rate_limit()

# Generated at 2022-06-24 20:03:48.283348
# Unit test for function retry
def test_retry():
    @retry(retries=10, retry_pause=1)
    def func():
        """This function will be retried 10 times with 1 sec pause between each retry.
        """
        pass

    func()



# Generated at 2022-06-24 20:03:56.257003
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from collections import deque
    TEST_CASES = [
        [
            [3, 9, 24, 47, 91],
            retry_never
        ]
    ]

    for test_case in TEST_CASES:
        backoff_iterator = deque(generate_jittered_backoff(*test_case[0]))
        should_retry_error = test_case[1]

        @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
        def fn(a, b, c=0, d=0):
            return a + b + c + d

        assert fn(1, 2, 3, 4) == 10

# Generated at 2022-06-24 20:03:57.273267
# Unit test for function retry
def test_retry():
    var_0 = retry_argument_spec()

# Generated at 2022-06-24 20:03:59.160774
# Unit test for function retry
def test_retry():
    x = retry(retries=5, retry_pause=1)(lambda y: y**2)(2)
    print(x)



# Generated at 2022-06-24 20:04:06.309160
# Unit test for function retry
def test_retry():
    """
    retry unit test stubs
    """
    retries = None
    retry_pause = 1

    def retry_limit():
        raise Exception("Retry limit exceeded: %d" % retries)

    def retry_with_value():
        return True

    def retry_without_value():
        return None

    @retry(retries, retry_pause)
    def retry_function_value():
        retry_with_value()

    @retry(retries, retry_pause)
    def retry_function_none():
        retry_without_value()

    @retry(retries, retry_pause)
    def retry_function_exception():
        retry_limit()


if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-24 20:04:17.117422
# Unit test for function retry
def test_retry():
    initial_attempt = 0

    @retry()
    def function_with_no_retries():
        return True

    @retry(retries=2)
    def function_with_retries():
        nonlocal initial_attempt
        initial_attempt += 1

        if initial_attempt == 1:
            raise Exception('Function not ready for use.')

        return True

    @retry(retries=2, retry_pause=1)
    def function_with_retries_and_pause():
        nonlocal initial_attempt
        initial_attempt += 1

        if initial_attempt == 1:
            raise Exception('Function not ready for use.')

        return True

    assert function_with_no_retries()

    with pytest.raises(Exception):
        function_with_retries()



# Generated at 2022-06-24 20:04:48.265941
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    try:
        var_0 = retry_with_delays_and_condition()
        print(var_0)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_retry_with_delays_and_condition()

# Generated at 2022-06-24 20:04:56.697218
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def retryable_f():
        return False

    def not_retryable_f():
        return True

    def divide_by_zero_f():
        1 / 0

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def function_with_no_retries():
        return retryable_f()

    @retry_with_delays_and_condition(generate_jittered_backoff(), None)
    def function_with_no_retries_so_backoff_iterator_should_be_run_once():
        return retryable_f()

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def function_with_retries():
        return retryable_f()


# Generated at 2022-06-24 20:05:02.087529
# Unit test for function retry
def test_retry():
    var_0 = rate_limit_argument_spec()
    wrapped = retry(var_0)(test_retry)
    var_2 = rate_limit_argument_spec()
    wrapped(var_2)


# Generated at 2022-06-24 20:05:12.282089
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = generate_jittered_backoff()
    function_args = {}
    function_kwargs = {}
    function_result = None
    success_count = 0
    retry_count = 0
    for delay in backoff_iterator:
        try:
            function_result = function(*function_args, **function_kwargs)
            success_count += 1
            assert success_count == 1
            assert retry_count == 0
        except Exception as e:
            retry_count += 1
            assert success_count == 0
            assert retry_count == 1
        time.sleep(delay)
    success_count += 1
    assert success_count == 1
    assert retry_count == 1

# Generated at 2022-06-24 20:05:19.672677
# Unit test for function rate_limit
def test_rate_limit():
    # For testing rate limiting, we want to make sure that a function takes longer than without the decorator.
    # In order to test this we need to make sure that the function takes longer than the decorator's minrate.

    # If no rate limiting is specified, we expect the function to take about the same amount of time as it does without the decorator.
    @rate_limit()
    def _rate_limited_function_0():
        time.sleep(0)

    start_time = time.time()
    _rate_limited_function_0()
    duration = time.time() - start_time
    assert duration < 0.5

    # If rate limiting is specified, we expect the function to take longer than the rate's minrate.

# Generated at 2022-06-24 20:05:20.993926
# Unit test for function retry
def test_retry():
    var_0 = retry_argument_spec()
    var_1 = retry()

# Generated at 2022-06-24 20:05:25.601231
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = generate_jittered_backoff()
    should_retry_error = retry_never

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def function(expected_exception):
        raise expected_exception

    hello = function(Exception('Hello'))
    assert hello is None



# Generated at 2022-06-24 20:05:28.090066
# Unit test for function rate_limit
def test_rate_limit():
    local_unit_info = sys._getframe().f_code.co_name

    # Set up test data

    # Run the test
    test_case_0()



# Generated at 2022-06-24 20:05:32.026359
# Unit test for function retry
def test_retry():
    count = 0

    def myfunction():
        if count < 2:
            count = count + 1
            raise Exception("retry")
        else:
            return True

    decorated_function = retry(retries=5)(myfunction)

    assert decorated_function()



# Generated at 2022-06-24 20:05:35.386380
# Unit test for function retry
def test_retry():
    test = 0
    @retry(2, 10)
    def test_function():
        global test
        if test == 0:
            test = 1
            raise Exception("test")
        return True
    assert test_function() is True



# Generated at 2022-06-24 20:06:42.337112
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    assert retry_with_delays_and_condition(generate_jittered_backoff())



# Generated at 2022-06-24 20:06:45.692338
# Unit test for function retry
def test_retry():
    @retry(retries=10)
    def _retry_test_funtion():
        return 0

    _retry_test_funtion()


# Generated at 2022-06-24 20:06:55.658135
# Unit test for function rate_limit
def test_rate_limit():
    var_0 = rate_limit_argument_spec()
    var_1 = retry_argument_spec()
    var_2 = basic_auth_argument_spec()
    var_3 = rate_limit(rate=var_0['rate'], rate_limit=var_0['rate_limit'])
    var_4 = retry(retries=var_1['retries'], retry_pause=var_1['retry_pause'])
    var_5 = basic_auth_argument_spec(spec=var_2)
    var_6 = generate_jittered_backoff(retries=var_1['retries'], delay_base=var_1['retry_pause'], delay_threshold=var_0['rate_limit'])

# Generated at 2022-06-24 20:07:00.615826
# Unit test for function retry
def test_retry():
    """Test for retry"""
    import mock

    @retry(retries=1, retry_pause=1)
    def _retryed(*args, **kwargs):
        print(args)

    # Should not raise on any attempt
    with mock.patch('time.sleep'):
        _retryed(1, 2, abc=1)

    # Should raise on second attempt (retries=1)
    with mock.patch('time.sleep'):
        _retryed(1, 2, abc=1)


if __name__ == '__main__':
    # Unit tests
    test_retry()

# Generated at 2022-06-24 20:07:02.436400
# Unit test for function retry
def test_retry():
    var_0 = retry(retries=None, retry_pause=1)



# Generated at 2022-06-24 20:07:02.954104
# Unit test for function retry
def test_retry():
    assert True

# Generated at 2022-06-24 20:07:07.333046
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    num_runs = 0
    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def retryable_function():
        nonlocal num_runs
        num_runs += 1
        return True, num_runs
    first_result = retryable_function()
    assert first_result == (True, 1)
    second_result = retryable_function()
    assert second_result == (True, 2)

    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def retryable_function_that_fails_10_times():
        nonlocal num_runs
        num_runs += 1
        raise Exception("This is call %d" % num_runs)

# Generated at 2022-06-24 20:07:16.971658
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Input parameters
    #   *backoff_iterator - iterator used to provide backoff delays in seconds
    #   should_retry_error - used to determine if an exception should trigger a retry or not
    backoff_iterator = [1]
    should_retry_error = retry_never
    retryable_function_exceptions = []
    retryable_function_results = []

    def test_function_that_raises_exception():
        if len(retryable_function_exceptions) > 0:
            exception = retryable_function_exceptions.pop()
            raise exception
        elif len(retryable_function_results) > 0:
            return retryable_function_results.pop()
        else:
            raise Exception('Unexpected test state')

    # Call retry_with_delays

# Generated at 2022-06-24 20:07:18.365734
# Unit test for function retry
def test_retry():
    var_1 = retry(None, 1)
    var_2 = retry(None, 3)


# Generated at 2022-06-24 20:07:25.102516
# Unit test for function retry
def test_retry():
    @retry(retries=2)
    def test_f():
        return 1
    assert test_f() == 1
    n = 0
    @retry(retries=2)
    def test_f():
        nonlocal n
        n += 1
        raise Exception("bad 1")
        return 1
    try:
        test_f()
    except Exception as e:
        assert str(e) == "Retry limit exceeded: 2"
    assert n == 2


# Generated at 2022-06-24 20:10:14.079688
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def should_retry(e):
        return isinstance(e, ValueError)

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=should_retry)
    def throw_on_2(n):
        """This function will raise a ValueError exception on the second call."""
        throw_on_2.call_count += 1
        if throw_on_2.call_count > 1:
            raise ValueError('Breaking on %d' % throw_on_2.call_count)
        return 'Ok on %d' % throw_on_2.call_count

    # We should break after three tries
    throw_on_2.call_count = 0
    assert throw_on_2(1) == 'Ok on 1'
    assert throw_on_

# Generated at 2022-06-24 20:10:16.989644
# Unit test for function rate_limit
def test_rate_limit():
    arg_spec = rate_limit_argument_spec()
    arg_spec = dict(
        from_test = True,
        rate = 1,
        rate_limit = 1
    )
    arg_spec = rate_limit_argument_spec(arg_spec)
    func = rate_limit(arg_spec['rate'], arg_spec['rate_limit'])
    return func


# Generated at 2022-06-24 20:10:18.149273
# Unit test for function rate_limit
def test_rate_limit():
    # unit test for function rate_limit
    pass



# Generated at 2022-06-24 20:10:24.310479
# Unit test for function retry
def test_retry():
    failed = 0

    def test_results(succeded, message=''):
        func_name = sys._getframe(1).f_code.co_name
        if not succeded:
            failed += 1
            print('Unit test failed: {}: {}'.format(func_name, message))
        else:
            print('Unit test passed: {}: {}'.format(func_name, message))

    test_results(not retry_with_delays_and_condition(generate_jittered_backoff(retries=0))(retry_never))
    test_results(retry_with_delays_and_condition(generate_jittered_backoff(retries=1), retry_never)(lambda x: x == 'oops')('nope'), 'retry_never')

# Generated at 2022-06-24 20:10:29.338983
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global func_retries, func_results, retry_error, retry_error_count
    func_retries = 0
    func_results = []

    def should_retry_error(exception):
        global retry_error, retry_error_count
        if retry_error is None or exception == retry_error:
            retry_error_count += 1
            return True
        else:
            return False

    def test_function():
        global func_retries
        func_retries += 1
        return func_retries

    @retry_with_delays_and_condition(backoff_iterator=[1, 2, 3], should_retry_error=should_retry_error)
    def test_function_with_retry():
        global func_retries
        func_retries += 1

# Generated at 2022-06-24 20:10:33.127884
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=2)
    def func():
        return 'foo'
    func()
    assert True


# Generated at 2022-06-24 20:10:34.381231
# Unit test for function rate_limit
def test_rate_limit():
    assert (rate_limit(1, 1) != None), "Function rate_limit must return a value"


# Generated at 2022-06-24 20:10:40.949378
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = [0, 1, 2, 4, 8]
    should_retry_error = retry_never
    function_to_test = retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    function_to_test(test_case_0)

if __name__ == "__main__":
    test_retry_with_delays_and_condition()

# Generated at 2022-06-24 20:10:45.467216
# Unit test for function retry
def test_retry():
    # Unit test for function retry
    with pytest.raises(AnsibleFailJson):
        def func(x):
            return x

        assert func(0) == 1



# Generated at 2022-06-24 20:10:53.166814
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class MockException(Exception):
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def mock_function_success(fail_after=0):
        if fail_after:
            raise MockException("Some failed execution")
        else:
            return "Success"

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    def mock_function_fail_no_retry():
        raise MockException("Some failed execution")

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def mock_function_fail_retry(fail_after=0):
        call_count = mock_function_fail_retry.call_count
        mock