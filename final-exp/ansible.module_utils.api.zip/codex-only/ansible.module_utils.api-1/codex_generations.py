

# Generated at 2022-06-22 21:09:48.106003
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit decorator using decorator"""

    @rate_limit(rate=2, rate_limit=10)
    def test_rate_limit_decorator():
        """Test rate_limit decorator using decorator"""
        pass

    def test_rate_limit_function():
        """Test rate_limit decorator using function"""
        pass
    test_rate_limit_function = rate_limit(rate=2, rate_limit=10)(test_rate_limit_function)

    start_time = time.time()
    for _ in range(0, 4):
        test_rate_limit_decorator()
    end_time = time.time()
    assert(end_time-start_time >= 3)
    assert(end_time-start_time <= 3.5)

    start_time = time.time()

# Generated at 2022-06-22 21:09:58.632310
# Unit test for function retry
def test_retry():
    import mock

    # Default config should use retries and try again
    @retry()
    def f():
        """test function"""
        raise Exception("test fail")
    args = mock.Mock()
    func_mock = mock.Mock()
    func_mock.side_effect = [Exception("test fail"), "test"]
    with mock.patch("ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_common.retry.f", func_mock):
        result = f(args)
        assert result == "test"
        assert func_mock.call_count == 2

    # No retries and we should just get the exception again
    @retry(retries=0)
    def g():
        """test function"""
        raise Exception("test fail")

# Generated at 2022-06-22 21:10:09.911350
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from collections import deque

    calls = deque(["first", "second", "third"])

    def should_retry_error(e):
        return e.message.startswith("retryable!")

    def call_with_retries():
        if len(calls) > 0:
            result = calls.popleft()
        else:
            result = "success"
        if result == "second":
            raise Exception("retryable! err")
        return result

    backoff_iterator = generate_jittered_backoff()
    call_with_retries = retry_with_delays_and_condition(
        backoff_iterator,
        should_retry_error)

    assert call_with_retries() == "success"
    assert len(calls) == 0

# Generated at 2022-06-22 21:10:19.083009
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec = retry_argument_spec()

    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    assert not module.params['retries']
    assert not module.params['retry_pause']

    # Create a module with retry settings
    module = AnsibleModule(argument_spec=argument_spec,
                           supports_check_mode=True,
                           bypass_checks=True)
    assert module.params['retries'] == 3
    assert module.params['retry_pause'] == 1

    # Create a module where we have set our own retry settings

# Generated at 2022-06-22 21:10:26.713206
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.api import basic_auth_argument_spec

    basic_auth_argument_spec_result = basic_auth_argument_spec()
    assert 'api_username' in basic_auth_argument_spec_result
    assert 'api_password' in basic_auth_argument_spec_result
    assert 'api_url' in basic_auth_argument_spec_result
    assert 'validate_certs' in basic_auth_argument_spec_result



# Generated at 2022-06-22 21:10:37.149883
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    should_retry = False
    def should_retry_error(exception):
        return should_retry

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=5, delay_threshold=1),
                                     should_retry_error=should_retry_error)
    def test_function(a, b, c):
        return a, b ,c

    assert test_function(1, 2, 3) == (1, 2, 3)
    assert test_function(1, 2, 3) == (1, 2, 3)

    should_retry = True
    catch_runtime_error_count = 0

# Generated at 2022-06-22 21:10:42.039478
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {'api_username': {'type': 'str'},
                'api_password': {'type': 'str', 'no_log': True},
                'api_url': {'type': 'str'},
                'validate_certs': {'type': 'bool', 'default': True}}

if __name__ == "__main__":
    test_basic_auth_argument_spec()

# Generated at 2022-06-22 21:10:52.317973
# Unit test for function rate_limit
def test_rate_limit():
    # Mock time using a dict with a default value of 0
    now = {'now': 0}
    time.time = lambda: now['now']
    time.sleep = lambda seconds: now.update(now={'now': now['now'] + seconds})

    @rate_limit(rate=2, rate_limit=1)
    def test():
        return True

    # The rate is 1/s so we should sleep 1s / 2
    assert test()
    assert now['now'] < 0.499
    # no sleep
    assert test()
    assert time.time() < 0.999
    # sleep 0.5s
    assert test()
    assert time.time() < 1.499
    # sleep 0.5s
    assert test()

    # reset
    now.update(now=0.0)
    assert time.time

# Generated at 2022-06-22 21:11:03.593269
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.common.dict_transformations import combine_vars
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils import basic
    import json

    def get_default(spec, attr):
        return next(iter(spec[attr].values()))

    spec = basic.get_argspec(test_retry_argument_spec)
    default_retries = get_default(spec, 'retries')
    default_retry_pause = get_default(spec, 'retry_pause')

    assert default_retries is None
    assert default_retry_pause == 1


# Generated at 2022-06-22 21:11:08.153596
# Unit test for function retry
def test_retry():
    @retry(retries=2)
    def test_func():
        return None

    @retry(retries=3)
    def test_fail():
        raise Exception('retry me!')

    assert test_func() is None
    assert isinstance(test_fail(), Exception)


if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-22 21:11:18.445009
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Test some pseudo random distribution for 60 seconds
    for delay in generate_jittered_backoff(retries=60, delay_base=1, delay_threshold=60):
        assert 0 <= delay <= 60, delay

    # Test pytest can catch the exception
    try:
        for delay in generate_jittered_backoff(retries=0, delay_base=1, delay_threshold=60):
            assert 0 <= delay <= 60, delay
        assert False
    except AssertionError as e:
        print(e)

    # Test should get exception for negative retries
    try:
        for delay in generate_jittered_backoff(retries=-1, delay_base=1, delay_threshold=60):
            assert 0 <= delay <= 60, delay
        assert False
    except AssertionError as e:
        print

# Generated at 2022-06-22 21:11:28.359658
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    argument_spec = basic_auth_argument_spec()
    assert argument_spec.get('api_password').get('no_log') == True, "api_password is not set to no_log"
    assert argument_spec.get('validate_certs') == {'type': 'bool', 'default': True}, "validate_certs is not set to default of True"
    assert argument_spec.get('api_url') == {'type': 'str'}, "api_url is not set to default of str"
    assert argument_spec.get('api_username') == {'type': 'str'}, "api_username is not set to default of str"

test_basic_auth_argument_spec()


# Generated at 2022-06-22 21:11:30.649374
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=60)
    def foo():
        return True

    foo()
    foo()
    foo()



# Generated at 2022-06-22 21:11:40.952389
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert type(spec) is dict
    assert "retries" in spec
    assert "retry_pause" in spec

    assert type(spec["retries"]) is dict
    assert "type" in spec["retries"]
    assert type(spec["retries"]["type"]) is str
    assert "int" == spec["retries"]["type"]

    assert type(spec["retry_pause"]) is dict
    assert "type" in spec["retry_pause"]
    assert "default" in spec["retry_pause"]
    assert type(spec["retry_pause"]["type"]) is str
    assert "float" == spec["retry_pause"]["type"]
    assert type(spec["retry_pause"]["default"]) is float

# Generated at 2022-06-22 21:11:52.866010
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from ansible.module_utils.six import print_
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    class MyException(Exception):
        pass

    if PY2:
        MyModuleBase = AnsibleModule
    else:
        class MyModuleBase(AnsibleModule):
            # This is needed to prevent it from checking argument spec
            # These tests will work with or without that function
            # Since this is just a unit test it isn't needed
            def _load_params(self):
                pass

    # Start with a module that uses the retry_with_delays_and_condition

# Generated at 2022-06-22 21:11:58.820039
# Unit test for function retry
def test_retry():
    func_retries = 0
    @retry(retries=3)
    def func(retry_count):
        func_retries += 1
        print("func_retries: %d, retry_count: %d" % (func_retries, retry_count))
        return None

    count = 0
    # Should run 3 times
    func(count)
    assert func_retries == 3

    func_retries = 0
    count = 1
    # Should run twice
    func(count)
    assert func_retries == 2

    func_retries = 0
    count = 3
    # Should run once
    func(count)
    assert func_retries == 1

# Generated at 2022-06-22 21:12:04.134632
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec({'foo': 'bar'}) == {'foo': 'bar', 'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}


# Generated at 2022-06-22 21:12:15.226966
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class FunctionThrewError(Exception):
        pass

    def function_always_throws_error(*args, **kwargs):
        raise FunctionThrewError()

    def function_always_returns_true(*args, **kwargs):
        return True

    def function_with_retry_condition(exception):
        return isinstance(exception, FunctionThrewError)

    @retry_with_delays_and_condition(backoff_iterator=(), should_retry_error=function_with_retry_condition)
    def never_retry_function():
        return function_always_returns_true()

    @retry_with_delays_and_condition(backoff_iterator=(), should_retry_error=function_with_retry_condition)
    def retry_function_once():
        return function

# Generated at 2022-06-22 21:12:24.345197
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestError(Exception):
        pass

    class SomeOtherError(Exception):
        pass

    class TestClass(object):
        def __init__(self, n_calls=0):
            self.n_calls = n_calls

        @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=0.1, delay_threshold=1))
        def foo(self):
            self.n_calls += 1
            if self.n_calls < 4:
                raise TestError("Retryable error")
            elif self.n_calls == 4:
                raise SomeOtherError("Non-retryable error")
            elif self.n_calls > 5:
                return "Fail"
            return "Success"


# Generated at 2022-06-22 21:12:32.728871
# Unit test for function rate_limit
def test_rate_limit():
    rate = 10
    rate_limit = 1
    minrate = float(rate_limit) / float(rate)

    def wrapper(f):
        last = [0.0]

        def ratelimited(*args, **kwargs):
            if sys.version_info >= (3, 8):
                real_time = time.process_time
            else:
                real_time = time.clock
            if minrate is not None:
                elapsed = real_time() - last[0]
                left = minrate - elapsed
                if left > 0:
                    time.sleep(left)
                last[0] = real_time()
            ret = f(*args, **kwargs)
            return ret

        return ratelimited
    return wrapper

# Generated at 2022-06-22 21:12:39.392518
# Unit test for function rate_limit
def test_rate_limit():
    import time

    @rate_limit(rate=10, rate_limit=1)
    def test(count=0):
        count += 1
        return count

    # This is a corner case, rate_limit will never let the time pass the limit
    # so the count will always stay the same, if this changes we are doing something wrong
    count = 0
    print('Expecting 10, rate_limit will always take 1 sec')
    while True:
        count = test(count=count)
        time.sleep(0.1)
        print(count)

# Generated at 2022-06-22 21:12:46.118598
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec(spec=None) == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1}
    }
    assert retry_argument_spec(spec={'foo': 1}) == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
        'foo': 1
    }


# Generated at 2022-06-22 21:12:50.568707
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils import basic

    spec = retry_argument_spec()

    for option in spec:
        assert option in ['retries', 'retry_pause']
        assert isinstance(spec[option], dict)
        assert 'type' in spec[option]



# Generated at 2022-06-22 21:12:55.916666
# Unit test for function retry_never
def test_retry_never():

    # Test that false is returned for a random exception
    exception = Exception("Some random exception")
    assert False == retry_never(exception)

    # Test that false is returned for a None result
    assert False == retry_never(None)

    # Test that false is returned for a negative result
    assert False == retry_never(-1)

    # Test that false is returned for a zero result
    assert False == retry_never(0)

    # Test that false is returned for a positive result
    assert False == retry_never(1)

# Generated at 2022-06-22 21:13:00.958445
# Unit test for function retry_never
def test_retry_never():
    result = retry_never(None)
    assert result == False
    try:
        retry_never(Exception("test"))
    except Exception as e:
        assert e.args[0] == "test"
    else:
        assert False, "Should have thrown exception"


# Generated at 2022-06-22 21:13:02.677163
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception('test'))


# Generated at 2022-06-22 21:13:08.921859
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    def always_raises_exception():
        raise Exception()

    was_run = False
    try:
        always_raises_exception()
    except Exception:
        was_run = True

    assert was_run is True

# Generated at 2022-06-22 21:13:09.900791
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert 'rate' in rate_limit_argument_spec()



# Generated at 2022-06-22 21:13:15.903431
# Unit test for function retry
def test_retry():

    @retry(retries=3)
    def func_retryable(n):
        if n:
            raise Exception
        return n

    @retry(retries=3, retry_pause=0.25)
    def func_retryable_pause(n):
        if n:
            raise Exception
        return n

    @retry(retries=3)
    def func_retryable_default():
        n = 1
        if n:
            raise Exception
        return n

    # Test retryable function that retries based on the return value
    with pytest.raises(Exception) as excinfo:
        assert func_retryable(1) == 0
    assert "Retry limit exceeded: 3" in str(excinfo.value)

    assert func_retryable(0) == 0

    #

# Generated at 2022-06-22 21:13:18.991771
# Unit test for function retry_never
def test_retry_never():
    # For now, simply run and make sure there are no exceptions
    retry_with_delays_and_condition([], retry_never)(lambda x: x)('foo')

# Generated at 2022-06-22 21:13:26.659325
# Unit test for function retry
def test_retry():
    """Retry tests"""
    class FailError(Exception):
        """FailError"""
        pass

    class Fail(object):
        """Fail"""
        def __init__(self, retries):
            """Fail"""
            self.retries = retries

        @retry(retries=2)
        def exception(self):
            """exception"""
            self.retries -= 1
            if self.retries > 0:
                raise FailError('exception')
            return True

        @retry(retries=2)
        def failure(self):
            """failure"""
            self.retries -= 1
            if self.retries > 0:
                return False
            return True

    fail = Fail(2)
    fail.exception()
    fail.failure()

# Generated at 2022-06-22 21:13:30.968234
# Unit test for function retry_never
def test_retry_never():
    """Function retry_never always return False"""
    result = retry_never("sometest")
    assert result is False


# Generated at 2022-06-22 21:13:36.125692
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    gjb = generate_jittered_backoff()
    del1 = next(gjb)
    del2 = next(gjb)
    del3 = next(gjb)
    del4 = next(gjb)
    del5 = next(gjb)
    assert del1 < 3
    assert del2 < 6
    assert del3 < 12
    assert del4 < 24
    assert del5 < 60

# Generated at 2022-06-22 21:13:37.429427
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert isinstance(rate_limit_argument_spec(), dict)


# Generated at 2022-06-22 21:13:42.327950
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    expected_result = [0, 0, 0, 0, 0, 0, 5, 9, 19, 54]
    result = []
    for delay in generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60):
        result.append(delay)
    assert expected_result == result

# Generated at 2022-06-22 21:13:44.181392
# Unit test for function retry
def test_retry():
    @retry(5, 1)
    def call_retryable_function():
        print("Called")
        raise Exception("We are retrying")

    call_retryable_function()

# Generated at 2022-06-22 21:13:51.758351
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """This code returns a dictionary that can be used to define an argument_spec
    """
    arg_spec = basic_auth_argument_spec()

    expected_arg_spec = {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }
    
    assert arg_spec == expected_arg_spec


# Generated at 2022-06-22 21:13:53.667554
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=60)
    def f():
        pass
    for i in range(0, 100):
        f()


# Generated at 2022-06-22 21:13:58.105898
# Unit test for function retry_never
def test_retry_never():
    @retry_with_delays_and_condition([])
    def thrower():
        raise Exception('Dummy exception')
    try:
        thrower()
    except Exception:
        pass
    else:
        assert False, 'Should have failed because of exception'



# Generated at 2022-06-22 21:14:01.622543
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert 'api_username' in spec
    assert 'api_password' in spec
    assert 'api_url' in spec
    assert spec['api_password'].get('no_log')

# Generated at 2022-06-22 21:14:05.330626
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=5, rate_limit=5)
    def f():
        return 1

    assert(f() == 1 and f() == 1 and f() == 1 and f() == 1 and f() == 1)
    assert(f() is None)


# Generated at 2022-06-22 21:14:10.681065
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec(spec=dict(test=dict(type='int'))) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}, 'test': {'type': 'int'}}

# Generated at 2022-06-22 21:14:17.747786
# Unit test for function rate_limit
def test_rate_limit():
    import time

    @rate_limit(3, 5)
    def f1(x):
        return x

    @rate_limit(5, 5)
    def f2(x):
        return x

    t0 = time.time()
    for i in range(0, 10):
        f1(i)
        f2(i)

    print('Took %s seconds' % (time.time() - t0))
    assert (time.time() - t0) > 5  # it should have been rate limited



# Generated at 2022-06-22 21:14:19.779773
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("testing")) == False
    assert retry_never("testing") == False


# Generated at 2022-06-22 21:14:30.325954
# Unit test for function retry
def test_retry():
    times_called = 0

    @retry(retries=10)
    def raise_exception():
        nonlocal times_called
        times_called += 1
        raise Exception("foo")

    def return_value():
        nonlocal times_called
        times_called += 1
        return 1

    @retry(retries=None)
    def raise_exception_no_limit():
        nonlocal times_called
        times_called += 1
        raise Exception("foo")

    raise_exception()
    assert times_called == 10

    return_value()
    assert times_called == 1

    raise_exception_no_limit()
    assert times_called == 2



# Generated at 2022-06-22 21:14:33.029929
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    iterator = generate_jittered_backoff()
    delays = [next(iterator) for i in range(10)]
    print(delays)

# Generated at 2022-06-22 21:14:43.843466
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """Test usage of basic_auth_argument_spec"""
    argument_spec = basic_auth_argument_spec()
    assert argument_spec == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }

    argument_spec = basic_auth_argument_spec(spec={'new_key': {'type': 'str'}})

# Generated at 2022-06-22 21:14:46.647595
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='int', default=1),
    ))
    assert retry_argument_spec() == arg_spec

# Generated at 2022-06-22 21:14:57.586332
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    class TestRateLimit(unittest.TestCase):
        def test_rate_limit(self):
            from ansible.module_utils.basic import get_exception
            from ansible.module_utils.api import rate_limit
            import time
            import random

            rate_limit_decorator = rate_limit(rate=None, rate_limit=None)
            rate1 = 10
            rate2 = 50
            rate_limit1 = 100
            rate_limit2 = 1000
            iterations = 100
            rate_limit_decorator = rate_limit(rate=rate1, rate_limit=rate_limit1)
            v = {}
            errors = []
            @rate_limit_decorator
            def rate_limit_test():
                rate_limit_test.count += 1

# Generated at 2022-06-22 21:15:06.052073
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for num_retries in [5, 10, 20]:
        for delay_base in [1, 2, 3, 4, 5]:
            for delay_threshold in [0, 1, 5, 10, 20, 60]:
                delays = list(generate_jittered_backoff(num_retries, delay_base, delay_threshold))
                last_delay = 0
                for delay in delays:
                    # Check that result is within specified bounds
                    assert delay <= delay_threshold
                    assert delay >= 0
                    if last_delay > 0:
                        # Check that the result increases monotonically
                        assert delay >= last_delay
                    last_delay = delay

                # Check that result has expected length
                assert len(delays) == num_retries



# Generated at 2022-06-22 21:15:11.199379
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def should_retry_error(exception):
        if isinstance(exception, RuntimeError):
            return True
        return False

    retry_decorator = retry_with_delays_and_condition(generate_jittered_backoff(5), should_retry_error)

    @retry_decorator
    def f():
        raise RuntimeError('Test runtime error')

    raised = False
    try:
        f()
    except RuntimeError:
        raised = True
    assert raised, 'Expected to raise RuntimeError'


# Generated at 2022-06-22 21:15:15.945796
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=1))
    def _retry():
        1 / 0

    try:
        _retry()
    except ZeroDivisionError:
        pass

# Generated at 2022-06-22 21:15:17.847726
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert 'rate_limit' in rate_limit_argument_spec()


# Generated at 2022-06-22 21:15:28.102156
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # should_retry_error will determine if the error is retriable or not
    should_retry_error = lambda e: isinstance(e, Exception)

    # We want to retry only once
    backoff_iterator = [0, 10]

    # This is the function the decorator wraps.
    # The lambda is used to raise the Exception and avoid using a separate function.
    def function():
        raise Exception()
    wrapped_function = retry_with_delays_and_condition(backoff_iterator, should_retry_error)(function)

    # There should be only two calls: the initial one and the retry
    assert wrapped_function.__wrapped__.call_count == 0
    wrapped_function()
    assert wrapped_function.__wrapped__.call_count == 2



# Generated at 2022-06-22 21:15:31.598363
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert 'retries' in spec
    assert 'retry_pause' in spec
    assert spec['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:15:35.557730
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    test_spec = dict(some_setting=dict(type='int'))
    result = rate_limit_argument_spec(spec=test_spec)
    expected = dict(rate=dict(type='int'), rate_limit=dict(type='int'), some_setting=dict(type='int'))
    assert(result == expected)



# Generated at 2022-06-22 21:15:46.052064
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Passing no arguments should return an empty dict
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )
    # Passing dict should return dict with dict appended to it
    assert basic_auth_argument_spec({'foo': 'bar'}) == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        foo=dict(type='bar'),
    )



# Generated at 2022-06-22 21:15:56.591528
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit"""
    import os.path
    import subprocess

    @rate_limit(rate=10, rate_limit=100)
    def test_rate(*args, **kwargs):
        """raises an error every time its called"""
        raise Exception("RATE LIMIT TEST")

    @retry(retries=5, retry_pause=.5)
    def test_rate_limited(*args, **kwargs):
        """rate limit test"""
        test_rate(*args, **kwargs)

    if not os.path.exists('test/test_rate_limit.py'):
        raise Exception("test_rate_limit.py not found")


# Generated at 2022-06-22 21:16:07.656904
# Unit test for function rate_limit
def test_rate_limit():
    import time

    class T(object):
        def __init__(self):
            self.stats = []

        @rate_limit(2, 3)
        def f(self, n):
            time.sleep(n)  # ensure that the rate limiter works
            self.stats.append(time.time())

    t = T()
    t.f(0.5)
    t.f(0.5)
    t.f(0.5)
    t.f(0.5)
    t.f(0.5)
    t.f(0.5)

    assert len(t.stats) == 6
    assert t.stats[0] == t.stats[1]
    assert t.stats[2] - t.stats[1] >= 1
    assert t.stats[3] - t.stats

# Generated at 2022-06-22 21:16:16.457092
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class TestRetryWithDelaysAndCondition(unittest.TestCase):
        def test_always_retry(self):
            function_retries = 0
            retryable_function_delay = 1
            backoff_iterator_delays = [0, 1]

            def backoff_iterator():
                for delay in backoff_iterator_delays:
                    yield delay

            @retry_with_delays_and_condition(backoff_iterator, retry_never)
            def retryable_function():
                """This function has not yet been called."""
                nonlocal function_retries
                function_retries += 1

                time.sleep(retryable_function_delay)

                if function_retries == len(backoff_iterator_delays):
                    return "end result"

# Generated at 2022-06-22 21:16:20.239592
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    expected_results = [0, 0, 0, 1, 0, 0, 1, 3, 3, 3]

    for result in zip(generate_jittered_backoff(), expected_results):
        assert result[0] == result[1]


# Generated at 2022-06-22 21:16:28.293985
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    gen = generate_jittered_backoff(retries=random.randint(1, 100), delay_base=random.randint(1, 10), delay_threshold=random.randint(10, 100))
    delays = []
    for delay in gen:
        delays.append(delay)

    # Check the jitter values are within the given limits
    assert all([delay >= 0 for delay in delays])
    assert all([delay <= 40 for delay in delays])

    # Check the length is correct across the different retry amounts
    assert len(delays) == random.randint(1, 100)

# Generated at 2022-06-22 21:16:32.732874
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module_args = {}
    module_args.update(basic_auth_argument_spec())
    print(module_args)
    assert module_args['api_username'] == dict(type='str')
    assert module_args['api_password'] == dict(type='str', no_log=True)
    assert module_args['api_url'] == dict(type='str')
    assert module_args['validate_certs'] == dict(type='bool', default=True)
    assert len(module_args) == 4


# Generated at 2022-06-22 21:16:43.125911
# Unit test for function retry_with_delays_and_condition

# Generated at 2022-06-22 21:16:49.385922
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Make sure that generated delays are all unique.
    # The function generate_jittered_backoff(retries=10) generates a list of 10 values and the probability that any of these values is duplicated is small.
    delays = []
    for delay in generate_jittered_backoff(retries=10):
        assert delay not in delays
        delays.append(delay)

# Generated at 2022-06-22 21:16:54.390030
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {'api_url': {'type': 'str'},
                                          'api_username': {'type': 'str'},
                                          'api_password': {'type': 'str', 'no_log': True},
                                          'validate_certs': {'type': 'bool', 'default': True}}

# Generated at 2022-06-22 21:17:06.083736
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestException(Exception):
        pass
    class RetryThisException(Exception):
        pass
    class DoNotRetryThisException(Exception):
        pass

    def should_retry_error(e):
        return isinstance(e, RetryThisException)

    def return_hello():
        return 'hello'

    def always_raise_TestException():
        raise TestException()

    def always_raise_RetryThisException():
        raise RetryThisException()

    def always_raise_DoNotRetryThisException():
        raise DoNotRetryThisException()

    def always_return_none():
        return None


# Generated at 2022-06-22 21:17:12.246013
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def foo():
        print("foo")
        return True
    retry_foo = retry_with_delays_and_condition(generate_jittered_backoff(retries=10), retry_never)
    assert retry_foo(foo) == True
    # Test that the decorator works on the decorated function
    assert retry_foo.__name__ == "foo"
    assert retry_foo.__doc__ == foo.__doc__
    assert retry_foo.__module__ == foo.__module__

# Generated at 2022-06-22 21:17:17.254800
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Test with default values
    generated_delays = list(generate_jittered_backoff())
    assert generated_delays == [0, 3, 3, 3, 3, 3, 3, 0, 0, 3]
    # Test with changing values
    generated_delays = list(generate_jittered_backoff(20, 10, 120))
    assert generated_delays[-1] == 79

# Generated at 2022-06-22 21:17:26.306240
# Unit test for function rate_limit
def test_rate_limit():
    """Run unit tests on api.rate_limit"""

    import time

    @rate_limit(rate=1, rate_limit=2)  # 1/2 => 0.5
    def rate_limited_function():
        time.sleep(0.01)

    start = time.time()

    rate_limited_function()
    delta = time.time() - start
    assert 0 < delta <= 0.5, "First call @ 0.5/f: %f" % delta

    rate_limited_function()
    delta = time.time() - start
    assert delta > 0.5, "Second call @ 0.5/f: %f" % delta

    rate_limited_function()
    delta = time.time() - start
    assert delta > 1.0, "Third call @ 0.5/f: %f" % delta

# Generated at 2022-06-22 21:17:28.804215
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    expected = (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    ))
    assert result == expected


# Generated at 2022-06-22 21:17:39.317367
# Unit test for function retry
def test_retry():
    # call the test function and assert the data is what we expect.
    import six
    @retry(retries=5, retry_pause=0.1)
    def run_test():
        if run_test.calls_made == 0:
            run_test.calls_made += 1
            raise Exception('Test Exception')
        else:
            return True

    run_test.calls_made = 0
    assert run_test()

    # Do the same but with a max calls.
    @retry(retries=3, retry_pause=0.1)
    def run_test():
        run_test.calls_made += 1
        raise Exception('Test Exception')

    run_test.calls_made = 0

# Generated at 2022-06-22 21:17:50.930238
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Normal case
    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    def func(count, fail_at=None):
        count[0] += 1
        if fail_at is not None and count[0] == fail_at:
            raise Exception("Failed")
        return count

    # First 2 attempts fail, final attempt succeeds
    count = [0]
    assert func(count=count, fail_at=2) == [3]
    # Always succeeds
    count = [0]
    assert func(count=count, fail_at=None) == [1]
    # Never succeeds
    count = [0]

# Generated at 2022-06-22 21:17:57.153061
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    # Create a spec for the custom module
    arg_spec = (dict(
        logfile=dict(type='str'),
    ))
    # Apply the rate limit spec
    arg_spec.update(rate_limit_argument_spec())
    assert arg_spec.get('rate') is not None
    assert arg_spec.get('rate_limit') is not None
    assert arg_spec.get('logfile') is not None

# Generated at 2022-06-22 21:18:08.637314
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class DummyException(Exception): pass

    RETRIES = 3
    # Choose a base value that should be large enough to ensure that
    # the resulting sum is always larger than the chosen test value
    # for `LARGE_VALUE`
    BASE_VALUE = 3.0
    LARGE_VALUE = 16.0

    def test_backoff(retries=None):
        return generate_jittered_backoff(retries=retries)

    @retry_with_delays_and_condition(test_backoff(RETRIES))
    def function_to_retry_on_error(number_of_attempts=0, raise_error=False):
        number_of_attempts += 1
        if raise_error:
            raise DummyException("Test Exception")

        return number_of_attempts

   

# Generated at 2022-06-22 21:18:17.498238
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}
    assert rate_limit_argument_spec({"a": "b"}) == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}, "a": "b"}

    # Test for backwards compatibility with the old rate_limit parameter
    assert rate_limit_argument_spec({"rate_limit": "b"}) == {'rate': {'type': 'int'}, 'rate_limit': 'b'}



# Generated at 2022-06-22 21:18:26.211448
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def function_wrapper_with_retries(number_of_retries):
        backoff_iterator = generate_jittered_backoff(retries=number_of_retries, delay_base=0.1)

        @retry_with_delays_and_condition(backoff_iterator=backoff_iterator)
        def f(number_of_retries):
            raise Exception("Error")

        return f

    f = function_wrapper_with_retries(number_of_retries=10)
    with pytest.raises(Exception):
        f(10)

    f = function_wrapper_with_retries(number_of_retries=0)
    with pytest.raises(Exception):
        f(0)

# Generated at 2022-06-22 21:18:34.289581
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=10)
    def func(message):
        print(message + " -> " + time.asctime())

    previous = time.time()
    func("start")
    previous = time.time()
    func("middle")
    previous = time.time()
    func("middle2")
    previous = time.time()
    func("middle3")
    previous = time.time()
    func("middle4")
    previous = time.time()
    func("end")



# Generated at 2022-06-22 21:18:45.765417
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {
            'rate': {'type': 'int'},
            'rate_limit': {'type': 'int'},
    }
    assert rate_limit_argument_spec({}) == {
            'rate': {'type': 'int'},
            'rate_limit': {'type': 'int'},
    }
    assert rate_limit_argument_spec({'foo': 'bar'}) == {
            'rate': {'type': 'int'},
            'rate_limit': {'type': 'int'},
            'foo': 'bar'
    }

# Generated at 2022-06-22 21:18:56.495867
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import itertools
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def function(run_count, exception_run_count, raise_exception):
        nonlocal run_count
        nonlocal exception_run_count
        nonlocal raise_exception
        run_count += 1

        if raise_exception:
            exception_run_count += 1
            raise Exception("An exception.")

    # Successful function call, should not retry
    run_count = 0
    exception_run_count = 0
    raise_exception = False
    function(run_count, exception_run_count, raise_exception)
    assert run_count == 1
    assert exception_run_count == 0
    # Exception raised and should retry
    run_count = 0
    exception_run

# Generated at 2022-06-22 21:19:07.307711
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import api

    arg_spec = api.retry_argument_spec()

    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True)
    assert module.params.get('retries') == 10
    assert module.params.get('retry_pause') == 1

    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True, retries=5)
    assert module.params.get('retries') == 5
    assert module.params.get('retry_pause') == 1

    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True, retries=5, retry_pause=1)

# Generated at 2022-06-22 21:19:14.096738
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    expected = [0, 4, 5, 9, 10, 11, 16, 17, 18, 20, 26, 31, 36, 40, 46, 51]
    actual_backoff = list(generate_jittered_backoff(retries=16, delay_base=3, delay_threshold=60))
    assert (expected == actual_backoff)

# Generated at 2022-06-22 21:19:23.825249
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Setup
    module = MockModule()
    module.params['api_username'] = 'ansible_test'
    module.params['api_password'] = 'Ansible_Test'
    module.params['api_url'] = 'https://test.com'
    module.params['validate_certs'] = 'false'
    # Execute
    result = basic_auth_argument_spec(module)
    # Verify
    assert result
    assert result['api_username'] == 'ansible_test'
    assert result['api_password'] == 'Ansible_Test'
    assert result['api_url'] == 'https://test.com'
    assert result['validate_certs'] == 'false'


# Generated at 2022-06-22 21:19:26.007506
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff = generate_jittered_backoff()
    for i in range(0, 10):
        assert 0 <= next(backoff) <= 3



# Generated at 2022-06-22 21:19:29.168654
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert(len(basic_auth_argument_spec().keys()) == 4)

# Generated at 2022-06-22 21:19:38.057733
# Unit test for function rate_limit
def test_rate_limit():
    """rate limiting decorator test"""
    import time

    def get_time():
        return time.time()
    rate = 2
    rate_limit = 30
    minrate = float(rate_limit) / float(rate)

    # decorate get_time with rate_limit
    rate_limited_get_time = rate_limit(rate, rate_limit)(get_time)

    # 4 requests
    start = time.time()
    rate_limited_get_time()
    rate_limited_get_time()
    rate_limited_get_time()
    rate_limited_get_time()
    end = time.time()
    diff = end - start
    assert minrate < diff < minrate * 2
    time.sleep(minrate * 2)

    # now we should be able to call as fast as we want
    start