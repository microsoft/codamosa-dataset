

# Generated at 2022-06-22 21:09:40.454230
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert(basic_auth_argument_spec() == {'api_username': {'type': 'str'},
                                          'api_password': {'type': 'str',
                                                           'no_log': True},
                                          'api_url': {'type': 'str'},
                                          'validate_certs': {'type': 'bool',
                                                             'default': True}})


# Generated at 2022-06-22 21:09:42.310567
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("") is False
    assert retry_never("abc") is False



# Generated at 2022-06-22 21:09:48.172011
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        foo=dict(type='str'),
        bar=dict(type='str'),
    )
    arg_spec = rate_limit_argument_spec(spec)
    expected_result = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        foo=dict(type='str'),
        bar=dict(type='str'),
    )
    assert arg_spec == expected_result



# Generated at 2022-06-22 21:09:58.827609
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    class TestRateLimit(unittest.TestCase):

        def setUp(self):
            self.rate = 1
            self.rate_limit = 10
            self.time_spent = 0.0
            self.calls = 10

            self.decorated = rate_limit(rate=self.rate, rate_limit=self.rate_limit)(self.function)

        def function(self):
            self.time_spent += 1.0

        def test_rate_limit(self):
            for i in range(self.calls):
                self.decorated()
            self.assertAlmostEqual(self.time_spent, self.calls * self.rate_limit, delta=self.rate)


# Generated at 2022-06-22 21:10:01.424486
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception)
    assert not retry_never(42)
    assert not retry_never(False)

# Generated at 2022-06-22 21:10:08.774727
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    required_spec = {
        "api_username": {"type": "str"},
        "api_password": {"type": "str", "no_log": True},
        "api_url": {"type": "str"},
        "validate_certs": {"type": "bool", "default": True}
    }
    assert basic_auth_argument_spec() == required_spec
    assert basic_auth_argument_spec({'api_url': {'type': 'str'}}) == required_spec

# Generated at 2022-06-22 21:10:10.447689
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff(3, 1, 10):
        print(delay)

# Generated at 2022-06-22 21:10:19.398881
# Unit test for function rate_limit
def test_rate_limit():
    rate_limit_test_rate = 1000
    rate_limit_test_time = 30
    rate_limit_test_number_of_calls = 100000
    rate_limit_test_total_time = 0

    # Create timer function
    if sys.version_info >= (3, 8):
        rate_limit_time = time.process_time
    else:
        rate_limit_time = time.clock

    # Create rate limited function
    @rate_limit(rate=rate_limit_test_rate, rate_limit=rate_limit_test_time)
    def rate_limited_function(a, b):
        return a + b

    # Create rate limited function

# Generated at 2022-06-22 21:10:28.474312
# Unit test for function retry
def test_retry():  # noqa: F811
    # Retry should raise an exception
    retries = 3
    @retry(retries, retry_pause=0.5)
    def test_false():
        return False

    success = False
    try:
        test_false()
    except Exception:
        success = True

    assert success == True

    # Retry should not raise an exception
    @retry(retries, retry_pause=0.5)
    def test_true():
        return True

    success = True
    try:
        test_true()
    except Exception:
        success = False

    assert success == True

# Generated at 2022-06-22 21:10:31.151875
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never("toto")
    assert not retry_never("toto")


# Unit tests for function retry_with_delays_and_condition

# Generated at 2022-06-22 21:10:41.699410
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = {'foo': {'type': 'int'},
            'bar': {'type': 'str', 'required': True}}
    new_spec = rate_limit_argument_spec(spec)
    assert isinstance(new_spec, dict)
    assert 'rate' in new_spec
    assert 'rate_limit' in new_spec
    assert new_spec['rate']['type'] == 'int'
    assert new_spec['rate_limit']['type'] == 'int'
    assert 'foo' in new_spec
    assert 'bar' in new_spec
    assert new_spec['foo']['type'] == 'int'
    assert new_spec['bar']['type'] == 'str'
    assert new_spec['bar']['required'] == True


# Generated at 2022-06-22 21:10:49.885601
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # test default values
    spec = retry_argument_spec()
    assert 'retries' in spec
    assert spec['retries']['type'] == 'int'

    assert 'retry_pause' in spec
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1

    # test multiple arg_spec
    spec = retry_argument_spec(dict(foo=dict(default='bar')))
    assert 'foo' in spec
    assert spec['foo']['default'] == 'bar'


# Generated at 2022-06-22 21:10:56.105584
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition([1, 2], should_retry_error=retry_never)
    def raise_exception():
        raise Exception("Retryable exception")

    try:
        raise_exception()
    except Exception as e:
        assert str(e) == "Retryable exception"
    else:
        raise Exception("Should have thrown exception")

    @retry_with_delays_and_condition([1, 2], should_retry_error=retry_never)
    def return_value():
        return "Success!"

    assert return_value() == "Success!"

# Generated at 2022-06-22 21:11:05.648379
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class SomeException(Exception):
        pass

    class RetryException(Exception):
        pass

    # no delays, only function call once (default behavior)
    @retry_with_delays_and_condition(iter([]))
    def no_delay():
        raise SomeException

    with pytest.raises(SomeException):
        no_delay()

    # delays are used, the first exception is ignored and the second one is raised.
    @retry_with_delays_and_condition([1, 1], should_retry_error=lambda e: isinstance(e, SomeException))
    def function_with_delays():
        raise RetryException

    with pytest.raises(RetryException):
        function_with_delays()

    # generate delays using the exponential backoff strategy

# Generated at 2022-06-22 21:11:14.299408
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.api import basic_auth_argument_spec, rate_limit_argument_spec, retry_argument_spec
    argument_spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        validate_certs=dict(type='bool', default=True)
    )
    spec_rate = dict(rate=dict(type='int'), rate_limit=dict(type='int'))

# Generated at 2022-06-22 21:11:19.643776
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=2, delay_base=0.5, delay_threshold=3))
    def inner(tries):
        if tries > 0:
            tries -= 1
            return tries
        raise RuntimeError('blah')
    inner(2)

# Generated at 2022-06-22 21:11:26.185975
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        param1=dict(type='str'),
        param2=dict(type='bool')
    )
    arg_spec = dict(
        param1=dict(type='str'),
        param2=dict(type='bool'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    assert retry_argument_spec(spec) == arg_spec

# Generated at 2022-06-22 21:11:34.826044
# Unit test for function rate_limit
def test_rate_limit():
    ''' test rate_limit function '''
    def foo():
        ''' foo '''
        print("I'm foo")
        return 'foo'

    @rate_limit(rate=1, rate_limit=1)
    def foo_rate_limited():
        ''' wrapped foo'''
        print("I'm foo")
        return 'foo'

    # foo should never be limited
    start = time.time()
    foo()
    first = time.time() - start
    start = time.time()
    foo()
    second = time.time() - start
    # the actual delay might be up to 1 second because the
    # function takes some time to run
    assert first < 0.9
    assert second < 0.9
    # foo_rate_limited should be beetween 1 and 2 second delay
    start = time.time

# Generated at 2022-06-22 21:11:40.876711
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec(dict(
        other=dict(required=True),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    ))
    assert isinstance(spec, dict)
    assert 'other' in spec
    assert spec['other']['required'] is True
    assert 'rate' in spec
    assert 'rate_limit' in spec
    assert spec['rate']['type'] == 'int'
    assert spec['rate_limit']['type'] == 'int'

# Generated at 2022-06-22 21:11:50.760949
# Unit test for function retry
def test_retry():

    time.process_time = time.clock
    last = [0.0]

    @retry(retries=2, retry_pause=1)
    @rate_limit(rate_limit=3, rate=1)
    def run():
        if sys.version_info >= (3, 8):
            real_time = time.process_time
        else:
            real_time = time.clock

        elapsed = real_time() - last[0]
        left = 1 - elapsed
        if left > 0:
            time.sleep(left)
        last[0] = real_time()
        return True

    assert True == run()

# Generated at 2022-06-22 21:11:53.772367
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff()
    last = 0
    for delay in backoff_iterator:
        assert delay >= 0
        assert delay <= 3
        assert delay >= last
        last = delay

# Generated at 2022-06-22 21:11:55.993417
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    args = dict(
        retries=10,
        retry_pause=2,
    )
    assert retry_argument_spec() == args



# Generated at 2022-06-22 21:12:05.478950
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """
    Test function basic_auth_argument_spec.
    """
    spec = dict(host=dict(type='str', default='localhost'),
                port=dict(type='int', default=80),
                protocol=dict(type='str', default='https'))
    arg_spec = basic_auth_argument_spec(spec=spec)

# Generated at 2022-06-22 21:12:13.437495
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict()

    result = rate_limit_argument_spec(spec)
    expected = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert result == expected

    spec = dict(newarg=dict(type='int'))
    result = rate_limit_argument_spec(spec)
    expected = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        newarg=dict(type='int')
    )
    assert result == expected



# Generated at 2022-06-22 21:12:14.298066
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception)

# Generated at 2022-06-22 21:12:17.455416
# Unit test for function retry
def test_retry():
    @retry(retries=2)
    def doit():
        print("Doing it...")
        return True
    doit()


# Generated at 2022-06-22 21:12:22.853469
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    expected_result = {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }
    assert expected_result == basic_auth_argument_spec()
    

if __name__ == '__main__':
    test_basic_auth_argument_spec()

# Generated at 2022-06-22 21:12:32.686691
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    arg_spec = (dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    ))
    test_module = AnsibleModule(rate_limit_argument_spec(arg_spec))
    assert test_module.params['rate'] == 0
    assert test_module.params['rate_limit'] == 0
    assert test_module.params['api_username'] == ''
    assert test_module.params['api_password'] == ''
    assert test_module.params['api_url'] == ''
    assert test_module.params['validate_certs'] is True



# Generated at 2022-06-22 21:12:40.155549
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # make sure basic_auth_argument_spec() works as expected
    from ansible.module_utils.basic import AnsibleModule
    basic_auth_argument_spec_dict = basic_auth_argument_spec()
    test_module = AnsibleModule({}, **basic_auth_argument_spec_dict)
    assert test_module.params['api_url'] == 'https://localhost'
    assert test_module.params['api_username'] is None
    assert test_module.params['api_password'] is None
    assert test_module.params['validate_certs'] is True
    # test not mutating the module
    assert basic_auth_argument_spec_dict == basic_auth_argument_spec()

# Generated at 2022-06-22 21:12:45.839417
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60):
        assert(0 <= delay <= 60)
    for delay in generate_jittered_backoff(retries=100000, delay_base=3, delay_threshold=60):
        assert(0 <= delay <= 60)



# Generated at 2022-06-22 21:12:55.451473
# Unit test for function rate_limit
def test_rate_limit():
    from functools import partial
    from unittest import TestCase, mock

    class RateLimitTest(TestCase):
        def setUp(self):
            self.mock_sleep = mock.patch('time.sleep').start()
            self.mock_time = mock.patch('time.clock').start()
            self.mock_time.side_effect = [0, 1.1]
            self.rate_limited_f = rate_limit(2, 1)(partial(lambda x: x))

        def tearDown(self):
            mock.patch.stopall()

        def test_rate_limit_by_amount(self):
            self.rate_limited_f()

            self.mock_sleep.assert_called_once_with(0.05)


# Generated at 2022-06-22 21:13:00.208090
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoffs = [2, 3, 1, 0, 0, 1, 0, 2, 1, 2] # based on seed=786
    gen = generate_jittered_backoff(retries=len(backoffs), seed=786)
    assert list(gen) == backoffs

# Generated at 2022-06-22 21:13:05.267859
# Unit test for function rate_limit
def test_rate_limit():
    import datetime
    import time

    @rate_limit(rate=1, rate_limit=3)
    def decorate_me(x):
        return x

    start_time = time.time()
    for i in range(0,10):
        decorate_me(i)
    end_time = time.time()
    assert (end_time - start_time) >= 3



# Generated at 2022-06-22 21:13:08.576361
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()

    assert arg_spec == {
        'retries': {'type': 'int'},
        'retry_pause': {'default': 1, 'type': 'float'}
    }



# Generated at 2022-06-22 21:13:12.711478
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg = retry_argument_spec()
    assert isinstance(arg, dict)
    assert isinstance(arg['retries'], dict)
    assert isinstance(arg['retry_pause'], dict)
    assert arg['retry_pause']['type'] == 'float'
    assert arg['retry_pause']['default'] == 1
    assert arg['retries']['type'] == 'int'


# Generated at 2022-06-22 21:13:22.862915
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule

    # Test without any parameters
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    assert module.params['api_username'] is None
    assert module.params['api_password'] is None
    assert module.params['api_url'] is None
    assert module.params['validate_certs'] is True

    # Test with parameters
    module = AnsibleModule(argument_spec=basic_auth_argument_spec(spec=dict(api_username=dict(required=True))))
    assert module.params['api_username'] is None
    assert module.params['api_password'] is None
    assert module.params['api_url'] is None
    assert module.params['validate_certs'] is True


# Generated at 2022-06-22 21:13:25.281170
# Unit test for function retry_never
def test_retry_never():
    obj = ()
    assert not retry_never(obj)



# Generated at 2022-06-22 21:13:27.461194
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert 'rate' in rate_limit_argument_spec() and 'rate_limit' in rate_limit_argument_spec()


# Generated at 2022-06-22 21:13:30.856781
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(
            required=False,
            type='int'
        ),
        retry_pause=dict(
            default=1,
            required=False,
            type='float'
        )
    )

# Generated at 2022-06-22 21:13:39.510406
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import datetime
    import unittest

    test_time = datetime.datetime(2020, 7, 21, 1, 2, 3)

    def test_should_retry(unused_exception):
        return True

    def test_should_not_retry(unused_exception):
        return False

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=4), should_retry_error=test_should_not_retry)
    def test_function_no_retry_error():
        return 'success'

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=4), should_retry_error=test_should_retry)
    def test_function(time_override):
        time

# Generated at 2022-06-22 21:13:46.569146
# Unit test for function retry
def test_retry():
    # Success after first attempt
    @retry()
    def attempt1():
        return True

    assert attempt1()

    # Success after third attempt
    @retry(retries=3, retry_pause=1)
    def attempt3():
        attempt3.attempt += 1
        if attempt3.attempt < 3:
            raise Exception("Retry")
        return True

    attempt3.attempt = 0

    assert attempt3()
    assert attempt3.attempt == 3

# Generated at 2022-06-22 21:13:58.278557
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    num_retries = 0
    num_failures = 0

    # The "Full Jitter" backoff strategy.
    # Ref: https://www.awsarchitectureblog.com/2015/03/backoff.html
    backoff_iterator = generate_jittered_backoff(retries=5, delay_base=2)

    # Always retry and allow unit test to modify retry count
    def always_retry(exception):
        global num_retries
        num_retries += 1
        return True

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error=always_retry)
    def retry_on_error():
        global num_failures
        num_failures += 1
        raise Exception('Test failure')


# Generated at 2022-06-22 21:14:01.454090
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    my_module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    my_module.exit_json(changed=True, result="basic_auth_argument_spec() ran without error")

# Generated at 2022-06-22 21:14:07.634734
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    result = [i for i in generate_jittered_backoff()]
    expected = [0, 0, 1, 6, 3, 30, 15, 60, 60, 60]

    for a, b in zip(expected, result):
        assert a == b

    result_retries = [i for i in generate_jittered_backoff(retries=3)]
    expected_retries = [0, 0, 1, 10]

    for a, b in zip(expected_retries, result_retries):
        assert a == b



# Generated at 2022-06-22 21:14:13.821617
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(foo=dict(type='str'))
    result = rate_limit_argument_spec(spec)
    rate_args = result.pop('rate', None)
    assert rate_args is not None
    rate_limit_args = result.pop('rate_limit', None)
    assert rate_limit_args is not None
    assert result == spec


# Generated at 2022-06-22 21:14:22.344858
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff = list(generate_jittered_backoff(retries=3))
    assert len(backoff) == 3
    assert backoff[0] <= 3
    assert backoff[1] <= 6
    assert backoff[2] <= 12

    backoff = list(generate_jittered_backoff(retries=3, delay_base=2))
    assert len(backoff) == 3
    assert backoff[0] <= 2
    assert backoff[1] <= 4
    assert backoff[2] <= 8

    backoff = list(generate_jittered_backoff(retries=3, delay_base=2, delay_threshold=5))
    assert len(backoff) == 3
    assert backoff[0] <= 2
    assert backoff[1] <= 4
    assert backoff[2]

# Generated at 2022-06-22 21:14:31.610684
# Unit test for function retry
def test_retry():
    """
    Ensure we retry the expected number of times,
    that we pause the expected time,
    and we don't retry more than expected.
    """
    tries = []
    pause = []

    def retryable_func():
        tries.append(1)
        if len(tries) < 5:
            raise Exception("Retry")

    @retry(retries=10, retry_pause=12)
    def retry_10_times_with_12_seconds_pause():
        pause.append(1)
        retryable_func()

    retry_10_times_with_12_seconds_pause()
    assert len(tries) == 5
    assert len(pause) == 5

# Generated at 2022-06-22 21:14:36.314384
# Unit test for function retry
def test_retry():
    def my_func():
        raise Exception("test exception")

    @retry(1, 0)
    def my_retry_func():
        my_func()

    try:
        my_retry_func()
        assert False # This should raise an exception
    except Exception as e:
        assert(str(e) == "test exception")

# Generated at 2022-06-22 21:14:39.211949
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(retries=dict(type='int'), retry_pause=dict(type='float', default=1))


# Generated at 2022-06-22 21:14:46.938068
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    ret = rate_limit_argument_spec()
    assert ret['rate']['type'] == 'int'
    assert ret['rate_limit']['type'] == 'int'

    ret = rate_limit_argument_spec({'auth_url': {'type': 'str', 'required': True}})
    assert ret['auth_url']['type'] == 'str'
    assert ret['auth_url']['required'] is True
    assert ret['rate']['type'] == 'int'
    assert ret['rate_limit']['type'] == 'int'



# Generated at 2022-06-22 21:14:48.637672
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) is False

# Generated at 2022-06-22 21:14:55.100097
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff = [1, 2, 3, 4, 5]

    @retry_with_delays_and_condition(backoff)
    def raise_exception():
        raise KeyError("key error!")

    with pytest.raises(KeyError) as excinfo:
        raise_exception()
    assert "key error!" in str(excinfo.value)

    retries = -1  # Number of retries the decorated function will have had.
    @retry_with_delays_and_condition(backoff, lambda x: True)
    def first_raise_exception():
        nonlocal retries
        retries += 1
        raise KeyError("first key error!")


# Generated at 2022-06-22 21:15:03.582975
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class MyRetryableError(Exception):
        pass
    class MyFatalError(Exception):
        pass

    def function(success, fail_with_fatal, fail_with_retryable, fail_and_succeed_with_retryable):
        if fail_with_fatal:
            raise MyFatalError
        if fail_with_retryable:
            raise MyRetryableError
        if fail_and_succeed_with_retryable:
            raise MyRetryableError
            return True
        return success


# Generated at 2022-06-22 21:15:10.782309
# Unit test for function retry
def test_retry():
    calls = 0
    delays = [3, 1, 4]
    if len(sys.argv) > 3:
        delays = [float(x) for x in sys.argv[3:]]

    @retry_with_delays_and_condition(generate_jittered_backoff(len(delays), delay_base=1, delay_threshold=60))
    def callit():
        nonlocal calls
        calls += 1
        return calls

    if len(sys.argv) > 2:
        print(callit(int(sys.argv[2])))
    else:
        print(callit())


if __name__ == "__main__":
    test_retry()

# Generated at 2022-06-22 21:15:18.424737
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Unit test function to validate that generate_jittered_backoff generates delays according to the documentation

    :return: True, if the test is successful, otherwise False.
    """
    if list(generate_jittered_backoff(0)) != []:
        return False
    
    if list(generate_jittered_backoff(1)) != [0, 0]:
        return False
    
    if list(generate_jittered_backoff(5)) != [0, 0, 1, 2, 4, 7]:
        return False
    
    return True

# Generated at 2022-06-22 21:15:26.752212
# Unit test for function rate_limit
def test_rate_limit():
    # ratelimit for a 1 second limit, at 10 requests per second:
    # 1 seconds / 10 requests = .1 seconds per request

    @rate_limit(rate=10, rate_limit=1)
    def fake_api_call(*args, **kwargs):
        pass

    # for this test we just care about the wall time, not the cpu time
    # so we use time.time instead of time.clock
    start = time.time()
    for i in range(11):
        fake_api_call()
    end = time.time()
    assert end - start >= 1.0



# Generated at 2022-06-22 21:15:34.436995
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    expected_argument_spec = {
        "retries": {
            "type": "int",
            "required": False,
            "default": None
        },
        "retry_pause": {
            "type": "float",
            "required": False,
            "default": 1
        }
    }

    assert retry_argument_spec() == expected_argument_spec
    assert retry_argument_spec({}) == expected_argument_spec
    assert retry_argument_spec({"new_param": {"type": "dict"}}) == dict(expected_argument_spec, **{"new_param": {"type": "dict"}})

# Generated at 2022-06-22 21:15:40.924361
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=2)
    def count():
        count.counter += 1
        if count.counter < count.final:
            raise Exception("not it")
        return count.counter
    count.counter = 0
    count.final = 4
    assert count() == 4
    count.final = 5
    assert count() == 5
    count.final = 6
    try:
        count()
    except Exception as e:
        assert e.message == 'Retry limit exceeded: 5'
    else:
        raise Exception('should have raised')

# Generated at 2022-06-22 21:15:48.304453
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_tests = [
        (None, dict(rate=dict(type='int'), rate_limit=dict(type='int'))),
        (dict(a=dict(type='str')),
            dict(rate=dict(type='int'), rate_limit=dict(type='int'), a=dict(type='str'))
        )
    ]
    for a_spec, expected_result in rate_limit_tests:
        result  = rate_limit_argument_spec(a_spec)
        assert result == expected_result


# Generated at 2022-06-22 21:15:49.118070
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    pass

# Generated at 2022-06-22 21:15:58.096543
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # This should run the function once, with no delay
    default_backoff_iterator = generate_jittered_backoff(retries=0, delay_base=3, delay_threshold=60)
    @retry_with_delays_and_condition(default_backoff_iterator)
    def bad_function():
        raise ValueError("This ValueError exception should be caught and the function retried")

    with pytest.raises(ValueError):
        # This ValueError should not be caught, so bad_function should raise
        bad_function()

    def should_retry_error(e):
        """This is a good example of what a should_retry_error function should look like"""
        if isinstance(e, AttributeError):
            # This function should not retry on AttributeError exceptions
            return False

        return True



# Generated at 2022-06-22 21:16:08.060284
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock

    arg_spec = basic_auth_argument_spec(spec=None)

    assert arg_spec['api_username']['type'] == 'str'
    assert arg_spec['api_password']['type'] == 'str'
    assert arg_spec['api_password']['no_log'] == True
    assert arg_spec['validate_certs']['type'] == 'bool'
    assert arg_spec['validate_certs']['default'] == True
    assert arg_spec['api_url']['type'] == 'str'


# Generated at 2022-06-22 21:16:16.795892
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from ansible.module_utils import basic
    class TestException(Exception):
        pass

    class TestClass(object):
        def __init__(self):
            self.should_retry = True
            self.attempt_num = 0
        def function(self):
            self.attempt_num += 1
            if self.should_retry:
                raise TestException("Retry me!")
            return "Success!"

    # Basic usage
    max_retries = 3
    test = TestClass()
    backoff = generate_jittered_backoff(max_retries)
    # Run the test 3 times, with delays based on the backoff_iterator
    retry_decorated = retry_with_delays_and_condition(backoff)(test.function)

# Generated at 2022-06-22 21:16:23.395750
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=1)
    def rate_limited():
        print("rate limited")
        time.sleep(0.1)

    start = time.time()
    for i in range(5):
        rate_limited()
    end = time.time()

    elapsed = end - start
    assert elapsed > 3 and elapsed < 3.5


# unit test for function retry

# Generated at 2022-06-22 21:16:31.049842
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(4, 10)  # 4 calls in 10 seconds is ok.
    def call():
        pass

    now = time.time()
    for i in range(3):
        call()
    assert time.time() - now < 4

    @rate_limit(30, 10)  # 20 calls in 10 seconds is ok.
    def call():
        pass

    now = time.time()
    for i in range(30):
        call()
    assert time.time() - now < 10

    @rate_limit(40, 10)  # 40 calls in 10 seconds will fail.
    def call():
        pass

    now = time.time()
    raised_error = False
    try:
        for i in range(40):
            call()
    except Exception:
        raised_error = True

# Generated at 2022-06-22 21:16:33.421969
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == retry_argument_spec(dict())
    assert retry_argument_spec() == retry_argument_spec({})
    assert retry_argument_spec() == retry_argument_spec({'options': 'data'})


# Generated at 2022-06-22 21:16:44.107239
# Unit test for function rate_limit
def test_rate_limit():
    # Set up the variables as they would be after the argument_spec was processed
    rate = 20000
    rate_limit = 60
    minrate = 30000

    # Decorate our function with the decorator we want to test
    @rate_limit(rate, rate_limit)
    def test_func():
        return

    # Assert that the decorated function has the correct attributes
    assert(test_func.__name__ == "test_func")
    assert(test_func.__module__ == "ansible_collections.notstdlib.moveitallout.plugins.modules.api")

    # Get the reference time
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock
    start_time = real_time()

    # Call the

# Generated at 2022-06-22 21:16:52.543004
# Unit test for function rate_limit
def test_rate_limit():
    """ test rate_limit decorator """
    tests = [
        (1, 1, True),
        (1, None, True),
        (None, 1, True),
        (2, None, False),
    ]

    for rate, rate_limit, expect in tests:
        @rate_limit(rate, rate_limit)
        def ratelimited(*args, **kwargs):
            """ dummy rate limited function """
            return args, kwargs

        args, kwargs = ratelimited(1, 2, 3, test='test')
        assert args[0] == 1
        assert kwargs['test'] == 'test'



# Generated at 2022-06-22 21:16:57.745288
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.api import basic_auth_argument_spec
    argspec = basic_auth_argument_spec()
    assert type(argspec) is dict
    assert set(argspec.keys()) == set(['api_username', 'api_password', 'api_url', 'validate_certs'])
    assert argspec['api_password']['no_log'] is True


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-22 21:17:06.479544
# Unit test for function rate_limit
def test_rate_limit():
    default_rate = 1.0
    default_rate_limit = 5.0

    @rate_limit()
    def f():
        print("Hello")

    # should never be called
    @rate_limit(rate=0)
    def g():
        print("Hello")

    @rate_limit(rate_limit=2, rate=10)
    def h():
        print("Hello")

    f()
    g()
    h()

    start = time.time()
    f()
    end = time.time()
    assert (end - start) > default_rate_limit/default_rate

test_rate_limit()

# Generated at 2022-06-22 21:17:14.555318
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import sys
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock

    @rate_limit(5, 10)
    def test():
        print(real_time())
    print(real_time())
    print('---------')
    test()
    test()
    test()
    test()
    test()
    test()
    print('---------')
    test()
    test()
    test()
    test()
    test()
    test()

if __name__ == "__main__":
    test_basic_auth_argument_spec()

# Generated at 2022-06-22 21:17:23.210013
# Unit test for function retry
def test_retry():
    @retry(retries=2)
    def test_retry_function(fail):
        print("Called test_retry_function with fail=%s" % fail)
        if fail:
            raise Exception('fail')
        return "ok"

    # Test retry success
    try:
        test_retry_function(fail=False)
    finally:
        assert test_retry_function.retries == 0

    # Test retry failure
    try:
        test_retry_function(fail=True)
    except Exception:
        pass
    finally:
        assert test_retry_function.retries == 2



# Generated at 2022-06-22 21:17:32.669317
# Unit test for function retry
def test_retry():
    # Helper function for testing retry decorator
    @retry(retries=2, retry_pause=0.01)
    def test_function(retry_times_left=4):
        if retry_times_left > 0:
            retry_times_left -= 1
            raise Exception('foo')
        else:
            return 'bar'
    # Check retry works with retries > 1
    assert test_function(retry_times_left=4) == 'bar'
    # Check retry fails when retry_times_left < retries
    try:
        test_function(retry_times_left=1)
    except Exception as e:
        assert e.args[0] == 'Retry limit exceeded: 2'



# Generated at 2022-06-22 21:17:38.389599
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    argspec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        state=dict(type='int'),
    )
    result = rate_limit_argument_spec(spec)
    assert result == spec


# Generated at 2022-06-22 21:17:41.687923
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )

# Generated at 2022-06-22 21:17:47.502735
# Unit test for function retry
def test_retry():
    test_input = 0
    @retry(retries=3, retry_pause=1)
    def test():
        global test_input
        if test_input == 0:
            test_input += 1
            raise Exception("Test")
        return True

    if not test():
        raise Exception("test_retry failed")

# Generated at 2022-06-22 21:17:50.799368
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Iterate 100 times to try and get a sample distribution
    for i in range(100):
        last = 0
        for item in generate_jittered_backoff(retries=100):
            assert last <= item
            last = item



# Generated at 2022-06-22 21:17:54.597328
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_argument_spec = rate_limit_argument_spec()
    assert rate_argument_spec['rate'] == {
        'type': 'int'
    }
    assert rate_argument_spec['rate_limit'] == {
        'type': 'int'
    }



# Generated at 2022-06-22 21:18:01.046488
# Unit test for function retry
def test_retry():
    @retry(retries=4, retry_pause=1)
    def test_function(retry_count):
        if retry_count != 0:
            raise Exception("Retry Error")
        return "OK"

    assert test_function(0) == 'OK'
    try:
        test_function(1)
    except Exception:
        assert True
    else:
        raise Exception('Retry function did not raise an error')

# Generated at 2022-06-22 21:18:11.328529
# Unit test for function retry
def test_retry():
    # This is just to test retry_decorator (with a single retry)
    import unittest

    class TestRetry(unittest.TestCase):

        @retry(retries=1, retry_pause=0)
        def function_to_retry(self):
            self.called_times += 1
            return self.called_times

        def test_called_twice(self):
            # Test that the function is called twice
            self.called_times = 0
            self.assertEqual(self.function_to_retry(), 2)

        def test_called_once(self):
            # Test that the function is called twice, then test that the function returns the same value
            self.called_times = 0
            self.assertEqual(self.function_to_retry(), 2)
            self

# Generated at 2022-06-22 21:18:15.494514
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert retry_spec == dict(retries=dict(type='int'), retry_pause=dict(type='float', default=1)), 'retry argument spec does not match expected dict'


# Generated at 2022-06-22 21:18:21.972883
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected_spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    real_spec = rate_limit_argument_spec()
    assert real_spec == expected_spec
    expected_spec.update(filename=dict(type='path'))
    real_spec = rate_limit_argument_spec(filename=dict(type='path'))
    assert real_spec == expected_spec



# Generated at 2022-06-22 21:18:28.153002
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_count = 0
    condition_result = [True, False]
    result_count = 0

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=lambda e: condition_result[result_count])
    def retryable_function():
        nonlocal backoff_count
        backoff_count += 1
        nonlocal result_count
        if backoff_count > 1:
            result_count += 1
        return 1 / 0

    with pytest.raises(ZeroDivisionError):
        retryable_function()

    assert backoff_count == 2

# Generated at 2022-06-22 21:18:31.339230
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("test")) is False
    assert retry_never(True) is False
    assert retry_never(None) is False
    assert retry_never(False) is False


# Generated at 2022-06-22 21:18:39.070001
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def fail_function(number_of_tries_left):
        if number_of_tries_left > 0:
            return fail_function(number_of_tries_left - 1)
        else:
            return 1

    # The jittered backoff delays are chosen from the interval (0, delay_max)
    delay_max = 6
    backoff_integer_iterator = generate_jittered_backoff(retries=4, delay_base=delay_max)

    # An error occurred since the function failed to return 1
    @retry_with_delays_and_condition(backoff_integer_iterator, retry_never)
    def fail_function_with_retry(starting_number):
        return fail_function(starting_number)

    # The function should return 1 after the fourth try
    assert fail_function_

# Generated at 2022-06-22 21:18:46.108548
# Unit test for function rate_limit
def test_rate_limit():
    global delta
    delta = []
    global ticks

    @rate_limit(rate=2, rate_limit=10)
    def func():
        delta.append(time.time() - ticks)
        ticks = time.time()

    ticks = time.time()
    for x in range(0, 10):
        func()

    # there should be 5 distinct calls
    assert(len(set(delta)) == 5)
    # each call should be 5 seconds apart
    assert(sorted(delta)[1] - sorted(delta)[0] == 5)



# Generated at 2022-06-22 21:18:56.818885
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import math
    import unittest

    def avg_error(actual, expected):
        return float(abs(actual - expected)) / float(expected)

    def assert_within_error_rate(actual, expected, error_rate):
        avg_error = float(abs(actual - expected)) / float(expected)
        assert avg_error <= error_rate

    def assert_mean_within_error_rate(values, expected, error_rate):
        assert_within_error_rate(float(sum(values)) / float(len(values)), expected, error_rate)

    def assert_jittered_backoff_within_error_rate(backoff_iterator, expected, error_rate=0.1):
        assert_mean_within_error_rate(backoff_iterator, expected, error_rate)


# Generated at 2022-06-22 21:19:05.189163
# Unit test for function retry

# Generated at 2022-06-22 21:19:06.649539
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never("test") == False


# Generated at 2022-06-22 21:19:09.471276
# Unit test for function retry
def test_retry():
    counter = [0]

    @retry(3, 2)
    def slow():
        counter[0] += 1
        if counter[0] < 4:
            raise Exception
        return True

    assert slow()
    assert counter[0] == 3


# Generated at 2022-06-22 21:19:11.162012
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert(type(basic_auth_argument_spec()) is dict)

# Generated at 2022-06-22 21:19:17.255872
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=60))
    def add_numbers(num1, num2):
        if num1 == 4 and num2 == 4:
            return num1 + num2
        else:
            raise ValueError("Numbers do not add up!")

    assert add_numbers(4, 4) == 8



# Generated at 2022-06-22 21:19:21.611523
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_vals = list(generate_jittered_backoff(retries=5, delay_base=2, delay_threshold=10))
    for i in range(4):
        assert backoff_vals[i] < backoff_vals[i + 1]
    assert backoff_vals[-1] == 10

# Generated at 2022-06-22 21:19:28.534471
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = {'test': {'type': 'str'}}
    result = basic_auth_argument_spec(arg_spec)
    expected = {'test': {'type': 'str'}, 'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True}, 'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}}
    assert result == expected

# Generated at 2022-06-22 21:19:30.321086
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert 'retries' in retry_argument_spec()


# Generated at 2022-06-22 21:19:33.596666
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(rate=0.25, rate_limit=1)
    def sleeper():
        time.sleep(random.random())
        return True

    for x in range(0, 10):
        sleeper()



# Generated at 2022-06-22 21:19:41.375091
# Unit test for function retry
def test_retry():
    class MyException(Exception):
        pass

    @retry(retries=4, retry_pause=1)
    def test():
        retry.called += 1
        if retry.called < retry.should_raise:
            raise MyException("fake")

    retry.called = 0
    retry.should_raise = 3

    test()
    assert retry.called == retry.should_raise

    retry.should_raise = 5
    try:
        test()
    except Exception:
        assert retry.called == retry.should_raise
        assert sys.exc_info()[0] == MyException
    else:
        assert False, "Expected exception, got none"

