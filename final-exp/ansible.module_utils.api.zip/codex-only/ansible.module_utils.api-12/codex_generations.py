

# Generated at 2022-06-22 21:09:41.609608
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = {
        'api_key': dict(type='str', required=True)
    }
    argument_spec = basic_auth_argument_spec(spec)
    assert type(argument_spec) == dict
    for key in argument_spec.keys():
        assert key in spec or key in ['api_username', 'api_password', 'api_url', 'validate_certs']

# Generated at 2022-06-22 21:09:50.252531
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Time the function to ensure it is not taking too long to run
    iteration_limit = 10000
    number_of_delays = 100
    delay_base = 3
    delay_threshold = 60

    total = 0

    start_time = time.time()
    for delay in generate_jittered_backoff(number_of_delays, delay_base, delay_threshold):
        total += delay
        if total > iteration_limit:
            break
    end_time = time.time()

    elapsed_time = end_time - start_time

    # We expect to for the time taken to be greater than zero, but less than a single second
    assert elapsed_time > 0 and elapsed_time < 1

# Generated at 2022-06-22 21:09:54.063460
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import random

    throttled = rate_limit(10, 1)(random.randint)
    t0 = time.time()
    while True:
        throttled()
        if (time.time() - t0) > 1:
            break



# Generated at 2022-06-22 21:10:05.349191
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    assert list(generate_jittered_backoff()) == [0] * 10

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def simple_raises_exception():
        raise Exception()
    assert simple_raises_exception() is None

    class MyException(Exception):
        pass
    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=lambda e: not isinstance(e, MyException))
    def raises_my_exception():
        raise MyException()
    assert raises_my_exception() is None

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def simple_returns_something():
        return 'something'
    assert simple_

# Generated at 2022-06-22 21:10:10.314287
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        api_username=dict(type='str', default='admin'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str', required=True),
        validate_certs=dict(type='bool', default=True)
    )
    assert spec == basic_auth_argument_spec()


# Generated at 2022-06-22 21:10:18.351985
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    rps = 1
    rpl = 1

    class TestRateLimit(unittest.TestCase):
        @rate_limit(rate=rps, rate_limit=rpl)
        def rate_limited_function(self):
            """A rate limited function to test rate_limit"""
            return True

    test_rate_limit = TestRateLimit()
    start_time = time.time()
    results = []
    while (time.time() - start_time) < rpl * 10:
        results.append(test_rate_limit.rate_limited_function())

    assert results.count(True) == rps * rpl * 10



# Generated at 2022-06-22 21:10:29.205285
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Testing if the decorator returns the correct result
    delays = range(0, 3)
    count = [0]  # Has to be a list to be modified from the function_wrapper

    @retry_with_delays_and_condition(delays, should_retry_error=lambda e: e.args[0] != 'result')
    def function_wrapper_no_exception():
        count[0] += 1
        return 'result'

    result = function_wrapper_no_exception()
    assert result == 'result'
    assert count[0] == 1

    # Testing if the decorator raises the correct exception
    count = [0]


# Generated at 2022-06-22 21:10:39.114011
# Unit test for function retry
def test_retry():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    def test_retry_true(e):
        return True

    def test_retry_false(e):
        return False

    class RetryFunctionUnitTestCase(unittest.TestCase):

        def test_retry_true(self):
            @retry_with_delays_and_condition(backoff_iterator=[1], should_retry_error=test_retry_true)
            def func_true():
                return True

            result = func_true()
            self.assertEqual(True, result)


# Generated at 2022-06-22 21:10:42.191806
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module = fake_module()
    rate_limit_argspec = rate_limit_argument_spec()
    for opt, val in rate_limit_argspec.items():
        assert opt in module.argument_spec
        assert val == module.argument_spec[opt]



# Generated at 2022-06-22 21:10:49.304023
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    random.seed(0)  # Seed to make tests deterministic
    assert list(generate_jittered_backoff()) == [0]
    assert list(generate_jittered_backoff(4, 2, 10)) == [2, 3, 7, 10]
    assert list(generate_jittered_backoff(4, 2, 1)) == [0, 1, 0, 1]
    assert list(generate_jittered_backoff(3, 4, 20)) == [8, 15, 20]



# Generated at 2022-06-22 21:10:50.654417
# Unit test for function retry_never
def test_retry_never():
    e = Exception
    assert retry_never(e) is False

# Generated at 2022-06-22 21:10:57.479247
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    from collections import Counter

    counters = {}

    def test_count_delays(delays):
        counts = Counter()
        for times in range(0, 100):
            for delay in generate_jittered_backoff(retries=delays, delay_base=3, delay_threshold=60):
                counts[delay] += 1

        counters[delays] = counts

    test_count_delays(delays=0)
    test_count_delays(delays=1)
    test_count_delays(delays=2)
    test_count_delays(delays=3)
    test_count_delays(delays=4)
    test_count_delays(delays=5)
    test_count_delays(delays=6)

# Generated at 2022-06-22 21:11:01.755276
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import statistics
    it = generate_jittered_backoff()
    delays = []
    for i in it:
        delays.append(i)
    assert len(delays) == 10
    assert 0.0 <= statistics.mean(delays) <= 1.5
    assert statistics.pstdev(delays) > 0.5



# Generated at 2022-06-22 21:11:09.555148
# Unit test for function retry
def test_retry():
    max_attempts = 3
    max_delay = 3
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=max_attempts, delay_base=max_delay), should_retry_error=retry_never)
    def retried_function():
        retried_function.call_count += 1
        return "success" if retried_function.call_count >= max_attempts else None

    retried_function.call_count = 0
    assert "success" == retried_function()
    assert max_attempts == retried_function.call_count

# Generated at 2022-06-22 21:11:19.016449
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import random

    random.seed(1)
    backoffs = list(generate_jittered_backoff())
    assert backoffs == [0, 0, 3, 0, 3, 0, 3, 3, 3, 3]

    random.seed(2)
    backoffs = list(generate_jittered_backoff(retries=8))
    assert backoffs == [0, 3, 0, 0, 3, 3, 0, 3]

    random.seed(3)
    backoffs = list(generate_jittered_backoff(retries=8, delay_base=4, delay_threshold=16))
    assert backoffs == [0, 4, 7, 0, 4, 11, 0, 4]

    random.seed(4)

# Generated at 2022-06-22 21:11:30.021167
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def test_function(raise_exception):
        if raise_exception:
            raise Exception("This function is supposed to fail")
        return True

    @retry_with_delays_and_condition(generate_jittered_backoff(3), retry_never)
    def never_retry_test(raise_exception):
        return test_function(raise_exception)

    @retry_with_delays_and_condition(generate_jittered_backoff(3), retry_never)
    def always_retry_test(raise_exception):
        return test_function(raise_exception)

    assert never_retry_test(True) is True

# Generated at 2022-06-22 21:11:34.230029
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module = AnsibleModule(rate_limit_argument_spec())
    module.exit_json(rate=module.params['rate'], rate_limit=module.params['rate_limit'])



# Generated at 2022-06-22 21:11:37.298409
# Unit test for function rate_limit
def test_rate_limit():
    r = random.randint(1, 10)
    l = random.randint(1, 100)
    @rate_limit(r, l)
    def f(x):
        print(x)

    f(r)

# Generated at 2022-06-22 21:11:44.820256
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class DummyException(Exception):
        pass

    class DummyOtherException(Exception):
        pass

    def raise_if_count(count, exception_to_raise, *args, **kwargs):
        raise_if_count.called_count += 1
        if raise_if_count.called_count == count:
            raise exception_to_raise()

    raise_if_count.called_count = 0

    backoff_iterator = generate_jittered_backoff(3, 1, 5)
    should_retry_dummy = lambda exception: isinstance(exception, DummyException)
    should_retry_other = lambda exception: isinstance(exception, DummyOtherException)

    def test_fail_after_all_retries():
        raise_if_count(4, DummyException)

        function = retry

# Generated at 2022-06-22 21:11:55.273560
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():

    class MockModule():
        def __init__(self):
            self.params = {
                'api_username': 'user',
                'api_password': 'pass',
                'api_url': 'https://api.example.com',
                'validate_certs': False,
            }

    m = MockModule()
    result = basic_auth_argument_spec()
    assert result.pop('api_username')(m) == 'user'
    assert result.pop('api_password')(m) == 'pass'
    assert result.pop('api_url')(m) == 'https://api.example.com'
    assert result.pop('validate_certs')(m) == False
    assert len(result) == 0



# Generated at 2022-06-22 21:12:03.792957
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec(spec={'retries': {'type': 'int'}}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec(spec={'retry_pause': {'type': 'float'}}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float'}}


# Generated at 2022-06-22 21:12:08.087963
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )



# Generated at 2022-06-22 21:12:17.408284
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec(None)
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1

    spec = retry_argument_spec({'test_option':{'test_option_arg': 'test_option_value'}})
    assert spec['test_option']['test_option_arg'] == 'test_option_value'
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1

# Generated at 2022-06-22 21:12:22.816458
# Unit test for function rate_limit
def test_rate_limit():
    '''passing in a rate limit and a rate'''
    modspec = dict(
        argument_spec=dict(
            rate_limit=dict(type='int'),
            rate=dict(type='int')
        )
    )
    _ = rate_limit_argument_spec(modspec)
    assert _['argument_spec']['rate_limit']['type'] == 'int'
    assert _['argument_spec']['rate']['type'] == 'int'



# Generated at 2022-06-22 21:12:28.434025
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest
    from tests.unit.unicode import unicode_data

    # Mock a function that returns an exception in the first attempts, then a result in the final attempt.
    called_count = [0]
    def mock_retryable_function(*args, **kwargs):
        called_count[0] += 1
        if called_count[0] < 4:
            raise Exception(u"Retryable error: {}".format(unicode_data))
        return u"Result: {}".format(unicode_data)

    # Test retry_with_delays_and_condition
    # - Test that it throws an error when we don't want to retry
    # - Test that it retries on exception up to the maximum number of retries, then passes the last exception

# Generated at 2022-06-22 21:12:31.507232
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import pytest

    expected_delays = [11, 18, 0, 4, 7, 19, 17, 17, 1, 19]
    delays = list(generate_jittered_backoff())

    assert delays == expected_delays
    assert len(delays) == 10



# Generated at 2022-06-22 21:12:41.738941
# Unit test for function retry
def test_retry():
    """ test constant retries"""
    @retry(retries=3, retry_pause=1)
    def retry_me():
        print("retrying")
        raise Exception('Failed')

    # this should eventually raise
    try:
        retry_me()
    except Exception as err:
        assert err.args[0] == "Retry limit exceeded: 3"
    else:
        fail("retry failed")

    # this should work
    @retry(retries=3, retry_pause=1)
    def retry_me():
        print("retrying")
        return "worked"

    assert retry_me() == "worked"

    # test exceptions
    @retry(retries=3, retry_pause=1)
    def retry_me():
        print("retrying")


# Generated at 2022-06-22 21:12:53.221282
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import math

    def check_limits(f, *args, **kwargs):
        wanted_time = args[0]
        rate_limit = args[1]
        rate = args[2]
        start_time = time.time()
        for i in range(rate_limit):
            f()
        elapsed_time = time.time() - start_time
        print('elapsed time: %s' % elapsed_time)
        print('wanted time: %s' % wanted_time)
        assert math.fabs(elapsed_time - wanted_time) < 0.1, 'elapsed time: %f time: %f' % (elapsed_time, wanted_time)

    def f():
        print('.')


# Generated at 2022-06-22 21:13:03.042412
# Unit test for function retry
def test_retry():
    def failer():
        raise Exception('failed')

    def often_failer():
        retries = 0
        while True:
            retries += 1
            if retries > 3:
                return retries
            else:
                raise Exception('failed')

    @retry(retries=3, retry_pause=1)
    def call_0():
        return failer()

    @retry(retries=3, retry_pause=1)
    def call_1():
        return often_failer()

    try:
        call_0()
        assert False
    except Exception:
        pass

    assert call_1() == 3

# Generated at 2022-06-22 21:13:12.419983
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestException(Exception):
        pass

    def always_retry_exception(e):
        return True

    def never_retry_exception(e):
        return False

    def FooException(e):
        return not isinstance(e, TestException)

    class TestClass:
        @retry_with_delays_and_condition(backoff_iterator=[1, 1, 1], should_retry_error=always_retry_exception)
        def foo_always(self):
            print("in foo_always")
            raise TestException

        @retry_with_delays_and_condition(backoff_iterator=[1, 1, 1], should_retry_error=never_retry_exception)
        def foo_never(self):
            print("in foo_never")
            raise TestException



# Generated at 2022-06-22 21:13:15.894767
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1)
    )


# Generated at 2022-06-22 21:13:23.650168
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=3, rate_limit=3)
    def test():
        return time.time()

    time.sleep(1)
    start = time.time()
    a = test()
    b = test()
    c = test()
    dur = time.time() - start
    # 5 secs rate window, 3x calls
    if dur > 5 or dur < 3:
        raise AssertionError()
    d = test()
    dur2 = time.time() - start
    # 5 secs rate window * 2, 4x calls
    if dur2 > 8 or dur2 < 5:
        raise AssertionError()

# Generated at 2022-06-22 21:13:32.553175
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_base = 3
    delay_threshold = 30
    assert len([x for x in generate_jittered_backoff(retries=3, delay_base=delay_base, delay_threshold=delay_threshold)]) == 3
    for delay in generate_jittered_backoff(retries=3, delay_base=delay_base, delay_threshold=delay_threshold):
        assert delay <= delay_threshold
        assert delay >= 0
    assert sum([x for x in generate_jittered_backoff(retries=3, delay_base=delay_base, delay_threshold=delay_threshold)]) > delay_base

if __name__ == '__main__':
    test_generate_jittered_backoff()

# Generated at 2022-06-22 21:13:40.455096
# Unit test for function retry
def test_retry():
    x = 0

    @retry()
    def doit():
        global x
        x += 1
        raise Exception("fail")

    try:
        doit()
        assert False
    except Exception:
        pass

    assert x == 5

    try:
        @retry(retries=10)
        def doit():
            global x
            x += 1
            raise Exception("fail")
        doit()
        assert False
    except Exception:
        pass

    assert x == 16

    @retry(retry_limit=10)
    def doit():
        global x
        x += 1
        raise Exception("fail")

    try:
        doit()
        assert False
    except Exception:
        pass

    assert x == 26

# Generated at 2022-06-22 21:13:49.915942
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.basic import AnsibleModule

    with_retries = retry_argument_spec(Connection.common_argument_spec)
    module = AnsibleModule(
        argument_spec=with_retries,
    )

    assert module.params['retries'] is None
    assert module.params['retry_pause'] == 1

    module = AnsibleModule(
        argument_spec=with_retries,
        params={'retries': 2, 'retry_pause': 2.3}
    )

    assert module.params['retries'] == 2
    assert module.params['retry_pause'] == 2.3

# Generated at 2022-06-22 21:13:59.570769
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Test generate_jittered_backoff() function.

    Generate 10 delays with base 3 and threshold 60.
    """
    delays = [generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60).__next__() for _ in range(0, 10)]
    assert 0 in delays and 60 in delays
    assert sorted(delays) == delays

    # Test for an exception for any negative number
    for retries in [-1, -2, -3]:
        with pytest.raises(ValueError):
            generate_jittered_backoff(retries=retries, delay_base=3, delay_threshold=60)



# Generated at 2022-06-22 21:14:00.541581
# Unit test for function retry_never
def test_retry_never():
    pass

# Generated at 2022-06-22 21:14:06.167169
# Unit test for function retry
def test_retry():
    """retry test function"""
    count = [0]

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff())
    def _pretend_to_call_something():
        """pretend to call something"""
        count[0] += 1

        if count[0] == 2:
            return True

        raise Exception("Something went wrong. We should retry.")

    _pretend_to_call_something()



# Generated at 2022-06-22 21:14:08.922791
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argspec = retry_argument_spec()
    assert "retries" in argspec.keys()
    assert "retry_pause" in argspec.keys()
    assert argspec["retries"]["type"] == "int"
    assert argspec["retry_pause"]["type"] == "float"

# Generated at 2022-06-22 21:14:14.489371
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    def run(times, delay_threshold, delay_base):
        backoff_iterator = generate_jittered_backoff(times, delay_threshold, delay_base)
        acceptable = True
        for delay in backoff_iterator:
            if delay < 0 or delay > delay_threshold:
                acceptable = False
                break
        return acceptable

    assert(run(10, 60, 3))
    assert(run(100, 60, 3))
    assert(run(100, 120, 3))
    assert(run(100, 3, 3))
    assert(run(100, 120, 120))

# Generated at 2022-06-22 21:14:20.461604
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = (dict(
        hello=dict(type='str', default='world'),
        foo=dict(type='str', default='bar'),
    ))
    a = rate_limit_argument_spec(spec)
    assert isinstance(a, dict)
    assert a['rate']['type'] == 'int'
    assert a['rate_limit']['type'] == 'int'
    assert a['hello']['type'] == 'str'
    assert a['foo']['type'] == 'str'


# Generated at 2022-06-22 21:14:23.828394
# Unit test for function rate_limit
def test_rate_limit():
    """ Unit test for rate_limit decorator """
    print('Running rate_limit decorator test')

# Generated at 2022-06-22 21:14:29.773809
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec
    assert isinstance(arg_spec, dict)
    assert 'retries' in arg_spec
    assert 'retry_pause' in arg_spec
    assert arg_spec['retry_pause']['default'] == 1
    assert arg_spec['retry_pause']['type'] == 'float'


# Generated at 2022-06-22 21:14:34.800820
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    result = basic_auth_argument_spec()
    expected = dict(api_username=dict(type='str'),
                    api_password=dict(type='str', no_log=True),
                    api_url=dict(type='str'),
                    validate_certs=dict(type='bool', default=True))
    assert result == expected

# Generated at 2022-06-22 21:14:36.359291
# Unit test for function retry
def test_retry():
    @retry(retries=2)
    def retry_func(x):
        print('retry_func argument: %s' % x)
        return None

    retry_func(1)

# Generated at 2022-06-22 21:14:43.890518
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """Unit test for function rate_limit_argument_spec"""
    assert rate_limit_argument_spec(spec=None) == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }

    assert rate_limit_argument_spec(spec=[{'rate': {'type': 'int'}}]) == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }


# Generated at 2022-06-22 21:14:50.064176
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Test for the retry_argument_spec function"""
    arg_spec1 = (dict(
        arg1=dict(type='str'),
    ))
    arg_spec2 = (dict(
        arg2=dict(type='str'),
    ))

    a1 = retry_argument_spec(arg_spec1)
    a2 = retry_argument_spec(arg_spec2)
    assert('retries' in a1)
    assert('retry_pause' in a1)
    assert('retries' in a2)
    assert('retry_pause' in a2)

# Generated at 2022-06-22 21:14:59.561470
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import six
    import unittest

    class TestRetryWithDelaysAndCondition(unittest.TestCase):
        def assert_retry_count(self, retries):
            num_attempts = 0
            for _ in retries:
                num_attempts += 1
            self.assertEqual(num_attempts, 0)

        def test_no_retry(self):
            backoff_iterator = generate_jittered_backoff()

            @retry_with_delays_and_condition(backoff_iterator, should_retry_error=retry_never)
            def function_that_does_not_raise():
                return True

            self.assertTrue(function_that_does_not_raise())
            self.assert_retry_count(backoff_iterator)


# Generated at 2022-06-22 21:15:07.433150
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    basic_auth = basic_auth_argument_spec()
    assert basic_auth['api_username']['type'] == 'str'
    assert basic_auth['api_password']['type'] == 'str'
    assert basic_auth['api_url']['type'] == 'str'
    assert basic_auth['validate_certs']['type'] == 'bool'
    assert basic_auth['validate_certs']['default'] == True

# Generated at 2022-06-22 21:15:14.051256
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        rate=dict(aliases=['nr'], type='int'),
        rate_limit=dict(aliases=['duration'], type='int'),
    )
    assert rate_limit_argument_spec(spec) == dict(
        rate=dict(aliases=['nr'], type='int'),
        rate_limit=dict(aliases=['duration'], type='int'),
    )



# Generated at 2022-06-22 21:15:25.437805
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=60))
    def raise_for_zero_delay(delay):
        if delay == 0:
            raise ValueError()

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=60), should_retry_error=lambda e: True)
    def raise_for_zero_delay(delay):
        if delay == 0:
            raise ValueError()


# Generated at 2022-06-22 21:15:33.593955
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    retry_times = 10
    backoff_delay_list = list(generate_jittered_backoff(retry_times))
    backoff_iter = iter(backoff_delay_list)

    # backoff_delay_list will be consumed and will become empty
    def backoff_iterator():
        return next(backoff_iter, 0)

    def fail_always(e):
        return True

    def fail_always_except_first(e):
        return True if backoff_delay_list else False

    def fail_always_except_last(e):
        return True if backoff_delay_list else False

    @retry_with_delays_and_condition(backoff_iterator, fail_always)
    def failing_function():
        return False


# Generated at 2022-06-22 21:15:34.940837
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never(Exception()) == False)



# Generated at 2022-06-22 21:15:41.177885
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    module_args = dict(
        retries=3,
        retry_pause=5,
        some_new_arg=False
    )

    @retry_argument_spec(spec=dict(some_new_arg=dict(type='bool')))
    def test_retry_func(module_args):
        assert module_args['retries'] == 3
        assert module_args['retry_pause'] == 5
        assert module_args['some_new_arg'] is False

    test_retry_func(module_args)



# Generated at 2022-06-22 21:15:45.112402
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=.5)
    def run(retry=1):
        print("running")
        if retry == 3:
            return True

    run(retry=1)
    run(retry=5)
    run(retry=3)

# Generated at 2022-06-22 21:15:55.905806
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Generate 10 delays
    delays_10 = list(generate_jittered_backoff(retries=10))
    assert len(delays_10) == 10
    # Verify the 10 delays are within the expected range
    # Note: The minimum value is always 0
    # The maximum value for a given attempt is based on the delay_base and delay_threshold set and starts at 3 and continues to increase until it reaches the delay_threshold
    # Once the maximum value has reached the delay_threshold, no further increases are made
    assert max(delays_10) <= 60
    # Generate 100 delays
    delays_100 = list(generate_jittered_backoff(retries=100))
    assert len(delays_100) == 100
    # Verify the 100 delays are within the expected range
    # Note: The minimum value is always 0


# Generated at 2022-06-22 21:16:03.838679
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Unit test for retry_with_delays_and_condition.

    If this is executed directly, it should print:
    i:0
    i:1
    i:2
    """

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3))
    def throw_error(i):
        print("i:%s" % i)
        raise Exception("error")

    for i in range(0, 3):
        throw_error(i)

    print("test_retry_with_delays_and_condition passed")

# Generated at 2022-06-22 21:16:13.891384
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # No jitter, the values are always the same
    for n in range(10):
        for v in generate_jittered_backoff(retries=10, delay_base=2, delay_threshold=2):
            assert v == 2

    # testing a random set, the values will change
    for n in range(10):
        for v in generate_jittered_backoff(retries=10, delay_base=2, delay_threshold=60):
            if v != 2 and v != 4:
                return
            assert v == 2 or v == 4

    # testing a random set, the values will change

# Generated at 2022-06-22 21:16:18.192336
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()

    assert(spec['api_username'] ==
           {'type': 'str'})
    assert(spec['api_password'] ==
           {'type': 'str', 'no_log': True})
    assert(spec['api_url'] ==
           {'type': 'str'})
    assert(spec['validate_certs'] ==
           {'type': 'bool', 'default': True})


# Generated at 2022-06-22 21:16:27.100596
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    from numbers import Number

    class TestCase(unittest.TestCase):

        def test_fun(self):

            @retry_with_delays_and_condition(generate_jittered_backoff())
            def fun(x):
                raise Exception("error")

            with self.assertRaises(Exception):
                fun("ex")

            @retry_with_delays_and_condition(generate_jittered_backoff())
            def fun2(x):
                return x

            self.assertIsInstance(fun2("ex"), Number)


    unittest.main()

# Generated at 2022-06-22 21:16:37.281577
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    s = {'resource_group': {'type': 'str'},
         'name': {'type': 'str', 'required': True},
         'state': {'type': 'str', 'default': 'present', 'choices': ['present', 'absent']}}
    res = rate_limit_argument_spec(spec=s)
    assert res == {'resource_group': {'type': 'str'},
                   'name': {'type': 'str', 'required': True},
                   'state': {'type': 'str', 'default': 'present', 'choices': ['present', 'absent']},
                   'rate': {'type': 'int'},
                   'rate_limit': {'type': 'int'}}



# Generated at 2022-06-22 21:16:40.015310
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """Unit test for function basic_auth_argument_spec"""
    assert 'api_username' in basic_auth_argument_spec()



# Generated at 2022-06-22 21:16:47.362529
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for rate_limit_decorator using a dummy rate limited func that prints max number"""
    def dummy_rate_limited(max_num):
        num = 0
        while True:
            if num >= max_num:
                return True
            yield num
            num += 1

    @rate_limit(rate=1, rate_limit=1)
    def rate_limited_dummy(max_num):
        for num in dummy_rate_limited(max_num):
            print(num)

    rate_limited_dummy(5)


# Generated at 2022-06-22 21:16:50.167705
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception)
    assert not retry_never(Exception())
    assert not retry_never(Exception('Almost any exception'))


# Generated at 2022-06-22 21:16:58.204010
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    test_spec = basic_auth_argument_spec()
    assert 'api_url' in test_spec
    assert test_spec['api_url']['type'] == 'str'
    assert 'api_username' in test_spec
    assert test_spec['api_username']['type'] == 'str'
    assert 'api_password' in test_spec
    assert test_spec['api_password']['type'] == 'str'
    assert test_spec['api_password']['no_log'] is True
    assert 'validate_certs' in test_spec
    assert test_spec['validate_certs']['type'] == 'bool'
    assert test_spec['validate_certs']['default'] is True


# Generated at 2022-06-22 21:17:09.076663
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Generate (default) jittered backoff"""
    delay = [i for i in generate_jittered_backoff()]
    assert len(delay) == 10
    assert max(delay) < delay_threshold
    assert min(delay) >= 0
    delay = [i for i in generate_jittered_backoff(retries=10, delay_base=10, delay_threshold=60)]
    assert len(delay) == 10
    assert max(delay) < delay_threshold
    assert min(delay) >= 0
    delay = [i for i in generate_jittered_backoff(retries=10, delay_base=20, delay_threshold=60)]
    assert len(delay) == 10
    assert min(delay) >= 10
    assert max(delay) <= 60

# Generated at 2022-06-22 21:17:18.531285
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    func = basic_auth_argument_spec
    mock_module = type('module', (object, ), {})()
    mock_module.params = {'api_username': 'user1', 'api_password': 'pass1', 'api_url': 'http://localhost:8080', 'validate_certs': False}
    assert func(mock_module) == {'api_username': 'user1', 'api_password': 'pass1', 'api_url': 'http://localhost:8080', 'validate_certs': False}

if __name__ == '__main__':
    exit_code = test_basic_auth_argument_spec()
    sys.exit(exit_code)

# Generated at 2022-06-22 21:17:27.077333
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    exception_names = ['A', 'B', 'C', 'D']

    def raise_exception(exception_idx):
        class ExceptionClass(Exception):
            def __str__(self):
                return exception_names[exception_idx]
        raise ExceptionClass()

    @retry_with_delays_and_condition([1, 2, 3], lambda e: str(e) not in exception_names)
    def function_that_raises_exceptions(call_count, exception_idx_to_raise):
        if len(exception_idx_to_raise) == call_count:
            return 'ok'

        raise_exception(exception_idx_to_raise[call_count])


# Generated at 2022-06-22 21:17:28.512340
# Unit test for function retry_never
def test_retry_never():
    assert (retry_never(True) is False)
    assert (retry_never(Exception('test')) is False)

# Generated at 2022-06-22 21:17:38.252556
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Unit test for function retry_argument_spec"""
    test_spec = dict(
        test_arg=dict(type='str')
    )

    expected_result = dict(
        test_arg=dict(type='str'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1)
    )

    # Test adding in "retry" arguments
    result = retry_argument_spec(test_spec)
    assert result == expected_result

    # Test adding in "retry" arguments with a blank spec
    result = retry_argument_spec()
    assert result == expected_result



# Generated at 2022-06-22 21:17:41.542193
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=3, rate_limit=10)
    def foo():
        pass
    return foo

foo = test_rate_limit()
for x in range(5):
    foo()

# Generated at 2022-06-22 21:17:52.574157
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import mock
    import unittest
    from hypothesis import given, assume, example
    from hypothesis.strategies import integers
    from hypothesis.strategies import floats

    @retry_with_delays_and_condition(backoff_iterator=[])
    def function_without_error(a, b):
        return a + b

    @retry_with_delays_and_condition(backoff_iterator=[i*2 for i in range(0, 10)])
    def function_with_error(a, b):
        error = ValueError()
        assume(a + b > 10)
        raise error


# Generated at 2022-06-22 21:17:58.622550
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.api_module import rate_limit_argument_spec
    assert rate_limit_argument_spec(spec=dict(username=dict(type='str'))) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        username=dict(type='str')
    )


# Generated at 2022-06-22 21:18:04.911616
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import inspect

    def foo():
        pass

    # Add retry_argument_spec to foo
    foo = retry_argument_spec()(foo)
    assert foo.__name__ == 'foo'
    assert 'retries' in inspect.getargspec(foo).args
    assert 'retry_pause' in inspect.getargspec(foo).args


# Generated at 2022-06-22 21:18:12.668995
# Unit test for function retry
def test_retry():
    """Unit test for the retry decorator"""

    @retry(retries=3, retry_pause=1)
    def test():
        return True

    assert test() is True

    @retry(retries=3, retry_pause=1)
    def test2():
        return False

    assert test2() is False

    @retry(retries=3, retry_pause=1)
    def test3():
        raise Exception("should retry")

    assert test3() is False

    @retry(retries=3, retry_pause=1)
    def test4():
        raise Exception("should not retry")

    try:
        test4()
    except Exception:
        pass
    else:
        assert False, "This should have failed"


# Generated at 2022-06-22 21:18:15.736446
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=basic_auth_argument_spec()
    )
    assert module.params['api_username'] == None

# Generated at 2022-06-22 21:18:19.943212
# Unit test for function retry
def test_retry():
    """Example retry on exception"""
    @retry(retries=3, retry_pause=1)
    def test():
        raise Exception("Failed")
    try:
        test()
        assert False
    except Exception:
        assert True



# Generated at 2022-06-22 21:18:24.369034
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retry_pause']['type'] == 'float'
    assert arg_spec['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:18:29.330988
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec({"param1": {"default": "sample"}}) == {
        'param1': {'default': 'sample'}, 'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}


# Generated at 2022-06-22 21:18:38.066091
# Unit test for function rate_limit
def test_rate_limit():
    import doctest
    import time

# Generated at 2022-06-22 21:18:40.078588
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg = rate_limit_argument_spec()
    assert 'rate' in arg


# Generated at 2022-06-22 21:18:43.642060
# Unit test for function retry
def test_retry():
    @retry(retries=3,  retry_pause=0.1)
    def run():
        raise Exception('Test')

    with pytest.raises(Exception) as exc:
        run()

    assert 'Retry limit exceeded' in str(exc)

# Generated at 2022-06-22 21:18:49.231593
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=25, rate_limit=1)
    def test_rate_func(param=None):
        return param

    start_time = time.time()
    # this should take 1 second
    for i in range(0,25):
        test_rate_func(i)
    # this should take 0.5 seconds
    for i in range(0,25):
        test_rate_func(i)
    end_time = time.time()
    # a bit faster then 1.5 seconds
    assert end_time - start_time < 1.6

# Generated at 2022-06-22 21:18:55.735317
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec=dict(
        foo=dict(type='str'),
        bar=dict(type='int'),
    )
    retry_arg_spec=retry_argument_spec(spec)
    assert retry_arg_spec == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        foo=dict(type='str'),
        bar=dict(type='int'),
    ), "Incorrect spec"


# Generated at 2022-06-22 21:19:00.247295
# Unit test for function retry_never
def test_retry_never():
    class TestException(Exception):
        pass

    assert retry_never(TestException()) is False
    assert retry_never(None) is False
    assert retry_never(True) is False
    assert retry_never(1) is False
    assert retry_never('test') is False



# Generated at 2022-06-22 21:19:03.265161
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }



# Generated at 2022-06-22 21:19:08.178172
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }
    assert rate_limit_argument_spec({'extra':{'type':'str'}}) == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
        'extra': {'type': 'str'}
    }



# Generated at 2022-06-22 21:19:16.822704
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = dict(
        state=dict(default='present', choices=['present', 'absent']),
    )
    test_argument_spec = retry_argument_spec(argument_spec)
    assert isinstance(test_argument_spec, dict)
    assert test_argument_spec == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        state=dict(default='present', choices=['present', 'absent']),
    )


# Generated at 2022-06-22 21:19:23.471608
# Unit test for function retry
def test_retry():
    """Unit tests for the retry decorator"""

    @retry(retries=2, retry_pause=0)
    def fail_function(result):
        """Function that returns a result or raises an exception"""
        if result:
            return result
        raise Exception("fail")

    # should retry twice, then return the result
    for i in range(0, 3):
        assert fail_function(i) == 2

    try:
        fail_function(0)
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-22 21:19:32.794480
# Unit test for function rate_limit
def test_rate_limit():
    import unittest
    import time

    class RateLimitTests(unittest.TestCase):

        def test_rate_limit_borders(self):
            @rate_limit(rate=3, rate_limit=10)
            def f():
                """sleep for less than rate_limit/rate."""
                time.sleep(2)
            elapsed = time.time()
            f()
            elapsed = time.time() - elapsed
            self.assertTrue(elapsed >= 2 and elapsed <= 3, 'elapsed time: %s' % elapsed)

        def test_rate_limit_no_rate(self):
            @rate_limit()
            def f():
                """no rate limiting."""
                time.sleep(2)
            elapsed = time.time()
            f()
            elapsed = time.time() - elapsed
            self

# Generated at 2022-06-22 21:19:34.638757
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for i in generate_jittered_backoff(20, 1, 100):
        assert 0 <= i <= 100

# Generated at 2022-06-22 21:19:41.065466
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    A set of test cases for the generic retry decorator.
    """
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def never_failing_function():
        return True

    assert never_failing_function()

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def failing_function(fail_on_try):
        if fail_on_try > 0:
            raise Exception('simulated error')
        return True

    assert failing_function(0)

    try:
        failing_function(1)
    except Exception as e:
        assert isinstance(e, Exception)
        assert e.args[0] == 'simulated error'
    else:
        assert False
