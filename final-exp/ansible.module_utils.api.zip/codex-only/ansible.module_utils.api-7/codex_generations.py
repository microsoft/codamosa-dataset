

# Generated at 2022-06-22 21:09:42.496011
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert vars(basic_auth_argument_spec()) == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }

# Generated at 2022-06-22 21:09:44.668281
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception())



# Generated at 2022-06-22 21:09:53.247521
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # First test that generator doesn't exceed threshold
    backoff_iterator = generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=30)

    for _ in range(10):
        for retry in backoff_iterator:
            assert retry <= 30

    # Second test that generator generates a variety of values
    backoff_iterator = generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=5)

    expected_values = [0, 1, 2, 3, 4, 5]

    for retry in backoff_iterator:
        assert retry in expected_values
        expected_values.remove(retry)

    assert len(expected_values) == 0

# Generated at 2022-06-22 21:09:57.113654
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {'api_username': {'type': 'str'}, 'api_password': {'no_log': True, 'type': 'str'}, 'api_url': {'type': 'str'}, 'validate_certs': {'default': True, 'type': 'bool'}}


# Generated at 2022-06-22 21:10:02.395390
# Unit test for function retry
def test_retry():
    global x
    x = 0
    @retry(retries=15, retry_pause=0.1)
    def fail_first():
        global x
        x += 1
        if x == 1:
            return False
        else:
            return True
    fail_first()
    assert (x == 2), "Test retry function"

# Generated at 2022-06-22 21:10:13.412670
# Unit test for function retry
def test_retry():
    ''' unit test for function retry '''
    class ExpectedRetriesExceededException(Exception):
        pass

    class RetryWrapper():
        def __init__(self):
            self.retry_count = 0
            self.retry_sleeps = 0

        def __call__(self, f):
            def wrapped_f(*args, **kwargs):
                self.retry_count += 1
                try:
                    return f(*args, **kwargs)
                except:
                    if self.retry_count < 3:
                        self.retry_sleeps += 1
                        raise
                    else:
                        raise ExpectedRetriesExceededException

            return wrapped_f

    @retry()
    def always_fail_function():
        raise Exception

    rw = RetryWrapper()


# Generated at 2022-06-22 21:10:24.897046
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    from unittest import mock

    # Keep this function up-to-date with the function above
    def call_counts_and_succeeds_after_4_attempts(function_to_decorate):
        # Keep this up-to-date with the test case below
        @retry_with_delays_and_condition(generate_jittered_backoff())
        def _call_counts_and_succeeds_after_4_attempts(*args, **kwargs):
            function_to_decorate()
            if args[0] == 3:
                raise ValueError("Success")
            return True
        return _call_counts_and_succeeds_after_4_attempts


# Generated at 2022-06-22 21:10:29.646992
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays_list = []
    for delay in generate_jittered_backoff(retries=10, delay_base=3,  delay_threshold=60):
        delays_list.append(delay)
    assert len(delays_list) == 10
    for delay in delays_list:
        assert delay > 0
        assert delay <= 60

# Generated at 2022-06-22 21:10:35.548590
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    res = basic_auth_argument_spec()
    assert res.get('api_username')['type'] == 'str'
    assert res.get('api_password')['type'] == 'str'
    assert res.get('api_url')['type'] == 'str'
    assert res.get('validate_certs')['type'] == 'bool'
    assert res.get('validate_certs')['default'] == True

# Generated at 2022-06-22 21:10:44.102289
# Unit test for function retry
def test_retry():
    def test_failretry(a, b):
        if a < b:
            return True
        else:
            raise Exception('test failretry')
    retry_test = retry(retries=3, retry_pause=1)
    print('*' * 20, 'retry is applied:')
    print(retry_test(test_failretry)(1, 2))

    print('*' * 20, 'retry is applied but retry_pause does not work:')
    print(retry_test(test_failretry)(2, 1))

    print('*' * 20, 'retry is not applied:')
    print(retry_test(test_failretry)(2, 2))

# Generated at 2022-06-22 21:10:47.426689
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception("")) is False
    assert retry_never("result") is False


# Generated at 2022-06-22 21:10:49.945419
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected_output = {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
    }
    rate_limit_arg_spec = rate_limit_argument_spec()
    assert rate_limit_arg_spec == expected_output


# Generated at 2022-06-22 21:11:01.301958
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=2)
    def do_something_retryable():
        print('do something that can fail')
        raise Exception('failed')

    print('do_something_retryable: 5 retries, 2 second delay between each retry')
    try:
        do_something_retryable()
    except Exception:
        print('raised exception')

    @retry(retries=None, retry_pause=1)
    def do_something_retryable_retries_none():
        print('do something that can fail')
        raise Exception('failed')

    print('do_something_retryable_retries_none: retry until successful')
    try:
        do_something_retryable_retries_none()
    except Exception:
        print('raised exception')

# Generated at 2022-06-22 21:11:04.100294
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("dummy_result") is False
    assert retry_never(Exception("dummy_error")) is False


# Generated at 2022-06-22 21:11:05.264358
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    result = basic_auth_argument_spec()
    assert len(result) == 4

# Generated at 2022-06-22 21:11:06.966895
# Unit test for function retry_never
def test_retry_never():
    err = "Some error"
    assert retry_never(err) is False


# Generated at 2022-06-22 21:11:10.172254
# Unit test for function retry
def test_retry():
    @retry(retries=3)
    def foo(retries):
        print("foo retry count %d" % retries)
        raise Exception
        return True

    foo(3)



# Generated at 2022-06-22 21:11:15.373302
# Unit test for function retry_never
def test_retry_never():
    constant_expected_value = 42
    def retry(retries):
        return constant_expected_value
    def retry_with_should_retry():
        return retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=retry_never)(retry)
    assert retry_with_should_retry() == constant_expected_value

# Generated at 2022-06-22 21:11:19.684348
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert("rate" in arg_spec)
    assert("rate_limit" in arg_spec)

    assert(arg_spec["rate"]["type"] == "int")
    assert(arg_spec["rate_limit"]["type"] == "int")

# Generated at 2022-06-22 21:11:21.687067
# Unit test for function retry_never
def test_retry_never():
    class MyException(Exception):
        pass

    assert retry_never(Exception()) is False
    assert retry_never(MyException()) is False

# Generated at 2022-06-22 21:11:28.709415
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert rate_limit_argument_spec(dict(foo=dict(type='str'))) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        foo=dict(type='str')
    )


# Generated at 2022-06-22 21:11:33.125685
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    def call_api():
        call_api.calls += 1
        raise RuntimeError("Expected error")

    call_api.calls = 0
    try:
        call_api()
    except Exception:
        pass
    assert call_api.calls == 11

# Generated at 2022-06-22 21:11:37.546719
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert "retries" in retry_spec
    assert "retry_pause" in retry_spec
    assert retry_spec["retry_pause"]["type"] == "float"
    assert retry_spec["retry_pause"]["default"] == 1


# Generated at 2022-06-22 21:11:38.956506
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never(None) == False)


# Generated at 2022-06-22 21:11:45.071757
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert([delay for delay in generate_jittered_backoff(5, 3, 60)] == [0, 3, 6, 12, 24])
    assert([delay for delay in generate_jittered_backoff(5, 100, 60)] == [0, 60, 60, 60, 60])
    assert([delay for delay in generate_jittered_backoff(5, 1, 100)] == [0, 1, 3, 7, 15])
    assert([delay for delay in generate_jittered_backoff(5, 1, 0)] == [0, 0, 0, 0, 0])
    assert([delay for delay in generate_jittered_backoff(5, 0, 0)] == [0, 0, 0, 0, 0])

# Generated at 2022-06-22 21:11:56.026873
# Unit test for function rate_limit
def test_rate_limit():
    '''rate_limit is a decorator that will limit the rate of a function calls,
       this just tests that it honors that rate
    '''
    import datetime
    import time

    # we will call this function with a rate of 3 and a minimum of 2 seconds in between calls
    @rate_limit(rate=3, rate_limit=2)
    def rate_limited_function():
        rate_limited_function.last_call = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

    rate_limited_function.last_call = None

    # call first time, should not sleep
    rate_limited_function()
    assert not rate_limited_function.last_call

    # call second time, should not sleep
    rate_limited_function()

# Generated at 2022-06-22 21:12:02.117520
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Test that basic_auth_argument_spec works as expected with valid input
    spec = {
        "api_username": {"type": "str"},
        "api_password": {"type": "str", "no_log": True},
        "api_url": {"type": "str"},
        "validate_certs": {"type": "bool", "default": True}
    }
    assert basic_auth_argument_spec() == spec



# Generated at 2022-06-22 21:12:06.091287
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for i, backoff_delay in enumerate(generate_jittered_backoff()):
        assert isinstance(backoff_delay, int)
        if i == 0:
            assert backoff_delay == 0
        if i == 1:
            assert backoff_delay == 0
        if i == 2:
            assert backoff_delay > 0
        if i == 3:
            assert backoff_delay == 3

# Generated at 2022-06-22 21:12:13.971572
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # When delay_base is greater than the delay_threshold, the delay should be capped.
    delays = list(generate_jittered_backoff(retries=2, delay_base=7, delay_threshold=6))
    assert delays == [6, 6]

    # The delay should be random for each retry.
    delays = list(generate_jittered_backoff(retries=10, delay_base=0, delay_threshold=10))
    assert delays != [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-22 21:12:23.256900
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # 10 numbers - distribution should be uniform over 3-2^10=3072
    for a in generate_jittered_backoff(10):
        print(a)

    # 20 numbers - distribution should be uniform over 3-2^20=3072
    for a in generate_jittered_backoff(20):
        print(a)

    # 3 numbers - distribution should be uniform over 3-2^3=30
    for a in generate_jittered_backoff(3):
        print(a)

    # 3 numbers with a delay_threshold of 60 should be uniform over 3-60
    for a in generate_jittered_backoff(3, delay_threshold=60):
        print(a)

    # 10 numbers with a delay_threshold of 60 should be uniform over 3-60

# Generated at 2022-06-22 21:12:29.112656
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert 'rate' in result
    assert 'rate_limit' in result

    result = rate_limit_argument_spec({'foo': 'bar'})
    assert 'foo' in result
    assert 'rate' in result
    assert 'rate_limit' in result



# Generated at 2022-06-22 21:12:39.518964
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = (dict(
        api_version=dict(type='str', default='v2'),
        validate_certs=dict(type='bool', default=True),
        endpoint_type=dict(type='str', default='publicURL'))
    )
    spec = basic_auth_argument_spec(spec)
    assert spec.get('api_username').get('type') == 'str'
    assert spec.get('api_password').get('type') == 'str'
    assert spec.get('api_url').get('type') == 'str'
    assert spec.get('api_version').get('type') == 'str'
    assert spec.get('endpoint_type').get('type') == 'str'

# Generated at 2022-06-22 21:12:42.780594
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=1)
    def foo():
        return random.randint(0, 4)

    assert(foo() == 1)
    assert(foo() == 3)


# Generated at 2022-06-22 21:12:45.745748
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception)
    assert not retry_never(None)
    assert not retry_never(True)


# Generated at 2022-06-22 21:12:48.708933
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate_limit=10, rate=100)
    def print_time():
        print(time.time())

    print_time()
    print_time()



# Generated at 2022-06-22 21:12:57.189225
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def test_should_retry_error(e):
        assert isinstance(e, ValueError)
        return True

    def test_retried_function():
        nonlocal test_retried_function_call_count
        test_retried_function_call_count += 1

        if test_retried_function_call_count > 1:
            return 42

        raise ValueError

    backoff_iterator = tuple(generate_jittered_backoff())

    test_retried_function_call_count = 0
    retried_function_retry = retry_with_delays_and_condition(backoff_iterator, test_should_retry_error)
    retried_function_retry(test_retried_function)

    assert test_retried_function_call_count == 2

# Generated at 2022-06-22 21:13:00.863921
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert arg_spec == rate_limit_argument_spec()


# Generated at 2022-06-22 21:13:10.243411
# Unit test for function retry
def test_retry():
    """
    >>> @retry(retries=5, retry_pause=1)
    ... def retryable_function():
    ...    return 0
    >>> retryable_function()
    0
    >>> @retry(retries=5, retry_pause=1)
    ... def retryable_function():
    ...    raise Exception('failure')
    >>> retryable_function()
    Traceback (most recent call last):
      ...
    Exception: Retry limit exceeded: 5
    >>> retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    Traceback (most recent call last):
      ...
    TypeError: 'NoneType' object is not callable

    """

# Generated at 2022-06-22 21:13:11.809450
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception) is False

# Simulated failure

# Generated at 2022-06-22 21:13:21.821490
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Check if value range is reasonable
    jittered_backoff = generate_jittered_backoff(retries=5, delay_base=5, delay_threshold=40)
    for delay in jittered_backoff:
        assert(delay >= 0)
        assert(delay <= 40)

    # Check if sequential values are reasonable
    jittered_backoff = generate_jittered_backoff(retries=5, delay_base=5, delay_threshold=40)
    last_value = 0
    for delay in jittered_backoff:
        assert(delay >= 0)
        assert(delay <= 40)
        assert(delay >= last_value)
        last_value = delay


# Generated at 2022-06-22 21:13:32.632235
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class TestRetry(unittest.TestCase):
        def setUp(self):
            self.call_count = 0

        def assert_count(self, count, function_callable):
            function_callable()  # Call the function
            self.assertEqual(count, self.call_count)

        def always_fails(self):
            raise Exception('Retry me!')

        def always_passes(self):
            pass

        def assert_raises(self, exception, function_callable):
            with self.assertRaises(exception):
                function_callable()

        def test_never_retry_no_delay(self):
            retry_once_callable = retry_with_delays_and_condition(
                [])(self.always_fails)


# Generated at 2022-06-22 21:13:38.391163
# Unit test for function retry
def test_retry():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(x):
        module = AnsibleModule({})
        return x

    module = retry(retries=2)(test_module)

    module_with_failures = retry(retries=3)(test_module)

    assert module(1) == 1
    # module_with_failures should fail 2 times before returning 2
    assert module_with_failures(2) == 2

# Generated at 2022-06-22 21:13:45.172350
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = {'a': {'type': 'dict'}}
    assert retry_argument_spec(spec) == \
        {'a': {'type': 'dict'}, 'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec() == \
        {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}

# Generated at 2022-06-22 21:13:56.980958
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    values = [v for v in generate_jittered_backoff()]
    assert values == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    values = [v for v in generate_jittered_backoff(10, 1, 10)]
    assert values == [0, 1, 2, 3, 3, 5, 5, 6, 9, 10]
    values = [v for v in generate_jittered_backoff(2, 3, 10)]
    assert values == [1, 8]
    values = [v for v in generate_jittered_backoff(3, 2, 1)]
    assert values == [0, 1, 1]
    values = [v for v in generate_jittered_backoff(3, 2, 3)]
    assert values == [0, 1, 1]

# Generated at 2022-06-22 21:14:05.649624
# Unit test for function rate_limit
def test_rate_limit():

    global rl_test_var

    @rate_limit(2, 1)
    def test_limit():
        if sys.version_info >= (3, 8):
            real_time = time.process_time
        else:
            real_time = time.clock
        global rl_test_var
        rl_test_var = real_time()

    global rl_test_var
    rl_test_var = 0.0
    start = time.time()

    for x in range(0, 10000):
        test_limit()

    elapsed = time.time() - start

    assert elapsed > 1.0
    print("rate_limit test took %f seconds" % elapsed)



# Generated at 2022-06-22 21:14:10.903005
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class MockException(Exception):
        pass

    class TestFunc:
        def __init__(self, side_effect=None):
            self.side_effect = side_effect
            self.call_count = 0

        def callable_side_effect(self):
            self.call_count += 1
            return self.side_effect[self.call_count - 1]

        # We want to test the run_function wrapper that the decorator puts around this function.
        # So, we use a side effect function to control the return value of the function,
        # and then we check that the side effect function was called the expected number of times.
        # If the function failed to call the side effect function the expected number of times,
        # then we would have an exception in the test.
        # The calls to the side effect function

# Generated at 2022-06-22 21:14:14.295781
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    args = rate_limit_argument_spec()
    assert args == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }


# Generated at 2022-06-22 21:14:19.940146
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module_spec = dict(
        name='test_rate_limit_argument_spec',
        argument_spec=rate_limit_argument_spec()
    )
    additional_attrs = dict(
        rate=5,
        rate_limit=1
    )

    module = AnsibleModule(**module_spec)
    module.params.update(additional_attrs)

    assert module.params['rate'] == 5
    assert module.params['rate_limit'] == 1



# Generated at 2022-06-22 21:14:24.388872
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert('retries' in retry_argument_spec(None))
    assert('retry_pause' in retry_argument_spec(None))
    assert('test' in retry_argument_spec({'test': dict(type='str')}))


# Generated at 2022-06-22 21:14:33.742681
# Unit test for function rate_limit
def test_rate_limit():
    # This test is to be run from run_tests.py
    from . import api
    expected_time = 14

    def test_f():
        return True

    test_f_rate_limited = api.rate_limit(rate=1, rate_limit=1)(test_f)

    start_time = time.time()
    for _ in range(expected_time):
        test_f_rate_limited()

    end_time = time.time()
    time_taken = end_time - start_time

    assert time_taken > expected_time
    assert time_taken < expected_time + 1


# Generated at 2022-06-22 21:14:35.219023
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert type(basic_auth_argument_spec(spec=None)) is dict



# Generated at 2022-06-22 21:14:46.142371
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest
    import itertools

    @retry_with_delays_and_condition(itertools.count(), should_retry_error=retry_never)
    def always_fails():
        raise Exception("always fails")

    @retry_with_delays_and_condition(itertools.count())
    def always_fails_and_succeeds():
        raise Exception("always fails on first attempt")

    def can_retry(e):
        raise Exception("No one should see this")

    @retry_with_delays_and_condition(itertools.count(), can_retry)
    def fails_and_succeeds():
        raise Exception("fails_and_succeeds always fails on first attempt")


# Generated at 2022-06-22 21:14:57.545891
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    #
    # Success case
    #
    called_count = 0

    def retryable_function():
        nonlocal called_count
        called_count += 1
        if called_count == 2:
            return "Success"

    wrapped_function = retry_with_delays_and_condition(
        backoff_iterator=[1, 2, 3],
        should_retry_error=retry_never,
    )(retryable_function)

    assert wrapped_function() == "Success"
    assert called_count == 2

    #
    # Exhausted backoff_iterator
    #
    called_count = 0

    def retryable_function():
        nonlocal called_count
        called_count += 1
        raise Exception(f"Failed {called_count} times")

    wrapped_function = retry

# Generated at 2022-06-22 21:15:01.140475
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()

    assert 'retries' in spec
    assert spec['retries']['type'] == 'int'
    assert 'retry_pause' in spec
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:15:05.608898
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected = {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
    }
    actual = rate_limit_argument_spec()
    assert expected == actual


# Generated at 2022-06-22 21:15:10.923296
# Unit test for function rate_limit
def test_rate_limit():
    import time
    count = 0
    sum = 0

    @rate_limit(rate=1, rate_limit=10)
    def timed_func():
        start = time.time()
        time.sleep(1)
        return time.time() - start

    while count < 20:
        count += 1
        sum += timed_func()
        print("Attempt %d: elapsed %.2f, average rate %.2f" % (count, sum, count / sum))
        time.sleep(1)


if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-22 21:15:22.142852
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import time
    import random

    retries = 10
    delay_base = 3
    delay_threshold = 60
    backoff_iterator = generate_jittered_backoff(retries, delay_base, delay_threshold)

    def function_that_always_fails():
        raise Exception('always-fail')

    def function_that_succeeds_after_n_attempts(attempts, total_retries=None, retry_errors=None):
        if total_retries is None:
            total_retries = retries
        if retry_errors is None:
            raise Exception('succeeds-after')
        if len(retry_errors) >= attempts - 1:
            return 'succeeded'
        if len(retry_errors) < total_retries:
            raise Exception

# Generated at 2022-06-22 21:15:31.292627
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert retry_spec['retries']['type'] == 'int'
    assert retry_spec['retry_pause']['type'] == 'float'
    assert retry_spec['retry_pause']['default'] == 1

    retry_spec1 = retry_argument_spec({'one': {'type': 'str'}})
    assert retry_spec1['retries']['type'] == 'int'
    assert retry_spec1['retry_pause']['type'] == 'float'
    assert retry_spec1['retry_pause']['default'] == 1
    assert retry_spec1['one']['type'] == 'str'



# Generated at 2022-06-22 21:15:36.448026
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=1)
    def _func():
        print(time.time())
    for i in range(1, 4):
        _func()


# Generated at 2022-06-22 21:15:42.702976
# Unit test for function retry
def test_retry():
    @retry(retries=2, retry_pause=1)
    def run():
        global count
        count += 1
        if count == 1:
            raise Exception('blah')
        return 'test'

    global count
    count = 0
    assert run() == 'test'
    count = 0
    try:
        run()
    except Exception as e:
        assert str(e) == 'Retry limit exceeded: 2'
    else:
        raise Exception('should have raised')



# Generated at 2022-06-22 21:15:49.064976
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # The jitter should be smaller than the delay from the exponential backoff
    for delay in generate_jittered_backoff():
        assert delay >= 0
        assert delay < (3 * 2 ** delay)

    # The maximum delay should be reached at the last iteration
    delay_iter = generate_jittered_backoff(retries=10, delay_threshold=60)
    # The actual test is to reach the max_sleep in a reasonable number of iterations
    max_sleep = delay_iter.__next__()
    for delay in delay_iter:
        assert delay < max_sleep


# Generated at 2022-06-22 21:15:51.667581
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=1)
    def test_func(i):
        print(i)
        return i

    for i in range(10):
        test_func(i)

# Generated at 2022-06-22 21:15:59.635119
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    # test rate limit spec with default arguments
    default_spec = rate_limit_argument_spec()
    assert default_spec['rate']['type'] == 'int', 'rate is not an integer'
    assert default_spec['rate_limit']['type'] == 'int', 'rate_limit is not an integer'

    # test rate limit spec with custom arguments
    custom_spec = rate_limit_argument_spec(
        dict(
            custom_rate=dict(type='float'),
            custom_rate_limit=dict(type='float'),
        ))
    assert 'rate' in custom_spec, 'rate is missing from spec'
    assert 'rate_limit' in custom_spec, 'rate_limit is missing from spec'

# Generated at 2022-06-22 21:16:03.283585
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=2)
    def test_rate_limited_function(message=None):
        print(message)

    test_rate_limited_function("Basic rate limited function")


# Generated at 2022-06-22 21:16:10.038669
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    module_args = dict()
    module_args.update(retry_argument_spec({'url': dict(type='str', required=True), 'method': dict(type='str')}))
    assert module_args == dict(
        url=dict(type='str', required=True),
        method=dict(type='str'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1)
    )


# Generated at 2022-06-22 21:16:14.357423
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestError(Exception):
        pass

    class TestError2(Exception):
        pass

    class TestError3(Exception):
        pass

    def test_should_retry_error(e):
        return type(e) == TestError

    def test_should_not_retry_error(e):
        return type(e) == TestError2

    def test_should_retry_result(result):
        return result == "retry"

    def test_should_not_retry_result(result):
        return result == "fail"

    @retry_with_delays_and_condition([1, 2, 3], test_should_retry_error)
    def raise_exception_3_times(exception):
        raise exception


# Generated at 2022-06-22 21:16:15.490348
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec().keys() == ['rate', 'rate_limit']



# Generated at 2022-06-22 21:16:17.233445
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception('oops'))


# Generated at 2022-06-22 21:16:28.058336
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit decorator"""
    def myprint(string):
        print(string)

    @rate_limit(rate=2, rate_limit=5)  # 2 requests every 5 seconds = 1 request every 2.5 seconds
    def myprint1(string):
        myprint(string)

    @rate_limit(rate=4, rate_limit=10)  # 4 requests every 10 seconds = 1 request every 2.5 seconds
    def myprint2(string):
        myprint(string)

    @rate_limit(rate=2, rate_limit=10)  # 2 requests every 10 seconds = 1 request every 5 seconds
    def myprint3(string):
        myprint(string)


# Generated at 2022-06-22 21:16:30.243351
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception())



# Generated at 2022-06-22 21:16:33.070657
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [delay for delay in generate_jittered_backoff()]
    assert len(delays) == 10
    assert all(delay <= 3 for delay in delays)

# Generated at 2022-06-22 21:16:37.282348
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec(spec={'a': {'type': 'int', 'default': 5}})
    assert spec == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        a=dict(type='int', default=5)
    )


# Generated at 2022-06-22 21:16:41.259291
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec = retry_argument_spec()
    module = AnsibleModule(argument_spec=argument_spec)
    assert module.params['retries'] == 5


# Generated at 2022-06-22 21:16:44.614515
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert arg_spec == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )


# Generated at 2022-06-22 21:16:54.827183
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.api import basic_auth_argument_spec
    import json

    module_args = dict(
        api_username="admin",
        api_password="admin",
        api_url="http://localhost",
        validate_certs=False,
        )

    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    module.check_mode = False
    module.params = module_args

    result = dict(
        api_username=module.params['api_username'],
        api_password=module.params['api_password'],
        api_url=module.params['api_url'],
        validate_certs=module.params['validate_certs'],
        )
    module.exit_

# Generated at 2022-06-22 21:17:06.167115
# Unit test for function generate_jittered_backoff

# Generated at 2022-06-22 21:17:10.208141
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert set(rate_limit_argument_spec().keys()) == {'rate', 'rate_limit'}
    assert set(rate_limit_argument_spec({'foo': {'type': 'str'}}).keys()) == {'rate', 'rate_limit', 'foo'}



# Generated at 2022-06-22 21:17:19.542125
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # A function which always throws an exception:
    def always_throws_exception(*args, **kwargs):
        raise Exception('Bad')

    # A function which throws an exception the first time it is called, and then succeds.
    def fails_first_time(*args, **kwargs):
        if fails_first_time.called == 0:
            fails_first_time.called += 1
            raise Exception('Bad')
        return True

    fails_first_time.called = 0

    # A function which throws an exception the first time, and then always suceeds.
    def always_succeeds(*args, **kwargs):
        if always_succeeds.called == 0:
            always_succeeds.called += 1
            raise Exception('Bad')
        return True

    always_succeeds.called

# Generated at 2022-06-22 21:17:22.421444
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    jittered_backoff = generate_jittered_backoff(10, 3, 60)
    for i in range(10):
        assert random.randint(0, min(60, 3 * 2 ** i)) == next(jittered_backoff)

# Generated at 2022-06-22 21:17:26.156773
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-22 21:17:37.201228
# Unit test for function rate_limit
def test_rate_limit():
    import unittest
    import mock

    class TestRateLimit(unittest.TestCase):
        def setUp(self):
            # We want to test the decorator with patched time values
            self.patchers = [mock.patch('time.clock'), mock.patch('time.process_time')]

            # We use this function for testing the decorator
            def a_function():
                return time.time()

            # We create a decorated version of our function
            # which is patched with a fixed rate_limit and rate
            # and with the patched time functions
            for patcher in self.patchers:
                patcher.start()
                time_value = time.clock()

            self.decorated_function = rate_limit(rate=1, rate_limit=1)(a_function)


# Generated at 2022-06-22 21:17:42.076988
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
    )
    assert(spec == basic_auth_argument_spec())


# Generated at 2022-06-22 21:17:52.993543
# Unit test for function rate_limit
def test_rate_limit():
    # rate_limit=3, rate=3
    # no longer than rate_limit/rate should be spent waiting
    # any timing would be acceptable, however if all the time
    # is spent waiting, we must fail.
    start = time.time()
    @rate_limit(rate=3, rate_limit=3)
    def test():
        return True
    elapsed = time.time() - start
    assert elapsed >= 1
    assert elapsed < 1.5
    # repeat 3 times, under rate
    start = time.time()
    for i in range(1,4):
        assert test()
    elapsed = time.time() - start
    assert elapsed < 1

    # repeat 6 times, over rate
    start = time.time()
    for i in range(1,7):
        assert test()
    elapsed = time.time()

# Generated at 2022-06-22 21:17:57.784543
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert 'rate' in spec
    assert 'rate_limit' in spec
    assert spec['rate']['type'] == 'int'
    assert spec['rate_limit']['type'] == 'int'



# Generated at 2022-06-22 21:18:08.796856
# Unit test for function retry
def test_retry():
    @retry()
    def fail():
        return False

    @retry(retries=2)
    def pass_once(arg):
        pass_once.calls += 1
        return pass_once.calls == arg

    pass_once.calls = 0

    assert not fail()
    assert pass_once(2)

    # retry_pause specified as float
    @retry(retry_pause=0.5)
    def fail():
        return False

    @retry(retry_pause=1, retries=5)
    def pass_once(arg):
        pass_once.calls += 1
        return pass_once.calls == arg

    pass_once.calls = 0

    assert not fail()
    assert pass_once(2)

# Generated at 2022-06-22 21:18:20.185279
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(retries=5, delay_base=4),
        should_retry_error=retry_never
    )
    def retry_never_function():
        return None

    class RetryNeverException(Exception):
        pass

    class RetryEveryException(Exception):
        pass

    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(retries=5, delay_base=4),
        should_retry_error=lambda e: isinstance(e, RetryEveryException)
    )
    def retry_every_function():
        return None

    class RetryOnlyFirstException(Exception):
        pass



# Generated at 2022-06-22 21:18:28.777527
# Unit test for function retry
def test_retry():
    @retry(3, 1.0)
    def retry_this():
        if not hasattr(retry_this, 'call_count'):
            retry_this.call_count = 0
        retry_this.call_count += 1
        if retry_this.call_count < 3:
            raise Exception
        return retry_this.call_count

    if not retry_this():
        raise Exception('retry_this did not increment call_count to 3')
    if retry_this.call_count != 3:
        raise Exception('retry_this.call_count not equal to 3')



# Generated at 2022-06-22 21:18:34.680521
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == ({'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}})
    assert rate_limit_argument_spec({'test': {'type': 'int'}}) == ({'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}, 'test': {'type': 'int'}})


# Generated at 2022-06-22 21:18:39.927251
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = list(generate_jittered_backoff(5, 3, 60))
    assert len(delays) == 5
    assert max(delays) <= 60
    assert min(delays) >= 0
    assert sum(delays) > 0

# Generated at 2022-06-22 21:18:47.969047
# Unit test for function retry
def test_retry():
    counter = 0

    @retry(retries=3)
    def simple_retry():
        global counter
        counter += 1
        return counter == 2

    simple_retry()
    assert counter == 2

    @retry(retries=3, retry_pause=0)
    def simple_retry_zero():
        global counter
        counter += 1
        return counter == 2

    simple_retry_zero()
    assert counter == 2

    @retry(retries=10)
    def simple_failure():
        global counter
        counter += 1
        return counter == 2

    try:
        simple_failure()
    except Exception:
        assert counter == 10
    else:
        assert False



# Generated at 2022-06-22 21:18:49.742698
# Unit test for function retry_never
def test_retry_never():
    exception = BaseException
    assert not retry_never(exception)


# Generated at 2022-06-22 21:18:58.691801
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global_times_called = [0]

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def func_to_retry():
        global_times_called[0] += 1
        if global_times_called[0] < 2:
            raise Exception
        return True

    assert func_to_retry() == True
    assert global_times_called[0] == 2

    # Test that exceptions are passed through
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def func_to_retry_without_error():
        raise Exception

    try:
        func_to_retry_without_error()
        raise AssertionError
    except Exception:
        pass

    # Test that exceptions are passed through

# Generated at 2022-06-22 21:19:06.689015
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    spec = {'bob': {'type': 'str'},
            'jane': {'type': 'str'},
            'john': {'type': 'str'},
            'foo': {'type': 'str', 'default': 'bar'}}

    result = rate_limit_argument_spec(spec)

    assert isinstance(result, dict)
    assert 'bob' in result
    assert 'jane' in result
    assert 'john' in result
    assert 'foo' in result
    assert 'rate' in result
    assert 'rate_limit' in result
    assert result['rate']['type'] == 'int'
    assert result['rate_limit']['type'] == 'int'



# Generated at 2022-06-22 21:19:07.842483
# Unit test for function retry_never
def test_retry_never():
    assert (retry_never(Exception('Test exception')) == False)

# Generated at 2022-06-22 21:19:14.193700
# Unit test for function rate_limit
def test_rate_limit():
    import os
    import time
    import subprocess

    tests = (
        (None, None, 1.0),
        (1, 1, 0.5),
        (5, 2, 0.5),
        (1, 10, 10.0),
        (10, 10, 1.0),
        (100, 10, 0.1),
    )
    for rate, rate_limit, expected in tests:
        print('rate: %s rate_limit: %s expected: %s' % (rate, rate_limit, expected))
        start_time = time.time()
        decorated = rate_limit(rate, rate_limit)(os.getpid)

# Generated at 2022-06-22 21:19:21.416525
# Unit test for function rate_limit
def test_rate_limit():
    # should not sleep if the time has not elapsed
    rate_limit(1,1)(print('test', flush=True))
    # should sleep if the time has elapsed
    rate_limit(1,1)(print('test2', flush=True))
    # should sleep if the time has elapsed
    rate_limit(1,1)(print('test3', flush=True))
    # should sleep if the time has elapsed
    rate_limit(1,1)(print('test4', flush=True))

# Generated at 2022-06-22 21:19:31.994379
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    try:
        run_retry_test(
            expected_delay_sequence=[0, 1, 4, 10],
            exception_on_attempt=None,
            should_retry_error=lambda exception: True
        )
        run_retry_test(
            expected_delay_sequence=[0, 1, 4, 10],
            exception_on_attempt=[0, 1, None],
            should_retry_error=lambda exception: True
        )

        run_retry_test(
            expected_delay_sequence=[0, 1, 4, 10],
            exception_on_attempt=[0, 1, None],
            should_retry_error=lambda exception: False
        )
    except Exception as ex:
        print("Test failed with exception: %s" % ex)



# Generated at 2022-06-22 21:19:36.979829
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Testing delay generator function in api module: generate_jittered_backoff.

    Make sure there are no duplicates in output.
    """
    delays = set()
    base_delay = 3
    threshold_delay = 60
    retries = 10
    for delay in generate_jittered_backoff(retries, base_delay, threshold_delay):
        delays.add(delay)
    assert(len(delays) == retries)

# Generated at 2022-06-22 21:19:42.121857
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    "This function tests the retry_argument_spec function"
    from ansible.utils.display import Display
    display = Display()
    retry_spec = retry_argument_spec()
    display.display(retry_spec, format='json')
    if retry_spec['retries']['default'] != 3:
        raise AssertionError('retry_argument_spec returned unexpected result.')
