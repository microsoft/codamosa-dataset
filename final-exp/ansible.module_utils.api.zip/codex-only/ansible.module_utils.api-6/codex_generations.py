

# Generated at 2022-06-22 21:09:44.113328
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils import basic
    # test with no spec
    args = {}
    spec = {}

    rate_limit_spec = rate_limit_argument_spec()
    basic.normalize_to_list_of_dict(rate_limit_spec)
    basic.validate_argument_spec(spec, args, rate_limit_spec, True)
    assert args['rate'] is None
    assert args['rate_limit'] is None

    # test with no default rate
    args = {}
    spec = {}
    rate_limit_spec = rate_limit_argument_spec()
    basic.normalize_to_list_of_dict(rate_limit_spec)
    basic.validate_argument_spec(spec, args, rate_limit_spec, False)
    assert args['rate'] == 1

# Generated at 2022-06-22 21:09:53.395798
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import mock
    exception_type = Exception
    exception = exception_type("Exception message")

    @retry_with_delays_and_condition(backoff_iterator=[3, 1, 4], should_retry_error=lambda e: not isinstance(e, StopIteration))
    def retryable_function():
        return "yay"

    with mock.patch("ansible.module_utils.basic.time.sleep") as mock_sleep:
        assert retryable_function() == "yay"
        mock_sleep.assert_not_called()

    with mock.patch("ansible.module_utils.basic.time.sleep") as mock_sleep:
        with mock.patch("ansible.module_utils.basic.function_wrapper") as mock_function_wrapper:
            mock_function_wrapper.side_effect = exception

# Generated at 2022-06-22 21:10:00.516992
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=300)
    def foo():
        pass

    for j in range(10):
        for i in range(10):
            foo()
        time.sleep(30)


if __name__ == '__main__':
    print('Running unit test for module: ' + __file__)
    print('\n=== begin rate_limit ===\n')
    test_rate_limit()
    print('\n=== end rate_limit ===\n')

# Generated at 2022-06-22 21:10:07.528112
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}}
    assert rate_limit_argument_spec(spec={'api_username': {'type': 'str'}}) == {'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}, 'api_username': {'type': 'str'}}



# Generated at 2022-06-22 21:10:16.497952
# Unit test for function retry
def test_retry():


    class TestException(Exception):
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3))
    def test_function():
        raise TestException

    try:
        test_function()
    except TestException:
        pass
    else:
        raise Exception("Should have not retried")

    try:
        retry_with_delays_and_condition(generate_jittered_backoff(retries=3), retry_never)(test_function)()
    except TestException:
        pass
    else:
        raise Exception("Should have not retried")

if __name__ == "__main__":
    test_retry()

# Generated at 2022-06-22 21:10:25.698254
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = dict(
        type='list',
        elements='dict',
        options=rate_limit_argument_spec()
    )
    assert rate_limit_argument_spec(result) == dict(
        type='list',
        elements='dict',
        options=(dict(
            type='dict',
            rate=dict(type='int'),
            rate_limit=dict(type='int'),
        ), dict(
            type='list',
            elements='dict',
            options=dict(
                type='dict',
                rate=dict(type='int'),
                rate_limit=dict(type='int'),
            )
        ))
    )



# Generated at 2022-06-22 21:10:29.400962
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff()
    sum_of_backoffs = 0
    for delay in generate_jittered_backoff():
        sum_of_backoffs += delay
    print(sum_of_backoffs)

# Generated at 2022-06-22 21:10:39.844603
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    # Prepare: Count how many times a function was called.
    function_call_count = 0
    def count_function(arg1, arg2, exception_on_first_call=False):
        nonlocal function_call_count
        function_call_count += 1

        if exception_on_first_call and function_call_count == 1:
            raise Exception("Exception!")
        else:
            return "function output"

    # Prepare: A few different backoff generators
    backoff_iterator_no_delays = []
    backoff_iterator_single_delay = [1]
    backoff_iterator_multiple_delays = [1, 2, 3]
    backoff_iterator_zero_delay = [0]

    # Prepare: A few different conditions to check

# Generated at 2022-06-22 21:10:41.646768
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception('anything')) is False



# Generated at 2022-06-22 21:10:51.846577
# Unit test for function rate_limit
def test_rate_limit():
    from nose.tools import assert_equal, assert_greater
    from timeit import default_timer as timer

    # Tests for function rate_limit

    # Test 1 - rate_limit 100 calls per second, should finish in less than 10 seconds
    #          actual time is usually around 0.01 to 0.1 seconds
    @rate_limit(rate=100, rate_limit=1)
    def rate_limited_call(number):
        return number

    start = timer()
    for i in range(100):
        assert_equal(rate_limited_call(i), i)
    end = timer()
    assert_greater(end - start, 0.0)
    assert_greater(10.0, end - start)

    # Test 2 - rate_limit 500 calls per second, should finish in less than 10 seconds
    #          actual time is

# Generated at 2022-06-22 21:10:53.023467
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception('Boom!')) is False


# Generated at 2022-06-22 21:11:03.704546
# Unit test for function retry
def test_retry():
    def add(x, y):
        return x + y

    def retry_3_times(e):
        return True

    def never_retry(e):
        return False

    # The EXPECTED retries is 3, but since each call is immediate, we will just call it twice
    add_retry = retry_with_delays_and_condition(generate_jittered_backoff(retries=3), should_retry_error=retry_3_times)(add)
    assert add_retry(2, 1) == 3

    add_retry2 = retry_with_delays_and_condition(generate_jittered_backoff(retries=3), should_retry_error=never_retry)(add)
    assert add_retry2(2, 1) == 3

# Unit

# Generated at 2022-06-22 21:11:12.954195
# Unit test for function rate_limit
def test_rate_limit():
    """test rate_limit decorator"""

    # 1,000 requests in 10 seconds
    @rate_limit(rate=1000, rate_limit=10)
    def test():
        "test"

    # first call is always fine
    last = time.time()
    test()

    # 1 request per second, should be fine
    current = time.time()
    diff = current - last
    if diff != 1:
        raise Exception("1 request per second failed, difference is %d instead of 1" % diff)

    # 500 requests per second, should fail
    last = current
    for x in range(0, 500):
        test()
    current = time.time()
    diff = current - last
    if diff != 6:
        raise Exception("500 request per second failed, difference is %d instead of 6" % diff)

# Generated at 2022-06-22 21:11:13.816063
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        print('delay:', delay)

# Generated at 2022-06-22 21:11:19.160870
# Unit test for function rate_limit
def test_rate_limit():
    this_rate_limiter = rate_limit(1, 1)
    this_rate_limited_func = this_rate_limiter(lambda: 'foo')
    counter = 0

    while True:
        counter += 1
        if counter >= 10:
            break
        print( this_rate_limited_func())


# Generated at 2022-06-22 21:11:20.521076
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('exception') == False


# Generated at 2022-06-22 21:11:26.771746
# Unit test for function rate_limit
def test_rate_limit():
    import datetime
    start = datetime.datetime.now()

    @rate_limit(rate=100, rate_limit=60)
    def expensive_rate_limited_function():
        print('expensive function')

    for i in range(0, 200):
        expensive_rate_limited_function()

    end = datetime.datetime.now()
    assert (end - start).seconds == 2, 'expensive function should be rate limited'

# Generated at 2022-06-22 21:11:38.167976
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec(spec=dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str', default='https://localhost'),
        validate_certs=dict(type='bool', default=False)
    ))
    assert 'retries' in arg_spec, "retry argument spec should contain 'retries' as key"
    retries = arg_spec['retries']
    assert 'type' in retries, "retry argument spec 'retries' should contain 'type' as key"
    assert retries['type'] == 'int', "retry argument spec 'retries' should be of type 'int'"

# Generated at 2022-06-22 21:11:42.575490
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    params = {
        'api_username': 'test_user',
        'api_password': '123456',
        'api_url': 'http://www.google.com'
    }
    assert all (item in arg_spec.keys() for item in params.keys()), "basic_auth_argument_spec() returns wrong arg_spec."

    arg_spec = basic_auth_argument_spec(spec=params)
    for key, value in params.items():
        assert arg_spec[key]['type'] == 'str', "basic_auth_argument_spec() returns wrong type({}) for key({})".format(arg_spec[key]['type'], key)

# Generated at 2022-06-22 21:11:53.053919
# Unit test for function retry_never
def test_retry_never():
    from unittest import TestCase

    class DummyError(Exception):
        pass

    def assert_error_raised(error_class):
        with TestCase().assertRaises(error_class):
            pass

    assert_error_raised(DummyError)

    @retry_with_delays_and_condition(backoff_iterator=(), should_retry_error=retry_never)
    def f():
        raise DummyError()

    assert_error_raised(DummyError)

    # No errors when no exceptions are raised
    @retry_with_delays_and_condition(backoff_iterator=(), should_retry_error=retry_never)
    def f():
        return 42

    assert f() == 42

# Generated at 2022-06-22 21:11:55.507110
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(StandardError('foo'))
    assert not retry_never('foo')



# Generated at 2022-06-22 21:11:59.492542
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    actual = rate_limit_argument_spec()
    expected = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert actual == expected, "rate_limit_argument_spec failed"


# Generated at 2022-06-22 21:12:07.472182
# Unit test for function retry
def test_retry():
    """Test the retry decorator"""
    def try_three_times(arg):
        """A function that will probably fail the first two times"""
        if arg == 0:
            raise Exception("too soon")
        if arg == 1:
            raise Exception("that didn't work")
        if arg == 2:
            return arg

    # No retry, should fail
    no_retry = retry(0)(try_three_times)
    try:
        no_retry(0)
        assert False
    except Exception as e:
        assert "too soon" in e.message

    # Normal retry
    normal_retry = retry(3)(try_three_times)
    result = normal_retry(0)
    assert result == 2

    # Inf retry, should fail
    inf_retry = retry()

# Generated at 2022-06-22 21:12:09.819896
# Unit test for function retry_never
def test_retry_never():
    result = retry_never("Fake Error")
    assert result is False
    assert retry_never("Fake Error") is False

# Generated at 2022-06-22 21:12:17.222025
# Unit test for function retry_never
def test_retry_never():
    r = retry_never('test')
    assert r is False, "retry_never() with a string should return False"

    r = retry_never(None)
    assert r is False, "retry_never() with None should return False"

    r = retry_never(False)
    assert r is False, "retry_never() with False should return False"

    r = retry_never(Exception())
    assert r is False, "retry_never() with Exception should return False"


# Generated at 2022-06-22 21:12:24.378364
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    expected = [1, 9, 13, 1, 5]
    backoff_iterator = iter(expected)
    retries = 0
    expected_exception = Exception('expected')

    def to_retry_on(exception):
        if retries < 2 and exception == expected_exception:
            return True
        return False

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error=to_retry_on)
    def function_to_test():
        nonlocal retries
        retries += 1
        if retries != len(expected):
            raise expected_exception
        return True

    function_to_test()
    assert(retries == len(expected))

# Generated at 2022-06-22 21:12:28.179314
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert isinstance(retry_spec, dict)
    assert 'retries' in retry_spec
    assert 'retry_pause' in retry_spec
    assert 'type' in retry_spec['retries']
    assert 'type' in retry_spec['retry_pause']



# Generated at 2022-06-22 21:12:32.363822
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(2, 1)
    def my_slow_function():
        time.sleep(0.4)
    t1 = time.time()
    my_slow_function()
    my_slow_function()
    my_slow_function()
    t2 = time.time()
    assert t2 - t1 >= 1.0
    assert t2 - t1 < 1.5


# Generated at 2022-06-22 21:12:42.426030
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """
    Test case for function rate_limit_argument_spec
    """
    import json
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=rate_limit_argument_spec())
    data = module.params
    compare_dict = {'rate': 1, 'rate_limit': 2}
    if data != compare_dict:
        module.fail_json(msg="rate_limit_argument_spec.test_rate_limit_argument_spec: failed")

    data = json.dumps(data)
    compare_dict = json.dumps(compare_dict)
    if data != compare_dict:
        module.fail_json(msg="rate_limit_argument_spec.test_rate_limit_argument_spec: failed")

# Generated at 2022-06-22 21:12:53.677298
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_float
    from ansible.module_utils.common.validation import check_type_int
    from ansible.module_utils.common.validation import is_integer

    args = dict(
        retry_pause=dict(type='float', default=1),
        retries=dict(type='int')
    )
    spec = dict(
        retry_pause=dict(type='float', default=1),
        retries=dict(type='int', required=True)
    )
    module = MockModule()
    module.params = dict(
        retry_pause="1",
        retries=10
    )

# Generated at 2022-06-22 21:13:01.785356
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert 'retries' in retry_argument_spec().keys()
    assert 'retry_pause' in retry_argument_spec().keys()
    assert len(retry_argument_spec()) == 2
    assert 'iam_endpoint' in retry_argument_spec({'iam_endpoint': {'type': 'str', 'required': True}}).keys()
    assert len(retry_argument_spec({'iam_endpoint': {'type': 'str', 'required': True}})) == 3


# Generated at 2022-06-22 21:13:10.761790
# Unit test for function rate_limit
def test_rate_limit():
    rate_limit_ok = False

    @rate_limit(rate=10, rate_limit=1)
    def test_rate_limited():
        return True

    # Test rate
    start_time = time.clock()
    for i in range(0, 9):
        test_rate_limited()
    finish_time = time.clock()
    time_elapsed = finish_time - start_time
    rate_limit_ok = time_elapsed > 0.9
    assert rate_limit_ok is True

    # Test rate_limit
    start_time = time.clock()
    for i in range(0, 9):
        test_rate_limited()
    finish_time = time.clock()
    time_elapsed = finish_time - start_time
    rate_limit_ok = time_elapsed > 0.9


# Generated at 2022-06-22 21:13:20.094009
# Unit test for function retry
def test_retry():
    num_tries = 0
    num_tries_max = 5
    retry_pause = 1

    @retry(retries=num_tries_max, retry_pause=retry_pause)
    def test_retry_func():
        global num_tries
        num_tries += 1
        if num_tries < num_tries_max:
            return False
        else:
            return True

    test_retry_func()
    assert num_tries == num_tries_max



# Generated at 2022-06-22 21:13:24.146742
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )



# Generated at 2022-06-22 21:13:33.805913
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Verify that the first number is between 0 and base.
    # That the next number is between base and 2*base, etc.
    # That the last number is below threshold

    # The example in the article is "1, 2, 4, 8, 16, 16, 16, 16, 16, 16"
    jittered_backoff_list = list(generate_jittered_backoff(10, 1, 16))
    assert jittered_backoff_list[0] >= 0 and jittered_backoff_list[0] < 1
    assert jittered_backoff_list[1] >= 1 and jittered_backoff_list[1] < 2
    assert jittered_backoff_list[2] >= 2 and jittered_backoff_list[2] < 4
    assert jittered_backoff_list[3] >= 4 and jittered

# Generated at 2022-06-22 21:13:36.244074
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )



# Generated at 2022-06-22 21:13:46.608789
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit

    :returns: True if test was successful, otherwise False
    """
    import time
    import threading

    def function_with_decorator():
        """Do nothing function"""
        pass

    # Start execution time
    start_time = time.clock()

    # Ten executions of the rate limited function
    for x in range(0, 10):
        function_with_decorator()
        time.sleep(0.1)

    # Difference of execution time
    difference_time = time.clock() - start_time

    # Check difference time is greater than 1 sec
    # to prove rate limiting
    if difference_time > 1:
        return True
    else:
        return False



# Generated at 2022-06-22 21:13:55.002397
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.net_tools.nxos import nxos_module
    retry_spec = retry_argument_spec()
    rate_spec = rate_limit_argument_spec()
    all_specs = rate_spec.copy()
    all_specs.update(retry_spec)
    module = AnsibleModule(argument_spec=all_specs, supports_check_mode=False)
    module = nxos_module(module, None)

# Generated at 2022-06-22 21:14:02.329788
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec(spec = {'argument1': {'type': 'int', 'required': True}})
    assert(spec == {'argument1': {'type': 'int', 'required': True}, 'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}})
    spec = retry_argument_spec()
    assert(spec == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}})

# Generated at 2022-06-22 21:14:06.943688
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    arg_spec = rate_limit_argument_spec()
    assert arg_spec == spec


# Generated at 2022-06-22 21:14:08.871968
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False



# Generated at 2022-06-22 21:14:13.973440
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        one=dict(type='str'),
        two=dict(type='str')
    )
    result = retry_argument_spec(spec)
    assert result['retries']['type'] == 'int'
    assert result['retry_pause']['type'] == 'float'
    assert result['retry_pause']['default'] == 1
    assert result['one']['type'] == 'str'
    assert result['two']['type'] == 'str'

# Generated at 2022-06-22 21:14:21.923629
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    test_results = list()

    def fake_function_run():
        try:
            test_results.append('running')
            raise RuntimeError('should retry')
        except Exception as e:
            test_results.append('exception')
            raise e
        else:
            test_results.append('success')

        return True

    retry_with_delay_and_condition_function = retry_with_delays_and_condition(generate_jittered_backoff(3), retry_never)
    test_function = retry_with_delay_and_condition_function(fake_function_run)

    assert test_function() is True
    assert test_results == ['running', 'exception']


# Generated at 2022-06-22 21:14:23.476666
# Unit test for function retry_never
def test_retry_never():
    try:
        raise Exception()
    except Exception as e:
        assert retry_never(e) is False


# Generated at 2022-06-22 21:14:34.472453
# Unit test for function retry
def test_retry():
    class BooBam(Exception):
        pass

    class Boom(Exception):
        pass

    # Three tries, pauses of 1, 2, 4 seconds
    @retry(retries=3, retry_pause=1)
    def raise_boo_bam():
        raise BooBam("Boo Bam")

    # Fail immediately
    @retry(retries=3, retry_pause=1)
    def raise_boom():
        raise Boom("Boom")

    try:
        raise_boo_bam()
        raise AssertionError("Should have thrown an exception")
    except BooBam:
        pass

    try:
        raise_boom()
        raise AssertionError("Should have thrown an exception")
    except Boom:
        pass


if __name__ == '__main__':
    test

# Generated at 2022-06-22 21:14:40.733184
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # Argument spec that has retry_pause_type as float
    arg_spec = retry_argument_spec()
    assert arg_spec['retry_pause']['type'] == 'float'

    # Argument spec that has retry_pause_type as string
    arg_spec = retry_argument_spec(dict(retry_pause=dict(type='str')))
    assert arg_spec['retry_pause']['type'] == 'str'


# Generated at 2022-06-22 21:14:43.043871
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception) is False


# Generated at 2022-06-22 21:14:50.780547
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = iter(generate_jittered_backoff(retries=3))

    def function(result):
        return result

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error=retry_never)
    def test_function_with_delays_and_condition(result):
        return function(result)

    # Each delay does not affect the subsequent ones
    assert_delays_are_increasing_but_not_accumulating(test_function_with_delays_and_condition)

    # If function returns correctly, we should not hit exception case
    assert test_function_with_delays_and_condition(1) == 1
    assert test_function_with_delays_and_condition(2) == 2



# Generated at 2022-06-22 21:14:55.764779
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }

# Generated at 2022-06-22 21:15:00.090147
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert isinstance(spec, dict)
    assert len(spec) == 2

    for k, v in spec.items():
        assert isinstance(k, str)
        assert isinstance(v, dict)
        assert len(v) == 1
        for t in v.values():
            assert isinstance(t, str)


# Generated at 2022-06-22 21:15:02.804400
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert(basic_auth_argument_spec())

# Generated at 2022-06-22 21:15:07.672993
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module_args = dict(
        rate=5,
        rate_limit=5,
        validate_certs=False,
        ansible_ssh_user='root',
        ansible_ssh_pass='test'
    )
    spec = rate_limit_argument_spec()
    assert spec == rate_limit_argument_spec(spec)
    assert not spec == {'rate': None}

# Generated at 2022-06-22 21:15:09.804567
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('foo') == False


# Generated at 2022-06-22 21:15:20.312965
# Unit test for function rate_limit
def test_rate_limit():
    """Unit tests for rate limit decorator"""
    import time

    @rate_limit(rate=1, rate_limit=1)
    def limited():
        return time.time()

    start = time.time()
    for i in range(0, 5):
        limited()
    end = time.time()
    assert (end - start) >= 5

    @rate_limit(rate=10, rate_limit=10)
    def limited():
        return time.time()

    start = time.time()
    for i in range(0, 50):
        limited()
    end = time.time()
    assert (end - start) < 20

    # faster then rate limit
    @rate_limit(rate=100, rate_limit=1)
    def limited():
        return time.time()

    start = time.time()


# Generated at 2022-06-22 21:15:30.851306
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # This decorator implements a "Full Jitter" backoff strategy.
    # See https://www.awsarchitectureblog.com/2015/03/backoff.html for further details.
    randomized_backoff_generator = generate_jittered_backoff()

    # Retry five times, the max number of times we will try to invoke get_retryable_function.
    # The max delay time between retries is 60 seconds.
    retryable_decorator = retry_with_delays_and_condition(randomized_backoff_generator, retries=5, delay_threshold=60)

    @retryable_decorator
    def get_retryable_function():
        failure_rate = 0.25
        if random.random() < failure_rate:
            raise Exception("Retryable error!")


# Generated at 2022-06-22 21:15:35.058370
# Unit test for function retry
def test_retry():

    global counter

    @retry(retries=3, retry_pause=0.001)
    def test(inp, outp=None):
        global counter
        counter += 1
        if outp == counter:
            return True
        else:
            return False

    global counter
    counter = 0
    assert test(2, 2) is True
    assert test(2, 2) is False
    assert test(1, 1) is True
    assert counter == 3

# Generated at 2022-06-22 21:15:39.909200
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    plugin_spec = dict(
        name=dict(type='str', required=True),
    )
    expected = dict(
        name=dict(type='str', required=True),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert expected == rate_limit_argument_spec(plugin_spec)



# Generated at 2022-06-22 21:15:45.010524
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.api import basic_auth_argument_spec
    argspec = basic_auth_argument_spec()
    assert argspec
    assert argspec.get('api_username')
    assert argspec.get('api_password')
    assert argspec.get('api_url')
    assert argspec.get('validate_certs')

# Generated at 2022-06-22 21:15:51.372749
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    module = AnsibleModule(
        argument_spec=rate_limit_argument_spec()
    )

    rate = module.params['rate']
    rate_limit = module.params['rate_limit']

    @rate_limit(rate, rate_limit)
    def rate_limited_function():
        return 'not rate limited'

    result = rate_limited_function()
    assert result == 'not rate limited'



# Generated at 2022-06-22 21:15:56.591033
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        one=dict(required=True, type='int'),
        two=dict(required=False, type='list'),
    )
    arg_spec = retry_argument_spec(spec)
    assert arg_spec['one']['required'] is True
    assert arg_spec['two']['required'] is False
    assert arg_spec['retry_pause']['default'] == 1

# Generated at 2022-06-22 21:15:59.279794
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert 'rate' in arg_spec
    assert 'rate_limit' in arg_spec


# Generated at 2022-06-22 21:16:01.087949
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    with pytest.raises(TypeError) as excinfo:
        rate_limit_argument_spec()


# Generated at 2022-06-22 21:16:11.101346
# Unit test for function retry
def test_retry():
    """An example of testing the retry function"""
    # FIXME: Remove when dropping Python 2.
    global __name__
    __name__ = '__main__'  # Trick the retry decorator to believe that this is the main module.

    # Test the wrapper
    # FIXME: This is not a unit test, this is merely an example of how to use the retry decorator.
    @retry(retries=10, retry_pause=1)
    def _test_retry():
        return 1 / 0

    # Test the actual decorator
    try:
        _test_retry()
    except Exception:
        print("Exception handled by decorator")


if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-22 21:16:13.890380
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    l = [x for x in generate_jittered_backoff(retries=10, delay_base=10, delay_threshold=100)]
    assert len(l) == 10
    assert min(l) >= 0
    assert max(l) <= 100

# Generated at 2022-06-22 21:16:17.932120
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
        "api_username": {"required": False, "type": "str"},
        "api_password": {"required": False, "type": "str", "no_log": True},
        "api_url": {"required": False, "type": "str"},
        "validate_certs": {"required": False, "type": "bool", "default": True},
    }

# Generated at 2022-06-22 21:16:23.014194
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    result = retry_argument_spec()
    assert result['retries']['type'] == 'int'
    assert result['retry_pause']['type'] == 'float'
    assert result['retry_pause']['default'] == 1



# Generated at 2022-06-22 21:16:25.921569
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retry_pause=dict(
            type='float',
            default=1
        ),
        retries=dict(
            type='int'
        )
    )

# Generated at 2022-06-22 21:16:27.951451
# Unit test for function retry_never
def test_retry_never():
    # Retry function never retries
    assert not retry_never("result")
    assert not retry_never("Exception")

# Generated at 2022-06-22 21:16:35.745351
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    print('Testing test_basic_auth_argument_spec:')
    assert('api_username' in basic_auth_argument_spec()), 'test_basic_auth_argument_spec - api_username not in arg spec'
    assert('api_password' in basic_auth_argument_spec()), 'test_basic_auth_argument_spec - api_password not in arg spec'
    assert('api_url' in basic_auth_argument_spec()), 'test_basic_auth_argument_spec - api_url not in arg spec'


# Generated at 2022-06-22 21:16:37.091756
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('foo') == False


# Generated at 2022-06-22 21:16:41.182711
# Unit test for function retry_argument_spec
def test_retry_argument_spec():

    result = retry_argument_spec()

    assert result == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}, 'retry_argument_spec unit test failed!'

# Generated at 2022-06-22 21:16:44.435801
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

    assert rate_limit_argument_spec() == rate_spec


# Generated at 2022-06-22 21:16:46.495140
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    expected_result = {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }
    input = {}
    output = retry_argument_spec(input)
    assert output == expected_result, 'Unexpected output for function retry_argument_spec'

# Generated at 2022-06-22 21:16:55.875168
# Unit test for function retry
def test_retry():
    """Unit test for function retry"""
    # pylint: disable=too-many-locals
    # import retry decorator
    from ansible.module_utils.basic import AnsibleModule  # noqa: F401

    RETRIES = 5
    RETRY_PAUSE = 10

    # pylint: disable=too-many-locals,too-many-statements,invalid-name,bare-except
    test_module = sys.modules[__name__]

    class TestModule(AnsibleModule):
        """AnsibleModule class"""
        fail = False

    # initialize module
    module = TestModule(
        argument_spec=retry_argument_spec(),
        supports_check_mode=True
    )

    module.fail = False

    # function to test

# Generated at 2022-06-22 21:17:06.992603
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.api import basic_auth_argument_spec

    def basic_auth_argument_spec_test(self):
        with patch.object(fetch_url,'__init__') as mocked_init:
            mocked_init.return_value = None
            self.assertIn('api_username',basic_auth_argument_spec())
            self.assertIn('api_password',basic_auth_argument_spec())
            self.assertIn('api_url',basic_auth_argument_spec())
            self.assertIn('validate_certs',basic_auth_argument_spec())

# Generated at 2022-06-22 21:17:13.889947
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoffs = [next(generate_jittered_backoff(10, 3, 60)) for i in range(10)]

    # Check if the lenght of the returned list is correct
    assert len(backoffs) == 10

    # Check if the generated values are in the appropriate range
    assert all([0 < backoff < 60 for backoff in backoffs])



# Generated at 2022-06-22 21:17:22.226391
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert rate_limit_argument_spec(dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
    )) == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )


# Generated at 2022-06-22 21:17:23.493031
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception()), "retry_never should always return False"

# Generated at 2022-06-22 21:17:25.503525
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception)

# Unit testing for function generate_jittered_backoff

# Generated at 2022-06-22 21:17:30.037935
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module_args = {
            'api_username': 'foo',
            'api_password': 'bar',
            'api_url': 'http://0.0.0.0:8080',
            'validate_certs': True
        }
    expected = module_args
    result = basic_auth_argument_spec(module_args)
    assert result == expected


# Generated at 2022-06-22 21:17:38.775464
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    import random

    class MyException(Exception):
        pass

    def retry_if_random(exception):
        return random.randint(0, 1)

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_if_random)
    def my_function():
        raise MyException

    # The test is to make sure we eventually get a retry
    # but we can't be sure how long it will take since it's randomized
    try:
        my_function()
        raise AssertionError()
    except MyException:
        pass

# Generated at 2022-06-22 21:17:46.927300
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Unit Test for function retry_argument_spec"""
    new_arg_spec = retry_argument_spec(dict(
        retry_pause=dict(type='float', default=None),
    ))
    assert 'retries' in new_arg_spec
    assert 'retry_pause' in new_arg_spec
    assert 'float' == new_arg_spec['retry_pause']['type']
    assert None == new_arg_spec['retry_pause']['default']

# Generated at 2022-06-22 21:17:50.618548
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert "api_username" in basic_auth_argument_spec()
    assert "api_password" in basic_auth_argument_spec()
    assert "api_url" in basic_auth_argument_spec()
    assert "validate_certs" in basic_auth_argument_spec()

# Generated at 2022-06-22 21:17:52.900734
# Unit test for function retry_never
def test_retry_never():
    try:
        raise Exception()
    except Exception:
        assert retry_never(Exception) is False

# Generated at 2022-06-22 21:17:57.430657
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff()
    backoff_list = list(backoff_iterator)
    assert backoff_list[0] == 0
    assert backoff_list[-1] <= 60
    assert len(backoff_list) == 10


# Generated at 2022-06-22 21:18:07.053827
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_generator = generate_jittered_backoff(retries=3, delay_base=3)

    actual_list = []
    delay_list = (1, 2, 4)
    for i in delay_generator:
        actual_list.append(i)

    assert delay_list == actual_list

    delay_generator = generate_jittered_backoff(retries=2, delay_base=2, delay_threshold=5)

    actual_list = []
    delay_list = (3, 5)
    for i in delay_generator:
        actual_list.append(i)
    assert delay_list == actual_list

# Generated at 2022-06-22 21:18:11.216344
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    sys.modules["__main__"] = type('', (), {})()
    sys.modules["__main__"].module = type('', (), {})()
    sys.modules["__main__"].module.params = {'api_username': 'foo', 'api_password': 'bar', 'api_url': 'qaz',
                                             'validate_certs': True}
    basic_auth_argument_spec()

# Generated at 2022-06-22 21:18:22.114678
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(),
                                      should_retry_error=lambda e: e == 'retry')
    def foo(retry_count, should_fail):
        if retry_count == 0 and should_fail:
            raise Exception('retry')
        elif retry_count == 1 and should_fail:
            raise Exception('noretry')
        else:
            return "success"

    # Unit test for function retry_with_delays_and_condition
    # Should raise exception
    try:
        foo(0, True)
        assert False
    except:
        assert True

    # Should succeed
    assert foo(0, False) == "success"

    # Should fail on last attempt

# Generated at 2022-06-22 21:18:24.848531
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = change_argument_spec()
    assert all(k in spec for k in ('api_username', 'api_password', 'api_url', 'validate_certs'))


# Generated at 2022-06-22 21:18:31.027791
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=5, delay_base=3, delay_threshold=30)
    backoff_iterator_steps = list(backoff_iterator)
    assert len(backoff_iterator_steps) == 5
    for backoff_step in backoff_iterator_steps:
        assert backoff_step >= 0 and backoff_step <= 30

# Generated at 2022-06-22 21:18:35.504155
# Unit test for function retry
def test_retry():
    """Test retrying function."""
    @retry(retries=3, retry_pause=1)
    def _test_retry(count):
        if count > 0:
            count -= 1
            raise Exception("count is not zero")
        return count

    val = _test_retry(3)
    assert val == 0

# Generated at 2022-06-22 21:18:42.261249
# Unit test for function retry_never
def test_retry_never():
    def exception_raiser(raise_exception=False):
        if raise_exception:
            raise Exception
    decorator = retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    assertCallSucceeds(exception_raiser, decorator)


# Generated at 2022-06-22 21:18:45.067591
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition((1, 1, 1))
    def f():
        """Simple function to test retry_with_delays_and_condition."""
        raise Exception()
    f()

# Generated at 2022-06-22 21:18:55.655203
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Example next_delay_generator
    def next_delay_generator():
        for delay in generate_jittered_backoff(retries=3):
            yield delay

    # Example exception handler
    def should_retry_exception(exception):
        return True

    # Example function
    def raises_exception(raise_exception):
        if raise_exception:
            raise Exception('foo')
        return True

    # Can execute without exception
    retried = retry_with_delays_and_condition(next_delay_generator(), should_retry_error=should_retry_exception)(raises_exception)
    assert retried(raise_exception=False)

    # Can execute with retries

# Generated at 2022-06-22 21:18:58.445609
# Unit test for function retry_never
def test_retry_never():
    try:
        raise Exception("Testing")
    except Exception as e:
        assert retry_never(e) == False


# Generated at 2022-06-22 21:19:08.100962
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # fake function that will raise an error until we reach the last attempt
    def retryable_function(attempt_number):
        if attempt_number < 6:
            raise ValueError('function failed')
        else:
            # success!
            return 'success'

    # we'll call the same function with a backoff iterator that has 6 delays,
    # and a condition that tells us to retry if attempt_number is < 6

    wrapped_function = retry_with_delays_and_condition(generate_jittered_backoff(retries=6, delay_base=2), should_retry_error=lambda e: e.args[0] != 'function failed')
    assert wrapped_function(attempt_number=5) == 'success'

    # Test with a shorter backoff iterator, to ensure that the should_retry_error condition

# Generated at 2022-06-22 21:19:10.167611
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    class TestRateLimit(unittest.TestCase):

        def test_rate_limit(self):
            rate_limit(rate=2, rate_limit=2)(lambda: None)()

# Generated at 2022-06-22 21:19:14.048808
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result == {'rate': {'type': 'int'},
                      'rate_limit': {'type': 'int'}}, "rate_limit_argument_spec does not work"

# Generated at 2022-06-22 21:19:24.344446
# Unit test for function retry
def test_retry():
    should_retry_error = lambda x: True
    run_count = [0]
    expected = "expected"

    @retry_with_delays_and_condition(generate_jittered_backoff(5))
    def always_fails():
        run_count[0] += 1
        raise Exception("boom")
        return "boom"

    try:
        always_fails()
    except Exception as e:
        assert str(e) == "boom"

    assert run_count[0] == 6

    run_count[0] = 0

    @retry_with_delays_and_condition(generate_jittered_backoff(5))
    def always_succeeds():
        run_count[0] += 1
        return expected

    resp = always_succeeds()

# Generated at 2022-06-22 21:19:28.969892
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=80)
    for retry_count in range(1, 11):
        delay = next(backoff_iterator)

        # Assert delay within range
        assert ((delay >= (retry_count - 1) * 3) and (delay <= (retry_count * 3)))



# Generated at 2022-06-22 21:19:33.455348
# Unit test for function retry
def test_retry():
    """ Unit test for function retry """
    @retry(3, 1)
    def my_test():
        """ test retry """
        return None

    with pytest.raises(Exception) as ex:
        my_test()

    assert str(ex.value) == "Retry limit exceeded: 3"


# Generated at 2022-06-22 21:19:35.534581
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception('this is an error')) is False
    assert retry_never('this is a result') is False
