

# Generated at 2022-06-22 21:09:44.112304
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=3, delay_base=1, delay_threshold=1))
    def test_function(n_times):
        if n_times < 0:
            raise ValueError('n_times must be non-negative')
        elif n_times > 0:
            raise Exception('retry attempt')

    # exercise the function with a valid value
    test_function(n_times=0)

    # exercise the function with invalid values, which should be retried before raising the exception

# Generated at 2022-06-22 21:09:55.295842
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class Exception0(Exception):
        pass

    class Exception1(Exception):
        pass

    # Test with retry_never which should never retry
    @retry_with_delays_and_condition(iter([1, 2, 3]))
    def function_1a(*args, **kwargs):
        if 'e' in kwargs:
            raise kwargs['e']
        else:
            return True

    class TestCase(unittest.TestCase):
        def test_true_with_no_args_or_kwargs(self):
            self.assertTrue(function_1a())

        def test_raises_exception0_when_passed_as_kwarg(self):
            self.assertRaises(Exception0, function_1a, e=Exception0())

       

# Generated at 2022-06-22 21:10:01.001775
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=5)
    backoff = list(backoff_iterator)
    assert len(backoff) == 10
    assert backoff[0] > 0
    assert backoff[0] < 5
    assert backoff == [2, 1, 3, 3, 3, 3, 3, 3, 3, 3]

# Generated at 2022-06-22 21:10:09.101037
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert arg_spec == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
    }

    arg_spec = rate_limit_argument_spec({'rate': {'type': 'int', 'aliases': ['rate_limit']}})
    assert arg_spec == {
        'rate': {'type': 'int', 'aliases': ['rate_limit']},
        'rate_limit': {'type': 'int'},
    }



# Generated at 2022-06-22 21:10:09.690029
# Unit test for function rate_limit
def test_rate_limit():
    pass

# Generated at 2022-06-22 21:10:13.910742
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=1)
    def f():
        return True

    assert f() is True
    assert f() is True
    try:
        f()
        assert False
    except Exception:
        pass



# Generated at 2022-06-22 21:10:19.541182
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # First attempt has no delay, next two have delays of 7 and 21 seconds respectively
    backoff_iterator = generate_jittered_backoff(retries=2, delay_base=7, delay_threshold=25)

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error=retry_never)
    def func(*args, **kwargs):
        return tuple(args), dict(kwargs)

    assert func(1, 2, 3, key='value') == ((1, 2, 3), dict(key='value'))



# Generated at 2022-06-22 21:10:30.676420
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert spec['api_username']
    assert spec['api_password']
    assert spec['api_url']
    assert spec['validate_certs']

    assert spec['api_username']['type'] == 'str'
    assert spec['api_password']['type'] == 'str'
    assert spec['api_url']['type'] == 'str'
    assert spec['validate_certs']['type'] == 'bool'

    assert spec['api_username'].get('no_log', None) is None
    assert spec['api_password']['no_log'] == True
    assert spec['api_url'].get('no_log', None) is None
    assert spec['validate_certs'].get('no_log', None) is None



# Generated at 2022-06-22 21:10:38.329534
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    count = [0]
    def do_something_that_fails(i):
        count[0] += 1
        if count[0] != i:
            raise Exception("Expected count to be {}.".format(i))
        print("Successfully ran function {} times!".format(count[0]))

    do_something_that_fails = retry_with_delays_and_condition(
        backoff_iterator = generate_jittered_backoff(delay_base=1),
        should_retry_error = retry_never
    )(do_something_that_fails)

    do_something_that_fails(5)

# Generated at 2022-06-22 21:10:46.482335
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import itertools

    delay_generator = itertools.chain(generate_jittered_backoff(), [0])
    # Make sure the generator keeps working
    for i in range(0, 100):
        next(delay_generator)

    method_call_counter = [0]

    @retry_with_delays_and_condition(delay_generator, should_retry_error=retry_never)
    def method_that_always_fails():
        method_call_counter[0] += 1
        raise Exception

    try:
        method_that_always_fails()
        raise Exception('The method should raise an exception after the retries')
    except:
        pass


# Generated at 2022-06-22 21:10:54.146947
# Unit test for function rate_limit
def test_rate_limit():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),))

    a = []
    @rate_limit(rate=1, rate_limit=1)
    def slow_function():
        a.append(time.time())

    slow_function()
    slow_function()
    slow_function()
    slow_function()
    slow_function()
    module.exit_json(msg=[a[0], a[1], a[2], a[3], a[4]], changed=False)


# Generated at 2022-06-22 21:11:01.301858
# Unit test for function retry_never
def test_retry_never():
    retry_never_function = retry_never
    assert retry_never_function('Test exception') == False
    assert retry_never_function(None) == False
    assert retry_never_function('') == False
    assert retry_never_function(0) == False
    assert retry_never_function(True) == False
    assert retry_never_function(False) == False
    assert retry_never_function(1) == False
    assert retry_never_function([]) == False
    assert retry_never_function({}) == False

# Generated at 2022-06-22 21:11:07.824201
# Unit test for function retry
def test_retry():
    """Retry function test"""
    @retry(retries=3, retry_pause=1)
    def foo():
        """retry test"""
        return random.choice([False, True])

    @retry(retries=None, retry_pause=0)
    def foo2():
        """retry test"""
        return random.choice([False, True])

    ret = foo()
    assert ret
    ret = foo2()
    assert ret

# Generated at 2022-06-22 21:11:09.666811
# Unit test for function retry_never
def test_retry_never():
    '''Test that retry_never function returns False (not retryable)'''
    assert retry_never('hello') is False


# Generated at 2022-06-22 21:11:19.100996
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class TestSuite(unittest.TestCase):
        def test_raises_exceptions_on_retries_and_succeeds_at_end(self):
            number_of_retries = 5
            delay_iterator = generate_jittered_backoff(retries=number_of_retries)

            class SideEffect:
                def __init__(self):
                    self.count = 0

                def foo(self):
                    self.count += 1
                    if self.count <= number_of_retries:
                        raise Exception('Fail!')

            sideEffect = SideEffect()

            class ExpectedException(Exception):
                pass


# Generated at 2022-06-22 21:11:30.103522
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    Unit test for the retry decorator
    Unit test needs to be seperate from doc test below because jython doesn't support yield
    """
    delay_backoff = [1, 2, 4]
    called_with = []

    @retry_with_delays_and_condition(delay_backoff, should_retry_error=lambda x: x.code != 404)
    def function_raising_404(arg):
        called_with.append(arg)
        raise HTTPError(url="http://example.com", code=404)

    # First try, only 404
    function_raising_404("first")
    assert called_with == ['first']
    called_with = []

    # Second try, 403 and 404

# Generated at 2022-06-22 21:11:40.604549
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def my_function():
        print("Hello")
    def my_function_raises_error():
        print("Raises error")
        raise Exception()


    # Run my_function three times with no delay in between
    no_delay_backoff_iterator = generate_jittered_backoff(retries=3, delay_base=0, delay_threshold=0)
    retry_with_no_delay = retry_with_delays_and_condition(no_delay_backoff_iterator, should_retry_error=retry_never)
    retry_with_no_delay(my_function)()

    # Run my_function three times with a delay of 0-1000ms between calls.
    # After the function has been called 3 times, raise the error and not retry
    backoff_iterator = generate_jittered

# Generated at 2022-06-22 21:11:43.218020
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert 'retries' in spec
    assert 'retry_pause' in spec



# Generated at 2022-06-22 21:11:46.597877
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('foo') == False
    assert retry_never(Exception()) == False
    assert retry_never(Exception('bar')) == False



# Generated at 2022-06-22 21:11:56.026567
# Unit test for function retry
def test_retry():
    state = []
    def func_to_retry():
        state.append(1)
        raise Exception('Error')

    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock
    current_time = 0
    def my_time():
        return current_time
    time.clock = my_time
    time.process_time = my_time

    func = retry(3, 1)(func_to_retry)

    func()
    assert state == [1, 1, 1]
    assert current_time == 3

    time.clock = time.process_time = real_time
    del time.clock
    del time.process_time



# Generated at 2022-06-22 21:12:03.116589
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=4, delay_base=1, delay_threshold=5))
    def retryable_function():
        retryable_function.call_count += 1
        if retryable_function.call_count == 2:
            return True
        raise ValueError()

    retryable_function.call_count = 0
    assert retryable_function() is True
    assert retryable_function.call_count == 2



# Generated at 2022-06-22 21:12:05.643421
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-22 21:12:15.227265
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module = AnsibleModule()
    module.params = dict(
        rate=10,
        rate_limit=10,
        rate_limit_timeout=1,
        rate_limit_target='system',
        rate_limit_type='requests',
        state='present'
    )

    result = rate_limit_argument_spec(dict(
        rate_limit_timeout=dict(type='int'),
        rate_limit_target=dict(type='str', choices=['system']),
        rate_limit_type=dict(type='str', choices=['requests', 'bytes']),
        state=dict(type='str', choices=['present', 'absent', 'query']),
    ))(module)
    assert result == 0



# Generated at 2022-06-22 21:12:21.075527
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    class dummy_self:
        def __init__(self):
            self.params = dict(rate=100, rate_limit=60)
            self.module = dict(rate=1, rate_limit=1)
        def fail_json(self, *args, **kwargs):
            pass

    obj = dummy_self()
    assert rate_limit_argument_spec() == rate_limit_argument_spec(spec={})


# Generated at 2022-06-22 21:12:25.425012
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    json_result = []
    for delay in generate_jittered_backoff():
        json_result.append(delay)
        if delay >= 60:
            break
    print(json_result)

# Generated at 2022-06-22 21:12:32.134704
# Unit test for function rate_limit
def test_rate_limit():
    """
    If a function is called more than rate times in rate_limit seconds,
    we should be throttled enough.
    """
    start = time.process_time()
    rate = 3
    rate_limit = 3
    minrate = float(rate_limit) / float(rate)

    @rate_limit(rate=rate, rate_limit=rate_limit)
    def deco_func(i):
        return i

    for i in range(rate):
        deco_func(i)

    elapsed = time.process_time() - start
    assert(elapsed > minrate)

# Generated at 2022-06-22 21:12:42.205299
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert list(generate_jittered_backoff(delay_threshold=None)) == [random.randint(0, 3), random.randint(0, 6), random.randint(0, 12)]
    assert list(generate_jittered_backoff(delay_threshold=1)) == [random.randint(0, 1), random.randint(0, 1), random.randint(0, 1)]
    assert list(generate_jittered_backoff(delay_threshold=10, retries=4)) == [random.randint(0, 3), random.randint(0, 6), random.randint(0, 10), random.randint(0, 10)]

# Generated at 2022-06-22 21:12:53.529550
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():  # pragma: no cover
    import unittest

    class RetryTestCase(unittest.TestCase):
        def test_retry_never_can_return_true(self):  # pragma: no cover
            self.assertTrue(retry_with_delays_and_condition(generate_jittered_backoff(),
                                                            should_retry_error=retry_never)(lambda: None))

        def test_retry_never_raises_exception(self):  # pragma: no cover
            self.assertRaises(ValueError,
                              retry_with_delays_and_condition(generate_jittered_backoff())(lambda: [].pop()))

        def test_retry_raises_exception_with_zero(self):  # pragma: no cover
            self

# Generated at 2022-06-22 21:13:04.650605
# Unit test for function retry
def test_retry():
    """Testing retry decorator"""
    # pylint: disable=unused-variable

    @retry(retries=3, retry_pause=0.1)
    def raise_exception():
        """raise exception to simulate error"""
        raise Exception('Fail by raising exception')

    @retry(retries=3, retry_pause=0.1)
    def return_true():
        """return true to simulate success"""
        return True

    @retry(retries=3, retry_pause=0.1)
    def return_false():
        """return false to simulate failure"""
        return False

    with pytest.raises(Exception):
        raise_exception()

    assert return_true()
    assert not return_false()



# Generated at 2022-06-22 21:13:08.284266
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec == (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))

# Generated at 2022-06-22 21:13:14.589068
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import random
    random.seed()
    # test a function that is not rate limited.
    @rate_limit()
    def f():
        return time.time()
    start = time.time()
    secs = [f() for _ in range(1, 10)]
    end = time.time()
    assert end - start < 1
    assert len(set(secs)) == 1

    # test a function that is rate limited.
    @rate_limit(rate=10, rate_limit=1)
    def f():
        return time.time()
    secs = []
    start = time.time()
    for i in range(1, 10):
        secs.append(f())
        time.sleep(.1)
    end = time.time()
    assert end - start > 1

# Generated at 2022-06-22 21:13:24.183987
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for retry in generate_jittered_backoff(retries=1):
        assert retry == 0
        break

    for retry in generate_jittered_backoff(retries=2):
        assert retry == 0
        break

    for retry in generate_jittered_backoff(retries=3, delay_threshold=1):
        if retry == 0:
            continue
        else:
            assert retry == 1
            break

    for retry in generate_jittered_backoff(retries=3, delay_threshold=1, delay_base=1):
        if retry == 0:
            continue
        else:
            assert retry == 1
            break


# Generated at 2022-06-22 21:13:33.847163
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """
    'generate_jittered_backoff' is a generator that returns a sequence of delays in seconds.
    Since the delays are jittered (and since they are not literally hard-coded), they aren't suitable for use in
    this unit test. Instead, we want to determine if the function returns the expected number of delays and if the
    maximum delay is also as expected.
    """
    def test_generator(generator, expected_count, expected_maximum_delay):
        count = 0
        maximum_delay = 0
        for delay in generator:
            count += 1
            maximum_delay = max(maximum_delay, delay)
        assert count == expected_count, "Expected %d delays, got %d" % (expected_count, count)

# Generated at 2022-06-22 21:13:38.309848
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.api import (
        rate_limit_argument_spec,
    )

    kwargs = {}
    module = AnsibleModule(argument_spec=rate_limit_argument_spec(),
                           supports_check_mode=True, **kwargs)

    module.exit_json(**module.params)


# Generated at 2022-06-22 21:13:49.285315
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.utils.listify import listify_lookup_plugin_terms
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    class BasicAuthArgumentSpecTestCase(unittest.TestCase):
        def setUp(self):
            self.spec = basic_auth_argument_spec()

        def test_basic_auth_argument_spec_type(self):
            self.assertTrue(isinstance(self.spec, dict))

        def test_basic_auth_argument_spec_contents(self):
            keys = ["api_username", "api_password", "api_url", "validate_certs"]
            self.assertListEqual(listify_lookup_plugin_terms(self.spec.keys()), keys)

# Generated at 2022-06-22 21:14:00.879423
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import yaml
    import datetime

    class Clock(object):
        def __init__(self):
            self.enemy_time = datetime.datetime(2020, 4, 1, 0, 0, 0, 0)

        def now(self):
            return self.enemy_time

        def tick(self, minutes=0, seconds=0):
            self.enemy_time += datetime.timedelta(seconds=seconds)
            self.enemy_time += datetime.timedelta(seconds=minutes * 60)

    def test_should_retry_once(exception_or_result):
        return True

    def test_should_retry_never(exception_or_result):
        return False


# Generated at 2022-06-22 21:14:06.097793
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import pandas as pd

    backoff_iterator = generate_jittered_backoff()
    delays = pd.DataFrame(list(backoff_iterator))
    assert delays[0].min() > 0 and delays[0].max() <= 3
    assert delays[0].max() < delays[3].min()
    assert delays[3].max() < delays[6].min()
    assert delays[6].max() < delays[9].min()

# Generated at 2022-06-22 21:14:11.460351
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'},
                                          'rate_limit': {'type': 'int'}}
    assert rate_limit_argument_spec({'param': {'type': 'str'}}) ==  {'rate': {'type': 'int'},
                                                                     'rate_limit': {'type': 'int'},
                                                                     'param': {'type': 'str'}}



# Generated at 2022-06-22 21:14:14.764693
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Generate 20 delays and ensure that the last delay is above or equal to the threshold
    for delay in generate_jittered_backoff(20, 3, 10):
        last_delay = delay
    assert last_delay >= 10

# Generated at 2022-06-22 21:14:19.050909
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arguments = retry_argument_spec()
    assert isinstance(arguments, dict)
    assert arguments['retries'] == dict(type='int')
    assert isinstance(arguments['retry_pause'], dict)
    assert arguments['retry_pause']['type'] == 'float'
    assert arguments['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:14:23.191102
# Unit test for function retry_never
def test_retry_never():
    @retry_with_delays_and_condition(should_retry_error=retry_never)
    def call_always_throws():
        raise Exception()

    try:
        call_always_throws()
        assert False, "Should not get here since function should always throw."
    except:
        assert True, "Expected to fall here since function should always throw."

# Unit test with retry never

# Generated at 2022-06-22 21:14:34.136015
# Unit test for function rate_limit
def test_rate_limit():
    # Create a function that takes time to run
    def time_consuming_function(delay=1):
        time.sleep(delay)
        return True

    # Decorate the function with the rate limit decorator
    # and wrap the decorated function in a method
    @rate_limit(rate=2, rate_limit=3)
    def wrapper(*args, **kwargs):
        return time_consuming_function(*args, **kwargs)

    # Check the output of the wrapper
    start = time.time()
    # The first call should happen immediately
    assert wrapper() is True
    # The second call should happen after 1 second
    assert wrapper() is True
    # The third call should be limited by the 2/3 rate limit
    assert wrapper() is True
    # The third call should take 2 seconds
    elapsed = time.time() - start

# Generated at 2022-06-22 21:14:41.735139
# Unit test for function retry
def test_retry():
    """Unit test"""
    class _TestException(Exception):
        pass

    @retry(retries=10)
    def _test_retry():
        raise _TestException("fake")

    for retry in range(0, 10):
        try:
            _test_retry()
        except Exception:
            pass
    try:
        _test_retry()
    except Exception as e:
        if isinstance(e, _TestException):
            return
    raise AssertionError("Retry failed to raise exception")



# Generated at 2022-06-22 21:14:43.452432
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(exception_or_result = None) == False


# Generated at 2022-06-22 21:14:51.133925
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    import time
    argspec = retry_argument_spec()
    module = AnsibleModule(argument_spec=argspec)

    @retry(module.params.get('retries'), module.params.get('retry_pause'))
    def test_exception(try_count, raise_exception, exception_value):
        if try_count == 1:
            if raise_exception:
                raise Exception(exception_value)
            else:
                return True

        return False

    assert module.params['retries'] == 2
    assert module.params['retry_pause'] == 1.0
    assert test_exception(0, False, 'Some exception')
    assert test_exception(1, True, 'Some exception')
    assert test_exception

# Generated at 2022-06-22 21:14:55.222832
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = (dict(
        foo=dict(type='int'),
        bar=dict(type='int'),
    ))
    _spec = rate_limit_argument_spec(spec)
    assert _spec['rate'] == dict(type='int')
    assert _spec['rate_limit'] == dict(type='int')
    assert _spec['foo'] == dict(type='int')
    assert _spec['bar'] == dict(type='int')



# Generated at 2022-06-22 21:14:59.247544
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_times = 12
    delay_base = 2
    delay_threshold = 8

    delays = generate_jittered_backoff(delay_times, delay_base, delay_threshold)

    assert delay_times == sum(1 for _ in delays)
    assert all(delay <= delay_threshold for delay in delays)



# Generated at 2022-06-22 21:15:02.695815
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False


# Generated at 2022-06-22 21:15:10.505899
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = (dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    ))
    assert retry_argument_spec(arg_spec) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}, 'retry_argument_spec has failed'
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}, 'retry_argument_spec has failed'

# Generated at 2022-06-22 21:15:16.353531
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for backoff_iterator in [
        generate_jittered_backoff(0),
        generate_jittered_backoff(10),
        generate_jittered_backoff(10, delay_threshold=20),
        generate_jittered_backoff(10, delay_threshold=0),
    ]:
        for delay in backoff_iterator:
            assert delay >= 0
            assert delay <= 60

# Generated at 2022-06-22 21:15:19.326800
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
  spec = rate_limit_argument_spec()
  assert spec['rate']['type'] == 'int'
  assert spec['rate_limit']['type'] == 'int'



# Generated at 2022-06-22 21:15:27.568599
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Verify that generate_jittered_backoff returns a list of integers and that the function works as expected."""
    backoff_results = [x for x in generate_jittered_backoff()]

    # Verify that all the results are integers
    assert all(isinstance(x, int) for x in backoff_results), "generate_jittered_backoff did not return an integer"

    # Verify that the results are in the correct range (between 0 and 3)
    assert all(x >= 0 and x <= 3 for x in backoff_results), "generate_jittered_backoff values are outside 0 to 3"

# Generated at 2022-06-22 21:15:29.147314
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False


# Generated at 2022-06-22 21:15:32.583013
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    try:
        assert retry_argument_spec()["retries"]["type"] == 'int'
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-22 21:15:34.033794
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert sorted(retry_argument_spec().keys()) == sorted(['retries', 'retry_pause'])

# Generated at 2022-06-22 21:15:38.268711
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(rate=1, rate_limit=2)
    def foo():
        print("foo called")

    start = time.time()
    foo()
    print(time.time() - start)


# Generated at 2022-06-22 21:15:48.593238
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import pytest
    from collections import Counter

    def test_with_retries_and_thresholds(retries, delay_base, delay_threshold):
        backoff_iter = generate_jittered_backoff(retries, delay_base, delay_threshold)
        delay_values = Counter(backoff_iter)
        assert len(delay_values) == retries
        assert all(delay < delay_threshold for delay in delay_values)

        # Test that the list is in sorted order
        sorted_backoff = sorted(delay_values.items())
        assert sorted_backoff == list(delay_values.items())

    test_with_retries_and_thresholds(retries=10, delay_base=3, delay_threshold=60)

# Generated at 2022-06-22 21:15:50.381855
# Unit test for function retry_never
def test_retry_never():
    """Test function retry_never"""
    try:
        retry_never(Exception())
    except Exception:
        pass

# Generated at 2022-06-22 21:15:51.291082
# Unit test for function retry_never
def test_retry_never():
    result = retry_never("")
    assert not result

# Generated at 2022-06-22 21:15:54.289281
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=1)
    def foo():
        print('foo')
        return False
    foo()


# Generated at 2022-06-22 21:15:57.899850
# Unit test for function retry
def test_retry():
    """Verify retry decorator works as expected"""
    retries = 3
    @retry(retries, 0)
    def run():
        return 0

    assert run() == 0


# Generated at 2022-06-22 21:16:04.536218
# Unit test for function retry
def test_retry():
    """Decorator tests: retry"""
    import mock

    @retry(retries=3, retry_pause=0.01)
    def fail_once():
        fail_once.attempts += 1
        if fail_once.attempts == 1:
            raise Exception("Fail on the first attempt")
        return "ok"

    fail_once.attempts = 0
    assert fail_once() == "ok"
    assert fail_once.attempts == 2



# Generated at 2022-06-22 21:16:06.548103
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert not retry_never(None)

# Generated at 2022-06-22 21:16:10.723739
# Unit test for function retry
def test_retry():
    num_retries = 0

    @retry(retries=3, retry_pause=1)
    def test_func():
        nonlocal num_retries
        num_retries += 1
        return False
    test_func()
    assert(num_retries == 3)



# Generated at 2022-06-22 21:16:19.030411
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Function which performs a simple retry based on the exception which was raised.
    Return True if the exception is of type Exception.
    Return False if the exception is of type TypeError
    """

    def retry_expected_error(e):
        return isinstance(e, Exception)

    # Test function which will throw a TypeError exception
    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(retries=10),
        should_retry_error=retry_expected_error)
    def test_function_exception():
        raise TypeError('This exception should be caught and not retried')

    # The function should only be called once and an exception thrown

# Generated at 2022-06-22 21:16:23.176047
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'required': False, 'type': 'int'}, 'rate_limit': {'required': False, 'type': 'int'}}


# Generated at 2022-06-22 21:16:28.972804
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }
    assert retry_argument_spec({'something': {'type': 'str'}}) == {
        'something': {'type': 'str'},
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }



# Generated at 2022-06-22 21:16:30.207600
# Unit test for function retry_never
def test_retry_never():
    """Retry never should return False"""
    assert retry_never(Exception()) is False



# Generated at 2022-06-22 21:16:31.209196
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_argument_spec()

# Generated at 2022-06-22 21:16:41.865823
# Unit test for function retry
def test_retry():
    @retry()
    def test_retry_without_retries():
        return None

    with pytest.raises(Exception):
        test_retry_without_retries()

    @retry(retries=2)
    def test_retry_with_retries():
        return None

    with pytest.raises(Exception):
        test_retry_with_retries()

    @retry(retries=2, retry_pause=0)
    def test_retry_with_retries_and_zero_delay():
        raise Exception('test')

    with pytest.raises(Exception):
        test_retry_with_retries_and_zero_delay()


# Generated at 2022-06-22 21:16:47.259256
# Unit test for function retry
def test_retry():
    retry_limit = 3
    retry_pause = 1
    retries = 0

    @retry(retry_limit, retry_pause)
    def test_function():
        global retries
        retries += 1
        raise Exception("Retry")

    try:
        test_function()
    except Exception:
        pass

    assert retries == retry_limit



# Generated at 2022-06-22 21:16:50.446785
# Unit test for function rate_limit
def test_rate_limit():
    global i
    i = 0

    @rate_limit(rate=1, rate_limit=1)
    def limited():
        global i
        i = i + 1

    for x in range(0, 5):
        limited()

    assert i == 2

# Generated at 2022-06-22 21:16:53.978085
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    dict = rate_limit_argument_spec({'rate' : dict(type = 'int')})
    assert dict['rate'] == dict(type = 'int'), 'rate_limit_argument_spec is setting the wrong data.'


# Generated at 2022-06-22 21:17:06.041231
# Unit test for function retry
def test_retry():
    """Simple sanity test for retry"""
    retries = 10

    @retry(retries - 1)
    def raises_1():
        raise Exception("Retry attempt %d" % raises_1.count)

    raises_1.count = 1

    raises_1()
    try:
        raises_1()
    except:
        pass
    try:
        raises_1()
    except Exception as e:
        assert retries - 2 == raises_1.count - 1
        assert str(e).startswith("Retry limit")

    # reload to clear counter
    reload(sys.modules[__name__])

    @retry(retries)
    def raises_1():
        if raises_1.count < retries:
            raises_1.count += 1

# Generated at 2022-06-22 21:17:14.462663
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec
    assert arg_spec['api_username']['type'] == 'str'
    assert arg_spec['api_password']['type'] == 'str'
    assert arg_spec['api_url']['type'] == 'str'
    assert arg_spec['validate_certs']['type'] == 'bool'

if __name__ == '__main__':
    test_basic_auth_argument_spec()

# Generated at 2022-06-22 21:17:16.985467
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never('not_exception') is False)



# Generated at 2022-06-22 21:17:18.968588
# Unit test for function retry_never
def test_retry_never():
    try:
        retry_never('hello')
    except Exception:
        assert False
    return True


# Generated at 2022-06-22 21:17:27.489159
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    incorrect_credentials_exception = Exception("Incorrect credentials")
    i = 0

    # @retry_with_delays_and_condition(backoff_iterator=...)
    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(),
        should_retry_error=lambda e: e is incorrect_credentials_exception
    )
    def retryable_function(credentials):
        """Assume a function which returns boolean values to indicate success or failure."""
        # Simulate a function which only works the first time called with correct credentials
        nonlocal i
        if credentials == "correct" and i == 0:
            i += 1
            return True
        elif credentials == "correct":
            raise incorrect_credentials_exception

# Generated at 2022-06-22 21:17:38.524239
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class MyError(Exception):
        pass

    class MyRetryError(Exception):
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=7, delay_base=0.05, delay_threshold=0.5), should_retry_error=lambda e: isinstance(e, MyRetryError))
    def call_api_with_retries():
        raise MyRetryError()

    call_api_with_retries()


# Generated at 2022-06-22 21:17:39.766331
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False


# Generated at 2022-06-22 21:17:44.342857
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    spec = retry_argument_spec(spec)
    assert 'retries' in spec and 'retry_pause' in spec

# Generated at 2022-06-22 21:17:50.158895
# Unit test for function retry
def test_retry():
    """Unit test for function retry"""
    @retry(retries=3, retry_pause=0.01)
    def myfunc():
        return False

    with pytest.raises(Exception):
        myfunc()

    @retry(retries=3, retry_pause=0.01)
    def myfunc():
        return 1

    assert myfunc() == 1



# Generated at 2022-06-22 21:17:51.094270
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("anything") is False

# Generated at 2022-06-22 21:17:53.798897
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    jittered_backoff = generate_jittered_backoff()
    for i in range(0, 10):
        assert next(jittered_backoff) < 60

# Generated at 2022-06-22 21:17:58.336082
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    iterations = 100

    for attempt in range(iterations):
        backoff_iterator = generate_jittered_backoff(
            retries=attempt, delay_base=1000, delay_threshold=2000)
        for delay in backoff_iterator:
            assert delay <= 2000

# Generated at 2022-06-22 21:18:09.318888
# Unit test for function rate_limit
def test_rate_limit():
    def myfunc():
        pass

    for rate in range(1,10):
        for rate_limit in range(1,10):
            t = time.time()
            for i in range(0, rate * 2):
                wrapped = rate_limit(rate=rate, rate_limit=rate_limit)(myfunc)
                wrapped()
            t = time.time() - t
            assert t >= rate_limit, "rate_limit failed: %d calls at rate=%d rate_limit=%d" % (rate*2, rate, rate_limit)
            assert t < rate_limit * 1.5, "rate_limit failed: %d calls at rate=%d rate_limit=%d" % (rate*2, rate, rate_limit)


# Generated at 2022-06-22 21:18:16.266400
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert(arg_spec['api_username']['type'] == 'str')
    assert(arg_spec['api_password']['type'] == 'str')
    assert(arg_spec['api_password']['no_log'] is True)
    assert(arg_spec['api_url']['type'] == 'str')
    assert(arg_spec['validate_certs']['type'] == 'bool')

# Generated at 2022-06-22 21:18:23.981612
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(backoff_iterator=[0, 1, 2])
    def foo(value):
        if value:
            return value
        raise ValueError('foo')

    assert foo(None) == 'foo'
    assert foo(0) == 'foo'
    assert foo('foo') == 'foo'
    assert foo(0) == 'foo'
    assert foo(1) == 'foo'
    try:
        foo(None)
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-22 21:18:25.991301
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('not a real exception') == False


# Generated at 2022-06-22 21:18:29.078511
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    try:
        retry_argument_spec()
        assert False, "No exception raised when spec is not passed"
    except TypeError:
        assert True

# Generated at 2022-06-22 21:18:31.821149
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for i in generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60):
        assert i <= 60
        assert i >= 0

# Generated at 2022-06-22 21:18:39.305005
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=1)
    def test_func(a, b):
        return a + b

    # Testing that the first 2 calls happen in less than 0.5s (1 second / rate)
    start = time.time()
    assert test_func(1, 2) == 3
    end = time.time()
    assert end - start < 0.5

    start = time.time()
    assert test_func(2, 3) == 5
    end = time.time()
    assert end - start < 0.5

    # Testing that the third call happens after at least 1 second
    start = time.time()
    assert test_func(1, 1) == 2
    end = time.time()
    assert end - start > 1
    assert end - start < 1.2

    # Testing

# Generated at 2022-06-22 21:18:40.853384
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never(None) == False)


# Generated at 2022-06-22 21:18:44.654427
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert type(basic_auth_argument_spec()) is dict
    assert type(basic_auth_argument_spec(None)) is dict
    assert type(basic_auth_argument_spec({'api_username': {'type':'str'}})) is dict


# Generated at 2022-06-22 21:18:51.572396
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for the rate_limit decorator"""
    import unittest
    import time
    from ansible.module_utils._text import to_native

    class TestRateLimit(unittest.TestCase):
        def test_rate_limit(self):
            start = time.time()
            try:
                class Mock(object):
                    pass
                @rate_limit(rate=5, rate_limit=5)
                def limit(self):
                    time.sleep(0.25)
                    self.value = time.time() - start
                m = Mock()
                for i in range(0,10):
                    limit(m)
            except Exception as e:
                self.fail(to_native(e))
            for i in range(1,10):
                self.assertTrue(m.value > i)
                self

# Generated at 2022-06-22 21:18:54.906262
# Unit test for function retry
def test_retry():
    def test(x):
        if x <= 0:
            raise Exception('test')

    r = retry(retries=1, retry_pause=0.5)
    t = r(test)

    t(0)

# Generated at 2022-06-22 21:19:03.188397
# Unit test for function rate_limit
def test_rate_limit():

    # Utility function for rate_limit test
    def fib(n):
        return n if n <= 1 else fib(n-1) + fib(n-2)

    # This function executes fib(30) every 0.34 seconds
    # in average (rate = 1/0.34 = 2.94)
    @rate_limit(rate=3, rate_limit=1)
    def fib_limited():
        return fib(30)

    start_time = time.time()

    print("Intended to call fib(30) every 0.34 sec (rate = 1/0.34 = 2.94)")
    for i in range(10):
        fib_limited()

    end_time = time.time()
    duration = end_time - start_time

    # If we have executed 10 fib(30) calls, the execution time must be greater

# Generated at 2022-06-22 21:19:06.258227
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert(basic_auth_argument_spec() == dict(api_username=dict(type='str'), api_password=dict(type='str', no_log=True), api_url=dict(type='str'), validate_certs=dict(type='bool', default=True)))


# Generated at 2022-06-22 21:19:12.899948
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    The function retry_with_delays_and_condition is used as follows:

    >>> @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    >>> def foo():
    >>>     # This is the function to retry.
    >>>     return True

    This testcase considers only the case where the function fails and is retried.
    """
    SECOND = 1
    def should_retry_error(e):
        return True

    def fail_at_first(args):
        if fail_at_first.attempt == 1:
            fail_at_first.attempt += 1
            raise ValueError("boo")
        return True
    fail_at_first.attempt = 1

    # If backoff_iterator is empty, we should still run the function a single

# Generated at 2022-06-22 21:19:20.329608
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    class RateLimitTest(unittest.TestCase):

        def test_rate_limit_zero_rate(self):
            @rate_limit(rate=0, rate_limit=1)
            def f():
                pass

            start = time.time()
            for _ in range(0, 100):
                f()
            duration = time.time() - start
            self.assertGreaterEqual(duration, 1.0)

        def test_rate_limit_zero_rate_limit(self):
            @rate_limit(rate=1, rate_limit=0)
            def f():
                pass

            start = time.time()
            for _ in range(0, 100):
                f()
            duration = time.time() - start
            self.assertLessEqual(duration, 0.001)



# Generated at 2022-06-22 21:19:30.855052
# Unit test for function retry_argument_spec

# Generated at 2022-06-22 21:19:32.177130
# Unit test for function retry_never
def test_retry_never():
    result = retry_never(Exception)
    assert result == False



# Generated at 2022-06-22 21:19:37.928690
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    test_spec = {'test_arg1': dict(type='bool', default=True)}
    result = basic_auth_argument_spec(spec=test_spec)
    assert result == {
        'test_arg1': dict(type='bool', default=True),
        'api_username': dict(type='str'),
        'api_password': dict(type='str', no_log=True),
        'api_url': dict(type='str'),
        'validate_certs': dict(type='bool', default=True),
    }