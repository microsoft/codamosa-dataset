

# Generated at 2022-06-22 21:09:40.715297
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    def test_func(api_username, api_password, api_url, validate_certs):
        pass
    test_func(**{'api_username': 'admin', 'api_password': 'password', 'api_url': 'http', 'validate_certs': False})

# Generated at 2022-06-22 21:09:50.500534
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    input_iter = [0.1, 0.2, 0.3, 0.4]
    retry_once = 1

    @retry_with_delays_and_condition(input_iter)
    def retry_function_1(foo):
        if foo > 0:
            foo -= 1
            raise Exception
        else:
            return True

    assert retry_function_1(retry_once) == True
    assert retry_function_1(retry_once + 1) == True

    @retry_with_delays_and_condition(input_iter, should_retry_error=lambda e: e.args[0] > 0)
    def retry_function_2(foo):
        if foo > 0:
            print("In retry_function_2", foo)
            raise Exception(foo)

# Generated at 2022-06-22 21:09:55.648006
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    module = mock.MagicMock()
    module.params = {'retries': 2}
    arg_spec = retry_argument_spec()
    Retry = retry(retries=module.params['retries'],
                  retry_pause=module.params['retry_pause'])
    assert isinstance(Retry, function)



# Generated at 2022-06-22 21:09:57.784733
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert 'rate' in spec
    assert 'rate_limit' in spec


# Generated at 2022-06-22 21:10:06.234351
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global call_number
    call_number = 0
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=2, delay_threshold=30)
    should_retry_error = functools.partial(should_retry_error_exceptions, RetryError=Exception)
    test_function = retry_with_delays_and_condition(backoff_iterator, should_retry_error)(retryable_function)
    result = test_function()
    assert result == 'ResultAfterRetries'
    assert call_number == 10


# Generated at 2022-06-22 21:10:11.512774
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Very basic unit test
    calls = 0

    def func():
        nonlocal calls
        calls += 1
        if calls < 3:
            raise Exception("Failed!")

    retry_decorated = retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff())
    retry_decorated(func)
    assert calls == 3

# Generated at 2022-06-22 21:10:18.928929
# Unit test for function retry
def test_retry():
    """This tests the retry decorator.

    There are 2 delays of 1 second and then a third one which results in an error
    """
    delays = [1, 1]

    @retry(retries=3, retry_pause=1)
    def times_three(x):
        """Thrice the value. Delays are added to test the retry mechanism.
        """
        try:
            delay = delays.pop(0)
        except IndexError:
            delay = None
        if delay:
            time.sleep(delay)
        else:
            raise ValueError('Not thrice-able')

        return x * 3

    assert times_three(5) == 15



# Generated at 2022-06-22 21:10:23.979424
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-22 21:10:28.128718
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

    assert rate_limit_argument_spec() == spec

    spec['my_arg'] = dict(type='str')

    assert rate_limit_argument_spec(spec) == spec


# Generated at 2022-06-22 21:10:30.861935
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=5, rate_limit=5)
    def func():
        pass
    for i in range(0, 10):
        func()

# Generated at 2022-06-22 21:10:34.042679
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = retry_argument_spec()
    # Function retry_argument_spec has 2 arguments and should return a dictionary with 2 keys
    assert len(argument_spec) == 2

# Generated at 2022-06-22 21:10:44.222560
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    def raise_an_exception_then_succeed(input):
        if raise_an_exception_then_succeed.times_called == 0:
            raise_an_exception_then_succeed.times_called += 1
            raise Exception("Exception")
        raise_an_exception_then_succeed.times_called += 1
        return input

    def raise_an_exception_then_fail(input):
        raise Exception("Exception")

    backoff_iterator = generate_jittered_backoff()
    retryable_function_with_exception = retry_with_delays_and_condition(backoff_iterator)

    raise_an_exception_then_succeed.times_called = 0
    raised_exception_then_succeed_function = retryable_function_

# Generated at 2022-06-22 21:10:45.720364
# Unit test for function retry_never

# Generated at 2022-06-22 21:10:51.202621
# Unit test for function retry
def test_retry():
    def test_function(a):
        return a

    assert retry(retries=1, retry_pause=3)(test_function)(2) == 2
    assert retry(retries=1, retry_pause=3)(test_function)(0) == 0
    assert retry(retries=2, retry_pause=3)(test_function)(0) == 0

# Generated at 2022-06-22 21:11:01.597767
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import pytest
    # No argument
    arg_spec = basic_auth_argument_spec()
    assert len(arg_spec) == 4
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec

    # With argument
    arg_spec = basic_auth_argument_spec(spec=dict(
        an_argument=dict(type='bool', default=False)
    ))
    assert len(arg_spec) == 5
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec
    assert 'an_argument' in arg_spec

# Generated at 2022-06-22 21:11:09.206487
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.api import basic_auth_argument_spec, retry_argument_spec
    argument_spec = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1)
    )
    assert argument_spec == retry_argument_spec(basic_auth_argument_spec())

# Generated at 2022-06-22 21:11:14.485752
# Unit test for function retry
def test_retry():
    global retries
    retries = 0

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    def raise_exception(exception):
        global retries
        retries += 1
        raise exception
    with pytest.raises(TypeError):
        raise_exception(TypeError)
    assert retries == 1

# Generated at 2022-06-22 21:11:17.828871
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=5)
    def foo():
        return False

    try:
        foo()
    except Exception:
        pass

# Generated at 2022-06-22 21:11:22.016188
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    module = MagicMock()
    module.params = dict()
    module.params.update(dict(retries=10, retry_pause=1))
    assert retry_argument_spec() == dict(dict(retries=dict(type='int'),
                                              retry_pause=dict(type='float', default=1)))


# Generated at 2022-06-22 21:11:27.123889
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():

    arg_spec = basic_auth_argument_spec()

    assert arg_spec['api_username']['type'] == 'str'
    assert arg_spec['api_username']['required'] == True

    assert arg_spec['api_password']['type'] == 'str'
    assert arg_spec['api_password']['required'] == True
    assert arg_spec['api_password']['no_log'] == True

    assert arg_spec['api_url']['type'] == 'str'
    assert arg_spec['api_url']['required'] == True

    assert arg_spec['validate_certs']['type'] == 'bool'
    assert arg_spec['validate_certs']['required'] == False
    assert arg_spec['validate_certs']['default'] == True

# Generated at 2022-06-22 21:11:31.525896
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(arg1=dict(type='str'))
    new_spec = retry_argument_spec(spec)
    assert 'retries' in new_spec
    assert 'retry_pause' in new_spec
    assert 'arg1' in new_spec

# Generated at 2022-06-22 21:11:41.284854
# Unit test for function rate_limit
def test_rate_limit():

    rate_limit_tries = 10
    rate_limit_rate = 1
    rate_limit_rate_limit = 10

    # rate_limit_rate * rate_limit_rate_limit should be 10 seconds
    # add buffer for system delays
    min_rate = 13
    max_rate = 15

    rate_limit = rate_limit_rate * rate_limit_rate_limit

    @rate_limit(rate_limit_rate, rate_limit_rate_limit)
    def rate_limited_func():
        return time.time()

    start = time.time()
    for _ in range(rate_limit_tries):
        rate_limited_func()
    end = time.time()
    duration = end - start

    assert min_rate <= duration <= max_rate


# Generated at 2022-06-22 21:11:52.911323
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    assert module.params['api_username'] is None
    assert module.params['api_password'] is None
    assert module.params['api_url'] is None
    assert module.params['validate_certs'] is True

    module = AnsibleModule(argument_spec=basic_auth_argument_spec(spec=dict(api_url=dict(required=True))))
    assert module.params['api_url'] is None

    module.params['validate_certs'] = False
    module.params['api_url'] = 'https://example.com/api'
    module.params['api_username'] = 'user1'
    module.params['api_password'] = 'pass1'

# Generated at 2022-06-22 21:11:56.625893
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_arguments = retry_argument_spec()
    assert(retry_arguments == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}})

# Generated at 2022-06-22 21:12:01.330098
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec["api_username"]["type"] == 'str'
    assert arg_spec["api_password"]["no_log"] == True
    assert arg_spec["api_url"]["type"] == 'str'


# Generated at 2022-06-22 21:12:04.431399
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert sum(generate_jittered_backoff(retries=2, delay_base=5, delay_threshold=15)) <= 18
    assert sum(generate_jittered_backoff(retries=3, delay_base=5, delay_threshold=15)) <= 45

# Generated at 2022-06-22 21:12:08.537639
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {'type': 'int'},
        'retry_pause': {'default': 1, 'type': 'float'},
    }



# Generated at 2022-06-22 21:12:18.230567
# Unit test for function retry
def test_retry():
    """
    >>> @retry(retries=1, retry_pause=1)
    ... def test():
    ...     return True
    >>> test()
    True
    >>> @retry(retries=1, retry_pause=1)
    ... def test():
    ...     return False
    >>> test()
    Traceback (most recent call last):
    ...
    Exception: Retry limit exceeded: 1
    >>> @retry(retries=2, retry_pause=1)
    ... def test():
    ...     return False
    >>> test()
    False
    """
    pass


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 21:12:25.687611
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    should_retry_error = functools.partial(retry_never)
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def callable_function():
        return "Test String"

    assert callable_function() == "Test String"  # Check that the string is returned if the function does not fail

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def callable_function_with_error():
        raise RuntimeError("Test Error")

    try:
        assert callable_function_with_error() == "Test String"
    except RuntimeError:
        pass

# Generated at 2022-06-22 21:12:31.790576
# Unit test for function retry
def test_retry():
    calls = [0]
    def run_me():
        calls[0] += 1
        if calls[0] == 3:
            return True
        if calls[0] > 3:
            raise Exception

    func = retry(retries=10, retry_pause=1)(run_me)
    result = func()
    assert result
    assert calls[0] == 3
    try:
        func()
        assert False
    except Exception:
        pass
    assert calls[0] == 4



# Generated at 2022-06-22 21:12:41.835182
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    vault_password_file = os.path.join(os.path.dirname(__file__), 'password')

    loader = DataLoader()
    variable_manager = VariableManager()
    vault_secrets = VaultLib(password_file=vault_password_file)
    variable_manager.extra_vars = {'ansible_password': vault_secrets.decrypt('password')}


# Generated at 2022-06-22 21:12:53.260022
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Unit test for the generic retry decorator"""

    # Call the function and skip over all retries
    @retry_with_delays_and_condition(iter([]))
    def always_returns_42():
        return 42

    assert always_returns_42() == 42

    # Retry the function
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def always_fails():
        raise Exception()

    with pytest.raises(Exception):
        always_fails()

    # Test a condition that decides to retry based on the exception
    class TestException(Exception):
        pass


# Generated at 2022-06-22 21:13:01.236363
# Unit test for function retry
def test_retry():
    class R(object):
        called = 0
        success = False
        def retried(*args, **kwargs):
            R.called += 1
            if R.success:
                return True
            return False

        retried = retry(retries=6, retry_pause=1)(retried)

    R.retried()
    assert R.called == 6
    assert R.success == False

    R.success = True
    assert R.retried() == True
    assert R.called == 7

# Generated at 2022-06-22 21:13:10.499174
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Test a regular call to the function.
    call_count = [0]
    def test_function():
        call_count[0] = call_count[0] + 1
        return True

    function_with_retry = retry_with_delays_and_condition(iter(()), retry_never)(test_function)
    function_with_retry()
    assert call_count[0] == 1

    # Test a call to the function that fails, and should be retried.
    call_count[0] = 0
    def test_function_that_fails():
        call_count[0] = call_count[0] + 1
        if call_count[0] == 1:
            raise Exception
        return True


# Generated at 2022-06-22 21:13:16.424124
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def retryable_function():
        return False

    try:
        retryable_function()
    except Exception:
        return True

    # Should never get here
    return False

# Generated at 2022-06-22 21:13:25.421703
# Unit test for function rate_limit
def test_rate_limit():
    """Test decorator rate_limit"""
    WAIT_TIME = 0.005
    last_call_time = [time.time()]
    count = [0]

    @rate_limit(rate=100, rate_limit=1)
    def rl_func(last_call_time, count):
        cur_time = time.time()
        diff_time = cur_time - last_call_time[0]
        last_call_time[0] = cur_time
        if abs(diff_time - WAIT_TIME) > .01:
            raise Exception("Unexpected time diff %f for count %d" % (diff_time, count[0]))
        count[0] += 1

    for i in range(0, 50):
        rl_func(last_call_time, count)
    time.sleep

# Generated at 2022-06-22 21:13:31.616618
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Unit test for basic_auth_argument_spec: it is tested that the correct ansible.module_utils.basic.py is being used, and that it is returning the correct type.
    # If the correct module_utils.basic.py is being used, the type(module_utils.basic.json) will be dict.
    assert type(basic_auth_argument_spec()) == dict



# Generated at 2022-06-22 21:13:34.821467
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )


# Unit tests for function rate_limit_argument_spec

# Generated at 2022-06-22 21:13:42.102529
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def return_none(number):
        if number < 3:
            return None
        return number

    def return_true(number):
        if number < 3:
            return None
        return True

    @retry_with_delays_and_condition([1, 2, 3])
    def test_function_one(number):
        return return_none(number)

    @retry_with_delays_and_condition([1, 2, 3], should_retry_error=lambda _: True)
    def test_function_two(number):
        return return_none(number)

    @retry_with_delays_and_condition(generate_jittered_backoff(3))
    def test_function_three(number):
        return return_none(number)


# Generated at 2022-06-22 21:13:48.109990
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    import datetime

    class TestRetry(unittest.TestCase):

        def test_retry(self):
            base_time = datetime.datetime.now()
            backoff_iterator = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]

            @retry_with_delays_and_condition(backoff_iterator)
            def function_with_exception_that_should_be_retried():
                raise Exception("This would be a retry from a network or other error")

            try:
                function_with_exception_that_should_be_retried()
            except:
                # We should get here
                pass

            delta = datetime.datetime.now() - base_time

# Generated at 2022-06-22 21:13:52.334020
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def mock_function():
        return True

    def test_should_retry_error(exception):
        return True

    mock_function = retry_with_delays_and_condition(generate_jittered_backoff(), test_should_retry_error)(mock_function)
    mock_function()

# Generated at 2022-06-22 21:14:03.887522
# Unit test for function retry
def test_retry():
    retry_count = [0]
    call_count = [0]
    delay_count = [0]

    @retry(retries=None, retry_pause=3)
    def retry1():
        """raise once"""
        retry_count[0] += 1
        raise Exception("failed")

    @retry(retries=1, retry_pause=3)
    def retry2():
        """raise once"""
        retry_count[0] += 1
        raise Exception("failed")

    @retry(retries=10, retry_pause=3)
    def retry3():
        """retry needed"""
        call_count[0] += 1
        if call_count[0] < 2:
            raise Exception("failed")
        return call_count[0]


# Generated at 2022-06-22 21:14:07.298276
# Unit test for function rate_limit
def test_rate_limit():
    test = rate_limit(1, 2)
    if not callable(test):
        raise AssertionError("rate_limit is not a function")


# Generated at 2022-06-22 21:14:11.874020
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import argparse
    args = argparse.Namespace(
        retries=10,
        retry_pause=1.1,
    )

    @retry(args.retries, args.retry_pause)
    def test():
        return True

    for _ in range(0, args.retries):
        assert test() is True
        time.sleep(args.retry_pause)


# Generated at 2022-06-22 21:14:18.207831
# Unit test for function retry
def test_retry():
    def testexec():
        count[0] += 1
        if count[0] <= 3:
            raise Exception()
    count = [0]
    retry = retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    f = retry(testexec)
    f()
    if count[0] != 4:
        raise Exception('retry_with_delays_and_condition failed')

if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-22 21:14:23.851253
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec(dict(
        api_username=dict(type='str', default='myname'),
        delete=dict(type='str', default='no')
    ))
    assert arg_spec.get('api_username').get('default') == 'myname'
    assert arg_spec.get('delete').get('default') == 'no'
    assert arg_spec.get('rate').get('type') == 'int'
    assert arg_spec.get('rate_limit').get('type') == 'int'


# Generated at 2022-06-22 21:14:33.874567
# Unit test for function rate_limit
def test_rate_limit():
    # pylint: disable=unused-argument
    @rate_limit(rate=2, rate_limit=20)
    def print_numbers(number=None):
        """Print the numbers"""
        for i in range(number):
            print(i)

    # pylint: disable=too-many-function-args
    print_numbers(3)

    # pylint: disable=unused-argument
    @rate_limit(rate=10, rate_limit=100)
    def print_more_numbers(number=None):
        """Print the numbers"""
        for i in range(number):
            print(i)

    print_more_numbers(3)


# Generated at 2022-06-22 21:14:44.817091
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest
    import call_count

    def never_throw():
        return 100

    def throw_exception():
        raise RuntimeError("boom")

    def always_throw():
        raise RuntimeError("boom")

    def throw_and_succeed():
        throw_and_succeed.call_count = throw_and_succeed.call_count + 1
        if throw_and_succeed.call_count < 2:
            raise RuntimeError("boom")
        return 200

    def failure_condition(exc):
        return isinstance(exc, RuntimeError)

    def success_condition(exc):
        return False


# Generated at 2022-06-22 21:14:51.342057
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert spec == {
        'api_username': {'type': 'str'},
        'api_password': {'no_log': True, 'type': 'str'},
        'api_url': {'type': 'str'},
        'validate_certs': {'default': True, 'type': 'bool'}}



# Generated at 2022-06-22 21:14:52.204119
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception)



# Generated at 2022-06-22 21:15:01.378270
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Verify that the function generates delays within the range of each delay step."""
    import math
    from fractions import Fraction
    from collections import defaultdict

    # TODO: Add unittest for function generate_jittered_backoff
    # Check that each delay is at least the previous delay
    # Check that the delay falls within the range of the exponential backoff
    # Check that the maximum delay is always less than the threshold

    num_trials = 1000

    # Generate the backoffs with specified parameters
    backoffs = list(generate_jittered_backoff(retries=5, delay_base=5, delay_threshold=30))

    # Generate a repeated set of delays (to make sure we generate enough)
    repeated_backoffs = backoffs * num_trials

    # Number of trials in each bin

# Generated at 2022-06-22 21:15:03.474244
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never('foo')
    assert not retry_never(Exception)

# Generated at 2022-06-22 21:15:11.338129
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # Load the module source file as a template so that it can be manipulated for testing.
    test_module = AnsibleTemplate(source_file='lib/ansible/module_utils/api.py',
                                  template_excludes=[],
                                  template_vars={},
                                  encoding='utf-8',
                                  escape_backslashes=True,
                                  convert_data=True,
                                  )
    # The argument specs are empty so they can be overwritten with the test data.
    test_module_args = {}

    # Syntax check the module without the required arguments
    with pytest.raises(AnsibleError):
        result = test_module.syntax(test_module_args)

    # Test with default value
    test_module_args = dict(retries=2)
    result = test_module.sy

# Generated at 2022-06-22 21:15:22.709463
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit"""
    import mock
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules.api_utils import rate_limit

    import_mock = mock.patch('ansible_collections.notmintest.not_a_real_collection.plugins.modules.api_utils.time.process_time')
    module_mock = mock.MagicMock()
    module_mock.check_mode = False
    import_mock.start()

    # Test rate_limit function
    rate_limit_decorator = rate_limit(rate=2, rate_limit=1)
    wrapped_function = rate_limit_decorator(module_mock)
    wrapped_function()
    # rate limit should have been checked, as time.process_time() is mocked

# Generated at 2022-06-22 21:15:27.764499
# Unit test for function retry
def test_retry():
    import time
    import pytest
    @retry(retries=4, retry_pause=1)
    def testfunc(args):
        if args == "error":
            return None
        else:
            return args

    assert testfunc(args="error") is None
    assert testfunc(args="success") == "success"
    with pytest.raises(Exception):
        testfunc(args="error")

# Generated at 2022-06-22 21:15:37.242226
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=3, rate_limit=60)
    def fn(hello, world):
        return hello, world

    # These are just examples, no accurate timing will be tested.
    start = time.time()
    fn('foo', 'bar')
    fn('foo', 'bar')
    fn('foo', 'bar')
    end = time.time()
    assert end - start < 1
    start = time.time()
    fn('foo', 'bar')
    fn('foo', 'bar')
    fn('foo', 'bar')
    end = time.time()
    assert end - start < 1
    start = time.time()
    fn('foo', 'bar')
    fn('foo', 'bar')
    fn('foo', 'bar')
    end = time.time()
    assert end - start < 1

# Generated at 2022-06-22 21:15:40.792908
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=0)
    def test_function(exception=False):
        if exception:
            raise Exception
        return "SUCCESS"

    assert test_function(exception=True) == "SUCCESS"

# Generated at 2022-06-22 21:15:42.274569
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception("foo"))
    assert not retry_never("bar")

# Generated at 2022-06-22 21:15:50.796852
# Unit test for function rate_limit
def test_rate_limit():
    # A test function that will wait the specified amount of time and then return the time waited
    def sample_func(time_to_wait):
        time.sleep(time_to_wait)
        return time_to_wait

    # Get the time before calling the function
    start_time = time.time()

    rate_limit_func = rate_limit(rate=5, rate_limit=5)
    rate_limited_func = rate_limit_func(sample_func)
    rate_limited_func(1)

    # Calculate the duration and make sure it is within the 1% error margin
    duration = time.time() - start_time
    assert abs(1 - duration) / 1.0 < .01


# Generated at 2022-06-22 21:15:59.202712
# Unit test for function retry
def test_retry():
    # we need to set a default for this function
    def retry_param_none(a, b=0):
        return True

    retry_param_none_with_retry = retry(retries=10)(retry_param_none)

    # if the first try works, we stop
    assert retry_param_none_with_retry(1, 1) is True

    # if we retry and succeed we stop
    counter = [0]

    def retry_param(*args, **kwargs):
        if counter[0] >= 1:
            return True
        else:
            counter[0] += 1
            return False

    retry_param_with_retry = retry(retries=10)(retry_param)
    assert retry_param_with_retry(1, 2) is True



# Generated at 2022-06-22 21:16:10.182628
# Unit test for function retry
def test_retry():
    """Retry decorator tests"""
    global retries_count

    retries_count = 0

    @retry(retries=1, retry_pause=0)
    def retry_test():
        """a retry_test function"""
        global retries_count
        retries_count += 1
        raise Exception("test exception")

    try:
        retry_test()
        assert False, "Decorated function should be raising an exception"
    except Exception:
        pass
    assert retries_count == 2

    retries_count = 0

    @retry(retries=1, retry_pause=0)
    def retry_test():
        """a retry_test function"""
        global retries_count
        retries_count += 1
        return retries_count

    test = retry_

# Generated at 2022-06-22 21:16:11.729876
# Unit test for function retry
def test_retry():
    """
    Test retry function
    """
    function = retry(retry_limit=10, retry_pause=1)
    successful_call = False
    successful_call = function(successful_call)
    assert successful_call is True

# Generated at 2022-06-22 21:16:13.892825
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert 'rate' in result.keys()
    assert 'rate_limit' in result.keys()


# Generated at 2022-06-22 21:16:19.993873
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    argument_spec = basic_auth_argument_spec()
    assert argument_spec['api_username']['type'] == 'str'
    assert argument_spec['api_username']['type'] == 'str'
    assert argument_spec['api_password']['no_log'] == True
    assert argument_spec['api_url']['type'] == 'str'
    assert argument_spec['validate_certs']['type'] == 'bool'
    assert argument_spec['validate_certs']['default'] == True

# Generated at 2022-06-22 21:16:25.094245
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    args = (dict(
        api_username='phillip',
        api_password='phillip',
        api_url='phillip',
        validate_certs=True
    ))
    result = basic_auth_argument_spec(args)
    assert result == args

# Generated at 2022-06-22 21:16:27.163216
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(Exception) == False


# Generated at 2022-06-22 21:16:38.269458
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=60)
    def fake_func(return_value):
        return return_value

    last = [0.0]
    num_iterations = 100

    # faking time using a counter
    def fake_time():
        last[0] += 1
        return last[0]

    fake_func = functools.partial(fake_func, return_value=True)

    # setting time to be mocked
    if sys.version_info >= (3, 8):
        real_time = time.process_time
        time.process_time = fake_time
    else:
        real_time = time.clock
        time.clock = fake_time

    # assert that we do rate limit
    for _ in range(num_iterations):
        assert fake_func() is True

# Generated at 2022-06-22 21:16:43.406333
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert 'retries' in spec
    assert 'retry_pause' in spec
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1



# Generated at 2022-06-22 21:16:46.233949
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=10)
    def test():
        print("ok")
    for _ in range(0, 10):
        test()

# Generated at 2022-06-22 21:16:47.991981
# Unit test for function retry_never
def test_retry_never():
    exception = Exception("Something bad happened")
    assert retry_never(exception) is False


# Generated at 2022-06-22 21:16:50.814997
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec(spec=None)
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'


# Generated at 2022-06-22 21:16:58.810100
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }


# Generated at 2022-06-22 21:17:03.394020
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retry_pause']['type'] == 'float'
    assert arg_spec['retry_pause']['default'] == 1



# Generated at 2022-06-22 21:17:12.850754
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    basic_auth_args = basic_auth_argument_spec()
    assert 'api_username' in basic_auth_args
    assert 'api_password' in basic_auth_args
    assert 'api_url' in basic_auth_args
    assert 'validate_certs' in basic_auth_args
    assert basic_auth_args['api_username']['type'] == 'str'
    assert basic_auth_args['api_password']['type'] == 'str'
    assert basic_auth_args['api_url']['type'] == 'str'
    assert basic_auth_args['validate_certs']['type'] == 'bool'
    assert basic_auth_args['api_password'].get('no_log', None) == True

# Generated at 2022-06-22 21:17:23.944694
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # pylint: disable=unused-argument, too-few-public-methods
    x = 0
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=5))
    def function_should_not_retry(i):
        nonlocal x
        x += 1
        return i
    function_should_not_retry(0)
    # x should not have changed
    assert x == 1

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=5))
    def function_should_retry_and_succeed(i):
        nonlocal x
        x += 1
        if x < 3:
            raise Exception('foo')
        return i
    function_should_retry_and_succeed

# Generated at 2022-06-22 21:17:32.086121
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    args = dict(
        api_username='myuser',
        api_password='mypass',
        api_url='https://api.example.com',
        validate_certs=True
    )
    qq = basic_auth_argument_spec(args)
    assert qq['api_username']['type'] == 'str'
    assert qq['api_username']['type'] == 'str'
    assert qq['api_url']['type'] == 'str'
    assert qq['validate_certs']['type'] == 'bool'
    assert qq['validate_certs']['default'] is True

# Generated at 2022-06-22 21:17:36.655761
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    # Expected output:
    expected_output = (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    ))
    assert arg_spec == expected_output



# Generated at 2022-06-22 21:17:45.464001
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=1, delay_base=1, delay_threshold=60))
    def test_retryable_func():
        global test_retry_counter
        # Should only be incrementing once
        test_retry_counter += 1
        raise Exception('test')

    # Reset global
    global test_retry_counter
    test_retry_counter = 0

    # Will cause an exception
    test_retryable_func()

    assert test_retry_counter == 2



# Generated at 2022-06-22 21:17:51.726582
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def function(*args, **kwargs):
        function.call_count += 1
        if function.call_count == 4:
            return 'yea'
        else:
            raise Exception('nope')

    function.call_count = 0
    function_with_retry = retry_with_delays_and_condition(generate_jittered_backoff())(function)

    result = function_with_retry()
    assert result == 'yea'



# Generated at 2022-06-22 21:17:55.396255
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    result = retry_argument_spec(spec=None)
    assert result == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}


# Generated at 2022-06-22 21:17:57.335142
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-22 21:18:05.219969
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    data = dict(retries=10, retry_pause=0.25)
    module = AnsibleModule(argument_spec=retry_argument_spec())
    module.params = data
    module.check_mode = False

    def test_function():
        module.exit_json(changed=False)

    run_test = retry(module.params['retries'], module.params['retry_pause'])(test_function)
    run_test()

# Generated at 2022-06-22 21:18:10.820361
# Unit test for function rate_limit
def test_rate_limit():
    """Demonstrates the rate limiting decorator"""
    import random
    from time import sleep
    from time import time

    @rate_limit(rate=2, rate_limit=2)
    def foo():
        sleep(random.randint(0, 3))
        return time()

    start = time()
    for x in range(0, 10):
        foo()
    end = time() - start
    assert end >= 2.0 and end <= 3.0


# Generated at 2022-06-22 21:18:19.466477
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    _spec = (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))
    arg_spec = retry_argument_spec()
    assert arg_spec == _spec
    arg_spec = retry_argument_spec(spec=dict(another_key='another_value'))
    assert arg_spec == {'another_key': 'another_value', 'retries': {'type': 'int'},
                        'retry_pause': {'type': 'float', 'default': 1}}

# Generated at 2022-06-22 21:18:24.019856
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=1)
    def rate_limited():
        return rate_limited.counter

    rate_limited.counter = 0
    for i in range(1, 11):
        assert rate_limited() == i
        rate_limited.counter = i



# Generated at 2022-06-22 21:18:29.948776
# Unit test for function retry
def test_retry():
    @retry()
    def test_function():
        return False
    assert test_function() == retry_pause

    try:
        test_function = retry(retries=1)(test_function)
    except:
        pass
    else:
        assert False, "exception should have been raised"

# Generated at 2022-06-22 21:18:34.170177
# Unit test for function retry
def test_retry():
    @retry(retries=10, retry_pause=2)
    def raise_error():
        raise Exception("CRITICAL: error raised")

    try:
        raise_error()
    except Exception as e:
        assert e.args[0] == "Retry limit exceeded: 10"


# Generated at 2022-06-22 21:18:45.645118
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    def _raise_exception():
        raise Exception('operation failed')

    def _return_true():
        return True

    def _return_false():
        return False

    _retry_with_delays_and_condition = retry_with_delays_and_condition(generate_jittered_backoff(retries=10))

    @_retry_with_delays_and_condition
    def _raise_exception_and_never_retry():
        _raise_exception()

    # Exception should be raised
    try:
        _raise_exception_and_never_retry()
    except Exception:
        pass
    else:
        raise Exception('Exception never raised')


# Generated at 2022-06-22 21:18:49.834552
# Unit test for function retry
def test_retry():
    @retry(retries=10)
    def func(x):
        print(x)
        return x

    func(1)
    try:
        func(None)
    except Exception:
        pass



# Generated at 2022-06-22 21:18:55.277523
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    argument_spec = basic_auth_argument_spec()
    # Verify it creates a dict with 4 entries
    assert len(argument_spec) == 4
    # Verify all 4 entries are in the dict
    assert 'api_username' in argument_spec
    assert 'api_password' in argument_spec
    assert 'api_url' in argument_spec
    assert 'validate_certs' in argument_spec

# Generated at 2022-06-22 21:19:05.725833
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=5, rate_limit=5)
    def do_some_work():
        return True

    do_some_work()
    time.sleep(2)
    do_some_work()
    time.sleep(2)
    do_some_work()
    time.sleep(2)
    do_some_work()
    time.sleep(2)
    do_some_work()
    time.sleep(1)

    t1 = time.time()
    # this should block for 1 seconds
    do_some_work()
    t2 = time.time()
    d = t2 - t1
    assert d >= 1, 'rate limit blocked too short'



# Generated at 2022-06-22 21:19:08.733734
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        api_username=dict(type='str', default='test_username'),
        api_password=dict(type='str'),
        api_url=dict(type='str', default='test_url'),
        validate_certs=dict(type='bool', default=True)
    )
    assert spec == basic_auth_argument_spec(spec)

# Generated at 2022-06-22 21:19:15.378022
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = generate_jittered_backoff(retries=4, delay_base=3, delay_threshold=60)
    assert next(delays) == 3
    assert next(delays) == 6
    assert next(delays) == 12
    assert next(delays) == 24
    assert next(delays) == 48
    with pytest.raises(StopIteration):
        next(delays)



# Generated at 2022-06-22 21:19:20.116652
# Unit test for function retry
def test_retry():
    @retry(2, 2)
    def fails():
        print('fails')
        raise Exception('fail')

    try:
        fails()
    except Exception as e:
        print(e)

# Unit tests for function retry_with_delays_and_condition

# Generated at 2022-06-22 21:19:30.860639
# Unit test for function rate_limit
def test_rate_limit():
    # define a module to use it
    import logging
    import time

    class TestModule(object):

        def __init__(self, rate=None, rate_limit=None):
            self.rate = rate
            self.rate_limit = rate_limit

        @rate_limit(rate_limit=rate_limit, rate=rate)
        def run(self):
            logging.debug('running')
            return time.time()

    logging.basicConfig(level=logging.DEBUG)
    rate = 2
    rate_limit = 3
    module = TestModule(rate=rate, rate_limit=rate_limit)

    # simulate rate limiting
    times = []
    for i in range(0, 3):
        times.append(module.run())
        time.sleep(1)

    # check it ran the right number of times


# Generated at 2022-06-22 21:19:33.971827
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    result = basic_auth_argument_spec()
    assert result.get('api_username') is not None
    assert result.get('api_password') is not None
    assert result.get('api_url') is not None
    assert result.get('validate_certs') is not None

# Generated at 2022-06-22 21:19:39.268320
# Unit test for function retry
def test_retry():
    # Use a global variable to track how many times the function is called
    num_calls = 0

    @retry(retries=4, retry_pause=1)
    def function_that_may_raise():
        """Raise an exception every time, except the final attempt."""
        global num_calls
        num_calls += 1

        if num_calls < 4:
            raise Exception('This failed')
        else:
            return 'Woo!'

    assert function_that_may_raise() == 'Woo!'
    assert num_calls == 4

