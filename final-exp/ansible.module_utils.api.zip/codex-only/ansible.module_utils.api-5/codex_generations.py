

# Generated at 2022-06-22 21:09:45.603630
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.six import iteritems
    basic_auth_spec = basic_auth_argument_spec()
    assert isinstance(basic_auth_spec, dict)
    assert basic_auth_spec.keys() == frozenset(['api_username', 'api_password', 'api_url', 'validate_certs'])
    for key, value in iteritems(basic_auth_spec):
        assert isinstance(value, dict)
        assert value.keys() == frozenset(['type'])


if __name__ == '__main__':
    test_basic_auth_argument_spec()

# Generated at 2022-06-22 21:09:51.669383
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    arg_spec = rate_limit_argument_spec()
    assert arg_spec['rate'] == {'type': 'int'}
    assert arg_spec['rate_limit'] == {'type': 'int'}

    arg_spec = rate_limit_argument_spec(spec=dict(api_username=dict(type='str')))
    assert arg_spec['rate'] == {'type': 'int'}
    assert arg_spec['rate_limit'] == {'type': 'int'}
    assert arg_spec['api_username'] == {'type': 'str'}


# Generated at 2022-06-22 21:09:54.631091
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    result = list(backoff_iterator)
    assert len(result) == 10

# Generated at 2022-06-22 21:10:01.808375
# Unit test for function rate_limit
def test_rate_limit():

    minrate = None
    if 2 is not None and 10 is not None:
        minrate = float(10) / float(2)

    last = 0.0

    def real_time():
        last = 0.0 + 1
        return last

    def ratelimited(*args, **kwargs):

        elapsed = real_time() - last
        left = minrate - elapsed
        if left > 0:
            time.sleep(left)
        last = real_time()

    ratelimited()



# Generated at 2022-06-22 21:10:06.538141
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=10)
    def my_function():
        return True

    start = time.time()
    for i in range(20):
        my_function()
    end = time.time()
    assert(end - start >= 2.0)



# Generated at 2022-06-22 21:10:11.959150
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    args = {}
    args.update(basic_auth_argument_spec())
    assert args['api_username']['type'] == 'str'
    assert args['api_password']['type'] == 'str'
    assert args['api_url']['type'] == 'str'
    assert args['validate_certs']['type'] == 'bool'

# Generated at 2022-06-22 21:10:14.940181
# Unit test for function retry_never
def test_retry_never():
    try:
        raise Exception
    except Exception as e:
        if retry_never(e):
            raise Exception("retry_never() is supposed to return a bool, but did not do so")

# Generated at 2022-06-22 21:10:27.445226
# Unit test for function rate_limit
def test_rate_limit():
    def test():
        print('test')

    # Test values
    RATE_LIMIT = 500  # Limit is 500 requests per second
    DELAY = 2  # should pause for at least 2 seconds
    N_CALLS = 3  # make 3 calls

    # decorator factory
    rate_limit_decorator = rate_limit(rate=RATE_LIMIT, rate_limit=RATE_LIMIT)

    @rate_limit_decorator
    def rate_limited_test():
        print('rate_limited_test')

    # rate limited calls
    before = time.time()
    for _ in range(N_CALLS):
        rate_limited_test()
    after = time.time()

    # calls without rate limit
    no_rate_limit_before = time.time()

# Generated at 2022-06-22 21:10:30.910463
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(1)
    assert not retry_never(Exception('hi'))
    assert not retry_never(Exception('hi', 1))
    assert not retry_never((Exception('hi', 1), 2))



# Generated at 2022-06-22 21:10:34.086084
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    ))



# Generated at 2022-06-22 21:10:39.980572
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    spec = retry_argument_spec(dict(
        test=dict(type='int'),
    ))
    module = AnsibleModule(argument_spec=spec)
    assert module.params['test'] == 1
    assert module.params['retries'] == 5
    assert module.params['retry_pause'] == 1

# Generated at 2022-06-22 21:10:46.792285
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest

    def delayed_response(success_on_attempt, exceptions):
        def delayed_response_function(*args, **kwargs):
            if success_on_attempt > 0:
                success_on_attempt -= 1
                raise exceptions[success_on_attempt]
            return 'ok'
        return delayed_response_function

    def retry_on_value_error(error):
        return isinstance(error, ValueError)

    def retry_on_except_key_error(error):
        return isinstance(error, KeyError)

    def no_retries(error):
        return False

    call_delayed_response = retry_with_delays_and_condition(generate_jittered_backoff(), retry_on_value_error)


# Generated at 2022-06-22 21:10:55.348045
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec(spec={'test': {'type': 'int'}}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}, 'test': {'type': 'int'}}
    assert retry_argument_spec(spec={'retry_pause': {}}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}

# Generated at 2022-06-22 21:11:01.637289
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # Test with empty spec
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    # Test with non empty spec
    assert retry_argument_spec({'ds': {'type': 'ds'}}) == {'ds': {'type': 'ds'}, 'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}


# Generated at 2022-06-22 21:11:04.138701
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff(10, 1, 0.5):
        assert delay <= 0.5
        print(delay)

# Generated at 2022-06-22 21:11:09.401937
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    test_spec = dict(
        test_arg=dict(type='int'),
        test_arg2=dict(type='bool')
    )
    res = rate_limit_argument_spec(test_spec)
    assert len(res.keys()) == 4
    assert 'rate' in res
    assert 'rate_limit' in res
    assert 'test_arg' in res
    assert 'test_arg2' in res



# Generated at 2022-06-22 21:11:14.341335
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))
    assert (retry_argument_spec(rate_limit_argument_spec()) ==
            retry_argument_spec(arg_spec))

# Generated at 2022-06-22 21:11:21.622795
# Unit test for function retry
def test_retry():
    # This test has to be a function, not a unittest class, because we want to
    # test the decorator.
    def test_case(retries, retry_pause, expected_results):
        results = []
        @retry(retries, retry_pause)
        def retried(*args, **kwargs):
            results.append(True)
            if 'exception' in kwargs and kwargs['exception']:
                raise Exception("Testing retry")
            return 'ok'
        try:
            retried(exception=True)
            assert False
        except Exception:
            pass
        assert results == expected_results

    test_case(retries=None, retry_pause=1, expected_results=[])

# Generated at 2022-06-22 21:11:32.127260
# Unit test for function retry
def test_retry():
    random.seed(42)
    jittered_backoff = list(generate_jittered_backoff(retries=4, delay_base=2, delay_threshold=4))

    def dummy_function():
        raise Exception("this exception happens every time")

    @retry_with_delays_and_condition(jittered_backoff)
    def dummy_function_with_retry():
        return dummy_function()

    try:
        dummy_function_with_retry()
    except Exception as e:
        assert e.args == ('this exception happens every time',)
    else:
        assert False

    try:
        jittered_backoff = iter([])
        dummy_function_with_retry()
    except Exception as e:
        assert e.args == ('this exception happens every time',)

# Generated at 2022-06-22 21:11:41.610361
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    retry_attempts = 3
    delay_base = 3
    delay_threshold = 60
    # Verify the expected number of retries.
    assert len(list(generate_jittered_backoff(retry_attempts))) == retry_attempts
    # Verify the base is used for the first delay.
    delays = list(generate_jittered_backoff(retry_attempts, delay_base=delay_base))
    assert delays[0] >= 0 and delays[0] <= delay_base
    # Verify the threshold is honored.
    delays = list(generate_jittered_backoff(retry_attempts, delay_base=delay_base, delay_threshold=delay_threshold))

# Generated at 2022-06-22 21:11:52.585913
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=15)
    def count(c=0):
        return c + 1

    assert count() == 1
    assert count() == 2
    assert count() == 3
    time.sleep(10)
    assert count() == 4
    assert count() == 5

    @rate_limit(rate=10, rate_limit=15)
    def count(c=0):
        return c + 1

    assert count() == 1
    assert count() == 2
    # this would be 3
    try:
        count()
    except Exception as e:
        if str(e) != 'Retry limit exceeded: 3':
            raise
    # now we can go again
    assert count() == 4
    assert count() == 5


# Generated at 2022-06-22 21:11:57.615299
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = {}
    spec.update(rate_limit_argument_spec())
    assert spec['rate']['type'] == 'int'
    assert spec['rate_limit']['type'] == 'int'
    assert 'default' not in spec['rate']
    spec.update(rate_limit_argument_spec(spec=dict(default=3)))
    assert spec['default'] == 3
    assert spec['rate']['default'] == 3
    assert spec['rate_limit']['default'] == 3



# Generated at 2022-06-22 21:11:59.800205
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never("do not retry") == False


# Generated at 2022-06-22 21:12:01.866720
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception())
    assert not retry_never(None)


# Generated at 2022-06-22 21:12:06.149743
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    assert retry_argument_spec({'a': 'b'}) == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        a='b',
    )


# Generated at 2022-06-22 21:12:17.181163
# Unit test for function retry
def test_retry():
    """Unit test for retry_with_delays_and_condition"""
    import pytest

    # Simple error that is not expected to be retried
    class UnexpectedError(Exception):
        pass

    # Basic error that can be retried
    class RetryableError(Exception):
        pass

    # Returns the number of times function was called in a retry
    def call_count(function):
        @functools.wraps(function)
        def wrapper(*args, **kwargs):
            wrapper.call_count += 1
            return function(*args, **kwargs)
        wrapper.call_count = 0
        return wrapper

    # Always retry
    def retry_all(exception):
        return True

    # Retry a maximum of three times
    def retry_three_times(exception):
        return retry

# Generated at 2022-06-22 21:12:19.474232
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception)
    assert not retry_never(Exception("whatever"))


# Generated at 2022-06-22 21:12:23.112786
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=10)
    delays = []
    for delay in backoff_iterator:
        delays.append(delay)
    expected_delays = [0, 3, 6, 12, 24, 48, 52, 56, 60, 60]
    assert delays == expected_delays


# Generated at 2022-06-22 21:12:26.884566
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}



# Generated at 2022-06-22 21:12:33.416980
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = {'foo': {'required': False}}
    arg_spec = rate_limit_argument_spec(spec)

    assert arg_spec['rate']['type'] == 'int'
    assert arg_spec['rate_limit']['type'] == 'int'
    assert arg_spec['foo']['required'] == False



# Generated at 2022-06-22 21:12:34.656563
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception('foo')) == False


# Generated at 2022-06-22 21:12:37.960700
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec(dict(a=1)) == dict(retries=dict(type='int'), retry_pause=dict(type='float', default=1), a=dict(a=1))

# Generated at 2022-06-22 21:12:42.629496
# Unit test for function retry
def test_retry():
    @retry(retries=3)
    def func(count):
        func.count += 1
        if func.count == 3:
            return "FIRST", "SECOND"
        else:
            return None

    func.count = 0
    result = func(3)
    assert func.count == 3
    assert result == ("FIRST", "SECOND")



# Generated at 2022-06-22 21:12:44.109848
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception())


# Generated at 2022-06-22 21:12:54.165328
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestException(Exception):
        pass

    @retry_with_delays_and_condition([3, 6, 9], lambda e: isinstance(e, TestException))
    def retryable_failing_function():
        raise TestException()
    try:
        retryable_failing_function()
    except TestException:
        pass
    else:
        raise Exception("Failed to raise exception")

    @retry_with_delays_and_condition([])
    def retryable_function():
        return 1
    assert retryable_function() == 1

    @retry_with_delays_and_condition([2, 4, 6])
    def retryable_working_function():
        return 1
    assert retryable_working_function() == 1

# Generated at 2022-06-22 21:13:04.611710
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert spec['rate']['type'] == 'int'
    assert spec['rate_limit']['type'] == 'int'

    expected_added_spec = {"some_key": "some_value"}
    spec = rate_limit_argument_spec(expected_added_spec)
    assert spec['some_key'] == 'some_value'

    expected_added_spec = {"rate": "some_value", "rate_limit": "some_value"}
    spec = rate_limit_argument_spec(expected_added_spec)
    assert spec['rate'] == 'some_value'
    assert spec['rate_limit'] == 'some_value'


# Generated at 2022-06-22 21:13:07.609919
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}

# Generated at 2022-06-22 21:13:14.929675
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest
    # Don't ever retry, just cause one failure
    @retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=retry_never)
    def no_retries():
        print("I am never retried.")
        raise ValueError

    # Test the retry function can be called with just exception types
    @retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=ValueError)
    def vale_error_retry():
        print("I am retried")
        raise ValueError

    # Test the retry function can be called with a function

# Generated at 2022-06-22 21:13:16.668788
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec()['retries'] == dict(type='int')


# Generated at 2022-06-22 21:13:21.047112
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=(dict(
        retries=dict(type='int', default=10),
        retry_pause=dict(type='float', default=1),
    )))
    module.exit_json(**module.params)

# Generated at 2022-06-22 21:13:24.477904
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(Exception('hello')) == False


# Generated at 2022-06-22 21:13:28.570713
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_list = [t for t in generate_jittered_backoff(retries=3)]

    if len(delay_list) != 3:
        raise Exception("The generated list should contain 3 elements")

    if max(delay_list) > 3:
        raise Exception("There should not be any delay greater than the base delay")

# Generated at 2022-06-22 21:13:38.798297
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class MyException(Exception):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return repr(self.value)

    def should_retry_error(e):
        if isinstance(e, MyException):
            return e.value

    # noinspection PyUnusedLocal
    def retryable_function():
        """Function that may return an exception."""
        return False  # no exception

    def retryable_function_with_exception():
        """Function that may return an exception."""
        try:
            raise MyException(True)
        except MyException as e:
            raise e
        return False  # no exception

    def retryable_function_with_non_retriable_exception():
        """Function that may return an exception."""


# Generated at 2022-06-22 21:13:44.521055
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(1) == False
    assert retry_never(Exception) == False
    assert retry_never(Exception("error")) == False
    assert retry_never(Exception(ValueError)) == False
    assert retry_never(Exception(ValueError("error"))) == False


# Generated at 2022-06-22 21:13:56.095000
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from functools import partial

    def raises_exception(args):
        val = args[0]
        if val == 0:
            raise ValueError("Value is zero")
        return val

    retryable_callable = partial(raises_exception, [0])

    # Incorrect input
    try:
        retry_with_delays_and_condition([1, 1, 1], None)(retryable_callable)
    except TypeError as e:
        assert str(e) == "retry_with_delays_and_condition expects an iterable of delays followed by a function that accepts an exception and returns a bool."

    # Retry on error
    retryable_callable = partial(raises_exception, [0])

# Generated at 2022-06-22 21:14:02.372731
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for _, delay in zip(range(0, 10), generate_jittered_backoff()):
        assert delay >= 0 and delay <= 60
    for _, delay in zip(range(0, 10), generate_jittered_backoff(delay_base=2)):
        assert delay >= 0 and delay <= 120
    for _, delay in zip(range(0, 10), generate_jittered_backoff(delay_threshold=10)):
        assert delay >= 0 and delay <= 10

# Generated at 2022-06-22 21:14:04.241132
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception)



# Generated at 2022-06-22 21:14:13.629915
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3), retry_never)
    def test_retry_function():
        global test_retry_function_counter
        test_retry_function_counter += 1
        print("Called the test retryable function %d times" % test_retry_function_counter)
        if test_retry_function_counter == 3:
            return True
        else:
            raise RuntimeError("Not yet retrying")

    test_retry_function_counter = 0
    test_retry_function()

    test_retry_function_counter = 0


# Generated at 2022-06-22 21:14:16.604558
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))
    assert retry_argument_spec() == argument_spec



# Generated at 2022-06-22 21:14:22.068058
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoffs = [delay for delay in generate_jittered_backoff(3, 3, 5)]
    assert backoffs == [0, 1, 4], "backoffs should be [0, 1, 4] instead of " + str(backoffs)

    backoffs = [delay for delay in generate_jittered_backoff(4, 5, 20)]
    assert backoffs == [0, 2, 6, 14], "backoffs should be [0, 2, 6, 14] instead of " + str(backoffs)

# Generated at 2022-06-22 21:14:24.842039
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit"""
    @rate_limit(5, 3)
    def do_rate_limit():
        print('hi')

    for _ in range(0, 100):
        do_rate_limit()



# Generated at 2022-06-22 21:14:27.961287
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = dict(rate=dict(type='int'), rate_limit=dict(type='int'))
    assert rate_limit_argument_spec() == arg_spec

# Generated at 2022-06-22 21:14:33.689692
# Unit test for function retry_never
def test_retry_never():
    # This is just to test if the function is working as it is supposed to work.
    # For example, if the default value for should_retry_error was changed accidentally, the backward compatibility with
    # the existing tests shall remain.
    # The test fails if the default value is changed and the backward compatibility is broken.
    assert retry_never == retry_never()



# Generated at 2022-06-22 21:14:37.474137
# Unit test for function retry
def test_retry():
    @retry(retries=3)
    def _test_retry_inner():
        print("Inner")
        raise Exception()
    try:
        _test_retry_inner()
    except Exception:
        pass
    else:
        raise Exception("fail")
    print("Passed")



# Generated at 2022-06-22 21:14:39.727228
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec()['validate_certs']['default'] == True


# Generated at 2022-06-22 21:14:42.130280
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) == False
    assert retry_never(None) == False


# Generated at 2022-06-22 21:14:48.911388
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    g = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    assert next(g) <= 3
    assert next(g) <= 6
    assert next(g) <= 12
    assert next(g) <= 24
    assert next(g) <= 48
    assert next(g) <= 60
    assert next(g) <= 60
    assert next(g) <= 60
    assert next(g) <= 60
    assert next(g) <= 60
    try:
        next(g)
        assert False
    except StopIteration:
        assert True

# Generated at 2022-06-22 21:14:58.610651
# Unit test for function rate_limit
def test_rate_limit():
    import unittest
    import sys

    class RateLimitTest(unittest.TestCase):
        def test_rate_limit_no_limit(self):
            if sys.version_info >= (3, 8):
                real_time = time.process_time
            else:
                real_time = time.clock
            start = real_time()
            @rate_limit(0, 0)
            def no_limit():
                pass
            no_limit()
            end = real_time()
            duration = end - start
            self.assertTrue(duration < 0.1)

        def test_rate_limit_seconds(self):
            if sys.version_info >= (3, 8):
                real_time = time.process_time
            else:
                real_time = time.clock
            start = real_time()


# Generated at 2022-06-22 21:15:06.813688
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        key1=dict(type='str'),
        key2=dict(type='bool', default=True)
    )
    spec = dict(
        key1=dict(type='str'),
        key2=dict(type='bool', default=True)
    )
    result = rate_limit_argument_spec(spec)
    assert result == expected

# Generated at 2022-06-22 21:15:10.850030
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    args = rate_limit_argument_spec()
    assert isinstance(args, dict)
    assert len(args) == 2
    assert isinstance(args['rate'], dict)
    assert isinstance(args['rate_limit'], dict)

# Generated at 2022-06-22 21:15:17.449910
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=2, rate_limit=5)
    def print_hello():
        print("Hello")

    # print_hello will be executed 5 times every 5 seconds
    # but only 2 hello per second because rate_limit=2
    # if rate_limit=1 then only 1 hello per second
    for i in range(0, 5):
        print_hello()

if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-22 21:15:26.184464
# Unit test for function rate_limit
def test_rate_limit():
    '''test_rate_limit'''
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock
    t = time.time()
    start = real_time()
    @rate_limit(10, 10)
    def test_function():
        print(time.time() - t)
        e = real_time() - start
        print('time elapsed', e, '\n')
        return True

    for n in range(0, 20):
        test_function()

if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-22 21:15:34.343514
# Unit test for function rate_limit
def test_rate_limit():
    import os

    def test_rate(rate, rate_limit):
        """Decorator to test behaviour of rate_limit"""
        @rate_limit(rate, rate_limit)
        def print_time(first_call=False):
            t = time.time()
            if first_call:
                return t
            print(time.time() - t)

        # test first call
        now = print_time(first_call=True)
        # test second call
        print('---')
        print_time()
        # test multiple calls
        print('---')
        n = 10
        if rate > n:
            n = rate + 1
        for i in range(n):
            print_time()

        # test that the minimum time between calls is rate, if not
        # first_call will be less than now

# Generated at 2022-06-22 21:15:41.485923
# Unit test for function rate_limit
def test_rate_limit():
    """Generate a random number and sleep for that number, and make sure it takes at least 60 seconds to run"""
    runs = 0
    start = time.time()
    # We will run this for 1 minute
    for i in range(0, 60):
        @rate_limit(rate=1, rate_limit=1)
        def test():
            """Generate a random number and sleep for that number of seconds"""
            number = random.randint(0, 9)
            time.sleep(number)

        test()
        runs += 1
    end = time.time()
    assert end >= start + 60
    return runs



# Generated at 2022-06-22 21:15:48.250180
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestException(Exception):
        def __init__(self, message):
            self.message = message

    @retry_with_delays_and_condition(generate_jittered_backoff(), lambda e: isinstance(e, TestException))
    def retry_me():
        raise TestException("retry_me")

    try:
        retry_me()
    except TestException as e:
        assert e.message == "retry_me"
    else:
        raise Exception("Expected TestException")



# Generated at 2022-06-22 21:15:56.764354
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    num_delays = 10
    delay_base = 2
    delay_threshold = 30
    backoff_iterator = generate_jittered_backoff(retries=num_delays,
                                                 delay_base=delay_base,
                                                 delay_threshold=delay_threshold)

    assert(isinstance(backoff_iterator, collections.Iterable))

    for i, delay in enumerate(backoff_iterator):
        assert(isinstance(delay, int))
        assert(delay >= 0)
        assert(delay <= delay_threshold)

        # Check that we got the number of delays we requested
        if i == (num_delays - 1):
            assert(delay_threshold == delay)

# Generated at 2022-06-22 21:16:07.703759
# Unit test for function rate_limit
def test_rate_limit():
    import time
    # This test is to validate that a rate_limited function is actually
    # limited to a specific rate.
    # The test rate is set at 100 calls per second, which means each
    # call should take approx 10ms.
    # To test this, we measure the time it takes to make 10 calls,
    # multiply it by 10 and verify it's approximately 100ms.
    # Since time.time() is not guaranteed to be precise, we add a
    # margin of error of 0.15, the resulting max time should be 115ms
    @rate_limit(100, 1)
    def simple_func():
        # If this test fails, it might be that time.time is only
        # precise up to 10ms, try using time.clock instead
        pass
    start_time = time.time()

# Generated at 2022-06-22 21:16:13.693363
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    expected_argument_spec = {
        "api_password":{
            "type":"str",
            "no_log":True
        },
        "api_username":{
            "type":"str"
        },
        "api_url":{
            "type":"str"
        },
        "validate_certs":{
            "type":"bool",
            "default":True
        }
    }
    assert basic_auth_argument_spec() == expected_argument_spec


# Generated at 2022-06-22 21:16:20.579053
# Unit test for function rate_limit
def test_rate_limit():
    import timeit
    @rate_limit(rate=5, rate_limit=60)
    def x(a):
        time.sleep(0.1)
        return a

    @rate_limit(rate=5, rate_limit=60)
    def y(a):
        time.sleep(1)
        return a

    print('results')
    print(timeit.timeit(lambda: x('a'), number=10))
    print(timeit.timeit(lambda: y('a'), number=10))
    print(timeit.timeit(lambda: y('a'), number=10))

# Generated at 2022-06-22 21:16:24.766138
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected_results = {'rate': dict(type='int'), 'rate_limit': dict(type='int')}
    assert rate_limit_argument_spec() == expected_results


# Generated at 2022-06-22 21:16:33.493054
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = { 'arg1': {'type': 'str'} }
    ansible_args = rate_limit_argument_spec(arg_spec)
    asserts = [
        {'key': 'rate'},
        {'key': 'rate_limit'},
        {'key': 'arg1'},
    ]
    for assert_item in asserts:
        assert assert_item['key'] in ansible_args

if __name__ == '__main__':
    test_rate_limit_argument_spec()

# Generated at 2022-06-22 21:16:40.658112
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    expected_basic_auth_argument_spec = {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }
    actual_basic_auth_argument_spec = basic_auth_argument_spec()
    assert expected_basic_auth_argument_spec == actual_basic_auth_argument_spec


# Generated at 2022-06-22 21:16:45.699255
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    test_spec = {"test": "test"}
    result = retry_argument_spec(test_spec)
    if result != {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}, 'test': 'test'}:
        raise Exception("Result is not as expected.")

# Generated at 2022-06-22 21:16:48.326259
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoffs_gen = generate_jittered_backoff()
    for backoff in backoffs_gen:
        assert isinstance(backoff, int)

# Generated at 2022-06-22 21:16:53.295711
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=5, rate_limit=1)
    def test_rate_limited_func(count):
        count.append(count[0] + 1)
        return count

    count = [0]
    for i in range(0, 10):
        test_rate_limited_func(count)
    assert count[0] == 5


# Generated at 2022-06-22 21:16:54.301646
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False

# Generated at 2022-06-22 21:16:56.671441
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) is False
    assert retry_never(None) is False


# Generated at 2022-06-22 21:17:08.056791
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def _advanced_callable(*args, **kwargs):
        return _callable(*args, **kwargs)

    def _callable(*args, **kwargs):
        # Exceptions are consumed by run_function
        if args[0] < 0:
            raise Exception("Exception")
        return args[0]

    returned_values = []

    # Function does not raise exceptions (no retry)
    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def my_function(value):
        returned_values.append(value)
        return _callable(value)

    my_function(3)

    assert returned_values == [3]

    # Function raises exceptions (retry)

# Generated at 2022-06-22 21:17:19.128393
# Unit test for function rate_limit
def test_rate_limit():
    """
    test the rate_limit decorator
    """
    import time
    import random

    @rate_limit(rate=10, rate_limit=60)
    def limited(i=None):
        """This is a rate limited function"""
        if i is None:
            i = []
        i.append(1)
        return i

    l = limited()
    time.sleep(0.5)
    l = limited()
    time.sleep(0.5)
    l = limited()
    time.sleep(0.5)
    l = limited()
    time.sleep(0.5)
    l = limited()
    time.sleep(0.5)
    l = limited()
    time.sleep(0.5)
    l = limited()
    time.sleep(0.5)
    l = limited

# Generated at 2022-06-22 21:17:20.417661
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        print(delay)

# Generated at 2022-06-22 21:17:28.281031
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Pull out the backoff delays so we can test them
    backoff_delays = [delay for delay in generate_jittered_backoff()]
    assert backoff_delays == [0, 0, 3, 0, 6, 3, 12, 12, 24, 48]

    backoff_delays = [delay for delay in generate_jittered_backoff(retries=20)]
    assert backoff_delays == [0, 0, 3, 0, 6, 3, 12, 12, 24, 48, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96]

    backoff_delays = [delay for delay in generate_jittered_backoff(retries=20, delay_threshold=50)]

# Generated at 2022-06-22 21:17:36.234820
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Test the jittered backoff function"""
    last_delay = None
    total = 0
    for delay in generate_jittered_backoff():
        if last_delay:
            assert delay >= last_delay
            assert delay <= 2 * last_delay
        else:
            assert delay > 0
            assert delay <= 3

        total += delay
        # Allow for a wide margin of error because we're working with randomness
        assert total < 100
        last_delay = delay



# Generated at 2022-06-22 21:17:39.889585
# Unit test for function rate_limit
def test_rate_limit():
    """
    >>> @rate_limit(rate=10, rate_limit=3)
    ... def f(): return True
    >>> f.__name__
    'ratelimited'
    >>> f.__doc__
    'rate limit decorator'
    >>> f()
    True
    """
    pass

# Generated at 2022-06-22 21:17:47.408374
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = {'api_username': {'type': 'str'},
            'api_password': {'type': 'str', 'no_log': True},
            'api_url': {'type': 'str'},
            'validate_certs': {'type': 'bool', 'default': True}}
    module = AnsibleModule(
        argument_spec=basic_auth_argument_spec()
    )
    assert module.params == spec

# Generated at 2022-06-22 21:17:58.184519
# Unit test for function retry
def test_retry():
    """Test the retry function to make sure it works as expected."""
    import random
    success_count = 0
    error_count = 0
    retries_count = 0
    retry_limit = 3
    random.seed(1)

    # Use a non-reachable IP address
    @retry(retries=retry_limit, retry_pause=0.001)
    def _test_retry():
        number = random.randint(1, 10)
        global success_count
        global error_count
        global retries_count
        if number == 1:
            # Simulate a successful connection.
            success_count += 1
            ret = True
        else:
            # Simulate an error.
            error_count += 1
            ret = False
        retries_count += 1
        return ret

   

# Generated at 2022-06-22 21:18:09.542974
# Unit test for function retry
def test_retry():

    class Error(Exception):
        pass

    @retry(retries=5, retry_pause=0.1)
    def _raise_retry(failures):
        """Test a retryable"""
        if failures[0] > 0:
            failures[0] -= 1
            raise Error("Unretryable")
        else:
            return "Suceeded"

    # success
    assert _raise_retry([0]) == "Suceeded"

    # hard failure
    try:
        _raise_retry([1])
    except Exception as e:
        assert str(e) == "Unretryable"

    # retry failure
    try:
        _raise_retry([5])
        assert False
    except Exception as e:
        assert  str(e) == "Retry limit exceeded: 5"

# Generated at 2022-06-22 21:18:13.274441
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    ))

    assert rate_limit_argument_spec() == arg_spec



# Generated at 2022-06-22 21:18:24.233564
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Test the retry_with_delays_and_condition decorator.
    Expected behavior is:
    - The function is called up to 5 times.
    - Each call is delayed by 0 to 3 seconds.
    - The first call falls and the second one returns 10.
    - The third and fourth calls also fall.
    - The fifth call finally succeeds and returns 20.
    """
    function_calls = 0
    max_function_calls = 5
    call_delay = 3
    call_success_return_value = 10
    fail_after_attempts = 2
    function_success_return_value = 20
    call_success = False

    def should_retry_error(err):
        return True

    def test_retryable_function():
        nonlocal function_calls
        nonlocal call_success
       

# Generated at 2022-06-22 21:18:28.926710
# Unit test for function retry
def test_retry():
    class TestException(Exception):
        pass

    @retry(retries=4, retry_pause=1)
    def test_func():
        raise TestException

    try:
        test_func()
    except Exception:
        pass

# Generated at 2022-06-22 21:18:31.636736
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=1)
    def error_test():
        return False

    assert(error_test())


# Generated at 2022-06-22 21:18:33.413589
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never(None) == False)


# Generated at 2022-06-22 21:18:45.123425
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class RetryableException(Exception):
        pass

    class NonRetryableException(Exception):
        pass

    def side_effect(*args, **kwargs):
        raise_exception = kwargs['exception'] if 'exception' in kwargs else None
        if raise_exception == 'retryable':
            raise RetryableException()
        elif raise_exception == 'nonretryable':
            raise NonRetryableException()

    def retryable_exception_predicate(exception):
        if isinstance(exception, RetryableException):
            return True
        return False


# Generated at 2022-06-22 21:18:47.261650
# Unit test for function retry_never
def test_retry_never():
    tested_exception = Exception("Test exception")
    assert retry_never(tested_exception) == False
    assert retry_never("non_exception") == False

# Generated at 2022-06-22 21:18:55.153741
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=5, delay_base=6, delay_threshold=10)
    backoff_delays = [next(backoff_iterator) for _ in range(5)]
    # These values are the output of the code when I ran the test.
    # The results should be relatively random so you can't have an exact value for the test.
    assert backoff_delays[0:4] == [4, 2, 5, 9]
    assert 0 <= backoff_delays[4] <= 10

# Generated at 2022-06-22 21:18:56.603626
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False
    assert retry_never(None) == False


# Generated at 2022-06-22 21:18:59.825302
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    args = rate_limit_argument_spec()
    assert isinstance(args, dict)
    assert 'rate' in args.keys()
    assert 'rate_limit' in args.keys()


# Generated at 2022-06-22 21:19:01.993032
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception)
    assert not retry_never(Exception())

# Generated at 2022-06-22 21:19:04.672680
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert isinstance(rate_limit_argument_spec(), dict)
    args = {'rate': 1, 'rate_limit': 1}
    assert rate_limit_argument_spec(args) == args

# Generated at 2022-06-22 21:19:05.505127
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('foo') == False

# Generated at 2022-06-22 21:19:12.404469
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # This test is based on the HTTP retry strategy described here:
    # https://cloud.google.com/storage/docs/json_api/v1/how-tos/upload#retry-transient-errors

    # Mocking: simulate a 500 error the first two tries, then success on the third try.
    mock_http_response_500 = dict(status=500, raises_exception=True)
    mock_http_response_200 = dict(status=200, raises_exception=False)
    mock_http_responses = [
        mock_http_response_500, mock_http_response_500, mock_http_response_200
    ]
    test_delays = list(generate_jittered_backoff(retries=len(mock_http_responses)))
    # Test expectations
    expected_run_

# Generated at 2022-06-22 21:19:20.167992
# Unit test for function retry
def test_retry():
    @retry(retries=4, retry_pause=1)
    def test_retry_with_retries(i, not_raise=False):
        if not_raise:
            return
        raise Exception("Failed")

    @retry(retries=None)
    def test_retry_without_retries(i, raise_error=False):
        if raise_error:
            raise Exception("Failed")

    @retry(retries=2)
    def test_retry_with_short_retries(i, raise_error=False):
        if raise_error:
            raise Exception("Failed")


# Generated at 2022-06-22 21:19:25.587370
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected_result = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    result = rate_limit_argument_spec()
    assert result == expected_result


# Generated at 2022-06-22 21:19:31.357915
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    expected_result = {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
    }
    actual_result = rate_limit_argument_spec()
    assert expected_result == actual_result


# Generated at 2022-06-22 21:19:33.596370
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
    rate=dict(type='int'),
    rate_limit=dict(type='int'),
    )


# Generated at 2022-06-22 21:19:35.164592
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(False)
    assert not retry_never(0)



# Generated at 2022-06-22 21:19:41.347343
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """Unit test for the rate_limit_argument_spec function"""
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.api import rate_limit

    ARG_SPEC = dict(
        name=dict(type='str'),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        retry_pause=dict(type='int'),
        retries=dict(type='int'),
    )
    module = AnsibleModule(
        argument_spec=rate_limit_argument_spec(ARG_SPEC)
    )

    @rate_limit(rate_limit=module.params['rate_limit'], rate=module.params['rate'])
    def _do():
        return module.params