

# Generated at 2022-06-22 21:09:45.933188
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        test1=dict(required=True),
        test2=dict(required=True),
        test3=dict(required=True)
    )
    auth_spec = basic_auth_argument_spec(spec)
    assert auth_spec["api_username"]["type"] == "str"
    assert auth_spec["api_password"]["type"] == "str"
    assert auth_spec["api_url"]["type"] == "str"
    assert auth_spec["validate_certs"]["type"] == "bool"
    assert auth_spec["test1"]["required"] is True
    assert auth_spec["test2"]["required"] is True
    assert auth_spec["test3"]["required"] is True

# Generated at 2022-06-22 21:09:46.824336
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)

# Generated at 2022-06-22 21:09:53.217885
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """Test function rate_limit_argument_spec
    """
    from ansible.module_utils.common.arguments import ArgSpec
    arg_spec = rate_limit_argument_spec()
    # rate_limit_argument_spec does not accept a spec
    assert arg_spec == ArgSpec(rate=dict(type='int'),
                               rate_limit=dict(type='int'))


# Generated at 2022-06-22 21:09:57.056283
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception())
    assert not retry_never(None)
    assert not retry_never('')
    assert not retry_never(True)
    assert not retry_never(False)
    assert not retry_never(0)

# Generated at 2022-06-22 21:09:59.534205
# Unit test for function retry_never
def test_retry_never():
    test_exception = Exception("Testing")
    assert retry_never(test_exception) is False
    assert retry_never("Success") is False

# Generated at 2022-06-22 21:10:10.537080
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition([0, 0, 0, 0, 0], False)
    def function_with_is_retryable_false():
        return True

    @retry_with_delays_and_condition([0, 0, 0, 0, 0], True)
    def function_with_is_retryable_true():
        return True

    @retry_with_delays_and_condition([1, 1, 1], lambda e: False)
    def function_with_exception():
        raise ValueError('test')

    assert function_with_is_retryable_false() is True
    assert function_with_is_retryable_true() is True
    try:
        function_with_exception()
    except Exception as e:
        assert e.message == 'test'

# Generated at 2022-06-22 21:10:12.310020
# Unit test for function retry_never
def test_retry_never():
    exc = Exception
    assert retry_never(exc) is False


# Generated at 2022-06-22 21:10:14.919783
# Unit test for function retry_never
def test_retry_never():
    # Testing for positive result
    assert retry_never(True) is False
    # Testing for negative result
    assert retry_never(False) is False


# Generated at 2022-06-22 21:10:21.469550
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    expected_values = [1, 2, 1, 2, 4, 1, 2, 0, 0, 0]
    for index, value in enumerate(expected_values):
        assert next(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=10)) == value

# Generated at 2022-06-22 21:10:24.000096
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    data = rate_limit_argument_spec()
    assert data.get('rate') is not None
    assert data.get('rate_limit') is not None

    data = rate_limit_argument_spec(spec=dict(rate=dict(type='str')))
    assert data.get('rate') is not None
    assert data.get('rate').get('type') == 'str'
    assert data.get('rate_limit') is not None


# Generated at 2022-06-22 21:10:26.666304
# Unit test for function rate_limit
def test_rate_limit():
    import sys
    import doctest

    ctx = dict(
        module=dict(
            params=dict(rate=10, rate_limit=3600),
        ),
        rate_limit=rate_limit,
    )

    if sys.version_info[:2] == (3, 5):
        doctest.testmod(m=sys.modules[__name__], extraglobs=ctx)
    else:
        doctest.testmod(extraglobs=ctx)

# Generated at 2022-06-22 21:10:31.544353
# Unit test for function retry
def test_retry():
    retry_count = 0
    @retry(retries=3, retry_pause=1)
    def retrytest(*args, **kwargs):
        global retry_count
        retry_count += 1
        return None
    retrytest()
    assert retry_count == 3

# TODO: test retry_with_backoff

# Generated at 2022-06-22 21:10:38.362846
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert retry_spec['retries']['type'] == 'int'
    assert retry_spec['retry_pause']['type'] == 'float'
    assert retry_spec['retry_pause']['default'] == 1

    retry_spec = retry_argument_spec(dict(test_param=dict(type='int', default=5)))
    assert retry_spec['test_param']['type'] == 'int'
    assert retry_spec['test_param']['default'] == 5

# Generated at 2022-06-22 21:10:42.174208
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception) is False
    assert retry_never(ValueError) is False


# Generated at 2022-06-22 21:10:47.237586
# Unit test for function rate_limit
def test_rate_limit():
    calls = 0

    @rate_limit(rate=60, rate_limit=60)
    def increment():
        global calls
        calls += 1

    start = time.time()
    for _ in range(100):
        increment()
    end = time.time()
    assert calls >= 40 and calls <= 80



# Generated at 2022-06-22 21:10:52.306532
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    # basic test
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}

    # test with custom spec
    assert rate_limit_argument_spec({'rate': {'type': 'str'}}) == {'rate': {'type': 'str'}, 'rate_limit': {'type': 'int'}}



# Generated at 2022-06-22 21:10:54.246835
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(('foo', 'bar')) is False
    assert retry_never(Exception()) is False


# Generated at 2022-06-22 21:10:57.355776
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(False)
    assert not retry_never(None)
    assert not retry_never(Exception)
    assert not retry_never(Exception("This is a test exception"))


# Generated at 2022-06-22 21:10:59.627696
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) is False
    assert retry_never(12) is False

# Unit tests for function generate_jittered_backoff

# Generated at 2022-06-22 21:11:05.123966
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        test_arg=dict(type='int')
    )
    correct_result = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        test_arg=dict(type='int')
    )
    assert spec == correct_result


# Generated at 2022-06-22 21:11:11.569472
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # This is not a real unit test. It just displays the result of the decorator
    # and asserts on the result of execution.

    try:
        # Decorator function
        @retry_with_delays_and_condition(generate_jittered_backoff(retries=10))
        def f():
            print("Running function f")
            return "success"

        # Call function
        print("Calling function f")
        f()

    except Exception:
        assert False, "Test failed"

# Generated at 2022-06-22 21:11:17.659618
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def always_retry_error(e):
        return True

    def never_retry_error(e):
        return False

    def fail_then_succeed():
        fail_then_succeed.calls += 1
        if fail_then_succeed.calls == 1:
            raise RuntimeError('fail_then_succeed')
        return True

    fail_then_succeed.calls = 0

    def fail_more_than_retries():
        fail_more_than_retries.calls += 1
        raise RuntimeError

    fail_more_than_retries.calls = 0

    def no_errors():
        return True


# Generated at 2022-06-22 21:11:24.861111
# Unit test for function retry
def test_retry():
    """Tests retry decorator"""
    ret = [0]

    @retry(retries=4, retry_pause=1)
    def test_retry():
        ret[0] += 1
        return False

    test_retry()
    assert ret[0] == 5, 'retries not working as expected %s != 5' % ret[0]

    ret[0] = 0

    @retry(retries=4, retry_pause=1)
    def test_retry():
        ret[0] += 1
        return True

    test_retry()
    assert ret[0] == 1, 'retries not working as expected %s != 1' % ret[0]

    ret[0] = 0


# Generated at 2022-06-22 21:11:25.994366
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)

# Generated at 2022-06-22 21:11:31.988494
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec(spec=dict(
        foo=dict(type='str'),
    ))
    expected = (dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        foo=dict(type='str'),
    ))
    assert expected == spec

# Generated at 2022-06-22 21:11:41.611043
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import logging

    class MockRequests(object):
        def __init__(self):
            self.requests_count = 0
            self.delay_count = 0
            self.expected_delay_count = [0, 1, 2, 3, 4, 5]
            self.expected_exponential_delays = [0, 3, 6, 12, 24, 48]
            self.logger = logging.getLogger(__name__)

        def request(self, *_, **__):
            self.requests_count += 1
            self.logger.warning("Request count: %s", self.requests_count)
            if self.requests_count >= 2 and self.requests_count <= 5:
                raise Exception("Intended exception")

# Generated at 2022-06-22 21:11:51.249748
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Construct iterable of delays
    delays = generate_jittered_backoff()

    # Create a function that succeeds after two calls
    function_attempt = [0]
    def function():
        function_attempt[0] += 1
        if function_attempt[0] < 3:
            # First two calls should fail with IOError
            raise IOError('Some error')
        else:
            return True

    # Wrap the function with retry decorator
    decorated_function = retry_with_delays_and_condition(delays)(function)

    # Call the decorated function
    assert(decorated_function() == True)
    assert(function_attempt[0] == 3)

# Generated at 2022-06-22 21:11:55.993295
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module_args = {
        'rate': 1,
        'rate_limit': 100
    }
    rate_limit_arg_spec = rate_limit_argument_spec()
    for arg in rate_limit_arg_spec:
        assert arg in module_args, ("module_args %s has no %s arg" % (module_args, arg))


# Generated at 2022-06-22 21:12:05.480037
# Unit test for function retry
def test_retry():
    import unittest
    import math

    class TestRetry(unittest.TestCase):
        def test_retry(self):
            @retry()
            def retry_me():
                return None

            with self.assertRaises(Exception):
                retry_me()

            # does not throw
            @retry(retries=0)
            def retry_me():
                return None

            @retry(retry_pause=0)  # faster than the sleep
            def retry_me():
                for retry_count in range(0, 10):
                    if retry_count == 5:
                        return retry_count
                    time.sleep(0.01)

            self.assertEqual(retry_me(), 5)


# Generated at 2022-06-22 21:12:13.109531
# Unit test for function rate_limit
def test_rate_limit():
    import datetime

    # import pdb;pdb.set_trace()
    @rate_limit(rate=100, rate_limit=1000000000)
    def api_call():
        return datetime.datetime.now()

    start = datetime.datetime.now()
    for x in range(0, 101):
        api_call()
    end = datetime.datetime.now()

    # make sure it took at least 1 second to run
    assert (end - start).total_seconds() > 1.0



# Generated at 2022-06-22 21:12:19.965974
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert retry_spec['retries']['type'] == 'int'
    assert retry_spec['retry_pause']['type'] == 'float'
    assert retry_spec['retry_pause']['default'] == 1

    passed_spec = dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    retry_spec = retry_argument_spec(spec=passed_spec)

    assert retry_spec['retries']['type'] == 'int'
    assert retry_spec['retry_pause']['type'] == 'float'
    assert retry_spec['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:12:23.333623
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}

# Generated at 2022-06-22 21:12:29.196102
# Unit test for function retry_never
def test_retry_never():
    # returns False for Exceptions
    assert retry_never(Exception) is False
    # returns False for None
    assert retry_never(None) is False
    # returns False for False
    assert retry_never(False) is False
    # returns False for True
    assert retry_never(True) is False



# Generated at 2022-06-22 21:12:32.230242
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        assert delay >= 0
        assert delay <= 60
        print(delay)

# Generated at 2022-06-22 21:12:42.310365
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Unit test for the function retry_argument_spec"""
    arg_spec = retry_argument_spec()
    spec_keys = set(arg_spec.keys())
    expected_keys = {'retries', 'retry_pause'}
    if spec_keys != expected_keys:
        raise AssertionError("arg_spec keys should be {} but are {}".format(expected_keys, spec_keys))
    retries_spec = arg_spec['retries']
    retries_spec_keys = set(retries_spec.keys())
    if retries_spec_keys != {'type'}:
        raise AssertionError("retries_spec keys should be {{'type'}} but are {}".format(retries_spec_keys))
    if retries_spec['type'] != 'int':
        raise Assertion

# Generated at 2022-06-22 21:12:52.311762
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit()
    def never_gets_called():
        raise Exception('Never gets called')

    assert not hasattr(never_gets_called(), '__call__')

    @rate_limit(1, 1)
    def always_gets_called():
        return True

    assert always_gets_called()

    @rate_limit(2, 1)
    def always_gets_called_but_not_immediately():
        return True

    assert not hasattr(always_gets_called_but_not_immediately(), '__call__')
    time.sleep(1)
    assert always_gets_called_but_not_immediately()


# Generated at 2022-06-22 21:12:57.253162
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert isinstance(arg_spec, dict)
    arg_spec = rate_limit_argument_spec(spec=dict(test=dict(type='str', required=True)))
    assert isinstance(arg_spec, dict)
    assert 'test' in arg_spec


# Generated at 2022-06-22 21:13:03.420183
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    result = basic_auth_argument_spec()

    assert result['api_username']['type'] == 'str'
    assert result['api_password']['type'] == 'str'
    assert result['api_url']['type'] == 'str'
    assert result['validate_certs']['type'] == 'bool'
    assert result['validate_certs']['default'] == True

# Generated at 2022-06-22 21:13:07.041383
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    seq = generate_jittered_backoff()
    assert len([i for i in seq]) == 10
    assert all(i >= 0 for i in seq)
    assert True

# Generated at 2022-06-22 21:13:14.539028
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def should_retry_error(exception):
        return isinstance(exception, on_last_retry_error)

    class on_last_retry_error(Exception):
        pass

    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(retries=3, delay_base=1, delay_threshold=60),
        should_retry_error=should_retry_error
    )
    def function_with_backoff(arg):
        function_with_backoff.count += 1
        if not arg:
            raise on_last_retry_error()
    function_with_backoff.count = 0

    # test
    function_with_backoff(True)
    assert function_with_backoff.count == 1
    function

# Generated at 2022-06-22 21:13:18.153413
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert arg_spec['rate']['type'] == 'int'
    assert arg_spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-22 21:13:20.513470
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}


# Generated at 2022-06-22 21:13:26.707999
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    simple_spec = {'test': {'type': 'int'}}
    big_spec = {'test': {'type': 'int'}, 'test1': {'type': 'int'}, 'test2': {'type': 'int'}}

    arg_spec = retry_argument_spec()
    assert len(arg_spec) == 2, "simple spec failed"

    arg_spec = retry_argument_spec(simple_spec)
    assert len(arg_spec) == 4, "merging simple spec failed"

    arg_spec = retry_argument_spec(big_spec)
    assert len(arg_spec) == 5, "merging big spec failed"



# Generated at 2022-06-22 21:13:33.147131
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert isinstance(retry_argument_spec(), dict)
    assert 'retries' in retry_argument_spec()
    assert 'retry_pause' in retry_argument_spec()
    assert 'type' in retry_argument_spec()['retries']
    assert 'type' in retry_argument_spec()['retry_pause']


# Generated at 2022-06-22 21:13:34.388983
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('error') == False


# Generated at 2022-06-22 21:13:41.840262
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Test the generic retry decorator.
    The test function should be called exactly three times,
    once with no delay and two retries with exponential backoff jitter.
    """
    import collections
    import itertools

    class MockException(Exception):
        pass

    was_called = collections.defaultdict(bool)
    should_retry_error = collections.defaultdict(int)
    def mock_backoff_iterator():
        delay_base = 3
        delay_threshold = 60
        delay = delay_base
        while delay < delay_threshold:
            yield delay
            delay *= 2
            delay += 1
        yield delay_threshold

    should_retry_error[MockException] = True
    # The mock test function should be called exactly three times.

# Generated at 2022-06-22 21:13:46.856680
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # Test return type
    assert isinstance(retry_argument_spec(), dict)
    # Test empty input
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    # Test non-empty input
    assert retry_argument_spec(dict(a=dict(type='str'))) == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        a=dict(type='str')
    )

# Generated at 2022-06-22 21:13:50.297577
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=3, rate_limit=1)
    def rate_limit_test():
        for i in range(10):
            print('Tick {}'.format(i))

    rate_limit_test()

# Generated at 2022-06-22 21:13:53.780296
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    wanted_result = {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }
    result = rate_limit_argument_spec()
    assert result['rate'] == wanted_result['rate']
    assert result['rate_limit'] == wanted_result['rate_limit']

# Generated at 2022-06-22 21:14:03.929210
# Unit test for function rate_limit
def test_rate_limit():
    def test_function(x):
        return x
    rate_limit_func = rate_limit(3, 10)(test_function)
    # Test if the rate_limit works,
    # set the counter to 0 and test if the time difference is in our acceptable range
    start_time = time.time()
    for i in range(3):
        rate_limit_func(i)
    end_time = time.time()
    assert end_time - start_time >= 3

    # Test if the rate_limit raises an Exception if the rate is smaller than required
    with pytest.raises(Exception):
        rate_limit_func = rate_limit(1000, 2)(test_function)
        rate_limit_func(1)



# Generated at 2022-06-22 21:14:12.583284
# Unit test for function rate_limit
def test_rate_limit():
    # Test with the default rate limit of one call per second
    @rate_limit
    def foo():
        return True
    foo()
    time.sleep(2)
    foo()

    # Test with a custom rate limit of one call every two seconds
    @rate_limit(rate=1, rate_limit=2)
    def foo2():
        return True
    foo2()
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock
    last = real_time()
    foo2()
    current = real_time()
    if current - last < 2.0:
        return False
    return True



# Generated at 2022-06-22 21:14:16.564645
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert 'rate' in spec
    assert 'rate_limit' in spec

    spec = rate_limit_argument_spec(dict(foo='bar'))
    assert 'rate' in spec
    assert 'rate_limit' in spec
    assert 'foo' in spec


# Generated at 2022-06-22 21:14:24.418368
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import pytest, os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from plugins.modules.common import retry_argument_spec
    def test_function():
        return retry_argument_spec()
    def test_function_with_inputs():
        arg_spec = (dict(
            param_1=dict(type='str'),
            param_2=dict(type='bool'),
        ))
        return retry_argument_spec(spec=arg_spec)

    # Asserting output for function with argument_spec
    output = test_function_with_inputs()
    assert output['param_1'] == {'type': 'str'}
    assert output['param_2'] == {'type': 'bool'}

# Generated at 2022-06-22 21:14:26.658254
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module = basic_auth_argument_spec()
    if module == None:
        raise AssertionError()

# Generated at 2022-06-22 21:14:32.147513
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    argument_spec = basic_auth_argument_spec()
    assert argument_spec == {'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True},
                             'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}}



# Generated at 2022-06-22 21:14:33.743951
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_argument_spec(spec=None)


# Generated at 2022-06-22 21:14:42.461991
# Unit test for function retry_argument_spec
def test_retry_argument_spec():

    argument_spec = retry_argument_spec()
    assert(argument_spec == {'retries': {'type': 'int'},
                             'retry_pause': {'type': 'float', 'default': 1}
                            })

    spec = {'new_option': {'type': 'str'}}
    argument_spec = retry_argument_spec(spec)
    assert(argument_spec == {'retries': {'type': 'int'},
                             'retry_pause': {'type': 'float', 'default': 1},
                             'new_option': {'type': 'str'}
                            })


# Generated at 2022-06-22 21:14:47.462478
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(0) is False
    assert retry_never(Exception()) is False
    assert retry_never(ZeroDivisionError()) is False


# This is a unit test for generate_jittered_backoff.
# It prints a pattern of delays, but they are not completely
# deterministic, so we don't try to parse them, just give
# an idea of the pattern.

# Generated at 2022-06-22 21:14:51.015162
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [3, 9, 5, 14, 20, 61, 5]
    test_delays = [_ for _ in generate_jittered_backoff()]
    assert test_delays == delays
    return True


# Generated at 2022-06-22 21:14:54.514192
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {'api_username': {'type': 'str'},
                                          'api_password': {'type': 'str', 'no_log': True},
                                          'api_url': {'type': 'str'},
                                          'validate_certs': {'type': 'bool', 'default': True}}

# Generated at 2022-06-22 21:15:01.842557
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        foo=dict(type='str'),
        bar=dict(type=dict)
    )
    retry_spec = retry_argument_spec(spec)
    assert 'retries' in retry_spec
    assert retry_spec['retries']['type'] == 'int'
    assert 'retry_pause' in retry_spec
    assert retry_spec['retry_pause']['type'] == 'float'
    assert retry_spec['retry_pause']['default'] == 1
    assert 'foo' in retry_spec
    assert retry_spec['foo']['type'] == 'str'



# Generated at 2022-06-22 21:15:05.773556
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))

    assert retry_argument_spec() == arg_spec


# Generated at 2022-06-22 21:15:10.353808
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=1), should_retry_error=retry_never)
    def test_function():
        return 0

    class TestRetryWithDelaysAndCondition(unittest.TestCase):

        def test_should_not_retry(self):
            self.assertEqual(test_function(), 0)

    unittest.main()

# Generated at 2022-06-22 21:15:13.897107
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('this is never a Exception') == False
    assert retry_never(Exception) == False
    assert retry_never(Exception('')) == False
    assert retry_never(Exception('something')) == False


# Generated at 2022-06-22 21:15:25.236479
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retries']['default'] == '3'
    assert arg_spec['retry_pause']['type'] == 'float'
    assert arg_spec['retry_pause']['default'] == '1'
    assert arg_spec['retry_pause']['version_added'] == '2.9'
    spec = dict(arg1=dict(type='str', default='test'))
    arg_spec = retry_argument_spec(spec)
    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retries']['default'] == '3'
    assert arg_spec['retry_pause']['type']

# Generated at 2022-06-22 21:15:26.506409
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import collections
    from pprint import pprint

    tally = collections.Counter(generate_jittered_backoff(1000))
    pprint(dict(tally))


# Unit tests for function retry_with_delays_and_condition

# Generated at 2022-06-22 21:15:30.325131
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module_args = basic_auth_argument_spec()
    assert module_args['api_username']['type'] == 'str'
    assert module_args['api_password']['type'] == 'str'
    assert module_args['api_url']['type'] == 'str'
    assert module_args['validate_certs']['type'] == 'bool'
    assert module_args['validate_certs']['default'] == True

# Generated at 2022-06-22 21:15:33.957594
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    def wrapper(i):
        return i
    f = retry_with_delays_and_condition(generate_jittered_backoff(), wrapper)
    assert f(lambda x: 1) == 1
    assert f(lambda x: 0) == 0
    assert f(lambda x: 0) == 0

# Generated at 2022-06-22 21:15:36.622185
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff(retries=2, delay_base=10, delay_threshold=31):
        assert delay < 31

# Generated at 2022-06-22 21:15:46.248107
# Unit test for function retry
def test_retry():
    def foo(raise_an_exception=False, n=0):
        n += 1
        if n > 1:
            return n
        elif raise_an_exception:
            raise Exception('Retry error')
        else:
            return n

    run_foo = retry_with_delays_and_condition(generate_jittered_backoff(retries=5, delay_base=10, delay_threshold=60), should_retry_error=retry_never)(foo)
    assert run_foo() == 1  # Function with no exception and no delay
    assert run_foo(raise_an_exception=True) == 2  # Function with an exception and no delay
    assert run_foo() == 2  # Function with no exception and no delay
    assert run_foo(raise_an_exception=True)

# Generated at 2022-06-22 21:15:51.055716
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec()['retries'] == {'type': 'int'}
    assert retry_argument_spec()['retry_pause'] == {'type': 'float', 'default': 1}

if __name__ == '__main__':
    test_retry_argument_spec()

# Generated at 2022-06-22 21:15:54.701512
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """retry_argument_spec() unit test"""
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )

# Generated at 2022-06-22 21:15:57.624207
# Unit test for function retry_never
def test_retry_never():
    res = retry_never('test')
    assert res is False
    res = retry_never(Exception())
    assert res is False


# Generated at 2022-06-22 21:16:08.336959
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def raise_or_not(number_of_calls, check_number):
        """Raises an Exception every time the number_of_calls match the check_number, otherwise does nothing."""
        def raise_or_not_inner(x):
            if x == check_number:
                raise RuntimeError("raised on function call {0}".format(x))
            else:
                print("function run {0} times".format(x))
        return raise_or_not_inner

    print("\nTesting retry_with_delays_and_condition with a simple retry condition")

# Generated at 2022-06-22 21:16:09.337653
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False

# Generated at 2022-06-22 21:16:13.096045
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-22 21:16:14.554340
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    argspec = basic_auth_argument_spec(spec=None)
    assert argspec ==  None

# Generated at 2022-06-22 21:16:17.962611
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = (dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    ))
    assert basic_auth_argument_spec() == spec

# Generated at 2022-06-22 21:16:24.722599
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(foo=dict(type='int'), bar=dict(type='float', default=1))
    result = dict(retries=dict(type='int'), retry_pause=dict(type='float', default=1), foo=dict(type='int'), bar=dict(type='float', default=1))
    assert(retry_argument_spec(spec) == result)



# Generated at 2022-06-22 21:16:36.339151
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    def should_retry_on_specific_exception(e):
        return "I am retryable" in str(e)

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=should_retry_on_specific_exception)
    def retryable_function(retry_count, exception_rate_increase=1):
        if retry_count >= 5 * exception_rate_increase:
            return "Success"
        else:
            raise Exception("I am retryable")

    # The following will be retried up to 5 times with jittered delays in between.
    # If we call with a retry_count higher than 5, the function will succeed.
    response = retryable_function(retry_count=5)


# Generated at 2022-06-22 21:16:47.117234
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    test_dict_1 = {'one': '1'}
    test_dict_2 = {'two': '2'}

    assert basic_auth_argument_spec(test_dict_1) == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        one='1',
    )

# Generated at 2022-06-22 21:16:54.350875
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def test_function():
        return True

    test_function()

    # Test that retries work, and that the jitter backoff works
    call_count = 0
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def test_function():
        nonlocal call_count
        call_count += 1
        if call_count == 2:
            return True

    test_function()
    assert call_count == 2



# Generated at 2022-06-22 21:17:05.348691
# Unit test for function retry
def test_retry():
    from ansible.module_utils.basic import AnsibleModule

    class Foo(object):
        def __init__(self):
            self.attempt = [0]

        def bar(self, module):
            if self.attempt[0] == 2:
                return True
            self.attempt[0] += 1
            module.fail_json(msg="I'm retrying")

    f = Foo()

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3, delay_threshold=1))
    def call_method(module, function):
        function(module)

    module = AnsibleModule(argument_spec=dict())

    call_method(module, f.bar)



# Generated at 2022-06-22 21:17:15.548753
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Tests the generic retry decorator.

    The function that gets run after being wrapped is expected to throw an exception.
    """
    @retry_with_delays_and_condition(iter([]))
    def retry_never_function():
        raise Exception("This exception should never be retried")

    try:
        retry_never_function()
        assert False
    except Exception as e:
        assert str(e) == "This exception should never be retried"

    @retry_with_delays_and_condition(iter([3, 6]), should_retry_error=retry_never)
    def retry_always_function():
        raise Exception("This exception should be retried twice")


# Generated at 2022-06-22 21:17:20.462020
# Unit test for function retry_never
def test_retry_never():
    @retry_with_delays_and_condition(range(0,10), should_retry_error=retry_never)
    def fail_function():
        raise Exception("Test exception")

    with pytest.raises(Exception, match='Test exception'):
        fail_function()



# Generated at 2022-06-22 21:17:28.281289
# Unit test for function rate_limit
def test_rate_limit():
    """ verify rate limit works with function calls """
    # pylint: disable=unused-variable,missing-docstring
    @rate_limit(rate=10, rate_limit=60)
    def test_rate_limited_function(*args, **kwargs):
        """ just returns time.time() """
        return time.time()

    # pylint: disable=unused-variable
    @rate_limit()
    def test_function(*args, **kwargs):
        """ just returns time.time() """
        return time.time()

    start = test_function()
    end = test_function()
    # without rate limit, function should return almost equal times
    assert (end - start) < 0.00001

    start = test_rate_limited_function()
    end = test_rate_limited_function()
    # with

# Generated at 2022-06-22 21:17:38.389880
# Unit test for function retry_never
def test_retry_never():
    f = retry_with_delays_and_condition(generate_jittered_backoff(0))
    @f
    def test(a, b, c=1):
        if c == 1:
            raise ValueError("naturally expected")
        return a + b

    try:
        test(1, 1, c=1)
    except ValueError:
        pass
    else:
        raise AssertionError("retry_never should fail")

    try:
        test(1, 1)
    except ValueError:
        raise AssertionError("retry_never should succeed")
    except:
        raise AssertionError("retry_never should succeed")
    else:
        pass


# Generated at 2022-06-22 21:17:42.076813
# Unit test for function retry_never
def test_retry_never():
    class ResultException(Exception):
        pass

    class SomeOtherException(Exception):
        pass

    assert retry_never(None) is False
    assert retry_never(ResultException("foo")) is False





# Generated at 2022-06-22 21:17:52.673023
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

    new_spec = retry_argument_spec(spec)

    expected_spec = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )

    assert new_spec == expected_spec

# Generated at 2022-06-22 21:17:59.002913
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        arg1=dict(type='int'),
        arg2=dict(type='int')
    )
    merged_spec = retry_argument_spec(spec)
    assert 'retries' in merged_spec
    assert 'retry_pause' in merged_spec
    assert 'arg1' in merged_spec
    assert 'arg2' in merged_spec

# Generated at 2022-06-22 21:18:06.023581
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module = basic_auth_argument_spec()
    assert module['api_username'] == {'type': 'str'}
    assert module['api_password'] == {'type': 'str', 'no_log': True}
    assert module['api_url'] == {'type': 'str'}
    assert module['validate_certs'] == {'type': 'bool', 'default': True}

# Generated at 2022-06-22 21:18:09.692689
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert 'rate' in arg_spec
    assert 'rate_limit' in arg_spec

    arg_spec = rate_limit_argument_spec(spec={ 'test': 'test'})
    assert arg_spec['test'] == 'test'



# Generated at 2022-06-22 21:18:15.943635
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec({'a': 1}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}, 'a': 1}

# Generated at 2022-06-22 21:18:20.944004
# Unit test for function retry
def test_retry():
    @retry(3)
    def test_function(counter, multiplier=1):
        count = counter[0]
        counter[0] += 1
        time.sleep(random.randint(1,3))
        raise Exception(count * multiplier)

    counter = [0]

# Generated at 2022-06-22 21:18:26.145948
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    number_of_retries = 10
    delay_base = 1
    delay_threshold = 10

    @retry_with_delays_and_condition(generate_jittered_backoff(number_of_retries, delay_base, delay_threshold))
    def retry_with_backoff():
        return True

    assert retry_with_backoff()


# Generated at 2022-06-22 21:18:32.886055
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():

    expected = {'api_password': {'type': 'str', 'no_log': True},
                'api_url': {'type': 'str'},
                'validate_certs': {'type': 'bool', 'default': True},
                'api_username': {'type': 'str'}}

    result = basic_auth_argument_spec()
    assert result == expected


# Generated at 2022-06-22 21:18:39.750228
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """basic_auth_argument_spec"""
    arg_spec = basic_auth_argument_spec()
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec



# Generated at 2022-06-22 21:18:43.425381
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff()
    backoffs = [next(backoff_iterator) for _ in range(1, 11)]
    assert backoffs == [0, 1, 3, 3, 7, 5, 15, 11, 27, 19]


# Generated at 2022-06-22 21:18:45.724423
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result == dict(rate=dict(type='int'), rate_limit=dict(type='int'))



# Generated at 2022-06-22 21:18:52.107855
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff(retries=3):
        assert(delay <= (3 * 2 ** 2))
    for delay in generate_jittered_backoff(retries=3, delay_threshold=5):
        assert(delay <= 5)
    for delay in generate_jittered_backoff(retries=3, delay_base=1, delay_threshold=10):
        assert(delay <= 10)

# Generated at 2022-06-22 21:19:00.305514
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit() function.

    We're testing the function by checking that the delay between
    function calls is more or less what it's supposed to be. Our
    result tolerance is of 10% of the expected delay.
    """
    rate = 2
    rate_limit = 10
    delay_expected = 5
    delay_tolerance = 0.5

    @rate_limit(rate=rate, rate_limit=rate_limit)
    def fake_workload(id):
        """Fake workload.

        :param id: The id of the workload.
        """
        time.sleep(0)
        return id

    before = time.time()
    for i in range(0, rate):
        fake_workload(i)
    after = time.time()
    delay_actual = after - before

    assert delay_expected - delay_

# Generated at 2022-06-22 21:19:08.876234
# Unit test for function rate_limit
def test_rate_limit():
    #import time
    #import random
    import unittest

    class RateLimitTestCase(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.test = False

        def setUp(self):
            self.test = True

        def tearDown(self):
            self.test = False

        def test_rate_limit(self, rate_limit=None, rate=None):
            if not self.test:
                raise Exception("setUp() not called")

            @rate_limit(rate_limit=rate_limit, rate=rate)
            def foo():
                time.sleep(0.01)
                return True


# Generated at 2022-06-22 21:19:18.713629
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=0)
    def test_retry(fail_count, return_ok):
        if fail_count > 0:
            fail_count -= 1
            raise Exception("Test retry")
        return return_ok

    assert test_retry(fail_count=1, return_ok=True) is True
    assert test_retry(fail_count=0, return_ok=True) is True
    assert test_retry(fail_count=3, return_ok=True) is True
    try:
        test_retry(fail_count=3, return_ok=False)
    except Exception as e:
        assert str(e) == 'Test retry'



# Generated at 2022-06-22 21:19:22.560440
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=1)
    def foo():
        return 1
    assert foo() == 1
    assert foo() == 1
    assert foo() == 1
    assert foo() == 1
    assert foo() == 1
    assert foo() == 1



# Generated at 2022-06-22 21:19:32.307606
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    times_called = 0
    times_retried = []
    times_should_retry_called = []

    class RetriableError(Exception):
        pass

    def broken_function(retry_count):
        """Will fail the first time it is called, succeed thereafter."""
        nonlocal times_called
        times_called += 1
        if times_called == 1:
            raise RetriableError("first call failed")
        else:
            return "success"

    def should_retry_error(e):
        nonlocal times_should_retry_called
        times_should_retry_called.append(e)
        return isinstance(e, RetriableError)


# Generated at 2022-06-22 21:19:39.850659
# Unit test for function rate_limit
def test_rate_limit():
    import time

    def time_sleep(t):
        time.sleep(t)
        return True

    time_sleep_rate_limited = rate_limit(rate=1, rate_limit=1)(time_sleep)

    # Measure the non rate limited execution of time_sleep_rate_limited
    t0 = time.time()
    time_sleep_rate_limited(2)
    t1 = time.time()
    assert(t1 - t0 >= 2)

    # Measure the rate limited execution of time_sleep_rate_limited
    t0 = time.time()
    time_sleep_rate_limited(2)
    t1 = time.time()
    assert(t1 - t0 >= 1)

    # Measure the rate limited execution of time_sleep_rate_limited
    t0 = time.time()
    time_sleep