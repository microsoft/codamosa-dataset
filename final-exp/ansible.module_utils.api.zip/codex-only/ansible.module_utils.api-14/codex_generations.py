

# Generated at 2022-06-22 21:09:37.649747
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec['api_url']['type'] == 'str'



# Generated at 2022-06-22 21:09:40.786287
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    ))
    assert rate_limit_argument_spec() == arg_spec


# Generated at 2022-06-22 21:09:49.683445
# Unit test for function retry
def test_retry():
    class TestException(Exception):
        def __init__(self, do_retry):
            self.do_retry = do_retry
            super(TestException, self).__init__('{}'.format(do_retry))

    def should_retry_error(exception):
        return isinstance(exception, TestException) and exception.do_retry

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=5, delay_base=1, delay_threshold=1),
                                     should_retry_error)
    def my_function():
        raise TestException(do_retry)

    with pytest.raises(TestException):
        my_function()

# Generated at 2022-06-22 21:09:54.150357
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=30, delay_threshold=60)
    for delay in backoff_iterator:
        print(delay)


if __name__ == "__main__":
    test_generate_jittered_backoff()

# Generated at 2022-06-22 21:10:05.436073
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(1, 1)
    def test_function():
        return time.time()

    last_invocation_time = None
    for i in range(1, 6):
        this_invocation_time = test_function()
        if last_invocation_time:
            next_invocation_time = last_invocation_time + 1
            if this_invocation_time < next_invocation_time:
                print("test_rate_limit: test failed")
                return false
            print("test_rate_limit: okay on iteraton %d, last_invocation_time=%f, this_invocation_time=%f, next_invocation_time=%f" % (i, last_invocation_time, this_invocation_time, next_invocation_time))

# Generated at 2022-06-22 21:10:09.685976
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=1))
    def test_retry_method():
        print("retry test method")
    test_retry_method()
    return

# Generated at 2022-06-22 21:10:13.506055
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    assert list(delays) == [0, 5, 4, 3, 47, 5, 22, 17, 56, 5]

# Generated at 2022-06-22 21:10:14.465027
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    pass


# Generated at 2022-06-22 21:10:15.457277
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)

# Generated at 2022-06-22 21:10:24.558946
# Unit test for function rate_limit
def test_rate_limit():
    # If no rate/rate_limit specified always return true
    @rate_limit()
    def true_func():
        return True

    # If rate/rate_limit not specified always return true
    assert true_func()

    # If rate/rate_limit specified, return true only once
    @rate_limit(rate=1, rate_limit=1)
    def true_func():
        return True

    # This should return true.
    assert true_func()

    # This should return false.
    assert not true_func()

    # This should return false.
    assert not true_func()

# Generated at 2022-06-22 21:10:26.124526
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) is False
    assert retry_never(None) is False

# Generated at 2022-06-22 21:10:29.410365
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    result = retry_argument_spec()
    assert result
    assert len(result) == 2
    assert 'retries' in result
    assert 'retry_pause' in result


# Generated at 2022-06-22 21:10:39.893374
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Unit test for function retry_with_delays_and_condition.
    We create a mock class and a mock function which will throw exceptions.
    The mock function is wrapped with the retry decorator.
    We will then test if the wrapped function returns the correct results and if exceptions get raised at the right moment.
    """
    class MyException(Exception):
        pass
    class MyOtherException(Exception):
        pass

    class MockResult:
        def __init__(self, result, counter=0):
            self.result = result
            self.counter = counter

    class MockClass:
        def __init__(self, result, exception=None, exception_delay=None, exception_counter=None):
            self.counter = 0

# Generated at 2022-06-22 21:10:41.999759
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert list(generate_jittered_backoff()) == [
        3, 0, 6, 0, 12, 0, 24, 0, 48, 0
    ]

# Generated at 2022-06-22 21:10:45.545086
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:10:53.948953
# Unit test for function rate_limit
def test_rate_limit():
    last = [0.0]
    real_time = time.clock

    def testfunc(rate, rate_limit):
        elapsed = real_time() - last[0]
        left = minrate - elapsed
        if left > 0:
            time.sleep(left)
        last[0] = real_time()

    rate = 10
    rate_limit = 60
    minrate = float(rate_limit) / float(rate)
    rate_limited = rate_limit(rate=rate, rate_limit=rate_limit)(testfunc)

    for i in range(10):
        print(i)
        rate_limited(rate, rate_limit)

# Generated at 2022-06-22 21:10:56.726922
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception("foo")) is False
    assert retry_never(1) is False


# Generated at 2022-06-22 21:11:05.019111
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Simple spot check with no jitter
    backoff_result = [i for i in generate_jittered_backoff(3, 1, 2)]
    assert backoff_result == [0, 1, 2]

    # Spot-check with jitter
    backoff_result = [i for i in generate_jittered_backoff(3, 1, 2)]
    for i in backoff_result:
        assert i >= 0
        assert i <= 2

    # Spot check jitter-threshold
    backoff_result = [i for i in generate_jittered_backoff(5, 2, 4)]
    for i in backoff_result:
        assert i >= 0
        assert i <= 4

# Generated at 2022-06-22 21:11:07.988998
# Unit test for function retry
def test_retry():
    counter = [0]

    @retry()
    def foo():
        counter[0] += 1
        return counter[0]

    print(foo())
    print(foo())
    print(counter)

# Generated at 2022-06-22 21:11:16.619553
# Unit test for function retry
def test_retry():

    @retry(retries=3, retry_pause=2)
    def test_retry_count(*args, **kwargs):
        print("test_retry_count was called with {} {}".format(args, kwargs))
        test_retry_count.retry_count += 1
        if test_retry_count.retry_count <= 2:
            return False
        else:
            return True

    test_retry_count.retry_count = 0
    if not test_retry_count(1, 2, 3):
        raise Exception("wrong behavior")

    if test_retry_count.retry_count != 3:
        raise Exception("wrong behavior")



# Generated at 2022-06-22 21:11:21.745565
# Unit test for function retry
def test_retry():
    """Unit tests for function retry"""
    counter = dict(count=0)

    @retry(retries=3, retry_pause=0)
    def func(counter):
        counter['count'] += 1
        raise Exception('retry')

    assert counter['count'] == 0
    try:
        func(counter)
    except Exception:
        pass
    assert counter['count'] == 4



# Generated at 2022-06-22 21:11:26.923679
# Unit test for function retry_never
def test_retry_never():
    class DummyException(Exception):
        pass

    def test_function(test_success=None):
        if not test_success:
            raise DummyException()

    retry_count = 0
    test_retry_never = retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=retry_never)
    test_function = test_retry_never(test_function)

    max_retries = 10
    while retry_count < max_retries:
        retry_count += 1
        try:
            test_success = False
            test_function(test_success)
        except Exception:
            test_success = True
            test_function(test_success)


# Generated at 2022-06-22 21:11:28.042554
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec is not None

# Generated at 2022-06-22 21:11:30.381010
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(ValueError) is False
    assert retry_never(Exception) is False
    assert retry_never(AttributeError) is False



# Generated at 2022-06-22 21:11:36.920564
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_threshold = 60
    for i in range(0, 10):
        delay_base = i + 1  # in range [1, 10]
        backoff_iterator = generate_jittered_backoff(retries=10, delay_base=delay_base,
                                                     delay_threshold=delay_threshold)
        for delay in backoff_iterator:
            assert delay < delay_threshold
            assert delay >= 0

# Generated at 2022-06-22 21:11:43.167854
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit"""
    argspec = rate_limit_argument_spec()
    module_args = dict(
        rate=2,
        rate_limit=2,
    )

    # Set up the module
    module = AnsibleModule(
        argument_spec=argspec,
        supports_check_mode=True,
    )

    # Run it
    @rate_limit(**module_args)
    def test_rate_limit_function():
        return True

    result = test_rate_limit_function()

    # Verify results
    assert result



# Generated at 2022-06-22 21:11:54.585861
# Unit test for function rate_limit
def test_rate_limit():

    class MockTime(object):
        def __init__(self):
            self.call_count = 0
            self.sleep_count = 0
            self.last_process_time = 0
            self.last_clock = 0

        def sleep(self, value):
            self.sleep_count += 1

        def process_time(self):
            self.call_count += 1
            self.last_process_time += random.randint(1, 10)
            return self.last_process_time

        def clock(self):
            self.call_count += 1
            self.last_clock += random.randint(1, 10)
            return self.last_clock

    # Test process_time
    mock_time = MockTime()
    test_count = 100
    time.process_time = mock_time.process_time


# Generated at 2022-06-22 21:12:05.040025
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Prepare data
    class ServerSideError(Exception):
        pass

    class NetworkError(Exception):
        pass

    my_backoff_iterator = iter([3, 15, 45, 45, 45])
    def should_retry_error(e):
        return isinstance(e, NetworkError)

    # Define function to test
    @retry_with_delays_and_condition(my_backoff_iterator, should_retry_error)
    def retryable_foo(param):
        if param == 0:
            raise ServerSideError("Server did not like your request")
        elif param == 1:
            raise NetworkError("Network did not like your request")
        return param

    # Test cases
    # 1. Retry should not happen, as we get another error

# Generated at 2022-06-22 21:12:10.026851
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    number_of_delays = 10
    delay_iterator = generate_jittered_backoff(retries=number_of_delays)
    delays = [delay for delay in delay_iterator]

    assert len(delays) == number_of_delays
    assert all(delay <= 60 for delay in delays)

# Generated at 2022-06-22 21:12:14.833300
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(2, 8)
    def test():
        return True

    count = 0
    start = time.time()
    while True:
        if test():
            count += 1
        elapsed = time.time() - start
        if elapsed >= 7:
            assert count == 2
            assert  elapsed < 10
            return
        if elapsed >= 8:
            raise Exception("failed rate limit test")


# Generated at 2022-06-22 21:12:20.992934
# Unit test for function rate_limit
def test_rate_limit():
    """Return the time in seconds for the decorated function to run with the given rate limit parameters"""
    @rate_limit(rate=2)
    def printit(*args, **kwargs):
        print(*args, **kwargs)

    start = time.time()
    printit('a')
    printit('b')
    printit('c')
    printit('d')
    printit('e')
    duration = time.time() - start
    return duration


# Generated at 2022-06-22 21:12:23.038469
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}



# Generated at 2022-06-22 21:12:25.080231
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=0.1)
    def myfunction():
        return 1
    try:
        myfunction()
        assert False
    except Exception:
        assert True

# Generated at 2022-06-22 21:12:29.841352
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    result = retry_argument_spec()
    assert 'retries' in result
    assert 'retry_pause' in result
    other_spec = dict(foo='bar')
    result = retry_argument_spec(other_spec)
    assert 'retries' in result
    assert 'retry_pause' in result
    assert 'foo' in result

# Generated at 2022-06-22 21:12:34.859711
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec(dict(last_name=dict(type='str'))) == {
        'last_name': {'type': 'str'}, 'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}
    }

# Generated at 2022-06-22 21:12:38.885697
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retry_pause']['type'] == 'float'
    assert arg_spec['retry_pause']['default'] == 1


# Generated at 2022-06-22 21:12:44.198500
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    test_arg_spec = rate_limit_argument_spec()
    assert('rate' in test_arg_spec)
    test_arg_spec = rate_limit_argument_spec(dict(test_arg=dict(type='int')))
    assert('rate' in test_arg_spec)
    assert('test_arg' in test_arg_spec)



# Generated at 2022-06-22 21:12:45.792598
# Unit test for function retry_never
def test_retry_never():
    assert False == retry_never(Exception())


# Generated at 2022-06-22 21:12:51.142156
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec(dict(a=dict(type='int')))
    assert spec.get('rate'), 'rate is missing from argument spec'
    assert spec.get('rate_limit'), 'rate_limit is missing from argument spec'
    assert spec.get('a'), 'a is missing from argument spec'



# Generated at 2022-06-22 21:12:57.996039
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Unit test for function retry_with_delays_and_condition."""
    import pytest
    import itertools

    # Suite 1: unretryable exception
    backoff_iterator = [True, False]
    should_retry_error = retry_never

    wrapped_function = retry_with_delays_and_condition(backoff_iterator, should_retry_error)(lambda: 5)
    assert wrapped_function() == 5

    # Suite 2: retryable error
    backoff_iterator = [True, True, False]
    should_retry_error = lambda x: True

    sum = 0
    wrapped_function = retry_with_delays_and_condition(backoff_iterator, should_retry_error)(lambda: sum + 1)
    assert wrapped_function() == 2

    #

# Generated at 2022-06-22 21:13:03.170466
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """
    Generate the list of delays and make sure that the last delay is less
    than the delay threshold.
    """
    threshold = 60
    delays = [delay for delay in generate_jittered_backoff(retries=10, delay_threshold=threshold)]
    assert delays[-1] < delay_threshold


# Generated at 2022-06-22 21:13:08.726945
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=retry_argument_spec(
            dict(sample_argument=dict(type='int'))
        ),
        supports_check_mode=True
    )

    params = test_module.params

    test_module.exit_json(**params)

# Generated at 2022-06-22 21:13:15.202523
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(5, 2))
    def fail_twice_then_succeed(number_of_failures):
        if number_of_failures > 0:
            number_of_failures -= 1
            raise ValueError("Fail")
        return "Success"

    result = fail_twice_then_succeed(2)
    assert result == "Success", "Function should return Success!"

    result = fail_twice_then_succeed(3)
    assert result == "Success", "Function should return Success!"

    with pytest.raises(ValueError):
        fail_twice_then_succeed(4)



# Generated at 2022-06-22 21:13:18.962378
# Unit test for function rate_limit
def test_rate_limit():
    import unit_test_utils
    import time

    class RateLimitedClass(object):
        @rate_limit(4, 60)
        def do_stuff(self):
            return time.time()

    test_class = RateLimitedClass()

    start = time.time()
    time_list = [test_class.do_stuff() for x in range(0, 4)]
    time_delta = time_list[-1] - start
    unit_test_utils.assertAlmostEqual(time_delta, 15, 1)



# Generated at 2022-06-22 21:13:26.634091
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import load_platform_subclass
    from ansible.module_utils._text import to_text
    sys.modules['ansible'] = type('ansible_stub', (), {})
    module = load_platform_subclass('module', platform='testhost', subplatform='testhost')
    mymodule = AnsibleModule(
        argument_spec=basic_auth_argument_spec(),
        supports_check_mode=True,
    )
    with pytest.raises(SystemExit) as ex:
        mymodule.fail_json(msg="Test message")
    assert to_text(ex.value) == "0"
    assert "api_username" in mymodule.params

# Generated at 2022-06-22 21:13:32.049335
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_list = list(generate_jittered_backoff())
    assert len(backoff_list) == 10
    assert backoff_list[0] <= 3
    assert backoff_list[9] <= 60



# Generated at 2022-06-22 21:13:40.545494
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def try_thrice():
        if try_thrice.failures < try_thrice.total:
            try_thrice.failures += 1
            raise ValueError(try_thrice.failures)
        return try_thrice.failures
    try_thrice.failures = 0
    try_thrice.total = 3
    assert try_thrice() == 3

    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def fail_and_succeed():
        fail_and_succeed.failures += 1

# Generated at 2022-06-22 21:13:51.262578
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    input1 = generate_jittered_backoff()
    assert list(input1) == [0, 0, 1, 2, 4, 8, 16, 32, 48, 60], \
        "Jittered backoff algorithm failed. Expected: %r, Got: %r" % ([0, 0, 1, 2, 4, 8, 16, 32, 48, 60], list(input1))

    input2 = generate_jittered_backoff(retries=100, delay_base=1, delay_threshold=10)
    assert list(input2)[0:5] == [0, 0, 0, 1, 1], \
        "Jittered backoff algorithm failed. Expected: %r, Got: %r" % ([0, 0, 0, 1, 1], list(input2)[0:5])

    input3 = generate_jittered_

# Generated at 2022-06-22 21:13:55.413059
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(False) == False
    assert retry_never('a string') == False


# Unit test generate_jittered_backoff

# Generated at 2022-06-22 21:13:58.316984
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int')
    )
    assert rate_limit_argument_spec() == spec


# Generated at 2022-06-22 21:14:00.785182
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    args = rate_limit_argument_spec()
    assert args.get('rate')
    assert args.get('rate_limit')


# Generated at 2022-06-22 21:14:04.007757
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=1)
    def test():
        return True
    assert test()
    @retry(retries=5, retry_pause=1)
    def test():
        return False
    assert test() is None


# Generated at 2022-06-22 21:14:13.413605
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert isinstance(spec, dict)
    assert 'rate' in spec.keys()
    assert 'rate_limit' in spec.keys()
    assert isinstance(spec['rate'], dict)
    assert 'type' in spec['rate'].keys()
    assert spec['rate']['type'] == 'int'
    assert isinstance(spec['rate_limit'], dict)
    assert 'type' in spec['rate_limit'].keys()
    assert spec['rate_limit']['type'] == 'int'

    spec = rate_limit_argument_spec(dict(foo=dict(type='str')))
    assert isinstance(spec, dict)
    assert 'rate' in spec.keys()
    assert 'rate_limit' in spec.keys()

# Generated at 2022-06-22 21:14:21.699492
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    args = [
        {'retries': 10, 'delay_base': 3, 'delay_threshold': 60},
        {'retries': 20, 'delay_base': 5, 'delay_threshold': 200},
        {'retries': 30, 'delay_base': 20, 'delay_threshold': 200},
        {'retries': 30, 'delay_base': 20, 'delay_threshold': 300},
        {'retries': 30, 'delay_base': 20, 'delay_threshold': 2000},
    ]
    for arg in args:
        sum = 0
        for value in generate_jittered_backoff(**arg):
            sum += value
        assert sum <= arg['delay_threshold'] * (2 ** arg['retries'] - 1)

# Generated at 2022-06-22 21:14:25.315288
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    assert module.params['api_username'] is None
    assert module.params['api_password'] is None
    assert module.params['api_url'] is None
    assert module.params['validate_certs'] is True



# Generated at 2022-06-22 21:14:36.273232
# Unit test for function retry
def test_retry():
    runs = []

    @retry(retries=3)
    def foo():
        runs.append(1)
        return None

    foo()
    assert runs == [1, 1, 1]

    runs = []
    @retry(retries=3)
    def foo():
        runs.append(1)
        return True

    foo()
    assert runs == [1]

    runs = []
    @retry(retries=3)
    def foo():
        runs.append(1)
        return True
        time.sleep(1)

    foo()
    assert runs == [1]

    runs = []
    @retry(retries=5, retry_pause=1)
    def foo():
        runs.append(1)
        return True

    foo()
    assert runs == [1]



# Generated at 2022-06-22 21:14:44.545812
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=5, delay_base=2))
    def test_retry():
        print("test_retry")
        raise Exception("test_retry_exception")

    try:
        test_retry()
    except Exception as e:
        assert e.args[0] == "test_retry_exception"
    else:
        raise Exception("test_retry_with_delays_and_condition() failed")

test_retry_with_delays_and_condition()

# Generated at 2022-06-22 21:14:53.101577
# Unit test for function retry
def test_retry():
    def run_method(action):
        if action == 'fail':
            raise ValueError('testing')
        if action == 'pass':
            return action

    retry_3 = retry(3, 1)
    retry_never = retry(0, 1)

    print('Testing retry(3, 1)')
    result = retry_3(run_method)('fail')
    assert result is None
    print('Testing retry_never()')
    result = retry_never(run_method)('pass')
    assert result == 'pass'

# Generated at 2022-06-22 21:14:53.976137
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never("anything")

# Generated at 2022-06-22 21:14:57.379935
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(Exception()) == False
    assert retry_never(False) == False
    assert retry_never(True) == False


# Generated at 2022-06-22 21:15:06.522389
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=0.5)
    def retry_raise():
        raise Exception()

    with pytest.raises(Exception):
        retry_raise()

    @retry(retries=3, retry_pause=0.5)
    def retry_return():
        return "foo"

    assert retry_return() == "foo"

    @retry(retries=3, retry_pause=0.5)
    def retry_return_false():
        return False

    with pytest.raises(Exception):
        retry_return_false()

    retry_count = 0

    @retry(retries=2, retry_pause=0.5)
    def retry_return_false_count():
        nonlocal retry_count


# Generated at 2022-06-22 21:15:18.229024
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import json

    THIS_MODULE = sys.modules[__name__]
    if hasattr(THIS_MODULE, 'argument_spec'):
        delattr(THIS_MODULE, 'argument_spec')

    def _test_module(argument_spec):
        setattr(THIS_MODULE, 'argument_spec', argument_spec)

        from ansible_collections.misc.not_a_real_collection.plugins.module_utils.misc import module_common_argspec

        expected_spec = dict(
            argument_spec=argument_spec,
            supports_check_mode=False,
        )
        result = module_common_argspec()
        assert result == expected_spec


# Generated at 2022-06-22 21:15:28.440678
# Unit test for function retry
def test_retry():

    from ansible.module_utils.basic import AnsibleModule
    import ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.api as api

    module = AnsibleModule(
        argument_spec=retry_argument_spec(
            dict(arg1=dict(type='str', required=False),
                 arg2=dict(type='int', required=False),
                 )
        )
    )

    @api.retry(module.params['retries'], module.params['retry_pause'])
    def test_function(a1, a2):
        if a1 == 'fail':
            raise Exception('%s:%s' % (a1, a2))
        return (a1, a2)


# Generated at 2022-06-22 21:15:35.053018
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = dict(retries=dict(type='int'), retry_pause=dict(type='float'))
    basic_spec = dict(foo=dict(type='str'), bar=dict(type='str'))
    assert retry_argument_spec() == retry_spec
    assert retry_argument_spec(basic_spec) == dict(retries=dict(type='int'), retry_pause=dict(type='float'), foo=dict(type='str'), bar=dict(type='str'))

# Generated at 2022-06-22 21:15:39.450619
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert type(spec) == dict
    assert len(spec) == 2
    assert spec.get('retries') == dict(type='int')
    assert spec.get('retry_pause') == dict(type='float', default=1)


# Generated at 2022-06-22 21:15:49.113397
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }
    assert retry_argument_spec({}) == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }
    assert retry_argument_spec(dict(a=1, b=2)) == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
        'a': 1,
        'b': 2,
    }


# Generated at 2022-06-22 21:15:58.096433
# Unit test for function rate_limit
def test_rate_limit():
    import json
    import unittest

    number_of_calls = 0

    @rate_limit(rate=5, rate_limit=10)
    def ratelimited():
        global number_of_calls
        number_of_calls += 1
        return json.dumps(number_of_calls)

    @retry(retries=1)
    def retried():
        return json.dumps(number_of_calls)

    # This calls should be rate limited
    for call in range(20):
        ratelimited()

    # This should not be retried
    try:
        retried()
    except Exception as e:
        assert('Retry limit exceeded' in str(e))

    # This calls should be rate limited but with a total counter
    for call in range(20):
        ratelimited()



# Generated at 2022-06-22 21:15:59.714708
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False
    assert retry_never(None) == False
    assert retry_never(1) == False
    assert retry_never('test') == False


# Generated at 2022-06-22 21:16:10.633921
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert all(
            x in range(0, 3) and x != 0
            for x in generate_jittered_backoff(retries=1)
            )
    assert all(
            x in range(0, 9) and x != 0
            for x in generate_jittered_backoff(retries=2)
            )
    assert all(
            x in range(0, 27) and x != 0
            for x in generate_jittered_backoff(retries=3)
            )
    assert all(
            x in range(0, 3) and x != 0
            for x in generate_jittered_backoff(retries=1, delay_base=5, delay_threshold=5)
            )

# Generated at 2022-06-22 21:16:18.415946
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global count

    def f(a, b, k=0):
        global count
        count += 1
        if count == 2:
            return count
        raise Exception("Oops")

    count = 0
    retryable_f = retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    assert retryable_f(f)(1, 2) == 2
    assert count == 2

    count = 0
    retryable_f = retry_with_delays_and_condition(generate_jittered_backoff(retries=3), retry_never)
    assert retryable_f(f)(1, 2) == 2
    assert count == 2

    count = 0

# Generated at 2022-06-22 21:16:21.608956
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoffs = list(generate_jittered_backoff())
    print(backoffs)


if __name__ == '__main__':
    test_generate_jittered_backoff()

# Generated at 2022-06-22 21:16:24.279744
# Unit test for function retry_never
def test_retry_never():
    assert False == retry_never(Exception("foo"))
    assert False == retry_never("foo")


# Generated at 2022-06-22 21:16:26.282605
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(type='str')
    x = rate_limit_argument_spec(spec)
    assert isinstance(x, dict)


# Generated at 2022-06-22 21:16:30.829663
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for i in range(0, 3):
        print ("Iteration #", i)
        for delay in generate_jittered_backoff(retries=4, delay_base=1, delay_threshold=4):
            print ("Backoff delay=", delay)

# Generated at 2022-06-22 21:16:41.495832
# Unit test for function retry
def test_retry():
    def my_succeed_function(succeed_after):
        def inner():
            if inner.retries_left > 0:
                inner.retries_left -= 1
                raise RuntimeError("Didn't succeed on the first try")
            return "Success"

        inner.retries_left = succeed_after
        return inner

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=retry_never)
    def dont_retry_on_error():
        raise RuntimeError("I'm not retrying this error")


# Generated at 2022-06-22 21:16:46.626608
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert type(basic_auth_argument_spec()) is dict
    assert 'api_username' in basic_auth_argument_spec()
    assert 'api_password' in basic_auth_argument_spec()
    assert 'api_url' in basic_auth_argument_spec()
    assert 'validate_certs' in basic_auth_argument_spec()


# Generated at 2022-06-22 21:16:47.947147
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    start = time.time()
    backoff_iterator = generat

# Generated at 2022-06-22 21:16:50.038240
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(0) == False
    assert retry_never(Exception()) == False
    assert retry_never('') == False


# Generated at 2022-06-22 21:16:55.503734
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    ''' unit test for function rate_limit_argument_spec '''
    actual = rate_limit_argument_spec()

    expected = [{'rate_limit': {'default': None,
                                'type': 'int',
                                'required': False},
                 'rate': {'default': None,
                          'type': 'int',
                          'required': False}}
                ]

    assert actual == expected


# Generated at 2022-06-22 21:17:06.714003
# Unit test for function retry
def test_retry():
    try:
        import pytest
    except ImportError:  # pragma: no cover
        # Skip the test if pytest is not installed.
        raise unittest.SkipTest("This test requires pytest to run.")

    # Simple counter to test the retry behaviour.
    NUMBER_OF_RETRIES = 10

    @retry(retries=NUMBER_OF_RETRIES)
    def retry_limited_call(*args, **kwargs):
        retry_limited_call.count += 1
        if retry_limited_call.count < NUMBER_OF_RETRIES:
            raise Exception("Fail on attempt number %d" % retry_limited_call.count)
        else:
            return True

    retry_limited_call.count = 0
    assert retry_limited_call() is True
   

# Generated at 2022-06-22 21:17:14.414861
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(3)
    def limited_function():
        print("Limited function")

    limited_function()
    limited_function()
    limited_function()
    limited_function()
"""
Rate limited function
Rate limited function
Rate limited function
"""

# Generated at 2022-06-22 21:17:20.782502
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }



# Generated at 2022-06-22 21:17:28.280694
# Unit test for function rate_limit
def test_rate_limit():
    # Test rate_limit by creating a bunch of functions that sleep for
    # a random period of time and then check we slept at least long
    # enough.  In python 2.7 the time module only gives us seconds so
    # we need to call time.sleep() at least 2 times to be sure we
    # waited for our time.

    def get_rate_limited_function(rate_limit):
        """
        Generates a random delay from 0-rate_limit and then
        return a rate limited function that will sleep for that long
        """
        random_delay = random.randint(0, rate_limit)

        @rate_limit(rate=1, rate_limit=rate_limit)
        def rate_limited_function():
            for _ in range(random_delay):
                time.sleep(1)
        return rate_limited_function



# Generated at 2022-06-22 21:17:39.179882
# Unit test for function rate_limit
def test_rate_limit():
    counter = 0

    @rate_limit(rate=5, rate_limit=10)
    def ratelimited_function():
        nonlocal counter
        counter += 1
        return True

    # first call, start timer
    assert ratelimited_function()

    # less than rate, no delay
    assert ratelimited_function()

    # exceeded rate, should delay
    time.sleep(2.0)
    assert ratelimited_function()
    assert counter == 3

    # exceeded rate, should delay
    time.sleep(2.0)
    assert ratelimited_function()
    assert counter == 4

    # exceeded rate, should delay
    time.sleep(2.0)
    assert ratelimited_function()
    assert counter == 5

    # exceeded rate, should delay
    time.sleep(2.0)
    assert ratelimited_function()


# Generated at 2022-06-22 21:17:42.969197
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Test case for generate_jittered_backoff"""
    backoff_iter = generate_jittered_backoff()
    for backoff in backoff_iter:
        assert 0 <= backoff <= 3



# Generated at 2022-06-22 21:17:53.758818
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def raise_exception_on_first_two_times():
        if raise_exception_on_first_two_times.counter < 2:
            raise_exception_on_first_two_times.counter += 1
            raise Exception("Exception")
        else:
            raise_exception_on_first_two_times.exception_thrown = False
            raise_exception_on_first_two_times.counter += 1
            return "Result"

    raise_exception_on_first_two_times.counter = 0
    raise_exception_on_first_two_times.exception_thrown = True

    def raise_exception_on_even_times():
        if raise_exception_on_even_times.counter % 2 == 0:
            raise_exception_on_even_times.exception

# Generated at 2022-06-22 21:18:03.277355
# Unit test for function retry
def test_retry():
    num = [0]
    def function(exc):
        num[0] += 1
        if num[0] < 3:
            raise Exception("Exc")
        return num[0]
    assert retry_with_delays_and_condition(should_retry_error=retry_never, backoff_iterator=[])(function)() == 1
    assert retry_with_delays_and_condition(should_retry_error=retry_never)(function)() == 1
    num[0] = 0
    assert retry_with_delays_and_condition(should_retry_error=lambda e: True, backoff_iterator=generate_jittered_backoff())(function)() == 3
    num[0] = 0

# Generated at 2022-06-22 21:18:11.159241
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    import yaml
    yaml_str = '''
options:
  rate:
    default: null
    description:
    - number of requests per time unit
    - see rate_limit
    type: int
  rate_limit:
    default: null
    description:
    - time window in which the limit is applied in seconds
    type: int
'''
    arg_spec = rate_limit_argument_spec()
    spec = yaml.load(yaml_str)
    this_spec = arg_spec['options']
    for key in spec:
        assert key in this_spec
        assert spec[key] == this_spec[key]


# Generated at 2022-06-22 21:18:21.029815
# Unit test for function retry
def test_retry():
    """Unit test for function retry"""
    # pylint: disable=too-few-public-methods
    class MyException(Exception):
        """My custom exception"""
        pass

    @retry(retries=3)
    def my_random_function():
        """Returns True 33.3% of the time"""
        if random.randint(0, 2) == 0:
            return True
        raise MyException()

    error_count = 0
    for _ in range(0, 10):
        try:
            result = my_random_function()
            if result:
                break
        except MyException:
            error_count += 1

    assert result
    assert error_count <= 3

# Generated at 2022-06-22 21:18:26.796335
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1)
    )
    assert retry_argument_spec(dict(foo=dict(type='str'))) == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        foo=dict(type='str')
    )

# Generated at 2022-06-22 21:18:36.984518
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3, delay_base=0, delay_threshold=1), retry_never)
    def simple_failing_function(exceptions_to_raise=1):
        if exceptions_to_raise > 0:
            exceptions_to_raise -= 1
            raise Exception()
        return 'success'

    assert simple_failing_function(exceptions_to_raise=1) == 'success'
    assert simple_failing_function(exceptions_to_raise=2) == 'success'
    assert simple_failing_function(exceptions_to_raise=3) == 'success'


# Generated at 2022-06-22 21:18:40.030514
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("foo") == False


# Unit tests for function retry_with_delays_and_condition

# Generated at 2022-06-22 21:18:48.570026
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=5, delay_base=1, delay_threshold=10))
    def call_with_delays(succeed_after_error_count, errors=None):
        if errors is not None:
            errors.append(True)
        if len(errors) < succeed_after_error_count:
            raise Exception("Failed")
        return "success"

    errors = []
    assert "success" == call_with_delays(succeed_after_error_count=1, errors=errors)
    assert len(errors) == 1
    assert "success" == call_with_delays(succeed_after_error_count=2, errors=errors)
    assert len(errors) == 2

# Generated at 2022-06-22 21:18:51.471681
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    results = generate_jittered_backoff()
    assert results
    try:
        next(results)
    except StopIteration:
        raise AssertionError('expected to get a value')

# Generated at 2022-06-22 21:18:59.749742
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import sys

    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock

    # We should be able to get at least 3 calls in 1 second
    count = [0]
    last_time = real_time()

    @rate_limit(rate=3, rate_limit=1)
    def test():
        count[0] += 1

    for _ in range(0, 5):
        test()
    time.sleep(1)  # Let things settle
    test()
    assert count[0] > 3, 'Expected more than 4, got %d' % count[0]

# Generated at 2022-06-22 21:19:03.463211
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    lst = []
    for i in generate_jittered_backoff():
        lst.append(i)
        if len(lst) == 10:
            break
    assert lst == [0, 0, 4, 6, 8, 10, 12, 17, 25, 26]

# Generated at 2022-06-22 21:19:06.268350
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = {"username": dict(type='str'), "password": dict(type='str', no_log=True)}
    result = basic_auth_argument_spec(spec)
    assert 'api_username' in result
    assert 'api_password' in result

# Generated at 2022-06-22 21:19:15.218631
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    class TestRateLimit(unittest.TestCase):

        def test_rate_limit_simple(self):
            @rate_limit(1, 1)
            def doit(ms):
                time.sleep(ms / 1000.0)

            start = time.time()
            doit(500)
            elapsed = time.time() - start
            self.assertTrue(elapsed > 0.5)

    unittest.main()

if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-22 21:19:24.943209
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import json
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.plugins.modules.utils.retry import retry_argument_spec
    from ..module_utils.basic import AnsibleModule
    from .ansible_module_mock import mock_argument_spec

    result = {'changed': True}

    def retry_one():
        return True

    def retry_fail():
        raise Exception("retry test exception")

    def retry_two():
        return True

    class TestRetry:
        def __init__(self):
            self.retry_run = 0

        @retry(retries=2, retry_pause=2)
        def test_retry(self):
            self.retry_run

# Generated at 2022-06-22 21:19:26.932195
# Unit test for function retry_never
def test_retry_never():
    try:
        raise ValueError("This is an error")
    except ValueError as exception:
        assert not retry_never(exception)

# Generated at 2022-06-22 21:19:33.596768
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert(rate_limit_argument_spec() == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    })
    assert(rate_limit_argument_spec({'test': 'me'}) == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
        'test': 'me'
    })


# Generated at 2022-06-22 21:19:39.593616
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class CustomException(Exception):
        """This is a custom exception to use in this test."""

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff())
    def function_to_test():
        """This function will fail three times before succeeding."""
        function_to_test.count += 1
        if function_to_test.count > 3:
            return
        raise CustomException("Must retry")
    function_to_test.count = 0

    run_function = function_to_test()
    assert run_function is None
    assert function_to_test.count == 4
