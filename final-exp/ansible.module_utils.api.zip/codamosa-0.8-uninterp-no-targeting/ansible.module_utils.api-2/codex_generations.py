

# Generated at 2022-06-20 15:20:44.457697
# Unit test for function rate_limit
def test_rate_limit():
    result = 0
    @rate_limit(1, 1)
    def increment():
        global result
        result += 1
    increment()
    increment()
    assert result == 2, "Test rate limiting failed with 2 updates in 1 second."

# Generated at 2022-06-20 15:20:46.833189
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert arg_spec == dict(rate=dict(type='int'), rate_limit=dict(type='int'), )



# Generated at 2022-06-20 15:20:53.916920
# Unit test for function retry
def test_retry():
    """Simple test case for the retry decorator"""
    def test_one(a, b):
        return a + b

    def test_one_error(a, b):
        raise Exception('test')

    @retry(retries=2, retry_pause=0.5)
    def test_two(a, b):
        return a + b

    @retry(retries=2, retry_pause=0.5)
    def test_three(a, b):
        raise Exception('test')

    assert test_one(1, 1) == 2
    assert test_two(1, 1) == 2
    assert test_three(1, 1)

    try:
        test_one_error(1, 1)
        assert False
    except:
        pass



# Generated at 2022-06-20 15:20:56.697246
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff()
    last_delay = None
    for delay in backoff_iterator:
        if last_delay is not None:
            assert delay != last_delay
        assert delay >= 0
        assert delay <= 3
        last_delay = delay

# Generated at 2022-06-20 15:21:05.377944
# Unit test for function retry
def test_retry():
    # Setup
    def test_function(count):
        test_function.call_count += 1
        if test_function.call_count <= count:
            raise Exception
        return True

    # Retry without delay
    test_function.call_count = 0
    retried_function = retry(retries=2, retry_pause=0)(test_function)
    # The first call fails, but the second succeeds
    assert retried_function(1)
    assert test_function.call_count == 2
    # If we require 3 calls, fails
    assert not retried_function(3)
    assert test_function.call_count == 3

    # Retry with delay
    test_function.call_count = 0
    retried_function = retry(retries=2, retry_pause=2)(test_function)

# Generated at 2022-06-20 15:21:16.442746
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    back_off_delays = (1, 6, 7, 8, 9)
    should_retry_error = lambda err: isinstance(err, Exception)

    try:
        @retry_with_delays_and_condition(back_off_delays, should_retry_error)
        def retry_function():
            print("Raising exception")
            raise Exception()

        retry_function()
    except Exception as e:
        print("Exception was raised. This was not expected")
        exit(1)


# Generated at 2022-06-20 15:21:19.917333
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    for k in ('api_username', 'api_password', 'api_url', 'validate_certs'):
        assert k in arg_spec

# Generated at 2022-06-20 15:21:32.266087
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Test all parameters specified
    params = {'api_username': 'test_username', 'api_password': 'test_password', 'api_url': 'https://test.url', 'validate_certs': 'True'}
    result = basic_auth_argument_spec(params)
    assert result['api_username']['type'] == 'str'
    assert result['api_password']['type'] == 'str'
    assert result['api_url']['type'] == 'str'
    assert result['validate_certs']['type'] == 'bool'

    # Test no parameters specified
    params = {}
    result = basic_auth_argument_spec(params)
    assert result['api_username']['type'] == 'str'
    assert result['api_password']['type'] == 'str'


# Generated at 2022-06-20 15:21:33.777819
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff = generate_jittered_backoff()
    for attempt in backoff:
        print(attempt)

# Generated at 2022-06-20 15:21:41.055504
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        service=dict(type='str')
    )
    test = basic_auth_argument_spec(spec)
    assert test['api_username']['type'] == 'str'
    assert test['api_password']['type'] == 'str'
    assert test['api_url']['type'] == 'str'
    assert test['validate_certs']['type'] == 'bool'
    assert test['service']['type'] == 'str'



# Generated at 2022-06-20 15:21:55.427777
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for rate_limit function"""

    def function_with_time_sleep(*args):
        """A function that sleeps for x seconds"""
        time.sleep(*args)

    def function_that_raises_exception(*arg):
        """A function that raises an exception"""
        raise Exception('Testing exception handling')

    wrapped_function_sleep_1 = rate_limit(rate=1, rate_limit=5)(function_with_time_sleep)
    wrapped_function_sleep_2 = rate_limit(rate=2, rate_limit=5)(function_with_time_sleep)
    wrapped_function_sleep_3 = rate_limit(rate=3, rate_limit=5)(function_with_time_sleep)


# Generated at 2022-06-20 15:22:06.778740
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    retry_times = 3
    delay_base = 5
    delay_threshold = 60

    class TestError(Exception):
        pass

    class TestError2(Exception):
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff(retry_times, delay_base, delay_threshold))
    def test_func_1(errors):
        if len(errors) == len(test_functions):
            return True

        for err in errors:
            raise err

        return False

    @retry_with_delays_and_condition(generate_jittered_backoff(retry_times, delay_base, delay_threshold))
    def test_func_2(errors):
        for err in errors:
            raise err


# Generated at 2022-06-20 15:22:08.784647
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception("Anything"))

# Generated at 2022-06-20 15:22:16.460645
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=1)
    def athing():
        return time.time()

    start = time.time()
    thing1 = athing()
    assert 1 <= time.time() - start <= 2
    thing2 = athing()
    assert 2 <= time.time() - start <= 3
    thing3 = athing()
    assert 3 <= time.time() - start <= 4
    thing4 = athing()
    assert 4 <= time.time() - start <= 5


# Generated at 2022-06-20 15:22:29.770067
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import numpy as np

    n_tests = 100
    results = [[] for _ in range(0, n_tests)]

    for retries in range(0, n_tests):
        for delay in generate_jittered_backoff(retries=retries, delay_base=2, delay_threshold=10):
            results[retries].append(delay)

    for retry_index, result in enumerate(results):
        assert len(result) == retry_index  # We have the right number of delays
        if retry_index <= 1:
            assert np.sum(result) == 0  # If we have less than 2 retries, there's no delay
        if retry_index >= 1:
            assert np.sum(result) > 0  # If we have delays, there's a delay

# Generated at 2022-06-20 15:22:39.681880
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # pylint: disable=unused-argument
    def check_in_range(delays, base, threshold):
        for delay in delays:
            assert delay >= 0, "Negative delays are not allowed"
            assert delay <= threshold, "Delay must be less than or equal to threshold"
            assert delay <= base * 2**(len(delays))

    # Valid parameters
    delays = list(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    assert len(delays) == 10
    check_in_range(delays, 3, 60)

    delays = list(generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=60))
    assert len(delays) == 3

# Generated at 2022-06-20 15:22:45.057835
# Unit test for function retry
def test_retry():
    @retry(retries=10)
    def retryable_function(fail=True):
        print("Called retryable_function")
        if fail:
            raise Exception("Failure")
        return True

    # 10 failures will succeed since retry limit is 10
    assert retryable_function(fail=True)

    # 2 failures will succeed since retry limit is 10
    assert retryable_function(fail=False)


# Generated at 2022-06-20 15:22:56.820332
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    called = [0]

    @retry_with_delays_and_condition([0.5, 2, 0.5],
                                     lambda x: False if called[0] == 2 else True)
    def should_not_retry(when_to_retry=2):
        # This function should not retry after getting Called: 2
        called[0] += 1
        raise Exception("Called: %s" % called[0])

    try:
        should_not_retry()
    except Exception as e:
        print(e)

    assert called[0] == 3

    called = [0]


# Generated at 2022-06-20 15:23:00.876396
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = (dict(
        api_username=dict(type='str', no_log=True)
    ))
    assert arg_spec == basic_auth_argument_spec(arg_spec)



# Generated at 2022-06-20 15:23:02.111734
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never("banana")


# Generated at 2022-06-20 15:23:15.296205
# Unit test for function retry
def test_retry():
    def method(should_succeed):
        print("Executed")
        if not should_succeed:
            raise Exception("Not successful")

    print(retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))(method)(False))

if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-20 15:23:18.332718
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    test_rate_limit_arg_spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int')
    )
    assert rate_limit_argument_spec() == test_rate_limit_arg_spec

# Generated at 2022-06-20 15:23:26.558525
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    def do_nothing(arg):
        return False
    arg_spec = retry_argument_spec()
    assert 'retries' in arg_spec
    assert 'retry_pause' in arg_spec
    assert arg_spec['retry_pause']['default'] == 1.0
    assert isinstance(arg_spec['retries']['type'](), int)
    assert isinstance(arg_spec['retry_pause']['type'](), float)
    retry_once = retry(retries=1)(do_nothing)
    assert retry_once(False) == False
    assert retry_once(False) == False

# Generated at 2022-06-20 15:23:29.915065
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    expected_jitter = [0, 3, 6, 9, 9, 15, 27, 36, 48, 57]
    jitter = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    assert expected_jitter == list(jitter)


# Generated at 2022-06-20 15:23:33.759973
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec(
        dict(
            api_username='bob',
            api_password='123',
            api_url='http://example.com',
            validate_certs=False
        )
    ) == dict(
        api_username='bob',
        api_password='123',
        api_url='http://example.com',
        validate_certs=False
    )



# Generated at 2022-06-20 15:23:36.284008
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('issue with results') is False
    assert retry_never('issue with exception') is False
    assert retry_never(10) is False


# Generated at 2022-06-20 15:23:45.933187
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    def test_func(a, b):
        pass
    spec = (dict(
        api_url=dict(type='str', default='http://localhost:8080'),
        api_username=dict(type='str', required=True),
        api_password=dict(type='str', no_log=True, required=True),
        validate_certs=dict(type='bool', default=False)
    ))
    updated_spec = basic_auth_argument_spec(spec)

# Generated at 2022-06-20 15:23:55.113174
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    def count_iterable(iterator):
        count = 0
        for item in iterator:
            count += 1
        return count

    def function_throwing_exception_matching_predicate_no_delay(exception_type, predicate, exception_to_generate):
        """Callable that will throw an exception that matches the given predicate.

        :param exception_type: The type of exception to create if the predicate is truthy.
        :param predicate: A callable that takes an exception and returns a boolean indicating whether or not to throw the given exception_type.
        :param exception_to_generate: The exception to generate.
        """

        def function():
            if predicate(exception_to_generate):
                raise exception_type(str(exception_to_generate))
        return function


# Generated at 2022-06-20 15:24:06.741904
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import random

    # Do not retry on anything
    @retry_with_delays_and_condition(backoff_iterator=[])
    def fail_always():
        raise Exception("")

    # Do not retry on NotImplementedError
    @retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=lambda _ex: not isinstance(_ex, NotImplementedError))
    def fail_only_on_not_implemented():
        raise Exception("")

    # Retry on all
    @retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=lambda _ex: True)
    def fail_on_everything():
        raise Exception("")

    # Retry 10 times with 1-60 second random delay

# Generated at 2022-06-20 15:24:10.427599
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = {"test": {"type": "foo"}}
    new_spec = rate_limit_argument_spec(spec)
    assert new_spec["rate"] == {"type": "int"}
    assert new_spec["rate_limit"] == {"type": "int"}
    assert new_spec["test"] == {"type": "foo"}


# Generated at 2022-06-20 15:24:27.083445
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception()) is False
    assert retry_never(ValueError()) is False
    assert retry_never(Exception()) is False



# Generated at 2022-06-20 15:24:30.150290
# Unit test for function retry
def test_retry():
    class Error(Exception):
        pass

    error_count = [0]

    @retry(retries=3)
    def error_func():
        error_count[0] += 1
        if error_count[0] < 4:
            raise Error()

    error_func()



# Generated at 2022-06-20 15:24:36.568304
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = {}
    ret = basic_auth_argument_spec(spec)
    print(ret)
    assert ret == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )


# Generated at 2022-06-20 15:24:37.915865
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        print(delay)



# Generated at 2022-06-20 15:24:45.819468
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def raise_exception_fn():
        raise ValueError("Forced error")

    def fn_to_decorate(delay_time):
        time.sleep(delay_time)
        return delay_time

    retries = [4, 1, 16, 2]

    for retry in retries:
        decorated_fn = retry_with_delays_and_condition(
            generate_jittered_backoff(retry_pause=1, retries=retry),
            should_retry_error=lambda e: isinstance(e, ValueError)
        )(fn_to_decorate)

        assert decorated_fn(2) == 2


# Generated at 2022-06-20 15:24:52.919221
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest
    class NeverAnyException(Exception):
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=2), should_retry_error=retry_never)
    def function_to_retry():
        raise NeverAnyException

    with pytest.raises(NeverAnyException) as exc_info:
        function_to_retry()
    assert exc_info.value



# Generated at 2022-06-20 15:25:00.115203
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for rate_limit decorator"""
    import functools
    import sys
    import time

    def use(args):
        """Function to wrap and apply rate limit"""
        out = 0
        for arg in args:
            out += arg
        return out

    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock

    # Standard rate limit test, 4 requests of 4 seconds each
    ratelimited = rate_limit(rate=1, rate_limit=4)(use)
    times = [0.0]
    out = [ratelimited(times)]
    assert float(times.pop()) == out.pop()
    assert float(times.pop()) == out.pop()
    assert float(times.pop()) == out.pop()


# Generated at 2022-06-20 15:25:05.867737
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec(dict(
        new_argument=dict(type='str', required=True),
        another_argument=dict(type='str')
        ))
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'
    assert spec['new_argument']['type'] == 'str'
    assert spec['new_argument']['required'] == True
    assert spec['another_argument']['type'] == 'str'

# Generated at 2022-06-20 15:25:14.783631
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    This function test retry functionality

    This function unit tests the retry functionality by creating a mock function that raises an exception.
    It creates lists of return values, delays and retry requests. It then submits the mock function to the retry decorator
    and matches the return values and delay number against the lists.

    This can be executed by running the command:
    python -m ansible.module_utils.basic_common -v
    """
    import unittest
    import random


# Generated at 2022-06-20 15:25:21.616653
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    test_spec = {'test_arg1': dict(type='str'),
                 'test_arg2': dict(type='str', no_log=True)}
    arg_spec = basic_auth_argument_spec(spec=test_spec)
    assert arg_spec['test_arg1'] == {'type': 'str'}
    assert arg_spec['test_arg2'] == dict(type='str', no_log=True)
    assert 'api_url' in arg_spec

# Generated at 2022-06-20 15:26:02.363158
# Unit test for function retry

# Generated at 2022-06-20 15:26:04.323042
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception)



# Generated at 2022-06-20 15:26:06.172866
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert 'retries' in retry_argument_spec()
    assert 'retry_pause' in retry_argument_spec()

# Generated at 2022-06-20 15:26:07.155721
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("foo") == False

# Generated at 2022-06-20 15:26:16.446794
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Test basic_auth_argument_spec function
    d_basic_auth_argument_spec = {
        'api_username': {
            'type': 'str'
        },
        'api_password': {
            'type': 'str',
            'no_log': True
        },
        'api_url': {
            'type': 'str'
        },
        'validate_certs': {
            'type': 'bool',
            'default': True
        }
    }
    assert d_basic_auth_argument_spec == basic_auth_argument_spec()

# Generated at 2022-06-20 15:26:23.272053
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    counter = 0
    backoff_iterator = generate_jittered_backoff(delay_base=1)
    should_retry_error = lambda e: e.args[0] == "continue"

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def call_me(call_me_counter):
        nonlocal counter
        if counter == call_me_counter:
            counter += 1
            return counter
        else:
            raise Exception("continue")

    assert call_me(4) == 5

# Generated at 2022-06-20 15:26:31.712650
# Unit test for function rate_limit
def test_rate_limit():

    # Default rate_limit of 10 per second
    test_rate_limit = rate_limit()

    @test_rate_limit
    def test_function():
        return True

    # Time to run all 10 requests
    time_per_ten_requests = (10.0 / 10.0)

    # Perform 10 requests, no sleep
    start_time = time.time()
    for _ in range(0, 10):
        test_function()
    end_time = time.time()
    elapsed_time = end_time - start_time
    assert elapsed_time < time_per_ten_requests

    # Perform 100 requests, with sleep
    start_time = time.time()
    for _ in range(0, 100):
        test_function()
    end_time = time.time()
    elapsed_time = end_time

# Generated at 2022-06-20 15:26:32.923570
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    print(rate_limit_argument_spec())


# Generated at 2022-06-20 15:26:39.986305
# Unit test for function rate_limit
def test_rate_limit():
    time_in_seconds = [1, 2, 3]

    def test():
        time.sleep(1)
        return True

    for val in time_in_seconds:
        test_with_val = rate_limit(rate_limit=val)(test)
        start_time = time.time()
        test_with_val()
        end_time = time.time()
        delta_time = end_time - start_time
        assert abs(val - delta_time) < 0.1



# Generated at 2022-06-20 15:26:44.216713
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    original_spec = {'test_arg': {'type': 'float', 'default': 3.2}}
    updated_spec = retry_argument_spec(spec=original_spec)
    assert 'retries' in updated_spec
    assert 'test_arg' in updated_spec


# Generated at 2022-06-20 15:27:48.379478
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """unit test for function retry_with_delays_and_condition"""
    import mock
    import types

    retry_count = [0]
    delay_list = [0, 1, 2]
    always_retry = mock.MagicMock()
    always_retry.return_value = True
    never_retry = mock.MagicMock()
    never_retry.return_value = False
    function_to_retry = mock.MagicMock()
    function_to_delay = mock.MagicMock()

    # test that the retry wrapper works for functions
    dec_func_to_retry = retry_with_delays_and_condition(delay_list, should_retry_error=always_retry)(function_to_retry)

# Generated at 2022-06-20 15:27:52.540234
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """test for function basic_auth_argument_spec"""
    result = basic_auth_argument_spec()
    assert isinstance(result, dict)
    assert len(result) == 4


# Generated at 2022-06-20 15:28:00.124921
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for rate_limit"""
    import time

    @rate_limit(rate=3, rate_limit=3)
    def test_func(i):
        return time.time()

    time.sleep(2)
    last = time.time()
    # should work
    assert test_func(1) > last
    last = time.time()

    # should fail and sleep
    assert test_func(2) > last
    last = time.time()

    assert test_func(3) > last
    last = time.time()

    time.sleep(2)
    # should work again
    assert test_func(4) > last



# Generated at 2022-06-20 15:28:05.971352
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Test whether the retry argument spec works."""
    arg_spec = {'arg1': dict(required=True)}
    new_arg_spec = retry_argument_spec(arg_spec)
    assert 'retries' in new_arg_spec
    assert 'retry_pause' in new_arg_spec
    assert 'arg1' in new_arg_spec
    assert 'required' in new_arg_spec['arg1']


# Generated at 2022-06-20 15:28:07.508907
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("a")) == False
    assert retry_never("foo") == False

# Generated at 2022-06-20 15:28:12.585709
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec({'test_arg1': {'type': 'str'}, 'test_arg2': {'type': 'str'}}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}, 'test_arg1': {'type': 'str'}, 'test_arg2': {'type': 'str'}}

# Generated at 2022-06-20 15:28:17.364366
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        retries=3,
        retry_pause=1
    )

    module = AnsibleModule(
        argument_spec=retry_argument_spec(),
        supports_check_mode=True
    )

    # Basic test.
    assert module.retries == 3, "retries param correctly loaded"
    assert module.retry_pause == 1, "retry_pause param correctly loaded"


# Generated at 2022-06-20 15:28:27.205200
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six import PY2
    if PY2:
        import __builtin__ as builtins # pylint: disable=import-error
    else:
        import builtins
    import random

    retryable_exception = ValueError("retryable")
    non_retryable_exception = TypeError("non_retryable")

    def should_retry(error):
        if isinstance(error, retryable_exception.__class__):
            return True
        return False

    def try_then_fail_with(i, error):
        if i == 1:
            raise error()
        else:
            return "success"


# Generated at 2022-06-20 15:28:32.087090
# Unit test for function rate_limit
def test_rate_limit():
    """Test to rate limited function"""

    @rate_limit(rate=10, rate_limit=60)
    def run(a, b):
        """Run function"""
        return a + b

    start = time.time()
    result = run(1, 2)
    end = time.time()

    assert result == 3
    assert end - start > 1



# Generated at 2022-06-20 15:28:35.496384
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    spec = {}
    spec = rate_limit_argument_spec(spec)
    assert 'rate' in spec
    assert 'rate_limit' in spec

    assert 'rate' in spec['rate']
    assert 'rate_limit' in spec['rate_limit']
