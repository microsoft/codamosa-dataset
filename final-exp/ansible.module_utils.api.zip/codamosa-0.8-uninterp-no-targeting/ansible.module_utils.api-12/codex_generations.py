

# Generated at 2022-06-20 15:20:43.667779
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    expected_keys = ['api_username', 'api_password', 'api_url', 'validate_certs']
    keys = basic_auth_argument_spec().keys()
    assert sorted(expected_keys) == sorted(keys)

# Generated at 2022-06-20 15:20:50.625934
# Unit test for function rate_limit
def test_rate_limit():
    """Tests the correctness of the rate_limit decorator"""

    import time
    from functools import partial

    def sleep_function(seconds):
        time.sleep(seconds)
    sleep = rate_limit(rate_limit=10)(partial(sleep_function, 1))

    pause = time.time()
    sleep()
    delta = time.time() - pause
    assert delta > 1, "Decorator waited less than one second"

    pause = time.time()
    sleep()
    delta = time.time() - pause
    assert delta < 1.5, "Decorator waited more than one and a half second"

# Generated at 2022-06-20 15:20:59.947471
# Unit test for function rate_limit
def test_rate_limit():

    import time
    import random
    random.seed(0)

    @rate_limit(rate=2, rate_limit=2)
    def _make_request():
        print("request")

    start = time.time()
    for _ in range(0, 6):
        _make_request()
    end = time.time()
    print(end - start)

    f = rate_limit(rate=2, rate_limit=2)(_make_request)
    start = time.time()
    for _ in range(0, 6):
        f()
    end = time.time()
    print(end - start)


if __name__ == "__main__":
    test_rate_limit()

# Generated at 2022-06-20 15:21:02.369877
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for n in range(1, 10):
        count = 0
        for delay in generate_jittered_backoff(retries=n):
            count += 1
            assert delay >= 0
        assert count == n

# Generated at 2022-06-20 15:21:10.592813
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate limit"""
    count = [0]

    @rate_limit(rate_limit=2)
    def increase(num):
        """Increase the number by 1"""
        count[0] += 1
        return num + 1

    increase(1)
    increase(1)
    assert count[0] == 2

    try:
        increase(1)
        raise Exception("Rate limit bypassed")
    except Exception:
        pass
    assert count[0] == 2

# Generated at 2022-06-20 15:21:22.514655
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Create an array with 5 delays of increasing value.
    delays = [x for x in generate_jittered_backoff(5, 3, 60)]

    times_ran = 0
    times_exception_raised = 0

    # Create a function below which raises exceptions, and increments the counters accordingly.
    def test_function():
        nonlocal times_ran, times_exception_raised
        times_ran += 1
        if times_ran < 3:
            times_exception_raised += 1
            raise Exception()

    test_function_with_retry = retry_with_delays_and_condition(backoff_iterator=delays)(test_function)

    test_function_with_retry()

    # Verify the function was called twice before it succeeded.
    assert times_ran == 3
    assert times_exception_raised == 2

# Generated at 2022-06-20 15:21:23.943470
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False
    assert retry_never(Exception('hello')) is False

# Generated at 2022-06-20 15:21:31.231189
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec= basic_auth_argument_spec()
    assert arg_spec['api_username']['type'] == 'str'
    assert arg_spec['api_password']['type'] == 'str'
    assert arg_spec['api_url']['type'] == 'str'
    assert arg_spec['validate_certs']['type'] == 'bool'
    assert arg_spec['validate_certs']['default'] == True

test_basic_auth_argument_spec()


# Generated at 2022-06-20 15:21:32.976107
# Unit test for function retry_never
def test_retry_never():
    e = Exception
    assert(retry_never(e) == False)
    

# Generated at 2022-06-20 15:21:36.244869
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec=dict(test_arg=dict(type='str'))
    assert rate_limit_argument_spec(spec) == dict(test_arg=dict(type='str'),rate=dict(type='int'),rate_limit=dict(type='int'))

# Generated at 2022-06-20 15:21:43.984921
# Unit test for function retry_never
def test_retry_never():
    retry_never(Exception) == False


# Generated at 2022-06-20 15:21:54.507038
# Unit test for function retry_never
def test_retry_never():
    class MyException(Exception):
        pass
    result_that_should_not_be_retried = False
    exception_that_should_not_be_retried = MyException()

    result_that_should_be_retried = True
    exception_that_should_be_retried = Exception()

    # Retrying results should always return False
    assert retry_never(result_that_should_not_be_retried) == False
    assert retry_never(result_that_should_be_retried) == False

    # Retrying generic exceptions should always return True
    assert retry_never(exception_that_should_not_be_retried) == False
    assert retry_never(exception_that_should_be_retried) == False


# Generated at 2022-06-20 15:22:05.448477
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():  # noqa: D102
    results = []
    backoff = [1, 1, 1, 1, 1]

    @retry_with_delays_and_condition(backoff, retry_never)
    def callit(iteration):
        results.append(iteration)

    callit(1)
    assert results == [1]

    @retry_with_delays_and_condition(backoff, retry_never)
    def raiseit(iteration):
        results.append(iteration)
        raise Exception('test')

    try:
        raiseit(1)
        assert False
    except Exception as e:
        # Check exception propagates
        assert e.args == ('test',)

    assert results == [1]


# Generated at 2022-06-20 15:22:14.045765
# Unit test for function rate_limit
def test_rate_limit():
    import time

    # setup
    r = 1000
    rl = 10
    md = 1
    delay = rl / r

    # init
    t = time.time()
    d = 1

    # first invocation, no delay
    rate_limited()
    assert(time.time() - t < delay)

    # invoke again, with delay
    t = time.time()
    rate_limited()
    assert(time.time() - t >= delay)



# Generated at 2022-06-20 15:22:22.689331
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    res = basic_auth_argument_spec()
    assert(res == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    ))



# Generated at 2022-06-20 15:22:27.624844
# Unit test for function rate_limit
def test_rate_limit():
    time.sleep = lambda x: None
    sys.version_info = (3, 8)
    time.process_time = lambda: 100.5
    time.clock = lambda: None
    rate_limit(rate=1, rate_limit=1)(lambda x: None)(5)
    assert time.process_time() == 101.5

# Generated at 2022-06-20 15:22:39.525759
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_text
    from ansible.module_utils.network.common.utils import ComplexList
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.ios.ios import get_config

    import json
    import pytest

    from units.modules.utils import set_module_args


# Generated at 2022-06-20 15:22:50.804921
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    test_backoff_iterator = [1, 2, 2, 0]
    test_exception = Exception("should retry")
    test_non_retry_exception = Exception("should not retry")

    test_retry_condition = lambda exception: exception == test_exception

    @retry_with_delays_and_condition(test_backoff_iterator, test_retry_condition)
    def test_function():
        raise test_exception

    with pytest.raises(Exception) as e:
        test_function()
    assert str(e.value) == str(test_exception)

    @retry_with_delays_and_condition(test_backoff_iterator, test_retry_condition)
    def test_function():
        raise test_non_retry_exception


# Generated at 2022-06-20 15:22:53.052682
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception('test_retry_never')) == False

# Generated at 2022-06-20 15:22:56.201608
# Unit test for function rate_limit
def test_rate_limit():
    class Test:
        @rate_limit(rate=2, rate_limit=10)
        def test(self):
            return True

    test = Test()
    result = test.test()
    assert result


# Generated at 2022-06-20 15:23:10.355748
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.common.parameters import _handle_aliases
    from ansible.module_utils.basic import AnsibleModule

    my_spec = rate_limit_argument_spec()
    module = AnsibleModule(argument_spec=my_spec, supports_check_mode=True)
    params = module.params
    assert params == {}

    # attempt to set rate and rate_limit as a string
    with pytest.raises(AnsibleModuleError):
        params = {'rate': 'string',
                  'rate_limit': 'string',
                  }
        module = AnsibleModule(argument_spec=my_spec, supports_check_mode=True)
        params = module.params
        _handle_aliases(module)

    # set rate and rate_limit as an integer

# Generated at 2022-06-20 15:23:13.961906
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = list(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    assert len(delays) == 10
    for delay in delays:
        assert 0 <= delay <= 60



# Generated at 2022-06-20 15:23:17.305886
# Unit test for function retry
def test_retry():
    def count(i):
        def f(i):
            return i
        return f(i)

    counter = [0]
    @retry(retries=10)
    def dec(counter):
        counter[0] = counter[0] + 1
        return count(counter[0])

    assert dec(counter) == 10
    # TODO: create a more advanced test with dummy exceptions to check retries



# Generated at 2022-06-20 15:23:21.486220
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-20 15:23:30.456914
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import json
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'retry_argument_spec': dict(type='dict', retries=dict(type='int'), retry_pause=dict(type='float', default=1))})
    spec_dict = {"retries": 5, "retry_pause": 5.55}
    json_str = json.dumps(spec_dict)
    module_input = {"retry_argument_spec": json_str}
    module.check_mode = False # Module input is not valid in check mode
    result = module.run_command('--tags debug_info --args "{}" {}'.format(json.dumps(module_input), __file__))
    retry_spec = module.params.get('retry_argument_spec')


# Generated at 2022-06-20 15:23:38.017094
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = {
        'boolean_arg': dict(type='bool', required=True),
        'integer_arg': dict(type='int', required=True),
        'string_arg': dict(type='str', required=True),
    }
    new_spec = retry_argument_spec(spec)
    assert 'retries' in new_spec.keys()
    assert 'retry_pause' in new_spec.keys()
    assert 'boolean_arg' in new_spec.keys()
    assert 'integer_arg' in new_spec.keys()
    assert 'string_arg' in new_spec.keys()

    # Make sure the original spec is not mutated
    assert 'retries' not in spec.keys()
    assert 'retry_pause' not in spec.keys()

# Generated at 2022-06-20 15:23:43.337904
# Unit test for function rate_limit
def test_rate_limit():
    # pylint: disable=protected-access, unused-variable
    import time

    @rate_limit(rate=1, rate_limit=2)
    def function():
        return time.time()

    ret = function()
    # Verify the return is sub second
    assert 0 <= ret < 1
    # Pause for 1
    time.sleep(1)
    # run it again, should fail
    ret2 = function()
    assert ret2 > ret
    # Pause for 0.5
    time.sleep(0.5)
    # run it again, should fail
    ret3 = function()
    assert ret3 > ret2
    # Pause for 1.5
    time.sleep(1.5)
    # run it again, should succed
    ret4 = function()
    assert ret4 > ret3
    #

# Generated at 2022-06-20 15:23:47.893544
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )
    assert basic_auth_argument_spec() == arg_spec

# Generated at 2022-06-20 15:23:56.220872
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import unittest
    from unittest.mock import MagicMock

    class MockTime:
        def __init__(self):
            self.t = 0.0
            self.d = 0.001

        @property
        def time(self):
            self.t += self.d
            return self.t

    @rate_limit(2, 2)
    def two_per_second():
        return True

    @rate_limit(6, 5)
    def six_per_five():
        return True

    @rate_limit(10, 60)
    def ten_per_minute():
        return True

    class TestRateLimit(unittest.TestCase):

        def test_two_per_second(self):
            mock_time = MockTime()
            saved_time = time.time


# Generated at 2022-06-20 15:24:00.580824
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    retry_count = 0
    for delay in generate_jittered_backoff(retries=4, delay_base=4, delay_threshold=60):
        retry_count += 1
        assert delay <= 60
        assert delay >= 0

    assert retry_count == 4

# Generated at 2022-06-20 15:24:25.289140
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    import datetime

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.function_call_count = 0
            self.function_call_time = None

        def function(self, *args, **kwargs):
            self.function_call_count += 1
            self.function_call_time = datetime.datetime.now()
            return self.function_call_count

        def test_no_retry(self):
            function = retry_with_delays_and_condition([])
            function(self.function)()
            self.assertEqual(self.function_call_count, 1)

        def test_retry_once(self):
            backoff_iterator = [10]
            function = retry_with_delays_and_condition

# Generated at 2022-06-20 15:24:30.037397
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec['api_username']['type'] == 'str'
    assert arg_spec['api_password']['type'] == 'str'
    assert arg_spec['api_url']['type'] == 'str'
    assert arg_spec['validate_certs']['type'] == 'bool'
    assert arg_spec['validate_certs']['default'] == True


# Generated at 2022-06-20 15:24:33.212106
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    expected = dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    result = retry_argument_spec()
    assert result == expected

# Generated at 2022-06-20 15:24:35.302495
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False


# Generated at 2022-06-20 15:24:40.944973
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=10, rate_limit=30)
    def sample():
        return

    assert sample.__name__ == 'sample'
    start = time.time()
    for i in range(0, 10):
        sample()
    assert time.time() - start <= 30
    start = time.time()
    for i in range(0, 10):
        sample()
    assert time.time() - start >= 30



# Generated at 2022-06-20 15:24:44.934721
# Unit test for function retry
def test_retry():
    """Unit test for function retry()"""
    num_retries = [0]

    @retry(retries=3, retry_pause=1)
    def delayed_retry():
        num_retries[0] += 1
        if num_retries[0] < 2:
            return False
        return True

    delayed_retry()
    assert num_retries[0] == 2



# Generated at 2022-06-20 15:24:50.148161
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    assert 'api_username' in module.params
    assert 'api_password' in module.params
    assert 'api_url' in module.params
    assert 'validate_certs' in module.params



# Generated at 2022-06-20 15:24:56.626214
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    out = rate_limit_argument_spec()
    assert out == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}, out
    out = rate_limit_argument_spec(spec = dict(foo = dict(type = 'int')))
    assert out == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}, 'foo' : {'type': 'int'}}, out


# Generated at 2022-06-20 15:25:00.726511
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Test retry argument spec"""
    spec = {
        'foo': dict(type='str'),
    }
    result = retry_argument_spec(spec)
    assert 'retries' in result
    assert 'retry_pause' in result
    assert 'foo' in result


# Generated at 2022-06-20 15:25:04.310818
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception())
    assert not retry_never(Exception("Test"))
    assert not retry_never(Exception(1))


# Unit tests for function generate_jittered_backoff

# Generated at 2022-06-20 15:25:37.072869
# Unit test for function rate_limit
def test_rate_limit():
    from time import time
    from time import sleep
    from time import clock
    import sys

    # create argument spec functions for unit testing
    rate_limit_spec = dict(
        rate=5,
        rate_limit=1
    )

    argspec = rate_limit_argument_spec(rate_limit_spec)

    # create rate limited function for unit testing,
    # function should have a rate of 5 calls per second
    last = [0.0]

    @rate_limit(argspec['rate'], argspec['rate_limit'])
    def test_func(message):
        if sys.version_info >= (3, 8):
            real_time = time
        else:
            real_time = clock
        elapsed = real_time() - last[0]
        last[0] = real_time()

# Generated at 2022-06-20 15:25:43.329510
# Unit test for function retry_never
def test_retry_never():
    retried = retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    @retried
    def raise_exception_once_more():
        raise Exception('To Infinity and Beyond!')

    try:
        raise_exception_once_more()
        assert False, 'Should have raised an exception'
    except Exception:
        assert True, 'An exception was raised'


# Generated at 2022-06-20 15:25:50.842032
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        a_param=dict(required=True),
        b_param=dict(default='hello')
    )

    # Test that required=True is set
    module_args = dict()
    auth_args = basic_auth_argument_spec(spec)

    assert auth_args['a_param']['required']
    assert 'a_param' in auth_args
    assert 'api_username' in auth_args
    assert 'api_password' in auth_args
    assert 'api_url' in auth_args
    assert 'validate_certs' in auth_args

# Generated at 2022-06-20 15:26:02.401741
# Unit test for function rate_limit
def test_rate_limit():
    """rate_limit: Make sure that rate limit works as expected"""
    # rate limit of 1 per second
    @rate_limit(1, 1)
    def test():
        """test"""
        return time.time()

    before = time.time()
    test()
    after = time.time()
    if after - before > 1:
        raise AssertionError('rate limit of 1 per second exceeded')

    # rate limit of 1 per 5 seconds
    @rate_limit(1, 5)
    def test_five():
        """test 5"""
        return time.time()
    before = time.time()
    test_five()
    after = time.time()
    if after - before > 5:
        raise AssertionError('rate limit of 1 per second exceeded')
    before = time.time()
    test_five()

# Generated at 2022-06-20 15:26:07.545059
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit function"""
    @rate_limit(rate=10, rate_limit=1)
    def my_function():
        """Test rate limit"""
        return True

    start_time = time.time()
    for _ in range(10):
        my_function()
    end_time = time.time()

    assert end_time - start_time <= 1.1



# Generated at 2022-06-20 15:26:09.824821
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert isinstance(rate_limit_argument_spec(), dict)

# Generated at 2022-06-20 15:26:15.293339
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    # Test with no arguments provided
    result = rate_limit_argument_spec()
    assert len(result.keys()) == 1
    # Test with argument specification provided
    spec = dict(a=dict(b=1))
    result = rate_limit_argument_spec(spec)
    assert result.keys() == spec.keys()

# Generated at 2022-06-20 15:26:26.144536
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class SomeException(Exception):
        pass

    class OtherException(Exception):
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=5), should_retry_error=lambda e: isinstance(e, SomeException))
    def run_function(exc=None):
        print("Run #%d" % run_function.call_count)
        run_function.call_count += 1
        if exc:
            raise exc

    run_function.call_count = 0

    try:
        run_function(SomeException)
        raise AssertionError("This should raise")
    except AssertionError:
        raise
    except OtherException:
        raise AssertionError("This should not raise")
    except SomeException:
        pass


# Generated at 2022-06-20 15:26:26.989016
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('foobar') == False

# Generated at 2022-06-20 15:26:29.878507
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec(dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int')
    )) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int')
    )



# Generated at 2022-06-20 15:27:32.092068
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert list(generate_jittered_backoff(0)) == []
    assert list(generate_jittered_backoff(10)) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# Generated at 2022-06-20 15:27:41.522902
# Unit test for function rate_limit
def test_rate_limit():
    import random
    import time
    mock_time_process_time = [0.0]

    def mock_time():
        return mock_time_process_time[0]

    def mock_sleep(secs):
        mock_time_process_time[0] += secs

    def mock_time_clock():
        return mock_time_process_time[0]

    if sys.version_info >= (3, 8):
        mock_time = mock_time_process_time
    else:
        mock_time = mock_time_clock

    @rate_limit(rate=2, rate_limit=10)
    def my_func():
        return mock_time()

    # This is not really a unit test, just a way to check how the decorator
    # behaves, should be replaced with proper unit tests
    #
   

# Generated at 2022-06-20 15:27:48.000128
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    res = retry_argument_spec()
    assert res['retries']['type'] == 'int'
    assert res['retry_pause']['type'] == 'float'
    assert res['retry_pause']['default'] == 1

    res = retry_argument_spec(spec=dict(foo=dict(type='str')))
    assert 'foo' in res
    assert res['foo']['type'] == 'str'
    assert res['retries']['type'] == 'int'
    assert res['retry_pause']['type'] == 'float'
    assert res['retry_pause']['default'] == 1


# Generated at 2022-06-20 15:27:57.336443
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        api_token=dict(type='str'),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True))
    arg_spec = basic_auth_argument_spec(spec)
    assert 'api_username' in arg_spec.keys()
    assert 'api_password' in arg_spec.keys()
    assert 'api_url' in arg_spec.keys()
    assert 'validate_certs' in arg_spec.keys()
    assert 'api_token' in arg_spec.keys()


# Generated at 2022-06-20 15:28:07.543474
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest

    class ExceptionA(Exception):
        pass

    class ExceptionB(Exception):
        pass

    calls_made = 0

    def should_retry_error(error):
        if isinstance(error, ExceptionA):
            return True
        if isinstance(error, ExceptionB):
            return False

        # Don't retry any other error
        return False

    @retry_with_delays_and_condition(generate_jittered_backoff(10), should_retry_error=should_retry_error)
    def retryable_function(dont_raise_exception_error=False, raise_exception_a=False, raise_exception_b=False):
        """Raise different exceptions depending on the parameters.
        Mark the number of calls made by modifying a global variable.
        """
       

# Generated at 2022-06-20 15:28:10.365785
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import math

    arg_test_specs = (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))

    @retry_argument_spec(arg_test_specs)
    def test_function(a, b):
        return a + b

    assert test_function(1, 2) == 3
    result = test_function(5, 4)
    assert result == 9


# Generated at 2022-06-20 15:28:16.941288
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    called_count = 0
    def test_function():
        nonlocal called_count
        called_count += 1

        if called_count == 1:
            raise Exception('first attempt failed')
        elif called_count == 2:
            raise Exception('second attempt failed')
        elif called_count == 3:
            raise Exception('third attempt failed')
        else:
            return 'success'

    decorated_function = retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(),
        should_retry_error=lambda e: True
    )(test_function)

    result = decorated_function()

    assert result == 'success'
    assert called_count == 4

# Generated at 2022-06-20 15:28:21.738232
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert spec['api_username']['type'] == 'str'
    assert spec['api_password']['type'] == 'str'
    assert spec['api_url']['type'] == 'str'



# Generated at 2022-06-20 15:28:24.798021
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()

    expected = {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }

    assert arg_spec == expected

# Generated at 2022-06-20 15:28:35.199885
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    test_data = (
        dict(
            rate=1,
            rate_limit=3,
            spec=dict(
                key1=dict(type='int', default=1)
            )
        ),
        dict(
            rate=1,
            rate_limit=3,
            spec=dict(
                key2=dict(type='str', default='str')
            )
        )
    )
    for td in test_data:
        result = rate_limit_argument_spec(td['spec'])
        assert result == dict(
            rate=dict(type='int'),
            rate_limit=dict(type='int'),
            key1=dict(type='int', default=1),
            key2=dict(type='str', default='str')
        )