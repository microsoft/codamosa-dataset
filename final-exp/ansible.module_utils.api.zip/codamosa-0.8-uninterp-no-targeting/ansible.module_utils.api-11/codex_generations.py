

# Generated at 2022-06-20 15:20:42.794219
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec
    assert arg_spec['api_password']['no_log']



# Generated at 2022-06-20 15:20:44.087315
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False

# Generated at 2022-06-20 15:20:52.037507
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    delay_threshold = 10

    # Set the number of iterations to a minimum of 10, since each of the iterations could take at least up to a second.
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=delay_threshold), should_retry_error=retry_never)
    def run_function():
        raise Exception("Retryable")

    start_time = time.time()

    try:
        run_function()
    except Exception as e:
        pass

    end_time = time.time()
    # Since we are delaying, the difference between start and end time should be > 0.
    return end_time - start_time > 0

# Generated at 2022-06-20 15:21:04.440236
# Unit test for function retry
def test_retry():
    """Simple test for retry helper"""
    i = [0]
    limit = [3]
    @retry(retries=limit[0])
    def _test():
        i[0] += 1
        raise Exception("test")

    try:
        _test()
    except Exception:
        assert i[0] == limit[0]
    else:
        assert False, 'test should have failed but did not'

    i[0] = 0
    limit[0] = 0
    try:
        _test()
    except Exception:
        assert False, 'test should have succeeded but did not'
    else:
        assert i[0] == 1

if __name__ == "__main__":
    test_retry()

# Generated at 2022-06-20 15:21:16.008529
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.urls import open_url

    result = rate_limit_argument_spec()
    assert result == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'))
    result = rate_limit_argument_spec(dict(param1='value'))
    assert result == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        param1='value')

    # test without rate

# Generated at 2022-06-20 15:21:25.288133
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    retries = 3
    expected_delays = [0, 3, 9, 27]
    count_down = [retries]

    def function():
        if count_down[0] > 0:
            time.sleep(random.randint(0, retries))
            count_down[0] -= 1
            raise Exception("Failed on purpose")
        raise Exception("This should not happen")

    @retry_with_delays_and_condition(generate_jittered_backoff(retries))
    def retry_decorated_function():
        function()

    retry_decorated_function()

    # Extreme case where the function should be called a single time
    @retry_with_delays_and_condition(expected_delays)
    def single_time_function():
        function()

    single_

# Generated at 2022-06-20 15:21:35.087074
# Unit test for function rate_limit
def test_rate_limit():
    """Base test for rate_limit"""
    rate = 5
    rate_limit = 30
    decorator = rate_limit(rate, rate_limit)

    global count
    count = 0
    sleep_time = 5
    @decorator
    def foo(sleep_time):
        global count
        count += 1
        time.sleep(sleep_time)

    # call foo 5 times with sleep_time = 5 (rate = 1/s)
    # since we have a rate limit of 5/s we should take 30s
    t1 = time.time()
    for i in range(0, rate):
        foo(sleep_time)
    t2 = time.time()

    assert count == rate
    assert round(t2-t1) == rate_limit



# Generated at 2022-06-20 15:21:41.816971
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    for value in (1, 3.2, 5.4, 7.8):
        assert arg_spec['retries']['type'] == 'int'
        assert arg_spec['retries']['default'] == 5

        assert arg_spec['retry_pause']['type'] == 'float'
        assert arg_spec['retry_pause']['default'] == 1


# Generated at 2022-06-20 15:21:44.130029
# Unit test for function retry
def test_retry():
    """Sets up a unit test for retry"""
    for i in [0, 1, 2, 3, 4]:
        if i == 3:
            return i
        raise Exception("I will fail")



# Generated at 2022-06-20 15:21:45.682393
# Unit test for function retry_never
def test_retry_never():
    try:
        raise Exception('foo')
    except Exception as e:
        assert retry_never(e) == False


# Generated at 2022-06-20 15:21:57.440597
# Unit test for function rate_limit
def test_rate_limit():
    rate = 2
    rate_limit = 10

    @rate_limit(rate=rate, rate_limit=rate_limit)
    def test_method():
        return

    start = time.time()
    test_method()
    end = time.time()
    elapsed = end - start

    # This should be the result of rate_limit/rate
    expected_elapsed = (1.0 / rate)

    assert expected_elapsed == elapsed, "Should take %s but took %s" % (expected_elapsed, elapsed)


# Generated at 2022-06-20 15:22:06.088172
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_argument_spec_arguments = retry_argument_spec()
    assert 'retries' in retry_argument_spec_arguments.keys()
    assert 'retry_pause' in retry_argument_spec_arguments.keys()
    assert retry_argument_spec_arguments['retry_pause']['default'] == 1
    assert retry_argument_spec_arguments['retry_pause']['type'] == 'float'
    assert retry_argument_spec_arguments['retries']['type'] == 'int'


# Generated at 2022-06-20 15:22:12.128081
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class TestRetryWithDelaysAndCondition(unittest.TestCase):

        def test_retry_never(self):
            self.assertFalse(retry_with_delays_and_condition(None, retry_never)(lambda: 1)())
            self.assertFalse(retry_with_delays_and_condition(None, retry_never)(lambda: 1)(a=1))

        def test_retry_once(self):
            def raise_if_one(a):
                if a == 1:
                    raise RuntimeError()
                return a

            self.assertEqual(retry_with_delays_and_condition(None, retry_never)(raise_if_one)(2), 2)

# Generated at 2022-06-20 15:22:15.829291
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec == {
        'retries': {
            'type': 'int'
        },
        'retry_pause': {
            'type': 'float',
            'default': 1
        }
    }



# Generated at 2022-06-20 15:22:19.864594
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    def retryable_function():
        """Retry me with the generated delays."""
        pass

    # We're not actually running the function, we're only verifying the delays it would use.
    retryable_function()

# Generated at 2022-06-20 15:22:30.218342
# Unit test for function rate_limit
def test_rate_limit():
    # Function to test
    def func(v):
        return v

    # Test single call
    t1 = time.time()
    rate_limited_func = rate_limit(rate=1, rate_limit=1)(func)
    rate_limited_func(1)
    t2 = time.time()
    assert t2 - t1 < 0.1

    # Test multiple calls
    t1 = time.time()
    rate_limited_func = rate_limit(rate=1, rate_limit=1)(func)
    rate_limited_func(1)
    rate_limited_func(2)
    rate_limited_func(3)
    t2 = time.time()
    assert t2 - t1 > 1
    t3 = time.time()
    assert t3 - t2 < 0.1

# Unit

# Generated at 2022-06-20 15:22:35.120934
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60))
    def test_function():
        raise AssertionError('Test exception')
    try:
        test_function()
    except AssertionError:
        pass
    else:
        raise AssertionError('Test function did not raise exception')

# Generated at 2022-06-20 15:22:37.232566
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(Exception("not going to be retried")) == False


# Generated at 2022-06-20 15:22:41.242698
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():

    delay_threshold = 60
    delay_base = 3
    retries = 30

    backoff_iterator = generate_jittered_backoff(retries, delay_base, delay_threshold)
    for delay in backoff_iterator:
        assert delay <= delay_threshold



# Generated at 2022-06-20 15:22:44.019871
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(rate=5, rate_limit=5)
    def test_rate_limited():
        print("Rate limited")

    test_rate_limited()



# Generated at 2022-06-20 15:23:03.609596
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(10), should_retry_error=lambda e: e == 'something bad')
    def retryable_function():
        global call_count
        call_count += 1
        if call_count < 10:
            raise "something bad"
        return call_count

    global call_count
    call_count = 0
    assert retryable_function() == 10



# Generated at 2022-06-20 15:23:06.006472
# Unit test for function retry_never
def test_retry_never():
    name = 'test_retry_never'
    # validate that retry_never does not retry when exception is handled
    assert not retry_never(Exception(name))



# Generated at 2022-06-20 15:23:12.318509
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {'api_password': {'no_log': True, 'type': 'str'}, 'api_url': {'type': 'str'}, 'api_username': {'type': 'str'}, 'validate_certs': {'default': True, 'type': 'bool'}}


# Generated at 2022-06-20 15:23:14.737123
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        print(delay)


# backward compatibility
Retry = retry

# Generated at 2022-06-20 15:23:17.940427
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import pytest
    test_args = dict(user='bcoca', password='password')
    assert basic_auth_argument_spec(spec=test_args) == dict(api_username='bcoca', api_password='password', api_url=None, validate_certs=True)

# Generated at 2022-06-20 15:23:23.217828
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Unit test for function generate_jittered_backoff"""
    backoff_sequence = list(generate_jittered_backoff())
    expected_backoff_sequence = [0, 0, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
    assert backoff_sequence == expected_backoff_sequence

# Generated at 2022-06-20 15:23:30.594235
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    import copy
    result = dict(
        api_username=dict(type='str'),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert copy.deepcopy(result) == rate_limit_argument_spec(dict(api_username=dict(type='str')))



# Generated at 2022-06-20 15:23:35.190166
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_base = 3
    delay_threshold = 20
    for delay in generate_jittered_backoff(retries=5, delay_base=delay_base, delay_threshold=delay_threshold):
        assert delay <= delay_threshold, "delay: %d" % delay

# Generated at 2022-06-20 15:23:42.430787
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1}
    }
    assert retry_argument_spec({'a': {'type': 'int'}, 'b': {'type': 'float'}}) == {
        'a': {'type': 'int'},
        'b': {'type': 'float'},
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1}
    }

# Generated at 2022-06-20 15:23:52.361226
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_generator = generate_jittered_backoff()
    expected_delays = [next(backoff_generator) for _ in range(4)]
    actual_delays = []

    # The test function has an always-true condition for retrying,
    # so we will retry all exceptions
    @retry_with_delays_and_condition(backoff_iterator=expected_delays)
    def raise_exception_n_times_then_sleep(n):
        if n > 0:
            # Raise an exception the first n-1 times and then return
            raise Exception()
        else:
            # We have retried n-1 times, so when we don't raise and exception, return
            return n


# Generated at 2022-06-20 15:24:05.855711
# Unit test for function retry
def test_retry():
    @retry(retries=2, retry_pause=1)
    def success_after_fail(fail=True):
        ret = True if not fail else False
        return ret
    assert success_after_fail(False)
    assert success_after_fail(True)
    assert success_after_fail(True)



# Generated at 2022-06-20 15:24:11.857555
# Unit test for function retry
def test_retry():
    """Unit test for function retry"""
    @retry(retries=5)
    def run_test_retries():
        return 0
    run_test_retries()

if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-20 15:24:17.165510
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'default': True, 'type': 'bool'}
    }

# Generated at 2022-06-20 15:24:22.640757
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    argument_spec = rate_limit_argument_spec()
    assert argument_spec['rate'] == dict(type='int'), "not the expected rate argument, got: %s" % argument_spec['rate']
    assert argument_spec['rate_limit'] == dict(type='int'), "not the expected rate_limit argument, got: %s" % argument_spec['rate_limit']



# Generated at 2022-06-20 15:24:30.554621
# Unit test for function rate_limit
def test_rate_limit():
    """ test rate_limit"""
    last = 0
    limit = 5
    window = 10

    def try_this():
        """test function to be rate limited"""
        global last
        if last:
            last += 1
        else:
            last = 1
        return last

    @rate_limit(rate=limit, rate_limit=window)
    def try_this_wrapped():
        """test rate_limited function"""
        return try_this()

    times = 10
    for _ in range(0, times):
        # pylint: disable=no-member
        limit = random.randrange(31, 51)
        window = random.randrange(11, 21)
        try_this_wrapped.__wrapped__.__wrapped__.__kwargs__['rate'] = limit
        try_this_wrapped

# Generated at 2022-06-20 15:24:35.779174
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert 'api_username' in spec
    assert 'api_password' in spec
    assert 'api_url' in spec
    assert 'validate_certs' in spec
    assert spec['validate_certs']['default'] is True


# Generated at 2022-06-20 15:24:38.362698
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )



# Generated at 2022-06-20 15:24:41.126439
# Unit test for function retry_never
def test_retry_never():
    # Assert that `retry_never` always return False
    assert retry_never(Exception()) == False



# Generated at 2022-06-20 15:24:43.333214
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    #
    # Test this is a valid argument spec
    #

    test_module = AnsibleModule(argument_spec=retry_argument_spec())
    for argument in test_module.argument_spec:
        assert test_module.params[argument] is not None


# Generated at 2022-06-20 15:24:49.990315
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    total_delay = 0

    for delay in generate_jittered_backoff():
        total_delay += delay
        if delay > 60:
            assert False, "The delay should not exceed 60 seconds."
        print("delay = %d, total delay = %d" % (delay, total_delay))
        if total_delay > 60:
            break
    assert total_delay <= 60 and total_delay > 0

# Generated at 2022-06-20 15:25:06.189672
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    call_count = [0]

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60),
                                     lambda e: e.args[0] == 'retry')
    def retry_function_ten_times(arg):
        call_count[0] += 1
        if arg == 'fail':
            raise Exception('retry')
        return arg

    retry_function_ten_times('pass')
    assert call_count[0] == 1

    call_count[0] = 0
    retry_function_ten_times('fail')
    assert call_count[0] == 11

# Generated at 2022-06-20 15:25:11.572432
# Unit test for function retry
def test_retry():

    # Test decorator, should fail and timeout at 5 tries
    @retry(retries=5)
    def fail():
        return False

    try:
        fail()
    except Exception:
        pass
    else:
        raise Exception("Should have failed")

    # Test decorator, should return after 1 retry
    @retry(retries=5)
    def success():
        return True

    success()

# Generated at 2022-06-20 15:25:17.576115
# Unit test for function retry
def test_retry():
    """Unit test for function retry.
    This function tries to delete a file name 'test_retry_file.txt'
    in the current working directory
    """
    import os
    import tempfile
    max_retries = 3
    retry_pause = 2
    retry_count = [0]
    test_file = os.path.join(tempfile.gettempdir(), 'test_retry_file.txt')

    def retried(*args, **kwargs):
        retry_count[0] += 1
        if retry_count[0] >= max_retries:
            raise Exception("Retry limit exceeded: %d" % max_retries)
        try:
            os.remove(test_file)
        except Exception:
            pass
        ret = os.path.exists(test_file)


# Generated at 2022-06-20 15:25:18.635152
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(raise_exception=False) is False

# Generated at 2022-06-20 15:25:27.786889
# Unit test for function retry
def test_retry():
    import pytest

    @retry(retries=2, retry_pause=1)
    def retry_test():
        raise Exception("Fail")

    @retry(retries=2, retry_pause=1)
    def retry_test_falsy():
        # returning None will cause a failure condition
        pass

    @retry(retries=2, retry_pause=1)
    def retry_test_success():
        return "success"

    try:
        retry_test()
    except Exception as e:
        assert e.args[0] == "Retry limit exceeded: 2"

    try:
        retry_test_falsy()
    except Exception as e:
        assert e.args[0] == "Retry limit exceeded: 2"

    assert retry_test_success

# Generated at 2022-06-20 15:25:33.242630
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-20 15:25:36.705013
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec(dict(arg1=dict(required=True))) == dict(
        arg1=dict(required=True),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

# Generated at 2022-06-20 15:25:44.680923
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    # Arrange
    spec = dict(test_arg=dict(type='str', choices=['one', 'two', 'three']))
    expected_result = {
        'test_arg': {'type': 'str', 'choices': ['one', 'two', 'three']},
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }

    # Act
    actual_result = rate_limit_argument_spec(spec)

    # Assert
    assert actual_result == expected_result


# Generated at 2022-06-20 15:25:46.290838
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never(Exception()) == False)

# Generated at 2022-06-20 15:25:48.410631
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    print(basic_auth_argument_spec)



if __name__ == '__main__':
    test_rate_limit_argument_spec()

# Generated at 2022-06-20 15:26:11.650828
# Unit test for function rate_limit
def test_rate_limit():
    class RateLimitTest:
        def __init__(self, rate=None, rate_limit=None):
            self.rate = rate
            self.rate_limit = rate_limit
            self.time = []
            self.count = 0
            self.ratelimited = rate_limit(self.rate, self.rate_limit)
            if sys.version_info >= (3, 8):
                self.real_time = time.process_time
            else:
                self.real_time = time.clock

        def tick(self):
            self.time.append(self.real_time())

        @rate_limit(rate=2, rate_limit=5)
        def ratelimited(self):
            self.tick()
            self.count += 1

        def start(self):
            self.tick()
            self.ratelimited()

# Generated at 2022-06-20 15:26:15.067750
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(True) is False
    assert retry_never(Exception) is False
    assert retry_never(False) is False
    assert retry_never(1234) is False


# Generated at 2022-06-20 15:26:25.863445
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from random import Random
    from nose.tools import assert_equals, assert_raises

    class AlwaysFailException(Exception):
        pass

    def raise_always_fail(x):
        raise AlwaysFailException(x)

    def add_random_delay(random_backoff_iterator, delay_base=3, delay_threshold=60):
        for delay in random_backoff_iterator:
            yield random.randint(0, min(delay_threshold, delay_base * 2 ** delay))

    class TestRetryWithDelays(object):
        def test_never_retry(self):
            function = retry_with_delays_and_condition([], should_retry_error=retry_never)(raise_always_fail)
            assert_raises(AlwaysFailException, function, 'something')


# Generated at 2022-06-20 15:26:27.365661
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    result = retry_argument_spec()
    assert 'retries' in result
    assert 'retry_pause' in result


# Generated at 2022-06-20 15:26:33.989352
# Unit test for function rate_limit
def test_rate_limit():
    # Test that rate_limit generates a decorator
    @rate_limit(1, 1)
    def foo():
        pass

    assert foo

    # Test that the value is rate limited
    calls = []
    @rate_limit(1, 1)
    def bar():
        calls.append(1)

    bar()
    bar()
    bar()
    assert len(calls) == 3  # this should be equal to 3 because we only ratelimit calls


# Generated at 2022-06-20 15:26:42.787268
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Test the retry_with_delays_and_condition decorator.

    This unit test covers four basic scenarios:
    1. No retry - success
    2. No retry - failure
    3. Retry with error - success
    4. Retry without error - failure

    It also asserts whether the full backoff_iterator is consumed.
    """
    retry_test_cases = [
        # Retries, success, delay_base, error_retry, Error
        (0, True, 1, True, None),
        (0, False, 1, True, None),
        (1, True, 0, True, TestException()),
        (1, False, 0, True, None),
    ]


# Generated at 2022-06-20 15:26:53.878663
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # The result we expect to be returned by the function
    expected_function_result = 'success'

    # Create a function that will except on the second call and return the expected result the next call
    exception_count = [0]
    def exception_on_second_call(param1, param2):
        exception_count[0] += 1
        if exception_count[0] == 2:
            raise RuntimeError('error')
        return expected_function_result

    # Retry this function with delays of 0, 1, and 2 seconds. The function should only be called three times.
    actual_result = retry_with_delays_and_condition(generate_jittered_backoff(3, 1, 2))(exception_on_second_call)(1, 2)
    assert actual_result == expected_function_result
    assert exception_

# Generated at 2022-06-20 15:27:04.839803
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    new_module = AnsibleModule(argument_spec=retry_argument_spec())
    assert new_module.params['retries'] is None
    assert new_module.params['retry_pause'] == 1.0

    new_module = AnsibleModule(argument_spec=retry_argument_spec(dict(name=dict(required=True))))
    assert new_module.params['retries'] is None
    assert new_module.params['retry_pause'] == 1.0
    assert new_module.params['name'] is None

    new_module = AnsibleModule(argument_spec=retry_argument_spec(dict(name=dict(required=True))),
                               params=dict(name='test', retries=5, retry_pause=1.5))
    assert new_module.params['retries'] == 5

# Generated at 2022-06-20 15:27:07.548704
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Test
    test = basic_auth_argument_spec()

    # Verify
    assert test is not None
    assert test['api_url']['type'] == 'str'

# Generated at 2022-06-20 15:27:10.595171
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert spec['retries']['type'] == 'int'
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1

# Generated at 2022-06-20 15:27:38.187772
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit function.  This is an example of how to use the decorator"""
    # rate = 3, rate_limit = 6
    @rate_limit(rate=3, rate_limit=6)
    def delayme(i):
        """If we counted seconds since the epoch and limited to 2 per second we could count
           from 0 to 3, then delay for 2 seconds, repeat
        """
        print(i)
        if i > 3:
            raise Exception("Should not reach value 4")

    for i in range(0, 6):
        delayme(i)

    # Disable rate limit
    @rate_limit()
    def delayme(i):
        """If we counted seconds since the epoch and limited to 2 per second we could count
           from 0 to 3, then delay for 2 seconds, repeat
        """
        print(i)

# Generated at 2022-06-20 15:27:40.053593
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('exception') == False
    assert retry_never('result') == False


# Generated at 2022-06-20 15:27:44.322241
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int')
    )
    module = AnsibleModule(argument_spec=rate_limit_argument_spec(spec))
    module.exit_json(changed=False, msg='Hello')



# Generated at 2022-06-20 15:27:48.597890
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    results = retry_argument_spec(spec=dict(a=dict(type='str'), b=dict(type='str')))
    print(results)
    assert results['a']['type'] == 'str'
    assert results['b']['type'] == 'str'
    assert results['retries']['type'] == 'int'
    assert results['retry_pause']['type'] == 'float'
    assert results['retry_pause']['default'] == 1


# Generated at 2022-06-20 15:27:59.488567
# Unit test for function retry
def test_retry():
    """ Unit test for generic retry decorator """
    # Example function that raises an exception on the first two calls
    @retry_with_delays_and_condition(
        generate_jittered_backoff(retries=2))  # use the "Full Jitter" backoff
    def raise_exception_on_first_two_calls():
        """ This function raises an exception for the first two calls """
        global test_count
        if test_count < 2:
            test_count += 1
            raise Exception("Test Error")
        else:
            return 0


# Generated at 2022-06-20 15:28:03.437260
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_arg_spec = None
    rate_limit_arg_spec = rate_limit_argument_spec()
    assert rate_limit_arg_spec['rate'] == {'type': 'int'}
    assert rate_limit_arg_spec['rate_limit'] == {'type': 'int'}



# Generated at 2022-06-20 15:28:13.302918
# Unit test for function rate_limit
def test_rate_limit():
    """Test the rate_limit decorator"""
    TEST_DATA = {
        "name": "foo",
        "state": "present"
    }

    @rate_limit(rate=2, rate_limit=2)
    def rate_limited_function(*args, **kwargs):
        print("Calling function with args: {}; kwargs: {}".format(args, kwargs))
        return True

    # test average rate
    rate = 2
    rate_limit = 2
    minrate = float(rate_limit) / float(rate)
    for i in range(0, rate):
        rate_limited_function(TEST_DATA)
    time.sleep(minrate)
    for i in range(0, rate):
        rate_limited_function(TEST_DATA)
    time.sleep(minrate)

   

# Generated at 2022-06-20 15:28:16.279090
# Unit test for function retry_never
def test_retry_never():
    """Tests the function retry_never"""
    assert callable(retry_never)
    assert not retry_never("")
    assert not retry_never(None)
    assert not retry_never(Exception("test"))

# Generated at 2022-06-20 15:28:20.304272
# Unit test for function retry
def test_retry():
    """
    The function retry should run the function 2 times,
    return the 3rd, and raise the exception
    """
    counter = 0

    def test_function():
        nonlocal counter
        counter += 1
        if counter < 3:
            raise Exception("test")

        return counter

    wrapped_test_function = retry_with_delays_and_condition(generate_jittered_backoff())(test_function)

    assert wrapped_test_function() == 3
    assert counter == 3

    try:
        wrapped_test_function()
    except Exception:
        pass

    assert counter == 5

# Generated at 2022-06-20 15:28:27.237422
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=1)
    def my_problem():
        failed = {}
        if not failed:
            failed = 1
            raise Exception("this failed")
        return failed

    try:
        my_problem()
    except Exception as e:
        assert isinstance(e, Exception)

    @retry(retries=3, retry_pause=1)
    def my_problem2():
        failed = {}
        if not failed:
            failed = 1
        return failed

    assert my_problem2() == 1

if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-20 15:29:14.985669
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Unit test for function retry_with_delays_and_condition.

    This test verifies that retrying with the backoff_iterator and retry_condition set to their default values
    doesn't call the wrapped function more than once.
    """
    called_count = [0]
    class Error(Exception):
        pass

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=retry_never)
    def function():
        called_count[0] += 1
        # raise Error()
        return 0
    function()
    assert called_count[0] == 1

# Generated at 2022-06-20 15:29:20.031139
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(api_username=dict(type='str'), api_password=dict(type='str', no_log=True), api_url=dict(type='str'), validate_certs=dict(type='bool', default=True))

# Generated at 2022-06-20 15:29:24.680694
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = generate_jittered_backoff()
    number_of_retries = 5

    @retry_with_delays_and_condition(backoff_iterator)
    def test_function(retries):
        nonlocal number_of_retries
        number_of_retries -= 1
        if number_of_retries > 0:
            raise Exception("Fail")
        return "Success"

    assert test_function(number_of_retries) == "Success"



# Generated at 2022-06-20 15:29:32.141069
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [delay for delay in generate_jittered_backoff()]
    min1, min2, min3, min4, min5, max6, max7, max8, max9, max10 = delays
    assert min5 == min4
    assert min5 == min3
    assert min5 == min2
    assert min5 == min1
    assert max6 == max7
    assert max6 == max8
    assert max6 == max9
    assert max6 == max10

# Generated at 2022-06-20 15:29:42.837627
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec == {'api_url': {'type': 'str'},
                        'api_username': {'type': 'str'},
                        'api_password': {'type': 'str', 'no_log': True},
                        'validate_certs': {'type': 'bool', 'default': True}}
    arg_spec = basic_auth_argument_spec(dict(api_key=dict(required=True)))

# Generated at 2022-06-20 15:29:48.231419
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    result_status = {
        "result": False
    }

    def should_retry_error(exception):
        return isinstance(exception, RuntimeError)

    def run_retryable_function():
        if result_status["result"] is False:
            result_status["result"] = True
            raise RuntimeError("retry_with_delays_and_condition failed")
        else:
            return "retry_with_delays_and_condition passed"

    retryable_function = retry_with_delays_and_condition(generate_jittered_backoff(),
                                                         should_retry_error=should_retry_error)(run_retryable_function)
    assert retryable_function() == "retry_with_delays_and_condition passed"

# Generated at 2022-06-20 15:29:50.446928
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg = basic_auth_argument_spec()
    assert len(arg) == 4



# Generated at 2022-06-20 15:30:00.500840
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import random
    import pytest
    def random_values_in_range(count, min_value, max_value):
        values = []
        for _ in range(count):
            value = random.randint(0, max_value)
            values.append(value)
        for value in values:
            assert min_value <= value <= max_value
        return values

    def test_generate_jittered_backoff_range(retries, delay_base, delay_threshold):
        backoff_generator = generate_jittered_backoff(retries, delay_base, delay_threshold)
        backoff_values = random_values_in_range(retries, 0, delay_threshold)
        for expected_value, actual_value in zip(backoff_values, backoff_generator):
            assert expected_

# Generated at 2022-06-20 15:30:05.196577
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }

# Generated at 2022-06-20 15:30:09.135106
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert rate_limit_argument_spec(dict(test_key=dict(test_value='test'))) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        test_key=dict(test_value='test')
    )
