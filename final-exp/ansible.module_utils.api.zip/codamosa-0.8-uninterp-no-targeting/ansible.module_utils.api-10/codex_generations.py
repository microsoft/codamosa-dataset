

# Generated at 2022-06-20 15:20:42.085509
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    args = dict(api_username='user', api_password='secret', api_url='http://localhost', validate_certs=True)
    assert basic_auth_argument_spec() == args

# Generated at 2022-06-20 15:20:43.795175
# Unit test for function retry_never
def test_retry_never():
    try:
        if retry_never(None) == False:
            return True
    except Exception:
        return False


# Generated at 2022-06-20 15:20:51.027315
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate = (1, 5)
    rate_limit = (10, 100)
    for r, rl in zip(rate, rate_limit):
        spec = dict(rate=r, rate_limit=rl)
        assert basic_auth_argument_spec(spec) == {
            'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True}, 'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True},
            'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}
        }


# Generated at 2022-06-20 15:20:55.945525
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    arg_spec = rate_limit_argument_spec()

    result = arg_spec == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}

    return result


# Generated at 2022-06-20 15:20:57.721090
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Check the list is not empty
    list = generate_jittered_backoff()
    assert list.__length_hint__() > 0
    # Check a sample value
    assert next(list) >= 0

# Generated at 2022-06-20 15:20:59.631717
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("Test exception")) == False



# Generated at 2022-06-20 15:21:01.109498
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(1) == False



# Generated at 2022-06-20 15:21:03.163797
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}



# Generated at 2022-06-20 15:21:15.372003
# Unit test for function retry
def test_retry():

    counter = 0

    @retry()
    def raiser(cnt):
        global counter
        counter += 1
        if cnt != counter:
            raise Exception()
        return True

    @retry(retries=2)
    def raiser(cnt):
        global counter
        counter += 1
        if cnt != counter:
            raise Exception()
        return True

    @retry(retries=3, retry_pause=2)
    def raiser(cnt):
        global counter
        counter += 1
        if cnt != counter:
            raise Exception()
        return True

    # double the time on a failure
    @retry(retries=8, retry_pause=2)
    def raiser(cnt):
        global counter
        counter += 1

# Generated at 2022-06-20 15:21:21.669316
# Unit test for function rate_limit
def test_rate_limit():
    # print(rate_limit(10, 1))
    # print(rate_limit())
    # print(rate_limit(10))
    # print(rate_limit(rate=10))

    # print(retry())
    # print(retry(retries=10))
    print(retry_argument_spec())
    # print(rate_limit_argument_spec())

if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-20 15:21:40.524341
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert_equal(arg_spec['rate']['type'], 'int')
    assert_equal(arg_spec['rate_limit']['type'], 'int')
    assert_true('default' not in arg_spec['rate'])
    assert_true('default' not in arg_spec['rate_limit'])

    arg_spec = rate_limit_argument_spec({'rate': dict(type='int', default=1)})
    assert_equal(arg_spec['rate']['type'], 'int')
    assert_equal(arg_spec['rate_limit']['type'], 'int')
    assert_equal(arg_spec['rate']['default'], 1)
    assert_true('default' not in arg_spec['rate_limit'])

# Generated at 2022-06-20 15:21:48.610673
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    call_count = [0]
    should_retry_error_count = [0]
    class ExceptionA(Exception):
        pass
    class ExceptionB(Exception):
        pass

    def function_a():
        call_count[0] += 1
        raise ExceptionA("exception A")

    def function_b():
        call_count[0] += 1
        raise ExceptionB("exception B")

    def function_c():
        call_count[0] += 1
        return "abc"

    def should_retry_error(e):
        should_retry_error_count[0] += 1
        if isinstance(e, ExceptionA):
            return True
        elif isinstance(e, ExceptionB):
            return False
        else:
            assert(False)

    decorated_a = retry_with

# Generated at 2022-06-20 15:21:55.508942
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    Example test that functions as a unit test for retry_with_delays_and_condition
    This can be run directly to validate changes to the decorator
    """
    import unittest
    # python 2/3 compatibility
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch
    from ansible.module_utils.basic import AnsibleModule

    class RetryWithDelaysAndConditionTest(unittest.TestCase):
        def setUp(self):
            self.patch_module = patch('ansible.module_utils.basic.AnsibleModule')
            self.mock_module = self.patch_module.start()
            self.module_instance = self.mock_module.return_value

# Generated at 2022-06-20 15:22:07.564787
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit"""
    rate_limit_test_function_call_times = []
    last_time = time.time()

    @rate_limit(rate=2, rate_limit=2)
    def test_function(arg):
        """
        This function sleeps for time_to_sleep seconds.
        Then it adds this time to the rate_limit_test_function_call_times list.
        :param arg: sleep time
        """
        time.sleep(arg)
        rate_limit_test_function_call_times.append(time.time() - last_time)

    # Call the function and add the time taken to call it to rate_limit_test_function_call_times
    test_function(1)
    test_function(1)
    test_function(1)

    assert rate_limit

# Generated at 2022-06-20 15:22:13.619818
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    modargs = dict(rate=10, rate_limit=60)
    testargs = dict(rate=10, rate_limit=60)
    result = rate_limit_argument_spec(testargs)
    assert testargs == result, "rate limit argument spec failed"
    assert modargs == result, "rate limit argument spec failed"



# Generated at 2022-06-20 15:22:14.903089
# Unit test for function retry_never
def test_retry_never():
    assert(retry_never(None) is False)


# Generated at 2022-06-20 15:22:26.656507
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    '''
    Unit test for function rate_limit_argument_spec
    '''
    module = AnsibleModule()
    arg_spec = rate_limit_argument_spec()
    module.argument_spec = arg_spec
    module.params = dict(rate=5, rate_limit=60)
    args = rate_limit(rate=module.params['rate'], rate_limit=module.params['rate_limit'])

    # Build a dummy function that counts the number of times it is called.
    # We will use this to make sure our rate_limit decorator does what it should.
    calls = 0
    @args
    def test_func():
        nonlocal calls
        calls += 1

    # Make sure we have decorated our function
    assert test_func.__name__ == 'ratelimited'

    # Now make sure it is actually

# Generated at 2022-06-20 15:22:33.246635
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # No upper bound.
    delay_threshold = 60
    delays = generate_jittered_backoff(retries=10, delay_threshold=delay_threshold)
    expected_max_delay_threshold = delay_threshold
    expected_min_delay_threshold = 0
    actual_max_delay_threshold = max(delays)
    actual_min_delay_threshold = min(delays)
    assert expected_max_delay_threshold == actual_max_delay_threshold
    assert expected_min_delay_threshold == actual_min_delay_threshold

    # Upper bound less than a retry.
    delay_threshold = 1
    delays = generate_jittered_backoff(retries=10, delay_threshold=delay_threshold)
    expected_max_delay_threshold = delay_

# Generated at 2022-06-20 15:22:36.904424
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = {'required': True, 'type': 'str'}
    ret_value = rate_limit_argument_spec(arg_spec)
    assert type(ret_value) is dict
    assert 'rate' in ret_value
    assert 'rate_limit' in ret_value
    return True



# Generated at 2022-06-20 15:22:38.949132
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never("")
    assert not retry_never(Exception())

# Generated at 2022-06-20 15:22:50.531200
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    class DummyRetryableException(Exception):
        """A dummy exception for the unit test."""

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=lambda error: isinstance(error, DummyRetryableException))
    def _raise_exception(count):
        """A dummy function for the unit test."""
        if count == 0:
            raise DummyRetryableException()
        return True

    assert _raise_exception(0) == True

# Generated at 2022-06-20 15:22:54.478178
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=1)
    def call_with_one_second_rate_limit():
        print('Calling...')

    # This should call every second
    for i in range(1, 10):
        call_with_one_second_rate_limit()



# Generated at 2022-06-20 15:23:00.758226
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """Unit test for rate_limit_argument_spec"""
    expected_spec = (dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        name=dict()
    ))

    spec = rate_limit_argument_spec(
        dict(name=dict())
    )

    assert spec == expected_spec



# Generated at 2022-06-20 15:23:04.661611
# Unit test for function retry
def test_retry():
    @retry(retries=2)
    def test_function(x, y):
        if z < 3:
            z = z + 1
            raise Exception
        else:
            return x+y

    z = 0
    result = test_function(5,5)
    assert result == 10
    assert z == 2

# Generated at 2022-06-20 15:23:05.225452
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    basic_auth_argument_spec()

# Generated at 2022-06-20 15:23:11.027639
# Unit test for function retry
def test_retry():
    class TestException(Exception):
        pass

    called = [0]

    @retry(retry_pause=0)
    def never_call():
        called[0] += 1
        raise TestException()

    with pytest.raises(TestException):
        never_call()

    assert called[0] == 11

# Generated at 2022-06-20 15:23:16.866402
# Unit test for function rate_limit
def test_rate_limit():
    min_wait = 3
    max_wait = 3.5
    @rate_limit(rate=1, rate_limit=1)
    def test_rate_limit():
        return time.time()

    start = test_rate_limit()
    end = test_rate_limit()
    e = end - start
    assert e > min_wait and e < max_wait, 'rate_limit seems to be broken'


# Generated at 2022-06-20 15:23:17.700121
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) is False

# Generated at 2022-06-20 15:23:21.576704
# Unit test for function retry_never
def test_retry_never():
    from ansible.module_utils.six import PY2
    if PY2:
        import pytest
        with pytest.raises(RuntimeError) as excinfo:
            retry_never(Exception('Ooops'))
        assert 'never' in str(excinfo.value)

# Generated at 2022-06-20 15:23:27.378443
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    argument_spec = basic_auth_argument_spec({})

    assert argument_spec['api_username'] == {'type': 'str'}
    assert argument_spec['api_password'] == {'type': 'str', 'no_log': True}
    assert argument_spec['api_url'] == {'type': 'str'}
    assert argument_spec['validate_certs'] == {'type': 'bool', 'default': True}

# Generated at 2022-06-20 15:23:48.181636
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec(
        dict(
            retries=dict(type='int', default=15),
            retry_pause=dict(type='float', default=0.5)
        ))
    assert spec == dict(
        retries=dict(type='int', default=15),
        retry_pause=dict(type='float', default=0.5)
    )

# Generated at 2022-06-20 15:23:56.426340
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Non-retryable exception
    with pytest.raises(ZeroDivisionError):
        @retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=lambda x: isinstance(x, ZeroDivisionError))
        def divide_by_zero():
            return 2.0/0.0
        divide_by_zero()

    # Retryable exception
    @retry_with_delays_and_condition(backoff_iterator=[1, 2, 3], should_retry_error=lambda x: isinstance(x, ZeroDivisionError))
    def divide_by_zero():
        return 2.0/0.0
    with pytest.raises(ZeroDivisionError):
        divide_by_zero()

    # Retryable exception with success

# Generated at 2022-06-20 15:24:08.291634
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import random

    import pytest

    class Error(Exception): pass
    class Error1(Error): pass
    class Error2(Error): pass

    def should_retry_error(exception):
        return isinstance(exception, Error1)

    @retry_with_delays_and_condition(backoff_iterator=[1, 2])
    def do_things():
        '''Do some things.
        This function raises an exception if the random int is even.
        Return True if the random int is odd.
        '''
        if random.randint(1, 10) % 2 == 0:
            raise Error()
        return True

    with pytest.raises(Error):
        do_things()


# Generated at 2022-06-20 15:24:11.987138
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    count = 0
    for delay in generate_jittered_backoff(retries=20, delay_base=3, delay_threshold=60):
        assert 0 <= delay <= 60
        count += 1
    assert count == 20

# Generated at 2022-06-20 15:24:19.003618
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    def test_function():
        pass

    test_function = retry(retries=10, retry_pause=1)(test_function)
    assert test_function.__name__ == 'test_function'
    assert test_function.__module__ == 'ansible_collections.ansible.netcommon.plugins.modules.network.api'

# Generated at 2022-06-20 15:24:28.114328
# Unit test for function retry
def test_retry():
    """Unit test for function retry"""
    # Simple return value
    @retry
    def foo():
        return 'foo'

    assert foo() == 'foo'

    # Simple return value w/ retries
    @retry(retries=3)
    def foo2():
        return 'foo'

    assert foo2() == 'foo'

    # No return value w/ retries
    @retry(retries=3)
    def foo3():
        pass

    foo3()

    # Raises exception on third try
    @retry(retries=3, retry_pause=None)
    def foo4():
        foo4.count += 1
        if foo4.count < 3:
            raise Exception
        return 'foo'

    foo4.count = 0

# Generated at 2022-06-20 15:24:40.111890
# Unit test for function rate_limit
def test_rate_limit():
    """ test rate limiting """
    @rate_limit(rate=2, rate_limit=60)
    def foo(x):
        """i'll be rate limited"""
        return x

    @retry(retries=3)
    @rate_limit(rate=2, rate_limit=60)
    def bar(x):
        """i'll be rate limited and retried"""
        if x > 2:
            return x

        raise RuntimeError('fail!')

    @rate_limit(rate=1, rate_limit=60)
    def big_foo(x):
        """i'm rate limited to 1 a minute, but I have lots to do"""
        for i in range(0, x):
            foo(x)


# Generated at 2022-06-20 15:24:41.636230
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) == False

# Unit tests for function generate_jittered_backoff

# Generated at 2022-06-20 15:24:44.726618
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    assert module.params['api_username'] == None
    assert module.params['api_password'] == None
    assert module.params['api_url'] == None
    assert module.params['validate_certs'] == True

# Generated at 2022-06-20 15:24:56.002436
# Unit test for function retry
def test_retry():
    @retry(retries=2, retry_pause=1)
    def test_retries_3(num):
        print("test retries %d" % num)
        if num > 0:
            raise Exception("test retries")
        return num

    assert test_retries_3(1) == 0

    @retry(retries=3, retry_pause=1)
    def test_retries_3(num):
        print("test retries %d" % num)
        if num > 0:
            raise Exception("test retries")
        return num

    assert test_retries_3(1) == 0

    @retry(retries=2, retry_pause=1)
    def test_retries_3(num):
        print("test retries %d" % num)

# Generated at 2022-06-20 15:25:23.069367
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """The "Full Jitter" backoff strategy.

    Ref: https://www.awsarchitectureblog.com/2015/03/backoff.html

    :param retries: The number of delays to generate.
    :param delay_base: The base time in seconds used to calculate the exponential backoff.
    :param delay_threshold: The maximum time in seconds for any delay.
    """
    result = []
    for delay in generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60):
        result.append(delay)
    assert len(result) == 10
    assert 0 <= result[0] <= delay_threshold
    assert 0 <= result[1] <= delay_threshold
    assert 0 <= result[2] <= delay_threshold
    assert 0 <= result[3] <= 6


# Generated at 2022-06-20 15:25:24.815009
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(1) is False
    assert retry_never(Exception) is False


# Generated at 2022-06-20 15:25:27.611686
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for x in generate_jittered_backoff(delay_base=10, retries=10):
        print(x)

# Invoke unit test
if __name__ == '__main__':
    test_generate_jittered_backoff()

# Generated at 2022-06-20 15:25:36.374433
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(rate=10, rate_limit=10)
    def foo():
        print("rate_limit passed")
        return True

    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert foo()
    assert not foo()
    time.sleep(1)
    assert foo()
    assert not foo()
    assert foo()
    assert foo()
    assert foo()
    # I give up, it works



# Generated at 2022-06-20 15:25:40.967804
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert arg_spec == {'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True}, 'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}}

# Generated at 2022-06-20 15:25:48.531998
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import pytest

    trace = []
    for delay in generate_jittered_backoff(retries=1, delay_threshold=2, delay_base=1):
        trace.append(delay)
        assert delay <= 2

    assert trace == [0] or trace == [1]

    trace = []
    for delay in generate_jittered_backoff(retries=5, delay_threshold=10, delay_base=2):
        trace.append(delay)
        assert delay <= 10

    assert len(trace) == 5

# Generated at 2022-06-20 15:25:49.661517
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False


# Generated at 2022-06-20 15:25:50.258573
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert None != basic_auth_argument_spec()

# Generated at 2022-06-20 15:25:55.319460
# Unit test for function retry_never
def test_retry_never():

    retries = 10
    errors = [Exception(), KeyError()]

    for i in range(retries):
        for e in errors:
            retry_result = retry_never(e)
            assert retry_result == False


# Unit test retry_with_delays_and_condition

# Generated at 2022-06-20 15:26:01.026874
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_sequence = list(generate_jittered_backoff(retries=20, delay_base=1, delay_threshold=60))
    assert len(backoff_sequence) == 20
    assert backoff_sequence[0] <= 2
    assert backoff_sequence[1] <= 4
    assert backoff_sequence[19] <= 60

# Generated at 2022-06-20 15:26:40.808638
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())

    module.params['api_username'] = 'frodo'
    module.params['api_password'] = 'baggins'
    module.params['api_url'] = 'http://www.example.com'
    module.params['validate_certs'] = False

    assert 'api_username' in module.params
    assert 'api_password' in module.params
    assert 'api_url' in module.params
    assert 'validate_certs' in module.params


# Generated at 2022-06-20 15:26:48.778541
# Unit test for function retry
def test_retry():
    # Test retry with no retry limit
    @retry()
    def foo():
        return True
    bar = foo()
    assert bar

    # Test retry with retry limit
    retries = 2
    @retry(retries=retries)
    def foo_error():
        raise Exception("Error")
    try:
        foo_error()
    except Exception as e:
        # Test the correct number of attempts are made
        assert retries + 1 == foo_error.retry_count
        assert "Error" in e.args[0]


# Generated at 2022-06-20 15:26:50.044804
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never("fake_error")


# Generated at 2022-06-20 15:27:00.805263
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    from ansible.module_utils.basic import AnsibleModule

    backoff = generate_jittered_backoff()

    def my_function(name):
        raise Exception("Error: {}".format(name))

    def my_result_ok(result):
        return result == 'hello'

    def my_should_retry(_):
        return False

    retry_with_delays_and_condition(backoff, my_should_retry)(my_function)('world')

    result = retry_with_delays_and_condition(backoff, my_result_ok)(my_function)('hello')
    assert result == 'hello'

    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str'),
        result=dict(type='bool', default=False)
    ))


# Generated at 2022-06-20 15:27:05.994717
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    data = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )
    assert(basic_auth_argument_spec() == data)

# Generated at 2022-06-20 15:27:12.625283
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    should_retry_error = lambda e: e.code == 500

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error)
    def test_function():
        return True  # OR let the test function raise an Exception to test retry

    @retry_with_delays_and_condition(generate_jittered_backoff(0))
    def test_function_with_no_retries():
        return True  # OR let the test function raise an Exception to test retry

    assert test_function() == True
    assert test_function_with_no_retries() == True



# Generated at 2022-06-20 15:27:21.868151
# Unit test for function retry
def test_retry():

    global count
    count = 0

    @retry(retries=3)
    def fail_retry():
        global count
        count += 1
        if count < 2:
            return False
        return True

    assert fail_retry()
    assert count == 2

    count = 0

    @retry(retries=3)
    def fail_retry_exception():
        global count
        count += 1
        if count < 2:
            raise Exception("Fail")
        return True

    try:
        fail_retry_exception()
    except Exception as e:
        assert False, "Should not raise exception"



# Generated at 2022-06-20 15:27:27.160928
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    jittered_backoff = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)

    # Generate list
    jittered_backoff_list = list(jittered_backoff)

    # Check if list has at least one element
    assert len(jittered_backoff_list) > 0

    # Check if all elements are integers
    for item in jittered_backoff_list:
        assert isinstance(item, int)


# Generated at 2022-06-20 15:27:33.411067
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Test retry argument specification"""
    arg_spec = retry_argument_spec(dict(
        retries=dict(type='int', default=5),
        retry_pause=dict(type='float')
    ))
    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retry_pause']['type'] == 'float'
    assert arg_spec['retries']['default'] == 5



# Generated at 2022-06-20 15:27:37.261917
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)

    for i, delay in enumerate(backoff):
        assert 0 <= delay <= 60
        assert delay > 0 or i == 0

    assert i == 9

# Generated at 2022-06-20 15:28:17.169340
# Unit test for function retry
def test_retry():
    """Simple test for the retry function above"""
    import argparse

    parser = argparse.ArgumentParser(description='Test function wrap')
    parser.add_argument('--retries', type=int, default=None)
    parser.add_argument('--rate', type=float, default=None)

    args = parser.parse_args()

    @retry(retries=args.retries, retry_pause=args.rate)
    def success_after_three():
        success_after_three.attempts += 1
        if success_after_three.attempts > 3:
            return 1
        return None

    # Set variable for retry to work
    success_after_three.attempts = 0
    result = success_after_three()
    print("result: %s" % (result,))
   

# Generated at 2022-06-20 15:28:21.348770
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )



# Generated at 2022-06-20 15:28:28.700483
# Unit test for function rate_limit
def test_rate_limit():
    import random
    import time

    class Foo:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    @rate_limit(rate=10, rate_limit=1.)
    def rate_limited_function(self):
        time.sleep(random.random())
        print("Running rate limited function with args %s and kwargs %s" % (self.args, self.kwargs))
        return True

    foo = Foo([1, 2, 3], a='b')
    print(rate_limited_function(foo))
    print(rate_limited_function(foo))
    print(rate_limited_function(foo))
    time.sleep(1.1)
    print(rate_limited_function(foo))



# Generated at 2022-06-20 15:28:37.939967
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        test=dict(type='int', default=1)
    )
    with_rate_limit = rate_limit_argument_spec(spec)

    assert(len(spec) == len(with_rate_limit))
    assert('test' in with_rate_limit)
    assert('rate' in with_rate_limit)
    assert('rate_limit' in with_rate_limit)

    assert(with_rate_limit['test']['type'] == 'int')
    assert(with_rate_limit['test']['default'] == 1)

    assert(with_rate_limit['rate']['type'] == 'int')
    assert('default' not in with_rate_limit['rate'])

    assert(with_rate_limit['rate_limit']['type'] == 'int')

# Generated at 2022-06-20 15:28:48.886256
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    def function_succeeds_on_first_attempt():
        return True

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_never)
    def function_fails_on_first_attempt_then_succeeds():
        try:
            raise Exception("An expected error that would normally cause a retry")
        except Exception:
            return True


# Generated at 2022-06-20 15:28:52.992109
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    args_spec = (dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    ))
    args_actual = retry_argument_spec()

    assert args_spec == args_actual

# Generated at 2022-06-20 15:28:57.872771
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(retries=5, delay_base=5, delay_threshold=60)
    backoff_list = []
    for delay in backoff_iterator:
        backoff_list.append(delay)
    assert backoff_list == [49, 5, 44, 33, 48]

# Generated at 2022-06-20 15:29:06.546298
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }

    assert rate_limit_argument_spec({'first': 'one', 'second': 'two'}) == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'},
        'first': 'one',
        'second': 'two'
    }


# Generated at 2022-06-20 15:29:10.885258
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = retry_argument_spec()
    assert 'retries' in argument_spec
    assert argument_spec['retries']['type'] == 'int'
    assert 'retry_pause' in argument_spec
    assert argument_spec['retry_pause']['type'] == 'float'

# Generated at 2022-06-20 15:29:20.987731
# Unit test for function rate_limit
def test_rate_limit():
    rate = 2
    rate_limit = 3
    minrate = float(rate_limit) / float(rate)
    function_rate_limited = rate_limit(rate, rate_limit)(test_function)
    elapsed = 0
    last_call = 0
    num_calls = 10
    for _ in range(num_calls):
        current_call = time.time()
        function_rate_limited()
        elapsed += time.time() - current_call
        if (time.time() - last_call) < minrate:
            return False
        last_call = time.time()

    if (elapsed / num_calls) > minrate:
        return False

    return True


# Generated at 2022-06-20 15:30:07.988573
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def raise_something_error():
        raise Exception

    retry_never_decorator = retry_with_delays_and_condition(iter([1]))
    assert retry_never_decorator(raise_something_error)() is None

    def raise_something_else_error():
        raise Exception

    retry_always_decorator = retry_with_delays_and_condition(iter([1]))
    try:
        retry_always_decorator(raise_something_else_error)()
        assert False
    except Exception:
        pass

    retries_5_times_decorator = retry_with_delays_and_condition(iter([]), should_retry_error=lambda e: True)

# Generated at 2022-06-20 15:30:11.543017
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    expected_results = [0, 0, 1, 0, 4, 0, 0, 4, 0, 0]
    results = []
    for delay in generate_jittered_backoff():
        results.append(delay)
    assert results == expected_results

# Generated at 2022-06-20 15:30:14.732407
# Unit test for function retry
def test_retry():
    """Unit test decorator function.
    """
    def test_function():
        return True
    test_function_decorated = retry()(test_function)
    assert test_function_decorated()

# Generated at 2022-06-20 15:30:24.968736
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """
    Runs a test on function retry_argument_spec
    """
    import pytest
    from ansible.module_utils.connection import Connection

    result = Connection.add_context({'arg_spec': retry_argument_spec()})
    assert 'retries' in result
    assert result['retries'] == dict(default=None, type='int')

    result = Connection.add_context({'arg_spec': retry_argument_spec({'arg1': {'type': 'str'}})})
    assert 'arg1' in result
    assert result['arg1'] == dict(type='str')
    assert 'retries' in result
    assert result['retries'] == dict(default=None, type='int')


# Generated at 2022-06-20 15:30:28.509055
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = (dict(
        test=dict(type='str'),
    ))
    assert rate_limit_argument_spec(spec) == {'rate_limit': dict(type='int'), 'rate': dict(type='int'), 'test': dict(type='str')}