

# Generated at 2022-06-20 15:20:46.103939
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # We don't really need to test the backoff generator, so we ignore the input
    def _generate_delays(retries=10, delay_base=3, delay_threshold=60):
        yield 1
        yield 2

    def always_retry_error(_):
        return True

    def never_retry_error(_):
        return False

    called = []
    @retry_with_delays_and_condition(_generate_delays(retries=3), always_retry_error)
    def retry_3_times(arg):
        called.append(arg)
        raise RuntimeError('Retry 3 times')
    assert retry_3_times(1) is None
    assert called == [1, 1, 1]

    called = []

# Generated at 2022-06-20 15:20:55.415239
# Unit test for function rate_limit
def test_rate_limit():
    global rate_limit_calls, rate_limit_last
    rate_limit_calls = 0
    rate_limit_last = [0.0]

    @rate_limit(10, 60)
    def rate_limited_function_test():
        global rate_limit_calls, rate_limit_last
        rate_limit_calls += 1
        dt = time.time() - rate_limit_last[0]
        rate_limit_last[0] = time.time()
        # time between calls should not be faster than 6 seconds
        # except the first call
        assert dt >= 0.0
        assert rate_limit_calls == 1 or dt >= 6.0
        return True

    # test rate limiting
    for i in range(0, 10):
        rate_limited_function_test()

    # test

# Generated at 2022-06-20 15:20:58.914162
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    test_input = {"key1":"val1", "key2":"val2"}
    expected_output = {'key1': 'val1', 'key2': 'val2', 'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}

    output = retry_argument_spec(test_input)
    assert output == expected_output

# Generated at 2022-06-20 15:21:04.919824
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # input argument
    spec = {'validate_certs': dict(type='bool', default=True)}
    # call function to test
    result = basic_auth_argument_spec(spec)

    # expected result
    expected_result = {
        'api_username': dict(type='str'),
        'api_password': dict(type='str', no_log=True),
        'api_url': dict(type='str'),
        'validate_certs': dict(type='bool', default=True)
    }

    # compare the result with expected result
    assert result == expected_result

# Generated at 2022-06-20 15:21:11.486643
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = [1, 2, 3]

    @retry_with_delays_and_condition(backoff_iterator)
    def always_raises(msg=None, *_, **__):
        raise Exception(msg)

    try:
        always_raises('first', 'second', 3, ['list'])
    except:
        pass



# Generated at 2022-06-20 15:21:16.955173
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # pylint: disable=unused-argument
    def test_function(arg1, arg2, retries=None, retry_pause=1):
        pass

    retry_function = retry(retries=5, retry_pause=1.5)(test_function)
    assert retry_function.__name__ == "test_function"

    try:
        retry_function(1, 2)
    except Exception:
        assert False, "retry function threw exception"


# Generated at 2022-06-20 15:21:25.671219
# Unit test for function retry
def test_retry():
    count = [0]
    @retry(retries=1, retry_pause=1)
    def retry_function():
        count[0] += 1
        raise Exception("%d attempt" % count[0])
    # only one attempt, raises exception
    try:
        retry_function()
        assert False, "should not get here!"
    except Exception as e:
        assert e.message == "2 attempt"
    # two attempts
    @retry(retries=3, retry_pause=.1)
    def retry_function():
        count[0] += 1
        if count[0] < 3:
            raise Exception("%d attempt" % count[0])
        return True
    assert retry_function()
    count = [0]
    # never retry

# Generated at 2022-06-20 15:21:30.502851
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    base_dict = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )
    assert basic_auth_argument_spec() == base_dict

# Generated at 2022-06-20 15:21:33.150890
# Unit test for function retry
def test_retry():
    @retry(retries=5)
    def get_result():
        print("attempting")
        if True:
            return "success!"

    assert get_result() == "success!"


# Generated at 2022-06-20 15:21:33.918764
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False

# Generated at 2022-06-20 15:22:07.578907
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils import basic
    from ansible.module_utils.six import integer_types

    try:
        specs = retry_argument_spec()
        assert set(specs.keys()) == {'retries', 'retry_pause'}
        assert specs['retries']['type'] == 'int'
        assert specs['retry_pause']['type'] == 'float'
        assert specs['retry_pause']['default'] == 1
        assert isinstance(specs['retry_pause']['default'], integer_types)
    except Exception as e:
        assert False, "Retry argument spec unit test failed: %s" % to_text(e)

# Generated at 2022-06-20 15:22:18.444694
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    call_counts = []
    success_after_counts = []
    exceptions_seen = []
    should_retry_counts = []

    def call_count(n):
        def call_count_decorator(f):
            @functools.wraps(f)
            def wrapped_f(*args, **kwargs):
                call_counts.append(n)
                return f(*args, **kwargs)
            return wrapped_f
        return call_count_decorator

    def success_after(n):
        def success_after_decorator(f):
            @functools.wraps(f)
            def wrapped_f(*args, **kwargs):
                success_after_counts.append(n)
                return f(*args, **kwargs)
            return wrapped_f
       

# Generated at 2022-06-20 15:22:21.974854
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True},
    }

# Generated at 2022-06-20 15:22:31.174645
# Unit test for function retry
def test_retry():
    class ControlledError(Exception):
        pass

    @retry_with_delays_and_condition(itertools.chain([1, 2, 4, 8], itertools.repeat(60, 1)), should_retry_error=lambda e: isinstance(e, ControlledError))
    def callable_failing_once(should_fail):
        if should_fail:
            raise ControlledError("Should fail")
        return "Should succeed"

    assert callable_failing_once(should_fail=False) == "Should succeed"
    try:
        callable_failing_once(should_fail=True)
        assert False
    except ControlledError:
        pass
    try:
        callable_failing_once(should_fail=True)
        assert False
    except ControlledError:
        pass

# Generated at 2022-06-20 15:22:40.334154
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    # Empty test spec
    assert basic_auth_argument_spec() == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

    # No spec given
    u = 'abc'
    p = 'def'
    url = 'http://foo.bar'
    b = False
    assert basic_auth_argument_spec(dict(api_username=u, api_password=p, api_url=url, validate_certs=b)) == dict(
        api_username=u,
        api_password=p,
        api_url=url,
        validate_certs=b
    )

    # Spec given


# Generated at 2022-06-20 15:22:43.749672
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=60):
        print("Delay: " + str(delay))
        assert delay >= 0
        assert delay < 60

try:
    import ansible_collections
except ImportError:
    pass
else:
    del sys.modules['ansible_collections']

# Generated at 2022-06-20 15:22:47.171843
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert spec['rate']['type'] == 'int'
    assert spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-20 15:22:50.234893
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(rate=1, rate_limit=1)
    def one_per_second():
        return "done"

    assert one_per_second() == "done"

# Generated at 2022-06-20 15:22:57.826715
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = {
        'rate': dict(type='int', default=10),
        'rate_limit': dict(type='int', default=60),
        'retries': dict(type='int', default=5),
        'retry_pause': dict(type='float', default=5),
    }

    actual = retry_argument_spec()
    for key, value in actual.items():
        assert key in spec
        assert spec[key]['type'] == value['type']
        assert spec[key]['default'] == value['default']

# Generated at 2022-06-20 15:23:07.244093
# Unit test for function rate_limit
def test_rate_limit():
    """
    >>> import time
    >>> @rate_limit(rate=3)
    ... def test_rate_limit():
    ...     print(time.time())
    >>> test_rate_limit()
    1560983328.237099
    >>> test_rate_limit()
    1560983328.2374251
    >>> test_rate_limit()
    1560983328.237673
    >>> test_rate_limit()
    1560983329.238459
    >>> test_rate_limit()
    1560983329.2386062
    >>> test_rate_limit()
    1560983329.23879
    >>>

    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 15:23:29.545303
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.utils.module_docs import get_docstring
    argument_spec = basic_auth_argument_spec()
    assert argument_spec['api_username']['type'] == 'str'
    assert argument_spec['api_password']['type'] == 'str'
    assert argument_spec['api_url']['type'] == 'str'
    assert argument_spec['validate_certs']['type'] == 'bool'
    assert argument_spec['validate_certs']['default'] == True
    assert get_docstring(basic_auth_argument_spec, lines=False, style='restructuredtext')

# Generated at 2022-06-20 15:23:32.445109
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec({'a': {'type': 'int'}}) == {'a': {'type': 'int'}, 'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}


# Generated at 2022-06-20 15:23:40.085454
# Unit test for function retry
def test_retry():
    retry_count = 0
    retry_limit = 5
    retry_limit_reached = False

    @retry(retries=retry_limit)
    def always_fail():
        print("Triggered retry")
        nonlocal retry_count
        retry_count += 1
        if retry_count >= retry_limit:
            nonlocal retry_limit_reached
            retry_limit_reached = True
            return True
        else:
            return False

    always_fail()
    assert retry_limit_reached, "retry limit not reached"

# Generated at 2022-06-20 15:23:44.447063
# Unit test for function retry
def test_retry():
    """Check that retry uses the retries/retry_pause parameters"""
    @retry(retries=2, retry_pause=1)
    def mock_retry():
        return "retry"
    i = mock_retry()
    assert i == "retry"



# Generated at 2022-06-20 15:23:48.335041
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff = generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=120)
    assert len(list(backoff)) == 10
    assert max(backoff) <= 120
    assert min(backoff) >= 0



# Generated at 2022-06-20 15:23:54.929497
# Unit test for function retry_argument_spec
def test_retry_argument_spec():

    module = AnsibleModule(
        argument_spec=retry_argument_spec(),
        supports_check_mode=True
    )

    retries_expected = 4
    retry_pause_expected = 4.5
    module.params['retries'] = retries_expected
    module.params['retry_pause'] = retry_pause_expected

    retries_actual = module.params['retries']
    retry_pause_actual = module.params['retry_pause']

    assert retries_actual == retries_expected
    assert retry_pause_actual == retry_pause_expected

# Generated at 2022-06-20 15:24:06.568661
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    Call the retry_with_delays_and_condition function in all possible scenarios and verify that the retried function is called the appropriate number of times
    """
    # Test the retry function with a backoff iterator that has delays, but does not trigger the should_retry_error condition
    class ExceptionWithMessage(Exception):
        def __init__(self, message):
            self.message = message

    def error_not_matched(e):
        return e.message != 'retry me'

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=error_not_matched)
    def decorated_function_success(function_call_count):
        function_call_count['success'] += 1
        return True


# Generated at 2022-06-20 15:24:18.636352
# Unit test for function retry
def test_retry():
    """
    Test that the retry function decorator works
    """

    def raiser():
        """
        Raises an Exception.
        """
        raise Exception('Error')

    def retry_raiser(retries=2):
        """
        Raise exception through retry_raiser.
        """
        return raiser()

    @retry(retries=2)
    def retry_raiser_decorated(retries=2):
        """
        Raise exception through retry_raiser_decorated.
        """
        return raiser()

    try:
        retry_raiser()
        assert False
    except Exception:
        pass

    try:
        retry_raiser_decorated()
        assert False
    except Exception:
        pass

# Generated at 2022-06-20 15:24:20.863466
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec({'rate': dict(type='int')})
    assert(result == {'rate': dict(type='int')})

# Generated at 2022-06-20 15:24:22.884122
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert 7 in generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)

# Generated at 2022-06-20 15:24:43.272010
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3, delay_base=1, delay_threshold=2))
    def function(args):
        function.count += 1
        if function.count <= 2:
            raise Exception('failed')
        return True

    function.count = 0
    assert function()
    assert function.count == 3

# Generated at 2022-06-20 15:24:47.766196
# Unit test for function retry
def test_retry():
    retries = 0
    success = False

    @retry(retries=5, retry_pause=1)
    def test_function():
        global retries
        if not success:
            retries += 1
            raise Exception("Not yet")
        return True

    if retries != 5:
        raise Exception("unexpected retries %d != 5" % retries)
    success = True
    if not test_function():
        raise Exception("unexpected failure")
    if retries != 5:
        raise Exception("unexpected retries %d != 5" % retries)



# Generated at 2022-06-20 15:24:58.531236
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_threshold=1))
    def retry_once(exception_to_throw):
        if exception_to_throw is not None:
            raise exception_to_throw
        else:
            return "success"

    # retry for error
    assert retry_once(Exception("some error")) == "success"

    # retry once for ValueError
    assert retry_once(ValueError("another error")) == "success"

    # retry once for ValueError without error message
    assert retry_once(ValueError()) == "success"

    # retry once and return last error
    with pytest.raises(KeyError):
        retry_once(KeyError("key error"))



# Generated at 2022-06-20 15:25:02.213757
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_specs = rate_limit_argument_spec()
    assert "rate" in rate_limit_specs.keys()
    assert "rate_limit" in rate_limit_specs.keys()


# Generated at 2022-06-20 15:25:08.627687
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=3, rate_limit=1)
    def func():
        import time
        time.sleep(0.25)

    start = time.time()
    for i in range(0, 10):
        func()
    stop = time.time()
    elapsed = stop - start

    # Even with 10 calls, there should only be 1 second of execution time,
    # and even if all the time is sleep, it should be >= 0.75 seconds
    if elapsed < 1 or elapsed > 1.25:
        raise AssertionError("Expected rate limiting to take 1 second, took %f" % elapsed)



# Generated at 2022-06-20 15:25:13.539446
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        testa=dict(type='int'),
        testb=dict(type='str')
    )
    arg_spec = retry_argument_spec(spec)

    assert arg_spec == dict(
        testa=dict(type='int'),
        testb=dict(type='str'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )

# Generated at 2022-06-20 15:25:24.325432
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Basic
    assert list(generate_jittered_backoff(10, 1, 1)) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    # But we don't expect them all to be the same
    assert list(generate_jittered_backoff(10, 1, 1)) != [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    # Filtered jitter, since the jitter is max(delay_base, delay_threshold):
    assert list(generate_jittered_backoff(10, 1, 3)) == [0, 3, 3, 3, 3, 3, 3, 3, 3, 3]

    # Filtered jitter, since the jitter is max(delay_base, delay_threshold):

# Generated at 2022-06-20 15:25:27.539618
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec(spec=None)
    assert arg_spec.get('retries') == dict(type='int')
    assert arg_spec.get('retry_pause') == dict(type='float', default=1)


# Generated at 2022-06-20 15:25:39.090673
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=3, delay_base=1))
    def example_retryable_function():
        # This could be a query or blocking operation that throws an exception.
        raise Exception()

    # Do not retry if the exception is AssertionError
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=3, delay_base=1), should_retry_error=lambda e: not isinstance(e, AssertionError))
    def example_retryable_function_with_filter():
        # This could be a query or blocking operation that throws an exception.
        raise Exception()

    # Retry once, but do not retry if the exception is

# Generated at 2022-06-20 15:25:39.713918
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec is not None

# Generated at 2022-06-20 15:26:02.124372
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    assert module.params['api_username'] is None
    assert module.params['api_password'] is None
    assert module.params['api_url'] is None
    assert module.params['validate_certs'] is True

# Generated at 2022-06-20 15:26:07.156925
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert callable(basic_auth_argument_spec)
    assert basic_auth_argument_spec() == {'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True}, 'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}}


# Generated at 2022-06-20 15:26:10.684700
# Unit test for function retry
def test_retry():
    seen = []

    @retry(retries=3)
    def do_stuff(retries):
        if retries:
            seen.append('fail')
            raise Exception("failed")
        else:
            seen.append('ok')

    do_stuff(retries=2)
    assert seen == ['fail', 'fail', 'ok']



# Generated at 2022-06-20 15:26:13.081176
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception("test"))
    assert not retry_never("result")

# Generated at 2022-06-20 15:26:18.778870
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(rate=1, rate_limit=1)
    def foo(msg):
        """
        Function to test rate limiting in api/utils.py
        """
        return msg

    assert foo('a') == 'a'
    assert foo('b') is None
    time.sleep(1)
    assert foo('c') == 'c'
    assert foo('d') is None


# Generated at 2022-06-20 15:26:20.135472
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('anything') is False


# Generated at 2022-06-20 15:26:29.878721
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    import math
    import itertools

    class RetryWithDelaysAndConditionTest(unittest.TestCase):
        def setUp(self):
            self.call_count = 0

        @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=5))
        def always_fail(self):
            self.call_count += 1
            if self.call_count < 10:
                raise Exception("Failure %d" % self.call_count)
            return True

        def test_retry_10_times(self):
            self.assertEqual(self.always_fail(), True)
            self.assertEqual(self.call_count, 10)


# Generated at 2022-06-20 15:26:38.238858
# Unit test for function rate_limit
def test_rate_limit():
    """
    Test the rate_limit decorator

    We are just testing if it wraps correctly,
    rate_limiting requires real world testing.
    """

    @rate_limit()
    def rate_limited():
        pass

    @rate_limit(rate=1, rate_limit=1)
    def rate_limited():
        pass

    def not_rate_limited():
        pass

    assert rate_limited.__closure__
    assert not not_rate_limited.__closure__
    assert len(rate_limited.__closure__) == 2


# Generated at 2022-06-20 15:26:40.372969
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [x for x in generate_jittered_backoff()]
    assert delays == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-20 15:26:41.382653
# Unit test for function retry_never
def test_retry_never():
    return retry_never("test")

# Generated at 2022-06-20 15:27:22.674664
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    argument_spec = rate_limit_argument_spec()
    assert isinstance(argument_spec, Mapping)

    for arg in ('rate', 'rate_limit'):
        spec = argument_spec[arg]
        assert isinstance(spec, Mapping)
        assert spec['type'] == 'int'



# Generated at 2022-06-20 15:27:24.351533
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception())


# Generated at 2022-06-20 15:27:35.604024
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    print(list(generate_jittered_backoff()))
    print(list(generate_jittered_backoff(retries=3, delay_base=2, delay_threshold=60)))
    print(list(generate_jittered_backoff(retries=5, delay_base=2, delay_threshold=60)))
    print(list(generate_jittered_backoff(retries=10, delay_base=2, delay_threshold=5)))
    print(list(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=3)))
    print(list(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=0)))

if __name__ == '__main__':
    test_generate_

# Generated at 2022-06-20 15:27:42.697414
# Unit test for function rate_limit
def test_rate_limit():
    calls = [0, 0, 0]

    @rate_limit(rate=3, rate_limit=1)
    def my_method(index):
        calls[index] += 1
        return True

    for i in range(0, 100):
        my_method(0)
        my_method(1)
        my_method(2)

    assert (calls[0] == 3)
    assert (calls[1] == 3)
    assert (calls[2] >= 29 and calls[2] <= 33)


if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-20 15:27:49.558698
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    no_retries = functools.partial(retry_with_delays_and_condition, backoff_iterator, retry_never)
    retries = functools.partial(retry_with_delays_and_condition, backoff_iterator, retry_with_delays_and_condition.__wrapped__)

    def first_attempt_error(x):
        if x == 0:
            raise Exception("Error")
        return x

    # Ensure that the function is ran at least one time
    assert no_retries(first_attempt_error)(0) == 0
    assert retries(first_attempt_error)(0) == 0

    # Ensure the function is ran

# Generated at 2022-06-20 15:27:59.736118
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def test_function(foo, bar):
        if foo == bar:
            raise RuntimeError('foo == bar!')
        return foo + bar

    # Test exception condition
    decorated_test_function = retry_with_delays_and_condition(
        should_retry_error=retry_never,
        backoff_iterator=[0, 2, 4, 6, 8, 10],
    )(test_function)

    # Call the decorated function like we would a normal function
    result = decorated_test_function(5, 5)
    assert result == 10

    # Test exception condition
    try:
        decorated_test_function(5, 5)
    except RuntimeError as e:
        assert e.args[0] == 'foo == bar!'

    # Test function with default retry behavior
    decorated_test_function = retry

# Generated at 2022-06-20 15:28:06.797801
# Unit test for function rate_limit
def test_rate_limit():
    from ansible.module_utils import basic

    @rate_limit(rate_limit=1)
    def test():
        return time.time()

    start, last = time.time(), time.time()
    for i in range(0, 10):
        last = test()
    elapsed = time.time() - start
    basic.assertTrue(elapsed >= 1, "elapsed should be >= %d" % 1)
    basic.assertTrue(elapsed < 1.1, "elapsed should be < %d" % 1.1)



# Generated at 2022-06-20 15:28:08.335722
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        print(delay)



# Generated at 2022-06-20 15:28:11.461958
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert 'rate' in spec
    assert 'rate_limit' in spec
    assert 'rate' in spec['rate']
    assert 'rate_limit' in spec['rate']

# Generated at 2022-06-20 15:28:15.570376
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    result_list = []
    for delay in generate_jittered_backoff():
        result_list.append(delay)

    if result_list == [0, 7, 1, 6, 16, 34, 60, 60, 60, 60]:
        print("generate_jittered_backoff() works as expected.")
    else:
        print("generate_jittered_backoff() failed.")


# Unit tests

# Generated at 2022-06-20 15:29:30.524012
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    pass

# Generated at 2022-06-20 15:29:36.996306
# Unit test for function retry
def test_retry():
    """Test retry function"""
    counter = 0

    @retry(retries=2, retry_pause=0)
    def bad_func():
        """Bad code that raises exception when counter is low"""
        global counter
        counter += 1
        if counter > 5:
            return True
        raise Exception

    bad_func()
    if counter != 6:
        print("Error too many retries")
        exit(1)



# Generated at 2022-06-20 15:29:43.164929
# Unit test for function rate_limit
def test_rate_limit():
    import random

    class TestClass(object):
        CALLS = 0

        @rate_limit(rate=10, rate_limit=1)
        def test_rate(self):
            self.CALLS += 1
            return self.CALLS

    test = TestClass()
    for i in range(0, 100):
        test.test_rate()

    assert test.CALLS == 10, "rate limiting failed, got %s calls" % test.CALLS



# Generated at 2022-06-20 15:29:45.396706
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=1)
    def test():
        return True

    assert test() is True



# Generated at 2022-06-20 15:29:56.745531
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import numbers

    jittered_backoff = generate_jittered_backoff()
    assert isinstance(jittered_backoff, collections.Iterable)
    assert not isinstance(jittered_backoff, collections.Sequence)
    assert not isinstance(jittered_backoff, collections.Mapping)

    backoff_list = list(jittered_backoff)
    assert backoff_list
    assert all(isinstance(c, numbers.Integral) for c in backoff_list)

    jittered_backoff = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    backoff_list = list(jittered_backoff)

    assert len(backoff_list) == 10

# Generated at 2022-06-20 15:29:59.571112
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=None, rate_limit=None)
    def test_function():
        return True

    assert test_function() == True



# Generated at 2022-06-20 15:30:05.516628
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec({'additional_key': {'type': 'str'}}) == {'retries': {'type': 'int'},
                                                                       'retry_pause': {'type': 'float', 'default': 1},
                                                                       'additional_key': {'type': 'str'}}

# Generated at 2022-06-20 15:30:11.024471
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import copy
    test_arg_spec = {'required': ['src', 'dest'],
                     'options': {'diff': {'type': 'bool', 'default': False},
                                 'src': {'type': 'str'}},
                     'required_one_of': [['src', 'dest']],
                     'mutually_exclusive': [['src', 'dest']],
                     'defaults': {'diff': False}}

    @retry(retries=5, retry_pause=10)
    def test_function(arg1, retries, retry_pause, src, dest):
        return src, dest, retries, retry_pause

    new_arg_spec = copy.deepcopy(test_arg_spec)

# Generated at 2022-06-20 15:30:21.585777
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class Error1(Exception):
        pass

    class Error2(Error1):
        pass

    class Error3(Exception):
        pass

    def should_retry_error1_or_error2(ex):
        return isinstance(ex, Error1)

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=should_retry_error1_or_error2)
    def test_function():
        """The function being tested."""
        return 3

    def test_function_with_error1():
        raise Error1()

    def test_function_with_error2():
        raise Error2()

    def test_function_with_error3():
        raise Error3()

    # Should retry on Error1, Error2 and succeed
    assert test_

# Generated at 2022-06-20 15:30:28.233745
# Unit test for function retry
def test_retry():
    from ansible.module_utils.api import basic_auth_argument_spec
    from ansible.module_utils.api import retry_argument_spec
    from ansible.module_utils.api import rate_limit_argument_spec

    class MockModule(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, **kwargs):
            self.msg = kwargs
            self.fail_json = True
            raise Exception(kwargs)

    @rate_limit(10, 10)
    @retry(10, 1)
    def retry_me():
        return True

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def retry_me_never():
        raise Exception('foo')
