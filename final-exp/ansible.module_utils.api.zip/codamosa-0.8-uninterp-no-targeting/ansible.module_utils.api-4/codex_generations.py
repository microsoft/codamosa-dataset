

# Generated at 2022-06-20 15:20:47.522309
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

    result_with_value = rate_limit_argument_spec(dict(test='option'))
    assert result_with_value == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        test='option'
    )

    result_with_none = rate_limit_argument_spec(None)
    assert result_with_none == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )



# Generated at 2022-06-20 15:20:58.440558
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    Testing the retry_with_delay_and_condition function decorator

    We want to be able to make a function retry if an error is raised,
    but only if that error is something we want to retry.

    The function should retry upto the number of retry allowed,
    and if it still fails after that, it should raise the last error
    raised by the function
    """
    import random
    import pytest
    data = [{'a': 1}, {'b': 2}, {'c': 3}]

    def function_raises_exception(test_data, retry_count):
        """
        This function raises an exception randomly
        """
        if random.randint(1, 10) == 1:
            raise Exception('Random error raised for retry test')

        # This is to simulate failures even after

# Generated at 2022-06-20 15:21:06.033978
# Unit test for function retry
def test_retry():
    @retry(retries=3, retry_pause=1)
    def check_if_one():
        return 1

    @retry(retries=3, retry_pause=2)
    def check_if_one_second_random_pause():
        random.seed(1)
        return 1

    @retry(retries=3, retry_pause=1)
    def check_if_one_with_exception():
        if random.randint(0, 1) == 0:
            raise Exception('bad')
        return 1

    @retry(retries=3, retry_pause=1)
    def check_if_one_with_exception_and_second_random_pause():
        random.seed(1)
        if random.randint(0, 1) == 0:
            raise

# Generated at 2022-06-20 15:21:10.242813
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arguments = retry_argument_spec()
    for argument in ['retries', 'retry_pause']:
        if argument not in arguments or arguments[argument]['type'] != 'float':
            return False
    return True


# Generated at 2022-06-20 15:21:13.622807
# Unit test for function retry_never
def test_retry_never():
    for retry_value in [1, -1, "text", random.randint(0, 100)]:
        assert retry_never(retry_value) is False



# Generated at 2022-06-20 15:21:24.515551
# Unit test for function retry
def test_retry():
    import time

    def run_test(testname, error):
        @retry(retries=3, retry_pause=1)
        def thrower():
            raise error

        start = time.time()
        result = thrower()
        end = time.time()
        delay = end - start

        print("%s: %s" % (testname, result))
        print("time waited: %s" % delay)
        if isinstance(error, Exception):
            print("Error: %s" % error)
        else:
            print("Error: %s" % result)
    # end run_test

    run_test("happy path", True)
    run_test("retry 1", Exception())
    run_test("retry 2", Exception())
    run_test("fail", Exception())


# Generated at 2022-06-20 15:21:27.056361
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert isinstance(spec, dict)
    assert 'rate' in spec
    assert 'rate_limit' in spec


# Generated at 2022-06-20 15:21:30.129381
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    assert [x for x in generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=60)] == [0, 0, 0]



# Generated at 2022-06-20 15:21:33.012133
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict()
    spec = rate_limit_argument_spec(spec)
    assert spec == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

# Generated at 2022-06-20 15:21:35.652963
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    pass

# Generated at 2022-06-20 15:21:53.736777
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestException(Exception):
        pass

    class FailingError(TestException):
        pass

    class PassingError(TestException):
        pass

    retryable_error = PassingError
    not_retryable_error = FailingError

    retry_limit = len(list(generate_jittered_backoff()))

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=should_retry_error)
    def raise_exception_on_retries(retries):
        if retries > 0:
            raise retryable_error
        else:
            return 23

    def should_retry_error(error):
        if isinstance(error, retryable_error):
            return True
        else:
            return False


# Generated at 2022-06-20 15:21:56.282003
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(rate_limit_argument_spec())
    assert m.params['rate'] == None
    assert m.params['rate_limit'] == None


# Generated at 2022-06-20 15:21:59.008980
# Unit test for function retry_never
def test_retry_never():
    test_exception = Exception('test_exception')
    assert not retry_never(test_exception)



# Generated at 2022-06-20 15:22:01.700949
# Unit test for function retry_never
def test_retry_never():
    exception = Exception('test')
    assert retry_never(exception) == False

# Generated at 2022-06-20 15:22:08.525489
# Unit test for function retry
def test_retry():
    result = 0
    i = 0
    @retry(4)
    def test():
        global i, result
        i += 1
        if i < 3:
            result += 1
            return None
        else:
            result += 1
            return result
    test()
    assert result == 4

# Generated at 2022-06-20 15:22:16.887768
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=0.1)
    def a():
        pass

    # measure how long a runs, if longer than 0.1s, it fails
    start = time.time()
    a()
    delta = time.time() - start
    assert delta < 0.11, "%s should be less than 0.11s" % delta
    # assert a.__doc__ == "ratelimited(*, rate=1, rate_limit=10)", '%s should be "ratelimited(*, rate=1, rate_limit=10)"' % a.__doc__

# Generated at 2022-06-20 15:22:19.778556
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    test_spec = dict(arg1='value1', arg2='value2')
    retry_arg_spec = retry_argument_spec(spec=test_spec)
    assert 'retries' in retry_arg_spec
    assert 'retry_pause' in retr

# Generated at 2022-06-20 15:22:24.745207
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_spec = rate_limit_argument_spec()
    assert 'rate' in rate_limit_spec
    assert rate_limit_spec['rate']['type'] == 'int'
    assert 'rate_limit' in rate_limit_spec
    assert rate_limit_spec['rate_limit']['type'] == 'int'

if __name__ == "__main__":
    test_rate_limit_argument_spec()

# Generated at 2022-06-20 15:22:28.377062
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(rate=1, rate_limit=1)
    def f():
        pass

    time.clock = lambda: 0
    f()
    time.clock = lambda: 0.5001
    f()
    time.clock = lambda: 1.0001
    f()



# Generated at 2022-06-20 15:22:33.565438
# Unit test for function retry
def test_retry():
    class TestException(Exception):
        pass
    @retry(retries=10, retry_pause=1)
    def test_retry_function():
        raise TestException
    with pytest.raises(TestException):
        test_retry_function()


# Generated at 2022-06-20 15:22:53.567473
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    result = basic_auth_argument_spec()
    assert result.get('api_username').get('type') == 'str'
    assert result.get('api_password').get('type') == 'str'
    assert result.get('api_password').get('no_log') == True
    assert result.get('api_url').get('type') == 'str'
    assert result.get('validate_certs').get('type') == 'bool'
    assert result.get('validate_certs').get('default') == True

# Generated at 2022-06-20 15:23:00.925416
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert 'retries' in arg_spec
    assert arg_spec['retries']['type'] == 'int'
    assert 'retry_pause' in arg_spec
    assert arg_spec['retry_pause']['type'] == 'float'
    assert 'default' in arg_spec['retry_pause']
    assert arg_spec['retry_pause']['default'] == 1


# Generated at 2022-06-20 15:23:06.382180
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.api import basic_auth_argument_spec, basic_auth_argument_spec
    arg_spec = basic_auth_argument_spec()
    assert arg_spec == {'api_username': {'type': 'str'},
                        'api_password': {'type': 'str', 'no_log': True},
                        'api_url': {'type': 'str'},
                        'validate_certs': {'type': 'bool', 'default': True}}

# Generated at 2022-06-20 15:23:13.962367
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    desired_result = ({'api_username': {'type': 'str'},
                       'api_password': {'type': 'str', 'no_log': True},
                       'api_url': {'type': 'str'},
                       'validate_certs': {'type': 'bool', 'default': True}})
    assert basic_auth_argument_spec() == desired_result


# Generated at 2022-06-20 15:23:17.497822
# Unit test for function rate_limit
def test_rate_limit():
    import time

    @rate_limit(rate=1, rate_limit=10)
    def func():
        print("This function should be called at least at every 10 seconds once")

    # This test provides a coverage of rate_limit with selected python versions
    if sys.version_info[:2] in [(3, 8)]:
        # Begin test
        start = time.time()
        func()
        end = time.time()
        assert((end - start) >= 10)

# Generated at 2022-06-20 15:23:23.499569
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # values from http://www.awsarchitectureblog.com/2015/03/backoff.html
    expected_delay_values = [0, 0, 1, 0, 0, 0, 2, 0, 1, 1]
    for test_delay_value, actual_delay_value in zip(expected_delay_values, generate_jittered_backoff()):
        assert test_delay_value == actual_delay_value

# Generated at 2022-06-20 15:23:33.470132
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import sys

    if sys.version_info < (3, 0):
        reload(sys)
        sys.setdefaultencoding('utf8')

    def myRetryFunc(arg1, arg2, kwarg1=None, kwarg2=None):
        """Return values: 0 is success, 1 is a retriable exception, -1 is a non-retriable exception"""
        if kwarg2 is None:
            raise Exception("Non-retriable exception")
        else:
            try:
                x = arg1 / arg2
            except ZeroDivisionError:
                raise Exception("Retriable exception")
            return 0

    retry_never_condition = functools.partial(retry_never)

# Generated at 2022-06-20 15:23:37.559227
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_arguement_spec()
    assert arg_spec['rate']['type'] == 'int'
    assert arg_spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-20 15:23:43.136943
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Test success with empty iterator
    @retry_with_delays_and_condition(iter(()))
    def foo():
        return "abc"
    assert foo() == "abc"

    # Test success with single attempt only
    @retry_with_delays_and_condition(iter((),))
    def foo():
        return "abc"
    assert foo() == "abc"

    # Test success
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def foo():
        return "abc"
    assert foo() == "abc"

    # Test failure
    @retry_with_delays_and_condition(generate_jittered_backoff(), lambda e: False)
    def foo():
        raise Exception()

# Generated at 2022-06-20 15:23:52.692978
# Unit test for function rate_limit
def test_rate_limit():
    """The test first makes sure the function finishes within the expected time
    (rate_limit*rate_limit/rate) and then that the minimum delay between
    calls is rate_limit/rate.
    The function takes a "last" argument which is the initial time the function was called.
    This is used to measure the minimum delay between calls.
    """

    def rate(rate, rate_limit, last):
        now = time.time()

# Generated at 2022-06-20 15:24:18.820794
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=retry_argument_spec())
    assert module.params['retries'] is None
    assert module.params['retry_pause'] == 1

# Generated at 2022-06-20 15:24:28.125925
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = (1, 2, 4, 8)
    function_with_exception = lambda: 1 / 0

    decorated_function = retry_with_delays_and_condition(backoff_iterator)
    try:
        result = decorated_function(function_with_exception)
    except ZeroDivisionError:
        pass
    else:
        raise ValueError("Expected exception did not occur.")

    decorated_function = retry_with_delays_and_condition(backoff_iterator, lambda e: True)
    result = decorated_function(function_with_exception)
    assert result is None

    function_with_result = lambda: "success"
    decorated_function = retry_with_delays_and_condition(backoff_iterator)
    result = decorated_function(function_with_result)


# Generated at 2022-06-20 15:24:30.812438
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False
    assert retry_never(True) == False


# Generated at 2022-06-20 15:24:41.597367
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    Tests the API module helper for retrying with a given delay iterator and an error condition
    """
    exception_list = []

    # Create a function with two exceptions:
    # TimeoutError will trigger the retry 3 times with a Full Jitter backoff
    # PermissionError will trigger the retry 2 times with a Full Jitter backoff
    # Then the retry will break after the 3rd TimeoutError
    def retryable_function(input_arg, exception_list):
        if input_arg == "should_raise_timeout_error":
            exception_list.append("timeout")
            raise TimeoutError("timeout")
        elif input_arg == "should_raise_permission_error":
            exception_list.append("permission")
            raise PermissionError("permission")

# Generated at 2022-06-20 15:24:42.906490
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception())
    assert not retry_never(Exception('barf'))

# Generated at 2022-06-20 15:24:53.934612
# Unit test for function rate_limit
def test_rate_limit():
    time.clock = time.process_time
    # no limit
    delay = 0.0
    rate = None
    rate_limit = None
    last = [0.0]
    minrate = rate_limit / rate
    elapsed = time.process_time() - last[0]
    left = minrate - elapsed
    if left > 0:
        delay = left
    assert delay == 0.0

    # limit too high
    delay = 0.0
    rate = 100
    rate_limit = 10
    last = [0.0]
    minrate = rate_limit / rate
    elapsed = time.process_time() - last[0]
    left = minrate - elapsed
    if left > 0:
        delay = left
    assert delay == 0.0

    # limit too low
    delay = 0.0
    rate

# Generated at 2022-06-20 15:25:03.347704
# Unit test for function retry
def test_retry():
    import pytest
    import unittest.mock as mock
    global_variable = [0]
    @retry(retries=1, retry_pause=0.5)
    def retried_function():
        global_variable[0] += 1
        return False

    with pytest.raises(Exception):
        retried_function()
    assert global_variable[0] == 2
    @retry(retries=1, retry_pause=0.5)
    def retried_function_succeed():
        global_variable[0] += 1
        return True

    retried_function_succeed()
    assert global_variable[0] == 3


# Generated at 2022-06-20 15:25:09.408221
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}
    assert retry_argument_spec({'test': {'test': 'test'}}) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}, 'test': {'test': 'test'}}


# Generated at 2022-06-20 15:25:16.482459
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import threading

    @rate_limit(rate=3, rate_limit=1)
    def rate_limited_function(arg1):
        time.sleep(0.3)
        return arg1 * 10

    class RateLimitedThread(threading.Thread):
        def __init__(self, name):
            threading.Thread.__init__(self)
            self.name = name
            self.value = None

        def run(self):
            self.value = rate_limited_function(self.name)

    threads = []
    for _thread in range(0, 5):
        thread = RateLimitedThread(_thread)
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join()
        assert thread.value == thread.name * 10

# Generated at 2022-06-20 15:25:26.882134
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import json

    class SomeException(Exception):
        pass

    class SomeOtherException(Exception):
        pass

    class SomeOtherOtherException(Exception):
        pass

    # Example function that raises exceptions when accessing path in the JSON of a given dict
    def example_function(data, *path):
        data_json = json.dumps(data)
        for element in path:
            try:
                data_json = json.loads(data_json)[element]
            except KeyError as e:
                raise SomeOtherException(e)
        raise SomeException
    test_data = {
        'foo': {
            'bar': {
                'john': None,
                'test': [1, 2, 3],
                'test2': 'test'
            }
        }
    }
    # Only retry for SomeException and not for

# Generated at 2022-06-20 15:26:19.987417
# Unit test for function retry
def test_retry():
    expected_run_count = 3
    actual_run_count = 0

    @retry(retries=expected_run_count)
    def _test_retry():
        nonlocal actual_run_count
        actual_run_count = actual_run_count + 1
        if actual_run_count < expected_run_count:
            return False
        return True

    _test_retry()
    assert actual_run_count == expected_run_count



# Generated at 2022-06-20 15:26:27.067380
# Unit test for function retry
def test_retry():
    # simulate a function which fails when it takes a negative argument
    @retry(retries=5)
    def fail_with_negative_arg(arg):
        if arg < 0:
            raise ValueError('arg is negative')
        else:
            return True

    # test that it succeeds
    assert fail_with_negative_arg(10)
    # simulate a retry
    try:
        fail_with_negative_arg(-10)
    except Exception as e:
        assert isinstance(e, ValueError)

# Generated at 2022-06-20 15:26:29.108204
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert 'rate' in arg_spec
    assert 'rate_limit' in arg_spec


# Generated at 2022-06-20 15:26:39.714596
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Given
    backoff_iterator = ((1, 2))
    should_retry_error = retry_never

    # When
    retry_delays_and_condition = retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    @retry_delays_and_condition
    def call_n_times(n):
        call_n_times.times += 1
        if call_n_times.times == n:
            return 'success'
        raise Exception()
    call_n_times.times = 0

    # Then
    result = call_n_times(n=2)
    assert result == 'success'
    assert call_n_times.times == 2



# Generated at 2022-06-20 15:26:47.163757
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    errors = {}
    errors['1'] = False

    for attempt, delay in enumerate(generate_jittered_backoff(10)):
        if delay >= 0 and delay <= 60:
            errors['1'] = True
        else:
            errors['1'] = False
            print('Delay %s out of 0 - 60 range!', delay)
            break
    if errors['1'] is False:
        raise Exception('Generate jittered backoff failed')


if __name__ == '__main__':
    test_generate_jittered_backoff()

# Generated at 2022-06-20 15:26:53.357974
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        test1=dict(type='str'),
        test2=dict(type='str')
    )
    arg_spec = rate_limit_argument_spec(spec)
    assert arg_spec['rate']['type'] == 'int'
    assert arg_spec['rate_limit']['type'] == 'int'
    assert arg_spec['test1']['type'] == 'str'
    assert arg_spec['test2']['type'] == 'str'

# Generated at 2022-06-20 15:27:04.473899
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest
    import unittest.mock

    # Mock the should_retry_error callable
    retry_condition_mock = unittest.mock.MagicMock()
    retry_condition_mock.side_effect = [True, False]

    # Mock the function
    function_mock = unittest.mock.MagicMock()
    function_mock.side_effect = Exception('test retry')

    # Mock time.sleep
    time_sleep_mock = unittest.mock.MagicMock()

    # Make the call to the wrapped function

# Generated at 2022-06-20 15:27:13.168371
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # pylint: disable=redefined-outer-name
    def test_function(fail_count, const_exception, *args, **kwargs):
        """A test function that we can call and will throw an error as many times as specified"""
        if fail_count > 0:
            fail_count -= 1
            raise const_exception
        return "Return value"

    def should_retry(exception):
        """A test function that decides whether to retry or not based on the exception thrown previously"""
        return isinstance(exception, ValueError)

    const_exception = ValueError()
    backoff_iterator = generate_jittered_backoff()

    # At first we expect a ValueError
    with pytest.raises(ValueError):
        test_function(10, const_exception)

    # Now we expect the

# Generated at 2022-06-20 15:27:17.209024
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():

    result = basic_auth_argument_spec()

    assert 'api_username' in result
    assert 'api_password' in result
    assert 'api_url' in result
    assert 'validate_certs' in result

# Generated at 2022-06-20 15:27:26.489132
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import inspect

    def function_with_arguments(string, integer=1, float_number=3.14, boolean=False, list_of_strings=None):
        pass

    function_with_arguments = retry_argument_spec(function_with_arguments)
    assert 'retries' in inspect.getfullargspec(function_with_arguments).args
    assert 'retry_pause' in inspect.getfullargspec(function_with_arguments).args

    @retry_argument_spec
    def function_without_arguments():
        pass

    assert 'retries' in inspect.getfullargspec(function_without_arguments).args
    assert 'retry_pause' in inspect.getfullargspec(function_without_arguments).args

# Generated at 2022-06-20 15:29:13.862255
# Unit test for function retry
def test_retry():
    class TestException(Exception):
        pass

    @retry(retries=10, retry_pause=0)
    def retried_function(error_on_first_attempt=False):
        if error_on_first_attempt:
            raise TestException("error")
        return "success"

    assert retried_function(error_on_first_attempt=False) == "success"
    try:
        retried_function(error_on_first_attempt=True)
        raise Exception("Expected func to raise an exception")
    except TestException:
        pass

    assert retried_function(error_on_first_attempt=False) == "success"


# Generated at 2022-06-20 15:29:17.554448
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for expected_delay, actual_delay in zip([0, 2, 3, 3, 6, 7, 13, 13, 13, 13], generate_jittered_backoff()):
        assert expected_delay == actual_delay

# Generated at 2022-06-20 15:29:25.684488
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import collections
    import sys

    # For python 2.x isinstance(x, type) is equivalent to type(x) == type.
    if sys.version_info[0] < 3:
        assert_raises = type
    else:
        assert_raises = AssertionError

    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    assert isinstance(backoff_iterator, collections.Iterator)

    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=0, delay_threshold=60)
    assert_raises(StopIteration, next, backoff_iterator)


# Generated at 2022-06-20 15:29:31.878188
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def throws_exception_once_then_returns(iteration):
        if iteration < 1:
            raise Exception("Intentionally simulated exception")
        return iteration + 1

    result = throws_exception_once_then_returns(0)
    assert result == 1

# Generated at 2022-06-20 15:29:41.781592
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Test that no more than half of the time is spent in "delay" and average delay is equal to delay_base.
    The test is stochastic and is expected to fail every few runs, but should converge to the asserted values.
    """
    delay_base = 0.5
    delay_threshold = 10
    delay_sum = 0
    calls_on_delay = 0
    delay_count = 100000
    for delay in generate_jittered_backoff(delay_count, delay_base, delay_threshold):
        delay_sum += delay
        calls_on_delay += 1
    assert delay_sum / calls_on_delay > delay_base / 2, "Test failed. If the problem persists, please retry the test. This failure may be caused by bad luck and is not an issue with the module."

# Generated at 2022-06-20 15:29:43.723421
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False
    assert retry_never(Exception) == False


# Generated at 2022-06-20 15:29:55.115462
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        api_url='http://localhost/api',
        api_version='2.5',
        api_username='api',
        api_password='password',
        validate_certs=False
    )
    expected_spec = dict(
        api_url=dict(type='str'),
        api_version=dict(type='str'),
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        validate_certs=dict(type='bool', default=True),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )

    actual_spec = retry_argument_spec(spec)
    assert actual_spec == expected_spec

    actual_spec = retry_argument

# Generated at 2022-06-20 15:30:04.903964
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def call_retryable_function():
        call_retryable_function.attempt_num += 1
        if call_retryable_function.attempt_num == 1:
            raise Exception('Failed 1, should retry')
        if call_retryable_function.attempt_num == 2:
            raise Exception('Failed 2, should retry')
        return call_retryable_function.attempt_num

    call_retryable_function.attempt_num = 0

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=retry_never)
    def retryable_function_once(callable_function, *args, **kwargs):
        return callable_function()

    assert retryable_function

# Generated at 2022-06-20 15:30:06.489002
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert spec
    assert 'rate' in spec
    assert 'rate_limit' in spec


# Generated at 2022-06-20 15:30:07.729803
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for b in generate_jittered_backoff(5):
        assert 0 <= b <= 15

