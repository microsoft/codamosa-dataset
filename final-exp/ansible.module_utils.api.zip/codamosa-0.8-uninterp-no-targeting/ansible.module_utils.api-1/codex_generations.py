

# Generated at 2022-06-20 15:20:54.823032
# Unit test for function retry_never
def test_retry_never():
    f = retry_never(Exception("An error"))
    assert not f


# Generated at 2022-06-20 15:20:59.145858
# Unit test for function retry
def test_retry():
    """Test retry function with retries == 1"""
    def test_func():
        raise Exception("test_func exception")

    retry_count = [0]
    retried = retry(retries=1)(test_func)
    assert_exception = False
    if retried:
        try:
            retried()
        except Exception:
            assert_exception = True
    assert assert_exception and retry_count[0] == 1, "retry failed"


# Generated at 2022-06-20 15:21:03.201310
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert spec["retries"]["type"] == "int"
    assert spec["retry_pause"]["type"] == "float"
    assert spec["retry_pause"]["default"] == 1
    assert spec["retry_pause"]["type"] == "float"
    assert spec["retry_pause"]["default"] == 1

# Generated at 2022-06-20 15:21:15.407477
# Unit test for function rate_limit
def test_rate_limit():
    import doctest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    m = AnsibleModule(
        argument_spec=basic.rate_limit_argument_spec(),
        supports_check_mode=True,
    )
    m._ansible_debug = True
    ratelimit = m.params.get('rate')
    rate = m.params.get('rate_limit')
    @rate_limit(ratelimit, rate)
    def ratelimited():
        return ratelimit, rate

    failed, total = doctest.testmod(basic, verbose=True)
    if failed == 0:
        m.exit_json(failed=0, ratelimit=ratelimited())
    else:
        m.fail_json(msg='unit tests for module basic failed')

# Generated at 2022-06-20 15:21:22.390797
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def example_test_function_with_retry():
        retry_counter = example_test_function_with_retry.retry_counter
        example_test_function_with_retry.retry_counter += 1
        return retry_counter
    example_test_function_with_retry.retry_counter = 0

    assert example_test_function_with_retry() == 0

# Generated at 2022-06-20 15:21:26.095468
# Unit test for function retry_never
def test_retry_never():
    import pytest

    assert(retry_never('test') is False)
    with pytest.raises(Exception):
        retry_never(Exception('test'))


# Generated at 2022-06-20 15:21:31.362307
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():

    # Test function with no parameters
    assert len(basic_auth_argument_spec()) == 4

    # Test function with one parameter
    assert len(basic_auth_argument_spec(spec={"test": {"type": "str"}})) == 5
    assert basic_auth_argument_spec(spec={"test": {"type": "str"}})["test"]["type"] == "str"

# Generated at 2022-06-20 15:21:42.156290
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(generate_jittered_backoff())
    def always_fail_function():
        raise ValueError

    assert always_fail_function() is None

    @retry_with_delays_and_condition(generate_jittered_backoff(delay_threshold=0.01, retries=9))
    def fail_three_times_function():
        fail_three_times_function.count += 1
        if fail_three_times_function.count < 3:
            raise ValueError
        return 2

    fail_three_times_function.count = 0
    assert fail_three_times_function() == 2


# Generated at 2022-06-20 15:21:47.618076
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    jittered_backoff = generate_jittered_backoff(10, 5, 50)
    backoff_test_set = [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]
    for delay in jittered_backoff:
        backoff_test_set.remove(delay)
    assert backoff_test_set == []

# Generated at 2022-06-20 15:21:48.676500
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert "api_username" in basic_auth_argument_spec()


# Generated at 2022-06-20 15:22:08.971291
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Unit test for function retry_with_delays_and_condition"""
    backoff_iterator = generate_jittered_backoff()
    call_count = [0]
    fail_threshold = len(backoff_iterator)

    @retry_with_delays_and_condition(backoff_iterator)
    def always_failing_function(should_fail):
        if should_fail:
            raise RuntimeError('Tried too many times!')
        call_count[0] += 1
        return True

    @functools.wraps(always_failing_function)
    def never_failing(should_fail):
        if should_fail:
            raise RuntimeError('Tried too many times!')
        call_count[0] += 1
        return True

    # Test that retries work for a True condition

# Generated at 2022-06-20 15:22:11.219007
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:22:17.326057
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Test cases for function retry_with_delays_and_condition."""

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff())
    def f(error):
        raise ValueError(error)

    try:
        f("test fail but retry")
    except:
        pass

    try:
        f("test fail and exit")
        assert "test fail and exit" == ""
    except:
        pass

# Generated at 2022-06-20 15:22:21.888976
# Unit test for function rate_limit
def test_rate_limit():
    """Rate limit decorator"""
    rl = rate_limit

    @rl(rate=3, rate_limit=7)
    def foo(i):
        return i

    import time

    start = time.time()
    for i in range(0, 10):
        foo(i)
    elapsed = time.time() - start
    # foo should have been called three times in a window of 7 seconds.
    assert elapsed > 7
    assert elapsed < 10



# Generated at 2022-06-20 15:22:31.110626
# Unit test for function retry
def test_retry():
    # Save the original function
    original = retry_with_delays_and_condition

    # Mock the random module
    retry_with_delays_and_condition = mock.MagicMock(
        wraps=retry_with_delays_and_condition,
        return_value=lambda f: lambda: original(mock.ANY, retry_never)(f)()
    )

    # Set the number of retries
    @retry(retries=3)
    def function():
        function.counter += 1
        if function.counter == 1:
            raise Exception("Test problem")
        return function.counter

    # Run the test
    function.counter = 0
    assert function() == 2

    # Restore the original function
    retry_with_delays_and_condition(iter([0]), lambda e: e)



# Generated at 2022-06-20 15:22:36.079566
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_arg_spec = retry_argument_spec()
    assert 'retries' in retry_arg_spec
    assert 'retry_pause' in retry_arg_spec
    assert retry_arg_spec['retry_pause']['default'] == 1
    assert retry_arg_spec['retries']['type'] == 'int'
    assert retry_arg_spec['retry_pause']['type'] == 'float'

# Generated at 2022-06-20 15:22:42.368566
# Unit test for function rate_limit
def test_rate_limit():
    rate = 5
    rate_limit = 60
    minrate = float(rate_limit) / float(rate)

    assert callable(rate_limit(rate, rate_limit))
    func_to_limit = rate_limit(rate, rate_limit)(time.sleep)
    assert callable(func_to_limit)
    start = time.time()
    for i in range(0, rate):
        func_to_limit(0.5)
    elapsed = time.time() - start
    assert elapsed >= rate_limit, elapsed

# Generated at 2022-06-20 15:22:51.167699
# Unit test for function rate_limit
def test_rate_limit():
    # 4 times in a second, will not exceed limit
    @rate_limit(4, 1)
    def fast(num):
        return num

    # once in 2 seconds, will not exceed limit
    @rate_limit(1, 2)
    def slow(num):
        return num

    # 2 times in a second, will exceed
    @rate_limit(2, 1)
    def fast_exceed(num):
        return num

    assert fast(1) == 1
    assert fast(2) == 2
    assert fast(3) == 3
    assert fast(4) == 4
    assert slow(5) == 5
    assert slow(6) == 6
    pytest.raises(Exception, lambda: fast_exceed(7))



# Generated at 2022-06-20 15:23:02.280127
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Test invocations with an empty backoff_iterator, a non-empty one, and an error condition
    backoff_iterator = generate_jittered_backoff(retries=0)
    for test_case in [('no_errors', 3), ('errors_with_retry', 2), ('errors_without_retry', 1)]:
        class RunCountedFunction:
            run_count = 0

            def __call__(self, error_after_how_many_runs=3, raise_error=False):
                self.run_count += 1
                if raise_error and self.run_count >= error_after_how_many_runs:
                    raise Exception('Run count is: %s' % self.run_count)
                return self.run_count


# Generated at 2022-06-20 15:23:06.966437
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    expected = {'api_password': {'no_log': True, 'type': 'str'},
                'api_url': {'type': 'str'},
                'api_username': {'type': 'str'},
                'validate_certs': {'default': True, 'type': 'bool'}}
    actual = basic_auth_argument_spec()
    assert expected == actual


# Generated at 2022-06-20 15:23:19.704877
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    module_args = {'retries': 3, 'retry_pause': 1.5}
    spec = retry_argument_spec()

    from ansible.module_utils.common.validation import check_argument_spec
    check_argument_spec(spec, module_args)



# Generated at 2022-06-20 15:23:23.801446
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    should_retry_error = lambda e: e != 3
    test_values = list(generate_jittered_backoff(retries=6, delay_threshold=60))
    assert len(test_values) == 6
    for value in test_values:
        assert value <= 60

# Generated at 2022-06-20 15:23:29.274382
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}



# Generated at 2022-06-20 15:23:31.252039
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(420)
    assert not retry_never(Exception())

# Generated at 2022-06-20 15:23:41.730612
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert retry_spec is not None, "retry_spec is none"
    assert 'retries' in retry_spec, "retries not in retry_spec"
    assert retry_spec['retries']['type'] == 'int', "retries type is not int"
    assert 'retry_pause' in retry_spec, "retry_pause not in retry_spec"
    assert retry_spec['retry_pause']['type'] == 'float', "retry_pause type is not float"
    assert retry_spec['retry_pause']['default'] == 1, "retry_pause default is not 1"
    retry_spec2 = retry_argument_spec(dict(myvar=dict(type='int')))
   

# Generated at 2022-06-20 15:23:44.740637
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    expected_result = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int')
    )
    assert rate_limit_argument_spec() == expected_result


# Generated at 2022-06-20 15:23:47.094828
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == (dict(
        retries = dict(type='int'),
        retry_pause = dict(type='float', default=1),
    ))

# Generated at 2022-06-20 15:23:55.990906
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """
    basic_auth_argument_spec:
        - api_username: str
        - api_password: str, no_log
        - api_url: str
        - validate_certs: bool, default=True
    """
    from collections import OrderedDict
    module_args = {"api_username": "user1", "api_password": "secret", "api_url": "http://localhost", "validate_certs": True}

# Generated at 2022-06-20 15:24:06.308515
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    args = basic_auth_argument_spec()
    assert isinstance(args, dict)
    assert set(args.keys()) == set(['api_username', 'api_password', 'api_url', 'validate_certs'])
    assert args['api_username']['type'] == 'str'
    assert args['api_password']['type'] == 'str'
    assert args['api_password']['no_log'] is True
    assert args['api_url']['type'] == 'str'
    assert args['validate_certs']['type'] == 'bool'
    assert args['validate_certs']['default'] is True


# Generated at 2022-06-20 15:24:12.056025
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [0, 1, 34, 45]
    assert list(generate_jittered_backoff(retries=4, delay_threshold=45)) == delays
    assert list(generate_jittered_backoff(retries=4, delay_threshold=None)) == delays
    # delay_base doesn't matter in this case
    assert list(generate_jittered_backoff(retries=4, delay_base=1, delay_threshold=45)) == delays

    delays = [0, 0, 1, 3, 9]
    assert list(generate_jittered_backoff(retries=5, delay_base=3, delay_threshold=10)) == delays


# Generated at 2022-06-20 15:24:40.316841
# Unit test for function retry
def test_retry():
    class SomeError(Exception):
        pass

    def some_function():
        return None

    def some_function_i_like_to_retry():
        random.seed(0)
        if random.randint(0, 99) <= 50:
            raise SomeError("I'm an error")
        return 42

    def some_function_that_should_not_retry_on_errors(error_to_raise):
        raise error_to_raise

    def should_retry_error(error):
        return isinstance(error, SomeError)

    def should_never_retry_error(error):
        return False


# Generated at 2022-06-20 15:24:41.992632
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    result = dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    assert retry_argument_spec() == result


# Generated at 2022-06-20 15:24:50.148691
# Unit test for function retry
def test_retry():
    """Test the retry decorator"""
    def successful_call():
        """Will return True after 5 retries"""
        successful_call.counter += 1
        if successful_call.counter == 5:
            return True
        else:
            raise Exception('not done')

    successful_call.counter = 0
    retries = 15
    delay_base = 1
    backoff_iterator = generate_jittered_backoff(retries, delay_base)
    decorator = retry_with_delays_and_condition(backoff_iterator)
    decorated_function = decorator(successful_call)
    assert decorated_function()

# Generated at 2022-06-20 15:24:53.081505
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert spec == {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }


# Generated at 2022-06-20 15:24:55.787131
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = rate_limit_argument_spec()
    assert spec['rate']['type'] == 'int'
    assert spec['rate_limit']['type'] == 'int'

# Generated at 2022-06-20 15:25:01.815574
# Unit test for function retry
def test_retry():
    @retry()
    def retryable(succeed=True):
        if succeed:
            return True
        else:
            return False

    if not retryable(succeed=False):
        raise Exception("Should have succeeded")

    import pytest
    try:
        retryable(succeed=False, retries=1)
    except Exception:
        pass
    else:
        pytest.fail("Should have failed")

# Generated at 2022-06-20 15:25:04.988033
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec

# Generated at 2022-06-20 15:25:10.370561
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Unit test for function retry_argument_spec"""
    spec = retry_argument_spec()
    assert "retries" in spec
    assert "retry_pause" in spec
    assert spec["retries"]["type"] == "int"
    assert spec["retry_pause"]["type"] == "float"
    assert spec["retry_pause"]["default"] == 1



# Generated at 2022-06-20 15:25:10.973708
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_argument_spec()


# Generated at 2022-06-20 15:25:15.114122
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = retry_argument_spec()
    assert argument_spec['retries']['type'] == 'int'
    assert argument_spec['retry_pause']['type'] == 'float'
    assert argument_spec['retry_pause']['default'] == 1



# Generated at 2022-06-20 15:25:40.762799
# Unit test for function retry
def test_retry():
    @retry(3)
    def dummy_retry(value):
        print('Trying to get retry value %s' % value)
        if sys.version_info >= (3, 0):
            return True if value == 4 else False
        else:
            if value == 4:
                return True
            else:
                return False

    # Correct return value
    assert dummy_retry(4) == True

    # Wrong return value
    try:
        dummy_retry(2)
    except Exception as e:
        assert 'Retry limit exceeded: 3' == str(e)

# Generated at 2022-06-20 15:25:50.945271
# Unit test for function retry
def test_retry():
    def test_function(i):  # Takes a single int argument
        if i == 0:
            raise RuntimeError
        return 2 * i

    # Test decorator
    test_function_retries = retry(retries=3, retry_pause=0)(test_function)
    assert test_function_retries(0) == 1
    assert test_function_retries(1) == 2
    # Test number of tries
    with pytest.raises(Exception) as exc_info:
        test_function_retries(0)
    assert "Retry limit exceeded" in str(exc_info.value)
    # Test function arguments are preserved
    test_function_retries = retry(retries=3, retry_pause=0)(test_function)
    assert test_function_retries(1) == 2
   

# Generated at 2022-06-20 15:25:57.929171
# Unit test for function retry
def test_retry():
    expected_value = "foobar"
    uses = 0
    next_valid_uses = 3

    @retry(retries=10, retry_pause=1)
    def retry_test():
        global uses
        uses += 1
        if uses < next_valid_uses:
            return False
        return expected_value

    assert(retry_test() == expected_value)
    assert(uses == 3)



# Generated at 2022-06-20 15:25:58.826590
# Unit test for function rate_limit
def test_rate_limit():
    rate_limit.__doc__

# Generated at 2022-06-20 15:26:04.244330
# Unit test for function retry
def test_retry():
    should_retry_error = lambda e: True

    @retry_with_delays_and_condition([1, 2, 3, 4, 5], should_retry_error)
    def retryable_function():
        raise Exception('Some failed error')

    # hmmm, don't have a good way of testing this is a decorator
    # probably need to move to pytest

# Generated at 2022-06-20 15:26:07.591367
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = list(generate_jittered_backoff(5, 3, 60))
    for attempt in range(0, len(backoff_iterator) - 1):
        assert backoff_iterator[attempt] <= backoff_iterator[attempt + 1] * 2

# Generated at 2022-06-20 15:26:09.044158
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception('error')) == False

# Generated at 2022-06-20 15:26:13.247627
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(50, 60)
    def dummy_func():
        return True

    dummy_func()
    assert(dummy_func.__name__ == 'dummy_func')



# Generated at 2022-06-20 15:26:16.441201
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(SystemExit('Exiting')) == False
    assert retry_never(Exception('Exception')) == False
    assert retry_never('Any string') == False

# Generated at 2022-06-20 15:26:23.272585
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert 'api_username' in spec
    assert 'api_password' in spec
    assert 'api_url' in spec
    assert 'validate_certs' in spec

    spec = basic_auth_argument_spec(spec={'some_arg': {'type': 'str'}})
    assert 'api_username' in spec
    assert 'api_password' in spec
    assert 'api_url' in spec
    assert 'validate_certs' in spec
    assert 'some_arg' in spec

# Generated at 2022-06-20 15:27:02.580169
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = retry_argument_spec({"check_mode": {"type": "bool", "default": False}})
    assert argument_spec == {"check_mode": {"type": "bool", "default": False}, "retries": {"type": "int"}, "retry_pause": {"type": "float", "default": 1}}

# Generated at 2022-06-20 15:27:09.200999
# Unit test for function retry
def test_retry():
    retries = 4
    max_attempts = 4
    counter = 0
    # Need some way to tell that the retry occured
    def fail():
        global counter
        if counter < (max_attempts - 1):
            counter += 1
            raise Exception("We were retried")
        else:
            return "SUCCESS"
        
    func = retry(retries)(fail)
    result = func()
    assert result == "SUCCESS"
    assert counter == (max_attempts - 1)

# Generated at 2022-06-20 15:27:10.827830
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    # Initial delay is 0-3 seconds
    assert(0 <= next(generate_jittered_backoff()) <= 3)

# Generated at 2022-06-20 15:27:16.283865
# Unit test for function retry
def test_retry():
    test_count = [0]

    @retry(retries=10, retry_pause=1)
    def test_func(exception):
        test_count[0] += 1
        if exception:
            raise Exception('Test Failed')
        return True

    try:
        test_func(exception=True)
    except Exception as e:
        assert (test_count[0] == 10)
        assert (e.args[0] == 'Test Failed')

    try:
        test_count[0] = 0
        test_func(exception=False)
    except Exception as e:
        assert (test_count[0] == 1)


if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-20 15:27:19.795897
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) == False
    assert retry_never(None) == False
    assert retry_never(0) == False
    assert retry_never('') == False
    assert retry_never('11') == False


# Generated at 2022-06-20 15:27:21.570293
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("test")) == False


# Generated at 2022-06-20 15:27:27.642070
# Unit test for function retry
def test_retry():
    """Retry decorator"""
    def wrapper(f):
        def retried(*args, **kwargs):
            retry_count = 0
            if retries is not None:
                ret = None
                while True:
                    retry_count += 1
                    if retry_count >= retries:
                        raise Exception("Retry limit exceeded: %d" % retries)
                    try:
                        ret = f(*args, **kwargs)
                    except Exception:
                        pass
                    if ret:
                        break
                    time.sleep(retry_pause)
                return ret

        return retried
    return wrapper

# Generated at 2022-06-20 15:27:33.177890
# Unit test for function rate_limit
def test_rate_limit():
    class A:
        pass

    a = A()
    # set number of requests to 1 per second
    a.rate = 1
    a.rate_limit = 1

    @rate_limit(rate=a.rate, rate_limit=a.rate_limit)
    def foo():
        return True

    for i in range(0, 10):
        res = foo()
        assert res



# Generated at 2022-06-20 15:27:38.806250
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(desired_key=dict(type='str', default='default'))

    result = rate_limit_argument_spec(spec)

    assert result['rate']['type'] == 'int'
    assert result['rate_limit']['type'] == 'int'
    assert result['desired_key']['type'] == 'str'
    assert result['desired_key']['default'] == 'default'


# Generated at 2022-06-20 15:27:42.659041
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """test the rate_limit_argument_spec function"""
    spec = rate_limit_argument_spec()
    assert 'rate' in spec
    assert 'rate_limit' in spec
    copy = rate_limit_argument_spec(spec)
    assert 'rate' in copy
    assert 'rate_limit' in copy



# Generated at 2022-06-20 15:28:59.726961
# Unit test for function retry_never
def test_retry_never():
    result_list = [True, None, '', ' ', 'data']
    for result in result_list:
        assert retry_never(result) is False


# Generated at 2022-06-20 15:29:11.475332
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TestException(Exception):
        pass

    def should_retry_retry(e):
        return isinstance(e, TestException) and e.args[0] == 'retry'

    def should_retry_never(e):
        return isinstance(e, TestException) and e.args[0] == 'never'

    # Test no failures, no delays, no retries
    @retry_with_delays_and_condition([], retry_never)
    def no_failure():
        return 'success'

    assert no_failure() == 'success'

    # Test no failures, with delays, no retries

# Generated at 2022-06-20 15:29:20.808041
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(retries=3, delay_base=1, delay_threshold=5))
    def test_func(should_fail):
        if should_fail:
            raise Exception('should not ever see this message.')
        return 'did not fail'

    assert test_func(should_fail=False) == 'did not fail'
    try:
        test_func(should_fail=True)
        assert False, 'Did not throw exception.'
    except Exception as e:
        assert str(e) == 'should not ever see this message.'

# Generated at 2022-06-20 15:29:23.258722
# Unit test for function retry_never
def test_retry_never():
    @retry_with_delays_and_condition(generate_jittered_backoff(), retry_never)
    def test_function():
        raise Exception("An exception")

    with pytest.raises(Exception):
        test_function()

# Generated at 2022-06-20 15:29:26.985582
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict(api_username='test_user', api_password='test_password', api_url='test_url')
    module = AnsibleModule(
        argument_spec=basic_auth_argument_spec()
    )
    assert module.params['api_username'] == 'test_user'
    assert module.params['api_password'] == 'test_password'
    assert module.params['api_url'] == 'test_url'

# Generated at 2022-06-20 15:29:32.865927
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    retries = 10
    delay_base = 3
    delay_threshold = 60
    for i in generate_jittered_backoff(retries, delay_base, delay_threshold):
        assert i <= delay_threshold, "Generated delay %d exceeds threshold %d" % (i, delay_threshold)

# Generated at 2022-06-20 15:29:43.374531
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    # Generate 1, 3, 6, 12, 60 (Jittered Backoff)
    backoff_iterator = generate_jittered_backoff(5)

    # 0,1,2,3,4 (= 5 - 1 here)
    number_of_failures = 4
    max_number_of_calls = number_of_failures + 1

    @retry_with_delays_and_condition(backoff_iterator)
    def function_to_retry():
        function_to_retry.called_count += 1

        # Only return after max_number_of_calls calls.
        if function_to_retry.called_count >= max_number_of_calls:
            return

        # Always raise an exception.
        raise ValueError("Test error")

    # Reset called_count.
    function_to

# Generated at 2022-06-20 15:29:45.494160
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert 'retries' in retry_argument_spec()
    assert 'retry_pause' in retry_argument_spec()

# Generated at 2022-06-20 15:29:46.866310
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('some text') == False



# Generated at 2022-06-20 15:29:52.137402
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception("Normal"))
    assert not retry_never(True)
    assert not retry_never(False)
    assert not retry_never(None)
    assert not retry_never(0)
    assert not retry_never(1)
