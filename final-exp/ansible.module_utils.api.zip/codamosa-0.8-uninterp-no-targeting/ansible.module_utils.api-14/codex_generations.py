

# Generated at 2022-06-20 15:20:42.829905
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception('Test exception'))

# Generated at 2022-06-20 15:20:49.779124
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    class MyFactsModule(object):
        def __init__(self):
            self.argument_spec = basic_auth_argument_spec()
        def execute_module(self):
            return {'changed': False}

    fm = MyFactsModule()
    assert fm.argument_spec == {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }

# Generated at 2022-06-20 15:20:56.308548
# Unit test for function retry
def test_retry():
    class TestRetryException(Exception):  # pylint: disable=C0103
        pass

    @retry_with_delays_and_condition(generate_jittered_backoff())
    def function_retry_jitter():
        return True

    function_retry_jitter()

    def should_retry_error(e):
        return isinstance(e, TestRetryException)

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error)
    def function_retry_jitter_with_exception():
        raise TestRetryException()

    function_retry_jitter_with_exception()


# Generated at 2022-06-20 15:21:01.254671
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    def test_module(module_args):
        module = AnsibleModule(argument_spec=basic_auth_argument_spec())
        assert module.params['api_username'] == module_args['api_username']
        assert module.params['api_password'] == module_args['api_password']
        assert module.params['api_url'] == module_args['api_url']
        assert module.params['validate_certs'] == module_args['validate_certs']

    module_args = {
        'api_username': 'user1',
        'api_password': 'secure_password',
        'api_url': 'http://api.example.com:8080',
        'validate_certs': False
    }
    test_module(module_args)



# Generated at 2022-06-20 15:21:05.808586
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec(dict(api_url=dict(type='str', required=True), api_username=dict(type='str', required=True)))
    assert 'api_url' in arg_spec
    assert 'api_username' in arg_spec
    assert 'retry_pause' in arg_spec
    assert 'retries' in arg_spec
    assert 'required' in arg_spec['api_url']
    assert 'required' in arg_spec['api_username']


# Generated at 2022-06-20 15:21:16.469345
# Unit test for function rate_limit
def test_rate_limit():
    # Rate limiting does not affect anything that takes less than the rate_limit setting.
    @rate_limit(rate_limit=10, rate=1)
    def f():
        return time.time()
    before = time.time()
    f()
    after = time.time()
    assert after - before < 0.1, "Call did not finish in less than 0.1s."

    # Rate limiting works for a series of calls
    @rate_limit(rate_limit=10, rate=3)
    def g():
        return time.time()
    before = time.time()
    g()
    g()
    g()
    after = time.time()
    assert after - before > 2 and after - before < 2.1, "Calls took more than 2s and less than 2.1s."

    # Rate limiting works for

# Generated at 2022-06-20 15:21:22.514386
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    assert retry_argument_spec(dict(a=4)) == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        a=4
    )


# Generated at 2022-06-20 15:21:31.795733
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import pytest
    from ansible_collections.turei.turei.plugins.modules import api
    test_arg_spec = dict(
        api_username=dict(type='str'),
        validate_certs=dict(type='bool', default=False),
        api_url=dict(type='str')
    )
    arg_spec = api.basic_auth_argument_spec(spec=test_arg_spec)
    assert arg_spec == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=False)
    )

# Generated at 2022-06-20 15:21:44.021653
# Unit test for function retry
def test_retry():
    retries = 20
    retry_pause = 1
    retry_count = [0]

    @retry(retries, retry_pause)
    def retry_example():
        retry_count[0] += 1
        if retry_count[0] <= 10:
            raise Exception("retry_count is %d <= 10, retrying" % retry_count[0])
        return "the value we want"

    assert (retry_count[0] == 0)
    ret = retry_example()
    assert (retry_count[0] == 11)
    assert (ret == "the value we want")



# Generated at 2022-06-20 15:21:53.191554
# Unit test for function rate_limit
def test_rate_limit():
    a = [0]

    @rate_limit(1, 10)
    def inc():
        a[0] += 1
        time.sleep(1)

    start = time.time()
    inc()
    inc()
    inc()
    elapsed = time.time() - start
    assert a[0] == 3
    assert elapsed > 3
    assert elapsed < 4

    a = [0]

    @rate_limit(10, 10)
    def inc():
        a[0] += 1

    start = time.time()
    inc()
    inc()
    inc()
    elapsed = time.time() - start
    assert a[0] == 10
    assert elapsed > 0.9
    assert elapsed < 1.1



# Generated at 2022-06-20 15:22:17.150588
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    """Test method for function retry_argument_spec()"""
    # Retry Argument Spec
    test_retry_argument_spec = retry_argument_spec()
    assert test_retry_argument_spec['retries']['type'] == 'int'
    assert test_retry_argument_spec['retry_pause']['type'] == 'float'
    assert test_retry_argument_spec['retry_pause']['default'] == 1

    # Retry argument Spec with int
    test_retry_argument_spec = retry_argument_spec(spec={'validate_certs': dict(type='int')})
    test_validate_certs = test_retry_argument_spec['validate_certs']
    assert test_validate_certs['type'] == 'int'

# Generated at 2022-06-20 15:22:29.804221
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    call_counter = 0

    def test_function():
        nonlocal call_counter
        call_counter += 1
        if call_counter < 3:
            raise Exception()
        return 'ok'

    retry_wrapper = retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_with_delays_and_condition.retry_never)
    assert call_counter == 0
    assert retry_wrapper(test_function) == 'ok'
    assert call_counter == 3

    call_counter = 0
    assert test_function() == 'ok'
    assert call_counter == 1

    call_counter = 0
    retry_wrapper = retry_with_delays_and_condition(generate_jittered_backoff())

# Generated at 2022-06-20 15:22:39.681931
# Unit test for function retry
def test_retry():
    # Create a decorator instance with a custom backoff strategy
    retry_delays_generator = generate_jittered_backoff(retries=3)
    retry_with_delays_decorator = retry_with_delays_and_condition(retry_delays_generator)

    # Decorate a retryable function that raises an exception
    @retry_with_delays_decorator
    def retryable_function():
        print("This function should be run 3 times")
        raise Exception("This is an exception.")

    try:
        retryable_function()
    except Exception as e:
        assert str(e) == "This is an exception."
        print("test_retry_with_delays_and_condition was successful.")



# Generated at 2022-06-20 15:22:47.042769
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    from collections import Counter

    delay_counts = Counter()

    BACKOFF_ITERATOR = generate_jittered_backoff(retries=10, delay_base=2, delay_threshold=5)

    for _ in range(1000):
        delay_counts[next(BACKOFF_ITERATOR)] += 1

    print(delay_counts)
    assert delay_counts[0] > 100
    assert delay_counts[1] > 100
    assert delay_counts[2] > 100
    assert delay_counts[3] > 100

# Generated at 2022-06-20 15:22:51.497361
# Unit test for function retry
def test_retry():
    """This function should be called once and succeed"""
    flag = [0]

    @retry()
    def myfunc():
        flag[0] += 1
        return 'spam'

    assert myfunc() == 'spam'
    assert flag[0] == 1



# Generated at 2022-06-20 15:22:54.535570
# Unit test for function retry
def test_retry():
    """
    This test function is called inside `test_retry_decorator` function
    """
    print("in test_retry")
    return True


# Generated at 2022-06-20 15:23:05.582803
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=1), retry_never)
    def always_raise_exception():
        raise Exception()
    with pytest.raises(Exception):
        always_raise_exception()

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=10, delay_base=1, delay_threshold=1), retry_never)
    def always_return():
        return 1
    assert always_return() == 1


# Generated at 2022-06-20 15:23:08.494809
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("unhandled exception") is False


# Generated at 2022-06-20 15:23:14.894768
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert spec == {'api_username': {'type': 'str'},
                    'api_password': {'type': 'str', 'no_log': True},
                    'api_url': {'type': 'str'},
                    'validate_certs': {'type': 'bool', 'default': True}
                    }, \
        "basic_auth_argument_spec should return predefined argument spec"

# Generated at 2022-06-20 15:23:15.782983
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(True) == False

# Generated at 2022-06-20 15:23:42.967487
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    def next(iterator, n=1):
        """Return the next n items of the iterator as a list"""
        return [next(iterator) for x in range(n)]

    assert next(generate_jittered_backoff(0)) == [0]
    assert next(generate_jittered_backoff(1)) == [0]
    assert next(generate_jittered_backoff(2)) == [0, 0]
    assert next(generate_jittered_backoff(10)) == next(generate_jittered_backoff(10))
    assert next(generate_jittered_backoff(), 3) != next(generate_jittered_backoff(), 3)

    for delay in generate_jittered_backoff():
        assert 0 <= delay <= 3


# Generated at 2022-06-20 15:23:52.565625
# Unit test for function retry_never
def test_retry_never():
    """Unit test for function retry_never"""
    import pytest
    # pylint: disable=unused-variable,missing-docstring

    class ExceptionToTest(Exception):
        """Test exception class"""
        pass

    def custom_retry(exception_or_result):
        if isinstance(exception_or_result, ExceptionToTest):
            return False
        return True

    # Test should return false for class ExceptionToTest
    result = retry_never(ExceptionToTest())
    assert result == False

    # Test should return false for ExceptionToTest when retry_never is used as a should_retry_error
    decorated_function = retry_with_delays_and_condition([], retry_never)
    @decorated_function
    def func_that_raises_exception():
        raise Exception

# Generated at 2022-06-20 15:24:01.325153
# Unit test for function retry
def test_retry():
    import random
    class Error(Exception): pass
    class Error1(Error): pass
    class Error2(Error): pass

    counter = 0
    @retry(retries=5, retry_pause=3)
    def test():
        global counter
        counter += 1
        rc = random.randint(1,10)
        if rc < 5:
            raise Error1()
        if rc < 10:
            raise Error2()
        return True

    assert counter == 0
    test()
    assert counter == 5

# Generated at 2022-06-20 15:24:05.728158
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()
    assert arg_spec == {'retries': {'type': 'int'},
                        'retry_pause': {'type': 'float',
                                        'default': 1
                                        }
                        }

# Generated at 2022-06-20 15:24:10.998269
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [delay for delay in generate_jittered_backoff()]
    assert delays[0] < delays[1]
    assert delays[4] > delays[3]

# Generated at 2022-06-20 15:24:17.447606
# Unit test for function rate_limit
def test_rate_limit():
    seconds = []
    @rate_limit(rate=5, rate_limit=10)
    def get_seconds():
        seconds.append(time.time())

    for i in range(0,10):
        get_seconds()
    seconds2 = seconds[:]
    seconds2.sort()
    assert len(seconds2) == len(seconds)
    assert seconds2[0] >= seconds[0]
    assert seconds2[-1] <= seconds[-1] + 0.01

# Generated at 2022-06-20 15:24:25.318750
# Unit test for function retry
def test_retry():

    @retry(retries=5, retry_pause=0.1)
    def f(retries):
        retries['calls'] += 1
        if not retries['result']:
            raise Exception('boom')
        else:
            return retries['result']

    retries = {'calls': 0, 'result': False}
    with pytest.raises(Exception):
        f(retries)
    assert retries['calls'] == 5

    retries = {'calls': 0, 'result': True}
    assert f(retries)
    assert retries['calls'] == 1

# Generated at 2022-06-20 15:24:28.589898
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == { 'retries': { 'type': 'int' }, 'retry_pause': { 'type': 'float', 'default': 1 } }
    assert retry_argument_spec({'a': 1}) == { 'retries': { 'type': 'int' }, 'retry_pause': { 'type': 'float', 'default': 1 }, 'a': 1 }


# Generated at 2022-06-20 15:24:40.189472
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    mod = AnsibleModule(basic_auth_argument_spec())
    mod.params = {
        'api_username': 'bob',
        'api_password': 'password',
        'api_url': 'http://localhost:8080',
        'validate_certs': False
    }
    if not PY3:
        # py2
        expected_result = {
            'api_username': 'bob',
            'api_password': 'password',
            'api_url': 'http://localhost:8080',
            'validate_certs': False,
        }

# Generated at 2022-06-20 15:24:42.568687
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff(5, delay_base=5, delay_threshold=60)
    assert all(item in range(0, 65) for item in backoff_iterator)


if __name__ == '__main__':
    test_generate_jittered_backoff()

# Generated at 2022-06-20 15:25:13.897060
# Unit test for function retry
def test_retry():
    @retry(2, 0.1)
    def silly_retry(a, b):
        print('attempt', a, b)
        if a == b:
            return a
        else:
            return None

    silly_retry(1, 1)
    silly_retry(2, 1)


# Generated at 2022-06-20 15:25:21.405153
# Unit test for function rate_limit
def test_rate_limit():
    start = time.time()
    @rate_limit(rate=1, rate_limit=1)
    def rate_limited_function(foo, bar):
        return "rate_limited_function called with %s and %s" % (foo, bar)
    end = time.time()
    delta = end - start
    assert delta > 1
    assert delta < 1.1
    result = rate_limited_function('foo', bar='bar')
    assert result == "rate_limited_function called with foo and bar"


# Generated at 2022-06-20 15:25:29.734734
# Unit test for function rate_limit
def test_rate_limit():
    '''
    This is a test function to demonstate how the
    rate limit decorator works.
    '''

    # this is a module parameter
    rate = 1

    # this is a module parameter
    rate_limit = 3

    @rate_limit(rate, rate_limit)
    def testing(log_time=True):
        '''
        just logs the time when this is called
        '''
        curtime = time.time()
        if log_time:
            print("testing() called at %s" % curtime)
        return curtime

    # time.time() returns the time in seconds
    # and the time is stored in this variable.
    startime = time.time()

    count = 0

    # the code will log the first time it is called
    # and then it goes into a loop, where it prints


# Generated at 2022-06-20 15:25:35.036657
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True}, 'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}}

# Generated at 2022-06-20 15:25:46.092309
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import mock
    import types

    # Generate some delays and create a function that should raise exceptions a number of times depending
    # on the delay, before returning a value.
    delays = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    # We'll use the index of the delay in the iterator to determine if we raise or not.
    # If the delay index is even, we'll raise an exception.
    # If the delay index is odd, we'll return the delay index.
    #
    # This will mean that the 10th delay should return a non-error value.
    # Otherwise, we should get an exception.
    exception_counts = 0
    for index, delay in enumerate(delays):
        if index % 2 == 0:
            exception_counts += 1

# Generated at 2022-06-20 15:25:47.340078
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for i in generate_jittered_backoff():
        print(i)



# Generated at 2022-06-20 15:25:49.950937
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1}
    }

# Generated at 2022-06-20 15:25:53.960319
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = (dict(
        foo=dict(type='int'),
        bar=dict(type='int')
    ))
    retry_spec = retry_argument_spec(arg_spec)
    for k in ('retries', 'retry_pause'):
        assert k in retry_spec, "retry_argument_spec did not include %s" % k
    for k in ('foo', 'bar'):
        assert k in retry_spec, "retry_argument_spec remove %s" % k

# Generated at 2022-06-20 15:26:05.199917
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # Test retry_argument_spec with no additional spec
    spec = None
    retry_spec = retry_argument_spec(spec)
    retry_spec_dict = dict(retries=dict(type='int'), retry_pause=dict(type='float', default=1))
    assert retry_spec == retry_spec_dict

    # Test retry_argument_spec with a basic retry spec
    spec = dict(retries=dict(type='int'), retry_pause=dict(type='float', default=1))
    retry_spec = retry_argument_spec(spec)
    assert retry_spec == retry_spec_dict

    # Test retry_argument_spec with a more complicated retry spec

# Generated at 2022-06-20 15:26:06.056486
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False



# Generated at 2022-06-20 15:27:07.243319
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(version=dict(type='str', default='v2.0'))
    function = basic_auth_argument_spec(spec)
    assert function == dict(
        version=dict(type='str', default='v2.0'),
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-20 15:27:14.683800
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest.mock
    backoff_iterator = [3, 4, 5]
    exceptions_list = [Exception("foo"), Exception("bar")]
    exceptions_list_iterator = iter(exceptions_list)
    exception_str = "foo"

    function_exception = unittest.mock.Mock(side_effect=lambda: next(exceptions_list_iterator))

    should_retry_error = unittest.mock.Mock(side_effect=[True, False])

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def raise_exception_function():
        function_exception()
        return None


# Generated at 2022-06-20 15:27:25.834099
# Unit test for function rate_limit
def test_rate_limit():
    def stub():
        pass

    # check that rate limit is not applied if rate_limit is negative, or rate is negative
    # or rate is 0
    for rate in [-1, 0]:
        for rate_limit in [-1, 0, 2]:
            assert rate_limit == stub()
            rate_limit_with_rate_limit(rate=rate, rate_limit=rate_limit)(stub)()

    # check that rate limit is not applied if rate is positive and rate_limit is negative
    for rate in [1, 2]:
        for rate_limit in [-1, 0]:
            assert rate_limit == stub()
            rate_limit_with_rate_limit(rate=rate, rate_limit=rate_limit)(stub)()

    # check that rate limit is not applied if rate is 0 and rate_limit is positive

# Generated at 2022-06-20 15:27:31.312640
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )
    assert(spec == basic_auth_argument_spec())

# Generated at 2022-06-20 15:27:40.768591
# Unit test for function retry
def test_retry():
    """Unit test for retry decorator."""
    class TestException(Exception):
        """Fake exception to test exception handling."""

    @retry(retries=5, retry_pause=1)
    def failing_function(should_fail):
        """Function that will fail for 2 seconds."""
        if should_fail:
            raise TestException('This function is supposed to fail')
        print('Succeeded')
        return False

    print('Will succeed after 2 seconds')
    start = time.time()
    try:
        failing_function(False)
    except Exception as e:
        print(e)
    end = time.time()
    assert end - start < 1.0
    print('Passed')

    print('Will fail after 5 seconds')
    start = time.time()

# Generated at 2022-06-20 15:27:47.106442
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import sys
    if sys.version_info >= (3, 0):
        raise AssertionError('Test not supported on Python 3')

    import nose
    from ansible.module_utils.urls import basic_auth_argument_spec

    results = dict(basic_auth_argument_spec())

    assert results['api_username'] == dict(type='str')
    assert results['api_password'] == dict(type='str', no_log=True)
    assert results['api_url'] == dict(type='str')
    assert results['validate_certs'] == dict(type='bool', default=True)


# Generated at 2022-06-20 15:27:58.231871
# Unit test for function retry
def test_retry():
    # Test for basic usage without exception
    try_count = 0

    def test():
        nonlocal try_count
        try_count += 1

    test = retry()(test)
    test()
    assert try_count == 1

    # Test for empty retries and retry_pause
    test = retry()(test)
    test()
    assert try_count == 2

    # Test for retries and retry_pause
    test = retry(retries=5, retry_pause=0.1)(test)
    test()
    assert try_count == 7

    # Test for retries, retry_pause and exception
    try_count = 0

    def test2():
        nonlocal try_count
        try_count += 1
        raise Exception()


# Generated at 2022-06-20 15:28:08.490308
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class test_retry_with_delays_and_condition(unittest.TestCase):
        def test_retry_with_delays_and_condition_success(self):
            call_count = 0
            # A dummy function returning the number of times the function has been called
            def func():
                nonlocal call_count
                call_count = call_count + 1
                return call_count
            backoff_iterator = generate_jittered_backoff(retries=10, delay_base=0, delay_threshold=0)
            retried_func = retry_with_delays_and_condition(backoff_iterator)(func)
            retried_func()
            self.assertEqual(call_count, 1)


# Generated at 2022-06-20 15:28:12.546067
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert(basic_auth_argument_spec() == {'api_username': {'type': 'str'}, 'api_password': {'type': 'str', 'no_log': True}, 'api_url': {'type': 'str'}, 'validate_certs': {'type': 'bool', 'default': True}})

# Generated at 2022-06-20 15:28:13.378040
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("foo") == False

# Generated at 2022-06-20 15:30:21.179904
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('exception_or_result') == False



# Generated at 2022-06-20 15:30:24.938336
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert 'rate' in arg_spec, 'rate argument not added by a rate_limit_argument_spec'
    assert 'rate_limit' in arg_spec, 'rate_limit argument not added by a rate_limit_argument_spec'


# Generated at 2022-06-20 15:30:34.176291
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def test_func(fail_string, fail_count, fail_count_2, fail_count_3, fail_delay):
        # fail_string: string to use in error message
        # fail_count: initial number of times to fail
        # fail_count_2: number of times to fail on retry attempt
        # fail_count_3: number of times to fail on retry attempt
        # fail_delay: seconds to delay if we are going to fail
        if not hasattr(test_func, 'calls'):
            test_func.calls = 0
        test_func.calls += 1

        if test_func.calls <= fail_count:
            if fail_delay > 0:
                time.sleep(fail_delay)
            raise Exception(fail_string)