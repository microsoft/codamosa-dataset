

# Generated at 2022-06-20 15:20:41.196287
# Unit test for function retry
def test_retry():
    """
    Unit test for function retry
    """
    @retry(retries=4)
    def foo():
        print("hello")

    foo()

# Generated at 2022-06-20 15:20:43.080020
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert arg_spec is not None


# Generated at 2022-06-20 15:20:51.738166
# Unit test for function rate_limit
def test_rate_limit():
    """ test rate_limit decorator """
    @rate_limit(rate=2, rate_limit=1)
    def test_rate_limited():
        print(".")

    @rate_limit()
    def test_default_rate():
        print(".")

    @rate_limit(rate=2, rate_limit=2)
    def test_no_limit():
        print(".")

    print("2 rate limit every .5 seconds")
    for _ in range(3):
        test_rate_limited()
        time.sleep(0.5)

    print("2 default rate limit every 1 seconds")
    for _ in range(3):
        test_default_rate()
        time.sleep(0.5)

    print("2 without rate limit")
    for _ in range(3):
        test_no_limit()
        time

# Generated at 2022-06-20 15:20:57.408351
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('exception') == False


# Generated at 2022-06-20 15:21:03.521611
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    sys.modules['ansible'] = type('object')()
    sys.modules['ansible.module_utils'] = type('object')()
    import ansible.module_utils
    spec = basic_auth_argument_spec()
    assert spec == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-20 15:21:10.291753
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert isinstance(rate_limit_argument_spec(), dict)
    assert len(rate_limit_argument_spec()) == 2
    assert isinstance(rate_limit_argument_spec({'new_key': {'type': 'int'}}), dict)
    assert len(rate_limit_argument_spec({'new_key': {'type': 'int'}})) == 3


# Generated at 2022-06-20 15:21:21.156881
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import random

    class FailingClass(object):
        def __init__(self, fail_on_iteration):
            self.fail_on_iteration = fail_on_iteration

        @retry_with_delays_and_condition(generate_jittered_backoff(retries=10), should_retry_error=lambda e: True)
        def failing_method(self):
            self.fail_on_iteration -= 1
            if self.fail_on_iteration >= 0:
                raise Exception("function failed")
            return True

    test_subject = FailingClass(random.randint(0, 10))
    test_subject.failing_method()
    assert test_subject.fail_on_iteration < 0

# Generated at 2022-06-20 15:21:27.014465
# Unit test for function retry
def test_retry():
    calls = [0]

    @retry(retries=3, retry_pause=0.1)
    def test_func():
        calls[0] += 1
        if calls[0] >= 2:
            return True
        else:
            return None
    test_func()
    assert calls == [2]



# Generated at 2022-06-20 15:21:30.492183
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = [round(delay) for delay in generate_jittered_backoff(retries=3, delay_base=2, delay_threshold=60)]
    assert delays == [0, 2, 6]

# Generated at 2022-06-20 15:21:32.458774
# Unit test for function retry
def test_retry():
    @retry(retries=3)
    def test():
        print(time.time())
        return True

    test()


# Generated at 2022-06-20 15:21:40.230199
# Unit test for function retry_never
def test_retry_never():
    for f in (retry_never, retry_never):
        class TestException(Exception):
            pass
        assert f(Result('a', 'b')) is False
        assert f(TestException('a', 'b')) is False


# Generated at 2022-06-20 15:21:48.361547
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.api import basic_auth_argument_spec
    from ansible.module_utils.api import retry_argument_spec

    spec = basic.AnsibleModule(
        argument_spec=basic_auth_argument_spec(spec=retry_argument_spec()),
    ).params
    assert isinstance(spec, Mapping)
    assert set(spec) == set(('validate_certs', 'api_url', 'retry_pause', 'retries', 'api_password', 'api_username'))
    assert isinstance(spec['api_url'], (type(None), str))

# Generated at 2022-06-20 15:21:53.959938
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    jb = generate_jittered_backoff()
    assert next(jb) <= 3
    assert next(jb) <= 3
    assert 9 <= next(jb) <= 18
    assert 27 <= next(jb) <= 54
    assert 81 <= next(jb) <= 60
    assert 24 <= next(jb) <= 60
    assert 72 <= next(jb) <= 60
    assert 54 <= next(jb) <= 60
    assert 36 <= next(jb) <= 60
    assert 18 <= next(jb) <= 60

# Generated at 2022-06-20 15:21:58.673455
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    argument_spec = retry_argument_spec(spec=dict(foo=dict(type='str')))
    assert argument_spec.get('foo') is not None
    assert argument_spec.get('foo')['type'] == 'str'
    assert argument_spec.get('retries') is not None
    assert argument_spec.get('retries')['type'] == 'int'
    assert argument_spec.get('retry_pause') is not None
    assert argument_spec.get('retry_pause')['type'] == 'float'

# Generated at 2022-06-20 15:22:07.579312
# Unit test for function retry
def test_retry():
    """ Unit tests for function retry() """
    def foo(retries, retry_pause):
        foo.count = 0
        def foo_func():
            if foo.count < retries:
                foo.count = foo.count + 1
                raise Exception('foo error')
            return True

        return foo_func

    @retry(retries=3, retry_pause=1)
    def foo3():
        return foo(3, 1)()

    @retry(retries=2, retry_pause=2)
    def foo2():
        return foo(2, 2)()


# Generated at 2022-06-20 15:22:11.645439
# Unit test for function retry
def test_retry():
    @retry(retries=5, retry_pause=0)
    def test_retry_function():
        print("test_retry_function was called")
        return True

    test_retry_function()

# Generated at 2022-06-20 15:22:14.441343
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {'retries': {'type': 'int'}, 'retry_pause': {'default': 1, 'type': 'float'}}

# Generated at 2022-06-20 15:22:22.378729
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    backoff_list = list(backoff)

    assert len(backoff_list) == 10
    assert max(backoff_list) <= 60


# Generated at 2022-06-20 15:22:30.180028
# Unit test for function retry_never
def test_retry_never():
    """ Ensures the retry_never function only retries when there is no result or
        when a exception is raised."""

    def create_args(exception=None, result=None):
        def f():
            if exception:
                raise exception
            return result
        return f

    assert retry_never(create_args(None, False)) is False
    assert retry_never(create_args(None, True)) is False
    assert retry_never(create_args(Exception(), False)) is False
    assert retry_never(create_args(Exception(), True)) is False
    assert retry_never(create_args(Exception())) is False

# Generated at 2022-06-20 15:22:38.020416
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import collections

    def count_occurences(values):
        """Count occurrences of every value."""
        return collections.Counter(values)

    expected_occurences = {3: 0.1, 6: 0.2, 12: 0.2, 24: 0.2, 48: 0.2, 60: 0.1}
    backoff_values = generate_jittered_backoff()
    values_count = count_occurences(backoff_values)
    for backoff_value, count in values_count.items():
        assert backoff_value in expected_occurences
        assert abs(count - expected_occurences[backoff_value]) < 0.1

# Generated at 2022-06-20 15:22:56.162992
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    def function_one(number):
        if number == 0:
            return 0
        else:
            raise Exception('Failed')

    def function_two(number):
        if number == 1:
            return 1
        else:
            raise IndexError('Failed')

    # No maximum delay, retry 10 times
    retry_one_n_times = retry_with_delays_and_condition(generate_jittered_backoff(10))
    retry_two_n_times = retry_with_delays_and_condition(generate_jittered_backoff(10))

    # Retry 10 times, after a maximum delay of 60 seconds
    retry_one = retry_with_delays_and_condition(generate_jittered_backoff(10, delay_threshold=60))
    retry

# Generated at 2022-06-20 15:23:01.598460
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    module = AnsibleModule(argument_spec=retry_argument_spec())

    module.params = {'retries': 4, 'retry_pause': 5.5}
    assert module.params.get('retries') == 4
    assert module.params.get('retry_pause') == 5.5



# Generated at 2022-06-20 15:23:09.124685
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.common.connection import ConnectionBase
    from ansible.module_utils.basic_auth import BasicAuth as Auth
    
    class Connection(ConnectionBase):
        def __init__(self, *args, **kwargs):
            super(Connection, self).__init__(*args, **kwargs)
            self._auth = Auth(creds=self._play_context.password, url=self._play_context.remote_addr)

        def _connect(self):
            return None

    C = Connection(module_name='test')
    C.check_connection()
    assert C._auth.url == 'http://localhost:5985'
    assert C._auth.session.auth == ('postgres', 'postgres')
    assert C._auth.session.verify is True

# Generated at 2022-06-20 15:23:19.498455
# Unit test for function rate_limit
def test_rate_limit():
    def func(a):
        print("function is called")
        return a

    # 1 call, rate = 0.5, rate_limit = 1 -> OK
    rate, rate_limit = 0.5, 1
    args = dict(rate=rate, rate_limit=rate_limit)
    print("args: {args}".format(args=args))
    func2 = rate_limit(**args)(func)
    func2(1)
    time.sleep(1)

    # 2 call, rate = 0.5, rate_limit = 1 -> Must fail
    func2(1)

    # 3 call, rate = 0.5, rate_limit = 1 -> Must fail
    func2(1)
    time.sleep(1)

    # 4 call, rate = 0.5, rate_limit = 1 -> OK

# Generated at 2022-06-20 15:23:29.122943
# Unit test for function rate_limit
def test_rate_limit():
    # Python >= 3.8 has time.process_time()
    # Python < 3.8 has time.clock()
    # The time.clock() doesn't take into account the time spent waiting
    # for the function to execute.  Here is a test that covers that case.
    if sys.version_info >= (3, 8):
        test_time = 'process_time'
    else:
        test_time = 'clock'
    @rate_limit(2, 2)
    def func(delay_in_s):
        time.sleep(delay_in_s)

    func(.5)
    t_before_func = getattr(time, test_time)()
    func(.5)
    t_after_func = getattr(time, test_time)()
    diff = t_after_func - t_before_

# Generated at 2022-06-20 15:23:31.151347
# Unit test for function retry_never
def test_retry_never():
    assert False == retry_never('some_exception')
    assert False == retry_never('some_result')

# Generated at 2022-06-20 15:23:36.718355
# Unit test for function rate_limit
def test_rate_limit():
    rate = 100
    rate_limit = 1
    minrate = float(rate_limit) / float(rate)
    print(minrate)
    def tstf():
        print("test")

    @rate_limit(rate, rate_limit)
    def callback():
        tstf()


    for i in range(10):
        callback()


# Generated at 2022-06-20 15:23:38.232328
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:23:43.455948
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_arg_spec = rate_limit_argument_spec()
    assert rate_arg_spec
    assert rate_arg_spec.get('rate')
    assert rate_arg_spec.get('rate_limit')
    assert rate_arg_spec.get('rate').get('type') == 'int'
    assert rate_arg_spec.get('rate_limit').get('type') == 'int'


# Generated at 2022-06-20 15:23:49.826675
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for rate_limit function"""
    import time

    expected_wait = 0.3

    @rate_limit(10, 60)
    def print_some(text):
        """rate limited print statement"""
        # print("called")
        return text

    start_time = time.time()
    for _ in range(1, 11):
        # print("called")
        assert print_some("test") == "test"
    assert (time.time() - start_time) > expected_wait


# Generated at 2022-06-20 15:24:05.761885
# Unit test for function rate_limit
def test_rate_limit():
    last = [0.0]

    def real_time():
        return time.clock()

    @rate_limit(rate=3, rate_limit=1)
    def my_func(foo):
        global last
        assert last[0] == 0.0
        last[0] = real_time()
        return foo

    my_func('bar')
    assert last[0] != 0.0
    assert my_func('baz') == 'baz'
    assert last[0] != 0.0

# Unit tests for function retry

# Generated at 2022-06-20 15:24:09.214350
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert isinstance(basic_auth_argument_spec(), dict)


# Generated at 2022-06-20 15:24:10.696639
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('anything') == False


# Generated at 2022-06-20 15:24:17.527562
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=retry_argument_spec())

    assert module.params['retries'] is None
    assert module.params['retry_pause'] == 1

    module = AnsibleModule(argument_spec=retry_argument_spec(dict(retries=dict(required=True))))

    assert module.params['retries'] is None
    assert module.params['retry_pause'] == 1


# Generated at 2022-06-20 15:24:22.961652
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert 'api_username' in basic_auth_argument_spec()
    assert 'api_password' in basic_auth_argument_spec()
    assert 'api_url' in basic_auth_argument_spec()
    assert 'validate_certs' in basic_auth_argument_spec()


# Generated at 2022-06-20 15:24:28.555126
# Unit test for function retry
def test_retry():
    """Test retry function decorator"""
    # Result should be 3 as the function is called 3 times
    # even though retries = 5
    @retry(retries=5, retry_pause=0)
    def test():
        """test function, we count calls"""
        test.calls += 1
        if test.calls < 3:
            raise Exception("test")
        else:
            return True

    test.calls = 0
    test()
    assert test.calls == 3



# Generated at 2022-06-20 15:24:36.717058
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    import json
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=basic_auth_argument_spec({'foo': dict(type='int')})
    )
    assert module.params['foo'] is None
    assert module.params['api_username'] is None
    assert module.params['api_password'] is None
    assert module.params['api_url'] is None
    assert module.params['validate_certs'] is True



# Generated at 2022-06-20 15:24:39.292199
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    import random

    random.seed(0)
    assert list(generate_jittered_backoff(retries=3, delay_base=3)) == [0, 1, 5]

# Generated at 2022-06-20 15:24:44.469504
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    test_spec = dict(
        bla_bla=dict(type='str'),
        test=dict(type='str', default='test')
    )
    assert retry_argument_spec(spec=test_spec) == dict(
        retry_pause=dict(type='float', default=1),
        retries=dict(type='int'),
        bla_bla=dict(type='str'),
        test=dict(type='str', default='test')
    )



# Generated at 2022-06-20 15:24:49.526008
# Unit test for function retry
def test_retry():
    @retry(retries=None)
    def test_retryable():
        print("Try")
        return None

    test_retryable()
    test_retryable()
    test_retryable()
    test_retryable()
    #TODO: asserts



# Generated at 2022-06-20 15:25:03.911967
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec({'argument1': dict(type='str'), 'argument2': dict(type='str')})
    assert arg_spec == {
        'argument1': dict(type='str'),
        'argument2': dict(type='str'),
        'api_username': dict(type='str'),
        'api_password': dict(no_log=True, type='str'),
        'api_url': dict(type='str'),
        'validate_certs': dict(default=True, type='bool')
    }

# Generated at 2022-06-20 15:25:09.146826
# Unit test for function retry
def test_retry():
    """Unit test for retry"""
    @retry(retries=3)
    def test_retry_function(state=False):
        """test for retry decorator"""
        if not state:
            return False
        else:
            return True

    assert not test_retry_function(state=False)
    assert test_retry_function(state=True)



# Generated at 2022-06-20 15:25:13.497984
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_arg_spec = rate_limit_argument_spec()

    assert "rate" in rate_limit_arg_spec
    assert rate_limit_arg_spec["rate"]["type"] == "int"

    assert "rate_limit" in rate_limit_arg_spec
    assert rate_limit_arg_spec["rate_limit"]["type"] == "int"


# Generated at 2022-06-20 15:25:24.326786
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class AlwaysRetryError(Exception):
        pass

    class NeverRetryError(Exception):
        pass

    class RaisesAlwaysRetryAndLastlyNeverRetryError(object):
        def __init__(self, number_of_always_retry_errors, number_of_never_retry_errors):
            self.number_of_always_retry_errors = number_of_always_retry_errors
            self.number_of_never_retry_errors = number_of_never_retry_errors

        def __call__(self, *_args, **_kwargs):
            number_of_always_retry_errors = self.number_of_always_retry_errors
            number_of_never_retry_errors = self.number_of_never_retry_errors

# Generated at 2022-06-20 15:25:34.991024
# Unit test for function retry
def test_retry():
    import time
    from ansible.module_utils.basic import AnsibleModule

    arg_spec = dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )
    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True)
    fail = module.params.get('fail', True)
    run = module.params.get('run', True)
    want = module.params.get('want', 4)
    got = -1

    @retry(module.params['retries'], float(module.params['retry_pause']))
    def do_test():
        nonlocal got
        got += 1

# Generated at 2022-06-20 15:25:43.569863
# Unit test for function rate_limit
def test_rate_limit():
    """
    Unit tests for rate_limit, not actual module usage
    """
    class Foo:
        @rate_limit(rate=2, rate_limit=2)
        def bar(self):
            """This would be a test method, for unit testing rate limit"""
            return True

    f = Foo()
    f.bar()
    f.bar()
    # we should wait at least up to rate_limit seconds, if earlier we raise an error
    start = time.time()
    f.bar()
    end = time.time() - start
    if end < 1:
        raise Exception("Rate limit not working: %s" % end)



# Generated at 2022-06-20 15:25:49.734717
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = {
        'api_username': dict(type='str'),
        'api_password': dict(type='str', no_log=True),
        'api_url': dict(type='str'),
        'validate_certs': dict(type='bool', default=True),
        'rate': dict(type='int'),
        'rate_limit': dict(type='int'),
    }
    assert rate_limit_argument_spec() == arg_spec


# Generated at 2022-06-20 15:25:52.947948
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """Unit test for basic_auth_argument_spec"""
    arg_spec = basic_auth_argument_spec()

    assert(arg_spec.get('api_username'))

# Generated at 2022-06-20 15:25:53.735194
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False

# Generated at 2022-06-20 15:26:01.235732
# Unit test for function retry
def test_retry():
    class TestException(Exception):
        pass

    @retry(retries=3, retry_pause=3)
    def retry_function():
        print("retry_function")
        raise TestException()

    try:
        retry_function()
    except Exception as e:
        assert(isinstance(e, TestException))
        print("retry_function raised TestException as expected")

if __name__ == '__main__':
    test_retry()

# Generated at 2022-06-20 15:26:13.702544
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False, "retry_never did not return False when it should"
    assert retry_never(Exception()) == False, "retry_never did not return False when it should"


# Generated at 2022-06-20 15:26:17.398446
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    actual = []
    expected = [3, 1, 6, 7, 0, 47, 5, 7, 34, 10]
    for jittered_backoff in generate_jittered_backoff():
        actual.append(jittered_backoff)

    assert actual == expected

# Generated at 2022-06-20 15:26:20.621480
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(False)
    assert not retry_never(True)
    try:
        assert not retry_never(1 / 0)
    except ZeroDivisionError:
        pass

# Generated at 2022-06-20 15:26:27.344463
# Unit test for function rate_limit
def test_rate_limit():
    """This test takes ~10 seconds on a decent machine"""
    rate = 10
    limit = 5
    minrate = float(limit) / float(rate)

    @rate_limit(rate=rate, rate_limit=limit)
    def test_api():
        return True

    start = time.time()
    for _ in range(0, rate):
        test_api()
    duration = time.time() - start
    assert minrate < duration < minrate * 2

# Generated at 2022-06-20 15:26:28.299535
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('a') == False



# Generated at 2022-06-20 15:26:30.340644
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:26:37.908273
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = (dict(
        api_username=dict(type='str', default='test'),
        validate_certs=dict(type='bool', default=True)
    ))
    auth = basic_auth_argument_spec(spec)
    assert auth == dict(api_username=dict(type='str', default='test'),
                        api_password=dict(type='str', no_log=True),
                        api_url=dict(type='str'),
                        validate_certs=dict(type='bool', default=True))

# Generated at 2022-06-20 15:26:49.042850
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    retry_spec = retry_argument_spec()
    assert 'retries' in retry_spec.keys()
    assert 'retry_pause' in retry_spec.keys()
    assert retry_spec['retries']['type'] == 'int'
    assert retry_spec['retry_pause']['type'] == 'float'
    assert retry_spec['retry_pause']['default'] == 1

    retry_spec = retry_argument_spec({'extra_arg': dict(type='int', default=5)})
    assert 'extra_arg' in retry_spec.keys()
    assert retry_spec['extra_arg']['type'] == 'int'
    assert retry_spec['extra_arg']['default'] == 5


# Generated at 2022-06-20 15:26:54.194231
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import basic_auth_argument_spec
    module = AnsibleModule(argument_spec=basic_auth_argument_spec())
    result = dict(
        changed=False,
        original_message='',
        message=''
    )
    module.exit_json(**result)



# Generated at 2022-06-20 15:26:58.310158
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = basic_auth_argument_spec()
    assert 'api_username' in spec
    assert 'api_password' in spec
    assert 'api_url' in spec
    assert 'validate_certs' in spec

# Generated at 2022-06-20 15:27:18.862901
# Unit test for function retry_never
def test_retry_never():
    # Add tests for exception retry_never
    assert retry_never("success") is False
    assert retry_never("failed") is False
    assert retry_never("error") is False


# Generated at 2022-06-20 15:27:23.394072
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {
            'type': 'int'
        },
        'retry_pause': {
            'type': 'float',
            'default': 1
        }
    }


# Generated at 2022-06-20 15:27:28.400182
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == dict(api_username=dict(type='str'),
                                        api_password=dict(type='str', no_log=True),
                                        api_url=dict(type='str'),
                                        validate_certs=dict(type='bool', default=True)
    )

# Generated at 2022-06-20 15:27:30.773881
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arguments = basic_auth_argument_spec(None)
    assert 4 == len(arguments)

# Generated at 2022-06-20 15:27:38.345568
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.api import base_arg_spec
    from ansible.module_utils.api import basic_auth_argument_spec
    from ansible.module_utils.api import retry_argument_spec

    arg_spec = base_arg_spec()
    arg_spec.update(retry_argument_spec(basic_auth_argument_spec()))
    module = AnsibleModule(
        argument_spec=arg_spec,
        supports_check_mode=True,
    )
    module.exit_json(changed=True)


# Generated at 2022-06-20 15:27:42.777255
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        echo=dict(type='str'),
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

    new_spec = rate_limit_argument_spec(spec)
    assert 'echo' in new_spec
    assert 'rate' in new_spec
    assert 'rate_limit' in new_spec


# Generated at 2022-06-20 15:27:46.426860
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = retry_argument_spec()
    assert 'retries' in spec
    assert spec['retries']['type'] == 'int'
    assert 'retry_pause' in spec
    assert spec['retry_pause']['type'] == 'float'
    assert spec['retry_pause']['default'] == 1

# Generated at 2022-06-20 15:27:55.485322
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    mod = AnsibleModule(
        argument_spec=retry_argument_spec(),
        supports_check_mode=True,
    )
    assert isinstance(mod.params, dict)
    assert 'retry_pause' in mod.params
    assert mod.params['retry_pause'] == 1

    connection = Connection(mod._name, mod)
    assert isinstance(connection.params, dict)
    assert 'retry_pause' in connection.params
    assert connection.params['retry_pause'] == 1



# Generated at 2022-06-20 15:27:58.624276
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    result = basic_auth_argument_spec()
    assert isinstance(result, dict)
    assert 'api_password' in result
    assert 'api_username' in result
    assert 'api_url' in result



# Generated at 2022-06-20 15:28:09.545782
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    try:
        from ansible.module_utils.ansible_release import __version__ as ansible_version
    except ImportError:
        ansible_version = '2.3.2.0'

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    basic_auth_arg_spec = basic_auth_argument_spec()
    # AnsibleModule.argument_spec is only supported in ansible v2.3.2.0
    if LooseVersion(ansible_version) >= LooseVersion('2.3.2.0'):
        module = AnsibleModule(argument_spec=basic_auth_arg_spec)
        username = module.params['api_username']
        password = module.params['api_password']

# Generated at 2022-06-20 15:29:28.372901
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert rate_limit_argument_spec(dict()) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    assert rate_limit_argument_spec(dict(a=1)) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        a=dict(type='int')
    )
    assert rate_limit_argument_spec(dict(rate=1)) == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )

# Generated at 2022-06-20 15:29:34.331782
# Unit test for function rate_limit
def test_rate_limit():
    import nose
    import nose.tools

    @rate_limit(5, 300)
    def get_value():
        return True

    for x in range(0, 20):
        get_value()
        time.sleep(1)

    nose.tools.assert_equal(get_value(), True)



# Generated at 2022-06-20 15:29:38.364866
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module = FakeModule()
    rate_limit_argument_spec(module)
    assert module.argument_spec == {'rate_limit': {'type': 'int'}, 'rate': {'type': 'int'}}


# Generated at 2022-06-20 15:29:42.900635
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_arg_spec = rate_limit_argument_spec()
    assert rate_limit_arg_spec['rate']['type'] == 'int'
    assert rate_limit_arg_spec['rate_limit']['type'] == 'int'

    # Do not alter passed in argument spec
    custom_arg_spec = {}
    rate_limit_arg_spec = rate_limit_argument_spec(custom_arg_spec)
    assert rate_limit_arg_spec is not custom_arg_spec


# Generated at 2022-06-20 15:29:46.599729
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(1, 10)
    def test():
        return time.time()
    test()
    now = time.time()
    test()
    delta = time.time() - now
    assert delta > 5.0
    assert delta < 10.0

# Generated at 2022-06-20 15:29:55.146876
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    module_name = 'test_rate_limit_argument_spec'
    d1 = {'rate': {'required': False, 'type': 'int', 'aliases': []}}
    d2 = {'rate_limit': {'type': 'int', 'required': False, 'aliases': []}}
    argument_spec = rate_limit_argument_spec()
    assert argument_spec[module_name]['rate'] == d1
    assert argument_spec[module_name]['rate_limit'] == d2


# Generated at 2022-06-20 15:29:58.012009
# Unit test for function rate_limit
def test_rate_limit():
    def test_func():
        pass

    assert type(rate_limit(1, 1)(test_func)) == type(test_func)
    assert rate_limit(1, 1)(test_func)() is None



# Generated at 2022-06-20 15:30:07.145335
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import math
    import random

    def rate_limited_func(msg="foo", n=10):
        """
        Do something with the input string,
        Repeating n times. Makes it easy to test
        """
        for x in range(n):
            time.sleep(random.randint(0, 5))
            print("%s %s" % (msg, x))

    rate_limit = 10   # Max 10 calls per second
    burst = 10        # 10 bursts per second is fine
    max_wait = 0.005  # 0.5ms wait tops

    if rate_limit:
        rate_limited_func = rate_limit(rate=rate_limit, rate_limit=1)(rate_limited_func)

    start = time.time()
    for x in range(0, burst):
        rate_limited

# Generated at 2022-06-20 15:30:11.887068
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = generate_jittered_backoff(retries=3, delay_base=3, delay_threshold=60)
    retryable_delays = []
    nonretryable_delays = []

    def should_retry_error(exception):
        nonretryable_delays.append(next(backoff_iterator))
        return False

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def retryable_function():
        delay = next(backoff_iterator)
        retryable_delays.append(delay)
        raise Exception(str(delay))

    try:
        retryable_function()
    except Exception:
        pass

    assert retryable_delays == [1, 1]
    assert nonretry

# Generated at 2022-06-20 15:30:16.575712
# Unit test for function retry
def test_retry():
    res = []
    def func():
        res.append(0)
        raise Exception("blah")

    retried = retry(retries=3, retry_pause=0)(func)
    try:
        retried()
    except Exception:
        pass
    assert res == [0, 0, 0, 0], res