

# Generated at 2022-06-20 15:20:48.907256
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec(spec={'api_username': dict(type='str'),
                                            'api_password': dict(type='str', no_log=True),
                                            'api_url': dict(type='str'),
                                            'validate_certs': dict(type='bool', default=False)})
    assert arg_spec == {
        'api_username': dict(type='str'),
        'api_password': dict(type='str', no_log=True),
        'api_url': dict(type='str'),
        'validate_certs': dict(type='bool', default=False)
    }, "Failed on empty argument spec."

# Generated at 2022-06-20 15:20:53.668581
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=retry_never)
    def f():
        return 1
    assert f() == 1

    @retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff(), should_retry_error=retry_never)
    def g():
        raise Exception("foo")
    try:
        g()
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-20 15:20:59.174142
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    from unittest import TestCase

    class TestRateLimitArgumentSpec(TestCase):

        def test_rate_limit_argument_spec(self):
            arg_spec = rate_limit_argument_spec({'param1': {'required': True, 'type': 'str'}})
            wanted_result = {'param1': {'required': True, 'type': 'str'}, 'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}
            self.assertEqual(arg_spec, wanted_result)

    # Execute Test
    TestRateLimitArgumentSpec().test_rate_limit_argument_spec()

# Generated at 2022-06-20 15:21:02.356551
# Unit test for function retry_never
def test_retry_never():
    import unittest
    class Test(unittest.TestCase):
        def setUp(self):
            self.test_function = retry_never

        def test_passes_through(self):
            self.assertTrue(self.test_function(None))

    unittest.main()


# Generated at 2022-06-20 15:21:08.677853
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec() == {
         "api_username": {"type": "str"},
         "api_password": {"no_log": True, "type": "str"},
         "api_url": {"type": "str"},
         "validate_certs": {"default": True, "type": "bool"},
    }

# Generated at 2022-06-20 15:21:14.998068
# Unit test for function retry
def test_retry():
    @retry_with_delays_and_condition(generate_jittered_backoff(retries=5, delay_threshold=60))
    def do_something_important(arg):
        print('trying something important')
        if arg == 'blah':
            raise RuntimeError
        if arg == 'flip':
            raise TypeError
        return "yes"

    ret = do_something_important('blah')
    assert ret == "yes"

# Generated at 2022-06-20 15:21:24.907175
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Test a retry decorator that retries once and sleeps for a fixed amount of time."""
    # No delays means we try the function once, then only the last time
    # The function returns 1,2,3 the three times it's called.
    @retry_with_delays_and_condition([], retry_never)
    def return_number_plus_one():
        return_number_plus_one.counter += 1
        return return_number_plus_one.counter
    return_number_plus_one.counter = 0
    assert return_number_plus_one() == 1
    assert return_number_plus_one() == 4

    # We try the function 3 times with a delay of 1,2,4 seconds

# Generated at 2022-06-20 15:21:28.826547
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():

    args = basic_auth_argument_spec()
    expected = (dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    ))
    assert args == expected

# Generated at 2022-06-20 15:21:40.435422
# Unit test for function rate_limit
def test_rate_limit():
    import unittest

    class TestRateLimit(unittest.TestCase):
        """Test rate_limit decorator.
        Test for different values apply for time.process_time and time.time
        To work correctly at the unittest time.time has to be mock for time.process_time
        """

        def setUp(self):
            if sys.version_info >= (3, 8):
                self.time_func = time.process_time
            else:
                self.time_func = time.time

            def wrapper_time():
                return self.time_func()

            time.time = wrapper_time

        def tearDown(self):
            time.time = self.time_func

        @rate_limit(3, 2)
        def f(self, rate):
            return rate


# Generated at 2022-06-20 15:21:42.421640
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        assert delay >= 0
        assert delay <= 60
        assert type(delay) is int

# Generated at 2022-06-20 15:21:57.020263
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert isinstance(result, dict), \
        '{name}() returned {type}, expected {exp}'.format(name='rate_limit_argument_spec',
                                                          type=type(result),
                                                          exp=type({}))
    assert 'rate' in result, \
        '{name}() did not return \'rate\' in dictionary'.format(name='rate_limit_argument_spec')
    assert 'rate_limit' in result, \
        '{name}() did not return \'rate_limit\' in dictionary'.format(name='rate_limit_argument_spec')



# Generated at 2022-06-20 15:22:02.918074
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_arg_spec = rate_limit_argument_spec()
    assert rate_limit_arg_spec['rate']['type'] == 'int'
    assert rate_limit_arg_spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-20 15:22:10.963819
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    """This test verifies that rate_limit_argument_spec returns the expected structure"""
    expected_spec = {
        'rate': {'type': 'int'},
        'rate_limit': {'type': 'int'}
    }
    assert rate_limit_argument_spec() == expected_spec



# Generated at 2022-06-20 15:22:20.437908
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Test function
    def function(fail_count):
        if fail_count == 0:
            return "Success"
        raise Exception("TestException")

    # Test arguments
    number_of_retries = 3
    call_delay_base = 3

    # Unit test
    @retry_with_delays_and_condition(generate_jittered_backoff(number_of_retries, call_delay_base))
    def test_retry_until_unhandled_exception(fail_count):
        # Throws an exception on the first call, retries until it reaches the number of retries.
        # The exception is not handled by the retry condition.
        return function(fail_count)

    # Test cases
    assert test_retry_until_unhandled_exception(1) == "Success"


# Generated at 2022-06-20 15:22:30.503282
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Verify that function generate_jittered_backoff provides expected values."""
    # Iterate twice to verify that each iteration has different delays.
    for _ in range(0, 2):
        backoff_list = list(generate_jittered_backoff())
        backoff_list_expected = [0, 3, 5, 7, 9, 12, 14, 16, 18, 20]
        assert backoff_list == backoff_list_expected, "Expected backoff_list does not match iteration {}".format(backoff_list)

    # Iterate twice to verify that each iteration has different delays.
    for _ in range(0, 2):
        backoff_list = list(generate_jittered_backoff(retries=5, delay_base=1, delay_threshold=20))

# Generated at 2022-06-20 15:22:38.255587
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    my_spec = basic_auth_argument_spec()
    expected = {
        'api_username': {'type': 'str'},
        'api_password': {'type': 'str', 'no_log': True},
        'api_url': {'type': 'str'},
        'validate_certs': {'type': 'bool', 'default': True}
    }
    assert(len(my_spec) == len(expected))
    for key, value in my_spec.items():
        assert(expected[key] == value)
    return True

if __name__ == '__main__':
    print(test_basic_auth_argument_spec())

# Generated at 2022-06-20 15:22:45.430029
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class TestRetryWithDelays(unittest.TestCase):
        def test_retry_with_delays_and_condition(self):
            attempts = []
            def failing_function(number_of_failures):
                def function(x):
                    attempts.append(x)
                    if len(attempts) <= number_of_failures:
                        raise Exception("Failed")
                    return x
                return function

            # Test all failures
            f = retry_with_delays_and_condition(
                [(0, 0), (0, 0), (0, 0)],
                should_retry_error=retry_never
            )(failing_function(3))
            self.assertRaises(Exception, f, "Test")

            # Test 2 failures, then success, then failure

# Generated at 2022-06-20 15:22:47.473050
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception())


# Generated at 2022-06-20 15:22:52.556325
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for i in generate_jittered_backoff(retries=10, delay_base=3):
        print(i)
    # Sample output:
    # 2
    # 2
    # 2
    # 2
    # 0
    # 1
    # 2
    # 5
    # 1
    # 3


# Generated at 2022-06-20 15:23:03.766847
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """
    Tests the retry_with_delays_and_condition function and the retry_never function

    1. Tests the retry_never function
        a. Tests that function returns false
        b. Tests that function throws exception for non-exception argument

    2. Tests the retry_with_delays_and_condition function
        a. Tests that function throws exception for non-exception argument
        b. Tests that function returns false for non-exception argument
        c. Tests that function returns true for an exception argument
    """
    import ansible.utils.path
    from ansible.module_utils.six import StringIO

    # initialize the env variables that we need to run the module
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic

# Generated at 2022-06-20 15:23:15.468977
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """ Full Jitter backoff strategy
    :return:
    """
    backoff_iterator = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    result = [next(backoff_iterator) for i in range(10)]
    print(result)
    assert result == [0, 16, 7, 0, 29, 6, 7, 11, 10, 0]

# Generated at 2022-06-20 15:23:16.554322
# Unit test for function retry_never
def test_retry_never():
    assert retry_never("Foo") == False
    assert retry_never("Bar") == False
    assert retry_never("Baz") == False

# Generated at 2022-06-20 15:23:26.665602
# Unit test for function rate_limit
def test_rate_limit():
    # Rate limit decorator for the function function_rate
    @rate_limit(rate=2, rate_limit=3)
    def function_rate():
        return True

    # Uniform generator
    def uniform(a, b):
        return (b - a) * random.random() + a

    # Too many calls to the function_rate per window of time_limit seconds
    time_limit = 3
    assert time_limit > 2
    number_of_calls = time_limit * 2
    message = "Did not get the right rate (time_limit = %f, number_of_calls = %f)" % (time_limit, number_of_calls)
    assert number_of_calls > time_limit, message

    # Start time of the test
    start_time = time.time()
    # Call the function_rate

# Generated at 2022-06-20 15:23:32.031172
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():

    # Add rate_limit_argument_spec to module arg_spec
    arg_spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True)
    )

    assert ("rate" in arg_spec)
    assert ("rate_limit" in arg_spec)


# Generated at 2022-06-20 15:23:40.708340
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    # Success case
    assert retry_argument_spec() == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )

    # Success case with argument spec
    assert retry_argument_spec(spec=dict(
        timeout=dict(type='int'),
        detach=dict(type='bool', default=False),
    )) == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
        timeout=dict(type='int'),
        detach=dict(type='bool', default=False),
    )


# Generated at 2022-06-20 15:23:48.229852
# Unit test for function rate_limit
def test_rate_limit():
    """unit test for rate_limit decorator"""
    import time
    import random

    @rate_limit(rate=2, rate_limit=3)
    def bounded_fn():
        """dummy function"""
        print('bounded_fn')
        time.sleep(random.randint(0, 3) * 0.1)

    time_start = time.time()
    for _ in range(0, 10):
        bounded_fn()
    elapsed_time = time.time() - time_start
    assert elapsed_time >= 9.0

    del bounded_fn



# Generated at 2022-06-20 15:23:48.826361
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    pass

# Generated at 2022-06-20 15:23:49.741038
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) is False

# Generated at 2022-06-20 15:23:52.446622
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec({'foo': 'bar'}) == {'foo': 'bar', 'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}


# Generated at 2022-06-20 15:23:58.367133
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = rate_limit_argument_spec()
    module = AnsibleModule(argument_spec=argument_spec)

    assert module.params['rate'] == None
    assert module.params['rate_limit'] == None

# Generated at 2022-06-20 15:24:12.777075
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    list_of_delays = list(generate_jittered_backoff(retries=5, delay_base=10, delay_threshold=30))
    print(list_of_delays)

# Generated at 2022-06-20 15:24:20.734342
# Unit test for function rate_limit
def test_rate_limit():

    @rate_limit(5, 60)
    def my_rate_limited_function():
        pass

    class MyRateLimitedClass(object):

        @rate_limit(5, 60)
        def my_rate_limited_method(self):
            pass

    class TestMyRateLimitedClass(object):

        def test_rate_limit_on_method(self):
            obj = MyRateLimitedClass()
            obj.my_rate_limited_method()

    class TestMyRateLimitedFunction(object):

        def test_rate_limit_on_method(self):
            my_rate_limited_function()



# Generated at 2022-06-20 15:24:24.868168
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(name=dict(type='str'))
    retry_spec = retry_argument_spec(spec=spec)
    assert retry_spec == dict(spec, retries=dict(type='int'), retry_pause=dict(type='float', default=1))



# Generated at 2022-06-20 15:24:30.548622
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global exception_count

    exception_count = 0

    @retry_with_delays_and_condition(generate_jittered_backoff(retries=3))
    def raise_exception(should_raise=True):
        nonlocal exception_count
        exception_count += 1
        if should_raise:
            raise Exception('forced exception')

    raise_exception(should_raise=True)
    assert exception_count == 4

    exception_count = 0
    should_raise = False
    raise_exception(should_raise=should_raise)
    assert exception_count == 1

# Generated at 2022-06-20 15:24:36.960529
# Unit test for function rate_limit
def test_rate_limit():
    delay = .8
    rate = 2

    @rate_limit(rate=rate, rate_limit=1)
    def func(x):
        return x

    start = time.time()
    results = [func(1), func(2), func(3)]
    end = time.time()
    time.sleep(delay)

    assert (end - start) > delay, "rate_limit did not work"

# Generated at 2022-06-20 15:24:38.304393
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:24:41.726612
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    module = AnsibleModule(
        argument_spec=rate_limit_argument_spec()
    )

    assert module.params['rate'] == None, "rate should be None"
    assert module.params['rate_limit'] == None, "rate_limit should be None"


# Generated at 2022-06-20 15:24:42.584197
# Unit test for function retry_never
def test_retry_never():
    """Should return False"""
    return retry_never(Exception('One time only'))

# Generated at 2022-06-20 15:24:46.769531
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    test_1 = basic_auth_argument_spec()
    assert 'api_username' in test_1
    assert 'api_password' in test_1
    assert 'api_url' in test_1
    assert 'validate_certs' in test_1


# Generated at 2022-06-20 15:24:50.608349
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_arg = rate_limit_argument_spec()
    assert rate_limit_arg['rate'] == {'type': 'int'}
    assert rate_limit_arg['rate_limit'] == {'type': 'int'}

# Generated at 2022-06-20 15:25:23.225044
# Unit test for function rate_limit
def test_rate_limit():
    # number of attempts made
    tries = 0
    # number of attempts that should have been made based on rate limit
    min_tries = 0
    # number of attempts that should have been made based on rate limit
    max_tries = 5

    @rate_limit(rate=10, rate_limit=2)
    def count():
        global tries
        tries += 1

    for x in range(0, 10):
        count()
    if sys.version_info >= (3, 8):
        real_time = time.process_time
    else:
        real_time = time.clock

    start = real_time()
    for x in range(0, 100):
        count()
    end = real_time()

    delay = (end - start) * 100
    min_tries = delay * 5
    max_tries

# Generated at 2022-06-20 15:25:24.644538
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:25:29.563294
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec() == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
    }
    assert retry_argument_spec({'test': 'testing'}) == {
        'retries': {'type': 'int'},
        'retry_pause': {'type': 'float', 'default': 1},
        'test': {'testing'}
    }


# Generated at 2022-06-20 15:25:35.371494
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        foo=dict(),
        bar=dict()
    )
    assert retry_argument_spec(spec) == {
        'retries': dict(type='int'),
        'retry_pause': dict(type='float', default=1),
        'foo': dict(),
        'bar': dict()
    }

# Generated at 2022-06-20 15:25:44.599550
# Unit test for function rate_limit
def test_rate_limit():
    @rate_limit(2, 2)
    def foo():
        return True

    assert foo()
    assert foo()
    assert not foo()

    # Now try with a different rate (1 req per second)
    @rate_limit(1, 1)
    def foo():
        return True

    for i in range(0, 2):
        assert foo()

    # Now try with a different rate (1 req every 2 secs)
    @rate_limit(1, 2)
    def foo():
        return True

    for i in range(0, 5):
        assert foo()


if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-20 15:25:46.208757
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) == False


# Generated at 2022-06-20 15:25:53.664761
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import unittest

    class TestRetry(unittest.TestCase):
        """Unit test for retry_with_delays_and_condition."""

        def test_always_retry_on_error(self):
            retries = 0
            max_retries = 3

            def should_retry(error):
                return True

            def retryable_function():
                nonlocal retries
                retries += 1
                raise Exception("Test function raised an exception.")
                return "This will never be returned as the function raises an exception every time."

            retry_decorator = retry_with_delays_and_condition(iter([]), should_retry)
            retryable_function_decorated = retry_decorator(retryable_function)


# Generated at 2022-06-20 15:25:58.658326
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert 'rate' in arg_spec
    assert arg_spec['rate']['type'] == 'int'
    assert 'rate_limit' in arg_spec
    assert arg_spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-20 15:26:02.931886
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    import pytest
    spec=dict(username=dict(type='str', default='admin'))
    assert rate_limit_argument_spec(spec) == dict(rate=dict(type='int'), rate_limit=dict(type='int'), username=dict(type='str', default='admin'))


# Generated at 2022-06-20 15:26:04.605193
# Unit test for function retry_never
def test_retry_never():
    if retry_never(None) is True:
        sys.exit(1)

# Generated at 2022-06-20 15:26:58.436873
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import collections
    import random

    # Generate a random array of retry delays.
    retry_delays = []
    for _ in range(0, 100):
        retry_delays.append(random.randint(0, 20))

    # Mock the retryable function.
    # Make a deque that is a copy of retry_delays, and pop values off the front for the function calls.
    return_value = "Return Value"
    def mock_retryable_function(retry_delays):
        call_attempts = collections.deque(retry_delays)
        def mock_function():
            if len(call_attempts) == 0:
                return return_value
            return_error = call_attempts.popleft()
            if return_error > 0:
                raise

# Generated at 2022-06-20 15:27:07.353418
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    """Unit test for function basic_auth_argument_spec"""
    spec = basic_auth_argument_spec()
    assert spec['api_username'] == {'type': 'str'}
    assert spec['api_password'] == {'type': 'str', 'no_log': True}
    assert spec['api_url'] == {'type': 'str'}
    assert spec['validate_certs'] == {'type': 'bool', 'default': True}

    spec = basic_auth_argument_spec({'a_extra': {'type': 'str', 'default': 'extra'}})
    assert spec['a_extra'] == {'type': 'str', 'default': 'extra'}



# Generated at 2022-06-20 15:27:11.870097
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delays = generate_jittered_backoff(retries=10, delay_base=3, delay_threshold=60)
    try:
        while True:
            print("{} ".format(next(delays)), end="")
    except StopIteration:
        pass
    print("")
    expected = "0 2 0 45 0 1 56 0 0 2 "
    assert expected == "{} ".format(next(delays))

# Generated at 2022-06-20 15:27:12.622836
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:27:16.880574
# Unit test for function retry_never
def test_retry_never():
    if retry_never(Exception) is False:
        print("{} passed".format(sys._getframe().f_code.co_name))
    else:
        raise Exception("{} failed".format(sys._getframe().f_code.co_name))



# Generated at 2022-06-20 15:27:24.426460
# Unit test for function retry
def test_retry():
    class BadException(Exception):
        pass

    @retry_with_delays_and_condition(
        backoff_iterator=generate_jittered_backoff(retries=1, delay_base=0, delay_threshold=3),
        should_retry_error=lambda exception: isinstance(exception, BadException)
    )
    def bad_function():
        raise BadException()
    try:
        bad_function()
    except Exception:
        pass
    else:
        # Retry will re-raise the exception.
        assert False

# Generated at 2022-06-20 15:27:34.657042
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    times_called = [0]
    times_to_fail_before_success = 3
    def dummy_function():
        times_called[0] += 1
        if times_called[0] <= times_to_fail_before_success:
            return False
        return True

    dummy_retryable_function = retry_with_delays_and_condition(backoff_iterator=generate_jittered_backoff())(dummy_function)
    dummy_retryable_function()
    assert times_called[0] == times_to_fail_before_success + 1

if __name__ == '__main__':
    test_retry_with_delays_and_condition()

# Generated at 2022-06-20 15:27:40.527518
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    assert basic_auth_argument_spec()['api_username'] == {'type': 'str'}
    assert basic_auth_argument_spec()['api_password'] == {'type': 'str', 'no_log': True}
    assert basic_auth_argument_spec()['api_url'] == {'type': 'str'}
    assert basic_auth_argument_spec()['validate_certs'] == {'type': 'bool', 'default': True}


# Generated at 2022-06-20 15:27:42.928921
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    arg_spec = rate_limit_argument_spec()
    assert arg_spec['rate']['type'] == 'int'
    assert arg_spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-20 15:27:45.211498
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    delay_list = list(generate_jittered_backoff())
    assert delay_list == [0, 0, 1, 2, 0, 2, 0, 2, 1, 2]

# Generated at 2022-06-20 15:29:21.593308
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    assert rate_limit_argument_spec() == dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )


# Generated at 2022-06-20 15:29:23.489372
# Unit test for function retry_never
def test_retry_never():
    # pylint: disable=unused-argument
    """ Unit test for function retry_never. """
    assert retry_never(Exception) == False
    return



# Generated at 2022-06-20 15:29:26.368744
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)
    assert not retry_never(Exception())


# Generated at 2022-06-20 15:29:37.225945
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    import platform
    import re

    assert re.match("<type 'dict'>", str(type(retry_argument_spec())))
    assert re.match("<type 'dict'>", str(type(retry_argument_spec({}))))

    for key in ['retries', 'retry_pause']:
        assert key in retry_argument_spec().keys()

    if platform.python_version_tuple()[0] == '2':
        assert re.match("<type 'str'>", str(type(retry_argument_spec().keys()[0])))
    else:
        assert re.match("<class 'str'>", str(type(retry_argument_spec().keys()[0])))


# Generated at 2022-06-20 15:29:41.082460
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    module = MagicMock(
        api_username='admin',
        api_password='password',
        api_url='url',
        validate_certs=True)
    api_spec = basic_auth_argument_spec()
    for key in api_spec.keys():
        assert hasattr(module, key)

# Generated at 2022-06-20 15:29:46.347954
# Unit test for function rate_limit
def test_rate_limit():
    """Unit test for function rate_limit"""
    from datetime import datetime

    @rate_limit(rate=10, rate_limit=1)
    def do_work():
        now = datetime.now()
        print(now.strftime('%H:%M:%S'))
        return True

    start = datetime.now()
    for i in range(0, 30):
        do_work()

    elapsed = (datetime.now() - start).seconds
    assert elapsed >= 2


if __name__ == '__main__':
    test_rate_limit()

# Generated at 2022-06-20 15:29:50.202411
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    res = rate_limit_argument_spec()
    assert res == {'rate': {'type': 'int'}, 'rate_limit': {'type': 'int'}}



# Generated at 2022-06-20 15:29:57.335522
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    spec = dict(
        required_together=[[
            'api_username',
            'api_password'
        ]],
    )
    res = rate_limit_argument_spec(spec)
    assert res['parameters']['rate']['type'] == 'int'
    assert res['parameters']['rate_limit']['type'] == 'int'
    assert res['parameters']['api_username']['type'] == 'str'
    assert res['parameters']['api_password']['type'] == 'str'



# Generated at 2022-06-20 15:30:00.836287
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    rate_limit_spec = rate_limit_argument_spec()
    assert rate_limit_spec['rate']['type'] == 'int'
    assert rate_limit_spec['rate_limit']['type'] == 'int'


# Generated at 2022-06-20 15:30:09.389943
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # This function must fail until it doesn't fail.
    call_count = [0]

    def fail_until_call_count_exceeds(retry_limit):
        def function(arg1):
            if arg1[0] > retry_limit:
                return
            call_count[0] = call_count[0] + 1
            raise Exception(f"Call #{call_count[0]} failed")
        return function

    def should_retry_error(exception):
        return True

    delay_iterator = generate_jittered_backoff(retries=5, delay_threshold=1)

    retryable_function = retry_with_delays_and_condition(delay_iterator, should_retry_error)
