

# Generated at 2022-06-20 15:20:41.296866
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(None)

# Generated at 2022-06-20 15:20:44.222804
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()

    assert arg_spec == dict(
        retries=dict(type='int'),
        retry_pause=dict(type='float', default=1),
    )



# Generated at 2022-06-20 15:20:50.702656
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    spec = dict(
        rate=dict(type='int'),
        rate_limit=dict(type='int'),
    )
    new_spec = retry_argument_spec(spec)
    assert new_spec['retries']['type'] == 'int'
    assert new_spec['retry_pause']['type'] == 'float'
    assert new_spec['retry_pause']['default'] == 1.0
    assert spec is not new_spec
    assert new_spec['rate']['type'] == 'int'
    assert new_spec['rate_limit']['type'] == 'int'

# Generated at 2022-06-20 15:20:54.453979
# Unit test for function retry_never
def test_retry_never():
    """Check that we return False as required"""
    assert retry_never("Test") == False

# Generated at 2022-06-20 15:20:57.370432
# Unit test for function rate_limit
def test_rate_limit(): # pragma: no cover
    import time

    @rate_limit(rate=4, rate_limit=3600)
    def test_rate_limited(n):
        print(n)

    for n in range(0, 10):
        time.sleep(1)
        test_rate_limited(n)



# Generated at 2022-06-20 15:21:02.293329
# Unit test for function retry
def test_retry():
    import random

    def can_error(*args, **kwargs):
        if random.randint(0, 10) > 3:
            raise Exception('error')
        return True


    decorator = retry_with_delays_and_condition(generate_jittered_backoff())

    for _ in range(0, 1000):
        decorator(can_error)()

# Generated at 2022-06-20 15:21:06.057780
# Unit test for function retry
def test_retry():
    """Usage tests for retry function."""

    @retry(retries=5, retry_pause=0.001)
    def retried(a, b, fail_count):
        fail_count[0] += 1
        if fail_count[0] < 5:
            raise Exception("Fail")
        else:
            return True

    assert retried(1, 2, [0])
    assert retried(1, 2, [0]) is False

# Generated at 2022-06-20 15:21:10.558145
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import pytest

    def error_generating_function(was_retried=False):
        """Raise an exception on the first attempt, then return value on second attempt."""
        if was_retried:
            return "success"
        else:
            raise Exception("first run")

    # Check that the function raises an exception on the first attempt when only given one attempt
    with pytest.raises(Exception):
        retry_with_delays_and_condition(backoff_iterator=[], should_retry_error=None)(error_generating_function)()

    # Check that the function returns success on the second attempt because we decided not to retry the error

# Generated at 2022-06-20 15:21:20.520806
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    global counter
    counter = 0
    backoff_iterator = [0, 3, 6, 12]  # 3 retries.
    delay_base = 3
    delay_threshold = 60

    def should_retry_error(x):
        return True

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error)
    def retryable_function():
        global counter
        # Test that the function is called 4 times (1 call w/o delay + 3 retries)
        counter += 1
        if counter < 3:
            raise ValueError("This function should be called again.")

        return "Test"

    val = retryable_function()
    assert val == "Test"
    assert counter == 4

# Generated at 2022-06-20 15:21:25.572811
# Unit test for function retry
def test_retry():
    """Unit test for retry decorator"""
    @retry()
    def testing(fail_until):
        print(fail_until)
        return True if fail_until == 0 else False
    testing(2)


# Generated at 2022-06-20 15:21:37.947574
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import sys
    import inspect

    # Create a mock exception
    class MockException(Exception):
        pass

    def mock_callable():
        pass

    object_id = id(mock_callable)

# Generated at 2022-06-20 15:21:41.673207
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    result = rate_limit_argument_spec()
    assert result['rate']['type'] == 'int', "Rate is an int"
    assert result['rate_limit']['type'] == 'int', "Rate limit is an int"



# Generated at 2022-06-20 15:21:51.388475
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import collections
    import unittest

    # Define a class to mock a counter.
    class Counter:
        def __init__(self):
            self.count = 0

        def increment(self):
            self.count += 1

    # Define a class to return a list of numbers in the next() method.
    class BackoffIterator:
        def __init__(self, backoff_list):
            self.backoff_list = backoff_list
            self.current_index = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.current_index == len(self.backoff_list):
                raise StopIteration

            current_delay = self.backoff_list[self.current_index]
            self.current_index += 1
            return current_delay



# Generated at 2022-06-20 15:21:58.510022
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    class TimeoutError(Exception):
        pass
    class OtherError(Exception):
        pass
    backoff_iterator = [0, 1, 3, 9]

    @retry_with_delays_and_condition(backoff_iterator)
    def function():
        # The "function" under test
        return 1

    @retry_with_delays_and_condition(backoff_iterator)
    def function_with_exception():
        # The "function" under test
        raise TimeoutError("function_with_exception")

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error=lambda e: isinstance(e, TimeoutError))
    def function_with_conditional_exception_retry():
        # The "function" under test
        raise TimeoutError

# Generated at 2022-06-20 15:22:08.971632
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    random.seed(0)
    backoff_iterator = generate_jittered_backoff()
    backoff_iterator_with_retries = itertools.islice(backoff_iterator, 5)
    backoff_iterator_with_retries_list = [i for i in backoff_iterator_with_retries]

    assert backoff_iterator_with_retries_list == [0, 0, 17, 31, 29]
    assert list(generate_jittered_backoff(3)) == [0, 6, 55]
    assert list(generate_jittered_backoff(3, 0)) == [0, 0, 0]
    assert list(generate_jittered_backoff(3, delay_threshold=1)) == [0, 0, 0]


# Generated at 2022-06-20 15:22:19.373007
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff = generate_jittered_backoff(retries=10)

    @retry_with_delays_and_condition(backoff, should_retry_error=retry_never)
    def does_nothing():
        pass

    does_nothing()

    @retry_with_delays_and_condition(backoff, should_retry_error=lambda e: e == 'retryable')
    def throws_exception():
        raise 'retryable'

    with pytest.raises(Exception):
        throws_exception()

    @retry_with_delays_and_condition(backoff, should_retry_error=lambda e: e == 'retryable')
    def retryable():
        if not hasattr(retryable, 'count'):
            retryable.count = 0


# Generated at 2022-06-20 15:22:23.706331
# Unit test for function rate_limit_argument_spec
def test_rate_limit_argument_spec():
    from ansible.module_utils.common.dict_transformations import camel_dict_to_snake_dict
    argument_spec = rate_limit_argument_spec()
    assert argument_spec['rate'] == dict(type='int')
    assert argument_spec['rate_limit'] == dict(type='int')


# Generated at 2022-06-20 15:22:27.124083
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    arg_spec = retry_argument_spec()

    for arg in ['retries', 'retry_pause']:
        assert arg in arg_spec

    assert arg_spec['retries']['type'] == 'int'
    assert arg_spec['retry_pause']['type'] == 'float'
    assert arg_spec['retry_pause']['default'] == 1

# Generated at 2022-06-20 15:22:29.375690
# Unit test for function retry
def test_retry():
    """
    @retry(retries=6, retry_pause=.5)
    def failure():
        print("fail")
        raise Exception("fail")

    failure()
    """



# Generated at 2022-06-20 15:22:37.232239
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    test_spec = dict(required_one_of=[['api_username', 'api_password']])
    # Test with no spec
    test = basic_auth_argument_spec()
    # Test with spec
    test = basic_auth_argument_spec(test_spec)
    assert test == dict(required_one_of=[['api_username', 'api_password']], api_username=dict(type='str'),
                        api_password=dict(type='str', no_log=True), api_url=dict(type='str'), validate_certs=dict(type='bool', default=True))



# Generated at 2022-06-20 15:22:55.955400
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():

    # Test a function which never throws an exception, we should never get into the retry logic.
    global_iteration_counter = 0
    @retry_with_delays_and_condition(generate_jittered_backoff(10, 3, 60))
    def succeeded_on_first_try():
        global global_iteration_counter
        global_iteration_counter += 1
        return True

    global_iteration_counter = 0
    succeeded_on_first_try()
    assert(global_iteration_counter == 1)

    # Test a function which always throws an exception, we should always retry.
    @retry_with_delays_and_condition(generate_jittered_backoff(10, 3, 60))
    def always_fail():
        raise Exception("Forced error")

    global_iteration_

# Generated at 2022-06-20 15:23:00.146238
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    values = [delay for delay in generate_jittered_backoff()]
    assert len(values) == 10
    assert values[-1] == 60
    assert all(v >= 0 and v <= 60 for v in values)

# Generated at 2022-06-20 15:23:07.074834
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    backoff_iterator = generate_jittered_backoff(retries=4, delay_base=4, delay_threshold=60)
    function_called_times = 0

    @retry_with_delays_and_condition(backoff_iterator, should_retry_error=None)
    def dummy_function():
        """A very basic dummy function."""
        nonlocal function_called_times
        function_called_times += 1
        return "result"

    returned_value = dummy_function()

    assert returned_value == "result"
    assert function_called_times == 1

# Generated at 2022-06-20 15:23:10.514167
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("test")) == False
    assert retry_never("test") == False


# Generated at 2022-06-20 15:23:20.322104
# Unit test for function retry
def test_retry():
    from ansible.module_utils.basic import AnsibleModule

    @retry(retries=2, retry_pause=1)
    def foo():
        return False

    @retry(retries=2, retry_pause=1)
    def bar():
        return True

    module = AnsibleModule(argument_spec={})

    try:
        foo()
    except Exception:
        module.exit_json(msg="foo() raised exception as expected", changed=True)
    else:
        module.exit_json(msg="foo() did nto raise exception", changed=False)

    if bar():
        module.exit_json(msg="bar() worked as expected", changed=True)
    else:
        module.exit_json(msg="bar() failed", changed=False)

# Generated at 2022-06-20 15:23:21.577126
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception) is False


# Generated at 2022-06-20 15:23:25.805186
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    backoff_iterator = generate_jittered_backoff()
    assert [next(backoff_iterator) for _ in range(0, 15)] == [
        0, 0, 3, 5, 1, 8, 24, 5, 16, 3, 8, 5, 10, 6, 9
    ]

# Generated at 2022-06-20 15:23:32.228269
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # Test success
    @retry_with_delays_and_condition(generate_jittered_backoff(3), retry_never)
    def successful_call():
        return "successful"

    assert successful_call() == "successful"

    # Test failures until we give up
    @retry_with_delays_and_condition(generate_jittered_backoff(3), retry_never)
    def failing_call():
        raise Exception("fail")

    with pytest.raises(Exception):
        failing_call()

    # Test failures until we succeed

# Generated at 2022-06-20 15:23:36.717167
# Unit test for function rate_limit
def test_rate_limit():
    global calls

    calls = 0

    @rate_limit(2, 5)
    def f():
        global calls
        calls += 1

    f()
    f()
    time.sleep(4)
    f()
    print(calls, 'calls in 5 seconds')
    assert calls == 3



# Generated at 2022-06-20 15:23:38.232923
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(None) == False


# Generated at 2022-06-20 15:23:54.369603
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    for delay in generate_jittered_backoff():
        print(delay)

test_generate_jittered_backoff()


# Generated at 2022-06-20 15:24:06.146524
# Unit test for function rate_limit
def test_rate_limit():
    import unittest
    import time

    class RateLimitTests(unittest.TestCase):
        def setUp(self):
            self.now = time.time()

        def test_it_should_wait_for_rate_limit(self):
            @rate_limit(rate=10, rate_limit=60)
            def test_rate_limited(self):
                return time.time()

            self.now = time.time()
            test_rate_limited(self)
            self.assertTrue(time.time() - self.now < 1)

            self.now = time.time()
            test_rate_limited(self)
            self.assertTrue(time.time() - self.now < 1)

            self.now = time.time()
            test_rate_limited(self)

# Generated at 2022-06-20 15:24:15.303942
# Unit test for function retry
def test_retry():
    @retry(retries=5)
    def _retry_test():
        _retry_test.count += 1
        if _retry_test.count == 3:
            ret = u'it worked!'
        else:
            ret = None
        return ret

    _retry_test.count = 0
    ret = _retry_test()
    assert ret == u'it worked!'
    assert _retry_test.count == 3


# Generated at 2022-06-20 15:24:24.825584
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert 'api_username' in arg_spec
    assert 'api_password' in arg_spec
    assert 'api_url' in arg_spec
    assert 'validate_certs' in arg_spec
    assert arg_spec['api_username']['type'] == 'str'
    assert arg_spec['api_password']['type'] == 'str'
    assert arg_spec['api_password']['no_log'] == True
    assert arg_spec['api_url']['type'] == 'str'
    assert arg_spec['validate_certs']['type'] == 'bool'
    assert arg_spec['validate_certs']['default'] == True
    return 0


# Generated at 2022-06-20 15:24:25.986915
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    arg_spec = basic_auth_argument_spec()
    assert isinstance(arg_spec, dict)

# Generated at 2022-06-20 15:24:30.674348
# Unit test for function basic_auth_argument_spec
def test_basic_auth_argument_spec():
    spec = dict(
        timeout=dict(type='int', default=10),
    )
    assert basic_auth_argument_spec(spec) == dict(
        api_username=dict(type='str'),
        api_password=dict(type='str', no_log=True),
        api_url=dict(type='str'),
        validate_certs=dict(type='bool', default=True),
        timeout=dict(type='int', default=10),
    )



# Generated at 2022-06-20 15:24:37.496118
# Unit test for function retry
def test_retry():
    global count
    count = 0
    global result

    @retry(retries=3, retry_pause=2)
    def test_function():
        global count
        global result
        count += 1
        if count < 3:
            result = False
            raise Exception("Test exception %d" % count)
        elif count == 3:
            result = True
            return True

    test_function()

    assert result
    assert count == 3

# Generated at 2022-06-20 15:24:43.452509
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    # A function that raises an error for the first retry and succeeds on the second retry
    retry_count = [0]
    def test_function():
        if retry_count[0] == 0:
            retry_count[0] += 1
            raise
        else:
            return "Success"

    retry_func = retry_with_delays_and_condition(generate_jittered_backoff(retries=5))(test_function)
    assert retry_func() == "Success"



# Generated at 2022-06-20 15:24:46.647150
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception()) is False
    assert retry_never(None) is False
    assert retry_never(1) is False

# Generated at 2022-06-20 15:24:52.227757
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Test the generator function that creates a sequence of delays"""
    expected_values = [3, 6, 12, 24, 60, 60, 60, 60, 60, 60]
    gen = generate_jittered_backoff(retries=len(expected_values))
    for i, delay in enumerate(gen):
        assert delay == expected_values[i], "delay values do not match"

# Generated at 2022-06-20 15:25:19.964548
# Unit test for function retry
def test_retry():
    @retry(retries=7, retry_pause=2)
    def rfunc():
        print("Retry attempt")
        raise Exception("failed")
    try:
        rfunc()
    except Exception:
        pass



# Generated at 2022-06-20 15:25:28.786121
# Unit test for function rate_limit
def test_rate_limit():
    """Test rate_limit decorator"""
    import time
    import unittest

    def dummy_function(a, b):
        """dummy function to use rate_limit"""
        return a + b

    @rate_limit(rate=10, rate_limit=1)
    def dummy_function_decorated(a, b):
        """dummy function to use rate_limit"""
        return dummy_function(a, b)

    class RateLimitDecoratorTest(unittest.TestCase):
        """Test case for rate_limit decorator"""
        def test_rate_limit(self):
            """test_rate_limit() - test rate_limit works as intended"""
            print("rate test")
            start = time.time()

# Generated at 2022-06-20 15:25:29.736237
# Unit test for function retry_never
def test_retry_never():
    assert retry_never(Exception("foo")) == False

# Generated at 2022-06-20 15:25:41.094208
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    import random
    import unittest
    class RetryDecoratorTest(unittest.TestCase):
        def setUp(self):
            self.retry_count = 0

        @retry_with_delays_and_condition(generate_jittered_backoff())
        def function_to_retry(self):
            self.retry_count += 1
            if self.retry_count < 3:
                raise Exception("Retry invocation")
            return "Success"

        @retry_with_delays_and_condition([1], lambda ex: not isinstance(ex, RuntimeError))
        def function_to_retry_with_runtime_error(self):
            self.retry_count += 1
            if self.retry_count < 3:
                raise RuntimeError("Runtime Error")

# Generated at 2022-06-20 15:25:51.215568
# Unit test for function retry
def test_retry():
    """Test retry decorator"""
    def good(n=0):
        return n

    def bad(n=0):
        raise Exception('Boom')

    @retry(retries=2)
    def good_with_retries(n=0):
        if n > 0:
            return n
        else:
            return None

    @retry(retries=2)
    def bad_with_retries(n=0):
        """Example of a function I want to retry , but not if it fails for a certain reason"""
        if n > 3:
            raise Exception("Boom")
        else:
            return False

    @retry(retries=2)
    def timed_out(n=0):
        """Example of a function I want to retry , but not if it fails for a certain reason"""


# Generated at 2022-06-20 15:26:02.439585
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """This test is only be run in utest.
             !Make sure not import the utest directory in any other places!
    """
    class RetryObject(object):
        def __init__(self):
            # how many times has run() been called.
            self.counter = 0
            # if the function should throw an error
            self.should_error = False
            # the number of times run() should throw an error
            self.error_attempts = 0
            # the number of times run() should run without error and return True
            self.success_attempts = 0

        def increment_counter(self):
            self.counter += 1

        def run(self):
            self.increment_counter()

# Generated at 2022-06-20 15:26:10.289539
# Unit test for function generate_jittered_backoff
def test_generate_jittered_backoff():
    """Test the delays generated by generate_jittered_backoff function.

    :returns: True if the test passed, else False.
    """
    test_backoff_iterator = generate_jittered_backoff(
        retries=10, delay_base=3, delay_threshold=60
    )
    delays = list(test_backoff_iterator)

    # The delays generated by test_backoff_iterator should have 10 elements
    if len(delays) != 10:
        return False

    # The delays generated by test_backoff_iterator should all fall between zero and
    # sixty, inclusive.
    if not all(map(lambda x: 0 <= x and x <= 60, delays)):
        return False

    return True



# Generated at 2022-06-20 15:26:14.064821
# Unit test for function retry_argument_spec
def test_retry_argument_spec():
    assert retry_argument_spec(spec=None) == {'retries': {'type': 'int'}, 'retry_pause': {'type': 'float', 'default': 1}}


# Generated at 2022-06-20 15:26:25.187489
# Unit test for function retry
def test_retry():
    try_count = [0]

    # Indicates that we should retry the function if it raised an exception
    def retry_any_error(_):
        return True

    # A function that raises an exception on its 3rd call otherwise prints it's call count
    def raise_exception_on_3rd_call():
        try_count[0] += 1
        if try_count[0] == 3:
            raise Exception("I failed at being called 3 times")
        print(try_count[0])

    @retry_with_delays_and_condition(generate_jittered_backoff(), should_retry_error=retry_any_error)
    def run_raise_exception_on_3rd_call():
        raise_exception_on_3rd_call()

    # Should print 1, 2, and

# Generated at 2022-06-20 15:26:32.142423
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    """Mock the decorated function.

    Makes it possible to simulate multiple attempts and to inspect the first and last call.
    """
    class Attempt:
        def __init__(self, tries, should_raise_error, *args, **kwargs):
            self.tries = tries
            self.args = args
            self.kwargs = kwargs
            self.should_raise_error = should_raise_error
            self.call_count = 0
            self.errors = []

        def __call__(self, *args, **kwargs):
            self.call_count += 1
            if self.call_count > self.tries:
                raise Exception("Expected %d calls, got %d" % (self.tries, self.call_count))

# Generated at 2022-06-20 15:27:29.443886
# Unit test for function retry
def test_retry():
    attempts = 0
    pass_attempts = 2

    @retry(retries=pass_attempts)
    def func():
        nonlocal attempts
        attempts += 1
        return False

    func()
    assert attempts == pass_attempts, 'Not all attempts were made.'

# Generated at 2022-06-20 15:27:39.650693
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    try:
        raise ValueError("testing error")
    except ValueError as e:
        assert type(e) == ValueError
    try:
        raise ValueError("testing error")
    except ValueError as e:
        assert type(e) == ValueError

    def raise_value_error_then_return_true(*args, **kwargs):
        raise ValueError("testing error")
        return True

    try:
        raise_value_error_then_return_true()
    except ValueError as e:
        assert type(e) == ValueError

    def raise_value_error(*args, **kwargs):
        raise ValueError("testing error")
        return True

    try:
        raise_value_error()
    except ValueError as e:
        assert type(e) == ValueError


# Generated at 2022-06-20 15:27:45.928225
# Unit test for function rate_limit
def test_rate_limit():
    module = {"rate": 100, "rate_limit": 1}
    try:
        rate_limit_decorator = rate_limit(rate=module['rate'], rate_limit=module['rate_limit'])

        @rate_limit_decorator
        def foo():
            print("Hi")

        for timer in range(10):
            start = time.time()
            for i in range(10):
                foo()
            delta = time.time() - start
            assert delta >= module['rate_limit']

    except AssertionError as e:
        raise Exception(e)



# Generated at 2022-06-20 15:27:57.142512
# Unit test for function retry_with_delays_and_condition
def test_retry_with_delays_and_condition():
    random.seed(0)

    errors = [None] * 3
    def generate_error_count(count):
        def side_effect(x):
            errors[x] += 1
            raise Exception("Error %d" % x)
        return side_effect

    def should_retry_error(e):
        return "Error %d" % 0 in str(e)

    function_with_error_counts = [
        retry_with_delays_and_condition(generate_jittered_backoff(2), should_retry_error)(generate_error_count(x)) for x in range(0, 3)]

    assert errors == [0, 0, 0]

    function_with_error_counts[0]()
    assert errors == [1, 0, 0]

    function_with_error_counts

# Generated at 2022-06-20 15:28:00.387281
# Unit test for function retry_never
def test_retry_never():
    assert retry_never('hi') is False
    assert retry_never('hello') is False
    assert retry_never('i am an exception') is False
    assert retry_never(Exception('i am an exception')) is False

# Generated at 2022-06-20 15:28:10.503900
# Unit test for function rate_limit
def test_rate_limit():
    import time
    import sys

    class RateLimitTest():
        # rate_limit is applied as delay (not as number of requests)
        # rate_limit = delay * rate -> delay = rate_limit / rate
        # delay = 1 -> rate = 1 -> 1 request per second
        # delay = 2 -> rate = 0.5 -> 1 request every 2 seconds
        # delay = 3 -> rate = 0.3333 -> 1 request every 3 seconds

        def __init__(self, msg="_init_"):
            self.msg = msg

        @rate_limit(rate=0.5, rate_limit=1)
        def test_delay_2(self):
            self.msg = "_test_delay_2_"


# Generated at 2022-06-20 15:28:11.871363
# Unit test for function retry_never
def test_retry_never():
    fake_exception = Exception()
    assert retry_never(fake_exception) == False
    assert retry_never(None) == False


# Generated at 2022-06-20 15:28:18.559621
# Unit test for function retry
def test_retry():
    import unittest

    class TestRetry(unittest.TestCase):
        def test_retry_with_delays_and_condition(self):
            @retry_with_delays_and_condition([1, 2, 3], should_retry_error=lambda e: isinstance(e, RetryException))
            def test_with_retry():
                nonlocal retry_count
                nonlocal error_raised

                if retry_count < error_raised:
                    raise RetryException()
                else:
                    return "ok"

            nonlocal retry_count
            nonlocal error_raised

            retry_count = 0
            error_raised = 3
            r = test_with_retry()
            self.assertEqual(r, "ok")

# Generated at 2022-06-20 15:28:27.175940
# Unit test for function retry
def test_retry():
    from ansible.module_utils.basic import AnsibleModule
    retry_spec = retry_argument_spec()
    module = AnsibleModule(argument_spec=retry_spec)
    retries = module.params.get('retries')
    pause = module.params.get('retry_pause')

    fail_times = 0
    retry_times = 0
    success = False

    @retry(retry_times, pause)
    def fail_always():
        global fail_times
        fail_times += 1
        raise Exception('Fail always')

    try:
        success = fail_always()
    except Exception:
        pass

    assert not success
    assert fail_times == retry_times + 1



# Generated at 2022-06-20 15:28:29.032482
# Unit test for function retry_never
def test_retry_never():
    assert not retry_never(Exception()), "test_retry_never true for Exception"