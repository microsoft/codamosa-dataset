

# Generated at 2022-06-23 12:10:16.703040
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import mock
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    # Pass a text object in on terms to ensure that
    # we can work with unicode in the recursive templating.
    terms = [to_text(u"{{ lookup(\"vars\", \"users\") }}"), u"authorized"]

    variable_manager = mock.Mock()
    variable_manager.get_vars.return_value = {}

# Generated at 2022-06-23 12:10:27.005449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Build mock LookupModule
    # - one dictionary item
    # - no flags defined
    module = LookupModule()
    module.run([
        [
            {'item-key': 'item-value'}
        ],
        'item-key'
    ], dict())
    # Assertions
    assert module.run([
        [{'item-key': 'item-value'}],
        'item-key'
    ], dict()) == [(
        {'item-key': 'item-value'},
        'item-value'
    )]
    # - one list item
    # - no flags defined
    module = LookupModule()
    module.run([
        [
            {'item-key': 'item-value'}
        ],
        'item-key'
    ], dict())
    # Assert

# Generated at 2022-06-23 12:10:29.963525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    LookupModule(loader=loader, variables=combine_vars(loader=loader, variables={}))

# Generated at 2022-06-23 12:10:38.856478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

    def test_subelements_lookup_module(key, value):
        return lookup_module.run([value, key], [])


# Generated at 2022-06-23 12:10:39.326148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:10:47.199280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare environ
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../'))
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../'))

    from ansible.plugins.lookup import LookupBase
    lookup = LookupBase()
    lookup._templar = None
    lookup._loader = None

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # test single item

# Generated at 2022-06-23 12:10:49.413859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert isinstance(subelements, LookupModule)


# Generated at 2022-06-23 12:10:54.052325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [{'skipped': True}, 'key', {'ignore_errors': True}]
    ret = lookup_module.run(terms, {}, **{'name': 'test', 'skip_missing': True})
    assert ret == []



# Generated at 2022-06-23 12:10:58.610440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor of LookupModule
    """
    def contains_module_utils(module):
        return "module_utils" in module

    with_subelements = LookupModule()
    assert with_subelements is not None

    assert contains_module_utils(str(with_subelements))
    assert contains_module_utils(repr(with_subelements))


# Generated at 2022-06-23 12:11:07.850088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def assert_raise_terms_error(msg=""):
        with pytest.raises(AnsibleError) as excinfo:
            LookupModule.run(
                LookupModule(
                    loader=None,
                    templar=None,
                    shared_loader_obj=None),
                terms=None,
                variables=None,
                **kwargs)
        assert "subelements lookup expects a list of two or three items, " + msg in str(excinfo.value)

    # check lookup terms - check number of terms

# Generated at 2022-06-23 12:11:18.032044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule constructor")
    import imp
    import os
    import sys

    # This is a hack. It is possible to load the LookupModule
    # in such a way that Ansible tests pass when executed using
    # `pip install .[test]` in the root directory of this package,
    # i.e. using the setup.py script. However, when testing from
    # within a virtual environment, the lookup plugin is loaded from
    # a different location than in the pip install of Ansible.
    # This hack therefore inserts the path to the lookup plugin
    # directory into sys.path so that it can be found and imported.
    lookup_plugin_dir = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-23 12:11:22.004285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test: constructor, expected default values
    lm = LookupModule()
    assert len(lm.get_options()) == 0
    assert lm._templar is None
    assert lm._loader is None



# Generated at 2022-06-23 12:11:30.708609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with a list as first term and a string as second term
    lookup_module = LookupModule()
    test_terms = [
        [
            {'name': 'bob', 'groups': ['wheel']},
            {'name': 'alice', 'groups': ['wheel']},
        ],
        'groups',
    ]
    result = lookup_module.run(test_terms, {}, **{})
    assert(result == [[('alice', 'wheel')], [('bob', 'wheel')]])

    # Test with a list as first term and a string as second term and a dict with flags as third term
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:11:40.447856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create lookupModule instance
    lookupMod = LookupModule()

    # define test data
    user1 = {'name': "alice"}
    user2 = {'name': "bob"}
    users = [user1, user2]

    # set test data
    user1['authorized'] = ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]
    user1['mysql'] = {'password': "mysql-password", 'hosts': ["%", "localhost"], 'privs': ["*.*:SELECT", "DB1.*:ALL"]}
    user2['authorized'] = ["/tmp/bob/id_rsa.pub", "/tmp/bob/id_rsa.pub"]

# Generated at 2022-06-23 12:11:50.847417
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import needed to test the class within the same package
    from ansible.plugins.lookup.subelements import LookupModule

    # Prepare the class
    lookup_plugin = LookupModule()

    # Empty terms to test the error management
    lookup_plugin.run([], [])

    # List of dicts needed for the tests
    list_of_dicts = [
        {"id": 1, "data": {"subelement": ["a", "b", "c"]}}
    ]

    # Test the execution

# Generated at 2022-06-23 12:12:01.925493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of class LookupModule
    lu = LookupModule()
    # prepare testdata
    testdata = {}
    testdata[1] = {}

# Generated at 2022-06-23 12:12:03.000651
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:12:11.784482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # create test data:
    users = [{}]
    users[0]['name'] = 'alice'
    users[0]['authorized'] = ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']
    users[0]['mysql'] = {}
    users[0]['mysql']['password'] = 'mysql-password'
    users[0]['mysql']['hosts'] = ['%', '127.0.0.1', '::1', 'localhost']
    users[0]['mysql']['privs'] = ['*.*:SELECT', 'DB1.*:ALL']
    users.append({})
    users[1]['name'] = 'bob'

# Generated at 2022-06-23 12:12:17.297365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib

    # first test: no flags
    lookup_plugin = LookupModule()
    lookup_plugin._templar = VaultLib([])
    lookup_plugin._loader = None
    def test1():
        users = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub" ]}, {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}]
        terms = [users, "authorized"]
        return lookup_plugin.run(terms, {})

# Generated at 2022-06-23 12:12:17.634455
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 12:12:19.612434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify class LookupModule is initialized
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:12:27.891462
# Unit test for constructor of class LookupModule
def test_LookupModule():

    ###########################################################
    #       Dummy Ansible module for testing purposes
    ###########################################################
    module = type('', (), {})()
    module.params = {'name': 'lookup_test'}
    module.fail_json = lambda **kwargs: sys.exit(1)
    module.exit_json = lambda **kwargs: sys.exit(0)
    CheckMode = type('', (), {})()
    CheckMode.name = 'check'
    module.check_mode = CheckMode

    ###########################################################
    #       Test cases
    ###########################################################
    # test for number of terms
    def test_exception_number_of_terms(loader, templar, params):
        lu = LookupModule()
        lu.set_options(direct=params)

# Generated at 2022-06-23 12:12:32.920626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['term', 'subkey']
    lm = LookupModule()
    lm._templar = None # TODO mock
    lm._loader = None # TODO mock
    result = lm.run(terms, None)
    assert result is None


# Generated at 2022-06-23 12:12:34.343758
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:12:41.781868
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Runs tests to ensure that the constructor works as expected
    """

    # Constructor should raise errors when invalid parameters are passed

# Generated at 2022-06-23 12:12:50.955982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    [{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel'], 'mysql': {'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'name': 'alice'}, {'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'hosts': ['db1'], 'password': 'other-mysql-password', 'privs': ['*.*:SELECT', 'DB2.*:ALL']}, 'name': 'bob'}]
    """


# Generated at 2022-06-23 12:13:03.041720
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:03.668973
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:13:11.024817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.parsing.convert_bool import boolean

    lookup = LookupModule()
    assert boolean(lookup.run([{'a': 1, 'b': 2}], {})[0][0].get('a'), strict=False)
    assert not boolean(lookup.run([{'a': 1, 'b': 2}], {})[0][0].get('b'), strict=False)
    assert not lookup.run([{'a': 1, 'b': 2}], {})[0][1]

# Generated at 2022-06-23 12:13:17.881881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    lookup_plugin = LookupModule()
    test_terms = [{u'1': {u'key2': u'value2'},
                   u'2': {u'key1': u'value1'}}, u'key1']
    assert lookup_plugin.run(test_terms, {}) == [u'value1']
    assert lookup_plugin.run(test_terms, {}, skip_missing=True) == [u'value1']
    assert lookup_plugin.run(test_terms, {}, skip_missing=boolean(True, strict=False)) == [u'value1']
    assert lookup_plugin.run(test_terms, {}, skip_missing=boolean('true', strict=False)) == [u'value1']
   

# Generated at 2022-06-23 12:13:18.947815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:13:20.582156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-23 12:13:30.364622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # tests
    # 1.
    in_list = [{'author': 'Noah', 'book': 'Genesis'},
               {'author': 'Paul', 'book': 'Romans'},
               {'author': 'Paul', 'book': 'Corinthians'}]
    in_key = 'author'
    ex_out = [('Noah', 'Genesis'), ('Paul', 'Romans'), ('Paul', 'Corinthians')]
    assert lookup_module.run([in_list, in_key]) == ex_out

    # 2.

# Generated at 2022-06-23 12:13:40.006894
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:40.973359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO
    pass

# Generated at 2022-06-23 12:13:49.382340
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test: test empty terms
    lookup_module = LookupModule()
    try:
        lookup_module.run([], None)
        assert False, "should not reach this"
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "

    # Test: test wrong type of first element
    lookup_module = LookupModule()
    try:
        lookup_module.run([1, 2], None)
        assert False, "should not reach this"
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

    # Test: test wrong type of second element
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:14:00.398866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    # prepare mock

# Generated at 2022-06-23 12:14:02.681954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # the constructor does not take any arguments, so just pass '0'
    assert lm

# Generated at 2022-06-23 12:14:12.569327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # check subkeys
    result = lookup.run(
        [
            {
                "users":
                [
                    {"name": "alice",
                     "authorized": [
                         {"key": "/tmp/alice/onekey.pub"},
                         {"key": "/tmp/alice/twokey.pub"}
                     ],
                    },
                    {"name": "bob",
                     "authorized":
                     [
                         {"key": "/tmp/bob/id_rsa.pub"},
                     ]
                    }
                ]
            },
            "users.authorized.key"
        ], [])

# Generated at 2022-06-23 12:14:17.945552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check normal mode, expects a list of two items
    assert LookupModule.run([['test'], 'test_key']) == []

    # check error 1
    try:
        LookupModule.run('test')
        assert 0
    except AnsibleError:
        pass

    # check error 2
    try:
        LookupModule.run(['test'])
        assert 0
    except AnsibleError:
        pass


# Generated at 2022-06-23 12:14:20.707753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    assert lookup_plugin._templar is not None
    assert lookup_plugin._loader is not None

# Generated at 2022-06-23 12:14:31.922970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1: variable 'users' have 2 keys, and we have to extract 2 elements for the first key,
    # and 3 elements for the second key according to subkey 'mysql.privs'
    users = [
        {
            'name': 'alice',
            'mysql': {
                'privs': [
                    '*.*:SELECT',
                    'DB1.*:ALL'
                ]
            }
        },
        {
            'name': 'bob',
            'mysql': {
                'privs': [
                    '*.*:SELECT',
                    'DB2.*:ALL',
                    'DB3.*:ALL'
                ]
            }
        }
    ]
    assert not LookupModule().run([users, 'mysql.privs'], variables=None)

    # Test case 2:

# Generated at 2022-06-23 12:14:34.630725
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(isinstance(lm, LookupModule))


# Generated at 2022-06-23 12:14:45.348466
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts import default_collectors

    lookup_plugins = {'subelements': LookupModule}

    # all this to create a fake context

# Generated at 2022-06-23 12:14:46.131261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:14:46.994053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:14:58.241447
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_text
    import pytest
    import ansible
    #
    # defaults: second term should be a list (or dict), third a string holding the subkey
    #
    lookup_instance = LookupModule()
    #
    # first term should be a list (or dict), second a string holding the subkey
    #
    # first term is not a list:
    with pytest.raises(AnsibleError) as e:
        lookup_instance.run([ 7, 'authorized' ], dict(skipped=False))
    assert to_text(e.value) == "subelements lookup expects a dictionary, got '7'"
    # first term is a dict without 'skipped' key:

# Generated at 2022-06-23 12:15:07.328654
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import patch
        from io import StringIO
    else:
        from mock import patch
        from StringIO import StringIO

    terms = {"users": [{"name": "Alice",
                        "authorized": ["alice-authorized-keys"],
                        "mysql": {"hosts": ["alice-hosts"], "privs": ["alice-privs"]}},
                       {"name": "Bob",
                        "authorized": ["bob-authorized-keys"],
                        "mysql": {"hosts": ["bob-hosts"], "privs": ["bob-privs"]}}],
             "subelements": "mysql.hosts"}

    lookup_module = LookupModule()

    # mock open method of the Lookup

# Generated at 2022-06-23 12:15:08.847628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, "run")

# Generated at 2022-06-23 12:15:19.508726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test required terms
    terms = [
        [
            {
                'name': 'alice',
                'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
                'mysql': {
                    'password': '<PASSWORD>',
                    'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
                    'privs': ['*.*:SELECT', 'DB1.*:ALL']
                },
                'groups': ['wheel']
            }
        ],
        'authorized'
    ]

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None, inject=None)


# Generated at 2022-06-23 12:15:28.465516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Subelements lookup plugin test",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("subelements", users, "mysql.hosts") }}')))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 12:15:31.214568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'org_id': 1, 'subkey': 'subvalue'},
        'subkey'
    ]
    assert LookupModule().run(terms, None, **{}), 'org_id=1'

# Generated at 2022-06-23 12:15:38.345237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 12:15:39.407581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule,LookupBase)


# Generated at 2022-06-23 12:15:40.897582
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__
    assert LookupModule.run.__doc__



# Generated at 2022-06-23 12:15:42.002117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-23 12:15:50.377133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems, string_types
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.plugins.lookup.subelements import LookupModule
    loader = DataLoader()
    variable_manager = VariableManager()
    lookup_module = LookupModule()
    lookup_module.set_loader(loader=loader)
    lookup_module.set_templar(templar=Templar(variable_manager=variable_manager))
    lookup_module.set_vars(variables=variable_manager)

    # method run: first term should be a list (or dict), second a string
    # holding the subkey

# Generated at 2022-06-23 12:15:51.405318
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert(True)

# Generated at 2022-06-23 12:16:02.545899
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup lookup_module
    lookup_module = LookupModule()
    terms = [{'skipped': False}, 'users.name']

    # run test
    ret = lookup_module.run(terms, None, None)

    # assert data
    assert isinstance(ret, list)
    assert len(ret) == 2
    assert ret == [('alice',), ('bob',)]

    # setup lookup_module
    lookup_module = LookupModule()
    terms = [{'skipped': True}, 'users.name']

    # run test
    ret = lookup_module.run(terms, None, None)

    # assert data
    assert isinstance(ret, list)
    assert len(ret) == 0
    assert ret == []

    # setup lookup_module
    lookup_module = LookupModule()
    terms

# Generated at 2022-06-23 12:16:04.010711
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-23 12:16:12.823009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelements = LookupModule()
    v = {"l": [
        {
            "name": "alice",
            "authorized": [
                "/tmp/alice/onekey.pub",
                "/tmp/alice/twokey.pub"
            ]
        },
        {
            "name": "bob",
            "authorized": [
                "/tmp/bob/id_rsa.pub"
                ]
            }
        ]
    }
    r = subelements.run([v, "authorized"], None, skip_missing=True)
    # print r

# Generated at 2022-06-23 12:16:22.991859
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # The test_LookupModule_run method is a unit test for method run of class LookupModule.
    # For this unit test to work, it is assumed that an ansible.cfg exists and a test inventory (containing 'all' group)
    # is defined in it.

    # Import required modules
    import os
    import sys
    import unittest
    # Append path to ansible-base module
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
    # Import required modules from ansible-base
    from ansible.parsing.vault import VaultLib
    from ansible.utils.display import Display
    # Import module to test
    from ansible.plugins.lookup import subelements

    # Make required private variables of

# Generated at 2022-06-23 12:16:32.714455
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:16:33.601014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-23 12:16:43.794180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # dict with dict items
    # dict item without subkey
    assert(lm.run([{ 'item1' : { 'subkey' : 'xyz' } }, 'subkey'], None) == [('xyz',)])
    # dict item with subkey
    assert(lm.run([{ 'item1' : { 'subkey' : 'xyz' }, 'item2' : {} }, 'subkey'], None) == [('xyz',)])
    # list item
    assert(lm.run([{ 'item1' : { 'subkey' : 'xyz' }, 'item2' : {} }, 'subkey'], None) == [('xyz',)])
    # list without subkey

# Generated at 2022-06-23 12:16:54.960672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import inspect
    import re
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    class LookupModule_run_TestCase(unittest.TestCase):
        def test_valid_start_dataset(self):
            lookup_module = LookupModule()

            # dataset where all var items contain the 'authorized' subkey:
            dataset = [
                {
                    'name': 'alice',
                    'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']
                },
                {
                    'name': 'bob',
                    'authorized': ['/tmp/bob/id_rsa.pub'],
                },
            ]

            # next_terms

# Generated at 2022-06-23 12:17:06.122575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    from ansible.module_utils._text import to_bytes

    # Set up context
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context._connection = None
    templar = Templar(loader=None, variables={})

    # Set up test data

# Generated at 2022-06-23 12:17:06.833869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:17:08.019000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    return lookup_instance

# Generated at 2022-06-23 12:17:18.259249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.module_utils.parsing.convert_bool import boolean

    # prepare for test
    lookup_module = LookupModule()
    context.CLIARGS = {
        'lookup_plugin_terms': [
            'terms1',
            'terms2',
        ]
    }

    # check that lookup_module.run raise exception when first term is missing
    try:
        lookup_module.run([], {})
    except AnsibleError as err:
        assert err.args[0] == "subelements lookup expects a list of two or three items, "
    else:
        raise AssertionError('AnsibleError not raised')

    # check that lookup_module.run raise exception when first term is not a list

# Generated at 2022-06-23 12:17:26.819618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ],
                'mysql': 'foobar'
            },
        ],
        'authorized', {'skip_missing': True}
    ]
    print(l.run(terms, {}))

# Generated at 2022-06-23 12:17:38.229095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare stubs
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)
    class Templar:
        def __init__(self):
            pass

        def template(self, term):
            return term

    class Loader:
        def __init__(self):
            pass

    templar = Templar()
    loader = Loader()

    # Create instance of class LookupModule
    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader = loader

    # Check "if not isinstance(terms, list) or not 2 <= len(terms) <= 3"
    # Without params

# Generated at 2022-06-23 12:17:49.474176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # mocking from ansible.module_utils.parsing.convert_bool import boolean
    def mocked_boolean(item, strict=False):
        """mocked method for boolean"""
        if item == 'True':
            return True
        elif item == 'False':
            return False
    # importing and mocking again
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.lookup import LookupModule
    import ansible.module_utils.parsing.convert_bool
    ansible.module_utils.parsing.convert_bool.boolean = mocked_boolean
    lookupmodule = LookupModule()

# Generated at 2022-06-23 12:17:57.802689
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test._templar = None
    test._loader = None
    # test _raise_term_error function
    try:
        test._raise_terms_error()
    except AnsibleError:
        pass
    try:
        test._raise_terms_error("error")
    except AnsibleError:
        pass
    # test run function
    try:
        test.run(None, None)
    except AnsibleError:
        pass
    try:
        test.run([1, 2], None)
    except AnsibleError:
        pass



# Generated at 2022-06-23 12:18:09.316952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy ansible context
    class AnsibleModuleDummy:
        def __init__(self, **kwargs):
            self.params = kwargs
            self.debug = kwargs.get('debug', False)

        def fail_json(self, **kwargs):
            raise AnsibleError(kwargs['msg'])


# Generated at 2022-06-23 12:18:21.204500
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test data
    subelements_data = {'users': [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]}

    # test single run in a simple case

# Generated at 2022-06-23 12:18:30.522946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    # test the run-method of the lookupmodule

# Generated at 2022-06-23 12:18:39.841546
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing class LookupModule')

    try:
        l = LookupModule()
        testdict = {'One':{'sub1':{'subsub1':'data'}},
                    'Two':{'sub2':{'subsub2':'data'}}
                   }
        l.run([testdict,'sub1.subsub1'])
    except Exception as e:
        print('Unexpected Exception: ' + str(e))
        assert 0
    else:
        print('Success')
        assert 1

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:18:47.893907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub', '/tmp/bob/id_dsa.pub']},
        {'name': 'charlie', 'authorized': []},
        {'name': 'dave', 'authorized': [], 'groups': ['wheel']},
        {'name': 'eve', 'authorized': ['/tmp/eve/onekey.pub', '/tmp/eve/twokey.pub'], 'groups': ['wheel', 'admin']},
        {'name': 'frank', 'authorized': [], 'groups': []}
    ]
    users_copy = copy.deepcopy(users)
    users_copy

# Generated at 2022-06-23 12:18:58.943005
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test successful run - dictionary
    data = {
        'alice': {
            'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']
        },
        'bob': {
            'authorized': ['/tmp/bob/id_rsa.pub']
        }
    }
    res = lookup.run([data, 'authorized'], None)
    assert res == [(data['alice'], '/tmp/alice/onekey.pub'), (data['alice'], '/tmp/alice/twokey.pub'), (data['bob'], '/tmp/bob/id_rsa.pub')]

    # test successful run - list

# Generated at 2022-06-23 12:19:00.370745
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([[1,2], 'b'], dict())



# Generated at 2022-06-23 12:19:12.119625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = {
        "skipped": False,
        "name": "alice",
        "authorized": [
            "/tmp/alice/onekey.pub",
            "/tmp/alice/twokey.pub"
        ],
        "mysql": {
            "password": "mysql-password",
            "hosts": [
                "%",
                "127.0.0.1",
                "::1",
                "localhost"
            ],
            "privs": [
                "*.*:SELECT",
                "DB1.*:ALL"
            ]
        },
        "groups": [
            "wheel"
        ]
    }
    l = [d, ]

    # With default options
    obj = LookupModule()
    result = obj.run([l, 'authorized'], None)

# Generated at 2022-06-23 12:19:23.996221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # create an empty module object
    lookup_plugin = LookupModule()
    lookup_plugin._templar = None
    lookup_plugin._loader = None

    # create a variable structure as documented in the module

# Generated at 2022-06-23 12:19:26.479662
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 12:19:27.112144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not isinstance(LookupModule, object)

# Generated at 2022-06-23 12:19:27.877009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule())

# Generated at 2022-06-23 12:19:38.382378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = dict(
        name="alice",
        groups=["wheel"],
        authorized=["/tmp/alice/onekey.pub", "/tmp/alice/two.pub"],
        mysql=dict(
            password="mysql-password",
            hosts=["%", "127.0.0.1", "::1", "localhost"],
            privs=["*.*:SELECT", "DB1.*:ALL"],
        )
    )
    lu = LookupModule()
    sublist = lu._templar.template("{{ lookup('subelements', '%s', 'authorized') | join(', ') }}" % d)
    assert sublist == '/tmp/alice/onekey.pub, /tmp/alice/two.pub'

# Generated at 2022-06-23 12:19:39.016042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:19:42.682027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        lookup_module.run([[{"my":"list"}], "my.list", {"skip_missing":False}], dict())
        assert False
    except:
        pass


# Generated at 2022-06-23 12:19:53.805616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    class DummyLookupModule(LookupModule):
        # Mock the _get_plugin_options
        def _get_plugin_options(self, terms):
            return terms

        # Mock the __getattr__
        def __getattr__(self, attr):
            if attr in ['_templar', '_loader']:
                return object
            raise RuntimeError('Not implemented')

    # This test will fail when the following conditions are not met:
    # - the lookup plugin is usable as a class
    # - the method supports:
    #     * 2 or 3 parameters
    #     * a list of dictionaries as first parameter
    #     * a (nested) key path as second

# Generated at 2022-06-23 12:19:54.792899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 12:20:04.124108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # check number of args
    ret = lookup_plugin._check_terms(None, None, None)
    assert ret == False
    ret = lookup_plugin._check_terms([], None, None)
    assert ret == False
    ret = lookup_plugin._check_terms(['1','2','3','4','5'], None, None)
    assert ret == True

    # check first arg is a list/dict
    ret = lookup_plugin._check_terms(['a','b'], None, None)
    assert ret == False
    ret = lookup_plugin._check_terms([1234,'b'], None, None)
    assert ret == False
    ret = lookup_plugin._check_terms([{'a':'b'},'b'], None, None)
    assert ret == True



# Generated at 2022-06-23 12:20:13.623879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # basic subelement test
    terms = [
        [{'a': {'b': [1]}}],
        'a.b']
    data = lookup_module.run(terms, {}, **{})
    assert data[0][0] == {'a': {'b': [1]}}
    assert data[0][1] == 1
    assert len(data) == 1
    # basic subelement test
    terms = [
        [{'a': {'b': [1, 2, 3]}}],
        'a.b']
    data = lookup_module.run(terms, {}, **{})
    assert data[0][0] == {'a': {'b': [1, 2, 3]}}
    assert data[0][1] == 1