

# Generated at 2022-06-23 12:10:08.835266
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(lm)

# Generated at 2022-06-23 12:10:11.285853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check that params are passed to the class constructor
    l = LookupModule(loader=None, templar=None)
    assert l != None, "Expected constructor to instantiate the object"

# Generated at 2022-06-23 12:10:21.860165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup init parameters for LookupModule
    terms = [{'key_subelement1': 'subelement1', 'key_subelement2': 'subelement2', 'key_subelement3': 'subelement3', 'key_subelement4': 'subelement4'}]
    variables = ''

    # run LookupModule and get result
    result = LookupModule(None, None).run(terms, variables)

    assert result[0] == ({'key_subelement1': 'subelement1', 'key_subelement2': 'subelement2', 'key_subelement3': 'subelement3', 'key_subelement4': 'subelement4'}, 'subelement1')

# Generated at 2022-06-23 12:10:27.826602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyLookup(LookupModule):
        def __init__(self, terms, variables=None, loader=None, templar=None):
            self._templar = templar

    lookup = DummyLookup(['', ''])
    # test error handling:
    try:
        lookup.run([], {}, {})
        assert False, "run should have raised an error"
    except AnsibleError as err:
        assert "subelements lookup expects" in str(err)

    # test return values
    assert [] == lookup.run([[], '', {}], {}, {})
    assert [] == lookup.run([{'skipped': False}, '', {}], {}, {})
    assert [] == lookup.run([{'skipped': True}, '', {}], {}, {})

# Generated at 2022-06-23 12:10:36.351282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # get terms
    terms = [
        {
            'foo': {
                'eyes': 'blue',
                'legs': 'long'
            },
            'bar': {
                'eyes': 'green',
                'legs': 'short'
            }
        },
        'eyes',
        {
            'skip_missing': True
        }
    ]
    results = lookup.run(terms, None, **{'omit_term': True})
    assert type(results) is list
    assert len(results) is 2
    assert type(results[0][0]) is dict
    assert results[0][1] == 'blue'
    assert results[1][1] == 'green'

    # continue previous test but with different input

# Generated at 2022-06-23 12:10:45.622977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create lookup
    lookup = LookupModule()

    terms = [{'skipped': False}, 'authorized.pubkey']
    result = lookup.run(terms=terms, variables={})

    # Returned value should be a list, even if that list is empty
    assert isinstance(result, list)
    assert len(result) == 0

    #
    #  Subelements expects a list of dictionaries with a dictionary key,
    #  which value is a list of further dictionaries.
    #

    terms = [
        [{'skipped': True}, {'skipped': True}, {'skipped': True}],
        'authorized.pubkey'
    ]
    result = lookup.run(terms=terms, variables={})

    # Returned value should be a list, even if that list is empty

# Generated at 2022-06-23 12:10:47.535187
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:10:48.155350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:10:58.402664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native, to_text

    from ansible.utils.listify import listify_lookup_plugin_terms

    import sys
    import unittest

    try:
        from unittest import mock
    except ImportError:
        import mock
    # python -m test tools/lib/ansible_test --collect-only -v LookupModule
    # coverage report
    # coverage html

    def normpath(path, **kwargs):
        if path is None:
            return None
        if PY3:
            return to_text(path)


# Generated at 2022-06-23 12:11:07.767754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Start test_LookupModule_run")
    from ansible.vars import VariableManager
    import ansible.inventory
    import ansible.playbook
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 12:11:17.942490
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # subelements.0 should contain a list or a dict
    result = lookup_plugin.run([123, 'some-key'] , variables={}, templar=True, loader=True)[0]
    assert result == AnsibleError("subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey")

    # subelements.1 should contain a string
    result = lookup_plugin.run([[123], 123] , variables={}, templar=True, loader=True)[0]
    assert result == AnsibleError("subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey")

    # subelements.2 should contain a dict with valid flags

# Generated at 2022-06-23 12:11:19.939898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Just test if the constructor can be called, but don't run it.
    l = LookupModule()
    del l

# Generated at 2022-06-23 12:11:21.812892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule()
    assert m is not None


# Generated at 2022-06-23 12:11:30.624423
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructs a LookupModule instance, which is later used to perform the lookup
    lookup_plugin = LookupModule()

    # Our test data

# Generated at 2022-06-23 12:11:33.836452
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert (lookup_instance.__class__.__name__ == "LookupModule")


# Generated at 2022-06-23 12:11:37.081585
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    print ("test_LookupModule: instantiating class LookupModule")
    lookup_module = LookupModule()
    print ("test_LookupModule: instantiated class LookupModule")
    return lookup_module


# Generated at 2022-06-23 12:11:48.626698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    # stub for class LookupBase
    def _get_basedir(self, variables):
        return './'

    LookupBase._get_basedir = _get_basedir

    # stub for variable __file__
    import sys
    if not hasattr(sys, '_getframe'):
        raise Exception('could not import sys._getframe, make sure you use python 2.7')

    sys.modules['__main__'].__file__ = './'

    # stub for os.path.expanduser
    def expanduser(path):
        return '.'

    original_expanduser = os.path.expand

# Generated at 2022-06-23 12:11:50.687155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x



# Generated at 2022-06-23 12:11:58.165653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Import module and test its correctness
from ansible.plugins.lookup import LookupModule
from ansible.utils.listify import listify_lookup_plugin_terms
from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
from ansible.parsing.yaml.constructor import AnsibleConstructor
from ansible.vars.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-23 12:12:00.621652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test terms
    terms = [
        {'skipped': True},
        'authorized.keys',
        {'skip_missing': True}
    ]

    # setup the class instance
    lookup_plugin = LookupModule()

    # execute the method under test
    result = lookup_plugin.run(terms, {}, **{'_terms': terms})

    # test assertions
    assert(result == [])



# Generated at 2022-06-23 12:12:07.321295
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    users = [{
            "name": "joe",
            "groups": ["sudo", "other"]
        }, {
            "name": "sue",
            "groups": ["adm", "users"]
        }]
    lu = LookupModule()

    # test run, two terms
    terms = [users, "groups"]
    assert lu.run(terms, None)[0] == (users[0], "sudo")
    assert lu.run(terms, None)[1] == (users[0], "other")
    assert lu.run(terms, None)[2] == (users[1], "adm")
    assert lu.run(terms, None)[3] == (users[1], "users")

    # test run, three terms
    terms = [users, "groups", {}]


# Generated at 2022-06-23 12:12:18.586882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n\n### Unit test lookup-plugins/subelements.py::test_LookupModule_run ###")

    # Init values of test

# Generated at 2022-06-23 12:12:27.440818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import hashlib
    if not os.path.exists("testdata/subelements.py"):
        return
    import inspect
    sys.path.insert(0, "testdata")
    testdata = __import__("subelements")
    sys.path.pop(0)
    for name, data in inspect.getmembers(testdata):
        if name.startswith("test_"):
            print("Testing subelements lookup plugin: %s" % name)
            data['terms'] = data.pop('input_terms')
            cls = LookupModule()
            test_md5, result = cls.run(data['terms'], data.get('variables', {}), attributes=data.get('attributes', {}))

# Generated at 2022-06-23 12:12:39.852945
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import python_2_unicode_compatible
    from ansible.module_utils._text import to_native

    # Python 2 and 3 compatible str-to-str conversion
    @python_2_unicode_compatible
    class Py2StrConverter(str):
        def __str__(self):  # noqa
            return str(self)

    class FakeAnsibleModule():
        def __init__(self):
            self.params = {}

    class FakeTemplar():
        def __init__(self, module):
            self.module = module

        def safe_checksum(self, value):
            return value  # return value without checksum


# Generated at 2022-06-23 12:12:49.773491
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:12:50.924740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:13:03.041155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = dict()
    d['users'] = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    lm = LookupModule()
    ret = lm.run([d,'authorized'],dict())

# Generated at 2022-06-23 12:13:13.301499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    b = LookupModule()
    ret = b.run([
        [{'name': 'Alice', 'group': ['Admin', 'Users']},
         {'name': 'Bob',   'group': ['Users']},
         {'name': 'Cecil', 'group': ['Sales']}],
        'group'
    ], dict())
    assert ret == [({'group': ['Admin', 'Users'], 'name': 'Alice'}, 'Admin'), ({'group': ['Admin', 'Users'], 'name': 'Alice'}, 'Users'), ({'group': ['Users'], 'name': 'Bob'}, 'Users'), ({'group': ['Sales'], 'name': 'Cecil'}, 'Sales')]


# Generated at 2022-06-23 12:13:15.018323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:13:26.215609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.sentinel import Sentinel

    data =[]
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, display)
    variable_manager.set_inventory(inventory)

    variable_manager.set_vault_password(Sentinel())

    my_var = {}

# Generated at 2022-06-23 12:13:37.294121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    run = LookupModule(None, None, None).run

# Generated at 2022-06-23 12:13:46.127686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _mock_templar(value, variables, **kwargs):
        return value

    pl = LookupModule(loader=None, templar=_mock_templar)

    def ret(terms):
        return pl.run(terms, variables=None)

    error_msg = 'subelements lookup expects a list of two or three items, '
    assert ret(None) == []
    assert ret(1) == []
    assert ret('abc') == []
    assert ret([]) == []
    assert ret(['abc']) == []
    assert ret(('abc')) == []
    assert ret(('abc', 'def')) == []
    assert ret(('abc', 'def', 'ghi')) == []
    assert ret(('abc', 'def', 'ghi', 'jkl')) == []



# Generated at 2022-06-23 12:13:54.727281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookuper = LookupModule()

    # wrong term
    elementlist = [{'name': 'tom'}, {'name': 'dick', 'groups': ['admins']}, {'name': 'harry', 'groups': ['users']}]
    terms = [elementlist, 'groups']
    result = lookuper.run(terms, None)
    assert result == [('tom', []), ('dick', ['admins']), ('harry', ['users'])]


    # wrong term
    terms = [elementlist, 'groups', {'skip_missing': 'false'}]
    result = lookuper.run(terms, None)
    assert result == [('tom', []), ('dick', ['admins']), ('harry', ['users'])]


    # wrong term

# Generated at 2022-06-23 12:13:55.874181
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



# Generated at 2022-06-23 12:14:07.535787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #the 'return' statements below are used just to make it more obvious that
    #the list being returned is EXACTLY what's being tested
    tests = dict()

    #test that a simple list of dicts works
    lookup_term = dict(
        [('_terms', [[{'a':[1,2]}, {'a': [3,4]}], 'a'])]
    )

# Generated at 2022-06-23 12:14:10.138043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test._templar = None
    test._loader = None
    assert test is not None

# Generated at 2022-06-23 12:14:19.001969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import inspect
    import sys
    import os

    # get current working directory
    cwd = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

    # add the plugin directory to the Python import path
    sys.path.insert(0, cwd + "/../")

    # create the module
    module = LookupModule()

    # test the run method

# Generated at 2022-06-23 12:14:30.796437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)

    # unit test: sub elements lookup
    print("\n\n#####\nTest of subelements lookup\n#####\n")
    variable = "users"
    users = [
        {'name': 'alice', 'authorized': [
            '/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': [
            '/tmp/bob/id_rsa.pub']}]
    terms = [users, "authorized"]
    print("\nTest case ::: subelements lookup of '%s' for subkey '%s'" % (variable, terms[1]))
    print("\nvariables ::: ")
    pp.pp

# Generated at 2022-06-23 12:14:42.399195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit tests for method run of class LookupModule
    """
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # test with mixed types
    mixed_terms = [ 'mixed_list', 'var1', {'skip_missing': 'true'}]

# Generated at 2022-06-23 12:14:44.971217
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    foo = lookup_plugin.run(terms=[['a', 'b', 'c'], 'd'], variables={})
    assert len(foo) == 0


# Generated at 2022-06-23 12:14:48.153525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit test for constructor of class LookupModule.
    #
    # Uses a test fixture from test_runner.py
    #
    # For more info on test fixtures see:
    # https://docs.pytest.org/en/latest/fixture.html
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:14:59.463631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    items = [
        {'item_name': 'one', 'item_sublist': ['1', '2']},
        {'item_name': 'two', 'item_sublist': ['a', 'b']},
        {'item_name': 'three', 'item_sublist': ['x', 'y']},
    ]
    terms = [items, 'item_sublist']
    # result is a list of tuples, so convert to list of lists:
    result = [[list(i) for i in lookup_module.run(terms, None)]]

# Generated at 2022-06-23 12:15:00.500815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()



# Generated at 2022-06-23 12:15:02.509747
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert isinstance(lm, LookupModule)
  assert lm.run is not None

# Generated at 2022-06-23 12:15:04.361985
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:15:11.047345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return super(LookupModule, self).run(terms, variables=variables, **kwargs)
    lookup_instance = LookupModule()

    # test_subelements_run_list_of_dict_and_string
    terms = [ [{'a':1,'b':2},{'a':3,'b':4}], 'b']
    terms = listify_lookup_plugin_terms(terms, loader=None, variables=None)
    result = lookup_instance.run(terms, variables=None)

# Generated at 2022-06-23 12:15:21.231450
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def _test_terms(terms):
        try:
            lookup_plugin = LookupModule()
            lookup_plugin.run(terms, _variables={}, **{})
        except AnsibleError as e:
            return e.message

    # test missing args
    _assert_error(
        _test_terms(None),
        "subelements lookup expects a list of two or three items, "
    )
    _assert_error(
        _test_terms([]),
        "subelements lookup expects a list of two or three items, "
    )
    _assert_error(
        _test_terms([1, 2, 3]),
        "subelements lookup expects a list of two or three items, "
    )

    # test invalid args

# Generated at 2022-06-23 12:15:32.997699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.template import Templar
  from ansible.vars import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.parsing.dataloader import DataLoader
  import __main__
  import sys
  import os

  # Specify a path of a YAML file containing a list of dictionaries with nested keys
  test_file_path = "./test_LookupModule_run.yml"

  # Initialize Fake objects
  fake_inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
  fake_variable_manager = VariableManager(loader=DataLoader(), inventory=fake_inventory)

  """
  Run the method under test:
  lookup.defaults.run(self, terms, variables, **kwargs)
  """
  lookup_plugin = LookupModule()
  lookup

# Generated at 2022-06-23 12:15:46.126616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    lookup_plugin = LookupModule()
    tst = dict(a = dict(b = dict(c = [10, 20, 30])))
    assert lookup_plugin.run([tst, 'a.b.c'], None) == [((tst['a']['b']['c'])[0],), ((tst['a']['b']['c'])[1],), ((tst['a']['b']['c'])[2],)]
    assert lookup_plugin.run([tst, 'a.b.d'], None) == []
    assert lookup_plugin.run([tst, 'a.b.d', dict(skip_missing=True)], None) == []

# Generated at 2022-06-23 12:15:47.032338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:15:59.603519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    class MockedLookupBase(LookupBase):
        def __init__(self, loader, templar, variables):
            self._loader = loader
            self._templar = templar
            self._variables = variables

        def _templated(self, term, variables=None):
            return term

    subelements = LookupModule(MockedLookupBase(None, None, None), [])

    assert subelements.run(['skip_missing'], None) == []

    assert subelements.run([1], None) == []

    terms = (
        [{'a': {'b': [1, 2, 3], 'c': [4, 5, 6]}}],
        "a.b"
    )

# Generated at 2022-06-23 12:16:09.747941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule(argument_spec=dict())
    return_value = dict(
        _ansible_no_log=False,
        failed=False,
        changed=False,
        _ansible_item_result=False,
        results=dict()
    )
    # Constructor
    obj = LookupModule(AnsibleLoader(None, variable_manager=None, datastore=None))
    # method run
    for result in obj.run([[dict(name='Mike')], 'name'], dict()):
        return_value['results']['name'] = result
    module.exit_json(**return_value)


from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 12:16:20.829914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ############################################################################################
    module = LookupModule()

# Generated at 2022-06-23 12:16:30.273500
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prepare mock objects
    class MockAnsibleError:
        def __init__(self, msg):
            self.message = msg

    class MockAnsibleModule:
        def __init__(self, msg):
            self.fail_json = msg
            self._name = 'mockAnsibleModule'

    class MockTemplar:
        def __init__(self, msg):
            self._fail_on_undefined_errors = msg

    class MockLoader:
        def __init__(self, msg):
            self._basedir = msg

    class MockLookupBase(LookupModule):
        def __init__(self, user_terms, user_variables):
            self._templar = MockTemplar(user_terms)
            self._loader = MockLoader(user_variables)

    # call main

# Generated at 2022-06-23 12:16:40.263775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # construct a lookup module object
    lookup_module = LookupModule()
    # create a list of dictionaries

# Generated at 2022-06-23 12:16:46.334477
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.parsing.dataloader
    terms = ["1", "2", "3", "4"]
    loader = ansible.parsing.dataloader.DataLoader()
    templar = ansible.parsing.dataloader.Templar(loader=loader)
    lookup_module = LookupModule()
    assert len(lookup_module.run(terms, templar=templar, loader=loader)) == 1

# Generated at 2022-06-23 12:16:57.667095
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test for lookup_plugin
    def test_lookup_plugin(terms, result, checkMethod, msg=''):

        # create LookupBase-Object of class LookupModule
        lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:17:09.335623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # default behavior
    # yields ('alice', '/tmp/alice/onekey.pub'), ('alice', '/tmp/alice/twokey.pub')
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}]
    result = module.run([users, 'authorized'], dict())

# Generated at 2022-06-23 12:17:15.307731
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()

    # test global variables
    assert lookup_instance._templar is not None
    assert lookup_instance._loader is not None

    # test functions
    assert lookup_instance.run is not None
    assert lookup_instance.run_term is not None
    assert lookup_instance.run_terms is not None
    assert lookup_instance.clear_caches is not None

# Generated at 2022-06-23 12:17:26.645114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'groups': ['admins']},
        {'name': 'carol', 'authorized': ['/tmp/carol/id_rsa.pub']},
        {'name': 'dan', 'authorized': []}
    ]
    kwargs = {}
    ret = lookup.run(['users', 'authorized'], {}, **kwargs)
    assert(isinstance(ret, list))
    assert(len(ret) == 4)

# Generated at 2022-06-23 12:17:27.320630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:17:31.363101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    usage = '''
        Tests lookup using  subelements lookup.
        '''
    import doctest
    doctest.testmod(verbose=True)
    print(usage)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:17:32.939713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:17:42.631136
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    lookup_params = dict(
        _terms=['tmp/list_of_dictionaries.yaml', 'a.b'],
        _variables={},
        _loader=None,
        _templar=None
    )
    lookup_module = LookupModule()
    elements = lookup_module.run(**lookup_params)

    # test if the number of extracted elements is 3
    print("Check number of elements")
    assert len(elements) == 3

    # test if the two first elements are equal
    print("Check first elements")

# Generated at 2022-06-23 12:17:54.717106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with dict
    assert LookupModule.run(None, [{'dict': {'testkey': 'testvalue'}}, 'dict.testkey']) == [{'testkey': 'testvalue'}, 'testvalue']

    # Test with list
    assert LookupModule.run(None, [[{'testkey': 'testvalue'}], '0.testkey']) == [['testkey', 'testvalue'], 'testvalue']

    # Test with missing key
    try:
        LookupModule.run(None, [[{'testkey': 'testvalue'}], 'missing_key'])
    except AssertionError as exc:
        assert exc.args[0] == "could not find 'missing_key' key in iterated item '{'testkey': 'testvalue'}'"
    else:
        raise Ass

# Generated at 2022-06-23 12:18:02.014451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    terms = ['alice', 'bob']
    variables = [{'name':'alice', 'age':'23', 'gender':'female'}, {'name':'bob', 'age':'45', 'gender':'male'}]
    assert module.run(terms, variables) == [('alice', 'bob')]
    terms = ['alice', {'name':'bob', 'age':'45'}, 'gender']
    assert module.run(terms, variables) == [('alice', {'name':'bob', 'age':'45'}), ('alice', 'gender')]
    terms = [{'name':'alice', 'age':'23', 'gender':'female'}, 'name']

# Generated at 2022-06-23 12:18:11.108834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test setup
    import ansible.utils.plugin_docs as plugindocs
    plugindocs.insert_lookup_docs(globals(), 'test_lookup_plugins')

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-23 12:18:17.175435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test started for subelements lookup plugin")

# Generated at 2022-06-23 12:18:18.163544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-23 12:18:28.918997
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Example Data used in tests
    data = [{'name': 'Alice', 'groups': ['wheel', 'users']},
            {'name': 'Bob', 'groups': ['dev', 'users']},
            {'name': 'Chuck', 'groups': None}]

    # To be able to test with Python 2.6:
    def assertItemsEqual_2_6(list1, list2):
        assert len(list1) == len(list2)
        for item in list1:
            assert item in list2

    # Testing
    # ----------------------------------------------------------------------------

    # #test_run: empty list, empty path
    # ----------------------------------------------------------------------------
    ret = LookupModule().run(
        [data, ''],
        [],
        [],
        [],
        [],
        []
    )
    assertItemsEqual_2_

# Generated at 2022-06-23 12:18:41.405351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing constructor of LookupModule...")
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('subelements')
    # Test for two parameters
    try:
        lookup._load_terms(["abcd","efgh"])
        print("ERROR: No error thrown for two parameters")
        raise Exception("Test failed.")
    except AnsibleError as e:
        print("ERROR thrown for two parameters: ", e)
    # Test for three parameters
    try:
        lookup._load_terms(["abcd","efgh",{"skip_missing":True}])
        print("ERROR: No error thrown for three parameters")
        raise Exception("Test failed.")
    except AnsibleError as e:
        print("ERROR thrown for three parameters: ", e)
    print("Done testing constructor of LookupModule")



# Generated at 2022-06-23 12:18:53.211205
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:18:55.288167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_module = LookupModule()
    assert lookup_module != None, "LookupModule object is null"

# Generated at 2022-06-23 12:18:58.690693
# Unit test for constructor of class LookupModule
def test_LookupModule():   # pylint: disable=too-many-public-methods
    assert isinstance(LookupModule(), LookupModule)
    #assert isinstance(LookupModule(run_once=True), LookupModule)


# Generated at 2022-06-23 12:19:10.744601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    #from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.lookup.subelements import LookupModule

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = DataLoader()
            self.inventory = Inventory(self.loader, self.variable_manager, 'localhost')
            self.variable_manager.set_inventory(self.inventory)

            # create play with tasks


# Generated at 2022-06-23 12:19:13.221525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert subelements is not None


# Generated at 2022-06-23 12:19:25.652063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = [{'key': 'value'}]
    subelements_data = ['key', {'subkey': 'subvalue'}]

    # First, test what happens when we don't pass a list
    try:
        LookupModule().run(subelements_data, None)
    except AnsibleError:
        pass
    else:
        assert False, "We should never get here"

    # Second, test what happens when we don't pass a list with the correct number of arguments
    try:
        LookupModule().run(['key'], None)
    except AnsibleError:
        pass
    else:
        assert False, "We should never get here"

    # Third, test what happens when we pass a list but not with a dictionary as the first argument

# Generated at 2022-06-23 12:19:33.214572
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup mock
    terms = [{}]
    variables = {}
    flags = {"skip_missing": True}
    LookupModule.run(terms, variables, **flags)

    # setup generic mock
    terms = [None, None]
    variables = {}
    flags = {'skip_missing': True}
    try:
        lookup_result = LookupModule.run(terms, variables, **flags)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert type(e).__name__ == 'AnsibleError'
        assert str(e) == 'subelements lookup expects a list of two or three items, '

    # check if the result is valid
    assert lookup_result == []

# Generated at 2022-06-23 12:19:35.361338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This is only here to get the code coverage of this constructor
    # Ansible will not call this directly.
    LookupModule(None, None)

# Generated at 2022-06-23 12:19:46.175120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized',
    ]
    result = LookupModule().run(terms, None)
    assert type(result) is list
    assert len(result) == 3
    assert result[0] == ({'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'name': 'alice'}, '/tmp/alice/onekey.pub')

# Generated at 2022-06-23 12:19:54.169159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare
    import sys
    import types
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from units.mock.loader import DictDataLoader

    dict_list_users=[
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups':['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'groups':['sudo', 'ou=unit-testing,dc=example,dc=org']},
        ]

# Generated at 2022-06-23 12:19:56.973486
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the LookupModule class"""
    print('Testing LookupModule')
    lookup = LookupModule()
    terms = ('string', 'test')
    variables = {}
    kwargs = {}
    print(lookup.run(terms, variables, **kwargs))

# Generated at 2022-06-23 12:20:06.964452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test setup
    terms = ["0", "1", "2"]
    terms[0] = [{'skipped': True}, {'mysql': {'hosts': ['localhost']}}]

    # tests
    try:
        lookup_plugin = LookupModule()
        # pylint: disable=unused-variable
        test_1 = lookup_plugin.run(terms, None)
        assert False, "AnsibleError should be raised"
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"