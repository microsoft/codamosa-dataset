

# Generated at 2022-06-23 12:10:08.629089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-23 12:10:15.212353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Verify explicitly set or default attributes of LookupModule class instance: """
    lookup_class = LookupModule()

    # default attributes for basic class instance
    assert lookup_class._supports_check_mode is False
    assert lookup_class._supports_encrypt is False

    # explicitly set attributes for basic class instance
    lookup_class._supports_check_mode = True
    lookup_class._supports_encrypt = True
    assert lookup_class._supports_check_mode is True
    assert lookup_class._supports_encrypt is True

# Generated at 2022-06-23 12:10:25.416166
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import BytesIO, StringIO
    from ansible.utils.display import Display


# Generated at 2022-06-23 12:10:30.034833
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_params = dict(
        basedir='.',
        runner_basedir='.',
        environment={}
    )
    # Like a runner but with no inventory and no loader
    runner = DummyRunner(None, None, **lookup_params)
    lookup = LookupModule(runner)
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 12:10:38.912323
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:10:39.632227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:10:45.940320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Recall: python-docs-samples-master/appengine/standard/hello_world/main.py
    # and https://docs.python.org/2/library/unittest.html
    import unittest
    import mock

    # build the object
    lookup_plugin = LookupModule()

    # build the test case
    class test_LookupModule(unittest.TestCase):

        def setUp(self):
            pass

        def test_something(self):
            pass

    class MockTemplar(object):

        def __init__(self):
            pass

        def template(self, term, preserve_trailing_newlines=True, convert_data=False, fail_on_undefined=True, override_vars=None):
            return term


# Generated at 2022-06-23 12:10:47.156638
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-23 12:10:57.783082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Please note that this uses the underscore prefix convention for
    # private methods.

    # Arrange
    vars = {}
    subelements = '''
- name: alice
  authorized:
    - /tmp/alice/onekey.pub
    - /tmp/alice/twokey.pub
- name: bob
  authorized:
    - /tmp/bob/id_rsa.pub
'''
    templar = DummyTemplar(vars, subelements)
    lookup = LookupModule()


# Generated at 2022-06-23 12:10:58.898958
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #assert False, "test missing"
    pass

# Generated at 2022-06-23 12:11:07.984958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import tempfile

# Generated at 2022-06-23 12:11:18.146275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.get_basedir = lambda x: "."
    lookup.set_loader(lambda x: x)
    lookup._templar = lambda x: x


# Generated at 2022-06-23 12:11:28.564289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultLib

    v = VaultLib([])
    p1 = v.encrypt("password1", "password:password1\n")
    p2 = v.encrypt("password2", "password:password2\n")
    p3 = v.encrypt("password3", "password:password3\n")

    # test the "data" option with subelements

# Generated at 2022-06-23 12:11:32.436131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # empty constructor is used for testing
    m = LookupModule()
    assert m.run(terms = ["abc"], variables = {}) == []

# Generated at 2022-06-23 12:11:40.933890
# Unit test for constructor of class LookupModule
def test_LookupModule():

    def mock_AnsibleError(self, *args, **kwargs):
        raise TypeError(args, kwargs)

    _lookup_test_args = {
        'terms': [
            [
                {
                    'foo': {
                        'bar': ['baz']
                    },
                },
                {
                    'foo': {
                        'bar': ['qux']
                    }
                }
            ],
            'foo.bar',
            {
                'skip_missing': True
            }
        ],
        'variables': {},
        'loader': None,
        'templar': None,
    }

    # Set up the lookup object
    lookup = LookupModule()
    lookup._AnsibleError = mock_AnsibleError


# Generated at 2022-06-23 12:11:51.153902
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:12:02.041672
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeTemplar(object):

        def __init__(self):
            self.template_data = None

        def template(self, data):
            self.template_data = data
            return data

    class FakeLoader(object):

        def __init__(self):
            self.paths = []

        def get_basedir(self, path):
            self.paths.append(path)
            return path.replace("$ansible_playbook_python", "/path/to/playbook")


# Generated at 2022-06-23 12:12:10.826904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    terms = [
        [{
            'foo': 1,
            'bar': 2,
            'baz': [3, 4, 5],
        }],
        'baz'
    ]
    expected = [(
        {
            'foo': 1,
            'bar': 2,
            'baz': [3, 4, 5],
        },
        3
    ), (
        {
            'foo': 1,
            'bar': 2,
            'baz': [3, 4, 5],
        },
        4
    ), (
        {
            'foo': 1,
            'bar': 2,
            'baz': [3, 4, 5],
        },
        5
    )]
    lookup = LookupModule()

# Generated at 2022-06-23 12:12:12.886812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_mod = LookupModule()

    assert lookup_mod._templar is not None

# Generated at 2022-06-23 12:12:14.470150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret



# Generated at 2022-06-23 12:12:19.984675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    users = [{"name": "alex", "authorized": ["/tmp/alex/id_rsa.pub"], "group": ["wheel"]},
             {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"], "group": ["wheel"]}]
    terms = [users, 'authorized']
    return LookupModule(terms, None)

# Generated at 2022-06-23 12:12:22.838077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    (is_fail, exception_msg, traceback) = run_test(is_fail=False)
    if is_fail:
        pytest.fail(exception_msg)


# Generated at 2022-06-23 12:12:35.347481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_terms(**kwargs):
        terms = {
            'list': [{'key1': 'val1', 'key2': 'val2'}],
            'dict': {'key1': 'val1', 'key2': 'val2'}
        }
        terms.update(**kwargs)
        return terms

    def _get_variables():
        return {}

    def _get_kwargs():
        return {}

    def _get_expected_result(result_type='list'):
        return [{'key1': 'val1', 'key2': 'val2'}]

    def _get_expected_result_skip_missing(result_type='list'):
        return []

    def _get_expected_error(msg):
        return AnsibleError(msg)

    # check number of

# Generated at 2022-06-23 12:12:46.252659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm._templar is None
    assert lm._loader is None

    # test case: lookup with list of terms: list of dictionaries and subkey, with skip_missing flag

# Generated at 2022-06-23 12:12:47.252443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-23 12:12:58.874690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_result1 = {}
    test_result2 = {'skipped': True}
    test_result3 = [{'aaa': False, 'aaa.bbb': ['record1'], 'aaa.ccc': 'single'},
                    {'aaa': False, 'aaa.bbb': ['record2', 'record3'], 'aaa.ccc': 'single'},
                    {'aaa': False, 'aaa.bbb': ['record4', 'record5', 'record6'], 'aaa.ccc': 'single'},
                    {'aaa': False, 'aaa.bbb': ['record7'], 'aaa.ccc': 'single'}]
    test_elements = [test_result1, test_result2, test_result3]
    test_subkeys = ['aaa.bbb']

# Generated at 2022-06-23 12:13:10.450407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''
    def _raise_terms_error(condition, msg=""):
        '''A function to check if a condition raises an AnsibleError'''
        def _result():
            '''Check raised AnsibleError'''
            raise AnsibleError(
                "subelements lookup expects a list of two or three items, " + msg)
        try:
            if condition:
                _result()
            else:
                pass
        except AnsibleError:
            pass
        else:
            _result()

    terms = [0, 1, 2]

    assert isinstance(terms, list) and 2 <= len(terms) <= 3


# Generated at 2022-06-23 12:13:22.528257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit testing of LookupModule.run"""
    import ansible.plugins.lookup.subelements
    import ansible.module_utils.parsing.convert_bool
    import ansible.parsing.yaml.objects
    my_lookup = ansible.plugins.lookup.subelements.LookupModule()
    user_list = ansible.parsing.yaml.objects.AnsibleSequence()
    user_list.append({'name': 'alice', 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}})

# Generated at 2022-06-23 12:13:31.711177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mock = LookupModule()

    assert len(lookup_mock.run([['a'], 'b'], {})) == 0

    terms = ['bcd']
    try:
        lookup_mock.run(terms, {})
    except AnsibleError as e:
        assert 'list of two or three items' in str(e)
    else:
        assert False, 'AnsibleError should be raised'

    terms = [{'skipped': True}, 'bcd']
    assert len(lookup_mock.run(terms, {})) == 0

    terms = [{'skipped': False}, 'bcd']
    assert len(lookup_mock.run(terms, {})) == 0

    terms = [['skipped'], 'bcd']

# Generated at 2022-06-23 12:13:40.653552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    lm = LookupModule(loader=loader, basedir='.')
    data = [
        {'name': 'Alice', 'groups': ['wheel'], 'skipped': False},
        {'name': 'Bob', 'skipped': False},
        {'name': 'Chuck', 'skipped': False},
        {'skipped': True},
    ]
    terms = [data, 'groups', {'skip_missing': True}]
    ret = lm.run(terms=terms, variables=None)
    assert ret == [
        ({'name': 'Alice', 'groups': ['wheel'], 'skipped': False}, 'wheel'),
    ]

    terms = [data, 'groups']

# Generated at 2022-06-23 12:13:49.198193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test terms with different length
    terms = ('list')
    # with 3.2.2, the following line would result in: 'unexpected keyword argument \'loader\''
    # since I did not want to make this a breaking change, I added an optional loader argument to the constructor
    # see also: ansible/ansible#55045
    LookupModule(terms, loader=None)

    terms = ('list', 'subkey')
    LookupModule(terms, loader=None)

    terms = ('list', 'subkey', dict(skip_missing='true'))
    LookupModule(terms, loader=None)

    # check first term should be a list (or dict), second a string holding the subkey
    terms = ('string')
    # would result in: 'unexpected keyword argument \'loader\''
    # see also: ansible/ans

# Generated at 2022-06-23 12:13:59.977228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('subelements')

    # define test variables (here in capital letters)
    NAME = 'alice'
    USERS = [
        {'name': NAME},
        {'name': 'bob'}
    ]
    BAD_USERS = {'name': 'bob', 'not_a_list': 'This is not a list'}
    LIST_IN_DICT = [
        {'name': NAME},
        {'name': 'bob', 'list': ['a', 'b', 'c']}
    ]
    KEY = 'list'
    FIRST_KEY = 'name'
    SECOND_KEY = KEY
    NESTED_KEY = 'child.child_list'
    NESTED_FIR

# Generated at 2022-06-23 12:14:03.923215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test_LookupModule ...")
    l = LookupModule()
    lm_ret = l.run(terms=[{'test':'hi'}, 'test'])
    assert lm_ret == ['hi']


# Generated at 2022-06-23 12:14:13.163598
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:14:17.731044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        [{'key1': {'subkey11': [1, 2, 3]}, 'key2': {'subkey21': [4, 5, 6]}}],
        'key1.subkey11',
        {}
    ]
    results = lookup_module.run(terms, None)

# Generated at 2022-06-23 12:14:19.829473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    print('TEST LOOKUPMODULE SUCCESS')


# Generated at 2022-06-23 12:14:21.970242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 12:14:27.632052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    module = LookupModule()
    terms = [[{'name': 'Alice', 'authorized': '/tmp/alice'}], 'authorized']

    # When
    result = module.run(terms, {})

    # Then
    assert result == [({'name': 'Alice', 'authorized': '/tmp/alice'}, '/tmp/alice')]

# Generated at 2022-06-23 12:14:27.963560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:14:28.899721
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:14:29.776154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule()


# Generated at 2022-06-23 12:14:40.917158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Create a dummy module object
    class Args:
        no_log = True
        config = ''
        fact_path=None
        module_path=None

    class Module:
        def __init__(self, args):
            self.args = args

    class VariableManager:
        def __init__(self):
            self.extra_vars = {}

    # Create a lookup module object
    lookup_module = LookupModule()
    lookup_module._templar = basic.AnsibleTemplar(None)
    lookup_module._loader = DataLoader

# Generated at 2022-06-23 12:14:51.490152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock object and object method
    mock_self = type('obj', (object,), {'_templar': None, '_loader': None})()
    lookup_class = LookupModule()
    lookup_class.__class__ = mock_self

# Generated at 2022-06-23 12:15:01.869546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # python setup.py test -s tests/unit --lookup-plugins
    module = LookupModule()

# Generated at 2022-06-23 12:15:12.003175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method run of class LookupModule
    """

    def _assert_run(terms, expected_ret):
        """
        Test the run method of class LookupModule
        """
        lookup_module = LookupModule()
        ret = lookup_module.run(terms, None)
        assert ret == expected_ret

    # Test the case when no terms is a list of two or three items
    terms = [
        ["users", "authorized"],
        ["users", "authorized", {"skip_missing": True}],
        [{"users": ["users", "authorized"]}, {"users": ["users", "authorized", {"skip_missing": True}]}]
    ]

# Generated at 2022-06-23 12:15:14.225818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run([[{'a':'x'}], 'a'], None)
    assert result == [('x',)], result

# Generated at 2022-06-23 12:15:23.473564
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Check if constructor of class LookupModule works properly:
    lookup_module = LookupModule()

    # is the options of LookupModule set correctly?
    data = lookup_module.get_options()
    assert data == {'_terms': {'description': 'tuple of list of dictionaries and dictionary key to extract', 'required': True, 'type': 'list'}, 'skip_missing': {'description': 'Lookup accepts this flag from a dictionary as optional. See Example section for more information.\n- If set to C(True), the lookup plugin will skip the lists items that do not contain the given subkey.\n- If set to C(False), the plugin will yield an error and complain about the missing subkey.', 'type': 'bool', 'default': False}}

    # is the return of LookupModule set correctly?
    data = lookup_module

# Generated at 2022-06-23 12:15:34.087212
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _assert_sublist(sublist):
        def _assert_run(result):
            assert isinstance(result, list)
            assert len(sublist) == len(result)
            for (user, key) in sublist:
                result_user, result_key = result[sublist.index((user, key))]
                assert user == result_user
                assert key == result_key

        return _assert_run

    users = [
        {
            "name": "alice",
            "authorized": [
                "/tmp/alice/onekey.pub",
                "/tmp/alice/twokey.pub"
            ]
        },
        {
            "name": "bob",
            "authorized": [
                "/tmp/bob/id_rsa.pub"
            ]
        }
    ]

# Generated at 2022-06-23 12:15:46.340184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.listify import listify_lookup_plugin_terms

    varmgr = VariableManager()
    varmgr.set_inventory(Inventory(loader=DataLoader(), variable_manager=varmgr))

    vars = dict(
        var1 = 5,
        var2 = [
            dict(
                var3 = 'var3val',
            ),
            dict(
                var3 = 'var3val2',
            ),
        ]
    )
    varmgr.set_vars(vars)


# Generated at 2022-06-23 12:15:46.918872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:15:59.446446
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Init unit test
    mock_templar = MockTemplar()
    mock_loader = MockLoader()
    lookup_plugin = LookupModule()
    lookup_plugin._templar = mock_templar
    lookup_plugin._loader = mock_loader

    # Test lookup module

# Generated at 2022-06-23 12:16:10.227614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock class for self
    class MockLookupBase(LookupBase):
        def __init__(self):
            pass

        def _templar(self, template, vars):
            return template

        def _loader(self, path):
            return path

    lu = MockLookupBase()
    result = lu.run([[{'a': 'a', 'b': [1, 2, 3]}], 'b'], [])
    assert result == [(({'a': 'a', 'b': [1, 2, 3]}, 1),
                       ( {'a': 'a', 'b': [1, 2, 3]}, 2),
                       ( {'a': 'a', 'b': [1, 2, 3]}, 3))]

# Generated at 2022-06-23 12:16:21.176737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with all default parameters
    lookup_options = dict(
        _terms=dict(
            terms=[['foo'], 'bar'],
            variables=dict()
        )
    )
    results = LookupModule().run(**lookup_options)
    assert results == [[('foo', 'bar')]]

    # Test with skip_missing=False
    lookup_options = dict(
        _terms=dict(
            terms=[['foo'], 'bar', dict(skip_missing=False)],
            variables=dict()
        )
    )
    results = LookupModule().run(**lookup_options)
    assert results == [[('foo', 'bar')]]

    # Test with skip_missing=True (should not yield an error)

# Generated at 2022-06-23 12:16:31.007225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    'privkey-alice.pub',
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    'privkey-bob-1.pub',
                    'privkey-bob-2.pub',
                ]
            }
        ],
        'authorized',
    ]
    lookup_result = LookupModule().run(terms)[0]
    assert type(lookup_result) is tuple
    assert len(lookup_result) == 2
    assert type(lookup_result[0]) is dict
    assert type(lookup_result[1]) is string_types
    assert terms[0][0]['name'] == lookup_result[0]['name']
    assert terms

# Generated at 2022-06-23 12:16:41.022494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check for constructor
    lookup = LookupModule()

    # init test-vars
    terms = [
        [
            {'name': 'Alice'},
            {'name': 'Bob', 'skipped': True},  # this one will be skipped
            {'name': 'Carol', 'groups': [], 'mysql': {'password': 123, 'privs': [], 'hosts': []}}
        ],
        'groups'
    ]
    variables = {}
    kwargs = {}

    # make test-run
    groups = lookup.run(terms, variables, **kwargs)

    # check if result is correct
    assert len(groups) == 1
    assert groups[0][0]['name'] == 'Carol'
    assert groups[0][1] == []

    # make second test-run without nested

# Generated at 2022-06-23 12:16:42.559146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'ansible.plugins.lookup.subelements' in sys.modules


# Generated at 2022-06-23 12:16:45.301743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=["users", "authorized"], variables=dict()) == [], "empty terms should yield empty list"



# Generated at 2022-06-23 12:16:49.926191
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # using global variables from ansible module
    lookup_plugin = LookupModule()

    # mocking it's behavior
    lookup_plugin.set_options({})
    lookup_plugin._templar = None
    lookup_plugin._loader = None

    # testing
    assert lookup_plugin.run([], {}) is None
    return True

# Generated at 2022-06-23 12:17:00.247048
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader

    test_loader = DataLoader()

    test_lookup = LookupModule(loader=test_loader)

    # test using dict instead of list
    assert test_lookup.run([{'a': {'b': [1, 2]}}, 'b'], None) == [(1,), (2,)]
    assert test_lookup.run([{'a': {'b': [1, 2]}}, 'b', {'skip_missing': True}], None) == [(1,), (2,)]
    assert test_lookup.run([{'a': {'b': [1, 2]}}, 'b', {'skip_missing': False}], None) == [(1,), (2,)]

    # test using list instead of dict
    assert test_look

# Generated at 2022-06-23 12:17:10.214131
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # MOCK: class LookupBase
    class MockLookupBase:
        def _templar(self, result):
            return result
        def _loader(self, result):
            return result

    # MOCK: method listify_lookup_plugin_terms of class LookupModule
    def mock_listify_lookup_plugin_terms(result, templar=None, loader=None):
        return result

    # MOCK: class AnsibleError
    class MockAnsibleError(Exception):
        pass

    # MOCK: method boolean of module ansible.module_utils.parsing.convert_bool
    def mock_boolean(string, strict=False):
        return string

    # MOCK: method listify of module ansible.utils.listify
    def mock_listify(result):
        return result



# Generated at 2022-06-23 12:17:12.528715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)
    assert isinstance(lu, LookupBase)


# Generated at 2022-06-23 12:17:21.543474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    options = {}
    lookup = LookupModule(loader=DataLoader(), **options)
    var_manager = VariableManager()

    # test first term that should be a list (or dict), second a string holding the subkey
    # first term should be a list (or dict), second a string holding the subkey
    terms = [[{'subkey1': 'value1', 'subkey2': {'subsubkey1': 'subsubvalue1'}}], 'subkey2.subsubkey1']
    ret_list = lookup.run(terms, variables=var_manager.get_vars(loader=DataLoader(), play=None))

# Generated at 2022-06-23 12:17:22.997059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    uut = LookupModule()
    assert isinstance(uut, LookupBase)

# Generated at 2022-06-23 12:17:32.204588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelements = LookupModule()

    # single key
    assert subelements.run([{'some': 'value', 'not': 'present'}, 'some']) == ['value']
    assert subelements.run([{'some': 'value', 'not': 'present'}, 'some', {'skip_missing': True}]) == ['value']

    assert subelements.run([{'some': 'value', 'not': 'present'}, 'not']) == ['present']
    assert subelements.run([{'some': 'value', 'not': 'present'}, 'not', {'skip_missing': True}]) == ['present']

    # two keys

# Generated at 2022-06-23 12:17:33.987460
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Generated at 2022-06-23 12:17:36.750249
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None
    # Uncomment to test LookupModule constructor
    # test = LookupModule()



# Generated at 2022-06-23 12:17:39.308918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup.run("key", "vars", **{'skip_missing': False})


# Generated at 2022-06-23 12:17:49.933245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule

    :return: -
    """
    import sys
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_m_instance = LookupModule()
    terms_in_1 = [["a_list"], "test.test", True]
    terms_in_2 = [["a_dict"], "test.test", True]

# Generated at 2022-06-23 12:17:50.963696
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-23 12:18:00.358543
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    terms = [
        [
            {
                "username": "joris",
                "authorized": [
                    "/tmp/joris/id_rsa.pub"
                ],
                "groups": [
                    "users",
                    "ssh-users"
                ]
            },
            {
                "username": "koen",
                "authorized": [
                    "/tmp/koen/id_rsa.pub",
                    "/tmp/koen/id_rsa.pub.bak"
                ],
                "groups": [
                    "wheel",
                    "ssh-users"
                ]
            }
        ],
        "authorized"
    ]

    ret

# Generated at 2022-06-23 12:18:03.420466
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 12:18:11.611841
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    t = [{"kenny": "blue", "stan": "red", "cartman": "orange"}]

    assert lm.run(["a"], t, val="k") == [], "a string is not a list"
    assert lm.run([["a"]], t, val="k") == [], "a list with a string is not a list of lists"
    assert lm.run([["a", "b"]], t, val="k") == [], "a list with 2 strings is not a list of lists of two elements"
    assert lm.run([["a", "b", "c"]], t, val="k") == [], "a list with 3 strings is not a list of lists of two elements"

# Generated at 2022-06-23 12:18:13.615091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._templar is None and lookup._loader is None

# Generated at 2022-06-23 12:18:15.344488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert(None != l)

# Generated at 2022-06-23 12:18:26.723410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    a = {'a_dictionary': {
        'a_nested_dictionary': {'a_key': 'my_value2'},
        'a_list': ['my_value'],
        'a_string': 'my_value3'
    }}
    # did not put flags here, which should be equal for all following tests
    b = lu.run([a, 'a_dictionary'], [None])
    assert b == [{'a_list': ['my_value'], 'a_key': 'my_value2', 'a_string': 'my_value3'}]
    c = lu.run([a, 'a_dictionary.a_key'], [None])
    assert c == [('my_value2',)]
    d = lu.run

# Generated at 2022-06-23 12:18:39.602943
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import tempfile
    import ansible.utils.template
    import ansible.template
    import ansible.vars
    import ansible.constants

    # create a fake host to generate a valid vars object
    fake_host = ansible.inventory.host.Host('testhost')
    # create a fake loader, since Template uses loader.get_basedir()
    fake_loader = ansible.parsing.dataloader.DataLoader()
    # create a fake templar, since Template uses Templar
    fake_vars = ansible.vars.VariableManager()
    fake_play_context = ansible.playbook.play_context.PlayContext()

# Generated at 2022-06-23 12:18:47.760242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test the method lookups.subelements.LookupModule.run """

    # get the lookup plugin
    lookup = LookupModule()

    # define the users list of dictionaries

# Generated at 2022-06-23 12:18:50.123898
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module,LookupModule)


# Generated at 2022-06-23 12:19:00.220888
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:12.038668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # the second term can be empty if the first term is a list of dictionaries
    lm.run([{1: 'one', 2: 'two'}], None)  # output: [1, 2]
    # second term as list (returns all subelements from the first argument)
    lm.run([{'one': {1: 'first', 2: 'second'}, 'two': {3: 'third', 4: 'fourth'}}], None)  # output: [1, 2, 3, 4]
    lm.run([{'one': {1: 'first', 2: 'second'}, 'two': {3: 'third', 4: 'fourth'}}, 'one'], None)  # output: [1, 2]

# Generated at 2022-06-23 12:19:12.850362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return

# Generated at 2022-06-23 12:19:13.741653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:19:14.784989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:19:27.265994
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=unused-variable
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    # Create a test environment in order to run the lookup
    # Since we are not running through ansible we need to create vars in order
    # to run the lookup
    class Environment:
        def __init__(self, vars):
            self.vars = vars

    # Create a test templar in order to run the lookup
    # Since we are not running through ansible we need to create vars in order
    # to run the lookup
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-23 12:19:28.760707
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(
        terms=["users", "authorized"],
        variables=[]
    )

# Generated at 2022-06-23 12:19:39.806071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # must be true for some tests
    assert(isinstance(loader, DataLoader))

    # Just as a test:
    # isinstance(loader, DataLoader) == True

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible import context


# Generated at 2022-06-23 12:19:40.536163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:19:51.512774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # basic example
    users = [
        {"name": "Alice", "authorized": ["/tmp/alice/id_rsa.pub"]},
        {"name": "Bob", "authorized": ["/tmp/bob/id_rsa.pub"]},
        {"name": "Carol", "authorized": ["/tmp/carol/id_rsa.pub"]},
    ]
    result = lookup_module.run([users, "authorized"], {})[0]

# Generated at 2022-06-23 12:19:52.471365
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:20:00.745929
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:20:09.855151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            {
                "name": "alice",
                "authorized": [
                    "/tmp/alice/onekey.pub",
                    "/tmp/alice/twokey.pub"
                ],
                "groups": [
                    "wheel"
                ]
            },
            {
                "name": "bob",
                "authorized": [
                    "/tmp/bob/id_rsa.pub"
                ]
            },
            {
                "skipped": True
            }
        ],
        "authorized"
    ]
