

# Generated at 2022-06-23 12:10:16.222832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    items = {'a': {'b': [1, 2, 3], 'd': 4, 'c': {'e': [5, 6], 'f': 1}}}
    subelements = 'c.e'
    terms = [items, subelements]

    result = LookupModule().run(terms, None)
    assert isinstance(result, list)
    assert len(result) == 2
    # Check if the two expected lists were returned
    for item in result:
        assert isinstance(item[0], dict)
        assert isinstance(item[1], int)
        assert isinstance(item[0]['c'], dict)
        for val in item[0]['c']['e']:
            assert isinstance(val, int)



# Generated at 2022-06-23 12:10:18.738035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # check if type of lm is indeed LookupModule
    assert (type(lm) == LookupModule)



# Generated at 2022-06-23 12:10:28.724597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # setup
    lookup_subelements = LookupModule()
    lookup_subelements.basedir = "."

    # Test simple stuff
    elementlist = [{'xyz': {'foo': 'bar'}}]
    results = lookup_subelements.run(["", "xyz.foo", {}], [])
    assert results == [('bar',)]

    # Test with skip_missing=True
    elementlist = [{'xyz': {'foo': 'bar'}}]
    results = lookup_subelements.run(["", "xyz.oops", {'skip_missing': True}], [])
    assert results == []

    # Test with skip_missing=False

# Generated at 2022-06-23 12:10:30.203450
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor for LookupModule
    l = LookupModule()
    return l

# Generated at 2022-06-23 12:10:30.981808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:10:39.885544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}

    # Test missing mandatory terms
    try:
        LookupModule.run(terms, variables)
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e)

    # Test invalid optional flags
    terms.append([{'name': 'aaa'}, 'authorized'])
    try:
        LookupModule.run(terms, variables)
        assert False
    except AnsibleError as e:
        assert "could not find 'authorized' key" in str(e)

    terms[0] = [{'name': 'aaa'}, 'authorized']
    terms[1] = {'skip_missing': True}

# Generated at 2022-06-23 12:10:46.174719
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar


# Generated at 2022-06-23 12:10:57.068694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_str
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, shared_loader_data=None)
    vault_secret = 'test secret'
    vault_password = VaultLib([], True).encrypt(vault_secret)

# Generated at 2022-06-23 12:11:05.183073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    eq_(lookup_module.run([
        [{'alpha': 'first', 'foo': ['bar1', 'bar2']}, {'beta': 'second', 'foo': ['bar3']}],
        'foo',
        {'skip_missing': False},
        ]),
        [({'alpha': 'first', 'foo': ['bar1', 'bar2']}, 'bar1'), ({'alpha': 'first', 'foo': ['bar1', 'bar2']}, 'bar2'), ({'beta': 'second', 'foo': ['bar3']}, 'bar3')]
        )

# Generated at 2022-06-23 12:11:14.817444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_plugin_class = LookupModule
    lookup_plugin = lookup_plugin_class()

    class Object():
        pass

    testobject = Object()
    testobject.skipped = False
    testobject.name = "alice"
    testobject.authorized = [
        "/tmp/alice/onekey.pub",
        "/tmp/alice/twokey.pub"
    ]
    testobject.mysql = Object()
    test

# Generated at 2022-06-23 12:11:15.639260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 12:11:18.604616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class NewClass(LookupModule):
        def run(self, terms, variables, **kwargs):
            return [terms,variables]

    assert NewClass() is not None


# Generated at 2022-06-23 12:11:28.933509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.loader import LookupModule as LookupModuleClass, get_loader
    from ansible.template import Templar

    def _get_loader_mock_class(subkey_value=None, ternary=False, elementlist=None):

        class LoaderModuleMock():

            class DataLoader():
                @staticmethod
                def get(name, *args, **kwargs):
                    if name == "terms":
                        return subkey_value
                    else:
                        raise AnsibleError("Unexpected loader.get call with name {0}.".format(name))

            class Template():
                @staticmethod
                def templar(value, variables):
                    return subkey_value


# Generated at 2022-06-23 12:11:39.839182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultAES256


# Generated at 2022-06-23 12:11:50.374853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

# Generated at 2022-06-23 12:12:01.489812
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:12:10.463449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import re

    # Adjust the env path to include ansible bin path
    ansible_bin_path = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, 'bin')
    if ansible_bin_path not in os.environ['PATH']:
        os.environ['PATH'] = ':'.join([ansible_bin_path, os.environ['PATH']])

    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase

    lu = LookupModule()

    # test error handling - missing terms argument

# Generated at 2022-06-23 12:12:16.678453
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:12:26.416833
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        {'name': 'charlie', 'authorized': []}]


# Generated at 2022-06-23 12:12:28.748354
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-23 12:12:40.699100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.splitter import parse_kv

    from ansible.plugins.lookup.subelements import LookupModule as TestLookupClass
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    lookup_obj = TestLookupClass()

    def check_lookup_result(param, expected_result, ansible_vars=None):
        if not isinstance(param, list):
            param = [param]
        res = lookup_obj.run(terms=param, variables=ansible_vars)
        assert res == expected_result

    # test with list as first term

# Generated at 2022-06-23 12:12:42.446175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:12:44.531008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu._templar is not None
    assert lu._loader is not None

# Generated at 2022-06-23 12:12:52.172469
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # generate invalid terms
    invalid_terms = [
        # terms should be a list
        {},
        # 2 terms ([{}, 'key'], 3 terms [{}, 'key', {'skip_missing': True}])
        [{}],
        ['key'],
        ["key", "key"]
    ]
    for terms in invalid_terms:
        try:
            lm.run(terms=terms, variables={})
            assert False
        except AnsibleError as e:
            assert str(e) == "subelements lookup expects a list of two or three items"
    # valid terms

# Generated at 2022-06-23 12:12:53.512098
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 12:13:05.673607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    test_obj=LookupModule()
    terms = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': 'wheel'}, 'authorized']

    # when
    actual_result = test_obj.run(terms, variables={}, all_vars={}, templar='', loader='', filters={})

    # then

# Generated at 2022-06-23 12:13:15.066784
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:16.669595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_ret = LookupModule()
    assert lookup_ret

# Generated at 2022-06-23 12:13:27.374461
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create class for testing
    L = LookupModule()


    users = [
        {'name': 'alice',
         'authorized': [ '/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub' ],
         'mysql': {
             'password': 'mysql-password',
             'hosts': [
                 '%',
                 '127.0.0.1',
                 '::1',
                 'localhost'
             ],
             'privs': [
                 '*.*:SELECT',
                 'DB1.*:ALL'
             ]
         },
         'groups': [ 'wheel' ]
        }
    ]
    res = L.run(terms = ['{{ users }}', 'authorized'], variables = {'users': users}, **{})

# Generated at 2022-06-23 12:13:29.633101
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None



# Generated at 2022-06-23 12:13:39.453465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    import pytest
    lookup = LookupModule()
    # base test
    assert(lookup.run([[{"a": 1, "b": {"c": [2, 3]}}], "a"], {}) == [[{"a": 1, "b": {"c": [2, 3]}}], 1])
    assert(lookup.run([[{"a": 1, "b": {"c": [2, 3]}}], "b.c"], {}) == [[{"a": 1, "b": {"c": [2, 3]}}], 2])
    # test skip_missing

# Generated at 2022-06-23 12:13:40.693283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l


# Generated at 2022-06-23 12:13:49.232996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    users = [{'name': 'alice'}, {'name': 'bob'}]
    terms = [users, 'name']
    ret = LookupModule().run(terms, None)
    assert ret == [('alice',), ('bob',)]

    terms.append({'skip_missing': True})
    ret = LookupModule().run(terms, None)
    assert ret == [('alice',), ('bob',)]

    terms[0].append({'name': 'bob'})
    with pytest.raises(Exception) as e:
        ret = LookupModule().run(terms, None)

# Generated at 2022-06-23 12:14:00.141531
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:14:11.025145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two items, first a dict or a list, second a string pointing to the subkey " + msg)


# Generated at 2022-06-23 12:14:19.535448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    FLAGS = ('skip_missing',)

    def test_lookup_module():
        # first term should be a list (or dict), second a string holding the subkey
        if not isinstance(terms[0], (list, dict)) or not isinstance(terms[1], string_types):
            raise AnsibleError("first a dict or a list, second a string pointing to the subkey")
        subelements = terms[1].split(".")


# Generated at 2022-06-23 12:14:31.236627
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # inventory
    vars_data = {"users": [
        {"name": "alice",
         "authorized": ["/tmp/alice/onekey.pub",
                        "/tmp/alice/twokey.pub"]}]}
    loader = DictDataLoader(vars_data)
    variables = VariableManager(loader=loader)

    # inventory
    dataloader = DataLoader()
    templar = Templar(loader=dataloader, variables=variables)

    # make lookup
    lookup_plugin = LookupModule()
    lookup_plugin._templar = templar
    lookup

# Generated at 2022-06-23 12:14:43.036680
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with non-existing key
    testusers = [
        {
            'name': 'foo',
            'sublist': {
                'subkey': 'foo',
            },
        },
        {
            'name': 'bar',
            'sublist': {
                'subkey': 'bar',
            },
        },
    ]
    # test with subkey in last element
    ret = LookupModule().run([testusers, "sublist.subkey", {'skip_missing': False}], variables={})
    assert ret == [{'subkey': 'foo'}, {'subkey': 'bar'}], ret

    # test with missing subkey testusers

# Generated at 2022-06-23 12:14:53.260393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # try invalid number of terms
    try:
        LookupModule([], None)
        assert False
    except AnsibleError:
        assert True
    try:
        LookupModule(['one', 'two', 'three', 'four'], None)
        assert False
    except AnsibleError:
        assert True

    # try invalid type of terms
    try:
        LookupModule(['one', 'two'], None)
        assert False
    except AnsibleError:
        assert True
    try:
        LookupModule([{}, 'two'], None)
        assert False
    except AnsibleError:
        assert True
    try:
        LookupModule([['one'], 'two'], None)
        assert True
    except AnsibleError:
        assert False

# Generated at 2022-06-23 12:14:54.224195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:15:01.785077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyVars(object):
        def __init__(self, the_dict):
            self.vars = the_dict


# Generated at 2022-06-23 12:15:09.554490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    look._templar = object()
    look._loader = object()
    # Terms: [complex list of dictionaries, subkey (string), flags (optional)]
    # Expected results: simple list of tuples (dictionary, sublist-element)
    # Test no. 1:

# Generated at 2022-06-23 12:15:10.412444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run') == True

# Generated at 2022-06-23 12:15:12.510998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    return True

# Generated at 2022-06-23 12:15:13.574222
# Unit test for constructor of class LookupModule
def test_LookupModule():
        assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:15:15.220027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["users", "authorized"]
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 12:15:24.390729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    For this test, we need to define variables that would normally be imported.
    """
    import copy
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems

    # Set module_utils import variable(s)
    ansible_module_utils_common_collections_ImmutableDict = ImmutableDict
    ansible_module_utils_six_iteritems = iteritems

    # Set module import variable(s)
    ansible_plugins_lookup_LookupBase_supports_check_mode = False
    ansible_plugins_lookup_LookupBase_supports_test = False
    ansible_plugins_lookup_LookupBase_supports_test_mode = True

    #

# Generated at 2022-06-23 12:15:34.359152
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:15:46.548108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    #initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    # set options

# Generated at 2022-06-23 12:15:59.027140
# Unit test for constructor of class LookupModule
def test_LookupModule():
        test = LookupModule()
        terms = [
            [
                {'foo': {'bar': {'baz': [1,2,3]}}},
                {'foo': {'bar': {'baz': [42,42,42]}}}
            ],
            'foo.bar.baz'
        ]
        result = test.run(terms,{}).sort()

# Generated at 2022-06-23 12:16:03.096501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Arrange
    terms = [ {u'foo':{u'bar':[u'first value', u'second value']}} ]
    terms.append(u'foo.bar')

    # Act
    l = LookupModule()

    # Assert
    assert subelements_result == l.run(terms, None)


# Generated at 2022-06-23 12:16:12.267971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test for error TermsError
    terms=[10, 'mysql.password', {'skip_missing': False}]
    ret = module.run(terms, None)
    assert ret == []

    # Test for error TermsError
    terms=[{'key':10}, 'mysql.password', {'skip_missing': False}]
    ret = module.run(terms, None)
    assert ret == []

    # Test for valid terms

# Generated at 2022-06-23 12:16:18.794892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__.strip().split("\n")) == 5
    assert LookupModule.run.__doc__.split("\n")[0] == \
           """run(terms, inject=None, **kwargs) -> list of strings"""
    lookup_module = LookupModule()
    assert len(lookup_module.run([], {}, templar=None, loader=None)) == 0

# Generated at 2022-06-23 12:16:25.483517
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Method run of class LookupModule
    l = LookupModule()
    # Test case 1: skip missing
    users = {
        'user1': {
            'mysql': {
                'password': 'mysql-password1',
                'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
                'privs': ['*.*:SELECT', 'DB1.*:ALL']
            }
        },
        'user2': {
            'mysql': {
                'password': 'mysql-password2',
                'hosts': ['db1'],
                'privs': ['*.*:SELECT', 'DB2.*:ALL']
            }
        }
    }

# Generated at 2022-06-23 12:16:36.131291
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:16:45.211585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = lambda x: x
    l._loader = lambda x: x

    terms = ("{{ mylist }}", "mysublist", {'skip_missing': True})
    mylist = [{"mysublist": ["a", "b", "c", "d"]}]
    result = l.run(terms, vars={"mylist": mylist})
    assert result == [('a',), ('b',), ('c',), ('d',)]

    terms = ("{{ mydict }}", "mysublist", {'skip_missing': True})
    mydict = {"item1": {"mysublist": ["a", "b", "c", "d"]}, "item2": {"mysublist": ["e", "f", "g", "h"]}}

# Generated at 2022-06-23 12:16:56.771314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup.subelements import LookupModule


# Generated at 2022-06-23 12:17:08.814741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of the class LookupModule
    """
    lookup_module = LookupModule()

    # test with empty terms
    terms = []
    result = lookup_module.run(terms, [])
    assert result is None

    # test with invalid terms
    terms = [1, 2, 3]
    result = lookup_module.run(terms, [])
    assert result == []

    # test with correct terms

# Generated at 2022-06-23 12:17:19.336327
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:17:20.300337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:17:30.376157
# Unit test for constructor of class LookupModule
def test_LookupModule():
    argdata = {'host': ['host1', 'host2'], 'user': 'testuser'}
    argdata.update(dict((x, True) for x in FLAGS))
    # setup test conditions
    lookup = LookupModule()
    # execute code to test
    terms = [argdata, 'host', argdata]
    ret = lookup.run(terms, None, inject={"lookup_plugin_name": "subelements"})
    # verify results
    assert type(ret) is list
    for x in ret:
        assert type(x) is tuple
        assert len(x) == 2
        assert type(x[0]) is dict
        assert type(x[1]) is str
        assert x[0]['user'] == 'testuser'
        assert x[1] in argdata['host']
   

# Generated at 2022-06-23 12:17:41.658154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json

# Generated at 2022-06-23 12:17:53.641502
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar:
        def __init__(self):
            self.res = None

        def template(self, value, fail_on_undefined=True):
            self.res = value
            return value

        def reset(self):
            self.res = None

        def is_template(self, value):
            return False

    # Simulate:
    # - var= {'a':'b','c':'d'}
    # - var2= [{'a':'b','c':'d'}]
    var = {'a': 'b', 'c': 'd'}
    var2 = [{'a': 'b', 'c': 'd'}]

    # Using LookupModule() directly
    # NOTE: It will 'fail' because the templar is not initialized
    t = Mock

# Generated at 2022-06-23 12:17:54.050688
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:18:05.372803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C



# Generated at 2022-06-23 12:18:16.896595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # - check lookup terms - check number of terms
    assert_exception(Exception)
    # - check lookup terms - check number of terms
    assert_exception(Exception, "too many terms")
    # - first term should be a list (or dict), second a string holding the subkey
    assert_exception(Exception, [["list"], ["of", "list"]])
    assert_exception(Exception, [{"list": "of", "dict": {3: 2}}, ["of", "list"]])
    assert_exception(Exception, [["list"], "of.dict"])
    assert_exception(Exception, [{"list": "of", "dict": {3: 2}}, "of.dict"])
    # - check for optional flags in third term

# Generated at 2022-06-23 12:18:25.182016
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import pytest

    # construct a LookupModule object
    lookup_plugin = LookupModule()

    # apply some tests
    with pytest.raises(AnsibleError):
        lookup_plugin.run(["users", "authorized", {"skip_missing": True}], {})
    with pytest.raises(AnsibleError):
        lookup_plugin.run(["users", "authorized"], {})
    with pytest.raises(AnsibleError):
        lookup_plugin.run(["users", "authorized", {"timeout": 60}], {})

# Generated at 2022-06-23 12:18:26.070052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-23 12:18:32.900727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for LookupModule class.
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    yaml_loader = DataLoader()
    variable_manager = VariableManager(loader=yaml_loader)
    inventory = InventoryManager(loader=yaml_loader, sources='localhost,')
    inventory.subset('all')

    lookup_plugin = LookupModule()
    lookup_plugin._templar = VariableManager._templar
    lookup_plugin._loader = yaml_loader
    lookup_plugin.set_options(dict(
        List=["alice"],
        Field="groups",
        Vars={'skip_missing': True}))



# Generated at 2022-06-23 12:18:34.709347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin



# Generated at 2022-06-23 12:18:44.942119
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:18:56.210394
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_variables(variable_name, variable_value):
        variable_name = variable_name.replace('.', '_')
        variable_dict = {variable_name: variable_value}
        return variable_dict

    test_vars = test_variables('users', [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob',   'authorized': ['/tmp/bob/id_rsa.pub']}
    ])

    lu = LookupModule()
    lu.set_options(None, test_vars, test_variables)
    result = lu.run(['users', 'authorized'], test_vars)

# Generated at 2022-06-23 12:19:03.761012
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test that 2 or 3 terms are required
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plugin = LookupModule()
        lookup_plugin.run([], None)
    assert "subelements lookup expects a list of two or three items" in str(excinfo.value)

    # Test that terms list should be a list
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plugin = LookupModule()
        lookup_plugin.run("another string", None)
    assert "subelements lookup expects a list of two or three items" in str(excinfo.value)

    # Test that terms list should be a list
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:19:04.877012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup is None

# Generated at 2022-06-23 12:19:14.839584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing subelements lookup plugin")
    lookup_terms = [{'skipped': False}, 'password']
    x = LookupModule()
    res = x.run(lookup_terms, variables={}, **{})
    assert isinstance(res, list)
    assert res == []
    #

# Generated at 2022-06-23 12:19:27.305613
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:37.492939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test instance of LookupModule class
    instance = LookupModule()
    
    # Create test data

# Generated at 2022-06-23 12:19:48.411857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import templar
    import unittest

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            basedir = os.path.dirname(sys.modules[__name__].__file__)
            self.loader = templar.Loader(basedir)
            self.templar = templar.Templar(loader=self.loader)
            self.lookup_instance = LookupModule()

        def test_subelements_list(self):
            data = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
            terms = [{'name': 'value1', 'mysql': {'password': 'mysql-password', 'privs': ['all']}}]

# Generated at 2022-06-23 12:19:58.304004
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate the LookupModule
    lm = LookupModule()

    # run tests
    assert lm.run([''], {}, **{}) == []
    assert lm.run([''], {}, **{}) == []
    assert lm.run([dict()], {}, **{}) == []

# Generated at 2022-06-23 12:20:08.358822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    from ansible_collections.notstdlib.moveitallout.plugins.lookup.subelements import LookupModule

    class Options(object):
        def __init__(self):
            self.connection = 'smart'
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None