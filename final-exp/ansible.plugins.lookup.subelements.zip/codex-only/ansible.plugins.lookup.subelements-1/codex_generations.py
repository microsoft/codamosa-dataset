

# Generated at 2022-06-23 12:10:14.079228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the case where it is passed a dictionary as the first term.
    We expect that it returns just the inner list, not the dict that contains it.
    """
    lm = LookupModule()
    first = {'first-list': ['a', 'b', 'c']}
    second = 'first-list'
    result = lm.run([first, second], dict())
    assert result == [['a'], ['b'], ['c']]

# Generated at 2022-06-23 12:10:24.480132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare object for lookup
    lookup = LookupModule()

    # Test error on missing first argument
    with pytest.raises(AnsibleError, match="list of two or three items, first a dict or a list, second a string pointing to the subkey"):
        lookup.run([])

    # Test error on empty first argument
    with pytest.raises(AnsibleError, match="list of two or three items, first a dict or a list, second a string pointing to the subkey"):
        lookup.run([[]])

    # Test error on missing second argument
    with pytest.raises(AnsibleError, match="list of two or three items, first a dict or a list, second a string pointing to the subkey"):
        lookup.run([[], {}])

    # Test error on empty second argument

# Generated at 2022-06-23 12:10:33.492219
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:10:44.000975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None  # mock a templar object
    lookup_module._loader = None  # mock a loader object
    lookup_module.set_options({})

    # check lookup terms - check number of terms
    terms = ['foo']
    try:
        lookup_module.run(terms, None)
        assert False, "subelements lookup failed to raise error when given too few arguments"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e)
    terms = ['foo', 'a', 'b', 'c']

# Generated at 2022-06-23 12:10:56.251669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # raises TestError if something's wrong
    class TestError(Exception):
        pass

    class LookupModuleSubclass(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            raise NotImplementedError

    lookup_module = LookupModuleSubclass()


# Generated at 2022-06-23 12:11:00.183373
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check for a functional test of the LookupModule class
    lu = LookupModule()
    assert 'LookupModule' == lu.__class__.__name__
    return True



# Generated at 2022-06-23 12:11:02.282852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule.__doc__

# Generated at 2022-06-23 12:11:03.174007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass

# Generated at 2022-06-23 12:11:12.918236
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:11:19.108429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelements = LookupModule()
    # missing subkey
    test_result = subelements.run([{"foo": "bar"}, "not_there"])
    assert len(test_result) == 0
    # missing subkey but skip_missing
    test_result = subelements.run([{"foo": "bar"}, "not_there", {"skip_missing": True}])
    assert len(test_result) == 0
    # missing subkey and not skip_missing should raise exception
    try:
        test_result = subelements.run([{"foo": "bar"}, "not_there", {"skip_missing": False}])
    except AnsibleError as e:
        assert "could not find" in str(e)
    # test with subkey

# Generated at 2022-06-23 12:11:29.167577
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Add test method
    def dict_get(data, key):
        for k, v in data.items():
            if k == key:
                yield v
            elif isinstance(v, dict):
                for result in dict_get(v, key):
                    yield result
            elif isinstance(v, list):
                for d in v:
                    if isinstance(d, dict):
                        for result in dict_get(d, key):
                            yield result

    def sorted_dict_values(adict):
        keys = sorted(adict)
        return [adict[key] for key in keys]

    class MockTemplar(object):

        def template(self, value, to_native=False):
            return value


# Generated at 2022-06-23 12:11:32.898172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule(loader=None, templar=None, **{})
    assert lookup_module


# Generated at 2022-06-23 12:11:41.132425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # no terms
    try:
        module.run([], {})
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "

    # wrong terms
    try:
        module.run([{}], {})
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

    try:
        module.run([[{}]], {})
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"


# Generated at 2022-06-23 12:11:49.809093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    data = {
        'name': 'Bobby Tables',
        'department': 'IT',
        'roles': [
            {
                'name': 'developer',
                'tags': ['algo', 'python'],
            },
            {
                'name': 'system admin',
                'tags': ['networking', 'linux'],
            },
        ],
    }
    terms = (data, 'roles.tags')
    result = lookup.run(terms, {})
    assert result == [('algo',), ('python',), ('networking',), ('linux',)]



# Generated at 2022-06-23 12:11:57.380073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = {}
    lm = LookupModule()
    assert type(lm) == LookupModule
    terms = ["myterm"]
    result = lm._templar.template(terms, variables=variables, loader=loader)
    assert result == "myterm"
    result = lm._loader.load_from_file(terms)
    assert result == "myterm"


# Generated at 2022-06-23 12:12:05.358151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.objects import AnsibleUnicode

    users = list()
    user = dict()
    user['name'] = AnsibleUnicode('alice')
    user['authorized'] = AnsibleUnicode('/tmp/alice/onekey.pub')
    users.append(user)

    user1 = dict()
    user1['name'] = AnsibleUnicode('bob')
    user1['authorized'] = [AnsibleUnicode('/tmp/bob/id_rsa.pub'), AnsibleUnicode('/tmp/bob/id_rsa_pub.pub')]
    users.append(user1)

    user2 = dict()

# Generated at 2022-06-23 12:12:13.365053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class AnsibleModuleMock():
        class AnsibleModule():
            def __init__(self):
                self.params = {
                    'a': {
                        'b': [
                            {
                                'c': [
                                    'e',
                                    'f'
                                ]
                            },
                            {
                                'c': [
                                    'g',
                                    'h'
                                ]
                            }
                        ],
                        'c': [
                            {
                                'd': [
                                    'i',
                                    'j'
                                ]
                            },
                            {
                                'd': [
                                    'k',
                                    'l'
                                ]
                            }
                        ]
                    }
                }
        def __init__(self):
            self.result

# Generated at 2022-06-23 12:12:24.149139
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test subelements lookup, here users is a list of dicts
    class TestSubelements(object):
        def __init__(self, users):
            self.lookup_module = LookupModule()
            self.variables = dict()
            self.result = self.lookup_module.run(
                terms=[users, 'authorized'],
                variables=self.variables
            )
        def test_get(self):
            # Test if subelements is a list of tupels
            assert isinstance(self.result, list)
            # Test that the number of users with authorized keys is correct
            assert len(self.result) == 2
            # Test that the first user has 2 authorized keys
            assert len(self.result[0]) == 2
            # Test that the first authorized key is absolute path (/tmp/alice/

# Generated at 2022-06-23 12:12:36.593966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    list_of_dictionaries = [
        {
            'key_one': {
                'key_two': (1, 2, 3, 4)
            }
        },
        {
            'key_two': {
                'key_one': (1, 2, 3, 4),
                'key_three': (5, 6, 7, 8)
            }
        }
    ]

    l1 = LookupModule()
    result = l1.run([list_of_dictionaries, 'key_two.key_one'], None)
    assert result == [(list_of_dictionaries[0], (1, 2, 3, 4)), (list_of_dictionaries[1], (1, 2, 3, 4))]

# Generated at 2022-06-23 12:12:37.222240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:12:47.790122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution

    class Distro(Distribution):
        OSDIST = 'Amazon'
        OSMAJOR = '2017.03'
        OSNAME = 'Amazon'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = inventory.get_host('localhost')

# Generated at 2022-06-23 12:12:49.870075
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    test initialization of LookupModule class
    :return: none
    """
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:13:01.956355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _mock_AnsibleError(message):
        pass

    def _mock_AnsibleModule_get_bin_path(binary, required=True, opt_dirs=[]):
        return "foo"

    def _mock_AnsibleModule_run_command(args):
        return 1, "", ""

    modules = {
        'ansible.modules.lookup_plugins.subelements': {
            'AnsibleError': _mock_AnsibleError,
            'AnsibleModule': {
                'get_bin_path': _mock_AnsibleModule_get_bin_path,
                'run_command': _mock_AnsibleModule_run_command,
            }
        }
    }

    from ansible.plugins.lookup import subelements


# Generated at 2022-06-23 12:13:03.871733
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:13:06.960135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.subelements
    lookup_plugin = ansible.plugins.lookup.subelements.LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:13:15.864226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    # test object
    lu = LookupModule()

    # testing run()

# Generated at 2022-06-23 12:13:17.484670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    print(obj.__dict__)

# Generated at 2022-06-23 12:13:28.035067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    terms = [
        [
            {
                "name": "serge",
                "mysql": {
                  "password": "topsecret",
                  "hosts": [
                    "db1",
                    "db2",
                    "db3"
                  ],
                },
            },
            {
                "name": "alice",
                "mysql": {
                  "password": "topsecret",
                  "hosts": [
                    "db4",
                    "db5",
                  ],
                },
            },
        ],
        "mysql.hosts",
    ]
    variables = {}
    kwargs = {}

    lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-23 12:13:37.968601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ##
    # Preparation
    #
    ##
    # Prepare result list
    results = []
    results.append({'name': 'alice', 'authorized': None, 'groups': ['wheel'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}})
    results.append({'name': 'bob', 'authorized': None, 'groups': None, 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}})
    ##
    # Prepare reference list
    ref = []

# Generated at 2022-06-23 12:13:47.746011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("subelements", users, "groups", { "skip_missing": true }) }}')))
        ]
    )


# Generated at 2022-06-23 12:13:54.187041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.run([
        [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
         {'name': 'bob', 'authorized': ['/tmp/alice/id_rsa.pub']}], 'authorized'])[0] == (
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/onekey.pub')

# Generated at 2022-06-23 12:13:55.932823
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert True


# Generated at 2022-06-23 12:14:07.572844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    # sys.argv.insert(1, '--user=vagrant')
    sys.argv.insert(2, '--ask-pass')
    sys.argv.insert(3, '--ask-su-pass')
    sys.argv.insert(4, '--ask-sudo-pass')
    # sys.argv.insert(5, '--become')
    # sys.argv.insert(6, '--ask-become-pass')
    sys.argv.insert(7, '--ask-vault-pass')
    sys.argv.insert(8, '--extra-vars={"ansible_ssh_private_key_file":"' + str(os.path.join(str(os.getcwd()), 'vagrant_key')) + '"}')

    # no

# Generated at 2022-06-23 12:14:08.655897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:14:18.295158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test is for regression of #23984
    """
    lookup = LookupModule()
    assert len(lookup.run(['foo', 'bar'], {})) == 0
    assert len(lookup.run([['foo'], 'bar'], {})) == 0
    assert len(lookup.run([{'foo': 'foo'}, 'bar'], {})) == 0

    assert len(lookup.run(['foo', 'bar', {'skip_missing': True}], {})) == 0
    assert len(lookup.run([['foo'], 'bar', {'skip_missing': True}], {})) == 0
    assert len(lookup.run([{'foo': 'foo'}, 'bar', {'skip_missing': True}], {})) == 0


# Generated at 2022-06-23 12:14:30.359790
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Run constructor
    lookup_plugin = LookupModule()

    # Initialize variables
    terms1 = [
        {'name': 'alice', 'groups': ['wheel']},
        'groups'
    ]
    terms2 = [
        {'name': 'alice', 'groups': ['wheel']},
        'groups',
        {'skip_missing': False}
    ]
    terms3 = [
        {'name': 'alice', 'groups': ['wheel']},
        'groups',
        {'skip_missing': True}
    ]

    # Create a list of dictionaries
    values1 = lookup_plugin.run(terms1, None)[0]

    # Create empty list
    values2 = lookup_plugin.run(terms2, None)[0]

    # Create empty list

# Generated at 2022-06-23 12:14:37.101787
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.constants
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    dummy_loader = DummyLoader()
    dummy_inventory = DummyInventory()

    lookup_plugin = LookupModule()
    lookup_plugin._templar = dummy_loader._templar
    lookup_plugin._loader = dummy_loader
    lookup_plugin.set_options({})
    lookup_plugin._display.verbosity = 3

    test_context = PlayContext()
    test_context.CLIARGS = ansible.constants.CLIARGS
    test_context.vars = combine_vars(loader=dummy_loader, inventory=dummy_inventory, variables=dict(users_var=dummy_users, users=dummy_users))

   

# Generated at 2022-06-23 12:14:46.795898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # first test: check the expected structure of the lookup result
    # without any arguments
    lookup = LookupModule()
    result = lookup.run(
        terms=[
            [
                {
                    "key1": [
                        "item1-1",
                        "item1-2",
                        "item1-3",
                        ],
                    "key2": "value2",
                    },
                {
                    "key3": "value3",
                    "key4": ["item4-1", "item4-2", "item4-3"],
                    },
                ],
            "key4",
            ],
        variables={},
        )

# Generated at 2022-06-23 12:14:58.316594
# Unit test for constructor of class LookupModule
def test_LookupModule():

    def test(subelements_args, expected_results):
        result = LookupModule().run(subelements_args, None, None, None)
        assert result == expected_results, "subelements(%s) returned %s but was expected to return %s" % (subelements_args, result, expected_results)
        print("subelements(%s) returned %s" % (subelements_args, result))


# Generated at 2022-06-23 12:15:07.365324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    users = [
        {
            'name': 'alice',
            'authorized': [
                'publickey',
                'publickey2'
            ],
            'hosts': [
                'host1',
                'host2'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                'publickey'
            ],
            'hosts': [

            ]
        }
    ]

    variables = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 12:15:18.432241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that the run method of the LookupModule class returns good results for different inputs
    # input for the LookupModule run method
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    privs_1 = ['*.*:SELECT', 'DB1.*:ALL']
    privs_2 = ['*.*:SELECT', 'DB2.*:ALL']

# Generated at 2022-06-23 12:15:19.821730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ basic test of instantiating the class """
    l = LookupModule()
    l

# Generated at 2022-06-23 12:15:28.732550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_text
    lookup_module = LookupModule()
    class DummyVars:
        def get(self, name, default=None):
            return default
    vars = DummyVars()
    templar = LookupBase()._templar
    loader = LookupBase()._loader

# Generated at 2022-06-23 12:15:36.589270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookup_instance = LookupModule()
    # create an instance of variables, which will be used as the second parameter in run method

# Generated at 2022-06-23 12:15:47.814106
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Init lookup
    lookup = LookupModule()

    # Contruct mock input

# Generated at 2022-06-23 12:15:49.683043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelement = LookupModule()
    assert(subelement is not None)

# Generated at 2022-06-23 12:15:58.156954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_params = {
        '_templar': "templar",
        '_loader': "loader"
    }
    lookup_instance = LookupModule(**lookup_params)

    assert lookup_instance._templar == lookup_params['_templar']
    assert lookup_instance._loader == lookup_params['_loader']

    assert lookup_instance._templar != "not_templar"
    assert lookup_instance._loader != "not_loader"


# Generated at 2022-06-23 12:16:07.451624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModuleMock(LookupModule):
        def __init__(self, **kwargs):
            self.module_vars = kwargs['module_vars']
            super(LookupModuleMock, self).__init__(**kwargs)

        def _templar(self, **kwargs):
            return kwargs['value']

        def _loader(self, **kwargs):
            return kwargs['value']

    module_vars = {'skip_missing': 'yes'}
    lookup = LookupModuleMock(module_vars=module_vars)

    # check conversion of item to bool

# Generated at 2022-06-23 12:16:19.530720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_params = {
        'terms': [
            [
                {
                    u'authorized': [
                        u'~/.ssh/id_rsa_pub'
                    ],
                    u'name': u'alice'
                },
                {
                    u'authorized': [],
                    u'name': u'bob'
                }
            ],
            'authorized'
        ]
    }
    lookup_mod = LookupModule()
    result = lookup_mod.run(**lookup_params)

# Generated at 2022-06-23 12:16:25.791973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = DataLoader()
            self._templar = VariableManager()


# Generated at 2022-06-23 12:16:36.596422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """This is a basic automated unit test class, that can be run in pytest.
    Testcase is using pytest, ansible, and ansible's testinfra."""

    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    users = [
        {"name" : "alice", "authorized": ["/tmp/alice/onekey.pub","/tmp/alice/twokey.pub"]},
        {"name" : "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}
    ]

    lookup_module = LookupModule()

# Generated at 2022-06-23 12:16:39.057298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange and act
    lookup = LookupModule()
    result = lookup.run([[{"skipped": True}]], {"skipped": False})
    # assert
    assert result == []


# Generated at 2022-06-23 12:16:48.772656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dicts
    class Options(object):
        def __init__(self):
            self.var1 = 'value1'
            self.var2 = 'value2'
    lookup_params = dict(
        _terms=['users', 'authorized'],
        var1='value1',
        var2='value2'
    )

# Generated at 2022-06-23 12:16:59.455265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines


# Generated at 2022-06-23 12:17:09.873950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text

    module = LookupModule()
    assert isinstance(module, LookupModule)

    # prepare test data
    master_list = [
        {'key': '1', 'val1': [{'subkey': '3', 'subval': ['a', 'b', 'c']}]},
        {'key': '2', 'val1': [{'subkey': '2', 'subval': ['d', 'e']}]},
        {'key': '3', 'val1': [{'subkey': '1', 'subval': ['f', 'g']}]},
    ]
    terms = [master_list, 'val1.subval', {'skip_missing': False}]

    # run test

# Generated at 2022-06-23 12:17:19.874064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelement = LookupModule()
    # run test for one element
    variable = [{'a': 'b'}, {'c': 'd'}]
    result_one_element = [{'a': 'b', 'c': 'd'}]
    assert subelement.run([variable, 'c'], None) == result_one_element

    # run test for two elements
    variable = [{'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'e'}]
    result_two_elements = [{'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'e'}]
    assert subelement.run([variable, 'c'], None) == result_two_elements

    # run test for two elements with different names

# Generated at 2022-06-23 12:17:27.320746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import ansible.parsing.vault
    from ansible.parsing.dataloader import DataLoader
    import ansible.plugins.lookup.subelements

    # build some dummy variables
    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        }
    ]

# Generated at 2022-06-23 12:17:28.648535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test equality
    l = LookupModule()
    assert l
    return True

# Generated at 2022-06-23 12:17:39.880438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils import context_objects as co

    # simple test
    assert LookupModule.run(
        [
            ['a', 'b'],
            "key1.key2"
        ],
        co.KeyContent(
            task_vars={
                'a': {
                    'key1': {
                        'key2': 'value'
                    }
                },
                'b': {
                    'key1': {
                        'key2': 'value'
                    }
                }
            }
        )
    ) == ['value', 'value']

    # nested dicts

# Generated at 2022-06-23 12:17:42.127566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

    # constructors
    assert isinstance(mod, LookupBase)

    # methods
    assert hasattr(mod, 'run')

# Generated at 2022-06-23 12:17:43.817628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=unused-variable
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:17:45.616966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-23 12:17:53.418829
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    terms = {
        'users': [
            {'name': 'smve', 'uid': '1000', 'gid': '1000', 'groups': {'group': 'wheel'}, 'shell': '/bin/bash', 'ensure': 'present'}
        ],
        'groups': {'skip_missing': True}
    }
    vars = {}
    l._loader, l._templar = _getMockLoader()
    l.run(terms, vars)


# Generated at 2022-06-23 12:17:59.419213
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import pytest

    args = [
        ['users', 'authorized'],
        ['users', 'groups', {'skip_missing': True}],
        [{'users': 'users'}, 'authorized'],
    ]

    with pytest.raises(AnsibleError):
        LookupModule('', '', '', '', '', {}).run([], [])

    for arg in args:
        with pytest.raises(AnsibleError):
            LookupModule('', '', '', '', '', {}).run(arg, [])

# Generated at 2022-06-23 12:18:10.320935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = [
        {'skipped': False, 'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
         'groups': ['wheel'], 'mysql': {'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL'],
                                       'hosts': ['%', '127.0.0.1', '::1', 'localhost']}},
        'authorized',
        {}
    ]
    variables = {}

# Generated at 2022-06-23 12:18:22.357653
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:18:31.215236
# Unit test for constructor of class LookupModule
def test_LookupModule(): 
    lu = LookupModule() 
    terms = [
        [
            { 'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'] },
            { 'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'] }
        ],
        'authorized'
    ]

    ret = lu.run(terms, {})

# Generated at 2022-06-23 12:18:42.539630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _loader = 'dummy'
    _templar = 'dummy'
    lookup_options = LookupModule(_loader, _templar)
    
    test_terms1 = [
        {
            "foo": 
                {
                    "bar":
                        [
                            "baz",
                            "biz"
                        ]
                },
            "foo2": 
                {
                    "bar":
                        [
                            "baz",
                            "biz"
                        ]
                }
            },
        "foo.bar",
        {
            'skip_missing': True
        }
    ]
    actual = lookup_options.run(test_terms1, {})


# Generated at 2022-06-23 12:18:54.006511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import json
    import tempfile

    # create a temporary ansible.cfg file that points to the test_plugins directory
    plugin_dir = os.path.join(os.path.dirname(__file__), 'test_plugins')
    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.write("[defaults]\n")
        f.write("lookup_plugins=%s\n" % plugin_dir)
        f.flush()

        loader = DataLoader()
        templar = Templar(loader=loader)

        # create a temporary test_data file that contains the data and the subkey

# Generated at 2022-06-23 12:19:02.956757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()

    # test some invalid arguments
    try:
        mylookup.run([], {})
        assert False
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "
    try:
        mylookup.run([1, 2], {})
        assert False
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

# Generated at 2022-06-23 12:19:04.018839
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({}, None).run([], {})

# Generated at 2022-06-23 12:19:06.488563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Test LookupModule constructor """
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:19:09.917909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    if not lookup_module:
        raise AssertionError("LookupModule instance couldn't be created")


# Generated at 2022-06-23 12:19:12.734708
# Unit test for constructor of class LookupModule
def test_LookupModule():
  class LookupModule(object):
    def __init__(self, basedir=None, **kwargs):
        self.basedir = basedir
  assert LookupModule(basedir='/var/lib/awx')

# Generated at 2022-06-23 12:19:25.099997
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:33.720176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ unit test for LookupModule.run """
    lookup = LookupModule()

    def test_tuple(terms, expected, skip_missing=False):
        """ test tuple """
        assert lookup.run(terms, None, skip_missing=skip_missing) == expected

    def test_error(terms, errstring):
        """ test tuple """
        try:
            lookup.run(terms, None)
        except AnsibleError as exc:
            assert str(exc) == errstring
        else:
            raise AssertionError("AnsibleError not raised")


# Generated at 2022-06-23 12:19:34.276890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:19:45.318377
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:19:47.090692
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run'), 'class LookupModule is lacking the run method'

# Generated at 2022-06-23 12:19:48.767412
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm


# Generated at 2022-06-23 12:19:58.554890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.loader import lookup_loader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager()

    # create a play

# Generated at 2022-06-23 12:19:59.664998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm

# Generated at 2022-06-23 12:20:00.301821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:20:02.733907
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelems = LookupModule()
    assert isinstance(subelems, LookupModule)

# Generated at 2022-06-23 12:20:04.764277
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Construct class object
    lookup_module = LookupModule()

    # Assert that terms is list
    assert isinstance(lookup_module._terms, list)

    # Assert that terms is empty
    assert lookup_module._terms == []

# Generated at 2022-06-23 12:20:14.806771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # helper function
    def _assert_msg(error, msg):
        return error.args[0].endswith(msg)

    # setup