

# Generated at 2022-06-23 12:10:09.328617
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert '_terms' in l.run.__code__.co_varnames

# Generated at 2022-06-23 12:10:10.693041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None


# Generated at 2022-06-23 12:10:21.497223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._templar.template = lambda x: x
    lookup_module._loader.get_basedir = lambda x: x

# Generated at 2022-06-23 12:10:30.953050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up
    lookup = LookupModule()
    lookup._templar = {}
    lookup._loader = {}

    assert lookup.run([
        [{'foo': {'bar': {'baz': ['Qux']}}}],
        'foo.bar.baz'
        ], {}) == [({'foo': {'bar': {'baz': ['Qux']}}}, 'Qux')]

    assert lookup.run([
        [{'foo': {'bar': {'baz': ['Qux']}}}],
        'foo.bar.bax'
        ], {}) == []


# Generated at 2022-06-23 12:10:39.861137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from collections import OrderedDict
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import sys
    if sys.version_info < (2, 7):
        pytest.skip("The unittest module was added in 2.7")
    import unittest

    class TestLookupBase(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            pass

    class TestTemplar(Templar):
        def __init__(self):
            super(TestTemplar, self).__init__(variables=dict())

    lookup_module = TestLookupBase()
    templar = TestTempl

# Generated at 2022-06-23 12:10:41.397418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert subelements is not None

# Generated at 2022-06-23 12:10:48.146874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock


    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.loader_mock = patch('ansible.plugins.lookup.subelements.LookupBase.load_template_file').start()
            self.loader_mock.return_value = Mock(
                __dict__={
                    'template': dict(
                        lookup_config=[],
                        jinja2_native=True),
                })
            self.vars_mock = patch('ansible.plugins.lookup.subelements.LookupBase._templar').start()
            self.vars_mock.__dict__ = dict(
                basedir='.')

# Generated at 2022-06-23 12:10:58.402065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    lookup_module = LookupModule()

    if hasattr(lookup_module, 'set_options'):
        # Ansible 2.3 onwards
        lookup_module.set_options({'var': 'myvar'})
    else:
        # Ansible 2.2 and earlier
        lookup_module.set_context({'var': 'myvar'})

    # test missing subelement
    with pytest.raises(AnsibleError):
        lookup_module.run([['a', 'b'], 'mysubelement'])

    # test missing subelement, with skip_missing flag

# Generated at 2022-06-23 12:11:07.766690
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:11:17.943204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.vars import VariableManager
    from copy import deepcopy
    import ansible

    dataloader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 12:11:28.449798
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    class TestLookupModuleException(Exception):
        pass


# Generated at 2022-06-23 12:11:29.625730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    print(x)

# Generated at 2022-06-23 12:11:32.164138
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-23 12:11:34.097626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin._templar = None
    assert lookup_plugin

# Generated at 2022-06-23 12:11:41.644501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar


# Generated at 2022-06-23 12:11:51.497715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [
            {
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub',
                    '/tmp/bob/id_rsa.pub'
                ],
                'name': 'alice'
            },
            {
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ],
                'name': 'bob'
            }
        ],
        'authorized'
    ]

    ret = LookupModule().run(
        terms=terms,
        variables={}
    )


# Generated at 2022-06-23 12:12:02.155571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()


# Generated at 2022-06-23 12:12:11.282508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    # http://stackoverflow.com/questions/241327/python-snippet-to-remove-c-and-c-comments
    import re
    comment_remover = re.compile(r'^\s*#.*$', re.MULTILINE)
    example = comment_remover.sub('', EXAMPLES)

# Generated at 2022-06-23 12:12:11.790576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-23 12:12:15.570292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import listvalues
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-23 12:12:25.747522
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing only possible with py.test
    import pytest
    import ansible.utils.unsafe_proxy as unsafe_proxy
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    from ansible.plugins.lookup.subelements import LookupModule

    # create a testable module
    module = AnsibleModule(argument_spec={})

    # create LookupModule object
    lookup = LookupModule()

    # Testing only with py.test
    from _pytest.runner import runtestprotocol

    ################
    #    TESTS     #
    ################

    # test

# Generated at 2022-06-23 12:12:38.095394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    lu = LookupModule()

    def test_subelements():
        """ Test for method run of class SubElements """

        # TODO: fill up test cases with more exhaustive test

# Generated at 2022-06-23 12:12:42.193477
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ansible = AnsibleModule(
        argument_spec={'terms': {'required': True, 'type': 'list'}},
        supports_check_mode=True)

    if __name__ == '__main__':
        ansible.exit_json(changed=False)

# Generated at 2022-06-23 12:12:42.849367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return

# Generated at 2022-06-23 12:12:44.890261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ('list', 'key')
    instance = LookupModule()
    instance.run(terms)

# Generated at 2022-06-23 12:12:52.325434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.compat.tests import unittest
    else:
        import unittest
    # create test class
    class TestLookupModule(unittest.TestCase):
        def test_run(self):
            # create instance of LookupModule to test
            lm = LookupModule()

            # array of tests
            test_cases = [
            ]

            def run_test(test):
                # dict of kwargs that get passed to run()
                kw = {}
                # run test and check result
                # TODO: add exceptions to catch incorrect usage
                res = lm.run(test['terms'], kwargs=kw)

# Generated at 2022-06-23 12:13:04.689885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule_run():
        def test_with_list_of_dicts(self):
            from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
            from ansible.plugins.loader import lookup_loader
            from ansible.template import Templar

            lookup_class = lookup_loader.get('subelements')
            templar = Templar(loader=None)
            # test data - a list of dicts

# Generated at 2022-06-23 12:13:05.349173
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:13:07.940472
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    terms = [[{'a':1}], 'a']
    variables = {}
    l.run(terms, variables)

# Generated at 2022-06-23 12:13:16.272919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    import pytest

    def _assert_error_message(msg, args, kwargs):
        with pytest.raises(AnsibleError) as error:
            LookupModule(*args, **kwargs)
        assert to_text(error.value) == msg

    if PY3:
        _assert_error_message(
            """subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey
            """,
            [['test_list']], {})
        d = {'skipped': True}

# Generated at 2022-06-23 12:13:17.882954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write a unit test with mocker
    pass

# Generated at 2022-06-23 12:13:18.948693
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule({}, {}, [])

# Generated at 2022-06-23 12:13:20.582071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:13:28.696427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import yaml

    y = yaml.safe_load

# Generated at 2022-06-23 12:13:31.164909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = [{'key': 'value'}, 'key']
    result = [{'key': 'value'}, 'value']
    assert lm.run(terms, {}) == result

# Generated at 2022-06-23 12:13:40.736758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.module_utils.six sometimes mis-parses the test files.
    # An exception is thrown that stops the test. Run this before
    # any Ansible module is imported.
    import ansible.module_utils.six
    ansible.module_utils.six.assertCountEqual = ansible.module_utils.six.assertItemsEqual

    # Prepare test data

# Generated at 2022-06-23 12:13:42.674547
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({'key': 'value'}, {})



# Generated at 2022-06-23 12:13:52.906190
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple
    from ansible.errors import AnsibleError
    
    UnitTest = namedtuple('UnitTest', 'terms, variables, result')


# Generated at 2022-06-23 12:13:56.153200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:14:05.166407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Use a list of dictionaries as input list
    lookup_list = [
        {
            'linux': {
                'master': ["user", "group", "other"],
                'slave': ["user", "group", "other"]
            },
            'windows': {
                'master': ["user", "group"],
                'slave': ["user", "group"]
            }
        },
        {
            'linux': {
                'master': ["user", "group", "other"],
                'slave': ["user", "group", "other"]
            },
            'windows': {
                'master': ["user", "group"],
                'slave': ["user", "group"]
            }
        }
    ]

    # Construct a method instance of class LookupModule and call run
    lookup_module = LookupModule()
    ret = lookup

# Generated at 2022-06-23 12:14:16.034544
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock the ansible.plugins.lookup.lookup_loader.get lookup plugin
    import ansible.plugins.lookup.lookup_loader
    from ansible.plugins.loader import lookup_loader

    original_get = lookup_loader.get

    def mock_get(name, *args, **kwargs):
        if name == 'subelements':
            return LookupModule()
        else:
            return original_get(name)

    lookup_loader.get = mock_get
    ansible.plugins.lookup.lookup_loader.get = mock_get

    from ansible.plugins.lookup import LookupBase
    lookup_base = LookupBase()
    terms = list()

    # Not enough arguments
    terms = [None, None, None]
    assert lookup_base.run(terms, dict()) is None



# Generated at 2022-06-23 12:14:28.690059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: the following example is based on a real-life use-case
    o_LookupModule = LookupModule()

# Generated at 2022-06-23 12:14:29.824109
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # LookupModule(name='', *args, **kwargs)
    LookupModule()

# Generated at 2022-06-23 12:14:36.707059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    test_subject = LookupModule()

    # test simple case: one element with one element sublist
    lookup_list = [{'foo': 'bar', 'users': ['first-user']}]
    assert test_subject._flatten(lookup_list, 'users') == [('first-user',)]

    # test skip_missing flag
    lookup_list = [{'foo': 'bar', 'users': ['first-user']},
                   {'foo': 'bar'}]
    assert test_subject._flatten(lookup_list, 'users', skip_missing=True) == [('first-user',)]

    # test nested subelements
    lookup_list = [{'foo': 'bar', 'users': {'mysql': {'hosts': ['db1']}}}]
    assert test_subject

# Generated at 2022-06-23 12:14:46.677557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test environment
    import sys
    sys.modules['__main__'] = LookupModule()
    sys.modules['ansible'] = sys.modules['__main__'].__dict__
    import ansible.utils
    ansible.utils.listify_lookup_plugin_terms = lambda x, y, z: x.copy()
    import ansible.plugins.lookup.subelements
    sys.modules['ansible.plugins.lookup'] = sys.modules['ansible'].__dict__
    sys.modules['ansible.plugins.lookup.subelements'] = ansible.plugins.lookup.subelements
    import ansible.plugins.lookup.subelements as module_name
    # setup test data

# Generated at 2022-06-23 12:14:57.794191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    if PY3:
        unicode_test = "str"
    else:
        unicode_test = "unicode"

    vault_test = AnsibleVaultEncryptedUnicode.from_plaintext("myvaultpassword",
                                                             "AES256",
                                                             u"vault data",
                                                             "vault1")
    vault_test.start_line = 1
    vault_test.end_line = 1


# Generated at 2022-06-23 12:15:06.984992
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check with two terms - first dict, second dict
    terms = [{'c': 3, 'd': 4, 'e': {'f': 5, 'g': 6}}, 'e']
    ret = LookupModule(terms, dict(g=7, h=8)).run(terms, dict(g=7, h=8))
    assert ret == [(dict(c=3, d=4, e=dict(f=5, g=6)), dict(f=5, g=6))]

    # Check with two terms - first list, second dict
    terms = [[dict(c=3, d=4), dict(e=5, f=6)], 'd']
    ret = LookupModule(terms, dict(g=7, h=8)).run(terms, dict(g=7, h=8))
    assert ret

# Generated at 2022-06-23 12:15:08.832553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing constructor.. ', end='')
    lookup = LookupModule()
    print('OK')


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:15:19.510366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an instance of the LookupModule
    lookup_module = LookupModule()

    # run the run function to test error handling for inputs
    class DummyClass(object):
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-23 12:15:25.962574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create some test objects
    import types
    import sys

    tmp = types.ModuleType("tmp")
    test_module_path = '/tmp/ansible_test_module_test_module'

    tmp.test_module_path, tmp.test_module_name = os.path.split(test_module_path)
    sys.modules['test_module'] = tmp

    from ansible.plugins.lookup import fake_loader
    lookup_plugin = LookupModule(loader=fake_loader())

# Generated at 2022-06-23 12:15:28.224477
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule), \
        'Object is not an instance of LookupModule'

# Generated at 2022-06-23 12:15:36.269005
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock variables
    terms = ['users', 'groups']
    variables = {'users': [{'name': 'alice', 'groups': []}, {'name': 'bob', 'groups': ['wheel']}]}
    kwargs = {}
    expected = [({'name': 'alice', 'groups': []}, []), ({'name': 'bob', 'groups': ['wheel']}, ['wheel'])]

    # Mock lookups plugins
    lookups_plugins = {
        'subelements': LookupModule
    }

    # Execute the method
    ret = lookups_plugins.get('subelements').run(terms, variables, **kwargs)

    # Validate the results
    assert ret == expected

    # Mock variables
    terms = ['users', 'groups', {'skip_missing': True}]
    variables

# Generated at 2022-06-23 12:15:39.160440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert not hasattr(LookupBase, 'run')

# Generated at 2022-06-23 12:15:40.267975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 12:15:49.607738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()


# Generated at 2022-06-23 12:15:52.976254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of LookupModule
    lm = LookupModule()
    # Test the return value of run.
    assert lm.run([], {}) == []


# Generated at 2022-06-23 12:15:53.719083
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:15:55.889038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1]
    l = LookupModule()
    l.run(terms, None)

# Generated at 2022-06-23 12:16:05.607016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit tests for method run of class LookupModule
    """
    import os
    MODULE_PATH = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-23 12:16:06.618960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 12:16:18.698358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

    # test 1, correct input
    terms = [
        [{
            'name': 'alice',
            'mysql': {
                'password': 'mysql-password',
                'hosts': ['127.0.0.1', 'localhost']
            }
        }, {
            'name': 'bob',
            'mysql': {
                'password': 'other-mysql-password',
                'hosts': ['db1']
            }
        }],
        'mysql.hosts'
    ]

# Generated at 2022-06-23 12:16:28.387587
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:16:39.021313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    def dict2bytes(d, **kwargs):
        return to_bytes(json.dumps(d, **kwargs))

    import json
    import os
    import pytest

    test_vault_password = '$ecretpassword'

# Generated at 2022-06-23 12:16:40.163257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:16:42.558461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # __init__(self, loader=None, templar=None, **kwargs)
    assert hasattr(LookupModule, '__init__')


# Generated at 2022-06-23 12:16:53.582330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.parsing.dataloader as dl
    import ansible.vars as ans_vars
    import ansible.template as templating
    import ansible.inventory as inventory

    loader = dl.DataLoader()
    variable_manager = ans_vars.VariableManager()
    inventory = inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list=['dummy'])
    variable_manager.set_inventory(inventory)
    templar = templating.Templar(loader=loader, variables=variable_manager.get_vars(None, True))
    lookup_plugin = LookupModule(loader=loader, templar=templar)

    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:17:02.081281
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #
    # CASE 1: both inputs are correct, 3rd element is not set
    #
    terms = [
        {
            'item0': {
                'subkey': [
                    'el1a', 'el1b', 'el1c'
                ]
            }
        },
        'subkey'
    ]
    results = [(
        {'subkey': ['el1a', 'el1b', 'el1c']},
        'el1a'), (
        {'subkey': ['el1a', 'el1b', 'el1c']},
        'el1b'), (
        {'subkey': ['el1a', 'el1b', 'el1c']},
        'el1c')]
    error = None


# Generated at 2022-06-23 12:17:03.376860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:17:12.428150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mymodule = LookupModule()

    def foo( vars, terms, **kwargs):
        return mymodule.run(terms, vars, **kwargs)

    class MakeAttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(MakeAttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self

    # test with list and key as string

# Generated at 2022-06-23 12:17:15.121303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("TEST LookupModule()")
    # test constructor
    assert LookupModule()
    print("OK")


# Generated at 2022-06-23 12:17:26.645252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE

    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup.subelements import LookupModule

    # initiate the object
    lookup_module_object = LookupModule()

    result = lookup_module_object.run(
        [
            [{'name': 'Alice', 'groups': ['wheel', 'audio']}],
            'groups'
        ],
        None
    )

# Generated at 2022-06-23 12:17:34.142639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = Host(name="test")
    variable_manager = VariableManager()
    loader = DataLoader()
    lookup_module = LookupModule(
        loader=loader,
        variable_manager=variable_manager,
        host=host
    )

    # test normal, use first term as list
    mock = json.loads("""
    [
        { "name": "Alice" },
        { "name": "Bob" },
        { "name": "Cindy" }
    ]
    """)
    assert lookup_module.run([mock, 'name'], dict()) == [('Alice',), ('Bob',), ('Cindy',)]



# Generated at 2022-06-23 12:17:36.441741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert type(lookup_plugin) == LookupModule


# Generated at 2022-06-23 12:17:37.522238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-23 12:17:48.715934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from importlib import import_module
    import os
    import sys
    import unittest

    class LookupMock(object):
        def get_basedir(self, terms):
            return '.'
    lookup_mock = LookupMock()
    lookupmock_path_list = os.path.dirname(os.path.realpath(__file__)).split(os.path.sep)
    lookupmock_path_list.append('lookup_plugins')
    sys.path = [os.path.sep.join(lookupmock_path_list)] + sys.path

    class Tests(unittest.TestCase):

        def setUp(self):
            self.lookup = import_module('subelements')


# Generated at 2022-06-23 12:17:59.032118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for run method of class LookupModule
    '''
    # Dict with dicts - dict as input
    #python 3
    #TODO: fix this, should be {'skipped': False, 'pamthing': {'skipped': False, 'authorized_keys': [1, 2, 3], 'id': 1}}, {'skipped': False, 'pamthing': {'skipped': False, 'authorized_keys': [1, 2, 3], 'id': 2}}
    tester = {'skipped': False, 'pamthing': {'skipped': False, 'authorized_keys': [], 'id': 1}}, {'skipped': False, 'pamthing': {'skipped': False, 'authorized_keys': [], 'id': 2}}
    #TODO: fix this,

# Generated at 2022-06-23 12:18:10.040693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with improper values
    l = LookupModule()
    l.set_runner(DummyRunner())
    l.set_loader({})
    l.vars = {}

    # Test with empty list
    result = l.run([[], 'item'], None)
    assert result == [], result

    result = l.run([[], 'item'], None, skip_missing=True)
    assert result == [], result

    # Test with list and missing key
    result = l.run([[{'item': 'value1'}], 'item2'], None)
    assert result[0] == ('item2', 'value1'), result

    result = l.run([[{'item': 'value1'}, {'item': 'value2'}], 'item2'], None)

# Generated at 2022-06-23 12:18:22.047810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultSecret, VaultAes256
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    users = AnsibleMapping()
    users[u'alice'] = AnsibleMapping()
    users[u'alice'][u'authorized'] = [u'/tmp/alice/onekey.pub', u'/tmp/alice/twokey.pub']
    users[u'alice'][u'mysql'] = AnsibleMapping()

# Generated at 2022-06-23 12:18:30.706733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass
#                   ^^^^ insert your test code here ^^^^
#
# Unit test operation guide
#   1. run test: ansible-test lookup subelements --python 3.x
#   2. edit this file, insert your test code at the marked spot
#   3. re-run command in step 1
#   4. if all passed, submit a PR
#
# General debugging tips:
#   1. enable trace by setting environment variable ANSIBLE_TRACE=1
#   2. for Python trace, set environment variable ANSIBLE_DEBUG=1
#   3. you can add and remove debug print() calls to check values of
#      variables in your code
#   4. add @trace which is the Python decorator version of adding
#      a print() call to a function (see example)
#

# Generated at 2022-06-23 12:18:32.133047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:18:35.612184
# Unit test for constructor of class LookupModule
def test_LookupModule():
    llookup = LookupModule()
    print(llookup.run([1, 2, 3], {}))

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:18:45.548671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    # Example using a list
    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        },
    ]

    ret = module.run([
        users,
        'authorized',
        {'skip_missing': True},
        ], dict(), loader=None, templar=None, **{})

    assert isinstance(ret, list)
    assert len(ret) == 3

# Generated at 2022-06-23 12:18:56.933702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test of method 'run' of class LookupModule
    # pylint: disable=too-many-arguments
    # pylint: disable=no-self-use
    # pylint: disable=invalid-name
    # pylint: disable=too-many-locals

    # test setup
    from ansible.plugins.lookup import LookupBase

    def _nothing(self, terms, variables, **kwargs):
        return []

    lookup = LookupBase()
    lookup.set_loader = _nothing
    lookup.set_environment = _nothing
    lookup.get_basedir = _nothing

    # test run
    lookup.run([], {})
    lookup.run([], {}, skip_missing=True)
    lookup.run([], {}, skip_missing=False)

    # test data


# Generated at 2022-06-23 12:19:04.091629
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create test data
    test_terms_list = dict(test1=1, test2=2)
    test_terms_tuple = dict(test3=3, test4=4)
    test_terms_single = dict(test5=5)

    # Create test class
    lu = LookupModule()

    # Prepare a test value
    result = lu.run([[test_terms_list, test_terms_tuple, test_terms_single]], None)

    # Make sure result is a list of tuples
    assert isinstance(result, list), "result is not a list"
    assert all([isinstance(term, tuple) for term in result]), "result is not a list of tuples"

    # Make sure each tuple contains two values

# Generated at 2022-06-23 12:19:14.411006
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # no terms
    terms = []
    lookup._templar = lambda x: x
    lookup._loader = lambda x: x
    assert False == lookup._validate_terms(terms)

    # correct terms
    terms = [{"a": "b"}, "c"]
    lookup._templar = lambda x: x
    lookup._loader = lambda x: x
    assert True == lookup._validate_terms(terms)

    # correct terms 2
    terms = [["a", "b"], "c"]
    lookup._templar = lambda x: x
    lookup._loader = lambda x: x
    assert True == lookup._validate_terms(terms)

    # correct terms 3
    terms = [["a", "b"], {"c":"d"}, "c"]

# Generated at 2022-06-23 12:19:26.926708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the test is constructed so that only one instance of LookupModule will be created and run
    # this is due to the singleton design of the call to constructor LookupBase.__new__
    # it is expected to change in the future with a better implementation of the
    # lookup plugins

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create options
    # see the whole list in class Options at lib/

# Generated at 2022-06-23 12:19:36.891181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:19:47.673983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test to deliver a list of dicts with a given subelements key
    users = [
        {'name':'alice', 'authorized': ['/tmp/onekey.pub', '/tmp/twokey.pub']},
        {'name':'bob', 'authorized': ['/tmp/id_rsa.pub', '/tmp/id_rsa2.pub']}
    ]
    terms = [users, 'authorized']
    l = LookupModule()
    items = l.run(terms, [])

# Generated at 2022-06-23 12:19:57.913056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[{'a': {'b': [1,2,3]}}],'a.b']
    # initialize LookupModule instance
    lm = LookupModule(None, terms, None, None, None)
    assert len(lm.run(terms,None)) == 3
    assert len(lm.run(terms+[[{'skip_missing':True}]], None)) == 3
    assert len(lm.run([{'a': {'c': [1,2,3]}}]+terms[1:],[])[0][0]['b']) == 3
    # test skip_missing
    terms = [[{'a': {'b': [1,2,3]}}],'a.c']
    assert len(lm.run(terms, None)) == 0


# Generated at 2022-06-23 12:20:07.975828
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # first term should be a list (or dict), second a string holding the subkey
    # subelements = terms[1].split(".")
    # elementlist = terms[0]  # (list or dict)
    # subkey = terms[2]  # subkey to extract

    # Tests for terms[0]
    elementlist1 = [{'name': 'alice',
                     'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
                    {'name': 'bob',
                     'bio': 'asdfadsf',
                     'authorized': ['/tmp/bob/id_rsa.pub']}]