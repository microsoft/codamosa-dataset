

# Generated at 2022-06-23 12:10:16.634986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Create lookup instance
    #
    lookup = LookupModule()
    #
    # Create data structure
    #
    data = {
      "data": {
        "keyA": [
          "A1",
          "A2"
        ],
        "keyB": [
          "B1",
          "B2"
        ],
        "keyC": [
          "C1",
          "C2"
        ]
      }
    }
    #
    # test run
    #
    result = lookup.run([data, "data.keyA"], [], loader=None, templar=None, variables={})

# Generated at 2022-06-23 12:10:26.918542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.vault import VaultLib

    def _get_loader():
        cwd = os.path.dirname(os.path.realpath(__file__))
        secrets_dir = os.path.join(cwd, 'secrets')
        vault_password_file = os.path.join(secrets_dir, 'vault.txt')
        return lookup_loader.get(None, loader=None, templar=None, vault_password_files=[vault_password_file])


# Generated at 2022-06-23 12:10:28.013762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:10:29.052970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert 'subelements' == module.name

# Generated at 2022-06-23 12:10:31.124067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule() # Note that this instantiates a LookupModule without any parameters.
    assert isinstance(lookup_module, LookupModule) # Note that this instantiates a LookupModule without any parameters.

# Generated at 2022-06-23 12:10:37.201308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # subelements LookupModule
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # the dictionary

# Generated at 2022-06-23 12:10:38.167731
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:10:46.645265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    def _dummy_templar(x):
        return x

    class _DummyLoader(object):
        def __init__(self):
            self._inventory = _DummyInventory()

    class _DummyInventory(object):
        pass

    x = LookupModule(
        loader=_DummyLoader(),
        basedir=None,
        runner=None,
        vault_password=None,
        paths=None,
        templar=_dummy_templar,
    )


# Generated at 2022-06-23 12:10:57.408324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    my_vars = VariableManager()
    my_vars.set_host_variable(Host(name='127.0.0.1'), 'ansible_python_interpreter', '/usr/bin/python')

    # create lookup object to test
    lookup_plugin = LookupModule()

    # get the data to test

# Generated at 2022-06-23 12:10:58.801514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == type(LookupModule())

# Generated at 2022-06-23 12:11:07.942386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    >>> users= [{'name':'alice','authorized':['/tmp/alice/onekey.pub'],'groups':['wheel']},{'name':'bob','authorized':['/tmp/bob/id_rsa.pub']}]
    >>> terms = [users,'authorized']
    >>> l = LookupModule()
    >>> a = l.run(terms, variables={})
    >>> a
    [({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub'], 'groups': ['wheel']}, ['/tmp/alice/onekey.pub']), ({'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}, ['/tmp/bob/id_rsa.pub'])]
    '''
    pass




# Generated at 2022-06-23 12:11:18.089985
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    # mocking the class with a fake ansible templar
    class FakeTemplar(object):
        def __init__(self, data):
            self._data = data

        def template(self, v, **kwargs):
            return self._data.get(v)

    class FakeLoader(object):
        def __init__(self, data):
            self._data = data

        def get_basedir(self, v):
            return self._data.get(v)

    # testing the class with the fake ansible templar
    class TestLookupModule(LookupModule):
        def __init__(self, basedir=None, **kwargs):
            self.templar = FakeTemplar(kwargs)
            self.loader = FakeLoader(kwargs)


# Generated at 2022-06-23 12:11:28.526229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {
                "name": "alice",
                "mysql": {
                    "password": "mysql-password",
                    "hosts": [
                        "127.0.0.1",
                        "::1"
                    ]
                }
            },
            {
                "name": "bob",
                "mysql": {
                    "password": "other-mysql-password",
                    "hosts": [
                        "db1"
                    ]
                }
            }
        ],
        "mysql.hosts",
        {
            "skip_missing": True
        }
    ]
    ret = LookupModule().run(terms, {})
    assert isinstance(ret, list)
    assert 2 == len(ret)

# Generated at 2022-06-23 12:11:39.630371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test run method of LookupModule class"""
    # instantiate a LookupModule

# Generated at 2022-06-23 12:11:50.258808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        connection = 'local'

    class Terms(object):
        name = 'test'

    class Runner(object):
        options = Options()
        basedir = '.'
        get_basedir = lambda x: None
        runner_config = dict()
        command_name = 'noop'
        module_vars = dict()
        templar = None
        module_args = None
        get_vars = lambda x: None
        set_vars = lambda *x: None
        inject = dict(vars=dict())

    class Injector(object):
        def __init__(self, runner):
            self.runner = runner
        def get_module_args(self, module_name, post_validate=True):
            return dict()

# Generated at 2022-06-23 12:11:53.111934
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == "__main__":
    test_LookupModule()

# Generated at 2022-06-23 12:12:02.226663
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:12:11.424639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

# Generated at 2022-06-23 12:12:22.519029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    args = dict(
        _terms=["{{users}}", "authorized"],
        basedir=".",
    )

    module = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='path'),
        ),
        supports_check_mode=True
    )

    module.params = args

    users = [
        {
            "name": "alice",
            "authorized": [
                "/tmp/alice/onekey.pub",
                "/tmp/alice/twokey.pub",
            ]
        },
        {
            "name": "bob",
            "authorized": [
                "/tmp/bob/id_rsa.pub",
            ]
        },
    ]

   

# Generated at 2022-06-23 12:12:35.030087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_subelements = LookupModule()

    # test normal case
    users = [{'name':'alice', 'mysql': {'password':'mysql-password', 'hosts':['%', '127.0.0.1', '::1', 'localhost'], 'privs':['*.*:SELECT', 'DB1.*:ALL']}, 'groups':['wheel']}]
    assert lookup_subelements.run([users, 'mysql.hosts', None], None) == [('alice', '%'), ('alice', '127.0.0.1'), ('alice', '::1'), ('alice', 'localhost')]

    # test case where some of the items are skipped

# Generated at 2022-06-23 12:12:42.288425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # input data

# Generated at 2022-06-23 12:12:45.257801
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    # No exception should be raised
    test_lookup_mod = lookup_mod


test_lookup_mod = None

# Generated at 2022-06-23 12:12:56.647661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = {
        'users': [
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            },
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            }
        ]
    }
    lookup_module = LookupModule()
    subelements_result = [('bob', '/tmp/bob/id_rsa.pub'), ('alice', '/tmp/alice/onekey.pub'), ('alice', '/tmp/alice/twokey.pub')]
    assert lookup_module.run([subelements, "users.authorized"], None) == sube

# Generated at 2022-06-23 12:13:08.545359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization of the class LookupModule
    lu = LookupModule()

    # Initialization of the attributes of class LookupBase
    class TestLookupBase:
        def __init__(self):
            self.variable_manager = 'variable_manager'
            self.loader = 'loader'
            self.templar = 'templar'
            self.basedir = 'basedir'
            self.current_env = 'current_env'
            self.run_once = 'run_once'

    tlb = TestLookupBase()
    lu._plugin_name = tlb
    lu._templar = tlb
    lu._loader = tlb
    lu._basedir = tlb
    lu._current_env = tlb
    lu._run_once = tlb

    # Initialization

# Generated at 2022-06-23 12:13:16.610993
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:27.334273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import unittest

    def subelement_basic_test(self):
        # basic test
        lm = LookupModule()
        subel = lm.run([[{'x': [1, 2, 3]}, {'x': [4, 5, 6]}, {'x': [7, 8, 9]}], 'x'], [])
        self.assertEqual(subel, [(subel[0][0], 1), (subel[0][0], 2), (subel[0][0], 3), (subel[1][0], 4), (subel[1][0], 5),
                                 (subel[1][0], 6), (subel[2][0], 7), (subel[2][0], 8), (subel[2][0], 9)])


# Generated at 2022-06-23 12:13:36.079741
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    import pytest
    import subelements_test_data

    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None

    # first term should be a dict or list, second a string holding the subkey
    with pytest.raises(AnsibleError) as execinfo:
        result = lookup.run([None, 'subelements'], None)
    assert str(execinfo.value) == 'subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey'

    # the optional third item must be a dict with flags skip_missing

# Generated at 2022-06-23 12:13:39.808880
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    class DummyTemplar:
        def template(self, value):
            return value

    class DummyLoader:
        pass

    lm._templar = DummyTemplar()
    lm._loader = DummyLoader()
    return lm


# Generated at 2022-06-23 12:13:41.146666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:13:49.472168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    check = lambda x, y: x == y
    # TODO: check could be a lot tighter
    check(
        LookupModule().run(
            [
                [
                    {'foo': 'bar'},
                    {'foo': 'baz'}
                ],
                'foo'
            ],
            {}
    ), [
        (
            {'foo': 'bar'},
            'bar'
        ),
        (
            {'foo': 'baz'},
            'baz'
        )
    ])


# Generated at 2022-06-23 12:13:51.093073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    # TODO: add more tests here

# Generated at 2022-06-23 12:14:02.890217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # simple test
    testdata = [{'name': 'Alice', 'groups': ['groupA', 'groupB']}]
    terms = [testdata, 'name']
    lookup = LookupModule()
    result = lookup.run(terms, {})
    assert result == [('Alice',)]

    # nested test, subelements groups
    testdata = [{'name': 'Alice', 'groups': ['groupA', 'groupB']}]
    terms = [testdata, 'groups']
    lookup = LookupModule()
    result = lookup.run(terms, {})
    assert result == [('groupA',), ('groupB',)]

    # nested test, subelements user.groups
    testdata = [{'user': {'name': 'Alice', 'groups': ['groupA', 'groupB']}}]
    terms

# Generated at 2022-06-23 12:14:12.688081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for method run of class LookupModule.
    """
    import sys
    import os
    import tempfile
    import yaml

    # create temporary variables file
    (fd, vars_file) = tempfile.mkstemp()
    os.close(fd)
    os.remove(vars_file)
    fd = open(vars_file, 'w')

# Generated at 2022-06-23 12:14:20.443736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # mock class
    class TestTemplar():
        def __init__(self, obj):
            self.obj = obj

        def template(self):
            return self.obj

    # mock class
    class TestLoader():
        def __init__(self, obj):
            self.obj = obj

    # mock class
    class TestVars():
        def __init__(self, obj):
            self.obj = obj

    # init
    terms = [{'a':'a'}, 'a']
    variables = TestVars({'a':'a'})
    templar = TestTemplar(terms)
    loader = TestLoader(terms)

    obj = LookupModule()
    obj._templar = templar
    obj._loader = loader
    obj._templar.available_variables = variables

# Generated at 2022-06-23 12:14:31.777402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get a handle to the class instance
    lm = LookupModule()

    # create list of dicts like the one in the var section of a play

# Generated at 2022-06-23 12:14:34.439599
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:14:45.193350
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:14:53.404710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = []
    terms = ['users','mysql.hosts']
    variables = {}
    users = [{"name":"Alice","authorized":["/tmp/alice/onekey.pub","/tmp/alice/twokey.pub"],"mysql":{"password":"mysql-password","hosts":["localhost.localdomain","127.0.0.1","::1","localhost",""],"privs":["*.*:SELECT","DB1.*:ALL"]},"groups":["wheel"]},{"name":"Bob","authorized":["/tmp/bob/id_rsa.pub"],"mysql":{"password":"other-mysql-password","hosts":["db1"],"privs":["*.*:SELECT","DB2.*:ALL"]}}]
    variables['users'] = users
    lookups = LookupModule()
    ret = lookups.run(terms, variables)

# Generated at 2022-06-23 12:15:03.595449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.lookup_plugins.subelements import LookupModule
    from ansible.module_utils.ansible_collections.community.tests.unit.compat import unittest

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.lookup = LookupModule()

        def test_1(self):
            # test subelements lookup and module together
            # tests require ansible to be installed, but *not* the pymysql library
            import ansible.constants
            import ansible.plugins.loader
            # monkeypatch the connection plugin to not try loading pymysql
            from ansible.plugins.connection.mysql import Connection as MySqlConnection
            MySqlConnection._pymysql_found = False

# Generated at 2022-06-23 12:15:13.949022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = [
        {'who': 'alice', 'mysql': [{'address': '127.0.0.1', 'password': 'alice-password'}, {'address': '::1', 'password': 'alice-password'}]},
        {'who': 'bob',   'mysql': [{'address': 'db1',      'password': 'bob-password'}]},
        {'who': 'carl',  'mysql': [{'address': 'db2',      'password': 'carl-password'}]}
    ]

    # simple example: get the 'address' field
    lookup = LookupModule()
    result = lookup.run([items, 'mysql.address'], {})
    assert len(result) == 5

# Generated at 2022-06-23 12:15:15.876566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with empty list
    terms = []
    result = LookupModule.run(terms)
    assert result == 0



# Generated at 2022-06-23 12:15:20.247254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['skipped', 'skipped']
    variables={}
    lookup_obj = LookupModule()
    assert lookup_obj.run(terms, variables,**{}) == []

# Generated at 2022-06-23 12:15:29.094550
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:15:30.550648
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:15:32.078438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("TODO")


# Generated at 2022-06-23 12:15:32.641318
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:15:39.172082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()

    # test 1 with wrong number of terms - first a dict or a list, second a string pointing to the subkey
    terms = {}
    lu._templar = None
    lu._loader = None
    lu._display = None
    try:
        lu.run(terms, None)
    except AnsibleError:
        pass
    else:
        raise AssertionError("test 1 failed")

    # test 2 with wrong number of terms - first a dict or a list, second a string pointing to the subkey
    terms = ("1","2","3")
    try:
        lu.run(terms, None)
    except AnsibleError:
        pass
    else:
        raise AssertionError("test 2 failed")

    # test 3 with wrong data types - first a dict or a

# Generated at 2022-06-23 12:15:48.598996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources=['/dev/null']))
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['tests/inventory/test_hosts']))
    variable_manager.extra_vars = {"names": ["Alice", "Bob", "Eve", {"name": "Mallory", "groups": ["wheel"]}]}
    variable_manager.set_of_variable_manager(variable_manager)
    st = variable_manager.get_vars()


# Generated at 2022-06-23 12:15:52.400348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [[1,2,3,"a","b","c"], 'bla']
    variables = {}
    lookup_plugin.run(terms, variables)

# Generated at 2022-06-23 12:16:03.228274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    # Test with valid input, expect a dict with authors with a non-empty list of reviews
    terms = [
        [
            {"book": "The Three Musketeers", "author": "Alexandre Dumas"},
            {"book": "War of the Worlds", "author": "H. G. Wells"}
        ],
        "author",
        {'skip_missing': False}
    ]

    lm = LookupModule()
    assert lm.run(terms, None, **{'vars': {}}) == [("Alexandre Dumas", {"book": "The Three Musketeers", "author": "Alexandre Dumas"}), ("H. G. Wells", {"book": "War of the Worlds", "author": "H. G. Wells"})]

    # Test with empty input, expect

# Generated at 2022-06-23 12:16:06.660929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    g = LookupModule()
    assert g.lookup('name', {}) is None
    assert g.lookup('name', {'_terms': ['key', 'value']}) == ['key', 'value']


# Generated at 2022-06-23 12:16:18.743158
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    terms = [{'skipped': False}, 'key1.key2.key3']

    lm.run(terms, None)

    # throw error when wrong arguments passed
    try:
        lm.run([], None)
        assert False, "should have thrown"
    except AnsibleError:
        pass

    try:
        lm.run([{'skipped': False}, {}], None)
        assert False, "should have thrown"
    except AnsibleError:
        pass

    try:
        lm.run([{'skipped': False}, 'key1.key2'], None)
        assert False, "should have thrown"
    except AnsibleError:
        pass

    # throw error when optional flag is not in FLAGS

# Generated at 2022-06-23 12:16:25.458592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module = LookupModule()
    # Create a list of dictionaries to pass as input

# Generated at 2022-06-23 12:16:26.637626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 12:16:28.246728
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup_instance = LookupModule()
   assert lookup_instance != None

# Generated at 2022-06-23 12:16:28.780972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:16:39.360596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils.six import StringIO

    # Test structure

# Generated at 2022-06-23 12:16:44.808076
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:16:56.384123
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyTemplate:
        def __init__(self, s=""):
            self.s = s

        def __getitem__(self, k):
            self.s = self.s + "[" + k
            return self

        def __str__(self):
            return self.s + "]"

    class DummyLoader:
        def __init__(self, s=""):
            self.s = s

        def get_basedir(self, x):
            self.s = self.s + "get_basedir(" + x + ")"
            return self.s

        def list_directory(self, x):
            self.s = self.s + "list_directory(" + x + ")"
            return self.s


# Generated at 2022-06-23 12:17:08.311967
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize terms
    terms = [[{"a1": {"b1": [{"c1": "d1"}, {"e1": "f1"}, {"g1": "h1"}],
                    "b2": [{"i1": "j1"}]}},
              {"a2": {"b3": [{"c2": "d2"}, {"e2": "f2"}, {"g2": "h2"}],
                    "b4": [{"i2": "j2"}]}}],
             "a1.b1",
             {"skip_missing": True}]

    # Initialize LookupModule
    lookup_module = LookupModule()

    # Test run method
    test_result = lookup_module.run(terms, None)

    # Wanted Result

# Generated at 2022-06-23 12:17:09.850567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret.run

# Generated at 2022-06-23 12:17:19.874691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert(lu.run([[{'a': [1, 2, 3]}, {'a': [4, 5, 6]}], 'a'], None) == [({'a': [1, 2, 3]}, 1), ({'a': [1, 2, 3]}, 2), ({'a': [1, 2, 3]}, 3), ({'a': [4, 5, 6]}, 4), ({'a': [4, 5, 6]}, 5), ({'a': [4, 5, 6]}, 6)])

# Generated at 2022-06-23 12:17:30.076632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    import __builtin__
    builtins = __builtin__.__dict__.copy()
    lookup = LookupModule()
    try:
        lookup._templar = MagicMock()
        lookup._loader = MagicMock()
        # 1. Test wrong number of arguments
        lookup.run([], dict())
        assert False, "AnsibleError should have been raised, got nothing"
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "
    try:
        lookup.run([], dict(), dict())
        assert False, "AnsibleError should have been raised, got nothing"
    except AnsibleError as e:
        assert str(e)

# Generated at 2022-06-23 12:17:36.905064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'terms': [["[{u'a': 1, u'b': 2, u'c': 3}, {u'a': 4, u'b': 5, u'c': 6}]", 'c'], "[u'a', u'b']"]})
    # lookup_module.run()


# Generated at 2022-06-23 12:17:44.716925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelements=LookupModule()
    assert subelements.run([
        [{'a': {'b': {'c': [1, 2, 3]}}}],
        'a.b.c',
        {'skip_missing': False}
        ]) == [[{'a': {'b': {'c': [1, 2, 3]}}}, 1],
                [{'a': {'b': {'c': [1, 2, 3]}}}, 2],
                [{'a': {'b': {'c': [1, 2, 3]}}}, 3]]

# Generated at 2022-06-23 12:17:55.974404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    # initialize class LookupModule to be tested
    lookup_module = LookupModule()
    lookup_module._templar = None  # TODO !!!
    lookup_module._loader = None  # TODO !!!

    # initialize test data
    terms1 = ['input1.json', 'users', {'skip_missing': 'True'}]
    terms2 = ['input1.json', 'users.mysql.hosts', {'skip_missing': 'True'}]
    terms3 = ['input1.json', 'users.mysql.hosts', {'skip_missing': 'False'}]
    terms4 = ['input1.json', 'users.groups']
    terms5 = [{'skipped': 'True'}, 'users']

    # perform test(s)

# Generated at 2022-06-23 12:18:07.864928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check number of terms
    LookupModule().run([], None)
    LookupModule().run([{}], None)
    LookupModule().run([{}, {}], None)
    try:
        LookupModule().run([{}, {}, {}, {}], None)
        assert False
    except AnsibleError:
        pass

    # first term should be a list, second a string holding the subkey
    try:
        LookupModule().run([{}, 5], None)
        assert False
    except AnsibleError:
        pass
    try:
        LookupModule().run([{}, 5, {}], None)
        assert False
    except AnsibleError:
        pass
    try:
        LookupModule().run([{}, 5, 3], None)
        assert False
    except AnsibleError:
        pass

   

# Generated at 2022-06-23 12:18:09.731441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    if lookup_plugin is None:
        raise AssertionError('lookup_plugin should not be none')

# Generated at 2022-06-23 12:18:11.190950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:18:17.328944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test case for method run of class LookupModule
    """
    terms = list(['subelements', 'authorized', '{"skip_missing":True}'])
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    result = LookupModule().run(terms, users)

# Generated at 2022-06-23 12:18:28.338843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # no args should raise an error
    try:
        lm.run([])
    except AnsibleError:
        pass
    else:
        assert False

    # one arg should raise an error
    try:
        lm.run([False])
    except AnsibleError:
        pass
    else:
        assert False

    # one arg should raise an error
    try:
        lm.run([None])
    except AnsibleError:
        pass
    else:
        assert False

    # first item should be a list
    try:
        lm.run({"a": 1, "b": 2}, "c")
    except AnsibleError:
        pass
    else:
        assert False

    # second item should be a string

# Generated at 2022-06-23 12:18:30.707222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()

    assert(result.run(["foo"]) == None)

# Generated at 2022-06-23 12:18:42.368891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms

    mock_loader = lambda x: x
    mock_templar = lambda x: x
    subkey = "authorized"

    lookup_instance = LookupModule()
    lookup_instance._loader = mock_loader
    lookup_instance._templar = mock_templar

    # Test for error on non existing subkey

# Generated at 2022-06-23 12:18:53.817131
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # test: only first two terms, first term is a list
    terms = [[{'foo': 'bar', 'baz': {'foz': 'bla'}}], 'baz.foz']
    assert 'bla' == lookup.run(terms, None)[0][1]

    # test: only first two terms, first term is a dictionary
    terms = [{'item': {'foo': 'bar', 'baz': {'foz': 'bla'}}}, 'baz.foz']
    assert 'bla' == lookup.run(terms, None)[0][1]

    # test: only first two terms, first term is a dict with skipped

# Generated at 2022-06-23 12:19:02.268847
# Unit test for constructor of class LookupModule
def test_LookupModule():
  from ansible.module_utils.ansible_release import __version__
  from ansible.utils.path import unfrackpath
  from ansible.utils.display import Display

  display = Display()

  testLookupModuleParm = dict(
      lookup_plugin_paths = [ unfrackpath("/home/work/Lab/ansible/lookup_plugins") ],
      variable_manager = {
      },
      loader = {
          '_basedir': "/home/work/Lab/ansible",
          '__version__': __version__,
          'path_info': [],
      }
  )

  lookup_module = LookupModule(**testLookupModuleParm)
  lookup_module.set_options({})
  assert lookup_module


# Generated at 2022-06-23 12:19:13.484007
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    my_list = ['a', 'b', 'c', 'd', 'e']
    my_dict = {'a': {'b': {'c': {'d': 'e'}}}}
    assert lookup.run([my_list, '0'], dict()) == [('a',)]
    assert lookup.run([my_list, '1'], dict()) == [('b',)]

    assert lookup.run([my_dict, 'a.b.c.d'], dict()) == [({'b': {'c': {'d': 'e'}}}, 'e')]
    assert lookup.run([my_dict, 'a.b.c'], dict()) == [({'b': {'c': {'d': 'e'}}}, {'d': 'e'})]


# Generated at 2022-06-23 12:19:14.491720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subel = LookupModule()
    assert subel

# Generated at 2022-06-23 12:19:27.014481
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:34.718066
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ([{'one': {'two': {'three': [1, 2, 3, 4, 5]}}}], 'one.two.three')
    test = LookupModule()

    results = test.run(terms, None)

    assert isinstance(results, list)
    assert len(results) == 5
    for i in range(1, 6):
        assert isinstance(results[i-1], tuple)
        assert len(results[i-1]) == 2
        assert isinstance(results[i-1][0], dict)
        assert isinstance(results[i-1][1], int)
        assert results[i-1][1] == i

# Generated at 2022-06-23 12:19:37.320038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=["users", "mysql.hosts"], variables={}, **{}) == []

# Generated at 2022-06-23 12:19:47.988095
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:56.345880
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def assert_raises_ansible_error(args, msg, *extra_args, **kwargs):
        try:
            LookupModule(*args, **kwargs)
        except AnsibleError as e:
            assert msg in str(e)
        else:
            raise AssertionError('AnsibleError not raised')

    assert_raises_ansible_error([], 'subelements lookup expects a list of two or three items', "", "", "")
    assert_raises_ansible_error([["test"]], 'subelements lookup expects a list of two or three items', "", "", "")

    assert_raises_ansible_error([["test"], "test"], 'subelements lookup expects a list of two or three items', "", "", "")

# Generated at 2022-06-23 12:20:06.153799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init
    lookupModule = LookupModule()
    lookupModule._templar = None
    lookupModule._loader = None

    # test 1
    users = [
        {'name': 'alice', 'authorize': ['key1', 'key2']},
        {'name': 'bob', 'authorize': ['key3']},
    ]
    terms = (users, 'authorize')
    assert len(lookupModule.run(terms, {})) == 3
    # test 2
    terms = (users, 'authorize2')
    try:
        lookupModule.run(terms, {})
        assert False
    except AnsibleError:
        pass
    # test 3
    terms = (users, 'authorize', {'skip_missing': True})

# Generated at 2022-06-23 12:20:15.983407
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # setup context:
    varmanager = VariableManager()
    templar = Templar(loader=None, variables=varmanager)

    # setup test vars:
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    # Mocks: