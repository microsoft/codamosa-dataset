

# Generated at 2022-06-23 12:10:17.423246
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lu = LookupModule()

    # test_run_method_exits_early_if_parameter_terms_is_not_a_list_or_has_too_many_or_too_few_items

    terms = ('abc',)
    try:
        lu.run(terms, variables=None)
        assert False
    except AnsibleError:
        pass

    terms = ('abc', 'def', 'ghi')
    try:
        lu.run(terms, variables=None)
        assert False
    except AnsibleError:
        pass

    # test_run_method_exits_early_if_first_term_is_not_a_dictionary_or_a_list

    terms = (123,)

# Generated at 2022-06-23 12:10:27.628808
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    # create a mock module for this test
    module = type('', (), {'warn': lambda self, msg: True,
                           '_templar': type('', (), {'template': lambda self, msg: msg}),
                           '_loader': type('', (), {'get_basedir': lambda self, task: 'fake_basedir',
                                                    'path_dwim': lambda self, task: 'fake_dwim'})})

    lookup_module = LookupModule(module)

    # simulate tasks.yml file
    class DummyTask:
        def __init__(self, task={}):
            for k in task:
                setattr(self, k, task[k])

    class DummyPlay:
        def __init__(self, play={}):
            self.basedir

# Generated at 2022-06-23 12:10:36.173449
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:10:39.287358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m1 = LookupModule()
    m1.run(["users", "mysql.password"], dict())
    m1.run(["users", "mysql.password", True], dict())



# Generated at 2022-06-23 12:10:45.631753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    loader = DataLoader()
    host_list = [dict(name='localhost', groups=['ungrouped'])]
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    def _get_terms(terms):
        terms = terms.split(",")
        terms = map(lambda x: x.strip(), terms)
        return terms

    lm = LookupModule()
    lm.set_options(variable_manager=variable_manager, loader=loader, templar=Templar(variable_manager))

    #

# Generated at 2022-06-23 12:10:56.951068
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a simple complex dictionary
    data = {"a.b.d": [1, 2], "a.b.e": [3, 4], "c.f.g": [5, 6]}
    terms = (data, "a.b")
    lookup = LookupModule()
    assert(lookup.run(terms, {}) == [({'a': {'b': {'d': [1, 2], 'e': [3, 4]}}}, [1, 2]),
                                     ({'a': {'b': {'d': [1, 2], 'e': [3, 4]}}}, [3, 4])])

    # Test with a simple complex list

# Generated at 2022-06-23 12:10:58.616130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert "LookupModule" == str(LookupModule)


# Generated at 2022-06-23 12:11:07.849851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    import ansible.module_utils.parsing.convert_bool
    import ansible.plugins.lookup
    import ansible.utils.listify
    # Define test data
    terms_data = [{'key1': 'value1'},
                  'subkey1',
                  {'skip_missing': False}]
    # Define the data structure to use instead of a dictionary lookup
    class FakeLookup(object):
        def __init__(self, value):
            self.value = value
        def get(self, key, default=None, boolean=False, integer=False, float=False, complex=False, fail_on_undefined=False):
            if key in self.value:
                return self.value[key]
            else:
                return

# Generated at 2022-06-23 12:11:09.188201
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:11:10.401589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert(isinstance(ret, LookupModule))

# Generated at 2022-06-23 12:11:13.804176
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    import pytest
    with pytest.raises(AnsibleError):
        lookup_plugin.run(
            [],
            None,
            templar=MagicMock(),
            loader=MagicMock()
        )

# Generated at 2022-06-23 12:11:20.608830
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Simple list
    users = [
        dict(name='alice'),
        dict(name='bob')
    ]
    terms = [
        users,
        'name',
    ]
    lm = LookupModule()
    result = lm.run(terms, {})

    assert len(result) == 2
    assert result[0][1] == 'alice'
    assert result[1][1] == 'bob'

    # Nested subkeys
    users = [
        dict(
            name='alice',
            authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']
        ),
        dict(
            name='bob',
            authorized=['/tmp/bob/id_rsa.pub']
        )
    ]

# Generated at 2022-06-23 12:11:20.958174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:11:26.757557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check length of ret
    lm = LookupModule()
    terms = [[{'key1': 'value1', 'key2': 'value2'}, {'key1': 'value3', 'key2': 'value4'}], 'key1']
    ret = lm.run(terms, {})
    assert len(ret) == 4
    assert (('value1', 'value2'), ('value1', 'value2')) in ret

# Generated at 2022-06-23 12:11:27.704854
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-23 12:11:38.921556
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

# Generated at 2022-06-23 12:11:43.345491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule([1, 2, 3, 4], None)
    assert 'subelements lookup expects a list of two or three items' in str(excinfo.value)


# Generated at 2022-06-23 12:11:52.261345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup_plugins.subelements import LookupModule

    class FakeTemplar:
        def __init__(self):
            self.vars = {}

        def template(self, value, *args, **kwargs):
            return value

    class FakeLoader:
        def __init__(self):
            self.vars = {}

        def list(self, value, *args, **kwargs):
            return value

    def _lookup_ret(terms, variables):
        lookup = LookupModule()
        lookup.set_options(direct=variables)
        lookup._templar = FakeTemplar()
        lookup._loader = FakeLoader()
        return lookup.run(terms, variables)

    # test missing parameters

# Generated at 2022-06-23 12:12:02.525360
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:12:04.934131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''create an object of the class LookupModule'''
    lm = LookupModule()
    return(lm)


# Generated at 2022-06-23 12:12:15.868821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Good input
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel'], },
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'groups': [], },
    ]
    terms = [users, 'authorized']
    result = lookup.run(terms, [])

# Generated at 2022-06-23 12:12:16.752770
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:12:17.880365
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule != None

# Generated at 2022-06-23 12:12:19.825086
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 12:12:21.245549
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert(module != None)



# Generated at 2022-06-23 12:12:26.310454
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dict_terms = dict(terms=dict(vars=dict(users=dict()), loader=dict(), templar=dict()))
    list_terms = dict(terms=list(vars=dict(users=dict()), loader=dict(), templar=dict()))
    assert(isinstance(LookupModule(dict_terms), LookupModule))
    assert(isinstance(LookupModule(list_terms), LookupModule))

# Generated at 2022-06-23 12:12:38.775326
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:12:40.232392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests skipped intentionally, test_lookup_plugin has extensive tests
    pass

# Generated at 2022-06-23 12:12:40.840768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:12:43.469020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    # test __init__
    assert subelements
    assert subelements.get_basedir is not None

# Generated at 2022-06-23 12:12:53.912145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # Case 1:
    # Test with a list of dictionaries and a given key to extract
    lookup_module = LookupModule()
    result = lookup_module.run([
        [{'foo': 'bar'}, {'foo': 'baz'}, {'foo_bar': 'baz'}],
        'foo'
    ], {})
    assert result == [('bar',), ('baz',)]

    # Case 2:
    # Test with a dictionary with a list of dictionaries and a given key to extract

# Generated at 2022-06-23 12:13:06.080391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    klazz = LookupModule

    users = [
        {
            "username": "A",
            "authorized": [
                {"key": "AAAA"},
                {"key": "FFFF"}
            ]
        },
        {
            "username": "B",
            "authorized": [
                {"key": "BBBB"},
                {"key": "EEEE"}
            ]
        },
        {
            "username": "C",
            "authorized": [
                {"key": "CCCC"}
            ]
        }
    ]

    def assert_equal(val1, val2):
        if val1 != val2:
            err = "Values not equal: %s != %s" % (str(val1), str(val2))
            raise AssertionError(err)

    # exception: 'terms' not a list or not

# Generated at 2022-06-23 12:13:15.304911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def assert_list_of_tuple(ret, expected):
        assert isinstance(ret, list)
        assert len(ret) == len(expected)
        for ret_item, expected_item in zip(ret, expected):
            assert isinstance(ret_item, tuple)
            assert len(ret_item) == len(expected_item)
            assert tuple(ret_item) == expected_item
    #
    # assert skip_missing == True
    #
    # subelements only
    assert_list_of_tuple(
        LookupModule(None, dict()).run(
            terms=[["Mike", "Mikey"], "name"],
            variables={},
        ),
        [('Mike',), ('Mikey',)]
    )
    #
    # subelements and record
    assert_list_of_tuple

# Generated at 2022-06-23 12:13:17.332231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:13:27.906127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # required libs
    import copy
    import os
    import sys

    # import ansible modules
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))

    # test LookupModule
    lookup_module = LookupModule()

    # declare test data

# Generated at 2022-06-23 12:13:36.628874
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # -----
    # TODO: test with templar and loader
    # -----

    from ansible.plugins.lookup.sub_elements import LookupModule

    # Define a users var

# Generated at 2022-06-23 12:13:39.293474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(['{ "a": {"b": {"c": [42, 42]}} }', 'a.b.c'], None)

# Generated at 2022-06-23 12:13:42.637251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test instantiate LookupModule
    lm = LookupModule()
    assert lm
    assert lm.run
    assert lm._templar
    assert lm._loader

# Generated at 2022-06-23 12:13:52.870744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _templar = None
    _loader = None
    lookup_instance = LookupModule(_loader=_loader, templar=_templar, basedir=None, runner=None)
    result = lookup_instance.run([
        {
            'key1':{'key2':[1,2,3]},
            'key3':{'key4':[4,5,6]}
        },
        'key1.key2'
    ], None, **{})

# Generated at 2022-06-23 12:13:53.953845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm

# Generated at 2022-06-23 12:14:06.412438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.template import Templar


# Generated at 2022-06-23 12:14:17.239894
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create instance of LookupModule
    # Check flags in terms
    terms = [0, 1, {'skip_missing': True}]
    lookup = LookupModule()
    assert isinstance(terms, list) and len(terms) == 3
    assert isinstance(terms[2], dict)
    assert all(isinstance(key, string_types) and key in FLAGS for key in terms[2].keys())

    terms = [0, 1, {'skip_missing': True, 'unambiguous_flag': True}]
    lookup = LookupModule()
    assert isinstance(terms, list) and len(terms) == 3
    assert isinstance(terms[2], dict)
    assert all(isinstance(key, string_types) and key in FLAGS for key in terms[2].keys())

    # Test skip_missing

# Generated at 2022-06-23 12:14:29.571480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    # Test for input error handling
    lookup = LookupModule()
    assert lookup.run([None, None], None) == []  # empty term
    assert lookup.run([None, None, None], None) == []  # empty term
    assert lookup.run([[], None], None) == []  # empty elementlist
    assert lookup.run([{}, None], None) == []  # empty elementlist

    # Test general functionality
    lookup = LookupModule()
    random.seed(9) # random, but repeatable

# Generated at 2022-06-23 12:14:40.665214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import base64
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.listify import listify_lookup_plugin_terms

    # define test modules
    modules = {
        # module that if first argument is a list and second is a string, returns the length of the list
        'len': lambda a, b: len(a),
        'base64encode': lambda a: base64.b64encode(a),
    }

    # define test variables

# Generated at 2022-06-23 12:14:51.237621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.utils.display import Display
    from ansible.plugins import lookup_loader

    variable_manager = VariableManager()
    loader = DataLoader()

    # Setup inventory and variables
    plugin = lookup_loader.get('subelements', class_only=True)()
    plugin._templar = VariableManager()
    term = [{'a': {'b': {'c': [1, 2, 3]}}}, 'a.b.c']

# Generated at 2022-06-23 12:15:01.643863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    terms = [
        {
            'name': 'first',
            'mysql': {
                'hosts': ['host1', 'host2'],
                'privs': ['SELECT', 'UPDATE'],
            }
        },
        {
            'name': 'second',
            'mysql': {
                'hosts': ['host1', 'host2'],
                'privs': ['ALL'],
            }
        }
    ]
    terms1 = [terms, 'mysql.privs']
    terms2 = [terms, 'mysql.hosts']
    terms3 = [terms, 'nonexisting']
    terms4 = [terms, 'empty']
    terms5 = [terms, 'empty', {'skip_missing': False}]

# Generated at 2022-06-23 12:15:03.463301
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Basic sanity test for the LookupModule constructor"""
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:15:05.317375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-23 12:15:14.060635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar(object):
        def __init__(self, data=None):
            self.data = data

        def template(self, term, variables=None, convert_bare=True, fail_on_undefined=True):
            return self.data

    class MockLoader(object):
        def __init__(self, data=None):
            self.data = data

        def list_directory(self, path):
            return self.data

    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar(terms)
    lookup_module._loader = MockLoader(dirs)
    lookup_module.run(terms, variables, **kwargs)



# Generated at 2022-06-23 12:15:23.840357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    class AnsibleExitJson(Exception):
        def __init__(self, *args, **kwargs):
            if args:
                self.args = args
            else:
                self.message = kwargs.get('message', '')
                self.args = (self.message, )

    class AnsibleFailJson(Exception):
        def __init__(self, *args, **kwargs):
            if args:
                self.args = args
            else:
                self.message = kwargs.get('message', '')
                self.args = (self.message, )

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None
            self.app = LookupModule()


# Generated at 2022-06-23 12:15:34.115523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lm = LookupModule()
  d = {
    'a': {
      'b': [
        'a.b.0',
        'a.b.1',
        'a.b.2'
      ],
      'c': [
        'a.c.0',
        'a.c.1',
        'a.c.2'
      ]
    }
  }

  # no top level skipped subelements
  ret = lm.run([d, 'a.b'], None)
  assert len(ret) == 3
  assert ret[0] == (d['a'], 'a.b.0')

  # no sublevel skipped subelements
  d['a']['c'].append('skipped')

# Generated at 2022-06-23 12:15:46.383734
# Unit test for constructor of class LookupModule
def test_LookupModule():
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play import Play
  from ansible.executor.task_queue_manager import TaskQueueManager

  loader = DataLoader()

  inventory = InventoryManager(loader=loader, sources='localhost,')
  variable_manager = VariableManager(loader=loader, inventory=inventory)

  lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:15:58.783356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  subelements = LookupModule()
  users = [
    {
      "name": "alice",
      "authorized": [
        "/tmp/alice/onekey.pub",
        "/tmp/alice/twokey.pub"
      ],
      "mysql": {
        "hosts": [
          "db1"
        ],
        "privs": [
          "*.*:SELECT"
        ]
      }
    },
    {
      "name": "bob",
      "authorized": [
        "/tmp/bob/id_rsa.pub"
      ]
    }
  ]
  terms = [[users, 'authorized'], {'skip_missing': False}]
  test_output = subelements.run(terms, None)
  assert isinstance(test_output, list)

# Generated at 2022-06-23 12:16:07.983097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import ansible.errors as ae

    class TestLookupModule(unittest.TestCase):
        def test_simple_list_returns_correct_results(self):
            lookup = LookupModule()
            self.assertEqual(lookup.run(["a", "b"], None), ["a", "b"])
            self.assertEqual(lookup.run([1, 2, 3], None), [1, 2, 3])
            self.assertEqual(lookup.run([1, ["a", "b"], 3], None), [1, ["a", "b"], 3])
            self.assertEqual(lookup.run([1, ("a", "b"), 3], None), [1, ("a", "b"), 3])


# Generated at 2022-06-23 12:16:19.928206
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    elements = [
        {
            'key1': 'value1',
            'key2': {
                'key3': 'value3',
                'key4': 'value4'
            }
        },
        {
            'skipkey1': 'skipvalue1',
            'key2': {
                'key3': 'value3'
            }
        },
        {
            'key1': 'value1',
            'key2': {
                'skipkey3': 'skipvalue3',
                'key4': 'value4'
            }
        }
    ]
    terms = [elements, 'key2.key3']
    result = lookup_plugin.run(terms, [])
    assert len(result) == 2

# Generated at 2022-06-23 12:16:21.212962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-23 12:16:31.004605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.compat.tests import unittest
    from ansible.plugins.lookup import subelements

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.ldr = DataLoader()
            self.varMgr = VariableManager()

        def test_subelements_negative_test(self):
            """
            Test invalid terms
            """
            lookup = subelements.LookupModule()
            # negative test - invalid term
            invalid_terms = [['one', 'two', 'three'], 1]

# Generated at 2022-06-23 12:16:32.363569
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:16:42.219567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check 'empty' input
    assert (LookupModule.run(None, None, None, None) == [])
    # create single item
    test_item = [{'test': 'testval'}, 'test']
    test_list = [{'test': 'testval'}]
    assert (LookupModule.run(test_item, None, None, None)[0][0] == test_list[0])
    # create two items
    test_item.append([{'test': 'testval2'}])
    test_list.append({'test': 'testval2'})
    assert (LookupModule.run(test_item, None, None, None)[0][0] == test_list[0])

# Generated at 2022-06-23 12:16:53.582104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._templar = True
    l._loader = True

# Generated at 2022-06-23 12:17:03.377263
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:17:06.828106
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check exception paths in LookupModule init
    try:
        assert LookupModule
    except:
        raise
    try:
        LookupModule()
        assert False
    except:
        pass


# Generated at 2022-06-23 12:17:08.267540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None


# Generated at 2022-06-23 12:17:13.585927
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    lookup_module = LookupModule()
    return lookup_module

if __name__ == '__main__':
    print("Testing 'LookupModule' class module")
    test_LookupModule()
    print("Test of module 'LookupModule' passed successfully!")

# Generated at 2022-06-23 12:17:19.569223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar(object):
        def __init__(self, variables):
            self._variables = variables

        def template(self, term, convert_bare=True, fail_on_undefined=True, overrides=None, escape_backslashes=True, **kwargs): # pylint: disable=unused-argument
            return term
    templar = MockTemplar({})
    lookup_module = LookupModule()
    lookup_module._templar = templar
    return lookup_module

# Generated at 2022-06-23 12:17:29.843931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar

    def _test(terms, expected, *args, **kwargs):
        """
        :param terms:
            string, or list of 2 or 3 items.
        """
        ansible_loader = AnsibleLoader(terms)
        templar = Templar(loader=ansible_loader)
        lookup = LookupModule()

        if not isinstance(terms, list):
            terms = [terms]
        terms = [ansible_loader] + terms
        terms = listify_lookup_plugin_terms(terms, templar=templar, loader=ansible_loader)
        result = lookup.run(terms, variables=None, **kwargs)
        assert result == expected


# Generated at 2022-06-23 12:17:41.545625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    play_context = PlayContext()
    play_context.loader = loader
    play_context.variable_manager = variable_manager
    play_context.inventory = inventory
    templar = Templar(loader, variable_manager, play_context)

    lookup_module = LookupModule()

    # set display
    lookup_module._display = display

   

# Generated at 2022-06-23 12:17:43.521442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) > 0
    assert LookupModule.__name__ == 'LookupModule'

# Generated at 2022-06-23 12:17:55.256073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    class MockVariableManager():
        def get_vars(self, loader, play, host):
            return {}
        def get_vars_as_dict(self, loader, play, host):
            return {}
        def get_host_vars(self, host, new_inventory=None):
            return {}
        def add_group_vars_files(self, group, files):
            pass
        def add_host_vars_files(self, host, files):
            pass
        def all_vars(self, ):
            return {}
        def extra_vars(self, loader, play, host):
            return {}
        def set_host_variable(self, host, varname, vardata):
            pass

# Generated at 2022-06-23 12:18:02.311063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    This method tests the run method of class LookupModule
    '''
    # Set up test input
    class AnsibleModuleMock:
        def __init__(self):
            self.params = dict()
            self.params['lookup_value'] = '[[{}, {}, {}, {}]]'
    class LookupBaseMock:
        def __init__(self):
            self._templar = AnsibleModuleMock()
            self._loader = AnsibleModuleMock()
    class AnsibleErrorMock:
        pass
    class LookupModuleMock:
        def __init__(self):
            self.base = LookupBaseMock()
            self.helpers = dict()
            self.helpers['templar'] = AnsibleModuleMock()

# Generated at 2022-06-23 12:18:11.155299
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest

    # Create an instance of LookupModule
    lookup = LookupModule()

    # Ensure an LookupModule instance is created
    assert isinstance(lookup, LookupModule)

    # Ensure AnsibleError is raised when first term is not list
    with pytest.raises(AnsibleError):
        lookup.run(terms=({},), variables={}, **{})

    # Ensure AnsibleError is raised when first term is not list or dict
    with pytest.raises(AnsibleError):
        lookup.run(terms=(None,), variables={}, **{})

    # Ensure AnsibleError is raised when second term is not string
    with pytest.raises(AnsibleError):
        lookup.run(terms=([],), variables={}, **{})

    # Ensure AnsibleError is raised when optional third term

# Generated at 2022-06-23 12:18:17.269520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run() function is only defined if ansible is run with the -v option
    try:
        from ansible.module_utils.ansible_release import __version__
    except ImportError:
        __version__ = None
    if __version__ is None or __version__.startswith('HP-UX'):
        return
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from cStringIO import StringIO
    class MockTemplar():
        def __init__(self, loader):
            self._loader = loader
        def template(self, template, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, boolean=False):
            return template

# Generated at 2022-06-23 12:18:28.249692
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # execute method run of class LookupModule and returns its results
    def run_test(test_vars):
        lookup_module = LookupModule()
        results = lookup_module.run(test_vars['terms'], test_vars['variables'])
        return results

    # generate a list of dictionaries based on info received by method run
    def generate_results(results):
        test_results = []
        for result in results:
            test_result = []
            test_result.append(result[0])
            test_result.append(result[1])
            test_results.append(test_result)
        return test_results

    # dictionary with test variables
    test_vars = {'variables': {}, 'terms': []}

    # test variables for test 1

# Generated at 2022-06-23 12:18:41.001832
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test the default behavior
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'hosts': ['db1'], 'password': 'other-mysql-password', 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}
    ]

# Generated at 2022-06-23 12:18:48.404958
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple
    FakeLoader = namedtuple("FakeLoader", ['loaders'])
    FakeTemplar = namedtuple("FakeTemplar", ['vars'])
    FakeTemplate = namedtuple("FakeTemplate", ['template'])
    fake_loader = FakeLoader(loaders=[])
    fake_templar = FakeTemplar(vars={})
    fake_template = FakeTemplate(template=None)

    # first test: generate a good result

# Generated at 2022-06-23 12:18:59.354226
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:00.919710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Generate lookup object
    LookupModule(None)


# Generated at 2022-06-23 12:19:12.474852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instantiate
    lookup = LookupModule()
    # define test variables

# Generated at 2022-06-23 12:19:22.189628
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create instance
    lm = LookupModule()

    # call run()
    #vars = {'users': {'alice': {'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, 'bob': {'authorized': ['/tmp/bob/id_rsa.pub']}}}
    #terms = [["alice", "bob"], "authorized"]
    terms = [dict(a=dict(a1=[1]), b=dict(b1=[2])), "b1"]
    ret = lm.run(terms, {})
    assert ([(((dict(b1=[2]), 2),)),]) == ret

# Generated at 2022-06-23 12:19:32.111873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.plugins import lookup_loader

    lookup_result = lambda *args, **kwargs: args[0] if args else kwargs

    # method run(self, terms, inject=None, **kwargs)
    #
    # Check parameters
    # Invalid number of params
    lookup = lookup_loader.get('subelements')
    # check that it returns an AnsibleError exception
    got_exception = False
    try:
        lookup.run()
    except AnsibleError:
        got_exception = True
    assert got_exception, "subelements lookup expects a list of two or three items"

    # First term not a list or dict
    got_exception = False

# Generated at 2022-06-23 12:19:33.378471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, {})

# Generated at 2022-06-23 12:19:44.218722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Passing a list by using a var
    user_data = [[{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'name': 'alice'},
        {'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob'}]]
    res = lm.run([user_data, 'authorized'])
    assert isinstance(res, list)
    for item in res:
        assert len(item) == 2
        item1 = item[1]
        assert isinstance(item1, string_types)
        assert item1.endswith('pub')
    # Passing a list

# Generated at 2022-06-23 12:19:44.900087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result

# Generated at 2022-06-23 12:19:46.183117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:19:54.169691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_module = LookupModule()
    lookup_module.get_basedir = lambda: os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_data')

    # test with empty list
    ret = lookup_module.run([], {})
    assert len(ret) == 0

    # test with 3 invalid terms
    with tempfile.NamedTemporaryFile() as temp_file:
        temp_file.write('{"a": {"b": [1, 2]}}')
        temp_file.flush()
        # invalid terms

# Generated at 2022-06-23 12:19:56.457258
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    lookup_plugin = LookupModule()

    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-23 12:19:57.320171
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:19:59.207040
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    l = LookupModule()
    assert hasattr(l, 'run')


# Generated at 2022-06-23 12:20:09.073246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_should_run_subelements

    terms = ['users']
    variables = {}
    kwargs = {}
    # {'name': alice, 'mysql': {'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL'], 'hosts': [u'%', u'127.0.0.1', u'::1', u'localhost']}, 'authorized': [u'/tmp/alice/onekey.pub', u'/tmp/alice/twokey.pub']}

    # {'name': 'bob', 'mysql': {'password': 'other-mysql-password', 'privs': ['*.*:SELECT', 'DB2.*:ALL'], 'hosts': ['db1']}, 'authorized': [u'/tmp/bob/id_rs