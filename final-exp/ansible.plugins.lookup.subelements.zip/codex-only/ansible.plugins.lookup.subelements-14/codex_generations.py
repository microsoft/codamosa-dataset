

# Generated at 2022-06-23 12:10:16.993108
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test run method
    lu = LookupModule()

    # check lookup terms - check number of terms
    def test_wrong_amount_of_terms():
        try:
            lu.run([], {})
        except AnsibleError as e:
            assert e.message.startswith("subelements lookup expects a list of two or three items")

        try:
            lu.run([], {}, num=4)
        except AnsibleError as e:
            assert e.message.startswith("subelements lookup expects a list of two or three items")


# Generated at 2022-06-23 12:10:27.259163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import json
    import unittest

    # Load class into global namespace,
    # otherwise the test loader cannot find it
    globals()['LookupModule']=LookupModule

    class TestLookupModule(unittest.TestCase):
        """Test class for testing method run for Ansible lookup plugin
        LookupModule.
        """

        def setUp(self):
            self.module = LookupModule()

# Generated at 2022-06-23 12:10:28.556474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # tests can't be done until we have a better way to mock objects
    pass

# Generated at 2022-06-23 12:10:35.852330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_LookupModule_run_test(test_name, terms, variables, ret):
        lm = LookupModule()
        result = lm.run(terms, variables)
        if result != ret:
            print("%s: ret=%s, expected=%s" % (test_name, result, ret))

    #
    # test the run method
    #

# Generated at 2022-06-23 12:10:44.038158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    my_vars = {}
    assert 'skipped' not in my_lookup.run(["{{ 'skipped' }}"], my_vars)
    assert my_lookup.run(["{{ 'skipped' }}"], {'skipped': True}) == []
    assert my_lookup.run([{'skipped': True}], {'skipped': True}) == []
    assert my_lookup.run(["{{ 'skipped' }}"], {'skipped': False}) == ['skipped']
    assert my_lookup.run([{'skipped': False}], {'skipped': False}) == [{'skipped': False}]

# Generated at 2022-06-23 12:10:56.336734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run of LookupModule...")

    # initialize the LookupModule
    lookup = LookupModule()
    lookup.set_loader(None)
    lookup.set_templar(None)

    # initialize the lists for testing

# Generated at 2022-06-23 12:11:06.837461
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Definition of the input data
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
            'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
                'privs': ['*.*:SELECT', 'DB1.*:ALL']},
            'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'],
            'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'],
                'privs': ['*.*:SELECT', 'DB2.*:ALL']}}
    ]

   

# Generated at 2022-06-23 12:11:15.563883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ##
    # Init environment
    ##

    # create ansible module:
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.six import PY3
    from ansible.plugins.lookup import LookupBase

    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __getattr__(self, _):
            return None

    class AnsibleModule(object):
        def __init__(self, **kwargs):
            args = dict(
                argument_spec=kwargs,
                supports_check_mode=False
            )
            if PY3:
                args['required_if'] = kwargs.pop

# Generated at 2022-06-23 12:11:16.677783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 12:11:19.307014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test LookupModule with no parameters
    l = LookupModule()

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:11:23.208027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Creation of instance to test
    terms = ['user', 'name']
    l = LookupModule()
    l.run(terms, 'ansible', inject=dict(ansible=dict(user=dict(name='test'))))



# Generated at 2022-06-23 12:11:23.855668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:11:31.734388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    t = LookupModule()
    loader = DataLoader()
    users = [
        {
            "name": "alice",
            "authorised": [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub',
            ]
        },
        {
            "name": "bob",
            "authorised": [
                '/tmp/bob/onekey.pub',
            ]
        }
    ]

    def run_terms(terms):
        t.set_loader(loader)
        if not isinstance(terms, list):
            terms = [terms]
        return t.run(terms, variables={'users': users})


# Generated at 2022-06-23 12:11:40.616036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import logging, logging.handlers
    log = logging.getLogger('ansible.test')
    logging.basicConfig(level=logging.INFO, format='forced utest %(levelname)s:%(name)s:%(lineno)d:%(message)s')

    lh = logging.handlers.RotatingFileHandler(os.environ.get('TEST_LOGFILE'), maxBytes=100, backupCount=2)
    log.addHandler(lh)
    log.info('Started test')

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.lookup import LookupBase

# Generated at 2022-06-23 12:11:50.975156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)

    with pytest.raises(AnsibleError) as exc:
        lookup_obj.run([3], None, **{})
    assert "subelements lookup expects a list of two or three items" in str(exc)

    with pytest.raises(AnsibleError) as exc:
        lookup_obj.run([[], 3], None, **{})
    assert "subelements lookup expects a list of two or three items" in str(exc)


# Generated at 2022-06-23 12:12:00.482977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create the test lookup module
    class TestLookupModule(LookupModule):

        DUNDER_ANSIBLE_VARS = variables = {"error_on_undefined_lookups": True}

    # create the test terms and expected result
    terms = [
        [{"user1": {"mysql": {"hosts": ["host1","host2"]} } },
         {'user2': "dict2"},
         {'user3': "dict3"}],
        "mysql.hosts"]

    # run the test
    result = TestLookupModule().run(terms)

    # check the results
    assert result == [('host1',), ('host2',)]

# Generated at 2022-06-23 12:12:01.567466
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:12:07.736383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:12:19.182446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """testing method LookupModule.run of class LookupModule"""

    def _assert(terms, expected, msg=None):
        """helper method to call LookupModule.run"""
        lookup_module = LookupModule()
        value = lookup_module.run(terms, {})
        msg = msg or ""
        if expected != value:
            msg = "%s failed: expected %s, got %s" % (msg, expected, value)
            raise AssertionError(msg)


# Generated at 2022-06-23 12:12:21.059975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 12:12:22.748247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:12:35.295832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    import random

    # set up test data
    random_boolean = lambda: bool(random.getrandbits(1))
    random_list_or_dict = lambda: dict(listify_lookup_plugin_terms(random_list(randint(0,10)), templar=None, loader=None))
    random_dict = lambda: dict(listify_lookup_plugin_terms(random_list(randint(0,10)), templar=None, loader=None))
    random_

# Generated at 2022-06-23 12:12:42.378585
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create dummy module class
    class DummyModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            pass

    # create dummy display object
    class DummyDisplay(object):
        def __init__(self, **kwargs):
            self.verbosity = 6

        def display(self, msg, *args, **kwargs):
            pass

    # create DummyTaskExecutor
    class DummyTaskExecutor(object):
        def __init__(self, **kwargs):
            self.dummy_volatile_vars = {"ansible_facts": {}}

    # create dummy templar

# Generated at 2022-06-23 12:12:44.074139
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:12:45.505323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:12:56.857354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.module_utils.six import PY3
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookup(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return (terms, variables)

    # Prepare
    if PY3:
        unicode = str
    # PY2 : terms is a list, terms_as_str is unicode
    terms = ['var', 'subkey']
    terms_as_str = u'var.subkey'
    terms_as_list = ['var', ['sub', 'key']]

# Generated at 2022-06-23 12:13:08.701320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # example data
    example_data = [{'password': 'pwd1', 'hosts': ['host1', 'host2'], 'privs': ['priv1', 'priv2']},
                    {'password': 'pwd2', 'hosts': ['host3', 'host4'], 'privs': ['priv3', 'priv4']}]

# Generated at 2022-06-23 12:13:09.382393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:13:17.038006
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()


# Generated at 2022-06-23 12:13:22.627976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = [
        [{'key1': 'value1'}, {'key2': 'value2'}], 'key1',
        {'skip_missing': True}
        ]
    ret = lm.run(terms, None)
    assert ret == [({'key1': 'value1'}, 'value1')]

# Generated at 2022-06-23 12:13:31.781284
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:13:41.929629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test: method run of class LookupModule"""
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    import copy

    class MockTemplar(Templar):

        def __init__(self, variables):
            super(MockTemplar, self).__init__()
            self._available_variables = variables

        def available_variables(self):
            return self._available_variables

    class MockLookupModule(LookupBase):

        def __init__(self, variables):
            self._templar = MockTemplar(variables)
            self._loader = None
            self._tem

# Generated at 2022-06-23 12:13:52.584947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems

    terms = ('users', 'mysql.privs', '{"skip_missing": True}')
    terms = list(terms)

    lookup_obj = LookupModule()
    new_terms = lookup_obj.run(terms, {})
    assert isinstance(new_terms, list), new_terms
    assert len(new_terms) == 2, new_terms
    for idx, term in enumerate(new_terms):
        assert isinstance(term, tuple), term
        assert len(term) == 2, term
        assert isinstance(term[0], dict), term[0]
        assert isinstance(term[1], list), term[1]
        if idx == 0:
            assert term[0]['name'] == 'alice', term[0]['name']

# Generated at 2022-06-23 12:14:05.185265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test default subelement extraction
    test_terms = [[ {'name': 'alice', 'authorized': ['/home/alice/.ssh/id_rsa.pub']}, {'name': 'bob', 'authorized': ['/home/bob/.ssh/id_rsa.pub']}], 'authorized']
    test_variables = {}
    test_kwargs = {}
    expected_output = [({'name': 'alice', 'authorized': ['/home/alice/.ssh/id_rsa.pub']}, '/home/alice/.ssh/id_rsa.pub'), ({'name': 'bob', 'authorized': ['/home/bob/.ssh/id_rsa.pub']}, '/home/bob/.ssh/id_rsa.pub')]
    test_instance = LookupModule()
    assert test_

# Generated at 2022-06-23 12:14:16.034319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instance needs a loader class
    class Loader:
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager
    loader = Loader(None)
    # instance needs a templar class
    class Templar:
        def on_template(self, template_ds, template_path):
            return template_ds, template_path
    templar = Templar()
    # create the instance
    x = LookupModule(loader=loader, templar=templar)

    ret = x.run(['foo'], None)
    assert ret == [], "must be an empty list"

    ret = x.run([''], None)
    assert ret == [], "must be an empty list"

    ret = x.run([], None)

# Generated at 2022-06-23 12:14:18.125564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l._templar is None
    assert l._loader is None

# Generated at 2022-06-23 12:14:19.832210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:14:31.432805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # basic error cases
    def check_terms_error(terms, msg):
        try:
            l.run(terms, variables=None)
            assert False, "error should have been raised"
        except AnsibleError as e:
            assert msg in str(e)

    check_terms_error([['a']], "list")
    check_terms_error(['a', 'b'], "list")
    check_terms_error([1, 'b'], "list")
    check_terms_error([['a'], 2], "string")
    check_terms_error([['a'], ['b']], "string")

    # check optional flags
    check_terms_error([['a'], 'b', "c"], "dict")

# Generated at 2022-06-23 12:14:43.346838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """
    # Initialization of lookkup variables
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
             {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]

# Generated at 2022-06-23 12:14:43.972298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 12:14:44.508877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:14:47.197272
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([None, None], None)
    l.run([None, None, {'skip_missing': True}], None)

# Generated at 2022-06-23 12:14:52.050349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [2, 3],
        'hello',
        {'skip_missing': True}
    ]
    test1 = LookupModule()
    ret = test1.run(terms, None)
    assert ret == [], "Got error running test %s" % ret

# Generated at 2022-06-23 12:15:02.386149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import yaml
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    lookup_plugin = lookup_loader.get('subelements')
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:15:12.658411
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:15:22.063950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms

    def _raises(expected_msg, *args, **kwargs):
        try:
            LookupModule.run(*args, **kwargs)
            assert False
        except AnsibleError as e:
            assert e.message == expected_msg

    # check lookup terms - check number of terms
    terms = []
    _raises(
        'subelements lookup expects a list of two or three items, ',
        terms, {})
    _raises(
        'subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey',
        terms, {}, 1)
    terms = [1]

# Generated at 2022-06-23 12:15:27.608623
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['foo', 'bar', 'baz']
    variables = ['foo']
    kwargs = []
    lm = LookupModule()
    assert lm.run(terms, variables, **kwargs) is not None

# Generated at 2022-06-23 12:15:35.176557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    # When the method is called with no arguments, then it should return an appropriate error message
    lm = LookupModule()
    x = lm.run([], [])
    assert isinstance(x, list) and len(x) == 0

    # Test 2
    # When the method is called with an appropriate argument, then it should return the corresponding value
    lm = LookupModule()
    x = lm.run([ [{"name":"ansible", "id": 1, "skipped": False}, {"name":"ansible", "id": 2, "skipped": True}], "id"], [])
    assert isinstance(x, list) and len(x) == 1

# Test for function _raise_terms_error of class LookupModule

# Generated at 2022-06-23 12:15:47.195899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import base class for running unit tests
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.plugins.modules import AnsibleExitJson
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.plugins.modules import AnsibleFailJson
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.plugins.module_utils import ModuleTestCase

    # get class
    lookup_module = LookupModule()

    # test error on missing subkey
    query_data = [{'name': 'bob'}]
    key = 'subkey'
    test_term = [query_data, key]
    with ModuleTestCase.func_wrapper(AnsibleFailJson) as f:
        lookup_module

# Generated at 2022-06-23 12:15:59.801597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LooupBaseStub(LookupBase):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar
            super(LooupBaseStub, self).__init__(loader, templar, **kwargs)

    class LooupModuleStub(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

# Generated at 2022-06-23 12:16:10.713613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.six import PY3

    if not PY3:
        import __builtin__ as builtins     # pylint: disable=import-error
    else:
        import builtins


# Generated at 2022-06-23 12:16:21.557032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # empty elementlist
    elementlist = []
    terms = [elementlist, 'subkey']
    result = lookup_module.run(terms, None)
    assert result == []

    # not a dictionary in elementlist
    elementlist = ['not a dictionary']
    terms = [elementlist, 'subkey']
    try:
        lookup_module.run(terms, None)
    except AnsibleError as e:
        assert 'not a dictionary' in e.message
        assert 'item0' in e.message
    else:
        raise AssertionError("AnsibleError not raised")

    # subkey not in dictionary
    elementlist = [{'otherkey': 'somevalue'}]
    terms

# Generated at 2022-06-23 12:16:22.583944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-23 12:16:32.326292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    # Test 1: test with normal dictionary
    terms = [{'foo': 'bar', 'faz': {'baz': ['baz1', 'baz2']}},'faz.baz']
    result = lu.run(terms=terms, variables={})
    assert result == [({'foo': 'bar', 'faz': {'baz': ['baz1', 'baz2']}}, 'baz1'), ({'foo': 'bar', 'faz': {'baz': ['baz1', 'baz2']}}, 'baz2')]

    # Test 2: test with empty dictionary
    terms = [{},'faz.baz']

# Generated at 2022-06-23 12:16:41.088647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    plugin = LookupModule()
    result = plugin.run([{'one': {'two': [1, 2, 3]}}], {}, **{'vault_password': 'test'})
    assert result == [({'one': {'two': [1, 2, 3]}}, 1),
                      ({'one': {'two': [1, 2, 3]}}, 2),
                      ({'one': {'two': [1, 2, 3]}}, 3)]
    result = plugin.run([{'one': {'two': {'three': [1, 2, 3]}}}], {}, **{'vault_password': 'test'})

# Generated at 2022-06-23 12:16:52.211311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 12:16:55.879702
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x._templar is None
    assert x._loader is None
    x = LookupModule(templar=1, loader=1)
    assert x._templar is 1
    assert x._loader is 1

# Generated at 2022-06-23 12:16:56.812196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:17:08.858466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    test = {'skip': False, 'item1': 'result1', 'item2': 'result2', 'item3': 'result3', 'item4': 'result4'}

# Generated at 2022-06-23 12:17:19.337150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    # Test cases
    list_of_dict = [
        {'subkey': 'alice'},
        {'subkey': 'bob'},
        {'subkey': 'charlie'},
        {'skip_this': [],
         'subkey': 'delta'}
    ]
    dict_of_dict = {
        'a': {'subkey': 'alice'},
        'b': {'subkey': 'bob'},
        'c': {'subkey': 'charlie'},
        'd': {'skip_this': [],
              'subkey': 'delta'}
    }

# Generated at 2022-06-23 12:17:22.832751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [
        [{ 'author': 'Robert C. Martin', 'title': 'Clean Code' }, { 'author': 'J.R.R. Tolkien', 'title': 'Lord of the Rings' }],
        'author',
    ]
    variables = []
    assert lookup_module.run(terms, variables) == ['Robert C. Martin', 'J.R.R. Tolkien']

# Generated at 2022-06-23 12:17:26.412420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, 'run_ansible_2_7_compat')
    assert hasattr(LookupModule, '_raise_subelements_error')


# Generated at 2022-06-23 12:17:34.018252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader
    from ansible.template.safe_eval import unsafe_eval


# Generated at 2022-06-23 12:17:35.855382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:17:44.166250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils import basic
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = combine_vars(loader=loader, variables=None)
    mylookup = LookupModule()

# Generated at 2022-06-23 12:17:45.563271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule())

# Generated at 2022-06-23 12:17:56.637195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys
    import os
    from ansible.module_utils.parsing.convert_bool import boolean
    for module in (sys.modules[__name__], ansible.plugins.lookup.subelements):
        if not hasattr(module, "LookupModule"):
            continue

# Generated at 2022-06-23 12:18:08.449181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    # test with one subkey level
    result = LookupModule().run([['users'], 'authorized'], dict())

# Generated at 2022-06-23 12:18:19.411709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test run method of class LookupModule
    """

    class DummyVars(object):

        def __init__(self):
            self.hostvars=[]

# Generated at 2022-06-23 12:18:29.805740
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:18:35.814095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    # string
    lookup = LookupModule()
    term = [["elem1", "elem2", "elem3"], "testkey"]
    result = lookup.run(term, None)[0]
    if PY3:
        assert result == "{'skipped': True}"
    else:
        assert result == "{u'skipped': True}"

    # list
    lookup = LookupModule()
    term = [[{"testkey": "elem1"}, {"testkey": "elem2"}, {"testkey": "elem3"}], "testkey"]
    result = lookup.run(term, None)
    assert result == [('elem1',), ('elem2',), ('elem3',)]

    # nested list
    lookup = LookupModule()


# Generated at 2022-06-23 12:18:45.630172
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create mocks
    class MockLoader:

        def __init__(self):
            self.paths = []

        def get_basedir(self, path):
            self.paths.append(path)
            return 'basedir'

    class MockTemplar:

        def __init__(self):
            self.paths = []

        def template(self, path):
            self.paths.append(path)
            return path

    class MockVars:

        def __init__(self):
            self.paths = []

        def get(self, path, default=None, boolean=False, variables=None):
            self.paths.append(path)
            return path

    loader = MockLoader()
    templar = MockTemplar()
    vars = MockVars()

    # initialize the

# Generated at 2022-06-23 12:18:57.028473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-23 12:19:08.975281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    assert l.run([['a', 'b', 'c'], '1', '2'], {}) == [['a', '1'], ['a', '2'], ['b', '1'], ['b', '2'], ['c', '1'], ['c', '2']]
    assert l.run([['a', 'b', 'c'], '1'], {}) == [['a', '1'], ['b', '1'], ['c', '1']]
    assert l.run([{'a': 'b', 'c': 'd'}, 'a', 'b'], {}) == [['b', 'a'], ['b', 'b'], ['d', 'a'], ['d', 'b']]

# Generated at 2022-06-23 12:19:11.997494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Invoke the class constructor for LookupModule.
    test_obj = LookupModule()
    #Assert the result of class constructor for LookupModule and expected result.
    assert test_obj is not None

# Generated at 2022-06-23 12:19:13.934463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 12:19:26.427895
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_items(*args):
        testee = LookupModule()
        return testee.run(args)

    # fail tests
    try:
        test_items([{"a": {"b": ["c", "d"]}}])
    except AnsibleError as e:
        assert "lookup expects a list of two or three items" in str(e)
    else:
        assert False

    try:
        test_items([{"a": {"b": ["c", "d"]}}], "a.b")
    except AnsibleError as e:
        assert "lookup expecting a list of two or three items" in str(e)
    else:
        assert False


# Generated at 2022-06-23 12:19:34.253745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    lm = LookupModule()


# Generated at 2022-06-23 12:19:45.318604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    module = namedtuple('module', ['params'])
    mod = module(module.params({'users':[{'name': 'alice', 'authorized':['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized':['/tmp/bob/id_rsa.pub']}], 'skip_missing': False}))
    lookup_plugin = LookupModule()
    lookup_plugin.set_runner(mod)
    # print(lookup_plugin.run([['/tmp/bob/id_rsa.pub'], 'users', ['authorized']], mod))

# Generated at 2022-06-23 12:19:46.752717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:19:57.281160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare variables
    terms = dict()

# Generated at 2022-06-23 12:19:58.110197
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:20:08.166716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Method created to run unit tests on module
    '''
    # set parameters