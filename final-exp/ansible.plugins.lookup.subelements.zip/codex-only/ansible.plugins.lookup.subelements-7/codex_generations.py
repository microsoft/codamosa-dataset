

# Generated at 2022-06-23 12:10:16.469662
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from io import open

    variables = UnsafeProxy({'users': {'alice': {'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': [{'host': '*.*', 'priv': 'SELECT'}, {'host': 'DB1.*', 'priv': 'ALL'}]}}}})
    templar = Templar(loader=None, variables=variables)
    # lookups in general are non templated
    lookup

# Generated at 2022-06-23 12:10:25.504228
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.lookup.subelements

    class AnsibleModuleMock():
        def __init__(self):
            self.params = {}

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    class DataLoaderMock():
        def __init__(self):
            self.params = {}

        def load(self, data, file_name=None, show_content=True):
            if data is None and file_name is None:
                # initialize the loader
                return True
            elif type(data) == dict:
                return AnsibleMapping(data)
            elif type(data) == list:
                return AnsibleSequence(data)
            else:
                return data


# Generated at 2022-06-23 12:10:33.845157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from collections import namedtuple
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup.sublist import LookupModule
    from ansible.parsing.vault import VaultLib

    # prepare arguments
    TermElement = namedtuple('TermElement', ['term', 'lookup_opts'])

# Generated at 2022-06-23 12:10:44.386326
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub',
                                              '/tmp/alice/twokey.pub']},
             {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    variable_manager.set_inventory_variable(host=None, group='all', varname='users', value=users)
    lookup_plugin = LookupModule(loader=loader, variable_manager=variable_manager)

    # check single item

# Generated at 2022-06-23 12:10:56.664957
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class ansible_module_mock(object):
        class params(object):
            pass

    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    users = [
        {'name': 'alice',
         'authorized': [
             "/tmp/alice/onekey.pub",
             "/tmp/alice/twokey.pub"]},
        {'name': 'bob',
         'authorized': [
             "/tmp/bob/id_rsa.pub"]}
    ]


# Generated at 2022-06-23 12:11:06.837462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run_lookup_module(terms, variables, lookup_plugin_class):
        lpm = lookup_plugin_class()
        return lpm.run(terms, variables)

    d = {
        "users": [
            {
                "name": "alice",
                "mysql": {
                    "hosts": [
                        "%",
                        "127.0.0.1",
                        "::1",
                        "localhost",
                    ]
                }
            },
            {
                "name": "bob",
                "mysql": {
                    "hosts": [
                        "db1",
                    ]
                }
            }
        ]
    }

    # test with list of dictionaries and a subkey
    terms = [[d], "users.mysql.hosts"]
    assert run_lookup_module

# Generated at 2022-06-23 12:11:16.639002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    try:
        l.run([''], None)
        raise Exception('exception should have been raised')
    except AnsibleError:
        pass

    try:
        l.run(['a', 'b', 'c'], None)
        raise Exception('exception should have been raised')
    except AnsibleError:
        pass

    try:
        l.run(['a'], None)
        raise Exception('exception should have been raised')
    except AnsibleError:
        pass

    try:
        l.run(['a', 'b', 'c'], None)
        raise Exception('exception should have been raised')
    except AnsibleError:
        pass


# Generated at 2022-06-23 12:11:17.718285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert look

# Generated at 2022-06-23 12:11:28.371890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test basic run
    users = [
        {'name': 'alice', 'groups': ['wheel']},
        {'name': 'bob', 'groups': ['wheel', 'nogroup']}
    ]
    result = LookupModule().run([users, 'groups'], {})
    assert result == [[{'name': 'alice', 'groups': ['wheel']}, 'wheel'], [{'name': 'bob', 'groups': ['wheel', 'nogroup']}, 'wheel'], [{'name': 'bob', 'groups': ['wheel', 'nogroup']}, 'nogroup']]

    # test with missing
    result = LookupModule().run([users, 'groups', {'skip_missing': True}], {})

# Generated at 2022-06-23 12:11:30.019979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    r = LookupModule()
    assert 2 <= len(r) <= 3

# Generated at 2022-06-23 12:11:40.419897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.constants import DEFAULT_HASH_BEHAVIOUR

    # Load builtin plugins
    LookupModule.load_plugins(None)

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory, hash_behaviour=DEFAULT_HASH_BEHAVIOUR)
    variable_manager.set_inventory(inventory)

    # options

# Generated at 2022-06-23 12:11:50.847402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    class TestLookupModule_run(unittest.TestCase):

        def test_run_exception(self):
            lookup_plugin = LookupModule()
            self.assertRaises(AnsibleError, lookup_plugin.run, [], {})
            self.assertRaises(AnsibleError, lookup_plugin.run, [{}], {})

        def test_run_ok(self):
            class DummyTemplar(object):
                def __init__(self):
                    pass

                def template(self, stuff):
                    return stuff

            lookup_plugin = LookupModule()
            lookup_plugin._templar = DummyTemplar()

# Generated at 2022-06-23 12:11:52.494557
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 12:11:54.246392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule
    LookupModule()


# Generated at 2022-06-23 12:11:56.930486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test run with empty list
    l = LookupModule()
    l.set_options({})
    result = l.run([{}], {})
    assert result == []



# Generated at 2022-06-23 12:12:07.408643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = loader.load_basedir('.')

    import os
    testdir = os.path.dirname(os.path.realpath(__file__))

    class FakeVarsModule(object):
        # TODO: share with the annotate task plugin
        def __init__(self):
            self.vars = combine_vars(loader, templar, "all", None)

        def set_fact(self, key, value):
            self.vars[key] = value

        def get_fact(self, key):
            return self.vars[key]


# Generated at 2022-06-23 12:12:18.770423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module = LookupModule()
   # Test with empty list should raise an error
   test_example = []
   try:
       lookup_module.run(terms=test_example, variables=None)
   except LookupError:
       assert True
   except Exception:
       assert False

   # Test with list with only one item should raise an error
   test_example = ['item1']
   try:
       lookup_module.run(terms=test_example, variables=None)
   except LookupError:
       assert True
   except Exception:
       assert False

   # Test with dict should raise an error
   test_example = [{'key1': 'value1'}, 'item2']
   try:
       lookup_module.run(terms=test_example, variables=None)
   except LookupError:
       assert True

# Generated at 2022-06-23 12:12:27.519183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init lookup
    lookup = LookupModule()
    lookup._templar = Dict()     # replace templar by a Dict
    lookup._loader  = Dict()     # replace loader by a Dict

    # init test vars
    elementlist_1 = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    # test
    # first test
    terms = [elementlist_1, 'authorized']
    result = lookup.run(terms, context={})

# Generated at 2022-06-23 12:12:39.956246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check if the right data is returned
    assert LookupModule().run([[{"a": {"b": [1,2,3]}}], "a.b"], None) == [({"a": {"b": [1,2,3]}}, 1), ({"a": {"b": [1,2,3]}}, 2), ({"a": {"b": [1,2,3]}}, 3)]

    # the optional third term is a dict with a single key 'skip_missing', set to a boolean (default: False)
    assert LookupModule().run([{'somekey': {"a": {"b": [1,2]}}}, "a.b"], None) == [({"a": {"b": [1,2]}}, 1), ({"a": {"b": [1,2]}}, 2)]

# Generated at 2022-06-23 12:12:41.455282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:12:50.777503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.plugins.lookup.subelements

    l = ansible.plugins.lookup.subelements.LookupModule()
    # build list

# Generated at 2022-06-23 12:13:00.963562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # test normal use case
    terms = [{
        'host1': {  # this item is to be skipped
            'skipped': True},
        'host2': {
            'mysql': {
                'hosts': [
                    'db1',
                    'db2']}
        },
        'host3': {
            'mysql': {
                'hosts': [
                    'db3']}
        }},
        'mysql.hosts']
    ret_list = lookup_plugin.run(terms, None)
    assert len(ret_list) == 2
    # this looks OK


# Generated at 2022-06-23 12:13:11.994442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Test subelements: lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey
    terms = [{'skipped': False}, 'authorized']
    try:
        lm.run(terms, {})
        assert False, "Expected AnsibleError"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in to_native(e)

    terms = [{'skipped': False}, '']
    try:
        lm.run(terms, {})
        assert False, "Expected AnsibleError"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in to_native(e)


# Generated at 2022-06-23 12:13:17.638755
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict())

    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

    lookup_plugin.set_options(direct=dict(key=42))
    assert lookup_plugin._options['key'] == 42


# Generated at 2022-06-23 12:13:20.268616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(lm._templar is None)
    assert(lm._loader is None)

# Generated at 2022-06-23 12:13:30.185237
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup a plugin that uses the lookup
    class LookupTester(object):
        def __init__(self):
            self._loader = None
            self._templar = None
    lookup_tester = LookupTester()
    lookup_tester.__class__ = LookupModule
    lookup_tester.run = LookupModule.run

    # run the testcases

# Generated at 2022-06-23 12:13:32.022522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # noinspection PyTypeChecker
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:13:35.876006
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = {'_terms': [
                [
                    {'name': 'Alice'},
                    {'name': 'Bob'}
                ],
                'name'
            ]}
    assert [('Alice',), ('Bob',)] == lm.run(terms, {})

# Generated at 2022-06-23 12:13:43.685508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _test_LookupModule_run(key):
        terms = [[{'a': {'b': [key]}}], 'a.b']
        ret = LookupModule().run(terms, None)
        assert(ret == [({'a': {'b': [key]}}, key)])
    _test_LookupModule_run([])
    _test_LookupModule_run({})
    _test_LookupModule_run('test1')
    _test_LookupModule_run(['test1'])
    _test_LookupModule_run([{'test1': 'test1'}])

# Generated at 2022-06-23 12:13:46.978043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # construct a class with a single argument
    lookup_plugin = LookupModule()
    # Call run function using argument `foo`
    assert lookup_plugin.run(["foo"], None) == "bar"

# Generated at 2022-06-23 12:13:49.727881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()
    my_lookup_module.run([["foo"], ["bar"]], {})

# Generated at 2022-06-23 12:13:51.201597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule), 'LookupModule is not a LookupModule'

# Generated at 2022-06-23 12:14:03.044634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get LookupModule object
    lu = LookupModule()

    # create dummy class to mimic the AnsibleTemplar object
    class DummyTemplar:
        def template(self, value):
            return value
    lu._templar = DummyTemplar()

    # test example 1
    terms = []
    terms.append(
        [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
         {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}])
    terms.append('authorized')

# Generated at 2022-06-23 12:14:12.772151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run([[10, 20, 30], '0'], None) == [10]
    assert lm.run([[{'b1': 10}, {'b1': 20}, {'b1': 30}], 'b1'], None) == [10, 20, 30]
    assert lm.run([{'a1': {'b1': 10}}, 'b1'], None) == [10]
    assert lm.run([[{'b1': 10}, {'b1': 20}, {'b1': 30}], 'b1', {'skip_missing': True}], None) == [10, 20, 30]

# Generated at 2022-06-23 12:14:20.459959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._loader = {}
    l._templar = {}
    x = l.run([{'a': {'b': [1, 2, 3]}}, 'a.b'],dict())
    assert x == [(None, 1), (None, 2), (None, 3)]
    x = l.run([{'a': {'b': [1, 2, 3]}}, 'a.b', dict()], dict())
    assert x == [(None, 1), (None, 2), (None, 3)]
    x = l.run([{'a': {'b': [1, 2, 3]}}, 'a.b', {'skip_missing': False}], dict())
    assert x == [(None, 1), (None, 2), (None, 3)]

# Generated at 2022-06-23 12:14:31.777821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    testing the run method
    '''
    # input data
    terms = [[{'user': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']},
              {'user': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}], 'authorized']
   

# Generated at 2022-06-23 12:14:43.651552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    class MockTemplar(object):
        def __init__(self, loader):
            self._loader = loader

        def template(self, data, convert_bare=None, fail_on_undefined=None, bare_deprecated=None, ignore_errors=None, override=None, preserve_trailing_newlines=None, escape_backslashes=None, convert_data=None, fail_on_undefined_errors=None):
            return data

        def is_safe_attribute(self, varname):
            return varname == 'skipped'

    class MockLoader(object):
        pass


# Generated at 2022-06-23 12:14:44.951003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:14:53.300166
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:14:55.590627
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


if __name__ == '__main__':
    print(test_LookupModule())

# Generated at 2022-06-23 12:15:01.594437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = [
    {'name':'user1', 'values':[1]},
    {'name':'user2', 'values':[1,2,3]}]
    variables = {'var': 'value'}
    result = [((u, 1) for u in terms)]
    assert result == lookup.run(terms, variables, **{'key': 'values'})

# Generated at 2022-06-23 12:15:11.654211
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    users = [{'name': 'alice', 'groups': ['wheel']},
             {'name': 'bob', 'groups': ['sysadmin']},
             {'name': 'charlie', 'skipped': True}]

    templar = MockTemplar()
    result = LookupModule.run(terms=[users, 'groups'], variables=dict(), templar=templar)
    assert result == [({'name': 'alice', 'groups': ['wheel']}, ['wheel']),
                      ({'name': 'bob', 'groups': ['sysadmin']}, ['sysadmin'])]


# Generated at 2022-06-23 12:15:21.277115
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:15:33.491041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=["foo", "bar"], variables=None, **{})
    assert result == []

    result = lookup_plugin.run(terms=[[{"foo": "bar"}], "foo"], variables=None, **{})
    assert result == [("bar",)]

    result = lookup_plugin.run(terms=[[{"foo": ["bar"]}], "foo"], variables=None, **{})
    assert result == [(["bar"],)]

    result = lookup_plugin.run(terms=[[{"foo": {"bar": "baz"}}], "foo.bar"], variables=None, **{})
    assert result == [("baz",)]


# Generated at 2022-06-23 12:15:46.169457
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import shutil
    import tempfile
    import json
    import pytest

    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.display import Display
    display = Display()

    ########################################################################
    #### The following lines are stolen from ansible/executor/__init__.py
    #### to be able to call _load_name_to_path_cache()
    #### see also https://github.com/ansible/ansible/pull/15982

# Generated at 2022-06-23 12:15:58.524334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    print(lu.run([
        [
            {
                "id": 1,
                "skipped": True
            },
            {
                "id": 2,
                "skipped": False,
                "values": {
                    "skipped": True
                }
            },
            {
                "id": 3,
                "skipped": False,
                "values": {
                    "skipped": False,
                    "mylist": [
                        {}, {}, {}, {}, {}, {}, {}, {}, {},
                        {
                            "skipped": True
                        },
                        {}, {}, {}, {}, {}, {}, {}, {}, {}
                    ]
                }
            }
        ],
        "values.mylist"
    ]))


# Generated at 2022-06-23 12:16:07.751603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test with a list of lists
    inventory = [
        {
            'name': 'localhost',
            'foobar': [
                {'a': 1, 'b': 2},
                {'a': 3, 'b': 4}
            ]
        }
    ]
    terms = [[inventory], 'foobar.a', {}]
    result = lookup.run(terms, dict(inventory=inventory))
    assert result == [[{'name': 'localhost', 'foobar': [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]}, 1],
                    [{'name': 'localhost', 'foobar': [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]}, 3]]

    # test with a list of diction

# Generated at 2022-06-23 12:16:09.429014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test module constructor
    assert LookupModule()

# Generated at 2022-06-23 12:16:20.674632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    def assertRaises(exp, arg):
        try:
            module.run(arg, None, skip_missing=False)
        except exp as e:
            assert str(e) == exp.errmsg
        else:
            raise AssertionError("exp '%s' was not caught" % exp.errmsg)

    assertRaises(AnsibleError, [1,2,3])
    assertRaises(AnsibleError, ['one', 'two'])
    assertRaises(AnsibleError, [{"a": "b"}, ["c", "d"]])
    assertRaises(AnsibleError, ['one', 'two', 'three'])
    assertRaises(AnsibleError, [{'a': 'b'}, ['c', 'd'], 'three'])
   

# Generated at 2022-06-23 12:16:22.012961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:16:27.648317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=no-self-use
    # create empty instance
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    lp = LookupModule(loader=loader, variable_manager=variable_manager, templar=None)
    assert lp is not None

# Generated at 2022-06-23 12:16:35.825909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [{'foo': 'ok', 'bar': 'nok'}, 'foo']
    ret = lookup_plugin.run(terms, variables=None, **{})
    assert len(ret) == 1
    assert isinstance(ret, list)
    assert isinstance(ret[0], tuple)
    assert len(ret[0]) == 2
    assert ret[0][0] == {'foo': 'ok', 'bar': 'nok'}
    assert ret[0][1] == 'ok'


# Generated at 2022-06-23 12:16:42.366892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # In order to properly test this, we need to create a loader
    # object, which is normally created in ansible's "main" function.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variables = VariableManager(loader=loader, inventory=inventory)
    # Load the lookup plugins
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./plugins/lookup')

    # Make an instance of the LookupModule
    lm = LookupModule()

    assert lm

# Generated at 2022-06-23 12:16:53.784032
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test with 2 arguments
    lookup_instance = LookupModule()


# Generated at 2022-06-23 12:16:55.879701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run'), "LookupModule must have a run method"

# Generated at 2022-06-23 12:17:07.717901
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import copy
    from units.mock.loader import DictDataLoader

    # simple case
    terms = [
        [
            {'subelement1': [{'subelement2': ['value1', 'value2']}]}
        ], 'subelement1.subelement2'
    ]
    loader = DictDataLoader({})
    lookup_plugin = LookupModule(loader=loader, basedir=None)
    assert lookup_plugin.run(copy.deepcopy(terms), variables=dict()) == [({'subelement1': [{'subelement2': ['value1', 'value2']}]}, 'value1'), ({'subelement1': [{'subelement2': ['value1', 'value2']}]}, 'value2')]

    # simple case with flags

# Generated at 2022-06-23 12:17:08.780329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    return 'module init ok'

# Generated at 2022-06-23 12:17:19.336564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Test with a list of dictionaries and a subkey
    terms = [
        [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}],
        'b'
    ]
    assert lm.run(terms, {}) == [({'a': 1, 'b': 2}, 2), ({'a': 3, 'b': 4}, 4)]

    # Test with a list of dictionaries with nested subkeys
    terms = [
        [{'a': 1, 'b': {'c': 2, 'd': 3}}, {'a': 11, 'b': {'c': 12, 'd': 13}}],
        'b.c'
    ]

# Generated at 2022-06-23 12:17:29.646976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    # given
    test_lookup = LookupModule()

    # Check for correct error handling
    try:
        test_lookup.run(['string'], {})
        assert False
    except AnsibleError as e:
        pass

    try:
        test_lookup.run(['l1', 4], {})
        assert False
    except AnsibleError as e:
        pass

    try:
        test_lookup.run(['l1', 's2', 's3'], {})
        assert False
    except AnsibleError as e:
        pass


# Generated at 2022-06-23 12:17:32.045767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:17:42.234894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

# Generated at 2022-06-23 12:17:54.292861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    def assert_result_contains_in_order(lst, *args, **kwargs):
        from nose.tools import assert_equal

        expected_len = len(args)
        assert_equal(len(lst), expected_len, "Expected %d items but got %d" % (expected_len, len(lst)))
        for i in xrange(expected_len):
            for j in xrange(len(args[i])):
                assert_equal(lst[i][j], args[i][j])

    lookup = LookupModule()

    # default skip_missing = False
    terms = [[{'x': {'a': [1, 2, 3]}}], 'x.a', dict()]

# Generated at 2022-06-23 12:17:59.855040
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()
    templar = AnsibleLoader(None, dataloader).get_loader(' Jinja2')
    subel = LookupModule(templar=templar, loader=dataloader)
    assert subel._templar == templar
    assert subel._loader == dataloader

# Generated at 2022-06-23 12:18:10.557193
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # creating an instance of LookupModule
    lookup_obj = LookupModule()

    # creating dictionary object

# Generated at 2022-06-23 12:18:22.510384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms_success = [
        {'skipped': False, 'name': 'Alice'},
        'name',
        {'skip_missing': False}
    ]
    assert lookup.run(terms_success, {}) == [('Alice',)]
    terms_skipped = [
        {'skipped': True, 'name': 'Alice'},
        'name',
        {'skip_missing': False}
    ]
    assert lookup.run(terms_skipped, {}) == []
    terms_missing = [
        {'skipped': False, 'unknown': 'Alice'},
        'name',
        {'skip_missing': False}
    ]

# Generated at 2022-06-23 12:18:31.304585
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # ---------------------------------------------------
    # Constructor tests
    # ---------------------------------------------------

    # test for parameter 'terms'
    # ---------------------------------------------------
    # Terms should be list of two items:
    #    * list of dictionaries
    #    * string, key to extract
    lm = LookupModule()
    # test: terms is list of two items
    input_terms = ['test', '']
    # test: 1st item is list
    # test: 2nd item is string
    # test: 2nd item is key inside 1st item
    # test: extract
    # test: extract value is not empty
    input_terms = [[{'test': [1, 2, 3]}], 'test']
    # test: extract value is list
    input_terms = [[{'test': 'aaa'}], 'test']
    # test: extract

# Generated at 2022-06-23 12:18:42.536411
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:18:54.009290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 2 <= len(l.run([{'one': ['a'], 'two': 'two'}, 'one'], dict()))
    assert 1 == len(l.run([{'one': ['a'], 'two': 'two'}, 'two'], dict()))
    assert len(l.run([{'skipped': True}, 'one'], dict())) == 0
    assert len(l.run([{'one': ['a'], 'skipped': True}, 'one'], dict())) == 0
    assert len(l.run([{'skipped': True, 'two': 'two'}, 'one'], dict())) == 0

# Generated at 2022-06-23 12:19:02.667264
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the LookupModule constructor

    :return:
    """

# Generated at 2022-06-23 12:19:13.555662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    class Options(object):
        verbosity = 0
    class Runner(object):
        options = Options()
    lookup = LookupModule()
    lookup.set_runner(Runner())
    lookup._templar = None
    lookup._loader = None
    # Exercise

# Generated at 2022-06-23 12:19:26.062333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = [[{'a': '1'}, {'skipped': True}, {'b': '2'}], 'a']
    assert lm.run(terms, None) == ['1']

    weird_skipped = object()
    terms = [
        [{'a': 1}, {'skipped': weird_skipped}, {'b': 2}], 'a'
    ]
    assert lm.run(terms, None) == [1]

    terms = [
        ["a", {'skipped': False}, "b"], 'a'
    ]
    try:
        lm.run(terms, None)
    except Exception as e:
        assert str(e) == "subelements lookup expects a dictionary, got 'a'"
    else:
        assert False


# Generated at 2022-06-23 12:19:34.044297
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:19:44.915557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Build a lookup module
    lm = LookupModule()
    lm.set_templar(None)
    lm.set_loader(None)
    # Build some arguments for the method
    args = {
        "terms": [[
            {
                "a": {
                    "b": [{"name": "foo"}, {"name": "bar"}]
                }
            },
            {
                "a": {
                    "b": [{"name": "hey"}, {"name": "you"}]
                }
            },
            {
                "a": {
                    "c": [{"name": "hi"}, {"name": "there"}]
                }
            },
            {"no-a": {"name": "test"}}
        ], "a.b"],
        "variables": {}
    }
    # Call the method

# Generated at 2022-06-23 12:19:45.606231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:19:47.151961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule(None, None, None, None, None))

# Generated at 2022-06-23 12:19:48.817214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:19:58.590770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.module_utils.six.moves import StringIO

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultEditor

    class FakeVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        def __init__(self, value, vault_id=None, filename=None):
            self.value = value
            self.vault_id = vault_id
            self.start_mark = "***"
            self.end_mark = "***"
            self.filename = filename

        def __str__(self):
            return "HashString<%s>" % self.value


# Generated at 2022-06-23 12:20:03.880784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    with open("/home/vagrant/ansible/tests/data/lookup_plugins/subelements/subelements_testdata.json", "r") as f:
        testdata = json.load(f)
    testlookup = LookupModule()
    testlookup.run(testdata["terms"], testdata["variables"])

# Generated at 2022-06-23 12:20:13.286538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text

    item_list = [
        {
            "name": "alice",
            "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]
        },
        {
            "name": "bob",
            "authorized": ["/tmp/bob/id_rsa.pub"]
        }
    ]

    lookup_module = LookupModule()

    # test run with a list
    terms = [item_list, "authorized"]
    result = lookup_module.run(terms, {})