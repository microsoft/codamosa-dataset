

# Generated at 2022-06-23 12:10:09.375236
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:10:15.790763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils import basic
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.lookup.subelements import LookupModule

    # test no argument
    test_object = LookupModule()
    assert test_object is not None

    # test with arguments
    test_object = LookupModule(loader=basic.AnsibleLoader())
    assert test_object is not None



# Generated at 2022-06-23 12:10:17.466700
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []

# Generated at 2022-06-23 12:10:27.669446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import assertCountEqual

    result = LookupModule().run([[{"name": "alice",
                                  "authorized": [
                                      "/tmp/alice/onekey.pub",
                                      "/tmp/alice/twokey.pub"
                                  ]},
                                  {"name": "bob",
                                  "authorized": "/tmp/bob/id_rsa.pub"}],
                                  "authorized"],
                                  dict())

# Generated at 2022-06-23 12:10:28.221513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:10:30.700620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This method tests the constructor of the LookupModule class

    :return: returns nothing
    :rtype: none
    """
    assert LookupModule()


# Generated at 2022-06-23 12:10:36.957444
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockTemplar(Templar):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables

    pony_vars = dict(
        users=[
            dict(name='alice', authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']),
            dict(name='bob', authorized=['/tmp/bob/id_rsa.pub'])
        ]
    )
    pony_vars_mgr = VariableManager()

# Generated at 2022-06-23 12:10:45.919024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.plugins.lookup.subelements import LookupModule
  lookup = LookupModule()
  # test 1
  users = [
            { 'name': 'alice', 'authorized': ['/tmp/alice/id_rsa.pub'] },
            { 'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'] }
          ]
  terms = [users, 'authorized']
  ret = lookup.run(terms, None)

# Generated at 2022-06-23 12:10:48.407287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module._loader is not None
    assert module._templar is not None



# Generated at 2022-06-23 12:10:58.522589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # lookup module instance
    lookup_module = LookupModule()

    # test parameters
    lookup_module._templar = None
    lookup_module._loader = None


# Generated at 2022-06-23 12:11:07.823244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    complex_variables = dict()

    complex_variables['users'] = dict()
    users_list = list()
    users_list.append(dict(
        name='alice',
        authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
        mysql=dict(
            password='mysql-password',
            hosts=[
                '%',
                '127.0.0.1',
                '::1',
                'localhost',
            ],
            privs=[
                '*.*:SELECT',
                'DB1.*:ALL',
            ],
        ),
        groups=['wheel'],
    ))


# Generated at 2022-06-23 12:11:08.812305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:11:09.375909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:11:18.261799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager()
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:11:28.640057
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)


# Generated at 2022-06-23 12:11:39.662982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes

    subelements = LookupModule()

    # vars

# Generated at 2022-06-23 12:11:50.258562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([[{'a': 1}, {'a': 2}, {'a': 3}], 'a'], None) == [(1,), (2,), (3,)]
    # skip missing keys
    assert lookup_plugin.run([[{'a': 1}, {'a': 2}, {'a': 3}], 'b', {'skip_missing': True}], None) == []
    # missing keys raise error
    try:
        lookup_plugin.run([[{'a': 1}, {'a': 2}, {'a': 3}], 'b', {'skip_missing': False}], None)
    except AnsibleError as err:
        assert str(err) == "could not find 'b' key in iterated item '{'a': 1}'"


# Generated at 2022-06-23 12:12:01.372287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # build a fake lookup module
    lookup = LookupBase()
    lookup._templar = None
    lookup._loader = None

    # TODO add to test/test_lookup_plugin.py!
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext


    class FakeLoader:
        def get(self, terms):
            return terms

    class TestLookupModule(unittest.TestCase):

        def test_subelements(self):
            lm = LookupModule()
            lm.set_loader({'_terms': ['test_subelements'], 'loader': FakeLoader()})
            v = VariableManager()
           

# Generated at 2022-06-23 12:12:03.845169
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [{'a':1}, "test"]
    variables = {}
    module = LookupModule()
    ret = module.run(terms, variables)

    assert(ret == [({"a": 1}, 1)])


# Generated at 2022-06-23 12:12:04.696272
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:12:05.902174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create instance of LookupModule
    obj = LookupModule()


# Generated at 2022-06-23 12:12:10.316790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader

    # input data
    #'{"1":{"authorized":["/tmp/alice/onekey.pub","/tmp/alice/twokey.pub"]},"2":{"authorized":["/tmp/bob/id_rsa.pub"]}}'
    loader = DataLoader()

# Generated at 2022-06-23 12:12:21.108426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    source = '''
- name: peter
  authorized:
    - ~/peter_id_rsa.pub
  mysql:
    password: peterpasswd
    hosts:
      - "%"
      - "127.0.0.1"
      - "::1"
      - "localhost"
    privs:
      - "*.*:SELECT"
      - "DB1.*:ALL"
- name: paul
  authorized:
    - ~/paul_id_rsa.pub
  mysql:
    password: paulpasswd
    hosts:
      - "%"
      - "127.0.0.1"
      - "::1"
      - "localhost"
    privs:
      - "*.*:SELECT"
      - "DB1.*:ALL"
    '''

# Generated at 2022-06-23 12:12:23.801112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms=[['sergey'], 'name']
    lookup_obj=LookupModule()
    result=lookup_obj.run(terms=terms, variables={})
    print(result)

# Generated at 2022-06-23 12:12:36.333900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Method LookupModule.run is tested
    """
    
    # import needed modules and functions
    import tempfile
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    
    
    # create a temporary file and write some YAML content to it
    fd, yaml_file = tempfile.mkstemp()
    f = open(yaml_file, "wb")

# Generated at 2022-06-23 12:12:47.080489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    terms = {}
    variables = {}
    lookup = LookupModule(loader=None, templar=None, **variables)

# Generated at 2022-06-23 12:12:58.611538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule of module subelements.
    """
    import pytest
    from ansible.module_utils._text import to_bytes

    def _test_run_lookup(terms):
        from ansible.module_utils.facts.system.distribution import Distribution

        distribution = Distribution(ignore_fqdn=True)
        distribution.set_facts({})

        lookup = LookupModule()
        lookup.get_basedir = lambda *args: ''
        lookup.set_options({})

# Generated at 2022-06-23 12:13:09.428860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("loaded, now testing")
    l =  LookupModule()
    print(l)

    users = [{'name': 'Alice', 'authorized': ['/a/b/c']}, {'name': 'Bob', 'authorized': ['/d/e/f']}]
    terms = users, 'authorized', {}
    info = l.run(terms=terms, variables=None)
    print(info)
    assert info == [({'name': 'Alice', 'authorized': ['/a/b/c']}, '/a/b/c'), ({'name': 'Bob', 'authorized': ['/d/e/f']}, '/d/e/f')]

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:13:11.481988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    "Unit test for constructor of class LookupModule"
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:13:13.125861
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test construction
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 12:13:15.537417
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # simple test on explicit construction of LookupModule
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:13:26.494596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = [
        [{'a': '1', 'b': '2', 'c': {'d': '3'}}],
        'c.d',
    ]
    assert lm.run(terms, None) == [[{'a': '1', 'b': '2', 'c': {'d': '3'}}, u'3']]

    lm = LookupModule()
    terms = [
        [{'a': '1', 'b': '2', 'c': {'d': '3'}}],
        'c.e',
        {'skip_missing': True}
    ]
    assert lm.run(terms, None) == []
    lm = LookupModule()

# Generated at 2022-06-23 12:13:37.483034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test method run of class LookupModule """

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # first test for regular subelements

# Generated at 2022-06-23 12:13:38.376027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-23 12:13:40.653505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    c = LookupModule(loader=None)
    c = LookupModule(loader=None, templar=None)


# Generated at 2022-06-23 12:13:49.198305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import imp
    import os
    import sys
    import errno
    sys.modules['__main__'] = imp.new_module('__main__')
    sys.modules['__main__'].__file__ = 'ansible_subelements'
    sys.modules['__main__'].ansible_module = imp.new_module('ansible_module')
    sys.modules['__main__'].ansible_module.params = {}
    sys.modules['__main__'].ansible_module.params['vars'] = {}
    import ansible_subelements
    sys.modules['ansible_subelements.LookupModule'] = ansible_subelements.LookupModule
    sys.modules['ansible_subelements.AnsibleError'] = ansible_subelements.AnsibleError
    sys

# Generated at 2022-06-23 12:13:59.978069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-23 12:14:10.918034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # 'lazy' import for unit testing, as we do not need the whole Ansible plug-in infrastructure
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode, AnsibleSequence
    from ansible.module_utils.six import string_types

    def _check_list_of_tuples(elements):
        if not isinstance(elements, list):
            raise Exception("Expected list, got %s" % elements)
        for element in elements:
            if not isinstance(element, tuple):
                raise Exception("Expected list of tuples, got %s" % elements)

    def _assert(actual, expected):
        if actual != expected:
            raise Exception("Expected '%s', got '%s'" % (expected, actual))


# Generated at 2022-06-23 12:14:18.107203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def dummy_runner(self, terms, **kwargs):
        # terms = terms.split()
        # terms[0] = list(terms[0])  # save for later
        for term in terms:
            if isinstance(term, list) or isinstance(term, tuple):
                # convert from list to tuple
                term = (term[0],) + tuple(term[1])
                # convert from tuple to list
                term = [term[0]] + list(term[1:])
        return terms
    LookupModule.run = dummy_runner


# Unit tests for subelements lookup

# Generated at 2022-06-23 12:14:29.238230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    import ansible.template
    import os

    templatePath = os.path.join(os.path.split(ansible.template.__file__)[0], 'plugins', 'lookup', 'subelements.py')
    with open(templatePath) as f:
        code = compile(f.read(), templatePath, 'exec')
        exec(code, globals(), locals())

    # test non-dict first argument
    #expected = False
    #actual = _raise_terms_error()
    #assert expected == actual

    # test dict first argument
    #expected = True
    #actual = _raise_terms_error()
    #assert expected == actual

# Generated at 2022-06-23 12:14:40.216479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test the method run of class LookupModule
    """
    module = LookupModule()

# Generated at 2022-06-23 12:14:41.856937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-23 12:14:52.184531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.playbook.play_context import PlayContext

    mocks = {
        'PlayContext._attributes': ['_hostvars'],
        'PlayContext._hostvars': {},
        'get_all_plugin_loaders': lambda: [],
        'get_loader': lambda p: None,
    }

    m = LookupModule(mocks)
    assert(m.run([[{"a": {"b": "c"}}, {"a": {"b": "d"}}], "a.b"], None) == ["c", "d"])

# Generated at 2022-06-23 12:15:02.510153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_run_1: subelements a list of hashes with a given (nested sub-)key inside of those records
    lookup_obj = LookupModule()

# Generated at 2022-06-23 12:15:10.007896
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import tempfile
    import os
    import shutil
    import stat
    import json
    import pytest

    # create the files this test case needs
    test_dir = tempfile.mkdtemp(prefix='ansible-test-lookup-subelements')
    test_dir_path = os.path.dirname(test_dir)
    test_dir_name = os.path.basename(test_dir)
    test_file = test_dir + '/yamltest.yml'
    yaml_content = {'a': 'simple', 'b': [1, 2, 3], 'c': {'d': 'complex'}}

    with open(test_file, 'w') as f:
        json.dump(yaml_content, f)


# Generated at 2022-06-23 12:15:20.685352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    assert LookupModule().run('', '', '',
        _terms=[
            [
                'datastructure',
                'accesskey'
            ]
        ],
        skip_missing=False
    ) == [
        'datastructure',
        'accesskey'
    ]

    assert LookupModule().run('', '', '',
        _terms=[
            [
                'datastructure',
                'accesskey'
            ]
        ]
    ) == [
        'datastructure',
        'accesskey'
    ]


# Generated at 2022-06-23 12:15:26.588487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Test the constructor of class LookupModule. """
    lookup = LookupModule()
    result = lookup.run([
        [
            {
                'bob': {
                    'authorized': [
                        '/tmp/bob/id_rsa.pub',
                        '/tmp/bob/id_rsa1.pub'
                    ]
                },
                'alice': {
                    'authorized': [
                        '/tmp/alice/id_rsa.pub',
                        '/tmp/alice/id_rsa1.pub'
                    ]
                }
            },
            'authorized',
            {
                'skip_missing': True
            }
        ]
    ])

# Generated at 2022-06-23 12:15:27.931479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert (instance, "but was") is not None

# Generated at 2022-06-23 12:15:36.016873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test wrong number of terms
    terms = ["a", "b"]
    try:
        lookup.run(terms, {})
        assert False
    except AnsibleError:
        pass
    terms = ["a", "b", "c", "d"]
    try:
        lookup.run(terms, {})
        assert False
    except AnsibleError:
        pass

    # test wrong type of terms
    terms = ["a", 1]
    try:
        lookup.run(terms, {})
        assert False
    except AnsibleError:
        pass
    terms = ["a", 1, 2]
    try:
        lookup.run(terms, {})
        assert False
    except AnsibleError:
        pass
    terms = [["a"], 1, 2]

# Generated at 2022-06-23 12:15:41.132512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyTemplar(object):
        def __init__(self, *args, **kwargs):
            pass

        def template(self, x):
            return x

    class DummyLoader(object):
        pass

    import pytest
    terms = [
        [{'first': '1'}, {'second': '2'}],
        'first',
        {'skip_missing': 'False'},
    ]
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._loader = DummyLoader()

    subelements = lookup_module.run(terms, dict())
    assert len(subelements) == 2
    assert subelements[0] == (terms[0][0], terms[0][0][terms[1]])
   

# Generated at 2022-06-23 12:15:49.994814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test result of method run
    '''


# Generated at 2022-06-23 12:16:01.956775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l.run({}, {}), list)
    assert l.run({}, {}) == []
    assert l.run(
        [[{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}], 'authorized'], {}
    ) == [({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/onekey.pub'),
           ({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/twokey.pub')]

# Generated at 2022-06-23 12:16:11.637213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a fake AnsibleModule object. To minimize the unit test size,
    # the AnsibleModule class is not tested here.
    def get_init_args():
        pass

    module = type('module', (object,), {'get_init_args': get_init_args, 'params': {}})()

    # Create a fake AnsibleModule object. To minimize the unit test size,
    # the AnsibleModule class is not tested here.
    def get_init_args():
        pass
    module = type('module', (object,), {'get_init_args': get_init_args, 'params': {}})()

    # Create a fake templar object. To minimize the unit test size, the
    # AnsibleTemplar class is not tested here.
    def template(data, **kwargs):
        return data

# Generated at 2022-06-23 12:16:22.229640
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:16:23.117518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "TODO"

# Generated at 2022-06-23 12:16:32.774467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # Check error for case when number of terms is not exactly 2 or 3
    error_msg = "subelements lookup expects a list of two or three items, "
    try:
        lookup_module.run(terms=[], variables={}, **{})
        assert False
    except AnsibleError as e:
        if not isinstance(e, AnsibleError) or error_msg not in str(e):
            assert False
    # Check error for case when first item is not dict or list
    error_msg = "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

# Generated at 2022-06-23 12:16:42.648005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # create instance
    lookup = LookupModule()

    # create test variables
    terms = [
      { 'skipped':'False', 'name':'alice', 'authorized': ['/tmp/alice/onekey.pub','/tmp/alice/twokey.pub'] },
      { 'skipped':'False', 'name':'bob', 'authorized': ['/tmp/bob/id_rsa.pub'] },
      'authorized']

    # call method run
    output = lookup.run(terms, {})

    # evaluate output
    assert isinstance(output, list)
    assert len(output)==4
    assert len(output[0])==2
    assert len(output[1])==2
    assert len(output[2])==2
    assert len(output[3])==2

# Generated at 2022-06-23 12:16:54.080376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ############################################################################
    # test_simple_dict
    elementlist = {
        'Key1': {'listkey1': ['value1', 'value2']},
        'Key2': {'listkey1': ['value3', 'value4']},
    }
    terms = [
        elementlist,
        'listkey1',
        {'skip_missing': True}
    ]
    ret = lookup.run(terms, {})
    assert ret == [
        ('value1',),
        ('value2',),
        ('value3',),
        ('value4',),
    ]

    ############################################################################
    # test_nested_skip_missing

# Generated at 2022-06-23 12:17:04.395899
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.lookup_plugins.subelements import LookupModule


# Generated at 2022-06-23 12:17:12.868716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class LookupParameters(object):
        def __init__(self, loader, templar, params):
            self._loader = loader
            self._templar = templar
            self.params = params

    if PY3:
        unicode = str
    # Initialize a LookupModule instance
    lookup_module = LookupModule()
    # Initialize a AnsibleDict object
    ansible_dict = AnsibleBaseYAMLObject()

# Generated at 2022-06-23 12:17:14.296204
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:17:22.797997
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:17:32.051456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock object for templar
    class _Templar(object):
        def __init__(self, variables, loader=None):
            self.variables = variables
            self.loader = loader
        def template(self, term):
            return term
    # Create mock object for loader
    class _Loader(object):
        def __init__(self, basedir=None):
            self.basedir = basedir
        def get_basedir(self, varname):
            return "/" + varname
    # Create mock object for templar
    templar = _Templar(None)
    loader = _Loader()

    # Instantiate class
    lookup = LookupModule()
    # Set templar and loader
    lookup._templar = templar
    lookup._loader = loader

    # Skip missing is

# Generated at 2022-06-23 12:17:42.234511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the AnsibleModule object
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    # create AnsibleModule instance to be used in Lookup
    am = AnsibleModule(
        # incoming parameters
        users="users",
        # imported used modules
        to_nice_yaml="ansible.module_utils.basic._ANSIBLE_ARGS",
    )

    # get the module to test
    lm = LookupModule()

    # initialize module
    # this is done to sync the __init__ part of the module with the parameters
    lm.set_options({
        "users": "users"
    })

    # set the AnsibleModule object on lm
    lm.set_ansible_module(am)

    # get parameters values


# Generated at 2022-06-23 12:17:54.292451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    users = [
        {'name': 'alice',
         'mysql': {
             'password': 'mysql-password',
             'hosts': [
                 '%',
                 '127.0.0.1',
                 '::1',
                 'localhost'
             ],
             'privs': [
                 '*.*:SELECT',
                 'DB1.*:ALL'
             ]
         }
        },
        {'name': 'bob',
         'mysql': {
             'password': 'other-mysql-password',
             'hosts': [
                 'db1'
             ],
             'privs': [
                 '*.*:SELECT',
                 'DB2.*:ALL'
             ]
         }
        }
    ]

    lookup_module = LookupModule()
    result = lookup

# Generated at 2022-06-23 12:18:05.795900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar()
    l._loader = DummyLoader()
    assert l.run(
        [],
        {}
    ) == []

    assert l.run(
        [{'skipped': False, 'key': 'value'}],
        {}
    ) == []

    assert l.run(
        [{'skipped': True}],
        {}
    ) == []

    assert l.run(
        [{'skipped': False, 'key': 'value'}],
        {},
        skip_missing=True,
    ) == []

    assert l.run(
        [{'skipped': False, 'key': 'value'}],
        {},
        skip_missing=False,
    ) == []

    assert l.run

# Generated at 2022-06-23 12:18:17.167379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test for correct return value
    term = [{'skipped': False, 'ansible_facts': {'test_value': [1, 2, 3]}, 'changed': False, 'ansible_module_generated': True, 'invocation': {'module_name': 'setup'}, '_ansible_no_log': False}, 'ansible_facts.test_value']
    value = lookup.run(term, None)
    assert isinstance(value, list)
    assert len(value) == 3
    assert value[0][0]['skipped'] is False
    assert value[0][0]['ansible_facts'] == {'test_value': [1, 2, 3]}
    assert value[0][0]['changed'] is False

# Generated at 2022-06-23 12:18:28.175928
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Module LookupModule simulate class ansible.plugins.lookup.lookup_plugins.LookupBase
    class LookupModule(object):
        def __init__(self):
            # testinit
            self._templar = None
            self._loader = None
        def _templar_from_module(self):
            return self._templar
        def _loader_from_module(self):
            return self._loader

    class AnsibleError(Exception):
        def __init__(self, msg):
            self.msg = msg

    class TestTemplate(object):
        pass

    # Unit test of class lookup_plugins.LookupModule used in method run of class lookup_plugins.LookupModule

# Generated at 2022-06-23 12:18:40.899308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import TestCase
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock, MagicMock

    class AnsibleModules(TestCase):

        def setUp(self):
            self.module = MagicMock()
            self.module.params = {}
            self.module.check_mode = False

    class AnsibleException(Exception):
        pass

    class TestLookupModule(AnsibleModules):

        def setUp(self):
            super(TestLookupModule, self).setUp()
            self.lookup = LookupModule()

        def test_get_blank_terms(self):
            r = self.lookup.run([], [], variables=None)
            self.assertEqual([], r)


# Generated at 2022-06-23 12:18:48.348426
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Empty list of terms
    l = LookupModule()
    l.run([], None)

    # List of terms with length 2
    l.run([['one','two'], 'key'], None)

    # List of terms with length 3
    l.run([['one','two'], 'key', {'skip_missing': False}], None)

    # List of terms with length 4
    try:
        l.run(['one', 'two', 'three', 'four'], None)
    except AnsibleError as e:
        assert 'subelements lookup expects a list of two or three items' in to_text(e)

    # First term is not list
    try:
        l.run(['one', 'two'], None)
    except AnsibleError as e:
        assert "First term should be a list"

# Generated at 2022-06-23 12:18:50.280793
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-23 12:19:00.334043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3, StringIO
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO
    from ansible.errors import AnsibleError
    from ansible.module_utils import basic
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    basic._ANSIBLE_ARGS = None

    # test_dict_scalar_to_list_ok
    terms = [{'one': {'value': 'value-one'}}, 'value']
    expected = [('value',)]
    actual = LookupModule().run(terms, None)
    assert actual == expected



# Generated at 2022-06-23 12:19:05.142815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """unit test to test constructor of class LookupModule"""
    module = LookupModule()
    data = '{"a":"b"}'
    terms = ['a', 'b']
    ret = module.run(terms, data)
    assert ret is not None, "Failed to run subelements lookup"


# Generated at 2022-06-23 12:19:07.392313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    LookupModule constructor test
    """
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:19:15.980907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    test_terms = ['users', 'mysql.hosts']
    test_terms2 = [ {'users': 'dummydict'}, 'non-existing-subkey']
    test_terms3 = [ {'users': ['dummylist']}, 'non-existing-subkey']
    test_terms4 = [ {'users': 'dummydict'}, 'non-existing-subkey', {}]
    test_terms5 = [ {'users': 'dummydict'}, 'non-existing-subkey', {'skip_missing': True}]
    test_terms6 = [ {'users': 'dummydict'}, 'non-existing-subkey', {'skip_missing': False}]

# Generated at 2022-06-23 12:19:21.503978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [{'local': [{'ip': '192.168.0.100', 'name': 'web_server'}]}, 'ip']
    result = lookup_plugin.run(terms, None, inject=None)
    assert result == [('192.168.0.100',)]

# Generated at 2022-06-23 12:19:31.664437
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Mock class for module_utils.parsing.convert_bool
    class MockBoolModule:
        def boolean(self, key, strict):
            return True

    # Mock class for module_utils.basic.AnsibleModule
    class MockAnsibleModule:
        def fail_json(self, msg):
            raise Exception(msg)

    # Mock class for module_utils.parsing.convert_bool
    class MockTemplar:
        def template(self, key):
            return key

    # Mock class for jinja2.Environment
    class MockLoader:
        def get_basedir(self, key):
            return key

    # Mock class for module_utils.parsing.convert_bool
    class MockPlugin:
        def lookup(self, key, key2, key3):
            return key

# Generated at 2022-06-23 12:19:42.682661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .lookup_mocks import LookupModuleMock
    lookup = LookupModuleMock.mock_lookup_plugin(LookupModule)
    lookup.set_options('')

    # check for wrong input
    try:
        lookup._run_terms([])
        assert False
    except AnsibleError:
        pass
    try:
        lookup._run_terms(['wrong input', 'key'])
        assert False
    except AnsibleError:
        pass
    try:
        lookup._run_terms({'wrong input': ''})
        assert False
    except AnsibleError:
        pass
    try:
        lookup._run_terms(['wrong input', 1])
        assert False
    except AnsibleError:
        pass

    # check for standard input

# Generated at 2022-06-23 12:19:44.819122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible.utils.listify_lookup_plugin_terms is tested in test_listify_lookup_plugin_terms
    pass

# Generated at 2022-06-23 12:19:46.256788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l


# Generated at 2022-06-23 12:19:56.959609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This tests the constructor of LookupModule using the same test
    as for the old lookup module to get the same results.
    """

    lookup_test = LookupModule()
    the_test = {
        u'name': u'alice',
        u'authorized': [u'/tmp/alice/onekey.pub', u'/tmp/alice/twokey.pub'],
        u'mysql': {
            u'password': u'mysql-password',
            u'hosts': [u'%', u'127.0.0.1', u'::1', u'localhost'],
            u'privs': [u'*.*:SELECT', u'DB1.*:ALL']
        },
        u'groups': [u'wheel']
    }
    the_subkey = u'authorized'


# Generated at 2022-06-23 12:19:58.692609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Unit test with pre-added data to the lookup module

# Generated at 2022-06-23 12:20:08.701427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [
        [{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'name': 'alice'},
         {'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob'}],
        'authorized']
    variables = {
        u'ansible_check_mode': False,
        u'ansible_verbosity': 0,
        u'inventory_hostname': u'ansible-host',
        u'inventory_hostname_short': u'ansible-host'
    }
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)