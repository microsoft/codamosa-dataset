

# Generated at 2022-06-23 12:10:09.746605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # can't be tested without mocking out the whole rest of Ansible
    pass

# Generated at 2022-06-23 12:10:16.604888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = []
    terms.append([{'id': 1, 'a': {'b': [1,2]}}, {'id': 2, 'a': {'b': [3,4,5]}}])
    terms.append('a.b')

    # Execute test
    ret = LookupModule.run(terms)

    # Assert result
    assert isinstance(ret, list)
    assert len(ret) == 5
    for i in ret:
        assert len(i) == 2
        assert isinstance(i[0], dict)
        assert isinstance(i[1], int)

# Generated at 2022-06-23 12:10:26.876073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module._loader = MockLoader()

# Generated at 2022-06-23 12:10:35.711708
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:10:45.097911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    class VarsModule(object):
        def __init__(self, variables=None):
            self.variables = variables or {}

        def get_vars(self, loader, path, entities, cache=True):
            return self.variables

    vars_mock = VarsModule()
    # vars_mock = VarsModule({'users': 'test'})

    loader_mock = DataLoader()


# Generated at 2022-06-23 12:10:47.061611
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()


# Generated at 2022-06-23 12:10:57.709494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # import dict of each testcase
    from ansible.errors import AnsibleError

    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.utils.listify import listify_lookup_plugin_terms

    testcases = get_testcases()

    for casename, testcase in testcases.items():
        # check for required keys
        for arg in ('descr', 'terms', 'expected'):
            if arg not in testcase:
                pytest.fail("testcase %s misses key %s" % (casename, arg))
        if 'exception' not in testcase and 'result' not in testcase:
            pytest.fail("testcase %s needs a key result or exception" % casename)

       

# Generated at 2022-06-23 12:11:07.409884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit tests require plugins to be loaded
    # pylint: disable=import-error,no-name-in-module
    from ansible.plugins.loader import lookup_loader

    # construct LookupModule with dummy loader obj
    lm = LookupModule(DummyLoader())

    # construct input data
    elementlist = [
        {"key1": ["a", "b", "c"], "key2": 2},
        {"key1": ["d", "e", "f"], "key2": {"key3": 6}}
    ]
    # test getting subelements of all list items
    # second argument is a string holding the subkey
    subkey = "key1"
    terms = [elementlist, subkey]
    ret = lm.run(terms, {})

# Generated at 2022-06-23 12:11:17.511084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test method LookupModule.run
    """
    #
    # initialisation
    #
    TERMS = "TERMS"
    VARIABLES = "VARIABLES"
    KWARGS = "KWARGS"

    # mocking classes
    class AnsibleErrorMock:
        def __init__(self, message):
            self.message = message
        def __str__(self):
            return str(self.message)

    class LookupBaseMock(LookupBase):
        def __init__(self):
            super(LookupBaseMock, self).__init__()
            self.debug_called = False
            self.debug_message = ""
            self.warning_called = False
            self.warning_message = ""
            self.fail_called = False
            self.fail

# Generated at 2022-06-23 12:11:19.737327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert hasattr(subelements, 'run')


# Generated at 2022-06-23 12:11:29.577965
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock templar for resolving test vars
    class MockTemplar:
        def __init__(self):
            self.test_vars = {"testdict": {"testkey1": 'val1', "testkey2": 'val2'}, "testlist": ['val1', 'val2'], "teststr": 'testVal'}
        def template(self, src, preserve_trailing_newlines=True, **kwargs):
            if not isinstance(src, basestring):
                raise TypeError
            if src in self.test_vars:
                return self.test_vars[src]
            else:
                raise AnsibleError("failed to template due to undefined variable")

    # create mock loader

# Generated at 2022-06-23 12:11:40.210317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup = LookupModule()
    q = mylookup.run
    # basic test
    terms = [
        [
            {'name': 'user1', 'groups': ['wheel', 'dbadmin'], 'other_key': {}},
            {'name': 'user2', 'groups': ['wheel', 'dbadmin']},
        ],
        'groups',
    ]

# Generated at 2022-06-23 12:11:50.670806
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test empty terms
    terms = []
    assert len(terms) == 0
    lookup = LookupModule()
    lookup._templar = mock_templar()
    # passing an empty terms list should result in a _raise_terms_error exception
    try:
        lookup.run(terms=terms, variables=dict())
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e)
    else:
        assert False

    # test non-list terms
    terms = 'foo'
    assert isinstance(terms, string_types)
    lookup = LookupModule()
    lookup._templar = mock_templar()
    # passing an non-list terms list should result in a _raise_terms_error exception

# Generated at 2022-06-23 12:12:00.240134
# Unit test for constructor of class LookupModule
def test_LookupModule():

    my_variable_manager = {}

    # not a list
    assert LookupModule().run({"it is not a list": "it is not a list"}, my_variable_manager) is None

    # not a list
    assert LookupModule().run("it is not a list", my_variable_manager) is None

    # missing first term
    assert LookupModule().run([], my_variable_manager) is None

    # missing second term
    assert LookupModule().run(["it is a list",], my_variable_manager) is None

    # both terms are there
    assert LookupModule().run(["it is a list", "it is a string"], my_variable_manager) is None

# Generated at 2022-06-23 12:12:09.433425
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init
    test_user_dict1 = {'name': 'Alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}
    test_user_dict2 = {'name': 'Bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    test_user_list = [test_user_dict1, test_user_dict2]
    terms = test_user_list, 'authorized'

    # test
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=None)

    # assert

# Generated at 2022-06-23 12:12:16.199331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test error good input

# Generated at 2022-06-23 12:12:26.272117
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    L = LookupModule()

    base = [
        {"name": "alice", "groups": ["wheel", "dev"], "authorized": ["/tmp/alice/onekey.pub"]},
        {"name": "bob", "groups": ["wheel"], "authorized": ["/tmp/bob/id_rsa.pub"]}
    ]

    assert L.run([base, "authorized"], None) == [(base[0], base[0]['authorized'][0]), (base[1], base[1]['authorized'][0])]
    assert L.run([base, "groups"], None) == [(base[0], base[0]['groups'][0]), (base[0], base[0]['groups'][1]), (base[1], base[1]['groups'][0])]


# Generated at 2022-06-23 12:12:38.724049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Check correct behaviour with a list

# Generated at 2022-06-23 12:12:42.397639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) > 0

    lookup_module = LookupModule()
    lookup_module.run(terms=dict(key="value", key2="value2"), variables=dict(variable="value"))



# Generated at 2022-06-23 12:12:51.214906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # see example section in module documentation
    def _assert(cond):
        if not cond:
            raise AssertionError
    # should raise error
    try:
        subelements = LookupModule()
        subelements.run([], None)
        _assert(False)  # do not get to this point
    except AnsibleError as e:
        _assert(str(e) == 'subelements lookup expects a list of two or three items')
    # should raise error

# Generated at 2022-06-23 12:13:03.350240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.template

    lookup = LookupModule()
    # create an empty environment
    lookup._templar = ansible.utils.template.AnsibleTemplar()

    # test with a list (two lists of one item)
    terms = [{'elementlist': [{'authorized': ['/some/path', '/some/other/path'], 'name': 'alice'}, {'authorized': ['/some/other/path'], 'name': 'bob'}], 'subkey': 'authorized'}, {'skip_missing': True}]

# Generated at 2022-06-23 12:13:10.764978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = (
        [{'field1': 1, 'field2': {'subfield1': 1, 'subfield2': 2}},
         {'field1': 3, 'field2': {'subfield1': 3, 'subfield2': 4}}],
        'field2.subfield1',
    )
    result = lm.run(terms, variables={})
    assert result == [(terms[0][0], 1), (terms[0][1], 3)]



# Generated at 2022-06-23 12:13:22.849315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = [None, "authorized", {'skip_missing': True}]

# Generated at 2022-06-23 12:13:31.907481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import os
    import shutil
    import copy

    loader = 'lookup_plugins/subelements.py'
    lookup = 'subelements'
    path1 = os.path.join('lib', 'ansible', 'plugins', 'lookup')
    path2 = os.path.join('lib', 'ansible', 'modules')

    # we need to see both the lookup plugin and module fqpaths
    sys.path.insert(0, path1)
    sys.path.insert(0, path2)
    test_subelements = __import__(loader.split('/')[0])

    # set up test data

# Generated at 2022-06-23 12:13:32.879334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('TODO: test LookupModule')

# Generated at 2022-06-23 12:13:41.565585
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([['a', 'b'],'c']) == []     # missing key
    assert lookup.run([{'a': {'c': 'd'}},'c']) == [({'a': {'c': 'd'}}, 'd')]
    assert lookup.run([{'a': {'c': 'd'}, 'e': {'c': True}},'c']) == [({'a': {'c': 'd'}, 'e': {'c': True}}, 'd'), ({'a': {'c': 'd'}, 'e': {'c': True}}, True)]

# Generated at 2022-06-23 12:13:52.232779
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    # Test look up term validation and error handling

# Generated at 2022-06-23 12:14:03.819241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({})
    lookup_plugin._templar = None
    lookup_plugin._loader = loader
    lookup_plugin._play_context = play_context
    lookup_plugin._inventory = inv
    return lookup_plugin


# Generated at 2022-06-23 12:14:05.864326
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:14:16.670283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    # Initialize objects as needed
    loader = DataLoader()
    lookup = LookupModule()
    lookup.set_loader(loader)

    terms = [1]
    lookup.run(terms, {})

    terms = None
    lookup.run(terms, {})

    terms = [1,2,3,4]
    lookup.run(terms, {})

    # Test case against simple list
    terms = [[1,2,3,4], 'listitem', {'skip_missing': True}]
    ret = lookup.run(terms, {})
    assert ret == [(1, 2), (2, 3), (3, 4)]

    # Test case agains skipping if not found

# Generated at 2022-06-23 12:14:18.299740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:14:19.632750
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm

# Generated at 2022-06-23 12:14:31.274181
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = basic.AnsibleTemplar()
    lookup_module = LookupModule(loader=loader, templar=templar)
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=1, variables=dict())
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=[1], variables=dict())
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=['1', 1], variables=dict())

# Generated at 2022-06-23 12:14:33.352033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: not yet implemented (https://github.com/ansible/ansible/issues/25931)
    pass

# Generated at 2022-06-23 12:14:44.708888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    def _run_test(terms, expected, variables=None):
        if variables is None:
            variables = {}
        assert expected == LookupModule().run(terms, variables)


# Generated at 2022-06-23 12:14:46.084320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:14:47.273837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:14:58.573523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    lookup_instance = LookupModule()
    templar_instance = Templar(loader=DataLoader(), variables=combine_vars(dict(), ansible.__dict__), fail_on_undefined=False)


# Generated at 2022-06-23 12:15:05.102927
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._templar = Dummy()
    l._loader = Dummy()
    l._loader._templar = l._templar
    terms = [{'element1': 'e1', 'element2': 'e2'}, 'element1']
    variables = {}
    ret = l.run(terms, variables, variable_manager=Dummy(), loader=l._loader)
    assert ret[0] == ('e1',)
    assert ret[1] == ('e2',)


# Generated at 2022-06-23 12:15:09.054173
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test: Constructor
    lm = LookupModule()

    # Test: No exception for a valid subelements call
    terms = [["a"], "b"]
    vars = {}

    lm.run(terms, vars, inject=dict())
    terms = [["a"], "b", {'skip_missing': True}]
    lm.run(terms, vars, inject=dict())

# Generated at 2022-06-23 12:15:19.689780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils._text import to_bytes, to_text

    # initialization
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 12:15:28.612710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_ansible_module = MagicMock(lookup_plugin_terms='mock_lookup_plugin_terms', variables='mock_variables')
    mock_ansible_module.params.get.return_value = 'mock_params_get'
    mock_ansible_module.run_command.return_value = {'rc': 0, 'stdout': 'mock_stdout'}
    mock_ansible_module.run_command.side_effect = lambda x, **kwargs: {'whoami': {'rc': 0, 'stdout': 'mock_stdout'}}.get(x[0], None)
    mock_ansible_module.fail_json.return_value = 'mock_fail_json'
    mock_ansible_module.warn.return_value = 'mock_warn'

# Generated at 2022-06-23 12:15:32.677574
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Dummy class for testing only 
    class DummyLoader(object):
        pass
    loader = DummyLoader()
    lookup_plugin = LookupModule(loader=loader, templar=loader)
    # Check for proper call of superclass constructor
    assert lookup_plugin._loader is loader
    assert lookup_plugin._templar is loader


# Generated at 2022-06-23 12:15:34.496371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert 2 <= len(lookup.get_options()) <= 3
    assert lookup._templar is None


# Generated at 2022-06-23 12:15:36.400678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:15:47.653007
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import unittest
    import tempfile


    class _Record(object):
        """A simple object that displays when str() is called"""
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __str__(self):
            return "Record(%s, %s)" % (self.args, self.kwargs)

    class TestLookupModule(unittest.TestCase):
        """Unit tests for lookup module subelements.py"""

        def setUp(self):
            self.lookup_module = LookupModule()

# Generated at 2022-06-23 12:15:53.135797
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()

    # Test the constructor of LookupModule
    test_elem = ["a", "b", {"skip_missing": "1"}]
    assert lookup_class.run(test_elem,dict(), **dict()) == [], "ERROR: Lookup constructor is broken"

# Generated at 2022-06-23 12:16:03.696376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import os
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    import ansible.constants as C
    import json


# Generated at 2022-06-23 12:16:05.218147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 2 <= len(LookupModule.__doc__.split("\n")) <= 3

# Generated at 2022-06-23 12:16:13.217161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    SubelementsLookupModule = LookupModule()

    terms = ( \
        [
            {'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'authorized': ['/tmp/bob/id_rsa.pub']},
        ],
        'authorized'
        )
    result = SubelementsLookupModule.run(terms, dict())


# Generated at 2022-06-23 12:16:15.616241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # ensure the LookupModule class can be instanciated
    assert LookupModule(None, None)

# Generated at 2022-06-23 12:16:22.712368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    lookup = LookupModule()
    lookup._loader = loader
    lookup._templar = None
    lookup.set_options({})

    # init users var

# Generated at 2022-06-23 12:16:26.624875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run([[{'subelements': ['test', 'test', 'test'], 'test': 'test'}], 'subelements']).pop() == ['test', 'test', 'test']

# Generated at 2022-06-23 12:16:32.533130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    host_vars = dict(ansible_python_interpreter="/usr/bin/python3")
    test_lookup = LookupModule()
    test_lookup.set_options()
    test_lookup.set_environment(host_vars)
    assert isinstance(test_lookup, LookupModule)


# Generated at 2022-06-23 12:16:34.061915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()

    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 12:16:44.360889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare lookup
    lookup_plugin = LookupModule()

    # test with subelement pointing to list
    terms = [
        [
            {'name': 'alice', 'authorized': '/tmp/alice/id_rsa.pub'},
            {'name': 'bob', 'authorized': '/tmp/alice/id_rsa.pub'}
        ],
        'authorized'
    ]
    assert lookup_plugin.run(terms) == [('alice', '/tmp/alice/id_rsa.pub'), ('bob', '/tmp/alice/id_rsa.pub')]

    # test with subelement pointing to dictionary
    terms[1] = 'mysql'

# Generated at 2022-06-23 12:16:45.347093
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule))

# Generated at 2022-06-23 12:16:56.893520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Empty terms
    try:
        lookup_plugin.run([], None)
        assert False
    except AnsibleError:
        assert True

    # One term
    try:
        lookup_plugin.run(["test1"], None)
        assert False
    except AnsibleError:
        assert True

    # Terms of type integer
    try:
        lookup_plugin.run([1, 2, 3], None)
        assert False
    except AnsibleError:
        assert True

    # Terms of type non-string
    try:
        lookup_plugin.run([[], [], {}], None)
        assert False
    except AnsibleError:
        assert True

    # first term is string

# Generated at 2022-06-23 12:17:08.974040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms
    module = LookupModule()
    users = listify_lookup_plugin_terms([{
        'name': 'alice',
        'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
        'mysql': {
            'password': 'mysql-password',
            'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
            'privs': ['*.*:SELECT', 'DB1.*:ALL']
        }
    }])
    subelements = module.run([users, 'authorized'], None)

# Generated at 2022-06-23 12:17:10.349735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:17:20.197694
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prepare class instances
    test_loader = DictDataLoader({
        'foobar': '{"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"], "mysql": {'
                   '"password": "mysql-password", "hosts": ["%", "127.0.0.1", "::1", "localhost"], "privs": ["*.*:SELEC'
                   'T", "DB1.*:ALL"]}, "groups": ["wheel"]}',
        '/tmp/alice/onekey.pub': 'ssh-rsa AAAAB3Nza...QQ== (pubkey)',
        '/tmp/alice/twokey.pub': 'ssh-rsa AAAAB3Nza...FF== (pubkey)'
    })
   

# Generated at 2022-06-23 12:17:30.302733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    lookup = LookupModule()
    testfolder = os.path.dirname(os.path.abspath(__file__))
    lookup._loader.set_basedir(testfolder)


# Generated at 2022-06-23 12:17:41.618381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib

    class Options(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Runner(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class PlayContext(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    context = PlayContext(vault_password='secret')
    templar = Templar(loader=DataLoader())
    templar.set_available_variables(variables=dict(foo='bar'))
   

# Generated at 2022-06-23 12:17:53.589558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Patch for AnsibleModule
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.listify import listify_lookup_plugin_terms_flat

    def mock_listify_lookup_plugin_terms(terms, templar=None, loader=None):
        return terms

    listify_lookup_plugin_terms = mock_listify_lookup_plugin_terms
    listify_lookup_plugin_terms_flat = mock_listify_lookup_plugin_terms

    # Patch for AnsibleError
    def mock_AnsibleError(msg):
        pass

    AnsibleError = mock_AnsibleError

    # Patch for template

# Generated at 2022-06-23 12:17:54.996331
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:18:06.906020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # test input errors
    #  - expected: a list of 2 or 3 elements is expected
    for num_elements in [0, 1, 4]:
        args = [None] * num_elements
        try:
            lm.run(terms=args,
                   variables=None)
            assert False, "AnsibleError not raised"
        except AnsibleError as e:
            assert e.message == "subelements lookup expects a list of two or three items, "

    #  - expected: the first element should be a list or a dict

# Generated at 2022-06-23 12:18:17.767573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    run_method = getattr(lu, 'run')
    terms = [
        [{'key': 'value'}, {'key2': 'value2'}],
        'key'
    ]

    ret = run_method(terms, {})
    assert ret[0][0] == {'key': 'value'} and ret[0][1] == 'value'
    assert ret[1][0] == {'key2': 'value2'} and ret[1][1] == 'value2'

    terms = [
        [{'key': {'key2': 'value2'}}, {'key3': {'key4': 'value4'}}],
        'key.key2'
    ]
    ret = run_method(terms, {})

# Generated at 2022-06-23 12:18:28.664513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test terms handling
    module = LookupModule()
    try:
        module.run([1, 2, 3, 4, 5])
    except AnsibleError as e:
        assert 'subelements lookup expects a list of two or three items' in str(e)
    try:
        module.run(['', ''])
    except AnsibleError as e:
        assert 'first a dict or a list, second a string pointing to the subkey' in str(e)
    try:
        module.run([{}, ''])
    except AnsibleError as e:
        assert "subelements lookup expects a dictionary, got '{}'" in str(e)

# Generated at 2022-06-23 12:18:41.305352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # we are testing the method run of the class LookupModule
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import json


# Generated at 2022-06-23 12:18:45.318294
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # check if it is possible to load the class
    import ansible.plugins.lookup.subelements
    obj = ansible.plugins.lookup.subelements.LookupModule(None)
    assert obj



# Generated at 2022-06-23 12:18:56.674323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={
        'option1': 'value1',
        'option2': 'value2',
        'task_vars': {
            'var1': 'value1'
        }
    })


# Generated at 2022-06-23 12:19:00.021270
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lm = LookupModule()
    assert hasattr(lm,'run')
    assert hasattr(lm,'_loader')
    assert hasattr(lm,'_templar')


# Generated at 2022-06-23 12:19:11.912007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Check to see if ansible.plugin.lookup.subelements.LookupModule.run has successfully passed its unit test. '''
    from ansible.module_utils.six import StringIO
    from ansible.plugins.lookup import LookupBase
    import ansible.module_utils.parsing.convert_bool
    import ansible.utils.listify
    import sys

    class __fake_module:
        ''' Pretend to be a AnsibleModule object '''

        def __init__(self, **kwargs):
            ''' Pass any keyword arguments to the AnsibleModule constructor '''
            self.__dict__.update(kwargs)

        def fail_json(self, **kwargs):
            ''' Pretend to be a json error '''
            self.__dict__.update(kwargs)
           

# Generated at 2022-06-23 12:19:23.894171
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test different types of subelements

# Generated at 2022-06-23 12:19:25.600461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:19:33.737780
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create object with dummy environment
    lookup_obj = LookupModule()

    # Define empty list
    subelements = []

    # Create list of list of dictionaries
    arguments = [
        [
            {"key_1" : 0},
            {"key_1" : 1}
        ],
        ["key_1"]
    ]
    # Call run with dummy arguments
    subelements = lookup_obj.run(arguments, dict())
    assert len(subelements) == 2
    for item in subelements:
        assert isinstance(item, tuple)
        assert len(item) == 2
        assert item[0] in arguments[0]
        assert item[1] in item[0][arguments[1][0]]

    # Create list of dictionary

# Generated at 2022-06-23 12:19:36.642114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule.run() Test - with empty parameters"""
    module = LookupModule()
    assert module.run([[], '', {}], {}) == []


# Generated at 2022-06-23 12:19:47.357198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test function for LookupModule.run"""

    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types

    # First if we want to test the original ansible-lookup-plugin let's import it

    # First define our test users

# Generated at 2022-06-23 12:19:49.809145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    run() of class LookupModule is tested by test/unit/plugins/lookup/test_subelements.py
    """
    pass

# Generated at 2022-06-23 12:19:57.560204
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_class = LookupModule

    # check lookup terms - check number of terms
    # args: terms, variables, **kwargs
    terms = [
        'item0',  # list of hashes
        'item1',  # keyword (subkey)
    ]

    # Retrieve the expected 'ret' from ansible plugin
    expected = [
        {'key': 'value'},
    ]
    # test the lookup module retrieved by the plugin
    assert module_class().run(terms, {}, expected) == expected

    expected = []
    assert module_class().run(terms, {}, expected) == expected

# Generated at 2022-06-23 12:19:59.207231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Unit test of method run of class LookupModule

# Generated at 2022-06-23 12:20:09.073469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager

    lookup_class = lookup_loader.get('subelements')
    if not lookup_class:
        raise Exception("subelements lookup plugin could not be loaded")

    lookup = lookup_class(loader=None, templar=None, shared_loader_obj=None)

    # test mandatory parameters
    ###########################

    # failure - empty lookup