

# Generated at 2022-06-21 06:37:50.350541
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert subelements


# Generated at 2022-06-21 06:38:01.216364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2

    # setup mocks
    if PY2:
        import __builtin__
    else:
        import builtins
    def mock_AnsibleError(msg):
        raise Exception(msg)
    def mock_listify_lookup_plugin_terms(terms, templar=None, loader=None):
        return terms
    def mock_boolean(value, strict=False):
        return value
    if PY2:
        __builtin__.__dict__['AnsibleError'] = mock_AnsibleError
        __builtin__.__dict__['listify_lookup_plugin_terms'] = mock_listify_lookup_plugin_terms
        __builtin__.__dict__['boolean'] = mock_boolean

# Generated at 2022-06-21 06:38:08.457717
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:38:12.995194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        "{{ lookup('file', '../../../examples/subelements.yml') }}", 'mysql.hosts',
        "{{ lookup('file', 'flags.yml') }}",
    ]
    flags = {"skip_missing": False}

# Generated at 2022-06-21 06:38:24.681398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module._templar is None
    assert module._loader is None

    users = {
        'name': 'alice',
        'authorized': [
            '/tmp/alice/onekey.pub',
            '/tmp/alice/twokey.pub'
        ],
        'groups': [
            'wheel'
        ]
    }

    # use first two items of arguments (terms, variables)
    # third argument is the variable loader
    # fourth argument is the variable templar
    output = module.run([users, 'authorized'], None, loader=None, templar=None)

# Generated at 2022-06-21 06:38:33.284990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({})
    l.set_context({})

    # case1: normal case

# Generated at 2022-06-21 06:38:44.604184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    '''
    dict users = {
      "name": "alice",
      "authorized": [
        "/tmp/alice/onekey.pub",
        "/tmp/alice/twokey.pub"
      ],
      "groups": [
        "wheel"
      ]
    }
    list userlist = [ users ]
    '''
    users = { u"name": u"alice",
              u"authorized": [u"/tmp/alice/onekey.pub", u"/tmp/alice/twokey.pub"],
              u"groups": [u"wheel"] }
    userlist = [ users ]


# Generated at 2022-06-21 06:38:56.014481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    # read lookup_plugin.py from test folder
    lookup_plugin_file = open("test/lookup_plugins/subelements.py")
    lookup_plugin_content = lookup_plugin_file.read()
    lookup_plugin_file.close()

# Generated at 2022-06-21 06:38:59.610851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    c.run(terms=["key", 'test'], variables=['test'])

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:39:09.979738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test(terms, items):
        l = LookupModule()
        actual = l.run(terms, {})
        assert actual == items

    # real world test case
    test([dict(name="alice"), "authorized"], [({'name': 'alice'}, '/tmp/alice/onekey.pub'), ({'name': 'alice'}, '/tmp/alice/twokey.pub')])

    # sublist not found
    try:
        test([dict(name="alice"), "authorized2"], [])
    except AnsibleError as e:
        assert e.message == "could not find 'authorized2' key in iterated item '{u'name': u'alice'}'"

    # sublist not found (skip_missing)

# Generated at 2022-06-21 06:39:29.235880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    sys.path.append(".")
    import test
    import ansible.plugins.lookup.subelements
    lookup_module = ansible.plugins.lookup.subelements.LookupModule()


# Generated at 2022-06-21 06:39:41.291667
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:39:50.923857
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup mocks
    mock_AnsibleError = Mock(AnsibleError)
    mock_boolean = Mock(return_value=False)
    mock_isinstance = Mock(side_effect=[True, True, True, True, True, True, True, True, True, True])
    mock_listify_lookup_plugin_terms = Mock(return_value=True)
    mock_string_types = Mock()

    # Mocks to make it think a given object is an instance of a given class
    mock_isinstance_list = Mock(side_effect=lambda x, y:
        isinstance(x, list) if y is list else False)
    mock_isinstance_dict = Mock(side_effect=lambda x, y:
        isinstance(x, dict) if y is dict else False)
    mock_isinstance_

# Generated at 2022-06-21 06:40:02.362498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.parsing.convert_bool import boolean

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list=[])
    variable_manager.set_inventory(inventory)

    lookup_plugin = LookupModule()
    lookup_plugin.set_options({})
    lookup_plugin._load_name = 'subelements'

    play_context = PlayContext()
    play_context.setup_cache()
    lookup_plugin._templar = play_context._templ

# Generated at 2022-06-21 06:40:13.557690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    function = LookupModule()
    function._templar = MockTemplar()
    function._loader = MockLoader()

# Generated at 2022-06-21 06:40:15.389213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)



# Generated at 2022-06-21 06:40:17.833812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-21 06:40:29.244037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:40:37.071393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # instantiate class LookupModule
    lookup_instance = LookupModule()
    # call run() function
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'groups': ['wheel']}]
    result = lookup_instance.run([users, 'authorized'])
    # test result - expect a list of two tuples [(users[0], '/tmp/alice/onekey.pub'), (users[1], '/tmp/bob/id_rsa.pub')]

# Generated at 2022-06-21 06:40:39.985163
# Unit test for constructor of class LookupModule
def test_LookupModule():
    submodule = LookupModule()
    submodule.run([[["a","b"],{"c":{"d":"e","f":["g","h","i"]}},["j","k"]], "c.f"], None)

# Generated at 2022-06-21 06:40:58.741932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    classLoader = LookupModule('')
    assert classLoader is not None


# Generated at 2022-06-21 06:41:10.607486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

    # given

# Generated at 2022-06-21 06:41:19.131312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # empty value for users should raise an error
    failed = False
    try:
        lookup_module.run([[]], [], [])
    except AnsibleError as e:
        assert e.message.startswith("subelements lookup expects a list of two or three items, ")
        failed = True
    assert failed is True

    # second term should be a string
    failed = False
    try:
        lookup_module.run([[]], [], [])
    except AnsibleError as e:
        assert e.message.startswith("subelements lookup expects a list of two or three items, ")
        failed = True
    assert failed is True

    # wrong flags type
    failed = False

# Generated at 2022-06-21 06:41:31.068730
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:41:34.036030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule(
        loader=None,
        templar=None,
        basedir=None,
        env=None,
        variables=None,
    )
    assert m

# Generated at 2022-06-21 06:41:42.852753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #
    # setup
    #
    # construct new object
    lookup_plugin = LookupModule()

    # construct test data
    # data from Ansible documentation:
    # https://github.com/ansible/ansible/blob/stable-2.9/lib/ansible/plugins/lookup/subelements.py

# Generated at 2022-06-21 06:41:49.210656
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance.run(terms=[[{'_ansible_no_log': False, 'skipped': False, 'names': ['hello', 'My', 'World']}], 'names'], variables={}) == [('hello',), ('My',), ('World',)]

# Generated at 2022-06-21 06:41:59.901186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = ["users", "authorized"]
    variables = {}
    result_expected = [
        ({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/onekey.pub'),
        ({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/twokey.pub'),
        ({'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}, '/tmp/bob/id_rsa.pub'),
        ]

# Generated at 2022-06-21 06:42:02.923328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #
    # Set up
    #
    # None.
    #
    #
    # Exercise/Verify
    #
    # None.
    #
    #
    # Clean up
    #
    # None.
    #
    pass

# Generated at 2022-06-21 06:42:08.819025
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=None)
    lm = LookupModule()


# Generated at 2022-06-21 06:42:31.732737
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule

    :return: assert True if test OK, False otherwise
    """
    lookup_plugin = LookupModule()

    return True


if __name__ == '__main__':
    test1 = test_LookupModule()
    print(test1)

# Generated at 2022-06-21 06:42:42.145943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    #
    # Ex1: 2 users, 1 with groups, 1 without
    #

    users = [
        {'name': 'user1', 'groups': ['group1']},
        {'name': 'user2', 'groups': ['group2']},
        {'name': 'user3'}
    ]
    expected_result = [('user1', 'group1'), ('user2', 'group2')]

    result = lookup_module.run([users, 'groups'], {})
    assert result == expected_result, "unexpected result returned: %s != %s" % (result, expected_result)

    #
    # Ex2: 2 users, 1 with groups, 1 without
    # optional flag skip_missing set to True
    #


# Generated at 2022-06-21 06:42:52.202039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup
    lookup = ansible.plugins.lookup.get("subelements")

# Generated at 2022-06-21 06:43:00.280267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Simple case with one subelement
    terms = "users,supported_os"
    result = lookup_module.run(terms)

# Generated at 2022-06-21 06:43:02.206926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    return lookup_plugin

# Generated at 2022-06-21 06:43:12.972210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    func = LookupModule().run

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    import json

    # test given data for the examples

# Generated at 2022-06-21 06:43:24.154194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yn = {
        'yes': True,
        'Yes': True,
        'YES': True,
        'no': False,
        'No': False,
        'NO': False,
        'True': True,
        'False': False,
        'foo': True,
        'bar': False}

    def test_bool(name):
        def check(value, expected_result):
            result = boolean(value, strict=False)
            if result != expected_result:
                raise BaseException("%s(%s) == %s != %s" % (name, value, result, expected_result))
        for value, expected_result in yn.items():
            yield check, value, expected_result

    for check_bool in test_bool("test_LookupModule_run"):
        yield check_bool,

# Generated at 2022-06-21 06:43:27.611915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pl = LookupModule()
    assert pl
    assert isinstance(pl, LookupModule)


# Generated at 2022-06-21 06:43:37.513368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookuper = lookup_module.run

    # points to a list of tuples - second element of tuple is extracted
    # {'users': [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
    #            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]}
    # => [('/tmp/alice/onekey.pub',), ('/tmp/alice/twokey.pub',), ('/tmp/bob/id_rsa.pub',)]
    #                ^^^^^^^^^^^^^^

# Generated at 2022-06-21 06:43:39.436166
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, "run")

# Generated at 2022-06-21 06:44:25.373497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # For now the test only covers the most basic functionality of method run
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    test_lookup_module = LookupModule()

    # test_lookup_module.run is expecting terms to be a list of three items
    # First item is a list or a dict. Only list is tested here
    # Second item is a string.
    # Third item is a dict. Only skip_missing is tested here

# Generated at 2022-06-21 06:44:35.766440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import mock
    import yaml
    from .test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.parsing.convert_bool import boolean

    class TestLookupModule(ModuleTestCase):
        def setUp(self):
            self.mock_get_basedir = mock.patch('ansible.plugins.lookup.lookup_loader.get_basedir')
            self.mock_get_basedir.start()
            self.mock_get_vars = mock.patch('ansible.plugins.lookup.lookup_loader.get_vars')
            self

# Generated at 2022-06-21 06:44:37.227853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)  # returns true if l is an instance of class LookupModule


# Generated at 2022-06-21 06:44:42.073155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        [
            {'one': 1, 'two': {'three': {'four': ['five', 'six']}}},
            {'one': 1, 'two': {'three': {'four': ['seven', 'eight']}}}
        ],
        'two.three.four'
    ]

# Generated at 2022-06-21 06:44:50.696219
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    ######################################################################################
    # Check a list with one elements with a subkey pointing to a list
    ######################################################################################


    test_list = [{'key1': 'value1', 'key2': 'value2', 'key3': ['value3', 'value4']}]
    test_subelement = 'key3'
    test_subelements = test_subelement.split(".")
    test_flags = {}

    expected_result = [(test_list[0], 'value3'), (test_list[0], 'value4')]

    lookup_module = LookupModule()
    result = lookup_module._run(test_list, test_subelements, test_flags)

    assert_result, expected_result
    ######################################################################################


    ######################################################################################
   

# Generated at 2022-06-21 06:45:02.697221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = [
      [{"item_name": "item_value"}],
      "item_name"
      ]
    assert lu.run(terms, None) == [('item_value')]

    terms = [
      [
        {
          "item1_name": "item1_value",
          "item2_name": "item2_value"
        }
      ],
      "item_name"
      ]
    assert lu.run(terms, None) == []

    terms = [
      [
        {
          "item1_name": "item1_value",
          "item2_name": "item2_value"
        }
      ],
      "item_name",
      {"skip_missing": True}
      ]

# Generated at 2022-06-21 06:45:13.941307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    import json


# Generated at 2022-06-21 06:45:20.474659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # simple test
    elementlist = [{'subelement': [1, 2]}]
    subkey = 'subelement'
    terms = [elementlist, subkey]
    result = lookup_module.run(terms, None)
    assert result == [(elementlist[0], 1), (elementlist[0], 2)]

    # test skipped flag
    elementlist = [{'skipped': "hello"}, {'subelement': [1, 2]}]
    subkey = 'subelement'
    terms = [elementlist, subkey]
    result = lookup_module.run(terms, None)
    assert result == [(elementlist[1], 1), (elementlist[1], 2)]

    # test skip_missing flag

# Generated at 2022-06-21 06:45:24.790599
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {'skipped': True}
    l = LookupModule()
    # check for proper result from constructor
    assert l.run([data]) == []
    assert l.run([data, "skipped", {"skip_missing": True}]) == []

# Generated at 2022-06-21 06:45:26.371180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None)

# Generated at 2022-06-21 06:46:44.094137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    options = dict()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
#    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{lookup("subelements", vars["users"], "authorized")}}')))
         ]
    )

# Generated at 2022-06-21 06:46:45.745852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'

# Generated at 2022-06-21 06:46:51.890573
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    a = {'a' : 3, 'b': 2}
    b = [ 1, 2,3 ]
    terms = [ a, 'b']
    result = lm.run(terms, None)
    assert(result == [2])
    terms = [ b, '2']
    result = lm.run(terms, None)
    assert(result == [3])

# vim: set expandtab shiftwidth=4 tabstop=4:

# Generated at 2022-06-21 06:47:02.753701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    lookup = LookupModule()

    instance = dict(
        _templar=None,
        _loader=None,
        _available_variables=[],
        _connection_info=[],
    )

    for attr in instance:
        setattr(lookup, attr, instance[attr])

    users = [
        dict(
            name='test-user-0',
            groups=['wheel', 'test-group-0'],
        ),
        dict(
            name='test-user-1',
            groups=['test-group-1'],
        ),
    ]

    ret = lookup.run([users, 'groups'], variables={})
    assert ret == [('wheel',), ('test-group-0',), ('test-group-1',)]

# Generated at 2022-06-21 06:47:12.758208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Check for exception if unallowed number of args is given
    try:
        lookup_plugin.run([[], '', ''], None)
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e)

    # Check for exception if the first argument is not a list
    try:
        lookup_plugin.run(['', ''], None)
    except AnsibleError as e:
        assert "first a dict or a list, second a string pointing to the subkey" in str(e)

    # Check for exception if the second argument is not a string

# Generated at 2022-06-21 06:47:13.747355
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True
    #  FIXME : not test is missing

# Generated at 2022-06-21 06:47:19.593468
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test 1
    class LookupModule_Mocked(LookupModule):

        def __init__(self):
            pass

        def _templar(self, input):
            return input

        def _loader(self):
            pass

        def _get_basedir(self):
            return "basedir"

    lookupModule = LookupModule_Mocked()

    users = [{'name': 'bob'}, {'name': 'alice'}]
    groups = {'bob': ['bob_group1', 'bob_group2']}
    terms = [users, 'groups']
    result = lookupModule.run(terms, variables={}, **{})
    assert result == [({'name': 'bob'}, ['bob_group1', 'bob_group2'])]

    # test 2


# Generated at 2022-06-21 06:47:20.516775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 06:47:29.200353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_plugin = LookupModule()
    lookup_plugin._loader = loader

    # first test: it should be possible to create a LookupModule object and it should accept some simple test data
    assert isinstance(lookup_plugin, LookupModule)

    # second test: it should be possible to create a LookupModule object and it should accept some simple test data
    assert isinstance(lookup_plugin, LookupModule)
    terms = [
        [
            { 'name': 'bob', 'pets': { 'dog': 'fido', 'cat': 'sally' } },
            { 'name': 'joe', 'pets': { 'dog': 'buddy' } }
        ],
        "pets.dog"
    ]

# Generated at 2022-06-21 06:47:37.776183
# Unit test for method run of class LookupModule