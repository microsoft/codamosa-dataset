

# Generated at 2022-06-21 06:37:57.805845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(terms=[
        dict(a=dict(b=dict(c=[1, 2, 3], d=[4, 5, 6]))),
        'b.c',
    ]) == l.run(terms=[
        dict(a=dict(b=dict(c=[1, 2, 3], d=[4, 5, 6]))),
        'b.c',
        dict(),
    ])

# Generated at 2022-06-21 06:38:06.542200
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup.subelements import LookupModule as lm

    l = lm()

    # run(self, terms, variables=None, **kwargs)
    l._templar = None
    l._loader = None

    # terms argument should be a list
    with pytest.raises(AnsibleError):
        l.run('wrong argument', [])

    # terms list should hold at least two items
    with pytest.raises(AnsibleError):
        l.run([1], [])
    with pytest.raises(AnsibleError):
        l.run([1, 2, 3, 4, 5], [])

    # first item should be a list or dict

# Generated at 2022-06-21 06:38:08.322105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:38:20.271550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test missing terms
    terms = None
    variables = None
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(terms, variables)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert e.message == "subelements lookup expects a list of two or three items, "
    # test missing first term
    terms = [None]
    variables = None
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(terms, variables)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"
    # test missing second term
    terms = [None, None]

# Generated at 2022-06-21 06:38:20.709647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:38:31.219893
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from collections import namedtuple

    TestCase = namedtuple('TestCase', ['test_name', 'input_terms', 'input_variable', 'expected_return', 'expected_exception'])

# Generated at 2022-06-21 06:38:41.219065
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyTerminal(object):
        def __init__(self):
            self.tty = True
            self.stdin = sys.stdin
            self.stdout = sys.stdout

    class DummyVars(object):
        def __init__(self):
            self.vars = {}
            self.extra_vars = {}

    fake_terminal = DummyTerminal()
    fake_loader = DummyLoader()
    fake_vars = DummyVars()
    fake_variable_manager = DummyVariableManager()
    lookup = LookupModule()

# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-21 06:38:42.532402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:38:45.194430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar == None
    assert lookup_plugin._loader == None

# Generated at 2022-06-21 06:38:47.153463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert isinstance(ret, LookupModule), "result must be of type LookupModule"

# Generated at 2022-06-21 06:38:55.625049
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert(True)

# Generated at 2022-06-21 06:38:57.825607
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    return lookup


# Generated at 2022-06-21 06:39:02.093402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run([[{'name':'Alice'}, {'name':'Bob', 'mysql':{'password': 'Bobpassword', 'hosts': ['localhost', 'host1']}}], 'name'],
                       {},
                       **{})


# Generated at 2022-06-21 06:39:11.024831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        { # first term
            'users': [
                {
                    'name': 'alice',
                    'authorized': [],
                    'mysql': {
                        'password': 'mysql-password',
                        'hosts': []
                    }
                },
                {
                    'name': 'bob',
                    'authorized': [],
                    'mysql': {
                        'password': 'other-mysql-password',
                        'hosts': []
                    }
                }
            ],
            'skip_hash':{'hosts':[]}
        },
        'authorized', # second term
        {'skip_missing': True}, # third term
    ]
    assert lookup.run(terms, {}, **{}) == []

# Generated at 2022-06-21 06:39:21.970539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object of class LookupModule
    obj = LookupModule()

    # Create object of class AnsibleTemplate
    objt = AnsibleTemplate()

    # Mock the object of class AnsibleTemplate
    obj.set_loader = MagicMock(return_value=objt)

    # Mock the method 'get_basedir' of class AnsibleTemplate
    objt.get_basedir = MagicMock(return_value='')

    # Create object of class AnsibleVariableManager
    obju = AnsibleVariableManager()

    # Mock the object of class AnsibleVariableManager
    obj.set_templar = MagicMock(return_value=obju)

    # Mock the method 'do_template' of class AnsibleVariableManager
    obju.do_template = MagicMock(return_value='')

    # Mock the method

# Generated at 2022-06-21 06:39:31.824797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText as unsafe_text
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes as unsafe_bytes

    users = [{'groups': ['a_group'], 'name': unsafe_text(u'ansible')},
             {'groups': ['wheel'], 'name': unsafe_text(u'root'), 'uid': unsafe_text(u'0')}]
    key = unsafe_text(u'groups')
    flags = {'skip_missing': False}

# Generated at 2022-06-21 06:39:44.634248
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    if sys.version_info.major < 3:
      import unittest2 as unittest
    else:
      import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import lookup_loader, lookup_loader_common

    class TestPlaybookExecutor(unittest.TestCase):

        def setUp(self):
            self._loader = DataLoader()
            self._variable_manager = VariableManager()

# Generated at 2022-06-21 06:39:48.140078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = dict(users=[1,2,3], authorized=[1,2,3])
    l = LookupModule()
    assert(l._templar is None)
    assert(l._loader is None)
    assert(l.run(terms, None) == terms)

# Generated at 2022-06-21 06:40:00.816100
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:40:03.626206
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Simple test to check the constructor works.
    params = {
        '_raw_params': 'test'
    }
    lookup_plugin = LookupModule(**params)
    assert lookup_plugin


# Generated at 2022-06-21 06:40:21.328242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert subelements
    assert isinstance(subelements, LookupBase)

# Generated at 2022-06-21 06:40:32.011379
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_native
    from ansible.plugins.lookup import LookupBase

    lmodule = LookupModule()

    assert isinstance(lmodule, LookupBase)


# Generated at 2022-06-21 06:40:34.445642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [{'foo': 'bar', 'baz': 'qux'}, ['foo'], {'skip_missing': True}]
    assert LookupModule().run(terms, variables=None) == [('bar',)]

# Generated at 2022-06-21 06:40:36.942472
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("testing constructor")
    l1 = LookupModule()
    print("testing constructor done")


# Generated at 2022-06-21 06:40:48.541768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for LookupModule.run method
    """
    import mock
    from ansible.module_utils.six.moves import builtins

    # vars for testing
    terms = [
        [{
            'alice': {
                'authorized': [
                    '/tmp/alice/onekey.pub',
                ],
            },
            'bob': {
                'authorized': [
                    '/tmp/bob/id_rsa.pub',
                ],
            },
        }],
        "authorized",
    ]

    # setup the standard module execution environment
    set_module_args(dict(
        query='value',
        _raw_params='params',
        _uses_shell=False,
        _diff=False,
    ))

# Generated at 2022-06-21 06:40:55.791234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # normal usage
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 06:40:57.533764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:41:09.202370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # check for required grandparent module
    grandparent_module = 'ansible.plugins.lookup.subelements'
    assert grandparent_module in sys.modules, 'ansible.plugins.lookup.subelements module is not imported in sys.modules'
    # instantiate
    lookup_plugin = LookupModule()
    # check for required parent module
    parent_module = 'ansible.plugins.lookup.subelements.LookupModule'
    assert parent_module in sys.modules, 'ansible.plugins.lookup.subelements.LookupModule module is not imported in sys.modules'
    # check for class LookupModule
    cls = getattr(sys.modules[parent_module], 'LookupModule')

# Generated at 2022-06-21 06:41:18.468819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Empty list
    lm = LookupModule()
    try:
        lm.run(terms=[], variables={})
        assert False, "should fail"
    except AnsibleError:
        pass

    # First entry is a string
    lm = LookupModule()
    try:
        lm.run(terms=[['foo']], variables={})
        assert False, "should fail"
    except AnsibleError:
        pass

    # First entry is a dictionary
    lm = LookupModule()
    try:
        lm.run(terms=[{'foo': ['bar']}], variables={})
        assert False, "should fail"
    except AnsibleError:
        pass

    # Second entry is a list
    lm = LookupModule()

# Generated at 2022-06-21 06:41:24.898659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare test data

    # method under test
    # lookups = dict(subelements=LookupModule)
    # runner = AnsibleRunner(loader=DataLoader())
    # runners.run_lookup_plugin('subelements', '', lookups, '')
    return

# Generated at 2022-06-21 06:41:56.730368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'lookup_plugins' in globals()


# Generated at 2022-06-21 06:42:00.739397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    data = [{'key': 'val0'}, {'key': 'val1'}]
    assert lookup_plugin.run([data, 'key'], {}) == [[i['key']] for i in data]

# Generated at 2022-06-21 06:42:07.778704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    # make module able to run outside of Ansible core
    import sys
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager

    # We may be running this from a tox env or from a normal CWD
    # so look for ansible.cfg in both places
    p = ConfigManager(None, [u'../test/ansible.cfg', u'ansible.cfg'])
    display = Display()
    display.VERBOSITY = 4
    display.DEBUG = True
    display.deprecated("This is a deprecation warning", version="2.12")
    config = p.get_config()

    # fake input args
    sys.argv

# Generated at 2022-06-21 06:42:17.013423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #### Setup mock objects
    import __builtin__ as builtins
    import mock
    import ansible
    import ansible.plugins
    import ansible.plugins.lookup
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.py3compat import StringIO

    #### Mocked objects
    class MockTemplar(object):
        def __init__(self, loader, variables=None, fail_on_undefined=True):
            pass

        def template(self, term, preserve_trailing_newlines=True, escape_backslashes=True,
                convert_data=True, fail_on_undefined=True, override_vars=None):
            return term

    class MockLoader(object):
        pass



# Generated at 2022-06-21 06:42:27.808341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This test is not part of the module's unit tests,
    # but is a part of the doctests.
    # http://docs.python-guide.org/en/latest/writing/tests/
    elements = [{'name': 'alice', 'groups': ['wheel']},
                {'name': 'bob'}]

    lm = LookupModule()
    subelements = lm.run([elements, 'groups'], [])
    print("subelements => " + str(subelements))

    subelements = lm.run([elements, 'groups', {'skip_missing': True}], [])
    print("subelements => " + str(subelements))

# Generated at 2022-06-21 06:42:28.427545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:42:39.046003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Call run
    nr_tests = 0
    ################################################################################################
    # Test case: bad number of terms
    ################################################################################################
    terms = []
    try:
        lookup_module.run(terms, None)
        assert False, "expected an exception"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message

    terms = ['a string is not a pair of lists']
    try:
        lookup_module.run(terms, None)
        assert False, "expected an exception"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items, " in e.message

# Generated at 2022-06-21 06:42:41.753506
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    ret = lookup.run([
        ['a', 'b'],
        "foo"
    ], dict(
        a='A',
        b='B'
    ))
    assert ['a', 'b'] == ret

# Generated at 2022-06-21 06:42:42.645392
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert True

# Generated at 2022-06-21 06:42:45.110300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run([["a", "b"]], None) == [('a', 'b')]



# Generated at 2022-06-21 06:43:48.782218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:43:55.952446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    [ ('users',), ('mysql.hosts',), ('mysql.privs',), ('authorized',), ]
    """
    # check for (in)correct number of terms
    terms_error_msg = "subelements lookup expects a list of two or three items"
    lookup = LookupModule()

    terms = []
    ret = lookup.run(terms, variables={})
    assert ret[0] == "ERROR! " + terms_error_msg, "_raise_terms_error is not working as expected"

    terms = ["users"]
    ret = lookup.run(terms, variables={})
    assert ret[0] == "ERROR! " + terms_error_msg, "_raise_terms_error is not working as expected"

    # check for (in)correct first and second terms

# Generated at 2022-06-21 06:44:00.040176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-21 06:44:04.196779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def _create_lookup_instance(terms, variables=None, loader=None, inventory=None):
        if loader is None:
            loader = DataLoader()
        lookup = LookupModule()
        lookup.set_loader(loader=loader)
        if inventory:
            lookup.set_inventory(inventory=inventory)
        if variables:
            lookup.set_vars(variables=VariableManager(loader=loader, inventory=inventory))
        lookup._templar = None
        return lookup.run(terms, variables)

    # create inventory, empty group
    inventory = InventoryManager(loader=None, sources='localhost,')
    inventory.add_group('local')

# Generated at 2022-06-21 06:44:14.772283
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:44:21.433220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # from ansible-playbook:
    le = LookupModule()

    terms = [
        [{"host": "host", "password": "pass", "username": "user"}],
        "password"
    ]
    assert le.run(terms, {'skip_missing': True, 'fail_on_undefined': False}) == 'pass'

    terms = [
        [{"host": "host", "password": "pass", "username": "user"}],
        "pass"
    ]
    assert le.run(terms, {'skip_missing': True, 'fail_on_undefined': False}) == ''

    terms = [
        [{"host": "host", "password": "pass", "username": "user"}],
        "fail"
    ]

# Generated at 2022-06-21 06:44:33.764970
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # we set up the module and its parameters
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-21 06:44:34.127715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 06:44:39.723892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    import json
    import os
    import unittest

    class TestLookupModule():

        def __init__(self, _terms, _variables):
            self.terms = _terms
            self.variables = _variables

    class TestVariables():

        def __init__(self):
            pass

    class TestTemplar():

        def __init__(self):
            pass

        def template(self, term):
            return term

    class TestLoader():

        def __init__(self):
            pass

        def path_dwim(self, term):
            return term

    class TestLookupModule_run(unittest.TestCase):

        def setUp(self):
            self.test_variables = TestVariables()


# Generated at 2022-06-21 06:44:47.593126
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class AnsibleMock:
        def __init__(self):
            self.errors = []
            self.warnings = []

    ansible_module = AnsibleMock()
    lookup = LookupModule(ansible_module)
    lookup.run([])
    assert len(ansible_module.errors) == 1
    assert ansible_module.errors[0].startswith("subelements lookup expects a")

# Generated at 2022-06-21 06:47:12.857327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule.run([['a'], 'x'], None) == [])

# Generated at 2022-06-21 06:47:19.171192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    def _raise_terms_0_error():
        _raise_terms_error("first a dict or a list, second a string pointing to the subkey")

    def _raise_terms_2_error():
        _raise_terms_error("the optional third item must be a dict with flags %s" % FLAGS)

    FLAGS = ('skip_missing',)


# Generated at 2022-06-21 06:47:28.390515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of LookupModule
    :return:
    """
    yaml_doc = """
- lookup_plugin: subelements
  lookup_terms:
    _terms:
      - "{{ users }}"
      - "authorized"
"""

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupModule
    from ansible.vars.manager import VariableManager

    # test args parsing
    args = {'_raw_params': '{{ users }} authorized'}
    lm = LookupModule()
    assert lm.parse_terms(args, {}) == [['{{', 'users', '}}'], 'authorized'], lm.parse_terms(args, {})

    # test args parsing

# Generated at 2022-06-21 06:47:38.170165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    class DummyVars(object):
        users = {'alice': {'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
                 'bob': {'authorized': ['/tmp/bob/id_rsa.pub']}}

    class DummyTemplar(object):
        def __init__(self, *args, **kwargs):
            pass

        def template(*args, **kwargs):
            return args[0]

    class DummyLoader(object):
        def __init__(self, *args, **kwargs):
            pass


    # Test with two arguments

    # Test with list as first argument