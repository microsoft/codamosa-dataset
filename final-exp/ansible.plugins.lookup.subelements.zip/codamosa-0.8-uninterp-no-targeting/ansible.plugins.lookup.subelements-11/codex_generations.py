

# Generated at 2022-06-21 06:37:59.121300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [{'first': {'only': 'one'}}, {'second': 'two'}],
        'first.only',
        {'skip_missing': False}
    ]
    ret = LookupModule().run(terms, {})
    assert ret == [('one',)], ret
    terms = [
        [{'first': 'one'}],
        'second',
        {'skip_missing': True}
    ]
    ret = LookupModule().run(terms, {})
    assert ret == [], ret
    terms = [
        [{'first': {'only': 'one'}}, {'first': {'only': 'two'}}, {'first': {'only': 'three'}}],
        'first.only',
        {'skip_missing': False}
    ]

# Generated at 2022-06-21 06:38:01.914958
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([[{'1': 1, '2': 2}], '1'], [], []) == [{'1': 1, '2': 2}]

# Generated at 2022-06-21 06:38:03.824742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ test the constructor of LookupModule """
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 06:38:16.139408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test skipping a term key
    users = [{"username": "user1", "authorized": ["/etc/file1", "/etc/filex"], "url": "http://www.example.com/file.pdf"}]
    lookup_module = LookupModule()
    ret = lookup_module.run([users, "authorized", {"skip_missing": True}], dict())
    assert ret == [('user1', "/etc/file1"), ('user1', "/etc/filex")]
    # test non existing term
    users = [{"username": "user1", "url": "http://www.example.com/file.pdf"}]
    lookup_module = LookupModule()
    ret = lookup_module.run([users, "authorized", {"skip_missing": True}], dict())
    assert ret == []
    # test skipping subelements

# Generated at 2022-06-21 06:38:24.498202
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mock_loader = MockLoader()
    mock_templar = MockTemplar()

    terms = [
        {
            'testDict': {
                'subDict': [
                    'sublistItem1',
                    'sublistItem2'
                ],
                'subDict2': 'subString'
            }
        },
        'subDict'
    ]

    lm = LookupModule(loader=mock_loader, templar=mock_templar, basedir=None)
    lm.run(terms, dict())


# Generated at 2022-06-21 06:38:33.174312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible import constants as C
    except ImportError:
        print('Module ansible.constants cannot be imported. Skipping unit test ' + __name__)
        return
    from ansible.module_utils.parsing.convert_bool import boolean

    # import ansible.module_utils.parsing.convert_bool for monkeypatching
    # FIXME: the following import is not needed, but it is here because of the python <2.7.12 on EL6 bug #15184
    # FIXME: See https://github.com/ansible/ansible/issues/33143, https://github.com/ansible/ansible/issues/17901
    from ansible.module_utils.parsing.convert_bool import boolean

    # import module LookupModule

# Generated at 2022-06-21 06:38:33.800471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 06:38:44.649543
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()

    # Test basic functionality
    assert lu.run([['foo','bar','baz'], 'subelements'], []) == ['foo','bar','baz']

    # Test with_subelements
    lu = LookupModule()
    assert lu.run([{'foo':'bar'}, 'subelements'], []) == [['bar', 'subelements']]

    # Test with_subelements with an additional kwarg
    lu = LookupModule()
    assert lu.run([{'foo':'bar'}, 'subelements', 'key_name'], []) == [['bar', 'subelements']]

    # Test with_subelements with a list of dictionaries
    lu = LookupModule()

# Generated at 2022-06-21 06:38:45.316469
# Unit test for constructor of class LookupModule
def test_LookupModule():
  pass

# Generated at 2022-06-21 06:38:56.616508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyVarsModule():
        def __init__(self,):
            self._data = {'users':
                          [{'authorized': [u'/tmp/alice/onekey.pub', u'/tmp/alice/twokey.pub'],
                            'name': u'alice'},
                           {'authorized': [u'/tmp/bob/id_rsa.pub'],
                            'name': u'bob'}]}

        def get_vars(self, loader, path, entities):
            return self._data.copy()

    class TestLookupModule(LookupModule):
        def __init__(self, basedir=None, runner=None, **kwargs):
            self.basedir = basedir
            self.runner = runner

# Generated at 2022-06-21 06:39:05.980725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:39:15.886939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    vars = dict()

# Generated at 2022-06-21 06:39:20.763897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    values = [ [ 1, 2, 3 ], [ 4, 5, 6 ] ]
    terms  = [ values, "2" ]

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)

    assert [ (v, v[2]) for v in values ] == result

# Generated at 2022-06-21 06:39:22.568777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:39:32.120387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    record = {
        'username': 'bob',
        'ssh_keys': {
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        },
        'mysql': {
            'hosts': [
                'db1'
            ],
            'privs': [
                '*.*:SELECT',
                'DB2.*:ALL'
            ]
        }
    }
    users = [record]
    authorized_keys = ['/tmp/bob/id_rsa.pub']

    lookup_module = LookupModule()
    result = lookup_module.run([users, 'ssh_keys.authorized'], context={})

    assert result[0][0] == record
    assert result[0][1] == authorized_keys[0]

# Generated at 2022-06-21 06:39:33.646304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sub = LookupModule()
    print(sub)
    #assert None == sub


# Generated at 2022-06-21 06:39:36.202080
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert isinstance(subelements, LookupModule)

# Generated at 2022-06-21 06:39:39.134553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None, 'class LookupModule constructor must return a non-None value'

# Generated at 2022-06-21 06:39:49.990968
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test should raise errors
    # 1. no args
    for args in ([], {}, ()):
        try:
            lookup_module.run(args, {})
        except AnsibleError:
            pass
        except:
            raise

    # 2. first arg missing
    for args in ([], {}, (), [{}], [2, 3], [False, {}], [True, {}], [None, {}]):
        for arg in args:
            for arg in args:
                try:
                    lookup_module.run([arg], {})
                except AnsibleError:
                    pass
                except:
                    raise

    # 3. first arg not list

# Generated at 2022-06-21 06:40:01.694676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultAES

    from ansible.plugins.lookup.subset import LookupModule
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-21 06:40:22.609227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # pylint: disable=protected-access
    assert len(lookup.run(terms=[])) == 0
    assert len(lookup.run(terms=['term0'])) == 0
    assert len(lookup.run(terms=['term0', 'terms1'])) == 0


# Generated at 2022-06-21 06:40:33.014103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    class MockTemplar(object):
        def __init__(self):
            pass
        def template(self, value):
            return value

    class MockLoader(object):
        def __init__(self):
            pass
    lookup = LookupModule()
    lookup._templar = MockTemplar()
    lookup._loader = MockLoader()

    # Tests that the 'run' method returns expected values
    # 1. Test with all params
    results = [
        ('username1', ('key1', '/path/to/key1')),
        ('username2', ('key2', '/path/to/key2')),
    ]

# Generated at 2022-06-21 06:40:38.920413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # check lookup terms - check number of terms
    # subelements lookup expects a list of two or three items
    assert isinstance(lookup.run('1', '2'), [AnsibleError])

    # first term should be a list (or dict), second a string holding the subkey
    assert isinstance(lookup.run(['1'], '2'), [AnsibleError])
    assert isinstance(lookup.run([1], '2'), [AnsibleError])
    assert isinstance(lookup.run([1, 2, 3], '2'), [AnsibleError])

    # check for optional flags in third term
    assert isinstance(lookup.run([{'a': 1}, 'a', 'b'], '2'), [AnsibleError])

# Generated at 2022-06-21 06:40:39.928277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 06:40:51.097704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test subelements with dictionary input and second term giving the subkey
    lm = LookupModule()

# Generated at 2022-06-21 06:40:53.272986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None) is not None

# Generated at 2022-06-21 06:41:05.070616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:41:16.322894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    _loader = AnsibleLoader(None, basic._ANSIBLE_ARGS)

    lo = LookupModule()

    # simple list, simple subkey
    result = lo.run([_loader.load("""
        - name: alice
          authorized:
            - /tmp/alice/onekey.pub
            - /tmp/alice/twokey.pub
        - name: bob
          authorized:
            - /tmp/bob/id_rsa.pub
    """)],
    {},
    templar=None,
    loader=_loader)

# Generated at 2022-06-21 06:41:17.060712
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-21 06:41:29.520389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:42:07.528540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    mylookup._templar = None
    mylookup._loader = None
    random_value = 'this could be anything'
    random_dict = {'key1': 'value1', 'key2': 'value2'}
    random_list = ['value1', 'value2']
    # test for empty terms
    assert mylookup.run(terms=[], variables={}) == []
    # test for wrong terms, not containing lists
    assert mylookup.run(terms=[1, 2], variables={}) == []
    assert mylookup.run(terms=['string', 'string'], variables={}) == []
    assert mylookup.run(terms=['string', 2], variables={}) == []
    # test for wrong terms, not containing lists with two or three items
    assert mylook

# Generated at 2022-06-21 06:42:15.421866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()

    assert m.run([{'a': 1}, {'b': 2}, 'hello'], {}) == [('hello', {'a': 1}), ('hello', {'b': 2})]

    assert m.run([{'a': 1}, {'b': 2}, 'hello'], {}) == [('hello', {'a': 1}), ('hello', {'b': 2})]

    assert m.run([[{'a': 1}, {'b': 2}], 'a'], {}) == [({'a': 1}, 1), ({'b': 2}, 2)]

# Generated at 2022-06-21 06:42:27.630543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(terms, expected_ret, expected_err_msg=None, expected_skip=None,
        terms2=None, terms3=None, terms4=None, terms5=None, terms6=None):
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager
        import ansible.constants as C
        class TestLookupModule(LookupModule):
            def __init__(self, loader=None, templar=None, **kwargs):
                self.loader = DataLoader()
                self.inventory = InventoryManager(loader=self.loader, sources=[])

# Generated at 2022-06-21 06:42:38.273594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    # use dict for plugin results, to be able to retrieve the results via dictionary keys

# Generated at 2022-06-21 06:42:45.263384
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import string_types
    lu = LookupModule()

    # - check for errors

# Generated at 2022-06-21 06:42:46.733704
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin



# Generated at 2022-06-21 06:42:47.955545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 06:42:54.598501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ('', '',)
    lm = LookupModule()
    try:
        ret = lm.run(terms, 'variables')
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

# Unit test to check error handling in LookupModule

# Generated at 2022-06-21 06:43:06.260326
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [{'key1': {'subkey1': 'a', 'subkey2': 'b'}, 'key2': {'subkey1': 'c', 'subkey2': 'd'}}, 'subkey2']

    res = LookupModule().run(terms, dict())
    expected = [('a',), ('b',), ('c',), ('d',)]
    assert res == expected

    terms = [{'key1': {'subkey1': 'a', 'subkey2': 'b'}, 'key2': {'subkey1': 'c', 'subkey2': 'd'}}, 'subkey3']

    res = LookupModule().run(terms, dict())
    assert res == list()


# Generated at 2022-06-21 06:43:17.031800
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # init
    assert LookupModule._templar is None
    assert LookupModule._loader is None
    lookup = LookupModule()

    # check options
    assert lookup.get_options() == {}

    # check run method
    ret = lookup.run(([], {}), {})
    assert ret == []
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(([], {}, {}), {})
    assert str(excinfo.value) == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run((['a'], {}, {}), {})

# Generated at 2022-06-21 06:44:37.665535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Basic sanity checks for lookup module

    :return: True
    """
    import ast
    lookup = LookupModule()

    # check valid vars
    assert lookup.run([{'skipped': False, 'a': {'b': [1, 2, 3]}}], None, **{}) == [(
        {'skipped': False, 'a': {'b': [1, 2, 3]}}, 1), (
        {'skipped': False, 'a': {'b': [1, 2, 3]}}, 2), (
        {'skipped': False, 'a': {'b': [1, 2, 3]}}, 3)], "test #1 failed"

# Generated at 2022-06-21 06:44:49.290992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    vm = LookupModule()

    # Check lookup terms - Check number of terms
    pytest.raises(AnsibleError, vm.run, ['arg1'], {})
    pytest.raises(AnsibleError, vm.run, ['arg1', 'arg2', 'arg3', 'arg4'], {})

    # Check lookup terms - First term should be a list (or dict), second a string holding the subkey
    pytest.raises(AnsibleError, vm.run, [['arg1'], {}], {})
    pytest.raises(AnsibleError, vm.run, [['arg1'], 'arg2'], {})
    pytest.raises(AnsibleError, vm.run, [['arg1'], 'arg2', 'arg3'], {})


# Generated at 2022-06-21 06:44:54.316178
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:45:04.535085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar


# Generated at 2022-06-21 06:45:12.175949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[{'a': {'b': ['x', 'y']}}, {'a': {'c': ['1', '2']}}], 'a.b']
    lm = LookupModule()
    assert lm.run(terms, dict()) == [({'a': {'b': ['x', 'y']}}, 'x'), ({'a': {'b': ['x', 'y']}}, 'y')]



# Generated at 2022-06-21 06:45:16.618074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test empty case, fully legal
    module = LookupModule()

    # Test wrong parameters
    try:
        module.run()
        assert False
    except TypeError:
        assert True
    try:
        module.run([])
        assert False
    except AnsibleError:
        assert True

    # Test right parameters
    assert module.run([[], ""]) == []



# Generated at 2022-06-21 06:45:28.510103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    def run_test(terms, elementlist, expected):
        element_result = []
        for item in elementlist:
            if item.get('skipped', False) is not False:
                # this particular item is to be skipped
                element_result.append(item)
            else:
                element_result.append(item)

        element_result_result = {'results': element_result}
        results = lookup_module.run(terms, None, variables=element_result_result)
        assert results == expected

    # test 1 with skip_missing True

# Generated at 2022-06-21 06:45:39.227141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arr = [{u'aaa': {u'bbb': [u'BBB1', u'BBB2'], u'ccc': u'CCC'}, u'ddd': u'DDD'},
           {u'aaa': {u'bbb': [], u'ccc': u'CCC'}, u'ddd': u'DDD'},
           {u'aaa': {u'ccc': u'CCC'}, u'ddd': u'DDD'},
           ]
    l = LookupModule()
    assert l.run(terms=[arr, u'aaa.bbb']) == [(arr[0], u'BBB1'), (arr[0], u'BBB2')]

# Generated at 2022-06-21 06:45:47.750610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    :return:
    """
    from ansible.plugins.lookup import LookupModule

    lookup_instance = LookupModule()

# Generated at 2022-06-21 06:45:51.883083
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test positive case
    lm = LookupModule()
    # Test negative case (should raise exception)
    try:
        terms = 'test'
        variables = 'test'
        lm.run(terms, variables)
    except Exception as e:
        assert isinstance(e, AnsibleError)