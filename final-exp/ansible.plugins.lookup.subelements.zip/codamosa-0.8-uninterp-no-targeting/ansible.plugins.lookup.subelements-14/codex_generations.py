

# Generated at 2022-06-21 06:37:58.925913
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test lookup with optional flags
    data = [
        {'testlist': [1, 2, 3, 4]},
        {'testlist': [5, 6], 'skipped': True},
        {'testlist': [7, 8, 9]},
        {'testlist': [10, 11], 'skipped': True},
        {'testlist': [12, 13, 14, 15]},
    ]

    lm = LookupModule()
    results = lm.run([data, 'testlist'], dict())
    assert len(results) == 12, "length of results is wrong"

    results = lm.run([data, 'testlist', {'skip_missing': True}], dict())
    assert len(results) == 12, "length of results is wrong"


# Generated at 2022-06-21 06:38:08.363563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from shutil import rmtree
    from ansible.module_utils.six import iteritems

    class SubjectUnderTest(LookupModule):
        def __init__(self):
            self.basedir = None

        def run(self, terms, variables, **kwargs):
            basedir = self.basedir
            if basedir is None:
                basedir = tempfile.mkdtemp(prefix="ansible_test_lookup_file_")
            # create the files
            for term in terms:
                if isinstance(term, dict):
                    for (path, content) in iteritems(term):
                        if not isinstance(content, string_types):
                            content = content.encode('utf-8')

# Generated at 2022-06-21 06:38:09.442090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu

# Unit testing for run() method of class LookupModule

# Generated at 2022-06-21 06:38:10.520613
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-21 06:38:21.897525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test class LookupModule

    Test coverage:
        - constructor
        - run
            - error on invalid arguments
            - no error on valid arguments
            - skip missing value
            - don't skip missing value
    """
    from ansible.utils import jsonify

    # Constructor test
    lm = LookupModule()

    # Lookup using terms with error
    terms = jsonify({}, False)
    variables = jsonify({}, False)
    try:
        lm.run(terms, variables)
        assert False, "LookupModule.run doesn't raise error on invalid arguments"
    except Exception as e:
        assert True, "LookupModule.run raise error as expected on invalid arguments"

    # Lookup using terms with error
    terms = [1,2,3]
    variables = jsonify({}, False)


# Generated at 2022-06-21 06:38:27.288026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    import string
    import random

    def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for _ in range(size))

    # test setting up of LookupModule, passing parameters
    lm = LookupModule()

    # simulate input parameters

# Generated at 2022-06-21 06:38:38.187892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    lookup_obj = LookupModule()
    users = [{'name': 'bob', 'authorized': ['/home/bob/id_rsa.pub']}]
    ret = lookup_obj.run([users, 'authorized'], variables={}, **{'_input_lines': [], '_input_lines_file': None, '_load_recursive_role_stdout': []})
    print(ret)
    assert ret == [({'authorized': ['/home/bob/id_rsa.pub'], 'name': 'bob'}, '/home/bob/id_rsa.pub')]

# Generated at 2022-06-21 06:38:49.478909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        LookupModule().run([])
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message
    try:
        LookupModule().run([[]])
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message
    try:
        LookupModule().run([[],''])
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message
    try:
        LookupModule().run([[],1])
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message

# Generated at 2022-06-21 06:38:51.235420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance is not None

# Generated at 2022-06-21 06:39:02.012199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test the subelements module.
    '''

    class VarsModule():
        ''' A dummy AnsibleVars '''

        def set_fact(self, name, value):
            ''' dummy set_fact '''
            self.facts[name] = value

        def __init__(self):
            ''' Constructor '''
            self.facts = {}

    lookup_ins = LookupModule()
    vars_ins = VarsModule()
    # Subelements should raise AnsibleError when the first parameter is not a list or a dict.
    try:
        lookup_ins.run('not a list or a dict', vars_ins, skip_missing=True)
        assert False
    except AnsibleError:
        assert True
    # Subelements should raise AnsibleError when the second parameter is not a

# Generated at 2022-06-21 06:39:20.817173
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # Check that constructor raises a TypeError when an invalid number of 
    # terms is provided
    for terms_err in [], [()], [0, 1, 2], [0, 1, ()]:
        try:
            l._construct_terms(terms_err)
        except TypeError:
            pass
        else:
            assert False, "No TypeError thrown for invalid number of terms"
    # Check construction of terms

# Generated at 2022-06-21 06:39:31.084322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialize plugin with valid arguments
    lookup = LookupModule()
    dict_users = {
        'name': 'alice',
        'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
        'mysql': {
            'password': 'mysql-password',
            'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
            'privs': ['*.*:SELECT', 'DB1.*:ALL']
        },
        'groups': ['wheel']
    }
    list_users = [dict_users]
    terms = [list_users, 'authorized']
    expected = [('alice', '/tmp/alice/onekey.pub'), ('alice', '/tmp/alice/twokey.pub')]


# Generated at 2022-06-21 06:39:42.911912
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Check 2 items in list
  assert(len(LookupModule().run(["item1", "item2"], None)) == 2)

  # Check 2 items in list with 1 optional
  assert(len(LookupModule().run(["item1", "item2", "optional"], None)) == 3)

  # Check 2 items in list with non-string optional
  success = False
  try:
    assert(len(LookupModule().run(["item1", "item2", ["optional"]], None)) == 3)
  except Exception:
    success = True

  assert(success)

  # Check 2 items in list with string optional
  assert(len(LookupModule().run(["item1", "item2", "optional"], None)) == 3)

  # Check 2 items in list with dictionary optionals

# Generated at 2022-06-21 06:39:51.810519
# Unit test for constructor of class LookupModule
def test_LookupModule():

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    terms = [["one", "two", "three"], {"four": ["bundle"]}, {"six": ["six"]}]

    if not isinstance(terms, list) or not len(terms) >= 2:
        _raise_terms_error()

    # first term should be a list (or dict), second a string holding the subkey
    if not isinstance(terms[0], list) or not isinstance(terms[1], dict):
        _raise_terms_error("first a dict or a list, second a string pointing to the subkey")

    # check for optional flags in third term
    flags = {}

# Generated at 2022-06-21 06:40:02.790542
# Unit test for constructor of class LookupModule
def test_LookupModule():

    print("now testing LookupModule")
    assert check_LookupModule("name", [{"name": "serge"}, {"name": "bob"}]) == ["serge", "bob"]
    assert check_LookupModule("name", [{"name": "serge"}, {"name": "bob"}], {"skip_missing": True}) == ["serge", "bob"]
    assert check_LookupModule("name", [{"name": "serge"}, {"name": "bob"}, {"skipped": "skipped"}]) == ["serge", "bob"]
    assert check_LookupModule("name", [{"skipped": "skipped"}]) == []
    assert check_LookupModule("name", [{"skipped": "skipped"}, {"skipped": "skipped"}, {"skipped": "skipped"}]) == []

    assert check_

# Generated at 2022-06-21 06:40:03.667318
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule == type(LookupModule())

# Generated at 2022-06-21 06:40:14.999477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.reset()

    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub',
            ],
            'groups': [
                'wheel'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        }
    ]

    terms = [users, 'not_existing']

# Generated at 2022-06-21 06:40:26.101557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run(terms=[], variables={}, **{}) == [], 'Should return [] for empty terms'

    # With subkey not found in dict
    # Still get a list of tuples, with a None value as second part
    # This is to be able to use with_subelements on the result
    ret = lookup_module.run(
        terms=[{
            'skipped': False,
            'a': {
                'b': 1,
                'c': 2,
                'd': 3,
            },
            'e': {
                'f': 4,
                'g': 5,
                'h': 6,
            },
        },
            'i'],
        variables={},
        **{}
    )


# Generated at 2022-06-21 06:40:28.636288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing", LookupModule)

    assert LookupModule
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 06:40:29.671908
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True


# Generated at 2022-06-21 06:40:47.050240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({}, [])

# Generated at 2022-06-21 06:40:48.375205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:40:55.699422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create class instance
    lookup_plugin = LookupModule()

    # should raise error when not 2 or 3 elements in terms
    try:
        lookup_plugin.run([], None)
        assert False, "run should have failed because of not enough arguments"
    except AnsibleError:
        pass
    try:
        lookup_plugin.run([{}, "lala", {}, "lele"], None)
        assert False, "run should have failed because of too many arguments"
    except AnsibleError:
        pass
    try:
        lookup_plugin.run({"not a list": "neither"}, None)
        assert False, "run should have failed because first argument is not a list"
    except AnsibleError:
        pass

# Generated at 2022-06-21 06:40:57.850614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:41:04.005999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_lookup = LookupModule()

    # check for mandatory terms
    try:
        module_lookup.run([], dict())
        assert False, "exception expected"
    except AnsibleError:
        pass

    # test term conversion
    data = module_lookup.run([{'a': 1}, 'a', dict()], dict())
    assert data == [(1,)]


test_LookupModule_run()

# Generated at 2022-06-21 06:41:15.386348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with terms = [[{'skipped': True}], 'x.y.z']
    data = [[{'skipped': True}], 'x.y.z']
    assert LookupModule().run(data, dict()) == []


    # Test with terms = [{'skipped': True}, 'x.y.z']
    data = [{'skipped': True}, 'x.y.z']
    assert LookupModule().run(data, dict()) == []

    # Test with terms = [[{'skipped': True, 'x': {'y': ['1', '2', '3']}}], 'x.skipped']
    data = [[{'skipped': True, 'x': {'y': ['1', '2', '3']}}], 'x.skipped']

# Generated at 2022-06-21 06:41:16.636176
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-21 06:41:17.119836
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:41:29.523595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins


# Generated at 2022-06-21 06:41:39.444279
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()

    # Test for invalid input
    for term in (None, "", {}, [], "two elements", ["one", "two", "three"]):
        try:
            lookup._process_terms(term, None, None)
        except AnsibleError:
            continue
        assert False, "Invalid term '%s' should have failed lookup"%(term)

    # Test for valid input

# Generated at 2022-06-21 06:42:12.645606
# Unit test for constructor of class LookupModule
def test_LookupModule():

    variables = {}
    LookupModule(loader=None,templar=None, variables=variables)



# Generated at 2022-06-21 06:42:14.470277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:42:27.475143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_simple_lists
    assert LookupModule().run(["test_list", "1"], "{}") == [1, 2]
    assert LookupModule().run(["test_list", "0"], "{}") == [1]

    # test_dict_and_nested_list
    assert LookupModule().run(["test_dict", "a"], "{}") == ['b', 'c']
    assert LookupModule().run(["test_dict", "b"], "{}") == [1, 2]

    # test_dict_and_nested_dict
    assert LookupModule().run(["test_dict2", "a", "skip_missing"], "{}") == [['x', 'y']]

    # test_dict_and_nested_dict_with_missing_key

# Generated at 2022-06-21 06:42:38.148706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    from ansible.plugins.lookup import LookupModule
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # set up required fixtures for this unit test
    data = [
        {'name': 'Alice', 'groups': ['wheel', 'users', 'other']},
        {'name': 'Bob', 'groups': ['other']}
    ]

    class MockLoader:
        """Mock loader class"""
        def get_basedir(self, fn):
            return ""

    class MockTemplar:
        """Mock templar class"""
        def __init__(self, loader, variables):
            self._loader = loader
            self._variables = variables

    class MockVariableManager:
        """Mock variable manager class"""

# Generated at 2022-06-21 06:42:45.214639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils import variable
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    variable_manager._options = {'_ansible_vault_password_file': ''}
    inventory = Inventory(variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    myLookupModule = LookupModule()
    myLookupModule._templar = variable.Variable('_templar')
    myLookupModule._loader = variable.Variable('_loader')
    myLookupModule.set_options(variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 06:42:52.129699
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 2 == len(l.run([[{'key1': ['value1']}], 'key1'], None))
    assert 1 == len(l.run([[{'key1': ['value1']}], 'key2'], None))
    assert 1 == len(l.run([[{'key1': ['value1']}], 'key2'], None, skip_missing=True))
    assert 2 == len(l.run([{'key1': {'key2': 'value1'}}, 'key1.key2'], None))

# Generated at 2022-06-21 06:43:04.697448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from unittest import mock
    except ImportError:
        import mock


# Generated at 2022-06-21 06:43:14.525832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.template import Templar

    mylookup = LookupModule()

    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    # test string
    terms = [users, 'authorized']
    result = mylookup.run(terms, dict(basedir='.'))

# Generated at 2022-06-21 06:43:26.069066
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:43:37.007531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # param: terms
    # term[0]: elementlist
    # term[0][0]: item0
    # term[1]: subkey
    # term[2]: flags (optional)
    # flags['skip_missing']: skip or fail on missing subkey

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, patch

    elementlist = [
        {'subkey1': {'subkey2': [1, 2, 3]}},
        {'subkey1': {'subkey2': [4, 5, 6]}, 'subkeyX': 'subkeyX'},
        {'subkey1': {'subkeyY': 'subkeyY'}}
    ]


# Generated at 2022-06-21 06:45:06.744591
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import __main__
    import sys
    import os
    import yaml
    lookup = LookupModule()

    # test list of dictionaries as input
    with open("test/lookup_plugins/gen_lookup_vars.yml", 'r') as stream:
        testvars = yaml.load(stream)
    testvars['_terms'] = ('list_of_dictionaries', 'subkey')
    testvars['value'] = testvars['users']
    testvars['subkey'] = 'authorized'
    testvars['skip_missing'] = False
    sys.argv = ['/usr/bin/ansible', '-vvvv']
    setattr(__main__, "__file__", 'ansible')

# Generated at 2022-06-21 06:45:11.501929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = 'bar'
    test = LookupModule()
    test.set_options({'foo': foo})
    result = test.run([], {})
    assert result == [('foo', foo)]

# Generated at 2022-06-21 06:45:19.051894
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu.run([["a"], "b"], {}) == [], 'run() should return a empty list when terms[0] is not a list of dictionaries and terms[1] is a string'
    assert lu.run([{"a": "b"}, "a"], {}), 'run() should return a list when terms[0] is a dictionary and terms[1] is a string and present as a key'

    data = [{"a": 1}, {"a": 2}]
    assert lu.run([data, "a"], {}) == [({"a": 1}, 1), ({"a": 2}, 2)], 'run() should return a list of tuples when terms[0] is a list of dictionaries and terms[1] is a string and present as a key'

# Generated at 2022-06-21 06:45:25.916079
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # instantiate
    lm = LookupModule()
    # run method
    r = lm.run([[{'name': 's', 'hosts': []}], 'hosts'], {}, **{'skip_missing': False})
    # evaluate results
    assert r == [({'hosts': [], 'name': 's'}, [])]

# Generated at 2022-06-21 06:45:36.161448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # test good terms
    terms_1 = [[{"a": [{"b": 1}, {"b": 2}]}, "a.b"]]
    assert lookup.run(terms=terms_1, variables=None) == [({"a": [{"b": 1}, {"b": 2}]}, {"b": 1}),
                                                      ({"a": [{"b": 1}, {"b": 2}]}, {"b": 2})]
    terms_2 = [[{"a": [{"b": 1}, {"b": 2}]}, "a.b.c"]]
    assert lookup.run(terms=terms_2, variables=None) == []
    terms_3 = [[{"a": [{"b": 1}, {"b": 2}]}, "a.b", {"skip_missing": True}]]

# Generated at 2022-06-21 06:45:45.834524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test Helpers
    class TestAnsibleModule(object):
        def fail_json(self, *args, **kwargs):
            return {'failed': True, 'msg': kwargs['msg']}

    class TestAnsiblePluginLookupBase(object):
        def __init__(self, templar, loader):
            self._templar = templar
            self._loader = loader

    class TestAnsibleTemplar(object):
        def __init__(self, ds):
            self.starting_data_scope = {'skip_missing': False}
            self.available_variables = ds

    class TestAnsibleLoader(object):
        pass

    def run_test(test_input, expected_output):
        lookup_module = LookupModule()
        lookup_module._templ

# Generated at 2022-06-21 06:45:51.603746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-21 06:46:02.614536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # check handling of invalid input
    # check raise of error on invalid input (non-dict)
    try:
        lookup.run([("a", "b"), "foo"])
        assert False, "Expected error"
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a dictionary, got '('a', 'b')'"

    # check raise of error on invalid input
    try:
        lookup.run([{"a": "b"}, "foo"])
        assert False, "Expected error"
    except AnsibleError as e:
        assert e.message == "the key a should point to a list, got 'b'"

    # check return of empty result on empty input
    res = lookup.run([{}, "foo"])

# Generated at 2022-06-21 06:46:03.655544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: create test
    pass

# Generated at 2022-06-21 06:46:15.028121
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test 1
    terms = [
        [{
            'a': {
                'list': ['b']
            }}],
        'a.list'
    ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)
    assert result == [({'a': {'list': ['b']}}, 'b')]

    # Test 2
    terms = [
        {
            'skip_me': {
                'a': {
                    'list': ['b']
                }},
            'take_me': {
                'a': {
                    'list': ['c']
                }}},
        'a.list'
    ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)