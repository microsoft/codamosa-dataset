

# Generated at 2022-06-21 06:37:59.449559
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:38:08.363896
# Unit test for constructor of class LookupModule
def test_LookupModule():
    users = [{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel'], 'name': 'alice', 'mysql': {'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL']}}, {'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'hosts': ['db1'], 'password': 'other-mysql-password', 'privs': ['*.*:SELECT', 'DB2.*:ALL']}, 'name': 'bob'}]

    # Test invalid parameters

# Generated at 2022-06-21 06:38:12.936086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_text
    import ansible.module_utils.basic

    # These two objects represent the original call parameters
    terms = ["users", "mysql.hosts", {"skip_missing": True}]
    variables = {}

    # These two objects mock the objects of ansible
    class DataLoader:
        class utils:
            class vars:
                @staticmethod
                def all():
                    return {}

    class VariableManager:
        def __init__(self, loader, inventory, *args, **kwargs):
            pass

    # ansible.utils.plugins.LookupBase does not have a constructor
    lookup = LookupModule()

# Generated at 2022-06-21 06:38:24.624495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    terms = [[{'name': 'alice', 'authorized': ['authorized_key_for_alice']},
              {'name': 'bob', 'authorized': ['authorized_key_for_bob']}], 'authorized']
    result = lookup_instance.run(terms, {})
    assert(result == [({'name': 'alice', 'authorized': ['authorized_key_for_alice']}, 'authorized_key_for_alice'),
                      ({'name': 'bob', 'authorized': ['authorized_key_for_bob']}, 'authorized_key_for_bob')])


# Generated at 2022-06-21 06:38:26.262639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert subelements

# Generated at 2022-06-21 06:38:30.137012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.parsing.convert_bool import boolean

    assert isinstance(LookupModule, object)
    assert issubclass(LookupModule, LookupBase)
    assert hasattr(LookupModule, 'run') and callable(getattr(LookupModule, 'run'))

# Generated at 2022-06-21 06:38:42.265746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    # Add path so we can import command line module
    sys.path.append('/home/serge/ansible/lib/ansible/modules')
    from ansible_module import AnsibleModule
    from ansible.module_utils.six import string_types
    from datetime import datetime
    from time import mktime

    module = AnsibleModule(argument_spec={})
    now = datetime.now()
    start = mktime(now.timetuple())
    module.params = {'input': [{'name': 'alice',
                                'authorized': ['/tmp/alice/onekey.pub',
                                               '/tmp/alice/twokey.pub']}]}
    lu = LookupModule()

    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-21 06:38:43.008640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:38:55.049935
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:39:04.742555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    try:
        lookup.run([], {}, [])
    except AnsibleError as e:
        assert e.message.startswith("subelements lookup expects a list of two or three items, ")

    try:
        lookup.run(['something'], {}, [])
    except AnsibleError as e:
        assert e.message.startswith("subelements lookup expects a list of two or three items, ")

    try:
        lookup.run(['something', 'something'], {}, [])
    except AnsibleError as e:
        assert e.message.startswith("subelements lookup expects a list of two or three items, ")


# Generated at 2022-06-21 06:39:13.953558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Generated at 2022-06-21 06:39:16.482703
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    if not isinstance(lookup_module, LookupModule):
        raise AssertionError()


# Generated at 2022-06-21 06:39:18.878100
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not isinstance(lookup, dict)
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 06:39:19.903009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 06:39:30.532920
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import unittest.mock as mock

    class TestVariables:  # dict

        def get(self, key):
            return self.__dict__[key]

    class TestTemplar:  # dict

        def __init__(self):
            self.__dict__ = {
                '_available_variables': TestVariables(),
                'templar': self
            }

        def is_safe_attribute(self, var):
            return var in self.__dict__

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value


# Generated at 2022-06-21 06:39:31.333005
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule  # silence pyflakes

# Generated at 2022-06-21 06:39:43.378651
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:39:52.045898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up an instance of the class
    subelements = LookupModule()
    subelements.set_options({})


    # generate a test-list to be used as the first term, then invoke lookup

# Generated at 2022-06-21 06:40:03.003675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            super(TestLookupModule, self).__init__(loader, templar, **kwargs)
    t = TestLookupModule()

    # test case: skip_missing=True, no subelements
    terms = [{'a': {'b': [0, 1, 2, 3]}, 'b': {'b': [0, 1, 2]}}, 'b.b', {'skip_missing': True}]
    q = t.run(terms, {})

# Generated at 2022-06-21 06:40:14.155356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

# Generated at 2022-06-21 06:40:31.043769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Skip test for constructor of class LookupModule.
    """



# Generated at 2022-06-21 06:40:41.895093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.context import context
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating import Templar

    if PY2:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    else:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes as AnsibleUnsafeText


# Generated at 2022-06-21 06:40:51.971124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    terms = listify_lookup_plugin_terms([{
        'skipped': False,
        'name': 'alice',
        'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
        'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']},
        'groups': ['wheel'],
        'otherkeys': 'ignore'
    }], loader=None, templar=None)
    variables = {'_original_file': '', 'ansible_env': {}, 'ansible_version': '', 'hostvars': {}}


# Generated at 2022-06-21 06:41:04.572775
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 06:41:15.921734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create object
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None

    # make users var

# Generated at 2022-06-21 06:41:27.914489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    test_LookupModule = LookupModule()

# Generated at 2022-06-21 06:41:38.004424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class OptionsModuleHelper:
        def __init__(self, value):
            self.value = value

        def get_option(self, name, *args, **kwargs):
            if name == 'skip_missing':
                return boolean(self.value, strict=False)
            raise KeyError('unknown option: %s' % name)

    class Find_FileModuleHelper:
        def __init__(self, value):
            self.value = value

        def find_needle(self, haystack, *args, **kwargs):
            if haystack == '/tmp/alice/onekey.pub':
                return self.value
            return haystack

    class TemplarModuleHelper:
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-21 06:41:45.253024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup arguments for the test
    module = LookupModule()
    lookup_plugin = module.run([
        [
            {
                'name': 'alice',
                'mysql': {
                    'password': 'mysql-password',
                    'hosts': [
                        '%',
                        '127.0.0.1',
                        '::1',
                        'localhost']}},
            {
                'name': 'bob',
                'mysql': {
                    'password': 'other-mysql-password',
                    'hosts': [
                        'db1'],
                    'privs': [
                        '*.*:SELECT',
                        'DB2.*:ALL']}}
        ],
        'mysql.hosts'], {})
    # evaluate the results

# Generated at 2022-06-21 06:41:46.329664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LUM = LookupModule()
    assert LUM

# Generated at 2022-06-21 06:41:57.297359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    source = """
---
users:
  - name: alice
    authorized:
      - /tmp/alice/onekey.pub
      - /tmp/alice/twokey.pub
  - name: bob
    authorized:
      - /tmp/bob/id_rsa.pub
"""
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    lookup_plugin = LookupModule()
    result = lookup_plugin.run([source, 'authorized'], variable_manager.get_vars())

# Generated at 2022-06-21 06:42:29.440527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 06:42:35.466961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [{ "name" : "alice", "groups" : ["wheel"] }, { "name" : "bob", "groups" : ["wheel"] }],
        "groups"
    ]
    sub_class = LookupModule()
    result = sub_class.run(terms, None)
    assert result == [("alice", "wheel"), ("bob", "wheel")]

# Generated at 2022-06-21 06:42:36.572244
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # not implemented yet
    assert True is True

# Generated at 2022-06-21 06:42:40.227824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    :param test_config:
    :return:
    """
    module = LookupModule()
    result = module.run(terms="tests")
    assert result == []


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:42:51.809989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_data = [
        ([['a', 'b'], "key"], ['a', 'b'], "subkey"),
        ([['a', 'b']], ['a', 'b'], "subkey"),
        ([['a', 'b'], "key"], ['a', 'b'], "subkey", {'skip_missing': True}),
        ([['a', 'b'], "key"], ['a', 'b'], "subkey", {'skip_missing': False}),
    ]
    for input, expected_elements, expected_subkey, expected_flags in test_data:
        module = LookupModule(None, None)

        # check terms
        elements, subkey, flags = module._terms(input)

# Generated at 2022-06-21 06:43:03.981576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_ok: All terms are correct
    terms = [
        [        # Directory of users
            { "name": "user1",
              "host": [ "example.com", "example.net" ]
            },
            { "name": "user2",
              "host": [ "example.com", "example.net", "example.org" ]
            },
            { "name": "user3",
              "host": [ "example.org" ]
            }
        ],
        "host"                                                 # Subkey to extract
    ]
    lm = LookupModule()
    result = lm.run(terms, '', '')

    # Checking results with asserts

# Generated at 2022-06-21 06:43:14.179808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test running method with valid and invalid parameters
    # test raising error on invalid subkey
    users = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]}, {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}]
    terms = [users, "authorized"]
    # look for existing subkey

# Generated at 2022-06-21 06:43:15.441122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-21 06:43:18.657955
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(['~/ansible/lib/ansible/plugins/lookup/subelement.py'], '127.0.0.1')

# Generated at 2022-06-21 06:43:19.784734
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l != None

# Generated at 2022-06-21 06:44:39.388416
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test method run with setting up a '_templar' and '_loader'
    # and given 'terms' and 'variables'
    # and returning a result 'ret'
    # (see test_runner.py for more information)
    LookupModule.test = lambda self, terms, variables, **kwargs: (self, terms, variables, kwargs)

    # create object of class LookupModule
    lm = LookupModule()

    # set _templar and _loader attributes
    lm._templar = True
    lm._loader = True

    # call method run

# Generated at 2022-06-21 06:44:50.208050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarsModule:
        class VarsModuleDict(dict):
            def __getitem__(self, key):
                return key
        def __init__(self):
            self.vars = self.VarsModuleDict()

    class LoaderModule:
        class FileLoaderModuleDict(dict):
            def get(self, key, default=None):
                return {'topkey': 'topvalue'}[key]
        def __init__(self):
            self.files = self.FileLoaderModuleDict()

    class TemplarModule:
        def __init__(self):
            self.basedir = None

# Generated at 2022-06-21 06:44:52.897913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    y = LookupModule()

# Generated at 2022-06-21 06:45:03.425114
# Unit test for constructor of class LookupModule
def test_LookupModule():
  with pytest.raises(AnsibleError) as result:
    lookups.LookupModule().run(["list", "string"], dict())
    assert "subelements lookup expects a list of two items, first a dict or a list, second a string pointing to the subkey" not in result
  assert lookups.LookupModule().run(["list", "string"], dict()) != None
  with pytest.raises(AnsibleError) as result:
    lookups.LookupModule().run(["list", "string", "flags"], dict())
    assert "subelements lookup expects a list of two items, first a dict or a list, second a string pointing to the subkey" not in result
  assert lookups.LookupModule().run(["list", "string", "flags"], dict()) != None
  return

# Generated at 2022-06-21 06:45:04.007212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-21 06:45:15.332186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #### Scenario: List of dicts with multiple values

    # Given an existing LookupModule with keyed data
    lookup_plugin = LookupModule()
    args = [{
        'key-1': {
            'key-1a': {
                'key-1a1': ['value-1-1a', 'value-1-2a']
            },
            'key-1b': {
                'key-1b1': ['value-1-1b', 'value-1-2b']
            }
        },
        'key-2': {
            'key-2a': {
                'key-2a1': ['value-2-1a', 'value-2-2a']
            }
        },
        'skipped': False
    }, 'key-1a.key-1a1']

   

# Generated at 2022-06-21 06:45:18.893568
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [{'name': 'alice'}, {'name': 'bob'}],
        "name",
        {'skip_missing': True},
    ]

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None, None)
    expected = [('alice',), ('bob',)]
    assert result == expected


# Generated at 2022-06-21 06:45:22.182551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._load_name = 'test'
    return lookup_module


# Generated at 2022-06-21 06:45:34.146307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    lu = LookupModule()

    # check testdata

# Generated at 2022-06-21 06:45:43.915699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare for tests
    import __builtin__
    setattr(__builtin__, '_', lambda x: x)
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
