

# Generated at 2022-06-21 06:37:59.355343
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

# Generated at 2022-06-21 06:38:07.380895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils.parsing.convert_bool import boolean
    assert listify_lookup_plugin_terms([[1, 2], 3, 4], templar=None, loader=None) == [1, 2, 3, 4]
    assert listify_lookup_plugin_terms({'q': [1, 2], 'w': 3, 'e': 4}, templar=None, loader=None) == {'q': 1, 'w': 3, 'e': 4}

# Generated at 2022-06-21 06:38:16.861419
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # imports
    import sys
    import os
    # add .. to module path to find lookup_plugins
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from ansible.plugins.loader import lookup_loader

    # Arrange

    lookup_module = lookup_loader.get('subelements')

    # Act
    lookup_module.run([{'key1': [1, 2, 3], 'key2': [4, 5], 'key3': [4, 5]}], None)

    # Assert
    assert 1 == 2

# Generated at 2022-06-21 06:38:19.998709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([[{'key': 'value'}], 'key'], dict())

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:38:21.953472
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 06:38:27.351463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ LookupModule: test run() method """

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # import of required modules
    import ansible.plugins.lookup.subelements

    # initialize AnsibleModule object
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # initialize LookupModule class object
    lookup_instance = ansible.plugins.lookup.subelements.LookupModule()

    # set options
    lookup_instance.set_options({})

    # declare argument list

# Generated at 2022-06-21 06:38:39.738169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import copy

    class TestLookupModule(unittest.TestCase):

        # terms = ('list of items','key to extract','optional flags')
        def assertSubdict(self, terms, result, error=None):
            self.assertEqual(
                LookupModule.run(self,[terms],{}),
                result,
                error
                )

        def test_no_items(self):
            terms = ('', 'mysql')
            self.assertSubdict(terms, [], "No items should return an empty list")

        def test_empty_dict(self):
            terms = ({}, 'mysql')
            self.assertSubdict(terms, [], "Empty dict should return an empty list")


# Generated at 2022-06-21 06:38:47.513113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupBase
    l = LookupBase()
    l.set_options(direct={'key':'value'})
    l.run([1, 2, 3], dict(a=1, b=2))
    l.filter('string', 'pattern', 'replacement')
    l.get_basedir('templates')
    l.get_basedir('files')
    l.get_basedir('vars')
    l.get_basedir('roles/myrole/tasks')

# Generated at 2022-06-21 06:38:48.413643
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:38:51.009471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run([{'key': 'jira.base_url'}, 'jira.base_url'], None)



# Generated at 2022-06-21 06:39:08.740099
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of the class LookupModule.
    """
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:39:11.033303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['host:127.0.0.1', 'port'],
                             variables={}) == [('127.0.0.1', '22')]


# Generated at 2022-06-21 06:39:11.940830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-21 06:39:22.282653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import b

    # Parameters
    terms = [
        {'first':
            {'subelements': 'firstsubelement'},
         'second':
            {'subelements': 'secondsubelement'},
         },
        'subelements'
    ]
    variables = {"elementlist": '[]'}
    lookup_module = LookupModule()
    lookup_module._loader = None
    lookup_module._templar = None

    # Code to test
    lookup_module.run(terms, variables)

    # Check result
    #print(lookup_module.run(terms, variables))
    assert 0 == 1

# Generated at 2022-06-21 06:39:32.012963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    # prepare environment
    loader = DataLoader()
    lookup_plugin = LookupModule()

    # tests
    #
    # simple testcase, two complete records

# Generated at 2022-06-21 06:39:33.196166
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:39:46.334948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.loader import lookup_loader

    def to_text(value):
        if isinstance(value, str):
            return value
        if isinstance(value, unicode):
            return value.encode('utf-8')
        if isinstance(value, bool):
            if value:
                return "true"
            else:
                return "false"
        return str(value)

    module = AnsibleUnsafeText(u"\"subelements\"")

# Generated at 2022-06-21 06:39:48.867007
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run(["{'key1': 'value1'}"], {}, None) == [('value1',)]

# Unit tests for method _raise_terms_error of class LookupModule

# Generated at 2022-06-21 06:39:58.024730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    module_loader = DataLoader()
    variable_manager = VariableManager()
    l = LookupModule()

    l.set_environment(variable_manager, '', module_loader)

    # Check error handling:
    terms = []
    assert l.run(terms, variables={}) == []
    terms = ["one", "two"]
    try:
        _ = l.run(terms, variables={})
        assert False
    except AnsibleError:
        assert True
  

# Generated at 2022-06-21 06:40:02.206816
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:40:29.489343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate
    # test for terms == None
    try:
        LookupModule(None)
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items,"
    # test for terms == list, but len(terms) != 2
    try:
        LookupModule([])
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items,"
    # test for terms == list, but len(terms) == 2, and terms[0] different from dict or list

# Generated at 2022-06-21 06:40:37.294689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    lm = LookupModule() # pylint: disable=invalid-name
    lm._templar = DummyTemplar() # pylint: disable=protected-access
    lm._loader = loader # pylint: disable=protected-access

    # test simple case
    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        }
    ]

# Generated at 2022-06-21 06:40:48.797922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    # Test multiplication
    terms = [[{'test1':'test1'}, {'test2':'test2'}], "test1"]
    ret = lk.run(terms, None)
    assert ret == [('test1',)]
    # Test multiplication
    terms = [[{'test1':'test1'}, {'test2':'test2'}], "test3"]
    ret = lk.run(terms, None, skip_missing=True)
    assert ret == []
    # Test multiplication
    terms = [[{'test1':'test1'}, {'test2':'test2'}], "test3"]

# Generated at 2022-06-21 06:40:55.922671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native


# Generated at 2022-06-21 06:41:07.814942
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # check lookup terms
    # check number of terms
    try:
        lookup_plugin.run(terms=[])
    except AnsibleError:
        pass

    # check number of terms
    try:
        lookup_plugin.run(terms=[1, 2, 3, 4])
    except AnsibleError:
        pass

    # first term should be a list (or dict), second a string holding the subkey
    try:
        lookup_plugin.run(terms=['test', 1])
    except AnsibleError:
        pass

    try:
        lookup_plugin.run(terms=[1, 'test'])
    except AnsibleError:
        pass

    # check for optional flags in third term

# Generated at 2022-06-21 06:41:17.550603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Let's create class attributes required for the test:
    templar = None
    loader = None
    # Let's create class object
    lookup_obj = LookupModule()
    # Let's set class attributes
    lookup_obj._loader = loader
    lookup_obj._templar = templar

    # Let's randomly create a few dictionaries and list with both valid and invalid structure for test cases
    # valid_dictionary
    valid_dictionary = {"dict_key_1":{"mysql":{"hosts":["%", "127.0.0.1", "::1", "localhost"],"privs":["*.*:SELECT", "DB1.*:ALL"],"password":"mysql-password"},"name":"alice","authorized":["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"],"groups":["wheel"]}}
    #

# Generated at 2022-06-21 06:41:25.862555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert listify_lookup_plugin_terms([], templar=None, loader=None) == []
    assert listify_lookup_plugin_terms(('alice', 'bob'), templar=None, loader=None) == ['alice', 'bob']
    assert listify_lookup_plugin_terms({'var1': 'alice', 'var2': 'bob'}, templar=None, loader=None) == ['alice', 'bob']

# Generated at 2022-06-21 06:41:36.420948
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup = LookupModule()

    assert lookup.run([['a', 'b', 'c']], dict()), ['a', 'b', 'c']

    # with dict:
    assert lookup.run([{'a': 'a'}, {'b': 'b'}, {'c': 'c'}], dict()), [{'a': 'a'}, {'b': 'b'}, {'c': 'c'}]

    # subelements

# Generated at 2022-06-21 06:41:44.317941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest


# Generated at 2022-06-21 06:41:50.667486
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create the lookup module
    lookup_module = LookupModule()

    # Retrieve the value of the variable 'ansible_distribution'
    result = lookup_module.run(['ansible_distribution'], dict(redhat=dict(), ansible_distribution='CentOS'))

    # Check the retrieved value
    assert result == ['CentOS']

# Generated at 2022-06-21 06:42:10.173890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 06:42:18.067071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("\n*** unit test subelements lookup")
    #import doctest
    #doctest.testmod()

    # doctest above doesn't catch everything, tests below to be removed when doctest is working
    lookup_module = LookupModule()
    # test a list of dictionaries, with subelement key
    result = lookup_module.run([{'one': {"two": ['a', 'b', 'c']}, 'two': {"two": ['a']}}], variables=None, **{})

# Generated at 2022-06-21 06:42:29.306176
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class mock_templar(object):
        def __init__(self, var):
            self.var = var
        def template(self):
            return self.var

    term1 = {'one': {'two': [1, 2, 3]}, 'two': {'three': [3, 4, 5]}, 'three': {'four': [6, 7, 8]}}
    term2 = 'one.two'
    flags = 'skip_missing'

    terms = [term1, term2, flags]
    templar = mock_templar(terms)
    mod = LookupModule()
    mod.run(terms, templar)
    assert mod._templar.var == [term1, term2, flags]

# test with a list of dictionaries

# Generated at 2022-06-21 06:42:39.864568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=line-too-long
    """ Unit test for method run of class LookupModule """
    # allterms: second term, then first term

# Generated at 2022-06-21 06:42:51.808796
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin._templar = DummyTemplar()

    # test that keyerror is raised for invalid subkey
    assert lookup_plugin.run([{'item': {'name': 'serge'}}, 'test'],
                             DummyVars({})) == []

    # no subkey given
    assert lookup_plugin.run([{'item': {'name': 'serge'}}],
                             DummyVars({})) == []

    # test that looker raises a error when subkey is not found in items
    assert lookup_plugin.run([{'item': {'name': 'serge'}}, 'test', {'skip_missing': False}],
                             DummyVars({})) == []

    # test that lookup result is the expected result:

# Generated at 2022-06-21 06:43:00.081486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test run method of LookupModule class
    '''
    # Test for invalid number of arguments
    def _raise_terms_error():
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " )
    # Test for invalid type of arguments
    def _raise_terms_error1():
        raise AnsibleError(
            "subelements lookup expects a dict or a list, " )
    # Test for invalid type of arguments
    def _raise_terms_error2():
        raise AnsibleError(
            "subelements lookup expects a string pointing to the subkey" )
    # Test for invalid integer argument
    def _raise_terms_error3():
        raise AnsibleError(
            "could not find '%s' key in iterated item '%s'" )
    # Test for

# Generated at 2022-06-21 06:43:00.653369
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:43:01.550698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret

# Generated at 2022-06-21 06:43:09.034857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os.path
    lookup = LookupModule()

# Generated at 2022-06-21 06:43:10.020888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-21 06:43:53.477759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance
    lookup_module = LookupModule()
    # define test data

# Generated at 2022-06-21 06:44:05.084592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    mydict = dict(k1="v1", k2=dict(k3="v3", k4=dict(k5="v5", k6=[10, 20, 30])), k7=7)
    terms = [mydict, 'k2.k4.k6']
    assert lm.run(terms, None) == [(mydict, 10), (mydict, 20), (mydict, 30)]
    mylist = [dict(k1="v1"), dict(k2="v2", k3=dict(k4="v4")), dict(k2="v2", k4=dict(k5="v5", k6=[10, 20, 30]))]
    terms = [mylist, 'k4.k6']

# Generated at 2022-06-21 06:44:06.168567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)


# Generated at 2022-06-21 06:44:08.023527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) > 0

# Generated at 2022-06-21 06:44:17.551402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Define test input data

# Generated at 2022-06-21 06:44:27.471908
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # simple test for dict with string keys
    testlist = [{'foo': 'a', 'bar': 'b'}, {'foo': 'c', 'bar': 'd'}]
    subelements = 'foo'
    expected = [('a', ), ('c', )]
    result = LookupModule().run([testlist, subelements])[0]  # run returns a list with only one element
    assert result == expected, 'Expected %s, got %s' % (expected, result)

    # simple test for list of dicts with string keys
    testlist = [{'foo': 'a', 'bar': 'b'}, {'foo': 'c', 'bar': 'd'}]
    subelements = 'bar'
    expected = [('b', ), ('d', )]

# Generated at 2022-06-21 06:44:33.081420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import yaml
    yaml_data = """
    flags:
      - skip_missing
    """
    data = yaml.load(yaml_data, Loader=yaml.FullLoader)
    flags = LookupModule._variable_data_from_name(data, data=data)['flags']
    assert flags == {'skip_missing': True}


# Generated at 2022-06-21 06:44:39.575724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    # import
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.errors import AnsibleError

    # initialize
    lookup_plugin = LookupModule()

    # test raise TermsError
    try:
        lookup_plugin.run([], [])
        assert False
    except AnsibleError:
        pass
    try:
        lookup_plugin.run(1, [])
        assert False
    except AnsibleError:
        pass
    try:
        lookup_plugin.run([1, 'a'], [])
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-21 06:44:43.239434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-21 06:44:44.957284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm


# Generated at 2022-06-21 06:46:07.788887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import types
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:46:09.853748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 06:46:18.825180
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:46:20.123614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-21 06:46:21.852639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:46:32.355020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stubs:
    class StubTemplar:
        def __init__(self): pass
        def template(self, value): return value
    class StubLoader:
        def __init__(self): pass
        def get_basedir(self): return "tests"
    class StubModule_utils_listify:
        def __init__(self): pass
        def listify_lookup_plugin_terms(terms, templar, loader): return terms
    class StubModule_utils_parsing_convert_bool:
        def __init__(self): pass
        def boolean(value, strict): return value

    StubModule_utils_listify.listify_lookup_plugin_terms = StubModule_utils_listify()
    StubModule_utils_parsing_convert_bool.boolean = StubModule_utils_p

# Generated at 2022-06-21 06:46:40.923747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    import copy

    # init class
    module = LookupModule()

    # create params

# Generated at 2022-06-21 06:46:52.941605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms


# Generated at 2022-06-21 06:47:03.417275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule([], dict(), dict())
    assert "lookup expects a list of two or three items" in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        LookupModule(["users", "mysql.hosts", {}], dict(), dict())
    assert "lookup expects a dict or a list" in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        LookupModule([dict(), "mysql"], dict(), dict())
    assert "lookup expects a dict or a list" in str(excinfo.value)


# Generated at 2022-06-21 06:47:13.267949
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for the module"""
    import imp
    import sys
    import os

    f, filename, desc = imp.find_module('ansible')
    sys.path.append(os.path.dirname(filename))
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader()
    variable_manager = None

    # initialize test variable