

# Generated at 2022-06-21 06:37:47.272226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:37:49.655884
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # type: () -> None
    assert LookupModule(None, {}, {}, None, None, None)

# Generated at 2022-06-21 06:37:50.718432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule(), 'run')

# Generated at 2022-06-21 06:38:01.549000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance
    ##################################################
    lookup_instance = LookupModule()

    ##################################################
    # Test subelements.yml
    ##################################################
    # Test 1
    ##################################################
    print("Test 1")

# Generated at 2022-06-21 06:38:08.648260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    import json
    import copy

    class TestCallback(CallbackBase):
        """
        Test callback plugin
        """
        def v2_runner_on_ok(self, result):
            """
            Print a json representation of the result
            """
            host = result._host
            print(json.dumps({host.name: result._result}, indent=4))


# Generated at 2022-06-21 06:38:13.117320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit tests for 'run' require ansible.module_utils.basic.AnsibleModule (unittest.mock)
    import unittest.mock
    import ansible.module_utils.basic

    myexit = unittest.mock.MagicMock(name="exit")
    myfail = unittest.mock.MagicMock(name="fail_json")
    myexit.side_effect = ansible.module_utils.basic.AnsibleFailJson(msg="exit message")
    myfail.side_effect = ansible.module_utils.basic.AnsibleFailJson(msg="fail message")
    import ansible.plugins.lookup.subelements

# Generated at 2022-06-21 06:38:24.822014
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    res0 = lm.run([{'a': 'b', 'c': {'d': {'e': ['f', 'g']}}, 'h': 'i'}, 'c.d.e'], {})
    assert res0 == [({'c': {'d': {'e': []}}, 'h': 'i', 'a': 'b'}, 'f'),
                    ({'c': {'d': {'e': []}}, 'h': 'i', 'a': 'b'}, 'g')]

    res0 = lm.run([[{'a': 'b', 'c': {'d': {'e': ['f', 'g']}}, 'h': 'i'}], 'c.d.e'], {})

# Generated at 2022-06-21 06:38:28.448865
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule expects keyword arguments loader and tempalar
    tmplar = None
    loader = None
    lookup_module = LookupModule(loader=loader, templar=tmplar)
    assert lookup_module is not None

# Generated at 2022-06-21 06:38:41.004824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # empty terms error
    # invalid terms
    # dict terms
    # dict terms and flags
    # list terms
    # list terms and flags
    # list terms and second list in var
    # list terms and second list in var and flags
    # dict terms and second dict in var
    # dict terms and second dict in var and flags
    # dict terms and all vars skipped
    # list terms and all vars skipped

    # Test first term:
    # Test subelements:
    # Test flags:

    assert l.run([[1,2,3], 'name'], variables = None) == [
        ({'name': 'Alice'}, 'Alice'),
        ({'name': 'Bob'}, 'Bob'),
        ({'name': 'Charlie'}, 'Charlie'),
    ]
    assert l.run

# Generated at 2022-06-21 06:38:53.632779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup.subelements import LookupModule

    # unit test for method run of class LookupModule
    # check optional third term
    class TestCase(unittest.TestCase):
        lookup_module = LookupModule()

        def test_subelements_list_dict(self):
            elementlist = [{'mysql': {'privs': [], 'hosts': [], 'password': 'secret'}}, {'mysql': {'privs': [], 'hosts': [], 'password': 'secret'}}]
            subelements = 'mysql.privs'
            terms = [elementlist, subelements]

# Generated at 2022-06-21 06:39:06.488599
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__ == '''Subelements walks a list of hashes (aka dictionaries) and then traverses a list with a given (nested sub-)key inside of those records.
    Subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey
    the optional third item must be a dict with flags skip_missing'''

# Generated at 2022-06-21 06:39:06.911027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:39:14.123951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # One term
    terms1 = [{'a': 'this', 'b': 'that'}, 'a']
    ll = LookupModule()
    assert ll.run(terms1, {}) == ['this']

    # Two terms
    terms2 = [
        [{'a': 'this', 'b': 'that'}, {'a': 'this too', 'b': 'that too'}], 'a']
    ll = LookupModule()
    assert ll.run(terms2, {}) == ['this', 'this too']

    # Two terms with skipped items in dictionary
    terms3 = [
        {'first': {'a': 'this', 'b': 'that'}, 'second': {'skipped': True}, 'third': {'a': 'this too', 'b': 'that too'}}, 'a']
    ll

# Generated at 2022-06-21 06:39:25.096521
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    filename = "static/strdup.c"
    mylookup = LookupModule()
    data = mylookup.run([[{'skipped': True}], 'users'], None)
    assert data == []
    data = mylookup.run([[{'skipped': False}], 'users'], None)
    assert data == []
    data = mylookup.run([[{'skipped': False, 'users': 'peter'}], 'users'], None)
    assert data == [({'skipped': False, 'users': 'peter'}, 'peter')]

    raise AnsibleError("bla bla")



# Generated at 2022-06-21 06:39:33.454010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # use string for subkey
    module_input = {'users': [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]}
    module_result = module.run(terms=[module_input, 'authorized'], variables='')

# Generated at 2022-06-21 06:39:46.613001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar:
        def __init__(self):
            self.was_called = False
            self.var_result = None
        def template(self, var):
            self.var_result = var
            self.was_called = True
            return var

    class MockLoader:
        def __init__(self):
            self.was_called = False
            self.var_result = None


# Generated at 2022-06-21 06:39:53.435570
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [[{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}], 'authorized']
    assert LookupModule(terms, None, None, None).run([]) == [({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/onekey.pub'), ({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/twokey.pub')]

    # test with skip_missing=True

# Generated at 2022-06-21 06:40:04.103432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class MockTemplar(object):
        def __init__(self):
            self.called = []

        def template(self, val):
            self.called.append(val)
            return val

    class MockLoader(object):
        pass

    class MockVarsModule(object):
        pass

    class LookupModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.lookup = LookupModule()
            self.lookup.set_options({})
            self.lookup.templar = MockTemplar()
            self.lookup.loader = MockLoader()
            self.lookup

# Generated at 2022-06-21 06:40:06.962751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-21 06:40:17.984478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # test on correct terms
    terms = [
        {
            'user1': {
                'authorized': ['/tmp/user1/id_rsa.pub'],
                'groups': ['adm', 'audio', 'bluetooth', 'cdrom', 'dialout', 'dip', 'fuse', 'kvm'],
            },
            'user2': {
                'authorized': ['/tmp/user2/id_rsa.pub'],
                'groups': ['dialout', 'dip', 'fuse', 'kvm'],
            }
        },
        'authorized'
    ]
    result = lookup_obj.run(terms, variables=None)
    assert len(result) == 2

# Generated at 2022-06-21 06:40:35.069803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert callable(getattr(LookupModule, 'run', None))


# Generated at 2022-06-21 06:40:47.490879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.parsing.convert_bool import boolean

    assert isinstance(LookupModule, type)
    assert issubclass(LookupModule, object)
    assert 2 <= LookupModule.run.__code__.co_argcount <= 3

    module = LookupModule()
    assert isinstance(module, LookupModule)
    assert isinstance(module, object)
    assert isinstance(module._templar, object)
    assert isinstance(module._loader, object)
    assert isinstance(module.run, object)
    assert module.run.__self__ is module
    assert 2 <= module.run.__code__.co_argcount <= 3


# Generated at 2022-06-21 06:40:55.201860
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Options(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    lookup_plugin = LookupModule()

    # test with a dict

# Generated at 2022-06-21 06:41:08.484324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    # test with correct arguments
    data = dict()
    data['hostvars'] = [{'host1': {'user1': 1234, 'user2': 'abcd', 'serverlist': ['abc', 'def'], 'userlist': [{'username': 'username1', 'userid': 'userid1'}, {'username': 'username2', 'userid': 'userid2'}]}},
                        {'host2': {'user1': 1234, 'user2': 'abcd', 'serverlist': ['abc', 'def'], 'userlist': [{'username': 'username1', 'userid': 'userid1'}]}}
                        ]
    data['userlist'] = [['username1', 'username2']]

# Generated at 2022-06-21 06:41:18.021943
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:41:30.563768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test with empty array
    res = module.run(terms=[], variables=None)
    assert res == []

    # test with valid array
    res = module.run([[{'subkey': ['subvalue']}], 'subkey'], variables=None)
    assert res == [({"subkey": ["subvalue"]}, "subvalue")]

    # test with valid array with flags
    res = module.run([[{'subkey': ['subvalue']}], 'subkey', {'skip_missing': True}], variables=None)
    assert res == [({"subkey": ["subvalue"]}, "subvalue")]

    # test with invalid array (wrong number of terms)

# Generated at 2022-06-21 06:41:33.474481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    s = LookupBase()
    assert(isinstance(s, LookupBase))
    assert(s._templar == None)
    assert(s._loader == None)


# Generated at 2022-06-21 06:41:42.413527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run([[], "", {}])
    assert result == []

    result = LookupModule().run([[], "", {"skip_missing": True}])
    assert result == []

    result = LookupModule().run([[], "", {"skip_missing": False}])
    assert result == []

    result = LookupModule().run([{"a": 1, "b": 2}, "", {"skip_missing": True}])
    assert result == []

    try:
        result = LookupModule().run([{"a": 1, "b": 2}, "", {"skip_missing": False}])
        assert result == []
    except AnsibleError:
        # lookup error, as expected
        pass
    else:
        raise AssertionError("Unexpected result: {0}".format(result))


# Generated at 2022-06-21 06:41:51.993948
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert len(lookup.run([['a','b','c'], 'name'], {})) == 3
    assert len(lookup.run([{'a': {'name': 'alice'}, 'b': {'name': 'bob'}}, 'name'], {})) == 2
    assert len(lookup.run([{'a': {'name': 'alice'}, 'b': {'name': 'bob'}}, 'name', {'skip_missing': True}], {})) == 2

# Generated at 2022-06-21 06:42:02.315392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupModule
    from ansible.utils.display import Display
    from ansible.template import Templar

    # save the original plugin dir
    original_lookup_plugin_path = lookup_loader.lookup_basedirs['lookup']

    # setup the test lookup plugin dir

# Generated at 2022-06-21 06:42:42.498075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test, see https://docs.python.org/2/library/unittest.html
    """
    import unittest
    import sys
    import os
    sys.path.append('.')  # this is the dir where the file is located

    ansible = os.path.dirname(os.path.dirname(__file__))
    test_vars = os.path.join(ansible, 'test/vars')
    with open(test_vars) as fh:
        vars = fh.read()

    from ansible.utils.listify import listify_lookup_plugin_terms

    test_lookup = LookupModule()
    test_lookup.set_options({})


# Generated at 2022-06-21 06:42:53.787152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Test for when two terms are passed in
    terms = ["users", "authorized"]

# Generated at 2022-06-21 06:42:57.646112
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print("test_LookupModule => {}".format(lookup_module))

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:43:09.524648
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.module_utils.parsing.convert_bool as convert_bool
    import mock # for mocking timer.sleep
    from ansible.module_utils.six import PY3 # only used in one test below
    from ansible.plugins.lookup import LookupBase

    print("Testing ansible.plugins.lookup.subelements")

    # simulate the runtime environment
    class TestEnv(object):
        class TestModule(object):
            class TestParams(object):
                ansible_lookup_plugin_requests = None

        class TestTemplar(object):
            pass

        class TestLoader(object):
            pass

    env = TestEnv()
    env.module = env.TestModule()
    env.module.params = env.module.TestParams()
    env.templar = env

# Generated at 2022-06-21 06:43:10.509695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run()

# Generated at 2022-06-21 06:43:13.445891
# Unit test for constructor of class LookupModule
def test_LookupModule():
   print("testing LookupModule")


# Generated at 2022-06-21 06:43:14.719917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-21 06:43:18.797656
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lk = LookupModule()
    terms = [
        [
            {"item1": {"foo": "bar", "bar": "bla"}},
        ],
        "foo",
    ]
    ret = lk.run(terms, {}, **{})
    assert isinstance(ret, list)
    assert ret == [("bar",)]



# Generated at 2022-06-21 06:43:27.993409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with simple key/value
    terms = []
    terms.append(
        [{'a': {'b': [1, 2, 3]}}]
    )
    terms.append('a.b')
    lookup_instance = LookupModule()
    assert lookup_instance.run(terms, {}) == [(({'a': {'b': [1, 2, 3]}}, 1)), (({'a': {'b': [1, 2, 3]}}, 2)), (({'a': {'b': [1, 2, 3]}}, 3))]
    return True



# Generated at 2022-06-21 06:43:29.876563
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(hasattr(LookupModule, '__init__'))
    assert(LookupModule.__init__ is not None)



# Generated at 2022-06-21 06:44:51.346413
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:44:54.915538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    t = lm.run([['a', 'b', 'c'], 'd'], None)
    assert t == [('a', 'd'), ('b', 'd'), ('c', 'd')]

# Generated at 2022-06-21 06:45:04.938540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    lookup_instance = LookupModule()
    assert hasattr(lookup_instance, 'run')

        # check terms
    terms = [1, 2, 3]
    try:
        lookup_instance.run(terms, None)
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message

    terms = ["abc"]
    try:
        lookup_instance.run(terms, None)
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message

    terms = [["abc"], "def"]

# Generated at 2022-06-21 06:45:16.152421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    import ansible.utils.unsafe_proxy

    # Skip the test if run along with ansible suite, called by:
    # python test/runner/lib/modules/lookup/test_subelements.py
    # https://github.com/ansible/ansible/issues/31300
    # Not using ansible.utils.unsafe_proxy.safe_hasattr because it would
    # have the same issue if 'ansible.utils.unsafe_proxy' was mocked
    if 'global_proxy' in vars(ansible.utils.unsafe_proxy):
        return

    class MockTemplar:

        def __init__(self):
            self.var = {}
            self.var_kwargs = {}

        def template(self, terms, **kwargs):
            assert isinstance(term, list)


# Generated at 2022-06-21 06:45:17.216059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-21 06:45:29.144536
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY2
    # Prepare variables for unit test

# Generated at 2022-06-21 06:45:39.814968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    class LookupModuleMock(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            pass

    def run_mock(terms, variables, **kwargs):
        assert isinstance(terms, list)
        assert isinstance(terms[0], list)
        lookup_name = terms[0][0]
        assert isinstance(lookup_name, basestring)
        assert terms[0][1] == "who"
        assert isinstance(terms[0][2], dict)
        assert isinstance(terms[1], dict)
        assert isinstance(terms[2], dict)
        assert isinstance(terms[3], dict)


# Generated at 2022-06-21 06:45:48.105765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # invalid number of terms
    # test no terms
    terms = []
    try:
        lookup_module.run(terms, {}, **{})
        assert False
    except AnsibleError:
        assert True

    # test 1 term
    terms = [
        {'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    try:
        lookup_module.run(terms, {}, **{})
        assert False
    except AnsibleError:
        assert True

    # test 4 terms
    terms = [
        {'authorized': ['/tmp/bob/id_rsa.pub']},
        'authorized',
        {},
        "garbage-param"
    ]

# Generated at 2022-06-21 06:45:59.147986
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:46:10.700839
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialise the templar
    templar = Templar(loader=DataLoader(), variables={})

    # test normal list
    input = [{'a': {'x': [1, 2, 3]}}, {'b': {'x': [4, 5, 6]}}]
    terms = [input, 'x']
    expected = [({'a': {'x': [1, 2, 3]}}, 1), ({'a': {'x': [1, 2, 3]}}, 2), ({'a': {'x': [1, 2, 3]}}, 3), ({'b': {'x': [4, 5, 6]}}, 4), ({'b': {'x': [4, 5, 6]}}, 5), ({'b': {'x': [4, 5, 6]}}, 6)]