

# Generated at 2022-06-21 06:37:55.941780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    lu = LookupModule()
    lu._templar = None
    lu._loader = None

    # check lookup terms - check number of terms
    if not isinstance(terms, list) or not 2 <= len(terms) <= 3:
        _raise_terms_error()

    # first term should be a list, second a string holding the subkey
    if not isinstance(terms[0], (list, dict)) or not isinstance(terms[1], string_types):
        _raise_terms_error("first a dict or a list, second a string pointing to the subkey")
    subelements = terms[1].split(".")


# Generated at 2022-06-21 06:38:05.335613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule:run()
    """
    lm = LookupModule()
    lm.set_options()
    lm.set_loader()
    lm.set_templar()

# Generated at 2022-06-21 06:38:17.324271
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:38:18.406905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:38:29.460656
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _create_lookup_object(terms):
        l = LookupModule()
        l.set_options({})
        l.set_env({})
        l.templar = None
        return l.run(terms, None)

    # test correct format of terms list
    try:
        res = _create_lookup_object([])
    except Exception as e:
        assert type(e) is AnsibleError
    try:
        res = _create_lookup_object([1, 2, 3, 4, 5])
    except Exception as e:
        assert type(e) is AnsibleError


# Generated at 2022-06-21 06:38:41.217481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    longdict = {
        'test': {
            'test2': {
                'test3': {
                    'l': [
                        1,
                        2,
                        3
                    ]
                }
            }
        }
    }
    shortdict = {
        'test': {
            'test2': {
                'test3': {
                    'l': [
                        1,
                        2,
                        3
                    ]
                }
            }
        }
    }
    unicodedict = {
        'test': {
            'test2': {
                'test3': {
                    u'l': [
                        1,
                        2,
                        3
                    ]
                }
            }
        }
    }

# Generated at 2022-06-21 06:38:53.473174
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _assert_subkey_in_element(subkey, element):
        assert subkey in element, "subkey '%s' not in element %s" % (subkey, element)

    def _assert_subkey_not_in_element(subkey, element):
        assert subkey not in element, "subkey '%s' in element %s" % (subkey, element)

    def _assert_elements_list_contains_el(element, elements_list):
        assert element in elements_list, "element %s not in %s" % (element, elements_list)

    def _assert_elements_list_does_not_contain_el(element, elements_list):
        assert element not in elements_list, "element %s not in %s" % (element, elements_list)


# Generated at 2022-06-21 06:38:59.620448
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 06:39:01.444429
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-21 06:39:08.148663
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import pytest
    # TODO: add test if correct exception is thrown
    # TODO: add test to check if correct skip_missing is used
    # in case we had no results, return an empty list
    subelements = LookupModule()
    subelements.set_options(
        dict(
            _terms=['', 'authorized']
        )
    )

# Generated at 2022-06-21 06:39:17.801150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:39:29.060315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-21 06:39:41.177554
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:39:42.660949
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup != None


# Generated at 2022-06-21 06:39:44.906408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 06:39:52.536658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # build a mock templar to replace the real one
    class mock_templar():
        def __init__(self):
            # nothing to init
            dummy = 0
        def template(self, data):
            # just return the data unmodified
            return data
    # build a mock variables to replace the real one
    class mock_variables():
        def __init__(self):
            # nothing to init
            dummy = 0
    class mock_loader():
        def __init__(self):
            # nothing to init
            dummy = 0
    # build an instance of LookupModule
    lookup_module = LookupModule()
    # set the templar and variables
    lookup_module._templar = mock_templar()
    lookup_module._loader = mock_loader()
    # test positive cases

# Generated at 2022-06-21 06:40:03.382791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # execute the lookup method
    LookupModule().run([{'a':1}, 'a'], {})
    # The lookup method should throw an error if the first arg is not a list
    try:
        LookupModule().run('a', {})
        raise Exception("subelements lookup method did not throw an error when"
                        " the first arg was not a list")
    except AnsibleError as e:
        # Ansible 2.1:
        # Check that the error message contains the given substring.
        if 'list' not in e.message:
            raise Exception("Wrong error raised, expected to find string 'list'")
        # Ansible 2.2+:
        # Check that the error message contains the given substring.

# Generated at 2022-06-21 06:40:10.330365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import constants as C
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_HOST_LIST = False
    C.DEFAULT_DEBUG = True
    C.DEFAULT_KEEP_REMOTE_FILES = True
    C.DEFAULT_MODULE_NAME = 'command'
    C.DEFAULT_MODULE_PATH = '~/.ansible/plugins/modules:/usr/share/ansible/plugins/modules'
    C.DEFAULT_REMOTE_USER = 'root'
    C.DEFAULT_PATHS = '~/.ansible/plugins/lookup:/usr/share/ansible/plugins/lookup'
    C.DEFAULT_TIMEOUT = 30
    from ansible.vars import VariableManager
    from ansible.playbook import Play

# Generated at 2022-06-21 06:40:22.217507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare mocks
    class MockTemplar:
        def __init__(self):
            self.vars = None

        def template(self, template, **args):
            self.vars = args.get('vars')
            return template

    class MockLoader:
        def __init__(self):
            self.paths = None

        def get_basedir(self, path):
            if self.paths is None:
                self.paths = []
            self.paths.append(path)
            return path

    templar = MockTemplar()
    loader = MockLoader()
    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader = loader

    # get result of lookup

# Generated at 2022-06-21 06:40:23.268174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 06:40:44.329842
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    subelements._templar = 'template'
    subelements._loader = 'loader'
    subelements.run([{'name': 'vanginderachter'}], 'variables', **{'vars': 'vars'})

# Generated at 2022-06-21 06:40:53.377794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    The test_LookupModule_run() method does some basic functional tests for the lookup plugin 'subelements'.
    """
    from ansible.errors import AnsibleError
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import PY3, string_types
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-21 06:41:05.115421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # no terms
    assert lm.run() == []

    # one term
    terms = [
        {'var': 'one'},
    ]
    assert lm.run(terms=terms) == []

    # two terms wrong
    terms = [
        {'var': 'one'},
        1,
    ]
    try:
        assert lm.run(terms=terms)
        assert False
    except:
        assert True

    # two terms
    terms = [
        [
            {'var': 'one', 'var2': 'two'},
            {'var': 'three', 'var2': 'four'},
        ],
        'var',
    ]

# Generated at 2022-06-21 06:41:16.362966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils import playbook_path
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_loader = LookupModule(loader=loader)
    result = lookup_loader.run([['tests/testLookupModule/test.yml']], {})
    assert(result == ['bar', 'baz'])
    result = lookup_loader.run([['tests/testLookupModule/test.yml'], 'foo'], {})
    assert(result == ['bar', 'baz'])
    result = lookup_loader.run([['tests/testLookupModule/test.yml'], 'x.foo'], {})
    assert(result == list())

# Generated at 2022-06-21 06:41:17.493919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:41:19.894100
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module)

# Generated at 2022-06-21 06:41:31.600858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subset as lookupclass
    lookup = lookupclass.LookupModule()

    # test second term not a string
    res = lookup._run([[{'test': 'foo'}], 1, {}], None)
    assert res == AnsibleError("subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey")

    # test missing second term
    res = lookup._run([{'test': 'foo'}], None)
    assert res == AnsibleError("subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey")

    # test first term not a list
    res = lookup._run([1, 'foo', {}], None)

# Generated at 2022-06-21 06:41:40.978130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # check function
    def check_function(function, expected):
        ret = function()
        for i in range(len(ret)):
            if isinstance(ret[i], UnsafeProxy):
                ret[i] = ret[i]._obj
            if isinstance(ret[i], list):
                for j in range(len(ret[i])):
                    if isinstance(ret[i][j], UnsafeProxy):
                        ret[i][j] = ret[i][j]._obj

# Generated at 2022-06-21 06:41:52.673174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # FIXME: use pytest!
    import os
    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase


# Generated at 2022-06-21 06:42:02.884550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod.run([{'a': {'b': [1, 2, 3]}, 'c': None}], None, skip_missing=True) == [(({'a': {'b': [1, 2, 3]}, 'c': None}, 1),), (({'a': {'b': [1, 2, 3]}, 'c': None}, 2),), (({'a': {'b': [1, 2, 3]}, 'c': None}, 3),)]

# Generated at 2022-06-21 06:42:36.522140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert callable(subelements)
    assert isinstance(subelements, LookupBase)



# Generated at 2022-06-21 06:42:37.502399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 06:42:38.437061
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:42:41.829476
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    we need to inject the class into the global namespace, so the lookup plugin
    can be unit tested
    '''
    global LookupBase
    import ansible.plugins.lookup.subelements
    LookupBase = ansible.plugins.lookup.subelements.LookupBase



# Generated at 2022-06-21 06:42:52.132646
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from collections import namedtuple
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # Create an instance of namedtuple for object Host
    # This object has to be a instance of class Host
    # In our case we use a namedtuple
    Host = namedtuple('Host', ['name'])
    hosts = [Host(name="host1"), Host(name="host2")]

    # Create an instance of namedtuple for object Group
    # This object has to be a instance of class Group
    # In our case we use a namedtuple
    Group = namedtuple('Group', ['name','hosts'])
    groups = [Group(name="group1", hosts=hosts)]

    # Create an instance of namedtuple for object InventoryManager

# Generated at 2022-06-21 06:42:59.094997
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Reads test/unit/test_sublueprint.py from the same directory as this file
    path = os.path.join(os.path.dirname(__file__), "test_subelements.py")
    yaml_file = open(path, 'r')
    terms = yaml.load(yaml_file)
    yaml_file.close()

    lookup_mod = LookupModule()

    result = lookup_mod.run(terms, None)

    # Check the results
    assert result == [('user1', 'sock1'), ('user1', 'sock2'), ('user2', 'sock3')]

# Generated at 2022-06-21 06:43:10.509372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method run of class LookupModule
    """
    import pytest
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:43:23.193088
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Dummy(object):
        def __init__(self, list_dicts, subkey, optional_flags={}):
            self.terms = [list_dicts, subkey, optional_flags]
            self.vars = {}

        def run(self, terms, variables, **kwargs):
            if self.terms != terms:
                raise Exception('terms not matching')
            if self.vars != variables:
                raise Exception('variables not matching')
            return LookupModule.run(self, terms, variables, **kwargs)

    # empty terms:
    lookup = Dummy(None, None, None)

# Generated at 2022-06-21 06:43:35.422357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # dummy class to allow testing of private function
    class DummyLookupModule(LookupModule):
        def __init__(self, basedir=None, runner=None, aliases=None, loader=None, templar=None, **kwargs):
            class DummyRunner:
                def __init__(self, kwargs):
                    self.args = kwargs
            self._templar = templar
            self._loader = loader
            self.runner = DummyRunner(kwargs)

    # dummy class to allow testing of private function
    class DummyTemplar(object):
        def __init__(self):
            pass

    # dummy class to allow testing of private function
    class DummyLoader(object):
        def __init__(self):
            pass

# Generated at 2022-06-21 06:43:37.581952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)
    assert isinstance(lookup_plugin, LookupBase)

# Generated at 2022-06-21 06:45:01.385596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-21 06:45:12.869378
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # NOTE: subelements is expected to take two parameters:
    # list and dictionary key.

    users = [
        {'name': 'alice', 'authorized': ['/authorized/key/alice.pub']},
        {'name': 'bob', 'authorized': ['/authorized/key/bob1.pub', '/authorized/key/bob2.pub']},
        {'name': 'charlie', 'authorized': ['/authorized/key/charlie1.pub', '/authorized/key/charlie2.pub', '/authorized/key/charlie3.pub']},
        {'name': 'dave', 'authorized': []}
    ]


# Generated at 2022-06-21 06:45:14.108796
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:45:17.936248
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = [
        [{'name': 'alice', 'groups': ['wheel']}, {'name': 'bob', 'groups': ['wheel']}],
        'groups',
        {'skip_missing': True}]

    expected = ['wheel', 'wheel']

    lm = LookupModule()
    result = lm.run(terms, None, False, None)

    assert result == expected

# Generated at 2022-06-21 06:45:21.136403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("\nUnit test for constructor of class LookupModule")
    lookup = LookupModule()
    print("Unit test for constructor of class LookupModule: completed\n")


# Generated at 2022-06-21 06:45:33.185685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_obj = LookupModule()

    # Test
    users = [
        {
            'name': 'alice',
            'authorized': [
                "/tmp/alice/onekey.pub",
                "/tmp/alice/twokey.pub"
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                "/tmp/bob/id_rsa.pub",
            ]
        },
    ]
    terms = (
        users,
        'authorized',
    )
    ret = lookup_obj.run(terms, {})

# Generated at 2022-06-21 06:45:43.046543
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run(LookupModule, [{'foo': {'bar': [1, 2]}}], {}) == [(None, 1), (None, 2)]
    assert LookupModule.run(LookupModule, [{'foo': {'bar': [1, 2]}}], {}) != [(None, 1), (None, 3)]
    assert LookupModule.run(LookupModule, [{'foo': {'bar': [1, 2]}}, {'skip_missing': False}], {}) == [(None, 1), (None, 2)]
    assert LookupModule.run(LookupModule, [{'foo': {'bar': [1, 2]}}, {'skip_missing': True}], {}) == [(None, 1), (None, 2)]

# Generated at 2022-06-21 06:45:46.878672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create Subelements
    # create a LookupModule instance
    lookupModule = LookupModule()
    # give the lookupModule the lookup term
    lookupModule._templar.template = {'one': {'two': ['three']}}
    # give the lookupModule the variables
    lookupModule._loader.get_basedir = lambda *args: ''
    # run the lookupModule
    result = lookupModule.run([['one'], 'two'], variables=dict())
    # assert on results
    assert result == [({'two': ['three']}, 'three')]

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:45:58.235778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test_LookupModule_run"""
    _this = LookupModule()
    _this.set_options({'variables':dict(
        users=[
            dict(name='alice', authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']),
            dict(name='bob', authorized=['/tmp/bob/id_rsa.pub'])
        ]
    )})
    _this._templar = None
    _this._loader = None

# Generated at 2022-06-21 06:46:09.498750
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    class TestTemplar(object):
        def template(self, *args, **kwargs):
            return args[0]

        def is_template(self, *args, **kwargs):
            return False

        def environment_fail_undefined(self, *args, **kwargs):
            return False

        def _finalize(self, *args, **kwargs):
            return args[0]

    templar = TestTemplar()

    class TestLoader(object):
        def get_basedir(self, *args, **kwargs):
            return "."
