

# Generated at 2022-06-21 06:37:58.058832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext

    module = AnsibleModule(
        argument_spec={
            '_raw_params': dict(type='str', required=True),
            '_terms': dict(type='list', required=True),
        },
    )

    if PY3:
        module.params['_raw_params'] = module.params['_raw_params'].encode('utf-8')

    lookup_instance = LookupModule()
    lookup_instance.set_options({})
    play_context = PlayContext()
    play_context.basedir = "/some/basedir"

# Generated at 2022-06-21 06:38:06.686842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    # create expected results

# Generated at 2022-06-21 06:38:18.963929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    lm = LookupModule()
    # empty
    terms = []
    res = lm.run(terms, {})
    assert not res
    # basic test

# Generated at 2022-06-21 06:38:22.775834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    print("initialized LookupModule object:", lm)
    return lm

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:38:32.182260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test with normal data

# Generated at 2022-06-21 06:38:36.745767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    _ = AnsibleVaultEncryptedUnicode  # noqa: F841
    assert LookupModule  # using pyflakes

# Generated at 2022-06-21 06:38:37.347010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:38:44.597356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    l = LookupModule()

    # testing config:
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
             {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
             {'name': 'eve'}]
    # tests:
    # ###### method run
    # test list, list or tuple
    ret = l.run([users, 'authorized'])

# Generated at 2022-06-21 06:38:46.100535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: Write test cases
    # global LookupModule
    pass

# Generated at 2022-06-21 06:38:47.205740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:38:55.937277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:38:56.717224
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 06:39:05.817837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import ansible.plugins
    import ansible.parsing.yaml
    libpath = os.path.join(os.path.dirname(ansible.plugins.__file__), 'lookup')
    c = ansible.plugins.loader.load_plugin_class('lookup', 'subelements')
    lu = c()
    data = ansible.parsing.yaml.load(open('tests/vars/subelements.yml'))
    # 2 items w/o flags

# Generated at 2022-06-21 06:39:06.367215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:39:08.152620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-21 06:39:16.799116
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _assert(actual, expected):
        assert actual == expected, "Expected '%s' but got '%s'" % (expected, actual)


# Generated at 2022-06-21 06:39:28.214091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [
        [{'a1': {'b1': [1, 2]}}, {'a2': {'b2': [3, 4]}}, {'a3': {'b3': [5, 6]}}],
        'a.b'
    ]
    # expected = [( {'a1': {'b1': [1, 2]}}, 1 ), ( {'a1': {'b1': [1, 2]}}, 2 ), ( {'a2': {'b2': [3, 4]}}, 3 ), ( {'a2': {'b2': [3, 4]}}, 4 ), ( {'a3': {'b3': [5, 6]}}, 5 ), ( {'a3': {'b3': [5, 6]}}, 6 )]

# Generated at 2022-06-21 06:39:39.652933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Old style plugin invocation
    #terms = [[{'a': {'b': [2, 3, 4]}}], 'a.b', {'skip_missing': True}]
    #terms = [terms, {}]
    #results = lookup.run(terms, variables=None, **dict())
    #assert results == [(2,), (3,), (4,)]

    # New style plugin invocation
    terms = [{'a': {'b': [2, 3, 4]}}, 'a.b', {'skip_missing': True}]
    results = lookup.run(terms, variables=None, **dict())
    assert results == [(2,), (3,), (4,)]


# Generated at 2022-06-21 06:39:50.307340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # General test data
    name = 'name'
    authorized = 'authorized'
    mysql = 'mysql'
    password = 'password'
    hosts = 'hosts'
    privs = 'privs'
    groups = 'groups'
    privs_list = ['*.*:SELECT', 'DB2.*:ALL']
    hosts_list = ['%', '127.0.0.1', '::1', 'localhost']
    groups_list = ['wheel']
    password_value = 'mysql-password'
    password_value2 = 'other-mysql-password'
    authorized_list = ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']
    authorized_list2 = ['/tmp/bob/id_rsa.pub']

    # Test data
    user_

# Generated at 2022-06-21 06:39:53.187738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({}) is not None
    assert LookupModule({'run_once': True}) is not None


# Generated at 2022-06-21 06:40:19.982230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager
    inventory = InventoryManager(loader=loader, sources='')
    play_source =  dict(
            name = "Ansible Play 2",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{item.0.mysql.privs | join("/") }}')))
            ]
        )

# Generated at 2022-06-21 06:40:30.831114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError

    ###################
    #   basic tests   #
    ###################

    lu = LookupModule()

    # assert error on wrong number of terms
    try:
        assert lu.run([], {})
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items"
    try:
        assert lu.run([], {}, terms=[1, 2, 3, 4])
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items"

    # assert on wrong subkey type

# Generated at 2022-06-21 06:40:41.262745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # Test keys that are present in the dict

# Generated at 2022-06-21 06:40:42.906261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:40:44.748215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:40:53.683608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(object):
        """wrapper class for tests to provide class lookup methods"""
        def __init__(self, module_utils):
            self.module_utils = module_utils

        @classmethod
        def _templar(cls, *args, **kwargs):
            return cls(cls.module_utils)._templar(*args, **kwargs)

        @classmethod
        def _loader(cls, *args, **kwargs):
            return cls(cls.module_utils)._loader(*args, **kwargs)

    class TestModuleUtils(object):
        pass


# Generated at 2022-06-21 06:41:05.252690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = [
        [{'_id': 1, 'api': 'http://localhost:5000', 'subelement': {'component': 'main'}}, {'_id': 2, 'api': 'http://localhost:5000', 'subelement': {'component': 'slave'}}],
        'subelement.component']
    result = lm.run(terms, None)
    myterms = [
        {'skipped': True}, {'skipped': True}
    ]
    result = lm.run(myterms, None)
    additional_terms = [
        {'skipped': True},
        'subelement.component',
        {'skip_missing': True},
    ]
    result = lm.run(additional_terms, None)

# Generated at 2022-06-21 06:41:10.068859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import pprint
    lookup_mod = LookupModule()
    test_terms = json.loads('''[
        [
            {
                "foo": "bar",
                "nested": {
                    "key": [1, 2, 3]
                },
                "skipped": "skipped",
                "bar": {
                    "skipped": "skipped"
                }
            }, 
            {
                "foo": "bar",
                "nested": {
                    "key": [4, 5, 6]
                },
                "skipped": "skipped",
                "bar": {
                    "skipped": "skipped"
                }
            }
        ],
        "nested.key"
    ]''') 
    results = lookup_mod.run(test_terms)
    #

# Generated at 2022-06-21 06:41:18.847389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys

    global LookupModule
    LookupModule = sys.modules[__name__] if PY3 else __builtins__[__name__]
    lookup_module = LookupModule()

    def _test_LookupModule_run(terms, result, **kwargs):
        global LookupModule
        LookupModule = sys.modules[__name__] if PY3 else __builtins__[__name__]
        lookup_module = LookupModule()
        out = lookup_module.run(terms, None, **kwargs)
        err = (sys.stderr.getvalue().strip()).splitlines()
        sys.stderr = sys.__stderr__
        sys

# Generated at 2022-06-21 06:41:31.021166
# Unit test for constructor of class LookupModule
def test_LookupModule():
    sub_element_list = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    sub_key = 'authorized'
    sub_element_dict = {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}
    sub_key = 'name'

# Generated at 2022-06-21 06:42:07.505218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes

    plugin = LookupModule()

# Generated at 2022-06-21 06:42:16.842706
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup test data
    class MockTemplar(object):
        def __init__(self):
            self.results = []
        def template(self, term, variables=None, convert_bare=True, fail_on_undefined=True, override=True):
            self.results.append((term, variables))
            return term
    templar = MockTemplar()


# Generated at 2022-06-21 06:42:28.920527
# Unit test for constructor of class LookupModule
def test_LookupModule():
    items = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
             {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    subelements = LookupModule()

# Generated at 2022-06-21 06:42:30.496841
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert isinstance(module, LookupModule)


# Generated at 2022-06-21 06:42:40.970488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    """
    Collect the tests in a class so that they can share test data
    """
    class Tests:

        def setUp(self):
            self.test_dir = os.path.join(os.path.dirname(__file__), '_test')

# Generated at 2022-06-21 06:42:51.894355
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import b
    from ansible.module_utils.parsing.convert_bool import boolean

    _module = LookupModule()

    # test 1:
    # extract key.subkey from a list of dictionaries
    terms = [[{"name": "john", "dictionary": {"subkey": ["1", "2"]}},
              {"name": "doe", "dictionary": {"subkey": ["3", "4", "5"]}}],
             "dictionary.subkey"]

# Generated at 2022-06-21 06:43:00.108510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This is a very basic unit test. It could be extended with more comprehensive
    tests
    """
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    users = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]},
             {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]},
             {"name": "carol", "mysql": {"password": "other-mysql-password"}},
             {"name": "dave", "mysql": {"hosts": ["db1"], "privs": ["*.*:SELECT", "DB2.*:ALL"]}}]
    task_vars = dict(users=users)
    templar

# Generated at 2022-06-21 06:43:01.871551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:43:12.690951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms

# Generated at 2022-06-21 06:43:23.866590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=missing-docstring
    class FakeTemplar(object):
        def __init__(self):
            pass

        def template(self, val):
            return val

    templar = FakeTemplar()

    class FakeLoader(object):
        def get_basedir(self, *args):
            return "/"

    loader = FakeLoader()

    lookup = LookupModule(loader=loader, templar=templar)


# Generated at 2022-06-21 06:44:49.438343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import module
    import sys
    sys.path.append('lib/ansible/plugins/lookup')
    exec('from subelements import LookupModule')
    test_data_dir = 'test/test_data/lookup_plugins'

    lookup_options = dict(
        _terms=['file', 'test.txt'],
        task_vars=dict(
            var1='foo'
        )
    )

    lookup_instance = LookupModule()
    results = lookup_instance.run(**lookup_options)

    assert results == ['bar\n']

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:45:00.493579
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # test successfull run:
    #terms = [{u'hostvars': {u'host1': {u'foo': 1, u'bar': 2}, u'host0': {u'foo': 2, u'bar': 3}}}, 'hostvars', {'skip_missing': False}]
    #assert lookup_module.run(terms, None) == [(u'host0', {u'foo': 2, u'bar': 3}), (u'host1', {u'foo': 1, u'bar': 2})]

# if __name__ == '__main__':
#     test_LookupModule()

# Generated at 2022-06-21 06:45:07.116617
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    users = [
        {
            'name': 'alice',
            'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
            'mysql': {'password': 'mysql-password',
                      'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
                      'privs': ['*.*:SELECT', 'DB1.*:ALL']},
            'groups': ['wheel']}
    ]

    l = LookupModule()

    terms = [[users], 'authorized']

# Generated at 2022-06-21 06:45:17.455628
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:45:18.328697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-21 06:45:30.607714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # import module for testing
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    # create inventory object and populate with hosts
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    # create play object
    play_source = dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{users}}')), register='debug_out'),
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-21 06:45:41.443623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupBase(LookupBase):
        def __init__(self, variable_manager=None, loader=None, templar=None, shared_loader_obj=None):
            self.variable_manager = variable_manager
            self.loader = loader
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
            self.ret = []
            self.called = []

        def get_basedir(self, variables):
            return None

    class MockVariableManager:
        def __init__(self):
            self.ret = []
            self.called = []


# Generated at 2022-06-21 06:45:42.337338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cm = LookupModule()  # noqa

# Generated at 2022-06-21 06:45:43.800589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 06:45:50.334605
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    mydict = {'a': [{'b': {'c': [10, 11],
                           'd': 20,
                           'e': 30,
                           }}]}

    # Make an example playbook to test lookup
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])