

# Generated at 2022-06-21 06:37:56.722593
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    value = lookup_plugin.run([['a', 'b', 'c'],'0'], {}, **{})
    assert value == ['a']
    value = lookup_plugin.run([{'0':'a','1':'b','2':'c'},'0'], {}, **{})
    assert value == ['a']

    my_list = [
        {'name': 'alice', 'languages': ['DE', 'EN']},
        {'name': 'bob', 'languages': ['EN', 'IT']},
    ]

    value = lookup_plugin.run([my_list,'languages'], {}, **{})
    assert value == [['DE', 'EN'],['EN', 'IT']]

    #  test with 3 arguments
    value = lookup_

# Generated at 2022-06-21 06:38:05.824401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # if this is run independently it can be used to test this lookup module
    # before/without the unittesting framework
    import sys
    # dummy lookup module
    class LookupModule(object):
        def __init__(self, basedir=None, **kwargs):
            pass

    lookup_module = LookupModule()

    # dummy users

# Generated at 2022-06-21 06:38:08.363600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 06:38:20.270755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run_no_terms
    terms = []
    assert test_LookupModule_run_helper(terms) == []

    # test_LookupModule_run_no_list
    terms = [
        {'test': 'value'},
        'test'
    ]
    assert test_LookupModule_run_helper(terms) == []

    # test_LookupModule_run_simple

# Generated at 2022-06-21 06:38:21.303763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup=LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:38:31.636548
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init the lookup module
    m = LookupModule()

    # create a list of dictionaries
    testlist = [
        {
            "foo": {
                "bar": {
                    "baz": [
                        "a", "b", "c"
                    ]
                }
            },
            "bar": ["d", "e", "f"]
        },
        {
            "foo": {
                "bar": {
                    "baz": [
                        "g", "h", "i"
                    ]
                }
            },
            "bar": ["j", "k", "l"]
        },
        {
            "foo": {
                "bar": {
                }
            },
            "bar": ["m", "n", "o"]
        }
    ]

    # define 5 tests

# Generated at 2022-06-21 06:38:43.257884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts import Facts
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 06:38:45.098724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup1 = LookupModule()
    assert my_lookup1

# Generated at 2022-06-21 06:38:56.406966
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:39:02.606334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #
    # Create a lookup module
    #
    lookup_module = LookupModule()

    terms = []
    terms.append([]) # variable 'key' is required
    terms.append([]) # variable 'key' is required

    #
    # test with right values
    #
    variable='value'
    runResult = lookup_module.run(terms, variable)
    assert type(runResult) is list


# Generated at 2022-06-21 06:39:11.860316
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(isinstance(lm, LookupModule))

# Generated at 2022-06-21 06:39:13.660730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # TODO
    pass


# Generated at 2022-06-21 06:39:14.545041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # succeed with a test
    assert True

# Generated at 2022-06-21 06:39:18.981974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # check default constructor
    assert lm.run == LookupModule.run
    assert lm.__class__.__name__ == "LookupModule"
    assert lm._templar is None
    assert lm._loader is None

# Generated at 2022-06-21 06:39:29.849117
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.template import Templar

    env = {'vars': {'users': [
        {'name': 'alice',
         'authorized': [
             '/tmp/alice/onekey.pub',
             '/tmp/alice/twokey.pub'
         ],
         'groups': ['wheel']},
        {'name': 'bob',
         'authorized': ['/tmp/bob/id_rsa.pub'],
         'groups': ['admin']}
    ]}}
    templar = Templar(loader=None, variables=env['vars'])
    templar._available_variables = env['vars']

    lookup_module = LookupModule()
    lookup_module._templar = templar

# Generated at 2022-06-21 06:39:41.411042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Correct usage
    assert isinstance(lookup_plugin.run([{'skipped': True}], None), list)
    assert isinstance(lookup_plugin.run([[1, 2], 'name'], None), list)
    assert isinstance(lookup_plugin.run([[1, 2], 'name', {'skip_missing': True}], None), list)

    # Incorrect usage
    try:
        lookup_plugin.run(None, None)
        assert False
    except AnsibleError as e:
        assert isinstance(e.args[0], str)
    try:
        lookup_plugin.run("a", None)
        assert False
    except AnsibleError as e:
        assert isinstance(e.args[0], str)

# Generated at 2022-06-21 06:39:50.983612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self):
            return 'a/b/c'

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    variable_manager = None
    loader = MockLoader()
    templar = MockTemplar()
    lookup = LookupModule(loader=loader, variable_manager=variable_manager, templar=templar)
    mock = MockModule()

    # No params
    assert lookup._fail_function('a') is False

    # Empty list of terms

# Generated at 2022-06-21 06:39:52.591631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [["first", "second", "third"], "subkey"]
    lm = LookupModule()
    assert len(lm.run(terms, {})) == 3

# Generated at 2022-06-21 06:39:57.079922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    # Check instantiation of the class
    assert(isinstance(module, LookupModule))
    # Check module constants
    assert(module.FLAGS == ('skip_missing',))
    assert(module.DOCUMENTATION)
    assert(module.EXAMPLES)
    assert(module.RETURN)


# Test data for the test_run method

# Generated at 2022-06-21 06:40:08.002044
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:40:33.612289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 06:40:45.853290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def assert_plugin_args(plugin, terms=[], variables=None, **kwargs):
        assert plugin._templar == templar
        assert plugin._loader == loader
        assert plugin._templar.template('{{ foo }}') == terms
        assert plugin._loader.get_basedir() == basedir

    mock_templar = MockTemplar()
    mock_loader = MockLoader()
    plugin = LookupModule()

    # test with no args
    plugin.__init__()
    assert plugin._templar == None
    assert plugin._loader == None

    # test with only Templar
    plugin.__init__(templar=mock_templar)
    assert plugin._templar == mock_templar
    assert plugin._loader == None

    # test with only loader

# Generated at 2022-06-21 06:40:46.865923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-21 06:40:54.852583
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prepare test data
    class MyVars(object):
        element1 = {'skipped': False, 'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}
        element2 = {'skipped': False, 'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        element3 = {'skipped': True, 'name': 'eve', 'authorized': ['/tmp/eve/id_rsa.pub']}
        testlist_of_dicts = [element1, element2, element3]
        testlist_of_dicts_with_dict = {'first': element1, 'second': element2, 'third': element3}
        testlist_of_dicts_with_list

# Generated at 2022-06-21 06:41:03.731537
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''test constructor of class LookupModule'''
    lookup_class = 'lookup.subelements'

    # Test: constructor LookupModule() with no parameters
    try:
        LookupModule()
        fail("expected Exception due to missing parameters")
    except:
        pass

    # Test: constructor LookupModule(loader=None, templar=None, **kwargs)
    try:
        LookupModule(loader=None, templar=None, **{})
    except:
        fail("Unexpected Exception: constructor LookupModule(loader=None, templar=None, **kwargs)")

# Generated at 2022-06-21 06:41:09.054864
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Case 1: Check if constructor works properly
    lookup = LookupModule()
    assert lookup is not None

    # Case 2: Check if constructor works properly for empty case
    lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    assert lookup is not None

# Generated at 2022-06-21 06:41:10.344950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:41:16.479957
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_args_str = 'name:server1'
    terms_str = '[1,2,3]'
    lookup_obj = LookupModule()
    lookup_obj.set_options(direct=dict(keyed_groups=['key'], key_file=None, module_args=module_args_str))
    terms = lookup_obj.run(terms, variables=dict(name="server1"), inject=None, **dict(keyed_groups=['key']))
    assert terms == [[], "server1"]

# Generated at 2022-06-21 06:41:21.484018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = [
        {
          "skipped": True,
          "msg": "msg1"
        }
    ]
    lm._templar = None
    lm._loader = None
    results = lm.run(terms)
    assert results == []

# Generated at 2022-06-21 06:41:23.685199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-21 06:42:03.506835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """basic test of run method"""
    lu = LookupModule()
    _terms = [["a","b","c"], "hosts"]
    _variables = {}
    _lst = lu.run(_terms, _variables)
    _expected = []
    assert _lst == _expected, "did not get the expected result; got {} and expected {}".format(_lst, _expected)

    _terms = [{"a":{"hosts":["h1","h2"]},"b":{"hosts":["h3"]},"c":{"hosts":["h4","h5"]}}, "hosts"]
    _variables = {}
    _lst = lu.run(_terms, _variables)

# Generated at 2022-06-21 06:42:15.678132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml.loader
    import ansible.parsing.yaml.objects
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import pytest

    sr = ansible.plugins.lookup.subelements.LookupModule()
    assert isinstance(sr, ansible.plugins.lookup.subelements.LookupModule)
    d = ansible.parsing.yaml.loader.DataLoader()
    assert isinstance(d, ansible.parsing.yaml.loader.DataLoader)
    v = VariableManager()
    assert isinstance(v, VariableManager)

    # test cases
    # case 1

# Generated at 2022-06-21 06:42:27.905322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Verify errors on invalid parameters
    assertLookupModuleResultIs(
        None,
        [],
        [
            (None, None, None),
            ('a', None, None)
            ],
        "Error on invalid parameters: expecting exception.")

    assertLookupModuleResultIs(
        None,
        [],
        [
            (None, None, None),
            ('a', 'b', None)
            ],
        "Error on invalid parameters: expecting exception.")

    assertLookupModuleResultIs(
        None,
        [],
        [
            (None, None, None),
            ('a', 'b', 'c', 'd')
            ],
        "Error on invalid parameters: expecting exception.")


# Generated at 2022-06-21 06:42:38.525168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = [{"key1": {"key2": [1,2,3,4]}}, "key1.key2"]
    assert lookup.run(terms, None) == [({"key1": {"key2": [1,2,3,4]}}, 1), ({"key1": {"key2": [1,2,3,4]}}, 2), ({"key1": {"key2": [1,2,3,4]}}, 3), ({"key1": {"key2": [1,2,3,4]}}, 4)]

    terms = [{"key1": {"key2": []}}, "key1.key2"]
    assert lookup.run(terms, None) == []


# Generated at 2022-06-21 06:42:50.008987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule.
    '''
    # Mock module input parameters
    mock_dict = {'user': 'test0',
                 'mysql': {'user': 'mysql0',
                           'password': 'mysql-password-0'},
                 'authorized': ['/tmp/test0/id_rsa.pub',
                                '/tmp/test0/id_rsa2.pub'],
                 'groups': ['group0', 'group1']}


# Generated at 2022-06-21 06:42:52.694348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)


# Generated at 2022-06-21 06:43:04.779141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    import json
    import tempfile
    import os
    import sys

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import StringIO as NativeStringIO

    from ansible.module_utils.six import binary_type
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.plugins.lookup import LookupBase

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            os.environ['LANG'] = 'C'

# Generated at 2022-06-21 06:43:14.583128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    li = [{'a': 'b', 'c': [1, 2, {'d': 'e', 'f': ['g', 'h']}]}]
    lookup_term = "c.2.d.e"

    lmod = LookupModule()
    ret = lmod.run([li, lookup_term], None)
    expected = [{'a': 'b', 'c': [1, 2, {'d': 'e', 'f': ['g', 'h']}]}, 'e']
    assert ret == [expected]

    ret = lmod.run([{'a': 'b', 'c': {'d': 'e', 'f': ['g', 'h']}}, lookup_term], None)
    assert ret == [expected]


# Generated at 2022-06-21 06:43:26.163840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variables = VariableManager()

    # Test case: get list of authorized keys
    testcase = dict(
        terms=[
          '{{ users }}',
          'authorized'
        ],
        users=[
          dict(
            name='alice',
            authorized=[
              '/tmp/alice/onekey.pub',
              '/tmp/alice/twokey.pub'
            ]
          ),
          dict(
            name='bob',
            authorized=[
              '/tmp/bob/id_rsa.pub'
            ]
          )
        ]
    )
    lm = LookupModule()
    lm.set_options(testcase)

# Generated at 2022-06-21 06:43:37.087260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # load test vars (it is needed to test one of the code paths)
    terms = [
        {'user_a': {'name': 'Alice'}},
        'name',
    ]

    assert(LookupModule._terms_is_valid(terms))

    # test validation for the number of terms
    for invalid_terms in [
        [],
        [1, 2],
        [1, 2, 3, 4],
    ]:
        try:
            LookupModule._terms_is_valid(invalid_terms)
            assert(False)
        except AnsibleError:
            assert(True)

    # test validation for the number of terms

# Generated at 2022-06-21 06:45:05.824405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelements_lookup = LookupModule()

    terms = {
        'ok': ["{{ users }}", "authorized"],
        'wrong_type': [None, None],
        'missing_terms': [],
        'wrong_terms': [123, "whatever", {}],
        'wrong_term1': [{}, {}],
        'wrong_term2': [[], None],
        'wrong_term3': [[], ["key1", "key2"]],
        'wrong_term4': ["{{ users }}", None],
        'wrong_term5': [None, "authorized"],
        'wrong_flags': [None, None, None]
    }

# Generated at 2022-06-21 06:45:15.216371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [{'username': 'Joe'}, {'username': 'Jane'}],
        'firstname',
        {'skip_missing': False}
    ]

    class MockVariableManager:
        """Mocks variable manager class."""
        def __init__(self):
            pass

    class MockTemplar:
        """Mocks templar class."""
        __init__ = MockVariableManager.__init__
        def template(self, x, y):
            return x

    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module.run(terms, None)

# Generated at 2022-06-21 06:45:21.111492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    l = LookupModule()
    l._loader = DataLoader()

    terms = [
        {
            'item0': {
                'key1': [
                    'value11',
                ],
                'key2': {
                    'key21': {
                        'key211': [
                            'value2111',
                        ],
                    },
                },
            },
            'item1': {
                'key1': [
                    'value21',
                ],
            },
        },
        'key1',
    ]

# Generated at 2022-06-21 06:45:26.985753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lm = LookupModule()
    assert lm != None
    lm._templar = Templar(loader=DataLoader(), variables=VariableManager())
    return lm


# Generated at 2022-06-21 06:45:34.433755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    testterm = [{"users": {"Alice": {"authorized": ["TEST1"]}, "Bob": {"authorized": ["TEST2"]}}}, "authorized"]
    l = LookupModule()

    # when
    r = l.run(testterm, None)

    # then
    assert len(r) == 2
    assert r == [({'authorized': ['TEST1'], 'name': 'Alice'}, 'TEST1'), ({'authorized': ['TEST2'], 'name': 'Bob'}, 'TEST2')]



# Generated at 2022-06-21 06:45:40.878843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [ ["1", "2", "3"], "foo.bar" ]
    module = LookupModule()
    result = module.run(terms, dict())
    assert result == [({'foo': {'bar': '1'}, 'skipped': False}, '1'), ({'foo': {'bar': '2'}, 'skipped': False}, '2'), ({'foo': {'bar': '3'}, 'skipped': False}, '3')]


# Generated at 2022-06-21 06:45:41.497845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:45:48.928434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

    # check lookup terms
    try:
        ret = lookup_instance.run([], {}, **{})
        assert "subelements lookup expects a list of two or three items" in ret, \
            "status message not found in %s" % ret
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e), \
            "status message not found in %s" % e

    # first term should be a list (or dict), second a string holding the subkey
    terms = [[""], ""]

# Generated at 2022-06-21 06:45:59.449505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    elementlist = [
        { 'hostname': 'host1', 'user': 'root', 'password': 'secret1', 'ssh_keys': [ 'key1a', 'key1b' ] },
        { 'hostname': 'host2', 'user': 'admin', 'password': 'secret2', 'ssh_keys': [ 'key2a', 'key2b', 'key2c' ] },
    ]
    subelementlist = [ 'key1a', 'key1b', 'key2a', 'key2b', 'key2c' ]
    terms = [ elementlist, 'ssh_keys' ]
    subelements = module.run(terms, variables = {})
    assert subelementlist == [ item[1] for item in subelements ]

# Generated at 2022-06-21 06:46:11.078396
# Unit test for method run of class LookupModule