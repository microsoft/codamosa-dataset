

# Generated at 2022-06-21 06:37:48.362364
# Unit test for constructor of class LookupModule
def test_LookupModule():
    subelements = LookupModule()
    assert isinstance(subelements, LookupModule)


# Generated at 2022-06-21 06:37:59.692237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    lookup_instance = LookupModule()
    users = [{"name": "alice",
              "ssh_keys": [{'key': "ASB"}, {'key': "ASD"}]},
             {"name": "bob",
              "ssh_keys": [{'key': "ASG"}]}]
    terms = [users, 'ssh_keys.key']
    lookup_instance._templar = None
    lookup_instance._loader = None
    assert lookup_instance.run(terms, None) == [('alice', {'key': 'ASB'}),
                                                ('alice', {'key': 'ASD'}),
                                                ('bob', {'key': 'ASG'})]

# Generated at 2022-06-21 06:38:01.750820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test the constructor of the class LookupModule"""
    ml = LookupModule()
    assert ml is not None


# Generated at 2022-06-21 06:38:03.980234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [{'item1': 'value1'}, 'item1']
    lookup_plugin.run(terms, None)

# Generated at 2022-06-21 06:38:15.732546
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import merge_hash
    test_loader = DictDataLoader({})
    vault_password = None
    test_variables = DictVars({}, vault_passwords=[vault_password])

    test_templar = Templar(loader=test_loader, variables=test_variables)
    test_lookup = LookupModule(loader=test_loader, templar=test_templar)

    terms = [
        [{'skipped': True}],
        ['name']
    ]
    variables = {'skipped': True}

    result = test_lookup.run(terms=terms, variables=variables)
    assert result == [], result


# Generated at 2022-06-21 06:38:24.915689
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    terms = []
    terms.append({u'a': {u'b': [u'1', u'2'], u'c': {u'd': [u'3', u'4']}}})
    terms.append(u'c.d')
    terms.append({})

    terms.append({u'a': {u'b': [u'1', u'2'], u'c': {u'd': [u'3', u'4']}}})
    terms.append(u'c.d')
    terms.append({u'skip_missing': True})

    module.run(terms, None)

# Generated at 2022-06-21 06:38:33.439980
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import iteritems
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar
    import pytest

    #


# Generated at 2022-06-21 06:38:34.403003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: create unit tests for class LookupModule
    raise NotImplementedError


# Generated at 2022-06-21 06:38:45.001240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lookup_terms = [
        [
            { "first_name": "John", "last_name": "Doe", "dob": "1940-12-31" },
            { "first_name": "Jane", "last_name": "Doe", "dob": "1945-03-03" },
            "last_name"
        ]
    ]
    ret = lm.run(terms=lookup_terms, variables=dict())
    assert ret == [("Doe", ), ("Doe", )]

    # Now with lists of lists.

# Generated at 2022-06-21 06:38:56.373322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fake_loader = DictDataLoader({})
    pick_attr = lambda obj, attr: dict((a, getattr(obj, a)) for a in attr)
    templar = Templar(loader=fake_loader, variables={})

    def templated(data, fail_on_undefined=True):
        return templar.template(data, fail_on_undefined)

    lookup = LookupModule()
    lookup._templar = templar
    lookup._loader = fake_loader


# Generated at 2022-06-21 06:39:14.890373
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # list of dictionaries as input and a subkey holding a list of dictionaries
    users = [
        {'name': 'alice',
         'authorized': [{'key': 'a1', 'keyvalue': 'a1v'}, {'key': 'a2', 'keyvalue': 'a2v'}]},
        {'name': 'bob',
         'authorized': [{'key': 'b1', 'keyvalue': 'b1v'}, {'key': 'b2', 'keyvalue': 'b2v'}]},
        {'name': 'charlie',
         'authorized': [{'key': 'c1', 'keyvalue': 'c1v'}, {'key': 'c2', 'keyvalue': 'c2v'}]}
    ]


# Generated at 2022-06-21 06:39:19.445638
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    check_terms = ['terms-list', 'second-key']
    check_variables = ['variables-list', 'second-element']
    result = lookup_module.run(check_terms, check_variables)
    assert result is not None

# Generated at 2022-06-21 06:39:30.214446
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prepare dependencies
    from ansible.utils.template import Template
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv, split_args

    # prepare input data

# Generated at 2022-06-21 06:39:41.743016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare a mock with a method that returns known values
    class MockTemplar:
        def template(*args, **kwargs):
            return args[0]
    loader = None
    templar = MockTemplar()
    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader = loader
    # Test run with known values
    terms = [({"name": "alice", "authorized": ["/tmp/alice/onekey.pub","/tmp/alice/twokey.pub"]}), ({"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}), "authorized"]
    # The call to run must not generate any exception
    lookup_module.run(terms, {})


# Execute the unit tests

# Generated at 2022-06-21 06:39:43.283959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None).run([], None, None) == []

# Generated at 2022-06-21 06:39:45.054597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None)

# Generated at 2022-06-21 06:39:52.620532
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests for a dictionary
    template_dict = {
        'first_dict': {
            'first_key': [1, 2, 3]
        },
        'second_dict': {}
    }

    # Test 1: dictionary with one key
    test1 = LookupModule()
    terms = [template_dict, 'first_dict']
    assert test1.run(terms, None) == [([1, 2, 3],)]

    # Test 2: dictionary without any valid key
    test2 = LookupModule()
    terms = [template_dict, 'invalid_key']
    assert test2.run(terms, None) == []

    # Tests for a list

# Generated at 2022-06-21 06:40:03.423564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {}
    lu = LookupModule()
    lu._templar = lu._loader = None

    def _raise_error(msg):
        raise AssertionError(msg)
    lu._display.error = _raise_error


# Generated at 2022-06-21 06:40:10.360667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [
        [
            {
                "firstname": "Barry",
                "lastname": "Allen",
                "powers": ["speed"]
            },
            {
                "firstname": "Hal",
                "lastname": "Jordan",
                "powers": ["will"]
            }
        ],
        "powers",
        {
            "skip_missing": True
        }
    ]
    ret = lookup_module.run(terms, variables=None)

# Generated at 2022-06-21 06:40:20.231125
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        [
            {"foo": "bar"},
            {"baz": "qux"},
            {"subelements": "testing"}
        ]
    ]
    variables = {}
    # _templar is needed by listify_lookup_plugin_terms
    _templar = None
    # _loader is needed by listify_lookup_plugin_terms
    _loader = None
    subelements = LookupModule()
    assert subelements.run(terms, variables) == [
        ({'foo': 'bar'}, 'testing'),
        ({'baz': 'qux'}, 'testing')
    ]

# Generated at 2022-06-21 06:40:37.045935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup



# Generated at 2022-06-21 06:40:38.105832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)

# Generated at 2022-06-21 06:40:38.684955
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:40:41.265673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'AnsibleError' in str(LookupModule("", "", "", "").run("", ""))



# Generated at 2022-06-21 06:40:44.238149
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:40:52.088340
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        # first term should be a list of dicts
        LookupModule('dict')

        assert False
    except AnsibleError:
        pass

    try:
        # second term should be a string
        LookupModule('dict', 'dict')

        assert False
    except AnsibleError:
        pass

    try:
        # third term should be a dict
        LookupModule('dict', 'dict', 'dict')

        assert False
    except AnsibleError:
        pass

    try:
        # third term should be a dict
        LookupModule('dict', 'dict', dict(notavalidflag=1))

        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-21 06:40:56.043564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test constructor of LookupModule
    """
    lm = LookupModule()
    lm.run(["", "", ""], {})

# Generated at 2022-06-21 06:40:59.416339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create some test objects
    test_module = LookupModule()
    test_module._templar = None
    test_module._loader = None

    # Placeholder for any real tests
    pass

# Generated at 2022-06-21 06:41:11.285147
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _run_lookup_module(terms, expected, verbosity=0):
        lm = LookupModule()
        result = lm.run(terms, [], verbosity=verbosity)
        if result != expected:
            print("Error in test_LookupModule_run for terms %s.\n"
                  "expected result:%s\n\n"
                  "actual result:%s" % (terms, expected, result))
            assert result == expected


# Generated at 2022-06-21 06:41:11.671465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:41:53.842829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing " + __file__)

    class TestJinja2():
        def __init__(self):
            self.environment = ""

        def from_string(self, template):
            return template

    class TestPluginLoader():
        def __init__(self):
            self.env = ""

        def get(self, name, *args, **kwargs):
            return TestJinja2()

        def list(self):
            return ""

    class TestTemplar():
        def __init__(self):
            self.environment = ""
            self.loader = TestPluginLoader()


# Generated at 2022-06-21 06:42:03.815512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    error = False

# Generated at 2022-06-21 06:42:14.469010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create the LookupModule object
    lookupModule = LookupModule()

    # Test the basic constructor
    terms = ['1', '2', '3']
    variables = {}
    ret = lookupModule.run(terms, variables, **kwargs)

    assert ret['kwargs_term'] is None
    assert ret['kwargs_variables'] is None
    assert ret['skip']

    # Test the constructor with kwargs
    lookupModule = LookupModule(terms, variables)
    ret = lookupModule.run(**kwargs)

    assert ret['kwargs_term'] is terms
    assert ret['kwargs_variables'] is variables
    assert not ret['skip']


# Generated at 2022-06-21 06:42:27.475243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    el = [{'x': 1}, {'x': 2}]
    t = ('value', None, True)
    v = 'x'
    assert t == lm.run([el, v], None)
    el = [{'x': 1}, {'y': 2}]
    t = ('value', None, False)
    assert t == lm.run([el, v], None)
    el = [{'x': [1, 2, 3]}, {'x': [3, 4, 5]}]
    t = [('value', 1), ('value', 2), ('value', 3), ('value', 3), ('value', 4), ('value', 5)]
    assert t == lm.run([el, v], None)

# Generated at 2022-06-21 06:42:28.323105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:42:29.966136
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert type(l) == LookupModule


# Generated at 2022-06-21 06:42:37.453482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = None
    l._loader = None

    #check for error in terms when multiple lists/dicts
    terms = [[{'one': '1', 'two': {'three': [1, 2]}}], 'two.three']
    try:
        l.run(terms, None)
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e)

    # check for error in terms when not list of 2 or 3
    terms = [[{'one': '1', 'two': {'three': [1, 2]}}], 'two.three', {'skip_missing': True}, 'skipped']

# Generated at 2022-06-21 06:42:44.798624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.run([[{"a": {"b": "c"}}], "a.b"])
    mod.run([[{"a": "c"}], "a"])
    mod.run([[{"a": {"b": "c"}}], "a.b.c"], skip_missing=True)
    mod.run([[{"a": {"b": "c"}}], "a.b.c"], skip_missing=False)
    mod.run([[{"a": {"b": "c"}, "c": "e"}], "a.b", {"skip_missing": True}])
    mod.run([[{"a": {"b": "c", "c": "e"}}], "a.b", {"skip_missing": True}])

# Generated at 2022-06-21 06:42:46.164687
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    assert myLookupModule is not None

# Generated at 2022-06-21 06:42:48.196476
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert issubclass(LookupModule, LookupBase)
  assert LookupModule.__name__ == "LookupModule"


# Generated at 2022-06-21 06:43:55.982378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.listify import listify_lookup_plugin_terms
    lookup_module = LookupModule()

    skip_missing = {'skip_missing': True}
    users = listify_lookup_plugin_terms([{'name': 'james', 'authorized': ['/tmp/james/id_rsa.pub', '/tmp/james/id_dsa.pub']}, {'name': 'bob'}, {'name': 'alice', 'authorized': ['/tmp/alice/id_rsa.pub']}])
    results = lookup_module.run([users, 'authorized', skip_missing], {})[0]

# Generated at 2022-06-21 06:44:00.038757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-21 06:44:04.746701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # a list of dictionaries
    testdata = [
        {'name': 'foo', 'groups': ['g1.1', 'g1.2'], 'skipped': False},
        {'name': 'bar', 'groups': ['g2.1', 'g2.2'], 'skipped': False},
        {'name': 'baz', 'skipped': False},
    ]

    # first test: check the test data
    assert len(testdata) > 0, "testdata should contain at least one element"
    for elem in testdata:
        assert isinstance(elem, dict), "testdata should be a list of dictionaries"

    # second test: run method of LookupModule with groups an subkey
    results = LookupModule.run(None, [testdata, 'groups'], {})
    # check

# Generated at 2022-06-21 06:44:15.354990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyTemplar(object):
        def __init__(self):
            self.failures = []

        def template(self, value, variables=None, convert_bare=True, fail_on_undefined=True, preserve_trailing_newlines=True, escape_backslashes=True, override_vars=None, *args, **kwargs):
            return value

        def add_failure(self, msg):
            pass

    class DummyLoader(object):
        def __init__(self):
            pass


    l = LookupModule()
    l._templar = DummyTemplar()
    l._loader = DummyLoader()

    # test: exception

# Generated at 2022-06-21 06:44:16.457292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_class = LookupModule()
    assert my_class is not None

# Generated at 2022-06-21 06:44:22.368372
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given a list of elements
    elements = [
        {'elmnt_0': {'subelmnt': [0, 1, 2]}},
        {'elmnt_1': {'subelmnt': [3, 4, 5]}},
        {'elmnt_2': {'subelmnt': [6, 7, 8]}},
    ]

    # When called with a subelements lookup
    module = LookupModule()
    subelements = module.run([elements, 'subelmnt'])

    # Then the list contains tuples with 3 elements
    assert len(subelements) == 3

    # And each tuple contains the item and the subelement
    for i, subelement in enumerate(subelements):
        assert len(subelement) == 2

# Generated at 2022-06-21 06:44:34.088856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    #
    # testing the subelements lookup
    #
    # prepare a setup, a list of dicts
    testsetup = {
        "users": [
            {"name": "alice",
                "authorized":
                ["/tmp/alice/onekey.pub",
                 "/tmp/alice/twokey.pub"]
                },
            {"name": "bob",
                "authorized":
                    ["/tmp/bob/id_rsa.pub"]
                }
        ]
    }
    # test the run method
    lookup = LookupModule()
    terms = [testsetup['users'], "authorized"]
    ret = lookup.run(terms, testsetup)
    assert isinstance(ret, list)

# Generated at 2022-06-21 06:44:40.224749
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()

    # test empty terms
    terms = []
    result = lookup_plugin.run(terms, None)
    assert isinstance(result, list)
    assert not result

    # test one term only, it should be rejected
    terms = [[1, 2, 3]]
    try:
        result = lookup_plugin.run(terms, None)
        assert False, "An exception was expected for the previous line"
    except AnsibleError:
        assert True

    # test two terms
    terms = [[{'a': '1', 'b': '2', 'c': '3'}], 'c']
    result = lookup_plugin.run(terms, None)
    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-21 06:44:50.265659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeTemplar():
        def template(self, value):
            return value
        def is_template(self, value):
            return False
    class FakeLoader():
        pass

    lookup = LookupModule()
    lookup._templar = FakeTemplar()
    lookup._loader = FakeLoader()

# Generated at 2022-06-21 06:45:02.655120
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    try:
        lookup.run([
            # wrong types
            [["a", "b", "c"]],
            12345,
            {"skip_missing": False}
        ], "")
        assert False
    except AnsibleError:
        assert True

    try:
        lookup.run([
            # wrong types
            [],
            "a.b.c",
            {"skip_missing": False}
        ], "")
        assert False
    except AnsibleError:
        assert True

    try:
        lookup.run([
            # wrong types
            {},
            "a.b.c",
            {"skip_missing": False}
        ], "")
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-21 06:47:32.781959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test
    lookup_module = LookupModule()
    lookup_module.set_runner({'_templar': None})
    lookup_module._loader = None  # noqa  pylint: disable=protected-access

    # run test 1
    lookup_module.run([[{'a': 'a-value', 'b': 'b-value'}, {'a': 'a-value-2', 'b': 'b-value-2'}], 'a'], {}) == [
        ({'a': 'a-value', 'b': 'b-value'}, 'a-value'), ({'a': 'a-value-2', 'b': 'b-value-2'}, 'a-value-2')]

    # run test 2

# Generated at 2022-06-21 06:47:35.328273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.lookup_ansible_lookup_plugins import LookupModule

    lookup_module = LookupModule()

    assert lookup_module is not None