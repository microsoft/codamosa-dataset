

# Generated at 2022-06-25 11:17:14.647696
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:20.570766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)

    terms = []
    variables = []
    kwargs = {}

    try:
        lookup_module_0.run(terms, variables, **kwargs)
    except Exception as err:
        return -1

    return 0

if __name__ == "__main__":
    if test_LookupModule_run() != 0:
        exit(-1)
    exit(0)

# Generated at 2022-06-25 11:17:32.122925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    str_0 = "3"
    dict_0 = dict()
    dict_0["Gvf_1bW8_fUVu1ZVh_5r5xw_Gz6gYdOoQP6_XU6lf8U_f6_3_END"] = str_0
    dict_0["R91_RSDn_nJh8g7Wu_p_5_7V5z5r5xw_Gz6gYdOoQP6_XU6lf8U_f6_3_END"] = str_0
    str_1 = "users"
    dict_0[str_1] = list()

# Generated at 2022-06-25 11:17:41.874039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(True)
    list_0 = ['a', 'aaa', 'aaaa', 'aaaaa']
    dict_0 = dict()
    dict_0['a'] = list_0
    dict_0['a'] = dict_0['a']
    dict_0['b'] = 'b'
    dict_0['b'] = dict_0['b']
    dict_0['c'] = 'c'
    dict_0['c'] = dict_0['c']
    dict_0['d'] = 'd'
    dict_0['d'] = dict_0['d']
    dict_0['e'] = 'e'
    dict_0['e'] = dict_0['e']
    dict_0['f'] = 'f'
    dict_0['f'] = dict_0

# Generated at 2022-06-25 11:17:48.870636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #print("__________________")
    #print("in suite test_LookupModule_run")
    #print("__________________")
    #print("__________________")
    #print("in test_LookupModule_run")
    #print("__________________")
    test_case_LookupModule_run_0()     #
    test_case_LookupModule_run_1()     #
    test_case_LookupModule_run_2()
    test_case_LookupModule_run_3()     #
    test_case_LookupModule_run_4()     #
    test_case_LookupModule_run_5()
    test_case_LookupModule_run_6()
    test_case_LookupModule_run_7()     #
    test_case_LookupModule_run_8()
    test

# Generated at 2022-06-25 11:17:53.389079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule(bool_0)
    # params: args, variables=None, **kwargs
    lookup_module_0.run(('', ), )


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:18:03.990410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(True)
    bool_0 = True
    dict_0 = dict()
    dict_0['skip_missing'] = bool_0
    dict_1 = dict()
    dict_2 = dict()
    dict_2['subkey'] = 'subkey'
    dict_2['value'] = dict_1
    dict_1['subkey'] = 'subkey'
    dict_1['value'] = dict_2
    dict_2['subkey'] = 'subkey'
    dict_2['value'] = dict_1
    dict_1['subkey'] = 'subkey'
    dict_1['value'] = dict_2
    list_0 = list()
    list_0.append('subkey')
    list_0.append(dict_1)

# Generated at 2022-06-25 11:18:11.293780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-25 11:18:17.715102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'a': 'b'}, 'a']
    variables = {"a": 'b'}
    lookup_module_0 = LookupModule(None, None)
    subelements = [{'a': 'b'}]
    assert lookup_module_0.run(terms, variables) == subelements

# Generated at 2022-06-25 11:18:25.062313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule(None)
    ansible_dict = {
        'a': {
            'b': {
                'c': [
                    {'name': 'test1'},
                    {'name': 'test2'},
                ]
            }
        }
    }
    terms = ['a.b.c', 'name']
    result = lookup.run(terms, ansible_dict)
    assert result == [{'name': 'test1'}, {'name': 'test2'}]

# Generated at 2022-06-25 11:18:34.013125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:18:45.092573
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['127.0.0.1', 'ansible_facts', 'skip_missing']
    # AnsibleModuleTestSuite.test_AnsibleModule.ansible_module_run.run(self, terms, variables, **kwargs)

    lookup_module_0 = LookupModule()
    int_0 = -1768729881
    int_1 = -118462298
    int_2 = -1535754552
    int_3 = 609179561
    int_4 = 69011295
    int_5 = -449336779
    int_6 = -1339257659
    int_7 = -1238780646
    int_8 = -1473166448
    int_9 = -1734651696
    int_10 = -1428691222
    int

# Generated at 2022-06-25 11:18:50.033800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import subprocess
    print('running test case 0')
    test_case_0()
    print('finished test case 0')
    x = subprocess.check_output(['pytest', '-v', sys.argv[0]])
    print('\n', x)

# Generated at 2022-06-25 11:18:53.409527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'E&&LYf'
    lookup_module_1 = 'a)'
    lookup_module_2 = {}
    var_0 = lookup_run(str_0, lookup_module_1, lookup_module_2)


# Generated at 2022-06-25 11:18:59.730174
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:08.088419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 1
    int_1 = 0
    str_0 = 'UT'
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'w'
    str_4 = 'r'
    str_5 = 'e5%'
    str_6 = "}}|O"
    str_7 = "7"
    str_8 = 'o'
    str_9 = "8"
    str_10 = str_1
    str_11 = str_5
    str_12 = '5gP|'
    str_13 = '=Ue'
    str_14 = 'c'
    str_15 = '.'
    str_16 = 'p'
    str_17 = 'HiW-'
    str

# Generated at 2022-06-25 11:19:09.704954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Unknown: lookup_module_0.run()


# Generated at 2022-06-25 11:19:13.966857
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        lookup_module_0 = LookupModule()
        str_0 = '.J\\\r!8|UL'
        lookup_module_1 = None
        set_0 = {lookup_module_1}
        list_0 = [set_0, lookup_module_0]
        var_0 = lookup_run(str_0, list_0)

    except TypeError as e:
        print(e)


# Generated at 2022-06-25 11:19:15.307576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:19:20.891132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'z6>%y6'
    lookup_module_1 = None
    set_0 = {lookup_module_1}
    list_0 = [set_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)



# Generated at 2022-06-25 11:19:37.863754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = ()
    lookup_module_1 = LookupModule()
    lookup_module_2 = {lookup_module_0}
    lookup_module_3 = ()
    lookup_module_4 = LookupModule()

    lookup_module_4.run(lookup_module_1, lookup_module_2, lookup_module_3)

# Generated at 2022-06-25 11:19:41.311428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Q\x19\x07\x1f\x0f'
    list_0 = [str_0]
    var_0 = lookup_run(str_0, list_0)
    assert var_0 is None


# Generated at 2022-06-25 11:19:51.889453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'w23'
    str_1 = '<bU$l'
    set_0 = {str_1}
    dict_0 = {'dict_key': set_0}
    list_0 = [dict_0]
    list_1 = [list_0, str_0]
    lookup_module_0.run(list_1)
    lookup_module_0.run(list_1)

if (__name__ == '__main__'):
    test_case_0()

# Need to create a unit test that uses self._templar.template, self._loader.path_dwim, etc.

# Generated at 2022-06-25 11:20:01.151507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_variable_definition - start
    str_0 = '.J\\\r!8|UL'
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0}
    list_0 = [set_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)
    # test_variable_definition - end
    # test_code_branch_0 - start
    # test_code_branch_0 - end
    #/ test_code_branch_0 - end
    # test_code_branch_1 - start
    # test_code_branch_1 - end
    #/ test_code_branch_1 - end
    # test_code_branch_2 - start
    # test_code_branch_

# Generated at 2022-06-25 11:20:05.303945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Y}5$5#'
    var_0 = lookup_run(str_0, lookup_module_0)
    list_0 = []
    lookup_module_1 = var_0
    assert len(set(list_0)) == lookup_run('h=)P', lookup_module_1)

# Generated at 2022-06-25 11:20:09.768868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '[8E_'
    set_0 = {set_0}
    list_0 = [set_0, lookup_module_0]
    var_0 = lookup_run(str_0, list_0)

# Generated at 2022-06-25 11:20:15.911754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except AnsibleError:
        pass


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:20:22.495298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '[\\\x0c'
    list_0 = ['~F', lookup_module_0]
    var_0 = lookup_run(str_0, list_0)


# Generated at 2022-06-25 11:20:30.627956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run('.J\\\r!8|UL', {None})
    assert ret == []
    ret = LookupModule.run('.J\\\r!8|UL', {None})
    assert ret == []
    ret = LookupModule.run('.J\\\r!8|UL', {None})
    assert ret == []
    ret = LookupModule.run('.J\\\r!8|UL', {None})
    assert ret == []
    ret = LookupModule.run('.J\\\r!8|UL', {None})
    assert ret == []
    ret = LookupModule.run('.J\\\r!8|UL', {None})
    assert ret == []
    ret = LookupModule.run('.J\\\r!8|UL', {None})

# Generated at 2022-06-25 11:20:34.582622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_2 = LookupModule()
    str_1 = '.J\\\r!8|UL'
    lookup_module_3 = None
    set_1 = {lookup_module_3}
    list_1 = [set_1, lookup_module_2]
    var_1 = lookup_run(str_1, list_1)

# Generated at 2022-06-25 11:21:11.948690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Invoke method run of class LookupModule
    try:
        test_case_0()
    except Exception:
        assert False

lookup_module = LookupModule()
lookup_run = lookup_module.run

from ansible.module_utils.basic import AnsibleModule

from ansible_collections.community.general.tests.unit.compat.mock import patch
from ansible_collections.community.general.tests.unit.modules.utils import set_module_args



# Generated at 2022-06-25 11:21:13.783075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = str()
    var_1 = test_case_0()
    print(var_1)



# Generated at 2022-06-25 11:21:18.877293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!|gnv:+'
    list_0 = [str_0, str_0]
    list_1 = [list_0, list_0]
    var_0 = lookup_module_0.run(list_1, list_0)
    assert var_0 is None


# Generated at 2022-06-25 11:21:24.314801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = 'Y4c%8s0'
    var_2 = [[1, '`S']]
    var_3 = lookup_run(var_1, var_2)



# Generated at 2022-06-25 11:21:24.884407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 11:21:29.856534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = LookupModule()

    # 1 input
    input = [
        [
            {'skipped': 'ps'},
            {'skipped': 'mf'}
        ],
        'skipped'
    ]
    expected = []
    actual = var.run(input, {})
    assert actual == expected, actual

    # 2 input
    input = [
        [
            [
                {
                    'skipped': {
                        'keywords': 'pix'
                    }
                }
            ],
            {
                'skipped': {
                    'keywords': 'mf'
                }
            }
        ],
        'skipped.keywords'
    ]

# Generated at 2022-06-25 11:21:36.109076
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_2 = LookupModule()
    str_1 = '4*^/'
    list_1 = ['B', 'N', '.', '9']
    test_case_1 = lookup_run(str_1, list_1)
    # test_case_1: should be ''

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:21:39.995676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'b*#y\'ILd^q@!,Mv&'
    list_0 = [{}, 'K>-h.Yp5\',,f!']
    lookup_module_0 = LookupModule()
    lookup_module_0.run(str_0, list_0)



# Generated at 2022-06-25 11:21:45.913293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case with only required arguments.
    lookup_module_0 = LookupModule()
    str_0 = 'N{9a'
    list_0 = [str_0]
    assert not lookup_module_0.run(terms=list_0)
    assert lookup_module_0.run(terms=list_0, variables='G-#o') is None
    assert not lookup_module_0.run(terms=list_0, variables='l')
    assert lookup_module_0.run(terms=list_0, variables=str_0) is None



# Generated at 2022-06-25 11:21:52.802949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'mfW_|8<3EiX9'
    int_0 = 15641777
    list_0 = [int_0, str_0]
    dict_0 = dict()
    dict_1 = dict()
    dict_1['i>$=GZKT`8Z'] = dict_0
    list_1 = [dict_1]
    dict_2 = dict()
    dict_2['=@l:m1X$S<@['] = dict_0
    list_2 = [dict_2, dict_0]
    dict_3 = dict()
    dict_3['`t,sBh*J)#;K'] = dict_0
    dict_4 = dict()

# Generated at 2022-06-25 11:23:04.627211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str = '.J\\\r!8|UL'
    lookup_module_1 = None
    set = {lookup_module_1}
    list_0 = [set, lookup_module]
    var = lookup_run(str, list_0)

# Generated at 2022-06-25 11:23:15.391073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  # actual = lookup_module_0.run({'skipped': False, '0': {'skipped': False, 'name': 'user', 'authorized': ['/home/user/somekey.pub', '/home/user/anotherkey.pub'], 'mysql': {'hosts': ['192.168.0.1', '::1', '192.168.0.2'], 'password': 'mysql-password', 'privs': ['*.*:ALL', 'DB1.*:SELECT']}}, '1': {'skipped': False, 'name': 'user2', 'authorized': ['/home/user2/id_rsa.pub'], 'mysql': {'hosts': ['db1'], 'password': 'other-mysql-password', 'privs': ['DB2.*

# Generated at 2022-06-25 11:23:17.991687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('', '')


# Generated at 2022-06-25 11:23:28.383159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # method run
    list_0 = ['uK7$Ug', '0]7V^', {'skip_missing': True}]

# Generated at 2022-06-25 11:23:36.718663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = dict(
        list_of_dict=[
            dict(name='alice', authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']),
            dict(name='bob', authorized=['/tmp/bob/id_rsa.pub']),
        ],
        subkey='authorized',
    )
    result = lookup.run(terms, dict())

# Generated at 2022-06-25 11:23:37.990833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [None]
    var_0 = lookup_module_0.run(None, list_0)


# Generated at 2022-06-25 11:23:46.560959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'x.xF.N'
    var_0 = [lookup_module_0, 5.9, 6]

# Generated at 2022-06-25 11:23:48.202085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'y'
    list_0 = []
    lookup_module_0.run(str_0, list_0)


# Generated at 2022-06-25 11:23:53.759407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run("subelements", "terms")
    assert var == 'terms'


# Generated at 2022-06-25 11:24:01.157635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: Replace with your own test case here
    str_0 = '.J\\\r!8|UL'
    lookup_module_1 = None
    set_0 = {lookup_module_1}
    list_0 = [set_0, lookup_module_0]
    var_0 = lookup_module_0.run(str_0, list_0)

if __name__ == "__main__":
    test_LookupModule_run()