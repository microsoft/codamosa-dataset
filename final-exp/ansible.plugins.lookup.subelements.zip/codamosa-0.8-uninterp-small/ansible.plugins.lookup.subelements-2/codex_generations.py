

# Generated at 2022-06-25 11:17:14.914948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['users', 'mysql.hosts']

# Generated at 2022-06-25 11:17:20.372188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    kwargs = dict()
    ret = lookup_module_0.run(terms=[], variables='', **kwargs)
    assert ret == []

    lookup_module_1 = LookupModule()
    kwargs = dict()
    ret = lookup_module_1.run(terms=[], variables='', **kwargs)
    assert ret == []


# Class LookupModule tests

# TESTING COMPLETE

# Generated at 2022-06-25 11:17:26.984747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # simple case, just a dictionary
    lookup_module = LookupModule()
    test_complex = {"a": "b"}
    assert lookup_module.run([test_complex], None) == {"a": "b"}


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:17:37.162508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['users', 'mysql.hosts', {'skip_missing': False}]
    lookup_module_0 = LookupModule()
    return_value = lookup_module_0.run(terms, {})

# Generated at 2022-06-25 11:17:42.119527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0(lookup_module_0)

# Generated at 2022-06-25 11:17:53.628463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # case 0
    (elementlist_0, subelements_0, flags_0) = ([{'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'skipped': False, 'privs': ['*.*:SELECT', 'DB1.*:ALL']}], ['hosts'], [])
    _lookup_module_run_0_e0_0 = lookup_module_0.run(terms=[elementlist_0, subelements_0, flags_0], variables=None, **{})

# Generated at 2022-06-25 11:18:03.927834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # when

# Generated at 2022-06-25 11:18:11.265830
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import string_types
    from ansible.plugins.loader import lookup_loader

    # Load lookup plugin
    lookup_0 = lookup_loader.get('subelements')

    # Setup context for lookup plugin
    variables_0 = {}
    templar_0 = lookup_0._templar
    loader_0 = lookup_0._loader

    # Setup terms for lookup plugin

# Generated at 2022-06-25 11:18:18.608210
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:27.929884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_data_0 = [
        (
            [
                ['item_0'],
                'item_1'
            ],
            {}
        ),
        (
            [
                ['item_0'],
                'item_1'
            ],
            {
                'skip_missing': True
            }
        )
    ]
    for arg_input, arg_vars in test_data_0:
        lookup_module = LookupModule()
        out = lookup_module.run(*arg_input, **{'variables': arg_vars})
        assert out is not None
        assert type(out) is list
        if type(out) is list:
            for item in out:
                assert type(item) is tuple

# Generated at 2022-06-25 11:18:47.900630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]

    lookup_module_0 = lookup_module.LookupModule()
    subelements = lookup_module_0.run(['users', 'authorized'], None)


# Generated at 2022-06-25 11:18:58.529157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:19:07.963428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # term as list
    terms_0 = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]

# Generated at 2022-06-25 11:19:12.282888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list = [{'a': {'b': [1, 2, 3]}}]
    terms = [list, 'a.b']
    variables = {}
    subelements = LookupModule().run(terms, variables)
    assert sorted(subelements) == [(list[0], 1), (list[0], 2), (list[0], 3)]


# Generated at 2022-06-25 11:19:20.724775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("test_LookupModule_run()")
  {
    "Users": [
      {
        "name": "alice",
        "authorized": [
          "/tmp/alice/onekey.pub",
          "/tmp/alice/twokey.pub"
        ]
      },
      {
        "name": "bob",
        "authorized": [
          "/tmp/bob/id_rsa.pub"
        ]
      }
    ]
  }
  lookup_module = LookupModule()
  ans = lookup_module.run(["Users", "authorized"], [])

# Generated at 2022-06-25 11:19:28.123688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with following arguments:
    #
    #    item0 = { 'name':'alice', 'authorized':['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql':{ 'password':'mysql-password', 'hosts':['%', '127.0.0.1', '::1', 'localhost'], 'privs':['*.*:SELECT', 'DB1.*:ALL']}, 'groups':['wheel']}
    #    item1 = { 'name':'bob', 'authorized':['/tmp/bob/id_rsa.pub'], 'mysql':{ 'password':'other-mysql-password', 'hosts':['db1'], 'privs':['*.*:SELECT', 'DB2

# Generated at 2022-06-25 11:19:33.154798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(["subkeys-2"], "subkeys")
    print(result)
    assert result[0] == "subkeys"


# Generated at 2022-06-25 11:19:41.893011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    subelement_list = [{'ansible_host': 'localhost', 'ansible_port': 22, 'ansible_user': 'root', 'ansible_password': 'secret'},
                       {'ansible_host': 'localhost', 'ansible_port': 22, 'ansible_user': 'root', 'ansible_password': 'secret'}]
    term_list = [subelement_list, "ansible_password"]
    res = lookup_module.run(term_list, None)
    assert res == [('secret',), ('secret',)]

# Generated at 2022-06-25 11:19:53.492457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = Templar(None, None, None)
    lookup_module_0._loader = DataLoader()
    lookup_module_0._loader.set_basedir(None)
    terms_list = [["test"], "test"]
    terms_dict = [{"test": ["test"]}, "test"]
    ret = lookup_module_0.run(terms_list, None, **{'variables': 'test'})
    assert ret is not None
    assert ret == [('test', ['test'])]
    ret = lookup_module_0.run(terms_dict, None, **{'variables': 'test'})
    assert ret is not None
    assert ret == [('test', ['test'])]


# Generated at 2022-06-25 11:20:04.189683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{'skipped': True}, 'missing', {}]
    result = lookup_module.run(terms, variables=None)
    assert result == []

    terms = [[{'skipped': True}], 'missing', {'skip_missing': False}]
    with pytest.raises(AnsibleError) as excinfo:
        result = lookup_module.run(terms, variables=None)
    excinfo.match('could not find')

    terms = [['not a dictionary'], 'missing']
    with pytest.raises(AnsibleError) as excinfo:
        result = lookup_module.run(terms, variables=None)
    excinfo.match('subelements lookup expects a dictionary,')


# Generated at 2022-06-25 11:20:39.580284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    kwargs = {'t': (1, 2)}
    assert lookup_module_0.run(None, kwargs) == []
    assert kwargs == {'t': (1, 2)}

# Generated at 2022-06-25 11:20:47.694947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        "name": "alice",
        "authorized": [
            "/tmp/alice/onekey.pub",
            "/tmp/alice/twokey.pub"
        ],
        "mysql": {
            "password": "mysql-password",
            "hosts": [
                "127.0.0.1",
                "::1",
                "localhost"
            ],
            "privs": [
                "*.*:SELECT",
                "DB1.*:ALL"
            ]
        },
        "groups": [
            "wheel"
        ]
    }
    list_0 = [
        dict_0
    ]

# Generated at 2022-06-25 11:20:52.360654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run([]), list)
    assert isinstance(lookup_module_0.run([]), list)
    assert isinstance(lookup_module_0.run([]), list)

# Method run of class LookupModule has an error if key 'terms' is missing. An exception is raised

# Generated at 2022-06-25 11:20:57.912952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = type('LookupModule', (object,), {'run': LookupModule.run})
    lookup_instance = lookup_module()
    terms = [{}, "authorized"]
    variables = {}

    result = lookup_instance.run(terms, variables, inject=None)
    assert result is not None

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:21:01.312546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is a test using a fake exit code to detect failures:
    args = [
        {'ansible_facts': {'env': {'HOME': '/home/username', 'PWD': '/home/username/project', }},
        'changed': False, 'invocation': {'module_name': 'setup'}, 'failed': False},
        'env',
        {},
    ]
    assert lookup_module_0.run(args) == [{'HOME': '/home/username', 'PWD': '/home/username/project'}]

# Generated at 2022-06-25 11:21:11.315303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]

# Generated at 2022-06-25 11:21:22.193027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for example pass, but with the following errors:
    # ERROR: Failure on example 2:
    # ERROR: Failure on example 3:
    # ERROR: Failure on example 4:

    lookup_module = LookupModule()
    # Tests for error raises with _terms error
    with pytest.raises(AnsibleError, match=r".*subelements lookup expects a list of two or three items.*"):
        lookup_module.run([], {"__subelements__": []})

    with pytest.raises(AnsibleError, match=r".*subelements lookup expects a list of two or three items.*"):
        lookup_module.run([1], {"__subelements__": []})


# Generated at 2022-06-25 11:21:28.814504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ToDo: verify the lookup result
    # lookup_module_0 = LookupModule()
    # lookup_module_0.run('','')
    pass

if __name__ == "__main__":
    import pytest
    pytest.main('-v -x test_subelements.py')

# Generated at 2022-06-25 11:21:36.212878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict = {'name': "alice", 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']}
    arr = [dict, dict]
    terms = [arr, 'authorized']
    lookup_module_1 = LookupModule()
    assert len(lookup_module_1.run(terms, None)) == 4


# Generated at 2022-06-25 11:21:40.649961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_result = lookup_module.run([['{\"first_name\":\"John\", \"last_name\":\"Smith\", \"age\":25, \"city\":\"Zurich\", \"country\":\"Switzerland\"}'], 'first_name'], None)
    assert lookup_result == [('John',)]


# Generated at 2022-06-25 11:22:23.456944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    str_2 = 'dict'
    str_3 = 'list'
    str_1 = str_3
    str_0 = 'dict'
    lookup_module_0.run(str_1, str_0)
    lookup_module_0.run(str_0, str_2)
    lookup_module_0.run(str_3, str_3)


# Generated at 2022-06-25 11:22:27.135879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 11:22:32.442076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["skipped"]
    variables = ["skipped"]
    kwargs = {"skipped": "skipped"}
    lookup = LookupModule()
    lookup.run(terms, variables, **kwargs)
    print(
        "Testcase 0 passed for method run of class LookupModule")

# Testcase 1: Using testcase 0 as input

# Generated at 2022-06-25 11:22:37.589776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    terms = [bool_0, bool_0, bool_0]
    variables = [bool_0, bool_0, bool_0]
    kwargs = [bool_0, bool_0, bool_0]
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms, variables, **kwargs)
    int_0 = 8192
    lookup_module_1 = LookupModule(int_0)



# Generated at 2022-06-25 11:22:46.497251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    lookup_module_0 = LookupModule()
    bool_1 = False
    list_1 = [bool_1, bool_0, bool_0]
    lookup_module_1 = LookupModule(list_1)
    bool_2 = False
    list_2 = [bool_2, bool_0, bool_0]
    lookup_module_2 = LookupModule(list_2)
    bool_3 = False
    list_3 = [bool_3, bool_0, bool_0]
    lookup_module_3 = LookupModule(list_3)


# Testcase for: subelements.py
if __name__ == "__main__":
    test_case_0()
    test_Look

# Generated at 2022-06-25 11:22:47.061191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:22:56.801197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0, list_0)
    int_0 = 8192
    lookup_module_1 = LookupModule(int_0)
    list_1 = [bool_0, bool_0, bool_0]
    list_2 = [bool_0, bool_0, bool_0]

# Generated at 2022-06-25 11:23:07.811952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        s_0 = "s_0"
        int_0 = 1
        dict_0 = {"v_0": int_0, "v_1": s_0}
        dict_1 = {"v_0": dict_0}
        lookup_module_0 = LookupModule()
        lookup_run(dict_1, s_0)
    except AnsibleError:
        pass
    else:
        s_0 = "test_LookupModule_run"
        assert 0
    dict_0 = {"v_0": xrange(1), "v_1": xrange(1)}
    list_0 = []
    lookup_module_0 = LookupModule()
    lookup_run(list_0, dict_0)

# Generated at 2022-06-25 11:23:10.525397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule(lookup_module_1)
    lookup_module_0.run()

    # Teardown



# Generated at 2022-06-25 11:23:16.445443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0]
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0, list_0)
    int_0 = 8192
    lookup_module_1 = LookupModule(int_0)


# Generated at 2022-06-25 11:24:34.973189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the object with default values and call the run method.
    lookup_module_0 = LookupModule()
    list_0 = ["", "", ""]
    list_1 = [list_0, list_0, {"": ""}, {"": ""}]
    list_2 = []
    list_2.extend([list_1, list_0])
    list_3 = lookup_module_0.run(list_2)


# Generated at 2022-06-25 11:24:39.788546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: Case not implemented yet
    """
    assert lookup_module_0.run() == undefined
    """



# Generated at 2022-06-25 11:24:44.569786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    assert True


# Generated at 2022-06-25 11:24:53.312446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re, json, yaml
    from ansible.template import generate_ansible_template_vars

    env = generate_ansible_template_vars()

# Generated at 2022-06-25 11:24:58.932297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert list(LookupModule().run(["-", "list"], [1, 2, 3])) == [1, 2, 3]
    assert list(LookupModule().run(["-", "list"], {'skipped': True})) == [{}]
    assert list(LookupModule().run(["-", "list"], {'skipped': False})) == [{}]
    assert list(LookupModule().run(["-", "list"], {'skipped': False})) == [{}]
    assert list(LookupModule().run(["-", "list"], {'skipped': False})) == [{}]
    assert list(LookupModule().run(["-", "list"], {'skipped': False})) == [{}]
    with pytest.raises(AnsibleError):
        list

# Generated at 2022-06-25 11:25:06.258741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that skipping missing key does not raise an error
    # see https://github.com/ansible/ansible-modules-core/issues/4183
    class FakeTerm:
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return repr(self.value)

    class FakeTermsList:
        def __init__(self, terms):
            self.terms = list(terms)

        def __iter__(self):
            return iter(self.terms)

    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob'}
    ]

# Generated at 2022-06-25 11:25:09.916193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_of_dictionaries = []
    dictionary_key_to_extract = ""
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_of_dictionaries, dictionary_key_to_extract)

# Generated at 2022-06-25 11:25:11.380398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["subelements"], ["subelements"])



# Generated at 2022-06-25 11:25:13.918562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters

    # Expected output:
    expected_ret = [([], [])]

    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run([], [])

    assert ret == expected_ret


# Generated at 2022-06-25 11:25:14.832849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True