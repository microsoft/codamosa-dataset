

# Generated at 2022-06-25 11:17:13.359478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:17:19.321162
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init
    terms = ["1", "2", "3", "4", "5", "6"]
    variables = ""
    kwargs = ""
    lookup_module_0 = LookupModule()

    # execute
    actual_return = lookup_module_0.run(terms, variables, kwargs)
    expected_return = None
    assert actual_return == expected_return

# Generated at 2022-06-25 11:17:23.043505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []



# Generated at 2022-06-25 11:17:35.463338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # noinspection PyUnresolvedReferences
    lookup_module_0 = LookupModule()
    terms_0 = [{}, "/etc/hosts"]
    terms_1 = [None, None]
    terms_2 = [0, 0]
    terms_3 = [object, object]
    terms_4 = [{}, 0]
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms_0, variables=[])
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms_1, variables=[])
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms_2, variables=[])

# Generated at 2022-06-25 11:17:47.209014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_def = dict(
        lookup_name = 'subelements',
        lookup_options = dict(),
        requested_terms = [
            dict(
                param_type = 'string',
                param_name = '_terms',
                param_value = 'users.authorized'
            ),
            dict(
                param_type = 'list-of-dicts',
                param_name = 'users',
                param_value = [
                    dict(
                        name = 'alice'
                    ),
                ]
            )
        ],
        variables = dict()
    )

    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(lookup_def['requested_terms'], lookup_def['variables'])

    assert(result_0 == [])

# Generated at 2022-06-25 11:17:58.396886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._loader = FakeLoader()
    # Call method run with valid parameters
    try:
        lookup_module.run([
            [
                {
                    'k1': 'v1',
                    'skipped': True
                },
                {
                    'k2': 'v2',
                    'skipped': True
                }
            ],
            'k3',
            {
                'skipped': False
            }
        ], {'k4': 'v4'})
    except Exception as e:
        assert False, "unexpected exception: %s" % e

    # Call method run with invalid parameters

# Generated at 2022-06-25 11:18:08.794515
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:15.616080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar.template = lambda x: None
    lookup_module_0._loader = lambda x: None
    terms = []
    terms.append([{'skipped': False}])
    terms.append(['skipped'])
    terms.append({})
    variables = {}
    ret = lookup_module_0.run(terms, variables, skip_missing=False)
    assert isinstance(ret, list)
    assert ret == []


# Generated at 2022-06-25 11:18:21.566837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg0 = [{'a': 1, 'b': 2}]
    arg1 = {'a': {'c': 1}, 'b': {'c': [2, 3]}}
    arg2 = 'b'
    arg3 = {'skip_missing': False}
    ret0 = lookup_module_0.run(arg0, arg1, arg2, arg3)
    assert ret0 == [(2, 3)]
    assert not (ret0 != [(2, 3)])
    arg0 = {'a': {'c': [1, 2]}, 'b': {'c': [2, 3]}}
    arg1 = {'a': {'c': 1}, 'b': {'c': [2, 3]}}
    arg2 = 'a'
    arg

# Generated at 2022-06-25 11:18:26.180259
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:44.435016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    kwargs_1 = {'data': 'data'}
    lookup_module_0.run(terms_0, variables_0, **kwargs_1)


# Generated at 2022-06-25 11:18:50.523774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{'foo': [{'bar': [1, 2, 3]}, {'bar': [4, 5, 6]}]}, 'foo.bar', {}]
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == [(({'foo': [{'bar': [1, 2, 3]}, {'bar': [4, 5, 6]}]},), [1, 2, 3]), (({'foo': [{'bar': [1, 2, 3]}, {'bar': [4, 5, 6]}]},), [4, 5, 6])]

# Generated at 2022-06-25 11:18:55.867768
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = [
        [
            {
                "name": "alice"
            }
        ],
        "name"
    ]
    abc = lookup_module.run(terms)
    assert abc == [('alice',)]


# Generated at 2022-06-25 11:19:03.868053
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:12.742796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a case where the input is correct and the correct result is returned
    lookup_module = LookupModule()
    terms = ['outerkey', 'innerkey', {'skip_missing': 'True'}]
    variables = {'outerkey': [{'innerkey': 'result_of_the_lookup'}]}
    result = lookup_module.run(terms, variables)
    assert result == ['result_of_the_lookup']

    # Test a case where the input is incorrect and the correct result is returned
    terms = ['outerkey']
    variables = {'outerkey': [{'innerkey': 'result_of_the_lookup'}]}

# Generated at 2022-06-25 11:19:20.344662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Condition where we have a list of two items
    t1 = [
        {"a": 1, "b": 2, "c": {"d": 3, "e": [1, 2, 3, 4]}},
        {"a": 11, "b": 12, "c": {"d": 13, "e": [1, 2, 3, 4]}},
    ]
    t2 = "c.e"
    t3 = ["1", "2", "3", "4"]
    terms = [t1, t2]
    variables = {}
    kwargs = {}
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == t3

# Generated at 2022-06-25 11:19:27.830690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run test case 0
    test_case_0()

    lookup_module_0 = LookupModule()
    var_terms = list()
    var_terms.append(listify_lookup_plugin_terms("""{
          "a": {
            "b": 1,
            "c": 2
          },
          "b": {
            "b": 3,
            "c": 4
          }
        }"""))
    var_terms.append("b")
    var_terms.append("c")
    var_variables = False
    expected = [("a", 1), ("a", 2), ("b", 3), ("b", 4)]
    res = lookup_module_0.run(var_terms, var_variables)

    # check if result is as expected
    assert res == expected

# Generated at 2022-06-25 11:19:31.685519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [lookup_module_0, lookup_module_0, (lookup_module_0, lookup_module_0), lookup_module_0]
    varibales_0 = {lookup_module_0: (lookup_module_0, lookup_module_0), lookup_module_0: (lookup_module_0, lookup_module_0)}
    print(lookup_module_0.run(term_0, varibales_0))


# Generated at 2022-06-25 11:19:43.443720
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:54.334374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run([
        {
            'skipped': True
        }
    ], None)
    assert ret == []

    ret = lookup_module.run([
        {
            'skipped': False
        }
    ], None)
    assert ret == []

    ret = lookup_module.run([
        [
            {
                'skipped': False
            },
            {
                'skipped': False
            }
        ]
    ], None)
    assert len(ret) == 2

    ret = lookup_module.run([
        {
            'skipped': False
        }
    ], None)
    assert ret == []


# Generated at 2022-06-25 11:20:33.050752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing lookup_module_run
    lookup_module_run = LookupModule()
    m = '__main__'
    l = 'LookupModule'

    assert lookup_module_run.run([{'skipped':True}], {'skipped':True}) == [], 'Should be [] because elementlist is a list of one empty map'
    assert lookup_module_run.run([{'skipped':False}], {'skipped':False}) == [], 'Should be [] because elementlist is a list of one empty map'

    assert lookup_module_run.run([{'skipped':False}], {'skipped':False}, skip_missing=False) == [], 'Should be [] because elementlist is a list of one empty map'

# Generated at 2022-06-25 11:20:37.289565
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # SETUP
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:20:41.477289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import textwrap

    # test case 0

# Generated at 2022-06-25 11:20:44.202646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with argument 'terms' which is tuple
    terms_tuple = ('users', 'mysql.hosts')
    var_variables = 'ansible'
    lookup_module_0.run(terms_tuple,var_variables)



# Generated at 2022-06-25 11:20:54.403044
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'var': 'item_0', '_terms': {'0': 'item_1', '1': 'item_2'}})
    assert lookup_module_0.run({'0': 'item_1', '1': 'item_2'}, []) == {}
    lookup_module_0.set_options({'var': 'item_0', '_terms': ['item_1', 'item_2']})
    assert lookup_module_0.run(['item_1', 'item_2'], []) == {}
    lookup_module_0.set_options({'var': 'item_0', '_terms': ['item_1', 'item_2']})

# Generated at 2022-06-25 11:20:58.267562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(None)
    lookup_module_0.set_templar(None)
    terms = [
        None,
        None,
    ]
    variables = None
    kwargs = {
        'skip_missing': None,
    }
    assert lookup_module_0.run(terms, variables, **kwargs) == []


# Generated at 2022-06-25 11:21:00.521305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["arg1", "arg2", "arg3"], "arg4")

# Generated at 2022-06-25 11:21:10.783515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
# test_case_run_0
    subelements = ['mysql.hosts']

# Generated at 2022-06-25 11:21:15.062630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert check_case_0(lookup_module_0)

# check method run of class LookupModule

# Generated at 2022-06-25 11:21:21.500347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Running Test test_LookupModule_run')
    lookup_module = LookupModule()

    # test1: Test case for method run of class LookupModule
    print('Testing Test case for method run of class LookupModule')
    terms = {'skip_missing': False}
    variables = {}
    result = lookup_module.run(terms, variables)
    assert type(result).__name__ == 'list'
    print('Test case test_LookupModule_run: Success')



# Generated at 2022-06-25 11:21:57.972991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [('name', 'alice'), ('authorized', '/tmp/alice/onekey.pub'), ('skipped', True)]
    var_1 = {'key': 'name', 'skipped': True}
    lookup_module_0 = LookupModule(var_0, **var_1)

# Generated at 2022-06-25 11:22:01.452020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Comparing the lookup module result with the expected one
    assert test_case_0() == test_case_1()


# Generated at 2022-06-25 11:22:08.771106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'LZDc=)9>B'
    int_0 = -2064
    float_0 = -742.25
    str_1 = '0fy]!z\\D>Y'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    var_0 = lookup_module_0.run(str_0, int_0)

# Generated at 2022-06-25 11:22:13.898284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False  # TODO: implement your test here


# Generated at 2022-06-25 11:22:20.750092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'Bv^d;.RxF'
    int_0 = -2064
    float_0 = -742.25
    str_1 = '0fy]!z\\D>Y'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    lookup_module_0.run(str_0, int_0)

 # Unit test for method run of class LookupBase

# Generated at 2022-06-25 11:22:25.280963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'LZDc=)9>B'
    int_0 = -2064
    float_0 = -742.25
    str_1 = '0fy]!z\\D>Y'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    var_0 = lookup_module_0.run(str_0, int_0)


# Generated at 2022-06-25 11:22:26.423585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:22:32.401774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '6zXq'
    int_0 = 5609
    float_0 = 584.49
    str_1 = 'nH'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    var_0 = lookup_run(str_0, int_0)

# Generated at 2022-06-25 11:22:37.562201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'R^H\\;J$xl+c%'
    int_0 = 3442
    dict_0 = {str_0: int_0}
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    int_0 = -3346
    dict_0 = {str_0: int_0}
    lookup_module_0 = LookupModule(dict_0, **dict_0)
    var_0 = lookup_module_0.run()

# Generated at 2022-06-25 11:22:43.379692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '9120HUti,6'
    int_0 = 0
    float_0 = 34.26
    str_1 = 'a^9TQ,]HnU'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    var_0 = lookup_run(str_0, int_0)

test_LookupModule_run()

# Generated at 2022-06-25 11:23:48.402779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'expr' == 'expr'
    assert 'expr' == 'expr'
    assert 'expr' == 'expr'
    assert 'expr' == 'expr'
    assert 'expr' == 'expr'


# Generated at 2022-06-25 11:23:56.401216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'Wc_u*7>'
    float_0 = -2030.0
    str_1 = 'xrzXD\\|Fa'
    list_0 = [str_0, float_0]
    lookup_module_0 = LookupModule(**list_0)
    var_0 = lookup_module_0.run(str_1)
    print_var_0 = var_0


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:23:57.532499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l_obj = LookupModule(10)
    l_obj.run(10, 10)


# Generated at 2022-06-25 11:24:03.588315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'EWn#g:I9X'
    float_0 = -4128.29
    str_1 = 'b8l?zJ'
    str_2 = 'I/0<A'
    str_3 = 'I'
    int_0 = 13
    int_1 = -30
    str_4 = ''
    str_5 = '7sx!y}'
    int_2 = -10
    str_6 = 'p.|;k'
    int_3 = 15
    str_7 = 'bQ2:>'
    str_8 = '{k>;'
    int_4 = -37
    str_9 = 'r1ag9Z'
    str_10 = 'Y_B<'
    int_5 = -24
    str_11 = ''

# Generated at 2022-06-25 11:24:06.642100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test case
    test_case_0()
    # Second test case
    test_case_1()



# Generated at 2022-06-25 11:24:10.086367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'LZDc=)9>B'
    int_0 = -2064
    float_0 = -742.25
    str_1 = '0fy]!z\\D>Y'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    var_0 = lookup_run(str_0, int_0)

# Generated at 2022-06-25 11:24:15.176685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '0fy]!z\\D>Y'
    int_0 = -2064
    float_0 = -742.25
    str_1 = 'LZDc=)9>B'
    dict_0 = {str_1: str_1}
    lookup_module_0 = LookupModule(float_0, **dict_0)
    lookup_module_0.run(int_0, str_0)
    lookup_module_0.run(str_1, int_0)
    lookup_module_0.run(float_0, str_1)


# Generated at 2022-06-25 11:24:20.446281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [timeseries_1, timeseries_1]
    variables_0 = {key_7: -3020, key_4: 'kBy8(:yR', key_5: 'S)ne5.t', key_3: timeseries_1, key_0: '8Qy/X^z', key_6: '#|'}
    lookup_module_0 = LookupModule(key_7, **variables_0)
    lookup_module_0.run(terms_0, variables_0)


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:24:25.469077
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # list of lists
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
            {'name': 'carol', 'authorized': ['/tmp/carol/id_rsa.pub']},
        ],
        'authorized'
    ]

    var_0 = len(terms[0])
    var_1 = int(var_0 + -1)
    var_2 = [terms[0][var_0], terms[0][var_1]]
    var_3 = var_2[1]
    var_4 = var_3['name']
    var_5 = terms

# Generated at 2022-06-25 11:24:35.609623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'xW1'
    list_0 = ['n', 'B', '<XtDn:t2Ky', '3', 'm', 'b']
    subelements_0 = ''.join(map(str_0.__add__, list_0))
    int_0 = 1860
    float_0 = -83.08
    str_1 = 'J'
    dict_0 = {'skip_missing': True}
    subelements_1 = ''.join(map(str_1.__add__, list_0))
    lookup_module_0 = LookupModule(float_0, **dict_0)
    assert lookup_module_0 == lookup_run(dict_0, subelements_1, int_0)
