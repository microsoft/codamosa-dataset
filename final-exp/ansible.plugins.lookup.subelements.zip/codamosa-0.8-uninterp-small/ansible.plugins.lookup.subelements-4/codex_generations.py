

# Generated at 2022-06-25 11:17:11.210496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(None, {'var':{'a':1}})
    runtime_args_1 = (('var',), None,  {})
    result_1 = lookup_module_1.run(*runtime_args_1)
    runtime_args_2 = (('var.a',), None,  {})
    result_2 = lookup_module_1.run(*runtime_args_2)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:17:17.599489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run([[], "b"], None) == [[], "b"]
    assert lookup_module_0.run([["a", "b"], "b"], None) == [["a", "b"], "b"]

# Generated at 2022-06-25 11:17:21.971784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{'id': 'nested.id'}, 'id', {'skip_missing': False}]
    variables_0 = {}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == ['id']

# Generated at 2022-06-25 11:17:31.063617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms  = [
      {
        "test_dict": {
          "test_subkey": [
            "test_subvalue"
          ]
        }
      },
      "test_subkey"
    ]
    variables = {}
    kwargs = {}
    t0= ( {
      "test_dict": {
        "test_subkey": [
          "test_subvalue"
        ]
      }
    }, "test_subvalue")
    assert [t0] == lookup_module.run(terms=terms, variables=variables, **kwargs)

# Generated at 2022-06-25 11:17:41.420871
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:53.162155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock module class global variable
    lookup_module_0 = LookupModule()

    # mock class module_utils.parsing.convert_bool.boolean
    def new_boolean(arg, strict):
        if strict is None:
            return True
        if strict:
            return True

    # mock class ansible.module_utils.parsing.convert_bool.boolean
    original_boolean = boolean
    boolean = new_boolean

    # mock class ansible.plugins.lookup.LookupBase._templar
    def new__templar(self):
        return None

    # mock class ansible.plugins.lookup.LookupBase._templar
    original__templar = LookupBase._templar
    LookupBase._templar = new__templar

    # mock

# Generated at 2022-06-25 11:18:03.708563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    class dummy_loader:
        def get_basedir(self, hostname):
            return None

    class dummy_templar:
        def __init__(self, loader):
            self._loader = loader


# Generated at 2022-06-25 11:18:11.097974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variable_dict = {'users': [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]}
    terms = ['users', 'authorized']

# Generated at 2022-06-25 11:18:22.340026
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:33.272155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module.run(terms=[{'a': {'b': [1, 2, 3]}}], variables=None)
    lookup_module.run(terms=[{'a': {'b': [1, 2, 3]}}, 'a.b', {'skip_missing': False}], variables=None)
    lookup_module.run(terms=[{'a': {'b': [1, 2, 3]}}, 'a.b', {'skip_missing': True}], variables=None)
    lookup_module.run(terms=[{'a': {'b': [1, 2, 3]}}, 'a.b.c', {'skip_missing': True}], variables=None)



# Generated at 2022-06-25 11:18:59.711123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'_original_basename': 'setup'})
    lookup_module_0.set_options({'extravars': dict()})
    lookup_module_0.set_args(['ansible_distribution_file_parsed', 'name'])
    lookup_module_0._display.warning.call_count
    # assert that the method getvalue of Mock object 'lookup_module_0._display.warning' has been called
    assert lookup_module_0._display.warning.call_count > 0
    lookup_module_0._templar.template.call_count
    # assert that the method getvalue of Mock object 'lookup_module_0._templar.template' has been called
    assert lookup_module_0._tem

# Generated at 2022-06-25 11:19:08.089568
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:18.454215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0._display = None
    elem0 = [{'item00': 'item0_00', 'item02': 'item0_02', 'item01': 'item0_01'}, {'item10': 'item1_00', 'item12': 'item1_02', 'item11': 'item1_01'}]
    elem1 = 'item02'
    lookup_module_0.run(elem0, elem1)

# Generated at 2022-06-25 11:19:20.772980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()

# Generated at 2022-06-25 11:19:26.904774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0 = LookupModule()
        lookup_module_0.run([], [])
    assert 'list of two or three items' in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(['1'], ['2'])
    assert 'first a dict or a list, second a string pointing to the subkey' in str(excinfo.value)

# Generated at 2022-06-25 11:19:37.262836
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:40.840969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar=None
    lookup_module_0._loader=None

    """
    def run(self, terms, variables, **kwargs):
    """
    lookup_module_0.run([[], None, None], None)

# Generated at 2022-06-25 11:19:46.799905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of LookupModule
    """

    lookup_module = LookupModule()
    sub_element = [{'a':{'b':'c'}}]
    try:
        lookup_module.run(sub_element,"c")
    except Exception as e:
        assert "first a dict or a list, second a string pointing to the subkey" in str(e)

    try:
        lookup_module.run(sub_element,"c","skip_missing")
    except Exception as e:
        assert "the optional third item must be a dict with flags ['skip_missing']" in str(e)

    sub_element = [{'a':{'b':'c'}},{'a':{'b':'c'}}]

# Generated at 2022-06-25 11:19:52.081388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test that it expects a list of two items
    lookup_module_run_0 = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_run_0.run([],{})
    assert 'subelements lookup expects a list of two' in str(excinfo.value)


# Generated at 2022-06-25 11:20:01.875855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = {}
    terms = [[{'authorized': ['/tmp/alice/onekey.pub'], 'name': 'alice'}, {'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob'}], 'authorized', {'skip_missing': False}]
    expected_result = [[({'authorized': ['/tmp/alice/onekey.pub'], 'name': 'alice'}, '/tmp/alice/onekey.pub'), ({'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob'}, '/tmp/bob/id_rsa.pub')]]
    result = lookup_module_0.run(terms, vars)
    assert result == expected_result

# Generated at 2022-06-25 11:20:38.241238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:20:43.184542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    expected = []
    users = []
    args = [users,'mysql.hosts']
    returned = lookup_module_0.run(args, variables=None, **None)
    assert returned == expected

# Note: there are additional tests in test/unit/test_lookup_plugins.py

# Generated at 2022-06-25 11:20:52.829489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
      {
        'term0': {
          'term0': {
            'term0': [
              'term0',
              'term0',
              'term0',
              'term0'
            ]
          }
        }
      },
      'term1.term1.term1'
    ]
    variables_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0)
    except Exception as e:
        print('Exception: %s [test_LookupModule_run]' % e.__str__())

# Generated at 2022-06-25 11:20:58.803994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    elementlist = [{'name': 'Alice', 'authorized': ['/home/alice/.ssh/id_rsa.pub', '/tmp/alice/id_rsa2.pub']}, {'name': 'Bob', 'authorized': ['/home/bob/.ssh/id_rsa.pub']}]
    subelements = [elementlist, 'authorized']
    lookup_module_1 = LookupModule()
    actual_value = lookup_module_1.run(subelements)

# Generated at 2022-06-25 11:21:09.676969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 0
    # 1. Test default behavior without any arguments
    # 2. Does not raise any exception
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0.run(terms=[])

    # Test case 1
    # 1. Expected behavior with two arguments
    # 2. Does not raise any exception
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = None
    lookup_module_1._loader = None
    terms = [{
        'name': 'Alice',
        'hosts': []
    }, 'hosts']
    lookup_module_1.run(terms=terms)

    # Test case 2
    # 1. Expected behavior with three arguments
   

# Generated at 2022-06-25 11:21:22.074314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        {
            'records': [
                {
                    'one': '1',
                    'two': '2',
                    'three': '3'
                },
                {
                    'one': '1',
                    'two': '2',
                    'three': '3'
                }
            ]
        },
        'one'
    ]
    variables_0 = dict()
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert isinstance(ret_0, list)
    assert len(ret_0) == 2
    assert isinstance(ret_0[0], tuple)
    assert isinstance(ret_0[1], tuple)

# Test lookup plugin subelements expected result

# Generated at 2022-06-25 11:21:23.975807
# Unit test for method run of class LookupModule
def test_LookupModule_run():

     # Initialization and instantiation of object
    lookup_module_0 = LookupModule()

    # Running lookup module
    lookup_module_0.run()

# Generated at 2022-06-25 11:21:30.833673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = [{'hosts': 'mysql-hosts', }]
    var_2 = 'hosts'
    test_case_0_1 = lookup_module_1.run(var_1, var_2)
    print(test_case_0_1) 




# Generated at 2022-06-25 11:21:38.405677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([], variables) == []
    assert lookup_module_1.run(terms, variables) == ret
    assert lookup_module_1.run(terms_missing, variables) == []
    assert lookup_module_1.run(terms_missing_error, variables) == []
    assert lookup_module_1.run(terms_notlist, variables) == False
    assert lookup_module_1.run(terms_missing_list, variables) == False
    assert lookup_module_1.run(terms_notstring, variables) == False


# Generated at 2022-06-25 11:21:47.135845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    users = [{"name": "alice", "mysql": {"password": "mysql-password", "hosts": ["%", "127.0.0.1", "::1", "localhost"], "privs": ["*.*:SELECT", "DB1.*:ALL"]}, "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"], "groups": ["wheel"]},
             {"name": "bob", "mysql": {"password": "other-mysql-password", "hosts": ["db1"], "privs": ["*.*:SELECT", "DB2.*:ALL"]}, "authorized": ["/tmp/bob/id_rsa.pub"]}]
    terms_0 = [users, "authorized"]

# Generated at 2022-06-25 11:22:56.639747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}

# Generated at 2022-06-25 11:23:07.785669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = (
        [{'key': 'value'}],
        'key',
    )
    variables = {}
    ret = []
    for item0 in terms[0]:
        if not isinstance(item0, dict):
            raise AnsibleError("subelements lookup expects a dictionary, got '%s'" % item0)
        if item0.get('skipped', False) is not False:
            # this particular item is to be skipped
            continue
        skip_missing = False
        subvalue = item0
        lastsubkey = False
        sublist = []
        for subkey in subelements:
            if subkey == subelements[-1]:
                lastsubkey = True
            if subkey not in subvalue:
                if skip_missing:
                    continue

# Generated at 2022-06-25 11:23:17.574972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [
        [
            {
                'g2': {
                    'g1_h': [
                        'g1_h_i'
                    ]
                }
            },
            {
                'g3': {
                    'g3_h': [
                        'g3_h_i1',
                        'g3_h_i2'
                    ]
                }
            }
        ],
        'g1'
    ]
    variables_1 = {}
    ret_1 = lookup_module_0.run(terms_1, variables_1)

# Generated at 2022-06-25 11:23:28.362650
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Check if method run raises a AnsibleError if a list of less than 2 and more than 3 items is provided.
    with pytest.raises(AnsibleError):
        lookup_module.run([1], '')
    
    with pytest.raises(AnsibleError):
        lookup_module.run([1, 2, 3, 4], '')
    
    # Check if method run raises a AnsibleError if one of the items is not of type string.
    with pytest.raises(AnsibleError):
        lookup_module.run([1, 'test'], '')
    
    with pytest.raises(AnsibleError):
        lookup_module.run(['test', 1], '')
    
    # Check if method run raises a AnsibleError if the first

# Generated at 2022-06-25 11:23:36.683326
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:23:40.776137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    yaml_0 = """
    options:
      _terms:
         description: tuple of list of dictionaries and dictionary key to extract
         required: True
      skip_missing:
        default: False
        description:
          - Lookup accepts this flag from a dictionary as optional. See Example section for more information.
          - If set to C(True), the lookup plugin will skip the lists items that do not contain the given subkey.
          - If set to C(False), the plugin will yield an error and complain about the missing subkey.
    """

# Generated at 2022-06-25 11:23:47.624738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()

    # empty
    from ansible.errors import AnsibleError
    try:
        lookup_module_run.run(terms=[], variables=None)
        assert False, "AnsibleError was not raised"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message

    # one element
    try:
        lookup_module_run.run(terms=[{"moo": "cow"}], variables=None)
        assert False, "AnsibleError was not raised"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in e.message

    # second term not a string

# Generated at 2022-06-25 11:23:57.699267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:24:00.485038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = [[{'one': 'a', 'two': {'three': 'c'}}], 'two.three']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(params, None) == ['c']


# Generated at 2022-06-25 11:24:05.819976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # SUCCESS TEST
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run([['ansible'], 'lookup'], {}, None)
    except:
        raise
    else:
        assert True
    finally:
        lookup_module_1 = None

    # FAILURE TESTS
    try:
        lookup_module_2 = LookupModule()
        lookup_module_2.run('ansible', {}, None)
    except:
        assert True
    else:
        raise
    finally:
        lookup_module_2 = None

    try:
        lookup_module_3 = LookupModule()
        lookup_module_3.run([['ansible'], 'lookup'], None, None)
    except:
        assert True
    else:
        raise