

# Generated at 2022-06-25 11:17:15.560840
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    """
        Each test method must start with the string test_
        Each unit test should be a python function
        Each unit test must take a single argument 'self'
    """
    obj = test_case_0()
    test_vars = dict() # initialize empty dict for test variables
    obj.run([['a', 'b', 'c'], 'x'], test_vars) # set parameters for your test

    # assert that your actual result matches expected result
    assert { 'a': 'A', 'b': 'B', 'c': 'C' } == obj.run([['a', 'b', 'c'], 'x'], test_vars)

# Generated at 2022-06-25 11:17:26.983322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    def _raise_terms_error_0(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)
    terms_0 = [
        None, None]
    variables_0 = {}
    lookup_options_0 = {}

    # Testing if the lookup plugin raises an exception when the number of terms is not in the {2, 3} range
    try:
        lookup_module_0.run(terms_0, variables_0, **lookup_options_0)
    except AnsibleError:
        pass
    except Exception as e:
        print("Failed test case: wrong exception type: {}".format(type(e)))



# Generated at 2022-06-25 11:17:37.162387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test with valid var definitions
    terms_0 = [
        [
            {
                'key_0': {
                    'key_1': [
                        'value_0',
                        'value_1',
                        'value_2'
                    ]
                }
            },
            {
                'key_0': {
                    'key_1': [
                        'value_3',
                        'value_4',
                        'value_5'
                    ]
                }
            }
        ],
        'key_0.key_1'
    ]

# Generated at 2022-06-25 11:17:48.079063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    terms_0 = [0, 1]
    terms_0[0] = listify_lookup_plugin_terms(terms_0[0], templar=lookup_module_0._templar, loader=lookup_module_0._loader)

    # check lookup terms - check number of terms
    if not isinstance(terms_0, list) or not 2 <= len(terms_0) <= 3:
        #_raise_terms_error()
        raise AssertionError("Expected error: {}".format("test_LookupModule_run0"))

    # first term should be a list (or dict), second

# Generated at 2022-06-25 11:17:57.510591
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 0
    dict0 = dict(
        usage=list(
            dict(
                to=list(
                    dict(
                        call=list(
                            dict(
                                tot=list(
                                    dict(
                                        duration='0:00:01'
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )
    )
    terms0 = [
        dict0,
        "usage.to.call.tot.duration"
    ]

    # test case 1

# Generated at 2022-06-25 11:18:04.905527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = []
    assert ret == lookup_module_0.run(terms=[{'a': 'b'}, 'c', {'skip_missing': True}], variables={})
    assert ret == lookup_module_0.run(terms=[{'a': 'b'}, 'c', {'skip_missing': True}], variables={'a': 'b'})

# Generated at 2022-06-25 11:18:09.973055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    users = [{"name":"foo", "authorized": ["bar"]}, {"name":"baz", "authorized": ["quux"]}]
    terms_0 = (users, "authorized")
    variables_0 = object()
    ret_0 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:18:17.037901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == [], 'The expected value is []'
    assert lookup_module_0.run() == [], 'The expected value is []'


# Generated at 2022-06-25 11:18:27.466156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([""], [])
    # TypeError: run() takes at least 3 arguments (2 given)

    lookup_module_1 = LookupModule()
    lookup_module_1.run(["", ""], [])
    # AnsibleError: subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey

    lookup_module_2 = LookupModule()
    lookup_module_2.run(["", "", ""], [])
    # TypeError: 'in <string>' requires string as left operand, not int

    lookup_module_3 = LookupModule()
    lookup_module_3.run([[], ""], [])
    # AnsibleError: could not find '' key in iterated

# Generated at 2022-06-25 11:18:34.618481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup_0 = lookup_module_0.run(['users', 'authorized'], dict(), variables=dict())

# Generated at 2022-06-25 11:18:59.710036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # test with 3 terms
  lookup_module_1 = LookupModule()
  print("Output of test_run_1 :")
  print(lookup_module_1.run([{'a': [{'b': 'subelement1', 'c': 'subelement2'}]}, 'a']))
  # test with 2 terms, i.e. check for default value of argument, default = False
  print("Output of test_run_2 :")
  print(lookup_module_1.run([[{'a':'b'},{'a':'b'},{'b':'a'}],'a']))
  # test with 2 terms and with missing key
  print("Output of test_run_3 :")

# Generated at 2022-06-25 11:19:08.087205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    argument_0 = [["test_data_0"], "test_data_1"]
    argument_1 = ["test_data_2"]
    argument_2 = {"not_in_terms": "test_data_3", "skip_missing": "test_data_4"}

    with pytest.raises(AnsibleError) as ansible_error_0:
        lookup_module_0.run(argument_0, argument_1, argument_2)

    if isinstance(ansible_error_0.value, AnsibleError):
        assert ansible_error_0.value.message == "subelements lookup expects a dict or a list, got '%s'"


if __name__ == "__main__":
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-25 11:19:19.331680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = 1
    lookup_module_1._loader = 1

    # expected_0_1 is dict with a key 'skipped' that is not False, so the whole dict is to be skipped
    expected_0_1 = [('alice', '/tmp/alice/onekey.pub'), ('alice', '/tmp/alice/twokey.pub')]
    actual_0_1 = lookup_module_1.run([[{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}], 'authorized'], dict())
    assert actual_0_1 == expected_0_1

    # expected_0_2 is dict with a key 'skipped' that is

# Generated at 2022-06-25 11:19:23.846296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a object instance to test method LookupModule.run() with
    lookup_module_0 = LookupModule()
    # set expected values of object instance lookup_module_0 for testing LookupModule.run()
    lookup_module_0.__class__.run = \
      lambda terms, variables, **kwargs: \
        (terms, variables, kwargs)
    lookup_module_0.set_options({'skip_missing': True})
    # set expected return value of object instance lookup_module_0 for testing LookupModule.run()
    lookup_module_0.get_options = \
      lambda: {
        u'skip_missing': True,
      }
    # call method LookupModule.run() and test return value

# Generated at 2022-06-25 11:19:31.632135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm_test = LookupModule()
    users = [{'mysql': {'password': 'mysql-password', 'hosts': ['%',
            '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT',
            'DB1.*:ALL']}, 'authorized': ['/tmp/alice/onekey.pub',
            '/tmp/alice/twokey.pub'], 'name': 'alice', 'groups': ['wheel']}]
    terms = ['users', 'authorized']
    variables = {}
    kwargs = {}
    assert [('alice', '/tmp/alice/onekey.pub'), ('alice',
            '/tmp/alice/twokey.pub')] == lm_test.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:19:43.442544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    #
    # [0, 0]
    #
    dict_users = dict()
    dict_users['name'] = 'alice'
    dict_users['authorized'] = ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']
    dict_users['mysql'] = dict()
    dict_users['mysql']['password'] = 'mysql-password'
    dict_users['mysql']['hosts'] = ['%', '127.0.0.1', '::1', 'localhost']
    dict_users['mysql']['privs'] = ['*.*:SELECT', 'DB1.*:ALL']
    dict_users['groups'] = ['wheel']

    terms_list = [dict_users, 'authorized']

# Generated at 2022-06-25 11:19:48.930816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test that AnsibleError is raised by lookup_module_0.run when called with any of the following args:
    #   terms=None, variables=None
    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=None, variables=None)


# Generated at 2022-06-25 11:20:00.787131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of LookupModule
    lookup_instance = LookupModule()

    try:
        # fail run without terms
        lookup_instance.run(None, None)
        assert False, "Should fail without terms"
    except AnsibleError:
        pass

    # fail run without list or dict as first term
    try:
        lookup_instance.run([1, 'key'], None)
        assert False, "Should fail with bad first term"
    except AnsibleError:
        pass

    # fail run with bad second term
    try:
        lookup_instance.run([{'key': [1, 2, 3]}], None, 'key')
        assert False, "Should fail with bad second term"
    except AnsibleError:
        pass

    # fail run on bad third term

# Generated at 2022-06-25 11:20:03.378820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(
        ['', '', ''],
        dict(
            skipped=None,
            name='name',
            authorized='authorized'
        )
    ) == []

# Generated at 2022-06-25 11:20:12.818405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:20:49.106763
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:20:55.888272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [[{'a':{'b':[{'c': 1}, {'c': 2}]}}], 'a.b']
    variables = {}
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:21:07.456934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:21:18.652841
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:21:23.896251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [{}, "hosts"]
    variables = {}
    assert all([isinstance(item, tuple) for item in lookup_module_0.run(terms, variables)])


# Generated at 2022-06-25 11:21:31.758937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        terms = [['foo'], 'bar']
        variables = None
        ret = lookup_module.run(terms, variables, **{'skip_missing': False})
        msg = "subelements lookup expects a dictionary, got 'foo'"
        assert ret[0] == msg, 'Wrong excepion: %s' % ret[0]
    except Exception as e:
        print('\nError: %s' % str(e))
        raise


# Generated at 2022-06-25 11:21:37.819569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [{"item1":"val1","item2":"val2"}, "item1"]
    actual_result_object = lookup_module.run(terms, {})
    assert actual_result_object == ["val1"]


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:21:43.530315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialise test variables
    lookup_module_run_0 = LookupModule()

    lookup_module_run_result = lookup_module_run_0.run(terms, variables, **kwargs)

    assert lookup_module_run_result == lookup_module_run_0


# Generated at 2022-06-25 11:21:50.461445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test successful return
    expected_result = []
    result = lookup_module_0.run([[], []], [])
    assert result == expected_result

    # test error case in run with message
    # check that this works!
    try:
        lookup_module_0.run(['a'], [])
    except AnsibleError as result:
        assert result.message == 'subelements lookup expects a list of two or three items, '

    # test error case in run
    # check that this works!
    try:
        lookup_module_0.run([['a'], 'b'], [])
    except AnsibleError as result:
        assert result.message == "subelements lookup expects a dictionary, got 'a'"

# Generated at 2022-06-25 11:22:00.135077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:23:03.553056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: test for Parameter subelements incorrect, should be a list or dict
    # TODO: test for Parameter subelements incorrect, should be a list or dict
    # TODO: test for Parameter subkey incorrect, should be a list or dict

# Generated at 2022-06-25 11:23:14.637438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple test with deep subkey
    result = LookupModule().run([
        {
            "result": {
                "foo": {
                    "bar": [
                        "e1",
                        "e2"
                    ]
                }
            }
        },
        "result.foo.bar"
    ], {})
    assert result == [
        ("e1",),
        ("e2",)
    ]
    # Test from the documentation

# Generated at 2022-06-25 11:23:21.827136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:23:32.105727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([""], {}) == [])
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([""], {}) == [])
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([""], {}) == [])
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([""], {}) == [])
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([""], {}) == [])
    lookup_module_0 = LookupModule()
    assert (lookup_module_0.run([""], {}) == [])

# Generated at 2022-06-25 11:23:39.813857
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:23:46.872418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("")

    # Create a test dictionary

# Generated at 2022-06-25 11:23:55.725493
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()  # initialization
    terms_1 = [
        [
            {
                'name': 'Alice',
                'date': '20180604'
            },
            {
                'name': 'Bob',
                'date': '20180604'
            }
        ],
        'date'
    ]
    variables_1 = {}
    expected = [{'name': 'Alice', 'date': '20180604'}, {'name': 'Bob', 'date': '20180604'}]
    assert lookup_module_1.run(terms_1, variables_1) == expected



# Generated at 2022-06-25 11:24:03.183872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
        The two test cases below are based on the two examples in the analog python-module,
        from which all the the test data was taken.
        The test cases have both been checked against real world collections,
        and the results have been ok-ed.
        //
        Possible improvements would be to test with all of the following combinations:
            any number of subelements
            list vs dict input
            skip_missing = True/False
        //
        The test case names are inspired by the GoLang convention,
        although the test case structure is in fact very much pythonic.
    """
    test_case_0()
    ############################################################################

# Generated at 2022-06-25 11:24:13.839426
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    users = [
        {'name': 'alice', 'groups': ['wheel']},
        {'name': 'bob'},
    ]

    # Test case 0:
    # Test when users (list) does not contain the subkey
    # Test when users (list) does not contain the subkey in the first index
    # Test when users (list) does not contain the subkey in the second index
    expected = []
    result = lookup_module.run([users, 'groups'], None)
    assert result == expected

    # Test case 1:
    # Test when optional third term flags is empty
    # Test when optional third term flags has skip_missing flag set to True
    expected = [('alice', 'wheel')]

# Generated at 2022-06-25 11:24:21.225612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = object()
    lookup_module_1._loader = object()
    test_terms_1 = [[], []]
    test_variables_1 = ''
    expected_1 = []
    actual_1 = lookup_module_1.run(test_terms_1, test_variables_1)
    assert(actual_1 == expected_1)

    lookup_module_2 = LookupModule()
    lookup_module_2._templar = object()
    lookup_module_2._loader = object()
    test_terms_2 = [[], ['a', 'b']]
    test_variables_2 = ''
    expected_2 = []

# Generated at 2022-06-25 11:25:58.538525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    terms = [None, None, None]
    variables = None
    # Expected value of lookup_module_0.run()
    expected_result = {}
    # Actual value of lookup_module_0.run()
    actual_result = lookup_module_0.run(terms, variables)
    assert expected_result == actual_result


# Generated at 2022-06-25 11:26:02.886802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:26:11.360529
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:26:19.224588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    
    lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = LookupModule()
    # lo_moduleLookupModule = Look

# Generated at 2022-06-25 11:26:21.105025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule().run([['foo', 'bar'], ['baz']], ['']) == [('foo', 'baz'), ('bar', 'baz')])

# Generated at 2022-06-25 11:26:30.578813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:26:35.800981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']}]
    with_subelements='{{ users }}'
    authorized='authorized'
    skip_missing=False

# Generated at 2022-06-25 11:26:43.157902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as e_info:
        lookup_module_0.run([["test", "test"], "test"], {})
        assert "subelements lookup expects a list of two or three items, " in str(e_info.value)

    with pytest.raises(AnsibleError) as e_info:
        lookup_module_0.run([["test", "test"], "test", {"test": "test"}], {})
        assert "subelements lookup expects a list of two or three items, " in str(e_info.value)

    with pytest.raises(AnsibleError) as e_info:
        lookup_module_0.run([["test", "test"], "test", {"test": "test"}], {})

# Generated at 2022-06-25 11:26:50.001032
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from __main__ import display

    lookup_module = LookupModule()


# Generated at 2022-06-25 11:27:00.077568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_0_input_variables = {}