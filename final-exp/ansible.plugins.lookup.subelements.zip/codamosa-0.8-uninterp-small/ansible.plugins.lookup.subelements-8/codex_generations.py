

# Generated at 2022-06-25 11:17:09.560053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']
    variables = 'baz'
    test_LookupModule_run_result_0 = LookupModule().run(terms, variables)
    assert test_LookupModule_run_result_0 == []


# === Tests of the lookup plugin ===
if __name__ == '__main__':
    # test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:17:17.070714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(['foo', 'bar'], 'baz')
    assert result == []
    result = lookup_module_1.run([{'foo': {'bar': 'baz'}}, 'foo.bar'], 'baz')
    assert result == [('baz',)]
    result = lookup_module_1.run([{'foo': {'bar': 'baz'}}, 'foo.bar', {'skip_missing': False}], 'baz')
    assert result == [('baz',)]
    result = lookup_module_1.run([{'foo': {'bar': 'baz'}}, 'foo.xxx', {'skip_missing': True}], 'baz')
    assert result == []
    result = lookup_module

# Generated at 2022-06-25 11:17:23.390366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_vars = {
                'test_hosts': [
                    {'item1': 'test_value1', 'item2': 'test_value2'}
                    ],
                '_terms': ['test_hosts', 'item1']
              }
    test_run_result = lookup_module.run(['test_hosts', 'item1'], variables=test_vars)
    assert test_run_result == [('test_value1',)]

# Generated at 2022-06-25 11:17:25.850891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:17:30.940578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Arguments: terms, variables
    terms = ('0', '1', '2')
    variables = ('0', '1', '2')
    # Return value: ret
    ret = ''
    ret = lookup_module_0.run(terms, variables)
    assert type(ret) == str



# Generated at 2022-06-25 11:17:41.422824
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:17:53.163802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with the following parameters:
    #     terms = (
    #         'name', 
    #         '/path/to/file'
    #     ), 
    #     variables = {
    #         'attributes': {
    #             'src': 'http://localhost/user_files/.public_keys', 
    #             'update': 'always', 
    #             'group': 'root', 
    #             'mode': '0400', 
    #             'owner': 'root'
    #         }
    #     }

    terms = (
        'name', 
        '/path/to/file'
    )

# Generated at 2022-06-25 11:17:58.359986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test run of LookupModule"""
    lookup_module = LookupModule()
    # Test with no parameters - raises AnsibleError
    try:
        lookup_module.run()
    except AnsibleError as e:
        assert True


# Generated at 2022-06-25 11:18:08.989460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    lookup_module_0 = LookupModule()
    var_terms_0 = [
        {
            '2': 3,
        },
        '1',
    ]
    var__terms_0 = var_terms_0
    var_variables_0 = None
    var_result_0 = lookup_module_0.run(var__terms_0, var_variables_0)
    assert isinstance(var_result_0, list)
    assert var_result_0 == [
        {},
    ]
    var_terms_1 = [
        [
            {
                '2': 3,
            },
            {
                '1': 2,
            },
        ],
        '1',
    ]
    var__terms_1 = var_terms

# Generated at 2022-06-25 11:18:13.420173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg0 = ''
    arg1 = ''
    ret0 = lookup_module_0.run(arg0, arg1)

# Generated at 2022-06-25 11:18:35.427232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_opt_flags_0()
    test_case_opt_flags_1()
    test_case_opt_flags_2()
    test_case_opt_flags_3()
    test_case_opt_flags_4()
    test_case_opt_flags_5()
    test_case_opt_flags_6()
    test_case_opt_flags_7()
    test_case_opt_flags_8()
    test_case_opt_flags_9()
    test_case_opt_flags_10()
    test_case_opt_flags_11()
    test_case_opt_flags_12()
    test_case_opt_flags_13()
    test_case_opt_

# Generated at 2022-06-25 11:18:48.939855
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:53.083008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = fake_Templar()
    lookup_module_0._loader = fake_Loader()
    terms = ["terms"]
    variables = ["variables"]

    # Test
    assert lookup_module_0.run(terms, variables) == []


# Generated at 2022-06-25 11:19:02.505237
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup test object
    lookup_module_two_arg = LookupModule()

    # setup test data
    test_data_1 = {'users': [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]}


    # test basic lookup with two args
    result_two_arg = lookup_module_two_arg.run([test_data_1, 'users'], dict())
    # expected result

# Generated at 2022-06-25 11:19:06.475554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=None, variables=None)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:19:11.841427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([['1', '3', '5'], '1'], ['']) == [('1', '5')]
    assert lookup_module_0.run([['1', '3', '5'], ['1']], ['']) == [('1', '5')]

# Generated at 2022-06-25 11:19:16.480578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{'skipped': False}]
    variables_0 = {}
    _result = lookup_module_0.run(terms_0, variables_0)
    assert _result == []


# Generated at 2022-06-25 11:19:25.755468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test_normal
    ret = lookup_module.run((
      [
        {
          "apps": [
            "app1",
            "app2"
          ],
          "groups": [
            "group1",
            "group2"
          ],
          "foo": "bar"
        },
        {
          "apps": [
            "app3",
            "app4"
          ],
          "groups": [
            "group3",
            "group4"
          ],
          "baz": "qux"
        }
      ],
      "apps"
    ), {}, None)

# Generated at 2022-06-25 11:19:31.866893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # check positional arguments
    elements = [{'mysql.users': ['u1']}, {'mysql.users': ['u2']}]
    assert lookup_module.run([elements, 'mysql.users'], None) == [('u1',), ('u2',)]

    # check keyword arguments
    elements = [{'mysql.users': ['u1']}, {'mysql.users': ['u2']}]
    assert lookup_module.run([elements, 'mysql.users'], None) == [('u1',), ('u2',)]

    # check multiple subelements
    elements = [{'mysql': {'users': ['u1']}}, {'mysql': {'users': ['u2']}}]

# Generated at 2022-06-25 11:19:32.558716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True

# Generated at 2022-06-25 11:20:09.232013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()

    users = [{"name": "alice",
              "authorized": [
                  "/tmp/alice/onekey.pub",
                  "/tmp/alice/twokey.pub"]}]
    terms = [users, "authorized"]
    # expected_result = [("/tmp/alice/onekey.pub","/tmp/alice/twokey.pub")]
    assert lookup_module_obj.run(terms, {}) == [('/tmp/alice/onekey.pub',), ('/tmp/alice/twokey.pub',)]

# Generated at 2022-06-25 11:20:20.261665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test data
    terms = [[{'bla': [1, 2]}, {'bla': [3, 4]}], 'bla']

    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms)

    assert 2 == len(ret)

    terms = [[{'bla': [1, 2]}, {'bla': [3, 4]}], 'bla', {'skip_missing': True}]

    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms)

    assert 4 == len(ret)

    terms = [[{'bla': [1, 2]}, {'bla': [3, 4]}], 'bla.0']

    lookup_module_0 = LookupModule()
    ret = lookup_module

# Generated at 2022-06-25 11:20:24.379225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [[""], [""]]
    variables_0 = {}
    additional_arguments_0 = {'skip_missing': False}
    result = lookup_module_0.run(terms_0, variables_0, **additional_arguments_0)
    assert len(result) == 0


# Generated at 2022-06-25 11:20:35.017325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # terms is: (list, string)

# Generated at 2022-06-25 11:20:44.041457
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # example of list of dictionaries as input

# Generated at 2022-06-25 11:20:54.288880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = DummyTemplar()
    lookup_module_0._loader = DummyLoader()

# Generated at 2022-06-25 11:21:00.428764
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:21:10.695866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # 
    # 
    # with subelements('',''):
    # 
    # 
    # with subelements([],''):
    # 
    # 
    # with subelements({},''):
    # 
    # 
    # with subelements({'':''},''):
    # 
    # 
    # with subelements({'':''}, ''):
    # 
    # 
    # with subelements(['', ''],''):
    # 
    # 
    # with subelements([''],''):
    # 
    # 
    # with subelements({'':''},''):
    # 
    # 
    # with subelements({'':{'':[]}},''

# Generated at 2022-06-25 11:21:13.828417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:21:18.593566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ok'
    assert lookup_module_0._flatten('ok') == str_0, 'expected:\n%s\n, got:\n%s\n' % (str_0, lookup_module_0._flatten('ok'))


# Generated at 2022-06-25 11:22:35.277384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hosts = [
      {
        "name": "alice",
        "authorized": ["/tmp/alice/onekey.pub","/tmp/alice/twokey.pub"],
        "mysql": {"password":"mysql-password","hosts":["%","127.0.0.1","::1","localhost"],"privs":["*.*:SELECT","DB1.*:ALL"]},
        "groups": ["wheel"]
      },
      {
        "name": "bob",
        "authorized": ["/tmp/bob/id_rsa.pub"],
        "mysql": {"password":"other-mysql-password","hosts":["db1"],"privs":["*.*:SELECT","DB2.*:ALL"]}
      }
    ]
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:22:39.795758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=[['hello', 'ansible'],['exists']], variables={})
    assert result == [True, True]

# Generated at 2022-06-25 11:22:44.100099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(terms, variables)
    assert lookup_module_run == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"


# Generated at 2022-06-25 11:22:54.150546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([[{'skipped': True, 'dict': {'foo': 'bar'}, 'key': 'val'}, {'skipped': False, 'dict': {'foo': 'baz'}, 'key': 'val'}], 'dict', {'skip_missing': True}], variables={'key': 'value'}) == [[{'skipped': False, 'dict': {'foo': 'baz'}, 'key': 'val'}], [{'foo': 'baz'}]]


# Generated at 2022-06-25 11:23:00.460563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check for correct return subelement with list of dict and string key.
    expected_result = [('1', 'path'), ('4', 'path')]
    list_of_dict = [{'1': 'path', '2': 'path'}, {'3': 'path', '4': 'path'}]
    dict_key = '1'
    lookup_module = LookupModule()
    assert lookup_module.run([list_of_dict, dict_key]) == expected_result
    list_of_dict = [{'1': 'path', '2': 'path'}, {'3': 'path', '4': 'path'}]
    dict_key = '1'
    lookup_module = LookupModule()
    assert lookup_module.run(list_of_dict, dict_key) == expected_result
    #

# Generated at 2022-06-25 11:23:01.670801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #TODO:
    # implement this unit test
    pass

# Generated at 2022-06-25 11:23:08.409375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        [
            {
                'skipped': False,
                'data': 'some additional data'
            },
            {
                'a': 'key',
                'b': 'other_key'
            },
            {
                'a': 'key',
                'b': 'other_key',
                'skipped': False
            }
        ],
        'a'
    ]
    result_0 = lookup_module_0.run(terms_0, variables={}, loader=None, templar=None)
    assert result_0 == [('key',), ('key',)]

# Generated at 2022-06-25 11:23:17.635433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_module = LookupModule()

    with pytest.raises(AnsibleError) as error_info:
        lookup_module.run([{}], [])

    with pytest.raises(AnsibleError) as error_info:
        lookup_module.run(["a", "b"], [])

    with pytest.raises(AnsibleError) as error_info:
        lookup_module.run(["a", "b", "c"], [])

    with pytest.raises(AnsibleError) as error_info:
        lookup_module.run(["a", "b", "c", "d"], [])

    with pytest.raises(AnsibleError) as error_info:
        lookup_module.run([[]], [])


# Generated at 2022-06-25 11:23:28.361682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with invalid arguments
    try:
        assert lookup_module_0.run() is None
    except:
        pass
    # Test with invalid arguments
    try:
        assert lookup_module_0.run('', '') is None
    except:
        pass
    # Test with invalid arguments
    try:
        assert lookup_module_0.run([], '') is None
    except:
        pass
    # Test with invalid arguments
    try:
        assert lookup_module_0.run([], '') is None
    except:
        pass
    # Test with invalid arguments
    try:
        assert lookup_module_0.run([], '') is None
    except:
        pass
    # Test with invalid arguments

# Generated at 2022-06-25 11:23:36.683719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check number of terms
    terms = (('a'), ('b'), ('c'))
    lookup_module = LookupModule()
    try:
        lookup_module._templar = None
        lookup_module.run(terms, None)
        raise Exception("Expecting AnsibleError exception")
    except AnsibleError as e:
        assert "subelements lookup expects" in str(e)

    # first term should be a list, second a string holding the subkey
    terms = (1, 'b')
    try:
        lookup_module.run(terms, None)
        raise Exception("Expecting AnsibleError exception")
    except AnsibleError as e:
        assert "subelements lookup expects a list or dictionary" in str(e)


# Generated at 2022-06-25 11:25:00.511352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x8fn\x8c'
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, list_0)


# Generated at 2022-06-25 11:25:04.417344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        list_0,
        str_0,
        list_1,
    ]
    variables = {}

# Generated at 2022-06-25 11:25:05.243479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert '__main__' == LookupModule()


# Generated at 2022-06-25 11:25:13.801871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x8fn\x8c'

# Generated at 2022-06-25 11:25:21.830838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing variable 1
    list_0 = []
    # Testing variable 2
    list_1 = []
    # Testing variable 3
    list_2 = []
    # Testing variable 4
    dict_0 = {}
    # Testing variable 5
    dict_1 = {}
    # Testing variable 6
    dict_2 = {}
    # Testing variable 7
    dict_3 = {}
    # Testing variable 8
    dict_4 = {}
    # Testing variable 9
    dict_5 = {}
    # Testing variable 10
    dict_6 = {}
    # Testing variable 11
    dict_7 = {}
    # Testing variable 12
    dict_8 = {}
    # Testing variable 13
    dict_9 = {}
    # Testing variable 14
    dict_10 = {}
    # Testing variable 15
    dict_11 = {}
    # Testing variable

# Generated at 2022-06-25 11:25:22.321161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:25:26.078023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # case0:
    bytes_0 = b'\x8fn\x8c'
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, list_0)
    assert(var_0 == [('Alice', 'alice@example.com'), ('Bob', 'bob@example.com'), ('Charlie', 'charlie@example.com')])

# Generated at 2022-06-25 11:25:32.653397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test if list_0 is an instance of list
  if not isinstance(list_0, list):
    raise RuntimeError("Argument 'list_0' should be of type list")
  # Test for length of list_0 is not equal to 2
  if len(list_0) != 2:
    raise RuntimeError("Argument 'list_0' should have length 2")
  # Test if list_0[0] is an instance of bytes
  if not isinstance(list_0[0], bytes):
    raise RuntimeError("Argument 'list_0[0]' should be of type bytes")
  # Test if list_0[1] is an instance of dict
  if not isinstance(list_0[1], dict):
    raise RuntimeError("Argument 'list_0[1]' should be of type dict")
  # Test if list

# Generated at 2022-06-25 11:25:42.016890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x8fn\x8c'
    bytes_1 = b'\xba\xc4\x10\xb7\xfe\x92\t\x1b\xb4'
    bytes_2 = b'\xa5\x15\xd3\x83\x0b\x81\x10\xef\xbe\x9c\x0b'
    list_0 = []
    list_1 = []
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}

# Generated at 2022-06-25 11:25:46.270979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Method run of class LookupModule"""

    req_args = [True]
    opt_args = []
    kwargs = dict([])
    module = LookupModule()
    assert module.run(*req_args, **kwargs)
