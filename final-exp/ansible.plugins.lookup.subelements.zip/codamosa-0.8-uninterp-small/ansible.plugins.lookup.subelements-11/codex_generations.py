

# Generated at 2022-06-25 11:17:12.455379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None,None]
    variables_0 = None
    assert lookup_module_0.run(terms_0, variables_0) == None

# Generated at 2022-06-25 11:17:18.773123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = ['{"key": {"subkey": ["a", "b", "c", "d"]}}', 'key.subkey']
    variables_3 = None
    assert lookup_module_1.run(terms_2, variables_3) == [
        ('{"key": {"subkey": ["a", "b", "c", "d"]}}', 'a'),
        ('{"key": {"subkey": ["a", "b", "c", "d"]}}', 'b'),
        ('{"key": {"subkey": ["a", "b", "c", "d"]}}', 'c'),
        ('{"key": {"subkey": ["a", "b", "c", "d"]}}', 'd')]

# Generated at 2022-06-25 11:17:26.997272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check if method run of class LookupModule  produces right output(subelements)
    """
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:17:37.166596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    validation_failures = []
    lookup_module_0 = LookupModule()
    p0 = {"name": "alice"}
    p0 = {"name": "bob"}
    p0 = {"name": "charlie"}
    elementlist_0 = [p0, p0, p0]
    subkey_0 = "users"
    terms_0 = [elementlist_0, subkey_0]
    flags_0 = {}
    skipped_0 = None
    variables_0 = {}
    kwargs_0 = {}
    result_0 = None
    try:
        result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-25 11:17:48.107590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # INVOCATION 1

    # check lookup terms - check number of terms
    terms_0 = ((['dict1', 'dict2'], 'mysql.hosts'))
    terms_0 = list(terms_0)

    # first term should be a list (or dict), second a string holding the subkey
    if not isinstance(terms_0[0], (list, dict)) or not isinstance(terms_0[1], string_types):
        _raise_terms_error("first a dict or a list, second a string pointing to the subkey")
    subelements_0 = terms_0[1].split(".")


# Generated at 2022-06-25 11:17:50.837838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(['a', 'b', 'c'])) == 3

# Generated at 2022-06-25 11:18:01.428606
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_0 = dict()
    dict_0['skipped'] = False
    dict_0['failed'] = False
    dict_0['changed'] = False
    dict_0['ansible_facts'] = None
    dict_0['ansible_facts_modified'] = False
    dict_0['ansible_modules'] = None
    dict_0['ansible_modules_files'] = None
    dict_0['ansible_modules_cached'] = None
    dict_0['ansible_skipped'] = []
    dict_0['ansible_failed'] = False
    dict_0['ansible_no_log'] = False
    dict_0['invocation'] = None
    dict_0['stats'] = None
    dict_0['parsed'] = False
    dict_0['msg'] = None
    dict_

# Generated at 2022-06-25 11:18:09.728056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = ['bla', 'blub']
    lookup_module.run(term, None)

    term = ['bla', 'blub', 'blab']
    lookup_module.run(term, None)

    term = [['bla'], 'blub', 'blab']
    lookup_module.run(term, None)

    term = [['bla'], 'blub']
    lookup_module.run(term, None)

    term = [[{'bla': 'blub'}], 'bla', 'blub2']
    lookup_module.run(term, None)

    term = [[{'bla': ['blub']}], 'bla']
    lookup_module.run(term, None)


# Generated at 2022-06-25 11:18:18.493473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:18:24.856399
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    # Test valid run
    result = lookup.run(['test'], 'test')[0]
    assert result == 'test'

    # Test lookup with one argument
    with pytest.raises(AnsibleError):
        lookup.run(['test'], 'test', 'test')

    # Test lookup with three arguments
    with pytest.raises(AnsibleError):
        lookup.run(['test'], 'test', 'test', 'test')

# Generated at 2022-06-25 11:18:42.656281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    templar = lookup_module._templar
    loader = lookup_module._loader
    lookup_module._templar = templar
    lookup_module._loader = loader
    variables = {}
    terms = ['users', 'mysql.hosts']
    kwargs = {}
    expected_result = [('name', 'alice'), ('name', 'bob')]
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == expected_result


# Generated at 2022-06-25 11:18:53.683042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_5 = LookupModule()
    var_10 = []
    var_11 = []
    test_var_0 = lookup_module_5.run(var_10, var_11)
    assert(type(test_var_0) == list)
    var_12 = [[["sherry", "lemonade"], "fanta"], "fanta"]
    var_13 = []
    test_var_1 = lookup_module_5.run(var_12,var_13)
    assert(test_var_1[0][0][1] == "lemonade")
    assert(test_var_1[0][1] == "fanta")

# Generated at 2022-06-25 11:19:02.974460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    users = [
      {'groups': ['wheel'], 'mysql': {'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'name': 'alice'},
      {'groups': [], 'mysql': {'hosts': ['db1'], 'password': 'other-mysql-password', 'privs': ['*.*:SELECT', 'DB2.*:ALL']}, 'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob'}]

    # case-0: test exception when only one term is provided

# Generated at 2022-06-25 11:19:12.639273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  import imp
  import os
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  from ansible.inventory import Inventory
  from ansible.playbook.play import Play

  class Options(object):
    def __init__(self):
      self.connection = 'local'
      self.remote_user = 'ansible'
      self.private_key_file = 'id_rsa'
      self.verbosity = 0
      self.extra_vars = ['variable_file']
      self.ask_pass = False
      self.module_path = os.getcwd()

  class Passwords(dict):
    def __init__(self):
      self.passwords = dict()

  loader_0 = DataLoader()
  variable_manager_0 = VariableManager

# Generated at 2022-06-25 11:19:20.726226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test case 0
    result = lookup_module.run([], {})
    assert result == []

    # test case 1
    result = lookup_module.run(
        [
            [
                {
                    'name': 'alice',
                    'authorized': [
                        '/tmp/alice/id_rsa.pub',
                    ]
                },
                {
                    'name': 'bob',
                    'authorized': [
                        '/tmp/bob/id_rsa.pub',
                    ]
                },
            ],
            'authorized',
        ],
        {}
    )

# Generated at 2022-06-25 11:19:29.889228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    result = lookup_module_0.run([['', '', ''], '', {}], dict(), templar=None, loader=None, variables=None)
    assert result is not None
    assert type(result) is list
    assert len(result) == 0


# Generated at 2022-06-25 11:19:37.461541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a set of test cases
    test_cases = [
        {
            "description": "Testing valid input",
            "input": [
                [
                    {
                        "test_key": "test_value"
                    },
                    {
                        "test_key": "test_value"
                    }
                ],
                "test_key"
            ],
            "expected_output": [
                [
                    {
                        "test_key": "test_value"
                    },
                    "test_value"
                ],
                [
                    {
                        "test_key": "test_value"
                    },
                    "test_value"
                ]
            ]
        }
    ]

    # Initialize expected_output from the test_cases
    expected_output = [case['expected_output'] for case in test_cases]



# Generated at 2022-06-25 11:19:44.940900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # test case 1
    terms_1_arg = [[[{'skipped': False, 'key1': 'val1'}, {'skipped': False, 'key2': 'val2'}], 'key1']]
    variables_1_arg = 'fake-variables'
    ret_1 = lookup_module_1.run(terms_1_arg, variables_1_arg)
    assert type(ret_1) == list
    assert ret_1 == ['val1']
    # test case 2
    terms_2_arg = [[[{'skipped': False, 'key1': 'val1'}, {'skipped': True}], 'key1']]
    variables_2_arg = 'fake-variables'
    ret_2 = lookup_module_1.run

# Generated at 2022-06-25 11:19:47.631492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run("", "")


# Generated at 2022-06-25 11:19:59.424152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test subelements lookup plugin with an example, again'''
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:20:20.652842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test cases for method run of class LookupModule
    # (source: https://github.com/ansible/ansible/blob/v2.4.2.0-1/test/units/plugins/lookup/test_subelements.py)

    # Test case data.

# Generated at 2022-06-25 11:20:28.257998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  users_var = {
    'alice': {
      'name': 'Alice',
      'authorized': [
        '/tmp/alice/onekey.pub',
        '/tmp/alice/twokey.pub'
      ],
      'mysql': {
        'password': 'mysql-password',
        'hosts': [
          '127.0.0.1',
          '::1',
          'localhost',
          '%'
        ],
        'privs': [
          '*.*:SELECT',
          'DB1.*:ALL'
        ]
      },
      'groups': [
        'wheel'
      ]
    }
  }

  terms = [
    users_var,
    'mysql.privs'
  ]

  terms_

# Generated at 2022-06-25 11:20:36.458664
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:20:40.560947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_dict = {}
    subkey = "subkey"
    my_dict[subkey] = "subkey_value"
    terms = [my_dict,subkey]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)
    assert(result[0] == "subkey_value")


# Generated at 2022-06-25 11:20:44.471548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{'stderr_lines': [], 'results': [['1','2','3']]},'results']
    variables = {'_ansible_verbosity': '0'}
    kwargs = {}
    ret_value = lookup_module.run(terms, variables, **kwargs)
    print(ret_value)

#test_LookupModule_run()

# Generated at 2022-06-25 11:20:54.934187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(["", ""], [])
    assert result_1 == []
    lookup_module_2 = LookupModule()
    result_2 = lookup_module_2.run([{}], [])
    assert result_2 == []
    lookup_module_3 = LookupModule()
    result_3 = lookup_module_3.run(["", "", ""], [])
    assert result_3 == []
    lookup_module_4 = LookupModule()
    result_4 = lookup_module_4.run(["", "", {}], [])
    assert result_4 == []
    lookup_module_5 = LookupModule()
    result_5 = lookup_module_5.run(["", "", {}], [])

# Generated at 2022-06-25 11:20:56.341037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run()


# Generated at 2022-06-25 11:21:07.265711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test_LookupModule_run: test of method run of class LookupModule
    """
    lookup_module = LookupModule()

    # check lookup terms - check number of terms
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    terms = [
        "users",
        "mysql.hosts",
        {
            "skip_missing": False
        }]
    variables = {}
    kwargs = {}

    result = lookup_module.run(terms, variables, **kwargs)

    if isinstance(result, list):
        return
    else:
        raise Exception("%s is not an instance of list" % result)

# Generated at 2022-06-25 11:21:13.754299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:21:15.205509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()


# Generated at 2022-06-25 11:21:48.009456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    assert lookup_module_obj.run() == None



# Generated at 2022-06-25 11:21:53.991068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'skip_missing': True})

# Generated at 2022-06-25 11:22:04.034275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test case where 0 == len(self._lookup_plugin.get_options(terms))
    t0 = [
        [
            {
                'kind': 'Deployment',
                'metadata': {
                    'name': 'foo',
                    'labels': {
                        'app': 'foo'
                    }
                }
            },
            {
                'kind': 'Service',
                'metadata': {
                    'name': 'foo',
                    'labels': {
                        'app': 'foo'
                    }
                }
            }
        ],
        'metadata.labels.app'
    ]
    v0 = {}
    result = lookup_module.run(t0, v0)
    assert result == [
        ('foo',),
        ('foo',)
    ]

# Generated at 2022-06-25 11:22:05.216863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:22:11.832781
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Variables
    elementlist = [(dict(key='value')), (dict(key='value'))]
    terms = [elementlist, 'key']
    parameters = dict(variables=dict(), **terms[2])

    lookup_module_0 = LookupModule()

    # Run test case
    result = lookup_module_0.run(terms, parameters)
    assert result == []

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:22:22.743130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Testcase0:
    # testcase with invalid number of terms
    terms = []
    variables = {}
    try:
        lookup_module.run(terms,variables)
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items," in str(e)
    # Testcase1:
    # testcase with first term as a non-list/dict, second term as a non-string
    terms = [1,1]
    variables = {}
    try:
        lookup_module.run(terms,variables)
    except AnsibleError as e:
        assert "first a dict or a list, second a string pointing to the subkey" in str(e)
    # Testcase2:
    # testcase with different types of third term
   

# Generated at 2022-06-25 11:22:34.111613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = MockTemplar()
    lookup_module_1._loader = MockLoader({'some_var': ['USER1', 'USER2', 'USER3']})
    lookup_module_1._templar._available_variables = {'some_var': ['USER1', 'USER2', 'USER3']}
    terms = []
    terms.append('some_var')
    terms.append('USER1')
    lookup_module_1._templar.available_variables = {'some_var': ['USER1', 'USER2', 'USER3']}
    lookup_module_1._templar.template('some_var')
    lookup_module_1.run(terms, {})


# Generated at 2022-06-25 11:22:38.527620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:22:46.873570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test a really simple case
    terms = ['_terms', 'key', {'skip_missing': 'True'}]
    lookup_module_0.run(terms, '_variables')
    # Test a second case
    terms = ['_terms', 'key', {'skip_missing': 'False'}]
    lookup_module_0.run(terms, '_variables')
    # Test a third case
    terms = ['_terms', 'key']
    lookup_module_0.run(terms, '_variables')
    # Test a fourth case
    terms = ['_terms', 'key', {'skip_missing': 'invalid'}]
    lookup_module_0.run(terms, '_variables')


# Generated at 2022-06-25 11:22:50.262095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['a', 'b', 'c'], 'd') == []

# Generated at 2022-06-25 11:23:28.597650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")

    assert True, "test succeeded"

    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0, dict_0)

# Generated at 2022-06-25 11:23:36.926644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    subelements = []
    subelements.append(u"users")
    subelements.append(u"authorized")
    subelements.append(u"grant")
    subelements.append(u'key')
    terms = [subelements]

# Generated at 2022-06-25 11:23:42.757780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0, dict_0)

# Generated at 2022-06-25 11:23:51.190484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test of function run of class LookupModule
    """
    lookup_module_1 = LookupModule()
    var_0 = {'var_0': 'var_0'}
    # the third value is a dictionary with flags
    # if set, the lookup will skip missing subkeys
    var_1 = lookup_run(['var_0', 'var_0', 'var_1'], var_0)
    assert('[' + 'var_0' + ',' + 'var_0' + ',' + 'var_1' + ']' == repr(var_1))
    var_2 = lookup_run(['var_0', 'var_0'], var_0)

# Generated at 2022-06-25 11:23:57.683589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(bool_0, dict_0)
    print(ret)

# Generated at 2022-06-25 11:24:00.220594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0, dict_0)


# Generated at 2022-06-25 11:24:02.543901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_case_0()
    return

test_LookupModule_run()

# Generated at 2022-06-25 11:24:05.557767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = tuple()
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(_terms, {}, {}, **{})
    assert(isinstance(result, list))
    assert (result == [])

# Generated at 2022-06-25 11:24:06.614010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()

# Generated at 2022-06-25 11:24:11.931793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _dict_0 = {'skipped': False}
    _dict_2 = {'skipped': False}
    _dict_1 = {'skipped': False}
    _dict_3 = {'skipped': False}
    _dict_5 = {'skipped': False}
    _dict_4 = {'skipped': False}
    _dict_6 = {'skipped': False}
    _dict_8 = {'skipped': True}
    _dict_7 = {'skipped': True}
    _int_0 = 1
    _list_0 = [_dict_0, _dict_1, _dict_2, _dict_3, _dict_4, _dict_5, _dict_6, _dict_7, _dict_8]
    _str_0 = 'key'
    _

# Generated at 2022-06-25 11:25:50.974587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:25:53.177492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()
    var_0 = LookupModule.run(lookup_module_0, bool_0, dict_0)


# Generated at 2022-06-25 11:26:01.034467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    list_0 = [bool_0]
    str_0 = "string"
    str_1 = "string"
    list_1 = [str_0, str_1]
    str_2 = "string"
    lookup_module_0 = LookupModule()
    print("-"*8)
    print("Unit test for method run of class LookupModule.")
    print("Somehow check that the following assertions are true:")
    print("- AssertionError(\"subelements lookup expects a dictionary, got '%s'\" % item0)")
    print("- AssertionError(\"subelements lookup expects a list, got '%s'\" % item0)")

# Generated at 2022-06-25 11:26:05.802655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This method test add two numeric values
    bool_0 = True
    instanceof_0 = bool_0
    assert_equals(instanceof_0, True)
    # Test lookups
    var_0 = "test"
    ret_2 = var_0
    instanceof_2 = ret_2
    assert_equals(instanceof_2, "test")
    # Test if the created dictionaries are the same
    var_1 = {"var_0": var_0}
    ret_3 = var_1
    instanceof_3 = ret_3
    assert_equals(instanceof_3, {"var_0": "test"})


# Generated at 2022-06-25 11:26:15.407538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-25 11:26:21.194989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    e = Exception("raised exception")
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = MockTemplar()
    lookup_module_0._loader = MockLoader()
    lookup_module_0.run("terms", "variables", "**kwargs")


# Generated at 2022-06-25 11:26:25.777648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, kwargs)


# Generated at 2022-06-25 11:26:28.444318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0, dict_0)
    assert var_0 == ('SUBELEMENTS', [])


# Generated at 2022-06-25 11:26:38.976014
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:26:49.529531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test looks fishy, given the unit test function name...
    # related to #22308
    terms = [{'item': {'a': [1, 2, 3], 'b': 'c'}}, 'a', {'d': 'e'}]
    variables = {}
    kwargs = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    term_0 = var_0[0]
    assert term_0[0] == {'a': [1, 2, 3], 'b': 'c'}
    assert term_0[1] == 1
    assert term_0[2] == {'d': 'e'}
    term_1 = var_0[1]
    assert term_1[0]