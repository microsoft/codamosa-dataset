

# Generated at 2022-06-25 11:17:10.387296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load the module
    lookup_module_0 = LookupModule()
    # Call the method run with parameters
    lookup_module_0.run(terms, variables)


if __name__ == '__main__':
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:17:17.636619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [object, object]
    variables_0 = object
    kwargs_0 = dict()
    terms_1 = [object, object]
    variables_1 = object
    kwargs_1 = dict()
    terms_2 = [object, object]
    variables_2 = object
    kwargs_2 = dict()
    terms_3 = [object, object]
    variables_3 = object
    kwargs_3 = dict()
    terms_4 = [object, object]
    variables_4 = object
    kwargs_4 = dict()
    terms_5 = [object, object]
    variables_5 = object
    kwargs_5 = dict()
    terms_6 = [object, object]
    variables_6 = object
   

# Generated at 2022-06-25 11:17:29.474371
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()

    terms_0 = lookup_module_2.run('', '', )
    terms_1 = lookup_module_2.run('', '', )
    terms_2 = lookup_module_2.run('', '', )
    terms_3 = lookup_module_2.run('', '', )
    terms_4 = lookup_module_2.run('', '', )
    terms_5 = lookup_module_2.run('', '', )
    terms_6 = lookup_module_2.run('', '', )
    terms_7 = lookup_module_2.run('', '', )
    terms_8 = lookup_module_2.run('', '', )
   

# Generated at 2022-06-25 11:17:41.309915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 11:17:44.338209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])
    lookup_module_0.run({})
    lookup_module_0.run(["string"])
    lookup_module_0.run({'K'})


# Generated at 2022-06-25 11:17:48.268712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = dict()
    kwargs = {}
    str_0 = '%s is not an IPv4 address.'
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    if isinstance(ret_0, list):
        pass
    else:
        raise AssertionError(ret_0)



# Generated at 2022-06-25 11:17:51.849683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    sut = LookupModule()
    str_0 = '%s is not an IPv4 address.'


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-25 11:18:03.032964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '*.*'
    dict_0 = {str_0: {}}
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20

# Generated at 2022-06-25 11:18:05.797479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['%s is not an IPv4 address.']
    variables_0 = dict()
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == []

# Generated at 2022-06-25 11:18:10.168233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['alice', 'bob']), list)
    assert isinstance(lookup_module_0.run(['alice', 'bob']), list)
    assert isinstance(lookup_module_0.run(['alice', 'bob']), list)


# Generated at 2022-06-25 11:18:21.630132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert hasattr(lookup_module_1, 'run')
    terms = [[""], ""]
    variables = {}
    lookup_module_1.run(terms, variables) == [""]
    terms = [[""], ""]
    variables = {}
    lookup_module_1.run(terms, variables) == [""]
    terms = [[""], ""]
    variables = {}
    lookup_module_1.run(terms, variables) == [""]

# Generated at 2022-06-25 11:18:26.239055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    string_0 = ":)"
    list_0 = list()
    dict_1 = dict()
    list_1 = list()
    string_1 = ',y@'

    dict_0['find'] = ['find', 'find', 'find', 'find']
    dict_0['subkey'] = 'subkey'
    dict_0['subkey.subsubkey'] = 'subsubkey'
    dict_0['subkey.subsubkey.subsubsubkey'] = 'subsubsubkey'

# Generated at 2022-06-25 11:18:30.576554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 is None

# vim: set expandtab:

# Generated at 2022-06-25 11:18:36.403094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:18:48.939451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # run(): Subelements walks a list of hashes (aka dictionaries) and then
    # traverses a list with a given (nested sub-)key inside of those records.

# Generated at 2022-06-25 11:18:59.710495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        [{
            'foo': 'bar',
            'item': {
                'key': 'value'
            }
        }],
        'item.key'
    ]
    variables_0 = {
        'dummy': 'dummy'
    }
    ret = LookupModule.run(LookupModule(), terms_0, variables_0)
    assert ret == [('value',)], ret
    terms_1 = [
        {
            'foo': 'bar',
            'item': {
                'key': 'value'
            }
        },
        'item.key'
    ]
    variables_1 = {
        'dummy': 'dummy'
    }
    ret = LookupModule.run(LookupModule(), terms_1, variables_1)

# Generated at 2022-06-25 11:19:08.088043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert len(lookup_module.run(terms = [[{'authorized': {'password': 'other-mysql-password',
          'hosts': ['db1'],
          'privs': ['*.*:SELECT', 'DB2.*:ALL']},
         'name': 'bob'},
        {'authorized': {'password': 'mysql-password',
          'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
          'privs': ['*.*:SELECT', 'DB1.*:ALL']},
         'name': 'alice'}], 'authorized'], variables = None)) == 2

# Generated at 2022-06-25 11:19:13.382410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{'skipped': None}, 'sshkey', {'foo': None, 'skip_missing': 'Yes'}]
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == []
    assert lookup_module_0.run(terms_0, variables_0) == []
    assert lookup_module_0.run(terms_0, variables_0) == []


# Generated at 2022-06-25 11:19:23.706684
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:26.903092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    class_0 = MockVarsModule()
    terms = ['foo', 'bar', 'baz']
    variables = {}
    skip_missing = False
    ret = lookup_module_0.run(terms, variables, skip_missing)
    ret


# Generated at 2022-06-25 11:19:44.459626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module.run(['users'], None, None, None)


# Generated at 2022-06-25 11:19:51.082384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(terms = [ { "a": { "b": [ "c" ] } }, "a.b" ]), list)
    assert isinstance(lookup_module.run(terms = [ { "a": { "b": [ "c" ] } }, "a.b", { "skip_missing": True } ]), list)

# Generated at 2022-06-25 11:20:02.278968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    filter_0 = dict()
    filter_0['skipped'] = False
    filter_0['name'] = 'alice'
    filter_0['groups'] = ['wheel']
    filter_0['authorized'] = ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']

    filter_0['mysql'] = dict()
    filter_0['mysql']['hosts'] = ['%', '127.0.0.1', '::1', 'localhost']
    filter_0['mysql']['password'] = 'mysql-password'
    filter_0['mysql']['privs'] = ['*.*:SELECT', 'DB1.*:ALL']

    filter_1 = dict()
    filter_1['skipped']

# Generated at 2022-06-25 11:20:08.787687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [0, 1, 2]
    variables = [0, 1, 2]
    result = lookup_module_1.run(terms, variables)
    assert result == [0, 1, 2]


# Generated at 2022-06-25 11:20:17.489398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    d1 = dict(skipped=False)
    d2 = dict(skipped=False)
    l1 = [d1, d2]
    l2 = ['skipped']
    l3 = [l1, l2]
    d3 = dict(skipped=False)
    d4 = dict(skipped=False)
    l4 = [d3, d4]
    d5 = dict(skipped=False)
    d6 = dict(skipped=False)
    l5 = [d5, d6]
    d7 = dict(skipped=False)
    d8 = dict(skipped=False)
    l6 = [d7, d8]
    d9 = dict(skipped=False)

# Generated at 2022-06-25 11:20:22.970970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    expected_result = []
    actual_result = lookup_module_0.run(terms, variables, **kwargs)
    assert actual_result == expected_result



# Generated at 2022-06-25 11:20:32.759519
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    # Case when 1st term is a list of dict and 2nd term is dict key to extract
    # Expected result: A list of tuples containing this dict key and each element in the list
    # which is a dict as tuples.
    lookup_module_1 = LookupModule()
    test_users_1 = [
      {'name': 'alice', 'SQL': 'SELECT'},
      {'name': 'bob', 'SQL': 'DELETE'}
    ]
    result_1 = lookup_module_1.run([test_users_1, 'SQL'], dict())

# Generated at 2022-06-25 11:20:40.870272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run([['test_term_0.0', 'test_term_0.1', 'test_term_0.2'], 'test_term_1', 'test_term_2'], 'test_variables', 'test_key')
    except Exception as e:
        raise Exception('Caught exception: ' + str(e)) from e


# Generated at 2022-06-25 11:20:49.129125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run([[], [{'skipped': True}], 'subelements'])
    assert len(results) == 0
    with pytest.raises(AnsibleError) as e_info:
        lookup_module.run([[], [{'skipped': False}], 'subelements'])
    assert "subelements lookup expects a dictionary" in str(e_info.value)
    with pytest.raises(AnsibleError) as e_info:
        lookup_module.run([[], [{'skipped': False}], 'subelements'])
    assert "subelements lookup expects a dictionary" in str(e_info.value)

# Generated at 2022-06-25 11:20:54.701166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ('hello', 'world')
    variables = ('hello', 'world')
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:21:33.671442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test run method from module lookup_subelements """
    lookup_module_0 = LookupModule()
    number_of_tests = 13

    if number_of_tests <= 0:
        raise ValueError("Testcase number of tests must be positive")

    # check lookup terms - check number of terms
    terms = [{
        "skipped": False,
        "ok": True,
        "changed": False,
        "unreachable": False,
        "failed": False,
        "skipped_reason": "conditional check failed",
        "invocation": {
            "module_args": "",
            "module_name": "ping"
        },
        "ansible_facts": {},
        "warnings": []
    }]
    terms[0]['skipped'] = False

# Generated at 2022-06-25 11:21:42.686977
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:21:47.361921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [{"key1": "val1", "key2": "val2"}],
        "key1"
    ]
    variables = {}
    kwargs = {}
    lookup_module_obj = LookupModule()
    value = lookup_module_obj.run(terms, variables, **kwargs)
    print("Value: %s" % (value))
    assert value == [("val1", )]


# Generated at 2022-06-25 11:21:50.805519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0
    # get_result with items, variables
    lookup_module_0.run(['one', 'two'], [])


# Generated at 2022-06-25 11:22:00.189787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    test_1 = [{'a': 'b'}, 'a', {'skip_missing': True}]
    assert lookup_module_0.run(test_1, {}) == [{'a': 'b'}, 'b']
    test_2 = [{'a': 'b'}, 'a']
    assert lookup_module_1.run(test_2, {}) == [{'a': 'b'}, 'b']
    test_3 = [{'a': 'b'}, 'a', {'skip_missing': False}]
    assert lookup_module_2.run(test_3, {}) == [{'a': 'b'}, 'b']



# Generated at 2022-06-25 11:22:10.087928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import tempfile
    import random
    import string
    import json
    import pytest

    # Test 1
    # Test with an empty terms list
    terms = []
    variables = {}
    with pytest.raises(AnsibleError):
        lookup_module = LookupModule()
        lookup_module.run(terms=terms, variables=variables)

    # Test 2
    # Test with a terms list with one item
    terms = ["one"]
    variables = {}
    with pytest.raises(AnsibleError):
        lookup_module = LookupModule()
        lookup_module.run(terms=terms, variables=variables)

    # Test 3
    # Test with a terms list with two items
    terms = ["one", "two"]
    variables = {}

# Generated at 2022-06-25 11:22:15.146873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(self, terms, variables, **kwargs)

# Generated at 2022-06-25 11:22:18.569307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['', '', '']
    variables_0 = ''
    result_0 = lookup_module_0.run(terms_0, variables_0)

    assert result_0 == []


# Generated at 2022-06-25 11:22:26.148302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init lookup module for testing
    lookup_module = LookupModule()
    # define expected test data
    expected_return_value_0 = [('alice', 'authorized'), ('bob', 'authorized')]
    expected_return_value_1 = [('alice', 'mysql.hosts'), ('bob', 'mysql.hosts')]
    expected_return_value_2_dict = [('alice', 'alice'), ('bob', 'bob')]
    expected_return_value_2_list = [('alice', 'alice'), ('bob', 'bob')]
    # init test data

# Generated at 2022-06-25 11:22:36.214132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    foo__0 = lookup_module_0.run([{'foo': 'bar'}, 'foo'], {})
    foo__1 = lookup_module_0.run([{'foo': 'bar', 'baz': {'qux': 'quux'}}, 'baz.qux'], {})
    foo__2 = lookup_module_0.run([{'foo': 'bar', 'baz': {'qux': ['quux', 'quuz']}}, 'baz.qux'], {})
    foo__3 = lookup_module_0.run([{'foo': 'bar', 'baz': {'qux': ['quux', 'quuz']}}, 'baz.qux', {'skip_missing': True}], {})

# Generated at 2022-06-25 11:23:39.922657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            'dict_0',
            'dict_1',
        ],
        'string_0',
    ]
    variables_0 = 'string_0'
    kwargs_0 = {
    }
    return_value_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    return

# Generated at 2022-06-25 11:23:46.250094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            {
                'skipped': False
            },
            {
                'skipped': False
            }
        ],
        'authorized',
        {
            'skip_missing': 'no'
        }
    ]
    variables_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == [
        (
            {
                'skipped': False
            },
            'authorized'
        ),
        (
            {
                'skipped': False
            },
            'authorized'
        )
    ]


# Generated at 2022-06-25 11:23:51.910495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    terms_0 = ['test_subelements_0.users', 'mysql.hosts']
    variables_0 = {}
    terms_0[0] = listify_lookup_plugin_terms(terms_0[0], loader=None, templar=None)
    if not isinstance(terms_0, list) or not 2 <= len(terms_0) <= 3:
        _raise_terms_error()
    if not isinstance(terms_0[0], (list, dict)) or not isinstance(terms_0[1], string_types):
        _raise_terms_error("first a dict or a list, second a string pointing to the subkey")
    sub

# Generated at 2022-06-25 11:23:58.101269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '',
        '',
        ''
    ]
    variables = {}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, variables, **{})
    assert result == []


# Generated at 2022-06-25 11:24:00.102284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: Fix this test case
    # lookup_module_0.run is not callable
    # lookup_module_0.run()

# Generated at 2022-06-25 11:24:11.071145
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:24:20.671048
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    LookupModule_run_0_vars = {
        'item': 'item',
        'users': [
            {
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub',
                ],
                'name': 'alice',
            },
            {
                'authorized': [
                    '/tmp/bob/id_rsa.pub',
                ],
                'name': 'bob',
            },
        ],
    }
    LookupModule_run_0_terms = [
        LookupModule_run_0_vars['users'],
        'authorized',
    ]

    # perform the test

# Generated at 2022-06-25 11:24:24.248763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run_setup
    lookup_module_0 = LookupModule()
    terms_0 = ['', '', '']
    vars_0 = {}
    kwargs_0 = {}
    # run test
    result_0 = lookup_module_0._run(terms_0, vars_0, **kwargs_0)
    assert result_0 is None

# Generated at 2022-06-25 11:24:34.694440
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:24:44.079538
# Unit test for method run of class LookupModule