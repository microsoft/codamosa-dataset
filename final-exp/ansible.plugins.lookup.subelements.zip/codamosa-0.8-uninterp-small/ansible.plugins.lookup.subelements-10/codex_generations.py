

# Generated at 2022-06-25 11:17:08.798504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    set_0 = {}
    lookup_module_0 = LookupModule(set_0)
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)



# Generated at 2022-06-25 11:17:12.938532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list()
    variables = str()
    lookup_module_0 = LookupModule(terms, variables)
    # call the method
    result = lookup_module_0.run(terms, variables)
    assert result == None


# Generated at 2022-06-25 11:17:19.547151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = {True}
    lookup_module_0 = LookupModule(set_0, 'ansible.plugins.lookup.subelements', 'LookupModule')
    lookup_module_0._loader = None
    lookup_module_0._templar = None
    lookup_module_0.run([u'users', u'groups', {'skip_missing': True}], None)



# Generated at 2022-06-25 11:17:31.304518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    prng_0 = random.Random()
    key_0 = prng_0.choice(string.ascii_letters)
    value_0 = [prng_0.randrange(1, 8, 1) for _ in range(21)]
    key_1 = prng_0.randrange(1, 8, 1)
    value_1 = prng_0.choice(string.ascii_letters)
    dict_0 = {key_0: value_0, key_1: value_1}
    key_2 = prng_0.randrange(1, 8, 1)
    value_2 = prng_0.choice(string.ascii_letters)
    dict_1 = {key_2: value_2}

# Generated at 2022-06-25 11:17:37.268571
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    sut = LookupModule(set())

    # Test for raised exceptions:
    # subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey

    # subelements lookup expects a dict or a list, got '%s'

    # the optional third item must be a dict with flags %s


# Generated at 2022-06-25 11:17:45.264877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    t1 = [["foo1", "foo2", "foo3"], {"k": "v"}]
    t2 = [["foo1", "foo2", "foo3"], {"k": "v"}, {"k2": "v2"}]

    assert m.run([t1], None) == t1, t1

    assert m.run([t2], None) == t2[0:2], t2



# Generated at 2022-06-25 11:17:56.968379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x11\x1a\x0e\x90\x81\x87\x90\x9a9\x13\x1a\x1c\xaf\x8f\xaf\xb6\x89\xd0\x1c\xbb\x97\x19\xa2\x16\xac\xf2\x96\x00\x99'
    set_0 = {bytes_0, bytes_0}
    lookup_module = LookupModule(set_0)
    arguments = [{"dict_0": {"dict_1": "hello"}}, "dict_1"]
    expected = [("hello",)]
    actual = lookup_module.run(arguments)
    assert expected == actual


# Generated at 2022-06-25 11:17:58.784472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(test_case_0()) == list


# Generated at 2022-06-25 11:18:09.113984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test simple case
    set_0 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    lookup_module_0 = LookupModule(set_0)
    terms_0 = ['key1']
    variables_0 = {}
    kwargs_0 = {}
    retval_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    if (retval_0 != set_0['key1']):
        raise RuntimeError('The returned value is incorrect')

    # test complex case
    terms_1 = [{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}, 'key1']
    variables_1 = {}
    kwargs_1 = {}
    ret

# Generated at 2022-06-25 11:18:17.628487
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:34.099710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()
    lookup_module_16 = LookupModule()

# Generated at 2022-06-25 11:18:34.524196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:18:39.543869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    terms = ['filter']
    variables = []
    kwargs = {'_original_file':'file',
              '_original_va':'va'}
    # Exception raised
    lookup_module._templar = 'templar'
    lookup_module._loader = 'loader'
    # Expected
    expected = 'result'
    # Actual
    actual = lookup_module.run(terms, variables, **kwargs)
    # Assertion
    assert actual == expected

# Generated at 2022-06-25 11:18:43.193865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 11:18:49.985017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey
    lookup_module_0 = LookupModule()
    with pytest.raises(AnsibleError) as exception_info:
        lookup_module_0.run([], dict)
    assert 'Subelements lookup expects a list of two or three items' in str(exception_info.value)
    # subelements lookup expects a list of two or three items, the optional third item must be a dict with flags ['skip_missing']
    with pytest.raises(AnsibleError) as exception_info:
        lookup_module_0.run([list, 'authorized', list], dict)
    assert 'The optional third item must be a dict with flags' in str(exception_info.value)
    # sub

# Generated at 2022-06-25 11:18:54.646224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [""]
    assert False == lookup_module_0.run(terms_0, "")


# Generated at 2022-06-25 11:19:00.484150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_var_0 = '{\"a\": {\"b\": {\"c\": 1, \"d\": 2}}, \"A\": {\"B\": {\"C\": 3, \"D\": 4}}}'
    lookup_var_1 = 'a.b.c'
    lookup_var_0 = lookup_module_0.run(lookup_var_0,lookup_var_1)
    assert_equal(lookup_var_0, [1])


# Generated at 2022-06-25 11:19:03.106402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([{'bob': {'authorized': ['/tmp/bob/id_rsa.pub']}}], 'authorized')

# Generated at 2022-06-25 11:19:07.696480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    v0 = [{'key1': 'value1', 'key2': 'value2'}]
    v1 = "key1"
    v2 = {}
    lookup_module_1.run(v0, v1, v2)
    assert(False)

# Generated at 2022-06-25 11:19:16.049188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list_of_dict = [{'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}, {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}]
    subkey = 'key1'
    subelement_list = lookup_module.run([list_of_dict, subkey], None)
    assert((list_of_dict[0], 'value1') in subelement_list)
    assert((list_of_dict[1], 'value1') in subelement_list)
    assert((list_of_dict[0], 'value2') not in subelement_list)
    assert((list_of_dict[1], 'value2') not in subelement_list)

# Generated at 2022-06-25 11:19:29.166229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = " If this is desired, use '^' to match every line in the file and avoid this warning."
    var_1 = -287
    var_2 = 'eVe}Y/\nM&'
    var_3 = '7PP'
    var_4 = {var_2: var_2, var_3: var_3}
    obj_0 = LookupModule(**var_4)
    obj_0.run(var_0, var_1)


# Generated at 2022-06-25 11:19:37.435614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ",b\r\\Y\\,m\r\\Vz\r\\U\r\\Q,{\\U\r\\,c\r\\O\r\\Q,j\\[,i\\[\r\\"
    int_0 = -47
    # AssertionError: assert lookup_module_0.run(str_0, int_0) == {}
    str_1 = "\\\r\\"
    assert lookup_module_0.run(str_1, int_0) == {}
    str_2 = "~3\\:`"
    del_attr_0 = delattr(lookup_module_0, str_2)

# Generated at 2022-06-25 11:19:40.046412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule.run, types.MethodType)
    assert len(LookupModule.run.__args__) == 1
    assert LookupModule.run.__self__ is LookupModule


# Generated at 2022-06-25 11:19:46.351665
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:58.972876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up mock for _templar, could be anything but for this test we just mock it as itself
    lookup_module = LookupModule(**{})
    lookup_module._templar = lookup_module

    # test None or any non-list / non-tuple results in a None return value
    assert lookup_module.run(None, None) is None
    assert lookup_module.run(False, None) is None
    assert lookup_module.run(False, None) is None

    # test invalid term results in AnsibleError exception
    with raises(AnsibleError):
        lookup_module.run([], None)
    with raises(AnsibleError):
        lookup_module.run([[]], None)
    with raises(AnsibleError):
        lookup_module.run([[], []], None)

# Generated at 2022-06-25 11:20:09.614149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "ansible"
    str_1 = "test"
    str_2 = "localhost"
    str_3 = "test.test_0"
    str_4 = "test_0.test_0"
    dict_0 = dict({str_0: str_4, str_1: str_3})
    dict_1 = dict({str_2: str_1})
    list_0 = [dict_0, dict_1]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0, dict_0, **dict_1)
    assert ((var_0 is not None) and (var_0 == str_2))


# Generated at 2022-06-25 11:20:12.379514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False



# Generated at 2022-06-25 11:20:20.569675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/j7G2Bm\n'
    str_1 = '7'
    list_0 = [str_0, str_1]
    str_2 = "7\nXc3bY"
    int_0 = 0
    list_1 = [int_0, int_0]
    map_0 = {str_2: list_0, str_1: list_1}
    lookup_module_0 = LookupModule(**map_0)
    str_3 = 'm*h'
    str_4 = 'p%c\n'
    str_5 = '1'
    int_1 = 1
    dict_0 = {str_3: int_0, str_4: str_5, str_0: int_1}
    var_0 = lookup_module_0

# Generated at 2022-06-25 11:20:26.091487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = " If this is desired, use '^' to match every line in the file and avoid this warning."
    int_0 = -287
    list_0 = [str_0, int_0]
    dict_0 = {'skipped': False, 'toxml_0': {'toxml_1': '', 'toxml_2': '', 'toxml_3': '', 'toxml_4': ''}}
    list_1 = [dict_0, dict_0]
    dict_1 = {'skipped': False, 'toxml_0': {'toxml_1': '', 'toxml_2': '', 'toxml_3': '', 'toxml_4': ''}}
    list_2 = [dict_1, dict_1]
    list_3

# Generated at 2022-06-25 11:20:36.195526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = """MvquN^hN"""
    dict_0 = {"f@A/1": str_0, "0>Z": str_0, "9X!eUb!": str_0}
    lookup_module_0 = LookupModule(**dict_0)
    str_1 = "Vg|[sUJ7VU`q:T-)TQFu%J^-L}&b\nM&U%cG"
    int_0 = -62
    str_2 = 'a:)OaA'
    str_3 = "i{0-\n      "
    dict_1 = {str_1: str_2, str_3: int_0}
    lookup_module_0.run(str_2, int_0)


# Generated at 2022-06-25 11:20:54.231483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:20:56.459544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0.run('YX|2h,', -946439495)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:21:07.504435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}
    var_1 = 'authorized'
    var_2 = {'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob', 'mysql': var_0}
    var_3 = {'name': 'alice', 'mysql': {'privs': ['*.*:SELECT', 'DB1.*:ALL'], 'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost']}, 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']}


# Generated at 2022-06-25 11:21:10.783975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test
    pass


# Generated at 2022-06-25 11:21:19.041934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "6*sUg"
    int_0 = 40
    str_1 = "2VuTZ:(Y\n"
    str_2 = "j~qr"
    dict_0 = {str_1: str_1, str_2: str_2}
    lookup_module_1 = LookupModule(**dict_0)
    var_0 = lookup_run(str_0, int_0)

# Generated at 2022-06-25 11:21:30.198253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = " could not find '%s' key in iterated item '%s'"
    str_1 = 'eVe}Y/\nM&'
    str_2 = '7PP'
    str_3 = 'eVe}Y/\nM&'
    str_4 = '7PP'
    str_5 = 'eVe}Y/\nM&'
    str_6 = '7PP'
    str_7 = 'eVe}Y/\nM&'
    str_8 = '7PP'
    str_9 = 'eVe}Y/\nM&'
    str_10 = '7PP'
    str_11 = 'eVe}Y/\nM&'
    str_12 = '7PP'

# Generated at 2022-06-25 11:21:32.447098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    (v, e) = test_case_0()

    assert v is not False

# Generated at 2022-06-25 11:21:37.083634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Note that this is not a valid setup for a test.
    str_2 = '^'
    int_5 = 2
    lookup_module_0.run(str_2, int_5)


# Generated at 2022-06-25 11:21:42.721257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subkey = "test"
    list_0 = [1, 2, 3, 4, 5]
    dict_0 = {'a': [3, 4, 5], 'b': 2, 'c': 1, 'd': [1, 2, 3], 'e': 5, 'f': 4, 'g': [5, 1, 2, 3, 4], 'h': 3}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, dict_0)
    pass


# Generated at 2022-06-25 11:21:47.688587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "TlxSf<o@Y#{E$\n{"
    int_0 = -292
    str_1 = 'H'
    str_2 = 'H'
    dict_0 = {str_1: str_1, str_2: str_2}
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_run(str_0, int_0)


# Generated at 2022-06-25 11:22:32.288431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = " If this is desired, use '^' to match every line in the file and avoid this warning."
    int_0 = -287
    str_1 = 'eVe}Y/\nM&'
    str_2 = '7PP'
    dict_0 = {str_1: str_1, str_2: str_2}
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_run(str_0, int_0)



# Generated at 2022-06-25 11:22:37.921568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = " If this is desired, use '^' to match every line in the file and avoid this warning."
    int_0 = -287
    str_1 = 'eVe}Y/\nM&'
    str_2 = '7PP'
    dict_0 = {str_1: str_1, str_2: str_2}
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_module_0.run(str_0, int_0)
    assert var_0 == -1


# Generated at 2022-06-25 11:22:43.021029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    lookup_module_0 = LookupModule()
    subvalue = lookup_module_0.run('subelements')
    assert(subvalue.__class__ == list)

    subvalue = LookupBase.run(lookup_module_0, terms=[])
    assert(subvalue.__class__ == list)


# Generated at 2022-06-25 11:22:50.956678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = " If this is desired, use '^' to match every line in the file and avoid this warning."
    int_0 = -287
    str_1 = 'eVe}Y/\nM&'
    str_2 = '7PP'
    dict_0 = {str_1: str_1, str_2: str_2}
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_run(str_0, int_0)

    # TEST CASE 0
    # ---
    # We don't yet have a test case to illustrate what this method does.
    # If you have one, please contribute it!
    # ---



# Generated at 2022-06-25 11:22:58.481042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assign parameters to variables
    # Assign parameter to variable int_0
    int_0 = -287
    # Assign parameter to variable str_0
    str_0 = " If this is desired, use '^' to match every line in the file and avoid this warning."

    # Assign parameter to variable str_1
    str_1 = 'eVe}Y/\nM&'
    # Assign parameter to variable str_2
    str_2 = '7PP'
    # Assign parameter to variable dict_0
    dict_0 = {str_1: str_1, str_2: str_2}
    # Create instance of LookupModule
    lookup_module_0 = LookupModule(**dict_0)

    # Attempt to run method named run of LookupModule

# Generated at 2022-06-25 11:23:00.645717
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case: run: test_case_0
    test_case_0()

# Generated at 2022-06-25 11:23:06.150966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '+|1z(Td\n'
    int_0 = -23
    str_1 = 'S,|V~w'
    str_2 = 'u4E'
    dict_0 = {str_1: str_1, str_2: str_2}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = lookup_run(str_0, int_0)

# Generated at 2022-06-25 11:23:15.164315
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # tests abitrary return value (ADHOC)
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run("", "") == []

    # tests passing variable as first parameter
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run("lookup_module_1", "") == []

    # tests passing variable as second parameter
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run("", "lookup_module_2") == []

    # tests passing variable as third parameter
    lookup_module_3 = LookupModule()
    assert lookup_module_3.run("", "") == []

# Unit tests for case 0

# Generated at 2022-06-25 11:23:19.937684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(45, 5, {'M': [1, 2, 3], 'h': 5, '-': [1, 2], 't': '&%?', '1': 4, 'r': '_c%r)', '`': [1, 2, 3]})
    var_1 = lookup_run(60, 10)


# Generated at 2022-06-25 11:23:29.676284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'vDz2k?]:i\t'
    str_1 = 'PQN'
    str_2 = '%!e'
    str_3 = 'oO/j'
    str_4 = 'iZ0H'
    str_5 = 'J'
    str_6 = 'jPQ'
    str_7 = 'G'
    str_8 = 'X8'
    str_9 = 'w/%|'
    str_10 = 'Y}0m{'
    str_11 = 'QW'
    str_12 = 'D'
    str_13 = '$'
    str_14 = '{'
    str_15 = 'Dn]B'
    str_16 = 'Z'
   

# Generated at 2022-06-25 11:24:58.611888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Run tests:')
    print('setUp()')
    print('test_LookupModule_run()')

    # setUp()

    # test_LookupModule_run()
    test_case_0()

# main test
test_LookupModule_run()

''',
'''
#!/usr/bin/python

# (c) 2013, Serge van Ginderachter <serge@vanginderachter.be>
# (c) 2012-17 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type


# Generated at 2022-06-25 11:25:05.981544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up objects needed to test
    lookup_module = LookupModule()
    args = {}
    args['_terms'] = [
        {'skipped': False, 'users': [{'user_id': '124', 'username': 'JohnDoe'}, {'user_id': '125', 'username': 'JohnDoe2'}, {'user_id': '123', 'username': 'JohnDoe3'}]},
        'users',
        {}
    ]
    args['_variables'] = {}

    # run the method
    result = lookup_module.run(**args)

    # assert we got the right answer
    assert result[0][0]['username'] == 'JohnDoe'
    assert result[1][0]['username'] == 'JohnDoe2'

# Generated at 2022-06-25 11:25:11.409050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    str_0 = "x"
    int_0 = -16
    str_1 = 'V'
    str_2 = 'Q'
    dict_0 = {str_2: str_2, str_1: str_1}
    lookup_module_0 = LookupModule(**dict_0)
    var_0 = lookup_run(str_0, int_0)

test_LookupModule_run()

# Generated at 2022-06-25 11:25:17.553730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "If this is desired, use '^' to match every line in the file and avoid this warning."
    list_0 = [
        "eVk{#0", "7dv", "b(N", "zA",
    ]
    list_1 = [
        "eVe}Y/\nM&", "6lB", "Cu", "l]",
        "B,,", "7PP", "j", "*P", "w}r",
        "t]n", "Y9", "E", "M", ";",
        "tLn", "R`{", "~2:z", "Y5", "<.",
    ]

# Generated at 2022-06-25 11:25:19.994777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test method "run" of class "LookupModule"')
    test_case_0()
    print('Test successful!')


# Generated at 2022-06-25 11:25:31.143746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = -215

# Generated at 2022-06-25 11:25:40.686798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\n\t\t\t#4:o~d'
    str_1 = 'l\ns'
    str_2 = 'm\t('
    str_3 = '5\x18\tv\x18'
    str_4 = '\x1a8\tW'
    str_5 = '\x1a8\tW'
    str_6 = '\x18\t\t\t#4:o~d'
    str_7 = '$\x1a8\t\t'
    str_8 = '\\^\x0f!'
    str_9 = '\x0f!'
    str_10 = '\\^9'
    str_11 = '\x0e'
    str_12

# Generated at 2022-06-25 11:25:48.408087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'D\\a|_'
    int_0 = 893
    str_1 = '7PP'
    str_2 = 'eVe}Y/\nM&'
    dict_0 = {str_0: str_0, str_1: str_1}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(int_0)

# Generated at 2022-06-25 11:25:53.123142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_private_field(field_name, object_instance):
        object_class = object_instance.__class__
        return object_class.__dict__[field_name].__get__(object_instance, object_class)

    def set_private_field(field_name, value, object_instance):
        object_class = object_instance.__class__
        return object_class.__dict__[field_name].__set__(object_instance, value)

    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables, **kwargs)
    pass


# Generated at 2022-06-25 11:25:58.040395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'l .'
    str_1 = "P"
    str_2 = 'T~Xs@Np'
    list_0 = ['t', str_0, "can't join a string with a", str_1]
    list_1 = ["l"]
    list_2 = ['ra', "e"]
    str_3 = '=f)nq3c'
    str_4 = '"^" to match every line in the file and avoid this warning.'
    int_0 = -14
    str_5 = 'n='
    str_6 = 'V}'
    list_3 = ['the optional third item must be', str_5]
    str_7 = 'B*q3'
    str_8 = 'Z^Pm'