

# Generated at 2022-06-25 11:17:08.542160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run() function tests
    lookup_module_1 = LookupModule()
    terms_1 = ('terms_1',)
    variables_1 = ('variables_1',)
    lookup_module_1.run(terms_1, variables_1)

test_LookupModule_run()

# Generated at 2022-06-25 11:17:16.334558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("##### Test start 'LookupModule_run' #####")
    lookup_module_1 = LookupModule()
    test_var_1 = [{'a': 1, 'b': 2, 'c': {'a': 'a', 'b': 1}}, {'a': 3, 'b': 2}]
    test_var_2 = 'c.b'
    result = lookup_module_1.run([test_var_1, test_var_2])
    assert result == [{'a': 1, 'b': 2, 'c': {'a': 'a'}}, {'a': 3, 'b': 2}]


# Generated at 2022-06-25 11:17:27.655595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    def fake_run(self, terms, variables, **kwargs):
        return []
    lookup_module.run = fake_run
    lookup_module.run([], None)

    # test with 2 list elements:
    terms = [
        ['list_element_0', 'list_element_1'],
        'subkey'
    ]
    ret = lookup_module.run(terms, None)
    assert ret == [('list_element_0', 'subkey'), ('list_element_1', 'subkey')]

    # test with 3 list elements:
    terms = [
        ['list_element_0', 'list_element_1', 'list_element_2'],
        'subkey'
    ]
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-25 11:17:32.463010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    terms = [['item1', 'item2'], 'key']
    # terms = ['item1', 'item2']
    variables = None
    skip_missing = False
    ret = obj.run(terms, variables, skip_missing=skip_missing)
    assert ret == [('item1', 'item2')]



# Generated at 2022-06-25 11:17:34.591904
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # instantiating the class:
    lookup_module_0 = LookupModule()

    # test for valid imput
    lookup_module_0.run()

# Generated at 2022-06-25 11:17:46.268121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = None
    lookup_module_0 = LookupModule()
    # Test with args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    # Test without args
    #

# Generated at 2022-06-25 11:17:50.782023
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[], variables='', **{})

# Generated at 2022-06-25 11:17:53.103037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    arguments_1 = [['user1', 'user2']]


# Generated at 2022-06-25 11:17:58.749270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    users = [
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*:*?SELECT', 'DB2.*:ALL']}},
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*:*?SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}
    ]

    # second term is a string holding the subkey

# Generated at 2022-06-25 11:18:04.670702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([['a', 'b', 'c', 'd'], 'foo'])
    assert result == [('a', 'foo'), ('b', 'foo'), ('c', 'foo'), ('d', 'foo')]



# Generated at 2022-06-25 11:18:27.796242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [('a', 'b')] == lookup_module.run([['a'], 'b'], None)
    assert [('a', 'b')] == lookup_module.run([{'a': 'b'}], None)
    with pytest.raises(AnsibleError):
        lookup_module.run([[], 'b'], None)
    with pytest.raises(AnsibleError):
        lookup_module.run([[], 'b', 'c'], None)
    with pytest.raises(AnsibleError):
        lookup_module.run([{'a': 'b', 'c': 'd'}, 'c'], None)



# Generated at 2022-06-25 11:18:34.862036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for item in test_cases['run']:
        terms = item[0]
        expected = item[1]
        variables = item[2]
        lookup_module = LookupModule()
        result = lookup_module.run(terms, variables)
        assert result == expected



# Generated at 2022-06-25 11:18:39.989212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('bob') == ['bob']

# Generated at 2022-06-25 11:18:49.515092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = '''[{"authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"], "name": "alice", "mysql": {"password": "mysql-password", "hosts": ["%", "127.0.0.1", "::1", "localhost"], "privs": ["*.*:SELECT", "DB1.*:ALL"]}}, {"authorized": ["/tmp/bob/id_rsa.pub"], "name": "bob", "groups": ["wheel"], "mysql": {"password": "other-mysql-password", "hosts": ["db1"], "privs": ["*.*:SELECT", "DB2.*:ALL"]}}]'''
    lookup_module_0 = LookupModule()
    lookup_module_0.run(x, None)

# Unit

# Generated at 2022-06-25 11:18:59.735534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0_0 = [
        'users',
        'mysqlhosts'
    ]

    variables_0_0 = {
        'users': [
            {
                'name': 'alice',
                'mysqlhosts': [
                    '%',
                    '127.0.0.1',
                    '::1',
                    'localhost'
                ]
            },
            {
                'name': 'bob',
                'mysqlhosts': [
                    'db1'
                ]
            }
        ]
    }

    kwargs_0_0 = {}

    ret_0_0 = lookup_module_0.run(terms_0_0, variables_0_0, **kwargs_0_0)

# Generated at 2022-06-25 11:19:09.229656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
      (
        {
          'skipped': False,
          'item0': {
            'item11': 'item11',
            'item10': 'item10',
            'subkey': [
              'subkey_value0',
              'subkey_value1',
              'subkey_value2',
            ],
          },
        }
      ),
      'subkey',
      {
        'skip_missing': False,
      },
    ]

# Generated at 2022-06-25 11:19:13.270437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ('test1', 'test1')
    variables_0 = 'test2'
    kwargs_0 = {'skip_missing': 'test3'}
    ret = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret == []


# Generated at 2022-06-25 11:19:17.143223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = [1, 2]
    subelements = LookupModule().run(
        ['defaults'], 
        dict(defaults=list(map(lambda x: dict(x=x), range(20)))))
    assert subelements ==ret


# Generated at 2022-06-25 11:19:25.719054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{"dell":{"hostname":"dell"}}, "hostname"]
    terms_1 = [{"dell":{"hostname":"dell"}}, "hostname"]
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    ret_0 = lookup_module_0.run(terms_0, templar, loader=None, **{})
    assert (ret_0 == [('dell', 'dell')])
    ret_1 = lookup_module_0.run(terms_1, templar, loader=None, **{})
    assert (ret_1 == [('dell', 'dell')])


# Generated at 2022-06-25 11:19:31.845891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]
    subelements = 'authorized'
    expected_

# Generated at 2022-06-25 11:20:10.774282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{u'alice': {"authorized": ["/tmp/alice/onekey.pub"],
                         "groups": ["wheel"],
                         "name": "alice",
                         "mysql": {"hosts": ["localhost"],
                                   "password": "mysql-password",
                                   "privs": ["*.*:SELECT"]}},
             u'bob': {"authorized": ["/tmp/bob/id_rsa.pub"],
                      "name": "bob",
                      "mysql": {"hosts": ["db1"],
                                "password": "other-mysql-password",
                                "privs": ["*.*:SELECT"]}}}]
    variables = {}
    kwargs = {}

# Generated at 2022-06-25 11:20:19.845890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    module_all_users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]
    variables = dict()

# Generated at 2022-06-25 11:20:27.894176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case = [
        {'skipped': True, 'name': 'alice', 'authorized': ['key1'], 'groups': ['wheel'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost']}},
        {'skipped': True, 'name': 'bob', 'authorized': ['key2'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost']}}
    ]

    expected_result = []

    lookup_module = LookupModule()
    result = lookup_module.run([test_case, 'authorized'], None)

    assert result == expected_result


# Generated at 2022-06-25 11:20:31.392437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(["alice", "bob"], "authorized_keys")
    assert result == ["alice", "bob"]


# Generated at 2022-06-25 11:20:43.888901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    users = [
        {'name': 'alice',
        'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob',
        'authorized': ['/tmp/bob/id_rsa.pub']}]

    terms = [users, 'authorized']
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms, {})
    users_0 = [
        {'name': 'alice',
        'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob',
        'authorized': ['/tmp/bob/id_rsa.pub']}]


# Generated at 2022-06-25 11:20:54.233012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var = {'users': [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}]}
    subelements = ["users", "authorized"]

# Generated at 2022-06-25 11:20:55.452547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    test_case_0()

# Generated at 2022-06-25 11:21:05.087348
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    terms=[['a','b'], ['b','c'], ['c','d']]
    variables={}
    kwargs={}

    LookupModule_run_ret = lookup_module_1.run(terms, variables, **kwargs)
    assert LookupModule_run_ret == [[('a', 'b'), ('b', 'c')], [('b', 'c'), ('c', 'd')], [('c', 'd')]]


# Generated at 2022-06-25 11:21:08.530388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(args=['foo', 'bar', 43], variables={'foo': 'Foo!', 'bar': 'Bar!', 43: 'The Answer!'}) == ['Foo!', 'Bar!', 'The Answer!']

# Generated at 2022-06-25 11:21:14.409195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # testing with a list of dictionaries and a subkey name:
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    ret = lookup_module.run([users, "authorized"], [])

# Generated at 2022-06-25 11:22:26.701908
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Case 1: test on empty list 
    assert lookup_module_0.run([], None, None) == []

    # Case 2: test on list with one string 
    assert lookup_module_0.run([''], None, None) == []

    # Case 3: test on list with two strings 
    assert lookup_module_0.run(['', ''], None, None) == []

    # Case 4: test on list with one dict 
    assert lookup_module_0.run([{}], None, None) == []

    # Case 5: test on list with two dicts 
    assert lookup_module_0.run(['', ''], None, None) == []

    # Case 6: test on list with one dict and one string 

# Generated at 2022-06-25 11:22:36.108155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [[{'skipped':False, 'key_a': {'key_b':[1,2,3]}}], ['key_a.key_b']]
    variables = {}
    result = lookup_module.run(terms, variables)
    expected_result = [(({'key_a': {'key_b': [1, 2, 3]}, 'skipped': False}, 1), ({'key_a': {'key_b': [1, 2, 3]}, 'skipped': False}, 2), ({'key_a': {'key_b': [1, 2, 3]}, 'skipped': False}, 3))]
    assert result == expected_result


# Generated at 2022-06-25 11:22:44.577677
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    lookup_module.run([['a', 'b'], 'teststr'], {}, **{})

    lookup_module.run([{'a': 'c', 'b': 'd'}, 'teststr'], {}, **{})

    lookup_module.run([{'a': 'c', 'b': 'd'}, 'teststr', {'skip_missing': False}], {}, **{})

    lookup_module.run([{'a': 'c', 'b': 'd'}, 'teststr', {'skip_missing': True}], {}, **{})

# Generated at 2022-06-25 11:22:56.545895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 11:23:07.783959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stub for method run of class LookupModule
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:23:17.746978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert True == lookup_module_1.run([[{'subkey1':'subvalue1','subkey2':'subvalue2'}],'subkey1'])
    assert True == lookup_module_1.run([[{'subkey1':'subvalue1','subkey2':'subvalue2'}],'subkey2'])
    assert False == lookup_module_1.run([[{'subkey1':'subvalue1','subkey2':'subvalue2'}],'subkey3'])
    assert True == lookup_module_1.run([[{'subkey1':{'subsubkey1':'subsubvalue1'},'subkey2':'subvalue2'}],'subkey1.subsubkey1'])

# Generated at 2022-06-25 11:23:28.555141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    elementlist = [{
        'item1key1': 'item1value1',
        'item1key2': 'item1value2',
        'sub': {'subkey1': 'subvalue1', 'sublist': ['sublist1value1', 'sublist1value2']},
        'subsub': {'subsubkey': {'subsubsublist': ['subsubsublist1value1', 'subsubsublist1value2']}}
    },
        {
            'item2key1': 'item2value1',
            'sub': {'sublist': ['sublist2value1', 'sublist2value2']}
        }]

    # With sublist, without flags
    lookup_module_0 = LookupModule()
   

# Generated at 2022-06-25 11:23:36.893946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # subelements lookup expects a list of two or three items,
    # first a dict or a list, second a string pointing to the subkey
    terms_0 = [{'foo': 1}]
    variables_0 = {}
    try:
        lookup_module_0.run(terms_0, variables_0)
    except AnsibleError:
        pass
    else:
        assert False

    # subelements lookup expects a list of two or three items,
    # first a dict or a list, second a string pointing to the subkey
    terms_1 = [{'foo': 1}, 'bar']
    variables_1 = {}
    try:
        lookup_module_0.run(terms_1, variables_1)
    except AnsibleError:
        pass

# Generated at 2022-06-25 11:23:46.460014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.utils.listify
    import ansible.plugins
    import ansible.plugins.lookup
    import ansible.errors
    import ansible.module_utils.parsing.convert_bool
    test_case_0.lookup_module_0 = LookupModule()
    ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.set_loader()
    ansible.template.Templar.set_loader()
    ansible.utils.listify.listify_lookup_plugin_terms.set_loader()
    ansible.utils.listify.listify_lookup_plugin_terms.set_loader()
    ansible.utils.listify.listify

# Generated at 2022-06-25 11:23:52.093324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['[{"a": {"b": {"c": [1, 2, 3]}}}, {"a": {"b": {"c": [4, 5, 6]}}}]', 'a.b.c']
    variables = {}

# Generated at 2022-06-25 11:26:49.163527
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with invalid terms
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms=["users"], variables={"users": ""})
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError was not raised")

    # test with valid terms
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms=["users", "authorized"], variables={"users": ""})

    # test with valid terms
    lookup_module_3 = LookupModule()
    lookup_module_3.run(terms=["users", "authorized", {"skip_missing": True}], variables={"users": ""})


# Generated at 2022-06-25 11:26:54.791519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [{'dict_single': {'subkey': ['a', 'b']}}, 'subkey']
    variables_1 = {}
    lookup_module_1.run(terms_1, variables_1)

    lookup_module_2 = LookupModule()
    terms_2 = [{'dict1': {'subkey': ['a', 'b']}, 'dict2': {'subkey': ['c', 'd']}, 'dict3': {'subkey': ['e', 'f']}}, 'subkey']
    variables_2 = {}
    lookup_module_2.run(terms_2, variables_2)

    lookup_module_3 = LookupModule()
    terms_3 = ['string', 'subkey']
    variables_3 = {}
    lookup