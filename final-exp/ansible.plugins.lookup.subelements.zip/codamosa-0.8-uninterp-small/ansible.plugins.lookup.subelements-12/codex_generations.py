

# Generated at 2022-06-25 11:17:11.904853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (len(LookupModule(str("\xd5\xfcx\x03\x06\x7f\x0e\x12\x15")).run([{'skipped': True}], {'skipped': True}, **{'skipped': True}))) == 0
    assert (len(LookupModule(str("\x0c\xb0\xcf\x94\xa0@\xe8zd\x12")).run([{'skipped': True}], {'skipped': True}, **{'skipped': True}))) == 0

# Generated at 2022-06-25 11:17:24.223821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "K`\x0c,QZ\x0b-7$\x18)u\x19y\x01'\x01"
    str_1 = "\x11\\h<j\x1c#\x0c-,\x0e~\x01U\x1f:\x1a"
    boolean_0 = boolean(str_1, strict=False)
    str_2 = '\x0bO?3t>{CoQ/SCuD7'
    lookup_module_0 = LookupModule(str_2)
    boolean_1 = boolean(str_2, strict=False)

# Generated at 2022-06-25 11:17:31.577652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\x0bO?3t>{CoQ/SCuD7'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '\x0bO?3t>{CoQ/SCuD7'
    lookup_module_0.run(str_1)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:17:37.988744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\x0bO?3t>{CoQ/SCuD7'
    list_0 = []
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    lookup_module_0 = LookupModule(str_0)
    int_0 = lookup_module_0.run(list_0, list_0)

# Generated at 2022-06-25 11:17:45.624242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #check _raise_terms_error
    #check error when terms are not valid
    #check error when elements in terms are not valid
    #check error when flags are not valid
    #check skipped items
    #check all skipped items
    #check sub lists
    #check sub lists for all levels
    #check list of dicts as input
    #check dict as input
    #check that dicts are converted to list
    #check results
    return True

# Test cases

# Generated at 2022-06-25 11:17:57.293394
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:08.409726
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:14.137365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test ensure that when subkey is not present no error is raised
    lookup_module_0 = LookupModule('')
    vars_0 = {}
    kwargs_0 = {'skip_missing': True}
    lookup_ret_0 = lookup_module_0.run(['', ''], vars_0, **kwargs_0)

    # Test ensure that the lookup is successful when subkey is nested
    lookup_module_1 = LookupModule('')
    vars_1 = {}
    kwargs_1 = {'skip_missing': True}
    lookup_ret_1 = lookup_module_1.run(['', 'test'], vars_1, **kwargs_1)

    # Test ensure that the lookup is successful when subkey is present
    lookup_module_2 = LookupModule('')

# Generated at 2022-06-25 11:18:18.982198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = [{'skipped': False}]
  variables = {'skipped': False}
  lookupModule = LookupModule(terms, variables, [], [])
  lookupModule.run(terms, variables)

# Test: works when only one key is queried

# Generated at 2022-06-25 11:18:27.985861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [{"first": 1, "skipped": True}, {"second": 2, "skipped": False}]
    variables = {"skipped": True}
    lookup_module_0.run(terms, variables)
    terms = [{"skipped": True}, [{"first": 1, "skipped": False}, {"second": 2, "skipped": False}], {"skipped": True}]
    variables = {"skipped": True}
    lookup_module_0.run(terms, variables)
    terms = [{"skipped": True}, {"skipped": False}]
    variables = {"skipped": True}
    lookup_module_0.run(terms, variables)
    terms = [{"skipped": True}]
    variables = {"skipped": True}
    lookup_module_

# Generated at 2022-06-25 11:18:48.939696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = "4b.e..4"
    str_1 = "\\s"
    str_2 = "H_e"
    str_3 = ",n"
    str_4 = "v%G)void"
    str_5 = "Vu~"
    str_6 = "b"
    str_7 = "A"
    str_8 = ""
    str_9 = ","
    str_10 = "f"
    str_11 = "\\"
    str_12 = "\\"
    int_0 = 2

    lookup_module = LookupModule()

    # start test : test method run of class LookupModule
    # test case : test case 0
    test_case_0()
    test_assert("1", bool_0)
    # test case

# Generated at 2022-06-25 11:18:53.210425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test case for LookupModule run method"""

    test_case_0()

# Generated at 2022-06-25 11:18:57.133841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["terms", "terms"]
    variables = "variables"
    kwargs = {}

    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables, **kwargs) == []


# Generated at 2022-06-25 11:18:59.730024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms, variables, kwargs = [], {}, {}
    subelements = LookupModule().run(terms, variables, **kwargs)
    return subelements


# Generated at 2022-06-25 11:19:03.819398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = { }
    terms_1 = [ term_0, 'subkeys' ]
    variables_2 = { }
    lookup_base = LookupModule(None)
    lookup_base._templar = None
    lookup_base._loader = None
    test_case_0()

    # This code was generated for following:
    # run(self, terms, variables=None, **kwargs)
    # Arguments:
    # - self: reference to object instance
    # - terms: string or list of strings
    # - variables: dict or None
    # - kwargs: additional keyword arguments
    # Return value: list or string
    # Exceptions raised: AnsibleError

    return

# Generated at 2022-06-25 11:19:09.753574
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Minimal example
    q = LookupModule()
    assert q.run([['foo'], 'bar', {}], {}) == [('foo', 'bar')]

    # Skipped items example
    q = LookupModule()
    assert q.run([[{'skipped': True}], 'bar', {}], {}) == []

    # Missing items example
    q = LookupModule()
    assert q.run([[{}], 'bar', {'skip_missing': True}], {}) == []

# Generated at 2022-06-25 11:19:11.204430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()

    test_object.run()


# Generated at 2022-06-25 11:19:16.175259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    s = subelements([{'foo': 'bar'}, {'bar': 'baz'}], 'foo', {'skip_missing': True})
    assert (s[0][0] == 'bar')


# Generated at 2022-06-25 11:19:20.425831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    assert isinstance(lookup_module_instance, LookupModule)

if __name__ == "__main__":
    import nose
    nose.main()

# Generated at 2022-06-25 11:19:27.909331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    sut = LookupModule()
    assert sut != None

    terms = [listify_lookup_plugin_terms(terms, templar=self._templar, loader=self._loader), listify_lookup_plugin_terms(terms, templar=self._templar, loader=self._loader)]

    if isinstance(terms, list) or isinstance(terms, dict):
        raise AnsibleError("subelements lookup expects a list of two or three items, " + msg)

    if isinstance(terms[0], (list, dict)) or isinstance(terms[1], string_types):
        raise AnsibleError("first a dict or a list, second a string pointing to the subkey")

    # check for optional flags in third term
    flags = {}

# Generated at 2022-06-25 11:19:38.234302
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:39.734180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = True
    assert bool_0
    assert bool_1


# Generated at 2022-06-25 11:19:40.919545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:19:46.869201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['[{"skipped": false, "name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"], "mysql": {"password": "mysql-password", "hosts": ["%", "127.0.0.1", "::1", "localhost"], "privs": ["*.*:SELECT", "DB1.*:ALL"]}, "groups": ["wheel"]}, {"skipped": false, "name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"], "mysql": {"password": "other-mysql-password", "hosts": ["db1"], "privs": ["*.*:SELECT", "DB2.*:ALL"]}}]', 'mysql.hosts', '{"skip_missing": true}']

# Generated at 2022-06-25 11:19:50.935379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    oLookupModule = LookupModule()
    terms = ["*", "*", "10", "2"]
    variables = "10"
    ret = oLookupModule.run(terms, variables)
    assert ret == ["10", "2"]



# Generated at 2022-06-25 11:20:00.961589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string_0 = 'C:\\Users\\Admin\\Ansible\\ansible\\lib\\ansible\\plugins\\lookup\\subelements.py'
    string_1 = 'C:\\Users\\Admin\\Ansible\\ansible\\lib\\ansible\\parsing\\convert_bool.py'
    string_2 = 'C:\\Users\\Admin\\Ansible\\ansible\\lib\\ansible\\utils\\listify.py'
    boolean_0 = boolean(value='', strict=True, fail_on_undefined=False, skip_values=())
    lookupmodule_0 = LookupModule()
    test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:20:03.886019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:20:08.135163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == "Not implemented yet"

# Generated at 2022-06-25 11:20:10.066637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["terms", "terms", "terms", "terms"]

    # Test case with arguments
    assert LookupModule.run(terms, {}, **{}) is None


# Generated at 2022-06-25 11:20:20.297441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            {
                'skipped': False
            },
            {
                'skipped': False
            },
            {
                'skipped': False
            },
            {
                'skipped': False
            },
            {
                'skipped': False
            }
        ],
        'mysql.hosts',
        {
            'skip_missing': False
        }
    ]
    variables = {}

# Generated at 2022-06-25 11:20:40.199739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['', '', '', '', '', '']
  variables = ['', '', '', '', '', '']
  kwargs = {}

  return_value = LookupModule().run(terms, variables, **kwargs)
  assert return_value == None

# Generated at 2022-06-25 11:20:48.511489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.module_utils.six import PY2

    with open("/etc/ansible/roles/lookup_plugins/test/data/playbook_subelements.json") as json_data:
        vars = json.load(json_data)
        json_data.close()

    lookup = LookupModule()

    terms = [[], 'users', {'skip_missing': 'False'}]
    ret = lookup.run(terms, vars)

    # list[tuple[dict, str]]
    assert isinstance(ret, list)
    assert all(isinstance(t, tuple) for t in ret)
    assert all(len(t) == 2 for t in ret)
    assert all(isinstance(t[0], dict) for t in ret)

# Generated at 2022-06-25 11:20:56.313257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    SUBELEMENTS_0 = {
        'authorized': [
            '/tmp/alice/onekey.pub',
            '/tmp/alice/twokey.pub'
        ],
        'groups': [
            'wheel'
        ],
        'mysql': {
            'hosts': [
                '%',
                '127.0.0.1',
                '::1',
                'localhost'
            ],
            'password': 'mysql-password',
            'privs': [
                '*.*:SELECT',
                'DB1.*:ALL'
            ]
        },
        'name': 'alice'
    }

# Generated at 2022-06-25 11:21:04.878091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    # bool_1 is the result of the run() method

    terms = [ bool_0, bool_0 ]
    variables = bool_0
    kwargs = {}
    bool_1 = bool_0.run(terms, variables, **kwargs)

    assert bool_1 == True

# Unit tests for class LookupModule is called
test_case_0()

# Unit tests for method run of class LookupModule is called
test_LookupModule_run()

# Generated at 2022-06-25 11:21:07.347580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    case_0 = test_case_0()


if __name__ == '__main__':
    test_LookupModule_run()


# vim: et:sta:bs=2:sw=4:

# Generated at 2022-06-25 11:21:08.267267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:21:14.291419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test for method 'run'
    bool_0 = bool(True)
    subelements = []
    terms = []
    variables = {}
    _terms_0 = bool_0
    terms.append(_terms_0)
    _terms_1 = bool_0
    terms.append(_terms_1)
    _terms_2 = bool_0
    terms.append(_terms_2)
    subelements.append(terms)
    _terms_3 = bool_0
    terms.append(_terms_3)
    _terms_4 = bool_0
    terms.append(_terms_4)
    _terms_5 = bool_0
    terms.append(_terms_5)
    subelements.append(terms)
    subelements.append(terms)
    test_case_

# Generated at 2022-06-25 11:21:17.949273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    RUN_TEST = False
    if RUN_TEST:
        subelements = LookupModule()
        terms = [None, None]
        variables = None
        kwargs = {}
        subelements.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:21:29.412833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    bool_3 = True
    bool_4 = True
    bool_5 = True
    bool_6 = True
    bool_7 = True
    bool_8 = True
    bool_9 = True
    bool_10 = True
    bool_11 = True
    bool_12 = True
    bool_13 = True
    bool_14 = True
    bool_15 = True
    bool_16 = True
    bool_17 = True
    bool_18 = True
    bool_19 = True
    bool_20 = True
    bool_21 = True
    bool_22 = True
    bool_23 = True
    dict_0 = dict(([('string_0', 'string_0'), ('string_1', 'string_1')]))


# Generated at 2022-06-25 11:21:32.617593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if bool_0:
        ret = LookupModule._raise_terms_error()
        assert ret is None


# Generated at 2022-06-25 11:22:16.906948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
   # Test parameter terms
    terms = []
   # Test parameter variables
    variables = {}
   # Test parameter kwargs
    kwargs = {}
    lm.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:22:20.428607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    p = {'skipped': True}
    r = lookup.run(['c', '{}', 'a'], 'var', **{})
    assert type(r) == type([])

test_LookupModule_run()

# Generated at 2022-06-25 11:22:24.861195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the class so we can get it's namespace for the test.
    lookup_module_instance = LookupModule()
    # Create an instance of the class so we can get it's namespace for the test.
    lookup_module_instance = LookupModule()

    # Create a Dictionary that the lookup_module_instance module's run function
    # will use as it's parameters.
    module_parameters = {}

    # The expected_results object is used to compare the results of the run function
    # to the expected output of the run function.
    expected_results = []

    # Create a variable that will be updated by calling the run function.
    actual_results = lookup_module_instance.run(module_parameters, None)

    # Assert if the values are not equal.
    assert actual_results == expected_results

# Run the

# Generated at 2022-06-25 11:22:25.965958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 11:22:36.144538
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:22:38.203083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:22:46.725047
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:22:49.876106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:22:54.291377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = {'0': {}}
    variables = {}
    skip_missing = False
    kwargs = {'skip_missing': True}
    ret = l.run(**terms)
    assert terms.keys() == ret.keys(), 'Expected equality'
    assert terms.values() == ret.values(), 'Expected equality'
    return


# Generated at 2022-06-25 11:22:58.754814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_plug = LookupModule()
    # test case for execution of run
    test_case_0()
    # test case for execution of run
    arr_elem_1 = [None]
    arr_elem_0 = [arr_elem_1]
    test_case_1()
    # test case for execution of run
    arr_elem_3 = [None]
    arr_elem_2 = [arr_elem_3]
    test_case_2()

# Generated at 2022-06-25 11:23:39.741043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data_0 = {'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel'], 'name': 'alice', 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}}

    # Strings are not valid
    with pytest.raises(AnsibleError):
        subelements([{'name': 'Foo'},'hosts'])
    # Empty lists are not valid
    with pytest.raises(AnsibleError):
        subelements([{'name': 'Foo'},[]])
    # List with more than three items are not valid


# Generated at 2022-06-25 11:23:45.404535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    # Test parameters
    terms = [r'%(alice|bob)s', 'authorized']
    variables = None
    keywords = {}

    # Test function
    result = m.run(terms, variables, **keywords)
    assert result == [('/tmp/alice/onekey.pub', '/tmp/alice/onekey.pub'), ('/tmp/alice/twokey.pub', '/tmp/alice/twokey.pub'), ('/tmp/bob/id_rsa.pub', '/tmp/bob/id_rsa.pub')]

# Generated at 2022-06-25 11:23:51.236396
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

    # check lookup terms - check number of terms
    if not isinstance(terms, list) or not 2 <= len(terms) <= 3:
        _raise_terms_error()

    # first term should be a list (or dict), second a string holding the subkey
    if not isinstance(terms[0], (list, dict)) or not isinstance(terms[1], string_types):
        _raise_terms_error("first a dict or a list, second a string pointing to the subkey")
    subelements = terms

# Generated at 2022-06-25 11:23:58.285916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = 'cY_MrK'
    int_0 = 7082
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)

# Generated at 2022-06-25 11:24:05.082478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '61tny#*f;\thP'
    int_0 = 1646
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)

# Generated at 2022-06-25 11:24:08.705923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = 'j7b=a1z'
    int_0 = 1052
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_module_0.run(bool_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:24:11.536483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '61tny#*f;\thP'
    int_0 = 1646
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:24:18.073713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params

    # Expected return value
    expected_return_value = None

    # Perform the test
    test_0 = expected_return_value == None

    # Return the results of the unit test.
    
    return test_0


# Generated at 2022-06-25 11:24:22.933112
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:24:26.276382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = [str_0, str_1, str_2, str_3]
    variables = []

    # Invoke method
    rv = lookup_module_0.run(terms, variables, str_0)

    # Verify
    pass


# Generated at 2022-06-25 11:26:11.254064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(test_case_0.__doc__)
    test_case_0()

# Generated at 2022-06-25 11:26:15.916725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '\x1c3\x1d'
    int_0 = 1646
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)

# Test class LookupModule

# Generated at 2022-06-25 11:26:16.692288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 11:26:24.678442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock parameter 'terms'
    terms = [
        [
            {
                'foo': 'foo',
                'bar': 'bar',
            },
            {
                'foo': 'foo',
                'bar': 'bar',
            },
        ],
        'foo',
    ]
    
    # mock parameter 'variables'
    variables = [
        {
            'bar': 'bar',
            'foo': 'foo',
        },
        {
            'bar': 'bar',
            'foo': 'foo',
        },
    ]
    
    # mock parameter 'kwargs'
    kwargs = [
        {
            'bar': 'bar',
            'foo': 'foo',
        },
        {
            'bar': 'bar',
            'foo': 'foo',
        },
    ]


# Generated at 2022-06-25 11:26:31.847990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '61tny#*f;\thP'
    int_0 = 1646
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)


# Generated at 2022-06-25 11:26:33.682725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '#'
    int_0 = 150
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)
    print(var_0)



# Generated at 2022-06-25 11:26:39.038707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '61tny#*f;\thP'
    int_0 = 1646
    tuple_0 = ()
    lookup_module_0 = LookupModule(int_0, tuple_0)
    var_0 = lookup_run(bool_0, str_0)


# Generated at 2022-06-25 11:26:49.529683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('\n[test_LookupModule_run]\n')
    import sys
    import yaml
    import json


# Generated at 2022-06-25 11:26:59.377583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    list_1 = []
    list_0.append(list_1)
    list_1.append(list_0)
    list_1.append(list_0)
    lookup_module_0 = LookupModule(list_1, list_0)
    lookup_module_0.run()
    lookup_module_0.run(list_0, list_1, list_1)
    lookup_module_0.run(list_1, list_1, list_0, list_0)
    lookup_module_0.run(list_0, list_1, {list_1:list_1})
    