

# Generated at 2022-06-25 11:17:09.892925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            {
                'skipped': [],
            },
        ],
        'skipped',
        {
        },
    ]
    variables_0 = {}
    _list_0 = lookup_module_0.run(terms_0, variables_0, **{'skip_missing': True})
    assert _list_0 == []


# Generated at 2022-06-25 11:17:18.229455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run([['foo', 'bar', 'baz']], {}, {})
    assert result == [('foo',), ('bar',), ('baz',)]
    result = lookup_module_1.run(['foo', 'bar', 'baz'], {}, {})
    assert result == [('foo',), ('bar',), ('baz',)]
    result = lookup_module_1.run([{'foo': 'foo', 'bar': 'bar'}], {}, {})
    assert result == [('foo',), ('bar',)]
    result = lookup_module_1.run([{'foo': 'foo', 'bar': 'bar', 'skipped': True}], {}, {})
    assert result == []
    result = lookup_module_1

# Generated at 2022-06-25 11:17:26.434489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test the environment variable 'ANSIBLE_LOOKUP_PLUGINS' is NOT set
    os.environ.pop('ANSIBLE_LOOKUP_PLUGINS', None)
    # Test the term is valid to be used in the 'run' method
    terms = [
        {'skipped': False},
        'authorized',
        {'skip_missing': True}
    ]
    # Test the variable is a valid Ansible variable
    variables = {}
    # Test Python3 compatibility
    if not is_python3:
        __real_val = __builtin__.__dict__['__import__']
    else:
        __real_val = __import__
    # If the following line throws an exception, then the
    # environment variable 'ANSIBLE_LOOKUP_PLUGINS'

# Generated at 2022-06-25 11:17:26.925499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:17:29.040925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert True # TODO: may fail later

# Generated at 2022-06-25 11:17:38.685627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["foo"]
    variables_0 = "foo"
    kwargs_0 = {"skip_missing":True}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    terms_1 = [{"skipped":False}]
    variables_1 = "foo"
    kwargs_1 = {"skip_missing":False}
    lookup_module_1.run(terms_1, variables_1, **kwargs_1)

# Generated at 2022-06-25 11:17:45.040373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{u'item1a': u'value1a', u'item1b': u'value1b',  u'item1c': u'value1c'}, u'item1b']
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=terms, variables=None)
    assert result == [u'value1b']


# Generated at 2022-06-25 11:17:54.201072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_0 = eval("""[['stuff', 'things'], "others.stuff"]""")

# Generated at 2022-06-25 11:17:59.851155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {}
    terms_0 = [{}, "skipped"]
    ret_0 = lookup_module_0.run(terms_0, vars_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:18:09.485713
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:18:25.501905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:18:28.676579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()


# Generated at 2022-06-25 11:18:35.381519
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # run called with terms = [{'item0': {'item1': ['item2']}}, 'item0'], variables = None, **kwargs = None
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([{'item0': {'item1': ['item2']}}, 'item0'], None, **None) == [({'item1': ['item2'], 'item0': {'item1': ['item2']}}, ['item2'])]

    # run called with terms = [{'item0': {'item1': 'item2'}}, 'item1'], variables = None, **kwargs = None
    lookup_module_1 = LookupModule()
    #assert lookup_module_1.run([{'item0': {'item1': 'item2'}},

# Generated at 2022-06-25 11:18:48.939268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        [[{'a': 1}, {'a': 2}], 'a'],
        [[{'a': 1}, {'a': 2}], 'b', {'skip_missing': True}],
        [[{'a': 1}, {'a': 2}], 'b'],
        [[{'a': 1}, {'a': 2}], 'c.d'],
        [[{'a': 1}, {'a': 2}], 'c.d', {'skip_missing': True}],
        [[{'a': 1}, {'a': 2}], 'c.d'],
        [[{'a': 1, 'c': {'d': 3}}, {'a': 2, 'c': {'d': 4}}], 'c.d']
    ]

# Generated at 2022-06-25 11:18:56.538497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = lambda x: x
    lookup_module_0._loader = lambda x: x
    lookup_terms_0 = [{"facts": {"foo": 42, }}]
    lookup_terms_0.append("foo")
    lookup_module_0.run(lookup_terms_0, {}, {})


# Generated at 2022-06-25 11:19:04.190286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # fail if terms is not list
    try:
        lookup_module.run(None, None)
    except AnsibleError:
        pass
    except:
        raise Exception('test_LookupModule_run: Failed to detect type error!')

    # fail if terms is empty
    try:
        lookup_module.run([], None)
    except AnsibleError:
        pass
    except:
        raise Exception('test_LookupModule_run: Failed to detect empty list!')

    # fail if terms is not list of two or three items
    try:
        lookup_module.run([], None)
    except AnsibleError:
        pass
    except:
        raise Exception('test_LookupModule_run: Failed to detect empty list!')

    # fail if terms[0] is not

# Generated at 2022-06-25 11:19:05.961591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:19:15.480496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['a', 'b', 'c', {'skipped': False}, 'd'], None)
    lookup_module_1.run(['a', 'b', 'c', {'skipped': True}, 'd'], None)
    lookup_module_1.run(['a', 'b', {'skipped': False}], None)
    lookup_module_1.run(['a', 'b', {'skipped': True}], None)
    lookup_module_1.run(['a', 'b', 'c', 'd'], None)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:19:17.555084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([["foo.bar"], ["bar"]], {}) == [("foo.bar", "bar")]


# Generated at 2022-06-25 11:19:23.472310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_1 = LookupModule()
   elementlist = [{'a': 'b'}, {'c': 'd'}]
   subelement = 'd'
   flags = {'skip_missing': 'False'}
   with pytest.raises(AnsibleError) as e_info:
      ret = lookup_module_1.run(elementlist, subelement, flags)


# Generated at 2022-06-25 11:19:54.590878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test for argument(s) number
    args = ['arg1', 'arg2', 'arg3']
    lookup_module_0.run(args, dict())



# Generated at 2022-06-25 11:20:00.657812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    elementlist = [{'dict': [{'skipped': None}, 'test']}]
    subdict = {'skipped': True}
    expected = []
    actual = LookupModule().run([elementlist, 'dict'], [{'skipped': None}, 'test'])
    assert expected == actual


# Generated at 2022-06-25 11:20:07.569491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    val_0 = [{'skipped': False, 'state': 'present', 'privilege': '*.*:SELECT', 'comment': 'Superuser privileges', 'login_user': 'root', 'login_password': 'mysql-password', 'login_port': 3306, 'login_host': 'localhost', 'user': 'root@localhost'}, {'skipped': False, 'state': 'present', 'privilege': 'user11db.*:ALL', 'comment': 'User privileges', 'login_user': 'root', 'login_password': 'mysql-password', 'login_port': 3306, 'login_host': 'localhost', 'user': 'user11@localhost'}]
    val_1 = 'state'
    val_2 = None

# Generated at 2022-06-25 11:20:16.312509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# def test_case_1():
#     lookup_module_0 = LookupModule(loader=None, templar=None, shared_loader_obj=None)
#     terms = []
#     variables = {}
#     assert lookup_module_0.run(terms, variables) == []

# def test_case_2():
#     lookup_module_0 = LookupModule(loader=None, templar=None, shared_loader_obj=None)
#     terms = []
#     variables = {}
#     assert lookup_module_0.run(terms, variables) == []


# Generated at 2022-06-25 11:20:27.584759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The result of the lookup plugin is a list that contains tuples of keys and values
    assert test_case_0().run([[{'key1': 'value1', 'key2': 'value2'}], 'key1']) == [('value1',)]
    assert test_case_0().run([[{'key1': 'value1', 'key2': 'value2'}], 'key2']) == [('value2',)]
    assert test_case_0().run([[{'key1': 'value1', 'key2': 'value2'}], 'key3']) == []

    assert test_case_0().run([[{'key1': ['a', 'b']}], 'key1']) == [('a',), ('b',)]

# Generated at 2022-06-25 11:20:35.874769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1.run([{'first': 'Alice', 'last': 'Smith'}, {'first': 'Bob', 'last': 'Jones'}], {}, {}), list)
    assert isinstance(lookup_module_1.run([{'first': 'Alice', 'last': 'Smith'}, {'first': 'Bob', 'last': 'Jones'}], {}, {'skip_missing': True}), list)
    assert isinstance(lookup_module_1.run([{'first': 'Alice', 'last': 'Smith'}, {'first': 'Bob', 'last': 'Jones'}], {}, {'skip_missing': False}), list)


# Generated at 2022-06-25 11:20:44.968024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #
    # Test type 1
    #

    input_terms_0 = [
        {
            'name': 'Alice',
            'age': 35,
            'hash': {
                'subkey': 'subvalue',
                'subkey2': [
                    'subvalue1',
                    'subvalue2'
                ]
            }
        },
        {
            'name': 'Bob',
            'age': 33,
            'hash': {
                'subkey': 'subvalue',
                'subkey2': [
                    'subvalue1',
                    'subvalue2'
                ]
            }
        },
    ]

# Generated at 2022-06-25 11:20:55.324041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test that subelements lookup can take a single value as input
    users_0 = {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}
    terms_0 = [users_0, 'authorized']
    variables_0 = {}
    kwargs_0 = {}
    ret_0_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0_0 == [(users_0, '/tmp/alice/onekey.pub'), (users_0, '/tmp/alice/twokey.pub')]

    # test that subelements lookup can take a list of dicts

# Generated at 2022-06-25 11:21:05.087312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   terms_0_0 = []
   terms_0_0.append(["a", "b"])
   terms_0_0.append("c")
   variables_0_0 = {}
   result = lookup_module_0.run(terms_0_0, variables_0_0)
   assert len(result) == 2
   assert result[0] == ("a", "c")
   assert result[1] == ("b", "c")


# Generated at 2022-06-25 11:21:12.407041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var_1=['cat','dog','fish','bird','lizard','iguana','turtle','snake']
    test_var_2=['cat','dog','fish','bird','lizard','iguana','turtle','snake']
    test_var_3=['cat','dog','fish','bird','lizard','iguana','turtle','snake']
    test_var_4=['cat','dog','fish','bird','lizard','iguana','turtle','snake']
    test_var_5=['cat','dog','fish','bird','lizard','iguana','turtle','snake']
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:22:16.994971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    map0_0_0 = {'test': True, 'mark': True}
    map0_0_1 = {'hello': True, 'mark': False}
    map0_0_2 = {'test': False, 'hello': True}
    map0_0_3 = {'test': True, 'mark': False}
    map0_0_4 = {'test': True, 'hello': True, 'mark': True}
    map0_0_5 = {'test': True, 'mark': False}
    map0_0_6 = {'test': True, 'mark': True}
    map0_0_7 = {'test': False, 'mark': False}
    map0_0_8 = {'test': False, 'hello': True}
    map

# Generated at 2022-06-25 11:22:19.021675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = test_case_0()
    lookup_module_0.run('', 'subkey')



# Generated at 2022-06-25 11:22:24.193072
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input parameters:
    terms = [
        {
            "key1":  {
                "key2": [
                    "val1",
                    "val2"
                ]
            }
        },
        "key1.key2",
        {}
    ]

    variables = {}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables) == [("val1",), ("val2",)]



# Generated at 2022-06-25 11:22:34.875873
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = [[
        {'name': 'alice', 'authorized': [
            '/tmp/alice/onekey.pub',
            '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': [
            '/tmp/bob/id_rsa.pub']}],
        'authorized']
    result = lookup_module.run(terms, None)

# Generated at 2022-06-25 11:22:46.134879
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Case 0
    terms = [
      0,
      1,
      {
        'skip_missing': True
      }
    ]
    variables = {}
    kwargs = {}

    result = lookup_module.run(terms, variables, **kwargs)
    assert result == []

    # Case 1
    terms = [
      {
        'skipped': False
      },
      '.',
      {
        'skip_missing': True
      }
    ]
    variables = {}
    kwargs = {}

    result = lookup_module.run(terms, variables, **kwargs)
    assert result == []

    # Case 2

# Generated at 2022-06-25 11:22:56.617683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    users_0 = [
        {
            'name': 'speye',
            'groups': [
                'spy',
                'eye'
            ],
            'authorized': [
                '/home/speye/spy.key',
                '/home/speye/eye.key'
            ]
        },
        {
            'name': 'hpeye',
            'authorized': [
                '/home/hpeye/spy.key',
                '/home/hpeye/eye.key'
            ]
        },
        {
            'name': 'jpeye',
            'groups': [
                'jp',
                'eye'
            ]
        }
    ]
    terms_0 = [
        users_0,
        'groups'
    ]
    variables_0 = {}
    kwargs_

# Generated at 2022-06-25 11:23:07.785901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_cases = []

    # testcase 0

# Generated at 2022-06-25 11:23:17.747576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    users = {
      'alice': {
        'authorized': [
          '/tmp/alice/id_rsa.pub'
        ],
        'mysql': {
          'password': 'mysql-password',
          'hosts': [
            '%'
          ],
          'privs': [
            '*.*:SELECT'
          ],
          'groups': [
            'wheel'
          ]
        }
      },
      'bob': {
        'authorized': [
          '/tmp/bob/id_rsa.pub'
        ]
      }
    }
    terms_0 = [
      [
        users
      ],
      'authorized'
    ]

# Generated at 2022-06-25 11:23:28.360388
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:23:36.440848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test when wrong number of options is passed
    terms = ["a", "b", "c", "d"]
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms, [])
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

    # test when dict and list is passed
    terms[1] = {}
    try:
        lookup_module.run(terms, [])
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"

    # test when list and string is passed
    terms[0] = []

# Generated at 2022-06-25 11:25:03.630280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries and a string
    assert(test_run_1())
    assert(test_run_2())
    assert(test_run_3())
    assert(test_run_4())
    assert(test_run_5())
    # Test with a dict and string
    assert(test_run_6())
    assert(test_run_7())
    assert(test_run_8())
    assert(test_run_9())
    assert(test_run_10())

# Tests that with_subelements works

# Generated at 2022-06-25 11:25:11.697312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {'skipped': False, 'item': 'a'},
        {'skipped': False, 'item': 'b'},
        {'skipped': True, 'item': 'c'},
        {'skipped': False, 'item': 'd'},
        {'skipped': True, 'item': 'e'}
    ]

    flags = {}
    subelements_1 = "items"
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, {}, subelements=subelements_1, **flags)
    assert result == [('a', 'a'), ('b', 'b'), ('d', 'd')]

    # Test that a skipped item is not treated as an error.

# Generated at 2022-06-25 11:25:17.756536
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:25:22.652093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    rval = lookup_module_0.run(sub_element_value)

    if None == rval:
        print("Subelement Exception: None == rval")


if __name__ == "__main__":
    #
    # Unit Test Code
    #
    sub_element_value = [[{'a':'x', 'b':'y'}, {'a':'z', 'b':'t'}], 'a']
    lookup_module_0 = LookupModule()
    test_LookupModule_run()

# Generated at 2022-06-25 11:25:26.860363
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    expected = [('Pass', {'lookup': 'name0', 'lookup2': 'name1'}), ('Pass', {'lookup': 'mname0', 'lookup2': 'mname1', 'lookup3': 'mname2'})]
    actual = lookup_module_1.run([{'name': {'lookup': 'name0', 'lookup2': 'name1'}, 'name2': {'lookup': 'mname0', 'lookup2': 'mname1', 'lookup3': 'mname2'}}, 'lookup'], {})
    assert (expected == actual)

    expected = []

# Generated at 2022-06-25 11:25:36.888522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(['', '', '', ''])
    assert lookup_module_0.run([""], "", "") == []
    lookup_module_0.set_options(['', '', '', ''])
    assert lookup_module_0.run(["", ""], "", "") == []
    lookup_module_0.set_options(['', '', '', ''])
    assert lookup_module_0.run(["", "", ""], "", "") == []
    lookup_module_0.set_options(['', '', '', ''])
    assert lookup_module_0.run(["", "", "", ""], "", "") == []
    lookup_module_0.set_options(['', '', '', ''])

# Generated at 2022-06-25 11:25:38.259181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run([], {}) == []

# Generated at 2022-06-25 11:25:44.087699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Case 0
        test_case_0()
    except Exception as e:
        print("Exception running test at line: " + str(e.__traceback__.tb_lineno) + " - " + str(e))


if __name__ == "__main__":
    # running unit tests
    test_LookupModule_run()

# Generated at 2022-06-25 11:25:46.003170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[], variables=LookupBase())



# Generated at 2022-06-25 11:25:52.087579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print ("LookupModule.run")
    test = 3
    lookup_module_1 = LookupModule()