

# Generated at 2022-06-25 11:17:09.305995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run(self, *args, **kwargs):
        return []

    lookup_module_0 = LookupModule()
    lookup_module_0.run = types.MethodType(run, lookup_module_0)

# Generated at 2022-06-25 11:17:16.901031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["[{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': []}, {'name': 'bob', 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}, 'authorized': ['/tmp/bob/id_rsa.pub']}]", "mysql.hosts"]
    variables_0 = {}

# Generated at 2022-06-25 11:17:26.414685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    ansible_0 = {'skipped': False}
    ansible_1 = 'authorized.keys'
    ansible_2 = {'skipped': False}
    ansible_3 = False
    ansible_4 = False
    ansible_5 = False
    ansible_6 = False
    ansible_7 = False
    ansible_8 = False
    ansible_9 = False
    ansible_10 = False
    ansible_11 = False
    ansible_12 = False
    ansible_13 = False
    ansible_15 = False
    ansible_16 = False
    ansible_17 = False
    ansible_18 = False
    ansible_19 = False
    ansible_20 = False
    ansible_22 = []
    ansible_23 = {}
    ansible

# Generated at 2022-06-25 11:17:36.886031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = ''
    lookup_module_0._loader = ''
    assert lookup_module_0.run('', '', '') == []

    lookup_module_0 = LookupModule()
    lookup_module_0._templar = ''
    lookup_module_0._loader = ''
    assert lookup_module_0.run('', '', '') == []

    lookup_module_0 = LookupModule()
    lookup_module_0._templar = ''
    lookup_module_0._loader = ''
    assert lookup_module_0.run(
        '', '', '') == []

    lookup_module_0 = LookupModule()
    lookup_module_0._templar = ''

# Generated at 2022-06-25 11:17:37.630370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-25 11:17:48.191140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # subelements.run: missing subkey
    with pytest.raises(AnsibleError):
        lookup_module._templar.template('{{ q("subelements", [[{"key": "value"}]]) }}')
    # subelements.run: missing subkey, skip_missing enabled
    assert lookup_module._templar.template('{{ q("subelements", [[{"key": "value"}]], "nomatter", skip_missing=True) }}') == []

    # subelements.run: wrong combination of parameters
    with pytest.raises(AnsibleError):
        lookup_module._templar.template('{{ q("subelements", [], "a.b.c", {"skip_missing": True}) }}')

# Generated at 2022-06-25 11:17:59.250437
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # test with valid arguments
    result = lookup_module.run([['a', 'b'], 'c', {'skip_missing': False}], [], wantlist=True)
    assert result == []

    result = lookup_module.run([{'a': 'a', 'b': 'b'}, 'c', {'skip_missing': False}], [], wantlist=True)
    assert result == []

    result = lookup_module.run([{'a': {'d': 'd', 'e': ['e1', 'e2', 'e3']}, 'b': {'d': 'd', 'e': ['e1', 'e2', 'e3']}}, 'c', {'skip_missing': False}], [], wantlist=True)
    assert result == []

    result

# Generated at 2022-06-25 11:18:08.410226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    terms_0 = [ 
        { 
            'skipped': False,
            'a.dict': { 
                'first': '1',
                'second': '2',
                'third': '3'
            }
        },
        'a.dict'
    ]
    variables_0 = { 
    }
    kwargs_0 = { 
    }
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)



# Generated at 2022-06-25 11:18:17.211979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(
        dict({u'_ansible_check_mode': True, u'_ansible_debug': True,
              u'_ansible_diff': False, u'_ansible_keep_remote_files': False,
              u'_ansible_no_log': False, u'_ansible_remote_tmp': None,
              u'_ansible_selinux_special_fs': [u'fuse', u'nfs', u'vboxsf', u'ramfs', u'9p', u'vfat']}))
    my_vars = dict()
    my_vars[u'ansible_check_mode'] = False
    my_vars[u'ansible_loop_var'] = u'item'

# Generated at 2022-06-25 11:18:27.500923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[{'Foo': {'Bar': [1, 2]}}], variables=None) == [(None, 1), (None, 2)]
    assert lookup_module_0.run(terms=[[{'Foo': {'Bar': [1, 2]}}]], variables=None) == [({'Foo': {'Bar': [1, 2]}}, 1), ({'Foo': {'Bar': [1, 2]}}, 2)]
    assert lookup_module_0.run(terms=[[{'Foo': {'Bar': [1, 2]}}]], variables=None) == [({'Foo': {'Bar': [1, 2]}}, 1), ({'Foo': {'Bar': [1, 2]}}, 2)]
   

# Generated at 2022-06-25 11:18:46.472782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    data = {'a': 'A', 'b': 'B', 'c': 'C'}
    for i in lookup_module.run([data, 'b'], {}):
        assert i == 'B'
    for i in lookup_module.run([data, 'x'], {}):
        assert i == ''

# Generated at 2022-06-25 11:18:52.149974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}]
    terms = tuple()
    flags = {'skip_missing': False}
    ret = lookup_module_0.run(terms, users, flags)
    assert False



# Generated at 2022-06-25 11:19:01.911551
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:19:12.282280
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_terms = [ {'name':'alice', 'authorized': ['/tmp/alice/onekey.pub','/tmp/alice/twokey.pub']} , 'authorized']
    lookup_result = lookup_module.run(lookup_terms, None)
    assert lookup_result == [({'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'name': 'alice'}, '/tmp/alice/onekey.pub'), ({'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'name': 'alice'}, '/tmp/alice/twokey.pub')]


# Generated at 2022-06-25 11:19:17.118380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['users', 'mysql.hosts', {'skip_missing': True}]
    variables_0 = None
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == [('127.0.0.1',), ('::1',), ('localhost',), ('db1',)]


# Generated at 2022-06-25 11:19:22.380758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [
        [
            {'k': 'v'}
        ],
        'k'
    ]
    variables = {}
    kwargs = {}
    output_1 = lookup_module_1.run(terms, variables, **kwargs)
    assert output_1 == [('v',)]

# Generated at 2022-06-25 11:19:31.544073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Calling run method of class LookupModule on a case-test where:
    # var_0 = [
    #         {
    #             'name': 'alice',
    #             'authorized': [
    #                 '/tmp/alice/onekey.pub',
    #                 '/tmp/alice/twokey.pub'
    #             ]
    #         },
    #         {
    #             'name': 'bob',
    #             'authorized': [
    #                 '/tmp/bob/id_rsa.pub'
    #             ]
    #         }
    #     ], var_1 = 'authorized'

    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:19:43.442278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        [
            {
                '1': '11',
                '2': '12',
                '3': '13',
            },
            {
                '1': '21',
                '2': '22',
                '3': '23',
            },
        ],
        '2',
    ]
    variables_1 = {}
    kwargs_1 = {}
    assert lookup_module_1.run(terms_1, variables_1, **kwargs_1) == [('11', '12'), ('21', '22')]


# Generated at 2022-06-25 11:19:54.334591
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([['hello'], 'bogus'])
    assert 'first a dict or a list' in str(excinfo)

    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([{'hello': 'world'}, 'bogus'])
    assert 'subelements lookup expects a dictionary' in str(excinfo)

    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([[{'hello': 'world'}], 'bogus'])
    assert "could not find 'bogus' key in iterated item" in str(excinfo)


# Generated at 2022-06-25 11:20:04.836412
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule
    lookup_module = LookupModule()

    # Test for errors in the terms

# Generated at 2022-06-25 11:20:40.752357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert not lookup_module.run(terms=['arg1', 'arg2'], variables={})

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-25 11:20:46.665405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # set up the arguments
    terms = []
    terms.append([{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']}, {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}])


# Generated at 2022-06-25 11:20:52.829181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ [ { 'title': 'dr', 'name': 'Frans', 'skipped': False },
                { 'title': 'mr', 'name': 'Bob', 'skipped': True } ],
              'name',
              { 'skip_missing': False } ]
    result = lookup_module.run(terms, {})
    assert result == [ ({ 'name': 'Frans', 'title': 'dr' }, 'Frans') ]


# Generated at 2022-06-25 11:20:58.378077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.environment = {"HOME":"/root"}
    terms = [["foo","bar"],SubelementsLookupError]
    variables = {"foo":"bar","baz":"qux"}
    lookup_module_0.run(terms, variables)
    terms = [dict(foo="bar"),SubelementsLookupError]
    lookup_module_0.run(terms, variables)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:21:09.572094
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #def test_case_0():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:21:21.791244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = AnsibleTemplar()
    lookup_module_0._loader = AnsibleLoader()
    list_0 = [{'0': {'1': {'2': {'3': '4'}, '5': '6'}}}, {'0': {'1': {'2': {'3': '4'}}}}]
    ret_0 = lookup_module_0.run(list_0, None)
    assert len(ret_0) == 0
    assert ret_0 == []

if __name__ == '__main__':
    test_LookupModule_run()

# ansible-2.9.12/lib/ansible/plugins/lookup/subelements.py

# Generated at 2022-06-25 11:21:28.632367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [[{'key0': {'key1': [{'key2': 'value2'}]}}], 'key0.key1.key2']
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, {})
    assert result == [('value2',)]
    return



# Generated at 2022-06-25 11:21:39.122098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    terms_0.append(['c', 'd', 'e'])
    terms_0.append('a')
    variables_0 = {}
    variables_0 = {}
    kwargs_0 = {}
    kwargs_0['_ansible_check_mode'] = False
    kwargs_0['_ansible_debug'] = False
    kwargs_0['_ansible_diff'] = False
    kwargs_0['_ansible_keep_remote_files'] = False
    kwargs_0['_ansible_no_log'] = False
    kwargs_0['_ansible_remote_tmp'] = 'None'
    kwargs_0['_ansible_verbosity'] = 0
    kwargs

# Generated at 2022-06-25 11:21:43.648133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == None


test_LookupModule_run()

# Generated at 2022-06-25 11:21:46.290734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["foo", "bar"]
    variables = ["foo"]
    results = lookup_module.run(terms, variables)
    assert results == "foo"
    

# Generated at 2022-06-25 11:22:56.185796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_base_element_value_0 = lookup_module_1.run(["alice", "name"], "")
    assert test_base_element_value_0 == [('alice', 'name')]

# Generated at 2022-06-25 11:23:01.709470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run([{'a': 1, 'b': 2}, 'b'], None)
    assert ret[0] == 2


# Generated at 2022-06-25 11:23:06.803004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()
    ret_val = test_class.run(terms=[
        [{dummy1: [1, 2]}, {dummy2: [3, 4]}, {dummy3: [5, 6]}],
        'dummy1'
    ])
    assert ret_val == [[{dummy1: [1, 2]}, 1], [{dummy1: [1, 2]}, 2]]


# Generated at 2022-06-25 11:23:13.188505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = {}
    kwargs_1 = {u'_original_file': u'/home/ben/.ansible/roles/role_pr/tasks/main.yml', u'_role': None}
    result = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert result == []


# Generated at 2022-06-25 11:23:20.231542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    lookup_module_0 = LookupModule()
    terms_0 = [
        [
            {
                'foo': 'bar'
            }
        ],
        'foo'
    ]
    variables_0 = None

    # Test case setup
    try:
        raise AnsibleError('Failed to run test')
    except Exception:
        pass  # noqa

    # Test case body
    try:
        # print('Before run')
        lookup_module_0.run(terms_0, variables_0)
        # print('After run')
    except Exception as e:
        # print('Exception raised: ' + str(e))
        assert False

    # Test teardown



# Generated at 2022-06-25 11:23:24.309847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # get all test cases for LookupModule.run
    test_cases = [0,1]

    for i in test_cases:
        # TODO: Write each test case
        pass

# Generated at 2022-06-25 11:23:31.199663
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize the class

    lookup_module = LookupModule()

    # value of argument terms
    terms_value = [[{'a': 1, 'b': {'c': 3}}], 'b.c']

    # value of argument variables
    variables_value = "variables_value"

    # value of argument kwargs
    kwargs_value = "kwargs_value"

    # method run of class LookupModule with arguments terms_value, variables_value, kwargs_value
    result = lookup_module.run(terms_value, variables_value, **kwargs_value)

    # Check if result is equal to the expected value
    assert result == "result"

# Generated at 2022-06-25 11:23:38.948761
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # error conditions:
    # Give wrong number of parameters
    input_term_1 = [(dict())]
    result_1 = lookup_module_0.run(input_term_1)
    assert result_1 is None

    input_term_2 = 'wrong type'
    result_2 = lookup_module_0.run(input_term_2)
    assert result_2 is None

    # Pass a dict for the first and a string for the second param
    input_term_3 = ( { "key_a": 1 }, 'value_b' )
    result_3 = lookup_module_0.run(input_term_3)
    assert result_3 == [ ( { "key_a": 1 }, 'value_b' ) ]

    # Pass a dict for the first and a string for the second param
    input_term_4

# Generated at 2022-06-25 11:23:45.793090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:23:48.107940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_0 = ['users1', '.authorized1', 'skip_missing']
    input_1 = {}
    input_2 = {}
    lookup_module_0.run(input_0, input_1, **input_2)

# Generated at 2022-06-25 11:26:42.919863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:26:46.930566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        [
            {'skipped':True}
        ],
        'test',
        {
            'skip_missing':False
        }
    ]
    vars = None
    kwargs = None
    lookup_module.run(
        terms = terms,
        variables = vars,
        **kwargs
    )

# Generated at 2022-06-25 11:26:52.999171
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock variable for class LookupBase
    lookup_module_instance = LookupModule()
    lookup_module_instance._templar = MockTemplar()
    lookup_module_instance._loader = MockLoader()

    assert_equals(lookup_module_instance.run([{'var1': [1, 2]}, 'var1'],
                                             {'var1': [1, 2]}, skip_missing=False), [(1, 1), (1, 2)])

    assert_equals(lookup_module_instance.run([{'var1': {'var2': [1, 2]}}, 'var1.var2'],
                                             {'var1': {'var2': [1, 2]}}, skip_missing=False), [(1, 1), (1, 2)])


# Generated at 2022-06-25 11:26:56.687045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # FIXME: set the real value for input
    input = ['']
    # FIXME: set the real value for variables
    variables = ['']

    # FIXME: implement the test here.
    ret = lookup_module_0.run(input, variables)
    raise NotImplementedError()