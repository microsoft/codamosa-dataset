

# Generated at 2022-06-17 13:09:52.254310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:10:05.254508
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:12.660447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils.parsing.convert_bool import boolean

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

# Generated at 2022-06-17 13:10:19.346613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_module = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:10:32.861031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lm = LookupModule()

    # create a dictionary to use as input

# Generated at 2022-06-17 13:10:44.326277
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:53.932692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a LookupModule object
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:10:59.961914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dicts and a subkey
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:11:12.443760
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:21.981893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    lookup_instance = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:11:34.085823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:11:38.817796
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:47.009355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.vars
    import ansible.utils.unsafe_proxy

    # create a lookup module instance
    lookup_module = ansible.plugins.lookup.subelements.LookupModule()

    # create a templar instance
    templar = ansible.template.Templar(loader=None)

    # create a variable manager instance
    variable_manager = ansible.vars.VariableManager()

    # create a list of dictionaries

# Generated at 2022-06-17 13:11:57.853910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    lookup_instance = LookupModule()

# Generated at 2022-06-17 13:12:10.209600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_instance = LookupModule()

    # check lookup terms - check number of terms
    terms = []
    assert lookup_instance.run(terms, {}) == []
    terms = [1]
    assert lookup_instance.run(terms, {}) == [1]
    terms = [1, 2]
    assert lookup_instance.run(terms, {}) == [1, 2]
    terms = [1, 2, 3]
    assert lookup_instance.run

# Generated at 2022-06-17 13:12:21.823898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # create a play to deal with lookup plugin loading

# Generated at 2022-06-17 13:12:30.477952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-17 13:12:43.945886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # test with empty list
    terms = []
    variables = {}
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms, variables)
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "
    else:
        assert False, "AnsibleError not raised"

    # test with list of one item
    terms = [1]
    variables = {}
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:12:52.801578
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:55.356448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 13:13:19.654651
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:30.494858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lm = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:13:42.565927
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:52.479111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms
            if not isinstance(terms, list) or not 2 <= len(terms) <= 3:
                _raise_terms_error()

            # first term should be a list (or dict), second a string holding the subkey

# Generated at 2022-06-17 13:14:04.654300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iter

# Generated at 2022-06-17 13:14:14.666981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:14:24.471622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test case 1
    terms = [
        {'skipped': False, 'a': {'b': {'c': [1, 2, 3]}}},
        'a.b.c',
        {'skip_missing': False}
    ]
    terms[0] = listify_lookup_plugin_terms(terms[0], templar=None, loader=None)
    # first term should be a list (or dict), second a string holding the subkey
    if not isinstance(terms[0], (list, dict)) or not isinstance(terms[1], string_types):
        raise

# Generated at 2022-06-17 13:14:35.640423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 13:14:45.996495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern
    from ansible.module_utils.six.moves import reload_module

# Generated at 2022-06-17 13:14:56.803711
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:34.708813
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:42.930661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test data

# Generated at 2022-06-17 13:15:54.932809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a mock class for the templar
    class MockTemplar(object):
        def __init__(self, loader):
            self.loader = loader

        def template(self, value, preserve_trailing_newlines=True, escape_backslashes=True, convert_data=True,
                     fail_on_undefined=True, override_vars=None):
            return value

    # create a mock class for the loader
    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self, hostname):
            return "."

    # create a mock class for the variable manager

# Generated at 2022-06-17 13:16:04.494051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_instance = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:16:14.598570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase

    class TestLookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_instance = TestLookupModule()

    # test with empty terms
    terms = []
    result = lookup_instance.run(terms, variables={})
    assert result == []

    # test with one term
    terms = ['one']
    result = lookup_instance.run(terms, variables={})
    assert result == ['one']

    # test with two terms
    terms = ['one', 'two']
    result = lookup_instance

# Generated at 2022-06-17 13:16:25.518570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of LookupModule
    #
    # Args:
    #     None
    #
    # Returns:
    #     None

    # create a LookupModule object
    lookup = LookupModule()

    # create a dictionary with a list of dictionaries

# Generated at 2022-06-17 13:16:35.259707
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:46.590215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        ],
        'authorized',
    ]
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:57.777743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 13:17:10.544039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:18:25.537603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:18:32.042139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_Look

# Generated at 2022-06-17 13:18:43.183906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    class TestCallbackModule(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallbackModule, self).__init__(*args, **kwargs)
            self.results = []


# Generated at 2022-06-17 13:18:51.556836
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:57.933780
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:03.197503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    def test_LookupModule_run_1(mocker):
        mocker.patch('ansible.plugins.lookup.LookupBase._templar', return_value=None)
        mocker.patch('ansible.plugins.lookup.LookupBase._loader', return_value=None)
        mocker.patch('ansible.plugins.lookup.LookupBase.run', return_value=None)
        mocker

# Generated at 2022-06-17 13:19:14.038293
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:21.601528
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:32.499254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)