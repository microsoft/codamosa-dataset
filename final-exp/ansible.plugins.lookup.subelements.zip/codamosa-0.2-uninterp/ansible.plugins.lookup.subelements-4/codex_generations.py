

# Generated at 2022-06-17 13:09:51.971833
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:04.912930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import xrange
   

# Generated at 2022-06-17 13:10:12.402772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vault import VaultLib

    # create a vault password file
    vault_pass_file = StringIO()
    vault_pass_file.write(to_bytes(VaultLib.create_pw_file()))
    vault_pass_file.seek(0)

    # create a vault secret file
    vault_secret_file = String

# Generated at 2022-06-17 13:10:19.219273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries and a subkey
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    variables = {}
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables)

# Generated at 2022-06-17 13:10:32.744003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # import needed modules
    import sys
    import os
    import pytest
    import ansible.plugins.lookup.subelements
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a LookupModule object

# Generated at 2022-06-17 13:10:44.279445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:10:51.670897
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:01.992626
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:05.094347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 13:11:12.763617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    # Setup
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

# Generated at 2022-06-17 13:11:33.555493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text

    # create a dummy class for LookupBase
    class DummyLookupBase(LookupBase):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

    # create a dummy class for AnsibleModule

# Generated at 2022-06-17 13:11:44.412487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:11:54.528038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # test with a list of dictionaries

# Generated at 2022-06-17 13:12:08.241949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init
    lookup = LookupModule()
    lookup.set_options({})
    lookup._templar = None
    lookup._loader = None

    # test
    result = lookup.run([[{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
                          {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}], 'authorized'])

# Generated at 2022-06-17 13:12:20.251904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test with list of dicts

# Generated at 2022-06-17 13:12:26.407245
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:36.320529
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:46.353871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run_1
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:12:56.936523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a LookupModule object
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:13:09.011855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle

# Generated at 2022-06-17 13:13:31.150914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_LookupModule_run_

# Generated at 2022-06-17 13:13:42.990358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_module = LookupModule()

    # check lookup terms - check number of terms
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    # first term should be a list (or dict),

# Generated at 2022-06-17 13:13:53.036651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    FLAGS = ('skip_missing',)

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

# Generated at 2022-06-17 13:13:58.162843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [[{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
              {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}], 'authorized']
    result = LookupModule().run(terms, None)

# Generated at 2022-06-17 13:14:10.036680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 13:14:19.796226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test with a list of dictionaries

# Generated at 2022-06-17 13:14:30.849195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:14:44.359178
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:55.353384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:15:02.719725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class DummyTemplar(object):
        def __init__(self):
            self.basedir = '.'

        def template(self, value):
            return value

    class DummyLoader(object):
        def __init__(self):
            self.path_dwim = lambda x: x

    class DummyVars(object):
        def __init__(self):
            self.hostvars = {}

    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.basedir = '.'

    class DummyPlayContext(object):
        def __init__(self):
            self.prompt = None
            self.connection

# Generated at 2022-06-17 13:15:44.771462
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:53.204038
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:02.147695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 13:16:13.253579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    subelements = LookupModule().run([users, 'authorized'], {})

# Generated at 2022-06-17 13:16:25.050462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # create a mock templar
    templar = mock.MagicMock()
    templar.template.side_effect = lambda x: x
    templar.template_ds.side_effect = lambda x: x

    # create a mock loader
    loader = mock.MagicMock()
    loader.load_from_file.side_effect = lambda x: x

    # create a mock display
    display = mock.MagicMock()

    # create a mock ansible options
    options = mock.MagicMock()
    options.tags = []
    options.skip_tags = []

    # create a mock ansible inventory
    inventory = mock.MagicMock()

    # create a mock ansible variable manager
    variable_manager = mock.MagicMock

# Generated at 2022-06-17 13:16:35.082064
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:46.552649
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:57.746372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:17:10.543922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dicts and subkey
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)

# Generated at 2022-06-17 13:17:21.256953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # test run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create LookupModule object
    lookup_module = LookupModule()

    # create test data

# Generated at 2022-06-17 13:18:33.319354
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:44.046107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lookup_module = LookupModule()

    # create variables
    variables = {}

    # create terms

# Generated at 2022-06-17 13:18:56.049176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {
                "name": "alice",
                "authorized": [
                    "/tmp/alice/onekey.pub",
                    "/tmp/alice/twokey.pub"
                ]
            },
            {
                "name": "bob",
                "authorized": [
                    "/tmp/bob/id_rsa.pub"
                ]
            }
        ],
        "authorized"
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:19:07.395740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar object
    templar = MockTemplar()

    # create a mock loader object
    loader = MockLoader()

    # create a mock variables object
    variables = MockVariables()

    # create a mock ansible module object
    ansible_module = MockAnsibleModule()

    # create a mock ansible module object
    ansible_module = MockAnsibleModule()

    # create a lookup module object
    lookup_module = LookupModule()

    # set the templar object
    lookup_module._templar = templar

    # set the loader object
    lookup_module._loader = loader

    # set the variables object
    lookup_module._available_variables = variables

    # set the ansible module object
    lookup_module._ansible_module = ansible_module

    #

# Generated at 2022-06-17 13:19:13.704728
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:24.573212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = TestLookupModule()
    lookup_plugin._templar = None
    lookup_plugin._loader = None

# Generated at 2022-06-17 13:19:34.100855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a dict
    terms = [{'item1': {'subkey1': [1, 2, 3]}}, 'subkey1']
    lm = LookupModule()
    result = lm.run(terms, None)
    assert result == [({'item1': {'subkey1': [1, 2, 3]}}, 1),
                      ({'item1': {'subkey1': [1, 2, 3]}}, 2),
                      ({'item1': {'subkey1': [1, 2, 3]}}, 3)]

    # test with a list
    terms = [[{'subkey1': [1, 2, 3]}], 'subkey1']
    lm = LookupModule()
    result = lm.run(terms, None)