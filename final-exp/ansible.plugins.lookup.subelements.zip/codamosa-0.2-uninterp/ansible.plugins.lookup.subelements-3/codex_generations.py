

# Generated at 2022-06-17 13:09:53.972059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a lookup module
    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader = loader
    lookup_module._available_variables = variables

    # create a mock users

# Generated at 2022-06-17 13:10:06.590975
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:17.547544
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:30.622902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import zip_longest
    from ansible.module_utils.six.moves import reduce


# Generated at 2022-06-17 13:10:41.832950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3

    # create a mock class for LookupBase
    class LookupBaseMock(LookupBase):
        def __init__(self):
            self._templar = None
            self._loader = None

    # create a mock class for AnsibleModule
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {}

    # create a mock class for AnsibleError

# Generated at 2022-06-17 13:10:50.552133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO

# Generated at 2022-06-17 13:11:01.080007
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:13.549694
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:25.227853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    # check lookup terms - check number of terms
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule().run(terms=[], variables={}, **{})
    assert 'subelements lookup expects a list of two or three items' in str(excinfo.value)

    # first term should be a list (or dict), second a string holding the subkey

# Generated at 2022-06-17 13:11:33.959479
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:54.088440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:12:07.805312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:12:13.472545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

    lookup_module = TestLookupModule()

    # test
    # test with list of dicts
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    result = lookup_module.run(terms, {})

# Generated at 2022-06-17 13:12:23.990945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    result = LookupModule().run(terms, None)

# Generated at 2022-06-17 13:12:31.580080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test data

# Generated at 2022-06-17 13:12:44.728605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import builtins
    import sys
    import os
    import json
    import pytest

    # prepare test data

# Generated at 2022-06-17 13:12:54.530169
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:06.233051
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:16.491367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:13:29.192359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)

# Generated at 2022-06-17 13:13:54.340177
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:06.800486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 13:14:18.039285
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:26.127441
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:36.899551
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:46.173046
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:56.960784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar

    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

    lookup_module = TestLookupModule()
    lookup_module._templar = Templar(loader=None, variables={})

    # test with a list of dictionaries

# Generated at 2022-06-17 13:15:09.613963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:15:16.566212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:15:25.356978
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:03.288894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms

# Generated at 2022-06-17 13:16:13.891605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # create a mock class for LookupBase
    class MockLookupBase(LookupBase):
        def __init__(self, loader=None, templar=None, **kwargs):
            self.loader = loader
            self.templar = templar

        def get_basedir(self, variables):
            return ""

    # create a mock class for AnsibleUnsafeText

# Generated at 2022-06-17 13:16:25.267821
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:35.154611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_instance = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:16:46.552703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test with a list of dictionaries

# Generated at 2022-06-17 13:16:52.981770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    import sys
    import yaml

    class MockTemplar(object):
        def __init__(self):
            pass


# Generated at 2022-06-17 13:17:04.141280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # create a fake vault secret

# Generated at 2022-06-17 13:17:17.366793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:17:27.322821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a lookup module instance
    lookup_module = LookupModule()

    # create a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    # test the lookup module
    result = lookup_module.run([users, 'authorized'], None)

# Generated at 2022-06-17 13:17:41.295301
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:56.655527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a dummy class with a dummy vars dictionary
    class DummyClass(object):
        def __init__(self, vars):
            self.vars = vars

    # create a dummy templar with a dummy loader
    class DummyTemplar(object):
        def __init__(self, loader):
            self.loader = loader


# Generated at 2022-06-17 13:19:07.906441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lm = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:19:14.185454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a lookup module instance
    lookup = LookupModule()

    # create a test variable

# Generated at 2022-06-17 13:19:21.705535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    import sys
    import os
    import json
    import pytest
    import yaml
    import re
    import copy
    import tempfile
    import shutil

    # setup test data

# Generated at 2022-06-17 13:19:32.561744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar object
    templar = MockTemplar()
    # create a mock loader object
    loader = MockLoader()
    # create a mock variable manager object
    variable_manager = MockVariableManager()
    # create a mock inventory object
    inventory = MockInventory()
    # create a mock play context object
    play_context = MockPlayContext()
    # create a mock task object
    task = MockTask()

    # create a lookup module object
    lookup_module = LookupModule()
    # set the templar, loader and variable manager objects
    lookup_module._templar = templar
    lookup_module._loader = loader
    lookup_module._templar.set_available_variables(variable_manager.get_vars(play=play_context, task=task))

    # create a

# Generated at 2022-06-17 13:19:43.601393
# Unit test for method run of class LookupModule