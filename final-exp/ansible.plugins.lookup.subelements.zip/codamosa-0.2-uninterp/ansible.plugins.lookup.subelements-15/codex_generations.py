

# Generated at 2022-06-17 13:09:54.696901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            pass
        def template(self, value):
            return value
    # create a mock loader
    class MockLoader:
        def __init__(self):
            pass
        def get_basedir(self, hostname):
            return "."
    # create a mock variable manager
    class MockVariableManager:
        def __init__(self):
            pass
        def get_vars(self, loader=None, play=None, host=None, task=None):
            return {}
    # create a mock display
    class MockDisplay:
        def __init__(self):
            pass

# Generated at 2022-06-17 13:10:07.162509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries and a subkey
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, {})

# Generated at 2022-06-17 13:10:17.573686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import module
    from ansible.plugins.lookup import subelements

    # create instance of class LookupModule
    lookup_module = subelements.LookupModule()

    # create mock for class AnsibleFile
    class AnsibleFile:
        def __init__(self, filename):
            self.filename = filename
        def __str__(self):
            return self.filename

    # create mock for class AnsibleTemplate
    class AnsibleTemplate:
        def __init__(self, content):
            self.content = content
        def __str__(self):
            return self.content

    # create mock for class AnsibleUnsafeText
    class AnsibleUnsafeText:
        def __init__(self, content):
            self.content = content
        def __str__(self):
            return self.content

    #

# Generated at 2022-06-17 13:10:30.674979
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:41.834509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a dummy templar object
    class DummyVarsModule(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._templar = DummyTemplar(loader=loader)
            self._available_variables = variables


# Generated at 2022-06-17 13:10:48.891623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a lookup module
    lookup_module = LookupModule()

    # set the templar, loader and variables
    lookup_module._templar = templar
    lookup_module._loader = loader
    lookup_module._available_variables = variables

    # create a list of dictionaries

# Generated at 2022-06-17 13:11:00.874156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock options
    options = MockOptions()
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock module_loader
    module_loader = MockModuleLoader()
    # create a mock shared loader plugin
    shared_loader_plugin = MockSharedLoaderPlugin()
    # create a mock task_vars
    task_vars = MockTaskVars()
    # create a mock templar

# Generated at 2022-06-17 13:11:13.373885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with empty list
    assert LookupModule().run([[], 'key'], {}) == []

    # test with list of dicts
    assert LookupModule().run([[{'key': 'value'}, {'key': 'value'}], 'key'], {}) == [({'key': 'value'}, 'value'), ({'key': 'value'}, 'value')]

    # test with list of dicts and subkey
    assert LookupModule().run([[{'key': {'subkey': 'value'}}, {'key': {'subkey': 'value'}}], 'key.subkey'], {}) == [({'key': {'subkey': 'value'}}, 'value'), ({'key': {'subkey': 'value'}}, 'value')]

    # test with list of dicts and sub

# Generated at 2022-06-17 13:11:20.433156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes

    # mock module input
    if PY3:
        builtin_module = 'builtins'
    else:
        builtin_module = '__builtin__'
    builtins_open = getattr(__import__(builtin_module, fromlist=['open']), 'open')
    setattr(builtins, 'open', lambda *args, **kwargs: cStringIO(to_bytes(u'key1')))

    # mock module output

# Generated at 2022-06-17 13:11:29.240431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)

# Generated at 2022-06-17 13:11:45.444712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
         {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}],
        'authorized',
        {'skip_missing': False}
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:11:54.758979
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:08.450318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_text

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:12:20.435184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:12:30.698379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError

    # setup

# Generated at 2022-06-17 13:12:44.469598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None

    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    result = lookup.run(terms, None)

# Generated at 2022-06-17 13:12:53.243546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play
    play = MockPlay()
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock loader plugin
    loader_plugin = MockLoaderPlugin()
    # create a mock templar plugin
    templar_plugin = MockTemplarPlugin()
    # create a mock action plugin
    action_plugin = MockActionPlugin()
    # create a mock shell plugin
    shell_plugin

# Generated at 2022-06-17 13:13:05.613493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:13:16.391148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:13:29.190477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock loader
    class MockLoader:
        def __init__(self):
            pass

        def get_basedir(self, play=None):
            return "."

    # create a mock display
    class MockDisplay:
        def __init__(self):
            pass

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass

    # create a mock variable manager
    class MockVariableManager:
        def __init__(self):
            pass

        def get_vars(self, play=None, host=None, task=None):
            return {}

   

# Generated at 2022-06-17 13:13:54.904655
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:07.540766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            self.result = None
        def template(self, value):
            self.result = value
            return value

    # create a mock loader
    class MockLoader:
        def __init__(self):
            self.result = None
        def load_from_file(self, filename):
            self.result = filename
            return filename

    # create a mock lookup
    class MockLookup:
        def __init__(self):
            self.result = None
        def get_basedir(self, variables):
            self.result = variables
            return variables

    # create a mock ansible module
    class MockAnsibleModule:
        def __init__(self):
            self.result = None

# Generated at 2022-06-17 13:14:16.308171
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:25.158404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self):
            self.result = None

        def template(self, value):
            self.result = value
            return value

    # create a mock loader
    class MockLoader(object):
        def __init__(self):
            self.result = None

        def load(self, value):
            self.result = value
            return value

    # create a mock ansible
    class MockAnsible(object):
        def __init__(self):
            self.result = None

        def get_option(self, value):
            self.result = value
            return value

    # create a mock display
    class MockDisplay(object):
        def __init__(self):
            self.result = None


# Generated at 2022-06-17 13:14:36.341625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    lookup_instance = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:14:46.167521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock options
    options = MockOptions()
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock play
    play = MockPlay()
    # create a mock play_context
    play_context = MockPlayContext()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock

# Generated at 2022-06-17 13:14:56.960173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.listify
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy

    # prepare test data
    users = ansible.parsing.yaml.objects.AnsibleMapping()
    users['alice'] = ansible.parsing.yaml.objects.AnsibleMapping()
    users['alice']['name'] = 'alice'
    users['alice']['authorized'] = ansible.parsing.yaml.objects.AnsibleSequence()
    users['alice']['authorized'].append

# Generated at 2022-06-17 13:15:09.571358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    test_list = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    test_terms = [test_list, 'authorized']
    test_result = LookupModule().run(test_terms, None)

# Generated at 2022-06-17 13:15:16.547174
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:25.354874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock options
    options = MockOptions()
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock play
    play = MockPlay()
    # create a mock play_context
    play_context = MockPlayContext()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock

# Generated at 2022-06-17 13:16:07.337782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    # test_LookupModule_run_basic
    # test_LookupModule_run_basic_dict
    # test_LookupModule_run_basic_dict_skip_missing
    # test_LookupModule_run_basic_dict_skip_missing_true
    # test_LookupModule_run_basic_dict_skip_missing_false
    # test_LookupModule_run_basic_dict_skip_missing_true_and_false
    # test_LookupModule_run_basic_dict_skip_missing_false_and_true
    # test_LookupModule_run_basic_dict_skip_missing

# Generated at 2022-06-17 13:16:16.150521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lm = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:16:26.297506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:35.818573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run: terms: [list, string]
    # test_LookupModule_run: terms: [list, string, dict]
    # test_LookupModule_run: terms: [list, string, dict, dict]
    # test_LookupModule_run: terms: [list, string, dict, dict, dict]
    # test_LookupModule_run: terms: [list, string, dict, dict, dict, dict]
    # test_LookupModule_run: terms: [list,

# Generated at 2022-06-17 13:16:47.255010
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:54.096544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-public-methods
    # pylint: disable=too-many-lines
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-

# Generated at 2022-06-17 13:17:00.638614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    import sys

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)


# Generated at 2022-06-17 13:17:13.385061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # setup test data

# Generated at 2022-06-17 13:17:24.897352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import builtins

    if PY3:
        builtin_module = 'builtins'
    else:
        builtin_module = '__builtin__'

    # setup context
    class TestLookupModule(object):
        def __init__(self, basedir=None):
            self.basedir = basedir
            self.FILTER_PLUGINS = dict()
            self.lookup_loader = None
            self.templar = None

    class TestTemplar(object):
        def __init__(self, variables):
            self.variables = variables


# Generated at 2022-06-17 13:17:33.766247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:18:48.303970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a mock module
    module = MockModule()

    # create a mock display
    display = MockDisplay()

    # create a lookup module
    lookup_module = LookupModule(loader=loader, templar=templar, variables=variables, display=display)

    # create a list of dictionaries

# Generated at 2022-06-17 13:18:57.183538
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:08.265455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a lookup object
    lookup = LookupModule()

    # create a templar object
    templar = lookup._templar

    # create a loader object
    loader = lookup._loader

    # create a list of dictionaries

# Generated at 2022-06-17 13:19:18.004399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = TestLookupModule()

# Generated at 2022-06-17 13:19:29.930785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    FLAGS = ('skip_missing',)

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

# Generated at 2022-06-17 13:19:34.773764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    import sys
    import os
    import json
    import pytest

    # setup
    if PY3:
        builtins_name = 'builtins'

# Generated at 2022-06-17 13:19:45.414473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            pass
        def template(self, value):
            return value
    templar = MockTemplar()

    # create a mock loader
    class MockLoader:
        def __init__(self):
            pass
        def load_from_file(self, filename):
            return filename
    loader = MockLoader()

    # create a mock ansible module
    class MockAnsibleModule:
        def __init__(self):
            pass
        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json was called")
    ansible_module = MockAnsibleModule()

    # create a mock ansible module