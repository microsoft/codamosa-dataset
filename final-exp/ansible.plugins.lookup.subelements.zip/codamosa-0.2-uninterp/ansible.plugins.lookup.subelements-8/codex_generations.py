

# Generated at 2022-06-17 13:09:51.912201
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:04.874776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_

# Generated at 2022-06-17 13:10:15.063927
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:22.145996
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:26.410851
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:36.636419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with a list of dictionaries
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:10:45.150520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_LookupModule_run_11
    # test_LookupModule_run_12
   

# Generated at 2022-06-17 13:10:53.983902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for method run of class LookupModule
    # test for simple case
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    l = LookupModule()

# Generated at 2022-06-17 13:11:04.462342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # create a lookup module
    lookup_module = LookupModule()

    # create a vault
    vault_password = 'vault-password'
    vault_secret = 'vault-secret'

# Generated at 2022-06-17 13:11:14.617651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern
    from ansible.module_utils.six.moves import xrange

# Generated at 2022-06-17 13:11:33.698668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    l = LookupModule()
    result = l.run(terms, None)

# Generated at 2022-06-17 13:11:44.465677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import xrange
   

# Generated at 2022-06-17 13:11:56.306342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = Dict({})
    # create a mock loader
    loader = Dict({})
    # create a mock variables
    variables = Dict({})
    # create a mock terms
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    # create a mock kwargs
    kwargs = Dict({})
    # create a mock LookupModule
    lookup_module = Look

# Generated at 2022-06-17 13:12:09.464995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 13:12:20.935431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes

    # setup test data

# Generated at 2022-06-17 13:12:30.084216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_instance = TestLookupModule()

    # test with invalid terms
    try:
        lookup_instance.run(terms=None)
        assert False, "should have raised an exception"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items"

# Generated at 2022-06-17 13:12:37.378328
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:49.441943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:12:56.725245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock object of class LookupModule
    lookup_module = LookupModule()
    # create a mock object of class AnsibleFile
    ansible_file = AnsibleFile()
    # create a mock object of class AnsibleTemplate
    ansible_template = AnsibleTemplate()
    # create a mock object of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode()
    # create a mock object of class AnsibleVaultEncryptedFile
    ansible_vault_encrypted_file = AnsibleVaultEncryptedFile()
    # create a mock object of class AnsibleVaultEncryptedText
    ansible_vault_encrypted_text = AnsibleVaultEncryptedText()
    # create a mock object of class AnsibleVaultEncryptedUnicode


# Generated at 2022-06-17 13:13:08.699896
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:34.098297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        ],
        'authorized'
    ]
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:13:43.838786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return []

    lookup_module = LookupModule()

    # check lookup terms - check number of terms
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run([], {})
    assert 'subelements lookup expects a list of two or three items' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        lookup

# Generated at 2022-06-17 13:13:55.484867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    l = LookupModule()

    # check lookup terms - check number of terms
    try:
        l.run([], {})
        assert False, "should have raised an error"
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "

    # first term should be a list (or dict), second a string holding the subkey

# Generated at 2022-06-17 13:14:07.890548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a lookup module
    lookup_module = LookupModule(loader=loader, templar=templar, variables=variables)

    # create a mock terms

# Generated at 2022-06-17 13:14:16.330690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return super(LookupModule, self).run(terms, variables, **kwargs)

    lookup_instance = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:14:25.187569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock class for templar
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock class for loader
    class MockLoader(object):
        def __init__(self):
            pass

        def load_from_file(self, value):
            return value

    # create a mock class for ansible
    class MockAnsible(object):
        def __init__(self):
            pass

        def __getattr__(self, name):
            if name == '_templar':
                return MockTemplar()
            elif name == '_loader':
                return MockLoader()
            else:
                return None

    # create a mock class for ansible.utils.listify

# Generated at 2022-06-17 13:14:31.690089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8


# Generated at 2022-06-17 13:14:42.434681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    import pytest
    import sys
    import os

    # create a dummy lookup class
    class LookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_instance = LookupModule()

    # create a dummy templar class

# Generated at 2022-06-17 13:14:53.090789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a mock module
    module = MockModule()

    # create a mock display
    display = MockDisplay()

    # create a mock connection
    connection = MockConnection()

    # create a mock play context
    play_context = MockPlayContext()

    # create a mock inventory
    inventory = MockInventory()

    # create a mock task
    task = MockTask()

    # create a mock play
    play = MockPlay()

    # create a mock set_loader
    set_loader = MockSetLoader()

    # create a mock set_connection
    set_connection = MockSetConnection()

    # create a mock set_play_

# Generated at 2022-06-17 13:15:01.002713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle

# Generated at 2022-06-17 13:15:41.390626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #     None
    #
    # Returns:
    #     None

    # create an instance of LookupModule
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:15:54.037862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_module = LookupModule()

    # test with a list of two items

# Generated at 2022-06-17 13:16:02.202921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]

# Generated at 2022-06-17 13:16:06.184568
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:15.591496
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:25.577861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # create a dummy templar
    class DummyTemplar(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables


# Generated at 2022-06-17 13:16:35.295568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_module = TestLookupModule()


# Generated at 2022-06-17 13:16:46.590641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    if PY3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    # create mock objects
    templar = MagicMock()
    loader = MagicMock()

    # create instance of LookupModule
    lookup_plugin = LookupModule()
    lookup_plugin._templar = templar
    lookup_plugin._loader = loader

    # create test data

# Generated at 2022-06-17 13:16:57.808556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    # check lookup terms - check number of terms
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    # first term should be a list (or dict), second a string holding the subkey

# Generated at 2022-06-17 13:17:02.820257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = LookupModule()

    # test with a list of two items

# Generated at 2022-06-17 13:18:14.548229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock class for the templar
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock class for the loader
    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self, play=None):
            return "/tmp"

    # create a mock class for the lookup_loader
    class MockLookupLoader(object):
        def __init__(self):
            pass

        def get(self, name, class_only=False):
            return LookupModule

    # create a mock class for the variables
    class MockVars(object):
        def __init__(self):
            pass


# Generated at 2022-06-17 13:18:25.663746
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:32.120310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar object
    templar = MockTemplar()

    # create a mock loader object
    loader = MockLoader()

    # create a mock variables object
    variables = MockVariables()

    # create a mock module object
    module = MockModule()

    # create a mock connection object
    connection = MockConnection()

    # create a mock play context object
    play_context = MockPlayContext()

    # create a mock inventory object
    inventory = MockInventory()

    # create a mock task object
    task = MockTask()

    # create a mock play object
    play = MockPlay()

    # create a mock set_loader object
    set_loader = MockSetLoader()

    # create a mock cli object
    cli = MockCLI()

    # create a mock options object
    options = MockOptions()

# Generated at 2022-06-17 13:18:43.251860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

# Generated at 2022-06-17 13:18:55.526084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # test run method of class LookupModule
    # test case 1:
    #   test run method of class LookupModule with a list of two items
    #   the first item is a list of dictionaries, the second item is a string holding the subkey
    #   the subkey is a key in the dictionaries
    #   the subkey points to a list
    #   the subkey is not the last subkey
    #   the subkey points to a list of dictionaries
    #   the subkey points to

# Generated at 2022-06-17 13:18:56.693796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 13:19:07.932791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:19:19.002701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # init
    lookup_module = LookupModule()

    # test
    # test 1: test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:19:30.926262
# Unit test for method run of class LookupModule