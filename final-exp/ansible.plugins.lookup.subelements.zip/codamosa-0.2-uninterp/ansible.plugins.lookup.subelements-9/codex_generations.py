

# Generated at 2022-06-17 13:09:53.205649
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:05.949186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip

    # create a dummy class for the templar
    class DummyTemplar(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables


# Generated at 2022-06-17 13:10:17.487986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=None)

# Generated at 2022-06-17 13:10:30.591156
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:43.608652
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:51.251149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    class Options(object):
        def __init__(self, connection='local', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False, diff=False):
            self.connection = connection
            self.module_path = module_path
            self.forks = forks
            self.become = become
            self.become_method = become_method
            self.become_user = become

# Generated at 2022-06-17 13:11:01.679093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_Look

# Generated at 2022-06-17 13:11:14.055562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-17 13:11:25.260746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test
    lookup = LookupModule()
    lookup.set_options({})
    lookup._templar = None
    lookup._loader = None

    # test with empty terms
    terms = []
    variables = {}
    try:
        lookup.run(terms, variables)
        assert False
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "

    # test with wrong number of terms
    terms = [1, 2, 3, 4]
    variables = {}
    try:
        lookup.run(terms, variables)
        assert False
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "

    # test with wrong type of first term
    terms = [1, 2]


# Generated at 2022-06-17 13:11:33.933257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test setup
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

    # test data

# Generated at 2022-06-17 13:11:47.603570
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:57.957704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # create a mock loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # create a mock inventory
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=loader, sources='')

    # create a mock variable manager
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a mock play context
    from ansible.playbook.play import Play
    play_context = Play().set_loader(loader)

    # create a mock options
    from ansible.cli.adhoc import AdHocCLI
    options = AdHoc

# Generated at 2022-06-17 13:12:10.267439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    lookup_module = LookupModule()
    terms = [
        [
            {
                "name": "alice",
                "authorized": [
                    "/tmp/alice/onekey.pub",
                    "/tmp/alice/twokey.pub"
                ]
            },
            {
                "name": "bob",
                "authorized": [
                    "/tmp/bob/id_rsa.pub"
                ]
            }
        ],
        "authorized"
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:12:22.059465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self):
            self.template_data = dict()

# Generated at 2022-06-17 13:12:30.682546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    # test for error when terms is not a list
    terms = "not a list"
    variables = {}
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms, variables)
        assert False, "should have raised an exception"
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e)

    # test for error when terms is a list but not of 2 or 3 items
    terms = ["not", "enough", "items"]
    variables = {}
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:12:44.468207
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:53.244167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self):
            self.result = None
            self.template = None
            self.vars = None

        def template(self, template, vars):
            self.template = template
            self.vars = vars
            return self.result

    # create a mock loader
    class MockLoader(object):
        def __init__(self):
            self.paths = None

        def get_basedir(self, paths):
            self.paths = paths
            return None

    # create a mock display
    class MockDisplay(object):
        def __init__(self):
            self.display = None


# Generated at 2022-06-17 13:13:05.613731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar object
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock loader object
    class MockLoader(object):
        def __init__(self):
            pass

        def load_from_file(self, filename):
            return filename

    # create a mock variable manager object
    class MockVariableManager(object):
        def __init__(self):
            pass

        def get_vars(self, loader=None, play=None, host=None, task=None):
            return {}

    # create a mock display object
    class MockDisplay(object):
        def __init__(self):
            pass


# Generated at 2022-06-17 13:13:16.390118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 13:13:29.190600
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:52.525368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock loader
    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self, *args, **kwargs):
            return "/"

    # create a mock display
    class MockDisplay(object):
        def __init__(self):
            pass

        def display(self, *args, **kwargs):
            pass

    # create a mock ansible
    class MockAnsible(object):
        def __init__(self):
            self.display = MockDisplay()

    # create a mock ansible options

# Generated at 2022-06-17 13:13:58.703878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import Ansible

# Generated at 2022-06-17 13:14:10.340131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=None)

# Generated at 2022-06-17 13:14:22.721142
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:31.312332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy class for LookupModule
    class DummyLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

    # create a dummy class for AnsibleModule
    class DummyAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    # create a dummy class for AnsibleTemplar
    class DummyAnsibleTemplar(object):
        def __init__(self, **kwargs):
            pass

        def template(self, value):
            return value

    # create a dummy class for AnsibleLoader

# Generated at 2022-06-17 13:14:42.400376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    import pytest
    import sys
    import os
    import json
    import tempfile
    import shutil
    import copy
    import yaml

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create the temporary files
    (fd, lookupfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    (fd, lookupfile2) = tempfile.mkstemp(dir=tmpdir)
    os

# Generated at 2022-06-17 13:14:53.046078
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:00.974780
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:13.061974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # import modules
    import sys
    import os
    import pytest
    import tempfile
    import shutil
    import json
    import yaml

    # set up paths
    test_dir = os.path.dirname(os.path.realpath(__file__))
    ansible_dir = os.path.dirname(os.path.dirname(test_dir))
    sys.path.append(ansible_dir)

    # import modules
    from ansible.plugins.lookup import subelements

    # create temp directory
    tmpdir = tempfile.mkd

# Generated at 2022-06-17 13:15:24.339313
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:02.089740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:16:13.252525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)
    assert result == [('alice', '/tmp/alice/onekey.pub'), ('alice', '/tmp/alice/twokey.pub'), ('bob', '/tmp/bob/id_rsa.pub')]

    # Test with a dictionary of dictionaries

# Generated at 2022-06-17 13:16:24.891945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries and a subkey
    lookup_module = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:35.042628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 13:16:45.179154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        }
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:52.209322
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:59.229923
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:11.664681
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:21.850283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_LookupModule_run

# Generated at 2022-06-17 13:17:33.088385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:18:44.596977
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:56.215242
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:07.530410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create lookup module
    lookup_module = LookupModule()

    # create test data

# Generated at 2022-06-17 13:19:13.801330
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:24.676416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    import json

# Generated at 2022-06-17 13:19:34.151966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:19:44.962411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    FLAGS = ('skip_missing',)

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)