

# Generated at 2022-06-17 13:09:54.221766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with two terms
    lookup_module = LookupModule()
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:10:06.806623
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:17.547367
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:30.623916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range

    class LookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_module

# Generated at 2022-06-17 13:10:43.634436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dictionaries
    test_list = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'groups': ['wheel']}
    ]
    # test with list of dictionaries and skip_missing
    test_list_skip_missing = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]


# Generated at 2022-06-17 13:10:51.299669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:11:01.714995
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:14.115610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:11:25.258566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

    # Test with a list of dictionaries

# Generated at 2022-06-17 13:11:33.932619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_instance = LookupModule()

    # test with list of two items

# Generated at 2022-06-17 13:11:54.016181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = None
    l._loader = None
    l._templar.available_variables = dict()
    l._templar.available_variables['users'] = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

# Generated at 2022-06-17 13:11:59.828715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with two terms
    terms = [
        [
            {
                "name": "alice",
                "authorized": [
                    "/tmp/alice/onekey.pub",
                    "/tmp/alice/twokey.pub"
                ]
            },
            {
                "name": "bob",
                "authorized": [
                    "/tmp/bob/id_rsa.pub"
                ]
            }
        ],
        "authorized"
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:12:09.433148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self):
            self.template_data = {}

        def template(self, variable, convert_bare=True, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, override_vars=None):
            return self.template_data.get(variable, variable)

    # create a mock loader
    class MockLoader(object):
        def __init__(self):
            self.paths = []

        def get_basedir(self, hostname):
            return self.paths

    # create a mock ansible
    class MockAnsible(object):
        def __init__(self):
            self.templar = MockTemplar()
            self.loader = Mock

# Generated at 2022-06-17 13:12:14.445752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    # test with list of dictionaries

# Generated at 2022-06-17 13:12:22.677750
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:33.557285
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:45.525030
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:56.089527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a lookup module
    lookup_module = LookupModule()

    # set the templar, loader and variables
    lookup_module._templar = templar
    lookup_module._loader = loader
    lookup_module._available_variables = variables

    # create a list of dictionaries

# Generated at 2022-06-17 13:13:07.884413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a dummy class that can be used to test the lookup module
    class DummyClass(object):
        def __init__(self, loader, templar, **kwargs):
            self._loader = loader
            self._templar = templar

    # create a dummy templar

# Generated at 2022-06-17 13:13:17.393414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run_subelements_lookup_expects_a_list_of_two_or_three_items
    try:
        LookupModule().run(
            terms=[],
            variables={},
            **{}
        )
        assert False
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "

    # test_LookupModule_run_subelements_lookup_expects_a_list_of_two_or_three_items_msg

# Generated at 2022-06-17 13:13:43.355373
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:53.438506
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:05.780694
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:15.721852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms
            if not isinstance(terms, list) or not 2 <= len(terms) <= 3:
                _raise_terms_error

# Generated at 2022-06-17 13:14:24.838834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:14:36.016463
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:46.097398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock options
    options = MockOptions()
    # create a lookup module
    lookup_module = LookupModule(loader=loader, variable_manager=variable_manager, play_context=play_context)

    # create a list of dictionaries

# Generated at 2022-06-17 13:14:56.882805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    # setup test data

# Generated at 2022-06-17 13:15:09.442218
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:21.217862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test data

# Generated at 2022-06-17 13:16:02.029080
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:13.251933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a lookup module
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:16:24.897567
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:35.044469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    l = LookupModule()
    result = l.run(terms, None)

# Generated at 2022-06-17 13:16:46.559444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_plugin = LookupModule()

    # test with a list of two items

# Generated at 2022-06-17 13:16:57.746494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test with list of dictionaries

# Generated at 2022-06-17 13:17:10.544576
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:19.664920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms


# Generated at 2022-06-17 13:17:27.716284
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:41.407542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.listify
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy


# Generated at 2022-06-17 13:18:56.580665
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:07.845110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes

    # create a dummy templar
    class DummyTemplar(object):
        def __init__(self):
            self.environment = None
        def set_available_variables(self, variables):
            self.environment = variables

# Generated at 2022-06-17 13:19:14.003792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _test_run(terms, expected_result, expected_error=None):
        lookup_module = LookupModule()
        if expected_error:
            try:
                result = lookup_module.run(terms, None)
            except Exception as e:
                assert str(e) == expected_error
            else:
                assert False, "Expected error: %s" % expected_error
        else:
            result = lookup_module.run(terms, None)
            assert result == expected_result

    # test_run
    _test_run([], "subelements lookup expects a list of two or three items")
    _test_run([[], "key"], "subelements lookup expects a list of two or three items")

# Generated at 2022-06-17 13:19:21.574925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes

    # setup

# Generated at 2022-06-17 13:19:32.464472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock templar
    class MockTemplar:
        def __init__(self):
            pass
        def template(self, value):
            return value
    templar = MockTemplar()

    # Create a mock loader
    class MockLoader:
        def __init__(self):
            pass
        def get_basedir(self, play=None):
            return "."
    loader = MockLoader()

    # Create a mock variable manager
    class MockVariableManager:
        def __init__(self):
            pass
        def get_vars(self, play=None, host=None, task=None):
            return {}
    variable_manager = MockVariableManager()

    # Create a mock display
    class MockDisplay:
        def __init__(self):
            pass

# Generated at 2022-06-17 13:19:43.546654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils._text import to_text

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_instance = LookupModule()

    # test with a list of dictionaries