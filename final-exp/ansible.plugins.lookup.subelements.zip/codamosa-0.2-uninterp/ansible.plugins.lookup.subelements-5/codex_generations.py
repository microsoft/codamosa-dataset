

# Generated at 2022-06-17 13:09:53.229466
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:05.949177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 13:10:17.486891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 13:10:30.579234
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:41.793316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    # test with a list of dictionaries

# Generated at 2022-06-17 13:10:50.525549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a dummy class with a dummy templar

# Generated at 2022-06-17 13:11:01.039687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY2

    # test_LookupModule_run_1
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:11:13.552440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import cmp
   

# Generated at 2022-06-17 13:11:25.227739
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:33.905509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):
            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms
            if not isinstance(terms, list) or not 2 <= len(terms) <= 3:
                _raise_terms_error()

# Generated at 2022-06-17 13:11:54.088971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

   

# Generated at 2022-06-17 13:12:07.805698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_Look

# Generated at 2022-06-17 13:12:11.876610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 13:12:20.663483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with empty list
    lookup_module = LookupModule()
    assert lookup_module.run([[], 'key'], {}) == []

    # test with list of dicts
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

# Generated at 2022-06-17 13:12:30.875762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}
    ]
    # test with a dictionary of dictionaries

# Generated at 2022-06-17 13:12:38.941883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern
    from ansible.module_utils.six.moves import long

# Generated at 2022-06-17 13:12:50.878302
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:57.802050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    display.verbosity = 3

    # test data
    users

# Generated at 2022-06-17 13:13:09.841423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with empty list
    assert LookupModule().run([[], 'key'], {}) == []

    # test with list of dicts
    assert LookupModule().run([[{'key': 'value'}], 'key'], {}) == [({'key': 'value'}, 'value')]

    # test with list of dicts and subkey
    assert LookupModule().run([[{'key': {'subkey': 'value'}}], 'key.subkey'], {}) == [({'key': {'subkey': 'value'}}, 'value')]

    # test with list of dicts and subkey

# Generated at 2022-06-17 13:13:19.612323
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:47.557706
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:56.850916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10
    # test_Look

# Generated at 2022-06-17 13:14:09.186617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play
    play = MockPlay()
    # create a mock task
    task = MockTask()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock connection
    connection = MockConnection()
    # create a mock module
    module = MockModule()
    # create a mock module_utils
    module_utils = MockModuleUtils()
    # create a mock module_utils.basic
    module_utils_basic = MockModuleUtilsBasic()
    # create a mock module_utils.basic.Ans

# Generated at 2022-06-17 13:14:19.351858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()
    # create a mock loader
    loader = MockLoader()
    # create a mock variable manager
    variable_manager = MockVariableManager()
    # create a mock inventory
    inventory = MockInventory()
    # create a mock play
    play = MockPlay()
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock play context
    play_context = MockPlayContext()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()

    # create a lookup module
    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader = loader

# Generated at 2022-06-17 13:14:30.883988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import filter

# Generated at 2022-06-17 13:14:44.361051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources='')

    # create a fake variable manager
    variable_manager = VariableManager

# Generated at 2022-06-17 13:14:55.395574
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:02.076887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):
            return terms

    lookup_module = LookupModule()

    # test with list of dictionaries

# Generated at 2022-06-17 13:15:13.792651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:15:22.098348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    # mock class
    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    # test run method
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []
    assert lookup_module.run([1], {}) == [1]
    assert lookup_module.run([1, 2], {}) == [1, 2]
    assert lookup_module.run([1, 2, 3], {})

# Generated at 2022-06-17 13:16:02.149002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a dummy class to test the LookupModule
    class DummyLookupModule(LookupModule):
        def __init__(self, basedir=None, runner=None, **kwargs):
            self.basedir = basedir
            self.runner = runner
            self.vars = dict()
            self

# Generated at 2022-06-17 13:16:13.253553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.vars
    import ansible.utils.listify
    import ansible.utils.unsafe_proxy
    import ansible.utils.vars

    # create a templar
    templar = ansible.template.Templar(loader=None)

    # create a variable manager
    variable_manager = ansible.vars.VariableManager()

    # create a loader
    loader = ansible.parsing.dataloader.DataLoader()

    # create a lookup module
    lookup_module = ansible.plugins.lookup.subelements.LookupModule()

    # set the templar
    lookup_module._templar = templar



# Generated at 2022-06-17 13:16:15.156096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit tests
    pass

# Generated at 2022-06-17 13:16:20.934231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:16:31.183003
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:43.267423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    # test with list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

# Generated at 2022-06-17 13:16:51.242365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError

    # define test data

# Generated at 2022-06-17 13:16:59.868543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the AnsibleModule class
    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    # mock the AnsibleModule class
    class AnsibleLookupBaseMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    # create an instance of the Ansible lookup class to test
    lookup_obj = LookupModule()

    # create a mock Ansible module
    ansible_module_mock = AnsibleModuleMock(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=False,
    )

    # create a mock Ansible lookup base
    ansible_lookup_base_mock = AnsibleLookupBaseMock

# Generated at 2022-06-17 13:17:04.512941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create an instance of the LookupModule class
    lookup_module = LookupModule()

    # create a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    # create a list of terms
    terms = [users, 'authorized']

    # call the run method
    result = lookup_module.run(terms, None)

    # assert the result

# Generated at 2022-06-17 13:17:17.691780
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:29.504475
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:42.640178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:18:51.537738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:18:57.934891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = TestLookupModule()
    lookup_plugin._templar = None
    lookup_plugin._loader = None

    # test with empty terms
    assert lookup_plugin

# Generated at 2022-06-17 13:19:08.277197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # test with a list of two items

# Generated at 2022-06-17 13:19:18.003791
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:29.930213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a test object
    lookup_module = LookupModule()

    # create a test list

# Generated at 2022-06-17 13:19:34.757461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lm = LookupModule()

    # create a list of dictionaries