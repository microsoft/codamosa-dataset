

# Generated at 2022-06-17 13:09:53.208424
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:05.949483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test data

# Generated at 2022-06-17 13:10:17.486891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_

# Generated at 2022-06-17 13:10:30.580813
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:41.793228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:10:48.864541
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:00.876182
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:13.375480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, dict())

# Generated at 2022-06-17 13:11:22.350920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_module = TestLookupModule()
    lookup_module.set_options({})

    # check lookup terms - check number of terms

# Generated at 2022-06-17 13:11:33.662695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern
    from ansible.module_utils.six.moves import xrange

# Generated at 2022-06-17 13:11:54.015469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:12:07.969006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of LookupModule class
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # create a test dictionary

# Generated at 2022-06-17 13:12:19.983722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock loader
    class MockLoader(object):
        def __init__(self):
            pass

        def load_from_file(self, filename):
            return filename

    # create a mock display
    class MockDisplay(object):
        def __init__(self):
            pass

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            return msg

    # create a mock lookup_loader
    class MockLookupLoader(object):
        def __init__(self):
            pass


# Generated at 2022-06-17 13:12:26.298655
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:34.216316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    import pytest

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms


# Generated at 2022-06-17 13:12:42.965051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            self.result = None
        def template(self, value):
            self.result = value
            return value
    templar = MockTemplar()

    # create a mock loader
    class MockLoader:
        def __init__(self):
            self.result = None
        def load_from_file(self, filename):
            self.result = filename
            return filename
    loader = MockLoader()

    # create a mock variables
    variables = {}

    # create a mock terms

# Generated at 2022-06-17 13:12:50.659031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        {'name': 'charlie', 'authorized': ['/tmp/charlie/id_rsa.pub'], 'groups': ['wheel']}
    ]
    terms = [users, 'authorized']
    l = LookupModule()
    ret = l.run(terms, None)

# Generated at 2022-06-17 13:12:57.643356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import range


# Generated at 2022-06-17 13:13:09.709150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        ],
        'authorized'
    ]
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:13:19.606471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the method run of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # create instance of LookupModule
    lookup_module = LookupModule()

    # create test data

# Generated at 2022-06-17 13:13:44.007365
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:52.481686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
   

# Generated at 2022-06-17 13:13:59.630390
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:10.998380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:14:23.511201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    # test with a list of dictionaries and a subkey
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    subkey = 'authorized'

# Generated at 2022-06-17 13:14:34.712497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a LookupModule instance
    lm = LookupModule()

    # create a test dictionary

# Generated at 2022-06-17 13:14:45.861623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:14:56.802355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dicts
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:15:09.356422
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:21.058517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8
    # test_LookupModule_run_9
    # test_LookupModule_run_10

# Generated at 2022-06-17 13:16:02.028226
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:13.251736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms

# Generated at 2022-06-17 13:16:24.891556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:35.042448
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:46.556689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    import pytest

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_instance = LookupModule()

    # check lookup terms - check number of terms
    with pytest.raises(AnsibleError) as excinfo:
        lookup_instance.run([], {})
    assert excinfo.value.message == "subelements lookup expects a list of two or three items, "


# Generated at 2022-06-17 13:16:57.747305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()

        def tearDown(self):
            pass


# Generated at 2022-06-17 13:17:10.548361
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:21.224490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    l = LookupModule()

# Generated at 2022-06-17 13:17:33.059213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms


# Generated at 2022-06-17 13:17:40.793894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # Test
    # Test: first term should be a list (or dict), second a string holding the subkey

# Generated at 2022-06-17 13:18:48.665260
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:18:57.514048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

# Generated at 2022-06-17 13:19:08.292423
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:18.006156
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:29.929384
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:34.757095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
