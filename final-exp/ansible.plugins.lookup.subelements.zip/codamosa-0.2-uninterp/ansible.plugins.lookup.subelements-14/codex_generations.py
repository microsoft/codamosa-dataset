

# Generated at 2022-06-17 13:09:54.038347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dictionaries
    lookup_module = LookupModule()
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        ],
        'authorized',
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:10:06.655016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {
                "name": "alice",
                "authorized": [
                    "/tmp/alice/onekey.pub",
                    "/tmp/alice/twokey.pub"
                ]
            },
            {
                "name": "bob",
                "authorized": [
                    "/tmp/bob/id_rsa.pub"
                ]
            }
        ],
        "authorized"
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:10:17.547712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import json

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 13:10:30.623490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_

# Generated at 2022-06-17 13:10:41.832702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # imports
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import json
    import os
    import sys
    import unittest

    # create a dummy callback plugin
    class CallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'dummy'



# Generated at 2022-06-17 13:10:50.551953
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:01.079492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import json

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 13:11:13.548687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:11:25.227867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase

    # prepare test data

# Generated at 2022-06-17 13:11:33.905484
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:54.184290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # mock class LookupBase
    class LookupBaseMock(LookupBase):
        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar

    # mock class AnsibleError
    class AnsibleErrorMock(AnsibleError):
        def __init__(self, msg):
            self.msg = msg

    # mock class boolean


# Generated at 2022-06-17 13:12:07.851157
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:19.798638
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:29.972291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test data

# Generated at 2022-06-17 13:12:43.794830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variable manager
    variable_manager = MockVariableManager()

    # create a mock inventory
    inventory = MockInventory()

    # create a mock play context
    play_context = MockPlayContext()

    # create a mock options
    options = MockOptions()

    # create a mock task
    task = MockTask()

    # create a mock connection
    connection = MockConnection()

    # create a mock module_loader
    module_loader = MockModuleLoader()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock module_utils
    module_utils

# Generated at 2022-06-17 13:12:51.328272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    templar = MockTemplar()

    # create a mock loader
    loader = MockLoader()

    # create a mock variables
    variables = MockVariables()

    # create a mock module
    module = MockModule()

    # create a mock display
    display = MockDisplay()

    # create a mock connection
    connection = MockConnection()

    # create a mock play
    play = MockPlay()

    # create a mock inventory
    inventory = MockInventory()

    # create a mock task
    task = MockTask()

    # create a mock play context
    play_context = MockPlayContext()

    # create a mock options
    options = MockOptions()

    # create a mock loader plugin
    loader_plugin = MockLoaderPlugin()

    # create a mock templar plugin
    templar_

# Generated at 2022-06-17 13:12:58.099042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            self.template_data = {}

        def template(self, variable, convert_bare=True, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, overrides=None, convert_data=True, strip_comments=True):
            return self.template_data.get(variable, variable)

    # create a mock loader
    class MockLoader:
        def __init__(self):
            self.paths = []

        def get_basedir(self, path):
            return self.paths[0]

    # create a mock variable manager
    class MockVariableManager:
        def __init__(self):
            self.vars = {}


# Generated at 2022-06-17 13:13:10.168228
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:18.490235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle

# Generated at 2022-06-17 13:13:29.869543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy class for the lookup plugin
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Runner(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class TmpVars(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class PlayContext(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Inventory(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-17 13:13:55.866616
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:08.270785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_instance = LookupModule()

    # check lookup terms - check number of terms
    with pytest.raises(AnsibleError) as excinfo:
        lookup_instance.run([], {})
    assert 'subelements lookup expects a list of two or three items' in str(excinfo.value)

    # first term should be a list (or dict), second a string holding the subkey


# Generated at 2022-06-17 13:14:18.912262
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:30.777261
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:41.059674
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:47.078583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 13:14:57.594739
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:10.180197
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:21.119005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle

# Generated at 2022-06-17 13:15:33.818512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dicts
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    lookup_module = LookupModule()
    result = lookup_module.run([users, 'authorized'], None)

# Generated at 2022-06-17 13:16:15.858451
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:25.959196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock object for the templar
    class MockTemplar(object):
        def __init__(self):
            self.template_data = {}

        def template(self, value, preserve_trailing_newlines=True, escape_backslashes=True, convert_data=True,
                     fail_on_undefined=True, override_vars=None):
            return value

    # create a mock object for the loader
    class MockLoader(object):
        def __init__(self):
            self.paths = []

    # create a mock object for the lookup
    class MockLookup(object):
        def __init__(self):
            self._templar = MockTemplar()
            self._loader = MockLoader()

    # create a mock object for the ansible error

# Generated at 2022-06-17 13:16:35.579702
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:47.712600
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:56.392380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        """
        Test callback module
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'


# Generated at 2022-06-17 13:17:08.538699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            self.template_data = {}

        def template(self, var):
            return self.template_data[var]

    # create a mock loader
    class MockLoader:
        def __init__(self):
            self.paths = []

        def path_dwim(self, path):
            return self.paths[path]

    # create a mock display
    class MockDisplay:
        def __init__(self):
            self.display = []

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.display.append(msg)

    # create a mock lookup

# Generated at 2022-06-17 13:17:19.915572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    lookup_module = LookupModule()

    # check lookup terms - check number of terms
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run([], {})
    assert 'subelements lookup expects a list of two or three items' in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        lookup

# Generated at 2022-06-17 13:17:27.834557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # mock the templar
    class MockTemplar(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables

        def template(self, data, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, convert_data=True, strip_comments=True, remove_blank_lines=True):
            return data

    # mock the loader

# Generated at 2022-06-17 13:17:39.228968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test setup
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import copyreg
    from ansible.module_utils.six.moves import queue
    from ansible.module_utils.six.moves import UserDict
    from ansible.module_utils.six.moves import UserList
    from ansible.module_utils.six.moves import UserString

# Generated at 2022-06-17 13:17:51.577054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms

# Generated at 2022-06-17 13:19:07.654611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test method run of class LookupModule

    # setup
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_text

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):
            return terms

    # test
    lookup_module = LookupModule

# Generated at 2022-06-17 13:19:17.967023
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:29.886371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # create a mock inventory
    inventory = InventoryManager(loader=None, sources='')

    # create a mock variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-17 13:19:41.164960
# Unit test for method run of class LookupModule