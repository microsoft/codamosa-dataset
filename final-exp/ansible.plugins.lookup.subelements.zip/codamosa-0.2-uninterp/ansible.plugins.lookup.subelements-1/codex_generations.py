

# Generated at 2022-06-17 13:09:52.788458
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:05.793195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lookup_plugin = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:10:17.487481
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:30.527590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    class LookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:10:41.799162
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:46.757939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import iteritems

    # create a mock templar
    class MockTemplar(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables

        def template(self, data, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, override_vars=None):
            if override_vars:
                self._available_variables.update(override_vars)
            if isinstance(data, string_types):
                return self._available_variables.get(data, data)

# Generated at 2022-06-17 13:10:54.417967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    test_list = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    test_terms = [test_list, 'authorized']
    test_result = LookupModule().run(test_terms, None)

# Generated at 2022-06-17 13:11:04.675927
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:14.771936
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:25.316416
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:44.329672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    FLAGS = ('skip_missing',)

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

# Generated at 2022-06-17 13:11:56.196031
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:09.350496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create test object
    lookup = LookupModule()

    # create test data

# Generated at 2022-06-17 13:12:20.495312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a dummy class for the lookup plugin
    class DummyLookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    # create a dummy templar
    class DummyTemplar(object):
        def __init__(self, variables):
            self.variables = variables

        def template(self, term):
            return self.variables.get(term, None)

    # create a dummy loader

# Generated at 2022-06-17 13:12:30.040766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    FLAGS = ('skip_missing',)

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

# Generated at 2022-06-17 13:12:37.357357
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:12:49.398039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()
    lookup_module.set_options({'skip_missing': False})

# Generated at 2022-06-17 13:12:56.700386
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:08.643236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    # Create a lookup module instance
    lookup_module = LookupModule()

    # Create a templar instance
    templar = lookup_module._templar

    # Create a loader instance
    loader = lookup_module._loader

    # Create a list of dictionaries

# Generated at 2022-06-17 13:13:17.762466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    # test with a list of dicts

# Generated at 2022-06-17 13:13:43.872428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:13:53.915085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dicts
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:14:06.338493
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:16.088956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes

    # create a dummy class with a dummy templar
    class DummyClass(object):
        def __init__(self):
            self.templar = DummyTemplar()

    # create a dummy templar
    class DummyTemplar(object):
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a dummy loader
    class DummyLoader(object):
        def __init__(self):
            pass

        def get_basedir(self, *args, **kwargs):
            return "/"

    # create a dummy display
   

# Generated at 2022-06-17 13:14:25.033908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle

# Generated at 2022-06-17 13:14:36.199765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import pickle
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern

# Generated at 2022-06-17 13:14:46.143400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a lookup module instance
    lookup_module = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:14:56.921200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test
    import ansible.plugins.lookup
    import ansible.parsing.yaml.objects
    import ansible.utils.listify
    import ansible.utils.unsafe_proxy
    import ansible.vars.unsafe_proxy
    import ansible.vars.manager
    import ansible.template
    import ansible.template.safe_eval
    import ansible.template.vars
    import ansible.template.template
    import ansible.template.jinja2.environment
    import ansible.template.jinja2.filters
    import ansible.template.jinja2.function
    import ansible.template.jinja2.runtime
    import ansible.template.jinja2.sandbox
    import ansible.template.jinja2.utils
    import ansible.template.jin

# Generated at 2022-06-17 13:15:09.529004
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:16.518261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_

# Generated at 2022-06-17 13:15:58.618219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dicts
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:10.257056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'groups': ['wheel']},
        {'name': 'charlie', 'authorized': ['/tmp/charlie/id_rsa.pub'], 'groups': ['wheel']}
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:19.899192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of LookupModule class
    #
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # test run method with correct arguments
    # test with a list of dictionaries

# Generated at 2022-06-17 13:16:30.318352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup.subelements import LookupModule

    # test_LookupModule_run_1
    # test_LookupModule_run_2
    # test_LookupModule_run_3
    # test_LookupModule_run_4
    # test_LookupModule_run_5
    # test_LookupModule_run_6
    # test_LookupModule_run_7
    # test_LookupModule_run_8


# Generated at 2022-06-17 13:16:42.837761
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:51.071776
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:58.477300
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:11.013502
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:17:21.528314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # create a fake templar
    class FakeTemplar(object):
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables

        def template(self, data, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, convert_data=True, strip_comments=True):
            return data

        def is_template(self, data):
            return False

# Generated at 2022-06-17 13:17:33.097156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class AnsibleUnsafeTextYAMLObject(AnsibleUnsafeText, AnsibleBaseYAMLObject):
        pass

    class AnsibleUnsafeBytesYAMLObject(AnsibleUnsafeText, AnsibleBaseYAMLObject):
        pass


# Generated at 2022-06-17 13:18:45.283999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:18:56.660013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            self.template_data = {}
        def template(self, variable, convert_bare=True, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, override_vars=None):
            return self.template_data[variable]
    templar = MockTemplar()

    # create a mock loader
    class MockLoader:
        def __init__(self):
            self.paths = []
        def get_basedir(self, hostname):
            return self.paths[0]
    loader = MockLoader()

    # create a mock variables
    variables = {}

    # create a mock lookup
    lookup = LookupModule()
    lookup._templar

# Generated at 2022-06-17 13:19:07.903772
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:18.970226
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:30.887015
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:42.147436
# Unit test for method run of class LookupModule