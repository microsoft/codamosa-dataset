

# Generated at 2022-06-17 13:09:53.249852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar:
        def __init__(self):
            pass

        def template(self, value):
            return value

    # create a mock loader
    class MockLoader:
        def __init__(self):
            pass

        def get_basedir(self, hostname):
            return '.'

    # create a mock variables
    class MockVars:
        def __init__(self):
            pass

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return {}

    # create a mock display
    class MockDisplay:
        def __init__(self):
            pass


# Generated at 2022-06-17 13:10:05.986071
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:17.489076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    # mock class
    class MockLookupBase(LookupBase):
        def __init__(self, loader=None, templar=None, shared_loader_obj=None):
            self._loader = loader
            self._templar = templar

    # mock class
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

    # mock class

# Generated at 2022-06-17 13:10:30.578565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock templar
    class MockTemplar(object):
        def __init__(self, loader):
            self._loader = loader

        def template(self, value, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True,
                     override_vars=None):
            return value

    # create a mock loader
    class MockLoader(object):
        def __init__(self):
            pass

        def get_basedir(self, hostname):
            return "/"

    # create a mock display
    class MockDisplay(object):
        def __init__(self):
            pass

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass

    # create a mock inventory


# Generated at 2022-06-17 13:10:41.793501
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:10:50.524906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms


# Generated at 2022-06-17 13:11:01.040164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a test object
    lookup_module = LookupModule()

    # create a test variable

# Generated at 2022-06-17 13:11:13.549388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub'
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
            ]
        }
    ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:11:20.527932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins

    # Mock the module_utils.basic.AnsibleModule class
    class MockAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    # Mock the module_utils.basic.AnsibleModule class


# Generated at 2022-06-17 13:11:29.315453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_plugin = TestLookupModule()

    # test with a list of two items

# Generated at 2022-06-17 13:11:46.771473
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:11:57.772280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six.moves import intern
    from ansible.module_utils.six.moves import next


# Generated at 2022-06-17 13:12:10.149870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of dicts
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ],
        'authorized'
    ]

# Generated at 2022-06-17 13:12:20.552829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, None)

# Generated at 2022-06-17 13:12:30.847918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml.objects
    import ansible.template
    import ansible.vars
    import ansible.utils.listify
    import ansible.utils.unsafe_proxy

    # create a mock templar
    templar = ansible.template.Templar(loader=None)

    # create a mock loader
    loader = ansible.parsing.dataloader.DataLoader()

    # create a mock variables
    variables = ansible.vars.VariableManager()

    # create a mock inventory
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variables, host_list=[])

    # create a mock play

# Generated at 2022-06-17 13:12:44.543263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip

    # create instance of LookupModule
    lookup_module = LookupModule()

    # create mock variables
    variables = {}

    # create mock terms

# Generated at 2022-06-17 13:12:53.326817
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:05.615082
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:16.392571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lookup_module = LookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:13:29.194893
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:13:55.528875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class LookupModule(LookupBase):

        def run(self, terms, variables, **kwargs):

            def _raise_terms_error(msg=""):
                raise AnsibleError(
                    "subelements lookup expects a list of two or three items, " + msg)

            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)

            # check lookup terms - check number of terms

# Generated at 2022-06-17 13:14:07.968484
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:14:18.733760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()
    lookup_module.set_options({'skip_missing': False})
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:14:30.741185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:14:44.322285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cPickle as pickle

# Generated at 2022-06-17 13:14:55.354786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, {})

# Generated at 2022-06-17 13:15:02.748799
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:14.094912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the method run of class LookupModule
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-public-methods
    # pylint: disable=too-many-lines
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-boolean-expressions
    # pylint: disable=too-

# Generated at 2022-06-17 13:15:24.394399
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:15:34.548242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test with a list of dictionaries

# Generated at 2022-06-17 13:16:14.848531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a list of dictionaries
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
        ],
        'authorized'
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:16:20.745010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty terms
    lookup_module = LookupModule()
    assert lookup_module.run([], {}) == []

    # Test with empty terms and skip_missing flag
    lookup_module = LookupModule()
    assert lookup_module.run([], {}, skip_missing=True) == []

    # Test with empty terms and skip_missing flag
    lookup_module = LookupModule()
    assert lookup_module.run([], {}, skip_missing=False) == []

    # Test with empty terms and skip_missing flag
    lookup_module = LookupModule()
    assert lookup_module.run([], {}, skip_missing=False) == []

    # Test with empty terms and skip_missing flag
    lookup_module = LookupModule()
    assert lookup_module.run([], {}, skip_missing=False) == []



# Generated at 2022-06-17 13:16:31.032490
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:16:38.291840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # create a mock templar object
    templar = Dictable()

    # create a mock loader object
    loader = Dictable()

    # create a mock variables object
    variables = Dictable()

    # create a mock display object
    display = Dictable()

    # create a mock ansible options object
    ansible_options = Dictable()

    # create a mock ansible options object
    ansible_options.connection_user = 'test_user'

    # create a mock ansible options object
    ansible_options.remote_user = 'test_user'

    # create a mock ansible options object
    ansible_options.private_key_file = 'test_key'

    # create a mock ansible options object
    ans

# Generated at 2022-06-17 13:16:49.887618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    lookup_instance = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:16:59.796306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # test with no terms
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run([], {})
    assert 'subelements lookup expects a list of two or three items' in str(excinfo.value)

    # test with one term
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run(['term1'], {})

# Generated at 2022-06-17 13:17:12.262114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create a LookupModule object
    lm = LookupModule()

    # create a list of dictionaries

# Generated at 2022-06-17 13:17:22.183299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    class TestLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    lookup_instance = TestLookupModule()

    # test with a list of dictionaries

# Generated at 2022-06-17 13:17:33.123910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test the run method of class LookupModule
    #
    # Args:
    #    None
    #
    # Returns:
    #    None

    # create an instance of LookupModule
    lookup_plugin = LookupModule()

    # test run method with a list of dictionaries and a subkey
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
    ]
    terms = [users, 'authorized']
    result = lookup_plugin.run(terms, None)

# Generated at 2022-06-17 13:17:40.864667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with list of dictionaries and subkey
    lookup_module = LookupModule()
    terms = [
        [
            {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
            {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        ],
        'authorized',
    ]
    result = lookup_module.run(terms, None)

# Generated at 2022-06-17 13:18:56.048877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.utils.listify import listify_lookup_plugin_terms

    # Test with a list of dictionaries

# Generated at 2022-06-17 13:19:07.396257
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:19:13.680509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of dictionaries

# Generated at 2022-06-17 13:19:21.351411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.parsing.convert_bool import BOOLE

# Generated at 2022-06-17 13:19:32.329266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    import ansible.plugins.lookup.subelements
    lookup = ansible.plugins.lookup.subelements.LookupModule()

# Generated at 2022-06-17 13:19:43.518102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE