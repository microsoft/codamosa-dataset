

# Generated at 2022-06-11 15:59:42.970235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys
    import os.path
    # change to test directory so we can import the 'module'
    test_dir = os.path.dirname(os.path.abspath(__file__))
    expected_result_file = os.path.join(test_dir, 'expected_result_subelements.json')
    module = os.path.join(test_dir, os.path.pardir, '..', '..', 'hacking', 'test-module')
    sys.path.insert(0, module)
    from module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

# Generated at 2022-06-11 15:59:53.043037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run([[{'a': 'b'}, {'a': 'bb'}], 'a'], None) == [[({'a': 'b'}, 'b')], [({'a': 'bb'}, 'bb')]]
    assert lookup.run([[{'a': 'b', 'c': 'd'}, {'a': 'bb', 'c': 'dd'}], 'a'], None) == [([{'a': 'b', 'c': 'd'}, 'b']), [{'a': 'bb', 'c': 'dd'}, 'bb']]
    assert lookup.run([{'a': {'a': 'b'}}, 'a'], None) == [[({'a': {'a': 'b'}}, {'a': 'b'})]]



# Generated at 2022-06-11 16:00:03.616583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

# Generated at 2022-06-11 16:00:14.844367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # data
    elementlist = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub'], 'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}
    ]

    # expected result

# Generated at 2022-06-11 16:00:24.972344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    vault_id = {
        'vault_password': 'foo',
    }

    def _run(terms, variables, **kwargs):
        return LookupModule().run(terms, variables, **kwargs)

    def _setup_lookup_mock(mocker, lookup_mock):
        class _BaseMock():
            def __init__(self):
                self.vaults = {}
                self._items = iter([])

            def set_vault_secrets(self, secrets):
                self.vaults = secrets

            def set_items(self, items):
                self._items = iter(items)


# Generated at 2022-06-11 16:00:34.212794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils import basic
    import json

    basic._ANSIBLE_ARGS = None
    tester = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = None
    # --- subelements lookup with 2 terms, list of dict and subkey ---

# Generated at 2022-06-11 16:00:46.055275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.parsing.convert_bool import boolean

    lookup = LookupModule()


# Generated at 2022-06-11 16:00:46.690681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:00:54.739569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This method tests the output of the run method on user defined dictionaries, lists and strings.
    """

# Generated at 2022-06-11 16:01:05.206583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import BytesIO

    # First tests: test with different input that should trigger a AnsibleError exception
    users_var_with_no_values = [{}]
    users_var_with_empty_values = [{"name": "alice"},{"name": "bob"},{"name": "bob", "authorized": []}]
    users_var_with_non_dictionary_values = [{"name": "alice"}, True, {"name": "bob", "authorized": []}]
    users_var_with_non_list_values = [{"name": "alice"}, {"name": "bob", "authorized": {}}]

# Generated at 2022-06-11 16:01:25.924728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case: [dict{}], non existing key
    lm = LookupModule()
    users = [{'name': 'alice'}]
    ret = lm.run([users,'non.existing.key'],{})
    assert ret == []

    # Test case: [dict{}], existing key, not a leaf
    lm = LookupModule()
    users = [{'name': {'non': 'existing', 'key': 'value'}}]
    ret = lm.run([users,'name'],{})
    assert ret == []

    # Test case: [dict{}], existing key, not a leaf, skip_missing
    lm = LookupModule()
    users = [{'name': {'non': 'existing', 'key': 'value'}}]

# Generated at 2022-06-11 16:01:36.580104
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    if not PY3:
        from ansible.module_utils.six.moves import cStringIO as StringIO

    # set up lookuptool and call method run
    lookup_module = LookupModule()
    lookup_module._templar = lambda a: a
    lookup_module._loader = lambda a: a

    def _run(terms):
        return lookup_module.run(terms, {"v1": "a", "v2": 2})

    # basic example in description should work

# Generated at 2022-06-11 16:01:48.676448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # wrong terms list
    terms = None
    try:
        lookup_module.run(terms, {})
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "

    terms = []
    try:
        lookup_module.run(terms, {})
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "

    terms = [
        {'alice': {'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']}},
        'authorized'
    ]


# Generated at 2022-06-11 16:01:59.933769
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    l = LookupModule()

    # Act
    lresult = l.run([
        [{'users': [{'authorized': [0, 1], 'name': 'alice', 'id': 1}], 'groups': [{'id': 1, 'name': 'users'}]}],
        'users',
        {'skip_missing': False}
    ], {}, [])

    # Assert
    assert lresult == [(
        {'users': [{'authorized': [0, 1], 'name': 'alice', 'id': 1}], 'groups': [{'id': 1, 'name': 'users'}]},
        {'authorized': [0, 1], 'name': 'alice', 'id': 1}
    )]


if __name__ == '__main__':
    test_Lookup

# Generated at 2022-06-11 16:02:12.915349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import text_type

    # run unit tests
    lm = LookupModule()

    # set up test input
    terms = [
        {
            'one': {
                'a': 1,
                'b': 2,
                'c': {
                    'ca': 1,
                    'cb': 2,
                    'cc': [8, 9]
                }
            },
            'two': {
                'a': 1,
                'b': 2,
                'c': {
                    'ca': 1,
                    'cb': 2,
                    'cc': [10, 11]
                }
            }
        },
        'c.cc'
    ]
    variables = None

    # run unit test
    results = lm.run(terms, variables)

    # assert results


# Generated at 2022-06-11 16:02:21.587820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance._templar = None
    lookup_instance._loader = None
    testdata = {'users': [{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
                           'name': 'alice',
                           'mysql': {'hosts': [ '127.0.0.1', 'localhost'],
                                     'password': 'mysql-password',
                                     'privs': ['*.*:SELECT', 'DB1.*:ALL']},
                           'groups': ['wheel']}]}
    result = lookup_instance.run([testdata, 'users.mysql.hosts'], testdata)

# Generated at 2022-06-11 16:02:34.867543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # invalid terms
    invalid_terms = [
        (),                                                    # not a list
        (1, 2, 3),                                             # too many
        ([],),                                                 # one item: list
        (dict(), dict()),                                      # two items: dict and dict
        ([], dict(), dict()),                                  # three items: list, dict and dict
        ([], 1, dict()),                                       # ...
        ([], "key", dict()),                                   # ...
        ([dict(), dict()], "key"),                             # ...
        ([dict(), dict()], "key", dict()),                     # ...
    ]
    # test run with invalid terms

# Generated at 2022-06-11 16:02:43.730885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _call_run = LookupModule().run

    def vequal(a, b):
        return a == b

    # test cases

# Generated at 2022-06-11 16:02:56.008616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    ret = True

    # Empty list of subelements, no items in list
    templar = DummyTemplar()
    loader = DummyLoader()
    lookup = LookupModule(loader=loader, templar=templar)
    item0 = [None]
    item1 = 'key'
    terms = [item0, item1]
    ret = ret and run_test(lookup, terms, [])

    # List of subelements, no items in list
    templar = DummyTemplar()
    loader = DummyLoader()
    lookup = LookupModule(loader=loader, templar=templar)

# Generated at 2022-06-11 16:03:04.731388
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:03:30.846907
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:03:42.904798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import assertCountEqual
    from ansible.module_utils._text import to_native

    module_class = LookupModule
    assert hasattr(module_class, 'run')
    module_instance = module_class()
    assert hasattr(module_instance, 'run')


# Generated at 2022-06-11 16:03:49.437058
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dict_users = dict(
        users=[
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub'
                ]
            },
            {
                'name': 'bob',
                'authorized': [
                    '/tmp/bob/id_rsa.pub'
                ]
            }
        ]
    )


# Generated at 2022-06-11 16:03:54.905760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

# Generated at 2022-06-11 16:03:59.750387
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # The test data (vars)
    vars = {
      'key_to_lookup': 'key1',
      'list_of_elements': [
         {
           'key1': 'value1',
           'key2': [
             'item1',
             'item2',
           ],
         },
         {
           'key1': 'value2',
           'key2': [
             'item1a',
             'item2a',
           ],
         },
      ]
    }

    # The main part
    test = LookupModule()
    test.set_runner(tasks=[])
    res = test.run([ [vars['list_of_elements'], vars['key_to_lookup']], ], vars)

    # The expected result

# Generated at 2022-06-11 16:04:11.175300
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    import os
    import sys

    # setup
    display = Display()
    loader = DataLoader()
    myvars = VariableManager()
    myplay = PlayContext()

    # datastructures and data
    hosts = ['localhost', 'otherhost']
    myvars.update({'inventory_hostname': 'localhost',
                   'group_names': ['ungrouped']})

    subkey = "mysql.hosts"

    # METHOD UNDER TEST
    ###################

    # create lookup object
    lookup = LookupModule()

    # call method under test

# Generated at 2022-06-11 16:04:22.252023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import os
    import sys

    plugin_path = os.path.dirname(sys.modules[__name__].__file__)
    json_path = os.path.join(plugin_path, '../../../../tests/ansible/test_data/lookup_plugins/json/json.json')

    with open(json_path) as fp:
        data = json.load(fp)

    t = []
    t.append(data)
    t.append('odoo_users')

    m = LookupModule()
    res = m.run(t, variables=dict())
    assert len(res) == 2

# Generated at 2022-06-11 16:04:29.890542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range
    lookup_plugin = LookupModule()

    with pytest.raises(AnsibleError) as execinfo:
        lookup_plugin.run(['wrong', 'arguments'], dict())
    assert "subelements lookup expects a list of two or three items" in str(execinfo.value)
    with pytest.raises(AnsibleError) as execinfo:
        lookup_plugin.run([dict(), 1], dict())
    assert "expects a list of two or three items, first a dict or a list, second a string pointing to the subkey" in str(execinfo.value)

# Generated at 2022-06-11 16:04:41.969465
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:04:54.710607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))


# Generated at 2022-06-11 16:05:37.065730
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        unicode = str

    users = [
        {'name': 'alice',
            'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
            'groups': ['wheel']
         },
        {'name': 'bob',
            'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    # mock stdout
    stdout = sys.stdout
    sys.stdout = StringIO()

    # run unit tests
    lookup = LookupModule()

    # terms should be a list
    terms = "string"
   

# Generated at 2022-06-11 16:05:48.881122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.errors import AnsibleError

    # init
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)
    assert isinstance(lookup_instance.run, object)

    # input

# Generated at 2022-06-11 16:06:00.914508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # method run() handles error cases
    def _test_error(terms, **kwargs):
        try:
            lookup._templar = mock_templar
            lookup._loader = mock_loader
            lookup.run(terms, {}, **kwargs)
        except AnsibleError as e:
            return str(e)
        return None

    # mock objects to avoid actual execution of templates
    mock_templar = mock.MagicMock()
    mock_loader = mock.MagicMock()
    mock_loader.path_dwim.return_value = '/path/to/file'

    # check lookup terms - check number of terms
    assert 'subelements lookup expects a list of two or three items' == _test_error(None)

# Generated at 2022-06-11 16:06:13.148590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    def raise_AnsibleError(*args, **kwargs):
        raise AnsibleError('raised error')

    def test_run_error(terms):
        """Test run with illegal input.

        Args:
            terms (dict): Parameters to subelements lookup module.

        Raises:
            AssertionError: The exception raised by subelements lookup module
                is not AnsibleError.
        """
        try:
            lookup_module.run(terms=terms, variables=None)
        except Exception as exception:
            # check that the raised exception is AnsibleError
            assert isinstance(exception, AnsibleError)
        else:
            assert False, "subelements lookup module does not raise AnsibleError for illegal input"


# Generated at 2022-06-11 16:06:24.518937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test if it raises a error when the terms are not ok
    terms = [{"users": "test"}, "fail"]
    with pytest.raises(AnsibleError):
        lookup_module.run(terms, [])

    # test if it raises a error when the terms are not ok
    terms = ["fail", ["fail", "fail"]]
    with pytest.raises(AnsibleError):
        lookup_module.run(terms, [])

    # test if it raises a error when the terms are not ok
    terms = [{"users": "test"}, {'fail': 'fail'}]
    with pytest.raises(AnsibleError):
        lookup_module.run(terms, [])

    # test if it raises a error when the terms are not ok

# Generated at 2022-06-11 16:06:35.400154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest2 import TestCase
    from ansible.module_utils.six import iteritems

    # helper class for pylint to find the fixtures
    class Fixtures(object):
        class Mylookup(LookupModule):
            def run(self, terms, variables=None, **kwargs):
                self.terms = terms
                self.variables = variables
                return []

            def get_basedir(self, variables):
                return variables

    # subelements with simple string as subkey
    # User can provide dict or list
    class TestRun_0(TestCase):
        def runTest(self):
            fixtures = Fixtures()
            # skip_missing=False, should raise error on missing 'key' in dict
            lookup_instance = fixtures.Mylookup()

# Generated at 2022-06-11 16:06:40.130882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import signal
    import subprocess
    import tempfile

    fhandle, fname = tempfile.mkstemp(prefix='ansible_test_lookup_subelements')
    f = os.fdopen(fhandle, 'wb')

# Generated at 2022-06-11 16:06:51.796787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.compat.six as six
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import binary_type

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)
    variable_manager._extra_vars = {}
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 16:07:00.062744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins.loader import connection_loader, lookup_loader

    data_loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=data_loader, sources='/dev/null')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 16:07:10.266231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # verify given data structure matches returned one
    def _verify_structure(given, returned, given_subkey):
        # sort returned data structure in order to simplify testing
        result = []
        for item in returned:
            result.append((item[0][given_subkey], item[1]))
        # check if given is a subset of result
        assert sorted(given) == sorted(result)

    # create lookup module instance and test with given config
    def _test(config):
        loader = MockLoader(vars=dict(users=config['users']))
        templar = MockTemplar()

# Generated at 2022-06-11 16:08:30.733134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2, PY3
    import sys
    if PY2:
        import __builtin__ as builtins
    else:
        import builtins

    templar = "templar"
    loader = "loader"


# Generated at 2022-06-11 16:08:42.617357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    import yaml

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["/dev/null"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts=["localhost"],
        gather_facts="no",
        tasks=[
            dict(action=dict(module="debug", args=dict(msg="Hello World!")))
        ]
    )

# Generated at 2022-06-11 16:08:43.261717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 16:08:54.226933
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:09:05.592425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Basic case: list of dict with lists in subelements
    actual = lookup.run([
        [{'a': 1, 'b': 2, 'c': 3}, {'a': 3, 'b': 4, 'c': 5}, {'a': 4, 'b': 4, 'c': 5}],
        'a'
    ])
    # Basic test should return list of tuples
    assert isinstance(actual, list)
    assert len(actual) == 2
    for return_value in actual:
        assert isinstance(return_value, tuple)
        assert len(return_value) == 2
        assert isinstance(return_value[0], dict)
        assert isinstance(return_value[1], int)

    # a list of dictionaries that doesn't contain given subelement

# Generated at 2022-06-11 16:09:06.663441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test code
    # TODO

    pass

# Generated at 2022-06-11 16:09:15.678169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = [
        {'ok': {'subkey': ['a', 'b']},
         'skipped': {'subkey': ['1', '2']}},
        'subkey',
    ]
    ret = l.run(terms, {})
    assert [['a', 'b']] == ret
    l = LookupModule()
    terms = [
        [{'subkey': ['a', 'b']},
         {'subkey': ['1', '2']}],
        'subkey'
    ]
    ret = l.run(terms, {})
    assert [['a', 'b'], ['1', '2']] == ret
    l = LookupModule()

# Generated at 2022-06-11 16:09:28.107277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)