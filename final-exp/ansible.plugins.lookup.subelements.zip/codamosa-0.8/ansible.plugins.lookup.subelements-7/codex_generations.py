

# Generated at 2022-06-11 15:59:44.686317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # imports
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3
    import copy

# Generated at 2022-06-11 15:59:54.325748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    # Import module used in tests
    from ansible.plugins.lookup.subelements import LookupModule

    # List of dictionaries.

# Generated at 2022-06-11 16:00:03.354424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    from collections import namedtuple

    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    sys.modules['ansible'] = namedtuple('AnsibleFakeModule', ['AnsibleError', 'boolean'])()
    sys.modules['ansible'].AnsibleError = AnsibleError
    sys.modules['ansible'].boolean = boolean

    class AnsibleModuleFake:
        def __init__(self, argument_spec, supports_check_mode=False):
            self.params = {}

    class AnsibleModuleUtilsFake:
        def __init__(self):
            self.AnsibleModule = AnsibleModuleFake


# Generated at 2022-06-11 16:00:14.476626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test_LookupModule_run() - Unit test for method run of class LookupModule."""
    import ansible.parsing.vault
    lookup_plugin = LookupModule()
    # Test a simple two level subelement walk
    terms = [
        [{'name': 'Alice', 'address': 'Main Street'},
         {'name': 'Bob', 'address': 'Broadway'}],
        'address'
    ]
    assert list(lookup_plugin.run(terms, dict())) == [
        [{'name': 'Alice'}, 'Main Street'],
        [{'name': 'Bob'}, 'Broadway']
    ]
    # Test a more complex three level subelement walk

# Generated at 2022-06-11 16:00:24.727104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    unittest for method run of class LookupModule
    """
    import sys
    import unittest
    import unittest.mock
    sys.path.append('../')
    from context import ansible
    from ansible import errors
    from ansible.plugins.lookup.subobj import LookupModule

    test_dir = 'testdir'
    test_dir_value = 'testdirval'

    # test class:
    lookuper = LookupModule()

    # tests:

    # test1: should not raise an exception
    arg_terms = [test_dir_value, 'fake_sublist']
    arg_variables = None
    arg_kwargs = {'var': 'varval'}
    # (a) when item0 is a dict, it should be skipped and not raised exceptions
    ret

# Generated at 2022-06-11 16:00:33.845144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    mylookup = LookupModule()

    #
    # first term should be a list (or dict), second a string holding the subkey
    #
    with pytest.raises(AnsibleError):
        mylookup.run([], {})
    with pytest.raises(AnsibleError):
        mylookup.run([{}, 'key'], {})
    with pytest.raises(AnsibleError):
        mylookup.run([[], 'key'], {})

    #
    # check for optional flags in third term
    #
    with pytest.raises(AnsibleError):
        mylookup.run([[{}, {}, {}], 'key', 'not-a-dict'], {})

# Generated at 2022-06-11 16:00:45.706517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native
    from ansible.plugins.lookup import LookupModule

    lookup = LookupModule()

    users = [
        {
            'name': 'alice',
                'authorized': [
                    'abc',
                    'def'
                ]
        },
        {
            'name': 'bob',
            'authorized': 'ghi'
        }
    ]

    results = lookup.run([users, 'authorized'], dict(), wantlist=True).pop()

    if PY3:
        File = io.StringIO
    else:
        File = StringIO
    fd = File()

# Generated at 2022-06-11 16:00:54.271113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Called by test_lookup_plugins.py"""
    from ansible.module_utils.six import iteritems

    def _add(self, terms, variables, **kwargs):
        """Add the results of a subelements lookup to the terms to be handed to the filter plugin."""
        terms.append(terms[0])
        terms[0] = self.do_lookup(terms[0], variables, **kwargs)

    # Old and new style plugin API (Ansible <= 2.6/2.7, Ansible >= 2.8)
    try:
        from ansible.plugins.loader import lookup_loader  # Ansible 2.8
        lookup_loader._add_lookup_class('subelements', LookupModule)
    except ImportError:
        from ansible.plugins import LookupBase  # Ansible 2.

# Generated at 2022-06-11 16:01:04.818285
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:15.119018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    assert boolean("TRUE", strict=False) == True
    assert boolean("FALSE", strict=False) == False

    lu = LookupModule()

    # test case - subelements lookup expects a list of two or three items
    with pytest.raises(AnsibleError) as ee:
        lu._templar.template("{{ q('subelements', [1, 2, 3, 4], 'foo') }}")
    assert "subelements lookup expects a list of two or three items" in str(ee.value)

    # test case - subelements lookup expects a list of two or three items

# Generated at 2022-06-11 16:01:27.760465
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with a single dictionary
    l = LookupModule()
    l.set_options(dict(skip_missing=True))
    l._templar = lambda value: value
    l._loader = lambda: None
    l.run([{"a": {"b": ["c", "d"]}}, "a.b"], {}) == [("c", "d")]

    # test with a list of a single dictionary
    l = LookupModule()
    l.set_options(dict(skip_missing=True))
    l._templar = lambda value: value
    l._loader = lambda: None
    l.run([[{"a": {"b": ["c", "d"]}}], "a.b"], {}) == [("c", "d")]

    # test with a list of two dictionaries
    l = LookupModule

# Generated at 2022-06-11 16:01:37.701468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test without subkey
    terms = ([], '', {})
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert len(result) == 0

    # test with empty subkey
    terms = (['test'], '', {})
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert len(result) == 1
    assert result[0][0] == 'test'
    assert result[0][1] is None

    # test with non existing subkey
    terms = ([{'test': 'value'}], 'nope', {})
    lookup_module = LookupModule()

# Generated at 2022-06-11 16:01:49.551476
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # A user with MySQL DB1 privilege and no groups
    user1 = {
        "name": "alice",
        "mysql": {
            "username": "alice",
            "password": "pwd",
            "hosts": [
                "localhost"
            ],
            "privs": [
                "DB1.*:ALL"
            ]
        }
    }

    # A user with MySQL DB2 privilege and a group
    user2 = {
        "name": "bob",
        "groups": [
            "wheel"
        ],
        "mysql": {
            "username": "bob",
            "password": "pwd",
            "hosts": [
                "localhost"
            ],
            "privs": [
                "DB2.*:ALL"
            ]
        }
    }

# Generated at 2022-06-11 16:02:01.027174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.lookup import LookupBase
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultSecret

    basedir = os.path.dirname(__file__)
    if not basedir:
        basedir = '.'

    # create a temporary vault secret
    vault_secret = VaultSecret('VaultPassword', 'ansible')

    # create Vault object for decoding vault-encrypted strings
    vault = VaultLib(vault_secret)

# Generated at 2022-06-11 16:02:14.417699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # options test
    from ansible import context
    from ansible.cli.debug import CLIDebug
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 16:02:20.562229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.yaml.loader import AnsibleLoader

    # create helper to test lookup module
    loader = AnsibleLoader(None, None)
    lookup_module = LookupModule()
    lookup_module._loader = loader
    lookup_module._templar = None

    # test: invalid number of parameters
    with pytest.raises(AnsibleError):
        lookup_module.run([])

    # test: first parameter should be a list or dict
    with pytest.raises(AnsibleError):
        lookup_module.run(["a string", "whatever"])

    # test: second parameter should be a string
    with pytest.raises(AnsibleError):
        lookup_module.run([[], ["not a string"]])

    # test: third parameter should be a dictionary with flags
   

# Generated at 2022-06-11 16:02:33.790137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Arrange
    lookup = LookupModule()


# Generated at 2022-06-11 16:02:43.580931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = None
    lookup._loader = None
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    templar = Templar(loader=None, shared_loader_obj=None)
    # check return value if called with empty terms
    terms = []
    assert lookup.run(terms, None, **{}) == []
    # check return value if called with empty variable dictionary
    terms = ['x', 'y', {'skip_missing': 'yes'}]
    assert lookup.run(terms, {}, **{}) == []
    # check return value if called with empty variable dictionary
    # and empty list within variable dictionary
    terms = ['x', 'y', {'skip_missing': 'yes'}]

# Generated at 2022-06-11 16:02:55.842233
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:03:04.637684
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing function LookupModule.run() for valid input

    # inputs:
    def test_1_lookup_input_valid():
        users = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub"]}, {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}]
        expected_result = [({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub']}, '/tmp/alice/onekey.pub'), ({'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}, '/tmp/bob/id_rsa.pub')]
        return (users, expected_result)

    # inputs:

# Generated at 2022-06-11 16:03:30.681831
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init class
    lookup = LookupModule()    # noqa: F841

    # terms and expected result

# Generated at 2022-06-11 16:03:42.750498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the get_plugin method of the lookup module is used in all tests
    # to get the proper lookup plugin (like in ansible/playbook/play_context.py):
    from ansible.plugins.lookup import LookupModule
    lookup_plugin = LookupModule()


# Generated at 2022-06-11 16:03:49.398061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # Init class LookupModule
    lookup = LookupModule()

    # Mock get_basedir()
    lookup._templar = type('Templar', (object,), {})

    # Mock get_basedir()
    lookup._loader = type('Loader', (object,), {})

    # Test run with no arguments given
    try:
        result = lookup.run([])
        raise AssertionError("AnsibleError exception was not raised")
    except AnsibleError:
        pass


# Generated at 2022-06-11 16:03:59.747776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-11 16:04:11.175030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms0 = [
        [
            {
                "name": "alice",
                "authorized":
                    [
                        "/tmp/alice/onekey.pub",
                        "/tmp/alice/twokey.pub"
                    ]
            },
            {
                "name": "bob",
                "authorized":
                    [
                        "/tmp/bob/id_rsa.pub"
                    ]
            }
        ],
        "authorized"
    ]


# Generated at 2022-06-11 16:04:22.251882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.module_utils._text import to_text


# Generated at 2022-06-11 16:04:29.890368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = []
    users = [
        dict(name='bob', authorized=['/tmp/bob/id_rsa.pub'], mysql={'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}),
        dict(name='alice', authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], mysql={'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, groups=['wheel']),
    ]
    lu = LookupModule()

# Generated at 2022-06-11 16:04:41.969276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # empty list
    test_run_method(
        expected_result=[],
        arguments=(
            [],  # list (or dict)
            'x',  # string pointing to the subkey
            {'skip_missing': False}  # optional dict with flags
        )
    )
    test_run_method(
        expected_result=[],
        arguments=(
            [],  # list (or dict)
            'x.y',  # string pointing to the subkey
            {'skip_missing': False}  # optional dict with flags
        )
    )

# Generated at 2022-06-11 16:04:54.709236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit tests for method run of class LookupModule """
    # The following dict will be serialized as a YAML string
    # using the function dumps from the yaml module

# Generated at 2022-06-11 16:05:04.922808
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import module directly and use its public methods
    from ansible.plugins.lookup.subelements import LookupModule
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # run with invalid terms
    invalid_terms = [1, 2, 3]
    try:
        lookup_module.run(invalid_terms, None)
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items, "

    # run with invalid terms: first and second not a list
    invalid_terms = ["invalidterms", "invalidterms"]

# Generated at 2022-06-11 16:05:46.418595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    lookup_plugins = dict()
    lookup_plugins['subelements'] = LookupModule()
    templar_arguments = dict()
    templar_arguments['no_lookups'] = False
    templar = Templar(loader=None, variables=dict(), **templar_arguments)

    play_context = PlayContext()

    ## get error if less than two arguments are given

# Generated at 2022-06-11 16:05:53.534758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    data = '''
    [
        {
            "foo": 42,
            "bar": {
                "one": "first",
                "two": "second"
            },
            "baz": [
                "a",
                "b",
                "c"
            ]
        },
        {
            "foo": 43,
            "bar": {
                "one": "third",
                "two": "fourth"
            },
            "baz": [
                "d",
                "e",
                "f"
            ]
        }
    ]
    '''

# Generated at 2022-06-11 16:05:55.848334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.subelements import test_subelements
    test_subelements()

# Generated at 2022-06-11 16:05:59.806162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .test_lookup_plugins import TestLookupBase
    lookup_base_test = TestLookupBase()

    lookup_base_test.testLookupModule(LookupModule)

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 16:06:12.319203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 1: try to run a lookup subelements with too many terms
    def test_case_1_run():
        l = LookupModule()
        l.run([{}, {}, {}], {})

    try:
        test_case_1_run()
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "

    # test case 2: try to run a lookup subelements with not enough terms
    def test_case_2_run():
        l = LookupModule()
        l.run([{}], {})


# Generated at 2022-06-11 16:06:23.405685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarsModule():
      def __init__(self, d = {}):
         self.vars = d
    class TemplarModule():
      def __init__(self, d = {}):
         self.vars = VarsModule(d)
      def template(self, s):
         return s

    users = [
      {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
      {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    loader = {}
    templar = TemplarModule()

    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module._loader

# Generated at 2022-06-11 16:06:25.332562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import doctest
    doctest.testmod()

# Run unit tests for class LookupModule

# Generated at 2022-06-11 16:06:36.060902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader, module_loader
    from ansible.plugins.dynamic_plugins.yes_plugin import ActionModule as Yes
    import os

    def create_lookup_plugin(terms, **kwargs):
        class LookupModule(object):
            def run(self, **kwargs):
                return terms
        return LookupModule()

    lookup_loader.add_directory

# Generated at 2022-06-11 16:06:48.163867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    # run method of LookupModule class with wrong number of arguments
    try:
        l = LookupModule()
        l.run()
    except TypeError as e:
        assert e.args[0] == 'run() takes at least 3 arguments (1 given)'

    # run method of LookupModule class with wrong type of first argument (terms)
    try:
        l = LookupModule()
        l.run(None, None)
    except TypeError as e:
        assert e.args[0] == '\'NoneType\' object is not iterable'

    # run method of LookupModule class with wrong type of second argument (variables)

# Generated at 2022-06-11 16:06:55.509163
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # ansible's test framework is not used here as this unit test is not invoked directly from ansible
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import json

    if ansible_version < '2.0':
        print("ERROR: ansible version '%s' too low to test this module" % ansible_version)

    # from test_lookup_plugin
    class TestTemplar(object):
        def __init__(self, variables):
            self._available_variables = variables

# Generated at 2022-06-11 16:08:01.313386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO
    pass

# Generated at 2022-06-11 16:08:12.363266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest import TestCase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.hashing import md5s
    from ansible.vars.unsafe_proxy import UnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    import os
    import yaml
    import __main__ as fake_main


# Generated at 2022-06-11 16:08:20.383451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = LookupModule()
    # Test case: subkey that is present in all items
    users = [{
        'name': 'alice',
        'authorized': ['/tmp/alice/id_rsa.pub']
    },
    {
        'name': 'bob',
        'authorized': ['/tmp/bob/id_rsa.pub']
    },
    {
        'name': 'charlie',
        'authorized': ['/tmp/charlie/id_rsa.pub']
    }]

# Generated at 2022-06-11 16:08:32.220798
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:08:34.092936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    TODO
    """
    assert False


# Generated at 2022-06-11 16:08:45.964316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock class LookupBase
    class LookupBaseMock:
        def _templar(self, *args):
            return args
        def _loader(self, *args):
            return args

    lookupbase = LookupBaseMock()

    # Init LookupModule
    lookup = LookupModule()
    lookup.set_loader(lookupbase)
    lookup.set_templar(lookupbase)

    # Perform unit test
    terms = [
        [{'one': 1, 'two': {'three': [3]}}],
        'two.three'
    ]
    variables = {}
    expected_output = [(terms[0][0], terms[0][0]['two']['three'][0])]
    actual_output = lookup.run(terms, variables)

# Generated at 2022-06-11 16:08:55.929787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create dummy env
    import os
    os.environ['ANSIBLE_CONFIG_FILE'] = os.path.join(os.path.dirname(__file__), "../../../../../ansible.cfg")
    os.environ['ANSIBLE_LIBRARY'] = os.path.join(os.path.dirname(__file__), "../../../../../lib")
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    # create dummy loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 16:09:07.353984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up test data
    users = [
        {'groups': ['wheel'],
            'name': 'alice',
            'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob',
            'authorized': ['/tmp/bob/id_rsa.pub']},
        {'name': 'charly',
            'authorized': ['/tmp/charly/id_rsa.pub', '/tmp/charly/id_dsa.pub']}
    ]

    # Test for correct data results
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(['users', 'authorized'], {'users': users},)

# Generated at 2022-06-11 16:09:15.979068
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:09:28.434187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo = LookupModule()
    testlist = [dict(a='zero', b='one', c='two', d='three'),
                dict(a='four', b='five', c='six', d='seven'),
                dict(a='eight', b='nine', c='ten', d='eleven'),
                dict(a='twelve', b='thirteen', c='fourteen', d='fifteen'),
                dict(a='sixteen', b='seventeen', c='eighteen', d='nineteen')]