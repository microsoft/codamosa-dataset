

# Generated at 2022-06-11 15:59:44.965346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../lib')))
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-11 15:59:54.366141
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.parsing.convert_bool import boolean

    class TestLookupModule(LookupModule):
        def run(self, terms, variables, **kwargs):
            # Actual class would use super
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    lookup = TestLookupModule()

    # Test most basic cases. Terms are handled in a 'safe' manner.

# Generated at 2022-06-11 16:00:03.352748
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mc_result = dict(
        skipped=False,
        rc=0,
        stdout="",
        stderr="",
        start="2016-08-02T22:30:00.819085",
        end="2016-08-02T22:30:00.831093",
        delta="0:00:00.012005",
        msg="non-zero return code",
        stdout_lines=[],
        stderr_lines=[]
    )


# Generated at 2022-06-11 16:00:14.473105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit tests for LookupModule._run """

# Generated at 2022-06-11 16:00:24.726039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import unittest
    import tempfile
    import os
    import shutil
    import yaml
    import ansible.constants as C

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.basedir = tempfile.mkdtemp()
            self.lookup = LookupModule()


# Generated at 2022-06-11 16:00:33.844540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    from ansible.plugins import lookup_loader
    lookup = lookup_loader.get('subelements', class_only=True)(None, {}, {}, {})

    test_subject = {
        "key1": "var1",
        "dictionary": {
            "key1": "var1",
            "key2": "var2",
            "list1": ["val1", "val2", "val3"],
            "list2": ["val1", "val2", "val3"],
        }
    }

    # test case: calling the run method of LookupModule with a one level subkey
    expected_elements = [('var1', 'val1'), ('var1', 'val2'), ('var1', 'val3')]

# Generated at 2022-06-11 16:00:45.706764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # input: one element
    terms = [{'term1': 'value1'}, "term1"]
    ret = lookup.run(terms, None)
    assert ret == [[('term1', 'value1')]]

    # input: one element, different order
    terms = ["term1", {'term1': 'value1'}]
    ret = lookup.run(terms, None)
    assert ret == [[('term1', 'value1')]]

    # input: list of one element
    terms = [[{'term1': 'value1'}], "term1"]
    ret = lookup.run(terms, None)
    assert ret == [[('term1', 'value1')]]

    # input: list of one element, different order

# Generated at 2022-06-11 16:00:52.149917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """subelements lookup plugin - unit test"""
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=None)
    variable_manager.set_inventory(inventory)


    class Options(object):
        """options for look for lookup plugin"""
        def __init__(self, verbosity=0, extra_vars=None, ask_vault_pass=False):
            self.verbosity = verbosity
            self.connection = 'local'
            self.module_path = None

# Generated at 2022-06-11 16:01:02.356338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test for class LookupModule and method run
    '''

    # use dict as users
    users = dict()
    users['alice'] = dict()
    users['alice']['name'] = 'alice'
    users['bob'] = dict()
    users['bob']['name'] = 'bob'
    users['alice']['authorized'] = []
    users['bob']['authorized'] = []
    users['alice']['authorized'].append('/tmp/alice/onekey.pub')
    users['alice']['authorized'].append('/tmp/alice/twokey.pub')
    users['bob']['authorized'].append('/tmp/bob/id_rsa.pub')


# Generated at 2022-06-11 16:01:13.087759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.lookup import LookupBase

    class LookupModule(LookupBase):
        def run(self, terms, variables, **kwargs):
            return terms

    class LookupModulePass(LookupBase):
        def run(self, terms, variables, **kwargs):
            return [terms]

    class LookupModuleSkip(LookupBase):
        def run(self, terms, variables, **kwargs):
            return [terms[:1] + [dict(skipped=True)] + terms[2:]]


# Generated at 2022-06-11 16:01:33.308443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # first test, with a list of 'users' and subkey 'groups'
    users = [{'name': 'alice', 'groups': ['wheel', 'editors']}]
    groups = ['wheel', 'editors']
    # instantiate the lookup plugin
    lookup_module = LookupModule()
    # prepare the terms
    terms = [users, 'groups']
    # run the lookup
    result = lookup_module.run(terms, {})
    # test result
    assert result == [(users[0], groups[0]), (users[0], groups[1])]

    # second test, with a dict of 'users' and subkey 'groups'.
    # This should give the same result as the previous test
    users = {'alice': {'name': 'alice', 'groups': ['wheel', 'editors']}}
   

# Generated at 2022-06-11 16:01:40.611591
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # first unit test with a list of dictionaries
    lookup_instance = LookupModule()
    testdata = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        {'name': 'other'}
    ]
    test_result = lookup_instance.run([testdata, 'authorized'])
    expected_result = [(testdata[0], '/tmp/alice/onekey.pub'), (testdata[0], '/tmp/alice/twokey.pub'), (testdata[1], '/tmp/bob/id_rsa.pub')]

# Generated at 2022-06-11 16:01:51.836070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    # force ansible.plugins.lookup.LookupBase to not add
    # LookupBase.run to method list for class LookupBase.
    # this prevents the test from inheriting LookupBase.run from
    # class LookupBase.
    LookupBase.run = None


# Generated at 2022-06-11 16:02:02.838856
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:15.887451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    import unittest


    # Setup lookup module and mock templar

    class MockTemplar(object):
        def __init__(self, loader, variables):
            self._variables = variables

        def template(self, term):
            if term in self._variables:
                return self._variables[term]
            raise AnsibleError("template term '%s' not found" % term)

    lookup = LookupModule()
    variables = dict()
    templar = MockTemplar(None, variables)
    lookup._templar = templar


# Generated at 2022-06-11 16:02:17.874075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(dict, subelement, subkey):
        module = AnsibleModule(argument_spec={})
        lookup = LookupModu

# Generated at 2022-06-11 16:02:29.824080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test_LookupModule_run
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager._extra_vars = {'me': 'sarge', 'what': 'nothing', 'to': 'complain', 'about': None}
    play_context = PlayContext()

    def _create_lookup_instance(terms, variables):
        """ _create_lookup_instance
            create an instance of the LookupModule and then call its run() method
        """
        lm = LookupModule()
        lm.set_options({'_ansible_lookup_plugin_class': "LookupBase"})


# Generated at 2022-06-11 16:02:39.388769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup_module = LookupModule()


# Generated at 2022-06-11 16:02:45.394643
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    tmock = Mock()
    lmock = Mock()
    tmock.loader = lmock
    tmock._templar = Mock()
    from ansible.module_utils.six import string_types
    assert issubclass(string_types, basestring)

    lu = LookupModule()

    tmock.config.get_config_value.return_value = False

    terms = []

    # test too few terms
    terms = [""]
    ret = lu._templar.template.side_effect = [terms]
    ret = lu.run(terms, {}, variables=dict())
    tmock.assert_called_once_with("too few terms in subelements lookup plugin")
    del terms[:]
    lu._templar.reset_mock()
    tm

# Generated at 2022-06-11 16:02:57.604114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = [
        [{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel'], 'name': 'alice', 'mysql': {'hosts': ['.*', '127.0.0.1', '::1', 'localhost'], 'password': 'mysql-password', 'privs': ['*.*:SELECT', 'DB1.*:ALL']}}, {'authorized': ['/tmp/bob/id_rsa.pub'], 'name': 'bob', 'mysql': {'hosts': ['db1'], 'password': 'other-mysql-password', 'privs': ['*.*:SELECT', 'DB2.*:ALL']}}],
        'mysql.hosts']
    lookup = LookupModule

# Generated at 2022-06-11 16:03:21.776436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError

    # The unit test should test the functionality of the run function, but the function itself is a callback
    # and therefore not easily testable.
    # For now we test the two functions that were introduced for the unittests of lookup_plugins

    # Check if the number of subelements is correct
    lookup_instance = LookupModule()
    terms = []
    terms.append([{'user1': {'id': '1'}}, {'user2': {'id': '2'}}, {'user3': {'id': '3'}}])
    terms.append('id')
    items = lookup_instance.run(terms, dict())
    assert len(items) == 3

    # Check if subelement is not in the first level of the list
    lookup_instance = Look

# Generated at 2022-06-11 16:03:31.702080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    terms = [
        [
            {
                "a": {
                    "b": [
                        "foo",
                        "bar"
                    ]
                }
            },
            {
                "a": {
                    "b": [
                        "baz"
                    ]
                }
            }
        ],
        "a.b"
    ]

    expected_result = [
        ({'a': {'b': ['foo', 'bar']}}, 'foo'),
        ({'a': {'b': ['foo', 'bar']}}, 'bar'),
        ({'a': {'b': ['baz']}}, 'baz')
    ]

    result = LookupModule().run(terms=terms, variables=None)
    assert result == expected_result

# Test

# Generated at 2022-06-11 16:03:43.739586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare mocks for LookupModule
    class LookupModule:
        class AnsibleError:
            def __init__(self, msg):
                self.msg = msg
        class Templar:
            def __init__(self):
                pass
            def template(self, x):
                return x
        class Loader:
            def __init__(self):
                pass
            def load_from_file(self, x):
                return x
    class MockAnsibleError(LookupModule.AnsibleError):
        def __init__(self, msg):
            LookupModule.AnsibleError.__init__(self, msg)
    class MockTemplar(LookupModule.Templar):
        def __init__(self):
            LookupModule.Templar.__init__(self)

# Generated at 2022-06-11 16:03:55.239846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import ansible.utils.plugin_docs as plugin_docs

    lookup = LookupModule()
    # This environment variable is used in tests to find the path(s)
    # to the test data
    lookup._loader.set_basedir(os.path.join(os.path.dirname(__file__), 'test_data'))

    ilist = [
        {'name': 'alice',
         'authorized': [
             '/tmp/alice/onekey.pub',
             '/tmp/alice/twokey.pub'],
         'groups': ['wheel']},
        {'name': 'bob',
         'authorized': [
             '/tmp/bob/id_rsa.pub'],
         'groups': ['test']}]


# Generated at 2022-06-11 16:04:06.566259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # prepare some test data
    my_list = [
        {'y': [1, 2, 3],
         'z': {'a': {'b': {'c': [1,2,3,4]}}}}
        ]
    my_vars = {'foo': 'bar'}
    my_var_manager = VariableManager()
    my_var_manager.set_nonpersistent_facts(my_vars)
    my_play_context = PlayContext()
    my_play_context.variable_manager = my_var_manager

    # set up the module, run it and verify

# Generated at 2022-06-11 16:04:14.573154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [[{"a": [("b", "c"), ("d", "e")]}, {"a": [("b", "f")]}], "a", {}]

    # get result
    result = lookup.run(terms, dict())

    # check result
    want = [[("b", "c"), ("a", [("b", "c")])], [("b", "f"), ("a", [("b", "f")])], [("d", "e"), ("a", [("d", "e")])]]
    for wantitem in want:
        assert wantitem in result, "want %s in result %s" % (wantitem, result)

    # check error
        # first term should be a list, second a string holding the subkey

# Generated at 2022-06-11 16:04:21.157494
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        import test.test_subelements_lookup
    except ImportError:
        print("No unittests for subelements lookup available.")
    else:
        # test class name for unittest of lookup method
        test_class = test.test_subelements_lookup.SubelementsLookupTest
        # run unittest
        test_class.test__subelements_lookup_method(LookupModule)



# Generated at 2022-06-11 16:04:29.398494
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create an empty (templar) environment
    environment = Environment()

    # create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(environment))

    ret = LookupModule().run(
        [
            [
                {"name": "alice", "groups": ["wheel"]},
                {"name": "bob", "groups": ["wheel"]},
            ],
            "groups"
        ],
        variable_manager._variables
    )
    assert ret == [
        ({"name": "alice", "groups": ["wheel"]}, ["wheel"]),
        ({"name": "bob", "groups": ["wheel"]}, ["wheel"]),
    ]


# Generated at 2022-06-11 16:04:41.687156
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

# Generated at 2022-06-11 16:04:54.448229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock: import module_utils.parsing.convert_bool and return a constant value
    module_utils = __import__('ansible.module_utils', globals(), locals(), ['parsing'], 0)
    parsing = module_utils.parsing
    _real_boolean = parsing.convert_bool.boolean
    def _mock_boolean(value, strict=False):
        return True
    parsing.convert_bool.boolean = _mock_boolean

    # Mock: import lookup_plugins.subelements and return a modified
    # version that only contains the class LookupModule
    module_lookup_plugins = __import__('ansible.plugins.lookup', globals(), locals(), ['subelements'], 0)
    subelements = module_lookup_plugins.subelements
   

# Generated at 2022-06-11 16:05:37.142328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.module_utils.parsing.convert_bool import boolean
    except ImportError:
        print("WARNING: `ansible.module_utils.parsing.convert_bool` is required for testing")
        exit(0)

    def runtest(terms, expected):
        lookup_mod = LookupModule()
        result = lookup_mod.run(terms, None)
        if result != expected:
            print("Expected: %s\nGot: %s" % (expected, result))
            exit(1)


# Generated at 2022-06-11 16:05:48.961163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    import ansible.plugins.lookup.subelements
    import sys
    import pytest
    import ansible.module_utils.parsing.convert_bool
    import ansible.plugins.lookup.subelements
    from ansible.module_utils.six import BytesIO as StringIO

    output = StringIO()
    sys.stdout = output

# Generated at 2022-06-11 16:06:00.914273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    def _run(terms, variables, **kwargs):
        if variables is None:
            variables = {}
        return lookup_obj.run(terms, variables, **kwargs)
    assert _run([[], ''], {}) == [], "empty list should give empty list"
    assert _run([[{'skipped': True}], ''], {}) == [], "skipped element should give empty list"

    data = {"result": [{'skipped': True}]}
    assert _run([data, 'result'], {}) == [], "skipped element should give empty list"

    data = {'skipped': False, 'result': [1, 2]}

# Generated at 2022-06-11 16:06:13.149889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test._templar = None
    test._loader = None
    terms = [{"hostname": "hostname-1", "ip_addresses": ["192.168.1.1", "10.1.1.1"], "skipped": True},
             {"hostname": "hostname-2", "ip_addresses": ["192.168.2.2", "10.2.2.2"]},
             {"hostname": "hostname-3", "ip_addresses": ["192.168.3.3", "10.3.3.3"]}]
    result = test.run(terms, None)
    assert len(result) == 2
    assert result[0][0]['hostname'] == "hostname-2"

# Generated at 2022-06-11 16:06:24.517819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost,127.0.0.1')
    variable_manager.set_inventory(inventory)
    play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )


# Generated at 2022-06-11 16:06:35.400722
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:06:47.495671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-11 16:06:54.948851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.set_templar(None)

    # check error cases
    try:
        lookup_module.run([1, 2, 3], {})
    except AnsibleError as exc:
        assert exc.args[0] == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"
    try:
        lookup_module.run([[1, 2, 3], 'a', [1, 2, 3]], {})
    except AnsibleError as exc:
        assert exc.args[0] == "subelements lookup expects a list of two or three items, the optional third item must be a dict with flags skip_missing"


# Generated at 2022-06-11 16:07:02.180534
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:07:11.103061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # required for unit test
    #
    class MockModule(object):

        class MockTemplar(object):

            def __init__(self, loader):
                self._loader = loader

            def template(self, value, preserve_trailing_newlines=True, escape_backslashes=True, *args, **kwargs):
                self._loader.load_from_file('/etc/ansible/myvars')
                return value

        class MockLoader(object):

            def __init__(self):
                self.path_found = []
                self.path_not_found = []

            def list_directory(self, path):
                if path not in (self.path_found + self.path_not_found):
                    self.path_not_found.append(path)
                    return []


# Generated at 2022-06-11 16:08:29.080107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    users = [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]}, {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}]
    terms = [(users, "authorized")]

# Generated at 2022-06-11 16:08:36.293775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{"alice": {"authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"],"groups": ["wheel", "bar"],"mysql": {"hosts": ["localhost", "127.0.0.1", "::1"], "privs": ["*.*:SELECT","DB1.*:ALL"], "password": "mysql-password"}}}, "alice.mysql.hosts"]

# Generated at 2022-06-11 16:08:48.769536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

# Generated at 2022-06-11 16:08:56.448017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run_test(terms, expected_result):
        class AnsibleModuleMock:
            def __init__(self):
                self.params = {}
                self.args = {}
                self.boolean = boolean
        class AnsibleModuleFail:
            def __init__(self):
                self.params = {}
                self.args = {}
                self.boolean = boolean
                raise Exception
        try:
            AnsibleModule = AnsibleModuleMock
            lookup_plugin = LookupModule()
            result = lookup_plugin.run(terms, [], variables={}, **{})
            assert result == expected_result
        except Exception as err:
            AnsibleModule = AnsibleModuleFail
            assert expected_result == "FAILURE"

    # 1. simple direct subelements test

# Generated at 2022-06-11 16:09:07.889372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    old_loader = None
    old_vars = None

# Generated at 2022-06-11 16:09:17.910757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test default use case of class LookupModule
    testlookupm = LookupModule()
    testlookupm.set_loader(None)
    testlookupm.set_templar(None)
    listofdics = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub',
            ]
        },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub',
            ]
        },
    ]
    output = testlookupm.run([listofdics, 'authorized'], None)

# Generated at 2022-06-11 16:09:30.426383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest