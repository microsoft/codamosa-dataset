

# Generated at 2022-06-11 15:59:45.234867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    :return: None
    """
    lookup = LookupModule()

    # Test error handling
    terms = [{}, 'a']
    lookup._templar = None
    lookup._loader = None
    assert lookup.run(terms, None) == []

    terms = [{'a': 1, 'b': 2}, 'c']
    lookup._templar = None
    lookup._loader = None
    assert lookup.run(terms, None) == []

    terms = [{'a': 1, 'b': 2}, 'a', {'skip_missing': True}]
    lookup._templar = None
    lookup._loader = None
    assert lookup.run(terms, None) == [(1,)]

    # Test without dictionary

# Generated at 2022-06-11 15:59:54.720971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create variable manager - used to set variables
    variable_manager = VariableManager()

    # Create PlaybookExecutor - used to run Playbooks
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    playbook = PlaybookExecutor(playbooks=[], inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={})

    # Create play to run

# Generated at 2022-06-11 16:00:05.089135
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    testlookup = LookupModule()


# Generated at 2022-06-11 16:00:17.397734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test
    lookup = LookupModule()
    lookup.basedir = '/tmp/ansible'
    lookup._loader = None

    # first test: no arguments
    terms = []
    ret = lookup.run(terms, None)
    assert ret == []

    # second test: no subkey
    terms = [[]]
    ret = lookup.run(terms, None)
    assert ret == []

    # third test: no subkey - list
    terms = [['first', 'second']]
    ret = lookup.run(terms, None)
    assert ret == []

    # fourth test: no subkey - dictionary
    terms = [{'alice': 'first', 'bob': 'second'}]
    ret = lookup.run(terms, None)
    assert ret == []

    # fifth test: no subkey - dictionary

# Generated at 2022-06-11 16:00:21.006482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up class objects
    lookup_plugin = LookupModule()

    # test case with valid data
    data = dict(
        one=dict(
            subdict=dict(
                sublist=["1", "2"],
            ),
        ),
        two=dict(
            subdict=dict(
                sublist=["3", "4"],
            ),
        ),
    )
    terms = [data, "subdict.sublist"]
    result = lookup_plugin.run(terms, dict())

    assert result == [
        (data["one"], "1"),
        (data["one"], "2"),
        (data["two"], "3"),
        (data["two"], "4"),
    ]

    # test case with invalid data

# Generated at 2022-06-11 16:00:31.055586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys

    class PluginLoader:
        class LookupModule:
            def __init__(self, loader, templar, **kwargs):
                pass
            def run(self, terms, variables=None, **kwargs):
                return terms
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            sys.modules['ansible.plugins.loader'] = PluginLoader
            class FakeTemplar:
                def __init__(self, filename=None, loader=None):
                    pass

# Generated at 2022-06-11 16:00:43.059237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = {'password': 'secret', 'module_path': '../lib/ansible/modules'}
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 16:00:47.566957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [{"k1": "v1"},
         {"k1": "v2"}],
        "k1"]
    lu = LookupModule()
    r = lu.run(terms, None)
    assert [('v1',), ('v2',)] == r, r


# Generated at 2022-06-11 16:00:56.368252
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    assert module.run([[],'subkey'], {}) == []
    assert module.run([[{'subkey': [1]}],'subkey'], {}) == [[1]]
    assert module.run([[{'subkey': [[1]]}],'subkey'], {}) == [[[1]]]
    assert module.run([[{'subkey': [1]}, {'subkey': [2]}],'subkey'], {}) == [[1], [2]]
    assert module.run([[{'subkey': [1]}, {'subkey': [2], 'otherkey': 'value'}],'subkey'], {}) == [[1], [2]]

# Generated at 2022-06-11 16:01:06.635031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class LookupModuleUnderTest(LookupModule):
        def __init__(self, loader=None, variable_manager=None, **kwargs):
            self.loader = DataLoader()
            self.variable_manager = VariableManager(loader=self.loader, inventory=InventoryManager(loader=self.loader, sources=['localhost,']))

    assert LookupModuleUnderTest().run([[{'skipped': True}], 'count'], variables=dict(), wantlist=True) == []


# Generated at 2022-06-11 16:01:26.890129
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:37.210836
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:49.325780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup = LookupModule()
    lookup.set_options({})
    lookup.set_loader()
    lookup.set_templar({})
    assert lookup.run(
        [
            [
                {
                    'groups': ['wheel', 'other'],
                },
                {
                    'groups': ['wheel', 'other'],
                },
            ],
            'groups',
        ], None
    ) == [[{'groups': ['wheel', 'other']}, 'wheel'], [{'groups': ['wheel', 'other']}, 'other'], [{'groups': ['wheel', 'other']}, 'wheel'], [{'groups': ['wheel', 'other']}, 'other']]

# Generated at 2022-06-11 16:02:00.861612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = dict(
        port=22,
        remote_user='root',
        become=False,
        become_method='sudo',
        become_user='root',
        check=False,
    )

# Generated at 2022-06-11 16:02:14.363679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for method LookupModule.run"""

    def mock_subkey_not_found(dictionary, subkey):
        """Mock of method subkey_not_found to run without skipped items (so without setting os.environ)"""
        raise AnsibleError("could not find '%s' key in iterated item '%s'" % (subkey, dictionary))

    lookup_module = LookupModule()
    terms = [
        {'1': {'subkey': 'subvalue'}},
        'subkey',
        {'skip_missing': True}
    ]
    # Test a dict with one key
    result = lookup_module.run(terms, variables={})
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], tuple)

# Generated at 2022-06-11 16:02:22.279376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    result = l.run(["item0", "item1", {'first': 'value'}], None)
    assert isinstance(result, list)
    assert len(result) == 2
    assert len(result[0]) == 2
    assert len(result[1]) == 2
    assert result == [('item0', {'first': 'value'}), ('item1', {'first': 'value'})]

    result = l.run([{"item0": {'first': 'value'}}, "first", {'skip_missing': False}], None)
    assert isinstance(result, list)
    assert len(result) == 1
    assert len(result[0]) == 2
    assert result == [({'item0': {'first': 'value'}}, 'value')]

    #

# Generated at 2022-06-11 16:02:35.323114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import operator
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.listify import listify_lookup_plugin_terms

    class MockTemplar(object):
        def __init__(self, loader, variables=None):
            pass
        def template(self, value):
            return value

    # Implement class LookupModule

    class LookupModule(LookupBase):

        def __init__(self):
            super(LookupModule, self).__init__()
            self._loader = DataLoader()
            self._templar = MockTemplar(self._loader)


# Generated at 2022-06-11 16:02:43.953101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test to test method run of class LookupModule

    """
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


    class Options(object):
        """
        Options class to replace Ansible OptParser
        """
        verbosity = False
        connection = 'local'
        forks = 100
        check = False

    class PlayContext(object):
        """
        PlayContext class to replace Ansible PlayContext
        """

# Generated at 2022-06-11 16:02:56.284856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unittest import TestCase
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    class AnsibleErrorImpl(Exception):
        def __init__(self, message):
            super(AnsibleErrorImpl, self).__init__(message)

    def _ansible_module_runner(module, module_name, task_vars=None, inject=None):
        class FakeModuleRunner(object):
            def __init__(self, module, module_name, task_vars, inject):
                self.module = module
                self.module_name = module_name
                self.task_vars = task_vars
                self.inject = inject


# Generated at 2022-06-11 16:03:04.876658
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    # test for missing subkey
    result = l.run([[{'sub': {'subsub': ['one', 'two']}}], 'subsubsub'],"")
    assert result[0][0] == "could not find 'subsubsub' key in iterated item '{'sub': {'subsub': ['one', 'two']}}'"

    # test for missing variable
    result = l.run([[{'sub': {'subsub': ['one', 'two']}}], 'subsubsub'], {'unknown': 'var'})
    assert result[0][0] == "could not find 'subsubsub' key in iterated item '{'sub': {'subsub': ['one', 'two']}}'"

    # test for length of subkey list
    l = LookupModule()
   

# Generated at 2022-06-11 16:03:30.519843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    res = lookup.run([{"skipped": False, "foo": "bar"}, "foo"], {})
    assert isinstance(res, list)
    assert len(res) == 1
    assert isinstance(res[0], tuple)
    assert res[0][0] == {"skipped": False, "foo": "bar"}
    assert res[0][1] == "bar"

    res = lookup.run([{'skipped': False, "foo": "bar"}, [{"skipped": False, "bar": "baz"}, {"skipped": False, "bar": "baz2"}], "foo"], {})
    assert isinstance(res, list)
    assert len(res) == 2
    assert isinstance(res[0], tuple)

# Generated at 2022-06-11 16:03:42.593519
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:03:49.331278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 16:03:59.717664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import re

    module_path = sys.argv[1]

    if not re.match(r'^(?:/|\w+://).*\.py$', module_path):
        sys.stderr.write('ERROR: Unexpected module_path: ' + module_path + '\n')
        sys.exit(-1)

    # Import the module to be tested
    # This also executes the class method run() above
    test_module = __import__(module_path[:-3].replace('/', '.'), globals(), locals(), -1)

    # Extract and check return value

# Generated at 2022-06-11 16:04:09.552961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    users = [
        {'name': 'alice', 'groups': ['wheel']},
        {'name': 'bob', 'groups': ['wheel']},
        {'name': 'charlie', 'groups': ['wheel', 'test']}
    ]
    terms = [users, 'groups', {'skip_missing': True}]
    ret = module.run(terms, {}, variables=None)
    assert ret == [
        (users[0], 'wheel'),
        (users[1], 'wheel'),
        (users[2], 'wheel'),
        (users[2], 'test'),
    ]

# Generated at 2022-06-11 16:04:19.981967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example data
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

    def _exception_message_contains(e, msg):
        if not isinstance(e, AnsibleError):
            return False
        return msg in str(e)

    # Empty terms
    try:
        terms = []
        LookupModule.run(terms, variables=None)
        assert False, "AnsibleError should be raised"
    except AnsibleError as e:
        print(e)
        assert _exception_message_contains(e, "two or three items")

   

# Generated at 2022-06-11 16:04:28.881244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock
    lookup_mock = LookupModule()
    # user variable

# Generated at 2022-06-11 16:04:29.722369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:04:41.889163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

# Generated at 2022-06-11 16:04:54.660749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = [{'skipped': True}]
    assert lookup_plugin.run(terms, None) == []

    terms = [{'skipped': False, 'john': {'firstname': 'John', 'lastname': 'Doe'}}]
    assert lookup_plugin.run(terms, None) == [('john', {'firstname': 'John', 'lastname': 'Doe'})]

    terms = [{'skipped': False, 'john': {'firstname': 'John', 'lastname': 'Doe'}}, 'lastname']
    assert lookup_plugin.run(terms, None) == [('john', 'Doe')]


# Generated at 2022-06-11 16:05:36.331788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run a test
    lookup_instance = LookupModule()

# Generated at 2022-06-11 16:05:48.136123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_inst = LookupModule()
    # Simple test
    terms = [
        [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
         {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}],
        'authorized',
    ]
    result = lookup_inst.run(terms, None)
    assert result[0][0]['name'] == 'alice'
    assert result[0][1] == '/tmp/alice/onekey.pub'
    assert result[1][0]['name'] == 'alice'
    assert result[1][1] == '/tmp/alice/twokey.pub'

# Generated at 2022-06-11 16:06:00.253771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test good cases:
    terms = None
    terms = [None, None]
    terms = [[None], None]
    terms = [[], None]
    terms = [[{}], None]
    terms = [{}, None]
    terms = [{}, None, None]
    terms = [{}, 'non_existing_subkey', None]
    terms = [{'subkey': []}, 'subkey', None]
    terms = [{'subkey': []}, 'subkey', {'skip_missing': True}]
    terms = [{'subkey': []}, 'subkey', {'skip_missing': False}]
    terms = [{'subkey': []}, 'subkey', {'skip_missing': 'True'}]

# Generated at 2022-06-11 16:06:12.631806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    l = LookupModule()
    l.set_runner(object)
    assert l.run(['[{ "not": "a dictionary" }]', 'key'], variable_manager, loader=loader, inventory=inventory) == []
    assert l.run(['[{ "not": { "a": "dictionary" } }]', 'key'], variable_manager, loader=loader, inventory=inventory) == []

# Generated at 2022-06-11 16:06:23.858506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    fake_variable_manager = []
    my_lookup_plugin = LookupModule(None, fake_variable_manager)
    my_lookup_plugin._templar = None
    my_lookup_plugin._loader = None

    users = [
        {
            'name': 'alice',
            'mysql': {
                'password': 'mysql-password',
                'hosts': [
                    '%',
                    '127.0.0.1',
                    '::1',
                    'localhost',
                ],
            },
        },
        {
            'name': 'bob',
            'mysql': {
                'password': 'other-mysql-password',
                'hosts': [
                    'db1',
                ],
            },
        }
    ]

    # Testing the

# Generated at 2022-06-11 16:06:34.974604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # init
    lookup_module = LookupModule()

    # run tests
    # test case 1: given a list of users, lookup their authorized ssh pubkeys
    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
             {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]

# Generated at 2022-06-11 16:06:47.059716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up a class instance to use
    lookup = LookupModule()
    lookup.set_options({})

    # some cases that we expect to be successful

# Generated at 2022-06-11 16:06:54.502643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # with user_dict
    user_dict = dict(name='alice', username='alice', authorized=['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'])
    assert lookup_plugin._templar is not None
    user_list = lookup_plugin.run([[user_dict], 'authorized'], dict())
    assert user_list == [[user_dict, '/tmp/alice/onekey.pub'], [user_dict, '/tmp/alice/twokey.pub']]
    # with user_list

# Generated at 2022-06-11 16:06:57.964177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {"first_term": "this_is_skipped"},
        "a_dict.a_list.a_value",
    ]
    variables = None

    lu = LookupModule()

    assert lu.run(terms, variables) == []

# Generated at 2022-06-11 16:07:09.017255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def rundata(terms, fail=False):
        """prepare/run lookup, return result list"""
        try:
            return LookupModule().run(terms, {}, **{'variable_start_string': '$', 'variable_end_string': ' '})
        except:
            if fail:
                pass
            else:
                raise

    # test with 3 items: a normal subelements lookup.

# Generated at 2022-06-11 16:08:21.304968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockPlugin:
        def run(self, terms, inject=None, **kwargs):
            return terms
    def mock_variable_manager(loader, template_paths=[]):
        return MockPlugin()
    import doctest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    parser = doctest.DocTestParser()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(None)
    variable_manager.set_variable_manager(mock_variable_manager)
    tests = parser.get_examples(__doc__)

# Generated at 2022-06-11 16:08:26.961604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins


# Generated at 2022-06-11 16:08:35.452732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import json
    if sys.version_info.major == 3:
        # python3 choice
        from unittest import mock
    else:
        # python2 choice
        import mock
    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.errors'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()
    sys.modules['ansible.module_utils.parsing'] = mock.Mock()
    sys.modules['ansible.module_utils.parsing.convert_bool'] = mock.Mock()
    sys.modules['ansible.plugins'] = mock.Mock()
    sys.modules['ansible.plugins.lookup'] = mock.Mock()

# Generated at 2022-06-11 16:08:47.563538
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.lookup.subelements
    # test_error_number_of_terms
    with pytest.raises(AnsibleError):
        ansible.plugins.lookup.subelements.LookupModule({}).run([])
    with pytest.raises(AnsibleError):
        ansible.plugins.lookup.subelements.LookupModule({}).run(["list"])
    with pytest.raises(AnsibleError):
        ansible.plugins.lookup.subelements.LookupModule({}).run(["list", "subkey", "another"])
    with pytest.raises(AnsibleError):
        ansible.plugins.lookup.subelements.LookupModule({}).run([[], "subkey", "another"])

    # test

# Generated at 2022-06-11 16:08:56.743677
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.ansible_lookup_plugins.common import DEFAULT_TERMS

    # test defaults
    lookup_instance = LookupModule()
    terms = [DEFAULT_TERMS[0], DEFAULT_TERMS[1]]

    def check_error(msg, terms):
        try:
            lookup_instance.run(terms, {})
        except AnsibleError as e:
            if msg not in repr(e):
                raise AssertionError("expected error message '%s', but got '%s'" % (msg, str(e)))
        else:
            raise AssertionError("expected an error")

    # test for non dictionary terms

# Generated at 2022-06-11 16:09:08.262452
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert LookupModule.run

    # case 1
    def test_case1():
        # noinspection PyPackageRequirements
        import mock
        assert LookupModule.run is not None

# Generated at 2022-06-11 16:09:11.446928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import doctest
    failed, total = doctest.testmod()
    if failed > 0:
        raise AssertionError(str(failed) + " tests failed in " + __file__)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 16:09:23.314879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    class Fake_self:
        _templar = None
        _loader = None
    class Fake_self2:
        _templar = None
        _loader = None
        def listify_lookup_plugin_terms(a, templar=None, loader=None):
            if a == "var_with_single_item_list":
                return ["var_with_single_item_list"]
            if a == "var_with_single_item_dict":
                return {"var_with_single_item_dict": "var_with_single_item_dict"}
            if a == "var_with_multiple_item_list":
                return ["var_with_multiple_item_list1", "var_with_multiple_item_list2"]

# Generated at 2022-06-11 16:09:33.831728
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModule_Mock(LookupModule):

        def __init__(self):
            self._templar = "templar_mock"
            self._loader = "loader_mock"

        def get_basedir(self, vars):
            return "/basedir"

    # Create test data