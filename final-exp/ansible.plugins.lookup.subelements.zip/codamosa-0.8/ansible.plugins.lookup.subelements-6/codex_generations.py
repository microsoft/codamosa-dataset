

# Generated at 2022-06-11 15:59:43.642129
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import collections
    import pytest
    from ansible.errors import AnsibleError
    # patch templar and loader to prevent import of jinja2
    def patch_templar_loader(self): pass

    lookup_module = LookupModule()
    lookup_module._templar = patch_templar_loader
    lookup_module._loader = patch_templar_loader

    # var users is build as a list of dicts of dicts
    users = []
    alice  = collections.defaultdict(dict)
    bob    = collections.defaultdict(dict)
    carol  = collections.defaultdict(dict)
    alice["name"] = "alice"
    alice["authorized"]["keys"] = ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]

# Generated at 2022-06-11 15:59:53.618265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: fix un-ordered dict problem
    module = LookupModule()
    # check correct argument
    ret = module.run([{'a': {'b': {'c': [{'d': 5}, {'d': 10}]}}}], dict(skip_missing=False))
    assert ret == [[{'a': {'b': {'c': [{'d': 5}, {'d': 10}]}}}, {'d': 5}], [{'a': {'b': {'c': [{'d': 5}, {'d': 10}]}}}, {'d': 10}]]

    # check second argument
    ret = module.run([{'a': {'b': {'c': [{'d': 5}, {'d': 10}]}}}], dict(skip_missing=True))

# Generated at 2022-06-11 16:00:02.182310
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import needed modules
    import os
    import tempfile
    import shutil
    import sys

    # Skip tests if python 2.6 or 2.7, because we use unittest.mock
    if sys.version_info[:2] == (2, 6) or sys.version_info[:2] == (2, 7):
        return

    # Get path to current file
    current_path = os.path.dirname(os.path.abspath(__file__))
    # Get path to test files
    unit_test_files_path = current_path + "/unit_test_files/"

    # import needed modules
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify

# Generated at 2022-06-11 16:00:13.174767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  test the module subelements.py of the Ansible distribution

    import sys
    from ansible.module_utils.six import StringIO

    from ansible.module_utils._text import to_bytes

    import ansible.plugins.lookup.subelements as uut

    _orig_stdout = sys.stdout
    sys.stdout = _captured_stdout = StringIO()

    uut.FLAGS = ['skip_missing',]

    kwargs = {
        '_lookup_plugin': uut,
        '_options': {},
        '_templar': {},
        '_loader': '',
    }

    # test_subelements

# Generated at 2022-06-11 16:00:23.904918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # Simple test on successful run
    lookup_plugin = LookupModule()
    lookup_plugin._templar = DummyTemplar()
    lookup_plugin._loader = DummyLoader()
    terms = [
        {'a': {'b': [{'c': 3}, {'c': 4}, {'c': 5}]}}
    ]
    terms += ['a.b', {'skip_missing': True}]
    result = lookup_plugin.run(terms, {})

# Generated at 2022-06-11 16:00:32.347781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test module run."""

    # Test initialization with ansible.utils.listify
    # Check return value (a list) of empty terms
    lookup_module = LookupModule()
    terms = []
    result = lookup_module.run(terms, None)
    assert result == [], "Return of run() should be an empty list, got %s" % result

    # Check return value of one term (a list)
    terms = [["element1", "element2"], "key"]
    result = lookup_module.run(terms, None)
    assert result == [
            ({"key": ["element1", "element2"]}, "element1"),
            ({"key": ["element1", "element2"]}, "element2")], \
        "Return of run() should be a list of 2 entries, got %s" % result

    #

# Generated at 2022-06-11 16:00:44.318975
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up plugin instance and mock callback
    result = []
    lm = LookupModule()
    def mock_callback(value):
        result.append(value)

    # set up vars
    vars = {'users': [
                {'name': 'alice',
                 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
                 'groups': ['wheel']},
                {'name': 'bob',
                 'authorized': ['/tmp/bob/onekey.pub', '/tmp/bob/twokey.pub'],
                 'groups': ['staff']}],
            'site_admins': ['bob', 'jeff'],
            'inventory_hostname': 'localhost'}

    # test simple subelements
    ret = lm

# Generated at 2022-06-11 16:00:53.491736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupModule(LookupModule):

        def __init__(self, data=None, basedir=None, loader=None,
                     templar=None, shared_loader_obj=None):
            super(MockLookupModule, self).__init__(basedir=basedir,
                                                   loader=loader,
                                                   templar=templar,
                                                   shared_loader_obj=shared_loader_obj)

    class MockLoader(object):
        def __init__(self, inventory):
            self.inventory = inventory

        def get_basedir(self, host):
            return [self.inventory.get_host(host).get_variables().get('inventory_dir')]

    class MockVariableManager(object):
        def __init__(self, loader):
            self.loader = loader


# Generated at 2022-06-11 16:01:03.733378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_plugin = LookupModule()
    test_lookup_plugin._templar = StubTemplar()
    test_lookup_plugin._loader = StubLoader()
    test_lookup_plugin.set_options({'_terms': ['users', 'mysql.hosts']})
    users = [
        {'name': 'alice',
         'mysql': {'hosts': ['%', '127.0.0.1', '::1', 'localhost'],
                   'password': 'mysql-password'}},
        {'name': 'bob',
         'mysql': {'hosts': ['db1'],
                   'password': 'other-mysql-password',
                   'options': {'foo': 'bar'}}}
    ]

# Generated at 2022-06-11 16:01:14.428496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the templar class
    from ansible.template import Templar
    mock_templar = Templar()

    subtest_test_LookupModule_run_terms_raise_terms_error()

    subtest_test_LookupModule_run_terms_normal()

    subtest_test_LookupModule_run_terms_flags()

    subtest_test_LookupModule_run_elementlist_raise_error_invalid_list_or_dict()

    subtest_test_LookupModule_run_elementlist_raise_error_invalid_first_element()

    subtest_test_LookupModule_run_elementlist_raise_error_invalid_value()

    subtest_test_LookupModule_run_elementlist_raise_error_invalid_value_skip_missing_false()

    subtest_

# Generated at 2022-06-11 16:01:34.397380
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:45.892517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ testing the function run of class LookupModule """
    from ansible.module_utils import basic
    from ansible.module_utils.lookup_plugins.subelements import LookupModule
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    options = basic.AnsibleOptions(connection='local', module_path='', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False, listhosts=None, listtasks=None, listtags=None, syntax=None)
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict(conn_pass=None, become_pass=None)

# Generated at 2022-06-11 16:01:54.556067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    module = LookupModule()
    # Test with all keys present
    module.run([[{"a": 1, "b": [{"c": 1, "d": [1, 2, 3]}]}], "b.d"]) == [({"a": 1, "b": [{"c": 1, "d": [1, 2, 3]}]}, 1),
                                                                         ({"a": 1, "b": [{"c": 1, "d": [1, 2, 3]}]}, 2),
                                                                         ({"a": 1, "b": [{"c": 1, "d": [1, 2, 3]}]}, 3)]
    # Test with missing keys

# Generated at 2022-06-11 16:02:04.048045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import yaml
    yaml_doc = '''---
    - {name: alice, authorized: ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], mysql: {password: mysql-password, hosts: ['%', '127.0.0.1', '::1', 'localhost'], privs: ['*.*:SELECT', 'DB1.*:ALL']}, groups: [wheel]}
    - {name: bob, authorized: ['/tmp/bob/id_rsa.pub'], mysql: {password: other-mysql-password, hosts: ['db1'], privs: ['*.*:SELECT', 'DB2.*:ALL']}}
    '''
    y = yaml.load(yaml_doc)
    from ansible.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-11 16:02:17.035249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __builtin__
    class AnsibleModule(object):
        def __init__(self, argspec, **kwargs):
            self.params = argspec
            for k in kwargs:
                setattr(self, k, kwargs[k])
            self.fail_json = __builtin__.fail_json
            self.exit_json = __builtin__.exit_json

    l = LookupModule()
    l._templar = None
    l._loader = None
    l._connection = None
    l._shell = None


# Generated at 2022-06-11 16:02:29.009970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Configure mock_loader
    class MockLoader:
        class MockVars:
            @staticmethod
            def get_vars(**kwargs):
                return {}

        @staticmethod
        def get_basedir(**kwargs):
            return os.getcwd() + '/.ansible/plugins/lookup'

        @staticmethod
        def path_dwim(*args, **kwargs):
            return os.getcwd() + '/.ansible/plugins/lookup/%s' % args[0]

    class MockTemplar:
        @staticmethod
        def template(*args, **kwargs):
            return args[0]

        @staticmethod
        def available_variables(*args, **kwargs):
            return {}

    # Configure mock_module

# Generated at 2022-06-11 16:02:38.946400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """check the run method of the LookupModule class"""
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.listify import listify_lookup_plugin_terms

    loader = AnsibleLoader(None, variable_manager=None)

# Generated at 2022-06-11 16:02:50.253376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    # pytestmark = pytest.mark.skipif(missing_required_lib(), reason="the required library 'MySQL-python' is missing")
    #
    # def setUpModule():
    #     from ansible.utils.hashing import checksum_s
    #     global AUTODETECT_MYSQL_SOCKET
    #     global AUTODETECT_MYSQL_PORT
    #     global TEST_USER_NAME
    #     global TEST_USER_PASSWD
    #     global TEST_USER_HOST
    #     global TEST_USER_DB
    #     global TEST_USER_SVR_CNX
    #     global TEST_USER_CLT_CNX
    #     global TEST_USER_ADMIN_CNX
    #     global TEST_USER_ADMIN_CUR
   

# Generated at 2022-06-11 16:03:01.260442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # empty list of elements
    data = lookup.run([[], 'test'])
    assert data == [], "empty list of elements"

    # list without subkeys, empty list of subelements
    data = lookup.run([[{'test': None}], 'test'])
    assert data == [], "list without subkeys, empty list of subelements"

    # list without subkeys, non-empty list of subelements
    data = lookup.run([[{'test': ['a', 'b', 'c']}], 'test'])
    assert data == [('a',), ('b',), ('c',)], \
        "list without subkeys, non-empty list of subelements"

    # list with subkeys, empty list of subelements

# Generated at 2022-06-11 16:03:11.442728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Import other needed classes for unit test
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupBase

    # Authentic test data
    # Change the values in this part for your test

# Generated at 2022-06-11 16:03:36.981611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    ############################################################################
    import os
    import sys
    import inspect
    #import ansible.plugins.lookup.subelements # This import is needed to test the LookupModule class
    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parent_dir = os.path.dirname(current_dir)
    ansible_dir = os.path.dirname(parent_dir)
    sys.path.insert(0, ansible_dir)
    module = {"ANSIBLE_MODULE_ARGS": {}}

    # Test lookup function of class LookupModule
    ############################################################################
    from ansible.plugins.lookup import subelements
    lookup = subelements.LookupModule()

    # Test help

# Generated at 2022-06-11 16:03:46.814119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.dataloader import DataLoader
    def mdict(**kwargs):
        return dict((k, v) for k, v in kwargs.items())
    ll_m = LookupModule()

    # apply defaults on this test input:

# Generated at 2022-06-11 16:03:58.092617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [ # input list
            {'key1': {'key2': {'key3': [1,2,3]}}},
            {'key1': {'key2': {'key3': [4,5,6]}}},
            {'key1': {'key2': {'key3': [7,8,9]}}},
        ],
        'key1.key2.key3', # subelement key
        {'skip_missing': True} # flags
    ]

    lu = LookupModule()
    result = lu.run(terms, {})
    assert terms[0][0]['key1']['key2'] == {u'key3': [1, 2, 3]}
    assert result[0][0]['key1']['key2'] == {} # should be

# Generated at 2022-06-11 16:04:10.188026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    if PY3:
        import io
        StringIO = io.StringIO
    else:
        from StringIO import StringIO
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

    # test without given data
    lookup_module = LookupModule()
    result = lookup_module.run()
    assert result == []

    # test with valid data

# Generated at 2022-06-11 16:04:21.056194
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:04:29.349737
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import module
    import sys
    sys.path.append('../lib')
    from ansible.plugins.lookup.subelements import LookupModule

    # test run method
    # assert that sub items are extracted from users

# Generated at 2022-06-11 16:04:41.687776
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_1
    # just subelements with a dot to express a sub key
    users = [
        {'name': 'alice', 'groups': ['wheel']},
        {'name': 'bob', 'groups': ['users']},
        {'name': 'charlie', 'groups': ['wheel']},
        {'name': 'dave', 'groups': ['users']}
    ]
    terms = [users, 'groups']
    lookup_mock = LookupModule()
    ret = lookup_mock.run(terms, [])
    assert len(ret) == 8
    assert (users[0], 'wheel') in ret
    assert (users[1], 'users') in ret
    assert (users[2], 'wheel') in ret
    assert (users[3], 'users') in ret
    # test_

# Generated at 2022-06-11 16:04:54.442016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    

# Generated at 2022-06-11 16:05:04.713615
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup test environment
    lookup = LookupModule()

    assert lookup.run(terms=[
        [{"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]}], 
        "authorized", 
        {}
    ],
    variables={}) == [({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/onekey.pub'),
                     ({'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, '/tmp/alice/twokey.pub')]


# Generated at 2022-06-11 16:05:10.294186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # given
    terms = []
    variables = {}
    given_terms = {}
    given_variables = {}

    # when
    lookup = LookupModule()
    result = lookup.run(given_terms, given_variables)

    # then
    assert result == []


# Generated at 2022-06-11 16:05:50.863841
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json_called = False

        class FailJsonException(Exception):
            pass

        def fail_json(self, **args):
            self.fail_json_called = True
            raise TestAnsibleModule.FailJsonException()

    class TestTemplar(object):
        def __init__(self, variables=None):
            self.variables = variables

        def template(self, data):
            if isinstance(data, list):
                return [self.template(i) for i in data]
            elif isinstance(data, dict):
                for key in data.keys():
                    value = data[key]

# Generated at 2022-06-11 16:06:02.174715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        [{'a': 1, 'b': 2, 'c': [10, 11, 12]}, {'a': 11, 'b': 22, 'c': [101, 102, 103]}],
        'c'
    ]
    ret = lookup.run(terms, None)

# Generated at 2022-06-11 16:06:14.021555
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test: If the first element is a list and the second element a string the run method should return a list with tuples
    # Result should be sorted by name

    data = {'users': [{'name': 'alice', 'authorized':['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}, {'name': 'bob', 'authorized':['/tmp/bob/id_rsa.pub']}]}
    terms = [data, 'users', 'authorized']

# Generated at 2022-06-11 16:06:25.400440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialization
    class Subelements:
        def __init__(self, data):
            self.data = data

        def __getitem__(self, index):
            print(self.data)
            return self.data[index]

    import pytest

    data = [
        {
            'name': 'Alice',
            'authorized': [
                '/tmp/Alice/onekey.pub',
                '/tmp/Alice/twokey.pub'
            ],
            'groups' : [ 'wheel' ]

        },
        {
            'name': 'Bob',
            'authorized': [
                '/tmp/Bob/id_rsa.pub'
            ],
            'boolean' : False
        }
    ]

    imported_class = Subelements(data)
    terms = ['authorized']

# Generated at 2022-06-11 16:06:36.132644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible import errors

    lookup_module = LookupModule()

    # test empty list
    result = lookup_module.run([[], "key"])
    assert result == [], "Method run does not return the correct result"

    # test empty key
    result = lookup_module.run([[{}], ""])
    assert result == [], "Method run does not return the correct result"

    # test list with one item and key present
    result = lookup_module.run([[{"key": ["value"]}], "key"])
    assert result == [({'key': ['value']}, 'value')], "Method run does not return the correct result"

    # test list with one item and key present

# Generated at 2022-06-11 16:06:48.268394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = dict()
    l._loader = dict()

# Generated at 2022-06-11 16:06:57.910438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.config.manager import ConfigManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    implicit_ipv4 = inventory.get_host("localhost").vars.get("ansible_all_ipv4_addresses")[0]
    implicit_ipv6 = inventory.get_host("localhost").vars.get("ansible_all_ipv6_addresses")[0]

    # test for False for skip_missing

# Generated at 2022-06-11 16:07:08.976467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    list1 = [
        {'name': 'alice',
         'authorized': ['/tmp/alice/id_rsa.pub',
                       '/tmp/alice/my_rsa.pub']},
        {'name': 'bob',
         'authorized': ['/tmp/bob/id_rsa.pub']},
        {'name': 'charlie',
         'authorized': ['/tmp/charlie/id_rsa.pub',
                       '/tmp/charlie/my_rsa.pub',
                       '/tmp/charlie/my_rsa.pub2']}
    ]
    result = lookup.run(['list1', 'authorized', 'skip_missing'])

# Generated at 2022-06-11 16:07:19.583920
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    lookup_module = LookupModule()

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    # Check if method _raise_terms_error is working
    try:
        _raise_terms_error()
        assert False
    except AnsibleError:
        assert True

    # Check if method _raise_terms_error is working
    try:
        _raise_terms_error("some test")
        assert False
    except AnsibleError:
        assert True

    # check the number of terms

# Generated at 2022-06-11 16:07:29.202870
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use a mock object to test run method of LookupModule
    lookup_module = LookupModule()

    # The first parameter should be a list or a dict, the second a string

# Generated at 2022-06-11 16:08:44.511248
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testcase for method run with skip_missing=False.
    #
    # intput:
    #
    # - terms:    [ [{'a': {'b':[1]}}, {'a': {'b':2}}], 'a.b' ]
    #
    # expected results:
    #
    # - return: [({'a': {'b': [1]}}, 1), ({'a': {'b': [1]}}, 2)]
    terms = [ [{'a': {'b':[1]}}, {'a': {'b':2}}], 'a.b' ]
    lookup_instance = LookupModule()
    ret = lookup_instance.run(terms, None)

# Generated at 2022-06-11 16:08:55.030615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_text

    if PY3:
        from unittest import mock
    else:
        import mock
    mocked_loader = mock.Mock()
    mocked_variable_manager = mock.Mock()
    mocked_inventory = mock.Mock()

    mocked_variable_manager.get_vars.return_value = {}
    mocked_loader.path_dwim.return_value = ['random', 'path']
    mocked_loader.get_basedir.return_value = 'some/path'

    inventory = {'all': {'hosts': {}}}

# Generated at 2022-06-11 16:09:06.559381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # basic usage of subelements
    assert lookup.run([["foo", "bar", "baz"], "1"], []) == ["bar"]
    assert lookup.run([["foo", "bar", "baz"], "10"], []) == []

    # more complex nested lookup structure

# Generated at 2022-06-11 16:09:15.611606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    context._init_global_context(config=dict(DEFAULT_VAULT_IDENTITY_LIST=[]))
    inp = { 'terms': [[{'first': {'second': [1, 2, 3]}}], 'first.second'], 'variables': {}}
    lookup = LookupModule()
    res = lookup.run(**inp)
    assert res == [({'first': {'second': [1, 2, 3]}}, 1), ({'first': {'second': [1, 2, 3]}}, 2), ({'first': {'second': [1, 2, 3]}}, 3)]

    inp = { 'terms': [[{'first': {'second': [1, 2, 3]}}], 'first.third'], 'variables': {}}
    lookup = LookupModule()

# Generated at 2022-06-11 16:09:28.056432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()

    # test invalid terms
    invalid_terms = [
        [],  # no item
        [{}],  # no subkey
        [{}, 'subkey'],  # no list to iterate
        [{'a': {}}, 'subkey'],  # no list to iterate
        [{'a': {'subkey': 'value'}}, 'subkey', {'abc': 'def'}]  # unknown flag
    ]
    for terms in invalid_terms:
        try:
            m.run(terms, {})
            assert False, "Expected error, did not get one"
        except AnsibleError:
            pass

    # test valid terms