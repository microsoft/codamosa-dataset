

# Generated at 2022-06-11 15:59:43.730043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # class name, module name, class for method get_connection
    lookup_module = LookupModule()
    # convert to list, string
    # when variable is empty
    terms = []
    terms[0] = dict()
    terms[1] = dict()
    terms[0] = "test"
    terms[1] = ""
    try:
        # when variable is not empty
        terms[0] = dict()
        terms[1] = dict()
        terms[0] = "test"
        terms[1] = "test"
        lookup_module.run(terms, None)
    except Exception as e:
        print(e)
        return 5
    # when variable is empty
    terms[0] = dict()
    terms[1] = dict()
    terms[0] = "test"

# Generated at 2022-06-11 15:59:53.618511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock class
    class MockTemplar(object):
        def template(self, var):
            return var

    class MockLoader(object):
        def get_basedir(self, play=None):
            return "/home/me/playbooks"

    class MockVars(object):
        def get_vars(self, play=None, host=None, task=None, include_hostvars=False):
            return {}

    class MockInventory(object):
        def get_hosts(self, pattern="all"):
            return []

        def get_host(self, hostname):
            return None

    lookup_plugin = LookupModule()

    mock_templar = MockTemplar()
    lookup_plugin._templar = mock_templar

    mock_loader = MockLoader()
    lookup_plugin

# Generated at 2022-06-11 16:00:02.223209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-11 16:00:13.224277
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestClass(object):
        def __init__(self, value):
            self.value = value
    class UnitTestLookupModule(LookupModule):
        def __init__(self, loader):
            self.loader = loader
        def run(self, terms, variables, **kwargs):
            return super(UnitTestLookupModule, self).run(terms, variables, **kwargs)
        def _get_files_from_terms(self):
            pass

    yaml_data = """
    users:
      - name: alice
        authorized:
          - key1
          - key2
      - name: bob
        authorized:
          - key3
      - name: charlie
        authorized:
          - key4
          - key5
    """

# Generated at 2022-06-11 16:00:17.201131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # build input terms, has to be a list of two or three items
    terms_input = [
        {'alice': {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']}},
        'authorized'
    ]

    # build instance of class LookupModule
    lookup_module = LookupModule()

    # build temporary vars, used for testing
    vars_temp = {}

    # build expected object

# Generated at 2022-06-11 16:00:25.836109
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:00:35.684895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """This method takes a LookupModule object and tests its
       output for expected values.
    """
    lm = LookupModule()

# Generated at 2022-06-11 16:00:47.414186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test_LookupModule_run()
    """
    lookup = LookupModule()
    #
    # test with a list as first term
    #
    terms = [
        [
            {
                'name': 'alice',
                'authorized':
                [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub',
                ]
            },
            {
                'name': 'bob',
                'authorized':
                [
                    '/tmp/bob/id_rsa.pub',
                ]
            },
        ],
        'authorized'
    ]
    ret = lookup.run(terms)
    assert len(ret) == 3

# Generated at 2022-06-11 16:00:55.973402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test content and formats of returned values
    """
    def _list_to_list_of_tuples(mylist):
        """ Make a list of tuples from a list of dictionaries
        """
        ret = []
        for item in mylist:
            ret.append((item,))
        return ret

    # creating test vars

# Generated at 2022-06-11 16:01:06.321939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This is a unit test method for LookupModule.run().
    It returns information about failures, if any, to the caller.

    WARNING:
        The unit test method uses a hard coded path to a lookup plugin.
        This limits the portability of the unit test for other systems.
        Further, there is no guarantee that this path will remain the same,
        or where the lookup plugin will be installed, so it may become
        impossible to run this unit test again in the future.

    :return: True if there are no failures.
    :raises: AssertionError, if there are failures in the tests
    """
    import sys
    import os


# Generated at 2022-06-11 16:01:26.837971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text # not always available in test setups

    # pylint: disable=unused-argument

    # method run(self, terms, inject=None, **kwargs):
    # terms is a list

    # test 1
    terms = []  # wrong number of terms, a list of two or three terms is expected
    lookupmodule = LookupModule()

    try:
        lookupmodule.run(terms, None)
    except: # pylint: disable=bare-except
        pass
    else:
        assert False, "terms: %s => should have raised an exception" % terms

    # test 2
    terms = [ 'word' ]  # wrong number of terms, a list of two or three terms is expected

# Generated at 2022-06-11 16:01:37.176548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 16:01:49.278436
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupmodule = LookupModule()

    # test that the right error is raised if not enough or
    # to many parameters are provided
    assert_raises(AnsibleError, lookupmodule.run, ['a', 'b'])
    assert_raises(AnsibleError, lookupmodule.run, ['a', 'b', 'c', 'd'])

    # test that the right error is raised if the first parameter is
    # not a list
    assert_raises(AnsibleError, lookupmodule.run, 'a', {})
    assert_raises(AnsibleError, lookupmodule.run, {}, {})

    # test that the right error is raised is the second parameter
    # is not a string
    assert_raises(AnsibleError, lookupmodule.run, [], {})

# Generated at 2022-06-11 16:02:00.818752
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class for test
    class TestLookupModule(LookupModule):

        def __init__(self):
            self._templar = Mock()

        def get_basedir(self, host):
            return '/'

    # Mocks
    class Mock:
        def __init__(self):
            self._templar = None

    test = TestLookupModule()
    mock = Mock()
    test._templar = mock
    test._templar.template = lambda param: param

    # 1. No terms provided
    terms = []
    variables = {}
    ret = test.run(terms, variables)
    assert ret == []

    # 2. No terms provided
    terms = [""]
    variables = {}
    ret = test.run(terms, variables)
    assert ret == []

    # 3. Bad

# Generated at 2022-06-11 16:02:14.308592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json

    class Options(object):
        connection = 'local'
        module_path = './'
        forks = 1
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False

    loader = DataLoader()
    options = Options()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="./tests/inventory.ini")

# Generated at 2022-06-11 16:02:22.254635
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # a list of dictionaries
    users = [
        {'name': 'alice',
         'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
        {'name': 'bob',
         'authorized': ['/tmp/bob/id_rsa.pub']},
    ]

    # create the lookup module
    lookup_module = LookupModule()

    # list one subelement
    subelements = lookup_module.run([users, 'authorized'], dict())
    assert len(subelements) == 2
    assert ('/tmp/alice/onekey.pub',) in subelements
    assert ('/tmp/alice/twokey.pub',) in subelements
    assert ('/tmp/bob/id_rsa.pub',)

# Generated at 2022-06-11 16:02:35.320711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    json_file_path = '../../files/subelements_test_data.json'
    f = open(json_file_path, 'r')
    json_file_data = json.loads(f.read())
    assert 2 == len(json_file_data)

    users = json_file_data[0]
    assert 4 == len(users)

    for user in users:
        assert 4 == len(user)
        assert 'authorized' in user
        assert 'mysql' in user
        assert 'groups' in user

    terms = json_file_data[1]
    assert ['alice', '/tmp/alice/onekey.pub'] == terms[0]
    assert 'alice.authorized.0' == terms[1]
    assert True == terms[2]

    lu = Lookup

# Generated at 2022-06-11 16:02:47.822210
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import unittest
    from mock import Mock, patch
    from io import StringIO

    class TestLookupModule(unittest.TestCase):

        # ------------------------------------------------------------------- #
        # Test run

        def test_LookupModule_run_correct_input_parameter_type(self):

            # Test function with correct input parameter types
            terms = [[{'key1': ['value1', 'value2']}], 'key1' ]
            variables = {}
            l = LookupModule()

            l.run(terms, variables)


# Generated at 2022-06-11 16:02:59.734930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    # subelements lookup: method run
    def run(terms, variables=None, **kwargs):
        import ansible.plugins.lookup as lookup_plugins
        lpm = lookup_plugins.LookupModule()
        return lpm.run(terms, variables=variables, **kwargs)

    # missing argument '_terms'
    try:
        run([])
        assert False, "AnsibleError should be raised"
    except AnsibleError as e:
        assert "subelements lookup expects a list of" in str(e)

    # invalid argument '_terms': first term not a list (or dict), second term not a string

# Generated at 2022-06-11 16:03:01.627071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # tests skip_missing flag
    # tests dict as first element and list as first element
    # tests subelements syntax "a.b.c" in terms[1]
    # tests with_subelements syntax [ terms[0], terms[1] ]
    pass

# Generated at 2022-06-11 16:03:16.590842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import dependencies
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir))
    # import test library
    import test_utils
    # run test case
    test_utils.run(LookupModule, input_data=[('arguments', 'to', 'run')], expected_result=['arguments', 'to', 'run'])

# Generated at 2022-06-11 16:03:25.340740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """
    def _assert_subelements(subelements, expected):
        """ unit test helper """
        lookup_module = LookupModule()
        result = lookup_module.run(subelements, {})
        assert result == expected

    # subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey

# Generated at 2022-06-11 16:03:33.515504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    terms = [
        [
            {'name': 'alice'},
            {'name': 'bob'}
        ],
        'name'
    ]
    variables = {}
    class DummyTemplar:
        def __init__(self, loader=False):
            self.loader = loader


# Generated at 2022-06-11 16:03:42.338863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init a module with no parameters
    module = LookupModule()
    # init parameters
    terms = [
        [
            {'ansible_facts': {'test': 'ok'}, 'skipped': False},
            {'ansible_facts': {'test': 'nok'}, 'skipped': True},
        ],
        'ansible_facts.test'
    ]
    # no variables, no extras
    variables = {}
    # run module
    result = module.run(terms, variables)
    # verify result
    assert result == ['ok']

# Generated at 2022-06-11 16:03:52.573432
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:04:01.365869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""

    import unittest.mock
    from ansible.template.safe_eval import safe_eval

    def mock_templar_inner(*args, **kwargs):
        return args, kwargs

    lookup_base = unittest.mock.MagicMock(LookupBase)
    lookup_base._templar.side_effect = mock_templar_inner

    # noinspection PyTypeChecker
    lookup_base._loader = None  # accept string only

    # noinspection PyUnresolvedReferences
    lookup_base.run.return_value = None  # return value doesn't matter in this test

    # noinspection PyTypeChecker
    lookup = LookupModule(loader=None, templar=None, variables=None)

    # 1

# Generated at 2022-06-11 16:04:12.192243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def assert_lookup(source, keys, expected):
        lookup = LookupModule()
        result = lookup.run([source, keys])
        assert result == expected

    assert_lookup(
        source=dict(foo=dict(bar=dict(baz=["qux", "quux"]))),
        keys="foo.bar.baz",
        expected=[(dict(bar=dict(baz=["qux", "quux"]), foo=dict(bar=dict(baz=["qux", "quux"]))), 'qux'),
                  (dict(bar=dict(baz=["qux", "quux"]), foo=dict(bar=dict(baz=["qux", "quux"]))), 'quux')])


# Generated at 2022-06-11 16:04:23.667023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = [
        [
          {'name': 'alice'},
          {'name': 'bob'}
        ],
        'name',
    ]
    result = module.run(terms, [])
    assert result == [('alice', 'alice'), ('bob', 'bob')], result

    terms = [
        [
          {'name': 'alice'},
          {'name': 'bob'},
          {'skipped': True}
        ],
        'name',
    ]
    result = module.run(terms, [])
    assert result == [('alice', 'alice'), ('bob', 'bob')], result


# Generated at 2022-06-11 16:04:24.975520
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:04:37.639735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.set_options({})

    users = [
        {"name": "alice",
         "authorized": [
             "/tmp/alice/onekey.pub",
             "/tmp/alice/twokey.pub"]},
        {"name": "bob",
         "authorized": [
             "/tmp/bob/id_rsa.pub"]}
    ]

    expected = [
        ("alice", "/tmp/alice/onekey.pub"),
        ("alice", "/tmp/alice/twokey.pub"),
        ("bob", "/tmp/bob/id_rsa.pub")
    ]
    results = lm.run([users, "authorized"])

    assert results == expected


# Generated at 2022-06-11 16:05:02.524249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    import json
    
    lookup_module = LookupModule()

    test_data = { 'spoofing': {'service': {'name': 'Spoofing Test'}, 'company': {'name': 'Spoofing Company'}, 'data': {'name': 'Test'}}}
    test_terms = [ test_data ]
    
    assert(lookup_module.run(test_terms, None)[0][0] == test_data['spoofing'])



# Generated at 2022-06-11 16:05:14.679588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # test that _raise_terms_error is getting the msg passed
    # the test will at first fail with an expected msg from _raise_terms_error
    # and then fail with the passed msg to _raise_terms_error
    # and then pass when the test runs with the passed msg for _raise_terms_error
    try:
        l._templar = "templar"
        l._loader = "loader"
        l.run([[],1,2,3], "variables")
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items, " in str(e)

# Generated at 2022-06-11 16:05:24.973709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pprint
    if sys.version_info.major < 3:
        import __builtin__ as builtins
    else:
        import builtins

    class Mocker(object):
        skipper = False
        def __call__(self, *args, **kwargs):
            if len(args) == 2:
                if args[0]=='subelements':
                    return args[1]
            if len(args) == 3:
                if args[0]=='subelements':
                    if self.skipper:
                        ret = args[1]
                        for i in range(len(ret)):
                            if isinstance(ret[i], dict):
                                ret[i]['skipped']=True
                        return ret

# Generated at 2022-06-11 16:05:36.612158
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:05:48.435208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # Convert dict to list
    yout = lookup_instance.run([{}, 'name'], None)
    assert yout == [], "expected [], got %s" % yout

    # Convert dict to list
    yout = lookup_instance.run([{'skipped':True}, 'name'], None)
    assert yout == [], "expected [], got %s" % yout

    users = [{'skipped':False, 'name':'alice'}, {'skipped': True, 'name': 'bob'}]
    yout = lookup_instance.run([users, 'name'], None)
    assert yout == [('alice', 'alice')], "expected [('alice', 'alice')], got %s" % yout

    # Convert nested

# Generated at 2022-06-11 16:06:00.590452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create LookupModule object
    lookup = LookupModule()
    lookup._loader = MagicMock()
    lookup._templar = MagicMock()
    # create some data

# Generated at 2022-06-11 16:06:12.891103
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    def nuniq(seq):
        "returns the number of unique elements in seq"
        seen = set()
        seen_add = seen.add
        return len(filter(lambda x: not (x in seen or seen_add(x)), seq))

    lookup = LookupModule()
    lookup.set_loader('unused')  # to pass the test: only used by templar

# Generated at 2022-06-11 16:06:24.212697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError):
        LookupModule().run(terms=None, variables=dict())

    flags_missing = LookupModule().run(terms=[
        {"x": {"a": 1}}, "y", {"skip_missing": False}],
        variables=dict())
    assert len(flags_missing) == 0

    flags_missing_skip = LookupModule().run(terms=[
        {"x": {"a": 1}}, "y", {"skip_missing": True}],
        variables=dict())
    assert len(flags_missing_skip) == 0

    x1 = LookupModule().run(terms=[
        {"x": {"a": 1}}, "x"],
        variables=dict())
    assert len(x1) == 1
    assert x1[0][0] == {"a": 1}


# Generated at 2022-06-11 16:06:35.210634
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:06:47.332604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_ret = LookupModule().run([
        [
            {
                "d": {
                    "e": [1, 2, 3]
                }
            },
            {
                "d": {
                    "e": [1, 2]
                }
            }
        ],
        "d.e",
    ], [])

# Generated at 2022-06-11 16:07:30.364311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os
    import sys

    # create PlayContext
    loader, inventory, variable_manager = _init_mock_objects()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '10.10.10.10'
    play_context.accelerate = 10

# Generated at 2022-06-11 16:07:40.588782
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    users = [{'mysql': {'password': 'mysql-password', 'hosts': ['%', '127.0.0.1', '::1', 'localhost'], 'privs': ['*.*:SELECT', 'DB1.*:ALL']}, 'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']}, {'mysql': {'password': 'other-mysql-password', 'hosts': ['db1'], 'privs': ['*.*:SELECT', 'DB2.*:ALL']}, 'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    subelements = "mysql.hosts"
    args = {'skip_missing': False}


# Generated at 2022-06-11 16:07:48.889948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''test method run of module LookupModule'''

    # test case 1
    # call run with all parameters valid and verify it returns expected value
    subelements_input = [[{'greeting': 'hello', 'name': 'alice'}, {'greeting': 'hallo', 'name': 'bob'}], 'name']
    expected_value = [({'greeting': 'hello', 'name': 'alice'}, 'alice'), ({'greeting': 'hallo', 'name': 'bob'}, 'bob')]
    my_lookup_module = LookupModule()
    result_value = my_lookup_module.run(subelements_input, None)

# Generated at 2022-06-11 16:07:59.457530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # Create object under test
    lookup_plugin = LookupModule()

    # Define arguments
    terms = [
        [
            {'ip': '10.0.0.1', 'vlan': 1234},
            {'ip': '10.0.0.2', 'vlan': 1235},
            {'ip': '10.0.0.3', 'vlan': 1236}
        ],
        'ip'
    ]
    variables = {}

    # Run unit test
    result = lookup_plugin._get_terms(terms, variables, [], None)
    for element in result:
        assert 'ip' in element[0]
        assert 'vlan' in element[0]
        assert element[1] == element[0]['ip']


# Generated at 2022-06-11 16:08:11.185702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_error_msg = "subelements lookup expects a list of two or three items"
    first_term_error_msg = "first a dict or a list, second a string pointing to the subkey"
    last_term_error_msg = "the optional third item must be a dict with flags %s" % FLAGS

    lookup_subelements = LookupModule()

    # check for required terms
    try:
        lookup_subelements.run([], variable=None)
        assert False, "run should fail without terms"
    except AnsibleError as e:
        assert e.message == 'one of the following is required: "list, list, dict", "list, dict, dict"'

    # check for wrong number of terms (1)

# Generated at 2022-06-11 16:08:20.427890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test the run method without flags
    testlookup = LookupModule()
    # fake a dictionary holding the needed data structure

# Generated at 2022-06-11 16:08:32.045434
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:08:44.270190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean

    # example1
    example1_lookup_plugin = LookupModule()
    example1_lookup_plugin._templar = DummyTemplar()
    example1_lookup_plugin._loader = DummyLoader()


# Generated at 2022-06-11 16:08:54.911449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import the class object
    from ansible.plugins.lookup.subelements import LookupModule

    # define test elements

# Generated at 2022-06-11 16:09:06.506287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import yaml

    # Create a mock inventory with a variable in a group
    inventory = """
    [group2]
    host2
    """
    loader = DataLoader()
    inventory = loader.load(StringIO(inventory))
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a list of hashes