

# Generated at 2022-06-11 15:59:41.853024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Prepare mock objects
    class MockLookupBase(LookupBase):
        def __init__(self):
            pass
        def run(self, terms, variables, **kwargs):
            pass
    lookup_base_mock = MockLookupBase()

    # Create class instance
    lookup_module_instance = LookupModule()
    lookup_module_instance._templar = lookup_base_mock
    lookup_module_instance._loader  = lookup_base_mock

    # Call method
    lookup_module_instance.run([], {})

# Generated at 2022-06-11 15:59:52.315931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_plugin = LookupModule()
    # First term is a list

# Generated at 2022-06-11 16:00:01.139501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given:
    users = [
        {"name": "Alice",
         "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"],
         "mysql": {"password": "mysql-password",
                   "hosts": ["%", "127.0.0.1", "::1", "localhost"],
                   "privs": ["*.*:SELECT", "DB1.*:ALL"]}},
        {"name": "Bob",
         "authorized": ["/tmp/bob/id_rsa.pub"],
         "mysql": {"password": "other-mysql-password",
                   "hosts": ["db1"],
                   "privs": ["*.*:SELECT", "DB2.*:ALL"]}}]

    # when:

# Generated at 2022-06-11 16:00:08.767419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    # first test case: list of dicts with item keys that exist in that list
    data = {"a": {"bb": [1,2,3], "cc": [4,5,6], "dd": [7,8,9]}, "b": {"bb": [1,2,3], "cc": [4,5,6], "dd": [7,8,9]}}
    terms = [data, "bb"]
    result = LookupModule().run(terms, {}, variables=combine_vars(data, {}))

# Generated at 2022-06-11 16:00:13.818272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_text


# Generated at 2022-06-11 16:00:24.265326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instance of LookupModule to test
    lookup_plugin = LookupModule()

    # Test with a valid dictionary
    dictionary = [
        {
            'name': 'dictionary_list_0',
            'authorized': ['/tmp/dictionary_list_0/id_rsa.key','/tmp/dictionary_list_0/id_rsa2.key'],
        },
        {
            'name': 'dictionary_list_1',
            'authorized': ['/tmp/dictionary_list_1/id_rsa.key','/tmp/dictionary_list_1/id_rsa2.key'],
        },
    ]
    terms = [dictionary,'authorized']
    result = lookup_plugin.run(terms,None)
    assert len(result) == 4

# Generated at 2022-06-11 16:00:32.893439
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test missing list of dicts in terms
    terms = [None, 'stamkey']
    l = LookupModule()
    try:
        l.run(terms, {})
    except AnsibleError as e:
        assert "list of two" in str(e), "Should raise AnsibleError with wrong number of terms"

    # test missing subkey in terms
    terms = [[{'stamkey':'stamvalue'}], None]
    l = LookupModule()
    try:
        l.run(terms, {})
    except AnsibleError as e:
        assert 'first a dict' in str(e), "Should raise AnsibleError with wrong term types"

    # test bad subkey name
    terms = [[{'stamkey':'stamvalue'}], 'bad.[subkey]']

# Generated at 2022-06-11 16:00:44.821629
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:00:53.794471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import os
    import tempfile

    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs


# Generated at 2022-06-11 16:00:55.239665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(LookupModule(), [], {}) is None

# Generated at 2022-06-11 16:01:14.347538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.ansible_release import __version__ as ANSIBLE_VERSION

    # prepare test variables

# Generated at 2022-06-11 16:01:26.329465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    # check lookup terms - check number of terms
    y = x.run([], {})
    assert y == []

    y = x.run(["", ""], {})
    assert y == []

    y = x.run(["", "", ""], {})
    assert y == []

    # first term should be a list, second a string holding the subkey
    y = x.run(["list", "string"], {})
    assert y == []

    y = x.run(["", "list", "string"], {})
    assert y == []

    y = x.run(["list", ""], {})
    assert y == []

    # check for optional flags in third term
    y = x.run(["", "", ""], {})
    assert y == []


# Generated at 2022-06-11 16:01:36.885699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            {
                'name' : 'alice',
                'authorized': ['/tmp/alice/onekey.pub'],
            },
            {
                'name' : 'bob',
                'authorized': ['/tmp/bob/twokey.pub'],
            }
        ],
        "authorized"
    ]
    lookup_module = LookupModule()
    # test method run of class LookupModule
    subelements = lookup_module.run(terms=terms, variables=None)

# Generated at 2022-06-11 16:01:48.991468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # No error if second term is not a string
    try:
        module.run([[{'skipped': False}], {'a': 'b'}], {})
    except AnsibleError as e:
        assert False, "raised AnsibleError but should not: %s" % e
    except Exception:
        pass

    # Error if first term is not a list or a dict
    try:
        module.run([{'skipped': False}], {})
        assert False, "Error not raised"
    except AnsibleError as e:
        assert True

    # No error if skipped is True in first term dictionary

# Generated at 2022-06-11 16:02:00.428010
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:13.843363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    from ansible.module_utils.six import binary_type

    # create a fake ansible environment with variables

# Generated at 2022-06-11 16:02:22.031788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.subelements import LookupModule
    lookup_instance = LookupModule()
    lookup_instance._templar = None
    lookup_instance._loader = None

    # Load unit test vars
    variables = {}
    with open("test/lib/ansible/plugins/lookup/test_subelements_vars.yml") as fp:
        variables = yaml.load(fp, Loader=yaml.FullLoader)

    # Test first lookup - should return a list of tuples
    # of which each tuple contains a dictionary and a string
    # of which each string is a path to a pubkey
    lookup_result = lookup_instance.run([
        variables["lookup_terms"],
        ], variables)

# Generated at 2022-06-11 16:02:35.285207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # retrieve lookup object
    lookup = LookupModule()

    # Check case where first term is a list.
    # Return value should be a list of all the subkey values, in
    # the order of the subkeys.
    elementList = [
        {'subkey1': 1, 'subkey2': 2},
        {'subkey1': 3, 'subkey2': 4},
        {'subkey1': 5, 'subkey2': 6},
    ]

    ret = lookup.run([elementList, 'subkey1'], None)
    assert ret == [ {'subkey1': 1, 'subkey2': 2}, {'subkey1': 3, 'subkey2': 4}, {'subkey1': 5, 'subkey2': 6} ], ret

# Generated at 2022-06-11 16:02:47.773179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar


# Generated at 2022-06-11 16:02:59.685551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test1
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    testterms = [{'item1': {'mysql': {'password': 'mysql-password',
      'privs': ['*.*:SELECT',
       'DB1.*:ALL'],
      'hosts': ['%',
       '127.0.0.1',
       '::1',
       'localhost']}},
    'item2': {'mysql': {'password': 'other-mysql-password',
      'privs': ['*.*:SELECT',
       'DB2.*:ALL'],
      'hosts': ['db1']}}},
  'mysql.hosts']

# Generated at 2022-06-11 16:03:22.328902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _get_my_class(**kwargs):
        return LookupModule()

    lookup_obj = _get_my_class()
    assert lookup_obj._lookup_name == 'subelements'
    assert lookup_obj.run(terms=[['a', 'b']], variables={}) == [[('a', 'a'), ('b', 'b')]]
    assert lookup_obj.run(terms=[['a']], variables={}) == [[('a', 'a')]]
    assert lookup_obj.run(
        terms=[
            {
                'some1': {'a': 'b'},
                'some2': {'a': 'b'}
            },
            'a'
        ],
        variables={}
    ) == [('some1', 'b'), ('some2', 'b')]
    assert lookup_obj

# Generated at 2022-06-11 16:03:32.073410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for LookupModule.run() method - basic test
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory


# Generated at 2022-06-11 16:03:43.964742
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import libraries
    import sys
    sys.modules['__main__'].LookupBase = LookupBase
    from ansible.plugins.lookup import subelements

    # create or load mock variables and classes
    from unittest.mock import MagicMock
    _templar = MagicMock()
    _loader = MagicMock()

    # create or load mock functions
    def listify_lookup_plugin_terms(terms, templar, loader):
        return terms
    sys.modules['__main__'].listify_lookup_plugin_terms = listify_lookup_plugin_terms

    # create instance of LookupModule
    lm = subelements.LookupModule()
    lm._templar = _templar
    lm._loader = _loader

    # test subelements.run

# Generated at 2022-06-11 16:03:55.556195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('subelements')
    # First test case with two elements in the lookup item,
    # user and authorized_key. The user contains a list of authorized keys.
    # Generate 3 authorized keys and 3 users with that authorized key.
    authorized_key1 = 'authorized_key1'
    authorized_key2 = 'authorized_key2'
    authorized_key3 = 'authorized_key3'
    user1 = {'name': 'user1', 'authorized': [authorized_key1]}
    user2 = {'name': 'user2', 'authorized': [authorized_key2]}
    user3 = {'name': 'user3', 'authorized': [authorized_key3]}
    users = [user1, user2, user3]

    # Compare the results

# Generated at 2022-06-11 16:04:07.023962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    skip_missing_false = '{ "skip_missing": false }'
    skip_missing_true = '{ "skip_missing": true }'
    skip_missing_false_AnsibleUnsafeText = AnsibleUnsafeText(skip_missing_false)
    skip_missing_true_AnsibleUnsafeText = AnsibleUnsafeText(skip_missing_true)

    class PluginOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    inventory = Inventory

# Generated at 2022-06-11 16:04:14.812699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the following test was extracted from file test/units/plugins/lookup/test_subelements.py
    # and was adapted to be independent from other ansible testing framework
    # (import _MOCK_VERSION, mock_lookup_plugin, mock_loader and mock_templar were removed)
    import copy
    import json

    # Mock ansible.module_utils.parsing.convert_bool
    from ansible.module_utils.parsing.convert_bool import boolean as mock_boolean
    def my_boolean(a, strict=False):
        return mock_boolean(a, strict)
    # Mock ansible.errors.AnsibleError
    class MockAnsibleError(Exception):
        pass
    # Mock ansible.utils.listify_lookup_plugin_terms

# Generated at 2022-06-11 16:04:25.965745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.template import Templar

    test_data = ['foo', 'bar', 'baz']
    test_dict = {'foo': 1, 'bar': 2, 'baz': 3}
    test_list = [
        {'key': 'foo', 'value': 1},
        {'key': 'bar', 'value': 2},
        {'key': 'baz', 'value': 3}
    ]

    lookup = lookup_loader.get('subelements')

    # Convert list and dict to list of tuples

# Generated at 2022-06-11 16:04:38.790819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with all parameters set
    subelements = LookupModule().run(([{'a': 'b', 'c': 'd'}, {'c': 'd'}], 'c', {'skip_missing': True}), {}, **{})
    assert subelements == [('b',),('d',)]

    # Test with 1 parameter set
    subelements = LookupModule().run(([{'a': 'b', 'c': 'd'}, {'c': 'd'}], 'a'), {})
    assert subelements == [('b',)]

    # Test with 2 parameters set
    subelements = LookupModule().run(([{'a': 'b', 'c': 'd'}, {'c': 'd'}], 'a', {}), {})

# Generated at 2022-06-11 16:04:46.120401
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:04:58.489870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # check different types of terms
    expected_result = []
    result = module.run(['a', 'b'], dict())
    assert result == expected_result, "Expected result %s to be %s" % (result, expected_result)
    result = module.run(['a', 'b'], dict(), variable_manager={})
    assert result == expected_result, "Expected result %s to be %s" % (result, expected_result)
    result = module.run(['a', 'b'], dict(), loader=dict())
    assert result == expected_result, "Expected result %s to be %s" % (result, expected_result)
    result = module.run(['a', 'b'], dict(), templar={})

# Generated at 2022-06-11 16:05:34.533479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    subelements = LookupModule()

    # got 2 or 3 items
    try:
        subelements.run([{'a': 1, 'b': 2}])
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items"
    else:
        raise Exception('AnsibleError not raised')
    try:
        subelements.run([{'a': 1, 'b': 2}, 'a', {'a': 1}, 'b'])
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items"
    else:
        raise Exception('AnsibleError not raised')

    # first term should be a

# Generated at 2022-06-11 16:05:45.949826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    BOOLEANS_FALSE.append('skip_missing')

    lookup_module = LookupModule()
    lookup_module.set_options({'variables': {}})

    # should fail

# Generated at 2022-06-11 16:05:53.397086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_LookupModule_run: execute with empty list of terms
    t = []
    l = LookupModule()
    try:
        l.run(t, variables=None)
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "
    else:
        assert False, "Empty list of terms should raise an AnsibleError"

    # test_LookupModule_run: execute with non-list of terms
    t = "string is wrong"
    try:
        l.run(t, variables=None)
    except AnsibleError as e:
        assert str(e) == "subelements lookup expects a list of two or three items, "
    else:
        assert False, "Non-list of terms should raise an AnsibleError"

    # test

# Generated at 2022-06-11 16:06:03.245028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    sl = LookupModule()


# Generated at 2022-06-11 16:06:14.798658
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # create a stub LookupModule object
    lm = LookupModule()

    # to pass tests, the returned value must be a list of two-element tuples
    # (value_from_list, subelements)

    # test 1: empty list
    assert lm.run([[]], {}, skip_missing=False) == []

    # test 2: empty dict
    assert lm.run([{}], {}, skip_missing=False) == []

    # test 3: simple case
    lookup_input = [
        {"key0": [{"subelement": "value0"}]},
        {"key1": [{"subelement": "value1"}]}
    ]
    assert l

# Generated at 2022-06-11 16:06:25.881961
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_run(terms, variables, result):
        lookup = LookupModule()
        # run method of LookupModule
        subelements = lookup.run(terms, variables)
        # check results
        assert subelements == result


# Generated at 2022-06-11 16:06:36.268369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    module = AnsibleModule(argument_spec={'var': dict(type='dict', required=True)})

    def itervars(varname, params):
        ret = []
        obj = module.params[varname]
        while True:
            if obj is None:
                break
            if isinstance(obj, AnsibleBaseYAMLObject):
                obj = obj.get_wrapped_data()
            if not isinstance(obj, list):
                obj = [obj]
            for elem in obj:
                ret.append({
                    '_raw': elem,
                    varname: elem,
                })
            break
        return ret


# Generated at 2022-06-11 16:06:48.372797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testclass = LookupModule()
    list_of_dicts = [{'id': 1, 'fruits': ['banana', 'apple']}, {'id': 2, 'fruits': ['orange', 'peach']}]
    subelements = 'fruits'
    test_ansible_errors = []
    _ansible_errors = []
    #test_ansible_errors.append(AnsibleError('test_value'))
    import sys, six
    if six.PY2:
        from mock import patch, MagicMock
    else:
        from unittest.mock import patch, MagicMock

# Generated at 2022-06-11 16:06:58.024934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    users = [
        {"name": "alice", "groups": ["wheel"]},
        {"name": "bob", "groups": ["adm"]}
    ]
    terms = [
        users,
        "groups"
    ]
    gathered = lm.run(terms, {})
    expected = [
        [
            {"name": "alice", "groups": ["wheel"]},
            "wheel"
        ],
        [
            {"name": "bob", "groups": ["adm"]},
            "adm"
        ],
    ]
    assert gathered == expected

    terms = [
        users,
        "groups",
        {"skip_missing": True}
    ]
    gathered = lm.run(terms, {})

# Generated at 2022-06-11 16:07:09.056164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    class DummyVars(object):
        def __init__(self):
            self.ansible_facts = {
                "domains": [
                    { "name": "one.example.com", "ip": "1.2.3.4", "children": [
                        { "name": "aaa.one.example.com" },
                        { "name": "bbb.one.example.com" }
                    ] },
                    { "name": "two.example.com", "ip": "2.3.4.5", "children": [
                        { "name": "ccc.two.example.com" },
                        { "name": "ddd.two.example.com" }
                    ] }
                ]
            }

    lookup_plugin

# Generated at 2022-06-11 16:08:26.836448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test help function
    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    # test lookup
    lookup = LookupModule()

    # test wrong input
    with pytest.raises(AnsibleError):
        lookup.run([], [])

    with pytest.raises(AnsibleError):
        lookup.run([1, 2, 3], [])

    # test wrong lookup terms
    with pytest.raises(AnsibleError):
        lookup.run([1, 2], [])

    with pytest.raises(AnsibleError):
        lookup.run([{'key': 'value'}, 1], [])

    with pytest.raises(AnsibleError):
        lookup.run

# Generated at 2022-06-11 16:08:35.427782
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def _get_terms(options):
        # get terms of a options dictionary
        return [options[x] for x in ['subelements', 'key', 'flags']]

    # define test data

# Generated at 2022-06-11 16:08:47.510525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    lookup_module = LookupModule()
    lookup_module.set_loader(loader)
    lookup_module.set_inventory(inventory)
    lookup_module.set_variable_manager(variable_manager)

    # create task result for this simple test

# Generated at 2022-06-11 16:08:56.715837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test data
    lookup_input = {
        'first_level1': {
            'second_level0': [
                "first_second_level0",
                "second_second_level0"
            ],
            'second_level1': "text_second_level1",
        },
        'first_level2': {
            'second_level2': [
                "first_second_level2",
                "second_second_level2",
                "third_second_level2",
            ]
        },
        'first_level3': {
            'second_level3': {
                'third_level3': [
                    "first_third_level3",
                    "second_third_level3",
                ]
            },
        },
    }

    # expected output

# Generated at 2022-06-11 16:09:08.196573
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up a mock templar
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # set up a list of test data

# Generated at 2022-06-11 16:09:17.909614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """This method unit tests method run() of class LookupModule."""
    # List lookup modules, to have access to the class LookupModule.
    lookup_plugins = list(map(lambda x: x.strip(), """action add_host add_group assemble async_status async_wrapper blockinfile
    copy lineinfile patch replace service shell slurp stat template unarchive uri user""".split()))
    # print(lookup_plugins)

    # Load all lookup modules.
    for lookup_plugin in lookup_plugins:
        # print(lookup_plugin)
        exec("from ansible.plugins.lookup import %s" % lookup_plugin)

    # Invoke method run() of class LookupModule.
    # This test is incomplete.
    exit(0)

# Generated at 2022-06-11 16:09:30.426346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   '''
   Test run method of class LookupModule.
   '''
   # pylint: disable=too-many-lines
   # pylint: disable=too-many-statements
   # pylint: disable=too-many-branches

   from ansible.module_utils.six import string_types
   from ansible.module_utils.parsing.convert_bool import boolean

   lookup = LookupModule()

   #
   # test error conditions - wrong number of terms
   #
   try:
      # pylint: disable=line-too-long
      lookup.run(["error condition - wrong number of terms - first term should be a list (or dict) and second a string holding the subkey", "username"], None)
   except AnsibleError:
      pass