

# Generated at 2022-06-11 15:59:44.812846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text

    class PluginLookupModule(LookupModule):   # simulate the lookup module in a local way
        def __init__(self):
            self._loader = None
            self._templar = None

        def run(self, terms, variables, **kwargs):
            assert variables['vault_password'] == 'vault-password'
            assert isinstance(terms, list) and len(terms) == 2 and terms[0] == '{{ users }}' and terms[1] == 'mysql.hosts'
            if PY3:
                assert isinstance(terms[0], AnsibleUnsafeText)

# Generated at 2022-06-11 15:59:54.326006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
    import test_utils as tu
    tu.skip_if_py3()

    def test_run(terms, exp):
        data = LookupModule().run(terms, None)
        assert(data == exp)

    test_run([['foo', 'bar'],'baz'], [])


# Generated at 2022-06-11 16:00:04.818189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unit.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def _check_run(list_of_dicts, subkey_list, raw_result, flags=None,
                   list_of_dicts_name='users', subkey_list_name='authorized',
                   skip_missing=False):
        templar = Templar(loader=DictDataLoader({}))
        variable_manager = VariableManager()

        terms = [list_of_dicts, subkey_list]
        if flags:
            terms.append(flags)
        result = LookupModule().run(terms, variable_manager, templar=templar)

# Generated at 2022-06-11 16:00:16.465787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
            {
                "name": "alice",
                "authorized": [
                    "/tmp/alice/onekey.pub",
                    "/tmp/alice/twokey.pub"
                    ]
                },
            {
                "name": "bob",
                "authorized": [
                    "/tmp/bob/id_rsa.pub"
                    ]
                }
            ]
    result = LookupModule().run(terms, None)
    assert len(result) == 3, "Expected result length is 3: {}".format(result)
    for item in result:
        assert isinstance(item[0], dict), "Expected item[0] to be a dict: {}".format(item[0])

# Generated at 2022-06-11 16:00:25.712077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    import os
    lookup.set_options(direct=dict(vars=dict(HOME=os.environ['HOME'])))
    # lookup.set_loader(None)

    # test with good input
    fake_loader = DictDataLoader(dict(
        basedir='/base/dir/',
        _ansible_vars=dict(foo='baz',
                           passwords=dict(mysql='abc123',
                                          postgres='def456')),
        _ansible_no_log=False))
    lookup.set_loader(fake_loader)
    lookup.set_templar(Templar(loader=fake_loader))

    result = lookup.run([[{'name': 'alice'}, {'name': 'bob'}], 'name'])

# Generated at 2022-06-11 16:00:35.524664
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests of (run(terms, variables, **kwargs) method of LookupModule

    # see https://stackoverflow.com/a/35328302/6325789
    import inspect
    import unittest
    import os

    class TestLookupModule_run(unittest.TestCase):
        def setUp(self):
            # Without the self.longMessage=True the test will not print details of failure
            self.longMessage = True
            self.fixtures = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures')


        # Example of test of method run of class LookupModule
        #def test_run_of_class_LookupModule(self):
        #    # arrange
        #    lookup_module = LookupModule()
        #    terms

# Generated at 2022-06-11 16:00:47.257743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock, Mock

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self._templar = Mock()
            self._loader = Mock()

            self.lookup = LookupModule()
            self.lookup._templar = self._templar
            self.lookup._loader = self._loader

            # construct mock data structure used as 'users'

# Generated at 2022-06-11 16:00:54.956708
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # patch method:
    global _raise_terms_error
    _raise_terms_error = lambda *args, **kwargs: None
    # patch method:
    global _subelements
    _subelements = lambda *args, **kwargs: [[1, 1], [1, 1], [1, 1]]
    # patch module:
    global boolean
    boolean = lambda *args, **kwargs: True

    lookup_module = LookupModule()
    terms = ["", "", ""]
    variables = ""
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == [[1, 1], [1, 1], [1, 1]]

    # patch method:
    global _raise_terms_error
    _raise_terms_error = lambda *args, **kwargs: None
    # patch method

# Generated at 2022-06-11 16:01:05.389700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar:
        def __init__(self):
            self._result = None
        def template(self, value):
            self._result = value
            return self._result
        def get_result(self):
            return self._result

    class MockLoader:
        def __init__(self):
            self.path = None
        def list_directory(self, path):
            self.path = path
            return ['onekey.pub', 'twokey.pub', 'id_rsa.pub']

    class MockAnsibleModule:
        def __init__(self):
            self.params = None
            self.exit_json = None
            self.fail_json = None
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            pass

    # no nested

# Generated at 2022-06-11 16:01:15.535815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test subelements lookup with 2 terms
    subelements = LookupModule()
    terms = [
        [
            {
                'name': 'alice',
                'authorized': [
                    '/tmp/alice/onekey.pub',
                    '/tmp/alice/twokey.pub',
                ],
            },
            {
                'name': 'boo',
                'authorized': [
                    '/tmp/boo/id_rsa.pub',
                    '/tmp/boo/id_rsa-2.pub',
                ],
            },
        ],
        'authorized',
    ]
    ret = subelements.run(terms, {})

# Generated at 2022-06-11 16:01:34.820705
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:46.594484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testing some examples
    lookup = LookupModule()

    terms = [{"alice": {"groups": ["wheel"]}}, "groups"]
    result = lookup.run(terms, None)
    assert result == [('alice', 'wheel')], "expected %s, got %s" % ([('alice', 'wheel')], result)

    terms = [{"alice": {"groups": ["wheel", "dba"]}}, "groups"]
    result = lookup.run(terms, None)
    assert result == [('alice', 'wheel'), ('alice', 'dba')], "expected %s, got %s" % ([('alice', 'wheel'), ('alice', 'dba')], result)

    terms = [{"alice": {"groups": []}}, "groups"]
    result = lookup.run(terms, None)
   

# Generated at 2022-06-11 16:01:54.936489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils.six import string_types
    lookup = LookupModule()

    # test: returns empty list when no argument is passed
    ret = lookup.run([], None)
    assert ret == [], "subelements lookup should return empty list when no argument is passed"

    # test: raise AnsibleError when first term is not a list or a dictionary
    ret = lookup.run([1], None)
    assert isinstance(ret, AnsibleError), "subelements lookup should raise AnsibleError when first term is not a list or a dictionary"

    # test: raise AnsibleError when second term is not a string
    ret = lookup.run([[1], 1], None)
   

# Generated at 2022-06-11 16:02:04.231729
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # import module
    import ansible.plugins.lookup.subelements

    # create class instance
    lookuper = ansible.plugins.lookup.subelements.LookupModule()

    # test data

# Generated at 2022-06-11 16:02:14.029614
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # prepare test data
    terms = dict()
    terms[0] = dict()
    terms[0]['users'] = []
    terms[0]['users'].append({"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]})
    terms[1] = "authorized"

    # init the lookup module
    lookup_module = LookupModule()

    # execute the run method to execute the code which is tested here
    lookup_module.run(terms, {})

# Generated at 2022-06-11 16:02:22.116592
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:35.278424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.module_utils.basic import AnsibleModule

    # build test data
    users_data = {
        'element1': {
            'mysql': {
                'hosts': ['h1', 'h2'],
                'privs': ['p1', 'p2']
            },
            'groups': ['g1', 'g2']
        },
        'element2': {
            'mysql': {
                'hosts': ['h1', 'h2'],
                'privs': ['p1', 'p2']
            },
            'groups': ['g1', 'g2']
        }
    }
    users_text = json.dumps(users_data)

    # generate AnsibleModule with defined fail_json and exit_json

# Generated at 2022-06-11 16:02:43.928787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    # TODO: rewrite test without using json.loads because it adds a unicode prefix to strings
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import wrap_var as wrap_vars
    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_bytes, to_native


# Generated at 2022-06-11 16:02:56.230394
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.listify import listify_lookup_plugin_terms

    lu = LookupModule()

    # test case 1
    # lookup mode
    # result a list of tuples
    # first term should be a list (or dict), second a string holding the subkey
    # with 2 elements (list, string)
    # check for optional flags in third term
    # build_items

# Generated at 2022-06-11 16:03:04.848912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # check lookup terms - check number of terms
    lookup_module.run([])
    try:
        lookup_module.run("")
    except Exception:
        pass
    else:
        #should not raise error
        raise Exception("Should raise error 1")

    #first term should be a list (or dict), second a string holding the subkey
    try:
        lookup_module.run([{}, ""])
    except Exception:
        pass
    else:
        #should not raise error
        raise Exception("Should raise error 2")
    try:
        lookup_module.run([[""], ""])
    except Exception:
        pass
    else:
        #should not raise error
        raise Exception("Should raise error 3")

# Generated at 2022-06-11 16:03:29.684006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(
                action=dict(
                    module='debug',
                    args=dict(
                        msg="{{item.0.authorized}}"
                    )
                )
            )
        ]
    )
    play = Play

# Generated at 2022-06-11 16:03:35.991198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([[{'foo': 'bar'}, {'baz': [1, 2, 3]}], 'baz'])
    assert result == [({"baz": [1, 2, 3]}, 1), ({"baz": [1, 2, 3]}, 2), ({"baz": [1, 2, 3]}, 3)]


# Generated at 2022-06-11 16:03:46.285955
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    mylookup = LookupModule()

    mylookup.set_loader({})
    mylookup._templar = None

    mylookup.run([{'skipped': False, 'dict': {'skipped': False, 'list': ['item1.1', 'item1.2']}, 'list': ['item2.1', 'item2.2']}, 'skipped', {'skip_missing': False}])

    # Act
    result = mylookup.run(
        [
            {'skipped': False, 'dict': {'skipped': False, 'list': ['item1.1', 'item1.2']}, 'list': ['item2.1', 'item2.2']},
            'skipped',
            {'skip_missing': False}
        ])

    # Assert


# Generated at 2022-06-11 16:03:53.479370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import yaml
    testfile = os.path.dirname(os.path.realpath(__file__)) + '/../tests/yamltests/test_lookup_subelements.yaml'
    testdata = yaml.load(open(testfile).read())
    testobj = LookupModule()
    for case in testdata:
        result = testobj.run(case['input'], variables={}, **case['kwargs'])
        assert case['output'] == result

# Generated at 2022-06-11 16:04:01.774801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock objects class LookupModule
    class MockTemplar(object):
        def __init__(self):
            self.result = True

        def template(self, template):
            return template

    class MockLoader(object):
        def __init__(self):
            self.result = True

        def get_basedir(self, parent=None):
            return parent

    mock_templar = MockTemplar()
    mock_loader = MockLoader()

    # create params for function run
    terms = [
        [
            {
                'name': 'alice',
                'authorized': 'alice pub key'
            },
            {
                'name': 'bob',
                'authorized': 'bob pub key'
            }
        ],
        'authorized'
    ]

    mock_lookup = Look

# Generated at 2022-06-11 16:04:12.480491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test setup: load the JSON data to a python object
    terms = None
    with open("/home/serg/Documents/projects/ansible-modules-extras/test/unit/plugins/lookup/lookup_subelements_data.json", "r") as data:
        terms = lookup._loader.load(data, "", "", "", False)
    assert(terms is not None)

    # Test setup: create a list from the JSON data and add the ansible-lookup syntax
    json = None
    with open("/home/serg/Documents/projects/ansible-modules-extras/test/unit/plugins/lookup/lookup_subelements_data.json", "r") as data:
        json = data.read()

# Generated at 2022-06-11 16:04:23.976953
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:04:35.532242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''
    # Init vars

# Generated at 2022-06-11 16:04:44.800603
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class UnitTest(object):
        def __init__(self):
            self.results = {}  # k:methodname v:result
            self.exit_json = self._exit_json
            self.fail_json = self._fail_json

        def _exit_json(self, **kwargs):
            self.results["exit_json"] = kwargs

        def _fail_json(self, **kwargs):
            self.results["fail_json"] = kwargs


# Generated at 2022-06-11 16:04:57.170780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    # TEST1: subelements lookup expects a list of two or three items
    try:
        LookupModule.run("string")
        assert False
    except AnsibleError as e:
        assert "subelements lookup expects a list of two or three items" in str(e), str(e)

    # TEST2: first term should be a dict
    try:
        LookupModule.run("string", "string")
        assert False
    except AnsibleError as e:
        assert "first a dict or a list, second a string pointing to the subkey" in str(e), str(e)

    # TEST3: second term should be a string

# Generated at 2022-06-11 16:05:37.277258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a instance of LookupModule for use in test
    lookup_plugin = LookupModule()
    # test lookup with key inside a list
    #
    # check for correct behavior
    #
    terms_list_key = [
        ['user1', 'user2'],
        'name']
    assert lookup_plugin.run(terms_list_key, None) == [[{'name': 'user1'}, 'user1'],
                                                        [{'name': 'user2'}, 'user2']]
    #
    # check for error handling
    #

    # test lookup with key inside a list and a list of subkeys
    #
    # check for correct behavior
    #
    terms_list_key = [
        ['user1', 'user2'],
        'name.hosts']
    assert lookup_plugin

# Generated at 2022-06-11 16:05:49.078767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self, results, **kwargs):
            self.results = results

        def run(self, terms, **kwargs):
            terms[0] = listify_lookup_plugin_terms(terms[0], templar=self._templar, loader=self._loader)
            return super(TestLookupModule, self).run(terms, **kwargs)

    # strict test cases
    suite = unittest.TestSuite()
    suite.addTest(SubelementsTestCase('testSubelementsNoErrors'))
    suite.addTest(SubelementsTestCase('testSubelementsErrorFirstItemNotList'))
    suite.addTest(SubelementsTestCase('testSubelementsErrorFirstItemNotDict'))

# Generated at 2022-06-11 16:06:01.031956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    plugin_class = lookup_loader.get('subelements')
    lookup_obj = plugin_class()

    # testing with valid structure

# Generated at 2022-06-11 16:06:13.250180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError


# Generated at 2022-06-11 16:06:24.601529
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 1: while no argument, calling run() will throw an error
    lookup_fail('subelements', [])

    # Case 2: while only one argument, calling run() will throw an error (min two required)
    lookup_fail('subelements', [ [ 'ok' ] ])

    # Case 3: while first argument is neither a dict nor a list, calling run() will throw an error
    lookup_fail('subelements', [ 'ok', 'second argument' ])

    # Case 4: while second argument is neither dict nor list, calling run() will throw an error
    lookup_fail('subelements', [ {}, [] ])

    # Case 5: while third argument contains a key not allowed, calling run() will throw an error
    lookup_fail('subelements', [ {}, 'key', { 'nokey': 'value' } ])

   

# Generated at 2022-06-11 16:06:28.778428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test are performed by TestLookupModule

    # This module is not simple enough to contain unit tests with assert statements;
    # this method mainly exists so that the test coverage report is 100%.
    assert True

# Generated at 2022-06-11 16:06:37.313330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    subelements = LookupModule()
    fake_loader = None
    fake_variables = {}

    # 1. list of dicts, subelement is missing
    user = [
        {'name': 'Alice'},
    ]
    terms = [user, 'authorized']
    try:
        subelements.run(terms, fake_variables, loader=fake_loader)
    except AnsibleError as e:
        assert e.message == "could not find 'authorized' key in iterated item '{u'name': u'Alice'}'"
    else:
        raise AssertionError('AnsibleError should be raised')

    # 1. list of dicts, subelement is missing, but skip_missing is active
    terms = [user, 'authorized', {'skip_missing': True}]

# Generated at 2022-06-11 16:06:49.324828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultsCollector(CallbackBase):
        """ collects all results """

        def __init__(self, *args, **kwargs):
            super(ResultsCollector, self).__init__(*args, **kwargs)
            self.host_ok = {}
            self.host_unreachable = {}
            self.host_failed = {}


# Generated at 2022-06-11 16:06:58.628599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    # Test a subelements lookup that is missing 'items' and 'subkey' term
    with pytest.raises(AnsibleError):
        instance.run([1], None)
    # Test a subelements lookup that is missing 'subkey' term
    with pytest.raises(AnsibleError):
        instance.run([{'a': 1}], None)
    # Test a subelements lookup that is missing 'items' subkey
    with pytest.raises(AnsibleError):
        instance.run([{'a': 1}, 'b'], None)
    # Test a subelements lookup that is missing 'items' list

# Generated at 2022-06-11 16:07:09.322161
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    users = [
        {'name': "alice",
         "authorized": [
             "/tmp/alice/onekey.pub",
             "/tmp/alice/twokey.pub"]}]

    # test with a list as first term
    subelements = LookupModule().run([users, "authorized"])
    assert len(subelements) == 2
    assert subelements[0][0]['name'] == 'alice'
    assert subelements[0][1] == '/tmp/alice/onekey.pub'

    # test with a dict as first term (should get converted to a list)
    subelements = LookupModule().run([{'users': users}, "authorized"])
    assert len(subelements) == 2

# Generated at 2022-06-11 16:08:21.276656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # basic test
    assert LookupModule(None, None, None).run([[{'a': {'b': [1, 2, 3]}}], 'a.b'], {}) == [(item, item1) for item in [{'a': {'b': [1, 2, 3]}}]
                                                                                          for item1 in item['a']['b']]

    # basic test with a dict with a skipped item

# Generated at 2022-06-11 16:08:26.910004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self):
            pass

    terms = [
        [
            {
                'first_key': {
                    'second_key': ['second_value_1', 'second_value_2']
                }
            },
            {
                'first_key': {
                    'second_key': ['second_value_3']
                }
            }
        ],
        'first_key.second_key'
    ]
    lookup_module = TestLookupModule()
    ret = lookup_module.run(terms)

# Generated at 2022-06-11 16:08:35.462586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module.set_templar(None)
    keyed_list = [{'foo': {'bar': ['a','b','c']}}]
    keyed_dict = {'foo': {'bar': ['a','b','c']}}
    terms = [keyed_list,'foo.bar']
    ret = lookup_module.run(terms, None)
    assert ret == [ (keyed_list[0], 'a'), (keyed_list[0], 'b'), (keyed_list[0], 'c') ]

    terms = [[keyed_list[0]],'foo.bar']
    ret = lookup_module.run(terms, None)

# Generated at 2022-06-11 16:08:36.522159
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: to be implemented

    return


# Generated at 2022-06-11 16:08:48.879561
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ###########################################################################
    # subelements lookup, subkey not found

    terms = [[{"a": {"b": "c"}}], "d"]
    variables = {}
    result = LookupModule.run(terms, variables, check_mode=False)
    assert result == {}

    ###########################################################################
    # subelements lookup, subkey not found, skip_missing=True

    terms = [[{"a": {"b": "c"}}], "d", {'skip_missing': True}]
    variables = {}
    result = LookupModule.run(terms, variables, check_mode=False)
    assert result == []

    ###########################################################################
    # subelements lookup, subkey not a dict

    terms = [[{"a": {"b": "c"}}], "a.b"]
    variables = {}


# Generated at 2022-06-11 16:08:53.878578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instantiate plugin and create lookup term
    lookup_plugin = LookupModule()
    lookup_term = dict(users='users.yml', key='mysql.hosts')

    # get template variables
    variables = {}

    # check the result
    assert lookup_plugin.run([lookup_term], variables) == [('example_11', 'db1')]

# Generated at 2022-06-11 16:09:05.104518
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # initialise an instance of the plugin to run
    l = LookupModule()

    # This first set of tests were written with two-item terms lists
    expected = [
        ({"name": "alice"}, "/tmp/alice/onekey.pub"),
        ({"name": "alice"}, "/tmp/alice/twokey.pub"),
        ({"name": "bob"}, "/tmp/bob/id_rsa.pub")
    ]
    users = [
        {"name": "alice", "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"]},
        {"name": "bob", "authorized": ["/tmp/bob/id_rsa.pub"]}
    ]
    terms = [users, "authorized"]

# Generated at 2022-06-11 16:09:14.607441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummy_variables = dict()

    def assertEqual(a, b, msg=""):
        assert a == b, "%s: %s != %s" % (msg, repr(a), repr(b))

    def assertRaises(e, *a):
        try:
            LookupModule(**a).run(dummy_terms, dummy_variables)
            assert False, "No exception raised for %s" % repr(a)
        except e:
            pass

    def assertWontRaise(e, *a):
        try:
            LookupModule(**a).run(dummy_terms, dummy_variables)
        except e:
            assert False, "Exception raised for %s" % repr(a)

    class DummyLoader(object):
        path = ['.']

    dummy_loader = DummyLoader

# Generated at 2022-06-11 16:09:27.355639
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types

    lookup_module = LookupModule()

    def test(terms, result):
        # check for type
        terms[0] = listify_lookup_plugin_terms(terms[0], templar=None, loader=None)
        assert isinstance(result, list)
        if len(result) > 0:
            assert isinstance(result[0], tuple)
            assert isinstance(result[0][0], dict)

        # check proper result
        assert result == lookup_module.run(terms, None)
