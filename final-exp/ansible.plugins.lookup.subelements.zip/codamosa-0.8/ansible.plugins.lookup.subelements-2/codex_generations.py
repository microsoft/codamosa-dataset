

# Generated at 2022-06-11 15:59:39.336128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run([[{'foo': 1}, {'foo': 2, 'bar': {'baz': 3}}, {'baz': 3}], 'foo'], {})
    assert result == [[{'foo': 1}, 1], [{'foo': 2, 'bar': {'baz': 3}}, 2], [{'baz': 3}, False]]



# Generated at 2022-06-11 15:59:49.545572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    def _raise_terms_error(msg=""):
        raise AnsibleError(
            "subelements lookup expects a list of two or three items, " + msg)

    # test _raise_terms_error
    try:
        _raise_terms_error()
    except AnsibleError as ae:
        assert str(ae).startswith("subelements lookup expects a list of two or three items, ")

    class TestTemplate():
        def __init__(self):
            self.name = "ansible"
            self.foo = {'a': 'A',
                        'b': 'B',
                        'c': 'C'}

# Generated at 2022-06-11 15:59:59.838251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    import sys
    lookup_module = LookupModule()
    # Test normal behaviour
    setattr(lookup_module._templar, 'template', lambda x:x) # Dummy of jinja2 templating to just return the argument
    terms = [
        [{'alice': {'group': ['wheel']}, 'bob': {'group': ['wheel']}}, 'two'],
        'group',
        {'skip_missing': False}
    ]
    sys.stdout = sys.__stdout__
    sys.stdout = StringIO()
    lookup_module.run(terms, dict())
    sys.stdout.seek(0)

# Generated at 2022-06-11 16:00:08.015881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test case for the subelements lookup plugin."""

    # an small test dict
    users = {
        "alice": {
            "authorized": [
                "/tmp/alice/onekey.pub",
                "/tmp/alice/twokey.pub"
            ],
            "groups": ["wheel"]
        },
        "bob": {
            "authorized": [
                "/tmp/bob/id_rsa.pub"
            ],
            "groups": ["wheel"]
        },
        "carol": {
            "authorized": []
        }
    }


# Generated at 2022-06-11 16:00:20.453851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    import json
    from ansible.template import Templar


# Generated at 2022-06-11 16:00:30.947819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {'vars':{}, 'loader':'', 'templar':''}
    lm = LookupModule()

    # test with wrong number of terms
    t1 = ["first wrong term"]
    t2 = ["first ok term", "second wrong term"]
    t3 = ["first ok term", "second wrong term", "third ok term"]
    assert_raises(AnsibleError, lm.run, t1, **args)
    assert_raises(AnsibleError, lm.run, t2, **args)
    assert_raises(AnsibleError, lm.run, t3, **args)

    # test with wrong type of terms
    t4 = ["first ok term", 1234]
    t5 = ["first ok term", "second ok term", 1234]
    assert_ra

# Generated at 2022-06-11 16:00:42.904878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils._text import to_text
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    lookup = lookup_loader.get('subelements')

    loader = DataLoader()
    env = {'basedir': 'tests'}
    vars_ = combine_vars(loader=loader, variables={"A": 123}, templar=None, shared_loader_obj=None, vault_password=None)
    terms = [{'a': {'b': 'c'}}, 'a']
    result = lookup.run(terms, vars_, loader=loader, templar=None, env=env)

# Generated at 2022-06-11 16:00:52.604552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar:
        def __init__(self, d): self.vars = d

        def template(self, v):
            if isinstance(v, string_types) and v in self.vars:
                return self.vars[v]
            return v

    class MockLoader:
        @staticmethod
        def load_from_file(v):
            if isinstance(v, string_types) and v == 'flag':
                return 'true'
            return v


# Generated at 2022-06-11 16:01:02.877867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys
    class TestSubelementsLookupModule(unittest.TestCase):
        def setUp(self):
            self.lookup = LookupModule()
            self.lookup.basedir = sys.path[0]  # lookup is run from sources root
            self.myenv = dict(ANSIBLE_JINJA2_NATIVE=True)
            self.myenv.update(ANSIBLE_CONFIG='/dev/null')
            self.myenv.update(ANSIBLE_LOOKUP_PLUGINS='.')


# Generated at 2022-06-11 16:01:03.822186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: write unit tests

    return True

# Generated at 2022-06-11 16:01:21.849440
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    testvars = dict(
        task_vars=dict(
            int_var=1,
            str_var="str",
            list_var=['1', '2', '3'],
            dict_var=dict(
                one=1,
            ),
        ),
        variables=dict(
            int_var=1,
            str_var="str",
            list_var=['1', '2', '3'],
            dict_var=dict(
                one=1,
            ),
        ),
        vars=dict(
            int_var=1,
            str_var="str",
            list_var=['1', '2', '3'],
            dict_var=dict(
                one=1,
            ),
        ),
    )

    LUM = LookupModule()
   

# Generated at 2022-06-11 16:01:33.753464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if not PY3:
        builtin_open = '__builtin__.open'
    else:
        builtin_open = 'builtins.open'

    subelements_class = LookupModule()
    subelements_class._templar = None
    subelements_class._loader = None

# Generated at 2022-06-11 16:01:45.006988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-11 16:01:54.165634
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.basedir = 'basedir'

    def _regular_run(terms, expected_result=None, expected_exception=None):
        try:
            result = lookup.run(terms, None)
            if expected_exception:
                assert False, "Expected exception '%s' not raised." % expected_exception.__class__.__name__
        except Exception as e:
            if expected_exception:
                if isinstance(e, expected_exception):
                    return
                else:
                    assert False, "Unexpected exception '%s' caught where '%s' was expected." % (e.__class__.__name__,
                                                                                                 expected_exception.__class__.__name__)
            else:
                raise

# Generated at 2022-06-11 16:02:03.823031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    unit test for method run (parameters and return) of class LookupModule
    """
    # import base test case class
    from ansible.module_utils.lookup_plugins.ansible_test_lookup_plugin import TestLookupBase

    # class to test, also inherits from TestLookupBase
    class TestLookupModule(LookupModule, TestLookupBase):
        def __init__(self, input_data, loader, templar, **kwargs):
            self.set_input_data(input_data)
            super(TestLookupModule, self).__init__(loader=loader, templar=templar, **kwargs)

    # prepare data for tests

# Generated at 2022-06-11 16:02:16.822994
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:28.472366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import os
    import sys
    # sys.path.append(os.path.dirname(sys.path[0]))
    # from plugins.lookup import subelements
    # test_instance = subelements.LookupModule()

    # test_terms = [{u'alice': {u'mysql': {u'password': u'mysql-password', u'hosts': [u'%', u'127.0.0.1', u'::1', u'localhost'], u'privs': [u'*.*:SELECT', u'DB1.*:ALL']}, u'authorized': [u'/tmp/alice/onekey.pub', u'/tmp/alice/twokey.pub']}, u'bob': {u'mysql': {u'password': u'other-mysql-password', u

# Generated at 2022-06-11 16:02:31.929868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_list_of_dicts = [{'test': {'test2': [{'test3': ['test4']}]}}]
    assert LookupModule().run(
        terms=["", random_list_of_dicts, 'test.test2.test3'],
        variables={},
    ) == [({'test': {'test2': [{'test3': ['test4']}]}}, 'test4')]

# Generated at 2022-06-11 16:02:40.298113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Create a class object and test lookup method:
    - traverse a subelement in a list of dictionaries
    - if the subelement contains a list, traverse this list
    - copy the rest of the dictionary
    """

# Generated at 2022-06-11 16:02:51.998429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar:
        def __init__(self):
            pass

        def template(self, source, **kwargs):
            return source

    class MockLoader:
        def __init__(self):
            pass

    # parametrized tests with testname - lookup parameters - expect

# Generated at 2022-06-11 16:03:13.995435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = [[{'a': 1, 'b': {'c': {'d': [2, 3], 'e': 4}}}, {'a': 5, 'b': {'c': {'d': 6, 'e': 7}}}], 'b.c.d', None]

    # Act
    instance = LookupModule()
    result = instance.run(terms, None)

    # Assert
    assert result == [(terms[0][0], terms[0][0]['b']['c']['d'][0]), (terms[0][0], terms[0][0]['b']['c']['d'][1]), (terms[0][1], terms[0][1]['b']['c']['d'])]



# Generated at 2022-06-11 16:03:22.084122
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModuleTester(LookupModule):
        def __init__(self):
            self.run_args = []
            self.run_results = []
            self.run_results.append({'result': [('value', 'foo'), ('value2', 'bar')]})
            self.run_results.append({'result': [('value', 'one'), ('value', 'two'), ('value', 'three')]})

        def run(self, terms, variables=None, **kwargs):
            self.run_args.append((terms, variables))
            return self.run_results.pop(0)['result']

    lookup_result = []


# Generated at 2022-06-11 16:03:31.920778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([{'item1': {'name': 'test1'}, 'item2': {'name': 'test2'}}, 'name']) == [{'name': 'test1'}, {'name': 'test2'}]
    assert lookup_module.run([[{'name': 'test1'}, {'name': 'test2'}], 'name']) == [{'name': 'test1'}, {'name': 'test2'}]
    assert lookup_module.run([[{'name': 'test1'}, {'name': 'test2'}], 'subitems.name']) == [[{'subitems': {'name': 'test1'}}, {'subitems': {'name': 'test2'}}]]

# Generated at 2022-06-11 16:03:43.875502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .test_lookup_plugins import TestLookupBase

    terms = [
              [
                {
                  'a': {
                    'b': ['c', 'd']
                  }
                },
                {
                  'a': {
                    'b': [1, 2]
                  }
                },
                {
                  'a': {
                    'b': ['x', 'y']
                  }
                },
                {
                  'a': {
                    'c': ['c', 'd']
                  }
                },
              ],
              'a.b'
            ]

    ret = list(TestLookupBase.test(LookupModule, terms))


# Generated at 2022-06-11 16:03:55.451087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import pdb; pdb.set_trace()
    users = [
        {'name': 'alice', 'authorized': ['publickey1', 'publickey2'], 'mysql': {'password': 'the-password', 'privs': [('*.*', 'SELECT'), ('DB1.*', 'ALL')]}, 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['publickey1'], 'mysql': {'password': 'the-password', 'privs': [('*.*', 'SELECT'), ('DB2.*', 'ALL')]}}
    ]

    module = LookupModule()

# Generated at 2022-06-11 16:04:06.871578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import pytest

    @pytest.fixture
    def lu(monkeypatch):
        # Lookup plugin's class
        lu_class = LookupModule(loader=None, templar=None, shared_loader_obj=None)

        # The loader and templar are only needed for reading the first argument
        # of the class constructor which is a list of paths from where the
        # plugin will get the input list of dictionaries to subelements.
        # Since we do not need that functionality we can use None for the loader,
        # and for the templar a dummy templar object will be enough.
        #
        # However, since the unit tests of the lookupplugin will attempt to read
        # the plugin itself which is in the pythonpath if it is not installed,
        # we will have to fake

# Generated at 2022-06-11 16:04:14.767446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.lookup import LookupBase


# Generated at 2022-06-11 16:04:25.928240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Subelements should return the list of dictionaries referred to by the second argument in the subelements of each dictionary referred to in the first argument.
    # setup
    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}
    ]

# Generated at 2022-06-11 16:04:26.794992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add unit test
    pass

# Generated at 2022-06-11 16:04:39.846960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create lookup module
    lm = LookupModule()
    # this is a list of dictionaries

# Generated at 2022-06-11 16:05:18.589548
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def __run(terms, variables):
        lookup = LookupModule()
        lookup.set_loader({})  # mock loader - we won't use it
        return lookup._flatten(lookup.run(terms, variables))

    def __assert_equal_unordered(list1, list2):
        # assertEqual does not work with unordered lists - this does
        assert len(list1) == len(list2)
        for item in list1:
            assert item in list2

    # run simple test
    users = [
        {'name': 'alice', 'hosts': ['host1', 'host2'], 'mysql': {'password': 'geheim'}},
        {'name': 'bob', 'hosts': ['host3'], 'mysql': {'password': 'secret'}}
    ]
   

# Generated at 2022-06-11 16:05:30.378127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    #test subkey not a string
    terms = [{'a': {'b': 'string'}}, 1]
    res = lookup_module.run(terms, None)
    assert res == {}, res

    terms = [{'a': {'b': 'string'}}, 'b']
    res = lookup_module.run(terms, None)
    assert res == ['string'], res

    #test subkey not a string
    terms = [{'a': {'b': 'string'}}, 'c']
    res = lookup_module.run(terms, None)
    assert res == {}, res

    #test subkey not a string
    terms = [{'a': {'b': 'string'}}, 'c', {'skip_missing': True}]
    res

# Generated at 2022-06-11 16:05:39.343819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader

    users = [
        {
            'name': 'alice',
            'authorized': [
                '/tmp/alice/onekey.pub',
                '/tmp/alice/twokey.pub',
                ]
            },
        {
            'name': 'bob',
            'authorized': [
                '/tmp/bob/id_rsa.pub'
                ]
            },
        ]
    terms = [users, 'authorized']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, dict())

# Generated at 2022-06-11 16:05:50.367585
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:06:01.943983
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.template import Templar

    users = AnsibleMapping()

# Generated at 2022-06-11 16:06:13.899408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lkm = LookupModule()
    terms0 = [
        [
            {
                'name': 'User0',
                'authorized': [
                    '/tmp/user0key1',
                ]
            },
            {
                'name': 'User1',
                'authorized': [
                    '/tmp/user1key1',
                    '/tmp/user1key2',
                ]
            },
        ],
        'authorized'
    ]


# Generated at 2022-06-11 16:06:25.322835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    lookup_module = LookupModule()

# Generated at 2022-06-11 16:06:36.059570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    LookupModule._templar = None
    LookupModule._loader = None

    ##################################################

    terms = [
        [
            {'mysql': {'hosts': ['db1']}},
            {'name': 'bob'}
        ],
        'name'
    ]

    lm = LookupModule()
    assert [('bob',)] == lm.run(terms, {})


    ##################################################

    terms = [
        [
            {'mysql': {'hosts': ['db1']}},
            {'name': 'bob'}
        ],
        'mysql.hosts'
    ]

    lm = LookupModule()

# Generated at 2022-06-11 16:06:48.216321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # test data

# Generated at 2022-06-11 16:06:58.017513
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #  check lookup terms - check number of terms
    lookup_instance = LookupModule()
    try:
      lookup_instance.run([], {})
    except AnsibleError as e:
      assert "subelements lookup expects a list of two or three items" in e.message

    #  first term should be a list (or dict), second a string holding the subkey
    try:
      lookup_instance.run([""], {})
    except AnsibleError as e:
      assert "first a dict or a list, second a string pointing to the subkey" in e.message

    try:
      lookup_instance.run([None], {})
    except AnsibleError as e:
      assert "first a dict or a list, second a string pointing to the subkey" in e.message


# Generated at 2022-06-11 16:08:12.234510
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:08:21.741187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import MagicMock
    from ansible.compat.tests.mock import patch

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()
            self.lookup._templar = MagicMock()
            self.lookup._loader = MagicMock()

        def tearDown(self):
            pass


# Generated at 2022-06-11 16:08:32.991056
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def _new_lookup():
        return LookupModule()

    def _init_lookup(lookup, terms, variables, **kwargs):
        lookup.set_environment(variables=variables)
        lookup.set_loader(loader=None)
        lookup.set_templar(templar=None)
        return lookup.run(terms, variables, **kwargs)


# Generated at 2022-06-11 16:08:44.879135
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # data
    a_list = [
        {
            "foo": {"bar": [{"name": "bar1"}, {"name": "bar2"}]}
        },
        {
            "foo": {"bar": [{"name": "bar3"}]}
        },
        {
            "foo": {"bar": [{"name": "bar4"}, {"name": "bar5"}, {"name": "bar6"}]}
        }
    ]
    a_dict = {
        "foo": {"bar": [{"name": "bar1"}, {"name": "bar2"}]}
    }
    path = "foo.bar.name"

    lookup_class = LookupModule()

    # test cases

# Generated at 2022-06-11 16:08:55.275619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance
    module = LookupModule()

    # prepare test data
    users = []
    alice = dict(name='alice', authorized=['/tmp/alice/onekey.pub','/tmp/alice/twokey.pub'])
    users.append(alice)

    bob = dict(name='bob', authorized=['/tmp/bob/id_rsa.pub'])
    users.append(bob)

    # run command and capture output
    terms = [users, 'authorized']
    ret = module.run(terms, dict())

    # check output
    assert ret[0][0] == alice
    assert ret[0][1] == '/tmp/alice/onekey.pub'
    assert ret[1][0] == alice

# Generated at 2022-06-11 16:09:06.771875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils.parsing.convert_bool import boolean
    import json
    import os.path
    import yaml
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    # check exception on bad data type
    try:
        lookup_module.run(['a', 'b', 'c'], None)
    except AnsibleError as e:
        assert e.message == "subelements lookup expects a list of two or three items"

    # check exception on bad second data type

# Generated at 2022-06-11 16:09:15.739330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test error handling
    assertRaisesRegexp(AnsibleError, "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey", lookup.run, "", "", "")
    assertRaisesRegexp(AnsibleError, "subelements lookup expects a list of two or three items, ", lookup.run, [], "", "")
    assertRaisesRegexp(AnsibleError, "subelements lookup expects a list of two or three items, ", lookup.run, [{}, [], []], "", "")
    assertRaisesRegexp(AnsibleError, "subelements lookup expects a list of two or three items, ", lookup.run, [{}, {}], "", "")
    assertRaisesRegex

# Generated at 2022-06-11 16:09:28.177444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    nm = lm.run([[{'user': 'alice', 'mysql': {'password': 'mysql-password', 'hosts': ['db1', 'db2']}},
                  {'user': 'bob', 'mysql': {'password': 'mysql-password', 'hosts': ['db1', 'db2']}}],
                 'user', {'skip_missing': False}])
    assert nm == [({'user': 'alice', 'mysql': {'password': 'mysql-password', 'hosts': ['db1', 'db2']}}, 'alice'),
                  ({'user': 'bob', 'mysql': {'password': 'mysql-password', 'hosts': ['db1', 'db2']}}, 'bob')]