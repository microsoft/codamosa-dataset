

# Generated at 2022-06-11 15:59:43.468131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    def assertEqualLists(l1, l2):
        assert set(l1) == set(l2), "Assertion of %s failed - expected %s, got %s" % (l1, l2)

    assertEqualLists(lu.run(terms=[{'a': 1}, 'a'], variables=None)[0], [1])

    assertEqualLists(lu.run(terms=[{'a': 1, 'b': 2}, 'c'], variables=None, fail_on_undefined=True), [])

    assertEqualLists(lu.run(terms=[{'a': {'b': [3, 4, 5]}}, 'a.b'], variables=None)[2], [5])


# Generated at 2022-06-11 15:59:44.304523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:59:53.999624
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:00:04.544872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule

    Providing a test case where a missing subkey is reported as error and it is not skipped.
    The second test case is similar and skips the missing subkey.

    This test is called by unit tests in test/unit/plugins/lookup and not intended to be
    run standalone.
    '''
    terms = [
        [{'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
         {'authorized': ['/tmp/bob/id_rsa.pub', '/tmp/bob/id_dsa.pub']}],
        'allowed_users'
    ]
    L = LookupModule()

# Generated at 2022-06-11 16:00:16.038101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.lookup_utils import AnsibleLookupError
    from ansible.parsing.dataloader import DataLoader

    # Data
    users = [
        {'name': 'alice',
          'authorized': [
            '/tmp/alice/onekey.pub',
            '/tmp/alice/twokey.pub'
          ]
        },
        {'name': 'bob',
          'authorized': [
            '/tmp/bob/id_rsa.pub'
          ]
        }
    ]


# Generated at 2022-06-11 16:00:25.609684
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:00:35.351678
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2

    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.plugins.lookup import LookupBase

    def redir_stdout():
        ''' Helper function to silence output '''
        return StringIO()

    ##########################################################################
    # In: users = [
    #        { 'name': 'alice',
    #          'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'],
    #          'mysql': {
    #              'password': 'mysql-password',
    #              'hosts': ['%', '

# Generated at 2022-06-11 16:00:47.102287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run([[
        {
            'skipped': False,
        },
        {
            'skipped': True,
        },
        {
            'skipped': False,
        }
    ], 'skipped', None])
    assert ret == []  # all are skipped
    ret = lookup.run([[
        {
            'skipped': False,
        },
        {
            'skipped': False,
        },
        {
            'skipped': False,
        }
    ], 'skipped', None])
    assert ret == [False, False, False]
    ret = lookup.run([{
        'skipped': False,
        'skipped2': True,
        'skipped3': False,
    }, 'skipped', None])

# Generated at 2022-06-11 16:00:54.897275
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:05.343238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    import sys
    import os
    import re

    test_module = sys.modules['ansible.plugins.lookup.subelements']
    lookup = test_module.LookupModule()

    # testing simple subkey: extract mysql.password

    # first test with a (py)dict of (py)dicts
    variable = [
        {'mysql': {'password': 'mysql-password'}},
        {'mysql': {'password': 'other-mysql-password'}}
    ]
    result = lookup.run([variable, 'mysql.password'], None)

# Generated at 2022-06-11 16:01:19.677346
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Successs, no flags, two subkeys
  lm = LookupModule(Loader())
  terms = [{'accounts':{'user':'root'}, 'mysql':{'db':'db1'}, 'key': 'value'}, 'mysql.db']
  assert lm.run(terms, None) == [({'mysql':{'db':'db1'}, 'key':'value'}, 'db1')]

  # Skip missing subkeys, two subkeys
  lm = LookupModule(Loader())
  terms = [{'accounts':{'user':'root'}, 'mysql':{'db':'db1'}, 'key': 'value'}, 'mysql.db', {'skip_missing': True}]

# Generated at 2022-06-11 16:01:25.688778
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.loader
    from ansible.module_utils.six.moves import StringIO

    # execute code to be tested
    lookup_plugin = ansible.plugins.loader.lookup_loader.get('subelements', class_only=True)
    lookup_instance = lookup_plugin()
    test_list = [{'mysql': {'hosts': ['db1', 'db2', 'db3'], 'privs': {'priv1': 'SELECT', 'priv2': 'ALL'}, 'password': 'abcdef'}},
                 {'mysql': {'hosts': ['db1', 'db2', 'db3'], 'password': 'abcdef'}}]

    # test 1 - first term is a list of dictionaries

# Generated at 2022-06-11 16:01:32.191585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access

    # set up dependency injected params
    terms = [
        {'files': '/etc/hosts'},
        'subkey'
    ]
    variables = None
    plugin = LookupModule()

    # invoke test method
    response = plugin.run(terms, variables)

    # assert result
    assert response == [('/etc/hosts',)]



# Generated at 2022-06-11 16:01:40.161276
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:01:40.868806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 2

# Generated at 2022-06-11 16:01:52.028212
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:02.838946
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:15.888136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None

    # test: subelements lookup expects a list of two or three items
    # test: first a dict or a list, second a string pointing to the subkey
    # test: the optional third item must be a dict with flags skip_missing
    #
    lookup_terms = [
        [None, 'not a list'],
        [None, 'not a list', None],
        ['not a list or dict', 'not a string']
    ]

# Generated at 2022-06-11 16:02:26.507386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # noinspection PyUnusedLocal
    from ansible.module_utils.parsing.convert_bool import boolean

    bool_flag = AnsibleUnsafeText("True")
    str_flag = AnsibleUnsafeText("skip_missing")
    list_terms = [bool_flag, str_flag]
    dict_terms = {bool_flag: str_flag}
    unexpected_value = AnsibleUnsafeText("unexpected value")
    dict_terms_unexpected_value = {bool_flag: unexpected_value}
    unexpected_key = AnsibleUnsafeText("unexpected key")
    dict_terms_unexpected_key = {unexpected_key: str_flag}

    lookup

# Generated at 2022-06-11 16:02:37.713679
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import inspect
    import copy

    # Import basic python modules
    import pytest
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.play
    from ansible.utils.vars import combine_vars

    # Import ansible modules
    from ansible.plugins.lookup import LookupModule

    # Load the class
    lookup_mod = LookupModule()

    # Setup the inserter (not needed)
    inserter = ansible.parsing.dataloader.DataLoader()
    ansible.vars.manager.set_vars_cache(inserter)

# Generated at 2022-06-11 16:03:03.453920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    result = list(module.run([["a", "b"], "key1"]))
    assert(result == [
        ({'key1': 'a'}, 'a'),
        ({'key1': 'b'}, 'b'),
    ])
    result = list(module.run([["a", "b"], "key1", {}]))
    assert(result == [
        ({'key1': 'a'}, 'a'),
        ({'key1': 'b'}, 'b'),
    ])
    result = list(module.run([["a", "b"], "key1", {'skip_missing': False}]))
    assert(result == [
        ({'key1': 'a'}, 'a'),
        ({'key1': 'b'}, 'b'),
    ])

# Generated at 2022-06-11 16:03:12.184586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.yaml.objects
    # import ansible.utils.unsafe_proxy
    import ansible.template

    l = LookupModule()

    assert l.run([2, 3], {}) == []

    users = [{'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub']},
             {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']}]
    assert l.run([users, 'authorized'], {}) == [(users[0], users[0]['authorized'][0]), (users[0], users[0]['authorized'][1]), (users[1], users[1]['authorized'][0])]


# Generated at 2022-06-11 16:03:21.242348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case for method run of class LookupModule

    """

    from ansible.module_utils.parsing.convert_bool import boolean

    lu = LookupModule()


# Generated at 2022-06-11 16:03:31.398041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test 1, 2 and 3 terms
    result = sorted(lookup.run([['users'], 'authorized', {'skip_missing': 'no'}], dict(users='users')))
    assert result == sorted([])

    result = sorted(lookup.run([['users'], 'authorized'], dict(users='users')))
    assert result == sorted([])

    result = sorted(lookup.run([['users'], 'authorized', {'skip_missing': 'yes'}], dict(users='users')))
    assert result == sorted([])

    result = sorted(lookup.run([['users'], 'authorized'], dict(users='users')))
    assert result == sorted([])

    # test error on wrong number of terms

# Generated at 2022-06-11 16:03:43.054809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    dict_ = dict(skipped=True)
    assert module.run([dict_, "foo"], {}, **{}) == []
    assert module.run([[dict_], "foo"], {}, **{}) == []

    dict_ = dict(skipped=False)
    assert module.run([dict_, "foo"], {}, **{}) == []
    assert module.run([[dict_], "foo"], {}, **{}) == []

    dict_ = dict(skipped=False, foo="bar")
    assert module.run([dict_, "foo"], {}, **{}) == [("bar", )]
    assert module.run([[dict_], "foo"], {}, **{}) == [("bar", )]


# Generated at 2022-06-11 16:03:54.292903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def _criteria(terms, result):
        # make sure both lists contain the same items in the same order
        if len(terms) != len(result):
            return False
        for item in result:
            if item not in terms:
                return False
        return True

    def _run_test(terms, expected):
        lookup_obj = LookupModule()
        result = lookup_obj.run(terms, dict())
        if not _criteria(expected, result):
            raise AssertionError("unexpected subelements result, expected %s and got %s" % (expected, result))

    # Simple test

# Generated at 2022-06-11 16:04:02.007045
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test run with a list
    lookup = LookupModule()
    terms = [{'item1': {'item2': {'item3': ['a', 'b', 'c', 'd']}}}, 'item1.item2.item3']
    assert sorted(lookup.run(terms, None)) == sorted([('a', {'item1': {'item2': {}}}), ('b', {'item1': {'item2': {}}}), ('c', {'item1': {'item2': {}}}), ('d', {'item1': {'item2': {}}}),])

    # test run with a list and flags
    lookup = LookupModule()

# Generated at 2022-06-11 16:04:12.602650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    terms = [
        [
            {'first_key': 'first_value'},
            {'second_key': 'second_value'},
            {
                'third_key': {
                    'fourth_key': [
                        'fourth_value_1',
                        'fourth_value_2',
                        'fourth_value_3'
                    ]
                }
            }
        ], 'third_key.fourth_key'
    ]

# Generated at 2022-06-11 16:04:24.132583
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError


# Generated at 2022-06-11 16:04:35.861663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test environment
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add('subelements', LookupModule)
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    variables = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    # here we define the test data

# Generated at 2022-06-11 16:05:17.621921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    import json
    import os
    import pytest
    from ansible.module_utils._text import to_bytes, to_text

    user_vars = {
        'ansible_user_id': 'alice',
        'ansible_ssh_host': 'localhost'
    }

    unittest_files_path = os.getenv(
        "UNITTEST_FILES_PATH", "/tmp/ansible_unittest_files/"
    )

# Generated at 2022-06-11 16:05:29.499207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError

    # Testing with a list of dictionaries

# Generated at 2022-06-11 16:05:36.464608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """
    # Init
    module = LookupModule()
    lookup_items = []
    returned_items = []
    expected_items = []
    lookup_items.append({"var1": ["foo1", "foo2"]})
    lookup_items.append({"var2": ["foo3", "foo4"], "var3": "foo5"})
    expected_items.append({"var1": "foo1", "var2": "foo3", "var3": "foo5"})
    expected_items.append({"var1": "foo2", "var2": "foo3", "var3": "foo5"})
    expected_items.append({"var1": "foo1", "var2": "foo4", "var3": "foo5"})
    expected_

# Generated at 2022-06-11 16:05:48.266467
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_list = [
        {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'},
        {'key1': 'value5', 'key2': 'value6', 'key3': 'value7', 'key4': 'value8'},
        {'key1': 'value9', 'key2': 'value10', 'key3': 'value11', 'key4': 'value12'}
    ]

    test_terms = [test_list, 'key1']
    # subelements lookup expects a list of two or three items
    test_terms = [test_list, 'key1', 'key2']

    test_lookup = LookupModule()

# Generated at 2022-06-11 16:06:00.379887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test module """
    subelements = LookupModule()

    users = [
        {'name': 'alice', 'authorized': ['/tmp/alice/onekey.pub', '/tmp/alice/twokey.pub'], 'groups': ['wheel']},
        {'name': 'bob', 'authorized': ['/tmp/bob/id_rsa.pub']},
        {'name': 'charlie', 'authorized': [], 'groups': ['wheel', 'foo']},
        {'name': 'david', 'authorized': [], 'groups': []},
        {'name': 'edgar', 'authorized': ['/tmp/edgar/id_rsa.pub'], 'groups': []},
    ]

    terms = users, 'authorized'  # no skip_missing flag

# Generated at 2022-06-11 16:06:12.737013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([[{'name':'bob'}, {'name':'alice'}], 'name']) == [[{'name': 'bob'}], [{'name': 'alice'}]]
    assert lookup.run([[{'name':'bob'}, {'name':'alice'}], 'name'], {}) == [[{'name': 'bob'}], [{'name': 'alice'}]]
    assert lookup.run(['this is not a list', 'name'], {}) == 'this is not a list'

# Generated at 2022-06-11 16:06:23.997352
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test setup, empty lists
    assert(test_data_empty == [])
    assert(test_data1_empty == [])
    assert(test_data2_empty == [])
    assert(test_data3_empty == [])
    assert(test_data_empty2 == [])
    assert(test_data1_empty2 == [])
    assert(test_data2_empty2 == [])
    assert(test_data3_empty2 == [])

    # Test empty list
    assert(subelements_lookup.run([test_data, 'none'], {}) == [])
    assert(subelements_lookup.run([test_data_empty, 'none'], {}) == [])

    # Test list with data and key

# Generated at 2022-06-11 16:06:35.059792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.utils.listify import listify_lookup_plugin_terms

    def get_variables():
        return {'name': 'Brian'}

    def load_resource(name, *args):
        return "value of %s" % name

    # Test as a list
    myusers = [{'name': 'alice', "authorized": ["/tmp/alice/id_rsa.pub"]},
               {'name': 'bob',   "authorized": ["/tmp/bob/id_rsa.pub"]}]
    terms = [myusers, "authorized"]
    lu = LookupModule()

# Generated at 2022-06-11 16:06:47.170484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, AnsibleSequence
    from ansible.vars.manager import VariableManager
    from ansible.utils.listify import listify_lookup_plugin_terms

    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

    # setup test objects

# Generated at 2022-06-11 16:06:54.669951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # Test with wrong number of arguments
    assert l.run([], None) == [], "Expect empty list with wrong number of arguments"
    assert l.run(['1', '2'], None) == [], "Expect empty list with wrong number of arguments"
    assert l.run(['1', '2', '3', '4'], None) == [], "Expect empty list with wrong number of arguments"

    # Test with wrong type argument
    assert l.run([1, 2], None) == [], "Expect empty list when term is not a list"
    assert l.run(['1', 2], None) == [], "Expect empty list when term is not a list"
    assert l.run([{}, 2], None) == [], "Expect empty list when term is not a list"

# Generated at 2022-06-11 16:08:11.799636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    # get instaance
    lookup_obj = LookupModule()

    # empty
    res = lookup_obj.run([], dict())
    assert res == []

    # with terms need to be a list and 2 or 3 items, first a dict or list
    with pytest.raises(AnsibleError) as excinfo:
        lookup_obj.run([], dict())
    assert "must be a list of two or three items" in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        lookup_obj.run(dict(), dict())
    assert "must be a list of two or three items" in str(excinfo.value)
    with pytest.raises(AnsibleError) as excinfo:
        lookup_

# Generated at 2022-06-11 16:08:21.278427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy LookupModule
    lookup_plugin = LookupModule()

    # create a dummy host variable tree

# Generated at 2022-06-11 16:08:32.750473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import os
    import unittest2 as unittest

    class TestLookupModule_run(unittest.TestCase):

        def test_all(self):
            sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
            from ansible.module_utils.parsing.convert_bool import boolean

            import ansible.plugins.lookup.subelements as subelements_lookup
            lookup_module = subelements_lookup.LookupModule()


# Generated at 2022-06-11 16:08:44.674338
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock for for module class AnsibleModule
    class AnsiModule:
        class AnsibleExitJson(Exception):
            pass

    import sys
    module = AnsiModule()

    # creating a LookupModule object
    lookup1 = LookupModule()
    lookup1.set_loader(None)
    lookup1.set_templar(None)

    # check a normal case

# Generated at 2022-06-11 16:08:55.139350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.ansible_release import __version_info__
    fake_loader = None
    fake_templar = None

# Generated at 2022-06-11 16:09:03.323997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # the next line make sure you are using the module class and not the base class of it
    assert issubclass(LookupModule, LookupBase)
    import ansible.utils.plugin_docs as plugindocs
    m = plugindocs.get_lookup_plugin_documentation(LookupModule)
    assert m.get('description') is not None
    assert m.get('options') is not None
    assert m.get('examples') is not None
    assert m.get('return') is not None
    return m



# Generated at 2022-06-11 16:09:13.314787
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:09:26.367411
# Unit test for method run of class LookupModule