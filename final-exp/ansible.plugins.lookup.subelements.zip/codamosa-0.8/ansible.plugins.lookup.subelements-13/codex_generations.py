

# Generated at 2022-06-11 15:59:44.749982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types


# Generated at 2022-06-11 15:59:54.325771
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.utils.vars import combine_vars

    class FakeVarsModule(object):
        def __init__(self, variables):
            self.variables = variables

        def get_vars(self, loader, path, entities):
            return combine_vars(self.variables, loader, path, entities)


# Generated at 2022-06-11 16:00:03.352918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import ansible.plugins.lookup.subelements
    import ansible.parsing.yaml
    import ansible.plugins.loader
    import ansible.template
    import ansible.vars

    # stubbed "inventory" that returns a mock inventory
    # needed to handle the subject of this test:
    # use of inventory.get_host_variables() in the PlayContext object
    class MockInventory(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_host_variables(self, *args, **kwargs):
            return {}

    # stubbed "playcontext" that returns a mock playcontext
    # needed to handle the subject of this test:
    # use of templar.template() in the LookupBase class
    # this is only used

# Generated at 2022-06-11 16:00:14.473373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    from become_methods import BecomeMethods
    from ansible.module_utils.common._collections_compat import Mapping

    loader = DataLoader()
    become_methods = BecomeMethods()
    variable_manager = VariableManager()


# Generated at 2022-06-11 16:00:24.724964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import modules needed for unit testing
    from ansible.plugins.loader import lookup_loader
    import ansible.parsing.yaml.objects
    import ansible.plugins.lookup.subelements

    # create dummy variables
    from collections import namedtuple
    options = namedtuple('Options', ['connection', 'module_path',
                                     'forks', 'become', 'become_method',
                                     'become_user', 'check', 'diff'])

    opt_args = dict(
        connection='local',
        module_path='',
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False
    )

    options = options(**opt_args)

    # initialize the plugin loader
    lookup_

# Generated at 2022-06-11 16:00:33.845362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test(terms, expected):
        lookup_result = LookupModule().run(terms, None)
        assert expected == lookup_result

    # 1. simplest case
    test(
        terms=[
            {
                'first': 'value',
                'second': {
                    'key': [
                        'value1',
                        'value2'
                    ]
                },
                'third': [
                    'valuedgjhf'
                ]
            }
        ],
        expected=[
            ('value1',)
        ]
    )

    # 2. 2-level-dict

# Generated at 2022-06-11 16:00:45.706516
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:00:54.271607
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def assert_lookup_result_contains(lookup_result, expected_subelements, expected_subelement_value):
        """ Assert if lookup_result contains the expected_sub_elements. """
        if not isinstance(lookup_result, list):
            assert False, "lookup_result is not a list"
        found_sub_elements = False
        for (sub_elements, sub_element_value) in lookup_result:
            if sub_elements == expected_subelements:
                found_sub_elements = True
                assert sub_element_value == expected_subelement_value, "sub_element_value '{0}'".format(sub_element_value)
                break

# Generated at 2022-06-11 16:01:04.817698
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._loader = DummyLoader()

    # test assuming skip_missing=False
    terms = ([{'a': {'b': {'c': [1, 2, 3]}}}], 'a.b.c')
    result = lookup_module.run(terms)
    assert result == [({"a": {"b": {"c": [1, 2, 3]}}}, 1),
                      ({"a": {"b": {"c": [1, 2, 3]}}}, 2),
                      ({"a": {"b": {"c": [1, 2, 3]}}}, 3)]


# Generated at 2022-06-11 16:01:15.118551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import yaml
    from ansible.module_utils.six import PY3

    print('Testing LookupModule.run...')

    # import the test data
    if PY3:
        test_data = yaml.safe_load(open('./tests/unittests/test_data.yaml', encoding='utf-8'))
    else:
        test_data = yaml.safe_load(open('./tests/unittests/test_data.yaml'))

    subelements = test_data['subelements']
    subelements_with_missing_key = test_data['subelements_with_missing_key']
    subelements_with_empty_list = test_data['subelements_with_empty_list']
    subelements_with_nested_keys = test_data

# Generated at 2022-06-11 16:01:34.861959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    terms = [
        [],
        "subkey",
    ]

    # Test normal execution
    lookup_plugin = LookupModule()
    data = lookup_plugin.run(terms, [])
    assert data == []

    # Test normal execution with one element
    lookup_plugin = LookupModule()
    terms[0] = {"subkey": [{"subsubkey": "subsubvalue"}]}
    data = lookup_plugin.run(terms, [])
    assert data == [({'subkey': [{'subsubkey': 'subsubvalue'}]}, {'subsubkey': 'subsubvalue'})]

    # Test normal execution with one element and multiple subelements in list
    lookup_plugin = LookupModule()
    terms

# Generated at 2022-06-11 16:01:46.647717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Test for function run of class LookupModule
    #
    lookup_module = LookupModule()

    #
    # test for the given example
    #
    test_id = 'test_subelements_for_example'

# Generated at 2022-06-11 16:01:55.003043
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test preparation:
    # expected result
    expected = [
        ({'geo': {'location': 'Brussels'}, 'name': 'alice'}, 'Belgium'),
        ({'geo': {'location': 'Paris'}, 'name': 'bob'}, 'France'),
        ({'geo': {'location': 'Brussels'}, 'name': 'bob'}, 'Belgium'),
        ({'geo': {'location': 'Rome'}, 'name': 'eve'}, 'Italy'),
        ({'name': 'bob'}, 'Belgium'),  # key 'geo' does not exist, but 'skip_missing' set
    ]
    # test data

# Generated at 2022-06-11 16:02:04.256203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    import collections
    import pytest

    from ansible.errors import AnsibleError
    from ansible.plugins.lookup.subelements import LookupModule
    from ansible.module_utils import basic

    # Test lookups return the expected value
    lookup_result = []
    Element = collections.namedtuple('Element', 'value')
    elementlist = list()

# Generated at 2022-06-11 16:02:17.076312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        [
            {'x': 1, 'y': 2, 'z': {'a': 3, 'b': 4, 'c': 5}, 'w': [1,2,3]},
            {'x': 11, 'y': 5, 'z': {'a': 7, 'b': 8}, 'w': [11]},
            {'x': 1},
            {'x': 1, 'w': [1]},
            {'x': 1, 'w': {}}
        ],
        'z.a'
    ]
    look = LookupModule()

    res = look.run(terms, {}, **{})
    assert res == [(terms[0][0], 3), (terms[0][1], 7)], "run method doesn't work"


# Generated at 2022-06-11 16:02:29.058995
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:38.932279
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:02:50.254213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Default tests

    # import ansible.modules.lookup_plugins.subelements
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    m1 = LookupModule()
    m2 = LookupBase()

    # class lookup.LookupBase(object):
    try:
        assert type(m2.run()) == None
    except AssertionError as exception:
        raise AssertionError("'LookupBase.run()' raises an AssertionError exception with wrong message")
    except Exception as exception:
        raise AssertionError("'LookupBase.run()' raises an exception")
    else:
        raise AssertionError("'LookupBase.run()' doesn't raise an exception")

    # class lookup.LookupModule(LookupBase):
    #

# Generated at 2022-06-11 16:03:01.260796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # for mocking, we need to patch the lookup plugin
    from ansible.plugins import lookup
    import ansible.plugins.lookup as lookup_plugin

    from ansible.module_utils.six import PY3

    import sys
    import shutil

    try:
        shutil.rmtree('/tmp/ansible_test_lookup_subelements')
    except:
        pass
    os.mkdir('/tmp/ansible_test_lookup_subelements')
    os.mkdir('/tmp/ansible_test_lookup_subelements/lookup_plugins')
    if PY3:
        lookup_plugin_name = 'subelements.py'
    else:
        lookup_plugin_name = 'subelements.pyc'

# Generated at 2022-06-11 16:03:11.477699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.parsing.convert_bool
    import ansible.utils.unsafe_proxy
    import sys
    import types
    import unittest

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    if sys.version_info < (3, 3):
        from mock import Mock, patch
    else:
        from unittest.mock import Mock, patch

    # Mock objects
    class Mock_AnsibleError(ansible.module_utils.parsing.convert_bool.AnsibleError):
        pass
    class Mock_listify_lookup_plugin_terms(ansible.module_utils.parsing.convert_bool.listify_lookup_plugin_terms):
        pass

# Generated at 2022-06-11 16:03:37.248822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy
    import cStringIO as StringIO
    module_utils_path = 'ansible.module_utils.basic'

    class DummyVarsModule(object):
        def __init__(self, vars):
            self.vars = vars

        def vars_from_file(self, path):
            return self.vars

        @staticmethod
        def add_host_vars(host):
            pass

    class DummyHostVarsLoader(object):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, loader, path, entities, cache=True):
            return self.vars

    lookup_module = LookupModule()

    empty_list = []

# Generated at 2022-06-11 16:03:46.954643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # wrong args size
    test_item = None
    lookup_module = LookupModule()
    try:
        lookup_module.run(test_item, None)
    except AnsibleError as e:
        assert e.message == \
            "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"
    else:
        assert False

    # invalid first argument
    test_item = [1, 2, 3]
    try:
        lookup_module.run(test_item, None)
    except AnsibleError as e:
        assert e.message == \
            "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"
    else:
        assert False

    # invalid third argument
   

# Generated at 2022-06-11 16:03:55.290660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # make it possible to import the module without installing it
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))

    from lookup_plugins.subelements import LookupModule
    lookup = LookupModule()

    def _assert_run_returns(expected, terms, variables):
        result = lookup.run(terms, variables)
        assert result == expected, "expected '%s' but got '%s'" % (expected, result)

    # TODO: add tests!
    pass

# Generated at 2022-06-11 16:04:06.617631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import for the unit test
    # from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib
    # import for the unit test
    if not string_types:
        string_types = (str, bytes)
    if not boolean:
        boolean = (lambda x, strict=False: isinstance(x, bool) and x)

    vm = VariableManager()
    terms = [
        'users.yml',
        'mysql.hosts',
        {}
    ]

# Generated at 2022-06-11 16:04:14.601703
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyLookupModule(LookupModule):
        def __init__(self, loader, templar, **kwargs):
            pass

    def _run(terms, elementlist, **kwargs):
        lookup_plugin = DummyLookupModule(None, None)
        lookup_plugin.run(terms, None)

    from ansible.errors import AnsibleError

    try:
        _run([], [])
    except AnsibleError as exception:
        assert exception.message == "subelements lookup expects a list of two or three items, first a dict or a list, second a string pointing to the subkey"


# Generated at 2022-06-11 16:04:25.808057
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # make a fake loader object
    class Loader:
        def load_from_file(self, filename, *args, **kwargs):
            return filename

    # make a fake templar object
    class Templar:
        def template(self, variable):
            return variable

    # make a fake variable object
    class Var:
        def __init__(self):
            self.VARS = {'list_var': [{'key': 'value'}]}
            self.VARS['dict_var'] = {'key': {'key_in_dict': 'value_in_dict'}}
            self.VARS['nested_list_var'] = [{'key': {'inner_key': 'inner_value'}}]

# Generated at 2022-06-11 16:04:35.968012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit tests for method run"""
    from ansible.module_utils.six import string_types
    lookup_module = LookupModule()
    assert isinstance(lookup_module._templar,string_types)
    assert isinstance(lookup_module._loader,string_types)
    assert lookup_module.run([], {}) == []
    assert lookup_module.run({}, {}) == []
    assert lookup_module.run({}, {}, **{}) == []
    assert lookup_module.run(['', ''], {}) == []
    assert lookup_module.run([{}, ''], {}) == []


# Generated at 2022-06-11 16:04:44.969877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    test_lookup = LookupModule()

    # first term should be a list (or dict), second a string holding the subkey
    with pytest.raises(AnsibleError):
        test_lookup.run([], {})
    with pytest.raises(AnsibleError):
        test_lookup.run([[{'test': 'test_value'}]], {})
    with pytest.raises(AnsibleError):
        test_lookup.run([{'test': 'test_value'}, 'test_value'], {})

    # build_items
    with pytest.raises(AnsibleError):
        test_lookup.run([{'test': 'test_value'}, 'test', {'skip_missing': True}], {})

    # test_look

# Generated at 2022-06-11 16:04:57.318373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run([[{'a': '1'}, {'a': '2'}, {'a': '3'}], 'a'], None) == [({'a': '1'}, '1'), ({'a': '2'}, '2'), ({'a': '3'}, '3')], 'test_LookupModule_run_01 failed!'

# Generated at 2022-06-11 16:05:06.321900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_subject = LookupModule()
    # subjects:

# Generated at 2022-06-11 16:05:47.963051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO, StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.errors import AnsibleError

    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()


# Generated at 2022-06-11 16:06:00.122864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # check lookup terms - check number of terms
    terms = [{}, 'a.b']
    result = lookup_module.run(terms, None, **{})
    assert result == [], 'Could not handle two-term input (1)'

    # check lookup terms - check number of terms
    terms = [{}, 'a.b', {'skip_missing': False}]
    result = lookup_module.run(terms, None, **{})
    assert result == [], 'Could not handle three-term input (1)'

    # first term should be a list (or dict), second a string holding the subkey
    terms = [5, 'a.b']

# Generated at 2022-06-11 16:06:12.631868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.compat.six as six
    from ansible.compat.tests import unittest
    from ansible.utils.listify import listify_lookup_plugin_terms
    tests = [(["users", "mysql.hosts"], {"users": [{"name": "alice", "mysql": {"hosts": ["127.0.0.1", "localhost"], "password": "mysql-password"}, "authorized": ["/tmp/alice/onekey.pub", "/tmp/alice/twokey.pub"], "groups": ["wheel"]}]}, [('users', '127.0.0.1'), ('users', 'localhost')])]
    for (terms, variables, expected_result) in tests:
        terms = listify_lookup_plugin_terms(terms, templar=None, loader=None)


# Generated at 2022-06-11 16:06:23.859270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import json

# Generated at 2022-06-11 16:06:34.973898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.lookup import LookupBase


# Generated at 2022-06-11 16:06:47.060836
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # pylint: disable=unused-variable
    from ansible.errors import AnsibleError

    lookup_module_class = LookupModule()

    def _lookup_module_class_run(terms):
        return lookup_module_class.run(terms, None)

    def _assert_error(terms, msg):
        try:
            _lookup_module_class_run(terms)
            return False
        except AnsibleError as e:
            assert e.message == msg
            return True


# Generated at 2022-06-11 16:06:48.441437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No tests written for LookupModule_run!"

# Generated at 2022-06-11 16:06:52.972645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    terms = [
      [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}], 'a'
    ]
    result = f.run(terms, None)
    assert result == [(1,), (3,)]



# Generated at 2022-06-11 16:07:00.633717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.subelements
    lookupModule = ansible.plugins.lookup.subelements.LookupModule()


# Generated at 2022-06-11 16:07:10.361104
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given
    lu = LookupModule()
    terms = [
        {
            'one': {
                'subkey': [
                    1,
                    2
                ]
            },
            'two': {
                'subkey': [
                    11,
                    12,
                    13
                ]
            },
            'three': {
                'subkey': [
                    21,
                    22
                ]
            }
        },
        'subkey'
    ]
    # When
    ret = lu.run(terms, {})

    # Then

# Generated at 2022-06-11 16:08:28.204850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # (in)valid args
    assert LookupModule([[], ""], {}).run() == []
    assert LookupModule([[], "", {}], {}).run() == []
    assert LookupModule([[], "", {'skip_missing': True}], {}).run() == []
    assert LookupModule([[], "", {'skip_missing': False}], {}).run() == []

    assert LookupModule([dict(skipped=True), "", {}], {}).run() == []
    assert LookupModule([dict(skipped=False), "", {}], {}).run() == []

    assert LookupModule([['test'], "", {}], {}).run() == []
    assert LookupModule([['test'], "", {'skip_missing': True}], {}).run() == []

# Generated at 2022-06-11 16:08:35.955911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    # setup a fake task
    task = namedtuple('_task', 'args')

# Generated at 2022-06-11 16:08:48.112097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create lookup instance
    l = LookupModule()
    l._templar = None
    l._loader = None

    # test with a list of dictionaries with one subkey
    terms = [[{'x':1, 'y':2, 'subelements':[11,12,13]},
              {'x':1, 'y':3, 'subelements':[21,22,23]},
              {'x':2, 'y':2, 'subelements':[31,32,33]}],
             'subelements']

# Generated at 2022-06-11 16:08:52.797753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize fixture lookup module
    lookup_module = LookupModule()


    # Run the method run
    ret=lookup_module.run(['[{"hello": "world", "foo": "bar"}, {"hello": "timmy"}]', "hello"])
    assert ret == ['world', 'timmy']

# Generated at 2022-06-11 16:09:03.809176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes, to_text

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.hashing import checksum_s


# Generated at 2022-06-11 16:09:13.665919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()

    #
    # Positive tests
    #

    # case: terms contain list of dict and subkey
    terms = [[{'skipped': False, 'a': {'b': {'c': [{'d': 'e'}]}} }], 'a.b.c']
    results = lookup_obj.run(terms, {})
    assert len(results) == 1
    assert results[0][0]['a']['b']['c'][0]['d'] == 'e'

    # case: terms contain list of dict and subkey
    terms = [[{'skipped': False, 'a': 'b' }], 'a']
    results = lookup_obj.run(terms, {})
    assert len(results) == 0

    # case: terms contain list of dict and

# Generated at 2022-06-11 16:09:26.743724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple

    FakeTerm = namedtuple('FakeTerm', ['skipped', 'value'])
    FakeUser = namedtuple('FakeUser', ['skipped', 'value'])
