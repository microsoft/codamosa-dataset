

# Generated at 2022-06-12 06:34:36.619603
# Unit test for function should_build
def test_should_build():
    expected = False
    assert expected == should_build()


# Generated at 2022-06-12 06:34:44.544183
# Unit test for function should_build
def test_should_build():
    assert should_build is False
    config["build_command"] = "python3 setup.py sdist bdist_wheel"
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_release"] = True
    assert should_build() is True
    config["build_command"] = False
    assert should_build() is False


# Generated at 2022-06-12 06:34:46.733332
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-12 06:34:52.660005
# Unit test for function should_build
def test_should_build():
    # remove the config from the environment.
    # this prevents something outside of this test
    # from changing the results.
    env = {**config}
    for key in env:
        del config[key]
    command = "echo run"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert not should_build()
    config["build_command"] = command
    assert should_build()
    assert not should_remove_dist()
    config["remove_dist"] = True
    assert should_remove_dist()
    # restore the config
    for key, value in env.items():
        config[key] = value

# Generated at 2022-06-12 06:34:53.950335
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:35:00.564790
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    assert should_build()
    config["build_command"] = ""
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "true"
    assert should_build()
    config["build_command"] = "python setup.py sdist"
    assert should_build()



# Generated at 2022-06-12 06:35:01.536705
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:35:02.790778
# Unit test for function should_build
def test_should_build():
    result = should_build()
    assert result == False



# Generated at 2022-06-12 06:35:06.114583
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-12 06:35:16.741310
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "")
    assert should_build() == False

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", 'echo "Test build"')
    assert should_build() == True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", 'echo "Test build"')
    assert should_build() == True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)

# Generated at 2022-06-12 06:38:56.246569
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()


# Generated at 2022-06-12 06:39:02.378786
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_dist"] = "yespls"
    assert not should_build()



# Generated at 2022-06-12 06:39:08.002070
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Given remove_dist is enabled,
    config["remove_dist"] = "true"
    # When I check should_remove_dist
    result = should_remove_dist()
    # Then I should get True
    assert result is True

    # Given remove_dist is disabled,
    config["remove_dist"] = "false"
    # When I check should_remove_dist
    result = should_remove_dist()
    # Then I should get False
    assert result is False



# Generated at 2022-06-12 06:39:09.412626
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-12 06:39:15.133193
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = "false"
    assert not should_remove_dist()

    config["remove_dist"] = "1"
    assert should_remove_dist()

    config["remove_dist"] = "0"
    assert not should_remove_dist()



# Generated at 2022-06-12 06:39:26.222066
# Unit test for function should_build
def test_should_build():
    test_config = {"upload_to_pypi": False,
                   "upload_to_release": False,
                   "build_command": "setuptools sdist bdist_wheel"}
    config.update(test_config)
    assert should_build() is False
    test_config.update({"upload_to_pypi": True, "upload_to_release": False})
    config.update(test_config)
    assert should_build() is True
    test_config.update({"upload_to_pypi": False, "upload_to_release": True})
    config.update(test_config)
    assert should_build() is True
    test_config.update({"upload_to_pypi": True, "upload_to_release": True})
    config.update(test_config)

# Generated at 2022-06-12 06:39:37.828062
# Unit test for function should_build
def test_should_build():
    # global config
    config.clear()
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = True
    assert not should_build()
    config["upload_to_pypi"] = True

# Generated at 2022-06-12 06:39:42.034237
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config['remove_dist'] = False
    assert should_remove_dist() is False
    config['upload_to_pypi'] = True
    assert should_remove_dist() is False

# Generated at 2022-06-12 06:39:49.512328
# Unit test for function should_build
def test_should_build():
    from .settings import CONFIG_FILE
    from .settings import Settings

    settings = Settings(CONFIG_FILE)
    upload_pypi = settings.get("upload_to_pypi")
    upload_release = settings.get("upload_to_release")
    build_command = settings.get("build_command")
    build_command = build_command if build_command != "false" else False
    assert bool(build_command and (upload_pypi or upload_release)) == should_build()

# Generated at 2022-06-12 06:39:50.664457
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

