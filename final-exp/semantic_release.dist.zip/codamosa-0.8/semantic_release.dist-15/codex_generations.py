

# Generated at 2022-06-12 06:34:35.972011
# Unit test for function should_build
def test_should_build():
    with open("fixtures/settings/.release.yaml") as fp:
        config.update(config.read_file(fp))
    assert should_build()

# Generated at 2022-06-12 06:34:36.625455
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-12 06:34:39.156834
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_build() != False



# Generated at 2022-06-12 06:34:41.420298
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    assert should_remove_dist()



# Generated at 2022-06-12 06:34:42.927873
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "The function should return False"

# Generated at 2022-06-12 06:34:49.298134
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "false"

    config["upload_to_pypi"] = "true"
    config["build_command"] = "setup.py sdist"
    assert should_remove_dist()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist()


# Generated at 2022-06-12 06:34:50.542784
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:34:53.779871
# Unit test for function should_build
def test_should_build():
    result = should_build()
    logger.info(f"should_build() result => {result}")
    assert result == False



# Generated at 2022-06-12 06:35:02.872902
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from copy import copy
    test_config = copy(config)
    test_config["upload_to_pypi"] = True
    test_config["upload_to_release"] = True
    test_config["build_command"] = "False"
    test_config["remove_dist"] = True
    assert not should_remove_dist()

    test_config["upload_to_pypi"] = False
    assert not should_remove_dist()

    test_config["upload_to_release"] = False
    assert not should_remove_dist()

    test_config["build_command"] = "echo"
    assert not should_remove_dist()

    test_config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-12 06:35:09.574136
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "false")
    assert should_remove_dist() == False
    config.set("build_command", "true")
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:38:37.943188
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-12 06:38:45.056330
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist()

    config.set("remove_dist", False)
    config.set("upload_to_pypi", True)
    assert not should_remove_dist()

    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    config.set("remove_dist", False)
    config.set("upload_to_release", False)
    assert not should_remove_dist()

    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)

# Generated at 2022-06-12 06:38:48.728822
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "something")
    config.set("remove_dist", True)
    assert should_remove_dist()

# Generated at 2022-06-12 06:38:49.828410
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-12 06:38:54.607985
# Unit test for function should_build
def test_should_build():
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = True
    assert should_build()
    del config["build_command"]
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-12 06:39:01.596590
# Unit test for function should_build
def test_should_build():
    params = dict(
        upload_pypi=True,
        upload_release=False,
        build_command="build",
    )
    config.update(params)
    assert should_build() is True
    params = dict(
        upload_pypi=False,
        upload_release=True,
        build_command="build",
    )
    config.update(params)
    assert should_build() is True
    params = dict(
        upload_pypi=True,
        upload_release=True,
        build_command="build",
    )
    config.update(params)
    assert should_build() is True
    params = dict(
        upload_pypi=False,
        upload_release=False,
        build_command="build",
    )
    config.update(params)


# Generated at 2022-06-12 06:39:04.933105
# Unit test for function should_build
def test_should_build():
    """Test for enable should build functionality
    """
    config.pipeline_config = "tests/fixtures/config/config_should_build.yml"
    assert should_build() == True

# Generated at 2022-06-12 06:39:06.584821
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False

# Generated at 2022-06-12 06:39:08.602135
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:39:10.341736
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:42:38.511578
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["build_command"] = "true"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["build_command"] = "true"
    assert should_build() == False
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

