

# Generated at 2022-06-12 06:34:32.566184
# Unit test for function should_build
def test_should_build():
    should_build()

# Generated at 2022-06-12 06:34:39.342057
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config.update({"upload_to_pypi": True})
    assert should_build()

    config.update({"upload_to_pypi": "false"})
    config.update({"upload_to_release": True})
    assert should_build()

    config.update({"upload_to_release": "false"})
    config.update({"build_command": True})
    assert should_build()

    config.update({"build_command": "false"})
    assert not should_build()



# Generated at 2022-06-12 06:34:50.382173
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.update({"build_command": "true",
                   "upload_to_pypi": False,
                   "upload_to_release": False})
    assert should_build() is False
    config.update({"build_command": "true",
                   "upload_to_pypi": True,
                   "upload_to_release": False})
    assert should_build() is True
    config.update({"build_command": "true",
                   "upload_to_pypi": False,
                   "upload_to_release": True})
    assert should_build() is False
    config.update({"build_command": "true",
                   "upload_to_pypi": True,
                   "upload_to_release": True})
    assert should_build() is True
    config

# Generated at 2022-06-12 06:34:57.254433
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()
    config["upload_to_pypi"] = "false"
    assert not should_build()
    config["upload_to_pypi"] = None
    config["build_command"] = "echo foo"
    assert not should_build()



# Generated at 2022-06-12 06:35:04.265297
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "ls"
    assert should_build() == True

# Generated at 2022-06-12 06:35:06.061021
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:35:06.505273
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-12 06:35:17.295830
# Unit test for function should_build
def test_should_build():
    config.runtime_env.set("upload_to_pypi", "true")
    assert should_build() == True
    config.runtime_env.set("upload_to_pypi", "false")
    assert should_build() == False
    config.runtime_env.set("upload_to_release", "true")
    assert should_build() == True
    config.runtime_env.set("upload_to_release", "false")
    assert should_build() == False
    config.runtime_env.set("build_command", "python setup.py sdist")
    assert should_build() == True
    config.runtime_env.set("build_command", "false")
    assert should_build() == False
    config.runtime_env.pop("upload_to_pypi")
    config.runtime_env.pop

# Generated at 2022-06-12 06:35:22.959332
# Unit test for function should_build
def test_should_build():
    """
    Test the function should_build

    The function returns true when
    the build_command is set (not false) and
    upload_to_pypi is true or
    upload_to_release is true

    The function returns false when
    one of the conditions is not met
    """
    # With build_command set to false should return false
    assert should_build() is True

    # With upload_to_pypi set to false should return false
    assert should_build() is True

    # With upload_to_release set to false should return false
    assert should_build() is True

# Generated at 2022-06-12 06:35:24.007714
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-12 06:37:09.675065
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-12 06:37:14.872126
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["upload_to_pypi"] = True
    assert should_build()

    del config["upload_to_pypi"]
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "true"
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()

    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-12 06:37:21.440713
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = ""
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'build'"
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'build'"
    assert should_build() == False  # TODO: => True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'build'"
    assert should_build() == True

# Generated at 2022-06-12 06:37:26.132412
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = False
    assert should_build() == False


# Generated at 2022-06-12 06:37:37.600417
# Unit test for function should_build
def test_should_build():
    # When Upload to pypi is true
    config.set("upload_to_pypi", True)
    # And upload to release is true
    config.set("upload_to_release", True)
    # And build command is not false
    config.set("build_command", "false")
    # Then should build is False
    assert should_build() == False

    # When Upload to pypi is true
    config.set("upload_to_pypi", True)
    # And upload to release is true
    config.set("upload_to_release", True)
    # And build command is not false
    config.set("build_command", "true")
    # Then should build is False
    assert should_build() == True

    # When Upload to pypi is true

# Generated at 2022-06-12 06:37:47.089896
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_remove_dist()

    config.set("remove_dist", False)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert not should_remove_dist()

    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_remove_dist()



# Generated at 2022-06-12 06:37:51.973390
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "build_command"
    assert should_remove_dist() == True
    config["remove_dist"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:37:56.347448
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-12 06:37:57.199679
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:38:01.228904
# Unit test for function should_build
def test_should_build():
    config.settings = {}
    assert should_build() == False
    config.settings = {
        "build_command": "build",
        "upload_to_release": True,
    }
    assert should_build() == True
    config.settings = {
        "build_command": "build",
        "upload_to_release": False,
        "upload_to_pypi": True,
    }
    assert should_build() == True

# Generated at 2022-06-12 06:39:44.828327
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-12 06:39:52.939997
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = None
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True


# Generated at 2022-06-12 06:40:00.721809
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "python setup.py sdist"
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False


# Generated at 2022-06-12 06:40:01.848602
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-12 06:40:06.527886
# Unit test for function should_build
def test_should_build():
    expected = {
        "commands": {
            "false": False,
            "build": True,
            "upload_to_release": True,
            "upload_to_pypi": False,
        },
    }
    for k, v in expected.items():
        config[k] = v
        assert should_build() == v



# Generated at 2022-06-12 06:40:14.669086
# Unit test for function should_build
def test_should_build():
    # Case 1
    build_command = "sphinx-build -E -b html -d docs/_build/doctrees docs docs/_build/html"
    assert (not should_build(build_command, False, False))
    # Case 2
    assert (should_build(build_command, True, False))
    # Case 3
    assert (should_build(build_command, False, True))
    # Case 4
    assert (should_build(build_command, True, True))
    # Case 5
    assert (not should_build(None, True, False))
    # Case 6
    assert (not should_build(None, False, True))
    # Case 7
    assert (not should_build(None, True, True))
    # Case 8
    assert (not should_build(build_command, False, False))

# Generated at 2022-06-12 06:40:20.963736
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("build_command", "false")
    assert should_build() == False
    config.set("build_command", "pwd")
    assert should_build() == False
    config.set("upload_to_pypi", True)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    assert should_build() == False
    config.set("upload_to_release", True)
    assert should_build() == True



# Generated at 2022-06-12 06:40:25.344351
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.update({"build_command": "some * command --with-options"})
    assert should_build()
    config.update({"upload_to_pypi": True})
    assert should_build()



# Generated at 2022-06-12 06:40:31.427349
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["build_command"] = "echo hello"
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:40:36.208560
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["build_command"] = "touch /tmp/test.txt"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    config["build_command"] = "touch /tmp/test.txt"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert not should_remove_dist()

