

# Generated at 2022-06-12 06:34:24.758651
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-12 06:34:36.282518
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = "false"
    assert should_remove_dist() is True
    config["upload_to_release"] = "true"
    assert should_remove_dist() is True
    config["upload_to_release"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "true"
    assert should_remove_dist() is True
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "true"

# Generated at 2022-06-12 06:34:37.971283
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:34:44.596511
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-12 06:34:52.750267
# Unit test for function should_build
def test_should_build():
    config.set_config(dict(
        upload_to_pypi="false",
        upload_to_release="false",
        build_command="false",
    ))
    assert should_build() is False

    config.set_config(dict(
        upload_to_pypi="false",
        upload_to_release="false",
        build_command="true",
    ))
    assert should_build() is True

    config.set_config(dict(
        upload_to_pypi="true",
        upload_to_release="false",
        build_command="false",
    ))
    assert should_build() is True

    config.set_config(dict(
        upload_to_pypi="true",
        upload_to_release="false",
        build_command="true",
    ))


# Generated at 2022-06-12 06:34:54.003582
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-12 06:35:00.974398
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "a command"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = True
    assert should_build()



# Generated at 2022-06-12 06:35:01.950737
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-12 06:35:13.031703
# Unit test for function should_build
def test_should_build():
    # Case 1: upload_to_pypi is true, upload_to_release is false, build_command is true
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "True"
    assert should_build() == True

    # Case 2: upload_to_pypi is false, upload_to_release is true, build_command is true
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "True"
    assert should_build() == True

    # Case 3: upload_to_pypi is false, upload_to_release is false, build_command is true
    config["upload_to_pypi"] = False

# Generated at 2022-06-12 06:35:22.457840
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True

# Generated at 2022-06-12 06:38:53.602538
# Unit test for function should_remove_dist
def test_should_remove_dist():

    assert(True == should_remove_dist())


# Generated at 2022-06-12 06:38:59.142681
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "test"
    assert should_build() == True

# Generated at 2022-06-12 06:39:08.867228
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build"
    # if none of upload_to_pypi and upload_to_release are false,
    # should_build return True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()
    # if upload_to_pypi is False but upload_to_release is True
    # should_build return True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    # if upload_to_pypi is True but upload_to_release is False
    # should_build return True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()


# Generated at 2022-06-12 06:39:18.947135
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": "false", "upload_to_release": "false", "build_command": True})
    assert should_build() == False
    config.update({"upload_to_pypi": True, "upload_to_release": True, "build_command": "false"})
    assert should_build() == False
    config.update({"upload_to_pypi": True, "upload_to_release": True, "build_command": "True"})
    assert should_build() == True
    config.update({"upload_to_pypi": True, "upload_to_release": "false", "build_command": "True"})
    assert should_build() == True

# Generated at 2022-06-12 06:39:20.016951
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:39:21.402332
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:39:22.058364
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:39:26.201623
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "command to build a wheel"
    assert not should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build()


# Generated at 2022-06-12 06:39:37.829322
# Unit test for function should_remove_dist
def test_should_remove_dist():
    c = config.copy()
    c["remove_dist"] = "false"
    c["upload_to_release"] = "true"
    c["upload_to_pypi"] = "false"
    c["build_command"] = "true"
    assert should_remove_dist() is False

    c = config.copy()
    c["remove_dist"] = "false"
    c["upload_to_release"] = "false"
    c["upload_to_pypi"] = "true"
    c["build_command"] = "true"
    assert should_remove_dist() is False

    c = config.copy()
    c["remove_dist"] = "false"
    c["upload_to_release"] = "true"
    c["upload_to_pypi"] = "true"

# Generated at 2022-06-12 06:39:39.100075
# Unit test for function should_build
def test_should_build():
    assert should_build()