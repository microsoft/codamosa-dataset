

# Generated at 2022-06-12 06:34:35.581569
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Function should_remove_dist should return True/False as expected
    """
    from .settings.development import config as config_development
    from .settings.test_release import config as config_test_release
    from .settings.prod_pypi import config as config_prod_pypi
    from .settings.test_pypi import config as config_test_pypi

    assert should_remove_dist() is False
    assert should_remove_dist(config_development) is False
    assert should_remove_dist(config_test_release) is True
    assert should_remove_dist(config_prod_pypi) is True
    assert should_remove_dist(config_test_pypi) is True



# Generated at 2022-06-12 06:34:37.423894
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

    config.set("upload_to_pypi", False)
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:34:38.122532
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:34:41.420126
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert(should_remove_dist())

# Generated at 2022-06-12 06:34:45.008369
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["build_command"] = "echo"
    assert should_remove_dist()

# Generated at 2022-06-12 06:34:46.277706
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()


# Generated at 2022-06-12 06:34:47.299176
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-12 06:34:48.226879
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == should_build()

# Generated at 2022-06-12 06:34:49.119975
# Unit test for function should_build
def test_should_build():
    assert should_build()
    pass

# Generated at 2022-06-12 06:34:50.079954
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-12 06:36:33.069990
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True



# Generated at 2022-06-12 06:36:36.774955
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("build_command", "build")
    assert should_remove_dist()

    config.set("remove_dist", False)
    assert not should_remove_dist()

# Generated at 2022-06-12 06:36:37.581642
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-12 06:36:47.593201
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "echo Build"
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()
    config.pop("build_command", None)
    assert not should_build()


# Generated at 2022-06-12 06:36:48.447222
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:36:55.689713
# Unit test for function should_build
def test_should_build():
    config.set("build_command", True)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)

    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build()

# Generated at 2022-06-12 06:37:04.648714
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config.update({"build_command": "false"})
    assert not should_remove_dist()

    config.update({"build_command": "echo"})
    assert not should_remove_dist()

    config.update({"upload_to_pypi": True})
    assert not should_remove_dist()

    config.update({"remove_dist": False})
    assert not should_remove_dist()

    config.update({"remove_dist": True})
    assert should_remove_dist()

# Generated at 2022-06-12 06:37:06.443483
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:37:14.534846
# Unit test for function should_build
def test_should_build():
    config.globals = {"build_command": "echo Foobar"}
    assert should_build() is True

    config.globals = {
        "upload_to_release": True,
        "upload_to_pypi": True,
        "build_command": False
    }
    assert should_build() is False

    config.globals = {
        "upload_to_release": True,
        "upload_to_pypi": False,
        "build_command": False
    }
    assert should_build() is False

    config.globals = {
        "upload_to_release": False,
        "upload_to_pypi": True,
        "build_command": False
    }
    assert should_build() is False

# Generated at 2022-06-12 06:37:15.457565
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-12 06:38:56.426795
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-12 06:38:57.249083
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-12 06:38:58.014000
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-12 06:38:59.117684
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-12 06:39:00.968480
# Unit test for function should_build
def test_should_build():
    assert type(should_build()) == bool

# Generated at 2022-06-12 06:39:02.378468
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-12 06:39:07.007980
# Unit test for function should_remove_dist
def test_should_remove_dist():

    assert(should_remove_dist() == False)

    config.set("remove_dist", True)
    config.set("build_command", "false")

    assert(should_remove_dist() == False)

    config.set("build_command", "python setup.py sdist bdist_wheel")

    assert(should_remove_dist() == True)

# Generated at 2022-06-12 06:39:14.435254
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist()
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert should_remove_dist()
    config["upload_to_release"] = False
    assert not should_remove_dist()

# Generated at 2022-06-12 06:39:15.420722
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-12 06:39:16.909155
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:40:58.388011
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-12 06:40:59.264973
# Unit test for function should_build
def test_should_build():

    assert should_build() == True



# Generated at 2022-06-12 06:41:04.957358
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

    with config.patch({"upload_to_pypi": False}):
        assert should_build() is False

    with config.patch({"upload_to_release": False}):
        assert should_build() is False

    with config.patch({"build_command": "false"}):
        assert should_build() is False



# Generated at 2022-06-12 06:41:06.307617
# Unit test for function should_remove_dist
def test_should_remove_dist():  # pragma: no cover
    assert should_remove_dist() is True

# Generated at 2022-06-12 06:41:15.782014
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist()

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist()

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_remove_dist()

    config["build_command"] = "false"
    assert should_remove_dist()

    config["build_command"] = "sphinx-build"
    assert should_remove_

# Generated at 2022-06-12 06:41:17.083583
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-12 06:41:19.003658
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set_key("upload_to_release", True)
    config.set_key("build_command", "python setup.py sdist bdist_wheel")
    assert should_build()

# Generated at 2022-06-12 06:41:23.512330
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config.set("build_command", "echo 'echo'")
    assert not should_build()

    config.set("upload_to_pypi", "true")
    assert should_build()

# Generated at 2022-06-12 06:41:25.710507
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False

# Generated at 2022-06-12 06:41:27.275413
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

