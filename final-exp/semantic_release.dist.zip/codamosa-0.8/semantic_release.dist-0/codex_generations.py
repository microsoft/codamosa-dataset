

# Generated at 2022-06-12 06:34:41.811238
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:34:43.284880
# Unit test for function should_build
def test_should_build():
    from . import config
    assert should_build()



# Generated at 2022-06-12 06:34:44.740864
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:34:45.755824
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-12 06:34:47.066551
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-12 06:34:54.788339
# Unit test for function should_remove_dist
def test_should_remove_dist():
    data = [
        ({"build_command": True, "upload_to_pypi": True, "remove_dist": True}, True),
        ({"build_command": True, "upload_to_pypi": True, "remove_dist": False}, True),
        ({"build_command": True, "upload_to_pypi": False, "remove_dist": True}, True),
        ({"build_command": True, "upload_to_pypi": False, "remove_dist": False}, True),
        ({"build_command": False, "upload_to_pypi": True, "remove_dist": True}, False),
        ({"build_command": False, "upload_to_pypi": True, "remove_dist": False}, False)
    ]
    for data, expected in data:
        config

# Generated at 2022-06-12 06:34:59.428995
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist()
    config["build_command"] = False
    assert not should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-12 06:35:00.518430
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:35:01.860588
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-12 06:35:02.805727
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:39:06.743733
# Unit test for function should_remove_dist
def test_should_remove_dist():
  from .settings import config
  config.load("settings.yml")
  config.set("remove_dist", True)
  config.set("build_command", "python setup.py sdist")
  assert should_remove_dist() == True
  config.set("upload_to_pypi", True)
  assert should_remove_dist() == True
  config.set("upload_to_release", True)
  assert should_remove_dist() == True
  config.set("upload_to_pypi", False)
  assert should_remove_dist() == True
  config.set("upload_to_release", False)
  assert should_remove_dist() == False
  config.set("build_command", False)
  assert should_remove_dist() == False

# Generated at 2022-06-12 06:39:08.857279
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-12 06:39:18.948120
# Unit test for function should_build
def test_should_build():
    # Should build when upload to pypi is set
    cfg = {"upload_to_pypi": "true", "build_command": "echo 'Build cmd'", "upload_to_release": False}
    assert should_build(cfg) is True

    # Should build when upload to release is set
    cfg = {"upload_to_pypi": False, "build_command": "echo 'Build cmd'", "upload_to_release": "true"}
    assert should_build(cfg) is True

    # Should not build when upload to pypi and release are set, but build command is False
    cfg = {"upload_to_pypi": "true", "build_command": False, "upload_to_release": "true"}
    assert should_build(cfg) is False

    # Should not build when upload to pyp

# Generated at 2022-06-12 06:39:23.469706
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["upload_to_pypi"] = True
    assert should_build() == False

    config["upload_to_release"] = True
    assert should_build() == False

    config["build_command"] = "echo 'Hello'"
    assert should_build() == True

# Generated at 2022-06-12 06:39:25.829511
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "True"
    config["build_command"] = "some-command"
    assert should_remove_dist() is True



# Generated at 2022-06-12 06:39:35.116806
# Unit test for function should_build
def test_should_build():

    # Check the function is correct when upload_to_pypi is set
    assert should_build() is True
    config.set("upload_to_pypi", "False")

    # Check the function is correct when upload_to_release is set
    config.set("upload_to_release", "True")
    assert should_build() is True
    config.set("upload_to_release", "False")

    # Check the function is correct when build_command is set to false
    config.set("upload_to_release", "False")
    config.set("build_command", "false")
    assert should_build() is False

# Generated at 2022-06-12 06:39:36.113955
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:39:40.633046
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_release"] = True
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "ls"
    assert should_build() is True



# Generated at 2022-06-12 06:39:48.105680
# Unit test for function should_build
def test_should_build():
    # Should always return True if the
    # build_command is set and we will upload to PyPI
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    assert should_build() is True

    # Should always return True if the
    # build_command is set and we will upload to PyPI
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True

# Generated at 2022-06-12 06:39:49.597237
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
