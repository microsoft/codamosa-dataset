

# Generated at 2022-06-12 06:34:51.887129
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "sdist"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "sdist"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "sdist"
    assert should_build()

    config["upload_to_pypi"] = False
   

# Generated at 2022-06-12 06:34:52.522601
# Unit test for function should_remove_dist
def test_should_remove_dist():
    pass

# Generated at 2022-06-12 06:34:54.430529
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-12 06:35:00.652950
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.settings["cmd_release_config"]["remove_dist"] = True
    config.settings["cmd_release_config"]["upload_to_pypi"] = False
    config.settings["cmd_release_config"]["upload_to_release"] = False

    assert should_remove_dist() is False

    config.settings["cmd_release_config"]["upload_to_release"] = True

    assert should_remove_dist()



# Generated at 2022-06-12 06:35:07.659871
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test with empty config
    config = {}
    should_remove = should_remove_dist()
    assert not should_remove

    # Test with upload_to_pypi=false and remove_dist=true
    config = {
        "upload_to_pypi": False,
        "remove_dist": True
    }
    should_remove = should_remove_dist()
    assert should_remove

    # Test with upload_to_pypi=true and remove_dist=false
    config = {
        "upload_to_pypi": True,
        "remove_dist": False
    }
    should_remove = should_remove_dist()
    assert not should_remove

    # Test with upload_to_pypi=true, remove_dist=true, build_command=""

# Generated at 2022-06-12 06:35:08.685036
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:35:20.095432
# Unit test for function should_build
def test_should_build():
    # This should return False because we are not uploading to anything
    assert not should_build()

    # This should return True because we are uploading to pypi
    assert should_build(upload_pypi=True)

    # This should return True because we are uploading to release
    assert should_build(upload_release=True)

    # This should return True because we are uploading to release
    assert should_build(build_command="test")

    # This should return False because we are not uploading to anything
    assert not should_build(build_command="test", remove_dist=True)
    assert not should_build(build_command="test", upload_pypi=True, remove_dist=True)
    assert not should_build(build_command="test", upload_release=True, remove_dist=True)



# Generated at 2022-06-12 06:35:25.009415
# Unit test for function should_remove_dist
def test_should_remove_dist():
    def helper(config: dict):
        config.update({"build_command": "echo", "remove_dist": True})
        assert should_remove_dist() is True

        config.update({"build_command": "false"})
        assert should_remove_dist() is False

    helper(config)

# Generated at 2022-06-12 06:35:25.870741
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:35:35.999679
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN
    config_with_remove_dist_true = {
        "remove_dist": "true",
        "upload_to_pypi": "true",
        "upload_to_release": "false",
        "build_command": "npm run build"
    }

    config_with_remove_dist_true_and_upload_to_release = {
        "remove_dist": "true",
        "upload_to_pypi": "false",
        "upload_to_release": "true",
        "build_command": "npm run build"
    }


# Generated at 2022-06-12 06:37:32.701307
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "true")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("remove_dist", True)
    assert should_remove_dist() is True
    

# Generated at 2022-06-12 06:37:33.760526
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:37:35.758590
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:37:36.679940
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-12 06:37:47.791720
# Unit test for function should_build
def test_should_build():
    # if no build command is set, return false
    config["build_command"] = "false"
    assert not should_build()

    # if build command is set and no upload is required, return true
    config["build_command"] = "true"
    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    assert should_build()

    # if build command is set and upload to release is required, return true
    config["build_command"] = "true"
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    assert should_build()

    # if build command is set and upload to pypi is required, return true
    config["build_command"] = "true"
    config["upload_to_pypi"] = True

# Generated at 2022-06-12 06:37:52.482452
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("build_command", "python setup.py sdist")
    assert should_build()
    assert not should_build()
    config.set("upload_to_pypi", "True")
    assert should_build()
    config.set("upload_to_pypi", "True")
    assert should_build()

# Generated at 2022-06-12 06:37:59.327669
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

    config["build_command"] = "false"
    assert should_build() == False

    config["build_command"] = "a command"
    config["upload_to_pypi"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True



# Generated at 2022-06-12 06:38:00.314609
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:38:01.335377
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-12 06:38:11.221214
# Unit test for function should_build
def test_should_build():
    # upload to release repo: yes
    assert should_build()

    # upload to release repo: no
    config.set("upload_to_release", None)
    assert should_build()

    # upload to pypi: yes
    config.set("upload_to_release", "http://example.com")
    config.set("upload_to_pypi", "yes")
    assert should_build()

    # upload to pypi: no
    config.set("upload_to_pypi", None)
    assert not should_build()

    # build_command: false
    config.set("build_command", "false")
    assert not should_build()

    # build_command: true
    config.set("build_command", "true")
    assert should_build()



# Generated at 2022-06-12 06:40:05.571881
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True

# Generated at 2022-06-12 06:40:12.861400
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["upload_to_pypi"] = "false"
    assert not should_remove_dist()
    config["upload_to_release"] = "true"
    assert should_remove_dist()
    config["upload_to_release"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-12 06:40:14.731799
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()



# Generated at 2022-06-12 06:40:19.154683
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    yield
    config.update({"build_command": "sphinx-build", "upload_to_pypi": False, "upload_to_release": False})
    assert not should_build()
    yield
    config.update({"upload_to_pypi": True})
    assert should_build()

# Generated at 2022-06-12 06:40:28.255037
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN
    config.set("remove_dist", True)
    # WHEN
    config.set("build_command", "true")
    config.set("upload_to_pypi", True)
    # THEN
    assert True == should_remove_dist()
    # WHEN
    config.set("build_command", "false")
    config.set("upload_to_pypi", True)
    # THEN
    assert False == should_remove_dist()
    # WHEN
    config.set("build_command", "true")
    config.set("upload_to_pypi", False)
    # THEN
    assert False == should_remove_dist()

# Generated at 2022-06-12 06:40:35.560385
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update(dict(remove_dist="true", upload_to_pypi="true"))
    assert should_remove_dist()
    config.update(dict(remove_dist="false", upload_to_pypi="true"))
    assert not should_remove_dist()
    config.update(dict(remove_dist="true", upload_to_release="true"))
    assert should_remove_dist()
    config.update(dict(remove_dist="false", upload_to_release="true"))
    assert not should_remove_dist()
    config.update(dict(remove_dist="false", build_command="false"))
    assert not should_remove_dist()


# Generated at 2022-06-12 06:40:38.060169
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config['remove_dist'] = 'true'
    config['build_command'] = 'true'
    assert should_remove_dist() is True

# Generated at 2022-06-12 06:40:39.203211
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:40:48.897672
# Unit test for function should_build
def test_should_build():
    global config
    config = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "python setup.py sdist bdist_wheel",
    }
    assert should_build()

    config = {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "python setup.py sdist bdist_wheel",
    }
    assert should_build()

    config = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "python setup.py sdist bdist_wheel",
    }
    assert not should_build()


# Generated at 2022-06-12 06:40:50.336381
# Unit test for function should_build
def test_should_build():
    assert "false" == "false"

