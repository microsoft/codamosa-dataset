

# Generated at 2022-06-12 06:34:40.853992
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:34:46.834895
# Unit test for function should_build
def test_should_build():
    assert(should_build() == False)
    config["build_command"] = "rm *"
    assert(should_build() == True)
    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    assert(should_build() == False)
    config["upload_to_release"] = True
    assert(should_build() == True)

# Generated at 2022-06-12 06:34:54.612825
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = config
    with test_config._get_mutator({'upload_to_release': True,
                                   'upload_to_pypi': True,
                                   'build_command': 'pandas',
                                   'remove_dist': True}) as config_inst:
        assert should_remove_dist() == True
    with test_config._get_mutator({'upload_to_release': True,
                                   'upload_to_pypi': True,
                                   'build_command': 'pandas',
                                   'remove_dist': False}) as config_inst:
        assert should_remove_dist() == False

# Generated at 2022-06-12 06:34:55.766391
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-12 06:35:03.106229
# Unit test for function should_build
def test_should_build():
    for upload_pypi in (True, False):
        for upload_release in (True, False):
            for build_command in (True, False):
                config["build_command"] = build_command
                config["upload_to_pypi"] = upload_pypi
                config["upload_to_release"] = upload_release
                assert should_build() == (build_command and (upload_pypi or upload_release))
                # Should remove if build an upload
                assert should_remove_dist() == (build_command and (upload_pypi or upload_release))



# Generated at 2022-06-12 06:35:08.397277
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = 'true'
    config['build_command'] = 'python3 setup.py sdist bdist_wheel'
    config['upload_to_pypi'] = 'true'
    assert should_remove_dist()

# Generated at 2022-06-12 06:35:17.257534
# Unit test for function should_build
def test_should_build():
    yaml = load_yaml_config()
    yaml["upload_to_release"] = True
    yaml["upload_to_pypi"] = False
    yaml["build_command"] = """echo "test"""
    set_config_from_dict(yaml)
    assert should_build() == True

    # last value should be False
    yaml["upload_to_release"] = False
    yaml["upload_to_pypi"] = False
    yaml["build_command"] = """echo "test"""
    assert should_build() == False

# Generated at 2022-06-12 06:35:18.389469
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-12 06:35:19.268534
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:35:24.528868
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_build()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert not should_build()

# Generated at 2022-06-12 06:37:09.347502
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Given
    config.update({"upload_to_pypi": False, "upload_to_release": True})
    assert should_remove_dist()



# Generated at 2022-06-12 06:37:16.600456
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": False,
                   "upload_to_pypi": True,
                   "upload_to_release": True,
                   "build_command": "echo test"})
    assert should_remove_dist() is False
    config.update({"remove_dist": True})
    assert should_remove_dist() is True
    config.update({"upload_to_pypi": False,
                   "upload_to_release": False})
    assert should_remove_dist() is False
    config.update({"upload_to_pypi": False,
                   "upload_to_release": True})
    assert should_remove_dist() is False
    config.update({"upload_to_pypi": True,
                   "upload_to_release": False})

# Generated at 2022-06-12 06:37:21.643764
# Unit test for function should_build
def test_should_build():
    config['build_command'] = "false"
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    assert False is should_build()

    config['upload_to_pypi'] = True
    assert True is should_build()


# Generated at 2022-06-12 06:37:29.709667
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "pybuilder"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "pybuilder"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "pybuilder"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "pybuilder"
    assert not should_build()

    config["upload_to_pypi"] = True


# Generated at 2022-06-12 06:37:38.207210
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "true"
    assert should_build() == True

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_build() == True


# Generated at 2022-06-12 06:37:40.126956
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist()



# Generated at 2022-06-12 06:37:43.905331
# Unit test for function should_build
def test_should_build():
    for val in [True, False]:
        config["upload_to_pypi"] = val
        config["upload_to_release"] = val
        # build_command is always True here
        assert should_build() is True

# Generated at 2022-06-12 06:37:44.845946
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:37:53.005863
# Unit test for function should_build
def test_should_build():
    from .settings import config

    config.set("build_command", "python setup.py sdist bdist_wheel")
    assert should_build()

    config.set("build_command", "false")
    assert not should_build()

    config.set("upload_to_pypi", "false")
    assert not should_build()

    config.set("upload_to_release", "false")
    assert not should_build()

    config.set("upload_to_pypi", "true")
    assert not should_build()

    config.set("upload_to_release", "true")
    assert should_build()

# Generated at 2022-06-12 06:37:57.722077
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test that it is true if the config flag is True
    assert should_remove_dist()

    # Test that it is false if the config flag is False
    config.update({
        "build_command": False,
        "upload_to_pypi": False,
        "upload_to_release": False,
        "remove_dist": False,
    })
    assert not should_remove_dist()



# Generated at 2022-06-12 06:39:50.586631
# Unit test for function should_build
def test_should_build():
    config.update({"build_command": False, "upload_to_pypi": False, "upload_to_release": False})
    assert should_build() == False
    config.update({"build_command": "true", "upload_to_pypi": True, "upload_to_release": False})
    assert should_build() == True
    config.update({"build_command": "true", "upload_to_pypi": False, "upload_to_release": True})
    assert should_build() == True
    config.update({"build_command": "true", "upload_to_pypi": True, "upload_to_release": True})
    assert should_build() == True

# Generated at 2022-06-12 06:39:53.519533
# Unit test for function should_build
def test_should_build():
    """
    Test to see if should_build is returning the correct value
    """

    # Test for True
    assert should_build()

    # Test for False
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    assert not should_build()

# Generated at 2022-06-12 06:40:04.544407
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    config["remove_dist"] = True
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "true"
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "true"
    config["remove_dist"] = True
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True

# Generated at 2022-06-12 06:40:10.607042
# Unit test for function should_build
def test_should_build():
    pypi_build = {"build_command":"pytest","upload_to_pypi":True}
    release_build = {"build_command":"pytest","upload_to_release":True}
    no_build = {"build_command":"false","upload_to_pypi":True}
    assert should_build(pypi_build)
    assert should_build(release_build)
    assert not should_build(no_build)



# Generated at 2022-06-12 06:40:16.626387
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # If upload_to_pypi or upload_to_release are True, return False
    config.set('upload_to_pypi', True)
    config.set('upload_to_release', True)
    config.set('build_command', True)
    config.set('remove_dist', False)
    assert(should_remove_dist() == False)
    # If upload_to_pypi and upload_to_release are False and remove_dist is True, return True
    config.set('upload_to_pypi', False)
    config.set('upload_to_release', False)
    config.set('remove_dist', True)
    assert(should_remove_dist() == True)
    # If build_command is False, return False
    config.set('remove_dist', True)

# Generated at 2022-06-12 06:40:22.532632
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    assert should_build()

    config["build_command"] = "false"
    config["upload_to_pypi"] = True
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-12 06:40:23.694546
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-12 06:40:31.344061
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("build_command", "true")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("upload_to_docker", False)
    assert should_remove_dist() is False

    config.set("upload_to_pypi", True)
    assert should_remove_dist() is True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist() is True

# Generated at 2022-06-12 06:40:36.390392
# Unit test for function should_build
def test_should_build():
    from .settings import config
    from .settings import save_config
    assert not should_build()
    config["build_command"] = "true"
    save_config("./test.cfg")
    assert should_build()
    config["upload_to_pypi"] = False
    save_config("./test.cfg")
    assert not should_build()
    config["build_command"] = "false"
    save_config("./test.cfg")
    assert not should_build()

# Generated at 2022-06-12 06:40:38.493033
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    # insert a false value for build_command
    assert should_remove_dist() == False