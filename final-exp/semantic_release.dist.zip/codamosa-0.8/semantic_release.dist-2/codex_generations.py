

# Generated at 2022-06-12 06:34:52.638174
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    assert not should_build()

    config["build_command"] = "echo true"
    assert not should_build()

    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    assert not should_build()

    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-12 06:34:56.106285
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.update({"build_command": "true", "upload_to_pypi": True})
    assert should_build() is True

# Generated at 2022-06-12 06:34:57.438320
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist()

# Generated at 2022-06-12 06:34:58.405581
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-12 06:35:01.376506
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update(config.get("test").get("should_remove_dist"))
    assert should_remove_dist() is False
    config.update(config.get("dev"))


# Generated at 2022-06-12 06:35:02.950140
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist(False) == False



# Generated at 2022-06-12 06:35:06.389645
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-12 06:35:07.706959
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build(build_command="false") is False

# Generated at 2022-06-12 06:35:08.732952
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-12 06:35:18.570001
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    # not upload_to_pypi and not upload_to_release = false
    assert not should_build()
    config["upload_to_pypi"] = "true"
    # not upload_to_release = true
    assert should_build()
    config["upload_to_release"] = "true"
    # true
    assert should_build()
    config["build_command"] = "ls"
    # true
    assert should_build()

# Generated at 2022-06-12 06:39:20.569088
# Unit test for function should_build
def test_should_build():
    config.setdefault("upload_to_pypi", False)
    assert not should_build()

    config.setdefault("upload_to_pypi", True)
    assert should_build()

    config.setdefault("build_command", "false")
    assert not should_build()

    config.setdefault("build_command", "echo Hello World")
    assert should_build()



# Generated at 2022-06-12 06:39:23.056261
# Unit test for function should_remove_dist
def test_should_remove_dist():
    t1 = should_remove_dist()
    assert t1 == False
    t2 = should_build()
    assert t2 == True

# Generated at 2022-06-12 06:39:24.237797
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:39:24.988416
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-12 06:39:26.141622
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-12 06:39:34.066721
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Test should_remove_dist function

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError: If build_dists is False when remove_dists is True
    """
    config.settings["remove_dist"] = True
    config.settings["build_command"] = "echo \"test command\""
    assert should_remove_dist() == True
    config.settings["remove_dist"] = True
    config.settings["build_command"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:39:38.043048
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # set to false
    config["remove_dist"] = "false"
    assert not should_remove_dist()

    # set to true
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert not should_remove_dist()

    # set to true
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-12 06:39:49.406748
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "foo")
    assert should_build() == False

    config.set("build_command", "false")
    assert should_build() == False

    config.set("build_command", "python setupy.py sdist bdist_wheel")
    assert should_build() == False

    config.set("build_command", "python setup.py sdist bdist_wheel")
    config.set("upload_to_release", True)
    assert should_build() == True

    config.set("build_command", "python setup.py sdist bdist_wheel")
    config.set("upload_to_release", False)
    config.set("upload_to_pypi", True)
    assert should_build() == True



# Generated at 2022-06-12 06:39:51.162461
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True, "Should return True"
    assert should_remove_dist() is False, "Should return False"

# Generated at 2022-06-12 06:40:02.585464
# Unit test for function should_build
def test_should_build():
    from .settings import override_default_config
    from .settings import config as _config

    config_values = {
        "build_command": "echo build",
        "upload_to_pypi": "true",
        "upload_to_release": "true",
    }
    override_default_config(config_values)
    assert should_build() is True
    config_values = {
        "build_command": "echo build",
        "upload_to_pypi": "false",
        "upload_to_release": "true",
    }
    override_default_config(config_values)
    assert should_build() is True