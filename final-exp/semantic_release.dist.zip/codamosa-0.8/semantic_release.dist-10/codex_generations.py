

# Generated at 2022-06-12 06:34:36.979187
# Unit test for function should_build
def test_should_build():
    config["build_command"] = False
    assert not should_build()

    config["upload_to_pypi"] = False
    config["build_command"] = "rm -rf *.dist"
    assert should_build()

    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    assert not should_build()



# Generated at 2022-06-12 06:34:38.850063
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-12 06:34:50.013105
# Unit test for function should_build
def test_should_build():
    #  When upload_to_pypi is True, upload_to_release is False
    #  and build_command is True, function should_build() should
    #  return True.
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    config['build_command'] = True
    assert should_build()
    #  When upload_to_pypi is False, upload_to_release is True
    #  and build_command is True, function should_build() should
    #  return True.
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    config['build_command'] = True
    assert should_build()
    #  When upload_to_pypi is True, upload_to_release is True

# Generated at 2022-06-12 06:34:55.013901
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-12 06:35:02.291798
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "echo 'hello'"
    assert not should_build()
    config["build_command"] = "echo 'hello'"
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()

# Generated at 2022-06-12 06:35:04.402102
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-12 06:35:06.923423
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    assert bool(should_remove_dist()) == False


# Generated at 2022-06-12 06:35:08.701946
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    expected = config.get("upload_to_release")
    config.set("upload_to_release", True)
    assert should_build() == expected

# Generated at 2022-06-12 06:35:10.624884
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-12 06:35:11.963204
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-12 06:37:13.883272
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 1"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 1"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 1"
    assert not should_build()

    config["upload_to_pypi"] = True


# Generated at 2022-06-12 06:37:18.961856
# Unit test for function should_build
def test_should_build():
    expected_false = {"build_command": False, "upload_to_pypi": True, "upload_to_release": True}
    expected_true = {"build_command": "sphinx-build", "upload_to_pypi": True, "upload_to_release": True}
    assert should_build() == False
    assert should_build(**expected_false) == False
    assert should_build(**expected_true) == True