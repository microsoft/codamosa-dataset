

# Generated at 2022-06-12 06:34:36.659040
# Unit test for function should_build
def test_should_build():
    args = {"upload_to_pypi": True, "upload_to_release": None, "build_command": "this is a command"}
    assert should_build()
    assert config["build_command"] == "this is a command"

# Generated at 2022-06-12 06:34:39.829274
# Unit test for function should_build
def test_should_build():
    # Given

    # When
    result = should_build()

    # Then
    assert result is False



# Generated at 2022-06-12 06:34:41.071160
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:34:44.230079
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": True, "upload_to_pypi": True, "build_command": "echo"})
    assert should_remove_dist()

# Generated at 2022-06-12 06:34:48.673695
# Unit test for function should_remove_dist
def test_should_remove_dist():
    #  default
    assert should_remove_dist() == True

    # not on pypi
    config["upload_to_pypi"] = False
    assert should_remove_dist() == True

    # not on release
    config["upload_to_release"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:34:59.933519
# Unit test for function should_build
def test_should_build():
    config.upload_to_pypi = True
    config.upload_to_release = False
    assert should_build() is True

    config.upload_to_pypi = False
    config.upload_to_release = True
    assert should_build() is True

    config.upload_to_pypi = True
    config.upload_to_release = True
    assert should_build() is True

    config.upload_to_pypi = False
    config.upload_to_release = False
    assert should_build() is False

    config.upload_to_pypi = False
    config.upload_to_release = False
    config.build_command = "python setup.py sdist bdist_wheel"
    assert should_build() is True

    config.upload_to_pypi = False
   

# Generated at 2022-06-12 06:35:07.355310
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "python setup.py sdist")
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "python setup.py sdist")
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "python setup.py sdist")
    assert not should_build()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)

# Generated at 2022-06-12 06:35:08.036099
# Unit test for function should_build
def test_should_build():
    should_build()


# Generated at 2022-06-12 06:35:10.153956
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True



# Generated at 2022-06-12 06:35:11.095631
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:38:53.132161
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = ""
    config["upload_to_release"] = ""
    config["build_command"] = ""
    assert not should_build()

    config["upload_to_pypi"] = "local"
    config["upload_to_release"] = ""
    config["build_command"] = "echo"
    assert should_build()

    config["upload_to_pypi"] = ""
    config["upload_to_release"] = "local"
    config["build_command"] = "echo"
    assert should_build()

    config["upload_to_pypi"] = "local"
    config["upload_to_release"] = "local"
    config["build_command"] = "echo"
    assert should_build()


# Generated at 2022-06-12 06:38:54.996728
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:39:01.117968
# Unit test for function should_build
def test_should_build():
    # should return True
    config["upload_to_pypi"] = True
    assert should_build()

    # should return True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    # should return False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    # should return False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-12 06:39:04.487260
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": True})
    assert should_remove_dist()
    config.update({"remove_dist": False})
    assert not should_remove_dist()

# Generated at 2022-06-12 06:39:06.206419
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True, "The remove_dist should be True"



# Generated at 2022-06-12 06:39:08.602916
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()

# Generated at 2022-06-12 06:39:12.441453
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["build_command"] = True
    assert should_build() is False
    config["upload_to_release"] = True
    assert should_build() is True

# Generated at 2022-06-12 06:39:17.116131
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "echo hi"
    # build_command is set but remove_dist is not
    assert should_remove_dist() == False

    config["remove_dist"] = "true"
    # build_command and remove_dist are set
    assert should_remove_dist() == True

    config["build_command"] = "false"
    # build_command is not set
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:39:27.346109
# Unit test for function should_build
def test_should_build():
    config_1 = dict(upload_to_pypi="False", upload_to_release="False", build_command="build")
    config_2 = dict(upload_to_pypi="True", upload_to_release="False", build_command="build")
    config_3 = dict(upload_to_pypi="False", upload_to_release="True", build_command="build")
    config_4 = dict(upload_to_pypi="True", upload_to_release="True", build_command="build")
    config_5 = dict(upload_to_pypi="True", upload_to_release="True", build_command="false")
    config_6 = dict(upload_to_pypi="False", upload_to_release="False")

# Generated at 2022-06-12 06:39:39.044883
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_dict = {"build_command": "test",
                   "upload_to_release": True,
                   "upload_to_pypi": False,
                   "remove_dist": True}
    config_dict_1 = {"build_command": "false",
                   "upload_to_release": False,
                   "upload_to_pypi": True,
                   "remove_dist": True}
    config_dict_2 = {"build_command": "test",
                   "upload_to_release": False,
                   "upload_to_pypi": True,
                   "remove_dist": True}
    config_dict_3 = {"build_command": "test",
                   "upload_to_release": True,
                   "upload_to_pypi": False,
                   "remove_dist": False}
    config_dict_

# Generated at 2022-06-12 06:40:38.440156
# Unit test for function should_build
def test_should_build():
    config.set_section('pypi')
    config.pypi.set('upload_to_pypi', True)
    config.pypi.set('upload_to_release', True)
    config.pypi.set('build_command', 'echo')
    assert should_build()

    config.pypi.set('upload_to_release', False)
    assert should_build()

    config.pypi.set('upload_to_pypi', False)
    assert not should_build()

    config.pypi.set('upload_to_release', True)
    config.pypi.set('build_command', 'false')
    assert not should_build()



# Generated at 2022-06-12 06:40:43.891576
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    assert should_remove_dist()
    config["build_command"] = False
    assert not should_remove_dist()

    config["build_command"] = "export"
    assert should_remove_dist()

# Generated at 2022-06-12 06:40:46.045640
# Unit test for function should_build
def test_should_build():
    settings = {
            "upload_to_pypi": "true",
            "upload_to_release": "false",
            "build_command": "echo building",
            }
    assert should_build(settings=settings) == True


# Generated at 2022-06-12 06:40:53.477448
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False

    config["build_command"] = "python setup.py sdist"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False

    config["build_command"] = "python setup.py sdist"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True

    config["build_command"] = "python setup.py sdist"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build

# Generated at 2022-06-12 06:40:54.351430
# Unit test for function should_remove_dist
def test_should_remove_dist():
    should_remove_dist()

# Generated at 2022-06-12 06:40:55.176900
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-12 06:41:00.405994
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from . import config
    config.set("upload_to_pypi", True)
    assert should_remove_dist() == True
    config.set("upload_to_release", True)
    assert should_remove_dist() == True
    config.set("upload_to_release", False)
    assert should_remove_dist() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_remove_dist() == False
    config.set("upload_to_pypi", True)
    assert should_remove_dist() == False
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:41:11.492141
# Unit test for function should_build
def test_should_build():
    # In case of upload_pypi or upload_release not set at all
    config.set("upload_to_pypi", None)
    config.set("upload_to_release", None)
    assert should_build() is False
    # In case of upload_to_release set to false
    config.set("upload_to_release", False)
    config.set("build_command", "build")
    assert should_build() is False
    # In case of upload_to_release and upload_to_release set to true
    # with build_command being true too
    config.set("upload_to_release", True)
    config.set("upload_to_pypi", True)
    assert should_build() is True
    # In case of upload_to_release and upload_to_release set to true
    #

# Generated at 2022-06-12 06:41:13.340235
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-12 06:41:19.273995
# Unit test for function should_remove_dist
def test_should_remove_dist():
    result_true = should_remove_dist()
    assert result_true is True, "function should_remove_dist should return True if config remove_dist is set to true"

    config.set("remove_dist", False)
    result_false = should_remove_dist()
    assert result_false is False, "function should_remove_dist should return False if config remove_dist is set to False"

    config.set("remove_dist", True)
    result_false_no_build = should_remove_dist()
    assert result_false_no_build is False, "function should_remove_dist should return False if config remove_dist is set to True and build_command is set to false"

# Generated at 2022-06-12 06:41:28.272171
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "echo hi"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-12 06:41:29.407479
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:41:30.221734
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-12 06:41:31.488134
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:41:39.952155
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("build_command", "test_build")
    assert should_remove_dist()
    config.set("upload_to_pypi", False)
    assert not should_remove_dist()
    config.set("upload_to_release", True)
    assert should_remove_dist()
    config.set("build_command", "false")
    assert not should_remove_dist()
    config.set("build_command", "test_build")
    assert should_remove_dist()

# Generated at 2022-06-12 06:41:41.198426
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:41:48.970725
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "echo test")
    assert should_build() is True

    config.set("build_command", False)
    assert should_build() is False

    config.set("build_command", "echo test")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_build() is False

    config.set("upload_to_pypi", True)
    assert should_build() is True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() is True


# Generated at 2022-06-12 06:41:49.846420
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-12 06:41:51.037510
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:41:51.832172
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-12 06:42:05.301073
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:42:15.482160
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    assert should_build()
    config["build_command"] = "false"
    config["upload_to_pypi"] = True
    assert not should_build()
    config["build_command"] = "true"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert not should_build()
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

# Generated at 2022-06-12 06:42:24.153807
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert should_build() == False
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    assert should_build() == True
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_build() == True
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    assert should_build() == True
    config.set("build_command", "false")
    assert should_build() == False
    config.set

# Generated at 2022-06-12 06:42:25.052123
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-12 06:42:34.430499
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "setup.py sdist"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-12 06:42:41.247113
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == False

    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_