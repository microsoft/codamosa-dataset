

# Generated at 2022-06-12 06:34:18.475633
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_remove_dist() is True

# Generated at 2022-06-12 06:34:20.377084
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "python setup.py sdist")
    assert should_build()



# Generated at 2022-06-12 06:34:21.636110
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:34:28.288909
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    result = should_remove_dist()
    assert result is True
    config.set("upload_to_release", False)
    result = should_remove_dist()
    assert result is True
    config.set("upload_to_pypi", False)
    result = should_remove_dist()
    assert result is False
    config.set("upload_to_pypi", True)
    config.set("remove_dist", False)
    result = should_remove_dist()
    assert result is False

# Generated at 2022-06-12 06:34:38.957943
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True

# Generated at 2022-06-12 06:34:40.137106
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-12 06:34:49.296693
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")

    assert should_build() == False

    config.set("upload_to_release", "true")
    assert should_build() == True

    config.set("upload_to_release", "false")
    config.set("upload_to_pypi", "true")
    assert should_build() == True

    config.set("upload_to_release", "true")
    config.set("upload_to_pypi", "true")
    assert should_build() == True

# Generated at 2022-06-12 06:34:57.950560
# Unit test for function should_build
def test_should_build():
    for build_command in ["false", False, None]:
        for upload_pypi in [False, "false"]:
            for upload_release in [False, "false"]:
                assert not should_build(build_command, upload_pypi, upload_release)

    for build_command in ["true", True, "python setup.py sdist"]:
        for upload_pypi in [True, "true"]:
            for upload_release in [True, "true"]:
                assert should_build(build_command, upload_pypi, upload_release)

# Generated at 2022-06-12 06:35:03.638222
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "False"
    assert not should_remove_dist()

    config["build_command"] = "echo"
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()

# Generated at 2022-06-12 06:35:08.779926
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

    config.set({"remove_dist": True})
    assert should_remove_dist() == True

    config.set({"build_command": False})
    assert should_remove_dist() == False


# Generated at 2022-06-12 06:36:52.454393
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_build() is True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist"


# Generated at 2022-06-12 06:36:56.335769
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = False
    assert not should_build()


# Generated at 2022-06-12 06:36:57.564418
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-12 06:37:08.289751
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False

    config['build_command'] = 'false'
    assert should_build() == False
    assert should_remove_dist() == False

    config['build_command'] = 'python setup.py bdist_wheel'
    assert should_build() == False
    assert should_remove_dist() == False

    config['upload_to_pypi'] = True
    assert should_build() == False
    assert should_remove_dist() == False

    config['upload_to_release'] = True
    assert should_build() == True
    assert should_remove_dist() == False

    config['remove_dist'] = 'true'
    assert should_build() == True
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:37:13.815811
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = True
    assert should_remove_dist() is False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "test"
    assert should_remove_dist() is True



# Generated at 2022-06-12 06:37:15.118303
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:37:19.857934
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = False
    config['upload_to_pypi'] = True
    config['upload_to_release'] = True
    assert should_remove_dist() == False
    config['remove_dist'] = True
    config['upload_to_pypi'] = False
    assert should_remove_dist() == False
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:37:21.173214
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()


# Generated at 2022-06-12 06:37:22.241455
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-12 06:37:24.835301
# Unit test for function should_build
def test_should_build():
    pypi = "false"
    release = "false"
    build_command = "false"
    assert not should_build()
    pypi = "true"
    assert should_build()
    pypi = "false"
    release = "true"
    assert should_build()
    release = "false"
    build_command = "true"
    assert should_build()


# Generated at 2022-06-12 06:40:37.221671
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-12 06:40:38.100900
# Unit test for function should_build
def test_should_build():
    assert should_build() is False



# Generated at 2022-06-12 06:40:47.459095
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "mkdir"
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["upload_to_pypi"] = False
    assert should_build() is True
    config["upload_to_release"] = False
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is False
    config["upload_to_release"] = True
    config["build_command"] = "mkdir"
    assert should_build() is True
    return



# Generated at 2022-06-12 06:40:48.701237
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-12 06:40:50.739250
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "should_remove_dist()  should be False"



# Generated at 2022-06-12 06:40:58.483813
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # config.get("remove_dist") = True, config.get("build_command") = True.
    # config.get("upload_to_pypi") = True
    # config.get("upload_to_release") = True
    assert should_remove_dist()

    # config.get("remove_dist") = True, config.get("build_command") = False.
    config.set("build_command", "false")
    assert should_remove_dist() is False

    # config.get("remove_dist") = False, config.get("build_command") = True.
    config.set("build_command", "sphinx")
    config.set("remove_dist", "false")
    assert should_remove_dist() is False

    # config.get("remove_dist") = False, config.get("build_command

# Generated at 2022-06-12 06:41:07.200753
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build()
    config["build_command"] = False
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = True
    assert should_build()

# Generated at 2022-06-12 06:41:16.365236
# Unit test for function should_build
def test_should_build():
    """Unit test for function should_build
    """
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_build()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build(), "Both are true"

    config.set("build_command", "false")
    assert not should_build(), "build command is false"


# Generated at 2022-06-12 06:41:18.223087
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN we have a config.ini file
    assert should_remove_dist() is False

# Generated at 2022-06-12 06:41:19.861832
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

