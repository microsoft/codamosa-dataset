

# Generated at 2022-06-12 06:34:51.783670
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dist_dir = "dist"
    assert not should_remove_dist()  # should not remove if no settings
    config.set("remove_dist", dist_dir)
    assert should_remove_dist()  # should remove if set
    config.set("build_command", "echo 'echo'")
    assert should_remove_dist()  # should remove if command set
    config.set("upload_to_pypi", True)
    assert should_remove_dist()  # should remove if pypi upload set
    config.set("upload_to_release", True)
    assert should_remove_dist()  # should remove if release upload set

# Generated at 2022-06-12 06:34:59.338113
# Unit test for function should_build
def test_should_build():
    # prepare the setup default
    config.setup_defaults()
    assert(should_build() == False)
    config.set("upload_to_pypi", True)
    assert(should_build() == False)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert(should_build() == False)
    config.set("build_command", "setup.py -sdist")
    assert(should_build() == True)

# Generated at 2022-06-12 06:35:07.041733
# Unit test for function should_build
def test_should_build():
    # Build and upload to PyPI
    config["upload_to_pypi"] = True
    config["build_command"] = "echo"
    assert should_build() == True

    # Build and upload only to release branch
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_build() == True

    # Build but do not upload
    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    config["build_command"] = "echo"
    assert should_build() == True

    # Do not build but upload
    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    config["build_command"] = "false"
    assert should_build() == False


#

# Generated at 2022-06-12 06:35:16.835262
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    assert should_build() is False
    config["upload_to_release"] = "true"
    assert should_build() is True
    config["upload_to_release"] = "false"
    assert should_build() is False
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "true"
    assert should_build() is False
    config["build_command"] = "pipenv run python setup.py sdist"
    assert should_build() is True


# Generated at 2022-06-12 06:35:19.609949
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "blah"
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist()



# Generated at 2022-06-12 06:35:26.263583
# Unit test for function should_remove_dist
def test_should_remove_dist():
    with open("temp_config.yaml", "w") as temp_config:
        temp_config.write("upload_to_pypi: true")
    with open("temp_config.yaml") as temp_config:
        config.read_dict(dict(temp_config))
    assert should_remove_dist()
    config.clear()
    config.read("temp_config.yaml")

test_should_remove_dist()

# Generated at 2022-06-12 06:35:30.220590
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_remove_dist() is True
    assert should_build() is True
    assert should_remove_dist() is True

# Generated at 2022-06-12 06:35:37.459425
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "true")
    config.set("build_command", "true")
    assert should_build() is True
    config.set("upload_to_pypi", "false")
    assert should_build() is False
    config.set("upload_to_pypi", "true")
    config.set("build_command", "false")
    assert should_build() is False
    config.set("build_command", "true")
    assert should_build() is True
    config.set("build_command", "false")
    config.set("upload_to_release", "true")
    assert should_build() is True
    config.set("build_command", "true")
    assert should_build() is True
    config.set("upload_to_release", "false")

# Generated at 2022-06-12 06:35:44.204253
# Unit test for function should_build
def test_should_build():
    # Should return True
    config["upload_to_pypi"] = "true"
    config["build_command"] = "true"
    assert should_build()

    # Should return False
    config["upload_to_pypi"] = "false"
    config["build_command"] = "true"
    assert not should_build()

    # Should return False
    config["upload_to_pypi"] = "true"
    config["build_command"] = "false"
    assert not should_build()

    # Should return False
    config["upload_to_pypi"] = "false"
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-12 06:35:53.537277
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": True,
                   "upload_to_release": True,
                   "build_command": "build",
                   "remove_dist": True})
    assert should_build()
    config.update({"upload_to_pypi": False,
                   "upload_to_release": False,
                   "build_command": "build"})
    assert not should_build()
    config.update({"upload_to_pypi": False,
                   "upload_to_release": False,
                   "build_command": "false"})
    assert not should_build()


# Generated at 2022-06-12 06:39:59.690484
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = True
    assert should_build() == True

# Generated at 2022-06-12 06:40:00.687072
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-12 06:40:01.856087
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-12 06:40:11.400850
# Unit test for function should_build
def test_should_build():
    # Arrange
    config.set('upload_to_pypi', False)
    config.set('upload_to_release', False)
    config.set('build_command', False)
    # Assert
    assert should_build() == False
    # Arrange
    config.set('upload_to_pypi', True)
    config.set('upload_to_release', False)
    config.set('build_command', True)
    # Assert
    assert should_build() == True
    # Arrange
    config.set('upload_to_pypi', True)
    config.set('upload_to_release', True)
    config.set('build_command', True)
    # Assert
    assert should_build() == True
    print("test_should_build passed.")

# Generated at 2022-06-12 06:40:16.533084
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist('abcdef') == True
    assert should_remove_dist('') == True


# Generated at 2022-06-12 06:40:17.501962
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-12 06:40:18.755122
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-12 06:40:19.605281
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:40:27.807498
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "true"
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["build_command"] = "false"
    config["remove_dist"] = "true"
    assert not should_remove_dist()
    config["build_command"] = "true"
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "false"
    config["remove_dist"] = "false"
    assert not should_remove_dist()



# Generated at 2022-06-12 06:40:28.391177
# Unit test for function should_build
def test_should_build():
    assert should_build()