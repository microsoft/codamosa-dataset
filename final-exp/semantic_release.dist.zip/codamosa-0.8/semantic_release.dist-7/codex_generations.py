

# Generated at 2022-06-12 06:34:33.231600
# Unit test for function should_build
def test_should_build():
    assert not should_build()

# Generated at 2022-06-12 06:34:38.990204
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_remove_dist = {"upload_to_pypi": True, "upload_to_release": True, "remove_dist": True}
    config_no_remove_dist = {"upload_to_pypi": True, "upload_to_release": True, "remove_dist": False}

    assert should_remove_dist(config_remove_dist) == True
    assert should_remove_dist(config_no_remove_dist) == False



# Generated at 2022-06-12 06:34:45.481378
# Unit test for function should_build
def test_should_build():
    assert should_build()
    config.update(build_command="false")
    assert not should_build()
    config.update(upload_to_pypi=False)
    assert not should_build()
    config.update(upload_to_release=False)
    assert not should_build()
    config.update(build_command="true")
    assert not should_build()



# Generated at 2022-06-12 06:34:53.877068
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_build() == False

    config["build_command"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_build() == True

    config["build_command"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build() == True

    config["build_command"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_

# Generated at 2022-06-12 06:34:57.673224
# Unit test for function should_build
def test_should_build():
    # Test empty config
    config.clear()
    assert should_build() == False

    # Test upload to release only
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == False


# Generated at 2022-06-12 06:35:05.914177
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import SETTINGS_DICT
    SETTINGS_DICT.update(remove_dist="true",
                         upload_to_pypi="true",
                         build_command="false",
                         upload_to_release="false")
    assert should_remove_dist() is False
    SETTINGS_DICT.update(remove_dist="false",
                         upload_to_pypi="true",
                         build_command="true",
                         upload_to_release="false")
    assert should_remove_dist() is False
    SETTINGS_DICT.update(remove_dist="true",
                         upload_to_pypi="false",
                         build_command="true",
                         upload_to_release="true")
    assert should_remove_dist() is True


# Generated at 2022-06-12 06:35:07.222651
# Unit test for function should_remove_dist
def test_should_remove_dist():
    command = "clean"
    config["remove_dist"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-12 06:35:07.934524
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-12 06:35:14.647624
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert should_build() is False

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "true")
    assert should_build() is True



# Generated at 2022-06-12 06:35:17.181447
# Unit test for function should_remove_dist
def test_should_remove_dist():
    should_remove_dist_bool = should_remove_dist()
    assert should_remove_dist_bool == False
# test_should_remove_dist()

# Generated at 2022-06-12 06:38:56.647846
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-12 06:38:57.505665
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-12 06:39:07.943302
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "true")
    config.set("build_command", "false")
    assert not should_remove_dist()

    config.set("upload_to_pypi", "true")
    config.set("build_command", "true")
    assert should_remove_dist()

    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "false")
    assert not should_remove_dist()

    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "true")
    assert should_remove_dist

# Generated at 2022-06-12 06:39:11.212057
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config.set("upload_to_pypi", True)
    config.set("build_command", "test")

    assert should_build()



# Generated at 2022-06-12 06:39:12.804787
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-12 06:39:22.914955
# Unit test for function should_build
def test_should_build():
    test = {"build_command": "true", "upload_to_pypi": "true", "upload_to_release": "true"}
    config.update(test)
    assert should_build()

    test = {"build_command": "true", "upload_to_pypi": "false", "upload_to_release": "true"}
    config.update(test)
    assert should_build()

    test = {"build_command": "true", "upload_to_pypi": "false", "upload_to_release": "false"}
    config.update(test)
    assert should_build()

    test = {"build_command": "false", "upload_to_pypi": "true", "upload_to_release": "true"}
    config.update(test)
    assert not should_build()

    test

# Generated at 2022-06-12 06:39:25.795388
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["build_command"] = ["ls"]
    assert should_remove_dist()
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-12 06:39:37.728959
# Unit test for function should_build
def test_should_build():
    """Test should_build function
    """
    # Config has "build_command"
    config["build_command"] = "command"
    # Config doesn't have upload_to_pypi or upload_to_release
    assert should_build() == False
    # Config has upload_to_pypi
    config["upload_to_pypi"] = True
    assert should_build() == True
    # Config has upload_to_release
    config["upload_to_release"] = True
    assert should_build() == True
    # Config has upload_to_release and upload_to_pypi
    config["upload_to_pypi"] = False
    assert should_build() == True
    # Config has upload_to_release, upload_to_pypi and build_command

# Generated at 2022-06-12 06:39:41.476731
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist() is True
    #
    config["remove_dist"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-12 06:39:42.752152
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
