

# Generated at 2022-06-12 06:34:48.895974
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'foo'"
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_build() is False


# Generated at 2022-06-12 06:34:53.877580
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = ""
    assert not should_remove_dist()
    config["build_command"] = "command"
    assert should_remove_dist()



# Generated at 2022-06-12 06:34:54.837317
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-12 06:34:57.534052
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist())
    config["remove_dist"] = False
    assert(not should_remove_dist())
    config["remove_dist"] = True

# Generated at 2022-06-12 06:35:05.828306
# Unit test for function should_build
def test_should_build():
    examples = [
        {"actions": {"upload_to_release": True}, "result": False},
        {"actions": {"upload_to_release": True, "build_command": "echo"}, "result": True},
        {"actions": {"upload_to_pypi": True, "build_command": False}, "result": False},
        {"actions": {"upload_to_pypi": True}, "result": True},
        {"actions": {"upload_to_pypi": True, "build_command": "echo"}, "result": True},
        {"actions": {}, "result": False},
    ]
    for example in examples:
        result = should_build(**example["actions"])
        assert result == example["result"], "Test {} failed!".format(example)

