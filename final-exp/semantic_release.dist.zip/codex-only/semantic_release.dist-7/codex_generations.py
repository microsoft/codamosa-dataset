

# Generated at 2022-06-24 01:29:15.947117
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'worked'"
    build_dists(command)
    assert True
    command = "echo 'did not work'"
    build_dists(command)
    assert False


# Generated at 2022-06-24 01:29:16.974837
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:18.411396
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:29:19.499569
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-24 01:29:26.576679
# Unit test for function build_dists
def test_build_dists():
    logging.basicConfig(level=logging.DEBUG)
    config.set("build_command", "echo 'build_command'")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    build_dists()
    assert should_build()
    assert not should_remove_dist()
    config.set("remove_dist", True)
    assert should_remove_dist()
    remove_dists("test")

# Generated at 2022-06-24 01:29:37.459172
# Unit test for function should_build
def test_should_build():
    cmd = 'sphinx-build docs/ docs/_build'
    assert should_build() is False
    config.update(dict(build_command=cmd))
    assert should_build() is True
    config.update(dict(upload_to_pypi=True))
    assert should_build() is True
    config.update(dict(upload_to_release=True))
    assert should_build() is True
    config.update(dict(upload_to_pypi=False))
    assert should_build() is True
    config.update(dict(upload_to_release=False))
    assert should_build() is False
    config.update(dict(upload_to_pypi=True))
    assert should_build() is True
    config.update(dict(build_command=False))
    assert should_build()

# Generated at 2022-06-24 01:29:42.014783
# Unit test for function should_remove_dist
def test_should_remove_dist():
    fn = should_remove_dist

    assert not fn()

    class ConfigDummy:
        pass
    dummy_config = ConfigDummy()
    dummy_config.remove_dist = "false"
    dummy_config.upload_to_pypi = True
    dummy_config.build_command = "python setup.py sdist bdist_wheel"

    assert not fn()

# Generated at 2022-06-24 01:29:42.862860
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('/tmp/test')

# Generated at 2022-06-24 01:29:44.254655
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    config["build_command"] = "echo 'Hello world'"
    build_dists()


# Generated at 2022-06-24 01:29:50.930676
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf build"
    logger.debug(f"Running {command}")
    run(command)

    command = f"rm -rf dist/"
    logger.debug(f"Running {command}")
    run(command)

    command = f"rm -rf *.egg-info"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:29:51.597156
# Unit test for function build_dists
def test_build_dists():
    # -
    assert build_dists

# Generated at 2022-06-24 01:29:52.706951
# Unit test for function should_remove_dist
def test_should_remove_dist():
    should_remove_dist()
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:29:57.415470
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:29:57.903751
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:58.520730
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:01.015612
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir -p /tmp/test")
    remove_dists("/tmp/test")
    run("test -d /tmp/test")



# Generated at 2022-06-24 01:30:03.747462
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")

# Generated at 2022-06-24 01:30:05.475347
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:30:08.427786
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() is None

# Generated at 2022-06-24 01:30:09.904527
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:30:13.292412
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "echo"
    assert not should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build()


# Generated at 2022-06-24 01:30:22.808576
# Unit test for function remove_dists
def test_remove_dists():
    import shutil
    import tempfile
    import fmflow as fm

    root = tempfile.mkdtemp(prefix="fmflow_distributions-test_remove_dists")
    path = root + "/test.tmp"
    logger.debug(f"test: path={path}")

    fm.utils.touch(path)
    assert fm.utils.exists(path)

    remove_dists(path)
    assert not fm.utils.exists(path)

    shutil.rmtree(root)
    assert not fm.utils.exists(root)


# Generated at 2022-06-24 01:30:29.331637
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["build_command"] = "make build"

    # WHEN
    result = should_remove_dist()

    # THEN
    assert result



# Generated at 2022-06-24 01:30:32.466848
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:30:33.664902
# Unit test for function build_dists
def test_build_dists():
    assert callable(build_dists)

# Generated at 2022-06-24 01:30:37.711015
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:30:43.907692
# Unit test for function should_build
def test_should_build():
    # default build_command is false
    config['build_command'] = False
    assert not should_build()
    # test upload_to_pypi
    config['upload_to_pypi'] = True
    assert should_build()
    config['upload_to_pypi'] = False
    # test build_command
    config['build_command'] = "build"
    assert should_build()
    config['build_command'] = False
    # test upload_to_release
    config['upload_to_release'] = True
    assert should_build()

# Generated at 2022-06-24 01:30:48.398230
# Unit test for function remove_dists
def test_remove_dists():
    # Create the directory to be removed
    import os
    from .settings import config
    from .utils import create_dir
    from .utils import delete_dir

    path = config.get("remove_dist")
    create_dir(path)

    remove_dists(path)

    assert os.path.exists(path) == False

# Generated at 2022-06-24 01:30:51.796692
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.get["remove_dist"] = True
    config.get["upload_to_pypi"] = True
    config.get["build_command"] = "poop"
    assert should_remove_dist()

# Generated at 2022-06-24 01:30:52.685484
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:31:01.930523
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "echo 'build'"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-24 01:31:02.768739
# Unit test for function should_build
def test_should_build():
    assert not should_build()

# Generated at 2022-06-24 01:31:14.441160
# Unit test for function should_build
def test_should_build():
    c1 = {"build_command": False, "upload_to_pypi": False, "upload_to_release": False}
    assert not should_build(c1)

    c2 = {"build_command": True, "upload_to_pypi": False, "upload_to_release": False}
    assert not should_build(c2)

    c3 = {"build_command": True, "upload_to_pypi": True, "upload_to_release": False}
    assert should_build(c3)

    c4 = {"build_command": True, "upload_to_pypi": False, "upload_to_release": True}
    assert should_build(c4)


# Generated at 2022-06-24 01:31:15.942102
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:31:16.821145
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:31:20.653080
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "python setup.py sdist")
    assert should_build() == True



# Generated at 2022-06-24 01:31:25.234384
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    config["upload_to_pypi"] = "false"
    assert should_build() == False
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build() == False
    config["upload_to_release"] = "true"
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-24 01:31:26.582500
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import dist_path
    remove_dists(dist_path)

# Generated at 2022-06-24 01:31:30.510847
# Unit test for function remove_dists
def test_remove_dists():
    """
    Test function remove_dists

    Test if function remove_dists return the correct command
    """
    import tempfile
    path = tempfile.mkdtemp()
    command = f"rm -rf {path}"
    assert command == remove_dists(path)

# Generated at 2022-06-24 01:31:35.792322
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.override(dict(remove_dist=True, upload_to_release=True))
    assert should_remove_dist()
    config.override(dict(remove_dist=False, upload_to_release=True))
    assert not should_remove_dist()
    config.override(dict(remove_dist=False, upload_to_release=False))
    assert not should_remove_dist()

    config.override(dict(remove_dist=True, upload_to_release=False))
    assert not should_remove_dist()

# Generated at 2022-06-24 01:31:37.533433
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")
    remove_dists("./*")


# Generated at 2022-06-24 01:31:39.566786
# Unit test for function build_dists
def test_build_dists():
    test_func = build_dists()
    assert test_func is None, "build_dists does not return expected value"

# Generated at 2022-06-24 01:31:40.385891
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:31:43.605260
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "build")
    config.set("upload_to_pypi", False)
    assert should_build()

    config.set("upload_to_pypi", True)
    assert should_build()

    config.set("build_command", "false")
    assert not should_build()

    config.set("upload_to_release", True)
    assert not should_build()

    config.set("build_command", "false")
    config.set("upload_to_pypi", False)
    assert not should_build()

# Generated at 2022-06-24 01:31:44.802773
# Unit test for function remove_dists
def test_remove_dists():
    pass
    # remove_dists("dist")



# Generated at 2022-06-24 01:31:45.321625
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:31:55.795121
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

    # False
    config["remove_dist"] = "false"
    assert should_remove_dist() is False

    # False - build_command is False
    config["build_command"] = "false"
    assert should_remove_dist() is False

    # False - upload_to_pypi is False
    config["upload_to_pypi"] = "false"
    assert should_remove_dist() is False

    # False - upload_to_release is False
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist() is False

    config["upload_to_release"] = "true"
    config["build_command"] = "true"

# Generated at 2022-06-24 01:31:58.058703
# Unit test for function remove_dists
def test_remove_dists():
    command = "pwd"
    run(command)
    logger.debug(f"Running {command}")

# Generated at 2022-06-24 01:31:58.992174
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/build")

# Generated at 2022-06-24 01:32:00.359636
# Unit test for function build_dists
def test_build_dists():
    command = config.get("build_command")
    run(command)



# Generated at 2022-06-24 01:32:02.406829
# Unit test for function build_dists
def test_build_dists():
    command = config.get("build_command")
    assert command != "false"
    assert should_build()
    build_dists()

# Generated at 2022-06-24 01:32:04.385737
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True



# Generated at 2022-06-24 01:32:06.699626
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "Remove dist should be false"



# Generated at 2022-06-24 01:32:14.537235
# Unit test for function should_build
def test_should_build():
    config.update(upload_to_pypi=True, build_command="true")
    assert should_build()
    config.update(upload_to_release=True, build_command="false")
    assert not should_build()
    config.update(upload_to_pypi=False, upload_to_release=False)
    assert not should_build()
    config.update(upload_to_pypi=True, build_command="false")
    assert not should_build()

# Generated at 2022-06-24 01:32:15.630735
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')

# Generated at 2022-06-24 01:32:17.712314
# Unit test for function should_build
def test_should_build():
    from .utils import load_config
    config = load_config()
    assert should_build() == True
    config["remove_dist"] = "False"
    assert should_build() == False


# Generated at 2022-06-24 01:32:18.402056
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./nadratrader")

# Generated at 2022-06-24 01:32:18.893272
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:21.586271
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:32:31.248482
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "test")

    # Build if upload_to_pypi is true
    config.set("upload_to_release", False)
    assert should_build()

    # Build if upload_to_release is true
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()

    # Build if both upload_to_pypi and upload_to_release are true
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build()

    # Do not build if both upload_to_pypi

# Generated at 2022-06-24 01:32:31.812837
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:32:32.386598
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:34.084009
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "test"
    assert should_build()


# Generated at 2022-06-24 01:32:45.007430
# Unit test for function remove_dists
def test_remove_dists():

    from .settings import Settings

    config = Settings(remove_dist=True, build_command="false")
    should_remove = should_remove_dist()
    assert should_remove is True

    config = Settings(upload_to_release=True, build_command="echo hello")
    should_remove = should_remove_dist()
    assert should_remove is True

    config = Settings(upload_to_release=False, upload_to_pypi=False)
    should_remove = should_remove_dist()
    assert should_remove is False

    config = Settings(upload_to_release=False, upload_to_pypi=True)
    should_remove = should_remove_dist()
    assert should_remove is True


# Generated at 2022-06-24 01:32:56.708351
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": False, "upload_to_release": False, "build_command": False})
    assert not should_build()

    config.update({"upload_to_pypi": False, "upload_to_release": True, "build_command": True})
    assert should_build()

    config.update({"upload_to_pypi": True, "upload_to_release": False, "build_command": True})
    assert should_build()

    config.update({"upload_to_pypi": True, "upload_to_release": True, "build_command": False})
    assert not should_build()

    config.update({"upload_to_pypi": False, "upload_to_release": True, "build_command": False})
    assert not should

# Generated at 2022-06-24 01:33:06.562033
# Unit test for function remove_dists
def test_remove_dists():
    from .context import Config
    from .settings import load_config
    from .os_utils import get_current_dir

    test_filename = "test-config.yml"
    config = Config(
        package_name="",
        package_version="",
        github_version="",
        current_dir=get_current_dir(),
        config_file_name=test_filename,
        uploaded_package_filename="",
        build_command="",
        upload_to_pypi=False,
        upload_to_release=False,
        remove_dist=False
    )
    load_config(config)
    config.current_dir.joinpath(test_filename).touch()
    assert config.current_dir.joinpath(test_filename).exists()

# Generated at 2022-06-24 01:33:09.307311
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"build_command": "build", "remove_dist": True})
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:10.525123
# Unit test for function build_dists
def test_build_dists():
    assert get_build_command() == 'python3 setup.py sdist bdist_wheel'

# Generated at 2022-06-24 01:33:14.165012
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:33:16.453752
# Unit test for function remove_dists
def test_remove_dists():
    logger.info("testing remove_dists function")
    remove_dists("*")
    command = "ls -a"
    result = run(command).stdout
    assert "dist" not in result



# Generated at 2022-06-24 01:33:17.714163
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:33:24.297161
# Unit test for function should_build
def test_should_build():
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    config['build_command'] = False
    assert not should_build()

    config['upload_to_pypi'] = True
    assert not should_build()

    config['build_command'] = True
    assert should_build()

    config['upload_to_pypi'] = False
    assert should_build()

# Generated at 2022-06-24 01:33:25.854339
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:33:35.215218
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()

    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["build_command"] = "false"

# Generated at 2022-06-24 01:33:37.597252
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('/tmp/to_be_removed')
    run('test -f /tmp/to_be_removed', pty=False, warn=True)



# Generated at 2022-06-24 01:33:38.260541
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:46.421587
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "flask --version"
    config["upload_to_pypi"] = True
    config["remove_dist"] = "true"

    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert not should_remove_dist()



# Generated at 2022-06-24 01:33:51.359853
# Unit test for function remove_dists
def test_remove_dists():
    # remove_dists("/tmp/repo_files")
    pass


if __name__ == '__main__':
    test_remove_dists()

# Generated at 2022-06-24 01:33:52.785768
# Unit test for function build_dists
def test_build_dists():
    logger.debug("Testing build_dists()")
    build_dists()

# Generated at 2022-06-24 01:33:55.279103
# Unit test for function remove_dists
def test_remove_dists():
    pass


# Generated at 2022-06-24 01:33:57.886726
# Unit test for function should_build
def test_should_build():
    config = {"upload_to_pypi": 1, "upload_to_release": None, "build_command": "true"}
    assert should_build() == True



# Generated at 2022-06-24 01:33:59.628492
# Unit test for function build_dists
def test_build_dists():
    command = "echo Hello world"
    config["build_command"] = command
    build_dists()



# Generated at 2022-06-24 01:34:01.329165
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:34:06.442470
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "true"
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert not should_remove_dist()
    config["build_command"] = "true"
    assert should_remove_dist()



# Generated at 2022-06-24 01:34:08.995958
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist bdist_wheel"
    logger.info(f"Running {command}")
    run(command)



# Generated at 2022-06-24 01:34:12.792959
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:15.425521
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist({"remove_dist": False, "build_command": "true"})
    assert should_remove_dist({"remove_dist": True, "build_command": "true"})

# Generated at 2022-06-24 01:34:18.473835
# Unit test for function build_dists
def test_build_dists():
    built_dists = build_dists()
    assert built_dists is not None

# Generated at 2022-06-24 01:34:20.059818
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:34:22.091615
# Unit test for function should_build
def test_should_build():
    assert should_build() == False, 'should_build() == false'
    assert should_build() == True, 'should_build() == True'

# Generated at 2022-06-24 01:34:25.535580
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:26.084583
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:34:27.232535
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/delete")
    assert True

# Generated at 2022-06-24 01:34:30.140081
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:34:32.298349
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    res = should_build()
    assert not res



# Generated at 2022-06-24 01:34:33.103002
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:34:37.568707
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = ""
    config["remove_dist"] = False
    assert not should_remove_dist(), "Should return False"

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    config["remove_dist"] = True
    assert should_remove_dist(), "Should return True"

# Generated at 2022-06-24 01:34:39.792998
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    exit()

# Generated at 2022-06-24 01:34:44.226361
# Unit test for function should_build
def test_should_build():
    assert should_build()
    assert not should_build({'upload_to_pypi': False})
    assert not should_build({'upload_to_release': False})
    assert not should_build({'build_command': False})
    assert not should_build({'build_command': 'false'})

# Generated at 2022-06-24 01:34:47.015465
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert (should_remove_dist() is True)

# Generated at 2022-06-24 01:34:53.988673
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.config = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "false",
        "remove_dist": True,
    }
    assert should_remove_dist() is False
    config.config = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "sphinx-build",
        "remove_dist": False,
    }
    assert should_remove_dist() is False
    config.config = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "sphinx-build",
        "remove_dist": True,
    }
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:34:59.774444
# Unit test for function should_build
def test_should_build():
    # upload_pypi = config.get("upload_to_pypi")
    # upload_release = config.get("upload_to_release")
    # build_command = config.get("build_command")
    # build_command = build_command if build_command != "false" else False
    # return bool(build_command and (upload_pypi or upload_release))
    assert should_build()


# Generated at 2022-06-24 01:35:01.039047
# Unit test for function remove_dists
def test_remove_dists():
    assert(remove_dists(path="./*") != False)



# Generated at 2022-06-24 01:35:04.003991
# Unit test for function should_build
def test_should_build():
    """Should build if config.upload_to_pypi is True
    """
    config.upload_to_pypi = "True"
    assert should_build()

# Generated at 2022-06-24 01:35:04.878000
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    return True

# Generated at 2022-06-24 01:35:07.256820
# Unit test for function remove_dists
def test_remove_dists():
    from . import utils
    utils.create_file("test_dist", "test_dist")
    remove_dists("test_dist")
    assert not utils.file_exists("test_dist")

# Generated at 2022-06-24 01:35:15.871133
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["build_command"] = "build_command"
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-24 01:35:17.609406
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:26.199449
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "false")
    assert not should_remove_dist()

    config.set("remove_dist", "true")
    assert should_remove_dist()

    config.set("upload_to_pypi", "false")
    assert not should_remove_dist()

    config.set("upload_to_release", "false")
    assert not should_remove_dist()

    config.set("upload_to_pypi", "true")
    assert should_remove_dist()

    config.set("upload_to_release", "true")
    assert should_remove_dist()



# Generated at 2022-06-24 01:35:27.173949
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:35:33.862405
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    assert not should_remove_dist()
    config["remove_dist"] = False
    config["upload_to_release"] = True
    assert not should_remove_dist()



# Generated at 2022-06-24 01:35:45.784347
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "false")
    assert should_build() is False
    config.set("upload_to_pypi", "true")
    config.set("build_command", "true")
    assert should_build() is True
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert should_build() is False
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    assert should_build() is True
    config.set("upload_to_pypi", "false")
    config.set("build_command", "false")
    assert should_build() is False

# Generated at 2022-06-24 01:35:54.007728
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from . import settings
    import tempfile
    config_file = tempfile.mkstemp()[1]
    with open(config_file, "w") as f:
        f.write(
            """
            [build]
            build_command = true
            remove_dist = true
            upload_to_pypi = true
            upload_to_release = false
            """)
    settings.load_config_from_file(config_file)
    assert should_remove_dist()
    settings.load_config_from_file(config_file)

# Generated at 2022-06-24 01:35:57.292623
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")

# Generated at 2022-06-24 01:35:58.548093
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:36:05.542624
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "build"
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:06.510067
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert False == should_remove_dist()

# Generated at 2022-06-24 01:36:07.607119
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf "
    return command

# Generated at 2022-06-24 01:36:16.973854
# Unit test for function should_build
def test_should_build():
    assert should_build() is False, "should_build() should return False"

    config.set("upload_to_release", True)
    assert should_build() is False, "should_build() should return False"

    config.set("build_command", "false")
    assert should_build() is False, "should_build() should return False"

    config.set("build_command", "some_command")
    config.set("upload_to_pypi", True)
    assert should_build() is True, "should_build() should return True"

# Generated at 2022-06-24 01:36:18.262435
# Unit test for function remove_dists
def test_remove_dists():
    path = "/tmp"
    remove_dists(path)

# Generated at 2022-06-24 01:36:25.307074
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

    config["build_command"] = "false"
    assert should_build() == False

    config["build_command"] = "python setup.py bist_wheel"
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False


# Generated at 2022-06-24 01:36:28.566820
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:35.313387
# Unit test for function should_build
def test_should_build():
    config.override("build_command", "false")
    assert should_build() is False

    config.override("build_command", "echo Hello World")
    config.override("upload_to_pypi", "false")
    config.override("upload_to_release", "false")
    assert should_build() is False

    config.override("upload_to_release", "false")
    assert should_build() is True

    config.override("upload_to_release", "true")
    config.override("upload_to_pypi", "false")
    assert should_build() is True

    config.override("upload_to_release", "false")
    config.override("upload_to_pypi", "true")
    assert should_build() is True


# Generated at 2022-06-24 01:36:36.098062
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:36:38.571437
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir temp")
    remove_dists("temp")
    run("ls").stdout.strip() == ""

# Generated at 2022-06-24 01:36:39.916122
# Unit test for function remove_dists
def test_remove_dists():
    assert isinstance(remove_dists("test"), None)


# Generated at 2022-06-24 01:36:40.950593
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    assert should_build() == False

# Generated at 2022-06-24 01:36:43.392471
# Unit test for function build_dists
def test_build_dists():
    from .config import config as test_config
    test_config["build_command"] = "mkdir test"
    build_dists()
    run("rm -rf test")



# Generated at 2022-06-24 01:36:49.825747
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config["build_command"] = "echo 'asdf'"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

    config["upload_to_pypi"] = True
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True

# Generated at 2022-06-24 01:36:50.200243
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:36:56.766508
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    import os.path as path
    temp_dir = tempfile.mkdtemp()
    os.makedirs(path.join(temp_dir, "build"))
    os.makedirs(path.join(temp_dir, "dist"))
    os.makedirs(path.join(temp_dir, "*.egg-info"))

    remove_dists(temp_dir)
    assert not path.exists(temp_dir)

# Generated at 2022-06-24 01:37:00.137312
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert should_build()



# Generated at 2022-06-24 01:37:07.014086
# Unit test for function should_build
def test_should_build():
    # pylint: disable=redefined-outer-name
    def _should_build(should_build_result, upload_to_pypi, upload_to_release,
                      build_command_result):
        config["upload_to_pypi"] = upload_to_pypi
        config["upload_to_release"] = upload_to_release
        assert should_build() == should_build_result

        if build_command_result != "false":
            assert config.get("build_command") == build_command_result
        else:
            assert config.get("build_command") != "false"

    _should_build(False, None, None, "false")
    _should_build(False, None, None, "true")
    _should_build(False, False, False, "true")
    _should

# Generated at 2022-06-24 01:37:09.594807
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:13.243876
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:37:14.153740
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:37:20.951797
# Unit test for function should_build
def test_should_build():
    config_map = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "true",
        "remove_dist": True,
    }
    config["configuration"].update(config_map)
    result = should_build()
    assert result is True

    config_map = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "true",
        "remove_dist": True,
    }
    config["configuration"].update(config_map)
    result = should_build()
    assert result is True


# Generated at 2022-06-24 01:37:22.211862
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:29.718522
# Unit test for function should_build
def test_should_build():
    config.update({
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "echo build me"
    })
    assert should_build() == True

    config.update({
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "echo build me"
    })
    assert should_build() == False

    config.update({
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "echo build me"
    })
    assert should_build() == True


# Generated at 2022-06-24 01:37:31.546617
# Unit test for function build_dists
def test_build_dists():
    config.update({"build_command": "echo 'Hello world'"})
    build_dists()

# Generated at 2022-06-24 01:37:32.983028
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == bool(config.get("remove_dist"))



# Generated at 2022-06-24 01:37:34.082013
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:37:34.847837
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:37:35.621033
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:37:41.009976
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["build_command"] = "true"
    config["upload_to_release"] = "false"
    assert should_build() == True

    config["upload_to_pypi"] = "false"
    config["build_command"] = "false"
    config["upload_to_release"] = "true"
    assert should_build() == False



# Generated at 2022-06-24 01:37:42.307143
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'change config file'"
    logger.info(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:37:43.400414
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:37:45.330439
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:37:47.353341
# Unit test for function remove_dists
def test_remove_dists():
    """
    Test the remove_dists function
    """
    path = "dist"
    remove_dists(path)

# Generated at 2022-06-24 01:37:52.494386
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "sdist bdist_wheel"
    assert should_build()
    config["remove_dist"] = ""
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:54.969643
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build"
    assert should_build() is True
    config["build_command"] = False
    assert should_build() is False



# Generated at 2022-06-24 01:37:57.839799
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        remove_dists(tmpdirname)
        from os import path
        assert not path.isdir(tmpdirname)

# Generated at 2022-06-24 01:38:08.586590
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "True"
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    assert should_remove_dist() == False
    config["upload_to_release"] = True
    assert should_remove_dist() == False
    config["build_command"] = False
    assert should_remove_dist() == False
    config["build_command"] = "something"
    assert should_remove_dist() == False
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = "false"
    assert should_remove_dist() == False
    config

# Generated at 2022-06-24 01:38:09.739724
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_build() == True

# Generated at 2022-06-24 01:38:18.127619
# Unit test for function should_build
def test_should_build():
    remove_dist = False
    upload_release = True
    upload_pypi = True
    build_command = 'gjoker'
    # should return a false since we are not gonna execute the build
    assert should_build() == False, 'should return a false since we are not gonna execute the build'
    upload_release = False
    # should return a true since execution of build is gonna be executed  
    assert should_build() == True, 'should return a true since execution of build is gonna be executed'



# Generated at 2022-06-24 01:38:23.143923
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "true")

    config.set("remove_dist", "false")
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    assert should_remove_dist() is False

    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    assert should_remove_dist() is True

    config.set("remove_dist", "false")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_remove_dist() is False

    config.set("remove_dist", "true")

# Generated at 2022-06-24 01:38:31.926166
# Unit test for function should_build
def test_should_build():
    config["build_command"] = ""
    assert should_build() == False

    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = False
    assert should_build() == False

    config["upload_to_release"] = False
    assert should_build() == False

    config["upload_to_pypi"] = True
    assert should_build() == True

    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    assert should_build() == True


# Generated at 2022-06-24 01:38:32.815139
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()


# Generated at 2022-06-24 01:38:36.461060
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

    config["build_command"] = False
    assert should_remove_dist() is False

    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() is False

    config["remove_dist"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:38:37.709349
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:42.923325
# Unit test for function remove_dists
def test_remove_dists():
    assert isinstance(remove_dists("/tmp"), None)

# Generated at 2022-06-24 01:38:44.441994
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:38:47.020050
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:38:50.833428
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("build_command", "ls")
    assert should_build()
    config.set("upload_to_pypi", False)
    assert not should_build()
    config.set("build_command", False)
    assert not should_build()

# Generated at 2022-06-24 01:38:51.813712
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:53.314484
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    
    

# Generated at 2022-06-24 01:38:56.005603
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    d = config
    d["build_command"] = "false"
    assert should_build() is False
    d["build_command"] = "echo build command"
    d["upload_to_pypi"] = True
    d["upload_to_release"] = False
    assert should_build() is True


# Generated at 2022-06-24 01:38:56.600966
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists(".")

# Generated at 2022-06-24 01:38:58.298719
# Unit test for function should_remove_dist
def test_should_remove_dist():
    pass



# Generated at 2022-06-24 01:39:01.283021
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    config["build_command"] = "ls -la"

    assert should_remove_dist()



# Generated at 2022-06-24 01:39:04.222981
# Unit test for function should_build
def test_should_build():
    # create config from dict
    config.update({
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "build",
        "remove_dist": True
    })
    # test that should_build returns True
    assert should_build() is True
    # test that remove_dist is True
    assert should_remove_dist() is True
    # test that should_build returns False
    config["upload_to_pypi"] = False
    assert should_build() is False

# Generated at 2022-06-24 01:39:14.230281
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile

    # Create temp folder and subfolders
    # then run remove command

    # Should work
    with tempfile.TemporaryDirectory() as tmpdir:
        sub_folder = os.path.join(tmpdir, "sub")
        os.mkdir(sub_folder)
        assert os.path.exists(tmpdir)
        remove_dists(tmpdir)
        assert not os.path.exists(tmpdir)

    # Should work
    with tempfile.TemporaryDirectory() as tmpdir:
        os.mkdir(tmpdir)
        assert os.path.exists(tmpdir)
        remove_dists(tmpdir)
        assert not os.path.exists(tmpdir)

    # Should fail