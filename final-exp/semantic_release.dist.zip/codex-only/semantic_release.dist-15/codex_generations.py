

# Generated at 2022-06-24 01:29:16.590147
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": "true"})
    assert should_remove_dist()

# Generated at 2022-06-24 01:29:17.396937
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:18.769545
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:20.492564
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/testdir")



# Generated at 2022-06-24 01:29:21.517584
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:29:23.093551
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert should_remove_dist()
    build_dists()

# Generated at 2022-06-24 01:29:31.730650
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "echo")

    assert not should_build()

    config.set("build_command", "false")
    assert not should_build()

    config.set("upload_to_pypi", True)
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()

    config.set("build_command", "true")
    assert should_build()



# Generated at 2022-06-24 01:29:32.574568
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:29:37.150031
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:29:38.420314
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    #assert should_remove_dist() == False

# Generated at 2022-06-24 01:29:44.376913
# Unit test for function should_remove_dist
def test_should_remove_dist():
    def _set_config(upload_to_release, upload_to_pypi, build_command, remove_dist):
        config['upload_to_release'] = upload_to_release
        config['upload_to_pypi'] = upload_to_pypi
        config['build_command'] = build_command
        config['remove_dist'] = remove_dist
    _set_config(True, True, 'echo build', True)
    assert should_remove_dist()
    _set_config(False, True, 'echo build', True)
    assert should_remove_dist()
    _set_config(True, False, 'echo build', True)
    assert should_remove_dist()
    _set_config(False, False, 'echo build', True)
    assert not should_remove_dist()
    _set_

# Generated at 2022-06-24 01:29:55.650351
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should not remove dist if "remove_dist" and "build_command" are not found
    assert False == should_remove_dist()
    # Should not remove dist if "remove_dist" and "build_command" are found
    config.set("build_command", {})
    config.set("remove_dist", {})
    assert False == should_remove_dist()
    # Should remove dist if "remove_dist" and "build_command" are found
    config.set("build_command", {"command": "false"})
    config.set("remove_dist", {})
    assert False == should_remove_dist()
    # Should remove dist if "remove_dist" and "build_command" are found
    config.set("build_command", {"command": "should_build"})
    config.set("remove_dist", {})

# Generated at 2022-06-24 01:30:03.392172
# Unit test for function should_remove_dist
def test_should_remove_dist():
    import os

    upload_pypi = os.environ['UPLOAD_TO_PYPI'] = 'true'
    upload_release = os.environ['UPLOAD_TO_RELEASE'] = 'true'
    build_command = os.environ['BUILD_COMMAND'] = 'echo "Foo"'
    remove_dist = os.environ['REMOVE_DIST'] = 'true'
    assert should_remove_dist()

    upload_pypi = os.environ['UPLOAD_TO_PYPI'] = 'false'
    upload_release = os.environ['UPLOAD_TO_RELEASE'] = 'true'
    build_command = os.environ['BUILD_COMMAND'] = 'echo "Foo"'

# Generated at 2022-06-24 01:30:13.200029
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", False)
    assert should_remove_dist() is False

    config.set("remove_dist", True)
    assert should_remove_dist() is False

    config.set("remove_dist", True)
    config.set("build_command", "sphinx-build -b html source build/html")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_remove_dist() is True

    config.set("remove_dist", True)
    config.set("build_command", "sphinx-build -b html source build/html")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:30:14.888310
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")

# Generated at 2022-06-24 01:30:16.331050
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("~/")

# Generated at 2022-06-24 01:30:18.684281
# Unit test for function build_dists
def test_build_dists():
    command = config.get("build_command")
    assert command == "python setup.py sdist"

# Generated at 2022-06-24 01:30:19.882955
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:30:20.432877
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() is None



# Generated at 2022-06-24 01:30:24.298828
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set({"upload_to_pypi": True})
    assert should_build() == False
    config.set({"upload_to_release": True})
    assert should_build() == False
    config.set({"build_command": "echo"})
    assert should_build() == True

# Generated at 2022-06-24 01:30:35.843898
# Unit test for function should_build
def test_should_build():
    config_t1 = dict(upload_to_pypi=True, build_command="command1")
    assert should_build(config_t1)

    config_t2 = dict(upload_to_release=True, build_command="command1")
    assert should_build(config_t2)

    config_t3 = dict(upload_to_pypi=True, upload_to_release=True, build_command="command1")
    assert should_build(config_t3)

    config_t4 = dict(upload_to_pypi=False, upload_to_release=False, build_command="command1")
    assert not should_build(config_t4)

    config_t5 = dict(upload_to_pypi=True, upload_to_release=False, build_command=False)

# Generated at 2022-06-24 01:30:36.768395
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == should_build()

# Generated at 2022-06-24 01:30:44.535999
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = True
    config["remove_dist"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:45.133399
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:30:45.661809
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:46.966993
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp") == None


# Generated at 2022-06-24 01:30:48.912718
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tests/DUMMY_BUILD_FOLDER")

# Generated at 2022-06-24 01:30:50.061087
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:30:52.052411
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert True == should_remove_dist()



# Generated at 2022-06-24 01:30:52.934424
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:30:56.173905
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:01.582697
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = False
    assert should_remove_dist() == False

    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["build_command"] = "build"

# Generated at 2022-06-24 01:31:02.103364
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:06.471744
# Unit test for function remove_dists
def test_remove_dists():
    assert(should_remove_dist())
    remove_dists(path="./dist")



# Generated at 2022-06-24 01:31:09.320492
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")

# Generated at 2022-06-24 01:31:16.209729
# Unit test for function should_build
def test_should_build():
    options = [
        {"upload_to_pypi": True, "upload_to_release": False, "build_command": "false"},
        {"upload_to_pypi": True, "upload_to_release": True, "build_command": "ls"},
        {"upload_to_pypi": False, "upload_to_release": True, "build_command": "false"},
        {"upload_to_pypi": False, "upload_to_release": True, "build_command": "ls"},
    ]

    assert [should_build() for option in options] == [False, True, False, True]



# Generated at 2022-06-24 01:31:17.110556
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:31:19.445725
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert bool(should_remove_dist()) == False


# Generated at 2022-06-24 01:31:20.264858
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")


# Generated at 2022-06-24 01:31:24.596209
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should return false as neither key is set
    empty_config = {}
    assert should_remove_dist(empty_config) is False

    # Should return true as the prepare_release key is set
    normal_config = {
        "prepare_release": True,
        "build_command": "ls",
        "upload_to_release": True,
        "upload_to_pypi": False,
        "remove_dist": True,
    }
    assert should_remove_dist(normal_config) is True

# Generated at 2022-06-24 01:31:26.029577
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:31:34.047624
# Unit test for function should_build
def test_should_build():
    c = {"build_command": False, "upload_to_pypi": False, "upload_to_release": False}
    config.update(c)
    assert not should_build()

    config.update({"build_command": "true"})
    assert should_build()

    config.update({"upload_to_pypi": True})
    assert should_build()

    config.update({"upload_to_pypi": False, "upload_to_release": True})
    assert should_build()

# Generated at 2022-06-24 01:31:45.665152
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {
        "build_command": "/usr/local/bin/python setup.py sdist",
        "upload_to_pypi": True,
        "upload_to_release": True,
        "remove_dist": True
    }
    assert should_remove_dist(config) is True
    config = {
        "build_command": "/usr/local/bin/python setup.py sdist",
        "upload_to_pypi": True,
        "upload_to_release": True,
        "remove_dist": False
    }
    assert should_remove_dist(config) is False
    config = {
        "build_command": "false",
        "upload_to_pypi": True,
        "upload_to_release": True,
        "remove_dist": False
    }
   

# Generated at 2022-06-24 01:31:48.477895
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:31:51.007309
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf ./dist"
    assert remove_dists(command) == None

# Generated at 2022-06-24 01:31:51.981114
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")



# Generated at 2022-06-24 01:31:57.103357
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "bdist_wheel"
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:32:01.114249
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dist_dir = './dist'
    if not should_remove_dist() and should_build():
        build_dists()
        assert should_remove_dist() == True, "Should be True"
    else:
        assert should_remove_dist() == False, "Should be False"


# Generated at 2022-06-24 01:32:03.219069
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:32:04.874122
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:32:08.292423
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist() == True
    config["remove_dist"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:32:12.682842
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil

    # Generate files
    test_path = "test/test_remove/"
    os.makedirs(test_path, exist_ok=True)
    os.makedirs(os.path.join(test_path, "test"), exist_ok=True)

    remove_dists(test_path)

    assert os.path.exists(test_path) == False

# Generated at 2022-06-24 01:32:18.632557
# Unit test for function build_dists
def test_build_dists():
    # TODO: cannot do the actual builds, since the original command is not easily mocked
    # For example, 'python setup.py sdist bdist_wheel' can spread across two invocations
    assert should_build() == True
    assert should_remove_dist() == True
    build_dists()
    remove_dists("dist")
    assert should_build() == False
    assert should_remove_dist() == False
    build_dists()
    remove_dists("dist")

# Generated at 2022-06-24 01:32:26.983289
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "false"
    config["remove_dist"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "false"
    config["remove_dist"] = "true"
    assert not should_remove_dist()

    config["build_command"] = "true"
    config["remove_dist"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "true"
    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:32:28.944239
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # given
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "pip install"
    config["remove_dist"] = True
    # when
    result = should_remove_dist()
    # then
    assert result



# Generated at 2022-06-24 01:32:30.156104
# Unit test for function build_dists
def test_build_dists():
    assert isinstance(build_dists(), None)

# Generated at 2022-06-24 01:32:31.460058
# Unit test for function build_dists
def test_build_dists():
    assert type(build_dists()) == None


# Generated at 2022-06-24 01:32:42.612257
# Unit test for function should_build
def test_should_build():
    # Given
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python3 setup.py sdist"
    # When
    test1 = should_build()
    # Then
    assert test1
    # Given
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python3 setup.py sdist"
    # When
    test2 = should_build()
    # Then
    assert test2
    # Given
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python3 setup.py sdist"
    # When
    test3 = should_build

# Generated at 2022-06-24 01:32:44.898459
# Unit test for function should_build
def test_should_build():
    assert (should_build()
            == (config.get("upload_to_pypi")
                or config.get("upload_to_release")))

# Generated at 2022-06-24 01:32:47.322609
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:32:55.225389
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    assert False == should_build()

    config["upload_to_pypi"] = True
    assert True == should_build()

    config["build_command"] = False
    assert False == should_build()

    config["build_command"] = "true"
    assert True == should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert False == should_build()

    config["upload_to_release"] = True
    assert True == should_build()



# Generated at 2022-06-24 01:32:59.531778
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import config
    path = config.get("dist_path")
    remove_dists(path)

# Generated at 2022-06-24 01:33:01.927030
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:33:02.465111
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:33:03.346653
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    pass

# Generated at 2022-06-24 01:33:07.226142
# Unit test for function should_build
def test_should_build():
    """ Test whether build should run or not
    """
    assert should_build() == True


# Generated at 2022-06-24 01:33:08.482920
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:33:09.185055
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:33:10.078567
# Unit test for function should_build
def test_should_build():
    assert True == should_build()


# Generated at 2022-06-24 01:33:19.932923
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import config
    from os import path

    # Get current path
    current_path = path.dirname(path.realpath(__file__))

    # Create fake dist
    # Run function
    # Assert it's gone
    dist_files = {
        "fake.file": path.join(current_path, "fake_dist", "fake.file"),
        "fake_folder": path.join(current_path, "fake_dist", "fake_folder"),
    }
    # Create fake dist
    for dist_file in dist_files.values():
        run(f"mkdir -p {path.dirname(dist_file)}")
        run(f"touch {dist_file}")
    # Test if created

# Generated at 2022-06-24 01:33:23.087882
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == True
    assert build_dists() == True
    assert remove_dists() == True

# Generated at 2022-06-24 01:33:32.537423
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import config
    config.set("upload_to_pypi", True)
    assert should_remove_dist()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()
    config.set("upload_to_release", False)
    config.set("build_command", "some command")
    assert not should_remove_dist()
    config.set("build_command", "false")
    assert not should_remove_dist()
    config.set("build_command", "some command")
    config.set("remove_dist", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:35.173462
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:33:42.819731
# Unit test for function should_build
def test_should_build():
    for i in [(True, False, True, True),
              (True, True, "make build", True),
              (True, True, "make build", False),
              (True, False, False, False),
              (True, False, "", False),
              (True, True, "", False)]:
        config["upload_to_pypi"], config["upload_to_release"], config["build_command"], \
        assert_result = i
        assert should_build() == assert_result, f"Expected {assert_result} got {should_build()}"


# Generated at 2022-06-24 01:33:46.992894
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:49.488957
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:33:50.363460
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./tests/testdir")

# Generated at 2022-06-24 01:33:54.308567
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = "True"
    config["upload_to_pypi"] = "True"
    config["upload_to_release"] = "False"
    assert should_remove_dist() == True
    config["build_command"] = "true"
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:56.116792
# Unit test for function build_dists
def test_build_dists():
    msg = "Run './scripts/build-dists.py'"
    assert config.get("build_command") == msg



# Generated at 2022-06-24 01:34:06.980544
# Unit test for function should_build
def test_should_build():
    # Test when all settings are true
    build_command = build_command_test()
    config.update(dict(upload_to_pypi=True, upload_to_release=True))
    assert should_build()
    # Test when upload to pypi is false
    config.update(dict(upload_to_pypi=False, upload_to_release=True))
    assert should_build()
    # Test when upload to release is false
    config.update(dict(upload_to_pypi=True, upload_to_release=False))
    assert should_build()
    # Test when build_command is false
    config.update(dict(upload_to_pypi=True, upload_to_release=True,
                       build_command=False))
    assert not should_build()
    # Test when all

# Generated at 2022-06-24 01:34:07.941216
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:34:16.241700
# Unit test for function should_build
def test_should_build():
    import os
    import shutil

    pkg_name = "bump2version"
    repository = "https://github.com/c4urself/bump2version.git"
    config["package_name"] = pkg_name
    config["repository_url"] = repository
    config["remove_dist"] = False

    cmd = "python setup.py sdist"
    config["build_command"] = cmd
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False

    config["upload_to_release"] = True
    assert should_build()


# Generated at 2022-06-24 01:34:16.888384
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-24 01:34:17.885076
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:34:18.475376
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:19.627755
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:20.672094
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")



# Generated at 2022-06-24 01:34:22.934350
# Unit test for function build_dists
def test_build_dists():
    class Test:
        def __init__(self):
            self.command = "echo 'Hello'"

    # Run the function build_dists with Test object
    build_dists(Test())

# Generated at 2022-06-24 01:34:28.758173
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert should_remove_dist()
    path = config.get("dists_path")
    remove_dists(path)
    build_dists()
    assert run(f"ls dist/ | grep .whl").stdout != ""
    assert run(f"ls dist/ | grep .tar.gz").stdout != ""

# Generated at 2022-06-24 01:34:30.058162
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists(__file__) == 0

# Generated at 2022-06-24 01:34:37.494244
# Unit test for function should_build
def test_should_build():
    def assert_should_build(command=False, pypi=False, release=False):
        config.set("build_command", command)
        config.set("upload_to_pypi", pypi)
        config.set("upload_to_release", release)
        assert should_build() == (bool(command) and (pypi or release))

    assert_should_build()
    assert_should_build(command=True, pypi=True)
    assert_should_build(command=True, release=True)
    assert_should_build(command=False, pypi=True)
    assert_should_build(command=False, release=True)
    assert_should_build(pypi=True, release=True)

# Generated at 2022-06-24 01:34:40.189463
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/does_not_exist/\"")
    pass

# Generated at 2022-06-24 01:34:50.453592
# Unit test for function should_build
def test_should_build():
    build_command = "python setup.py sdist bdist_wheel"
    # Should build from pypi
    config["upload_to_pypi"] = True
    config["build_command"] = build_command
    assert should_build()
    # Should build to release
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    # Should build with both uploads
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()
    # Should force build
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["force_build"] = True
    assert should_build()
    # Should not build
    config

# Generated at 2022-06-24 01:35:01.388866
# Unit test for function remove_dists
def test_remove_dists():
    from .test_utils import create_test_settings_file
    from .config import Config
    from .paths import Paths
    from shutil import rmtree
    # Create random test directory
    from random import randint
    test_settings_path = f"/tmp/test_remove_dists{randint(0, 1000)}.yml"
    # Create test_settings_path
    create_test_settings_file(test_settings_path, {})
    # Create Paths and Config objects
    paths = Paths(test_settings_path)
    config = Config(paths)
    # Path to be deleted
    path = f"{paths.root_dir}/foo/bar"
    # Create directory to be deleted
    run(f"mkdir -p {path}")
    # Remove directory
    remove_

# Generated at 2022-06-24 01:35:02.969204
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:35:04.209834
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="./dist")



# Generated at 2022-06-24 01:35:11.057449
# Unit test for function should_build
def test_should_build():
    test_config = {"build_command": "test_command", "upload_to_pypi": "True"}
    assert should_build(test_config) == True

    test_config = {"build_command": "test_command", "upload_to_release": "True"}
    assert should_build(test_config) == True

    test_config = {"build_command": "test_command", "upload_to_pypi": "False"}
    assert should_build(test_config) == True

    test_config = {"build_command": "test_command", "upload_to_release": "False"}
    assert should_build(test_config) == True

    test_config = {"build_command": "false", "upload_to_pypi": "True"}
    assert should_build(test_config) == False



# Generated at 2022-06-24 01:35:14.103802
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert build_dists() ==  None

# Generated at 2022-06-24 01:35:20.136039
# Unit test for function should_build
def test_should_build():
    config["upload_to_release"] = "true"
    config["upload_to_pypi"] = "true"
    config["build_command"] = "build"
    assert should_build() is True



# Generated at 2022-06-24 01:35:23.666414
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        remove_dists(tempdir)

# Generated at 2022-06-24 01:35:26.884927
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == False
    command = config.get("build_command")
    assert command == "python setup.py sdist bdist_wheel"
    assert should_build() == True

# Generated at 2022-06-24 01:35:27.519153
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:29.749792
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert should_remove_dist()
    build_dists()
    remove_dists(config.get("dist_path"))

# Generated at 2022-06-24 01:35:37.839002
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # when config = {"upload_to_pypi": "false", "upload_to_release": "true", "remove_dist": "false", "build_command": "python setup.py sdist"}
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = False
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist() is False

    # when config = {"upload_to_pypi": "false", "upload_to_release": "true", "remove_dist": "true", "build_command": "python setup.py sdist"}
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = True
   

# Generated at 2022-06-24 01:35:38.909883
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:39.938454
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True

# Generated at 2022-06-24 01:35:46.488741
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build() is True
    config["upload_to_pypi"] = False
    assert should_build() is False
    config["upload_to_release"] = False
    assert should_build() is False
    config["upload_to_release"] = True
    config["build_command"] = False
    assert should_build() is False



# Generated at 2022-06-24 01:35:47.405013
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:35:51.353101
# Unit test for function build_dists
def test_build_dists():
    """Test the build_dists function."""
    config.set("build_command", "do-nothing --quiet")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build()
    build_dists()
    assert not should_remove_dist()

# Generated at 2022-06-24 01:35:53.128208
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = 'true'
    config['build_command'] = 'build-command'
    assert should_remove_dist()



# Generated at 2022-06-24 01:36:02.921341
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "some_command"
    assert should_remove_dist() is True
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() is True
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:36:08.362896
# Unit test for function remove_dists
def test_remove_dists():
    path = "./dist/test"
    run(f"mkdir -p {path}")
    assert run(f"find {path}").ok
    remove_dist(path)
    assert not run(f"find {path}").ok

# Generated at 2022-06-24 01:36:09.254070
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="/tmp/")

# Generated at 2022-06-24 01:36:13.622074
# Unit test for function should_build
def test_should_build():
    assert(should_build({'upload_to_pypi': False,
                         'upload_to_release': False,
                         'build_command': 'false'}) is False)
    assert(should_build({'upload_to_pypi': True,
                         'upload_to_release': False,
                         'build_command': 'true'}) is True)
    assert(should_build({'upload_to_pypi': False,
                         'upload_to_release': True,
                         'build_command': 'true'}) is True)

# Generated at 2022-06-24 01:36:20.202613
# Unit test for function should_build
def test_should_build():
    logger.info("Test should_build()")
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "test"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:36:21.120496
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:36:22.030631
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:33.058886
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.config = {"build_command": "test"}
    assert should_build() == False
    config.config = {"build_command": "test", "upload_to_pypi": True}
    assert should_build() == True
    config.config = {
        "build_command": "test",
        "upload_to_pypi": True,
        "upload_to_release": True,
    }
    assert should_build() == True
    config.config = {"build_command": "false"}
    assert should_build() == False
    config.config = {"build_command": "test", "upload_to_release": True}
    assert should_build() == True
    config.config = {"build_command": "test", "upload_to_pypi": True}


# Generated at 2022-06-24 01:36:36.735838
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() is None, "build_dists() returns None."



# Generated at 2022-06-24 01:36:41.102852
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:36:45.435139
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf dist"
    run(command)
    result = remove_dists("dist")
    assert result == True
    command = "mkdir dist"
    result = remove_dists("dist")
    assert result == False
    run(command)

# Generated at 2022-06-24 01:36:46.392372
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:36:49.476713
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:57.220941
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config.update({"remove_dist": "false"})
    assert should_remove_dist() == False
    config.update({"remove_dist": "true"})
    assert should_remove_dist() == False
    config.update({"build_command": "false"})
    assert should_remove_dist() == False
    config.update({"build_command": "true"})
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:37:01.079295
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist"
    logger.info(f"Testing {command}")
    run(command)

# Generated at 2022-06-24 01:37:08.317917
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    root = tempfile.mkdtemp()
    dist1 = tempfile.mkdtemp(dir=root)
    dist2 = tempfile.mkdtemp(dir=root)
    remove_dists(root)
    assert not os.path.exists(root)

# Generated at 2022-06-24 01:37:12.154897
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    from .build_dists import build_dists
    from .build_dists import should_build
    assert should_build()
    assert config.get("build_command")
    build_dists()



# Generated at 2022-06-24 01:37:14.153269
# Unit test for function remove_dists
def test_remove_dists():
    try:
        assert remove_dists("") == None
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-24 01:37:16.128966
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:37:18.117499
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp/") == None

# Generated at 2022-06-24 01:37:26.044302
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from itest_utils import update_config
    config = update_config({"remove_dist": "true", "build_command": True})
    assert should_remove_dist() is True
    config = update_config({"remove_dist": "false", "build_command": True})
    assert should_remove_dist() is False
    config = update_config({"remove_dist": "true", "build_command": False})
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:37:34.812786
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    from shutil import rmtree
    from pathlib import Path

    test_dir = Path(tempfile.mkdtemp(prefix="vx-release-test-"))
    test_dir.mkdir(exist_ok=True)
    test_dir.resolve()
    # create path for removing
    Path(test_dir, "dist_to_remove").mkdir()
    # create path for not removing
    Path(test_dir, "normal_dir").mkdir()

    remove_dists(path=str(test_dir.joinpath("dist")))

    assert not test_dir.joinpath("dist_to_remove").exists()
    assert test_dir.joinpath("normal_dir").exists()
    rmtree(test_dir)

# Generated at 2022-06-24 01:37:37.555936
# Unit test for function remove_dists
def test_remove_dists():
    def mock_run(cmd):
        assert cmd == "rm -rf build"
    old_run = run
    run = mock_run
    remove_dists("build")
    run = old_run

# Generated at 2022-06-24 01:37:38.457799
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert bool(should_remove_dist()) is True



# Generated at 2022-06-24 01:37:38.904532
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()

# Generated at 2022-06-24 01:37:42.365738
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    path = os.path.join(tempfile.gettempdir(), "beauty_ocean_test")
    os.makedirs(path, exist_ok=True)
    remove_dists(path)

# Generated at 2022-06-24 01:37:54.016752
# Unit test for function should_build
def test_should_build():
    # Given
    config.set("build_command", "false")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)

    # When
    result = should_build()

    # Then
    assert result == False

    # Given
    config.set("build_command", "true")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)

    # When
    result = should_build()

    # Then
    assert result == False

    # Given
    config.set("build_command", "true")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)

    # When
    result = should_build()

    #

# Generated at 2022-06-24 01:37:55.413574
# Unit test for function should_build
def test_should_build():
    """
    Test that should_build returns True when the command is not false
    """
    assert should_build()



# Generated at 2022-06-24 01:37:58.404917
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    test_dir = tempfile.TemporaryDirectory()
    test_path = os.path.join(test_dir.name, "*")
    remove_dists(test_path)

# Generated at 2022-06-24 01:37:59.522193
# Unit test for function remove_dists
def test_remove_dists():
    assert True == should_remove_dist()

# Generated at 2022-06-24 01:38:01.176419
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "should_remove_dist fails"


# Generated at 2022-06-24 01:38:02.502099
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:38:04.148488
# Unit test for function build_dists
def test_build_dists():
    build = should_build()
    assert build is True

# Generated at 2022-06-24 01:38:05.141447
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:06.987947
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo test"
    build_dists()

# Generated at 2022-06-24 01:38:09.638732
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:11.772687
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True

# Generated at 2022-06-24 01:38:15.630645
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Load test configuration
    config.load_dict({"remove_dist": "true", "upload_to_pypi": "true"})
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:19.386937
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Test should_remove_dist function.
    """
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:38:27.428795
# Unit test for function should_build
def test_should_build():
    from .project import DEFAULT_CONFIG

    # Simple test, no pypi or release
    config1 = DEFAULT_CONFIG
    config1["upload_to_pypi"] = False
    config1["upload_to_release"] = False
    config1["build_command"] = "python3 setup.py sdist bdist_wheel"
    assert should_build() == False

    # Simple test, no pypi or release (but command set to false)
    config1 = DEFAULT_CONFIG
    config1["upload_to_pypi"] = False
    config1["upload_to_release"] = False
    config1["build_command"] = "false"
    assert should_build() == False

    # Simple test, no pypi or release (but command set to false)
    config1 = DEFAULT_CON

# Generated at 2022-06-24 01:38:29.883250
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-24 01:38:36.129954
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_set = {
        "build_command": "python setup.py bdist_wheel",
        "remove_dist": True,
        "upload_to_pypi": True,
        "upload_to_release": True
    }
    assert should_remove_dist()

    config_set = {
        "build_command": "python setup.py bdist_wheel",
        "remove_dist": False,
        "upload_to_pypi": True,
        "upload_to_release": True
    }
    assert not should_remove_dist()


# Generated at 2022-06-24 01:38:46.463907
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "not-false")
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "not-false")
    assert should_remove_dist() is False
    config.set("remove_dist", False)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:51.542071
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    import os
    d = tempfile.mkdtemp()
    os.makedirs(f"{d}/test")
    assert os.path.isdir(d)
    assert os.path.isdir(f"{d}/test")
    test_path = f"{d}/test"
    remove_dists(test_path)
    assert not os.path.isdir(test_path)

# Generated at 2022-06-24 01:38:56.806956
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:38:57.990604
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist()) == False


# Generated at 2022-06-24 01:39:05.444812
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "asdf")
    config.set("upload_to_pypi", "asdf")
    config.set("upload_to_release", "asdf")
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    assert should_remove_dist() is True
    config.set("build_command", "false")
    assert should_remove_dist() is False
    config.set("upload_to_pypi", False)
    assert should_remove_dist() is False
    config.set("upload_to_release", False)
    assert should_remove_dist() is False
    config.set("upload_to_pypi", True)

# Generated at 2022-06-24 01:39:06.429886
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("~/tmp") == None

# Generated at 2022-06-24 01:39:08.068814
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:39:08.909012
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist/")

# Generated at 2022-06-24 01:39:09.431741
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:39:10.494700
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("unittests")

# Generated at 2022-06-24 01:39:14.360485
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

