

# Generated at 2022-06-24 01:29:17.820985
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False    
    assert should_remove_dist(True) == True
    assert should_remove_dist(False) == False

# Generated at 2022-06-24 01:29:19.551294
# Unit test for function should_build
def test_should_build():
    function_should_build = should_build()
    assert function_should_build

# Generated at 2022-06-24 01:29:23.754654
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = 'inv build'
    config["remove_dist"] = True
    assert should_remove_dist()
    config["build_command"] = 'false'
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:29:24.517489
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:29.279947
# Unit test for function build_dists
def test_build_dists():
    config.set("build_command", "echo 'Hello World'")
    build_dists()



# Generated at 2022-06-24 01:29:33.668006
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:37.210825
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:29:40.709302
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.update({"upload_to_pypi": True})
    assert should_remove_dist() is False
    config.update({"upload_to_release": True})
    assert should_remove_dist() is False
    config.update({"build_command": "test"})
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:29:44.443194
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp/test") == None

# Generated at 2022-06-24 01:29:46.201889
# Unit test for function build_dists
def test_build_dists():
    assert True



# Generated at 2022-06-24 01:29:47.749458
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf /tmp/dist"
    assert command == remove_dists("/tmp/dist")

# Generated at 2022-06-24 01:29:49.471468
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:29:53.867885
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('covid_model_seiir_pipeline/tests/__pycache__')

# Generated at 2022-06-24 01:29:55.058612
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/1234567890")



# Generated at 2022-06-24 01:29:57.140614
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

test_remove_dists()

# Generated at 2022-06-24 01:29:57.939855
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:29:58.458248
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:29:59.422574
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:29:59.992431
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:07.473975
# Unit test for function should_build
def test_should_build():
    test_config = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "echo 'build'"
    }
    config.update(test_config)
    assert should_build()

    test_config["upload_to_pypi"] = False
    assert should_build()

    test_config["upload_to_pypi"] = False
    test_config["upload_to_release"] = True
    assert should_build()

# Generated at 2022-06-24 01:30:08.903111
# Unit test for function should_remove_dist
def test_should_remove_dist():
    actual = should_remove_dist()
    assert actual



# Generated at 2022-06-24 01:30:10.765895
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf dist"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:30:13.826803
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:30:15.234927
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:30:22.315615
# Unit test for function should_build
def test_should_build():
    from .settings import set_config
    assert not should_build()
    set_config(dict(build_command="make dist"))
    assert should_build()
    set_config(dict(upload_to_pypi=False, build_command="make dist"))
    assert should_build()
    set_config(dict(upload_to_pypi=False, upload_to_release=False, build_command="make dist"))
    assert not should_build()



# Generated at 2022-06-24 01:30:23.485180
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:30:24.493764
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-24 01:30:27.334440
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:30:28.894590
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:32.127187
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:36.820044
# Unit test for function should_remove_dist
def test_should_remove_dist():
    command_true = "sdist bdist_wheel"
    config["build_command"] = command_true
    config["remove_dist"] = "true"
    assert should_remove_dist()

    command_false = "false"
    config["build_command"] = command_false
    config["remove_dist"] = "true"
    assert should_remove_dist() == False

    command_true = "sdist bdist_wheel"
    config["build_command"] = command_true
    config["remove_dist"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:40.861457
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_release", "true")
    config.set("upload_to_pypi", "true")
    config.set("build_command", "./setup.py sdist bdist_wheel")
    assert should_remove_dist()

# Generated at 2022-06-24 01:30:43.325742
# Unit test for function remove_dists
def test_remove_dists():
    from tempfile import mkdtemp

    path = mkdtemp()
    remove_dists(path)
    from os.path import exists
    assert exists(path)  # `remove_dists` does not remove the path

# Generated at 2022-06-24 01:30:50.587487
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("build_command", "git push origin master")
    assert should_build() is True
    config.set("build_command", "false")
    assert should_build() is False
    config.set("upload_to_pypi", False)
    config.set("build_command", "git push origin master")
    config.set("upload_to_release", True)
    assert should_build() is True



# Generated at 2022-06-24 01:30:55.810003
# Unit test for function remove_dists
def test_remove_dists():
    import shutil
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as path:
        with open(os.path.join(path, "test.txt"), "w") as f:
            f.write("This is a test")
        assert os.path.exists(os.path.join(path, "test.txt"))
        remove_dists(path)
        assert not os.path.exists(os.path.join(path, "test.txt"))

# Generated at 2022-06-24 01:31:05.630938
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    assert should_build()

    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()

    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["build_command"] =  False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-24 01:31:09.410234
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")
    remove_dists("dist")
    remove_dists("*.egg-info")

# Generated at 2022-06-24 01:31:10.092890
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:12.779282
# Unit test for function build_dists
def test_build_dists():
    # Test: command must be string
    assert should_build() is False
    config["build_command"] = "false"
    assert should_build() is False

# Generated at 2022-06-24 01:31:16.693599
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config._store["remove_dist"] = True
    config._store["build_command"] = "false"
    config._store["upload_to_pypi"] = True
    config._store["upload_to_release"] = False
    assert should_remove_dist() == False

    config._store["build_command"] = "build"
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:18.504182
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test/dists")


# Generated at 2022-06-24 01:31:21.159103
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-24 01:31:25.495268
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import PROJECT_ROOT

    remove_pypi = bool(config.get("upload_to_pypi"))
    remove_release = bool(config.get("upload_to_release"))
    remove_dist = bool(config.get("remove_dist"))

    if remove_pypi and remove_release and remove_dist:
        remove_dists(PROJECT_ROOT / "dist" / "*")


# Generated at 2022-06-24 01:31:26.462661
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:36.423942
# Unit test for function should_remove_dist
def test_should_remove_dist():
    with config.set_values({"remove_dist": "false", "upload_to_pypi": "False", "upload_to_release": "False", "build_command": "false"}):
        assert not should_remove_dist()

    with config.set_values({"remove_dist": "true", "upload_to_pypi": "False", "upload_to_release": "False", "build_command": "false"}):
        assert not should_remove_dist()

    with config.set_values({"remove_dist": "false", "upload_to_pypi": "False", "upload_to_release": "False", "build_command": "pwd"}):
        assert not should_remove_dist()


# Generated at 2022-06-24 01:31:37.286594
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:37.867169
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:31:39.246205
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:31:40.012316
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:41.100637
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    

# Generated at 2022-06-24 01:31:44.266314
# Unit test for function build_dists
def test_build_dists():
    build_command = "tar -czvf venv.tar.gz venv"
    config["build_command"] = build_command
    config["upload_to_pypi"] = True
    assert should_build() == True
    build_dists()



# Generated at 2022-06-24 01:31:44.866607
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:31:54.822773
# Unit test for function should_build
def test_should_build():
    # not uploading to either, no build command
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() is False

    # uploading to either, no build command
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() is False

    # not uploading to either, build command
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo \"test\""
    assert should_build() is False

    # uploading to either, build command
    config["upload_to_pypi"] = False
   

# Generated at 2022-06-24 01:31:58.418556
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    assert config.get("build_command") is not None
    assert should_build()

# Generated at 2022-06-24 01:31:58.953751
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:32:07.100559
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "do-not-remove")
    assert not should_remove_dist(), "must return False when remove_dist is do-not-remove"
    config.set("remove_dist", "remove")
    config.set("upload_to_pypi", "False")
    assert not should_remove_dist(), "must return False when upload_to_pypi is False"
    config.set("upload_to_pypi", "True")
    assert should_remove_dist(), "must return True when upload_to_pypi is True and build_command is not False"
    config.set("upload_to_pypi", "False")
    config.set("upload_to_release", "False")

# Generated at 2022-06-24 01:32:17.991852
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "true"
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["build_command"] = "setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "true"
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "false"
    config["upload_to_pypi"] = "true"
    config["remove_dist"] = "true"
    assert not should_remove_dist()
    config["build_command"] = "setup.py sdist bdist_wheel"

# Generated at 2022-06-24 01:32:19.266114
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# vim:et:fenc=utf-8:

# Generated at 2022-06-24 01:32:23.299324
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "test"
    assert should_build()



# Generated at 2022-06-24 01:32:28.278490
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

# Generated at 2022-06-24 01:32:29.846581
# Unit test for function remove_dists
def test_remove_dists():
    path = "dist"
    remove_dists(path)

# Generated at 2022-06-24 01:32:32.865953
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is False
    config["build_command"] = f"touch a.txt"
    assert should_build() is True
    build_dists()
    config["remove_dist"] = True
    remove_dists("a.txt")

# Generated at 2022-06-24 01:32:34.213717
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == True)



# Generated at 2022-06-24 01:32:36.922769
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True

# Generated at 2022-06-24 01:32:38.492102
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo test"
    build_dists()



# Generated at 2022-06-24 01:32:42.119874
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import test_config
    from .utils import get_path
    from .settings import dist_path
    config.update(test_config)
    path = get_path(dist_path)
    remove_dists(path)

# Generated at 2022-06-24 01:32:43.654550
# Unit test for function should_build
def test_should_build():
    assert should_build() is True, "should_build function does not work"



# Generated at 2022-06-24 01:32:52.473782
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_values = {"build_command": "sphinx-build",
                     "upload_to_pypi": True,
                     "upload_to_release": False,
                     "remove_dist": True}
    assert should_remove_dist() is True, "should_remove_dist() is True"

    config.update(config_values)
    assert should_remove_dist() is False, "should_remove_dist() is True"
    config.clear()



# Generated at 2022-06-24 01:32:54.399317
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:32:55.472015
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:05.528559
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config.update({"upload_to_pypi": True})
    assert should_build() is False

    config.update({"upload_to_release": True})
    assert should_build() is False

    config.update({"build_command": "echo"})
    assert should_build() is False

    config.update({"upload_to_pypi": False})
    assert should_build() is True

    config.update({"upload_to_release": False})
    assert should_build() is False

    config.update({"upload_to_pypi": None})
    assert should_build() is True

    config.update({"upload_to_pypi": False})
    config.update({"upload_to_release": False})
    assert should_build() is False

# Generated at 2022-06-24 01:33:06.805668
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/dists")

# Generated at 2022-06-24 01:33:09.088543
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:33:15.192916
# Unit test for function build_dists
def test_build_dists():
    dist_dir = config.get("dist_dir")
    build_dists()
    # Check that dist_dir exists
    assert dist_dir.exists()
    # Remove directory
    if should_remove_dist():
        remove_dists(dist_dir)
        

# Generated at 2022-06-24 01:33:19.634058
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "python setup.py bdist_wheel"
    assert should_build()
    config["build_command"] = "python setup.py sdist"
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "python setup.py bdist_wheel"



# Generated at 2022-06-24 01:33:21.757324
# Unit test for function should_build
def test_should_build():
    expected = True
    actual = should_build()
    assert expected == actual



# Generated at 2022-06-24 01:33:22.795308
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:27.039084
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    assert should_build()

    config["build_command"] = "false"
    config["upload_to_release"] = True
    assert not should_build()

# Generated at 2022-06-24 01:33:29.026452
# Unit test for function build_dists
def test_build_dists():
    run("python -m flakydoodle.build_dist --help")

# Generated at 2022-06-24 01:33:30.693587
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-24 01:33:31.396912
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:33:34.029345
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:33:34.663727
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:36.004713
# Unit test for function remove_dists
def test_remove_dists():
    assert isinstance(remove_dists(), str)


# Generated at 2022-06-24 01:33:41.939684
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["build_command"] = "false"
    assert not should_build()

    config["upload_to_release"] = "false"
    assert not should_build()

    config["upload_to_release"] = "true"
    assert not should_build()

    config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-24 01:33:44.576622
# Unit test for function build_dists
def test_build_dists():
    command = "pip install invoke"
    config["build_command"] = command
    config["remove_dist"] = "true"
    build_dists()

# Generated at 2022-06-24 01:33:45.215509
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:33:45.956437
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="dummy_path")

# Generated at 2022-06-24 01:33:53.412434
# Unit test for function should_build
def test_should_build():
    conf = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "remove_dist": True,
        "build_command": "true",
    }
    config.update(conf)
    assert should_build()
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:55.635028
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:34:03.025809
# Unit test for function should_build
def test_should_build():
    config["build_command"] = False

    config["upload_to_pypi"] = False
    assert not should_build()

    config["upload_to_release"] = True
    assert not should_build()

    config["upload_to_pypi"] = True
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    # remove False
    del config["build_command"]
    assert should_build()



# Generated at 2022-06-24 01:34:04.119226
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:34:12.873957
# Unit test for function should_remove_dist
def test_should_remove_dist():
    for upload_pypi in [True, False, 1, 0]:
        for upload_release in [True, False, 1, 0]:
            for remove_dist in [True, False, 1, 0]:
                config.set("upload_to_pypi", upload_pypi)
                config.set("upload_to_release", upload_release)
                config.set("remove_dist", remove_dist)
                config.set("build_command", "true")
                result = bool(upload_pypi or upload_release) == should_remove_dist()
                print(f"""
                      upload_pypi={upload_pypi}
                      upload_release={upload_release}
                      remove_dist={remove_dist}
                      result={result}""")


# Generated at 2022-06-24 01:34:14.307917
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")


# Generated at 2022-06-24 01:34:20.384764
# Unit test for function build_dists
def test_build_dists():
    # Test if function invokes build command by trying to get an invalid
    # version number, which should throw an exception
    try:
        build_dists()
        print("Build command failed")
    except Exception:
        pass

# Generated at 2022-06-24 01:34:23.001385
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert should_remove_dist()



# Generated at 2022-06-24 01:34:25.619775
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:34:26.880006
# Unit test for function remove_dists
def test_remove_dists():
    path = 'test'
    remove_dists(path)

# Generated at 2022-06-24 01:34:32.489100
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "echo foo")
    assert should_build() is True



# Generated at 2022-06-24 01:34:33.615338
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:34:34.456037
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:34:42.252910
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Tests should_remove_dist calls
    # Should return False if 'remove_dist' is not set in config
    config['remove_dist'] = ''
    assert should_remove_dist() is False
    # Should return True if 'remove_dist' is set and 'upload_to_pypi' is set
    config['remove_dist'] = 'true'
    config['upload_to_pypi'] = 'true'
    assert should_remove_dist() is True
    # Should return True if 'remove_dist' is set and 'upload_to_release' is set
    config['upload_to_pypi'] = ''
    config['upload_to_release'] = 'true'
    assert should_remove_dist() is True
    # Should return False if 'upload_to_pypi' and 'upload_to_release'

# Generated at 2022-06-24 01:34:43.584322
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:34:47.063768
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:34:49.883195
# Unit test for function build_dists
def test_build_dists():
    import mock
    mock_run = mock.Mock()
    with mock.patch('invoke.run', mock_run):
        config["build_command"] = "test command"
        build_dists()
        assert mock_run.called_once_with('test command')



# Generated at 2022-06-24 01:34:56.895756
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should be True
    assert should_remove_dist() == True, "should_remove_dist is False"
    # Should be False
    config["remove_dist"] = False
    assert should_remove_dist() == False, "should_remove_dist is True"
    # Should be False
    config["remove_dist"] = True
    config["build_command"] = "false"
    assert should_remove_dist() == False, "should_remove_dist is True"


# Generated at 2022-06-24 01:34:58.622850
# Unit test for function remove_dists

# Generated at 2022-06-24 01:34:59.284998
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-24 01:35:04.338987
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "pytest"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:35:05.201792
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:35:05.826704
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-24 01:35:07.220701
# Unit test for function remove_dists
def test_remove_dists():
    cmd = "rm -rf ~/build"
    assert remove_dists("~/build") == run(cmd)

# Generated at 2022-06-24 01:35:09.772637
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:35:18.257231
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    dir_name = tempfile.mkdtemp()
    os.rmdir(dir_name)
    dists_dir = os.path.join(dir_name, "dists")
    os.mkdir(dists_dir)
    file_outcome = open(os.path.join(dists_dir, "test.txt"), "w")
    file_outcome.close()
    remove_dists(dists_dir)
    assert not os.path.isdir(dists_dir)

# Generated at 2022-06-24 01:35:18.911270
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:35:26.638333
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "echo")
    config.set("remove_dist", False)
    assert should_remove_dist() == False

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "echo")
    config.set("remove_dist", True)
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:35:27.227059
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:35:27.959790
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:35:36.798914
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": "true",
                   "upload_to_pypi": "false",
                   "upload_to_release": "false",
                   "build_command": "false"})
    assert should_remove_dist()

    config.update({"remove_dist": "false",
                   "upload_to_pypi": "false",
                   "upload_to_release": "false",
                   "build_command": "false"})
    assert not should_remove_dist()

    config.update({"remove_dist": "true",
                   "upload_to_pypi": "true",
                   "upload_to_release": "false",
                   "build_command": "false"})
    assert not should_remove_dist()


# Generated at 2022-06-24 01:35:38.586225
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("build_command")

# Generated at 2022-06-24 01:35:46.105814
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "python setup.py sdist"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["remove_dist"] = True
    expected_result = True
    actual_result = should_remove_dist()
    print("Expected Result: ", expected_result)
    print("Actual result: ", actual_result)
    assert expected_result == actual_result


# Generated at 2022-06-24 01:35:46.958994
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:35:54.871737
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['upload_to_release'] = True
    config['upload_to_pypi'] = False
    config['build_command'] = ''
    config['remove_dist'] = ''

    assert True == should_remove_dist()
    config['upload_to_release'] = True
    config['upload_to_pypi'] = False
    config['build_command'] = ''
    config['remove_dist'] = 'True'

    assert True == should_remove_dist()
    config['upload_to_release'] = True
    config['upload_to_pypi'] = False
    config['build_command'] = ''
    config['remove_dist'] = 'False'

    assert False == should_remove_dist()
    config['upload_to_release'] = False

# Generated at 2022-06-24 01:35:57.439963
# Unit test for function remove_dists
def test_remove_dists():
    pass


# Generated at 2022-06-24 01:35:58.346843
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")



# Generated at 2022-06-24 01:36:06.427085
# Unit test for function should_build
def test_should_build():
    build_command = "python setup.py sdist bdist_wheel"
    config["build_command"] = build_command
    result = should_build()
    assert result

    config["upload_to_release"] = False
    result = should_build()
    assert result

    config["upload_to_release"] = "false"
    result = should_build()
    assert result

    config["upload_to_pypi"] = False
    result = should_build()
    assert not result


# Generated at 2022-06-24 01:36:13.420006
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py build"
    assert should_build() == False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py build"
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py build"
    assert should_build() == True

    config["build_command"] = "false"
    assert should_build() == False



# Generated at 2022-06-24 01:36:22.063405
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['upload_to_pypi'] = 'true'
    config['upload_to_release'] = 'true'
    config['build_command'] = 'false'
    config['remove_dist'] = 'true'
    assert should_remove_dist() == False

    config['upload_to_pypi'] = 'false'
    config['upload_to_release'] = 'false'
    config['build_command'] = 'python setup.py sdist bdist_wheel'
    config['remove_dist'] = 'true'
    assert should_remove_dist() == True

    config['upload_to_pypi'] = 'true'
    config['upload_to_release'] = 'true'
    config['build_command'] = 'python setup.py sdist bdist_wheel'

# Generated at 2022-06-24 01:36:24.347059
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/a")

# Generated at 2022-06-24 01:36:24.948736
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:27.128162
# Unit test for function remove_dists
def test_remove_dists():
    assert should_build() == True
    assert should_remove_dist() == False
    assert should_build() == True
    # build_dists()
    # remove_dists()

# Generated at 2022-06-24 01:36:29.394418
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "ls"
    build_dists()
    assert True

# Generated at 2022-06-24 01:36:30.351289
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:36:39.127421
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should remove when upload_to_pypi and remove_dist are set to true
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist()

    # Should not remove when upload_to_pypi is set to false
    config["upload_to_pypi"] = False
    config["remove_dist"] = True
    assert not should_remove_dist()

    # Should not remove when remove_dist is set to false
    config["upload_to_pypi"] = True
    config["remove_dist"] = False
    assert not should_remove_dist()

    # Should not remove when upload_to_pypi and remove_dist are set to false
    config["upload_to_pypi"] = False
    config["remove_dist"] = False

# Generated at 2022-06-24 01:36:40.760793
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:41.423402
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:46.451770
# Unit test for function remove_dists
def test_remove_dists():
    from .temporary_directory import TemporaryDirectory
    with TemporaryDirectory() as tmp_dir:
        test_file = 'test.txt'
        run(f'echo "This is a test file" > {tmp_dir}/{test_file}')
        remove_dists(f'{tmp_dir}/*')
        command = f'ls {tmp_dir}/{test_file} 2> /dev/null'
        process = run(command, hide='both', warn=True)
        assert process.failed, 'Expected test file to be deleted'

# Generated at 2022-06-24 01:36:49.655266
# Unit test for function build_dists
def test_build_dists():
    """Test function build_dists
    """
    from .settings import SETTINGS
    config = SETTINGS
    config["build_command"] = "ls"
    build_dists()

# Generated at 2022-06-24 01:36:51.004025
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:36:59.472214
# Unit test for function should_build
def test_should_build():
    config['build_command'] = ''
    assert should_build() == False
    config['build_command'] = 'false'
    assert should_build() == False
    config['build_command'] = 'command'
    config['upload_to_release'] = False
    config['upload_to_pypi'] = False
    assert should_build() == False
    config['upload_to_release'] = True
    assert should_build() == True
    config['upload_to_release'] = False
    config['upload_to_pypi'] = True
    assert should_build() == True


# Generated at 2022-06-24 01:37:01.119738
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:37:08.317891
# Unit test for function remove_dists
def test_remove_dists():
    from tempfile import mkdtemp
    from pathlib import Path
    dir = mkdtemp()
    dir = Path(dir)
    (dir / "a.txt").touch()
    (dir / "b.txt").touch()
    remove_dists(dir)
    assert not dir.exists()

# Generated at 2022-06-24 01:37:13.786451
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist()

    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:16.983202
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except AttributeError:
        print("test_build_dists PASSED")
    else:
        print("test_build_dists FAILED")


# Generated at 2022-06-24 01:37:18.555600
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./project/")

# Generated at 2022-06-24 01:37:21.777324
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')

# Generated at 2022-06-24 01:37:23.030394
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception:
        pass

# Generated at 2022-06-24 01:37:23.918453
# Unit test for function should_build
def test_should_build():
    pass
    # TODO

# Generated at 2022-06-24 01:37:25.868343
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import TEST_CONFIG
    assert should_remove_dist() == True
    TEST_CONFIG["dist_path"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:34.918780
# Unit test for function should_build
def test_should_build():
    pypi_true_release_true_build_command_true = True
    pypi_true_release_true_build_command_false = False
    pypi_true_release_false_build_command_true = False
    pypi_false_release_true_build_command_true = False
    pypi_false_release_false_build_command_true = False

    assert (
        should_build()
        == pypi_true_release_true_build_command_true
    )
    config["upload_to_pypi"] = False
    assert (
        should_build()
        == pypi_false_release_true_build_command_true
    )
    config["upload_to_release"] = False

# Generated at 2022-06-24 01:37:37.133677
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf /tmp/build"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:37:42.005143
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "false")
    assert should_remove_dist() == True
    config.set("upload_to_pypi", "true")
    assert should_remove_dist() == True
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:42.942442
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./mymodule/dist")

# Generated at 2022-06-24 01:37:54.466869
# Unit test for function should_build
def test_should_build():
    build_command = "python setup.py bdist_wheel"
    upload_pypi = True
    upload_release = False

    assert should_build(build_command, upload_pypi, upload_release) is True
    upload_pypi = False
    assert should_build(build_command, upload_pypi, upload_release) is False
    upload_pypi = True
    upload_release = True
    assert should_build(build_command, upload_pypi, upload_release) is True
    upload_pypi = False
    assert should_build(build_command, upload_pypi, upload_release) is True
    build_command = False
    assert should_build(build_command, upload_pypi, upload_release) is False
    build_command = "true"

# Generated at 2022-06-24 01:37:55.011611
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:56.368298
# Unit test for function remove_dists
def test_remove_dists():
    path = "dists"
    remove_dists(path)

# Generated at 2022-06-24 01:37:57.789456
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")
    assert True

# Generated at 2022-06-24 01:38:01.041627
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['build_command'] = "build"
    config['upload_to_pypi'] = True
    config['upload_to_release'] = True
    config['remove_dist'] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:02.004288
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:03.338923
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    pass


# Generated at 2022-06-24 01:38:04.349808
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:07.116316
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:09.625832
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:38:10.748240
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:38:16.796324
# Unit test for function should_build
def test_should_build():
    config.override({
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": None,
    })
    assert(should_build() == False)

    config.override({
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "sdist"
    })
    assert(should_build() == True)

    config.override({
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "sdist"
    })
    assert(should_build() == True)


# Generated at 2022-06-24 01:38:17.646491
# Unit test for function remove_dists
def test_remove_dists():
    from .paths import build_path
    remove_dists(build_path)

# Generated at 2022-06-24 01:38:18.501066
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:38:23.337011
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'test'"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'test'"
    assert should_remove_dist() is False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_

# Generated at 2022-06-24 01:38:25.831161
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:38:26.712270
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:34.556751
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    assert should_build()

    config["upload_to_release"] = "true"
    assert should_build()

    config["build_command"] = "echo build"
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:38:35.961780
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:41.838868
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:43.042306
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:38:45.650490
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist())

# Generated at 2022-06-24 01:38:46.500828
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./tests/setup.py")

# Generated at 2022-06-24 01:38:48.364769
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception as e:
        raise AssertionError(e)

# Generated at 2022-06-24 01:38:51.505385
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:52.300845
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:52.970413
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist/")


# Generated at 2022-06-24 01:38:58.908376
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "ls -la"
    assert should_build() == True
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == True
    config["upload_to_release"] = False
    assert should_build() == False

# Generated at 2022-06-24 01:39:02.806365
# Unit test for function should_build
def test_should_build():
    assert not should_build()


# Generated at 2022-06-24 01:39:06.533569
# Unit test for function should_remove_dist
def test_should_remove_dist():
    remove_dist = True
    build = True
    assert should_remove_dist() == remove_dist and build
    remove_dist = False
    assert should_remove_dist() == remove_dist or build

# Generated at 2022-06-24 01:39:08.317905
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:39:09.658825
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('*')

# Generated at 2022-06-24 01:39:11.651251
# Unit test for function build_dists
def test_build_dists():
    import logzero

    logzero.loglevel(logging.DEBUG)
    build_dists()
    logzero.loglevel(logging.INFO)

# Generated at 2022-06-24 01:39:14.444195
# Unit test for function build_dists
def test_build_dists():
    build_dists()

