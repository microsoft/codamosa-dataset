

# Generated at 2022-06-24 01:29:21.964939
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist() is True

    config["build_command"] = "false"
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:29:22.591424
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:29:24.465579
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("dist") == None


# Generated at 2022-06-24 01:29:29.278712
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_build() == True


# Generated at 2022-06-24 01:29:33.004339
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:36.688346
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:29:43.417815
# Unit test for function should_build
def test_should_build():
    assert should_build(
        {"upload_to_pypi": True, "upload_to_release": True, "build_command": True}
    ) is True
    assert should_build(
        {"upload_to_pypi": True, "upload_to_release": False, "build_command": True}
    ) is True
    assert should_build(
        {"upload_to_pypi": False, "upload_to_release": True, "build_command": True}
    ) is True
    assert should_build(
        {"upload_to_pypi": False, "upload_to_release": False, "build_command": True}
    ) is True

# Generated at 2022-06-24 01:29:46.525239
# Unit test for function should_build
def test_should_build():
    should_build()



# Generated at 2022-06-24 01:29:49.633070
# Unit test for function remove_dists
def test_remove_dists():
    result = lambda: remove_dists("a")
    assert result == None
    assert result != Exception

# Generated at 2022-06-24 01:29:53.213531
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path = "../../dist")

# Generated at 2022-06-24 01:29:54.196697
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:29:59.896293
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    config.set("build_command", False)
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:30:03.636376
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True

# Generated at 2022-06-24 01:30:04.889086
# Unit test for function should_build
def test_should_build():
    pass



# Generated at 2022-06-24 01:30:07.995029
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:14.969971
# Unit test for function should_build
def test_should_build():
    from .settings import config
    from .utils import default_config

    # Build
    config.update(default_config)
    config.update({"upload_to_pypi": True})
    assert should_build()

    # Do not build
    config.update(default_config)
    config.update({"upload_to_pypi": False})
    config.update({"upload_to_release": False})
    config.update({"build_command": "echo false"})
    assert not should_build()

    # Build
    config.update(default_config)
    config.update({"build_command": "echo true"})
    config.update({"upload_to_release": True})
    assert should_build()

    # Do not build
    config.update(default_config)

# Generated at 2022-06-24 01:30:18.540562
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    path = tempfile.mkdtemp()
    remove_dists(path)
    import os
    assert not os.path.exists(path)

# Generated at 2022-06-24 01:30:23.473487
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    assert not should_build()
    config["upload_to_pypi"] = False
    assert not should_build()
    config["upload_to_release"] = False
    assert not should_build()
    config["upload_to_release"] = True
    config["build_command"] = "echo test"
    assert should_build()

# Generated at 2022-06-24 01:30:30.190514
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "false")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_build()

    config.set("build_command", "")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert not should_build()

    config.set("build_command", "")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert not should_build()

    config.set("build_command", "false")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert not should_

# Generated at 2022-06-24 01:30:34.707360
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "pip build"
    config["remove_dist"] = "true"
    assert should_remove_dist() is True
    config["build_command"] = "false"
    config["remove_dist"] = "true"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:30:44.890487
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist()



# Generated at 2022-06-24 01:30:51.086615
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True


# Generated at 2022-06-24 01:30:51.738850
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:31:02.630272
# Unit test for function should_remove_dist
def test_should_remove_dist():
    helper_config = {
        "remove_dist": True,
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "false"
    }
    assert should_remove_dist() is False, "shouldn't remove dist"

    helper_config = {
        "remove_dist": True,
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "false"
    }
    assert should_remove_dist() is False, "shouldn't remove dist"

    helper_config = {
        "remove_dist": True,
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "false"
    }

# Generated at 2022-06-24 01:31:03.919900
# Unit test for function remove_dists
def test_remove_dists():
    # GIVEN a path
    path = "."
    # WHEN calling remove_dists
    remove_dists(path)
    # THEN no exception should be thrown

# Generated at 2022-06-24 01:31:04.598659
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:06.377531
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:31:09.166121
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/some_project")

# Generated at 2022-06-24 01:31:11.254310
# Unit test for function should_build
def test_should_build():
    from .config import Development

    assert should_build() == True

    config = DevEnvironment()
    assert should_build() == False

# Generated at 2022-06-24 01:31:12.173536
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:31:16.996397
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config["build_command"] = "false"
    assert should_build() is False

    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() is False

    config["upload_to_pypi"] = True
    assert should_build() is True

    config["upload_to_pypi"] = False

    config["upload_to_release"] = True
    assert should_build() is True

# Generated at 2022-06-24 01:31:24.670026
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = dict(remove_dist=True,
                       upload_to_pypi=True,
                       upload_to_release=False,
                       build_command="build_command")
    config.update(test_config)
    assert should_remove_dist()
    config.update(dict(remove_dist=True,
                       upload_to_pypi=False,
                       upload_to_release=True,
                       build_command="build_command"))
    assert should_remove_dist()
    config.update(dict(remove_dist=True,
                       upload_to_pypi=False,
                       upload_to_release=False,
                       build_command="build_command"))
    assert not should_remove_dist()

# Generated at 2022-06-24 01:31:31.711277
# Unit test for function remove_dists
def test_remove_dists():
    from invoke import Context

    from .settings import config

    from . import tasks_utils as utils
    context = Context()
    c = config
    if c.get("upload_to_pypi"):
        assert utils.remove_dists(context, c.get("dist_pypi_path"))
    if c.get("upload_to_release"):
        assert utils.remove_dists(context, c.get("dist_release_path"))

# Generated at 2022-06-24 01:31:33.527258
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-24 01:31:36.157926
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/Users/johnny/Desktop/temp")

# Generated at 2022-06-24 01:31:40.621991
# Unit test for function remove_dists
def test_remove_dists():
    import pytest
    run = pytest.mock.MagicMock()
    remove_dists("somedir")
    assert run.called is True
    assert "rm -rf somedir" in run.call_args[0][0]
    run.assert_called_once()



# Generated at 2022-06-24 01:31:41.660308
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:31:43.639437
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:48.190922
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = False
    assert should_remove_dist() == False

    config['remove_dist'] = True
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    config['build_command'] = False
    assert should_remove_dist() == False

    config['remove_dist'] = True
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    config['build_command'] = True
    assert should_remove_dist() == True

    config['remove_dist'] = True
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    config['build_command'] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:50.914509
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    should_build()
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:51.854759
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True

# Generated at 2022-06-24 01:32:01.768992
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "/bin/build")
    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert  not should_remove_dist()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert not should_remove_dist()

    config.set("build_command", False)
    assert not should_remove_dist()

    config.set("build_command", "/bin/build")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()

# Generated at 2022-06-24 01:32:04.246874
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test/test_file")

# Generated at 2022-06-24 01:32:04.841924
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:05.904431
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:32:06.442361
# Unit test for function remove_dists
def test_remove_dists():
    assert 1



# Generated at 2022-06-24 01:32:12.884173
# Unit test for function build_dists
def test_build_dists():
    import os
    prefix = os.path.expanduser("~/test_dist_dir/")
    config_dict = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": f"python setup.py sdist bdist_wheel",
        "remove_dist": False,
        "dist_dir": f"{prefix}dist",
        "build_dir": f"{prefix}build"
    }
    config.update(config_dict)
    build_dists()
    assert os.path.exists(f"{prefix}dist/")

# Generated at 2022-06-24 01:32:16.384747
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.load_from_dict({"remove_dist": "true"})
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:32:19.275153
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = "true"
    config["build_command"] = "make build"
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:32:21.587883
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:23.089187
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:32:27.376866
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import load_settings
    from .utils import init_logging
    from .pathutils import get_dist_path

    settings = load_settings("test_remove_dists_settings.yml")
    settings["log_level"] = "debug"
    init_logging(settings)
    remove_dists(get_dist_path(settings))

# Generated at 2022-06-24 01:32:28.444950
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config.set("remove_dist", "True")
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:32:30.769883
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.update({"upload_to_pypi": "True", "upload_to_release": "True"})
    assert not should_build()
    config["build_command"] = "test"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()


# Generated at 2022-06-24 01:32:32.738867
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == False
    assert should_build() == True


# Generated at 2022-06-24 01:32:44.174867
# Unit test for function should_build
def test_should_build():
    # Should return True when all 3 parameters are set
    config_1 = {
        "build_command": "command",
        "upload_to_pypi": "pypi",
        "upload_to_release": "release",
    }
    config.update(config_1)
    assert should_build() is True

    # Should return True when build_command and upload_to_pypi are set
    config_2 = {
        "build_command": "command",
        "upload_to_pypi": "pypi",
        "upload_to_release": "false",
    }
    config.update(config_2)
    assert should_build() is True

    # Should return True when build_command and upload_to_release are set

# Generated at 2022-06-24 01:32:46.905366
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:32:48.288437
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")

# Generated at 2022-06-24 01:32:49.019924
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:32:55.427060
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == True
    config["upload_to_release"] = False
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
test_should_build()


# Generated at 2022-06-24 01:33:05.528449
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist() == True

    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist() == True

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist() == False

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "false"

# Generated at 2022-06-24 01:33:12.793604
# Unit test for function should_build
def test_should_build():
    assert all(map(lambda x: should_build() == x[0], [
        (True, {"upload_to_pypi": True, "upload_to_release": True}),
        (True, {"upload_to_pypi": True, "upload_to_release": False}),
        (True, {"upload_to_pypi": False, "upload_to_release": True}),
        (False, {"upload_to_pypi": False, "upload_to_release": False}),
    ]))



# Generated at 2022-06-24 01:33:16.161773
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Fixture for this test case
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    config["remove_dist"] = True

    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:19.226054
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "false")
    assert not should_remove_dist()
    config.set("remove_dist", "true")
    assert should_remove_dist()
    config.set("build_command", "false")
    assert not should_remove_dist()
    config.set("build_command", "echo")
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:21.756321
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    assert should_remove_dist("file1") is True
    assert should_remove_dist("file2") is True

# Generated at 2022-06-24 01:33:24.937042
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "pwd"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build()



# Generated at 2022-06-24 01:33:27.198121
# Unit test for function build_dists
def test_build_dists():
    command = config.get("build_command")
    logger.info(f"Running {command}")
    # run(command)



# Generated at 2022-06-24 01:33:28.809311
# Unit test for function remove_dists
def test_remove_dists():
    pass


# Generated at 2022-06-24 01:33:32.536650
# Unit test for function remove_dists
def test_remove_dists():
    # unit tests
    command = f"rm -rf ~/.local/share/virtualenvs/closure-publisher-*"
    logger.debug(f"Running {command}")
    run(command)


# Generated at 2022-06-24 01:33:41.214945
# Unit test for function should_build
def test_should_build():
    assert should_build()

    setattr(config, "upload_to_pypi", False)
    setattr(config, "upload_to_release", False)
    assert not should_build()

    setattr(config, "upload_to_pypi", True)
    assert should_build()

    setattr(config, "upload_to_pypi", False)
    setattr(config, "upload_to_release", True)
    assert should_build()

    setattr(config, "build_command", "false")
    assert not should_build()



# Generated at 2022-06-24 01:33:43.039252
# Unit test for function remove_dists
def test_remove_dists():
    invoke.run('touch test.txt')
    remove_dists('test.txt')


# Generated at 2022-06-24 01:33:53.133380
# Unit test for function should_build
def test_should_build():
    command = config.get("build_command")
    config.set("upload_to_pypi", "true") 
    config.set("upload_to_release", "false")
    config.set("build_command", "false")

    assert not should_build()
    config.set("upload_to_pypi", "true") 
    config.set("upload_to_release", "false")
    config.set("build_command", command)
    assert should_build()
    config.set("upload_to_pypi", "false") 
    config.set("upload_to_release", "true")
    config.set("build_command", command)
    assert should_build()
    config.set("upload_to_pypi", "true") 

# Generated at 2022-06-24 01:34:03.122423
# Unit test for function build_dists
def test_build_dists():
    import os
    import tempfile

    test_path = tempfile.mkdtemp()
    test_config = config
    test_config["build_command"] = os.path.join(test_path, "test_file")
    test_command = test_config["build_command"]

    build_dists()
    assert not os.path.isfile(test_command)

    with open(test_command, "a"):
        build_dists()
        assert os.path.isfile(test_command)
        # Cleanup
        os.remove(test_command)
        os.rmdir(test_path)

# Generated at 2022-06-24 01:34:04.308124
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('.')

# Generated at 2022-06-24 01:34:05.639603
# Unit test for function build_dists
def test_build_dists():
    #assert build_dists() == "dists built"
    pass

# Generated at 2022-06-24 01:34:14.929028
# Unit test for function build_dists
def test_build_dists():
    class InvokeResult(object):
        def __init__(self, exited):
            self.exited = exited

    class InvokeRunMock(object):
        def __init__(self):
            self.command = None
            self.result = None

        def __call__(self, command, **kwargs):
            self.command = command
            self.result = InvokeResult(0)
            return self.result

    invoke_run = InvokeRunMock()

    class ConfigMock(object):
        def get(self, key):
            assert key == "build_command"
            return "python setup.py sdist bdist_wheel"

    config_mock = ConfigMock()

    class LoggerMock(object):
        def __init__(self):
            self.log_msg = None


# Generated at 2022-06-24 01:34:15.751952
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:20.179323
# Unit test for function should_build
def test_should_build():
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    config["build_command"] = "ls"
    assert should_build() is True

# Generated at 2022-06-24 01:34:20.756545
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:24.710407
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil
    dist_path = "dist"
    if os.path.isdir(dist_path):
        shutil.rmtree(dist_path)
    os.mkdir(dist_path)
    assert os.path.exists(dist_path)
    remove_dists(dist_path)
    assert not os.path.exists(dist_path)

# Generated at 2022-06-24 01:34:25.860258
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:34:28.255578
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    # Set config['build_command'] to false
    config['build_command'] = 'false'
    assert should_build() == False


# Generated at 2022-06-24 01:34:29.527902
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")
    remove_dists("build")

# Generated at 2022-06-24 01:34:35.906129
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_remove_dist() is True
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:34:37.053266
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-24 01:34:39.174019
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:34:40.040619
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:41.470741
# Unit test for function build_dists
def test_build_dists():
    """Tests build_dists"""
    build_dists()



# Generated at 2022-06-24 01:34:42.546101
# Unit test for function build_dists
def test_build_dists():
    assert build_dists()


# Generated at 2022-06-24 01:34:43.575167
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:34:46.917626
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:34:47.905410
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:34:51.756935
# Unit test for function build_dists
def test_build_dists():
    print("Not implemented")
    # TODO: implement
    # Build the dists
    # Validate that the dist folder was created
    # Validate that the contents of the dist folder were created

# Generated at 2022-06-24 01:34:59.484010
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    assert should_build() is True
    config.set("upload_to_pypi", False)

    config.set("upload_to_release", True)
    assert should_build() is True
    config.set("upload_to_release", False)

    config.set("build_command", "false")
    assert should_build() is False
    config.set("build_command", "ls")

    assert should_build() is True



# Generated at 2022-06-24 01:35:05.807924
# Unit test for function remove_dists
def test_remove_dists():
    from .test_utils import assert_logging
    from .test_utils import assert_run
    from .test_utils import test_config
    test_config["remove_dist"] = True
    with assert_logging('debug', "Running rm -rf dist") as l:
        with assert_run("rm -rf dist"):
            remove_dists("dist")
    assert l.output == "DEBUG - Running rm -rf dist\n"
    test_config["remove_dist"] = False



# Generated at 2022-06-24 01:35:09.563162
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")

# Generated at 2022-06-24 01:35:10.587871
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()

# Generated at 2022-06-24 01:35:13.074850
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:19.465224
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build(), "Should return True when upload_to_pypi"

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build(), "Should return True when upload_to_release"

    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build(), "Should return False when build_command is false"

    config["build_command"] = "pip whatever"
    assert should_build(), "Should return True when build_command is not false"

# Generated at 2022-06-24 01:35:25.324679
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import config

    config["remove_dist"] = "true"
    config["dist_path"] = "dist"
    remove_dists(config["dist_path"])

    config["remove_dist"] = "false"
    config["dist_path"] = "dist"
    remove_dists(config["dist_path"])

# Generated at 2022-06-24 01:35:26.931287
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    # TODO: ensure that the dists folder exists

# Generated at 2022-06-24 01:35:28.497095
# Unit test for function build_dists
def test_build_dists():
    run("python3 -m invoke build_dists")



# Generated at 2022-06-24 01:35:31.279045
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "something"
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:33.820456
# Unit test for function build_dists
def test_build_dists():
    args = {'build_command': 'echo'}
    assert should_build() == True
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:35:45.704211
# Unit test for function should_build
def test_should_build():
    # should return True
    config.raw = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "any-command"
    }
    assert should_build() is True

    # should return True
    config.raw = {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "any-command"
    }
    assert should_build() is True

    # should return False
    config.raw = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "any-command"
    }
    assert should_build() is False

    # should return False

# Generated at 2022-06-24 01:35:46.227165
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:47.086413
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:35:48.546128
# Unit test for function remove_dists
def test_remove_dists():
    command = "ls"
    run(command)
    assert True

# Generated at 2022-06-24 01:35:52.847628
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:35:53.600001
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:35:57.248270
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:35:57.959299
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:36:02.327163
# Unit test for function build_dists
def test_build_dists():
    config['build_command'] = 'echo "123"'
    build_dists()


# Generated at 2022-06-24 01:36:12.872256
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config

# Generated at 2022-06-24 01:36:16.409098
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist() is True
    config["remove_dist"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = ""
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:36:20.936357
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Test unit for function should_remove_dist
    """
    config.set("remove_dist", "True")
    config.set("upload_to_pypi", "True")
    config.set("upload_to_release", "False")
    config.set("build_command", "False")
    assert should_remove_dist() is True

    config.set("remove_dist", "True")
    config.set("upload_to_pypi", "False")
    config.set("upload_to_release", "True")
    config.set("build_command", "False")
    assert should_remove_dist() is True

    config.set("remove_dist", "True")
    config.set("upload_to_pypi", "False")
    config.set("upload_to_release", "False")

# Generated at 2022-06-24 01:36:32.378718
# Unit test for function should_build
def test_should_build():
    # returns True when upload_to_pypi is True or upload_to_release is True
    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Build Distribution'"
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Build Distribution'"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True

# Generated at 2022-06-24 01:36:42.689774
# Unit test for function remove_dists
def test_remove_dists():
    from . import packaging
    from .files import find_files
    import tempfile
    import os
    import shutil

    tmpdir = tempfile.mkdtemp()

    keepdir = os.path.join(tmpdir, "keepdir")
    os.makedirs(keepdir)

    dummydir = os.path.join(tmpdir, "dummydir")
    os.makedirs(dummydir)

    dummmyfile = os.path.join(tmpdir, "dummyfile.txt")
    with open(dummmyfile, "w") as f:
        f.write("Dummy file")

    # Packaging.remove_dists should remove everything from tmpdir except keepdir
    packaging.remove_dists(tmpdir)
    assert len(find_files(tmpdir, "*", True)) == len

# Generated at 2022-06-24 01:36:46.350846
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:36:58.288535
# Unit test for function remove_dists
def test_remove_dists():
    from .helpers import temp_path
    from .settings import config
    from . import project
    from . import dists

    # This test only works if run in a directory with a 'setup.py' file
    config.load_project_config()
    config.set_project(project.get())
    config.set_remove_dist(True)

    # Fake project directory
    with temp_path() as path:
        with open(f"{path}/setup.py", "w") as f:
            f.write("# This is a fake file")
        # Create directory to delete
        run(f"mkdir {path}/dist")

        # Run function
        dists.remove_dists(f"{path}/dist")

    # Assert directory no longer exists

# Generated at 2022-06-24 01:37:00.548667
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".").return_value

# Generated at 2022-06-24 01:37:01.833693
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test_remove_test")

# Generated at 2022-06-24 01:37:10.013058
# Unit test for function build_dists
def test_build_dists():
    class MockConfig:
        def get(self, arg):
            if arg == "upload_to_pypi":
                return True
            if arg == "build_command":
                return "true"

    origconfig = config
    config = MockConfig()
    logger.info = lambda x: print(x)

    assert(should_build()) is True

    from . import dist
    dist.logger.info = logger.info
    dist.run = lambda x: None

    build_dists()
    config = origconfig

# Generated at 2022-06-24 01:37:10.972319
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-24 01:37:11.860661
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:37:12.753173
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:37:14.264649
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    config["build_command"] = "echo yo"
    build_dists()

# Generated at 2022-06-24 01:37:16.305015
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:37:20.651573
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir /tmp/tmpdir")
    test_path = "/tmp/tmpdir"
    assert (run(f"ls {test_path}").stdout) == ""
    remove_dists(test_path)
    assert (run(f"ls {test_path}").stdout) == ""



# Generated at 2022-06-24 01:37:23.318318
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist({"upload_to_pypi": True,
                               "remove_dist": True,
                               "build_command": "flask"}) is True


# Generated at 2022-06-24 01:37:24.444043
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf ./dist"
    run(command)



# Generated at 2022-06-24 01:37:25.896637
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:37:33.178414
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("upload_to_pypi", True)
    config.set("build_command", "true")
    assert should_build()
    config.set("upload_to_release", True)
    config.set("build_command", "true")
    assert should_build()
    config.set("upload_to_release", False)
    config.set("build_command", "true")
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("build_command", "false")
    assert not should_build()

# Generated at 2022-06-24 01:37:33.696014
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:34.483293
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()



# Generated at 2022-06-24 01:37:35.870741
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf test-dist"
    logger.debug(f"Running {command}")
    return True

# Generated at 2022-06-24 01:37:38.616898
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set_option("remove_dist", True)
    config.set_option("upload_to_pypi", True)
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:39.457630
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")
# End of unit test

# Generated at 2022-06-24 01:37:42.021441
# Unit test for function remove_dists
def test_remove_dists():
    # create a directory to remove
    import tempfile
    tempdir = tempfile.mkdtemp()
    remove_dists(tempdir)

# Generated at 2022-06-24 01:37:44.229557
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp")


# Generated at 2022-06-24 01:37:45.284222
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:48.793346
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:51.667983
# Unit test for function remove_dists
def test_remove_dists():
    try:
        remove_dists("build")
    except Exception as e:
        raise(e)
    remove_dists("build")

# Generated at 2022-06-24 01:37:52.691097
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:54.845546
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Test the should_remove_dist method
    """
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:37:56.567823
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()
    config['remove_dist'] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:57.555828
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:37:58.451723
# Unit test for function should_build
def test_should_build():
    assert should_build() is False


# Generated at 2022-06-24 01:38:08.507665
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "true"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = False
    assert not should_build()



# Generated at 2022-06-24 01:38:11.465304
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import config
    from .release import should_build, should_remove_dist, build_dists, remove_dists
    if should_build():
        build_dists()
    if should_remove_dist():
        remove_dists(config["build_path"])

# Generated at 2022-06-24 01:38:16.121971
# Unit test for function remove_dists
def test_remove_dists():
    path = "./tmp_folder"
    run(f"mkdir -p {path}")
    assert path in run("ls -A").stdout
    remove_dists(path)
    assert path not in run("ls -A").stdout

# Generated at 2022-06-24 01:38:27.877527
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = {"remove_dist": "true",
                   "upload_to_pypi": "true",
                   "upload_to_release": None,
                   "build_command": "flit build"}
    assert should_remove_dist(test_config), test_config
    test_config = {"remove_dist": "true",
                   "upload_to_pypi": None,
                   "upload_to_release": "true",
                   "build_command": "flit build"}
    assert should_remove_dist(test_config), test_config
    test_config = {"remove_dist": "true",
                   "upload_to_pypi": "true",
                   "upload_to_release": "true",
                   "build_command": "flit build"}
    assert should_remove_dist(test_config), test

# Generated at 2022-06-24 01:38:29.917943
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:38:37.175426
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    config["build_command"] = "pwd"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["build_command"] = False
    assert not should_remove_dist()


# Generated at 2022-06-24 01:38:38.001685
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:38:40.208703
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert should_remove_dist()
    assert remove_dists()
    assert build_dists()

# Generated at 2022-06-24 01:38:42.430663
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists is not None
    try:
        remove_dists("TESTING")
    except:
        assert False

# Generated at 2022-06-24 01:38:45.892103
# Unit test for function build_dists
def test_build_dists():
    try:
        config["build_command"] = "pwd"
        build_dists()
    except:
        raise
    finally:
        config["build_command"] = "python setup.py sdist bdist_wheel"

# Generated at 2022-06-24 01:38:47.757971
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:38:48.653065
# Unit test for function should_build
def test_should_build():
    assert should_build() == expected_value

# Generated at 2022-06-24 01:38:53.809344
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN
    config["build_command"] = "test"
    config["remove_dist"] = "test"
    # WHEN
    result = should_remove_dist()
    # THEN
    assert result is True

# Generated at 2022-06-24 01:38:57.686196
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:39:05.277625
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "test"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "test"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "test"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_build()

    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:39:11.743053
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "unit_tests.sh"
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = False
    assert not should_build()


# Tests for function build_dists

# Generated at 2022-06-24 01:39:17.366751
# Unit test for function should_build
def test_should_build():
    # Arrange
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    # Act
    result = should_build()
    # Assert
    assert result is False

