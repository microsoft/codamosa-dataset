

# Generated at 2022-06-24 01:29:14.189900
# Unit test for function remove_dists
def test_remove_dists():
    path = "../tests/data"
    remove_dists(path)

# Generated at 2022-06-24 01:29:19.642935
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "echo 'Hi'"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert not should_build()
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-24 01:29:20.836237
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:29:31.694809
# Unit test for function should_remove_dist
def test_should_remove_dist():
    print(" Test if it should remove the dist folder")
    config_for_remove_dist = {
        "remove_dist": "true",
        "upload_to_pypi": "true",
        "upload_to_release": "true"
    }
    assert(should_remove_dist(config_for_remove_dist) == True)
    print(" Test if it should remove the dist folder passed")
    config_for_remove_dist = {
        "remove_dist": "false",
        "upload_to_pypi": "true",
        "upload_to_release": "true"
    }
    assert(should_remove_dist(config_for_remove_dist) == False)
    print(" Test if it should remove the dist folder passed")

# Generated at 2022-06-24 01:29:40.603057
# Unit test for function should_build
def test_should_build():
    # upload_pypi is True and upload_release is False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    build_command = "./setup.py sdist bdist_wheel"
    config.set("build_command", build_command)
    assert should_build() == True
    # upload_pypi and upload_release are False
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_build() == False
    # upload_pypi is True, upload_release is True, build_command is False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)

# Generated at 2022-06-24 01:29:44.402938
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:51.524104
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "python setup.py sdist"
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True
    del config["upload_to_release"]
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True


# Generated at 2022-06-24 01:29:55.774780
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:29:57.123589
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True



# Generated at 2022-06-24 01:30:01.750991
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config.update({"remove_dist": True, "upload_to_pypi": False, "upload_to_release": False})
    assert not should_remove_dist()

    config.update({"remove_dist": True, "upload_to_pypi": True, "upload_to_release": True})
    assert should_remove_dist()

# Generated at 2022-06-24 01:30:12.282018
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from . import (  # noqa
        config,
        build_dists,
        remove_dists,
        should_remove_dist,
        should_build,
    )
    # Turn off building
    config["build_command"] = "false"
    assert not should_remove_dist()
    assert not should_build()

    # Turn on building
    config["build_command"] = "ls"
    assert not should_remove_dist()
    assert should_build()
    # Turn on removing
    config["build_command"] = "ls"
    config["remove_dist"] = "true"
    assert should_remove_dist()
    assert should_build()
    # Turn on removing, with a "false" string value
    config["build_command"] = "ls"
    config["remove_dist"] = "false"

# Generated at 2022-06-24 01:30:23.585432
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Check should be False if config is empty
    config.clear()
    assert not should_remove_dist()

    # Check should be False if build_command is False
    config.update({
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": False,
        "remove_dist": True,
    })
    assert not should_remove_dist()

    # Check should be True
    config.update({
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "/path/to/command",
        "remove_dist": True,
    })
    assert should_remove_dist()

# Generated at 2022-06-24 01:30:30.550833
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_release"] = True
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True
    config["build_command"] = False
    assert should_remove_dist() == False
    config["upload_to_release"] = False
    config["remove_dist"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:31.894888
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/path/to/dists")

# Generated at 2022-06-24 01:30:35.555744
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as dirname:
        for f in range(3):
            open(os.path.join(dirname, str(f)), 'w').close()
        remove_dists(dirname)
        assert not os.path.exists(dirname)

# Generated at 2022-06-24 01:30:37.952263
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:30:38.847391
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:30:40.161975
# Unit test for function should_build
def test_should_build():
    assert should_build() == config.get("build_command") != "false"

# Generated at 2022-06-24 01:30:44.910926
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()

    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()

    config["build_command"] = "echo 'Hello'"
    assert should_build()


# Generated at 2022-06-24 01:30:54.710878
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # in case of 'remove_dist=True', but 'upload_to_pypi=False', and
    # 'upload_to_release=False'
    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_remove_dist() is False

    # in case of 'remove_dist=True', and 'upload_to_pypi=True' and
    # 'upload_to_release=False'
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_remove_dist() is True

    # in case of 'remove_dist=True', and 'upload_to

# Generated at 2022-06-24 01:30:56.808406
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:30:58.034312
# Unit test for function should_build
def test_should_build():
    result = should_build()
    assert result is True


# Generated at 2022-06-24 01:31:01.516978
# Unit test for function remove_dists
def test_remove_dists():
    path = "blah"
    remove_dists(path)



# Generated at 2022-06-24 01:31:02.370189
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:31:09.649595
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import create_tmp_dir
    import os
    tmp_dir = create_tmp_dir()
    tmp_file = os.path.join(tmp_dir, "test.txt")
    with open(tmp_file, "w") as f:
        f.write("")
    remove_dists(tmp_dir)
    assert os.path.isdir(tmp_dir) is False
    assert os.path.isfile(tmp_file) is False

# Generated at 2022-06-24 01:31:10.629097
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:31:17.050559
# Unit test for function build_dists
def test_build_dists():
    import os

    os.environ["build_command"] = "false"
    assert should_build() is False

    os.environ["build_command"] = "echo hello world"
    assert should_build() is False

    os.environ["upload_to_pypi"] = "false"
    assert should_build() is False

    os.environ["upload_to_release"] = "false"
    assert should_build() is True

    os.environ["upload_to_pypi"] = "false"
    os.environ["upload_to_release"] = "false"
    assert should_build() is False

    os.environ["upload_to_pypi"] = "true"
    os.environ["upload_to_release"] = "true"
    assert should_build() is True




# Generated at 2022-06-24 01:31:19.134342
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-24 01:31:24.999082
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config["build_command"] = "hello"

    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert should_remove_dist()

    config["build_command"] = "false"
    config["remove_dist"] = "true"
    assert not should_remove_dist()

    config["build_command"] = "true"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:31:25.987633
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:31:26.857175
# Unit test for function should_build
def test_should_build():
    pass



# Generated at 2022-06-24 01:31:35.896070
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import pathlib
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    path = f"{tmp_dir}/my_dir"
    os.mkdir(path)
    pathlib.Path(f"{path}/file1").touch()
    pathlib.Path(f"{path}/file2").touch()
    pathlib.Path(f"{path}/file3").touch()
    assert os.listdir(path) == ["file1", "file2", "file3"]
    remove_dists(path)
    assert os.listdir(tmp_dir) == []
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-24 01:31:37.045366
# Unit test for function should_build
def test_should_build():
    assert should_build()
    assert not should_build()

# Generated at 2022-06-24 01:31:37.625818
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:31:38.561660
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path=".")

# Generated at 2022-06-24 01:31:48.478157
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["remove_dist"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

    config["build_command"] = "false"
    assert not should_remove_dist()



# Generated at 2022-06-24 01:31:49.769680
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:31:54.114859
# Unit test for function should_remove_dist
def test_should_remove_dist():
    build_command = True
    upload_pypi = upload_release = True
    assert should_remove_dist()

    build_command = False
    assert not should_remove_dist()

    build_command = True
    upload_pypi = upload_release = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:31:58.628968
# Unit test for function remove_dists
def test_remove_dists():
    logging.disable(logging.CRITICAL) # disable logs

    assert remove_dists("test") == None


# Generated at 2022-06-24 01:32:05.817578
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    for key in config:
        if key == "build_command":
            config[key] = "echo hello"
        elif key.startswith("upload_to"):
            config[key] = True
        else:
            config[key] = False
    assert should_build() is True

    config["build_command"] = "echo hello"
    config["upload_to_pypi"] = True
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True


# Generated at 2022-06-24 01:32:10.525069
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.settings["upload_to_release"] = "true"
    assert should_build() is False
    config.settings["build_command"] = "echo '123'"
    assert should_build() is True
    config.settings["upload_to_pypi"] = "true"
    assert should_build() is True



# Generated at 2022-06-24 01:32:12.970533
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.update({"build_command": "python setup.py sdist bdist_wheel"})
    assert should_build()


# Generated at 2022-06-24 01:32:18.470028
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "foobar")
    assert should_build() is True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_build() is False
    config.set("upload_to_pypi", True)
    assert should_build() is True
    config.set("upload_to_release", True)
    assert should_build() is True

# Generated at 2022-06-24 01:32:19.150873
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:32:21.876999
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('path')

# Generated at 2022-06-24 01:32:23.951289
# Unit test for function build_dists
def test_build_dists():
    config.update({"build_command": "echo 'foobar'"})
    build_dists()



# Generated at 2022-06-24 01:32:27.288621
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "true"
    config["build_command"] = "build_command"
    config["remove_dist"] = "true"
    result = should_remove_dist()
    assert result

# Generated at 2022-06-24 01:32:27.842524
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:28.725317
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:32:30.067493
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:32:37.362613
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config['upload_to_pypi'] = True
    assert should_build()
    config['upload_to_pypi'] = False
    assert not should_build()
    config['upload_to_release'] = True
    assert should_build()
    config['upload_to_release'] = False
    assert not should_build()
    config['build_command'] = "echo build"
    assert should_build()



# Generated at 2022-06-24 01:32:39.315311
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.data["remove_dist"] = "true"
    assert should_remove_dist()
    config.data["remove_dist"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:32:41.110779
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")



# Generated at 2022-06-24 01:32:42.688004
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:32:43.611415
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:32:47.214485
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:32:55.574097
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"upload_to_pypi": True})
    assert should_remove_dist()
    config.update({"upload_to_pypi": False})
    assert not should_remove_dist()
    config.update({"upload_to_release": True})
    assert should_remove_dist()
    config.update({"upload_to_release": False})
    assert not should_remove_dist()
    config.update({"build_command": "false"})
    assert not should_remove_dist()
    config.update({"build_command": "echo 'Build command'"})
    assert should_remove_dist()

# Generated at 2022-06-24 01:32:59.013691
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-24 01:33:02.765215
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    config["remove_dist"] = True

    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:09.414569
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    # No build command, should build
    config["build_command"] = False
    assert should_build() is False

    # No upload
    config["upload_to_pypi"] = False
    assert should_build() is False

    # Should build
    config["build_command"] = "python setup.py bdist_wheel"
    config["upload_to_pypi"] = True
    assert should_build() is True

    # Should build
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True

    # Should build
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:33:11.828260
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "setup")
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:20.046403
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Testing for true cases
    config.update({"upload_to_pypi": True, "remove_dist": True})
    assert should_remove_dist()

    config.update({"upload_to_release": True, "remove_dist": True})
    assert should_remove_dist()

    config.update({"upload_to_pypi": True, "upload_to_release": True,
                   "remove_dist": True})
    assert should_remove_dist()

    # Testing for false cases
    config.update({"upload_to_pypi": False, "remove_dist": True})
    assert not should_remove_dist()

    config.update({"upload_to_release": False, "remove_dist": True})
    assert not should_remove_dist()


# Generated at 2022-06-24 01:33:22.768511
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:24.212431
# Unit test for function should_build
def test_should_build():
    sut = should_build()
    assert sut is True

# Generated at 2022-06-24 01:33:29.320585
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False

    config.set("upload_to_pypi", True)
    config.set("build_command", "true")
    assert should_build() == True
    assert should_remove_dist() == False

    config.set("remove_dist", True)
    assert should_build() == True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:31.188864
# Unit test for function build_dists
def test_build_dists():
    logger.info("Building files")

# Generated at 2022-06-24 01:33:36.163157
# Unit test for function should_remove_dist
def test_should_remove_dist():
    cfg = {
        "remove_dist": "true",
        "upload_to_pypi": "true",
    }
    config.update(cfg)
    assert should_remove_dist()


# Generated at 2022-06-24 01:33:37.196318
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("some-path")

# Generated at 2022-06-24 01:33:37.888829
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert should_build()
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:45.981677
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is False
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "echo test build"
    assert should_build() is False
    config["upload_to_pypi"] = "true"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    assert should_build() is False
    config["upload_to_release"] = "true"
    assert should_build() is True
    config["upload_to_release"] = "false"
    assert should_build() is False

# Generated at 2022-06-24 01:33:49.370023
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:33:50.658164
# Unit test for function build_dists
def test_build_dists():
    assert should_build()



# Generated at 2022-06-24 01:33:53.711512
# Unit test for function build_dists
def test_build_dists():
    """
    >>> from .dist import build_dists
    >>> build_command = "echo 'hello'"
    >>> config["build_command"] = build_command
    >>> build_dists()
    Running echo 'hello'
    hello
    """



# Generated at 2022-06-24 01:34:05.147458
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "true"
    assert should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_build()
    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:34:13.992516
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_one = {"build_command": "python setup.py sdist", "upload_to_pypi": True,
                  "remove_dist": True, "upload_to_release": False}
    config_two = {"build_command": "python setup.py sdist", "upload_to_pypi": True,
                  "remove_dist": False, "upload_to_release": True}
    config_three = {"build_command": "python setup.py sdist", "upload_to_pypi": False,
                    "remove_dist": False, "upload_to_release": True}
    assert should_remove_dist(config=config_one) == True
    assert should_remove_dist(config=config_two) == True
    assert should_remove_dist(config=config_three) == False

# Generated at 2022-06-24 01:34:15.912774
# Unit test for function should_build
def test_should_build():
    # upload_to_pypi is true, upload_to_release is true, build_command is not
    # false (the default value)
    assert should_build()



# Generated at 2022-06-24 01:34:18.521812
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/dist")

# Generated at 2022-06-24 01:34:20.966678
# Unit test for function build_dists
def test_build_dists():
    config_dict = {"build_command": "ls"}
    build_dists()  # Will call run("ls")

# Generated at 2022-06-24 01:34:21.596830
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-24 01:34:30.356448
# Unit test for function should_remove_dist
def test_should_remove_dist():
    expected_remove_dist = False
    config["upload_to_pypi"] = False
    config["build_command"] = "false"
    config["remove_dist"] = True
    assert expected_remove_dist == should_remove_dist()

    expected_remove_dist = True
    config["upload_to_pypi"] = True
    config["build_command"] = "true"
    config["remove_dist"] = True
    assert expected_remove_dist == should_remove_dist()

# Generated at 2022-06-24 01:34:35.238916
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "test"
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["build_command"] = None
    config["remove_dist"] = None
    assert should_remove_dist() == False

    config["build_command"] = "test"
    config["remove_dist"] = False
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:34:38.028271
# Unit test for function build_dists
def test_build_dists():
    # there are no assert in this function
    build_dists()
    remove_dists()

# Generated at 2022-06-24 01:34:43.531716
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "some build command"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:34:49.441672
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.config["remove_dist"] = True
    assert should_remove_dist() is False
    config.config["build_command"] = "Some Command"
    config.config["upload_to_pypi"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:34:56.665358
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "build"
    assert should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-24 01:34:58.376750
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("example.txt")
    remove_dists("example")



# Generated at 2022-06-24 01:35:00.086491
# Unit test for function build_dists
def test_build_dists():
    command = 'echo "Building dists"'
    assert build_dists() == 'Building dists'


# Generated at 2022-06-24 01:35:02.786170
# Unit test for function build_dists
def test_build_dists():
    assert True == should_build()
    build_dists()
    assert True == should_remove_dist()
    remove_dists(path="dist")

# Generated at 2022-06-24 01:35:05.444355
# Unit test for function remove_dists
def test_remove_dists():
    with open("/tmp/test_test.txt", 'w') as file:
        file.write("test")

    remove_dists("/tmp/test*")
    assert True



# Generated at 2022-06-24 01:35:07.510082
# Unit test for function remove_dists
def test_remove_dists():
    path = "/Users/dmitrysvistunov/Documents/PycharmProjects/cicd-flow/build"
    remove_dists(path)

# Generated at 2022-06-24 01:35:16.883469
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test with remove_dist = false, upload_to_pypi = false, upload_to_release = false
    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    # Test with remove_dist = false, upload_to_pypi = true, upload_to_release = false
    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()

    # Test with remove_dist = false, upload_to_pypi = false, upload_to_release = true
    config["remove_dist"] = False
    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:35:19.024055
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist()
    remove_dists(path="dist")

# Generated at 2022-06-24 01:35:22.472444
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:23.770304
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")



# Generated at 2022-06-24 01:35:25.057625
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test")

# Generated at 2022-06-24 01:35:34.924228
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    assert should_remove_dist() is True

    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    assert should_remove_dist() is False
    config["upload_to_release"] = True
    assert should_remove_dist() is False
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False

    config["remove_dist"] = True
    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:35:35.916455
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:35:36.851592
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("")

# Generated at 2022-06-24 01:35:38.214187
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:35:49.315844
# Unit test for function should_build
def test_should_build():
    # Test should return false when no build command specified
    config["build_command"] = ""
    assert should_build() is False
    config["build_command"] = False
    assert should_build() is False
    config["build_command"] = "false"
    assert should_build() is False
    # Test should return false when no upload location specified
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False
    # Test should return true when upload location specified
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True


# Generated at 2022-06-24 01:35:52.728030
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:35:59.954763
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    config["build_command"] = "python3 setup.py --command-packages=stdeb.command sdist_dsc --debian-version 1.2.3 --suite bionic"
    result = should_remove_dist()
    assert result is True # noqa

# Generated at 2022-06-24 01:36:02.587544
# Unit test for function should_remove_dist
def test_should_remove_dist():
    result = should_remove_dist()
    assert str(result) == "True"


# Generated at 2022-06-24 01:36:08.325762
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    assert config.set("remove_dist", False) is None
    assert should_remove_dist() is False
    assert config.set("remove_dist", True) is None



# Generated at 2022-06-24 01:36:09.477805
# Unit test for function build_dists
def test_build_dists():
    assert not should_build()
    assert should_build() == False

# Generated at 2022-06-24 01:36:11.454667
# Unit test for function remove_dists
def test_remove_dists():
    command = "ls /"
    assert run(command, hide='out', warn=True).stdout != "dists\n"
    remove_dists("/dists")
    assert run(command, hide='out', warn=True).stdout != "dists\n"

# Generated at 2022-06-24 01:36:14.587900
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() is False
    assert should_build() is True

    build_dists()
    remove_dists("answers-release")

# Generated at 2022-06-24 01:36:24.479078
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    # missing
    config["remove_dist"] = None
    assert should_remove_dist() is False
    # empty string
    config["remove_dist"] = ""
    assert should_remove_dist() is False
    # disabled
    config["remove_dist"] = False
    assert should_remove_dist() is False


# Non unit tests
#
# These are more functional tests than unit tests.
# They depend on the presence of the configuration file.

# def test_should_build():
#     assert should_build() is True
#     # missing
#     config["build_command"] = None
#     assert should_build() is False
#     # empty string
#     config["build_command"] = ""
#     assert should_build() is False
#     # disabled
#     config

# Generated at 2022-06-24 01:36:28.698219
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:36:31.106155
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "foo"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()

# Generated at 2022-06-24 01:36:32.768522
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:36:35.862714
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:36:36.737241
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:36:38.618796
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:39.011006
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:36:43.357498
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import temp_dir
    from .files import create_files
    create_files(["__init__.py", "setup.py"], temp_dir)
    assert remove_dists(temp_dir)
    assert remove_dists("xxx") # should not raise exception

# Generated at 2022-06-24 01:36:48.866049
# Unit test for function build_dists
def test_build_dists():
    logger.debug("Testing build_dists")
    assert not should_build()
    config["build_command"] = "test_build_dists"
    assert should_build()
    build_dists()
    remove_dists("./dist")


if __name__ == "__main__":
    test_build_dists()

# Generated at 2022-06-24 01:36:50.428053
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-24 01:36:52.208804
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert bool(should_remove_dist()) == True


# Generated at 2022-06-24 01:36:52.889190
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:56.103102
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config["remove_dist"] = False
    assert should_remove_dist() is False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:36:59.665840
# Unit test for function remove_dists
def test_remove_dists():
    """Test remove_dists function"""
    import tempfile
    _, path = tempfile.mkstemp()
    remove_dists(path)
    import os
    assert os.path.isfile(path)

# Generated at 2022-06-24 01:37:03.110297
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build command"
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert should_remove_dist()
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:05.664889
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test")
    assert True

# Generated at 2022-06-24 01:37:06.911373
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()

# Generated at 2022-06-24 01:37:15.588240
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    assert not should_build()

    config["build_command"] = "echo 'TEST'"
    assert should_build()

    config["upload_to_pypi"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = "true"
    assert should_build()

    config["upload_to_release"] = "false"
    assert should_build()

    config["upload_to_release"] = "true"
    assert should_build()



# Generated at 2022-06-24 01:37:17.522481
# Unit test for function build_dists
def test_build_dists():
    assert build_dists(path="./") is None

# Generated at 2022-06-24 01:37:25.976417
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "some_command"
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = False
    assert not should_remove_dist()


# Generated at 2022-06-24 01:37:33.545643
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Unit test for function should_remove_dist
    """
    env = config.get_env()
    assert should_remove_dist() == env.get("remove_dist")
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    assert should_remove_dist() is False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["remove_dist"] = True
    assert should_remove_dist() is False
    config["upload_to_release"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:37:34.082164
# Unit test for function build_dists
def test_build_dists():
    assert True == True

# Generated at 2022-06-24 01:37:35.147351
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/foo")
    assert True

# Generated at 2022-06-24 01:37:41.901685
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import config
    from .utils.mock import MockContext
    from .utils.settings import TMP_DIR
    config.set("dist_path", TMP_DIR)
    c = MockContext()
    c.run(f"touch {TMP_DIR}/test.txt")
    remove_dists(TMP_DIR)
    assert not c.run(f"test -e {TMP_DIR}/test.txt", warn=True).failed
    assert not c.run(f"test -d {TMP_DIR}", warn=True).failed

# Generated at 2022-06-24 01:37:47.782545
# Unit test for function remove_dists
def test_remove_dists():
    import os
    from .context import PROJECT_ROOT

    path = os.path.join(PROJECT_ROOT, 'tmp.txt')
    f = open(path, "w+")
    f.close()

    assert os.path.isfile(path) == True
    remove_dists(path)
    assert os.path.isfile(path) == False

# Generated at 2022-06-24 01:37:48.758134
# Unit test for function remove_dists
def test_remove_dists():
    assert should_build() == True

# Generated at 2022-06-24 01:37:50.323478
# Unit test for function remove_dists
def test_remove_dists():
    # TODO
    pass

# Generated at 2022-06-24 01:37:51.811407
# Unit test for function build_dists
def test_build_dists():
    assert callable(build_dists)


# Generated at 2022-06-24 01:37:52.876771
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('.')

# Generated at 2022-06-24 01:37:55.013842
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True
    build_dists()
    assert should_remove_dist() is True
    remove_dists(path="dist")

# Generated at 2022-06-24 01:37:56.423139
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is not None



# Generated at 2022-06-24 01:38:07.326694
# Unit test for function should_build
def test_should_build():
    config["build_command"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = False
    assert should_build() == True
    config["build_command"] = True
    config["upload_to_pypi"] = False
    assert should_build() == True
    config["build_command"] = False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False


if __name__ == "__main__":
    test_should_build()

# Generated at 2022-06-24 01:38:11.245527
# Unit test for function remove_dists
def test_remove_dists():
    import os
    remove_dists("__pycache__")
    os.makedirs("__pycache__")
    remove_dists("__pycache__")


if __name__ == "__main__":
    test_remove_dists()

# Generated at 2022-06-24 01:38:15.320991
# Unit test for function should_remove_dist
def test_should_remove_dist():
    a = True
    b = False
    assert bool(should_remove_dist()) == True
    #assert bool(should_remove_dist()) == False

# Generated at 2022-06-24 01:38:18.697673
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-24 01:38:28.926742
# Unit test for function remove_dists
def test_remove_dists():
    # command = "cd /tmp ; rm -rf temp"
    # run (command)
    # 
    # command = "mkdir /tmp/temp"
    # run (command)
    # command = "mkdir /tmp/temp/temp1"
    # run (command)
    # command = "mkdir /tmp/temp/temp1/temp2"
    # run (command)
    # command = "touch /tmp/temp/temp1/temp2/temp3"
    # run (command)
    #
    # command = "ls -la /tmp/temp/temp1/temp2"
    # run (command)
    assert should_remove_dist()
    remove_dists (path="/tmp/temp")
    # command = "ls -la /tmp/temp"
    # run (command)

# Generated at 2022-06-24 01:38:37.146930
# Unit test for function should_build
def test_should_build():
    c = config.copy()
    c["upload_to_pypi"] = True
    c["build_command"] = "ls"
    assert should_build() == True

    c = config.copy()
    c["upload_to_release"] = True
    c["build_command"] = "ls"
    assert should_build() == True

    c = config.copy()
    c["upload_to_pypi"] = False
    c["upload_to_release"] = False
    c["build_command"] = "ls"
    assert should_build() == False

    c = config.copy()
    c["upload_to_pypi"] = True
    c["upload_to_release"] = False
    c["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-24 01:38:41.123269
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build(build_command=False) is False
    assert should_build(upload_to_pypi=False) is False
    assert should_build(upload_to_release=False) is False


# Generated at 2022-06-24 01:38:41.726619
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:38:44.115046
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True
    assert should_build() == True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:47.281340
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:38:52.766976
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    config['upload_to_release'] = ""
    config['upload_to_pypi'] = ""
    assert should_build() is False
    config['upload_to_release'] = "release"
    assert should_build() is True
    config['upload_to_pypi'] = "pypi"
    config['build_command'] = ""
    assert should_build() is False
    config['build_command'] = "pwd"
    assert should_build() is True


# Generated at 2022-06-24 01:39:01.997681
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # With default configuration
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "ls"
    assert should_remove_dist() == True
    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "ls"
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "ls"
    assert should_remove_dist() == True
    config["remove_dist"] = False

# Generated at 2022-06-24 01:39:03.087362
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('.') is None

# Generated at 2022-06-24 01:39:05.482259
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')
    assert not os.path.isdir('dist')

# Generated at 2022-06-24 01:39:08.622850
# Unit test for function build_dists
def test_build_dists():
    if should_build():
        build_dists()
        if should_remove_dist():
            remove_dists(path=config.get("build_dir"))

# Generated at 2022-06-24 01:39:09.395555
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:39:12.483025
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Arrange
    config["build_command"] = "false"
    config["upload_to_release"] = "false"
    config["upload_to_pypi"] = "false"

    # Act
    result = should_remove_dist()

    # Assert
    assert not result



# Generated at 2022-06-24 01:39:14.175703
# Unit test for function build_dists
def test_build_dists():
    build_dists()