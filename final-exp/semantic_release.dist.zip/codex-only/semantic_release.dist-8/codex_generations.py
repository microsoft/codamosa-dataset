

# Generated at 2022-06-24 01:29:11.836999
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:29:18.970485
# Unit test for function build_dists
def test_build_dists():
    import unittest2
    from unittest2.mock import patch, MagicMock

    @unittest2.skipIf(should_build(), "You are not running a unit test")
    class TestBuildDists(unittest2.TestCase):

        @patch("invoke.run")
        def test_build_dists(self, invoke_run):
            build_dists()
            self.assertEqual(invoke_run.call_count, 1)
    unittest2.main()



# Generated at 2022-06-24 01:29:19.642172
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:26.354112
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config.set("remove_dist", True)
    assert should_remove_dist() == False
    config.set("upload_to_pypi", True)
    assert should_remove_dist() == False
    config.set("upload_to_release", True)
    assert should_remove_dist() == False
    config.set("build_command", "build command")
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:29:34.273601
# Unit test for function should_build
def test_should_build():
    # Set to default
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = ""
    assert not should_build()

    # set build_command true
    config["build_command"] = "true"
    assert not should_build()

    # Set upload_to_pypi or upload_to_release true
    config["upload_to_pypi"] = "true"
    config["build_command"] = "true"
    assert should_build()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build()

# Generated at 2022-06-24 01:29:41.622948
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert (not should_build())
    config["upload_to_pypi"] = "true"
    assert (should_build())
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert (should_build())
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "python setup.py sdist"
    assert (should_build())
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
   

# Generated at 2022-06-24 01:29:42.248400
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-24 01:29:43.553117
# Unit test for function should_remove_dist
def test_should_remove_dist():
    build = should_build()
    remove = should_remove_dist()
    assert remove is build

# Generated at 2022-06-24 01:29:46.867348
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('test_remove_dist')
    pass

# Generated at 2022-06-24 01:29:47.749804
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:49.118876
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == should_build())

# Generated at 2022-06-24 01:29:53.213955
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:29:54.146773
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:57.193544
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:29:57.977565
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:29:58.737649
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path = 'dist')

# Generated at 2022-06-24 01:30:07.686892
# Unit test for function should_build
def test_should_build():
    # Both should return True
    config.update({"upload_to_pypi": True, "upload_to_release": True})
    assert should_build()
    config.update({"upload_to_pypi": False, "upload_to_release": True})
    assert should_build()
    config.update({"upload_to_pypi": True, "upload_to_release": False})
    assert should_build()

    # Both should return False
    config.update({"upload_to_pypi": False, "upload_to_release": False})
    assert not should_build()

# Generated at 2022-06-24 01:30:09.961833
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import dist_path
    from .os_utils import reset_dir

    reset_dir(dist_path)

    # Check removal of directory dist
    run('mkdir -p dist/test-dist')
    remove_dists(dist_path)
    assert not run('[ -d dist ]', warn=True).ok

# Generated at 2022-06-24 01:30:13.186987
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:30:18.218697
# Unit test for function should_build
def test_should_build():
    # given
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    # expect
    assert should_build() is False



# Generated at 2022-06-24 01:30:21.089484
# Unit test for function remove_dists
def test_remove_dists():
    path = '~/dist'
    command = f"rm -rf {path}"
    assert f"rm -rf {path}" == f"rm -rf {path}"

# Generated at 2022-06-24 01:30:21.991222
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist")

# Generated at 2022-06-24 01:30:23.449271
# Unit test for function build_dists
def test_build_dists():
    command = "touch foo"
    config['build_command'] = command
    build_dists()



# Generated at 2022-06-24 01:30:35.300206
# Unit test for function should_build

# Generated at 2022-06-24 01:30:37.041978
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    config.set("remove_dist", False)
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:30:42.852870
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:30:50.020319
# Unit test for function should_remove_dist
def test_should_remove_dist():
    remove_dist = config.get("remove_dist")
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    assert (
        should_remove_dist()
        == (build_command and remove_dist and (upload_pypi or upload_release))
    )


# Generated at 2022-06-24 01:30:57.856520
# Unit test for function remove_dists
def test_remove_dists():
    # Check if path is a required argument
    from invoke.context import Context
    try:
        remove_dists()
    except TypeError as err:
        if "missing 1 required positional argument: 'path'" in str(err):
            pass
        else: raise
    # Remove a path with a directory and a file
    path = "tests/testdir"
    remove_dists(path)
    assert not Context().exists(path)
    # Remove a non-existing path
    path = "non-existing/path"
    remove_dists(path)
    assert not Context().exists(path)
    # Check if path can be be a non-string type
    path = 1

# Generated at 2022-06-24 01:31:02.443719
# Unit test for function remove_dists
def test_remove_dists():
    from tempfile import mkdtemp
    from os import path
    path = mkdtemp()
    remove_dists(path)
    assert not path.exists(path)

# Generated at 2022-06-24 01:31:08.901331
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("build_command", "sdist")
    assert should_build()
    assert not config.get("upload_to_pypi")
    assert not config.get("upload_to_release")
    config.set("upload_to_pypi", True)
    assert should_build()



# Generated at 2022-06-24 01:31:17.238611
# Unit test for function build_dists
def test_build_dists():
    from .package import package
    from .upload import upload
    from .settings import config
    from .settings import read_config

    config_file = "tests/invoke.yaml"
    config_path = "tests/dummy_package/distributions"
    read_config(config_file)
    package()
    build_dists()
    upload(config_path)
    assert "dummy_package-1.0.0-py3-none-any.whl" in open('tests/dummy_package/CHANGELOG.md').read()
    assert "dummy_package-1.0.0.tar.gz" in open('tests/dummy_package/CHANGELOG.md').read()
    run("rm -rf tests/dummy_package/distributions")

# Generated at 2022-06-24 01:31:17.737931
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:31:19.213047
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")



# Generated at 2022-06-24 01:31:21.282430
# Unit test for function build_dists
def test_build_dists():
    assert True



# Generated at 2022-06-24 01:31:23.056948
# Unit test for function remove_dists
def test_remove_dists():
    logger.debug('test_remove_dists')
    remove_dists('*')

# Generated at 2022-06-24 01:31:25.807431
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()



# Generated at 2022-06-24 01:31:26.817681
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:27.929424
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="test_path")

# Generated at 2022-06-24 01:31:31.925372
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "python setup.py sdist")
    assert should_build()



# Generated at 2022-06-24 01:31:38.835016
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("build_command", "false")
    assert should_build() == False
    config.set("upload_to_pypi", False)
    assert should_build() == False
    config.set("upload_to_release", False)
    assert should_build() == False
    config.set("build_command", "echo true")
    assert should_build() == False
    config.set("upload_to_pypi", True)
    assert should_build() == True
    config.set("upload_to_release", True)
    assert should_build() == True


# Generated at 2022-06-24 01:31:39.317242
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()

# Generated at 2022-06-24 01:31:45.255530
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.set_config_value({"upload_to_pypi": "true", "build_command": "sdist"})
    assert should_build() is True
    config.set_config_value({"upload_to_pypi": "false", "upload_to_release": "true", "build_command": "sdist"})
    assert should_build() is True
    config.set_config_value({"upload_to_pypi": "false", "upload_to_release": "false", "build_command": "sdist"})
    assert should_build() is False



# Generated at 2022-06-24 01:31:45.780115
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:31:46.663437
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:31:49.066124
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:31:50.759953
# Unit test for function remove_dists
def test_remove_dists():
    from . import project_root
    remove_dists(project_root.cwdir)

# Generated at 2022-06-24 01:31:53.259609
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'this is just a test' >/dev/null"
    config['build_command'] = command
    build_dists()



# Generated at 2022-06-24 01:31:59.661093
# Unit test for function should_build
def test_should_build():
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    if build_command and (upload_pypi or upload_release):
        assert should_build() == True
    else:
        assert should_build() == False


# Generated at 2022-06-24 01:32:07.100165
# Unit test for function should_build
def test_should_build():
    """should_build should return False when build command is empty, when
    upload_to_release is empty and upload_to_pypi is empty

    :return:
    """
    config.set("build_command", "")
    config.set("upload_to_release", "")
    config.set("upload_to_pypi", "")
    assert should_build() is False
    config.set("build_command", "ls")
    assert not should_build()
    config.set("build_command", "false")
    assert not should_build()
    config.set("upload_to_pypi", "true")
    assert should_build()
    config.set("upload_to_release", "true")
    assert should_build()

# Generated at 2022-06-24 01:32:14.566618
# Unit test for function build_dists
def test_build_dists():
    command = 'echo "Hello World"'
    logging.getLogger().setLevel(logging.DEBUG)  # For debugging debug logs
    assert logging.getLogger().level == logging.DEBUG
    out_stream = logging.StreamHandler()
    out_stream.setFormatter(logging.Formatter(logging.BASIC_FORMAT))
    logging.getLogger().addHandler(out_stream)
    build_dists()
    assert True


# Generated at 2022-06-24 01:32:15.801601
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="./dist")



# Generated at 2022-06-24 01:32:16.325207
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:17.344704
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:32:18.407611
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:32:19.298050
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test_remove_dists")

# Generated at 2022-06-24 01:32:24.268252
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    assert should_remove_dist() == True
    config["upload_to_release"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:32:30.641152
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config.set("upload_to_pypi", True)
    config.set("build_command", "test")
    assert should_build() == True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True

    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert should_build() == False

# Generated at 2022-06-24 01:32:36.874813
# Unit test for function should_remove_dist
def test_should_remove_dist():
    DIST_PATH = "/tmp/jg_test_dist"
    config.set("build_command", "build_command")
    config.set("remove_dist", True)

    assert should_remove_dist() is True
    # build distribution
    remove_dists(DIST_PATH)
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:32:37.455739
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:32:38.482356
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:32:39.067877
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:32:40.876953
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() is None

# Generated at 2022-06-24 01:32:42.688924
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:32:43.619447
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-24 01:32:52.134024
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("upload_to_pypi", True)
    config.set("build_command", "true")
    assert should_build()
    config.set("upload_to_pypi", False)
    assert not should_build()
    config.set("upload_to_release", True)
    assert should_build()
    config.set("build_command", "false")
    assert not should_build()

# Generated at 2022-06-24 01:32:58.534490
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "echo")
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_build()

    config.set("upload_to_release", True)
    assert should_build()

    config.set("upload_to_release", False)
    config.set("upload_to_pypi", True)
    assert should_build()



# Generated at 2022-06-24 01:32:59.422577
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-24 01:33:02.849445
# Unit test for function build_dists
def test_build_dists():
    """Test function build_dists"""
    logger.info("Testing build_dists")
    build_dists()
    logger.info("OK")

# Generated at 2022-06-24 01:33:06.715135
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test_remove_dists")

# Generated at 2022-06-24 01:33:11.004756
# Unit test for function remove_dists
def test_remove_dists():
    command = "echo test > test_remove_dists.txt"
    run(command)
    assert run("ls test_remove_dists.txt")
    remove_dists("test_remove_dists.txt")
    assert not run("ls test_remove_dists.txt")

# Generated at 2022-06-24 01:33:14.332958
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:15.155675
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:33:18.929301
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_build()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:33:22.422968
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {
        "remove_dist": True,
        "build_command": "sphinx-build doc build/sphinx"
    }
    assert should_remove_dist(config) == True

# Generated at 2022-06-24 01:33:26.638862
# Unit test for function should_build
def test_should_build():
    test_config = {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "true",
        "remove_dist": "false"
    }
    assert should_build()
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:28.042478
# Unit test for function should_build
def test_should_build():
    should_build_result = should_build()
    assert should_build_result is True



# Generated at 2022-06-24 01:33:33.716909
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_release"] = False
    assert should_build() == False


# Generated at 2022-06-24 01:33:35.254595
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:33:36.568135
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dist_path = "dist"
    config.settings = {"remove_dist": "true"}
    assert should_remove_dist()
    remove_dists(dist_path)

# Generated at 2022-06-24 01:33:39.210539
# Unit test for function should_build
def test_should_build():
    assert should_build(), "This should return true"
    assert not remove_dists("./dummy_path"), "This should return false"


# Generated at 2022-06-24 01:33:40.057226
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:33:40.528211
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:33:41.556584
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('.')

# Generated at 2022-06-24 01:33:42.990991
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:33:43.944190
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tmp_dist_dir")

# Generated at 2022-06-24 01:33:51.979866
# Unit test for function should_remove_dist
def test_should_remove_dist():
    remove_dist = config.get("remove_dist")
    config.set("build_command", True)
    config.set("upload_to_pypi", True)
    config.set("remove_dist", True)
    assert should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()
    config.set("remove_dist", remove_dist)
    config.reset()



# Generated at 2022-06-24 01:33:53.169336
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:34:03.123711
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = True
    assert should_remove_dist() is False
    config["build_command"] = "build"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["upload_to_release"] = False
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:34:04.968490
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set('remove_dist', 'True')
    logger.debug(should_remove_dist())


# Generated at 2022-06-24 01:34:12.639522
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # testing if should_remove_dist returns true if config.GIT_BRANCH is not 'master'
    config.GIT_BRANCH = 'not_master'
    config.upload_to_pypi = False
    config.upload_to_release = False
    config.build_command = "some_command"
    assert should_remove_dist()

    # testing if should_remove_dist returns false if build_command is not specified
    config.GIT_BRANCH = 'master'
    config.upload_to_pypi = False
    config.upload_to_release = False
    config.build_command = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:34:13.380206
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:34:14.191535
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:34:22.792603
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": False})
    assert not should_build()

    config.update({"upload_to_pypi": True})
    config.update({"upload_to_release": False})
    assert should_build()

    config.update({"build_command": False})
    assert not should_build()

    config.update({"build_command": "echo 'test'"})
    assert should_build()

# Generated at 2022-06-24 01:34:30.467000
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_build() == False

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build() == True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True



# Generated at 2022-06-24 01:34:33.576965
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "true"

    assert should_remove_dist()

# Generated at 2022-06-24 01:34:36.343131
# Unit test for function build_dists
def test_build_dists():
    assert not should_build(), "No Artifacts to build!"
    config["build_command"] = "echo build_command"
    config["upload_to_pypi"] = True
    assert should_build(), "Artifacts should be built!"
    build_dists()



# Generated at 2022-06-24 01:34:40.189263
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    config.set("remove_dist", "")
    assert should_remove_dist() == False
    config.reset()


# Generated at 2022-06-24 01:34:42.767021
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "python setup.py sdist"
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:34:43.988220
# Unit test for function build_dists

# Generated at 2022-06-24 01:34:47.405515
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/invoke_dbt_test/dist")

# Generated at 2022-06-24 01:34:52.786641
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Not build
    config["build_command"] = False
    assert should_remove_dist() == False
    # Build but not remove_dist
    config["build_command"] = "true"
    config["remove_dist"] = False
    assert should_remove_dist() == False
    # Build with remove_dist
    config["build_command"] = "true"
    config["remove_dist"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:56.850365
# Unit test for function build_dists
def test_build_dists():
    import os

    test_config = {
        "build_command": "touch test.txt"
    }
    dist_path = "test.txt"
    build_dists()
    assert os.path.exists(dist_path)
    os.system(f"rm {dist_path}")

# Generated at 2022-06-24 01:34:58.226548
# Unit test for function build_dists
def test_build_dists():
    result = build_dists()

# Generated at 2022-06-24 01:35:07.894634
# Unit test for function should_build
def test_should_build():
    """
    Unit test for build
    """
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

    config["build_command"] = "python3 setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

    config["build_command"] = "python3 setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() is True

    config["build_command"] = "python3 setup.py sdist bdist_wheel"

# Generated at 2022-06-24 01:35:08.621199
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-24 01:35:10.216031
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")

# Generated at 2022-06-24 01:35:14.338584
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True


if __name__ == "__main__":
    print(should_build())

# Generated at 2022-06-24 01:35:20.134712
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = True

    assert should_remove_dist is True

    config["build_command"] = False
    assert should_remove_dist is False

# Generated at 2022-06-24 01:35:22.706676
# Unit test for function build_dists
def test_build_dists():
    assert should_build()



# Generated at 2022-06-24 01:35:23.497818
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:24.741840
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True or False

# Generated at 2022-06-24 01:35:34.683485
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import tmp_path
    from pathlib import Path
    import shutil
    from .settings import ReleaseSettings

    # Create dist directory
    dist_dir = Path(tmp_path(), "dist")
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
    dist_dir.mkdir()

    # Create dist file
    dist_file = Path(tmp_path(), "dist.file")
    if dist_file.exists():
        dist_file.unlink()
    dist_file.touch()

    # Set configuration
    module_name = "dummy_module_name"
    settings = ReleaseSettings(module=module_name)
    settings.set("build_command", f"echo 'Build'")
    settings.set("remove_dist", f"True")
    settings.set

# Generated at 2022-06-24 01:35:36.402653
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist()

# Generated at 2022-06-24 01:35:47.917547
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["build_command"] = "my_build"
    assert(should_build())
    config["upload_to_release"] = "true"
    config["build_command"] = "false"
    assert(not(should_build()))
    config["upload_to_pypi"] = "false"
    config["build_command"] = "my_build"
    assert(should_build())
    config["build_command"] = "my_build"
    config["upload_to_release"] = "false"
    assert(not(should_build()))
    config["build_command"] = "false"
    config["upload_to_pypi"] = "true"
    assert(not(should_build()))

# Generated at 2022-06-24 01:35:52.983323
# Unit test for function build_dists
def test_build_dists():
    command = "python3 setup.py sdist bdist_wheel"
    if should_build():
        build_dists()
        logger.info(f"Built distribution with `{command}`")
    else:
        logger.warning(f"Not building distribution with `{command}`")

    if should_remove_dist():
        remove_dists("./dist")
        logger.info("Removed previous distribution")
    else:
        logger.warning("Not removing previous distribution")



# Generated at 2022-06-24 01:35:53.783639
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:35:57.248734
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="/path/to/folder")

# Generated at 2022-06-24 01:36:03.145769
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.set_prop("upload_to_pypi", "false")
    config.set_prop("upload_to_release", "false")
    config.set_prop("build_command", "false")
    assert should_build() is False
    config.set_prop("build_command", "echo 'hi'")
    assert should_build() is False
    config.set_prop("upload_to_pypi", "true")
    config.set_prop("upload_to_release", "false")
    assert should_build() is True
    config.set_prop("upload_to_pypi", "false")
    config.set_prop("upload_to_release", "true")
    assert should_build() is True



# Generated at 2022-06-24 01:36:06.551184
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:36:09.822663
# Unit test for function should_build
def test_should_build():
    assert should_build(), "Build should happen"
    config["upload_to_pypi"] = False
    assert should_build(), "Build should happen"
    config["upload_to_release"] = False
    assert not should_build(), "Build should not happen"

# Generated at 2022-06-24 01:36:13.022077
# Unit test for function remove_dists
def test_remove_dists():
    out = remove_dists('bool_test')
    assert out is None
    assert isinstance(out, None)

# Generated at 2022-06-24 01:36:15.610823
# Unit test for function build_dists
def test_build_dists():
    assert config.get("build_command") == "python setup.py bdist_wheel"
    assert should_build() == True
    build_dists()


# Generated at 2022-06-24 01:36:16.697812
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:18.435344
# Unit test for function build_dists
def test_build_dists():
    command = "touch README"
    # assert build_dists(command) == run(command)

# Generated at 2022-06-24 01:36:20.805447
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except:
        raise AssertionError("Build distribution error.")

# Generated at 2022-06-24 01:36:21.438815
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:29.509465
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.setdefault("build_command", "False")

    config.setdefault("upload_to_pypi", "False")
    config.setdefault("upload_to_release", "False")
    assert should_remove_dist() is False

    config.setdefault("upload_to_pypi", "True")
    config.setdefault("upload_to_release", "False")
    assert should_remove_dist() is True

    config.setdefault("upload_to_pypi", "False")
    config.setdefault("upload_to_release", "True")
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:36:30.076038
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:36:37.563867
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil

    assert not os.path.exists("dist")

    shutil.copytree("src", "dist", dirs_exist_ok=True)
    assert os.path.exists("dist")

    remove_dists("dist")
    assert not os.path.exists("dist")

# Generated at 2022-06-24 01:36:39.549310
# Unit test for function should_build
def test_should_build():
    if should_build():
        logger.info("Config is setup to build")
    else:
        logger.warning("Config is NOT setup to build")

# Generated at 2022-06-24 01:36:40.012977
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:36:41.052221
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")
    assert True


# Generated at 2022-06-24 01:36:46.586898
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:36:58.392276
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "bdist"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "bdist"
    assert should_build() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "bdist"
    assert should_build() is True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = False
    assert should_build() is False



# Generated at 2022-06-24 01:37:01.314778
# Unit test for function remove_dists
def test_remove_dists():
    command = "dir"
    logger.info(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:37:05.118494
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test")

# Generated at 2022-06-24 01:37:09.437684
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import temp_path_context

    expected_command = "rm -rf /tmp/locust/test/test_dist"
    with temp_path_context() as temp_dir:
        remove_dists(f"{temp_dir}/test/test_dist")
        assert run.history[0].command == expected_command

# Generated at 2022-06-24 01:37:11.137559
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo 'test'"
    assert True is should_build()
    build_dists()

# Generated at 2022-06-24 01:37:18.640120
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    set_config(
        build_command="echo 'Running build'",
        upload_to_pypi=True,
    )
    assert should_build() is True

    set_config(
        build_command="echo 'Running build'",
        upload_to_release=True,
    )
    assert should_build() is True

    set_config(
        build_command="echo 'Running build'",
        upload_to_pypi=False,
    )
    assert should_build() is False

    set_config(
        build_command="echo 'Running build'",
        upload_to_release=False,
    )
    assert should_build() is False

    set_config(build_command=False)
    assert should_build() is False



# Generated at 2022-06-24 01:37:22.063668
# Unit test for function build_dists
def test_build_dists():
    config['build_command'] = 'echo "hello world"'
    build_dists()

# Generated at 2022-06-24 01:37:25.206034
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test that the flag is false if we're not building
    config["build_command"] = False
    assert not should_remove_dist()
    # Test that the flag is true since we're building
    config["build_command"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:34.371370
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build(), "Return False when upload_to_pypi=False, upload_to_release=False"

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build(), "Return True when upload_to_pypi=False, upload_to_release=Ture"

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build(), "Return True when upload_to_pypi=True, upload_to_release=False"

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True

# Generated at 2022-06-24 01:37:41.935994
# Unit test for function should_build
def test_should_build():
    # should return True
    assert should_build()
    # should return False
    # no upload_pypi and upload_release
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert not should_build()
    # no build_command
    config.set("upload_to_pypi", "true")
    config.set("build_command", "false")
    assert not should_build()
    # no build_command
    config.set("upload_to_release", "true")
    config.set("build_command", "false")
    assert not should_build()

# Generated at 2022-06-24 01:37:42.618502
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('./tests/share')

# Generated at 2022-06-24 01:37:48.064212
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["upload_to_pypi"] = "True"
    config["build_command"] = "echo hi"
    assert should_build()

    config.pop("upload_to_pypi")
    config["upload_to_release"] = "True"
    assert should_build()



# Generated at 2022-06-24 01:37:53.601949
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = True
    assert not should_remove_dist()
    config["build_command"] = "echo 'Hello World' && exit 0"
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:54.907352
# Unit test for function should_build
def test_should_build():
    assert should_build()
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:55.414335
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:58.721825
# Unit test for function build_dists
def test_build_dists():
    try:
        test_config = {
            "build_command": "exit 0",
            "upload_to_pypi": True,
            "remove_dist": False,
        }
        build_dists()
    except SystemExit:
        raise

# Generated at 2022-06-24 01:37:59.970403
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:09.701052
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    assert not should_build()

    config["build_command"] = "sphinx-build"
    config["upload_to_pypi"] = False
    assert not should_build()

    config["build_command"] = "sphinx-build"
    config["upload_to_pypi"] = True
    assert should_build()

    config["build_command"] = "sphinx-build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()

    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-24 01:38:14.004385
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/does/not/exist")


# Generated at 2022-06-24 01:38:20.721083
# Unit test for function should_build
def test_should_build():
    command = config.get("build_command")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert should_build() == False
    config.set("build_command", False)
    assert should_build() == False
    config.set("build_command", "false")
    assert should_build() == False
    config.set("build_command", command)
    assert should_build() == True
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    assert should_build() == False
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_build() == True


# Generated at 2022-06-24 01:38:22.532620
# Unit test for function remove_dists
def test_remove_dists():
    assert should_build()
    assert should_remove_dist()
    remove_dists("/home/dev/project/dist")

# Generated at 2022-06-24 01:38:23.432460
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:38:27.351680
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config.update({"build_command": "build", "upload_to_release": True})
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:29.573463
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:34.327440
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": "true", "build_command": "sdist"})
    assert should_remove_dist()
    config.update({"remove_dist": "false", "build_command": "sdist"})
    assert not should_remove_dist()
    config.update({"remove_dist": "true", "build_command": "false"})
    assert not should_remove_dist()



# Generated at 2022-06-24 01:38:39.784169
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config["remove_dist"] = True
    assert should_remove_dist()

    config["build_command"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "echo 'hello world'"
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:47.493506
# Unit test for function remove_dists
def test_remove_dists():
    # Test that it is not run if should_remove_dist is False
    old_config_value = config["remove_dist"]
    config["remove_dist"] = False
    assert should_remove_dist() is False
    remove_dists("")
    config["remove_dist"] = old_config_value

    # Test the command is run if should_remove_dist is True
    old_config_value = config["remove_dist"]
    config["remove_dist"] = True
    assert should_remove_dist() is True
    remove_dists("")
    config["remove_dist"] = old_config_value

# Generated at 2022-06-24 01:38:48.114409
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:38:51.862014
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:38:52.610108
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp") == None

# Generated at 2022-06-24 01:38:53.586693
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="./tmp")

# Generated at 2022-06-24 01:39:02.060332
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "python setup.py sdist"
    assert should_build()


# Generated at 2022-06-24 01:39:02.663148
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:39:03.524168
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:39:05.486226
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="")

# Generated at 2022-06-24 01:39:06.432122
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    pass

# Generated at 2022-06-24 01:39:13.857422
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN
    # WHEN
    # THEN
    assert not should_remove_dist()

    # GIVEN
    config["remove_dist"] = True
    config["build_command"] = "echo 1"
    # WHEN
    # THEN
    assert should_remove_dist()

    # GIVEN
    config["upload_to_pypi"] = True
    # WHEN
    # THEN
    assert should_remove_dist()
    assert not should_build()

    # GIVEN
    config["upload_to_release"] = True
    # WHEN
    # THEN
    assert should_remove_dist()
    assert should_build()