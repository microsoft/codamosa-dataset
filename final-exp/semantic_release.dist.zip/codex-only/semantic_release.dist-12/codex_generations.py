

# Generated at 2022-06-24 01:29:15.702705
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build"
    should_build()

    config["build_command"] = False
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-24 01:29:22.865816
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = {
        "build_command": "build",
        "upload_to_pypi": True,
        "remove_dist": True,
    }
    assert should_remove_dist(test_config) is True

    test_config = {
        "build_command": "build",
        "upload_to_pypi": True,
        "remove_dist": False,
    }
    assert should_remove_dist(test_config) is False

# Generated at 2022-06-24 01:29:28.302909
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "true")
    config.set("build_command", "python setup.py sdist bdist_wheel")
    assert(should_build())

    config.set("upload_to_pypi", "false")
    assert (not should_build())


if __name__ == "__main__":
    test_should_build()

# Generated at 2022-06-24 01:29:29.278883
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tests/dist")

# Generated at 2022-06-24 01:29:34.054857
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:29:41.475788
# Unit test for function should_build
def test_should_build():
    from .settings import Configuration
    from .settings import ConfigType
    from .settings import BoolType
    from .settings import StringType

    config_test = Configuration(
      upload_pypi=BoolType(False),
      upload_to_release=BoolType(False),
      build_command=StringType(False),
      remove_dist=BoolType(False),
      **ConfigType["project"].value
    )
    assert should_build() is False
    config_test = Configuration(
      upload_pypi=BoolType(True),
      upload_to_release=BoolType(True),
      build_command=StringType(True),
      remove_dist=BoolType(True),
      **ConfigType["project"].value
    )
    assert should_build() is True

# Generated at 2022-06-24 01:29:42.028143
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("testpath")

# Generated at 2022-06-24 01:29:43.223935
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": True})
    assert should_build() == True

# Generated at 2022-06-24 01:29:46.950320
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('my-folder') == None



# Generated at 2022-06-24 01:29:56.840851
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "some_command"
    assert should_build() == False

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "false"

# Generated at 2022-06-24 01:29:57.764309
# Unit test for function remove_dists
def test_remove_dists():
    command = "ls"
    assert command == "ls"

# Generated at 2022-06-24 01:29:59.518019
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo 1234"
    build_dists()



# Generated at 2022-06-24 01:30:04.642875
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'hello'"
    config.set("build_command", command)
    build_dists()
    config.set("build_command", False)


# Generated at 2022-06-24 01:30:14.028219
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = None
    config["upload_to_pypi"] = None
    config["upload_to_release"] = None

    assert should_remove_dist() is False

    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False

    assert should_remove_dist() is True

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True

    assert should_remove_dist() is True



# Generated at 2022-06-24 01:30:15.410284
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:30:23.547929
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Tests should_remove_dist with config values
    """
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["remove_dist"] = False
    assert should_remove_dist() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["remove_dist"] = True
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:24.532354
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:30:27.378224
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:30:29.583218
# Unit test for function build_dists
def test_build_dists():
    command = "inv builddists"
    logger.info(f"Running {command}")
    run(command)



# Generated at 2022-06-24 01:30:32.466837
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True


# Generated at 2022-06-24 01:30:38.101470
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    config.set("build_command", "build_com")
    assert should_remove_dist() is False
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist() is False
    config.set("upload_to_pypi", True)
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:30:39.755280
# Unit test for function remove_dists
def test_remove_dists():
    logger.debug("Testing remove dists")
    remove_dists("/tmp/example/dist")

# Generated at 2022-06-24 01:30:40.656041
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:30:41.246465
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() == None


# Generated at 2022-06-24 01:30:47.424860
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({
        "upload_to_pypi": True,
        "remove_dist": True,
        "build_command": "setup.py sdist bdist_wheel"
    })
    assert should_remove_dist() == True

    config.update({
        "upload_to_pypi": False,
        "upload_to_release": True,
        "remove_dist": True,
        "build_command": "setup.py sdist bdist_wheel"
    })
    assert should_remove_dist() == True

    config.update({
        "upload_to_pypi": True,
        "upload_to_release": True,
        "remove_dist": True,
        "build_command": False
    })
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:30:56.818827
# Unit test for function should_build
def test_should_build():
    config_build = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "test",
        "remove_dist": True,
    }
    config["build"] = config_build
    assert should_build()

    config_build = {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "test",
        "remove_dist": True,
    }
    config["build"] = config_build
    assert should_build()

    config_build = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": None,
        "remove_dist": True,
    }
    config["build"] = config

# Generated at 2022-06-24 01:30:57.723598
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:31:04.520438
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.init(
        {
            "alpha": {
                "upload_to_pypi": False,
                "upload_to_release": True,
                "build_command": "build",
                "remove_dist": True
            }
        }, "alpha"
    )
    config.configure()
    assert should_remove_dist()

    config.init(
        {
            "beta": {
                "upload_to_pypi": False,
                "upload_to_release": False,
                "build_command": "build",
                "remove_dist": True
            }
        }, "beta"
    )
    config.configure()
    assert not should_remove_dist()


# Generated at 2022-06-24 01:31:05.009155
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:05.741964
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:09.271873
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    remove_dists('./dist')

# Generated at 2022-06-24 01:31:10.311235
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True


# Generated at 2022-06-24 01:31:10.894905
# Unit test for function remove_dists
def test_remove_dists():
    return None

# Generated at 2022-06-24 01:31:12.183757
# Unit test for function remove_dists
def test_remove_dists():
    test_path = "./dist"
    remove_dists(test_path)

# Generated at 2022-06-24 01:31:15.625360
# Unit test for function remove_dists
def test_remove_dists():
    try:
        run("mkdir -p dist/test")
    except:
        pass
    assert "dist/test" in run("ls dist/", hide="out")
    remove_dists("dist/test")
    assert "dist/test" not in run("ls dist/", hide="out")

# Generated at 2022-06-24 01:31:24.289189
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", False)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "wibble")
    assert should_remove_dist() is False

    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "wibble")
    assert should_remove_dist() is False

    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "wibble")

# Generated at 2022-06-24 01:31:25.947499
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:31:26.817609
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:31:28.947810
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert not should_remove_dist()
    build_dists()

# Generated at 2022-06-24 01:31:30.621909
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf {path}"
    assert command == f"rm -rf {path}"

# Generated at 2022-06-24 01:31:34.106075
# Unit test for function build_dists
def test_build_dists():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as tmp:
        test_file = os.path.join(tmp, "test")
        command = f"touch {test_file}"
        config["build_command"] = command
        build_dists()
        assert os.path.exists(test_file)


# Generated at 2022-06-24 01:31:38.296313
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:38.766983
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:31:48.350009
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "python3 setup.py sdist"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "python3 setup.py sdist"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "python3 setup.py sdist"


# Generated at 2022-06-24 01:31:50.614084
# Unit test for function remove_dists
def test_remove_dists():
    build_dists()
    remove_dists("dist")
    assert True

# Generated at 2022-06-24 01:31:51.676185
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:31:54.114714
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Unit test to check the functionality of should_remove_dist.
    """
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:31:59.377978
# Unit test for function build_dists
def test_build_dists():
    command = "touch dist.txt"
    logger.info(f"Running {command}")
    run(command)
    command = "rm dist.txt"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:32:05.974675
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    # Not an empty build command
    config["build_command"] = "hello"
    assert should_build() == False

    # Upload to pypi is false but upload to release is
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    assert should_build() == True

    # Now upload both to pypi and release
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    assert should_build() == True


# Generated at 2022-06-24 01:32:09.218812
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist() == True

    config.set("remove_dist", False)
    config.set("upload_to_pypi", False)
    assert should_remove_dist() == False

    config.set("remove_dist", False)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:32:18.103361
# Unit test for function should_build
def test_should_build():
    # GIVEN
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    # WHEN
    actual = should_build()
    # THEN
    assert actual is True

    # GIVEN
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    # WHEN
    actual = should_build()
    # THEN
    assert actual is True

    # GIVEN
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True

# Generated at 2022-06-24 01:32:24.356151
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf ./dist/test*"
    run(command)
    command = f"mkdir -p ./dist/test"
    run(command)
    command = f"touch ./dist/test/test_file"
    run(command)
    remove_dists("./dist")
    assert run(f"ls ./dist/test").failed

# Generated at 2022-06-24 01:32:25.924179
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    # assert output == True

# Generated at 2022-06-24 01:32:26.891805
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True



# Generated at 2022-06-24 01:32:28.143222
# Unit test for function should_build
def test_should_build():
    assert not should_build(), "should_build() should return False"

# Generated at 2022-06-24 01:32:28.603744
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist/")

# Generated at 2022-06-24 01:32:29.025591
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:32:30.155784
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:32:31.162660
# Unit test for function remove_dists
def test_remove_dists():
    assert bool(remove_dists) is True

# Generated at 2022-06-24 01:32:32.823101
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == False)  # test on default config



# Generated at 2022-06-24 01:32:33.783890
# Unit test for function remove_dists
def test_remove_dists():
  assert remove_dists("dist")

# Generated at 2022-06-24 01:32:36.825305
# Unit test for function build_dists
def test_build_dists():
    assert(should_build())
    build_dists()


# Generated at 2022-06-24 01:32:42.680281
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("build_command", "true")
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    assert should_remove_dist()
    config.set("upload_to_pypi", "false")
    assert should_remove_dist()
    config.set("upload_to_release", "false")
    assert not should_remove_dist()

# Generated at 2022-06-24 01:32:43.584226
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:32:52.805401
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "true"
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()



# Generated at 2022-06-24 01:33:04.028825
# Unit test for function build_dists
def test_build_dists():
    import os
    from .settings import config
    from .settings import cache
    from .settings import CONFIG_FILE_NAME
    from .utils import get_temp_folder_name
    from .utils import get_temp_config_file_name
    from .utils import get_temp_cache_file_name
    # Create temporary folder and config file
    temp_folder = get_temp_folder_name(parent=".")
    temp_config_file = get_temp_config_file_name(parent=temp_folder)
    temp_cache_file = get_temp_cache_file_name(parent=temp_folder)
    os.makedirs(temp_folder, exist_ok=True)
    open(temp_config_file, "w").close()
    os.environ["TEST_CONFIG_FILE_NAME"] = temp_config

# Generated at 2022-06-24 01:33:06.524963
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-24 01:33:15.985849
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": False, "upload_to_release": False, "build_command": "some build command"})
    assert should_build() is False
    config.update({"upload_to_pypi": False, "upload_to_release": False, "build_command": ""})
    assert should_build() is False
    config.update({"upload_to_pypi": True, "upload_to_release": False, "build_command": "some build command"})
    assert should_build() is True
    config.update({"upload_to_pypi": True, "upload_to_release": True, "build_command": "some build command"})
    assert should_build() is True

# Generated at 2022-06-24 01:33:17.548584
# Unit test for function should_build
def test_should_build():
    result = should_build()
    expected = False
    assert result == expected

# Generated at 2022-06-24 01:33:18.105569
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:22.124778
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = bool(True)
    config["upload_to_release"] = bool(True)
    config["build_command"] = bool(True)
    assert should_build() == bool(True)

# Generated at 2022-06-24 01:33:23.090165
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:23.591580
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:25.312516
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:32.904922
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "sdist"
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["upload_to_pypi"] = "false"
    assert not should_remove_dist()
    config["upload_to_release"] = "true"
    assert should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()


# Generated at 2022-06-24 01:33:34.570252
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:33:35.507919
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:33:36.529262
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tests/dist")

# Generated at 2022-06-24 01:33:37.192883
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:38.826004
# Unit test for function remove_dists
def test_remove_dists():
    path = "./tests/{dist_path}"
    path_structure = path.format(dist_path="delme-path")
    run(f"mkdir {path_structure}")
    remove_dists(path)
    assert not run(f"test -d {path_structure}", warn=True).failed

# Generated at 2022-06-24 01:33:46.845970
# Unit test for function remove_dists
def test_remove_dists():
    # Test proper removal of dist folder
    from .tempdir import get_temporary_directory
    from .utils import discover_paths

    with get_temporary_directory() as tmpdir:
        temp_dists_dir = tmpdir.join("dists")
        temp_dists_dir.mkdir()
        temp_dists_dir.join("fake.txt").write("Fake file")
        remove_dists(temp_dists_dir.strpath)
        assert len(list(discover_paths(temp_dists_dir.strpath))) == 0



# Generated at 2022-06-24 01:33:50.532283
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    # TODO: Add more tests here

# Generated at 2022-06-24 01:33:51.492334
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:52.588950
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:33:55.593863
# Unit test for function should_remove_dist
def test_should_remove_dist():
    print(should_remove_dist())



# Generated at 2022-06-24 01:33:56.462917
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("test")

# Generated at 2022-06-24 01:33:58.014180
# Unit test for function build_dists
def test_build_dists():
    assert not should_build()
    assert not should_remove_dist()

# Generated at 2022-06-24 01:34:03.074801
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
    config["build_command"] == "false"
    assert should_build() == False


# Generated at 2022-06-24 01:34:10.380543
# Unit test for function should_build
def test_should_build():
    """Test should_build"""
    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    config["build_command"] = False
    assert not should_build()
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    config["build_command"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    config["build_command"] = True
    assert not should_build()

# Generated at 2022-06-24 01:34:14.499905
# Unit test for function remove_dists
def test_remove_dists():
    from .test_config import parsed_config
    config.update(parsed_config)
    remove_dists("./dist")

# Generated at 2022-06-24 01:34:18.755313
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf {path}"
    assert command == remove_dists("{path}")

# Generated at 2022-06-24 01:34:25.369679
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "echo 'hello'"
    config["upload_to_pypi"] = True
    assert should_remove_dist()

    config["build_command"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "echo 'hello'"
    config["upload_to_pypi"] = "false"
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    assert not should_remove_dist()

    config["upload_to_release"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:34:31.373454
# Unit test for function should_build
def test_should_build():
    # True
    config.data["upload_to_pypi"] = True
    config.data["upload_to_release"] = True
    config.data["build_command"] = "false"
    assert not should_build()
    config.data["build_command"] = "true"
    assert should_build()
    # False
    config.data["upload_to_pypi"] = False
    config.data["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-24 01:34:41.318291
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["build_command"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert not should_remove_dist()
    config["build_command"] = "false"

# Generated at 2022-06-24 01:34:42.314609
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:34:46.039751
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build"] = "true"
    config["remove_dist"] = "true"
    assert should_remove_dist() == True
    config["remove_dist"] = "false"
    assert should_remove_dist() == False
    config["build"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:34:54.427788
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("upload_to_pypi", True)
    assert should_remove_dist()

    assert not should_remove_dist()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    assert not should_remove_dist()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    assert not should_remove_dist()


# Generated at 2022-06-24 01:35:00.168360
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True
    assert should_remove_dist() is True
    logger.info("Testing build_dists function")
    # Adding a fake dist folder to ensure it's removed
    run("mkdir -p ./dist")
    build_dists()
    assert run("ls dist", hide=True).ok is True
    remove_dists("./dist")
    assert run("ls dist", hide=True).ok is False

# Generated at 2022-06-24 01:35:00.823562
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:02.743126
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    # assert should_build() == False

# Generated at 2022-06-24 01:35:05.046324
# Unit test for function build_dists
def test_build_dists():
    build = should_build()
    if build:
        build_dists()
    else:
        logger.info("No build commands found")



# Generated at 2022-06-24 01:35:08.805955
# Unit test for function should_build
def test_should_build():
    config.params["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
    config.params["build_command"] = "false"
    assert should_build() == False
    config.params["build_command"] = "true"
    config.params["upload_to_pypi"] = True
    assert should_build() == True

# Generated at 2022-06-24 01:35:10.720871
# Unit test for function remove_dists
def test_remove_dists():
    path = 'testpath'
    remove_dists(path)
    print("success")

# Generated at 2022-06-24 01:35:13.074395
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:35:17.468844
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config["build_command"] = "echo hello world"
    assert should_build() is False

    config["upload_to_release"] = True
    assert should_build() is True

    config["upload_to_release"] = False
    assert should_build() is False

    config["upload_to_pypi"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:35:18.567184
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:20.875407
# Unit test for function build_dists
def test_build_dists():
    run("pip install invoke")  # Just in case invoke is not installed
    assert should_build() == False
    build_dists()
    assert should_build() == False

# Generated at 2022-06-24 01:35:32.056866
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = ""
    result = should_remove_dist()
    assert result == False, "Should return False"

    config["remove_dist"] = "false"
    result = should_remove_dist()
    assert result == False, "Should return False"

    config["remove_dist"] = "true"
    result = should_remove_dist()
    assert result == False, "Should return False"

    config["remove_dist"] = "true"
    config["build_command"] = "test"
    result = should_remove_dist()
    assert result == False, "Should return False"

    config["remove_dist"] = "true"
    config["build_command"] = "test"
    config["upload_to_pypi"] = "true"
    result = should_remove_dist()
    assert result

# Generated at 2022-06-24 01:35:34.742415
# Unit test for function build_dists
def test_build_dists():
    """Test if it runs the build command
    """
    from .settings import config_dict
    config.update(config_dict)
    build_dists()



# Generated at 2022-06-24 01:35:46.518546
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_build({"upload_to_pypi": False}) == False
    assert should_build({"build_command": "mybuild -n --bdist"}) == True
    assert should_build({"upload_to_release": True}) == True
    assert should_build({"upload_to_release": True,
                         "upload_to_pypi": True}) == True
    assert should_build({"upload_to_release": True,
                         "upload_to_pypi": False}) == True
    assert should_build({"upload_to_release": False,
                         "upload_to_pypi": True}) == True

# Generated at 2022-06-24 01:35:47.759853
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert bool(should_remove_dist()) == True



# Generated at 2022-06-24 01:35:50.729899
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should return False with no remove_dist in config
    assert should_remove_dist() == False

    # Should return True with remove_dist set to True
    config["remove_dist"] = True
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:35:52.550152
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {
        "remove_dist": False
    }
    assert should_remove_dist(config) is False

# Generated at 2022-06-24 01:35:53.557976
# Unit test for function build_dists
def test_build_dists():
    build_command = "echo"
    config.update({"build_command": build_command})
    build_dists()



# Generated at 2022-06-24 01:35:58.300788
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:36:03.044975
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf tests/tests_data/dist"
    remove_dists("tests/tests_data/dist")
    assert run(command).ok == True

# Generated at 2022-06-24 01:36:12.925410
# Unit test for function build_dists
def test_build_dists():
    import inspect
    import unittest
    from unittest.mock import patch

    class Test(unittest.TestCase):
        def setUp(self):
            super().setUp()
            self.build_dists = globals()["build_dists"]

        def tearDown(self):
            super().tearDown()
            del self.build_dists

        @patch("invoke.run")
        def test_build_dists(self, patched):
            command = "echo hello"
            config = {"build_command": command}
            self.build_dists(config)
            patched.assert_called_once_with(command)


# Generated at 2022-06-24 01:36:14.002509
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists(".")

# Generated at 2022-06-24 01:36:15.060305
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp/test") == None

# Generated at 2022-06-24 01:36:15.672454
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:27.242327
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "echo 'Build'"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo 'Build'"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "echo 'Build'"
    assert should_build() is False
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"

# Generated at 2022-06-24 01:36:33.169919
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import tempdir, touch
    from os.path import join

    def _remove_dists(inp: dict):
        with tempdir(inp) as tmpdir:
            touch(join(tmpdir, inp["file"]))
            remove_dists(tmpdir)

    values = [
        {
            "file": "test.txt"
        }
    ]
    for value in values:
        yield _remove_dists, value

# Generated at 2022-06-24 01:36:36.818224
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "pwd"
    build_dists()
    assert 1 == 1


# Generated at 2022-06-24 01:36:47.038802
# Unit test for function should_build
def test_should_build():
    config.data = {'build_command': True, 'upload_to_pypi': True}
    assert should_build() == True

    config.data = {'build_command': True, 'upload_to_release': True}
    assert should_build() == True

    config.data = {'build_command': False, 'upload_to_release': True}
    assert should_build() == False

    config.data = {'build_command': False, 'upload_to_pypi': True}
    assert should_build() == False

    config.data = {'build_command': True, 'upload_to_release': False}
    assert should_build() == False

    config.data = {'build_command': True, 'upload_to_pypi': False}
    assert should_build() == False

   

# Generated at 2022-06-24 01:36:52.441891
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:58.187475
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import tempdir
    from .settings import config
    with tempdir() as td:
        config.set("remove_dist : true")
        build_dists = td / "build"
        build_dists.mkdir()
        build_dists = str(build_dists)
        remove_dists(build_dists)
        print(td.listdir())
        assert not (td / "build")

# Generated at 2022-06-24 01:37:00.548618
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:37:01.199504
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:08.598923
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    assert not should_remove_dist()
    config["upload_to_release"] = True
    assert should_remove_dist()



# Generated at 2022-06-24 01:37:10.007311
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:15.293896
# Unit test for function should_build
def test_should_build():
    build_command = "true"
    upload_pypi = True
    upload_release = True

    assert should_build() == False

    config["build_command"] = build_command
    assert should_build() == False

    config["upload_to_pypi"] = upload_pypi
    assert should_build() == False

    config["upload_to_release"] = upload_release
    assert should_build() == True

# Generated at 2022-06-24 01:37:25.164349
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    This function will test if config.yml is correctly using remove_dist and
    build_command options.

    The tests are as follow:
    remove_dist=false, build_command=true
    remove_dist=false, build_command=false
    remove_dist=true, build_command=true
    remove_dist=true, build_command=false
    """

    # remove_dist=false
    config["remove_dist"] = "false"
    result = should_remove_dist()
    assert result is False

    # build_command=false
    config["build_command"] = "false"
    result = should_remove_dist()
    assert result is False

    # remove_dist=true, build_command=false
    config["remove_dist"] = "true"
    result = should_remove_dist()


# Generated at 2022-06-24 01:37:27.025777
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    should_remove_dist()

# Generated at 2022-06-24 01:37:29.496479
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path='~/src/repos/my_project')


# Generated at 2022-06-24 01:37:32.746997
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:33.545230
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:36.640205
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_release"] = True

    assert should_build()



# Generated at 2022-06-24 01:37:39.907708
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # When remove_dist is false, should_remove_dist should always return false
    assert should_remove_dist() is True

    config.set("remove_dist", False)
    assert should_remove_dist() is False
    assert should_build() is True


# Generated at 2022-06-24 01:37:42.102238
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "python3 setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:42.709180
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:44.417377
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:37:45.520520
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:37:55.646588
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["remove_dist"] = "false"
    config["build_command"] = "false"
    assert not should_remove_dist()

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["remove_dist"] = "true"
    config["build_command"] = "ls"
    assert should_remove_dist()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["remove_dist"] = "true"
    config["build_command"] = "ls"
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:00.995624
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        os.mkdir("dist")
        os.mkdir("build")
        remove_dists(os.path.join(tmpdirname, "dist"))
        remove_dists(os.path.join(tmpdirname, "build"))
        # This should not throw an exception
        assert True

# Generated at 2022-06-24 01:38:11.183066
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.clear()
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "setup.py"

    assert(should_remove_dist())

    # remove_dist is False
    config["remove_dist"] = False
    assert(not should_remove_dist())

    # upload_to_pypi is False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert(should_remove_dist())

    # upload_to_release is False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert(not should_remove_dist())

# Generated at 2022-06-24 01:38:11.919200
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:14.760754
# Unit test for function remove_dists
def test_remove_dists():
    # testing with a fake path
    remove_dists("/fake/path")

# Generated at 2022-06-24 01:38:15.835221
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist("remove_dist") == False



# Generated at 2022-06-24 01:38:20.962540
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:38:21.801384
# Unit test for function should_build
def test_should_build():
    assert(should_build())



# Generated at 2022-06-24 01:38:22.332084
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:38:23.189223
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-24 01:38:26.017392
# Unit test for function should_build
def test_should_build():
    assert should_build() == config.get("build_command")



# Generated at 2022-06-24 01:38:26.874142
# Unit test for function remove_dists
def test_remove_dists():
    # TODO: implement unit test
    pass

# Generated at 2022-06-24 01:38:31.470919
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception as e:
        assert False, e



# Generated at 2022-06-24 01:38:32.098946
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:38:32.648919
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:38:36.276597
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build() is True
    assert should_build() is True
    assert should_build() is True

# Generated at 2022-06-24 01:38:37.277196
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:44.701027
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Check if remove_dist is not a boolean
    config.set("remove_dist", "foo")
    assert should_remove_dist() == True

    # Check if remove_dist is True and build is True
    config.set("remove_dist", True)
    assert should_remove_dist() == True

    # Check if remove_dist is False and build is True
    config.set("remove_dist", False)
    assert should_remove_dist() == False

    # Clean up
    config.set("remove_dist", "true")



# Generated at 2022-06-24 01:38:52.761575
# Unit test for function should_build
def test_should_build():
    # With only upload_to_pypi set to true
    config.settings["upload_to_pypi"] = True
    config.settings["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
    config.settings["upload_to_pypi"] = False

    # With only upload_to_release set to true
    config.settings["upload_to_release"] = True
    config.settings["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True
    config.settings["upload_to_release"] = False

    # With upload_to_pypi and upload_to_release both set to false
    config.settings["upload_to_pypi"] = False

# Generated at 2022-06-24 01:38:56.512977
# Unit test for function remove_dists
def test_remove_dists():
    try:
        run("make fake_dist")
        remove_dists("fake_dist")
        run("ls -alh fake_dist")
    except:
        pass
    else:
        raise Exception("Should have failed because there is no fake_dist")
    finally:
        run("rm -rf dist")

# Generated at 2022-06-24 01:38:58.298042
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:39:04.574271
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": True})
    assert should_remove_dist() is True
    config.update({"remove_dist": False})
    assert should_remove_dist() is False
    config.update({"upload_to_pypi": True})
    assert should_remove_dist() is False
    config.update({"upload_to_release": True})
    assert should_remove_dist() is False
    config.update({"build_command": "make dist"})
    assert should_remove_dist() is False
    config.update({"build_command": "false"})
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:39:08.511344
# Unit test for function remove_dists
def test_remove_dists():
    with open("test_data/test_dist_build.txt", "w") as f:
        f.write("test")
    remove_dists("test_data")



# Generated at 2022-06-24 01:39:09.695157
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:39:10.901299
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:39:14.365643
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")
