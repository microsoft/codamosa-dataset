

# Generated at 2022-06-24 01:29:19.811271
# Unit test for function build_dists
def test_build_dists():
    build_command = "echo unit_test"
    config["build_command"] = build_command
    buf = capture_buffer(build_dists)
    result = buf.getvalue()
    assert build_command in result


# Generated at 2022-06-24 01:29:22.488835
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # should_remove_dist() returns what is configured in the config.json file
    assert should_remove_dist() == config.get("remove_dist")



# Generated at 2022-06-24 01:29:29.608207
# Unit test for function should_remove_dist
def test_should_remove_dist():
    command = "something"
    upload_pypi = True
    upload_release = True

    assert should_remove_dist() == False
    config["build_command"] = command
    assert should_remove_dist() == False
    config["upload_to_pypi"] = upload_pypi
    assert should_remove_dist() == False
    config["upload_to_release"] = upload_release
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:29:34.274701
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists(config.get("dist_directory")), "Successfully removes dists"

# Generated at 2022-06-24 01:29:35.001312
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists



# Generated at 2022-06-24 01:29:36.245770
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tests/unit/dists_test")

# Generated at 2022-06-24 01:29:41.653596
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # removing distribution files should be False when:
    # 1. build_command is False
    # 2. pypi package is not released
    config.load_from_dict({"build_command": "false", "upload_to_pypi": False})
    assert should_remove_dist() is False

    # removing distribution files should be True when:
    # 1. build_command is not False
    # 2. pypi package is released
    config.load_from_dict({"build_command": True, "upload_to_pypi": True})
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:29:49.794703
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"build_command": "echo hello",
                   "remove_dist": False,
                   "upload_to_release": False})
    assert not should_remove_dist()
    config.update({"build_command": "echo hello",
                   "remove_dist": True,
                   "upload_to_pypi": False})
    assert should_remove_dist()
    config.update({"build_command": "echo hello",
                   "remove_dist": False,
                   "upload_to_pypi": True})
    assert not should_remove_dist()

# Generated at 2022-06-24 01:29:53.450370
# Unit test for function remove_dists
def test_remove_dists():
    removal_path = "foo"
    remove_dists(removal_path)

# Generated at 2022-06-24 01:29:54.059932
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:58.086904
# Unit test for function should_remove_dist
def test_should_remove_dist():
    remove_dist = config.get("remove_dist")
    assert should_remove_dist() == bool(remove_dist)



# Generated at 2022-06-24 01:30:00.197341
# Unit test for function build_dists
def test_build_dists():
    command = "setup.py sdist bdist_wheel"
    build_dists()
    assert command == config.get("build_command")

# Generated at 2022-06-24 01:30:07.277588
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["build_command"] = "build"
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False

# Generated at 2022-06-24 01:30:08.233201
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")



# Generated at 2022-06-24 01:30:11.893954
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    setattr(config, "remove_dist", "true")
    assert should_remove_dist() is True
    setattr(config, "build_command", "false")
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:30:18.238319
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"build_command": "false", "remove_dist": "true"})
    assert should_remove_dist() is False

    config.update({"build_command": "build", "remove_dist": "true"})
    assert should_remove_dist() is True

    config.update({"build_command": "false", "remove_dist": "false"})
    assert should_remove_dist() is False

    config.update({"build_command": "build", "remove_dist": "false"})
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:30:18.829856
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:25.925479
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config["build_command"] = "false"
    assert should_build() is False

    config["upload_to_pypi"] = True
    assert should_build() is True

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = True
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

    config["build_command"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:30:28.262058
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {
        "build_command": "ls",
        "remove_dist": True,
        "upload_to_pypi": False,
        "upload_to_release": False,
    }
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:29.016340
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:32.125982
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:36.387876
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir -p /tmp/pypi-builder-tests/")
    run("touch /tmp/pypi-builder-tests/testfile")
    assert should_remove_dist()
    remove_dists("/tmp/pypi-builder-tests/")
    assert run("ls /tmp/pypi-builder-tests/", warn=True).failed
    run("rm -rf /tmp/pypi-builder-tests/")



# Generated at 2022-06-24 01:30:38.032925
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:38.929625
# Unit test for function should_build
def test_should_build():
    assert should_build() is False



# Generated at 2022-06-24 01:30:43.478571
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() is True

    config["remove_dist"] = False
    assert should_remove_dist() is False

    config["build_command"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:30:48.003699
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = 'true'
    config['build_command'] = 'command'
    assert should_remove_dist() is True

    config['remove_dist'] = 'false'
    assert should_remove_dist() is False

    config['build_command'] = 'false'
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:30:49.186933
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:50.266275
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:57.959811
# Unit test for function should_remove_dist
def test_should_remove_dist():
    c = dict(
        build_command="echo 'build command'",
        upload_to_pypi=True,
        upload_to_release=False,
        remove_dist=False,
    )
    assert should_remove_dist(config=c) is False
    c = dict(
        build_command="echo 'build command'",
        upload_to_pypi=False,
        upload_to_release=True,
        remove_dist=False,
    )
    assert should_remove_dist(config=c) is False
    c = dict(
        build_command="echo 'build command'",
        upload_to_pypi=False,
        upload_to_release=False,
        remove_dist=False,
    )
    assert should_remove_dist(config=c) is False
   

# Generated at 2022-06-24 01:31:02.444953
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    config['upload_to_pypi'] = True
    config['upload_to_release'] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:06.246973
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:31:13.331108
# Unit test for function should_build
def test_should_build():
    ret = should_build()
    assert isinstance(ret, bool)
    assert ret is False

    config["build_command"] = "fake.command"
    config["upload_to_pypi"] = True
    ret = should_build()
    assert ret is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    ret = should_build()
    assert ret is True



# Generated at 2022-06-24 01:31:15.985864
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:31:24.447295
# Unit test for function should_build
def test_should_build():
    """
    Test that should_build returns False when upload_to_pypi and upload_to_release are False
    """
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "python setup.py sdist")
    assert not should_build()
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build()
   

# Generated at 2022-06-24 01:31:25.583037
# Unit test for function remove_dists
def test_remove_dists():
    path = "./dist/"
    print(f"Testing remove_dists function to delete path: {path}")
    remove_dists(path)

# Generated at 2022-06-24 01:31:31.410304
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = {
        "upload_to_pypi": 'true',
        "upload_to_release": 'true',
        "build_command": 'false',
        "remove_dist": 'true'
    }
    assert should_remove_dist(test_config) == True

# Generated at 2022-06-24 01:31:33.533127
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:31:45.118765
# Unit test for function should_build
def test_should_build():
    logger.info("Testing function should_build")
    assert should_build() is False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "pip install boto3"
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "pip install boto3"
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "pip install boto3"
    assert should_build() is False
    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:31:45.540933
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:46.188759
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:31:51.357783
# Unit test for function build_dists
def test_build_dists():
    global pypi_upload, config
    pypi_upload = True
    config = {}
    config["build_command"] = "echo 1"
    config["upload_to_pypi"] = True
    build_dists()

# Generated at 2022-06-24 01:31:59.700718
# Unit test for function should_build
def test_should_build():
    config['build_command'] = 'echo "do build"'
    assert should_build()
    config['build_command'] = 'false'
    assert should_build() == False
    config['upload_to_pypi'] = True
    assert should_build()
    config['upload_to_release'] = True
    assert should_build()
    config['upload_to_pypi'] = False
    assert should_build() == False
    config['upload_to_pypi'] = True
    assert should_build()
    config['upload_to_release'] = False
    assert should_build() == False
    


# Generated at 2022-06-24 01:32:02.049835
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test_datadog_checks_dev/dist")

# Generated at 2022-06-24 01:32:08.536877
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("build_command", "build")
    assert should_remove_dist()
    config.set("build_command", "false")
    assert not should_remove_dist()
    config.set("build_command", "build")
    config.set("remove_dist", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:32:10.776450
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("")

# Generated at 2022-06-24 01:32:11.303977
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:32:14.877443
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo command"
    assert not should_build()

# Generated at 2022-06-24 01:32:17.609713
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "touch build_test_file.txt"
    build_dists()
    config["build_command"] = False
    assert should_build()
    run("rm build_test_file.txt")

# Generated at 2022-06-24 01:32:18.868921
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/home/paul/repositories/snowflake-connector-python/dist")

# Generated at 2022-06-24 01:32:22.425108
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()



# Generated at 2022-06-24 01:32:24.012000
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist()



# Generated at 2022-06-24 01:32:28.314255
# Unit test for function should_build
def test_should_build():
    # Explicit negative
    config["build_command"] = "false"
    assert not should_build()
    # Explicit positive
    config["build_command"] = "build"
    assert should_build()
    # Should upload to PyPi = false
    config["upload_to_pypi"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:32:30.102576
# Unit test for function build_dists
def test_build_dists():
    from mock import Mock, call

    config = Mock()
    config.get = Mock(return_value="true")

    build_dists()

    assert config.get.call_count == 3
    assert config.get.call_args_list == [
        call("build_command"),
        call("upload_to_pypi"),
        call("upload_to_release")
    ]



# Generated at 2022-06-24 01:32:33.911613
# Unit test for function remove_dists
def test_remove_dists():
    logger.debug("Testing remove_dists")
    # Test string
    path1 = "tests/unit/data/dist"
    assert remove_dists(path1) is True


if __name__ == "__main__":
    pass
    # remove_dists("tests/unit/data/dist")

# Generated at 2022-06-24 01:32:38.614619
# Unit test for function build_dists
def test_build_dists():
    import mock

    with mock.patch(__name__ + "." + "build_dists") as mock_build_dists:
        build_dists()
        mock_build_dists.assert_called_once_with()



# Generated at 2022-06-24 01:32:40.877747
# Unit test for function remove_dists
def test_remove_dists():
    print(remove_dists(path="/home/bla"))

# Generated at 2022-06-24 01:32:45.299163
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import sys
    import shutil

    path = "build"
    os.mkdir(path)
    remove_dists(path)
    assert os.path.exists(path) == False, "Path should be deleted"

# Generated at 2022-06-24 01:32:50.907833
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.load_config({
        "build_command": "./setup.py sdist",
        "remove_dist": "false",
        "upload_to_pypi": "true",
        "upload_to_release": "false",
    })
    assert not should_remove_dist()



# Generated at 2022-06-24 01:33:02.252936
# Unit test for function should_remove_dist
def test_should_remove_dist():
    try:
        config['build_command'] = 'true'
        config['upload_to_pypi'] = 'true'
        config['upload_to_release'] = 'true'
        config['remove_dist'] = 'true'
        assert should_remove_dist()
        logger.info("should_remove_dist True passed")
    except AssertionError:
        logger.error("should_remove_dist True failed")


# Generated at 2022-06-24 01:33:03.148366
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:33:06.715372
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:33:09.342218
# Unit test for function should_remove_dist
def test_should_remove_dist():
    result = should_remove_dist()
    assert result is bool(config.get("remove_dist"))

# Generated at 2022-06-24 01:33:10.241907
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")



# Generated at 2022-06-24 01:33:19.956570
# Unit test for function remove_dists
def test_remove_dists():
    import numpy as np
    from pathlib import Path
    from .settings import STARFISH_TEST_FILES

    path = Path(STARFISH_TEST_FILES)
    for f in path.iterdir():
        f.unlink()
    files = list(path.iterdir())
    assert len(files) == 0
    names = ["data-{}.npz".format(i) for i in range(10)]

    for name in names:
        f = path / name
        data = np.arange(10)
        np.savez_compressed(f, data=data)

    files = list(path.iterdir())
    assert len(files) == 10
    remove_dists(str(path))
    files = list(path.iterdir())
    assert len(files) == 0

# Generated at 2022-06-24 01:33:21.357070
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:33:29.664963
# Unit test for function should_build
def test_should_build():
    # Upload_to_pypi and upload_to_release false and build_command is false, should_build should be false
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() == False

    # Upload_to_pypi and upload_to_release is False, build_command is set, should_build should be true
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "echo test"
    assert should_build() == True

    # Upload_to_pypi and upload_to_release is True and build_command is not set, should_build should be false

# Generated at 2022-06-24 01:33:31.215808
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")

# Generated at 2022-06-24 01:33:32.052832
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:34.852892
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./build")



# Generated at 2022-06-24 01:33:38.523357
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("build_command", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:33:44.263216
# Unit test for function remove_dists
def test_remove_dists():
    from .constants import DISTRIBUTION_PATH
    from .utils import temp_chdir
    with temp_chdir("/tmp/") as cwd:
        import os
        os.mkdir("version/dist")
        os.mkdir("version/build")
        remove_dists(DISTRIBUTION_PATH)
        assert not os.path.exists("version/dist")
        assert not os.path.exists("version/build")

# Generated at 2022-06-24 01:33:44.959250
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:47.172521
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists(path=config.get("path"))

# Generated at 2022-06-24 01:33:53.485616
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.build_command = True
    config.remove_dist = True
    assert should_remove_dist()
    config.build_command = False
    assert not should_remove_dist()
    config.build_command = True
    config.remove_dist = False
    assert not should_remove_dist()


# Generated at 2022-06-24 01:33:55.633925
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:33:57.500510
# Unit test for function build_dists
def test_build_dists():
    remove_dists("./dist/*")
    build_dists()
    remove_dists("./dist/*")

# Generated at 2022-06-24 01:34:05.322650
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    assert should_remove_dist() is False
    config.set("upload_to_pypi", True)
    assert should_remove_dist() is True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist() is True
    config.set("upload_to_release", False)
    config.set("build_command", "test")
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:34:07.016108
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Unit tests for function build_dists

# Generated at 2022-06-24 01:34:07.986702
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:34:08.936102
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:34:09.931190
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-24 01:34:16.797017
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "test"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()

# Generated at 2022-06-24 01:34:18.661760
# Unit test for function should_remove_dist
def test_should_remove_dist():
    "Testing function should_remove_dist"
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:34:20.148949
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:34:20.835763
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() is None


# Generated at 2022-06-24 01:34:22.464489
# Unit test for function build_dists
def test_build_dists():
    run("mkdir foo")
    build_dists()
    run("rm -rf foo")

# Generated at 2022-06-24 01:34:27.504522
# Unit test for function build_dists
def test_build_dists():
    command = "touch test.txt"
    c = config.copy()
    c["build_command"] = command
    with config.patch(c, clear=False):
        build_dists()
    run("rm test.txt")

# Generated at 2022-06-24 01:34:35.857704
# Unit test for function should_build
def test_should_build():
    build_command = "python setup.py sdist"
    config["build_command"] = build_command
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build() == True

    config["upload_to_pypi"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() == False



# Generated at 2022-06-24 01:34:37.012881
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/remove_dists")

# Generated at 2022-06-24 01:34:45.560562
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()
    config["build_command"] = True
    assert should_build()
    config["build_command"] = False
    assert not should_build()
    config["build_command"] = "somecommand"
    assert should_build()

# Generated at 2022-06-24 01:34:46.177858
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:34:47.092920
# Unit test for function remove_dists
def test_remove_dists():
    cmd = "foo"
    remove_dists(cmd)

# Generated at 2022-06-24 01:34:48.083513
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="/")

# Generated at 2022-06-24 01:34:51.123247
# Unit test for function remove_dists
def test_remove_dists():
    path = "dist/"
    command = f"rm -rf {path}"
    run(command)

# Generated at 2022-06-24 01:35:01.710899
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert should_build() == False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert should_build() == False
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "false")
    assert should_build() == False
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "true")


# Generated at 2022-06-24 01:35:02.933485
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:03.705054
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:35:08.282634
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_release", "false")
    config.set("upload_to_pypi", "false")
    config.set("build_command", "false")
    assert should_remove_dist() == False

    config.set("remove_dist", "true")
    config.set("upload_to_release", "true")
    config.set("upload_to_pypi", "false")
    config.set("build_command", "true")
    assert should_remove_dist() == True

    config.set("remove_dist", "true")
    config.set("upload_to_release", "false")
    config.set("upload_to_pypi", "true")
    config.set("build_command", "true")
    assert should

# Generated at 2022-06-24 01:35:13.036770
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import build_settings
    from .settings import Settings
    print("Testing function should_remove_dist")
    config = Settings()
    config.set_settings(build_settings)
    should_remove_dist_true = config.get("remove_dist")

    assert should_remove_dist() == True
    assert should_remove_dist_true == True

# Generated at 2022-06-24 01:35:18.246049
# Unit test for function should_build
def test_should_build():
    config.update({"build_command": "false"})
    assert should_build() is False
    config.update({"build_command": "false", "upload_to_pypi": "true"})
    assert should_build() is False
    config.update({"build_command": "false", "upload_to_release": "true"})
    assert should_build() is False
    config.update(
        {"build_command": "python setup.py sdist bdist_wheel", "upload_to_pypi": "true"}
    )
    assert should_build() is True
    config.update(
        {"build_command": "python setup.py sdist bdist_wheel", "upload_to_release": "true"}
    )
    assert should_build() is True



# Generated at 2022-06-24 01:35:19.303854
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:35:23.592878
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() != True
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:35:29.148425
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "true"
    assert should_remove_dist()
    config["upload_to_release"] = False
    assert should_remove_dist()

# Generated at 2022-06-24 01:35:37.464992
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # WHEN
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    config.set("build_command", "echo hi")

    # THEN
    assert should_remove_dist()

    # WHEN
    config.set("remove_dist", "false")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    config.set("build_command", "echo hi")

    # THEN
    assert not should_remove_dist()

    # WHEN
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "true")

# Generated at 2022-06-24 01:35:38.900458
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist bdist_wheel"
    build_dists()

# Generated at 2022-06-24 01:35:39.595361
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:44.708500
# Unit test for function should_build
def test_should_build():
    _config = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "foo",
        "remove_dist": False
    }
    assert should_build(_config) is True



# Generated at 2022-06-24 01:35:46.801463
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:47.405962
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:48.730441
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf build/*"
    pass


# Generated at 2022-06-24 01:35:53.055222
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build_command"
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:35:57.087175
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "true"
    assert should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "true"
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "false"
    config["remove_dist"] = "true"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:35:58.993483
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    assert should_remove_dist()
    remove_dists(config.get("dist_dir"))

# Generated at 2022-06-24 01:36:01.402426
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:36:03.342953
# Unit test for function build_dists
def test_build_dists():
    assert True == should_build()
    build_dists()
    assert True == should_remove_dist()
    remove_dists("dist/")

# Generated at 2022-06-24 01:36:06.591503
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    build_dists()


# Generated at 2022-06-24 01:36:13.720856
# Unit test for function should_build
def test_should_build():
    from invoke import MockContext
    from doctall.settings import load_config

    run_mock = MockContext()
    load_config("./tests/no_test_config.yml")
    config.set("build_command", "test command")
    assert should_build()

    # No build command
    config.set("build_command", False)
    assert not should_build()

    # No release or upload
    config.set("upload_to_release", False)
    config.set("upload_to_pypi", False)
    assert not should_build()

    config.set("upload_to_release", True)
    config.set("upload_to_pypi", False)
    assert should_build()

    config.set("upload_to_release", False)

# Generated at 2022-06-24 01:36:14.768756
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:36:19.215894
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["build_command"] = "echo 'hello'"
    assert should_build() is True
    config["upload_to_release"] = True
    assert should_build() is True
    config["upload_to_pypi"] = True
    assert should_build() is True

# Generated at 2022-06-24 01:36:29.405770
# Unit test for function should_build
def test_should_build():
    config["build_command"] = ""
    assert should_build() == False
    config["build_command"] = False
    assert should_build() == False
    config["build_command"] = "echo 'Build'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False
    return True


# Generated at 2022-06-24 01:36:31.506038
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    assert should_build() is True
    assert should_remove_dist() is False
    assert should_build() is False

# Generated at 2022-06-24 01:36:32.465003
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:36.293517
# Unit test for function build_dists
def test_build_dists():
    """Build_dists function should run and return True when return code is 0
    """
    assert build_dists() is True

# Generated at 2022-06-24 01:36:46.151318
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.update({"upload_to_pypi": True, "upload_to_release": True})
    assert should_build()
    config.update({"upload_to_pypi": False})
    assert should_build()
    config.update({"upload_to_release": False})
    assert not should_build()
    config.update({"upload_to_pypi": True, "upload_to_release": True})
    assert should_build()
    config.update({"build_command": "false"})
    assert not should_build()
    config.update({"build_command": "python setup.py bdist_wheel"})
    assert should_build()


# Generated at 2022-06-24 01:36:48.597447
# Unit test for function build_dists
def test_build_dists():
    logger.debug("Test for function build_dists")
    build_dists()
    build_dists("mycommand")



# Generated at 2022-06-24 01:36:53.979829
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

    config["remove_dist"] = True
    config["build_command"] = "my command"
    assert should_remove_dist() is True

    config["build_command"] = "false"
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:37:00.681498
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("build_command", "ls -al")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build()
    config.set("build_command", "false")
    assert not should_build()
    config.set("build_command", "ls -al")
    config.set("upload_to_release", False)
    assert should_build()



# Generated at 2022-06-24 01:37:01.678551
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:37:08.400248
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["build_command"] = "true"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:37:10.155080
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:37:12.763016
# Unit test for function should_build
def test_should_build():
    # Test whether True is returned when the "build_command" or "upload_to_pypi"
    # or "upload_to_release" are True.
    assert should_build()



# Generated at 2022-06-24 01:37:13.519894
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:37:18.591389
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = "true"
    assert should_remove_dist() is False
    config["build_command"] = "python3 setup.py sdist"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() is True
    # make sure the upload_to_release doesn't change anything after upload_to_pypi
    config["upload_to_release"] = "true"
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:37:22.064256
# Unit test for function remove_dists
def test_remove_dists():
    # remove_dists(path="stub_build_dir")
    pass

# Generated at 2022-06-24 01:37:22.654349
# Unit test for function remove_dists
def test_remove_dists():
    assert False

# Generated at 2022-06-24 01:37:23.847402
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:24.635995
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:37:25.970587
# Unit test for function remove_dists
def test_remove_dists():
    from .constants import REPO_ROOT
    remove_dists(REPO_ROOT)

# Generated at 2022-06-24 01:37:35.121230
# Unit test for function build_dists
def test_build_dists():

    dummy_command = "ls"

    res1 = should_build()
    assert res1 is False
    res2 = should_remove_dist()
    assert res2 is False

    config["upload_to_release"] = True
    config["build_command"] = dummy_command
    res1 = should_build()
    assert res1 is True
    res2 = should_remove_dist()
    assert res2 is True

    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    config["build_command"] = dummy_command
    res1 = should_build()
    assert res1 is True
    res2 = should_remove_dist()
    assert res2 is True

    config["remove_dist"] = False
    config["build_command"] = dummy_command

# Generated at 2022-06-24 01:37:36.772855
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:37:40.406661
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'This is a test'"
    config["build_command"] = command
    build_dists()


if should_remove_dist():
    path = config.get("dist_path")
    if should_build():
        remove_dists(path)
    build_dists()

# Generated at 2022-06-24 01:37:41.192160
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:43.320583
# Unit test for function should_build
def test_should_build():
    conf = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "true"
    }
    assert should_build(conf), "should_build should return true"



# Generated at 2022-06-24 01:37:44.901061
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:37:52.639875
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "build"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:37:59.010749
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    commands = ["mkdir dist", "touch dist/file", "mkdir something", "touch something/readme.md"]
    for command in commands:
        run(command, cwd=tempdir)
    assert os.path.isdir(f"{tempdir}/dist")
    assert os.path.isfile(f"{tempdir}/dist/file")
    assert os.path.isdir(f"{tempdir}/something")
    assert os.path.isfile(f"{tempdir}/something/readme.md")
    remove_dists(tempdir)
    assert not os.path.isdir(f"{tempdir}/dist")

# Generated at 2022-06-24 01:38:00.188110
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")

# Generated at 2022-06-24 01:38:06.262376
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import TemporaryDirectory
    from .settings import config
    with TemporaryDirectory() as temp_dir:
        assert temp_dir.exists()
        config['build_command'] = "pwd"
        build_dists()
        config['remove_dist'] = True
        remove_dists(temp_dir)
        assert temp_dir.is_empty()

# Generated at 2022-06-24 01:38:13.089128
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = False
    assert not should_build()

# Generated at 2022-06-24 01:38:17.615859
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.config["publish"]["build"]["remove_dist"] = True
    config.config["publish"]["upload_to_pypi"] = True
    config.config["publish"]["build"]["command"] = "python3 setup.py sdist bdist_wheel"
    assert should_remove_dist() == True

    config.config["publish"]["build"]["remove_dist"] = False
    config.config["publish"]["upload_to_release"] = True
    assert should_remove_dist() == False

    config.config["publish"]["build"]["remove_dist"] = True
    config.config["publish"]["upload_to_release"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:18.486303
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build"
    assert should_remove_dis

# Generated at 2022-06-24 01:38:25.009028
# Unit test for function remove_dists
def test_remove_dists():
    config["build_command"] = "echo"
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "False"
    config["remove_dist"] = "True"
    assert should_build() == False
    assert should_remove_dist() == True
    remove_dists("fake")


# Generated at 2022-06-24 01:38:26.161677
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:38:34.426515
# Unit test for function should_remove_dist
def test_should_remove_dist():
    def config_with_remove_dist(remove_dist):
        return {
            'build_command': 'bdist_wheel',
            'upload_to_pypi': True,
            'upload_to_release': True,
            'remove_dist': remove_dist,
        }
    assert should_remove_dist() == True
    assert should_remove_dist(config=config_with_remove_dist(True)) == True
    assert should_remove_dist(config=config_with_remove_dist(False)) == False



# Generated at 2022-06-24 01:38:36.680263
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:38:38.279878
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo 'hello world'"
    build_dists()

# Generated at 2022-06-24 01:38:47.174930
# Unit test for function should_build
def test_should_build():
    # Setup
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = ""

    # Test 1
    # Shouldn't build when no command to run
    config["build_command"] = ""
    assert not should_build()

    # Test 2
    # Shouldn't build when no uploads are set
    config["build_command"] = "true"
    assert not should_build()

    # Test 3
    # Should build if upload_to_pypi is set
    config["upload_to_pypi"] = True
    assert should_build()

    # Test 4
    # Should build if upload_to_release is set
    config["upload_to_release"] = True
    assert should_build()

    # Test
    # Shouldn

# Generated at 2022-06-24 01:38:54.486787
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({
        "upload_to_pypi": "true",
        "remove_dist": "true",
        "build_command": "python setup.py bdist_wheel",
    })
    assert should_remove_dist()
    config.update({
        "upload_to_pypi": "true",
        "remove_dist": "false",
        "build_command": "python setup.py bdist_wheel",
    })
    assert not should_remove_dist()
    config.update({
        "upload_to_pypi": "false",
        "remove_dist": "true",
        "build_command": "python setup.py bdist_wheel",
    })
    assert not should_remove_dist()

# Generated at 2022-06-24 01:38:58.406037
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/home/travis")


# Generated at 2022-06-24 01:39:00.451838
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "true")
    assert should_remove_dist()
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_remove_dist()

# Generated at 2022-06-24 01:39:08.963765
# Unit test for function should_build
def test_should_build():
    data = [
        ({"upload_to_pypi": True, "build_command": "sdist"}, True),
        ({"upload_to_pypi": False, "build_command": False}, False),
        ({"upload_to_pypi": False, "build_command": "py.test"}, True),
    ]
    for entry in data:
        config.set_full(entry[0])
        assert should_build() == entry[1]

# Generated at 2022-06-24 01:39:11.070590
# Unit test for function build_dists
def test_build_dists():
    path = "./dist"
    if should_remove_dist():
        remove_dists(path)
    build_dists()
    assert len(path) > 0

# Generated at 2022-06-24 01:39:14.567861
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('my_test') == None

# Generated at 2022-06-24 01:39:20.167888
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == False)
    config.set("remove_dist", "true")
    assert(should_remove_dist() == False)
    config.set("build_command", "echo nothing")
    assert(should_remove_dist() == False)
    config.set("upload_to_pypi", "false")
    assert(should_remove_dist() == False)
    config.set("upload_to_release", "true")
    assert(should_remove_dist() == True)