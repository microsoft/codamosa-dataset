

# Generated at 2022-06-24 01:29:24.464144
# Unit test for function should_build
def test_should_build():
    # when the release and pypi options are false,
    # and the build command is false
    # then should_build should be false

    # When the release and pypi options are true,
    # and the build_command is false,
    # then should_build should be false

    # When the release and pypi options are false,
    # and the build_command is true,
    # then should_build should be false

    # When the release and pypi options are true,
    # and the build_command is true,
    # then should_build should be true
    pass

# Generated at 2022-06-24 01:29:25.758059
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-24 01:29:29.316778
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist")



# Generated at 2022-06-24 01:29:34.556074
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:29:41.830509
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import config as test_config
    test_config["upload_release"] = True
    test_config["upload_to_pypi"] = False
    test_config["build_command"] = "test-build"
    test_config["remove_dist"] = True
    assert should_remove_dist() == True
    test_config["upload_release"] = False
    test_config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    test_config["upload_release"] = True
    test_config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    test_config["build_command"] = False
    assert should_remove_dist() == False
    test_config["build_command"] = "test-build"
    test_config

# Generated at 2022-06-24 01:29:42.569350
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("release")

# Generated at 2022-06-24 01:29:44.853504
# Unit test for function should_build
def test_should_build():
    from .settings import config
    assert should_build() == True
    config.set("upload_to_pypi", False)
    assert should_build() == True
    config.set("upload_to_release", False)
    assert should_build() == False
    config.set("build_command", False)
    assert should_build() == False


# Generated at 2022-06-24 01:29:46.563778
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:29:47.749578
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists = config.get("remove_dist")
    return remove_dists

# Generated at 2022-06-24 01:29:50.984122
# Unit test for function build_dists
def test_build_dists():
    command = "make build"
    assert command == config.get('build_command')
    assert True == should_build()
    build_dists()



# Generated at 2022-06-24 01:29:52.804712
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {
        "remove_dist": True,
        "upload_to_pypi": True,
        "build_command": "echo test"
    }
    assert should_remove_dist(config) == True

# Generated at 2022-06-24 01:29:56.838887
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config.update({"remove_dist": False})
    assert should_remove_dist() is False
    config.update({"remove_dist": True})
    config.update({"build_command": False})
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:29:57.406801
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:59.678902
# Unit test for function should_build
def test_should_build():
    """Should build dists if build_command is specified in .publishrc file.
    """
    config["build_command"] = "echo 'test'"
    assert should_build()



# Generated at 2022-06-24 01:30:04.148709
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf dist"
    remove_dists(path="dist")
    # FIXME

# Generated at 2022-06-24 01:30:05.475803
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:30:08.572623
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:30:11.455433
# Unit test for function build_dists
def test_build_dists():
    """
    Tests for function build_dists
    """
    command = f"pwd"
    build_dists()
    assert run(command) is not None

# Generated at 2022-06-24 01:30:18.212958
# Unit test for function should_build
def test_should_build():
    # Scenario 1: build command and upload release is set
    config["build_command"] = "command"
    config["upload_to_release"] = True
    assert should_build() == True

    # Scenario 2: build command and upload pypi is set
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build() == True

    # Scenario 3: build command is set, but not upload
    config["upload_to_pypi"] = False
    assert should_build() == False



# Generated at 2022-06-24 01:30:19.836874
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist(), f"Should remove dist, but returns false"

# Generated at 2022-06-24 01:30:20.220052
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:25.304877
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil
    import tempfile

    temp_path = tempfile.mkdtemp()
    path = os.path.join(temp_path, "subfolder1")
    os.makedirs(path)
    assert os.path.isdir(temp_path)
    assert os.path.isdir(path)
    remove_dists(temp_path)
    assert not os.path.exists(temp_path)
    assert not os.path.exists(path)

# Generated at 2022-06-24 01:30:29.009665
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config.set("remove_dist", "True")
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:30:32.715599
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:30:33.803206
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:30:40.790881
# Unit test for function should_build

# Generated at 2022-06-24 01:30:41.996091
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True
    build_dists()


# Generated at 2022-06-24 01:30:42.685084
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:30:43.897915
# Unit test for function remove_dists
def test_remove_dists():
    command = "ls"
    run(command)

# Generated at 2022-06-24 01:30:45.307052
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:30:45.834476
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:30:55.648822
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config._set_value("build_command", "echo 'test command'")

    assert should_remove_dist() == False

    config._set_value("build_command", "false")
    assert should_remove_dist() == False

    config._set_value("build_command", "echo 'test command'")
    config._set_value("remove_dist", "false")
    assert should_remove_dist() == False

    config._set_value("build_command", "echo 'test command'")
    config._set_value("remove_dist", "true")
    config._set_value("upload_to_pypi", "false")
    config._set_value("upload_to_release", "false")
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:30:59.948192
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:31:02.151245
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()



# Generated at 2022-06-24 01:31:06.264969
# Unit test for function remove_dists
def test_remove_dists():
    mock_path = "test"
    remove_dists(mock_path)

# Generated at 2022-06-24 01:31:11.958761
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config_data = {
        'upload_to_release': True,
        'upload_to_pypi': True,
        'build_command': True,
        'remove_dist': True
    }
    assert should_remove_dist(test_config_data)



# Generated at 2022-06-24 01:31:22.440682
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should be True if remove_dist is True
    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert should_remove_dist()

    # Should be False if remove_dist is False
    config["remove_dist"] = "false"
    config["build_command"] = "false"
    assert not should_remove_dist()

    # Should be False if build_command is False
    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert not should_remove_dist()

    # Should be True if remove_dist is True and build_command is True
    config["remove_dist"] = "true"
    config["build_command"] = "python setup.py build"
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:26.164235
# Unit test for function remove_dists
def test_remove_dists():
    assert bool(
        'rm -rf test_dist' in remove_dists.__defaults__[0])



# Generated at 2022-06-24 01:31:30.160105
# Unit test for function remove_dists
def test_remove_dists():
    assert(remove_dists("test") == "rm -rf test")

# Generated at 2022-06-24 01:31:30.938720
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")

# Generated at 2022-06-24 01:31:34.528602
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf"
    path = "path/to/dir"
    assert remove_dists("path/to/dir") == (command + " path/to/dir")

# Generated at 2022-06-24 01:31:35.346316
# Unit test for function should_remove_dist
def test_should_remove_dist():
    
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:35.807360
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:39.385543
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

    config.set("remove_dist", True)
    assert should_remove_dist() == False

    config.set("upload_to_pypi", True)
    assert should_remove_dist() == True

    config.set("upload_to_release", True)
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:39.874115
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:31:44.399345
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist()
    config.set("upload_to_release", True)
    assert should_remove_dist()
    config.set("upload_to_pypi", False)
    assert should_remove_dist()
    config.set("upload_to_release", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:31:51.493463
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "debug_command"
    assert should_build()
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "debug_command"
    assert should_build()



# Generated at 2022-06-24 01:32:01.769006
# Unit test for function should_build
def test_should_build():
    # No upload, no build command => no build
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build()

    # Upload to pypi and build command => build
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()

    # upload to release and build command => build
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    # No upload and build command => no build
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "true"

# Generated at 2022-06-24 01:32:09.988481
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "make build"
    assert not should_build()
    config["upload_to_pypi"] = "True"
    assert should_build()
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "True"
    assert should_build()
    config["upload_to_pypi"] = "True"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:32:14.010414
# Unit test for function should_remove_dist
def test_should_remove_dist():
    c = dict(config)
    c['remove_dist'] = False
    c['build_command'] = True
    c['upload_to_release'] = False
    c['upload_to_pypi'] = False
    res = should_remove_dist()
    assert not res
    c['remove_dist'] = True
    res = should_remove_dist()
    assert res


# Generated at 2022-06-24 01:32:17.253906
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    path = tempfile.mkdtemp()
    dist_file = os.path.join(path, "dist.tar.gz")
    os.mkdir(dist_file)
    remove_dists(path)
    assert not os.path.exists(dist_file)

# Generated at 2022-06-24 01:32:18.622723
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:21.824164
# Unit test for function remove_dists
def test_remove_dists():
    command = remove_dists
    command("/tmp")



# Generated at 2022-06-24 01:32:22.884786
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("tests/tmp/")

# Generated at 2022-06-24 01:32:24.100183
# Unit test for function build_dists
def test_build_dists():
    # Test for string input
    assert build_dists("") is None



# Generated at 2022-06-24 01:32:26.050431
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    config['build_command'] = False
    assert should_build() is False

# Generated at 2022-06-24 01:32:26.982884
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path=".")

# Generated at 2022-06-24 01:32:27.887247
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:32:29.364139
# Unit test for function should_build
def test_should_build():
    result = should_build()
    assert result



# Generated at 2022-06-24 01:32:32.117140
# Unit test for function build_dists
def test_build_dists():
    from .settings import settings
    from .utils import get_project_name
    assert should_build()
    build_dists()
    remove_dists(f"dist/{get_project_name(settings)}*")

# Generated at 2022-06-24 01:32:34.472821
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:32:37.497646
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:32:47.419503
# Unit test for function build_dists
def test_build_dists():
    # mock run()
    run_mock = Mock()
    build_dists_run_patch = patch("polyswarmclient.build.build_dists.run", new=run_mock)
    # mock logging
    logger_mock = Mock()
    build_dists_logger_patch = patch("polyswarmclient.build.build_dists.logger", new=logger_mock)

    with build_dists_run_patch, build_dists_logger_patch:
        # test a command
        config["build_command"] = "hello"
        config["upload_to_pypi"] = True
        config["upload_to_release"] = False
        build_dists()
        run_mock.assert_called_once_with("hello")
        # test no build command
        run

# Generated at 2022-06-24 01:32:51.620278
# Unit test for function should_build
def test_should_build():
    config_values = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "python setup.py sdist",
    }
    assert should_build(config_values) == True



# Generated at 2022-06-24 01:33:02.979838
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.remove_dist = True
    config.upload_to_pypi = True
    config.upload_to_release = True
    assert should_remove_dist() is True

    config.remove_dist = True
    config.upload_to_pypi = True
    config.upload_to_release = False
    assert should_remove_dist() is True

    config.remove_dist = True
    config.upload_to_pypi = False
    config.upload_to_release = True
    assert should_remove_dist() is True

    config.remove_dist = False
    config.upload_to_pypi = True
    config.upload_to_release = True
    assert should_remove_dist() is False

    config.remove_dist = True
    config.upload_to_pypi = False
   

# Generated at 2022-06-24 01:33:06.410051
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/build")

# Generated at 2022-06-24 01:33:08.769109
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True, "Wrong value returned"

# Generated at 2022-06-24 01:33:09.430056
# Unit test for function build_dists
def test_build_dists():
    should_build() is True



# Generated at 2022-06-24 01:33:10.324505
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:33:14.432878
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path=r"test_data/test_dist")

# Generated at 2022-06-24 01:33:14.972158
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:20.539820
# Unit test for function should_build
def test_should_build():
    command = 'python3 setup.py sdist'
    upload_pypi = 'false'
    upload_release = 'false'

    assert should_build() is False

    config['upload_to_pypi'] = True

    assert should_build() is False

    config['build_command'] = command

    assert should_build() is True

    config['build_command'] = 'false'

    assert should_build() is False

    config['build_command'] = command
    config['upload_to_pypi'] = False

    assert should_build() is False

    config['upload_to_release'] = 'true'

    assert should_build() is True

    config['build_command'] = 'false'

    assert should_build() is False

# Generated at 2022-06-24 01:33:21.853959
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:26.397207
# Unit test for function should_remove_dist
def test_should_remove_dist():
    def _test(value, expect):
        config.set_value("remove_dist", value)
        assert bool(should_remove_dist()) == expect

    _test(True, True)
    _test(False, False)
    _test(None, False)



# Generated at 2022-06-24 01:33:28.388882
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    import shutil
    dirpath = tempfile.mkdtemp()
    remove_dists(dirpath)
    shutil.rmtree(dirpath)

# Generated at 2022-06-24 01:33:29.445609
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:33:31.028103
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:33:43.284848
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf ~/.vim/bundle/apackages/autoload"
    run(command)
    command = "mkdir -p ~/.vim/bundle/apackages/autoload"
    run(command)
    command = "touch ~/.vim/bundle/apackages/autoload/__init__.vim"
    run(command)
    remove_dists("~/.vim/bundle/apackages/autoload")
    command = "[ -e ~/.vim/bundle/apackages ]"
    assert run(command).ok
    command = "[ ! -e ~/.vim/bundle/apackages/autoload ]"
    assert run(command).ok
    command = "rm -rf ~/.vim/bundle/apackages"
    run(command)

# Generated at 2022-06-24 01:33:45.212090
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """test_should_remove_dist(invoke_plugin.should_remove_dist)"""
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:48.095277
# Unit test for function remove_dists
def test_remove_dists():
    from tempfile import TemporaryDirectory
    from .utils import create_file

    with TemporaryDirectory() as folder:
        create_file(folder, "dist1", "")
        create_file(folder, "dist2", "")
        assert len(os.listdir(folder)) == 2
        remove_dists(folder)
        assert len(os.listdir(folder)) == 0

# Generated at 2022-06-24 01:33:48.924631
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:33:56.774739
# Unit test for function should_build
def test_should_build():
    # Test for a build command
    config.set("build_command", "true")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert not should_build()
    config.set("build_command", "not false")
    assert should_build()
    # Test for upload to pypi
    config.set("build_command", "false")
    config.set("upload_to_pypi", "true")
    assert should_build()
    # Test for upload to release
    config.set("build_command", "false")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_build()

# Generated at 2022-06-24 01:33:58.025148
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()


# Generated at 2022-06-24 01:33:59.047000
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:05.040207
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "python setup.py sdist bdist_wheel")
    assert should_build()
    config.set("build_command", False)
    assert not should_build()
    config.set("build_command", "python setup.py sdist bdist_wheel")
    config.set("upload_to_pypi", False)
    assert not should_build()
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert not should_build()



# Generated at 2022-06-24 01:34:06.315943
# Unit test for function build_dists
def test_build_dists():
    run("python setup.py sdist bdist_wheel")


# Generated at 2022-06-24 01:34:08.032463
# Unit test for function should_build
def test_should_build():
    assert should_build() == True, "Should always be True"


# Generated at 2022-06-24 01:34:08.990031
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() == None


# Generated at 2022-06-24 01:34:12.873908
# Unit test for function should_build
def test_should_build():
    assert should_build() == bool(config["build_command"])
    assert should_build() == bool(config["upload_to_pypi"] or config["upload_to_release"])
    assert should_build() == bool(config["build_command"] and (config["upload_to_pypi"] or config["upload_to_release"]))


# Generated at 2022-06-24 01:34:14.648169
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf build"
    assert remove_dists(path='build') == run(command)

# Generated at 2022-06-24 01:34:21.680032
# Unit test for function should_build
def test_should_build():
    # Test 1: Should build when build_command is in settings
    settings = {
        "build_command": "sphinx-build -b html docs build/docs",
        "upload_to_pypi": "false",
        "upload_to_release": "false" 
    }
    assert should_build(settings=settings)

    # Test 2: Should build when build_command is in settings
    settings = {
        "build_command": "sphinx-build -b html docs build/docs",
        "upload_to_pypi": "false",
        "upload_to_release": "true" 
    }
    assert should_build(settings=settings)

    # Test 3: Should not build when build_command is not in settings

# Generated at 2022-06-24 01:34:25.819386
# Unit test for function remove_dists
def test_remove_dists():
   assert run(remove_dists(path="dist"))
# Test for should_build

# Generated at 2022-06-24 01:34:27.310764
# Unit test for function remove_dists
def test_remove_dists():
    """ Test remove_dists function """
    remove_dists("/tmp/test_dir")

# Generated at 2022-06-24 01:34:30.284348
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist")

# Generated at 2022-06-24 01:34:30.760430
# Unit test for function remove_dists
def test_remove_dists():

    pass

# Generated at 2022-06-24 01:34:33.467787
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import cd, PROJECT_PATH
    remove_dists(PROJECT_PATH.joinpath("dist"))

# Generated at 2022-06-24 01:34:34.333114
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:34:42.235871
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "true")
    assert should_build()
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", True)
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", True)
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", False)
    assert not should_build()




# Generated at 2022-06-24 01:34:44.226207
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({'remove_dist': 'true'})
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:47.015571
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")



# Generated at 2022-06-24 01:34:50.548480
# Unit test for function remove_dists
def test_remove_dists():
    from os.path import exists
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        path = f"{temp_dir}/foo"
        with open(path, "w") as temp_file:
            temp_file.write("test")

        assert exists(path)

        remove_dists(temp_dir)

        assert not exists(path)

# Generated at 2022-06-24 01:34:52.516088
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:34:56.989086
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_dic = {"upload_to_pypi": "false",
                  "upload_to_release": "false",
                  "build_command": "true",
                  "remove_dist": "true"}
    assert should_remove_dist() == False
    config.update(config_dic)
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:58.326114
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:34:59.638692
# Unit test for function remove_dists
def test_remove_dists():
    path = "build"
    remove_dists(path)


# Generated at 2022-06-24 01:35:01.622739
# Unit test for function should_remove_dist
def test_should_remove_dist():
    remove_dist = config.get("remove_dist")
    assert should_remove_dist() == bool(remove_dist)



# Generated at 2022-06-24 01:35:09.860357
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "echo Hello World"
    assert not should_remove_dist()
    config["build_command"] = "echo Hello World"
    config["remove_dist"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should

# Generated at 2022-06-24 01:35:17.532251
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-24 01:35:28.227605
# Unit test for function build_dists
def test_build_dists():
    # Set up mock config to run one test
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = True
    config["remove_dist"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = True
    assert not should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"]

# Generated at 2022-06-24 01:35:29.658129
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except:
        raise

# Generated at 2022-06-24 01:35:37.346976
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python3 setup.py sdist"
    assert should_remove_dist() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:35:39.583394
# Unit test for function build_dists
def test_build_dists():
    config.set("build_command", "python setup.py sdist bdist_wheel")
    build_dists()



# Generated at 2022-06-24 01:35:42.162854
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'test'"
    logger.info(f"Running {command}")
    assert run(command)

# Generated at 2022-06-24 01:35:48.136059
# Unit test for function build_dists
def test_build_dists():
    """
    I built this unit test to verify that the build_dists function works properly.
    """
    # If the build_dists function is to work, then the build_command key must be in the config.
    try:
        build_command = config.get("build_command") 
        assert isinstance(build_command, str)
    except KeyError:
        raise KeyError("'build_command' is not in the config.py file.")

# Generated at 2022-06-24 01:35:53.414537
# Unit test for function build_dists
def test_build_dists():

    assert should_build() is not None
    assert should_remove_dist() is not None
    assert should_build() is True
    assert should_remove_dist() is False

    command = config.get("build_command")
    assert command == "python setup.py sdist bdist_wheel"

    build_dists()

    assert not should_remove_dist()

    rmdist_command = "rm -rf dist"
    remove_dists("dist")

    assert not run(rmdist_command)

# Generated at 2022-06-24 01:35:59.812778
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config.set_all({"upload_to_pypi": True, "remove_dist": True})
    assert should_remove_dist()

    config.set_all({"upload_to_release": True, "remove_dist": True})
    assert should_remove_dist()

# Generated at 2022-06-24 01:36:09.156422
# Unit test for function should_build
def test_should_build():
    """Test of function should_build"""
    assert should_build() == False
    config.set("upload_to_pypi", "true")
    assert should_build() == True
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_build() == True
    config.set("upload_to_pypi", "true")
    assert should_build() == True
    config.set("upload_to_release", "false")
    config.set("build_command", "false")
    assert should_build() == False
    config.set("build_command", "echo Build")
    assert should_build() == True
    config.set("build_command", "false")
    config.set("delete_dist", "true")
   

# Generated at 2022-06-24 01:36:10.256681
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:36:11.434080
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('dist/') == None

# Generated at 2022-06-24 01:36:15.298019
# Unit test for function build_dists
def test_build_dists():
    """Test calling build builds"""
    def mocked_run(cmd):
        """Mock the run command"""
        assert cmd == "build"

    build_dists.run = mocked_run
    build_dists()



# Generated at 2022-06-24 01:36:19.341309
# Unit test for function should_remove_dist
def test_should_remove_dist():
    conf = {
        "build_command": "setup.py sdist bdist_wheel",
        "upload_to_pypi": "false",
        "remove_dist": "true"
    }
    expected = True
    actual = should_remove_dist()
    assert actual == expected

# Generated at 2022-06-24 01:36:21.258223
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/python-readme-generator/dist/**")

# Generated at 2022-06-24 01:36:22.916587
# Unit test for function build_dists
def test_build_dists():
    assert should_build()



# Generated at 2022-06-24 01:36:24.432547
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:36:25.380540
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:36:28.897861
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:36:33.188901
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "echo 'TEST'")
    assert should_build()
    config.set("upload_to_pypi", False)
    assert should_build()
    config.set("upload_to_release", False)
    assert not should_build()



# Generated at 2022-06-24 01:36:36.857201
# Unit test for function build_dists
def test_build_dists():
    command = "ls"
    logger.info(f"Running {command}")
    run(command)



# Generated at 2022-06-24 01:36:42.539599
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/blah")
    remove_dists("/tmp/blah/blah")
    remove_dists("/tmp/blah/blah/blah")



# Generated at 2022-06-24 01:36:46.360651
# Unit test for function remove_dists
def test_remove_dists():
    assert run("invoke _remove_dists")

# Generated at 2022-06-24 01:36:47.638139
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    pass

# Generated at 2022-06-24 01:36:49.017438
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:51.396741
# Unit test for function remove_dists
def test_remove_dists():
    # Default is to remove the ./dist directory
    assert remove_dists("./dist") is None

# Generated at 2022-06-24 01:36:52.760580
# Unit test for function remove_dists
def test_remove_dists():
    try:
        remove_dists("/tmp/fake_path")
    except:
        pass
    assert True


# Generated at 2022-06-24 01:36:53.442892
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:57.081381
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dist_path = "dist/"
    config["remove_dist"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist()
    remove_dists(dist_path)
    config.clear()

# Generated at 2022-06-24 01:37:01.629011
# Unit test for function remove_dists
def test_remove_dists():
    run('echo "begin unit test for function remove_dists"')
    run('mkdir ./fake/')
    remove_dists('./fake/')
    run('if [ -d ./fake/ ]; then echo "remove dists unit test failed"; exit 1; fi')
    run('echo "unit test for function remove_dists passed"')

# Generated at 2022-06-24 01:37:06.221952
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test if should_remove_dist returns false if config['remove_dist'] is set to 'n'
    config['remove_dist'] = 'n'
    assert should_remove_dist() is False
    # Test if should_remove_dist returns false if config['build_command'] is set to 'false'
    config['build_command'] = 'false'
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:37:09.872345
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:37:12.542489
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("build_command", "test")
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:37:18.070135
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config['remove_dist'] = "true"
    assert should_remove_dist() == False
    config['build_command'] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True
    config['build_command'] = "false"
    assert should_remove_dist() == False
    config['upload_to_pypi'] = "true"
    assert should_remove_dist() == True
    config['upload_to_release'] = "true"
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:28.922398
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "build_command"
    config["remove_dist"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "build_command"
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:38.544080
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "command"
    assert should_build()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "command"
    assert should_build()

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "command"
    assert should_build()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "command"
    assert should_build()


# Generated at 2022-06-24 01:37:39.209381
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:37:40.679413
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:37:41.401238
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:52.690779
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    config.set("build_command", "false")
    assert not should_build()

    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    config.set("build_command", "false")
    assert not should_build()

    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    config.set("build_command", "false")
    assert not should_build()

    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")

# Generated at 2022-06-24 01:37:53.758372
# Unit test for function remove_dists
def test_remove_dists():
    assert(1==1)

# Generated at 2022-06-24 01:37:54.593934
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")

# Generated at 2022-06-24 01:37:55.659549
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    assert should_build() == True

# Generated at 2022-06-24 01:37:58.362790
# Unit test for function remove_dists
def test_remove_dists():
    test_path = "/tmp/test"
    command = f"rm -rf {test_path}"
    assert command == remove_dists(test_path)


# Generated at 2022-06-24 01:37:59.521838
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:00.463463
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:10.747811
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo \"[bdist_wheel]\""
    assert should_remove_dist() == True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "echo \"[bdist_wheel]\""
    assert should_remove_dist() == False
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo \"[bdist_wheel]\""
    assert should_remove_dist() == True
    config["upload_to_pypi"] = "true"


# Generated at 2022-06-24 01:38:11.815072
# Unit test for function should_build
def test_should_build():
    assert should_build() is True, "Should build and upload to release"

# Generated at 2022-06-24 01:38:15.063481
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo hello"
    build_dists()



# Generated at 2022-06-24 01:38:18.897032
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:21.640487
# Unit test for function build_dists
def test_build_dists():
    # Init class
    logger.debug("Init test_build_dists")
    build_dists()

    # Assert
    logger.debug("Assertion test_build_dists")
    assert 1 == 1



# Generated at 2022-06-24 01:38:32.142024
# Unit test for function remove_dists
def test_remove_dists():
    assert should_build() == False
    assert should_remove_dist() == False
    assert build_dists() == None
    config["build_command"] = "python3 setup.py sdist"
    assert should_build() == False
    assert should_remove_dist() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    assert build_dists() == None
    config["remove_dist"] = True
    assert should_remove_dist() == True
    assert remove_dists("dist") == None
    assert should_build() == True
    assert should_remove_dist() == True
    config["build_command"] = "false"


# Generated at 2022-06-24 01:38:38.412100
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert should_remove_dist()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:42.940169
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:44.441978
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:38:45.981632
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception as e:
        assert e


# Generated at 2022-06-24 01:38:49.813543
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build(True, True) is True
    assert should_build(False, True) is True
    assert should_build(True, False) is True
    assert should_build(False, False) is False
    assert should_build(True, False, False) is False

# Generated at 2022-06-24 01:39:00.156639
# Unit test for function should_build
def test_should_build():
    # Test 1
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert not should_build()

    # Test 2
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "false")
    assert not should_build()

    # Test 3
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "sdist")
    assert should_build()

# Generated at 2022-06-24 01:39:10.977219
# Unit test for function should_remove_dist
def test_should_remove_dist():

    config.update({"upload_to_pypi": True, "upload_to_release": False, "remove_dist": True, "build_command": "test"})
    assert should_remove_dist()

    config.update({"upload_to_pypi": False, "upload_to_release": False, "remove_dist": True, "build_command": "test"})
    assert not should_remove_dist()

    config.update({"upload_to_pypi": True, "upload_to_release": True, "remove_dist": True, "build_command": "test"})
    assert should_remove_dist()

    config.update({"upload_to_pypi": True, "upload_to_release": True, "remove_dist": False, "build_command": "test"})

# Generated at 2022-06-24 01:39:14.402820
# Unit test for function should_build
def test_should_build():
    assert bool(should_build() is True)

# Generated at 2022-06-24 01:39:25.120583
# Unit test for function should_build
def test_should_build():
    remove_dist = config.get("remove_dist")
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")

    if remove_dist or upload_pypi or upload_release:
        assert should_build() is True
    else:
        assert should_build() is False

    config["upload_to_pypi"] = False
    assert should_build() is False
    config["upload_to_release"] = False
    assert should_build() is False
    config["upload_to_release"] = True
    config["build_command"] = False
    assert should_build() is False

    config["upload_to_pypi"] = True