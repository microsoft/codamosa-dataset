

# Generated at 2022-06-24 01:29:19.451602
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo 'building dists'"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    build_dists()



# Generated at 2022-06-24 01:29:21.128734
# Unit test for function remove_dists
def test_remove_dists():
    path = "./dist"
    remove_dists(path)

# Generated at 2022-06-24 01:29:31.872005
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = True

# Generated at 2022-06-24 01:29:37.525100
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # upload_pypi is true, upload_release is false, and remove_dist is true
    assert should_remove_dist(True, False, True) is True
    # upload_pypi is true, upload_release is true, and remove_dist is true
    assert should_remove_dist(True, True, True) is True
    # upload_pypi is false, upload_release is true, and remove_dist is false
    assert should_remove_dist(False, True, False) is False
    # upload_pypi is false, upload_release is false, and remove_dist is false
    assert should_remove_dist(False, False, False) is False



# Generated at 2022-06-24 01:29:37.996249
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:42.264585
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Example for working scenario
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    config["remove_dist"] = True

    assert should_remove_dist()

    # Example when build_dist is not set
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:29:43.294480
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("foo/bar")  # FIXME: Fix this


# Generated at 2022-06-24 01:29:46.612843
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:52.223737
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "this is a build command"
    config["remove_dist"] = "false"
    result = should_remove_dist()
    assert result is False
    config["remove_dist"] = "true"
    result = should_remove_dist()
    assert result is True


# Generated at 2022-06-24 01:29:52.709326
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:53.862322
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:03.892323
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.config = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "echo",
        "remove_dist": False,
    }
    assert should_remove_dist() == False

    config.config = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "echo",
        "remove_dist": True,
    }
    assert should_remove_dist() == True

    config.config = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "echo",
        "remove_dist": True,
    }
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:05.571321
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist") and should_build()

# Generated at 2022-06-24 01:30:08.427422
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:10.296785
# Unit test for function remove_dists
def test_remove_dists():
    path = "dist/"
    remove_dists(path)


# Generated at 2022-06-24 01:30:19.358259
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.update({"build_command": "test"})
    config.update({"upload_to_pypi": False})
    config.update({"upload_to_release": False})
    assert should_build() == False
    config.update({"build_command": "test"})
    config.update({"upload_to_pypi": True})
    config.update({"upload_to_release": False})
    assert should_build() == True
    config.update({"build_command": "test"})
    config.update({"upload_to_pypi": False})
    config.update({"upload_to_release": True})
    assert should_build() == True
    config.update({"build_command": "test"})

# Generated at 2022-06-24 01:30:20.028702
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:21.450709
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("~/.pigar/")


# Generated at 2022-06-24 01:30:22.164529
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path = 'test_path')

# Generated at 2022-06-24 01:30:23.055063
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist/*")

# Generated at 2022-06-24 01:30:26.150104
# Unit test for function remove_dists
def test_remove_dists():
    from .test import temp_dir
    with temp_dir() as temp:
        remove_dists(temp)

# Generated at 2022-06-24 01:30:27.000221
# Unit test for function build_dists
def test_build_dists():
    print(build_dists())


# Generated at 2022-06-24 01:30:27.463109
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:29.657875
# Unit test for function build_dists
def test_build_dists():
    command = config.get('build_command')
    logger.info(f"Running {command}")
    run(command, hide=True)


# Generated at 2022-06-24 01:30:34.250459
# Unit test for function should_build
def test_should_build():
    config.remove("current_tag")
    config["upload_to_pypi"] = "true"
    config["build_command"] = "python setup.py sdist"
    build = should_build()
    assert build == True



# Generated at 2022-06-24 01:30:35.812299
# Unit test for function remove_dists
def test_remove_dists():
    command = "ls -l"
    test_command = f"rm -rf {command}"
    assert test_command == remove_dists(command)

# Generated at 2022-06-24 01:30:36.997619
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    assert should_remove_dist() is False
    assert build_dists() is None
    assert remove_dists("") is None

# Generated at 2022-06-24 01:30:39.139050
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'Make sdist' && echo 'Make bdist_wheel'"
    logger.info(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:30:46.421959
# Unit test for function should_build
def test_should_build():
    class MockSettings:
        def __init__(self, config):
            self.config = config
        def get(self, name):
            return self.config[name]

    class MockConfig:
        def __init__(self, config):
            self.config = MockSettings(config)

    config = MockConfig({"build_command": "echo 'hi'"})
    assert should_build()

    config = MockConfig({"build_command": "echo 'hi'", "upload_to_pypi": True})
    assert should_build()

    config = MockConfig({"build_command": "echo 'hi'", "upload_to_release": True})
    assert should_build()

    config = MockConfig({"build_command": "echo 'hi'", "upload_to_pypi": False})
    assert should_

# Generated at 2022-06-24 01:30:50.497733
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert not should_remove_dist()
    config["build_command"] = "build_command"
    assert should_remove_dist()



# Generated at 2022-06-24 01:30:51.731307
# Unit test for function build_dists
def test_build_dists():
    return True


# Generated at 2022-06-24 01:30:58.798457
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import consoler
    from .utils.consoler import INDENT_SIZE
    from .utils.consoler import ClassIndenter
    from .utils.context_managers import make_temp_path

    with consoler.redirected():
        with consoler.suppressed_logging():
            with make_temp_path() as test_path:
                remove_dists(path=test_path)

                assert not consoler.log.messages[1]["indent"] == \
                       consoler.log.messages[0]["indent"] + INDENT_SIZE

            with ClassIndenter(level=1):
                remove_dists(path=test_path)

                assert consoler.log.messages[1]["indent"] == \
                       consoler.log.messages[0]["indent"] + IND

# Generated at 2022-06-24 01:31:02.196126
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "ls"
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()


# Generated at 2022-06-24 01:31:10.207453
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = ""
    assert should_build() is False
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "echo"
    assert should_build() is True
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:31:16.287195
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-24 01:31:24.622700
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # GIVEN
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    config.set("build_command", "false")

    # EXPECT
    assert not should_remove_dist()

    # GIVEN
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    config.set("build_command", "echo 1")

    # EXPECT
    assert not should_remove_dist()

    # GIVEN
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "echo 1")

    # EXPECT
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:25.658536
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-24 01:31:29.925755
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False
    config.set("upload_to_pypi", True)
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:31:38.445218
# Unit test for function should_build
def test_should_build():
    init_config = config.copy()
    config["upload_to_pypi"] = True
    config["build_command"] = "echo test"

    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_pypi"] = True
    config["build_command"] = False
    assert not should_build()

    # Return config to inital state
    config.clear()
    config.update(init_config)

# Generated at 2022-06-24 01:31:38.906765
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:39.405466
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()

# Generated at 2022-06-24 01:31:45.874614
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "poop"
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist()

    config["remove_dist"] = False
    config["build_command"] = "poop"
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = "false"
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert not should_remove_dist()



# Generated at 2022-06-24 01:31:52.523137
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test with default default
    assert should_remove_dist() == True

    # Test with remove_dist set to False
    config["remove_dist"] = False
    assert should_remove_dist() == False

    # Test with build_command set to False
    config["build_command"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:31:53.865721
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-24 01:31:59.113852
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import get_config
    path = f"{get_config('project_root')}/dist"
    assert path
    remove_dists(path)
    assert not os.path.isdir(path)

# Generated at 2022-06-24 01:32:05.389592
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_for_testing = {
        "build_command": "pwd",
        "upload_to_pypi": "false",
        "upload_to_release": "false",
    }
    config.load_config(config_for_testing)
    assert should_remove_dist() == False

    config_for_testing = {
        "build_command": "false",
        "upload_to_pypi": "false",
        "upload_to_release": "false",
    }
    config.load_config(config_for_testing)
    assert should_remove_dist() == False

    config_for_testing = {
        "build_command": "pwd",
        "upload_to_pypi": "true",
        "upload_to_release": "true",
    }

# Generated at 2022-06-24 01:32:07.879534
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import get_release_path
    remove_dists(get_release_path())

# Generated at 2022-06-24 01:32:10.208244
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:17.846626
# Unit test for function build_dists
def test_build_dists():
    try:
        config["build_command"] = "false"
        assert not should_build()
        config["build_command"] = False
        assert not should_build()
    except:
        assert False

    try:
        config["build_command"] = "cd .."
        config["upload_to_pypi"] = "false"
        config["upload_to_release"] = "false"
        assert not should_build()
        config["upload_to_pypi"] = False
        config["upload_to_release"] = False
        assert not should_build()
    except:
        assert False


# Generated at 2022-06-24 01:32:18.930833
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-24 01:32:19.412976
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()

# Generated at 2022-06-24 01:32:25.966813
# Unit test for function should_build
def test_should_build():
    config["build_command"] = False
    assert not should_build()
    config["build_command"] = True
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()


# Generated at 2022-06-24 01:32:27.928457
# Unit test for function build_dists
def test_build_dists():
    if should_build():
        build_dists()
    else:
        logger.info("No build command was provided")



# Generated at 2022-06-24 01:32:31.842785
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.update({"remove_dist": "true"})
    assert should_remove_dist() is False
    config.update({"remove_dist": "true", "upload_to_pypi": "true"})
    assert should_remove_dist() is True
    config.update({"remove_dist": "true", "upload_to_release": "true"})
    assert should_remove_dist() is True
    config.update({"remove_dist": "true", "upload_to_pypi": "",
                   "upload_to_release": ""})
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:32:32.431263
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:33.740779
# Unit test for function should_build
def test_should_build():
    assert should_build() == (True and (True or False))



# Generated at 2022-06-24 01:32:34.344708
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:37.055856
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:32:39.548398
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should return True when config.remove_dist is true
    config.remove_dist = True
    assert should_remove_dist()

    # Should return False when config.remove_dist is false
    config.remove_dist = False
    assert not should_remove_dist()

    # Should return True when config.remove_dist is not set
    del config.remove_dist
    assert should_remove_dist()



# Generated at 2022-06-24 01:32:42.833837
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="dist")

# Generated at 2022-06-24 01:32:43.398578
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:44.764202
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:32:52.921544
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build-command"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False



# Generated at 2022-06-24 01:32:53.826203
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("fake_directory")

# Generated at 2022-06-24 01:32:54.656807
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:58.118934
# Unit test for function should_remove_dist
def test_should_remove_dist():
    import pytest
    assert should_remove_dist() == False
    assert should_remove_dist() == False
    assert should_remove_dist() == False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:33:03.230424
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir -p mock")
    try:
        remove_dists("mock")
        assert False
    except:
        pass

if __name__ == "__main__":
    build_dists()
    if should_remove_dist():
        remove_dists("dist")

# Generated at 2022-06-24 01:33:09.610352
# Unit test for function should_build
def test_should_build():
    config.pop("upload_to_release")
    assert should_build() == False
    config["upload_to_pypi"] = True
    config["build_command"] = "echo test"
    assert should_build() == True



# Generated at 2022-06-24 01:33:10.160733
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:14.432785
# Unit test for function should_build
def test_should_build():
    assert should_build() == False  # pylint: disable=E111



# Generated at 2022-06-24 01:33:15.006148
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:15.789838
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:33:20.539589
# Unit test for function should_build
def test_should_build():
    # With nothing set
    assert should_build() is False
    # With false build command
    config.set("build_command", "false")
    assert should_build() is False
    # With build command and upload_to_pypi
    config.set("build_command", "poetry build")
    config.set("upload_to_pypi", True)
    assert should_build() is True
    # With build command and upload_to_release
    config.set("build_command", "poetry build")
    config.set("upload_to_release", True)
    assert should_build() is True



# Generated at 2022-06-24 01:33:21.408180
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:24.863190
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Test for function should_remove_dist
    """
    assert(should_remove_dist() is True)
    config.set("remove_dist", "false")
    assert(should_remove_dist() is False)
    config.set("remove_dist", "true")



# Generated at 2022-06-24 01:33:25.721441
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tmp")

# Generated at 2022-06-24 01:33:29.258367
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    tmp_path = tempfile.TemporaryDirectory()
    remove_dists(tmp_path.name)

# Generated at 2022-06-24 01:33:31.269057
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:33:43.421208
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "/tmp/build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert should_remove_dist()

    config["build_command"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["remove_dist"] = True
    assert not should_remove_dist()

    config["build_command"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["remove_dist"] = True
    assert not should_remove_dist()

    config["build_command"] = "/tmp/build"
    config["upload_to_pypi"] = True


# Generated at 2022-06-24 01:33:44.873783
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() == "not implemented"


# Generated at 2022-06-24 01:33:53.640703
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    config["build_command"] = "true"
    config["remove_dist"] = True
    assert(should_remove_dist())

    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    assert(not should_remove_dist())

    config["upload_to_pypi"] = True
    assert (should_remove_dist())

    config["build_command"] = "false"
    assert(not should_remove_dist())

    config["build_command"] = "true"
    config["remove_dist"] = False
    assert(not should_remove_dist())

# Generated at 2022-06-24 01:33:55.634352
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:33:56.584261
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/dists")

# Generated at 2022-06-24 01:33:58.534120
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert not should_remove_dist()
    build_dists()

# Generated at 2022-06-24 01:33:59.228406
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:02.665335
# Unit test for function remove_dists
def test_remove_dists():
    old_path = config.get("dist_path")
    assert remove_dists(old_path) == old_path
    new_path = config.get("dist_path")
    assert old_path != new_path

# Generated at 2022-06-24 01:34:03.929948
# Unit test for function build_dists
def test_build_dists():
    assert build_dists() is None



# Generated at 2022-06-24 01:34:04.968145
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("temp_dist")

# Generated at 2022-06-24 01:34:13.860014
# Unit test for function should_remove_dist
def test_should_remove_dist():
    def get_config(value, upload_to_pypi=True, upload_to_release=True):
        return {
            "build_command": "echo true",
            "remove_dist": value,
            "upload_to_pypi": upload_to_pypi,
            "upload_to_release": upload_to_release,
        }

    # noqa: E999 - this is for the debug message
    config.update(get_config(True))
    assert should_remove_dist() is True
    config.update(get_config(False))
    assert should_remove_dist() is False

    # Test removing dist when build command is false
    config.update(get_config(True, upload_to_pypi=False, upload_to_release=False))

# Generated at 2022-06-24 01:34:20.096849
# Unit test for function should_build
def test_should_build():
    config.set_section("build", values={
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "echo hello",
    })
    assert should_build()
    config.set_section("build", values={
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "echo hello",
    })
    assert should_build()
    config.set_section("build", values={
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "echo hello",
    })
    assert not should_build()

# Generated at 2022-06-24 01:34:23.263248
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.configure({"build_command": "sphinx-build", "remove_dist": True})
    assert should_remove_dist()
    config.configure({"build_command": "false", "remove_dist": True})
    assert not should_remove_dist()

# Generated at 2022-06-24 01:34:26.341020
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path='/Users/jgarcia/Projects/pytd/dist')

# Generated at 2022-06-24 01:34:37.209308
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:34:46.491828
# Unit test for function should_build
def test_should_build():
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()
    config["upload_to_release"] = False
    assert not should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = False
    assert not should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert not should_build()



# Generated at 2022-06-24 01:34:47.804480
# Unit test for function build_dists
def test_build_dists():
    logging.basicConfig(level=logging.DEBUG)
    build_dists()


# Generated at 2022-06-24 01:34:51.756374
# Unit test for function build_dists
def test_build_dists():
    command = "pipenv run python setup.py sdist bdist_wheel"
    logger.info(f"Running {command}")
    run(command)


# Generated at 2022-06-24 01:35:01.871199
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    result = should_build()
    assert result is True

    config["upload_to_pypi"] = "false"
    result = should_build()
    assert result is True

    config["upload_to_release"] = "false"
    result = should_build()
    assert result is False

    config["upload_to_pypi"] = "true"
    result = should_build()
    assert result is False

    config["build_command"] = "false"
    result = should_build()
    assert result is False

    config["upload_to_release"] = "true"
    result = should_build()
    assert result is False

   

# Generated at 2022-06-24 01:35:07.821781
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .utils import make_context

    ctx = make_context({"remove_dist": "true", "build_command": "sdist"})
    assert should_remove_dist(ctx) is True

    ctx = make_context({"remove_dist": "true", "build_command": "false"})
    assert should_remove_dist(ctx) is False

    ctx = make_context({"remove_dist": "true", "build_command": False})
    assert should_remove_dist(ctx) is False

# Generated at 2022-06-24 01:35:15.450068
# Unit test for function should_remove_dist
def test_should_remove_dist():
    with config.set("build_command", '"echo pippo"'):
        assert should_remove_dist() == False
    with config.set("remove_dist", '"echo pippo"'):
        assert should_remove_dist() == False
    with config.set("upload_to_pypi", '"echo pippo"'):
        assert should_remove_dist()
    with config.set("upload_to_release", '"echo pippo"'):
        assert should_remove_dist()
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:35:24.768126
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil
    def mock_run(command):
        """use instead of invoke.run to mock command run"""
        pass
    build_command = "echo 'twine upload'"
    config.set("remove_dist", "true")
    config.set("upload_to_pypi", "true")
    config.set("build_command", build_command)
    os.makedirs('path/to/dist')
    with open('path/to/dist/file1.txt', 'w'):
        pass
    remove_dists('path/to/dist')
    assert not os.path.isdir('path/to/dist')
    shutil.rmtree('path/to')



# Generated at 2022-06-24 01:35:25.880737
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:35:29.450122
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build" 
    config["remove_dist"] = True
    assert should_remove_dist() is True

    config["build_command"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:35:37.609742
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "twine")
    assert should_build()

    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    config.set("build_command", "twine")
    assert should_build()

    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    config.set("build_command", "twine")
    assert should_build()

    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")

# Generated at 2022-06-24 01:35:38.586614
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:35:45.416583
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:35:47.127728
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:35:47.666097
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:35:50.335154
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    config["build_command"] = "test"
    assert should_build() == True


# Generated at 2022-06-24 01:35:51.157291
# Unit test for function should_build
def test_should_build():
    assert should_build() is False



# Generated at 2022-06-24 01:35:51.684514
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist/*")


# Generated at 2022-06-24 01:36:01.727462
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    assert not should_build()

    config["build_command"] = "false"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = None
    
    assert not should_build()

    config["build_command"] = "false"
    config["upload_to_pypi"] = None
    config["upload_to_release"] = True
    
    assert not should_build()

    config["build_command"] = "test"
    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    
    assert should_build()


# Generated at 2022-06-24 01:36:05.049496
# Unit test for function build_dists
def test_build_dists():
    should_build_dists = should_build()
    if should_build_dists:
        logger.info("Build dists")
        build_dists()
    else:
        logger.info("Skip build dists in this run")
    return should_build_dists



# Generated at 2022-06-24 01:36:06.425320
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:36:12.772915
# Unit test for function should_build
def test_should_build():
    test_config = {}
    assert not should_build()
    test_config["upload_to_pypi"] = False
    test_config["upload_to_release"] = False
    test_config["build_command"] = False
    assert not should_build()
    test_config["upload_to_pypi"] = True
    assert should_build()
    test_config["upload_to_pypi"] = False
    test_config["upload_to_release"] = True
    assert should_build()
    test_config["upload_to_release"] = False
    test_config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-24 01:36:13.776880
# Unit test for function remove_dists
def test_remove_dists():
    assert should_build()
    assert should_remove_dist()
    remove_dists("dist")

# Generated at 2022-06-24 01:36:16.215252
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Test if should_remove_dist returns false if build is not enabled"""
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:26.582282
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist() is False
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["build_command"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:36:33.789087
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "echo this is a build command"
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["upload_to_pypi"] = "true"
    config["build_command"] = "echo this is a build command"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo this is a build command"
    assert should_build() is True



# Generated at 2022-06-24 01:36:37.135515
# Unit test for function remove_dists
def test_remove_dists():
    with open('test_py_projecs/build.log', 'r') as file:
        data = file.readlines()
    data = [line.split(' \n')[0] for line in data ]
    remove_dists(data[-1])

# Generated at 2022-06-24 01:36:47.040305
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should remove true
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist() == True
    # Should remove false
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_remove_dist() == False
    # Should remove false
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_remove_dist() == False
    # Should remove

# Generated at 2022-06-24 01:36:52.890642
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "make build"
    config["remove_dist"] = "true"
    assert should_remove_dist() is True

    config["remove_dist"] = "false"
    assert should_remove_dist() is False

    config["build_command"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:36:53.979824
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:37:01.058175
# Unit test for function remove_dists
def test_remove_dists():
    try:
        import pathlib
        from .settings import config
    except ImportError:
        logger.error("Skip unit test for function remove_dists")
    else:
        path = pathlib.Path("/tmp/dist_ut")
        path.mkdir(parents=True, exist_ok=True)
        config["remove_dist"] = True
        assert(should_remove_dist())
        try:
            remove_dists(str(path))
        except Exception:
            assert(False)
        assert not path.exists()

# Generated at 2022-06-24 01:37:04.735373
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:37:05.595728
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:37:11.013123
# Unit test for function remove_dists
def test_remove_dists():
    path = "test"
    rm_return = run("rm -rf test")
    assert rm_return.ok
    remove_dists(path)
    assert not rm_return.ok

# Generated at 2022-06-24 01:37:11.988652
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:12.541729
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:20.974543
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    assert should_remove_dist() == True
    config.set("remove_dist", "false")
    config.set("upload_to_pypi", "true")
    assert should_remove_dist() == True
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_remove_dist() == True
    config.set("upload_to_release", "false")
    config.set("build_command", "python setup.py sdist")
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:22.650595
# Unit test for function build_dists
def test_build_dists():
    command = "invoke build"
    build_dists()
    assert command == config.get(build_command)

# Generated at 2022-06-24 01:37:23.288337
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:24.108422
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:37:27.163241
# Unit test for function remove_dists
def test_remove_dists():
    # test function remove_dists with a valid path
    remove_dists("dist")



# Generated at 2022-06-24 01:37:36.969739
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": "true", "build_command": "true"})
    assert should_remove_dist()

    config.update({"remove_dist": "true", "build_command": "false"})
    assert not should_remove_dist()

    config.update({"remove_dist": "false", "build_command": "true"})
    assert not should_remove_dist()

    config.update({"remove_dist": "false", "build_command": "false"})
    assert not should_remove_dist()



# Generated at 2022-06-24 01:37:47.258942
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    assert not should_remove_dist()
    config["upload_to_pypi"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:48.610013
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True



# Generated at 2022-06-24 01:37:56.289034
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    test_config = {"build_command": "build_command"}
    config["test"] = test_config

    assert should_build()
    del config["test"]

    test_config = {"build_command": "build_command", "upload_to_pypi": True}
    config["test"] = test_config

    assert should_build()
    del config["test"]

    test_config = {"build_command": "build_command", "upload_to_release": True}
    config["test"] = test_config

    assert should_build()
    del config["test"]

# Generated at 2022-06-24 01:37:58.021475
# Unit test for function build_dists
def test_build_dists():
    command = "ls -l"
    logger.info(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:37:58.674566
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:07.074467
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import tmp_dir
    from .settings import TEMPDIR
    from os.path import join
    test_dir_path = join(TEMPDIR, "dist")
    with tmp_dir(test_dir_path):
        test_dist_path = join(test_dir_path, "test_dist")
        run(f"mkdir {test_dist_path}")
        assert remove_dists(test_dist_path)
        # Make sure it is removed
        run(f"ls {test_dist_path}", warn=True)

# Generated at 2022-06-24 01:38:11.032137
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# if should_build():
#     if should_remove_dist():
#         remove_dists(config["dist_path"])
#     build_dists()

# Generated at 2022-06-24 01:38:11.848570
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(config.get("dist_path"))

# Generated at 2022-06-24 01:38:14.452692
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:14.956499
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:19.771483
# Unit test for function build_dists
def test_build_dists():
    command = "echo 'Test Run'"
    config["build_command"] = command
    build_dists()
    assert command in capture("logs", "debug")



# Generated at 2022-06-24 01:38:20.757181
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist(), "Should remove dist"

# Generated at 2022-06-24 01:38:21.601668
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:38:22.777977
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:38:23.314356
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:33.776038
# Unit test for function should_build
def test_should_build():
    def fake_config(**kwargs):
        return config(
            **{
                "upload_to_pypi": kwargs.get("upload_to_pypi", False),
                "upload_to_release": kwargs.get("upload_to_release", False),
                "build_command": kwargs.get("build_command", False),
            }
        )

    with fake_config() as nconfig:
        assert not should_build()

    with fake_config(upload_to_pypi=True) as nconfig:
        assert should_build()

    with fake_config(upload_to_release=True) as nconfig:
        assert should_build()


# Generated at 2022-06-24 01:38:45.365376
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Only remove_dist is True it should return True
    assert should_remove_dist(
        {'remove_dist': True, 'upload_to_pypi': False, 'upload_to_release': False,
         'build_command': 'true'}) is True

    # Only remove_dist is True and should_build is False it should return False
    assert should_remove_dist(
        {'remove_dist': True, 'upload_to_pypi': False, 'upload_to_release': False,
         'build_command': 'false'}) is False

    # Only remove_dist is False it should return False

# Generated at 2022-06-24 01:38:46.542791
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:38:48.117759
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("test") == None


# Generated at 2022-06-24 01:38:51.857953
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="dist")

# Generated at 2022-06-24 01:38:54.976027
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config["remove_dist"] = "true"
    assert not should_remove_dist()

    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:58.146535
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")

# Generated at 2022-06-24 01:39:00.623015
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["build_command"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:39:08.223425
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["upload_to_release"] = "true"
    assert should_remove_dist()
    config["upload_to_pypi"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert should_remove_dist()

# Generated at 2022-06-24 01:39:09.294873
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/dist")



# Generated at 2022-06-24 01:39:11.103565
# Unit test for function build_dists
def test_build_dists():
    build_command = config.get("build_command")
    assert "sdist" in build_command
    build_dists()

# Generated at 2022-06-24 01:39:14.403298
# Unit test for function build_dists
def test_build_dists():
    # run(command)
    assert True



# Generated at 2022-06-24 01:39:15.555321
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('/tmp') == None

# Generated at 2022-06-24 01:39:16.551210
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")
