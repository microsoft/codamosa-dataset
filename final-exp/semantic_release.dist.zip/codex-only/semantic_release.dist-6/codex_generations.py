

# Generated at 2022-06-24 01:29:14.510482
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:29:15.045876
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:16.211727
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:29:18.768906
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    assert should_remove_dist()



# Generated at 2022-06-24 01:29:26.254122
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:29:37.434501
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Test that should_remove_dist() returns appropriate True/False values
    """
    # pylint: disable=W0612,W0613
    def test_case(config, expected):
        """test_case function
        """
        config["build_command"] = "echo 'hello world'"
        config["upload_to_pypi"] = "false"
        config["upload_to_release"] = "false"
        config["remove_dist"] = "true"
        assert should_remove_dist() == expected

    test_case(config, False)
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist

# Generated at 2022-06-24 01:29:38.454760
# Unit test for function build_dists
def test_build_dists():
    assert(build_dists() == True)


# Generated at 2022-06-24 01:29:39.264704
# Unit test for function remove_dists
def test_remove_dists():
    assert isinstance(remove_dists, object)

# Generated at 2022-06-24 01:29:44.362711
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:29:46.949844
# Unit test for function should_build
def test_should_build():
    assert should_build() == config.get("build_command")

# Generated at 2022-06-24 01:29:50.089969
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist() is True
    config["remove_dist"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:29:53.820763
# Unit test for function remove_dists
def test_remove_dists():
    command = 'rm -rf dist'
    remove_dists(command)



# Generated at 2022-06-24 01:30:03.134430
# Unit test for function should_build
def test_should_build():
    import tempfile
    from os.path import join

    tmp_folder = tempfile.gettempdir()
    config["build_command"] = "false"
    config["upload_to_pypi"] = True
    assert should_build() is False

    config["build_command"] = f"cd {tmp_folder} && touch test"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True

    config["remove_dist"] = False
    assert should_remove_dist() is False

    remove_dists(join(tmp_folder, "test"))
    config["remove_dist"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:30:06.951937
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    from shutil import copyfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        copyfile("invoke.py", f"{tmpdirname}/invoke.py")
        remove_dists(tmpdirname)

# Generated at 2022-06-24 01:30:07.956661
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:30:08.568086
# Unit test for function build_dists
def test_build_dists():
    should_build()

# Generated at 2022-06-24 01:30:14.681131
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({
        "remove_dist": "true",
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "dummy command"
    })
    assert should_remove_dist()

    config.update({
        "remove_dist": "false",
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "dummy command",
    })
    assert not should_remove_dist()



# Generated at 2022-06-24 01:30:16.564516
# Unit test for function remove_dists
def test_remove_dists():
    from unittest.mock import MagicMock
    m = MagicMock()
    remove_dists(m)
    assert m.called



# Generated at 2022-06-24 01:30:24.152928
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist()

    config.set("remove_dist", False)
    assert not should_remove_dist()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_remove_dist()



# Generated at 2022-06-24 01:30:24.691409
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:32.959171
# Unit test for function remove_dists
def test_remove_dists():
    import shutil
    import tempfile
    import pathlib

    dirpath = tempfile.mkdtemp()
    file1 = pathlib.Path(dirpath)/"file1.txt"
    file2 = pathlib.Path(dirpath)/"file2.txt"
    file1.touch()
    file2.touch()

    remove_dists(path=dirpath)

    assert not pathlib.Path(dirpath).exists()
    shutil.rmtree(dirpath)

# Generated at 2022-06-24 01:30:35.778991
# Unit test for function build_dists
def test_build_dists():
    # TODO(pbouschitz): adding this for initial tests.
    # Need to figure out a real way to handle settings/config.
    # Perhaps inject them for testing?
    config["build_command"] = "false"
    build_dists()

# Generated at 2022-06-24 01:30:45.186648
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "make build"
    output = should_build()
    assert output
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "make build"
    output = should_build()
    assert output
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = False
    output = should_build()
    assert not output
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = False
    output = should_build()
    assert not output

# Generated at 2022-06-24 01:30:53.058183
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "false")
    assert should_remove_dist() == False

    config.set("remove_dist", "true")
    assert should_remove_dist() == True

    config.set("upload_to_release", "false")
    assert should_remove_dist() == False

    config.set("upload_to_release", "true")
    assert should_remove_dist() == True

    config.set("build_command", "false")
    assert should_remove_dist() == False

    config.set("build_command", "true")
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:03.368449
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "python"
    assert should_remove_dist() is True

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "python"
    assert should_remove_dist() is True

    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "python"
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:31:06.343689
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:31:09.057956
# Unit test for function build_dists
def test_build_dists():
    assert should_build()



# Generated at 2022-06-24 01:31:17.325276
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    # Only one build command (build_command), one upload (upload_pypi)
    config.set("build_command", "echo build_command")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build() == True

    # Build command (build_command), two upload (upload_pypi, upload_release)
    config.set("build_command", "echo build_command")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build() == True

    # Not build command (build_command), one upload (upload_pypi)
    config.set("build_command", "false")

# Generated at 2022-06-24 01:31:25.027481
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "test"
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = "test"
    assert should_build()
    config["build_command"] = False
    assert not should_build()


# Generated at 2022-06-24 01:31:25.609905
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:31:35.991978
# Unit test for function should_build
def test_should_build():
    config_data = {
        "upload_to_pypi": True
    }
    config.update(config_data)
    assert should_build(), "If upload_to_pypi is True, should_build should return True"
    config_data = {
        "upload_to_release": True
    }
    config.update(config_data)
    assert should_build(), "If upload_to_release is True, should_build should return True"
    config_data = {
        "build_command" : "build_something"
    }
    config.update(config_data)
    assert should_build(), "If build_command is not 'false', should_build should return True"
    config_data = {
        "build_command" : "false"
    }
    config.update(config_data)

# Generated at 2022-06-24 01:31:37.041162
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:31:37.581122
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:31:44.974187
# Unit test for function should_build
def test_should_build():
    """Unit test for function should_build
    """
    assert not should_build()
    config.update({"build_command": "python setup.py clean", "upload_to_pypi": True, "upload_to_release": False})
    assert should_build()
    config.update({"build_command": "python setup.py clean", "upload_to_pypi": False, "upload_to_release": True})
    assert should_build()
    config.update({"build_command": "python setup.py clean sdist bdist_egg bdist_wheel", "upload_to_pypi": True, "upload_to_release": True})
    assert should_build()

# Generated at 2022-06-24 01:31:54.451138
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "True"
    config["upload_to_pypi"] = "True"
    config["build_command"] = "True"
    assert should_remove_dist() == True
    config["build_command"] = "False"
    assert should_remove_dist() == False
    config["build_command"] = "True"
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "False"
    assert should_remove_dist() == False
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "True"
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:31:58.380862
# Unit test for function build_dists
def test_build_dists():
    pass


if __name__ == "__main__":
    test_build_dists()

# Generated at 2022-06-24 01:32:06.749157
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Run should_remove_dist() to ensure that it works with expected inputs
    """

    old_config = config.copy()
    config.update({"remove_dist": False, "upload_to_pypi": False, "upload_to_release": False, "build": False, "build_command": False})
    assert should_remove_dist() == False

    config.update({"remove_dist": True, "upload_to_pypi": False, "upload_to_release": False, "build": False, "build_command": False})
    assert should_remove_dist() == False

    config.update({"remove_dist": True, "upload_to_pypi": False, "upload_to_release": True, "build": False, "build_command": False})

# Generated at 2022-06-24 01:32:10.893857
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist()
    remove_dists("dist")



# Generated at 2022-06-24 01:32:18.190712
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "python setup.py sdist"
    assert should_build() == True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = ""
    assert should_build() == False
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = ""
    config["build_command"] = "python setup.py sdist"
    assert should_build() == False
    config["upload_to_pypi"] = ""
    config["upload_to_release"] = "false"
    config["build_command"] = ""

# Generated at 2022-06-24 01:32:20.142134
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert not should_remove_dist()
    build_dists()

# Generated at 2022-06-24 01:32:23.646655
# Unit test for function should_build
def test_should_build():
    config.reset_config()
    assert should_build() is False


# Generated at 2022-06-24 01:32:24.973483
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:32:26.093694
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:32:37.193322
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Test the should_remove_dist function with various inputs
    """
    assert not should_remove_dist()
    config.set("remove_dist", "false")
    assert not should_remove_dist()
    config.set("remove_dist", "True")
    assert not should_remove_dist()
    config.set("build_command", "true")
    assert not should_remove_dist()
    config.set("upload_to_pypi", "true")
    assert should_remove_dist()
    config.set("upload_to_pypi", "false")
    assert not should_remove_dist()
    config.set("upload_to_release", "true")
    assert should_remove_dist()
    config.set("upload_to_release", "false")
    assert not should_remove_dist()
   

# Generated at 2022-06-24 01:32:45.706253
# Unit test for function should_build
def test_should_build():
    test = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "True",
        "result": True,
    }
    config["upload_to_pypi"] = test["upload_to_pypi"]
    config["upload_to_release"] = test["upload_to_release"]
    config["build_command"] = test["build_command"]
    assert should_build() == test["result"]
    test = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "True",
        "result": True,
    }
    config["upload_to_pypi"] = test["upload_to_pypi"]
    config["upload_to_release"]

# Generated at 2022-06-24 01:32:54.777376
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Case 1: remove_dist is set but no build command
    assert not should_remove_dist()

    # Case 2: remove_dist is set and build command is set
    config.set("build_command", "echo 'Hello'")
    assert not should_remove_dist()

    # Case 3: remove_dist is set and build command is false
    config.set("remove_dist", "true")
    assert not should_remove_dist()

    # Case 4: remove_dist is set and build is to be uploaded
    config.set("upload_to_pypi", True)
    assert should_remove_dist()



# Generated at 2022-06-24 01:32:55.805097
# Unit test for function should_build
def test_should_build():
    assert should_build() is False


# Generated at 2022-06-24 01:32:57.828899
# Unit test for function should_build
def test_should_build():
    assert config.get("build_command") == "true"
    assert should_build() is True
    config.set("upload_to_pypi", False)
    assert should_build() is True
    config.set("build_command", "false")
    assert should_build() is False


# Generated at 2022-06-24 01:33:02.595455
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Unit test for function should_remove_dist
    """
    config["build_command"] = "pyroma . && poetry build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:33:03.462737
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')



# Generated at 2022-06-24 01:33:08.535832
# Unit test for function remove_dists
def test_remove_dists():
    path = "/Users/tunguyen/BerkeleyX/CS110X/project/test/"
    remove_dists(path)

# Generated at 2022-06-24 01:33:15.193436
# Unit test for function should_build
def test_should_build():
    import tempfile
    with tempfile.TemporaryDirectory() as directory:
        logger.debug(f"Patching config to use {directory}")
        with config.patch({'build_command': f'touch {directory}/build'}):
            assert should_build()
            build_dists()
            assert should_remove_dist()

# Generated at 2022-06-24 01:33:16.028638
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:20.251113
# Unit test for function should_build
def test_should_build():
    # Test should_build should return True
    assert should_build() is True
    # Test should_build should return True
    assert should_build() is not False
    # Test should_build should return False
    assert should_build() is not None


# Generated at 2022-06-24 01:33:21.509575
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:33:29.735215
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = None
    config["build_command"] = "test"
    assert should_build()
    config["upload_to_pypi"] = None
    config["upload_to_release"] = True
    config["build_command"] = "test"
    assert should_build()
    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    config["build_command"] = "test"
    assert not should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = None
    assert not should_build()
    config["upload_to_pypi"] = True

# Generated at 2022-06-24 01:33:38.628740
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("build_command", "test")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    config.set("remove_dist", True)
    config.set("build_command", "test")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:39.803255
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:33:44.394105
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:45.085953
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:46.851795
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:33:50.176176
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:33:51.295905
# Unit test for function build_dists
def test_build_dists():
    # Should not raise an exception
    build_dists()



# Generated at 2022-06-24 01:33:53.675912
# Unit test for function remove_dists
def test_remove_dists():
    import pytest
    from .settings import build_dir
    try:
        remove_dists(build_dir)
    except Exception as e:
        pytest.fail(e)

# Generated at 2022-06-24 01:34:00.191282
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil
    import tempfile

    try:
        directory = tempfile.mkdtemp()
        test = os.path.join(directory, "test")
        os.mkdir(test)

        assert os.path.exists(test)

        remove_dists(path=directory)

        assert not os.path.exists(test)
    finally:
        shutil.rmtree(directory)

# Generated at 2022-06-24 01:34:04.641341
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config._config = {
        "build_command": "python setup.py sdist bdist_wheel",
        "upload_to_pypi": True,
        "remove_dist": True,
        "dist_dir": "/dist"
    }
    assert should_remove_dist()

# Generated at 2022-06-24 01:34:12.121536
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.config = {
        'remove_dist': True,
        'build_command': True
    }
    assert should_remove_dist() == True
    config.config = {
        'remove_dist': False,
        'build_command': True
    }
    assert should_remove_dist() == False
    config.config = {
        'remove_dist': True,
        'build_command': False
    }
    assert should_remove_dist() == False
    config.config = {
        'remove_dist': False,
        'build_command': False
    }
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:34:17.892749
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = "testing"
    assert not should_build()
    config["build_command"] = False
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()


# Generated at 2022-06-24 01:34:18.474856
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:34:19.977674
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:34:24.882089
# Unit test for function should_build
def test_should_build():
    config['upload_to_pypi'] = 'true'
    config['upload_to_release'] = 'true'
    config['build_command'] = 'false'
    assert should_build() == False
    config['build_command'] = 'true'
    assert should_build() == True
    config['upload_to_pypi'] = 'false'
    assert should_build() == True
    config['upload_to_release'] = 'false'
    assert should_build() == False


# Generated at 2022-06-24 01:34:25.726423
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:33.844336
# Unit test for function should_build
def test_should_build():
    """test for function should_build
    """
    # with build_command and upload_to_pypi = true
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "command"
    assert should_build()  # pylint: disable=no-member

    # with build_command and upload_to_release = true
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "command"
    assert should_build()  # pylint: disable=no-member

    # with no build_command and upload_to_release = true
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
   

# Generated at 2022-06-24 01:34:37.470691
# Unit test for function remove_dists
def test_remove_dists():
    # TODO
    pass

# Generated at 2022-06-24 01:34:39.789140
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("dist")

# Generated at 2022-06-24 01:34:40.611809
# Unit test for function remove_dists
def test_remove_dists():
    assert True == True

# Generated at 2022-06-24 01:34:50.992842
# Unit test for function should_build
def test_should_build():
    # Should return False when no build_command is provided
    config.set_item("build_command", "")
    assert should_build() is False

    # Should return False if build_command is False
    config.set_item("build_command", "false")
    assert should_build() is False

    # Should return False if build_command is True
    config.set_item("build_command", "true")
    assert should_build() is False

    # Should return False if build_command is set and upload_pypi is False
    config.set_item("build_command", "ls")
    config.set_item("upload_to_pypi", "")
    assert should_build() is False

    # Should return False if build_command is set and upload_release is False

# Generated at 2022-06-24 01:34:54.344046
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    test_path = tempfile.mkdtemp()
    remove_dists(test_path)
    # TODO: Verify deletion



# Generated at 2022-06-24 01:34:55.383907
# Unit test for function remove_dists
def test_remove_dists():
    pass


# Generated at 2022-06-24 01:35:03.795811
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_false = dict(
        upload_to_pypi=False,
        upload_to_release=False,
        build_command="echo hi",
        remove_dist=True)
    config_true = dict(
        upload_to_pypi=True,
        upload_to_release=False,
        build_command="echo hi",
        remove_dist=True)
    assert should_remove_dist() is False
    config.update(config_false)
    assert should_remove_dist() is False
    config.update(config_true)
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:35:04.488843
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:35:05.049771
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:35:06.076006
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()

# Generated at 2022-06-24 01:35:13.369259
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["remove_dist"] = True

    assert should_remove_dist()
    remove_dists("dist")

    config["remove_dist"] = False
    assert not should_remove_dist()



# Generated at 2022-06-24 01:35:24.058373
# Unit test for function should_build
def test_should_build():
    # pylint: disable=unused-argument
    def test_case(config, expected):
        assert should_build() == expected

# Generated at 2022-06-24 01:35:30.279512
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.update({"build_command": "true"})
    assert should_build() == True
    config.update({"build_command": "false"})
    assert should_build() == False
    config.update({"upload_to_pypi": True})
    assert should_build() == True
    config.update({"upload_to_release": True})
    assert should_build() == True

# Generated at 2022-06-24 01:35:35.084783
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # No value in .envrc
    config = {}
    assert should_remove_dist() == False

    # No build command in .envrc
    config = {'build_command': "false"}
    assert should_remove_dist() == False

    # Should remove
    config = {'build_command': "true", 'remove_dist': "true"}
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:35.995846
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:35:38.538533
# Unit test for function build_dists
def test_build_dists():
    command = config.get("build_command")
    logger.info(f"Running {command}")
    run(command)



# Generated at 2022-06-24 01:35:45.785722
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "yes"
    assert should_build()
    config["upload_to_pypi"] = "no"
    config["upload_to_release"] = "yes"
    assert should_build()
    config["upload_to_pypi"] = "no"
    config["upload_to_release"] = "no"
    config["build_command"] = True
    assert should_build()

# Generated at 2022-06-24 01:35:54.007277
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_dict = {
        "remove_dist": True,
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": True
    }
    config.update(config_dict)
    assert should_remove_dist() is True

    config_dict = {
        "remove_dist": False,
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": True
    }
    config.update(config_dict)
    assert should_remove_dist() is False

    config_dict = {
        "remove_dist": True,
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": True
    }
    config.update

# Generated at 2022-06-24 01:36:00.932470
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist()
    try:
        path = "./dist"
        command = f"mkdir {path}"
        run(command)
        remove_dists(path)
        command = f"ls {path}"
        response = run(command, hide=True, warn=True)
        assert response.ok
        assert response.stdout.strip() == ""
    finally:
        run(f"rm -r {path}")

# Generated at 2022-06-24 01:36:11.165758
# Unit test for function remove_dists
def test_remove_dists():
    import os
    from os.path import exists
    from pyfakefs.fake_filesystem_unittest import Patcher
    from .settings import config
    from .utils import is_string

    dist_path = config.get("dist")
    if not is_string(dist_path):
        dist_path = dist_path[0]

    patcher = Patcher()
    patcher.setUp()
    # directories inside dist will be removed
    os.makedirs(dist_path, exist_ok=True)
    tmp_dir1 = os.path.join(dist_path, "tmp_dir1")
    tmp_dir2 = os.path.join(dist_path, "tmp_dir2")
    os.makedirs(tmp_dir1, exist_ok=True)

# Generated at 2022-06-24 01:36:14.627032
# Unit test for function remove_dists
def test_remove_dists():
    path = "./test_remove_path"
    run(f"mkdir {path}")
    assert path in run("ls")
    remove_dists(path)
    assert path not in run("ls")

# Generated at 2022-06-24 01:36:18.106792
# Unit test for function remove_dists
def test_remove_dists():
    from .upload import get_dists_path
    from .settings import config
    from .utils import rm_tree
    config["build_command"] = "false"
    path = get_dists_path()
    run("python setup.py sdist bdist_wheel build")
    remove_dists(path)
    rm_tree(path)

# Generated at 2022-06-24 01:36:25.870676
# Unit test for function remove_dists
def test_remove_dists():
    import shutil
    import tempfile
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.mkstemp()[1]
    remove_dists(tmp_dir)
    assert not os.path.exists(tmp_dir)
    remove_dists(tmp_file)
    assert os.path.exists(tmp_file)
    os.remove(tmp_file)
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-24 01:36:28.660922
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-24 01:36:29.468676
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == bool(True)

# Generated at 2022-06-24 01:36:38.961180
# Unit test for function should_build
def test_should_build():
    config['upload_to_pypi'] = 'false'
    config['upload_to_release'] = 'false'
    config['build_command'] = 'false'
    assert should_build() is False

    config['upload_to_pypi'] = 'false'
    config['upload_to_release'] = 'true'
    config['build_command'] = 'false'
    assert should_build() is False

    config['upload_to_pypi'] = 'false'
    config['upload_to_release'] = 'false'
    config['build_command'] = 'true'
    assert should_build() is False

    config['upload_to_pypi'] = 'true'
    config['upload_to_release'] = 'false'
    config['build_command'] = 'false'
    assert should_

# Generated at 2022-06-24 01:36:41.796532
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:36:44.104001
# Unit test for function should_build
def test_should_build():
    env = {"upload_to_pypi": "false",
           "upload_to_release": "false",
           "build_command": "echo"
           }
    assert should_build(env) is False

# Generated at 2022-06-24 01:36:46.591490
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True



# Generated at 2022-06-24 01:36:53.764948
# Unit test for function build_dists
def test_build_dists():
    """Test if correct command is build and ran.

    Arguments:
        None
    Returns:
        None
    """
    from .settings import config
    from .utils import temp_config
    from .package import Package

    with temp_config(config(), config_dict={
        "build_command": "build_command"
    }) as config:
        package = Package(config)
        build_dists()



# Generated at 2022-06-24 01:36:58.692481
# Unit test for function build_dists
def test_build_dists():
    # Test when build_command is invalid 
    assert not should_build(), "should_build() should be False"
    build_dists()
    # Test when build command is valid
    config.set("build_command", "echo test")
    assert should_build(), "should_build() should be True"
    build_dists()

# Generated at 2022-06-24 01:37:06.847320
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

# Generated at 2022-06-24 01:37:09.584678
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:37:10.505979
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:37:19.951366
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import Settings

    settings = Settings(
        {
            "upload_to_pypi": True,
            "upload_to_release": False,
            "build_command": "true",
            "remove_dist": True,
        }
    )
    remove_dist = should_remove_dist(settings)
    assert remove_dist

    settings = Settings(
        {
            "upload_to_pypi": True,
            "upload_to_release": False,
            "build_command": "false",
            "remove_dist": True,
        }
    )
    remove_dist = should_remove_dist(settings)
    assert not remove_dist


# Generated at 2022-06-24 01:37:21.559816
# Unit test for function remove_dists
def test_remove_dists():
    # Remove existing dists
    path = ".dist-for-test"
    run(f"mkdir {path}")
    remove_dists(path)
    assert not run(f"test -f {path}", hide=True).ok

# Generated at 2022-06-24 01:37:29.320130
# Unit test for function should_build
def test_should_build():
    """
    Test should_build
    """
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "ls"

    assert(should_build())
    assert(should_remove_dist())

    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "ls"

    assert(should_build())
    assert not(should_remove_dist())

    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "ls"


# Generated at 2022-06-24 01:37:36.360090
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:37:38.088632
# Unit test for function remove_dists
def test_remove_dists():
    assert 'dist' in remove_dists.__doc__
    remove_dists("test") == "rm -rf test"

# Generated at 2022-06-24 01:37:38.477111
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:39.353675
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()



# Generated at 2022-06-24 01:37:45.431129
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import shutil
    cwd = os.getcwd()
    folder = "dist"
    os.mkdir(folder)
    assert os.path.exists(folder)
    remove_dists(folder)
    assert not os.path.exists(folder)
    os.chdir(cwd)
    shutil.rmtree(folder)

# Generated at 2022-06-24 01:37:47.124077
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:37:49.203390
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

    config["remove_dist"] = False
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:37:50.815282
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="./dist")

# Generated at 2022-06-24 01:37:52.746566
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf dist"
    assert remove_dists("dist") == run(command)


# Generated at 2022-06-24 01:37:55.484979
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:55.986164
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:37:57.145862
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')

# Generated at 2022-06-24 01:38:06.632829
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config.update({"build_command": "true"})
    assert bool(should_build())

    config.update({"upload_to_pypi": True, "upload_to_release": True})
    assert bool(should_build())

    config.update({"upload_to_pypi": False, "upload_to_release": True})
    assert bool(should_build())

    config.update({"upload_to_pypi": True, "upload_to_release": False})
    assert bool(should_build())

    config.update({"build_command": "false"})
    assert not bool(should_build())



# Generated at 2022-06-24 01:38:09.467430
# Unit test for function build_dists
def test_build_dists():
    from unittest.mock import MagicMock
    from .settings import config
    config['build_command'] = "test"
    run = MagicMock()
    build_dists()
    run.assert_called_once()

# Generated at 2022-06-24 01:38:10.383265
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:38:14.250114
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:38:15.900306
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_build() == False
    assert should_build() == True


# Generated at 2022-06-24 01:38:17.484485
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:19.465168
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True, "Should remove dist"
    assert should_remove_dist() == False, "Should remove dist"


if __name__ == '__main__':
    test_should_remove_dist()

# Generated at 2022-06-24 01:38:22.943182
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:38:23.789217
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-24 01:38:34.252883
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo test"
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() is True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() is False

# Generated at 2022-06-24 01:38:39.784164
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["build_command"] = "python setup.py sdist"
    assert should_build()

    config["upload_to_pypi"] = False
    assert not should_build()

    config["upload_to_release"] = True
    assert should_build()

# Generated at 2022-06-24 01:38:43.231351
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_release", True)
    config.set("build_command", "false")
    assert should_build() == False, "Should not build when build_command is `false`"

# Generated at 2022-06-24 01:38:46.937488
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:38:48.156569
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('test/') == None

# Generated at 2022-06-24 01:38:53.022190
# Unit test for function remove_dists
def test_remove_dists():
    t = remove_dists
    assert t("build")
    assert not t("/tmp")
    assert not t("/")

# Generated at 2022-06-24 01:38:54.742013
# Unit test for function remove_dists
def test_remove_dists():
    path = "my/path"
    command = f"rm -rf {path}"
    run.side_effect = [None]

    remove_dists(path)

    run.assert_called_with(command)

# Generated at 2022-06-24 01:39:04.929446
# Unit test for function build_dists
def test_build_dists():
    import os
    from pytest import raises
    from os import environ
    from invoke import exceptions

    # Use whatever build command is set in the config
    config['build_command'] = 'echo "test"'
    old_build_command = config['build_command']

    build_dists()

    # Ensure build commands can be run with the default settings
    config['build_command'] = old_build_command
    build_dists()

    config['build_command'] = 'false'
    with raises(exceptions.Failure):
        build_dists()

    config['build_command'] = 'this Fails'
    with raises(exceptions.Failure):
        build_dists()

    config['build_command'] = 'true'
    with raises(exceptions.Failure):
        build_dists()


# Generated at 2022-06-24 01:39:12.622183
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config.set_setting("build_command", "false")
    assert should_remove_dist() == False
    config.set_setting("build_command", True)
    assert should_remove_dist() == False
    config.set_setting("remove_dist", False)
    config.set_setting("upload_to_pypi", True)
    assert should_remove_dist() == True
    config.set_setting("remove_dist", True)
    config.set_setting("upload_to_pypi", False)
    config.set_setting("upload_to_release", True)
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:39:14.881892
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/build")
