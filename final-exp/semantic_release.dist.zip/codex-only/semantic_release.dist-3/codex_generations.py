

# Generated at 2022-06-24 01:29:17.396435
# Unit test for function should_build
def test_should_build():
    assert should_build() is False



# Generated at 2022-06-24 01:29:21.713480
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config._config["build_command"] = "echo xxx"
    config._config["upload_to_pypi"] = True
    config._config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-24 01:29:24.360430
# Unit test for function remove_dists
def test_remove_dists():
    path = "dist man"
    command = f"rm -rf {path}"
    assert command == remove_dists(path)

# Generated at 2022-06-24 01:29:26.845701
# Unit test for function remove_dists
def test_remove_dists():
    from .project import test_project
    project = test_project()
    remove_dists(project.get_dist_path())

# Generated at 2022-06-24 01:29:27.927310
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("my-path")

# Generated at 2022-06-24 01:29:29.650401
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:29:34.037433
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test_dir")

# Generated at 2022-06-24 01:29:36.497104
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build()



# Generated at 2022-06-24 01:29:37.661407
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")


# Generated at 2022-06-24 01:29:39.726636
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import get_test_config
    from .utils import get_temp_dir

    config = get_test_config()
    path = get_temp_dir()
    remove_dists(path)

# Generated at 2022-06-24 01:29:44.509120
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["remove_dist"] = True
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "echo"
    assert should_build()



# Generated at 2022-06-24 01:29:51.202894
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = False
    config["remove_dist"] = False
    assert should_remove_dist() is False
    config["remove_dist"] = True
    assert should_remove_dist() is False
    config["build_command"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:29:56.872730
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = True
    assert not should_build()



# Generated at 2022-06-24 01:30:03.719819
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "echo")
    config.set("remove_dist", True)
    assert should_remove_dist()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_remove_dist()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert not should_remove_dist()

    config.set

# Generated at 2022-06-24 01:30:04.980063
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:30:12.460759
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import config
    from .context import taskconfig
    from .utils import set_taskconfig_attrs
    taskconfig.package_name = "foo"
    taskconfig.new_version = "1.2.3"
    taskconfig.wheel_dist_path = "wheelhouse"
    taskconfig.egg_dist_path = "dist"

    remove_dists(config.get("dist_path"))

# Generated at 2022-06-24 01:30:23.283288
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("upload_to_pypi", True)
    config.set("remove_dist", True)
    config.set("build_command", "echo 'echoing'")
    assert should_remove_dist() is True
    config.set("upload_to_pypi", False)
    assert should_remove_dist() is False
    config.set("build_command", "false")
    assert should_remove_dist() is False
    config.set("upload_to_pypi", True)
    assert should_remove_dist() is False
    config.set("remove_dist", False)
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:30:35.269146
# Unit test for function should_build
def test_should_build():
    # Test that build is False for pypi and release
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() == False

    # Test that build is false for pypi and true for release
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_build() == True

    # Test that build is true for pypi and false for release
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "true"
    assert should_build() == True



# Generated at 2022-06-24 01:30:36.216844
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:30:41.054736
# Unit test for function remove_dists
def test_remove_dists():
    # Create fake directory
    run("mkdir -p 'tests/test_dists/some/path'")

    # Check if build files are created
    build_files_created = run("ls tests/test_dists/some/path", hide=True).ok
    assert build_files_created

    # Run dist removal
    remove_dists("tests/test_dists/some/path")

    # Check if build files are deleted
    build_files_deleted = not run("ls tests/test_dists/some/path", hide=True).ok
    assert build_files_deleted

# Generated at 2022-06-24 01:30:42.555951
# Unit test for function build_dists
def test_build_dists():
    run.return_value = True
    build_dists()
    run.assert_called_with("python setup.py sdist")



# Generated at 2022-06-24 01:30:45.038034
# Unit test for function build_dists
def test_build_dists():
    """
    Unit test for function build_dists
    """
    build_dists()
    assert True



# Generated at 2022-06-24 01:30:45.664912
# Unit test for function build_dists
def test_build_dists():
    should_build()

# Generated at 2022-06-24 01:30:50.457214
# Unit test for function should_build
def test_should_build():
    # GIVEN
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    expected = False
    # WHEN
    result = should_build()
    # THEN
    assert result == expected



# Generated at 2022-06-24 01:30:51.392394
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-24 01:30:52.309535
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()


# Generated at 2022-06-24 01:30:56.795123
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-24 01:30:57.356275
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:59.709178
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo"
    assert should_build()
    build_dists()
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:31:02.723878
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = 'false'
    config["remove_dist"] = 'true'
    assert should_remove_dist() is False
    config["build_command"] = 'true'
    config["remove_dist"] = 'true'
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:31:03.513390
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:31:04.862756
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:13.535690
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    assert should_build()
    config.set("upload_to_pypi", False)
    assert not should_build()
    config.set("upload_to_release", True)
    assert should_build()
    config.set("upload_to_release", False)
    assert not should_build()
    config.set("build_command", "command")
    assert should_build()
    config.set("build_command", "false")
    assert not should_build()

# Generated at 2022-06-24 01:31:15.984035
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:31:16.871953
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:24.939143
# Unit test for function should_build
def test_should_build():
    # asserts true should be true
    from unittest import TestCase
    from unittest.mock import patch

    with patch("config.settings.config", {"upload_to_pypi": True}):
        assert TestCase().assertTrue(should_build())

    # asserts true should be true
    with patch("config.settings.config", {"upload_to_release": True}):
        assert TestCase().assertTrue(should_build())

    # asserts true should be true
    with patch(
        "config.settings.config", {"build_command": "command", "upload_to_release": True}
    ):
        assert TestCase().assertTrue(should_build())

    # asserts true should be false

# Generated at 2022-06-24 01:31:29.676141
# Unit test for function build_dists
def test_build_dists():
    logging.basicConfig(level=logging.DEBUG)
    config["build_command"] = "echo hello"
    build_dists()
    config["build_command"] = False
    build_dists()

# Generated at 2022-06-24 01:31:30.584740
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:31:31.103856
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:33.531109
# Unit test for function remove_dists
def test_remove_dists():
    pass


# Generated at 2022-06-24 01:31:34.353040
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:31:41.913362
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = "true"
    assert should_remove_dist() is False
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() is True
    config["upload_to_release"] = "1"
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:31:44.253266
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == False
    assert build_dists() == None


# Generated at 2022-06-24 01:31:52.469057
# Unit test for function build_dists
def test_build_dists():
    cmd = "false"
    config["build_command"] = cmd
    assert(should_build() is False)
    cmd = "true"
    config["build_command"] = cmd
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert(should_build() is False)
    config["build_command"] = cmd
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert(should_build() is True)
    config["build_command"] = cmd
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert(should_build() is True)
    config["build_command"] = cmd
    config["upload_to_pypi"] = True

# Generated at 2022-06-24 01:31:53.815931
# Unit test for function build_dists
def test_build_dists():
    assert build_dists == should_build()

# Generated at 2022-06-24 01:32:04.426519
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["remove_dist"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["remove_dist"] = "true"
    assert not should_remove_dist()

    config["build_command"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["remove_dist"] = "false"
    assert not should_remove_dist()

    config["build_command"]

# Generated at 2022-06-24 01:32:05.259481
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:32:14.074876
# Unit test for function build_dists
def test_build_dists():
    import sys
    import os
    from contextlib import contextmanager
    from io import StringIO
    from unittest import mock
    from unittest.mock import patch
    from invoke.runners import Result

    get_config_patch = patch("pypistats.settings.dictionaries.get_config")
    get_config_mock = get_config_patch.start()
    get_config_mock.return_value = {'build_command': 'pytest', 'upload_to_pypi': True, 'upload_to_release': False, 'remove_dist': False}

    def mock_Runner_invoke(self, command, **kwargs):
        """Mock Result object returned by invoke.run"""
        return Result(None, command=command, **kwargs)


# Generated at 2022-06-24 01:32:15.707411
# Unit test for function build_dists
def test_build_dists():
    command = "python3 setup.py sdist bdist_wheel"
    assert command == config.get("build_command")



# Generated at 2022-06-24 01:32:21.110111
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    assert should_remove_dist() is False

    config.set("upload_to_pypi", True)
    assert should_remove_dist() is True

    config.set("upload_to_release", True)
    assert should_remove_dist() is True

    config.set("upload_to_pypi", False)
    assert should_remove_dist() is True

    config.set("upload_to_release", False)
    assert should_remove_dist() is False


if __name__ == "__main__":
    test_should_remove_dist()

# Generated at 2022-06-24 01:32:22.924996
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:32:29.937317
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hi'"
    assert not should_build()
    config["build_command"] = "echo 'Hi'"
    config["upload_to_pypi"] = True
    assert should_build()


# Generated at 2022-06-24 01:32:34.385168
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = True
    assert should_remove_dist is True
    config["remove_dist"] = True
    config["build_command"] = False
    assert should_remove_dist is False
    config["remove_dist"] = False
    config["build_command"] = True
    assert should_remove_dist is False

# Generated at 2022-06-24 01:32:41.035420
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config["build_command"] = "echo 'hello'"
    assert should_build() is True

    config["upload_to_pypi"] = "false"
    assert should_build() is True

    config["upload_to_release"] = "false"
    assert should_build() is False



# Generated at 2022-06-24 01:32:42.986487
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:32:50.701512
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "true"
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "true"
    assert should_remove_dist() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()


# Generated at 2022-06-24 01:32:57.546210
# Unit test for function should_build
def test_should_build():

    assert should_build() == True

    config["upload_to_pypi"] = False
    assert should_build() == True

    config["build_command"] = ""
    assert should_build() == False

    config["build_command"] = "ls"
    config["upload_to_release"] = False
    assert should_build() == False

    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = True
    assert should_build() == True


# Generated at 2022-06-24 01:32:58.864668
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:59.819879
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")



# Generated at 2022-06-24 01:33:02.211139
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:03.107307
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="/tmp")

# Generated at 2022-06-24 01:33:15.136524
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "python setup.py sdist bdist_wheel")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build() == True

    config.set("build_command", "python3 setup.py sdist bdist_wheel")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True

    config.set("build_command", "python setup.py sdist bdist_wheel")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build() == True


# Generated at 2022-06-24 01:33:16.233685
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/tmp.T1HV4yO8pv")

# Generated at 2022-06-24 01:33:21.706835
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config.update({"upload_to_pypi": True, "upload_to_release": True})
    assert should_build()

    config.update({"upload_to_pypi": False, "upload_to_release": False})
    assert should_build() is False



# Generated at 2022-06-24 01:33:29.966498
# Unit test for function should_build
def test_should_build():
    def test_config(build_command, upload_pypi, upload_release, should_build):
        config.set("build_command", build_command)
        config.set("upload_to_pypi", upload_pypi)
        config.set("upload_to_release", upload_release)
        assert should_build() == should_build
    test_config(build_command="", upload_pypi=True, upload_release=True,
                should_build=False)
    test_config(build_command=False, upload_pypi=True, upload_release=True,
                should_build=False)
    test_config(build_command="echo", upload_pypi=False, upload_release=False,
                should_build=False)

# Generated at 2022-06-24 01:33:31.597827
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:33:34.080977
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tmp")

# Generated at 2022-06-24 01:33:34.720215
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-24 01:33:39.946811
# Unit test for function remove_dists
def test_remove_dists():
    import os

    filename = "test"
    path = os.path.join(os.getcwd(), "dist", filename)

    with open(path, "w") as f:
        f.write("Content of test file")

    remove_dists(path)
    assert not os.path.exists(path), "File {} was not removed".format(path)

# Generated at 2022-06-24 01:33:41.981019
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "echo build"
    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:33:43.467497
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:33:44.126693
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:48.805026
# Unit test for function build_dists
def test_build_dists():
    logger = logging.getLogger("aiida_crystal17")
    logger.setLevel(logging.DEBUG)
    logger.handlers = []
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    build_dists()


# Generated at 2022-06-24 01:33:54.728366
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() is True
    assert should_build() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["upload_to_release"] = False
    assert should_remove_dist() is False
    assert should_build() is False



# Generated at 2022-06-24 01:33:55.789268
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True

# Generated at 2022-06-24 01:33:57.373075
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    assert should_remove_dist()

# Generated at 2022-06-24 01:34:08.079525
# Unit test for function should_build
def test_should_build():
    # pypi
    config["upload_to_pypi"] = True
    config["build_command"] = "build_command"
    assert should_build()
    # release
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "build_command"
    assert should_build()
    # no command
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert not should_build()
    # command
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "build_command"
    assert should_build()
    # no build
    config

# Generated at 2022-06-24 01:34:09.451153
# Unit test for function build_dists
def test_build_dists():
    command = "ls"
    build_dists(command)


# Generated at 2022-06-24 01:34:13.980671
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    try:
        old_config_command = config["build_command"]
        config["build_command"] = "true"
        assert should_build() == True
        build_dists()
    finally:
        config["build_command"] = old_config_command


if __name__ == "__main__":
    print(__doc__)
    print(f"Should build dists? {should_build()}")

# Generated at 2022-06-24 01:34:20.020073
# Unit test for function should_build
def test_should_build():
    command = config.get("build_command")
    assert not should_build()
    config.set("build_command", command)
    assert should_build()



# Generated at 2022-06-24 01:34:30.168738
# Unit test for function should_build
def test_should_build():

    class ConfigDictStruct(object):
        def __init__(self, data=None):
            self._data = data or {}

        def __getitem__(self, key):
            return self._data[key]

        def get(self, key):
            return self._data.get(key)

    config = ConfigDictStruct({
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "false",
        "remove_dist": False,
    })

    assert(should_build() == False)

    config = ConfigDictStruct({
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "false",
        "remove_dist": False,
    })


# Generated at 2022-06-24 01:34:32.299804
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "true")

    assert should_build()



# Generated at 2022-06-24 01:34:33.103479
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:34:37.703610
# Unit test for function remove_dists
def test_remove_dists():
    '''
    Unit test to verify ability to remove generated distribution files
    '''
    from .settings import config
    import os
    import subprocess

    path = config.get("dist_dir")
    file_name = 'test_dir_file.py'

    # Create directory
    os.makedirs(path)

    # Create directory file
    open(os.path.join(path, file_name), 'a').close()

    # Verify directory file exists
    assert(os.path.exists(os.path.join(path, file_name)))

    # Remove directories
    remove_dists(path)

    # Verify directory file no longer exists
    assert(not os.path.exists(os.path.join(path, file_name)))

# Generated at 2022-06-24 01:34:40.191298
# Unit test for function remove_dists
def test_remove_dists():
    path = "dist"
    remove_dists(path)



# Generated at 2022-06-24 01:34:42.338228
# Unit test for function remove_dists
def test_remove_dists():
    command = "python -c 'import shutil; shutil.rmtree(\"dist\")'"
    assert run("python -c 'import shutil; shutil.rmtree(\"dist\")'") is None

# Generated at 2022-06-24 01:34:43.745432
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-24 01:34:52.334209
# Unit test for function should_build
def test_should_build():
    assert(should_build())

    config["build_command"] = False
    assert(not should_build())

    config["build_command"] = "false"
    assert(not should_build())

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert(not should_build())

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert(should_build())

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert(should_build())



# Generated at 2022-06-24 01:34:53.840600
# Unit test for function should_build
def test_should_build():
    result = should_build()
    assert result is True


# Generated at 2022-06-24 01:34:55.243984
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:34:56.188804
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:34:59.004645
# Unit test for function should_build
def test_should_build():
    config.load_config("./tests/test_config_is_intended_for_testing_only.yaml")
    assert should_build() == True


# Generated at 2022-06-24 01:35:07.925108
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "./setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_build()
    config["build_command"] = "./setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build()
    config["build_command"] = "./setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build()
    config["build_command"] = "false"

# Generated at 2022-06-24 01:35:08.641172
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:35:09.824102
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:35:15.186396
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist bdist_wheel"
    assert config.get("build_command") != command
    build_dists()
    assert config.get("build_command") == command

# Generated at 2022-06-24 01:35:18.384497
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:28.696497
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = True
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False

# Generated at 2022-06-24 01:35:29.343575
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:30.678064
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="/path/to/dist")



# Generated at 2022-06-24 01:35:31.760223
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:35:33.004918
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:35:33.892326
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("**")

# Generated at 2022-06-24 01:35:40.567868
# Unit test for function should_build
def test_should_build():
    config['upload_to_pypi'] = True
    assert should_build() is True
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    assert should_build() is True
    config['upload_to_release'] = False
    config['build_command'] = "test_command"
    assert should_build() is True
    config['build_command'] = "false"
    assert should_build() is False


# Generated at 2022-06-24 01:35:51.083038
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Test if should_remove_dist work properly"""
    config.config["remove_dist"] = "true"
    config.config["build_command"] = "/a/valid/command"
    config.config["upload_to_pypi"] = "true"
    assert should_remove_dist()

    config.config["remove_dist"] = "false"
    assert not should_remove_dist()

    config.config["remove_dist"] = "true"
    config.config["build_command"] = "false"
    assert not should_remove_dist()

    config.config["remove_dist"] = "true"
    config.config["build_command"] = "/a/valid/command"
    config.config["upload_to_pypi"] = "false"
    config.config["upload_to_release"] = "false"

# Generated at 2022-06-24 01:35:53.654811
# Unit test for function remove_dists
def test_remove_dists():
    print("Test function - remove_dists")
    path = 'test_dist'
    run(f"mkdir {path}")
    print(run(f"ls"))
    remove_dists(path)
    print(run(f"ls"))

# Generated at 2022-06-24 01:35:57.248902
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:36:02.766269
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    from distutils.dir_util import mkpath
    from distutils.file_util import write_file

    with tempfile.TemporaryDirectory() as dist_path:
        setup_py = f"{dist_path}/setup.py"
        build = f"{dist_path}/build"
        mkpath(build)
        write_file(setup_py, "import yagmail")
        write_file(f"{build}/a_file.py", "import yagmail")
        remove_dists(dist_path)
        assert not os.path.exists(setup_py)
        assert not os.path.exists(build)



# Generated at 2022-06-24 01:36:06.901711
# Unit test for function build_dists
def test_build_dists():
    global run
    run = lambda command: command
    assert build_dists() == "echo 'Hello World'"

# Generated at 2022-06-24 01:36:11.378097
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:36:11.978138
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:18.687959
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config['build_command'] = True
    config['remove_dist'] = True
    config['upload_to_release'] = True
    assert should_remove_dist() == True
    config['build_command'] = False
    config['remove_dist'] = True
    assert should_remove_dist() == False
    config['build_command'] = True
    config['remove_dist'] = False
    assert should_remove_dist() == False
    config['build_command'] = False
    config['remove_dist'] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:36:24.034564
# Unit test for function remove_dists
def test_remove_dists():
    try:
        run("mkdir -p /tmp/dist")
        remove_dists("/tmp/dist")
        assert not run("ls /tmp | grep dist", hide=True).ok
    finally:
        run("rm -rf /tmp/dist")

# Generated at 2022-06-24 01:36:25.034177
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/*")

# Generated at 2022-06-24 01:36:28.514270
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:29.704629
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:36:32.316697
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:36:40.984382
# Unit test for function should_build
def test_should_build():
    config.load(environment="test")
    ## Should return false for no build command and no uploads
    assert(not should_build())

    ## Should return true for no build command and uploads
    config["upload_to_pypi"] = True
    assert(should_build())

    ## Should return true for build command and uploads
    config["build_command"] = "build command"
    assert(should_build())

    ## Should return false for build command and no uploads
    config.pop("upload_to_pypi", None)
    assert(not should_build())


# Generated at 2022-06-24 01:36:42.048821
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")
    remove_dists("dist")

# Generated at 2022-06-24 01:36:45.626294
# Unit test for function should_remove_dist
def test_should_remove_dist():
    command = config.get("build_command")
    if command != "false":
        assert should_remove_dist()
    else:
        assert not should_remove_dist()

# Generated at 2022-06-24 01:36:53.060491
# Unit test for function should_build
def test_should_build():
    config['upload_to_pypi'] = True
    assert should_build() == True
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    assert should_build() == True
    config['upload_to_release'] = False
    config['build_command'] = False
    assert should_build() == False
    config['build_command'] = True
    assert should_build() == True


# Generated at 2022-06-24 01:36:54.143817
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:36:56.138106
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    remove_dists(temp_dir)

# Generated at 2022-06-24 01:37:06.381883
# Unit test for function should_build
def test_should_build():
    # If build_command is false/None should return false
    config["build_command"] = False
    assert should_build() is False
    config["build_command"] = None
    assert should_build() is False
    # If upload_to_pypi and upload_to_release is unset should return false
    config["build_command"] = "/bin/ls"
    assert should_build() is False
    # If upload_to_pypi and upload_to_release is false should return false
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False
    # If upload_to_pypi or upload_to_release is true should return true
    config["upload_to_pypi"] = True

# Generated at 2022-06-24 01:37:11.600398
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == True
    assert config.get("build_command") == "build-command"
    build_dists()
    assert True


# Generated at 2022-06-24 01:37:12.540604
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True

# Generated at 2022-06-24 01:37:19.322679
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert should_build() == False



# Generated at 2022-06-24 01:37:21.850911
# Unit test for function remove_dists
def test_remove_dists():
    assert callable(remove_dists)

# Generated at 2022-06-24 01:37:22.901230
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:37:24.673347
# Unit test for function remove_dists
def test_remove_dists():
    logger.info("Testing function remove_dists")

    result = remove_dists("test")
    assert result is None, "remove_dists returns None"

# Generated at 2022-06-24 01:37:27.855101
# Unit test for function remove_dists
def test_remove_dists():
    expected_command = "rm -rf asdasdasd"
    command = remove_dists(expected_command)
    assert expected_command in str(command)

# Generated at 2022-06-24 01:37:32.320793
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception:
        assert False



# Generated at 2022-06-24 01:37:32.874917
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:41.661346
# Unit test for function should_build
def test_should_build():
    def test_no_upload_no_build_command():
        from .settings import config
        config.set("upload_to_pypi", False)
        config.set("upload_to_release", False)
        config.set("build_command", "")
        assert not should_build()

    def test_upload_and_build_command():
        from .settings import config
        config.set("upload_to_pypi", True)
        config.set("upload_to_release", True)
        config.set("build_command", "echo $PWD")
        assert should_build()

    def test_no_upload_and_build_command():
        from .settings import config
        config.set("upload_to_pypi", False)
        config.set("upload_to_release", False)
        config

# Generated at 2022-06-24 01:37:44.803911
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_release"] = True
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:37:46.889649
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    logger.debug(f"There are no dists to build")

# Generated at 2022-06-24 01:37:54.065246
# Unit test for function should_build
def test_should_build():
    config['build_command'] = 'test'
    assert should_build()
    assert not should_remove_dist()
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    assert should_build()
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    assert should_build()
    config['build_command'] = 'false'
    assert not should_build()
    config['build_command'] = 'test'

# Generated at 2022-06-24 01:37:57.088666
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/")  # Will raise an exception
    remove_dists("nonexisting_path_or_file")  # Will raise an exception
    remove_dists("dist/*")  # Will remove all files in dist/ folder

# Generated at 2022-06-24 01:37:58.404860
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('test_dir')



# Generated at 2022-06-24 01:37:59.892083
# Unit test for function build_dists
def test_build_dists():
    assert callable(build_dists)



# Generated at 2022-06-24 01:38:06.394425
# Unit test for function should_build
def test_should_build():
    """Should return True when the following conditions is true:

        - 'build_command' is not None
        - 'upload_to_pypi' is True
        - 'upload_to_release' is True
    """
    build_command = config.get("build_command")
    build_command = build_command if build_command else False
    assert should_build() == bool(build_command and True and True)

# Generated at 2022-06-24 01:38:09.861495
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:38:15.287342
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "doit"
    assert should_build()

# Generated at 2022-06-24 01:38:22.855627
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "bdist_wheel")
    config.set("remove_dist", True)
    assert should_remove_dist() == True

    config.set("build_command", "bdist_wheel")
    config.set("remove_dist", False)
    assert should_remove_dist() == False

    config.set("build_command", False)
    config.set("remove_dist", True)
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:38:30.023830
# Unit test for function should_build
def test_should_build():
    config.set('upload_to_pypi', 'false')
    config.set('upload_to_release', 'false')
    config.set('build_command', 'false')
    assert should_build() is False

    config.set('upload_to_pypi', 'true')
    config.set('upload_to_release', 'true')
    config.set('build_command', 'true')
    assert should_build() is True



# Generated at 2022-06-24 01:38:31.049431
# Unit test for function remove_dists
def test_remove_dists():
    assert isinstance(remove_dists, object)

# Generated at 2022-06-24 01:38:32.010330
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:33.236977
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:38:37.754730
# Unit test for function remove_dists
def test_remove_dists():
    test_path = "tests/fixtures/test_dists"
    assert os.path.exists(test_path)
    remove_dists(test_path)
    assert not os.path.exists(test_path)

# Generated at 2022-06-24 01:38:42.691574
# Unit test for function should_build
def test_should_build():
    assert should_build() is False



# Generated at 2022-06-24 01:38:48.113791
# Unit test for function should_build
def test_should_build():
    assert not should_build(), "Cannot build the distribution if the option is false"
    config["upload_to_pypi"] = True
    assert should_build(), "If the upload_to_pypi option is true, it is possible to build the distribution"

# Generated at 2022-06-24 01:38:51.857279
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:38:52.927251
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("")

# Generated at 2022-06-24 01:38:58.227211
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import config_mock

    config_mock["remove_dist"] = True
    config_mock["build_command"] = "pip"
    config_mock["upload_to_pypi"] = True
    assert should_remove_dist()

    config_mock["remove_dist"] = False
    config_mock["upload_to_pypi"] = True
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:39:00.922915
# Unit test for function should_build
def test_should_build():
    for key, value in {"upload_to_pypi": True,
                       "upload_to_release": True,
                       "build_command": "echo"}.items():
        assert should_build()
        config[key] = value



# Generated at 2022-06-24 01:39:06.676743
# Unit test for function should_remove_dist
def test_should_remove_dist():
    c = config.copy()
    c["upload_to_pypi"] = True
    c["upload_to_release"] = False
    c["build_command"] = "echo build"
    c["remove_dist"] = True
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:39:08.474046
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:39:09.395547
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:39:09.878650
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:39:12.154402
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir -p /tmp/invoke-sphinx-test")
    remove_dists("/tmp/invoke-sphinx-test")

# Generated at 2022-06-24 01:39:12.868298
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:39:14.590351
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:39:17.366640
# Unit test for function build_dists
def test_build_dists():
    # mock command
    config["build_command"] = "ls"
    assert should_build() is True
    assert should_remove_dist() is False
    build_dists()

