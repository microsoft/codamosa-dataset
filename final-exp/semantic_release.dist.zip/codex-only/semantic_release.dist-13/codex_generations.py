

# Generated at 2022-06-24 01:29:17.396401
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:29:18.170436
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:18.866860
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists

# Generated at 2022-06-24 01:29:23.527998
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import test_config
    from .settings import temp_dir

    test_path = temp_dir / 'dist'
    test_path.mkdir()
    assert test_path.is_dir()

    remove_dists(test_path)

    assert not test_path.is_dir()

# Generated at 2022-06-24 01:29:24.360642
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:29:32.138614
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True

    config["remove_dist"] = False
    assert should_remove_dist() is False

    config["upload_to_release"] = False
    assert should_remove_dist() is False


# Generated at 2022-06-24 01:29:33.729531
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = "true"
    assert should_remove_dist() is False
    config["remove_dist"] = "True"
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:29:36.722213
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-24 01:29:37.623681
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:29:43.160564
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist())
    config.update({'remove_dist': False})
    assert(should_remove_dist() is False)
    config.update({'build_command': False})
    assert(should_remove_dist() is False)
    config.update({'build_command': 'build_command'})
    config.update({'remove_dist': True})
    config.update({'upload_to_pypi': False})
    assert(should_remove_dist() is False)
    config.update({'upload_to_pypi': True})
    config.update({'upload_to_release': True})
    assert(should_remove_dist())

# Generated at 2022-06-24 01:29:47.596048
# Unit test for function build_dists
def test_build_dists():
    print("Start Unit test")
    config["build_command"] = "ls"
    build_dists()



# Generated at 2022-06-24 01:29:49.158183
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/home/user/test")
    assert run.called

# Generated at 2022-06-24 01:29:57.540881
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "this_is_a_build_command"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "this_is_a_build_command"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-24 01:29:58.521074
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:29:59.605216
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:30:07.634640
# Unit test for function should_build
def test_should_build():
    config["build_command"] = True
    assert should_build() is True
    config["build_command"] = False
    assert should_build() is False
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "some_command"
    assert should_build() is True
    config["upload_to_pypi"] = False
    assert should_build() is False
    config["upload_to_release"] = False
    assert should_build() is False



# Generated at 2022-06-24 01:30:08.305697
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:12.284764
# Unit test for function build_dists
def test_build_dists():
    class Invoke:
        @staticmethod
        def run(command):
            return command
    import sys

    # make sure we don't acutally run the command
    sys.modules["invoke"] = Invoke
    assert build_dists() == "python setup.py sdist bdist_wheel"

# Generated at 2022-06-24 01:30:17.332264
# Unit test for function should_build
def test_should_build():
    # given
    config["upload_to_release"] = True
    config["build_command"] = "echo"

    # when
    result = should_build()

    # then
    assert result



# Generated at 2022-06-24 01:30:18.786155
# Unit test for function should_build
def test_should_build():
    assert should_build() in [True, False]

# Generated at 2022-06-24 01:30:22.201251
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()


build_options = {
    "build_command": "false",
    "remove_dist": True,
    "upload_to_pypi": False,
    "upload_to_release": False,
}



# Generated at 2022-06-24 01:30:27.887165
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build(build_command=False) is False
    assert should_build(upload_to_pypi=False) is False
    assert should_build(upload_to_release=False) is False
    assert should_build(build_command=False, upload_to_pypi=False) is False
    assert should_build(build_command=False, upload_to_release=False) is False
    assert should_build(upload_to_pypi=False, upload_to_release=False) is False



# Generated at 2022-06-24 01:30:32.701512
# Unit test for function should_build
def test_should_build():
    assert should_build()

    config["build_command"] = False
    assert not should_build()

    config["upload_to_pypi"] = False
    assert not should_build()

    config["build_command"] = "echo 'Hello'"
    config["upload_to_pypi"] = True
    assert should_build()

# Generated at 2022-06-24 01:30:33.804827
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:30:42.787620
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "test"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-24 01:30:53.139448
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.update({"build_command": "echo \"test\""})
    assert should_build()
    config.update({"build_command": "false"})
    assert not should_build()
    config.update({"upload_to_pypi": True})
    assert should_build()
    config.update({"upload_to_pypi": False})
    config.update({"upload_to_release": True})
    assert should_build()
    config.update({"upload_to_release": False})
    assert not should_build()
    config.update({"upload_to_release": True})
    config.update({"upload_to_pypi": True})
    assert should_build()
    config.update({"build_command": "echo \"test\""})


# Generated at 2022-06-24 01:30:56.569582
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./toto")

# Generated at 2022-06-24 01:31:00.717124
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:03.852713
# Unit test for function remove_dists
def test_remove_dists():
    from . import helpers
    from . import settings
    settings.config = helpers.load_config()
    path = config.get("dist_path")
    if not should_remove_dist():
        logger.error("The package distribution directory should not be removed")
        return
    remove_dists(path)



# Generated at 2022-06-24 01:31:15.251960
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Test should_remove_dist function
    """
    import os
    import tempfile

    real_remove_dist = config.get("remove_dist")

    with tempfile.TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        config["build_command"] = "false"
        config["upload_to_pypi"] = False
        config["upload_to_release"] = False

        config["remove_dist"] = "true"
        assert should_remove_dist()

        config["remove_dist"] = "false"
        assert not should_remove_dist()

        config["remove_dist"] = "true"
        config["build_command"] = "echo 123"
        assert should_remove_dist()

        config["build_command"] = "false"

# Generated at 2022-06-24 01:31:16.865885
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist bdist_wheel"
    assert command == config.get("build_command")
    build_dists()

# Generated at 2022-06-24 01:31:19.405264
# Unit test for function build_dists
def test_build_dists():
    logger.info("Running test build_dists")
    build_dists()

# Generated at 2022-06-24 01:31:24.820918
# Unit test for function should_build
def test_should_build():
    mock_config = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "tox",
        "remove_dist": True,
    }
    config.update(mock_config)

    assert should_build()

    mock_config["build_command"] = None
    config.update(mock_config)

    assert not should_build()

    mock_config["build_command"] = "tox"
    mock_config["upload_to_release"] = False
    config.update(mock_config)

    assert should_build()



# Generated at 2022-06-24 01:31:25.856105
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-24 01:31:35.683202
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import get_settings
    from .utils import tmp_dir
    from pathlib import Path
    from shutil import rmtree

    with tmp_dir() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        dist_dir = tmp_dir / "dist"
        dist_dir.mkdir()
        assert dist_dir.exists()
        dist_file = dist_dir / "tmp.txt"
        dist_file.touch()
        assert dist_file.exists()
        get_settings(dist_dir=str(dist_dir))

        remove_dists(path=str(dist_dir))
        assert not dist_file.exists()

    assert not dist_dir.exists()


# Generated at 2022-06-24 01:31:44.213487
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    # command exists
    config.set("build_command", "false")
    assert should_build() == False
    config.set("build_command", "python setup.py sdist")
    assert should_build() == False

    # command and pypi upload
    config.set("upload_to_pypi", "true")
    assert should_build() == True

    # command and release upload
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    assert should_build() == True

# Generated at 2022-06-24 01:31:44.582298
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:49.943465
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config["upload_to_release"] = True
    assert should_remove_dist()

    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:51.394547
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/*dist*")



# Generated at 2022-06-24 01:31:58.012177
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = "True"
    config["build_command"] = "echo test"
    assert should_build()
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "True"
    assert should_build()
    config["upload_to_release"] = "False"
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:32:05.850416
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    assert should_remove_dist() is False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py bdist_wheel"
    assert should_build() is True
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "python setup.py bdist_wheel"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

# Generated at 2022-06-24 01:32:07.111721
# Unit test for function should_build
def test_should_build():
    if should_build():
        logger.info("Build test passed")
    else:
        logger.error("Build test failed")



# Generated at 2022-06-24 01:32:10.602151
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True

# Generated at 2022-06-24 01:32:11.424434
# Unit test for function remove_dists
def test_remove_dists():
    assert 0 == remove_dists("tst")

# Generated at 2022-06-24 01:32:17.769856
# Unit test for function should_build
def test_should_build():
    # with pytest.raises(Exception):
    #     with pytest.raises(Exception):
    #         should_build()
    assert not should_build()
    config["build_command"] = "echo"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-24 01:32:21.262216
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "true"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    del config["upload_to_pypi"]
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()
    del config["upload_to_release"]

# Generated at 2022-06-24 01:32:28.016818
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["build_command"] = "foo"
    assert should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_release"] = True
    config["build_command"] = "foo"
    assert should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:32:39.028298
# Unit test for function should_build
def test_should_build():
    config.put("upload_to_pypi", True)
    config.put("upload_to_release", False)
    config.put("build_command", "ls -l")
    assert should_build()

    config.put("upload_to_pypi", False)
    config.put("upload_to_release", True)
    config.put("build_command", "ls -l")
    assert should_build()

    config.put("upload_to_pypi", False)
    config.put("upload_to_release", False)
    config.put("build_command", "ls -l")
    assert not should_build()

    config.put("upload_to_pypi", False)
    config.put("upload_to_release", False)
    config.put("build_command", False)


# Generated at 2022-06-24 01:32:41.697979
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == False
    assert should_build() == True
    build_dists()
    remove_dists("dist")

# Generated at 2022-06-24 01:32:42.484798
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("~/dist")

# Generated at 2022-06-24 01:32:44.358335
# Unit test for function build_dists
def test_build_dists():
    command = "/bin/false"
    logger.info(f"Running {command}")
    run(command)



# Generated at 2022-06-24 01:32:47.580268
# Unit test for function remove_dists
def test_remove_dists():
    path = "/test/test"
    remove_dists(path)

# Generated at 2022-06-24 01:32:48.935001
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:32:55.041133
# Unit test for function remove_dists
def test_remove_dists():
    distribute_dir = ".distribute"
    from .settings import config_dir, root_dir
    from .setup import root_path
    from shutil import copytree, rmtree
    copytree(
        str(root_path(config_dir)),
        str(root_path(config_dir, distribute_dir)),
    )
    remove_dists(distribute_dir)
    assert not root_path(distribute_dir).exists()
    rmtree(root_path(distribute_dir))

# Generated at 2022-06-24 01:32:56.713899
# Unit test for function build_dists
def test_build_dists():
    """
    To test this function, you need to edit this file (tasks.py) and set
        'build_command' to something that makes sense.
        Then update test_basic_build to call the build_dists
    """
    return

# Generated at 2022-06-24 01:32:59.734087
# Unit test for function should_remove_dist
def test_should_remove_dist():
    remove_dist_true = True
    remove_dist_false = False
    assert should_remove_dist() == remove_dist_true
    assert should_remove_dist() == remove_dist_false

# Generated at 2022-06-24 01:33:08.637962
# Unit test for function should_build
def test_should_build():
    config['upload_to_pypi'] = True
    config['upload_to_release'] = True
    config['build_command'] = 'sh -c'
    assert should_build() == True
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    config['build_command'] = 'sh -c'
    assert should_build() == True
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    config['build_command'] = 'sh -c'
    assert should_build() == True
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    config['build_command'] = 'sh -c'
    assert should_build() == False

# Generated at 2022-06-24 01:33:09.330722
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:33:16.499231
# Unit test for function should_build
def test_should_build():
    build_cmd = "docker build ."
    upload_pypi = True
    upload_release = False
    assert should_build()

    build_cmd = "docker build ."
    upload_pypi = False
    upload_release = True
    assert should_build()

    build_cmd = "docker build ."
    upload_pypi = True
    upload_release = True
    assert should_build()

    build_cmd = "docker build ."
    upload_pypi = False
    upload_release = False
    assert not should_build()

    build_cmd = "false"
    upload_pypi = True
    upload_release = True
    assert not should_build()



# Generated at 2022-06-24 01:33:17.714326
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:33:25.312469
# Unit test for function remove_dists
def test_remove_dists():
    import pytest
    from .utils import tmpdir
    # Edge Case: path is empty
    with tmpdir() as tmp:
        remove_dists(tmp)
    # Edge Case: path does not exist
    with pytest.raises(Exception):
        remove_dists("/some/path/that/does/not/exist")
    # Normal: remove a dist directory
    with tmpdir() as tmp:
        tmp.joinpath("dist").mkdir()
        remove_dists(tmp)


# Generated at 2022-06-24 01:33:35.186138
# Unit test for function should_build
def test_should_build():
    """Tests for the should_build function."""
    config.set_config({
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "test"
    })
    assert should_build() == True
    # test that build_command=false returns false
    config.set_config({
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "false"
    })
    assert should_build() == False
    # test that not uploading anywhere returns false
    config.set_config({
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "test"
    })
    assert should_build() == False

# Generated at 2022-06-24 01:33:37.274064
# Unit test for function should_build
def test_should_build():
    print("test_should_build")
    assert should_build() == True
    print(">>> SUCCESS")


# Generated at 2022-06-24 01:33:37.785451
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:33:45.408106
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf some/fake/path"
    mockRemoveDist = MagicMock()
    mockRun = MagicMock()
    # monkey patch
    from bowlero_backend.utils.pypi.build_command import remove_dists
    remove_dists.run = mockRun
    remove_dists.logger = mockRemoveDist
    remove_dists("some/fake/path")
    remove_dists.run.assert_called_with(command)
    remove_dists.logger.debug.assert_called_with(f"Running {command}")

# Generated at 2022-06-24 01:33:48.010749
# Unit test for function remove_dists
def test_remove_dists():
    logger.debug("Running unit test for function remove_dists")
    remove_dists("test")

# Generated at 2022-06-24 01:33:49.205532
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert callable(should_remove_dist)



# Generated at 2022-06-24 01:33:49.836497
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:33:51.010579
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="./tests/fakes")

# Generated at 2022-06-24 01:33:52.225257
# Unit test for function build_dists
def test_build_dists():
    command = "pwd"
    run(command)

# Generated at 2022-06-24 01:33:54.709779
# Unit test for function remove_dists
def test_remove_dists():
    # mock the logger
    logging.basicConfig(level=logging.DEBUG)
    # set the system executable to sh
    run.shell_default = "sh"
    # run the function
    remove_dists("./")

# Generated at 2022-06-24 01:33:56.136868
# Unit test for function build_dists
def test_build_dists():
    command = "echo Yes"
    build_dists(command)

# Generated at 2022-06-24 01:34:05.280574
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "some build command"
    config["remove_dist"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()

    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-24 01:34:06.226366
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:34:07.940901
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-24 01:34:14.156389
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test config
    cfg = {"upload_to_pypi": True,
           "upload_to_release": False,
           "build_command": "test",
           "remove_dist": True}
    assert should_remove_dist() == True
    cfg["remove_dist"] = False
    assert should_remove_dist() == False
    cfg["upload_to_pypi"] = False
    cfg["upload_to_release"] = True
    assert should_remove_dist() == False
    cfg["build_command"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:34:20.384463
# Unit test for function build_dists
def test_build_dists():
    logger.info("Running test_build_dists")
    config.set("build_command", "false")
    assert not should_build()

    config.set("build_command", "true")
    assert should_build()

# Generated at 2022-06-24 01:34:23.964868
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = ""
    assert should_remove_dist() is False

    config["remove_dist"] = "true"
    assert should_remove_dist() is False

    config["build_command"] = "true"
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:34:25.744164
# Unit test for function build_dists
def test_build_dists():
    # build_dists()
    pass

# Generated at 2022-06-24 01:34:28.455951
# Unit test for function build_dists
def test_build_dists():
    try:
        assert should_build is False and should_remove_dist is False
        build_dists()
    except AssertionError as e:
        logger.exception(f"{e}")


# Generated at 2022-06-24 01:34:35.585354
# Unit test for function build_dists
def test_build_dists():
    from .utils import set_config
    from .settings import GIT
    from .gitignore import get_gitignored_files

    build_command = "echo 'Hello World'"
    build_path = "./tests/.tests/build/"
    dist_file = "test_dist.txt"
    dist_path = f"{build_path}/{dist_file}"
    
    set_config("build_command", build_command)
    set_config("build_path", build_path)

    build_dists()

    assert run("test -f ./tests/.tests/build/test_dist.txt", hide=True).ok

    get_gitignored_files(refresh=True)
    GIT.get_branch_name(refresh=True)
    remove_dists(path=build_path)
    


# Generated at 2022-06-24 01:34:36.765176
# Unit test for function build_dists
def test_build_dists():
    assert should_build()


# Generated at 2022-06-24 01:34:47.329958
# Unit test for function should_build
def test_should_build():
    cmd = "echo test"
    build_command = config.get("build_command")
    assert should_build() == False
    setattr(config, "build_command", cmd)
    assert should_build() == False
    setattr(config, "upload_to_pypi", True)
    assert should_build() == True
    setattr(config, "upload_to_release", True)
    assert should_build() == True
    setattr(config, "upload_to_pypi", False)
    assert should_build() == True
    setattr(config, "upload_to_release", False)
    assert should_build() == False
    setattr(config, "build_command", build_command)
    assert should_build() == False

# Generated at 2022-06-24 01:34:52.905148
# Unit test for function should_build
def test_should_build():
    # Check for correct values for should_build
    assert should_build() is False
    config.set("upload_to_pypi", True)
    assert should_build() is False
    config.set("upload_to_release", True)
    assert should_build() is False
    config.set("build_command", "python setup.py build")
    assert should_build() is True
    config.set("upload_to_pypi", False)
    assert should_build() is True
    config.set("upload_to_release", False)
    assert should_build() is False



# Generated at 2022-06-24 01:34:53.658930
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:34:54.626220
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:55.568919
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:56.495905
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:34:58.669771
# Unit test for function remove_dists
def test_remove_dists():
    # Try to delete the directory located in the current path
    remove_dists('./dist')

# Generated at 2022-06-24 01:34:59.988443
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:35:00.905289
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:35:01.830064
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tests/")


# Generated at 2022-06-24 01:35:03.370836
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("requirements.txt")

# Generated at 2022-06-24 01:35:12.593728
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_cases = [
        ({"build_command": "false", "remove_dist": True}, False),
        ({"build_command": "make dist", "remove_dist": True}, True),
        ({"build_command": "make dist", "remove_dist": False}, False),
        ({"build_command": "make dist", "upload_to_pypi": False}, False),
        ({"build_command": "make dist", "upload_to_pypi": True}, True),
    ]
    for config_value, expected in test_cases:
        # Change config in old way
        config.update(config_value)
        assert should_remove_dist() == expected

# Generated at 2022-06-24 01:35:16.955020
# Unit test for function remove_dists
def test_remove_dists():
    from .utils import TemporaryPath
    with TemporaryPath(prefix="python_packaging_tools_") as tmpdir:
        run(f"mkdir {tmpdir}/dist/")
        remove_dists(path=tmpdir)
        logger.debug(run(f"ls {tmpdir}"))
        assert not run(f"ls {tmpdir}", hide=True).ok

# Generated at 2022-06-24 01:35:27.886855
# Unit test for function should_build
def test_should_build():
    conf = {
        "upload_to_release": False,
        "upload_to_pypi": True,
        "build_command": "echo 'hi'"
    }
    config.update(conf)
    assert should_build() is True

    conf = {
        "upload_to_release": True,
        "upload_to_pypi": False,
        "build_command": "echo 'hi'"
    }
    config.update(conf)
    assert should_build() is True

    conf = {
        "upload_to_release": False,
        "upload_to_pypi": False,
        "build_command": "echo 'hi'"
    }
    config.update(conf)
    assert should_build() is False


# Generated at 2022-06-24 01:35:36.770096
# Unit test for function should_build
def test_should_build():
    context = {
        "build_command": "setup.py bdist_wheel",
        "upload_to_pypi": True,
        "upload_to_release": True,
    }
    assert should_build()
    assert should_remove_dist() is True

    context = {
        "build_command": "falsy",
        "upload_to_pypi": True,
        "upload_to_release": True,
    }
    assert should_build() is False
    assert should_remove_dist() is False

    context = {
        "build_command": "setup.py bdist_wheel",
        "upload_to_pypi": True,
        "upload_to_release": False,
    }
    assert should_build() is True
    assert should_remove_dist() is True

   

# Generated at 2022-06-24 01:35:38.214130
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:35:44.277958
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config.update({"upload_to_pypi": True})
    assert should_build() is False

    config.update({"upload_to_release": True})
    assert should_build() is False

    config.update({"build_command": "echo 'testing'"})
    assert should_build() is True

# Generated at 2022-06-24 01:35:47.033820
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:35:47.917235
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:35:55.463964
# Unit test for function should_build
def test_should_build():
    command = "python setup.py sdist bdist_wheel"

    # Setup config
    config.store = {
        "build_command": "python setup.py sdist bdist_wheel",
        "upload_to_pypi": False,
        "upload_to_release": False
    }

    assert should_build() == False

    config.store["upload_to_pypi"] = True
    config.store["upload_to_release"] = True
    assert should_build() == True

    config.store["upload_to_pypi"] = True
    config.store["upload_to_release"] = False
    assert should_build() == True

    config.store["upload_to_pypi"] = False
    config.store["upload_to_release"] = True
    assert should_build() == True



# Generated at 2022-06-24 01:36:02.380128
# Unit test for function should_build
def test_should_build():
    global config
    config["build_command"] = True
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["build_command"] = False
    config["upload_to_pypi"] = True
    assert should_build() is False
    config["build_command"] = True
    config["upload_to_pypi"] = False
    assert should_build() is False
    config["build_command"] = False
    config["upload_to_pypi"] = False
    assert should_build() is False
    config["build_command"] = True
    config["upload_to_release"] = True
    assert should_build() is True

# Generated at 2022-06-24 01:36:08.758590
# Unit test for function should_build
def test_should_build():
    global config
    backup = config.copy()
    config["upload_to_pypi"] = True
    assert should_build() == True

    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    assert should_build() == True

    config["upload_to_release"] = False
    assert should_build() == False

    config["build_command"] = "some-command"
    assert should_build() == True

    config["build_command"] = "false"
    assert should_build() == False

    config = backup

# Generated at 2022-06-24 01:36:18.109485
# Unit test for function should_build
def test_should_build():
    conf = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "true"
    }
    assert should_build(conf)

    conf["upload_to_pypi"] = False
    conf["upload_to_release"] = True
    assert should_build(conf)

    conf["upload_to_pypi"] = True
    assert should_build(conf)

    conf["upload_to_pypi"] = False
    conf["upload_to_release"] = False
    assert not should_build(conf)

    conf["build_command"] = "false"
    assert not should_build(conf)

# Generated at 2022-06-24 01:36:24.035203
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["build_command"] = False
    assert should_remove_dist() is False
    config["remove_dist"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:36:29.117357
# Unit test for function should_build
def test_should_build():
    assert should_build() == True, "Should build if build_command is true and upload_to_pypi or upload_to_release is true"
    assert should_build() == False, "Should not build if build_command is false and upload_to_pypi and upload_to_release is true"
    assert should_build() == False, "Should not build if build_command is true and upload_to_pypi and upload_to_release is false"


# Generated at 2022-06-24 01:36:35.637295
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    assert should_remove_dist(remove_dist=True)
    assert not should_remove_dist(remove_dist=False)
    assert not should_remove_dist(remove_dist=True, upload_to_pypi=False)
    assert not should_remove_dist(remove_dist=True, upload_to_pypi=True,
                                  build_command=False)
    assert not should_remove_dist(remove_dist=True, upload_to_release=False)
    assert not should_remove_dist(remove_dist=True, upload_to_release=True,
                                  build_command=False)
    assert not should_remove_dist(build_command=False)
    assert not should_remove_dist(upload_to_pypi=False)
    assert not should

# Generated at 2022-06-24 01:36:36.023561
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:45.474686
# Unit test for function should_build
def test_should_build():
    # Scenario 1: No upload intended
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False

    # Scenario 2: PyPI upload intended
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True

    # Scenario 3: Release upload intended
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    # Scenario 4: Both upload intended
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True

    # Scenario 5: Both upload and build intended

# Generated at 2022-06-24 01:36:46.566680
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")

# Generated at 2022-06-24 01:36:47.253231
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:36:48.217255
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-24 01:36:50.297038
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:37:00.050217
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False



# Generated at 2022-06-24 01:37:01.038933
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")

# Generated at 2022-06-24 01:37:09.688619
# Unit test for function should_build
def test_should_build():
    """
    Should return True if either of this
    is true:

      - `upload_to_pypi` is True or
      - `upload_to_release` is True and
      - `build_command` is not False

    Should return False otherwise
    """
    should = should_build()
    assert should == config.get("build_command") and (
        config["upload_to_pypi"] or config["upload_to_release"]
    )



# Generated at 2022-06-24 01:37:10.291200
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:13.591129
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "python3 setup.py sdist bdist_wheel"
    assert should_build() == True


# Generated at 2022-06-24 01:37:15.664895
# Unit test for function build_dists
def test_build_dists():
    # TODO: stub run
    pass



# Generated at 2022-06-24 01:37:17.522046
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:22.656994
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf {path}"
    assert should_remove_dist() == True, "Remove_dist is set func"

# Generated at 2022-06-24 01:37:25.344890
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:37:31.430030
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False
    config["upload_to_release"] = False
    assert should_remove_dist() is False
    config["build_command"] = False
    assert should_remove_dist() is False
    config["build_command"] = "blah"
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:37:37.474546
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist() == True

    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_remove_dist() == False



# Generated at 2022-06-24 01:37:38.376565
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path=config.get("dist_dir"))

# Generated at 2022-06-24 01:37:43.063202
# Unit test for function should_build
def test_should_build():
    config['build_command'] = "Should not build"
    assert should_build() is False
    config['build_command'] = "Should build"
    config['upload_to_release'] = True
    assert should_build() is True
    config['upload_to_pypi'] = True
    assert should_build() is True
    config['upload_to_pypi'] = False
    assert should_build() is True
    config['upload_to_release'] = False
    assert should_build() is False

# Generated at 2022-06-24 01:37:44.279361
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:44.951335
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:37:47.024713
# Unit test for function build_dists
def test_build_dists():
    """Verify that function build_dists runs fine.
    """
    build_dists()



# Generated at 2022-06-24 01:37:48.064239
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("")

# Generated at 2022-06-24 01:37:49.020385
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="/tmp/testing")

# Generated at 2022-06-24 01:37:50.569292
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test/test.txt")

# Generated at 2022-06-24 01:37:56.161818
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "")
    assert should_build() == False

    config.set("upload_to_pypi", True)
    assert should_build() == True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True


# Generated at 2022-06-24 01:38:00.553973
# Unit test for function build_dists
def test_build_dists():
    """Unit test for function build_dists
    """
    # Testing that function does not error if no command is specified
    config["build_command"] = ""
    assert build_dists() is None
    """
    TODO: could figure out how to mock run to test that the correct command is
    being passed to the invoke run command
    """



# Generated at 2022-06-24 01:38:10.851375
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "echo"
    assert not should_build()
    assert not should_remove_dist()

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert not should_build()
    assert not should_remove_dist()

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo"
   

# Generated at 2022-06-24 01:38:13.152487
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("upload_to_pypi", True)
    assert not should_build()
    config.set("build_command", "make")
    assert should_build()


# Generated at 2022-06-24 01:38:18.797607
# Unit test for function should_remove_dist
def test_should_remove_dist():
    def remove_dist_is_none():
        assert should_remove_dist() is False

    def remove_dist_is_false():
        config["remove_dist"] = False
        assert should_remove_dist() is False

    def remove_dist_is_true():
        config["remove_dist"] = True
        config["upload_to_pypi"] = False
        assert should_remove_dist() is False

    def remove_dist_is_true_upload_to_pypi_is_true():
        config["remove_dist"] = True
        config["upload_to_pypi"] = True
        assert should_remove_dist() is True

    def remove_dist_is_true_upload_to_release_is_true():
        config["remove_dist"] = True

# Generated at 2022-06-24 01:38:20.555666
# Unit test for function remove_dists
def test_remove_dists():
    mock_path = "/Users/user/.my_home/my_project/build"
    print(remove_dists(mock_path))



# Generated at 2022-06-24 01:38:26.332434
# Unit test for function remove_dists
def test_remove_dists():
    local_config = config
    local_config.set("build_command", "false")
    local_config.set("remove_dist", "false")
    assert not should_remove_dist()
    local_config.set("build_command", "my_build_command")
    local_config.set("remove_dist", "true")
    assert should_remove_dist()

# Generated at 2022-06-24 01:38:27.886839
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-24 01:38:29.650044
# Unit test for function should_build
def test_should_build():
    return True

# Generated at 2022-06-24 01:38:30.152822
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists

# Generated at 2022-06-24 01:38:31.179188
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:38:35.669433
# Unit test for function should_build
def test_should_build():
    # GIVEN a config
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "ls -l"

    # WHEN I test if I should build dists
    should_build_result = should_build()

    # THEN I see that I should
    assert should_build_result == True



# Generated at 2022-06-24 01:38:36.326024
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:38:46.580306
# Unit test for function remove_dists
def test_remove_dists():
    from . import _test_paths
    from .utils import cd
    from .settings import config
    from .build import remove_dists
    from .settings import config
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from distutils.dir_util import copy_tree
    d = mkdtemp()
    p = Path(d)
    config["remove_dist"] = True
    config["build_command"] = "echo"
    config["release_path"] = _test_paths.release_path
    config["pypi_path"] = _test_paths.pypi_path
    remove_dists(d)
    # Test 1
    assert (not p.exists())
    # Test 2
    d = mkdtemp()

# Generated at 2022-06-24 01:38:48.854459
# Unit test for function remove_dists
def test_remove_dists():
    # TODO: Mock invoke's run() calls to check if the command actually gets called
    remove_dists("foo")



# Generated at 2022-06-24 01:38:51.556086
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:38:52.137414
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:54.852992
# Unit test for function remove_dists
def test_remove_dists():
    path = config.get("dist_path")
    command = f"rm -rf {path}"
    logger.debug(f"Check {command}")
    assert command == "rm -rf dist"

# Generated at 2022-06-24 01:38:57.820687
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:58.406968
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:39:00.206026
# Unit test for function remove_dists
def test_remove_dists():
    # Testing if the command is properly formed
    path = "pipeline/tests"
    command = f"rm -rf {path}"
 

# Generated at 2022-06-24 01:39:05.054355
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

if __name__ == "__main__":
    test_should_remove_dist()

# Generated at 2022-06-24 01:39:05.894109
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-24 01:39:07.209306
# Unit test for function remove_dists
def test_remove_dists():
    path = "/tmp"
    remove_dists(path)

# Generated at 2022-06-24 01:39:10.316663
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:39:15.042130
# Unit test for function build_dists
def test_build_dists():
    # TODO: Mock the `run` command to test this function
    pass



# Generated at 2022-06-24 01:39:16.550800
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

