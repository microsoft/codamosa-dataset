

# Generated at 2022-06-24 01:29:19.223557
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    assert not should_remove_dist()


if __name__ == '__main__':
    test_build_dists()
    print("Done")

# Generated at 2022-06-24 01:29:23.484985
# Unit test for function should_build
def test_should_build():
    assert should_build()
    assert not should_build(upload_pypi=False)
    assert not should_build(upload_release=False)
    assert not should_build(build_command="false")
    assert not should_build(build_command="")



# Generated at 2022-06-24 01:29:24.308056
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:29:26.760345
# Unit test for function remove_dists
def test_remove_dists():
    logger.debug("Testing remove_dists")
    remove_dists("/tmp/dist")
    remove_dists("/tmp")



# Generated at 2022-06-24 01:29:32.304983
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set_item("remove_dist", "true")
    assert should_remove_dist() == True

    config.set_item("remove_dist", "false")
    assert should_remove_dist() == False

    config.set_item("upload_to_pypi", "true")
    assert should_remove_dist() == False

    config.set_item("upload_to_release", "true")
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:29:37.123493
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-24 01:29:38.961383
# Unit test for function build_dists
def test_build_dists():
    success = False
    try:
        build_dists()
        success = True
    except Exception:
        success = False
    assert success == True


# Generated at 2022-06-24 01:29:47.983111
# Unit test for function remove_dists
def test_remove_dists():
    class MockRun:
        def __init__(self):
            self.command = None

        def __call__(self, command, **kwargs):
            self.command = command

    mock_run = MockRun()

    def mock_should_remove_dist(path):
        return True

    assert remove_dists(path="test/path", should_remove_dist=mock_should_remove_dist, run=mock_run) == True
    assert mock_run.command == "rm -rf test/path"

# Generated at 2022-06-24 01:29:50.188174
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:29:56.011150
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "true"
    assert should_remove_dist()

# Generated at 2022-06-24 01:29:58.013751
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config._config = {"remove_dist": "true", "build_command": "build_command"}
    assert should_remove_dist()



# Generated at 2022-06-24 01:29:58.993323
# Unit test for function should_build
def test_should_build():
    assert should_build() is False



# Generated at 2022-06-24 01:30:08.664572
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("build_command", "echo true")
    assert should_build()
    config.set("upload_to_pypi", False)
    assert should_build()
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build()
    config.set("upload_to_release", False)
    assert should_build()
    config.set("build_command", "false")
    assert not should_build()
    config.set("build_command", False)
    assert not should_build()
    config.set("build_command", "true")
    assert should_build()

# Generated at 2022-06-24 01:30:10.482465
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    #assert "OK" in result

# Generated at 2022-06-24 01:30:14.555615
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False



# Generated at 2022-06-24 01:30:20.042226
# Unit test for function should_build
def test_should_build():
    # If there is no build command, we should not build
    config["build_command"] = None
    assert not should_build()
    # If there is a build command, but we are not uploading to pypi or release,
    # we should not build
    config["build_command"] = "setup.py sdist bdist_wheel"
    assert not should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    # If build_command is false, we should

# Generated at 2022-06-24 01:30:21.451082
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:30:21.881447
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:23.593520
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == (
        True if config.get("remove_dist") and should_build() else False
    )

# Generated at 2022-06-24 01:30:35.300763
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_build()
    config.set("upload_to_pypi", True)
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()
    config.set("build_command", False)
    assert not should_build()
    config.set("upload_to_pypi", True)
    assert not should_build()
    config.set("upload_to_release", True)
    assert not should_build()
    config.set("build_command", "false")
    assert not should_build()



# Generated at 2022-06-24 01:30:35.633584
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-24 01:30:38.307107
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist")



# Generated at 2022-06-24 01:30:45.894671
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"

    build = should_build()
    assert not build, "build_command = false and upload_pypi = false should not build"

    config["build_command"] = "false"

    build = should_build()
    assert not build, "build_command = false and upload_release = false should not build"

    config["upload_to_release"] = "false"
    config["build_command"] = "true"

    build = should_build()
    assert build, "build_command = true and upload_pypi = true should build"

    config["upload_pypi"] = "false"
    config["upload_to_release"] = "true"

# Generated at 2022-06-24 01:30:46.444481
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-24 01:30:56.152405
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

    c = config.copy()
    c["remove_dist"] = "true"
    c["build_command"] = "false"
    c["upload_to_pypi"] = "true"
    c["upload_to_release"] = "true"
    assert should_remove_dist(c) is True

    c = config.copy()
    c["remove_dist"] = "true"
    c["build_command"] = "false"
    c["upload_to_pypi"] = "false"
    c["upload_to_release"] = "false"
    assert should_remove_dist(c) is False

    c = config.copy()
    c["remove_dist"] = "true"
    c["build_command"] = "false"

# Generated at 2022-06-24 01:30:56.974371
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")

# Generated at 2022-06-24 01:30:57.560041
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:31:03.746205
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

    config["remove_dist"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "echo"
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:04.563622
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:31:15.693215
# Unit test for function remove_dists
def test_remove_dists():
    from .settings import get_settings
    from .templates import create_dirs_and_files
    from ..utils import create_dirs
    from pathlib import Path
    import pytest
    import shutil
    import tempfile
    import subprocess

    def _remove_dir(dir_path):
        if dir_path.exists():
            shutil.rmtree(dir_path)
        if dir_path.exists():
            raise Exception
        logger.info(f"Path {dir_path} removed")

    config_file = Path(tempfile.mkdtemp())
    config_file.joinpath("config.json").touch()
    parent_path = config_file.parent
    _remove_dir(parent_path)

# Generated at 2022-06-24 01:31:19.399227
# Unit test for function remove_dists
def test_remove_dists():
    from .repo import get_repo_root
    from .dist import should_remove_dist, remove_dists

    if should_remove_dist():
        remove_dists(get_repo_root())

# Generated at 2022-06-24 01:31:21.231861
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert (should_remove_dist() == False)

# Generated at 2022-06-24 01:31:26.256049
# Unit test for function should_build
def test_should_build():
    config.set_data({'build_command': False})
    assert not should_build()
    config.set_data({'upload_to_pypi': True})
    assert not should_build()
    config.set_data({'build_command': True})
    assert should_build()
    config.set_data({'upload_to_pypi': False})
    assert should_build()
    config.set_data({'upload_to_release': True})
    assert should_build()
    config.set_data({'remove_dist': True})


# Generated at 2022-06-24 01:31:29.837377
# Unit test for function build_dists
def test_build_dists():
    assert should_build()



# Generated at 2022-06-24 01:31:30.674953
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:31:33.618749
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-24 01:31:36.937083
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:31:37.915038
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:31:49.221667
# Unit test for function build_dists
def test_build_dists():
    """
    This unit test for checking if when build_command is set to 'echo'
    build_dists will print to stdout 'echo'
    """
    from unittest.mock import patch, mock_open, call
    from .settings import config as unit_config
    unit_config['build_command'] = 'echo'
    with patch('invoke.run', autospec=True) as run:
        unit_config['upload_to_pypi'] = True
        unit_config['upload_to_release'] = True
        # call build_dists
        build_dists()
        # check if run called with expected command
        assert run.call_count == 1
        assert run.call_args_list[0][0][0] == 'echo'

        # mock run to return different command

# Generated at 2022-06-24 01:31:53.716835
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:32:02.349375
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "echo"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()

# Generated at 2022-06-24 01:32:12.750766
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "echo 'Building'"
    config["upload_to_pypi"] = True
    assert should_build(), "should_build returned False when upload_to_pypi is set"

    config["build_command"] = "echo 'Building'"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build(), "should_build returned False when upload_to_release is set"

    config["build_command"] = False
    config["upload_to_pypi"] = True
    assert not should_build(), "should_build returned True when upload_to_pypi and build_command is set"

    config["build_command"] = False
    config["upload_to_pypi"] = True

# Generated at 2022-06-24 01:32:15.710075
# Unit test for function remove_dists
def test_remove_dists():
    path = "test_remove_dists"
    remove_dists(path)

# Generated at 2022-06-24 01:32:16.482841
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:32:18.825833
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:32:21.518747
# Unit test for function remove_dists
def test_remove_dists():
    assert True



# Generated at 2022-06-24 01:32:24.354999
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    from .context import _context

    with _context():
        config.load(["tests/fixtures/nomad_dev.cfg"])
        build_dists()



# Generated at 2022-06-24 01:32:30.421578
# Unit test for function remove_dists
def test_remove_dists():
    import os, tempfile
    from .settings import BaseConfig
    # create a temporary directory
    path = tempfile.mkdtemp()
    # create a file in temporary directory
    fd, fp = tempfile.mkstemp(dir=path)
    BaseConfig.remove_dist = True
    remove_dists(path)
    assert os.path.exists(path) == False
    # remove the directory after the test
    os.rmdir(path)

# Generated at 2022-06-24 01:32:31.036527
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:32:38.570360
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "true")
    config.set("upload_to_pypi", "true")
    assert should_build() == True
    config.set("build_command", "false")
    assert should_build() == False
    config.set("upload_to_release", "true")
    config.set("build_command", "true")
    assert should_build() == True
    config.set("upload_to_release", "false")
    assert should_build() == False



# Generated at 2022-06-24 01:32:41.357002
# Unit test for function should_build
def test_should_build():
    assert (
        should_build() ==
        (True, "upload_to_pypi", "build_command")
    )



# Generated at 2022-06-24 01:32:42.085538
# Unit test for function should_build
def test_should_build():
    assert should_build() is False


# Generated at 2022-06-24 01:32:45.282173
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = {
        "upload_to_release": False,
        "upload_to_pypi": True,
        "build_command": "python setup.py sdist",
        "remove_dist": True
    }
    config.update(test_config)
    print(should_remove_dist())

# Generated at 2022-06-24 01:32:48.022623
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    assert should_build() != False

# Generated at 2022-06-24 01:32:54.315347
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = "true"
    config["build_command"] = "echo 'Hello world'"
    assert should_build()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo 'Hello world'"
    assert should_build()

# Generated at 2022-06-24 01:32:55.805568
# Unit test for function build_dists
def test_build_dists():
    command = "ls -al"
    build_dists()

# Generated at 2022-06-24 01:32:56.556109
# Unit test for function build_dists
def test_build_dists():
    run("true")



# Generated at 2022-06-24 01:33:04.615379
# Unit test for function should_build
def test_should_build():
    # pylint: disable=unused-argument
    def mock_config_get(key):
        return None

    assert should_build() is False

    config.get = mock_config_get
    config.load = lambda: None
    config.set("build_command", "pip install . --upgrade")

    # No upload
    assert should_build() is False

    config.set("upload_to_release", True)
    assert should_build() is True

    config.set("upload_to_pypi", True)
    assert should_build() is True

# Generated at 2022-06-24 01:33:13.969385
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["build_command"] = "echo test"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    assert not should_remove_dist()
    config["upload_to_pypi"] = "true"
    config["build_command"] = False
    assert not should_remove_dist()
    config["build_command"] = "echo test"


# Generated at 2022-06-24 01:33:14.764546
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")


# Generated at 2022-06-24 01:33:16.453823
# Unit test for function build_dists
def test_build_dists():
    logging.basicConfig(level=logging.DEBUG)
    config["build_command"] = "echo 'hello'"
    build_dists()

# Generated at 2022-06-24 01:33:18.767997
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("../dist/*.[!rpm|!deb]")
    remove_dists("../dist/*")

# Generated at 2022-06-24 01:33:27.626111
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    # Enable to build release package
    config["upload_to_release"] = True
    assert should_build() == False

    # Enable to build Pypi package
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build() == False

    # Enalble to run build command
    config["upload_to_pypi"] = False
    config["build_command"] = "echo"
    assert should_build() == True

    # Disable to run build command
    config["build_command"] = False
    assert should_build() == False

# Generated at 2022-06-24 01:33:28.785038
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:33:30.330106
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:33:31.407337
# Unit test for function should_build
def test_should_build():
    assert should_build() is False, "Should be False, checking for False."



# Generated at 2022-06-24 01:33:39.211272
# Unit test for function should_build
def test_should_build():
    assert should_build()
    config["build_command"] = False
    assert not should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "python setup.py bdist_egg"
    config["upload_to_pypi"] = False
    assert not should_build()
    config["upload_to_release"] = True
    assert should_build()

# Generated at 2022-06-24 01:33:46.021346
# Unit test for function should_build
def test_should_build():
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    upload_pypi = upload_pypi if upload_pypi != "false" else False
    upload_release = upload_release if upload_release != "false" else False
    build_command = build_command if build_command != "false" else False
    assert bool(build_command and (upload_pypi or upload_release)) == True

# Generated at 2022-06-24 01:33:50.396447
# Unit test for function build_dists
def test_build_dists():
    if should_build():
        build_dists()



# Generated at 2022-06-24 01:33:52.668980
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("foo/bar")
    assert run("cat ~/build.log | grep -iq \"rm -rf foo/bar\"")

# Generated at 2022-06-24 01:33:55.926191
# Unit test for function build_dists
def test_build_dists():
    assert isinstance(should_build(), bool)
    build_dists()

# Generated at 2022-06-24 01:34:05.725036
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "ls"
    assert should_build()
    config["upload_to_pypi"] = False
    assert should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "ls"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-24 01:34:06.318706
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:07.286615
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:08.690037
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:34:09.378721
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:20.433571
# Unit test for function should_remove_dist
def test_should_remove_dist():
    true_config = config
    true_config["remove_dist"] = True
    true_config["upload_to_release"] = True
    assert should_remove_dist()

    true_config["upload_to_release"] = False
    true_config["upload_to_pypi"] = True
    assert should_remove_dist()

    true_config["remove_dist"] = False
    true_config["upload_to_release"] = False
    true_config["upload_to_pypi"] = True
    assert not should_remove_dist()

    true_config["upload_to_release"] = True
    true_config["upload_to_pypi"] = False
    assert not should_remove_dist()

    true_config["upload_to_release"] = False

# Generated at 2022-06-24 01:34:21.554434
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() is True)

# Generated at 2022-06-24 01:34:28.579565
# Unit test for function should_build
def test_should_build():
    TEST_BUILD_CONFIG = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "test",
    }

    assert should_build() == False

    with config.patch(TEST_BUILD_CONFIG):
        assert should_build() == True

# Generated at 2022-06-24 01:34:35.584842
# Unit test for function should_build
def test_should_build():
    test_cases = [
        # (upload_pypi, upload_release, build_command, expected)
        (False, False, False, False),
        (False, False, True, False),
        (False, True, False, False),
        (False, True, True, True),
        (True, False, False, False),
        (True, False, True, True),
        (True, True, False, False),
        (True, True, True, True),
    ]
    for (upload_pypi, upload_release, build_command, expected) in test_cases:
        if expected:
            assert should_build(upload_pypi, upload_release, build_command)
        else:
            assert not should_build(upload_pypi, upload_release, build_command)

# Generated at 2022-06-24 01:34:39.307570
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm"
    test_remove_dists.command = command


if __name__ == "__main__":
    test_remove_dists()

# Generated at 2022-06-24 01:34:41.369057
# Unit test for function remove_dists
def test_remove_dists():
    path = 'example.py'
    assert remove_dists(path) == 'rm -rf example.py'

# Generated at 2022-06-24 01:34:42.358547
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:34:47.269505
# Unit test for function should_build
def test_should_build():
    class fake_config:
        @classmethod
        def get(cls, key):
            return {
                "upload_to_pypi": True,
                "upload_to_release": True,
                "build_command": "python setup.py sdist bdist_wheel",
            }.get(key)

    config.CONFIG = fake_config()
    assert should_build(), "should build"
    config.CONFIG = None



# Generated at 2022-06-24 01:34:53.631313
# Unit test for function should_build
def test_should_build():
    _settings = {
        # Upload to pypi, build command, status
        True: {True: True, False: False},
        False: {False: False, True: True},
    }

    for upload in [True, False]:
        for build in [True, False]:
            for key in _settings.keys():
                status = _settings[key][upload]
                command = "build" if build else False
                assert should_build(build_command=command, upload_to_pypi=key, upload_to_release=upload) == status, f"failed on {upload} {build}"

# Generated at 2022-06-24 01:35:03.583845
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "echo foo")
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("remove_dist", True)
    assert should_remove_dist()

    config.set("build_command", "echo foo")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("remove_dist", True)
    assert not should_remove_dist()

    # Delete config values
    config.unset("build_command")
    config.unset("upload_to_pypi")
    config.unset("upload_to_release")
    config.unset("remove_dist")

# Generated at 2022-06-24 01:35:08.179611
# Unit test for function should_build
def test_should_build():
    from .settings import Settings
    from .utils import PROJECT_NAME
    settings = Settings(project_name=PROJECT_NAME)
    settings.read_file()
    assert should_build() is False
    settings.config.pop("build_command")
    assert should_build() is False
    settings.config.pop("upload_to_pypi")
    assert should_build() is False
    settings.config.pop("upload_to_release")
    assert should_build() is False
    settings.config.update({"build_command": "false"})
    assert should_build() is False
    settings.config.update(
        {
            "build_command": "python setup.py sdist bdist_wheel",
            "upload_to_pypi": True
        })
    assert should_build() is True
   

# Generated at 2022-06-24 01:35:16.923055
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import build_config, clear_config

    build_config({"upload_to_pypi": True, "upload_to_release": False,
                  "remove_dist": True, "build_command": "echo 'foo'"})
    assert should_remove_dist()

    build_config({"upload_to_pypi": True, "upload_to_release": False,
                  "remove_dist": False, "build_command": "echo 'foo'"})
    assert not should_remove_dist()

    build_config({"upload_to_pypi": True, "upload_to_release": False,
                  "remove_dist": True, "build_command": False})
    assert not should_remove_dist()


# Generated at 2022-06-24 01:35:18.609498
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:35:28.941357
# Unit test for function should_build
def test_should_build():
    # Check if should build false
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    config['build_command'] = 'false'
    assert should_build() is False

    # Check if should build false
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    config['build_command'] = 'false'
    assert should_build() is False

    # Check if should build false
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    config['build_command'] = 'false'
    assert should_build() is False

    # Check if should build true
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False


# Generated at 2022-06-24 01:35:29.941391
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True or False

# Generated at 2022-06-24 01:35:31.263231
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True



# Generated at 2022-06-24 01:35:32.622021
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist")



# Generated at 2022-06-24 01:35:33.509564
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-24 01:35:34.440802
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:35:40.506793
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": "true", "build_command": "./setup.py sdist"})
    assert should_build()
    config.update({"upload_to_pypi": "true", "build_command": "false"})
    assert not should_build()
    config.update({"upload_to_pypi": "true"})
    assert not should_build()



# Generated at 2022-06-24 01:35:46.557442
# Unit test for function build_dists
def test_build_dists():
    logging.basicConfig(level=logging.DEBUG)
    test_config = {
        "build_command": "echo 1",
        "upload_to_pypi": True,
        "upload_to_release": False,
        "remove_dist": False
    }
    config.update(test_config)
    build_dists()



# Generated at 2022-06-24 01:35:47.179018
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:35:48.135282
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:35:54.261439
# Unit test for function should_build
def test_should_build():
    config.clear()
    assert should_build() is False
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_release"] = True
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = True
    assert should_build() is True
    config["upload_to_pypi"] = False
    assert should_build() is True
    config["upload_to_release"] = False
    assert should_build() is False


# Generated at 2022-06-24 01:35:57.291373
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")
    assert True

# Generated at 2022-06-24 01:35:59.186780
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo 'hello world'"
    build_dists()
    config["build_command"] = "false"


# Generated at 2022-06-24 01:36:09.131733
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "./build.sh"
    assert should_build() is True

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "./build.sh"
    assert should_build() is False

    config["upload_to_pypi"] = ""
    config["upload_to_release"] = ""
    config["build_command"] = "./build.sh"
    assert should_build() is False

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"

# Generated at 2022-06-24 01:36:11.676329
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist()
    remove_dists("dist")

# Generated at 2022-06-24 01:36:13.165264
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/shutils-test")

# Generated at 2022-06-24 01:36:14.627832
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-24 01:36:15.558205
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:36:16.958333
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test_file")

# Generated at 2022-06-24 01:36:17.922870
# Unit test for function build_dists
def test_build_dists():
    # run build dist
    build_dists()

# Generated at 2022-06-24 01:36:18.817169
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:36:26.191830
# Unit test for function should_build
def test_should_build():
    assert should_build("setup.py sdist", True, True)  # Both True
    assert should_build("setup.py sdist", True, False)  # pypi True
    assert should_build("setup.py sdist", False, True)  # release True
    assert not should_build("", True, True)  # All false
    assert not should_build("", False, False)  # All false


# Generated at 2022-06-24 01:36:28.330257
# Unit test for function build_dists
def test_build_dists():
    assert False == should_build()
    assert 0 == run("ls").return_code
    assert False == should_remove_dist()
    assert 0 == run("ls").return_code

# Generated at 2022-06-24 01:36:29.245369
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/test")

# Generated at 2022-06-24 01:36:30.465671
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("./dist*")

# Generated at 2022-06-24 01:36:32.926625
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    # Check if the file exist after the build
    import os.path
    assert os.path.isfile('dist/pypi_gh_actions_example-1.0.0.tar.gz') is True

# Generated at 2022-06-24 01:36:36.042606
# Unit test for function build_dists
def test_build_dists():
    assert callable(build_dists)

# Generated at 2022-06-24 01:36:38.571581
# Unit test for function should_build
def test_should_build():
    config["build_command"] = True
    config["upload_to_pypi"] = True

    assert should_build()

# Generated at 2022-06-24 01:36:39.145951
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:36:42.420791
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("upload_to_pypi", True)
    config.set("build_command", "true")
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()


# Generated at 2022-06-24 01:36:48.961429
# Unit test for function should_build
def test_should_build():
    # input_1
    global config
    config = {"build_command": "sphinx-build", "upload_to_release": "true",
              "upload_to_pypi": "true"}
    assert should_build()
    # input_2
    config = {"build_command": "sphinx-build", "upload_to_release": "false",
              "upload_to_pypi": "true"}
    assert should_build()
    # input_3
    config = {"build_command": "false", "upload_to_release": "true",
              "upload_to_pypi": "true"}
    assert should_build()
    # input_4

# Generated at 2022-06-24 01:36:50.417636
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()

# Generated at 2022-06-24 01:36:58.641520
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Scenario 1: Should remove dist according to config
    config["build_command"] = "build_command"
    config["remove_dist"] = True
    assert should_remove_dist() is True

    # Scenario 2: Should not remove dist because build_command is not present
    config["build_command"] = False
    assert should_remove_dist() is False

    # Scenario 3: Should not remove dist because remove_dist is False
    config["build_command"] = "build_command"
    config["remove_dist"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:36:59.617654
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:37:04.118011
# Unit test for function should_build
def test_should_build():
    config._storage = {}
    assert should_build() is False

    config["build_command"] = "ls"
    assert should_build() is False

    config["upload_release"] = True
    assert should_build() is True

    config["upload_pypi"] = True
    assert should_build() is True

    config["build_command"] = "false"
    assert should_build() is False


# Generated at 2022-06-24 01:37:05.433820
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/samples/")

# Generated at 2022-06-24 01:37:07.032084
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-24 01:37:13.755048
# Unit test for function remove_dists
def test_remove_dists():
    try:
        import builtins
        # pylint: disable=no-member, protected-access
        builtins._ = remove_dists
    except (ImportError, AttributeError):
        pass
    try:
        import __builtin__ as builtins
        # pylint: disable=no-member, protected-access
        builtins._ = remove_dists
    except ImportError:
        pass

# Generated at 2022-06-24 01:37:14.199192
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:37:16.165971
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:37:19.440304
# Unit test for function build_dists
def test_build_dists():
    config.update({"build_command": "python setup.py"})
    build_dists()
    config.update({"build_command": False})
    build_dists()

# Generated at 2022-06-24 01:37:28.974089
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_false = {"build_command": "echo 1",
                    "remove_dist": "false",
                    "upload_to_pypi": "true",
                    "upload_to_release": "false"}
    config_true = {"build_command": "echo 1",
                   "remove_dist": "true",
                   "upload_to_pypi": "true",
                   "upload_to_release": "false"}
    config["build_command"] = "echo 1"
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist() == False
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:32.899078
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf /tmp"
    run(command)
    #assert False

# Generated at 2022-06-24 01:37:33.443817
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-24 01:37:34.260596
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:37:35.932025
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    print(f"Test case for building distributions.")


# Generated at 2022-06-24 01:37:43.685998
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "sdist bdist_wheel")
    assert should_build() is True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "sdist bdist_wheel")
    assert should_build() is False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "sdist bdist_wheel")
    assert should_build() is True
    config.set("upload_to_pypi", False)

# Generated at 2022-06-24 01:37:48.701109
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # True if build_command and remove_dist are both True
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

    # False if build_command is False
    config["build_command"] = False
    config["remove_dist"] = True
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:51.059283
# Unit test for function should_remove_dist
def test_should_remove_dist():
    if should_remove_dist() is True:
        assert True
    else:
        assert False


# Generated at 2022-06-24 01:37:52.153508
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:58.354591
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # check if remove_dist = True and upload_to_pypi = True
    # then should_remove_dist is True
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True

    # check if remove_dist = False then should_remove_dist is False
    config["remove_dist"] = False
    assert should_remove_dist() == False

    # check if remove_dist = True and upload_to_pypi = False
    # then should_remove_dist is False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-24 01:37:58.943556
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:00.061741
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists


# Generated at 2022-06-24 01:38:04.348927
# Unit test for function should_build
def test_should_build():

    test_config = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "sdist bdist_wheel",
    }
    assert should_build(test_config)



# Generated at 2022-06-24 01:38:05.953688
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:38:11.925910
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "ls"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

    config["upload_to_pypi"] = True
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() is True

    config["build_command"] = "false"
    assert should_build() is False



# Generated at 2022-06-24 01:38:14.107069
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:38:14.910119
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:38:19.133428
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()

    config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-24 01:38:19.699222
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:27.446866
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    config["build_command"] = None
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = None
    config["build_command"] = None
    assert not should_build()

    config["upload_to_pypi"] = None
    config["upload_to_release"] = True
    config["build_command"] = None
    assert not should_build()

    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    config["build_command"] = "test"
    assert not should_build()

    config["upload_to_pypi"] = True

# Generated at 2022-06-24 01:38:30.121387
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists('/') == None


# Generated at 2022-06-24 01:38:38.007176
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py build"
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py build"
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py build"
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py build"
    assert should_

# Generated at 2022-06-24 01:38:48.156542
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "Should return False if remove_dist = false"
    config["remove_dist"] = "true"
    assert should_remove_dist() == False, "Should return False if build_command = false"
    config["build_command"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist() == False, "Should return False if upload_to_release = false"
    config["upload_to_pypi"] = "false"
    assert should_remove_dist() == False, "Should return False if upload_to_pypi = false"
    config["upload_to_release"] = "true"
    assert should_remove_dist() == True, "Should return True"
    config["upload_to_pypi"] = "true"


# Generated at 2022-06-24 01:38:56.555694
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config['remove_dist'] = 'true'
    assert should_remove_dist() == True
    config['upload_to_pypi'] = 'true'
    assert should_remove_dist() == False
    config['upload_to_release'] = 'true'
    assert should_remove_dist() == False
    config['build_command'] = 'true'
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:39:02.352145
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["build_command"] = False
    assert not should_build()

    config["build_command"] = "python3 setup.py build"
    assert should_build()

# Generated at 2022-06-24 01:39:09.781699
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.remove_dist = True
    assert should_remove_dist() is True
    config.remove_dist = False
    assert should_remove_dist() is False
    config.upload_to_release = True
    assert should_remove_dist() is False
    config.upload_to_pypi = True
    assert should_remove_dist() is True
    config.build_command = "false"
    assert should_remove_dist() is False
    config.build_command = "pwd"
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:39:12.851864
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = "true"
    assert should_build()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build()


# Generated at 2022-06-24 01:39:14.590294
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-24 01:39:15.768183
# Unit test for function build_dists
def test_build_dists():
    pass
