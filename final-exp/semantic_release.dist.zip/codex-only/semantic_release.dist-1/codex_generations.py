

# Generated at 2022-06-24 01:29:16.397514
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-24 01:29:20.785909
# Unit test for function should_build
def test_should_build():
    # pylint: disable=protected-access
    config._dict["upload_to_pypi"] = True
    config._dict["upload_to_release"] = False
    config._dict["build_command"] = "ls"
    assert should_build()

    config._dict["upload_to_pypi"] = False
    config._dict["upload_to_release"] = True
    assert should_build()

    config._dict["upload_to_pypi"] = False
    config._dict["upload_to_release"] = False
    assert not should_build()

    config._dict["upload_to_pypi"] = True
    config._dict["upload_to_release"] = True
    assert should_build()

    config._dict["build_command"] = "false"
    assert not should_build()

#

# Generated at 2022-06-24 01:29:24.652801
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dist = {"remove_dist": "true",
            "build_command": "build",
            "upload_to_pypi": "true",
            "upload_to_release": "true"}
    assert True == should_remove_dist()

# Generated at 2022-06-24 01:29:34.051702
# Unit test for function should_build
def test_should_build():
    # Check for pypi only upload
    config["build_command"] = "./setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() is True
    config["build_command"] = False
    assert should_build() is False
    # Check for upload pypi and github release
    config["build_command"] = "./setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() is True
    # Check for upload github release only
    config["build_command"] = "./setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = False
    config

# Generated at 2022-06-24 01:29:41.436902
# Unit test for function build_dists
def test_build_dists():
    import os
    import shutil

    def gen_setup_py(setup_py_name):
        with open(setup_py_name, "w") as setup_py:
            setup_py.write("import setuptools\n" \
                           "if __name__ == '__main__':\n" \
                           "    setuptools.setup(name='test.pkg')\n")

    build_path = os.getcwd() + "/build"
    dist_path = build_path + "/dist"
    clean_up_paths = [build_path, dist_path]


# Generated at 2022-06-24 01:29:41.982613
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-24 01:29:42.742537
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:29:51.901981
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    test_directory = tempfile.mkdtemp()
    test_file = tempfile.NamedTemporaryFile(dir=test_directory)
    # Remove the file initially
    os.remove(test_file.name)
    # Create a directory and a file
    os.mkdir(os.path.join(test_directory, "dist"))
    test_file.write(b"Sample text")
    test_file.flush()
    # Assert the file exists
    assert os.path.exists(test_file.name)
    # Ensure the file closes, this is required by the next line
    test_file.close()
    # Run the remove command
    remove_dists(test_directory)
    # Assert the file and directory were deleted

# Generated at 2022-06-24 01:29:54.173429
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "test"
    config["remove_dist"] = "test"
    assert should_remove_dist() is True
    config["upload_to_pypi"] = "test"
    assert should_remove_dist() is False

# Generated at 2022-06-24 01:30:06.714915
# Unit test for function should_build
def test_should_build():
    config_should_build = {
        "build_command": "echo hello",
        "upload_to_pypi": True,
        "upload_to_release": True,
    }
    assert should_build() == True
    config_should_build = {
        "build_command": "false",
        "upload_to_pypi": True,
        "upload_to_release": True,
    }
    assert should_build() == False
    config_should_build = {
        "build_command": "echo hello",
        "upload_to_pypi": False,
        "upload_to_release": False,
    }
    assert should_build() == False

# Generated at 2022-06-24 01:30:08.541330
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:30:10.731630
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    assert should_build() is True



# Generated at 2022-06-24 01:30:14.110680
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists.__name__ == "remove_dists"

# Generated at 2022-06-24 01:30:20.292589
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True
    assert should_remove_dist() is True
    assert config.get("build_command") is not None
    assert config.get("upload_to_pypi") is not None
    assert config.get("upload_to_release") is not None
    build_dists()
    assert should_build()

# Generated at 2022-06-24 01:30:22.764039
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:30:24.080342
# Unit test for function should_build
def test_should_build():
    should_build_pypi = should_build()
    assert should_build_pypi is True

# Generated at 2022-06-24 01:30:24.613126
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:30:33.237426
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "false"
    # Assert return false
    assert should_build() == False

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "pip install"
    # Assert return true
    assert should_build() == True



# Generated at 2022-06-24 01:30:43.979302
# Unit test for function should_remove_dist
def test_should_remove_dist():
    settings = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": True,
        "remove_dist": True,
    }
    assert should_remove_dist()
    settings["upload_to_pypi"] = False
    assert should_remove_dist()
    settings["upload_to_release"] = False
    assert not should_remove_dist()
    settings = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": True,
        "remove_dist": False,
    }
    assert not should_remove_dist()

# Generated at 2022-06-24 01:30:53.999743
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "something"
    assert should_build() is True, "should_build is False"

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "something"
    assert should_build() is True, "should_build is False"

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "something"
    assert should_build() is True, "should_build is False"

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

# Generated at 2022-06-24 01:30:57.312360
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == True
    build_dists()

# Generated at 2022-06-24 01:31:04.169809
# Unit test for function should_build
def test_should_build():
    config.set('upload_to_pypi', False)
    config.set('upload_to_release', False)
    config.set('build_command', False)
    assert should_build() == False

    config.set('upload_to_pypi', True)
    config.set('upload_to_release', True)
    config.set('build_command', True)
    assert should_build() == True

# Generated at 2022-06-24 01:31:04.972556
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-24 01:31:11.872298
# Unit test for function should_build
def test_should_build():
    # Should return True
    config.set("build_command", "build")
    assert should_build() is True
    # Should return True
    config.set("upload_to_pypi", True)
    assert should_build() is True
    # Should return True
    config.set("upload_to_release", True)
    assert should_build() is True



# Generated at 2022-06-24 01:31:21.843746
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    config.update({
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "python3 setup.py sdist bdist_wheel"
    })
    assert should_build() is True

    config.update({
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "python3 setup.py sdist bdist_wheel"
    })
    assert should_build() is True

    config.update({
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "python3 setup.py sdist bdist_wheel"
    })
    assert should_build() is False

    config.update

# Generated at 2022-06-24 01:31:26.127197
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo build"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = False
    assert not should_build()
    config["build_command"] = ""
    assert not should_build()



# Generated at 2022-06-24 01:31:30.066997
# Unit test for function remove_dists
def test_remove_dists():
    pass


# Generated at 2022-06-24 01:31:35.709650
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.update(
        {
            "upload_to_pypi": True,
            "upload_to_release": False,
            "build_command": "python setup.py sdist bdist_wheel",
        }
    )
    assert should_build()
    config.update(
        {
            "upload_to_pypi": True,
            "upload_to_release": True,
            "build_command": "python setup.py sdist bdist_wheel",
        }
    )
    assert should_build()



# Generated at 2022-06-24 01:31:42.002268
# Unit test for function should_build
def test_should_build():
    assert(should_build() == False)
    config["build_command"] = "false"
    assert(should_build() == False)
    config["build_command"] = "true"
    assert(should_build() == False)
    config["upload_to_pypi"] = "true"
    assert(should_build() == True)
    config["upload_to_pypi"] = "false"
    assert(should_build() == False)
    config["upload_to_release"] = "true"
    assert(should_build() == True)
    config["upload_to_release"] = "false"
    assert(should_build() == False)


# Generated at 2022-06-24 01:31:45.246186
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config.set("upload_to_release", "yes")
    assert not should_remove_dist()
    config.set("build_command", "python setup.py sdist")
    assert should_remove_dist()

# Generated at 2022-06-24 01:31:46.055471
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-24 01:31:48.905981
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/*")

# Generated at 2022-06-24 01:31:59.622046
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_for_test = config.copy()
    config_for_test["build_command"] = "some command"
    config_for_test["remove_dist"] = "false"
    assert should_remove_dist() == False

    config_for_test = config.copy()
    config_for_test["build_command"] = "some command"
    config_for_test["remove_dist"] = "true"
    assert should_remove_dist() == True

    config_for_test = config.copy()
    config_for_test["upload_to_release"] = "false"
    config_for_test["build_command"] = "some command"
    config_for_test["remove_dist"] = "true"
    assert should_remove_dist() == True

    config_for_test = config.copy()
   

# Generated at 2022-06-24 01:32:06.965872
# Unit test for function should_build
def test_should_build():
    config['build_command'] = 'test build command'
    config['upload_to_pypi'] = 'test upload to pypi'
    assert should_build()

    config['upload_to_pypi'] = 'False'
    assert should_build()

    config['build_command'] = 'False'
    config['upload_to_release'] = 'test upload to release'
    assert should_build()

    config['build_command'] = 'False'
    config['upload_to_pypi'] = 'False'
    assert not should_build()

    config['upload_to_release'] = 'False'
    config['upload_to_pypi'] = 'True'
    assert not should_build()

# Generated at 2022-06-24 01:32:13.140329
# Unit test for function build_dists
def test_build_dists():
    import tempfile
    import os
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b'Test')
    f.close()
    os.environ["build_command"] = 'echo'
    build_dists()



# Generated at 2022-06-24 01:32:13.860609
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-24 01:32:15.738308
# Unit test for function build_dists
def test_build_dists():
    config.update({"_root": "zipline", "build_command": "ls"})
    build_dists()
    assert config["build_command"] == "ls"

# Generated at 2022-06-24 01:32:16.807688
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-24 01:32:19.735889
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True, "Should remove dists"
    assert should_build() == True, "Should build dists"
    assert should_remove_dist() == True, "Should remove dists"
    assert should_build() == True, "Should build dists"
    assert should_remove_dist() == True, "Should remove dists"

# Generated at 2022-06-24 01:32:23.665219
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.upload_to_pypi = True
    config.build_command = True
    assert should_build()



# Generated at 2022-06-24 01:32:24.973020
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True



# Generated at 2022-06-24 01:32:34.477243
# Unit test for function build_dists
def test_build_dists():
    """testing function build_dists
    """
    # functional logic test
    assert_build_dists_called = False
    def run_build_dists(command):
        assert command == "command to run"
        nonlocal assert_build_dists_called
        assert_build_dists_called = True
    global run
    run = run_build_dists
    global config
    config["build_command"] = "command to run"
    global upload_to_release
    upload_to_release = True
    global upload_to_pypi
    upload_to_pypi = True
    build_dists()
    assert assert_build_dists_called

    # unittest for upload_to_pypi and upload_to_release is false 
    # and build_command is false
    assert_

# Generated at 2022-06-24 01:32:40.753361
# Unit test for function remove_dists
def test_remove_dists():

    # Happy flow
    command1 = "rm -rf path/to/file"
    assert remove_dists(path="path/to/file") == command1

    # Non-happy flow
    command2 = "rm -rf path/to/file"
    assert remove_dists(path="") != command2

# Generated at 2022-06-24 01:32:43.290454
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp/fake-dist") == None

# Generated at 2022-06-24 01:32:45.237187
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist()
    remove_dists(config.get("dist_dir"))

# Generated at 2022-06-24 01:32:50.907768
# Unit test for function remove_dists
def test_remove_dists():
    try:
        remove_dists("/tmp/test")
    except Exception as e:
        assert(e.exited) == False
        assert(e.failed) == True
        assert(e.message) == ("Command failed: rm -rf /tmp/test", 1)
        return
    assert(False)

# Generated at 2022-06-24 01:32:51.455963
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-24 01:32:52.721616
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build() is True


# Generated at 2022-06-24 01:32:54.423149
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-24 01:32:55.523479
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-24 01:32:58.976259
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist/*")



# Generated at 2022-06-24 01:32:59.908340
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:02.211557
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-24 01:33:09.153108
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "false"
    assert should_remove_dist() is False

    config["upload_to_pypi"] = "false"
    assert should_remove_dist() is False

    config["build_command"] = "false"
    assert should_remove_dist() is False

    config["upload_to_release"] = "false"
    assert should_remove_dist() is False

    config["upload_to_release"] = "true"
    assert should_remove_dist() is True

    config["upload_to_pypi"] = "true"
    assert should_remove_dist() is True

    config["upload_to_pypi"] = "false"
    config["build_command"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:33:13.969289
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist()
    config.set("remove_dist", "True")
    assert should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()
    config.set("remove_dist", "False")
    assert not should_remove_dist()
    config.set("remove_dist", None)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:33:15.468545
# Unit test for function remove_dists
def test_remove_dists():
    with open("test_file") as f:
        pass
    remove_dists("test_file")

# Generated at 2022-06-24 01:33:26.721233
# Unit test for function should_build
def test_should_build():
    # test that we should build when build_command is true
    config["build_command"] = "build"
    assert should_build()

    # test that we should not build when build_command is false
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_build()

    # test that we should not build when upload_to_pypi is false and upload_to_release is true
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "build"
    assert not should_build()

    # test that we should not build when upload_to_release is false and upload_to_pypi is true

# Generated at 2022-06-24 01:33:28.405114
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:33:39.796644
# Unit test for function build_dists
def test_build_dists():
    # Test for no config
    config.update({
        "build_command": False,
        "upload_to_pypi": False,
        "upload_to_release": False
    })
    assert should_build() is False
    assert should_remove_dist() is False

    # Test for config with no release section
    config.update({
        "build_command": "false",
        "upload_to_pypi": False,
        "upload_to_release": False
    })
    assert should_build() is False
    assert should_remove_dist() is False

    # Test for config with no release
    config.update({
        "build_command": False,
        "upload_to_pypi": False,
        "upload_to_release": True
    })
    assert should_build() is False


# Generated at 2022-06-24 01:33:40.608114
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test_dist")

# Generated at 2022-06-24 01:33:43.234550
# Unit test for function build_dists
def test_build_dists():
    config['build_command'] = f"touch /tmp/test-{config['short_name']}.tar.gz"
    build_dists()
    config['build_command'] = False

# Generated at 2022-06-24 01:33:45.870090
# Unit test for function remove_dists
def test_remove_dists():
    path = "path/to/dir"
    command = f"rm -rf {path}"
    assert remove_dists(path) == run(command)


# Generated at 2022-06-24 01:33:47.598832
# Unit test for function should_build
def test_should_build():
    assert should_build() is not False

# Generated at 2022-06-24 01:33:48.448473
# Unit test for function build_dists
def test_build_dists():
    assert isinstance(build_dists, object)

# Generated at 2022-06-24 01:33:56.670709
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import config

    # Verify default values
    config.set_default_values()
    assert should_remove_dist() == True

    # Verify False when remove_dist is False
    config.remove_dist = False
    assert should_remove_dist() == False

    # Verify False when build_command is False
    config.remove_dist = True
    config.build_command = False
    assert should_remove_dist() == False

    # Verify False when upload_to_pypi is False
    config.build_command = "cmd"
    config.upload_to_pypi = False
    assert should_remove_dist() == False

    # Verify False when upload_to_release is False
    config.upload_to_pypi = True
    config.upload_to_release = False
    assert should_remove_dist

# Generated at 2022-06-24 01:33:59.795296
# Unit test for function should_build
def test_should_build():
    #  Note: Testing that a boolean is considered True
    #  See: https://www.tutorialspoint.com/python/logical_operators_example.htm
    assert should_build() is True



# Generated at 2022-06-24 01:34:01.839461
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Unit tests for function build_dists

# Generated at 2022-06-24 01:34:02.635608
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-24 01:34:10.380223
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Returns True if the config file has remove_dist set to True and the
    build command is also set to something
    """
    config.set("remove_dist", True)
    config.set("build_command", "build")
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()
    config.set("remove_dist", True)
    config.set("build_command", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:34:14.237483
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert not should_remove_dist()
    build_dists()

# Generated at 2022-06-24 01:34:19.718918
# Unit test for function remove_dists
def test_remove_dists():
    def test_command():
        pass
    remove_dists(path='.')
    remove_dists(path=None)

# Generated at 2022-06-24 01:34:20.633521
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-24 01:34:25.719041
# Unit test for function remove_dists
def test_remove_dists():
    run('rm -rf ~/tmp/temp_dists')
    run('mkdir ~/tmp/temp_dists')
    run('touch ~/tmp/temp_dists/foo')
    path = '~/tmp/temp_dists'
    assert run(f'ls {path} | wc -l').stdout.strip() == '1', "Directory not empty after creation"
    remove_dists(path)
    assert run(f'ls {path} | wc -l').stdout.strip() == '0', "Directory is not empty after cleanup"

# Generated at 2022-06-24 01:34:28.175478
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:34:33.998456
# Unit test for function should_build
def test_should_build():
    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "xyz"
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()

    config["build_command"] = "xyz"
    config["upload_to_release"] = True
    assert should_build()
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build()



# Generated at 2022-06-24 01:34:42.405118
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == False

    config["upload_to_pypi"] = True
    config["build_command"] = False
    assert should_remove_dist() == False

    config["build_command"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:34:43.746794
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-24 01:34:46.966216
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:34:53.988120
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": True, "upload_to_release": False, "build_command": "false"})
    assert not should_build()
    config.update({"upload_to_pypi": True, "upload_to_release": False, "build_command": "true"})
    assert should_build()
    config.update({"upload_to_pypi": True, "upload_to_release": False, "build_command": "test"})
    assert should_build()
    config.update({"upload_to_pypi": False, "upload_to_release": True, "build_command": "false"})
    assert not should_build()

# Generated at 2022-06-24 01:34:54.961591
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")


# Generated at 2022-06-24 01:34:55.902698
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists()



# Generated at 2022-06-24 01:34:56.497834
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:58.188179
# Unit test for function remove_dists
def test_remove_dists():
    """Test remove dist
    """
    remove_dists("dist")

# Generated at 2022-06-24 01:34:58.863106
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:34:59.774379
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-24 01:35:04.545472
# Unit test for function build_dists
def test_build_dists():
    # given
    build_command = "python setup.py bdist_wheel"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = build_command
    # when
    build_dists()
    # then
    assert True



# Generated at 2022-06-24 01:35:11.306469
# Unit test for function build_dists
def test_build_dists():
    import os
    from . import settings
    from . import dist

    assert globals()['config']['build_command'] == 'false'


    assert dist.should_build() == False

    settings.config['build_command'] = 'python setup.py sdist bdist_wheel'
    assert dist.should_build() == False
    settings.config['upload_to_pypi'] = 'true'
    settings.config['upload_to_release'] = 'false'
    assert dist.should_build() == True
    settings.config['upload_to_pypi'] = 'false'
    settings.config['upload_to_release'] = 'true'
    assert dist.should_build() == True

    settings.config['upload_to_pypi'] = 'true'

# Generated at 2022-06-24 01:35:13.489991
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:14.283940
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:18.656244
# Unit test for function remove_dists
def test_remove_dists():
    assert "rm " in remove_dists("")


# Generated at 2022-06-24 01:35:20.909785
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile

    path = tempfile.mkdtemp()
    remove_dists(path)
    assert not os.path.exists(path)



# Generated at 2022-06-24 01:35:22.270133
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-24 01:35:22.751898
# Unit test for function should_build
def test_should_build():
    pass



# Generated at 2022-06-24 01:35:28.721470
# Unit test for function should_build
def test_should_build():
    # should be true
    assert should_build()
    # set build_command to False
    config.set("build_command", "false")
    # should be false
    assert not should_build()
    # set build_command to True
    config.set("build_command", "sphinx-build")
    # should be false as upload_to_pypi is false
    assert not should_build()
    # set upload_to_pypi to True
    config.set("upload_to_pypi", "true")
    # should be true
    assert should_build()
    # set upload_to_release to False
    config.set("upload_to_release", "false")
    # should be true as upload_to_pypi is True
    assert should_build()
    # set upload_to_p

# Generated at 2022-06-24 01:35:37.233409
# Unit test for function should_build
def test_should_build():
    from .settings import config as _config
    from .settings import WERKZEUG_SECTION
    from .settings import BASE_SECTION

    assert not should_build()

    _config.set(BASE_SECTION, 'upload_to_pypi', True)
    assert not should_build()

    _config.set(WERKZEUG_SECTION, 'build_command', 'ls')
    assert should_build()

    _config.set(BASE_SECTION, 'upload_to_pypi', False)
    _config.set(BASE_SECTION, 'upload_to_release', True)
    assert should_build()

    _config.set(BASE_SECTION, 'upload_to_pypi', True)

# Generated at 2022-06-24 01:35:44.871230
# Unit test for function remove_dists
def test_remove_dists():
    from .test_utils import assert_existing_directories_are_deleted, assert_non_existent_directories_are_deleted

    # non-existent directory should not raise an exception
    assert_non_existent_directories_are_deleted(remove_dists, '/tmp/this_directory_should_not_exist')

    # existent directory should be deleted
    assert_existing_directories_are_deleted(remove_dists, '/tmp')



# Generated at 2022-06-24 01:35:47.092048
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:35:48.850260
# Unit test for function remove_dists
def test_remove_dists():
    def run(a):
        return a

    assert run('rm -rf ./dist') == 'rm -rf ./dist'

# Generated at 2022-06-24 01:35:49.756470
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:35:53.342460
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "ls /tmp"
    assert should_build()
    assert not should_remove_dist()
    config["remove_dist"] = True
    assert should_remove_dist()
    build_dists()
    config["build_command"] = "false"
    assert not should_build()


# Generated at 2022-06-24 01:35:57.560775
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False



# Generated at 2022-06-24 01:35:58.466562
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build/*")

# Generated at 2022-06-24 01:36:08.645456
# Unit test for function should_build
def test_should_build():
    # return True with upload_pypi set to True and upload_release set to False
    assert should_build({"upload_to_pypi": True,
                         "upload_to_release": False,
                         "build_command": "command"}), "should be true"
    assert not should_build({}), "should be false"
    assert not should_build({"upload_to_pypi": False,
                             "upload_to_release": False,
                             "build_command": "command"}), "should be false"
    assert not should_build({"upload_to_pypi": True,
                             "upload_to_release": True,
                             "build_command": "false"}), "should be false"



# Generated at 2022-06-24 01:36:15.255566
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["build_command"] = "test command"
    assert should_build() is True
    config["upload_to_pypi"] = True
    assert should_build() is True
    config["upload_to_release"] = True
    assert should_build() is True



# Generated at 2022-06-24 01:36:17.059862
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:36:18.650606
# Unit test for function build_dists
def test_build_dists():
    command = "echo $PWD"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-24 01:36:24.991152
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "python -m invoke build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["remove_dist"] = False
    build_dists()
    config["build_command"] = False
    build_dists()


# Generated at 2022-06-24 01:36:32.763621
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = False
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    config["build_command"] = "true"

    assert(should_remove_dist() == False)

    config["remove_dist"] = True
    assert(should_remove_dist() == True)

    config["remove_dist"] = "false"
    assert(should_remove_dist() == True)


# Generated at 2022-06-24 01:36:43.758736
# Unit test for function should_build
def test_should_build():
    # Test with upload_pypi and not upload_release
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "some command"
    assert should_build()
    # Test with upload_release and not upload_pypi
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "some command"
    assert should_build()
    # Test with both upload_release and upload_pypi
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "some command"
    assert should_build()
    # Test with both upload_release false and upload_pypi false

# Generated at 2022-06-24 01:36:48.618505
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # test config and build
    assert should_build()
    assert should_remove_dist()
    # test config and no build
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()
    assert not should_remove_dist()

# Generated at 2022-06-24 01:36:53.980055
# Unit test for function remove_dists
def test_remove_dists():
    from .io import BaseFS
    from .io import Directory
    from .io import File

    dir_name = "dist"
    fs = BaseFS()
    fs.create_tree(["dist"], Directory)
    remove_dists(dir_name)
    assert not fs.path_exists(dir_name)

# Generated at 2022-06-24 01:36:59.579321
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False
    config["remove_dist"] = True
    assert should_remove_dist() is False
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True


# Generated at 2022-06-24 01:37:02.361168
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "nothing"
    assert should_build()



# Generated at 2022-06-24 01:37:06.950723
# Unit test for function remove_dists
def test_remove_dists():
    command = "python3 setup.py sdist bdist_wheel"
    run(command)
    remove_dists("dist")

# Generated at 2022-06-24 01:37:15.588171
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test case no config section
    config_test = {}
    config.update(config_test)
    assert not should_remove_dist()
    # Test case with remove_dist set to false
    config_test = {"remove_dist": False}
    config.update(config_test)
    assert not should_remove_dist()
    # Test case with remove_dist set to true and build_command set to false
    config_test = {"remove_dist": True, "build_command": "false"}
    config.update(config_test)
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:18.556465
# Unit test for function build_dists
def test_build_dists():
    build_command = "echo test"
    config["build_command"] = build_command
    build_dists()

# Generated at 2022-06-24 01:37:24.316622
# Unit test for function remove_dists
def test_remove_dists():
    import tempfile
    build_dir = tempfile.mkdtemp()
    remove_dists(build_dir)
    with open(build_dir) as f:
        assert False, "The folder doesn't exist"



# Generated at 2022-06-24 01:37:25.200225
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-24 01:37:28.316941
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf test"
    assert remove_dists("test") == command
    assert remove_dists(
        "test") == command  # test if function is runing more then once

# Generated at 2022-06-24 01:37:34.307266
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "sdist",
        "remove_dist": True,
    }
    assert should_remove_dist(test_config)



# Generated at 2022-06-24 01:37:41.341689
# Unit test for function build_dists
def test_build_dists():
    """Test if function build_dists creates dists"""
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    if upload_pypi or upload_release:
        assert should_build()
        assert should_remove_dist()
        build_dists()
        assert config.dists_exist
        remove_dists(config.dist_directory)
        assert not config.dists_exist

# Generated at 2022-06-24 01:37:42.200149
# Unit test for function build_dists
def test_build_dists():
    raise NotImplementedError



# Generated at 2022-06-24 01:37:44.277129
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-24 01:37:45.282178
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/dists")

# Generated at 2022-06-24 01:37:46.546507
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")


# Generated at 2022-06-24 01:37:47.542193
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:37:50.223233
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-24 01:37:58.068057
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("build_command", "test_build")
    assert should_build() is True

    config.set("upload_to_pypi", False)
    config.set("build_command", "test_build")
    assert should_build() is False

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "test_build")
    assert should_build() is True

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "test_build")
    assert should_build() is False


# Generated at 2022-06-24 01:37:58.984702
# Unit test for function build_dists
def test_build_dists():
    assert not build_dists()

# Generated at 2022-06-24 01:38:00.102622
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-24 01:38:02.545812
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist bdist_wheel"
    build_dists()
    assert command == config.get("build_command")



# Generated at 2022-06-24 01:38:04.149771
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test_dir")

# Generated at 2022-06-24 01:38:12.949295
# Unit test for function should_build
def test_should_build():
    conf = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "false",
    }
    assert not should_build(conf)

    conf = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "false",
    }
    assert not should_build(conf)

    conf = {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "false",
    }
    assert not should_build(conf)

    conf = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "false",
    }
   

# Generated at 2022-06-24 01:38:13.720655
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-24 01:38:14.684548
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="foo")

# Generated at 2022-06-24 01:38:16.026221
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "echo \"build dists\""
    build_dists()



# Generated at 2022-06-24 01:38:23.271049
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    import os

    path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    build_command = "pipenv run python setup.py sdist bdist_wheel"
    config["build_command"] = build_command
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    build_dists()
    assert os.path.exists("dist")

# Generated at 2022-06-24 01:38:33.816844
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    assert should_build() is True

    config["upload_to_pypi"] = False
    assert should_build() is True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() is True

    config["build_command"] = "false"
    assert should_build() is False

    config["build_command"] = "true"
    assert should_build() is True

# Generated at 2022-06-24 01:38:35.646125
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist/*")

# Generated at 2022-06-24 01:38:41.247242
# Unit test for function build_dists
def test_build_dists():
    config["build_command"] = "true"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "false"
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True

# Generated at 2022-06-24 01:38:50.664761
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["remove_dist"] = "false"
    config["build_command"] = "false"
    assert should_build() is False
    config["upload_to_pypi"] = "true"
    config["remove_dist"] = "false"
    config["build_command"] = "false"
    assert should_build() is False
    config["upload_to_pypi"] = "true"
    config["remove_dist"] = "false"
    config["build_command"] = "echo testing"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["remove_dist"] = "false"
    config["build_command"] = "echo testing"
   

# Generated at 2022-06-24 01:38:51.761416
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-24 01:38:52.830016
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-24 01:38:54.522148
# Unit test for function remove_dists
def test_remove_dists():
    path = "test_path"
    assert remove_dists(path) == None
    assert remove_dists

# Generated at 2022-06-24 01:38:58.102262
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-24 01:39:02.612943
# Unit test for function should_build
def test_should_build():
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    if upload_pypi or upload_release:
        assert should_build() is True
    else:
        assert should_build() is False

# Generated at 2022-06-24 01:39:11.366484
# Unit test for function remove_dists
def test_remove_dists():
    from .file_utils import mkdtemp
    from .settings import reset
    from .settings import set_config

    reset()
    tmp_dir = mkdtemp()
    mock_config = {
        "directory": tmp_dir,
        "build_command": "touch test_file.whl",
        "remove_dist": True,
    }
    set_config(mock_config)
    build_dists()
    assert run("ls test_file.whl", hide=True).ok
    remove_dists(tmp_dir)
    assert not run("ls test_file.whl", hide=True).ok

# Generated at 2022-06-24 01:39:16.510644
# Unit test for function build_dists
def test_build_dists():
    import sys
    import subprocess
    subprocess.run(["python", "setup.py", "sdist", "bdist_wheel"])
    assert sys.argv[1] == "sdist"