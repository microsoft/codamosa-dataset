

# Generated at 2022-06-18 03:05:52.767456
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:53.630991
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:54.471765
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:05:59.320773
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:06:01.963833
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:06:03.127018
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:04.074788
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:04.998076
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:06.361244
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:06:08.061529
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:53.781559
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:09:54.424075
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:55.003351
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:04.707293
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = True
    assert should_remove_dist() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    config["upload_to_release"] = True
    assert should_remove_dist() == True
    config["upload_to_release"] = False
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:10:10.218065
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:10:11.138436
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:19.434015
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:10:26.087768
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True


# Generated at 2022-06-18 03:10:27.199164
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:34.174379
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "echo true"
    assert should_build() == True
