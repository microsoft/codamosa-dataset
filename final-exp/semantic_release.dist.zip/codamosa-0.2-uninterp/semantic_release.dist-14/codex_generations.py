

# Generated at 2022-06-18 03:05:41.709955
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:49.974242
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["upload_to_pypi"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello World'"
    assert should_build() == False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False

# Generated at 2022-06-18 03:05:59.826223
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:06:01.509487
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:09.851258
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert not should_build()

    config["upload_to_pypi"] = True

# Generated at 2022-06-18 03:06:11.010075
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:20.574020
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert not should_remove_dist()

    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_remove_dist()


# Generated at 2022-06-18 03:06:21.407359
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-18 03:06:27.701705
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:06:29.180800
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-18 03:08:26.746974
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_release"] = True
    assert should_build() == True


# Generated at 2022-06-18 03:08:27.808637
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:08:37.587332
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    assert should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = "echo"
    config["upload_to_release"] = True
    assert should_remove_dist()

    config["remove_dist"] = True
    config["build_command"] = "echo"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["remove_dist"] = False
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    assert not should_remove_dist()

    config["remove_dist"]

# Generated at 2022-06-18 03:08:38.691294
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:08:47.516770
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:08:54.821843
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello World'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:08:56.150120
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:08:57.082397
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:00.905262
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:09:10.024345
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist() is True

    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist() is False

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist() is False

    config["remove_dist"] = True

# Generated at 2022-06-18 03:13:04.197845
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_build() == False

# Generated at 2022-06-18 03:13:08.671724
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True


# Generated at 2022-06-18 03:13:09.493284
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:13:10.371472
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:11.224943
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:12.095448
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-18 03:13:14.100148
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:13:14.926983
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:13:15.671150
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:13:16.571508
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
