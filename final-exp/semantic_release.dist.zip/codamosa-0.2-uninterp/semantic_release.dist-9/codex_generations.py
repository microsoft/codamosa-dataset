

# Generated at 2022-06-18 03:05:37.417530
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-18 03:05:38.478823
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-18 03:05:39.280506
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:05:46.444025
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert should_remove_dist()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist()
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_remove_dist()
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"

# Generated at 2022-06-18 03:05:56.885143
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo build"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo build"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo build"
    assert should_build() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo build"
    assert should_build() is True


# Generated at 2022-06-18 03:06:06.529838
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "ls"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "ls"
    assert should_build() == True


# Generated at 2022-06-18 03:06:08.059522
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:08.905368
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:06:09.531966
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-18 03:06:10.732572
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:33.531058
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    assert should_remove_dist() == False
    config["build_command"] = "true"
    assert should_remove_dist() == True
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() == True
    config["upload_to_release"] = "true"
    assert should_remove_dist() == True
    config["upload_to_release"] = "false"
    assert should_remove_dist() == True
    config["upload_to_pypi"] = "false"
    assert should_remove_dist() == False
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["remove_dist"] = "false"
    assert should

# Generated at 2022-06-18 03:09:34.269683
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:35.121290
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:35.954329
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:36.777831
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:37.512798
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:46.342436
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'test'"
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "echo 'test'"
    assert should_build()
    config["upload_to_pypi"]

# Generated at 2022-06-18 03:09:47.106790
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:47.866007
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:48.508147
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-18 03:13:09.145355
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:10.334346
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:13:11.186757
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:12.095481
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:19.446973
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:13:20.127589
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:24.737812
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["build_command"] = "echo"
    assert should_build() is True
    config["upload_to_pypi"] = False
    assert should_build() is False
    config["upload_to_release"] = True
    assert should_build() is True



# Generated at 2022-06-18 03:13:25.988561
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-18 03:13:34.023254
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:13:34.975603
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True