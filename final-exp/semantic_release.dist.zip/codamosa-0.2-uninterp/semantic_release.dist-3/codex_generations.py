

# Generated at 2022-06-18 03:05:55.829295
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:56.837930
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:05.442506
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:06:09.192637
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    assert should_remove_dist() == True
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:10.022021
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:15.980916
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = True
    assert should_remove_dist() == False
    config["build_command"] = "true"
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    config["upload_to_release"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:19.054849
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:23.461852
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.update({"upload_to_pypi": True})
    assert should_build() == False
    config.update({"upload_to_release": True})
    assert should_build() == False
    config.update({"build_command": "echo"})
    assert should_build() == True
    config.update({"build_command": "false"})
    assert should_build() == False
    config.update({"build_command": "echo"})
    assert should_build() == True
    config.update({"upload_to_pypi": False})
    assert should_build() == True
    config.update({"upload_to_release": False})
    assert should_build() == False


# Generated at 2022-06-18 03:06:24.267190
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:25.016970
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:08:32.551200
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "echo 'Hello World'")
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "echo 'Hello World'")
    assert should_build()

    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "echo 'Hello World'")
    assert should_build()

    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)

# Generated at 2022-06-18 03:08:42.356122
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_dist() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() == False
    config["upload_to_release"] = True
    config["build_command"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:08:43.524605
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-18 03:08:44.086233
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-18 03:08:47.399856
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:08:54.744844
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True


# Generated at 2022-06-18 03:08:56.150462
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:08:57.082866
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:08:57.853434
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:08:58.615851
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:11:03.092501
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_build()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert not should_build()
    config["upload_to_pypi"] = True

# Generated at 2022-06-18 03:11:11.670250
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo 'Hello World'"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'Hello World'"
    assert should_build() == True
    config["remove_dist"] = True
    assert should_build() == True
    config["remove_dist"] = False
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:11:12.368065
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:11:21.989972
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:11:22.631621
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:11:23.613363
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:11:25.083366
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:11:25.823709
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:11:33.441545
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:11:34.173302
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:13:44.142384
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True


# Generated at 2022-06-18 03:13:45.161475
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:13:53.253534
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()