

# Generated at 2022-06-18 03:05:52.860270
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-18 03:06:00.792254
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'Hello'"
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:06:01.553288
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:06:02.824879
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:03.723351
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:04.997826
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True


# Generated at 2022-06-18 03:06:06.360140
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:06:15.751056
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "echo"
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:06:18.931193
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:19.734591
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:36.039636
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_build() == False

# Generated at 2022-06-18 03:10:36.839598
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:37.651114
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:43.854592
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:10:44.589841
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:51.410043
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:10:52.210876
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-18 03:10:53.170170
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:54.178520
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:56.109126
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
