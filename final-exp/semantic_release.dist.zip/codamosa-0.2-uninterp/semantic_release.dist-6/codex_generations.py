

# Generated at 2022-06-18 03:05:44.704662
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'Hello World'"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'Hello World'"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello World'"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello World'"
    assert not should_build()


# Generated at 2022-06-18 03:05:45.469273
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:05:51.858414
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'hello'"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'hello'"
    assert should_build() is True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() is False


# Generated at 2022-06-18 03:05:52.903251
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:05:53.795392
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-18 03:05:54.723725
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:05:55.784641
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-18 03:05:56.789837
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:05:58.960865
# Unit test for function should_build
def test_should_build():
    assert should_build() is True
    assert should_build() is False

# Generated at 2022-06-18 03:06:01.149576
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-18 03:09:37.444601
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() is True
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["remove_dist"] = "false"
    assert should_remove_dist() is False

# Generated at 2022-06-18 03:09:43.194838
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["upload_to_pypi"] = True
    assert should_build() == True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

    config["build_command"] = "echo 'hello'"
    assert should_build() == True

# Generated at 2022-06-18 03:09:43.986039
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:09:44.816029
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:09:51.681117
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = False
    assert not should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-18 03:09:52.661805
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:09:56.496048
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:09:58.612976
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:59.705294
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-18 03:10:00.580518
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:39.473740
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = False
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'hello'"
    assert should_build() == True

# Generated at 2022-06-18 03:13:40.378652
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:13:45.424225
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False
    config.set("remove_dist", True)
    config.set("build_command", False)
    assert should_remove_dist() is False
    config.set("build_command", "echo")

# Generated at 2022-06-18 03:13:46.961374
# Unit test for function should_build
def test_should_build():
    assert should_build() == True