

# Generated at 2022-06-18 03:05:39.725790
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("upload_to_pypi", True)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True
    config.set("upload_to_release", False)
    config.set("build_command", "echo 'test'")
    assert should_build() == True

# Generated at 2022-06-18 03:05:40.983321
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:05:41.781026
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:05:48.517095
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:05:49.347707
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:50.236613
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:56.650433
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = True
    assert should_remove_dist() == False
    config["build_command"] = "echo 'test'"
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    config["upload_to_release"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:08.238699
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False

# Generated at 2022-06-18 03:06:15.934214
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    assert should_remove_dist()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_remove_dist()
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert not should_remove_dist()
    config.set("build_command", "echo hello")
    assert not should_remove_dist()
    config.set("remove_dist", False)
    assert not should_remove_dist()

# Generated at 2022-06-18 03:06:24.836373
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:09:47.931925
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:09:48.984197
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:09:54.831984
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:10:00.397321
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == False
    config["build_command"] = "true"
    assert should_build() == True


# Generated at 2022-06-18 03:10:07.797044
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_dist() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist

# Generated at 2022-06-18 03:10:08.758047
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:09.710817
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:10.680855
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:19.558998
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:10:20.284603
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:13:44.938658
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:13:52.753190
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "echo 1"
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["build_command"] = "echo 1"
    config["remove_dist"] = False
    assert not should_remove_dist()

