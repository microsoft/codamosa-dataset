

# Generated at 2022-06-18 03:05:46.000169
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:05:47.313137
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:53.872250
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:05:54.857129
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:00.497230
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "true"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:06:09.556654
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:06:10.730918
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:06:11.882337
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:06:14.689007
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo 'Hello'"
    assert should_build() == True


# Generated at 2022-06-18 03:06:21.647896
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-18 03:10:03.513306
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'hello'"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:10:09.035374
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist()

    config["remove_dist"] = False

# Generated at 2022-06-18 03:10:09.974858
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:10.908457
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-18 03:10:19.277166
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:10:20.108483
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:27.193163
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_build() == False

# Generated at 2022-06-18 03:10:37.462250
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert not should_remove_dist()
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist()
    config["upload_to_pypi"] = "false"

# Generated at 2022-06-18 03:10:38.246451
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:44.143676
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
