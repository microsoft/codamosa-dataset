

# Generated at 2022-06-18 03:05:43.172485
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:05:47.072257
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["upload_to_pypi"] = True
    assert should_build() == False

    config["upload_to_release"] = True
    assert should_build() == False

    config["build_command"] = "echo 'hello'"
    assert should_build() == True



# Generated at 2022-06-18 03:05:48.001239
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:48.759089
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:05:49.569092
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:05:59.049143
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True


# Generated at 2022-06-18 03:06:06.529473
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "true"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:06:08.055688
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-18 03:06:08.688771
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-18 03:06:09.298861
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:39.412579
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:09:40.343570
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-18 03:09:41.762245
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:09:42.577855
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:45.374219
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:09:46.172868
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-18 03:09:48.738772
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "echo 'hello'"
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["build_command"] = "false"
    config["remove_dist"] = True
    assert should_remove_dist() is False
    config["build_command"] = "echo 'hello'"
    config["remove_dist"] = False
    assert should_remove_dist() is False

# Generated at 2022-06-18 03:09:55.083921
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'test'"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'test'"
    assert should_remove_dist()

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'test'"
    assert not should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_pypi"]

# Generated at 2022-06-18 03:09:56.634265
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:09:58.678825
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

