

# Generated at 2022-06-18 03:05:50.552497
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "true"
    assert should_remove_dist() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() == True
    config["upload_to_release"] = True
    config["build_command"] = False
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:05:58.652170
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build() == True


# Generated at 2022-06-18 03:06:07.266923
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:06:08.121904
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:08.745434
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:18.161284
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:06:19.116763
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:19.866182
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-18 03:06:20.736671
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:06:28.437534
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "true"
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "true"
    assert should_build() == True
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    assert should_build() == True
    config["build_command"] = "false"
    assert should_

# Generated at 2022-06-18 03:10:13.951959
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:14.759673
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:15.545386
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:10:20.048373
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = "true"
    assert should_build() == False
    config["upload_to_release"] = "true"
    assert should_build() == False
    config["build_command"] = "echo 'test'"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:10:25.878080
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:10:26.806862
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:10:28.241182
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:10:30.079225
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:10:39.763148
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("upload_to_pypi", True)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True
    config.set("upload_to_release", False)
    config.set("build_command", "echo 'test'")
    assert should_build() == False
    config.set("upload_to_pypi", True)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True
    config.set("upload_to_release", False)

# Generated at 2022-06-18 03:10:41.777800
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()