

# Generated at 2022-06-18 03:05:58.431133
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'hello'"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'hello'"
    assert should_build() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'hello'"
    assert should_build() is True


# Generated at 2022-06-18 03:06:00.398145
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:06:09.505053
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config["upload_to_pypi"] = "true"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build() is True
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "true"
    assert should_build() is True
    config["build_command"] = "false"
    config["upload_to_pypi"] = "true"
    assert should_build() is False
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should

# Generated at 2022-06-18 03:06:11.009513
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-18 03:06:12.161575
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:13.305473
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:20.424035
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True


# Generated at 2022-06-18 03:06:21.249260
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:06:26.831888
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["build_command"] = "echo 'test'"
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-18 03:06:27.410411
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:08:19.271878
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:08:21.219416
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist()

# Generated at 2022-06-18 03:08:21.854045
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:08:23.826793
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-18 03:08:24.716174
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:08:29.094062
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello World'"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'Hello World'"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'Hello World'"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'Hello World'"
    assert not should_build()


# Generated at 2022-06-18 03:08:38.736883
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["upload_to_release"] = True
    config["build_command"] = False
    assert not should_remove_dist()

# Generated at 2022-06-18 03:08:48.142242
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "echo 'test'")
    assert should_remove_dist() is True

    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "echo 'test'")
    assert should_remove_dist() is True

    config.set("remove_dist", True)
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "echo 'test'")
    assert should

# Generated at 2022-06-18 03:08:53.383704
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = True
    assert should_build() == False
    config["build_command"] = "echo"
    assert should_build() == True
    config["upload_to_pypi"] = False
    assert should_build() == False
    config["upload_to_release"] = True
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False


# Generated at 2022-06-18 03:08:54.625328
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:41.447803
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-18 03:10:42.300583
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:10:48.103429
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo 'build'"
    assert should_remove_dist()

    config["remove_dist"] = "false"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo 'build'"
    assert not should_remove_dist()

    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo 'build'"
    assert not should_remove_dist()

    config

# Generated at 2022-06-18 03:10:56.477818
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "true"
    assert should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert not should_remove_dist()
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist()
    config["upload_to_pypi"] = "false"

# Generated at 2022-06-18 03:10:57.308772
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-18 03:10:58.083409
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:10:58.717613
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:11:00.531991
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-18 03:11:01.519181
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-18 03:11:02.309685
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True