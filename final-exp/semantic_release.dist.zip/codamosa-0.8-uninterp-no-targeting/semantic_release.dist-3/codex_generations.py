

# Generated at 2022-06-21 20:34:52.054537
# Unit test for function build_dists
def test_build_dists():
    from invoke import MockContext

    config["build_command"] = "echo hello"
    context = MockContext()
    build_dists()

# Generated at 2022-06-21 20:34:52.542413
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-21 20:34:53.271182
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:34:58.898118
# Unit test for function should_build
def test_should_build():
    config_1 = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "whatever",
    }
    config_2 = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "whatever",
    }
    config_3 = {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "whatever",
    }
    config_4 = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "whatever",
    }

# Generated at 2022-06-21 20:34:59.898588
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-21 20:35:04.748697
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "echo 'build'"
    assert should_build()
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_pypi"] = False
    assert not should_build()


# Generated at 2022-06-21 20:35:05.614234
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")



# Generated at 2022-06-21 20:35:07.447499
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-21 20:35:08.093383
# Unit test for function build_dists
def test_build_dists():
    assert True

# Generated at 2022-06-21 20:35:09.823602
# Unit test for function remove_dists
def test_remove_dists():
    test_path = "dist"
    remove_dists(test_path)



# Generated at 2022-06-21 20:36:57.544164
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() and should_build()

# Generated at 2022-06-21 20:37:00.657080
# Unit test for function should_build
def test_should_build():
    should_build() == True
    command = config.get("build_command")
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    assert command != "false"
    assert upload_pypi is not None
    assert upload_release is not None


# Generated at 2022-06-21 20:37:02.029057
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


test_should_remove_dist()

# Generated at 2022-06-21 20:37:13.020023
# Unit test for function build_dists
def test_build_dists():
    import __main__
    setattr(__main__, 'config', dict(get=lambda x: "false"))
    assert should_build() == False
    setattr(__main__, 'config', dict(get=lambda x: "echo"))
    assert should_build() == False
    setattr(__main__, 'config', dict(get=lambda x: "echo"))
    assert should_build() == False
    setattr(__main__, 'config', dict(get=lambda x: "echo", upload_to_pypi="true"))
    assert should_build() == False
    setattr(__main__, 'config', dict(get=lambda x: "echo", upload_to_release="true"))
    assert should_build() == False

# Generated at 2022-06-21 20:37:13.953470
# Unit test for function build_dists
def test_build_dists():
    assert not build_dists()

# Generated at 2022-06-21 20:37:15.560926
# Unit test for function remove_dists
def test_remove_dists():
    # TODO: make remove dist as a task, to be able to mock run
    pass


# Generated at 2022-06-21 20:37:21.084921
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "false"
    assert not should_remove_dist()

    config["build_command"] = "ls"
    assert not should_remove_dist()

    config["upload_to_release"] = True
    assert should_remove_dist()

    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_remove_dist()

    config["upload_to_release"] = False
    config["upload_to_pypi"] = False
    assert not should_remove_dist()

# Generated at 2022-06-21 20:37:22.475575
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == bool(str(config.get('remove_dist')))

# Generated at 2022-06-21 20:37:34.465422
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_build() == True, "should return True even if upload_to_pypi and upload_to_release are set to false"

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build() == True, "should return True even if upload_to_pypi is set to True"

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build() == True, "should return True even if upload_to_release is set to True"

    config["upload_to_pypi"] = "true"

# Generated at 2022-06-21 20:37:40.098855
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.upload_to_pypi = True
    assert should_build()
    config.upload_to_pypi = False
    config.upload_to_release = True
    assert should_build()
    config.upload_to_release = False
    config.build_command = "build"
    assert should_build()

# Generated at 2022-06-21 20:41:23.857787
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./")

# Generated at 2022-06-21 20:41:28.120564
# Unit test for function build_dists
def test_build_dists():
    from .settings import SandboxConfig

    config = SandboxConfig()
    config.set_config_value("build_command", "python setup.py sdist bdist_wheel")
    config.set_config_value("upload_to_pypi", True)
    config.set_config_value("upload_to_release", True)

    assert should_build() == True
    assert should_remove_dist() == True
    build_dists()

# Generated at 2022-06-21 20:41:32.641203
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    assert should_remove_dist()
    remove_dists(path="dist")

# Generated at 2022-06-21 20:41:34.276941
# Unit test for function build_dists
def test_build_dists():
    from .settings import config
    config.set("build_command", "true")
    assert should_build()

# Generated at 2022-06-21 20:41:34.795381
# Unit test for function build_dists
def test_build_dists():
    assert should_build()

# Generated at 2022-06-21 20:41:35.607957
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:41:43.272058
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should return False if config is missing
    config["remove_dist"] = "false"
    assert should_remove_dist() == False

    # Should return False if build_command is missing
    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert should_remove_dist() == False

    # Should return False if build_command is present but not upload_to_pypi or upload_to_release
    config["build_command"] = "py1"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:41:53.429666
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "build_command"
    assert should_build() is True
    config["upload_to_release"] = "true"
    assert should_build() is True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_build() is False
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "build_command"

# Generated at 2022-06-21 20:41:53.915419
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:41:59.466255
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True