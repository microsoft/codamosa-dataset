

# Generated at 2022-06-21 20:34:39.029787
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:34:42.379384
# Unit test for function remove_dists
def test_remove_dists():
    import shutil, os

    path = os.path.join(os.getcwd(), "test")
    os.mkdir(path)
    remove_dists(path=path)
    assert not os.path.exists(path)



# Generated at 2022-06-21 20:34:44.422294
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() is True
    remove_dists("/tmp")
    remove_dists(".")

# Generated at 2022-06-21 20:34:47.883758
# Unit test for function remove_dists
def test_remove_dists():
    import os
    # Create the test_files directory here
    os.makedirs("test_files")
    remove_dists("test_files")
    assert not os.path.exists("test_files")

# Generated at 2022-06-21 20:34:48.453999
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:34:49.489999
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-21 20:34:50.988689
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-21 20:34:51.476387
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:34:57.908892
# Unit test for function should_build
def test_should_build():
    upload_to_pypi = False
    upload_to_release = False
    build_command = "false"
    config["upload_to_pypi"] = upload_to_pypi
    config["upload_to_release"] = upload_to_release
    config["build_command"] = build_command
    assert not should_build()
    upload_to_release = False
    build_command = "build"
    config["upload_to_pypi"] = upload_to_pypi
    config["upload_to_release"] = upload_to_release
    config["build_command"] = build_command
    assert should_build()
    upload_to_release = False
    upload_to_pypi = True
    build_command = "false"

# Generated at 2022-06-21 20:35:07.007694
# Unit test for function should_build
def test_should_build():
    expected = True
    config["build_command"] = "foo"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    actual = should_build()
    assert (actual == expected)

    expected = False
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    actual = should_build()
    assert (actual == expected)

    expected = False
    config["build_command"] = "foo"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    actual = should_build()
    assert (actual == expected)



# Generated at 2022-06-21 20:36:53.087615
# Unit test for function remove_dists
def test_remove_dists():
    run("python3 -m pytest tests/release/test_build.py -k test_remove_dists")

# Generated at 2022-06-21 20:36:54.354179
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("src")

# Generated at 2022-06-21 20:36:55.549600
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists()

# Generated at 2022-06-21 20:36:56.832431
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()


# Generated at 2022-06-21 20:36:57.648413
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-21 20:36:58.378481
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-21 20:36:59.104905
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-21 20:37:00.385020
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-21 20:37:02.029479
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except FileNotFoundError:
        logger.error("Cannot run build command")

# Generated at 2022-06-21 20:37:04.131763
# Unit test for function build_dists
def test_build_dists():
    command = "python setup.py sdist twine upload"
    assert config.get("build_command") == command
    build_dists()

# Generated at 2022-06-21 20:40:17.526046
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")



# Generated at 2022-06-21 20:40:21.939373
# Unit test for function build_dists
def test_build_dists():
    logger.error = MagicMock()
    logger.info = MagicMock()
    run = MagicMock()
    build_dists()
    run.assert_called_once_with(config["build_command"])
    logger.info.assert_called()

# Generated at 2022-06-21 20:40:25.141968
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set_values({"remove_dist": "false", "upload_to_pypi": "false",
                       "upload_to_release": "false", "build_command": "false"})
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:40:25.978759
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-21 20:40:26.889329
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-21 20:40:27.422290
# Unit test for function remove_dists
def test_remove_dists():
    pass

# Generated at 2022-06-21 20:40:29.586344
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("./dist")

# Generated at 2022-06-21 20:40:30.486288
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-21 20:40:35.274490
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
    config['build_command'] = None
    assert should_build() == False
    config["build_command"] = "echo 'hi'"
    assert should_build() == True
    config["upload_to_pypi"] = None
    assert should_build() == False
    config["upload_to_release"] = None
    assert should_build() == False

# Generated at 2022-06-21 20:40:36.920661
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

