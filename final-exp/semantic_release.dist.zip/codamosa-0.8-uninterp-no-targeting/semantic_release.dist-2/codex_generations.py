

# Generated at 2022-06-21 20:34:34.983615
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo hello"
    config["remove_dist"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo hello"
    config["remove_dist"] = False
    assert not should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = None
    config["remove_dist"] = True
    assert not should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True


# Generated at 2022-06-21 20:34:43.342888
# Unit test for function remove_dists
def test_remove_dists():
    from .contexts import mock_context
    from .files import get_repo_root
    from .upload import pypi_filepaths, release_filepaths

    assert should_remove_dist()
    assert not should_build()
    root = get_repo_root()
    with mock_context(config, "build_version", "0.0.0", "0.1.0"):
        remove_dists(pypi_filepaths["tar.gz"])
        remove_dists(release_filepaths["tar.gz"])

# Generated at 2022-06-21 20:34:46.933540
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "echo test"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist() is True

    config["build_command"] = "false"
    assert should_remove_dist() is False

    config["build_command"] = "echo test"
    config["upload_to_pypi"] = False
    assert should_remove_dist() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_remove_dist() is False



# Generated at 2022-06-21 20:34:47.650622
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:34:49.008435
# Unit test for function build_dists
def test_build_dists():
    """Build Distributions
    """
    build_dists()

# Generated at 2022-06-21 20:34:49.624454
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:34:50.484388
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')

# Generated at 2022-06-21 20:34:50.989935
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:34:55.765754
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.update({"upload_to_pypi": True})
    assert should_build() is False
    config.update({"build_command": "python setup.py sdist"})
    assert should_build() is True
    config.update({"upload_to_pypi": False, "upload_to_release": True})
    assert should_build() is True
    config.update({"build_command": "false"})
    assert should_build() is False

# Generated at 2022-06-21 20:34:56.948758
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path="dir")

# Generated at 2022-06-21 20:38:14.665041
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception as err:
        logger.error("Failed to run command")
        logger.error(err)
        raise

# Generated at 2022-06-21 20:38:15.557225
# Unit test for function build_dists
def test_build_dists():
    assert True


# Generated at 2022-06-21 20:38:17.072160
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    assert should_remove_dist()


# Generated at 2022-06-21 20:38:20.179810
# Unit test for function build_dists
def test_build_dists():
    logger.setLevel(logging.DEBUG)
    config["build_command"] = "touch test_build_dists.txt"
    build_dists()
    config["build_command"] = "rm test_build_dists.txt"
    build_dists()

# Generated at 2022-06-21 20:38:28.627536
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_remove_dist() is False
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() is True
    config["upload_to_release"] = "true"
    assert should_remove_dist() is True
    config["build_command"] = "false"
    assert should_remove_dist() is False
    config["build_command"] = "echo 'hello world'"
    assert should_remove_dist() is True

# Generated at 2022-06-21 20:38:31.829961
# Unit test for function should_build
def test_should_build():
    # pylint: disable=unused-argument
    assert should_build() is True
    # pylint: enable=unused-argument



# Generated at 2022-06-21 20:38:36.956854
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["build_command"] = "./setup.py sdist bdist_wheel"
    assert should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()
    config["remove_dist"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-21 20:38:38.388275
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    remove_dists("/tmp")
    assert True

# Generated at 2022-06-21 20:38:39.355419
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:38:40.744997
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True


# Generated at 2022-06-21 20:42:03.876786
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("build_command", "false")
    assert should_build() == False


# Generated at 2022-06-21 20:42:04.865943
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-21 20:42:11.198422
# Unit test for function should_build
def test_should_build():
    from .config import test_config
    from .config import test_config_no_command
    assert should_build() is True
    assert should_build(config=test_config) is True
    assert should_remove_dist() is True
    assert should_remove_dist(config=test_config) is True
    assert should_build(config=test_config_no_command) is False
    assert should_remove_dist(config=test_config_no_command) is False

# Generated at 2022-06-21 20:42:13.077833
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "true"
    assert should_build()



# Generated at 2022-06-21 20:42:15.075425
# Unit test for function remove_dists
def test_remove_dists():
    run("mkdir -p /tmp/test_remove_dists")
    remove_dists("/tmp/test_remove_dists")
    assert run("[ ! -e /tmp/test_remove_dists ]", hide=True).ok

# Generated at 2022-06-21 20:42:16.916072
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True
    assert should_remove_dist() == False
    build_dists()


# Generated at 2022-06-21 20:42:19.130654
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-21 20:42:20.304903
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:42:21.298894
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:42:24.163711
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    assert should_remove_dist()

    config.set("remove_dist", False)
    assert not should_remove_dist()

