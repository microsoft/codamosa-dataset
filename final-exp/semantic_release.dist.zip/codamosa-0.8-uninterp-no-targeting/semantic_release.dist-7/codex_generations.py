

# Generated at 2022-06-21 20:35:03.977437
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist()

# Generated at 2022-06-21 20:35:11.087171
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Should always remove dist when the remove_dist is set to true
    assert should_remove_dist() == True

    # Should be false if users do not want to remove dist
    config["remove_dist"] = False
    assert should_remove_dist() == False

    # Should be false if build command is not given
    config["remove_dist"] = True
    config["build_command"] = None
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:35:12.174946
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:35:21.804560
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build_command"
    config["remove_dist"] = "true"
    assert should_remove_dist() is True

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_remove_dist() is True

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_remove_dist() is True

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_remove_dist() is True

    config["build_command"] = "false"
    config["upload_to_pypi"] = "true"

# Generated at 2022-06-21 20:35:22.865281
# Unit test for function remove_dists
def test_remove_dists():
    path = '/tmp/test'
    remove_dists(path)

# Generated at 2022-06-21 20:35:24.884285
# Unit test for function remove_dists
def test_remove_dists():
    try:
        remove_dists("../dist")
    except:
        pass

# Generated at 2022-06-21 20:35:36.390176
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()

    config["upload_to_release"] = True
    config["remove_dist"] = True
    config["build_command"] = "echo"
    assert should_remove_dist()

    config["upload_to_pypi"] = "false"
    config["remove_dist"] = True
    config["build_command"] = "echo"
    assert not should_remove_dist()

    config["upload_to_release"] = "false"
    config["remove_dist"] = True
    config["build_command"] = "echo"
    assert not should_remove_dist()

    config["upload_to_release"] = "false"

# Generated at 2022-06-21 20:35:47.117440
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    config['build_command'] = 'false'
    config['upload_to_pypi'] = True
    assert should_remove_dist() is False
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    assert should_remove_dist() is False
    config['build_command'] = 'ls'
    assert should_remove_dist() is True
    config['remove_dist'] = False
    assert should_remove_dist() is False
    config['build_command'] = 'false'
    config['upload_to_release'] = False
    config['upload_to_pypi'] = False
    assert should_remove_dist() is False

# Generated at 2022-06-21 20:35:48.277304
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:35:48.859075
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:40:06.631146
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:40:08.174291
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:40:17.895521
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("build_command", "command")
    config.set("upload_to_pypi", "true")
    assert should_remove_dist()

    config.set("remove_dist", "true")
    config.set("build_command", "false")
    config.set("upload_to_pypi", "true")
    assert not should_remove_dist()

    config.set("remove_dist", "true")
    config.set("build_command", "command")
    config.set("upload_to_pypi", "false")
    assert not should_remove_dist()

    config.set("remove_dist", "true")
    config.set("build_command", "false")

# Generated at 2022-06-21 20:40:19.004736
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("dist")

# Generated at 2022-06-21 20:40:20.069002
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-21 20:40:26.224107
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "echo 123"
    assert(should_build() == True)
    config["build_command"] = False
    config["upload_to_pypi"] = True
    assert(should_build() == False)
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert(should_build() == False)
    config["upload_to_release"] = False


# Generated at 2022-06-21 20:40:27.197103
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:40:30.021677
# Unit test for function build_dists
def test_build_dists():
    # We can call build_dists, as it doesn't need a config entry
    build_dists()



# Generated at 2022-06-21 20:40:31.234075
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-21 20:40:33.044461
# Unit test for function build_dists
def test_build_dists():
    args = [{"build_command": "echo 'It works!'"}]
    for arg in args:
        config.update(arg)
        build_dists()