

# Generated at 2022-06-21 20:34:49.872706
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import set_defaults
    from .settings import set_env
    import os
    import tempfile
    from .logger import Logger
    from .settings import config
    from .settings import defaults
    from .settings import env
    from .settings import defaults_file
    from .settings import env_file

    # set defaults
    defaults_file = defaults_file()
    env_file = env_file()
    if defaults_file.startswith(os.path.sep):
        set_defaults(defaults_file)
        set_env(env_file)
    else:
        # The default defaults.json is the one in the package
        defaults_defaults = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'defaults.json')
        set_

# Generated at 2022-06-21 20:34:59.505504
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "true")
    # build_command = False
    config.set("build_command", "")
    assert should_build() == False

    # build_command = True
    config.set("build_command", "python setup.py sdist bdist_wheel")
    assert should_build() == True

    # upload_to_pypi = False
    config.set("upload_to_pypi", "")
    assert should_build() == False

    # upload_to_pypi = True; upload_to_release = True
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    assert should_build() == True

    # upload_to_pypi = False; upload_to_

# Generated at 2022-06-21 20:35:00.456708
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True


# Generated at 2022-06-21 20:35:03.763446
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    #The value must be true
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:35:15.744590
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    config.set("build_command", "echo test")
    config.set("upload_to_release", "true")
    assert should_remove_dist()
    config.set("remove_dist", "false")
    config.set("build_command", "false")
    config.set("upload_to_release", "true")
    assert not should_remove_dist()
    config.set("remove_dist", "true")
    config.set("build_command", "false")
    config.set("upload_to_release", "true")
    assert not should_remove_dist()
    config.set("remove_dist", "false")
    config.set("build_command", "echo test")
    config.set("upload_to_release", "true")
    assert not should

# Generated at 2022-06-21 20:35:20.366377
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    config['build_command'] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == True
    config['remove_dist'] = False
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:35:22.046988
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')
    assert run('ls | grep dist', hide=True).exited == 1
    # assert run('lsssss', hide=True).exited == 127

# Generated at 2022-06-21 20:35:23.712786
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-21 20:35:25.040903
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:35:26.621779
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    build_dists()
    assert should_remove_dist()

# Generated at 2022-06-21 20:38:43.745315
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:38:44.824066
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:38:45.523114
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:38:48.499584
# Unit test for function remove_dists
def test_remove_dists():
    import os
    from .settings import config

    with open('test.txt', 'w') as f:
        f.write('Hello, world!')

    test_file = 'test.txt'
    config['build_dir'] = os.path.dirname(os.path.realpath(__file__))
    remove_dists(config.get("build_dir"))

    assert not os.path.exists(test_file)

# Generated at 2022-06-21 20:38:55.550641
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    filename = 'test.txt'
    temp_file = os.path.join(tempdir, filename)
    with open(temp_file, 'w') as file:
        file.write('testing remove_dists')
    remove_dists(tempdir)
    assert not os.path.exists(tempdir)

# Generated at 2022-06-21 20:38:56.456987
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist/*")

# Generated at 2022-06-21 20:38:57.352154
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('dist')



# Generated at 2022-06-21 20:38:58.412192
# Unit test for function should_remove_dist
def test_should_remove_dist():
    actual = should_remove_dist()
    assert actual is False

# Generated at 2022-06-21 20:39:06.753698
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import pathlib
    import tempfile

    path = pathlib.Path(tempfile.gettempdir())
    os.chdir(path)
    os.mkdir("test_remove")
    os.mkdir("test_remove/dist")
    assert os.path.exists("test_remove/dist")
    remove_dists(path)
    assert os.path.exists("test_remove")
    assert not os.path.exists("test_remove/dist")

# Generated at 2022-06-21 20:39:10.873869
# Unit test for function should_build
def test_should_build():
    config_for_test = config
    config_for_test["upload_to_release"] = True
    config_for_test["upload_to_pypi"] = False
    config_for_test["build_command"] = "pytest -q"
    assert should_build()

