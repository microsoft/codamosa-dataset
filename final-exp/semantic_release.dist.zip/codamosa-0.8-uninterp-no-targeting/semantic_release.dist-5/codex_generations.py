

# Generated at 2022-06-21 20:34:51.475150
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "echo 'Building'"
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"

    assert should_remove_dist() == True

    config["upload_to_pypi"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:34:58.176922
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config['build_command'] = "something"
    assert should_build()
    config['build_command'] = "false"
    assert not should_build()
    config['upload_to_pypi'] = True
    assert should_build()
    config['upload_to_release'] = True
    assert should_build()
    config['upload_to_release'] = False
    assert should_build()
    config['upload_to_pypi'] = False
    assert not should_build()


# Generated at 2022-06-21 20:34:59.402559
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:35:00.358398
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is True

# Generated at 2022-06-21 20:35:02.028702
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-21 20:35:08.712443
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = False

# Generated at 2022-06-21 20:35:14.446324
# Unit test for function should_remove_dist
def test_should_remove_dist():
    from .settings import config_data
    from ..helpers import dict_to_object
    config = dict_to_object(config_data)
    assert not should_remove_dist()
    config.update({"remove_dist": True})
    assert not should_remove_dist()
    config.update({"build_command": "echo hello"})
    assert should_remove_dist()

# Generated at 2022-06-21 20:35:20.643595
# Unit test for function should_build
def test_should_build():
    cases = (
        ({"upload_to_release": False, "build_command": False}, False),
        ({"upload_to_release": False, "build_command": True}, False),
        ({"upload_to_release": True, "build_command": False}, False),
        ({"upload_to_release": True, "build_command": True}, True),
    )
    for config_data, result in cases:
        config.update(config_data)
        assert should_build() == result



# Generated at 2022-06-21 20:35:21.463138
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-21 20:35:22.262985
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("params")

# Generated at 2022-06-21 20:39:08.853332
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"].set("me")
    assert should_build()
    config["upload_to_pypi"].set("false")
    config["upload_to_release"].set("me")
    assert should_build()
    config["upload_to_release"].set("false")
    config["build_command"].set("me")
    assert should_build()



# Generated at 2022-06-21 20:39:11.548758
# Unit test for function build_dists
def test_build_dists():
    test_command = 'mkdir test_build'
    test_should_build = False
    build_dists()
    test_should_build = should_build()
    assert test_should_build


# Generated at 2022-06-21 20:39:12.480925
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-21 20:39:13.426433
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False

# Generated at 2022-06-21 20:39:16.304415
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf remove_dists"
    run_command = remove_dists("remove_dists")
    assert run_command.command == command


if __name__ == "__main__":
    logging.basicConfig(level="DEBUG")
    test_remove_dists()

# Generated at 2022-06-21 20:39:18.782183
# Unit test for function build_dists
def test_build_dists():
    from .settings import Settings

    settings = Settings(config_path="tests/data/settings.yml")
    settings.set_project_configuration()
    build_dists()

# Generated at 2022-06-21 20:39:21.677967
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = None
    assert should_remove_dist() == False

    config["remove_dist"] = True
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:39:22.857797
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:39:24.458958
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "true")
    assert should_build()



# Generated at 2022-06-21 20:39:25.618215
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("build")