

# Generated at 2022-06-21 20:34:36.194044
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")


if __name__ == "__main__":
    test_remove_dists()

# Generated at 2022-06-21 20:34:39.873918
# Unit test for function remove_dists
def test_remove_dists():

    from .settings import config
    from .settings import path

    config.set("remove_dist", True)
    config.set("build_command", "false")

    remove_dists(path)

# Generated at 2022-06-21 20:34:50.404373
# Unit test for function build_dists
def test_build_dists():
    import os
    import shutil
    from unittest.mock import patch
    import tempfile
    import logging

    log_format = "%(levelname)s %(message)s"
    logging.basicConfig(format=log_format, level=logging.DEBUG)
    build_dir = tempfile.mkdtemp()
    os.environ["BUILD_DIST_DIR"] = build_dir
    config["build_command"] = f"ls -lR {os.getcwd()} > {build_dir}/out.txt"
    with patch('invoke.run') as fake_run:
        build_dists()
    fake_run.assert_called_once()
    try:
        shutil.rmtree(build_dir)
    except Exception:
        pass



# Generated at 2022-06-21 20:34:56.232210
# Unit test for function should_build
def test_should_build():
    # When build is true and pypi is true
    assert should_build()

    # When build is true and pypi is false
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    assert should_build()

    # When build is false
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    assert not should_build()

    # When build is None
    config['build_command'] = False
    assert not should_build()

    config['build_command'] = None
    assert not should_build()



# Generated at 2022-06-21 20:35:06.154146
# Unit test for function should_build
def test_should_build():
    from .settings import config
    from . import build
    import os

    # use the default config
    # build.should_build should not raise an exception
    with build.settings.ctx_config(config):
        assert build.should_build() is True

    # if we override the config
    # set the values to all false
    custom_config = {
        "upload_to_pypi": "false",
        "upload_to_release": "false",
        "build_command": "false",
    }
    with open(".invoke.yaml", "w") as f:
        f.write(custom_config)

    assert build.should_build() is False

    # clean the file system
    os.remove(".invoke.yaml")

# Generated at 2022-06-21 20:35:07.769455
# Unit test for function build_dists
def test_build_dists():
    pass



# Generated at 2022-06-21 20:35:18.289773
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    assert should_build(False, True) is False
    assert should_build(build_command=False, upload_pypi=True) is False
    assert should_build(build_command=False, upload_release=True) is False
    assert should_build(build_command=False) is False
    assert should_build(build_command="false") is False
    assert should_build(build_command=None) is False
    assert should_build(build_command=True) is True
    assert should_build(build_command="true") is True
    assert should_build(build_command=None, upload_pypi=True) is True
    assert should_build(build_command=None, upload_release=True) is True

# Generated at 2022-06-21 20:35:19.472551
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    

# Generated at 2022-06-21 20:35:25.440998
# Unit test for function remove_dists
def test_remove_dists():
    test_path = "build"
    assert should_remove_dist()
    assert not run(f"ls -d {test_path}", hide=True, warn=True).ok
    run(f"touch ./{test_path}/file")
    assert run(f"ls -d {test_path}", hide=True).ok
    remove_dists(f"./{test_path}")
    assert not run(f"ls -d {test_path}", hide=True, warn=True).ok

# Generated at 2022-06-21 20:35:26.041024
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:37:12.222550
# Unit test for function build_dists
def test_build_dists():
    class MockRun:
        def __init__(self, command):
            self.command = command
            self.log = ""

        def __call__(self, command):
            self.command = command

        def __repr__(self):
            return f'command: {self.command}'

    run_mock = MockRun("")
    config["build_command"] = "my_command"
    build_dists(run=run_mock)
    assert run_mock.command == "my_command"


# Generated at 2022-06-21 20:37:13.909003
# Unit test for function remove_dists
def test_remove_dists():
    """Unit test for function remove_dists
    """
    assert should_remove_dist()
    assert should_build()

# Generated at 2022-06-21 20:37:21.414784
# Unit test for function should_build
def test_should_build():
    # Given
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True

    # Then
    assert should_build() == True

    # Given
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False

    # Then
    assert should_build() == True

    # Given
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True

    # Then
    assert should_build() == True

    # Given
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

    # Then
    assert should_build() == True

    # Given
    config["upload_to_pypi"] = True
    config["upload_to_release"]

# Generated at 2022-06-21 20:37:22.014263
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:37:23.861638
# Unit test for function build_dists
def test_build_dists():
    config.update({"build_command": "echo 'Building distribution'"})
    build_dists()



# Generated at 2022-06-21 20:37:33.735271
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"build_command": "false", "remove_dist": "false"})
    assert should_remove_dist() is False

    config.update({"build_command": "true", "remove_dist": "false"})
    assert should_remove_dist() is False

    config.update({"build_command": "true", "remove_dist": "true"})
    assert should_remove_dist() is True

    # Should also work for string "true"
    config.update({"build_command": "true", "remove_dist": "true"})
    assert should_remove_dist() is True



# Generated at 2022-06-21 20:37:35.147545
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert config.get("build_command")

# Generated at 2022-06-21 20:37:45.364671
# Unit test for function build_dists
def test_build_dists():
    import pytest
    from .settings import mock_configuration

    # Testing when upload_to_pypi and upload_to_release are both True
    mock_configuration({"upload_to_pypi": True,
                        "upload_to_release": True,
                        "build_command": "echo 'this is build command'"})
    from .distributions import build_dists
    from .distributions import should_build
    from .distributions import should_remove_dist

    build_dists()
    assert should_build() is True
    assert should_remove_dist() is False

    # Testing when upload_to_pypi and upload_to_release are both False

# Generated at 2022-06-21 20:37:45.865329
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:37:46.968053
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-21 20:39:33.448246
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["build_command"] = "true"
    assert should_build()

    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = None
    config["upload_to_release"] = None
    config["build_command"] = None
    assert not should_build()



# Generated at 2022-06-21 20:39:34.060070
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:39:38.610561
# Unit test for function should_build
def test_should_build():
    config.settings["build_command"] = "true"
    config.settings["upload_to_pypi"] = True
    assert should_build()

    config.settings["upload_to_pypi"] = False
    config.settings["upload_to_release"] = True
    assert should_build()

# Generated at 2022-06-21 20:39:39.168060
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:39:45.042582
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "false")
    assert not should_build()
    config.set("build_command", "true")
    assert should_build()
    config.set("build_command", "false")
    assert not should_build()
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "true")
    config.set("build_command", "true")
    assert should_build()
    config.set("build_command", "false")
    assert not should_build()
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")


# Generated at 2022-06-21 20:39:54.719931
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.config.set("build_dists", True)
    assert should_remove_dist() is True  # should remove dists
    config.config.set("build_dists", False)
    assert should_remove_dist() is False  # shouldn't remove dists
    config.config.set("remove_dist", False)
    assert should_remove_dist() is False  # shouldn't remove dists
    config.config.set("build_dists", True)
    config.config.set("remove_dist", True)
    assert should_remove_dist() is True  # should remove dists



# Generated at 2022-06-21 20:39:57.971310
# Unit test for function should_build
def test_should_build():
    logger.info("Testing should_build function")
    build_val = should_build()
    assert build_val == True, "Should should_build is True, got {build_val}"

# Generated at 2022-06-21 20:39:59.500937
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(path=str(config.get("dist_dir")))

# Generated at 2022-06-21 20:40:00.746457
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:40:01.960715
# Unit test for function build_dists
def test_build_dists():
    build_dists()