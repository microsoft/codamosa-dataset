

# Generated at 2022-06-21 20:35:16.898319
# Unit test for function should_build
def test_should_build():
    assert not should_build()  # should not build if nothing is required
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "build command"
    assert should_build()
    config["build_command"] = False
    assert not should_build()



# Generated at 2022-06-21 20:35:17.839578
# Unit test for function build_dists
def test_build_dists():
    assert should_build() is True



# Generated at 2022-06-21 20:35:18.497516
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:35:22.589102
# Unit test for function should_build
def test_should_build():
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    assert bool(build_command and (upload_pypi or upload_release)) is True

# Generated at 2022-06-21 20:35:24.096473
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-21 20:35:34.645369
# Unit test for function should_build
def test_should_build():
    ret = should_build()
    assert ret is False

    config["build_command"] = "echo"
    ret = should_build()
    assert ret is False

    config["upload_to_pypi"] = "t"
    ret = should_build()
    assert ret is True

    config["upload_to_pypi"] = "false"
    ret = should_build()
    assert ret is False

    config["upload_to_release"] = "t"
    ret = should_build()
    assert ret is True

    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    ret = should_build()
    assert ret is False



# Generated at 2022-06-21 20:35:36.100857
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp/MyNewTest") == None


# Generated at 2022-06-21 20:35:45.619273
# Unit test for function should_build
def test_should_build():
    """Test should_build function
    """
    # upload_pypi is true but no build command
    config.upload_to_pypi = True
    config.build_command = "false"
    assert not should_build()

    config.upload_to_pypi = False
    config.upload_to_release = True
    assert should_build()

    config.upload_to_pypi = True
    config.upload_to_release = True
    assert should_build()

    config.upload_to_pypi = False
    config.upload_to_release = False
    assert not should_build()



# Generated at 2022-06-21 20:35:49.010380
# Unit test for function should_build
def test_should_build():
    from .settings import config
    config.update({
        "upload_to_pypi": True,
        "build_command": "python setup.py sdist bdist_wheel"
    })
    assert should_build() is True

# Generated at 2022-06-21 20:35:49.599265
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:38:04.581099
# Unit test for function should_remove_dist
def test_should_remove_dist():
    pass



# Generated at 2022-06-21 20:38:10.971636
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-21 20:38:18.305164
# Unit test for function should_build
def test_should_build():
    assert not should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo build"
    assert not should_build()

    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = False
    assert not should_build()

# Generated at 2022-06-21 20:38:19.383873
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:38:19.862126
# Unit test for function remove_dists
def test_remove_dists():
    assert True

# Generated at 2022-06-21 20:38:21.805723
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.load_config('.checkitinrc')
    assert should_remove_dist() is True

# Generated at 2022-06-21 20:38:29.007627
# Unit test for function build_dists
def test_build_dists():
    import os
    import shutil
    from tempfile import mkdtemp
    from wltp.utils import set_config
    from wltp.config.settings import config
    from wltp.config.defaults import defaults

    set_config(defaults)

    folder = mkdtemp()
    command = "true"
    config["build_command"] = command

    build_dists()
    assert os.path.isdir(folder)
    shutil.rmtree(folder)



# Generated at 2022-06-21 20:38:37.738071
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    assert should_remove_dist() == True
    config["remove_dist"] = "false"
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["build_command"] = "true"
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() == True
    config["upload_to_release"] = "true"
    assert should_remove_dist() == True
    config["upload_to_release"] = "false"
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:38:39.499268
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/") is None
    assert remove_dists("tests") is None

# Generated at 2022-06-21 20:38:40.664335
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True


# Generated at 2022-06-21 20:41:03.688828
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "false"
    config["build_command"] = "false"
    assert should_build() == False
    assert should_remove_dist() == False

    config["build_command"] = "python setup.py sdist"
    assert should_build() == True
    assert should_remove_dist() == False

    config["upload_to_pypi"] = "true"
    config["remove_dist"] = "false"
    assert should_build() == True
    assert should_remove_dist() == False

    config["remove_dist"] = "true"
    assert should_build() == True
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:41:04.525728
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-21 20:41:05.353812
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-21 20:41:07.784426
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist({}) is True
    assert should_remove_dist({"remove_dist": False}) is False
    assert should_remove_dist({"remove_dist": True, "build_command": False}) is False

# Generated at 2022-06-21 20:41:08.630935
# Unit test for function build_dists
def test_build_dists():
    pass


# Generated at 2022-06-21 20:41:09.404404
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-21 20:41:10.706295
# Unit test for function remove_dists
def test_remove_dists():
    path = "foo"
    command = f"rm -rf {path}"
    assert remove_dists(path) == command

# Generated at 2022-06-21 20:41:11.585875
# Unit test for function build_dists
def test_build_dists():
    # Nothing raised
    build_dists()


# Generated at 2022-06-21 20:41:12.376878
# Unit test for function build_dists
def test_build_dists():
    cmd = "echo "
    build_dists(cmd)

# Generated at 2022-06-21 20:41:12.752859
# Unit test for function build_dists
def test_build_dists():
    build_dists()