

# Generated at 2022-06-21 20:34:58.830788
# Unit test for function build_dists
def test_build_dists():
    import pytest
    from .settings import TEST_SETTINGS

    # Set of possible values for config['build_command'] in a
    # test.yaml file.
    commands = ["false", "true", ""]

    # No command set
    config.temp_override(None, TEST_SETTINGS)
    assert not should_build()

    # Empty command set
    config.temp_override("build_command", "", TEST_SETTINGS)
    assert not should_build()

    # False command set
    config.temp_override("build_command", "false", TEST_SETTINGS)
    assert not should_build()

    # True command set
    config.temp_override("build_command", "true", TEST_SETTINGS)
    assert should_build()

    # True command and upload_to_

# Generated at 2022-06-21 20:35:06.327489
# Unit test for function should_build
def test_should_build():
    # Should build if upload_to_release == true or upload_to_pypi = true
    assert should_build()
    config["upload_to_release"] = False
    assert should_build()
    config["upload_to_release"] = True
    config["upload_to_pypi"] = False
    assert should_build()

    # Should not build if build_command == false
    config["build_command"] = "false"
    assert not should_build()
    config["build_command"] = "python setup.py build"
    assert should_build()



# Generated at 2022-06-21 20:35:14.550818
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist() is True
    config["remove_dist"] = False
    assert should_remove_dist() is False
    config["remove_dist"] = ""
    assert should_remove_dist() is False
    config["remove_dist"] = "False"
    assert should_remove_dist() is False
    config["remove_dist"] = "false"
    assert should_remove_dist() is False
    config["remove_dist"] = "dist/*"
    assert should_remove_dist() is True

# Generated at 2022-06-21 20:35:23.330931
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = 'fake_command'
    assert should_remove_dist() is True

    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = 'fake_command'
    assert should_remove_dist() is False

    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = 'fake_command'
    assert should_remove_dist() is True

    config["remove_dist"] = True

# Generated at 2022-06-21 20:35:35.343830
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "build"
    config["remove_dist"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "build"
    config["remove_dist"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "build"
    config["remove_dist"] = True
    assert should_remove_dist()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config

# Generated at 2022-06-21 20:35:36.266085
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")



# Generated at 2022-06-21 20:35:47.689800
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Remove dist build
    config.update({"remove_dist": True, "build_command": "true", "upload_to_pypi": True})
    assert should_remove_dist() == True

    # Don't Remove dist build
    config.update({"remove_dist": False, "build_command": "true", "upload_to_pypi": True})
    assert should_remove_dist() == False

    # Don't Remove dist build
    config.update({"remove_dist": True, "build_command": False, "upload_to_pypi": True})
    assert should_remove_dist() == False

    # Don't Remove dist build
    config.update({"remove_dist": True, "build_command": False, "upload_to_pypi": False})
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:35:49.601456
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf dist"
    remove_dists(path="dist")



# Generated at 2022-06-21 20:35:54.433304
# Unit test for function should_build
def test_should_build():
    config.update({"build_command": "sdist"})
    assert should_build() is False

    config.update({"build_command": "sdist", "upload_to_pypi": True})
    assert should_build() is True

    config.update({"build_command": "sdist", "upload_to_release": True})
    assert should_build() is True

    config.update({"build_command": "false"})
    assert should_build() is False



# Generated at 2022-06-21 20:35:59.571128
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.read("setup.cfg")
    logger.debug("Running test_should_remove_dist")
    assert should_remove_dist() == False
    config.set("build_sphinx", "remove_dist", "True")
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:39:50.660007
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(tmp_dir)
    assert os.path.exists(tmp_dir)
    remove_dists(tmp_dir)
    assert not os.path.exists(tmp_dir)

# Generated at 2022-06-21 20:39:51.269119
# Unit test for function should_remove_dist
def test_should_remove_dist():
    return should_build()

# Generated at 2022-06-21 20:39:52.863372
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("**")

# Generated at 2022-06-21 20:39:53.979200
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-21 20:39:55.281442
# Unit test for function build_dists
def test_build_dists():
    from . import settings
    settings.config["build_command"] = "echo 01"
    build_dists()

# Generated at 2022-06-21 20:40:00.795802
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "false"
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["build_command"] = "echo 'hello'"
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:40:02.585115
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-21 20:40:03.700281
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/") is None


# Generated at 2022-06-21 20:40:05.806328
# Unit test for function build_dists
def test_build_dists():
    run('touch todo')
    assert(build_dists())
    run('rm todo')

# Generated at 2022-06-21 20:40:06.892237
# Unit test for function build_dists
def test_build_dists():
    build_dists()

