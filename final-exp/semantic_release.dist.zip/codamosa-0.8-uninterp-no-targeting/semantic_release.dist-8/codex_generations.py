

# Generated at 2022-06-21 20:34:41.947590
# Unit test for function build_dists
def test_build_dists():
    # Test that a build command is run
    command = "command"
    config.settings["build_command"] = command
    config.settings["upload_to_pypi"] = True
    config.settings["upload_to_release"] = True

    build_dists()

    global run
    run.assert_called_with(command)


# Generated at 2022-06-21 20:34:43.034717
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("test_dirs") == None

# Generated at 2022-06-21 20:34:44.150555
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-21 20:34:45.005470
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf {path}"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-21 20:34:46.245974
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:34:52.686558
# Unit test for function remove_dists
def test_remove_dists():
    dir_test = "dir_test"
    command = f"mkdir {dir_test}"
    logger.debug(f"Running {command}")
    run(command)
    remove_dists(dir_test)
    command = f"test -e {dir_test}"
    logger.debug(f"Running {command}")
    result = run(command)
    command = f"rmdir {dir_test}"
    logger.debug(f"Running {command}")
    run(command)
    assert result.failed

# Generated at 2022-06-21 20:34:53.700712
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:35:03.288542
# Unit test for function build_dists
def test_build_dists():
    config.set_config({"build_command": "false"})
    assert not should_build()

    config.set_config({"build_command": "python setup.py sdist bdist_wheel"})
    assert should_build()

    config.set_config({"upload_to_pypi": 0})
    assert not should_build()

    config.set_config({"upload_to_release": 0})
    assert not should_build()

    config.set_config({"upload_to_release": 1})
    assert should_build()

    config.set_config({"upload_to_pypi": 1})
    assert should_build()



# Generated at 2022-06-21 20:35:04.025771
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:35:09.168286
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "false"
    assert should_remove_dist()


# Generated at 2022-06-21 20:38:43.821441
# Unit test for function remove_dists
def test_remove_dists():
    test_path = "test_remove_dists"
    command = "mkdir test_remove_dists"
    run(command)
    remove_dists(test_path)
    command = "test -d test_remove_dists"
    try:
        run(command)
        assert False, "Should have raised CalledProcessError"
    except Exception as err:
        assert type(err) == CalledProcessError, "Should have raised CalledProcessError"

# Generated at 2022-06-21 20:38:47.360980
# Unit test for function remove_dists
def test_remove_dists():
    from pathlib import Path
    path_to_create = Path("/tmp/unit_test")
    path_to_create.mkdir(parents=True, exist_ok=True)
    remove_dists(path_to_create)
    try:
        assert not path_to_create.is_dir()
    finally:
        path_to_create.rmdir()


# Generated at 2022-06-21 20:38:50.023960
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-21 20:38:51.115952
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True



# Generated at 2022-06-21 20:38:52.511906
# Unit test for function remove_dists
def test_remove_dists():
    path = "test_dist"
    remove_dists(path)

# Generated at 2022-06-21 20:38:53.630659
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:38:55.822433
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("/tmp/test_remove_dists") == None

# Generated at 2022-06-21 20:38:59.206921
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()
    config["build_command"] = True
    assert should_build()
    config["build_command"] = False
    assert should_build()



# Generated at 2022-06-21 20:39:05.366640
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

    test_config = config.copy()
    test_config["upload_to_pypi"] = True
    test_config["upload_to_release"] = True
    test_config["build_command"] = "build_command"

    res = should_build()
    assert res is True

# Generated at 2022-06-21 20:39:15.024220
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # set config
    config["remove_dist"] = False
    # call function under test
    actual = should_remove_dist()
    # assert results
    assert actual is False

    # set config
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    # call function under test
    actual = should_remove_dist()
    # assert results
    assert actual is True

    # set config
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    # call function under test
    actual = should_remove_dist()
    # assert results
    assert actual is True

    # set config
    config["remove_dist"] = True