

# Generated at 2022-06-21 20:34:52.788933
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:34:54.978762
# Unit test for function build_dists
def test_build_dists():
    config = {
        "build_command": "touch build.txt"
    }
    assert should_build()
    build_dists()
    assert open("build.txt").read() == ""


# Generated at 2022-06-21 20:34:55.577957
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:34:58.367870
# Unit test for function build_dists
def test_build_dists():
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    build_dists() # TODO: Mock response

# Generated at 2022-06-21 20:35:02.956506
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    config["remove_dist"] = ""
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = ""
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:35:04.026243
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-21 20:35:05.101446
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:35:06.254846
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-21 20:35:07.769508
# Unit test for function build_dists
def test_build_dists():
    build_dists()


# Generated at 2022-06-21 20:35:18.698075
# Unit test for function should_build
def test_should_build():
    print("TEST:", should_build.__name__)
    # No upload specified
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert not should_build()

    # No build command specified
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "false")
    assert not should_build()

    # Build command specified, but no upload
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    config.set("build_command", "echo \"Hello\"")
    assert not should_build()

    # Everything good

# Generated at 2022-06-21 20:39:20.533232
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {"remove_dist": True, "build_command": True, "upload_to_pypi":True}
    assert should_remove_dist() == True
    config = {"remove_dist": True, "build_command": True, "upload_to_release":True}
    assert should_remove_dist() == True
    config = {"remove_dist": True, "build_command": False, "upload_to_release":True}
    assert should_remove_dist() == False
    config = {"remove_dist": True, "build_command": True, "upload_to_release":False}
    assert should_remove_dist() == False
    config = {"remove_dist": False, "build_command": True, "upload_to_release":True}
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:39:25.214515
# Unit test for function build_dists
def test_build_dists():
    assert not should_remove_dist()
    assert not should_build()
    config.set("build_command", "echo 'hello'")
    config.set("upload_to_pypi", True)
    config.set("remove_dist", True)
    assert should_build()
    assert should_remove_dist()

# Generated at 2022-06-21 20:39:26.757380
# Unit test for function build_dists
def test_build_dists():
    assert should_build() == True


# Generated at 2022-06-21 20:39:28.761234
# Unit test for function remove_dists
def test_remove_dists():
    assert should_build() == True
    assert should_remove_dist() == True
    remove_dists("dist")

# Generated at 2022-06-21 20:39:38.387541
# Unit test for function remove_dists
def test_remove_dists():
    import os
    import tempfile
    from pathlib import Path
    from shutil import rmtree
    from .settings import config
    from .utils import write_yaml

    project_name = "testproject"
    tmpdir = tempfile.mkdtemp()
    test_path = Path(tmpdir) / project_name
    write_yaml(config, test_path / "pypiceagle.yaml")
    test_path.mkdir()
    assert os.path.exists(str(test_path))
    remove_dists(str(test_path))
    assert not os.path.exists(str(test_path))
    rmtree(tmpdir)



# Generated at 2022-06-21 20:39:39.291478
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists('test')

# Generated at 2022-06-21 20:39:40.144909
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-21 20:39:41.509175
# Unit test for function remove_dists
def test_remove_dists():
     command = f"rm -rf {path}"
     logger.debug(f"Running {command}")
     run(command)

# Generated at 2022-06-21 20:39:44.938885
# Unit test for function build_dists
def test_build_dists():
    run.return_value = "test_value"
    assert should_build()
    build_dists()
    run.assert_called_once_with("test_value")


# Generated at 2022-06-21 20:39:46.348681
# Unit test for function should_build
def test_should_build():
    assert should_build() == True
