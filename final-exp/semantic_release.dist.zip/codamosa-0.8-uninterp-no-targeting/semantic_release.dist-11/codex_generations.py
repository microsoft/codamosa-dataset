

# Generated at 2022-06-21 20:34:58.460993
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:34:59.603891
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")



# Generated at 2022-06-21 20:35:00.551725
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-21 20:35:02.237401
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp")

# Generated at 2022-06-21 20:35:06.779257
# Unit test for function should_build
def test_should_build():
    config['build_command'] = 'build'
    config['upload_to_pypi'] = 'yes'
    assert should_build()

    config['build_command'] = False
    assert not should_build()

    config['upload_to_pypi'] = False
    assert not should_build()

    config['upload_to_release'] = 'release'
    assert should_build()



# Generated at 2022-06-21 20:35:09.601649
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config = {"build_command": "some_build_command"}
    result = should_remove_dist()
    assert result is False

# Generated at 2022-06-21 20:35:18.983740
# Unit test for function build_dists
def test_build_dists():
    import os
    import shutil

    test_string = "testing123"
    test_path = "test-build-dists"

    try:
        def test_function():
            if os.path.exists(test_path):
                print(f"{test_path} already exists, removing.")
                shutil.rmtree(test_path)
            os.mkdir(test_path)
            command = f"echo {test_string}"
            build_dists()
        assert not test_function()  == test_string
    except AssertionError:
        pass
    finally:
        if os.path.exists(test_path):
            shutil.rmtree(test_path)

# Generated at 2022-06-21 20:35:19.587481
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-21 20:35:25.665873
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    assert should_remove_dist() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["remove_dist"] = False
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() == False
    config["remove_dist"] = True
    config["upload_to_pypi"] = "true"
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:35:30.834168
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("build_command", "false")
    assert not should_build()

    config.set("build_command", "python setup.py sdist bdist_wheel")
    assert should_build()

# Generated at 2022-06-21 20:37:40.428284
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "ls -la"
    config["remove_dist"] = True
    assert should_remove_dist()
    config["build_command"] = False
    config["remove_dist"] = True
    assert not should_remove_dist()
    config["build_command"] = "ls -la"
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["build_command"] = False
    config["remove_dist"] = False
    assert not should_remove_dist()

# Generated at 2022-06-21 20:37:49.583583
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["build_command"] = True
    assert should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = True
    assert should_remove_dist()
    config["remove_dist"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = True
    assert not should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = True

# Generated at 2022-06-21 20:37:50.388806
# Unit test for function remove_dists
def test_remove_dists():
    return True

# Generated at 2022-06-21 20:37:51.766027
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except:
        raise AssertionError("build_dists function not working")

# Generated at 2022-06-21 20:37:52.769187
# Unit test for function remove_dists
def test_remove_dists():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:37:53.733156
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:37:55.050963
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    # No assertion


# Generated at 2022-06-21 20:38:04.623038
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("upload_to_pypi", True)
    assert should_build() == True
    config.set("build_command", "")
    assert should_build() == False
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True
    config.set("upload_to_release", False)
    config.set("build_command", "echo")
    assert should_build() == True
    config.set("build_command", "false")
    assert should_build() == False



# Generated at 2022-06-21 20:38:05.709385
# Unit test for function should_build
def test_should_build():
    assert should_build() is False

# Generated at 2022-06-21 20:38:10.824697
# Unit test for function should_build
def test_should_build():
    assert True == should_build()
    assert False == should_build(False, False, False)
    assert False == should_build(True, False, False)
    assert True == should_build(False, False, True)
    assert True == should_build(False, True, True)

# Generated at 2022-06-21 20:42:29.835820
# Unit test for function build_dists
def test_build_dists():
    command = "python3 setup.py sdist && python3 setup.py bdist_wheel"
    logger.info(f"Running {command}")
    run(command)

# Generated at 2022-06-21 20:42:31.466424
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "echo works"
    assert should_build()


# Generated at 2022-06-21 20:42:32.220866
# Unit test for function should_build
def test_should_build():
    assert should_build() is True



# Generated at 2022-06-21 20:42:37.253074
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    config["build_command"] = "build"
    assert should_build() == True
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = "build"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_build() == False
    config["upload_to_release"] = "true"
    assert should_build() == True
    config["upload_to_release"] = "false"
    config["upload_to_pypi"] = "true"
    assert should_build() == True


# Generated at 2022-06-21 20:42:38.259378
# Unit test for function remove_dists
def test_remove_dists():
  remove_dists("dist/")

# Generated at 2022-06-21 20:42:39.952807
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("/tmp/tmp-build-dist")



# Generated at 2022-06-21 20:42:50.180974
# Unit test for function should_build
def test_should_build():
    # Without a build command
    config.set("build_command", "")
    assert not should_build()

    # With build command and false value for upload_to_pypi and upload_to_release
    config.set("build_command", "true")
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    assert not should_build()

    # With build command and true value for upload_to_pypi
    config.set("upload_to_pypi", "true")
    assert should_build()

    # With build command and true value for upload_to_release
    config.set("upload_to_pypi", "false")
    assert should_build()

