

# Generated at 2022-06-21 20:34:46.744175
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists == "rm -rf"

# Generated at 2022-06-21 20:34:49.008685
# Unit test for function remove_dists
def test_remove_dists():
    command = f"remove_dists('/tmp')"
    logger.debug(f"Running {command}")
    run(command)

# Generated at 2022-06-21 20:34:49.998480
# Unit test for function should_build
def test_should_build():
    return


# Generated at 2022-06-21 20:34:50.525785
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:34:51.324823
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-21 20:34:57.650934
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

    config["build_command"] = "command"
    assert should_build() == False

    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = "true"
    assert should_build() == True

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build() == True

    config["upload_to_release"] = "false"
    config["upload_to_pypi"] = "true"
    assert should_build() == True

    config["upload_to_release"] = "true"
    config["build_command"] = "false"
    assert should_build() == False

# Generated at 2022-06-21 20:34:58.274325
# Unit test for function build_dists
def test_build_dists():
    pass

# Generated at 2022-06-21 20:35:00.173000
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "false"
    assert should_build() is False



# Generated at 2022-06-21 20:35:04.628487
# Unit test for function remove_dists
def test_remove_dists():
    import pathlib
    import tempfile
    path = pathlib.Path(tempfile.mkdtemp())
    path.mkdir(exist_ok=True)
    assert path.exists()
    remove_dists(str(path))
    assert not path.exists()

# Generated at 2022-06-21 20:35:12.069680
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    assert should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist()
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_remove_dist()

# Generated at 2022-06-21 20:38:52.281739
# Unit test for function remove_dists
def test_remove_dists():
    pass



# Generated at 2022-06-21 20:38:53.872297
# Unit test for function remove_dists
def test_remove_dists():
    assert(remove_dists("/tmp/abc.deb"))

# Generated at 2022-06-21 20:38:55.642614
# Unit test for function remove_dists
def test_remove_dists():
    import os

    import pytest

    pass # TODO

# Generated at 2022-06-21 20:39:00.614461
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.reload_config(
        {
            "upload_to_release": True,
            "upload_to_pypi": False,
            "build_command": "xxx",
            "remove_dist": True
        }
    )
    assert should_remove_dist() is True

    config.reload_config(
        {
            "upload_to_release": False,
            "upload_to_pypi": True,
            "build_command": "xxx",
            "remove_dist": False
        }
    )
    assert should_remove_dist() is False



# Generated at 2022-06-21 20:39:01.575182
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-21 20:39:13.249528
# Unit test for function should_build
def test_should_build():
    # When all three fields are set, should_build returns true
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "true")
    config.set("build_command", "true")
    assert should_build()

    # When only one field is set, should_build returns false
    config.set("upload_to_pypi", "")
    config.set("upload_to_release", "")
    config.set("build_command", "true")
    assert should_build() is False

    # When only one field is set to false, should_build returns false
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    config.set("build_command", "true")
    assert should

# Generated at 2022-06-21 20:39:16.912361
# Unit test for function should_build
def test_should_build():
    assert should_build() == False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True


# Generated at 2022-06-21 20:39:22.504439
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "test_command")
    config.set("remove_dist", True)
    assert should_remove_dist() is True
    config.set("remove_dist", False)
    assert should_remove_dist() is False
    config.set("build_command", "false")
    config.set("remove_dist", True)



# Generated at 2022-06-21 20:39:23.789603
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:39:25.680359
# Unit test for function remove_dists
def test_remove_dists():
    path = "~/ok"
    command = f"rm -rf {path}"
    assert remove_dists(path) == run(command)