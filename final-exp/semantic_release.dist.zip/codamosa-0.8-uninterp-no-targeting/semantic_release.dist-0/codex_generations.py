

# Generated at 2022-06-21 20:35:09.115258
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", "true")
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")
    config.set("remove_dist", "false")

    assert should_remove_dist() == False


# Generated at 2022-06-21 20:35:13.063599
# Unit test for function remove_dists
def test_remove_dists():
    path = "dist/"
    # Test param is None
    remove_dists(None)
    # Test param is empty
    remove_dists("")
    # Test param is a not empty string
    remove_dists(path)

# Generated at 2022-06-21 20:35:21.195727
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test should remove dist
    config._config["upload_to_pypi"] = True
    config._config["upload_to_release"] = True
    config._config["build_command"] = "python setup.py sdist"
    config._config["remove_dist"] = True
    assert should_remove_dist()
    # Test should't remove dist
    config._config["upload_to_pypi"] = True
    config._config["upload_to_release"] = True
    config._config["build_command"] = "python setup.py sdist"
    config._config["remove_dist"] = False
    assert not should_remove_dist()



# Generated at 2022-06-21 20:35:24.638211
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["build_command"] = "bdist"
    assert should_remove_dist() == True
    config["remove_dist"] = False
    assert should_remove_dist() == False
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["remove_dist"] = True
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:35:27.653369
# Unit test for function build_dists
def test_build_dists():
    build_command = config.get("build_command")
    assert build_dists() == run(f"{build_command}")

# Generated at 2022-06-21 20:35:38.773343
# Unit test for function should_build
def test_should_build():
    # test case 1 should be true
    config["build_command"] = "["
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build()

    # test case 2 should be false
    config["build_command"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert not should_build()

    # test case 3 should be false
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert not should_build()

    # test case 4 should be false
    config["build_command"] = "false"
    config["upload_to_pypi"] = False

# Generated at 2022-06-21 20:35:40.729496
# Unit test for function remove_dists
def test_remove_dists():
    command = "rm -rf build"
    assert remove_dists(command) == None

# Generated at 2022-06-21 20:35:45.790433
# Unit test for function build_dists
def test_build_dists():
    # noinspection PyUnresolvedReferences
    from .settings import Settings
    settings = Settings(upload_to_pypi=True)
    assert should_build() is True
    # noinspection PyUnresolvedReferences
    from .settings import config
    config.update(settings)
    build_dists()

# Generated at 2022-06-21 20:35:54.232475
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Check when command is false
    config["remove_dist"] = False
    config["build_command"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() == False

    # Check when remove_dist is false and build_command is true
    config["build_command"] = "echo"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() == False

    # Check when all flags are true
    config["remove_dist"] = True
    config["build_command"] = "echo"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:36:06.188771
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = "true"
    config["upload_to_release"] = "true"
    assert should_remove_dist()

    config["remove_dist"] = "false"
    assert not should_remove_dist()

    config["remove_dist"] = ""
    assert not should_remove_dist()

    config["upload_to_pypi"] = ""
    assert not should_remove_dist()

    config["build_command"] = "false"
    assert not should_remove_dist()

    del config["remove_dist"]
    assert not should_remove_dist()

    del config["upload_to_pypi"]
    assert not should_remove_

# Generated at 2022-06-21 20:38:17.070738
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-21 20:38:20.140381
# Unit test for function should_build
def test_should_build():
    c = config.copy()
    c["upload_to_pypi"] = True
    c["upload_to_release"] = True
    c["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build()


# Generated at 2022-06-21 20:38:23.009924
# Unit test for function build_dists
def test_build_dists():
    try:
        build_dists()
    except Exception as e:
        assert False, f"Failed to build dists with {e}"

# Generated at 2022-06-21 20:38:24.393642
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:38:26.469546
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-21 20:38:29.141541
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:38:29.774539
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:38:33.690354
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['build_command'] = True
    config['remove_dist'] = True
    assert should_remove_dist() == True

    config['build_command'] = False
    config['remove_dist'] = True
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:38:39.786923
# Unit test for function should_build
def test_should_build():
    assert not should_build(), 'Should not build without a command'
    config["build_command"] = "echo"
    assert not should_build(), 'Should not build without uploads'
    config["upload_to_pypi"] = True
    assert should_build(), 'Should build with uploads'
    del config["upload_to_pypi"]
    config["upload_to_release"] = True
    assert should_build(), 'Should build with uploads'



# Generated at 2022-06-21 20:38:41.472755
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": True, "upload_to_pypi": True})
    assert should_remove_dist()


# Generated at 2022-06-21 20:40:51.152819
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("path") is None

# Generated at 2022-06-21 20:41:00.879884
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo build"
    assert should_build() is True
    config["build_command"] = "false"
    assert should_build() is False
    config["build_command"] = "echo build"
    config["upload_to_pypi"] = False
    assert should_build() is True
    config["upload_to_release"] = False
    assert should_build() is False
    del config["upload_to_release"]
    del config["upload_to_pypi"]
    assert should_build() is False
    del config["build_command"]
    assert should_build() is False


# Generated at 2022-06-21 20:41:02.346286
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:41:04.019310
# Unit test for function remove_dists
def test_remove_dists():
    run("python3 -m pytest -vv ./tests/test_building.py::test_build_dists")

# Generated at 2022-06-21 20:41:06.110319
# Unit test for function remove_dists
def test_remove_dists():
    from .tasks import remove_dists
    remove_dists(None)
    # Test for remove_dists()


# Test for function should_remove_dist()

# Generated at 2022-06-21 20:41:08.213020
# Unit test for function remove_dists
def test_remove_dists():
    command = f"rm -rf {'/Users/raghuramramki/Desktop/test_remove_dists'}"
    print(f"Running {command}")
    run(command)

# Generated at 2022-06-21 20:41:09.052819
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-21 20:41:10.339469
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": "True"})
    assert should_remove_dist() is True



# Generated at 2022-06-21 20:41:14.944268
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "command"
    assert should_remove_dist()
    config["remove_dist"] = False
    assert not should_remove_dist()
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert not should_remove_dist()
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert not should_remove_dist()
    config["build_command"] = "false"
    assert not should_remove_dist()



# Generated at 2022-06-21 20:41:16.811111
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("path")