

# Generated at 2022-06-21 20:34:59.455235
# Unit test for function remove_dists
def test_remove_dists():
    run("rm -rf ./invoke_test_build_directory")
    run("mkdir ./invoke_test_build_directory")
    remove_dists("./invoke_test_build_directory")
    run("rm -rf ./invoke_test_build_directory")

# Generated at 2022-06-21 20:35:06.699137
# Unit test for function should_build
def test_should_build():
    config_true = {
        "build_command": "true",
        "upload_to_pypi": True,
        "upload_to_release": False,
    }
    config_false = {
        "build_command": "false",
        "upload_to_pypi": False,
        "upload_to_release": False,
    }
    assert should_build() == False
    with config.push_values(config_true):
        assert should_build()
    with config.push_values(config_false):
        assert not should_build()


# Generated at 2022-06-21 20:35:08.039579
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-21 20:35:09.770084
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-21 20:35:10.923166
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists(".")

# Generated at 2022-06-21 20:35:12.438385
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True



# Generated at 2022-06-21 20:35:13.543784
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("tmp")

# Generated at 2022-06-21 20:35:21.841735
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.set("upload_to_pypi", True)
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build()
    config.set("build_command", "make dist")
    assert should_build()
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert not should_build()
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    assert should_build()


# Generated at 2022-06-21 20:35:22.897144
# Unit test for function build_dists
def test_build_dists():
    """
    Test build dists
    """
    build_dists()

# Generated at 2022-06-21 20:35:25.713133
# Unit test for function remove_dists
def test_remove_dists():
    command = f"mkdir test"
    run(command)
    command = f"rm -r test"
    run(command)

# Generated at 2022-06-21 20:39:20.710999
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:39:21.597947
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-21 20:39:24.598426
# Unit test for function build_dists
def test_build_dists():
    assert should_build()
    assert should_remove_dist()
    logger.info(f"Testing build_dists")
    build_dists()

# Generated at 2022-06-21 20:39:25.771156
# Unit test for function remove_dists
def test_remove_dists():
    assert remove_dists("dist") == None

# Generated at 2022-06-21 20:39:29.691937
# Unit test for function build_dists
def test_build_dists():
    """Verify that build_dists() run a command
    """
    try:
        config.build_command = "touch foo.txt"
        assert not should_build(), "Should not build here"
    finally:
        config.build_command = ""

# Generated at 2022-06-21 20:39:40.345215
# Unit test for function should_build
def test_should_build():
    # fmt: off
    assert should_build() == False
    config["upload_to_pypi"] = "true"
    assert should_build() == True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    assert should_build() == True
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    assert should_build() == True
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    assert should_build() == False
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_build() == True

# Generated at 2022-06-21 20:39:40.898936
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:39:42.433667
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Tests should_remove_dist function
    """
    assert should_remove_dist()

# Generated at 2022-06-21 20:39:46.174381
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_remove_dist is True



# Generated at 2022-06-21 20:39:48.357385
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == should_build()
