

# Generated at 2022-06-21 20:34:34.812418
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "true"
    assert bool(should_remove_dist())

    config["remove_dist"] = "false"
    assert bool(should_remove_dist())
    config["upload_to_pypi"] = "false"
    assert bool(should_remove_dist())

# Generated at 2022-06-21 20:34:46.154678
# Unit test for function build_dists
def test_build_dists():
    from . import dist
    import pytest

    dist.config["build_command"] = "pytest"
    dist.config["upload_to_pypi"] = True
    dist.config["upload_to_release"] = False

    with pytest.raises(SystemExit):
        dist.build_dists()
    dist.remove_dists("./build")
    dist.remove_dists("./dist")

    dist.config["build_command"] = "pytest"
    dist.config["upload_to_pypi"] = True
    dist.config["upload_to_release"] = True

    with pytest.raises(SystemExit):
        dist.build_dists()
    dist.remove_dists("./build")
    dist.remove_dists("./dist")

    dist.config

# Generated at 2022-06-21 20:34:49.745693
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "./build.sh"
    config["remove_dist"] = True
    assert should_build()



# Generated at 2022-06-21 20:34:50.328470
# Unit test for function build_dists
def test_build_dists():
    assert should_build()


# Generated at 2022-06-21 20:34:51.135412
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:34:57.148309
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False

    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    assert should_remove_dist() == False
    config["upload_to_release"] = True
    assert should_remove_dist() == True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True

    config["upload_to_release"] = False
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    assert should_remove_dist() == False


# Generated at 2022-06-21 20:34:58.373419
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("test")

# Generated at 2022-06-21 20:34:59.504582
# Unit test for function remove_dists
def test_remove_dists():
    remove_dists("dist")

# Generated at 2022-06-21 20:35:00.457281
# Unit test for function build_dists
def test_build_dists():
    build_dists()



# Generated at 2022-06-21 20:35:05.213528
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = "test command"
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-21 20:38:26.178838
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:38:28.068795
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:38:39.452866
# Unit test for function should_remove_dist
def test_should_remove_dist():

    assert not should_remove_dist()

    config.update({"remove_dist": "true", "build_command": "true",
                   "upload_to_pypi": "false", "upload_to_release": "false"})
    assert not should_remove_dist()

    config.update({"remove_dist": "true", "build_command": "false",
                   "upload_to_pypi": "false", "upload_to_release": "false"})
    assert not should_remove_dist()

    config.update({"remove_dist": "true", "build_command": "false",
                   "upload_to_pypi": "true", "upload_to_release": "false"})
    assert not should_remove_dist()


# Generated at 2022-06-21 20:38:44.021959
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "should_remove_dist()"
    assert should_build() == True, "should_build()"
    assert should_remove_dist() == True, "should_remove_dist()"
    assert should_build() == True, "should_build()"
    assert should_remove_dist() == True, "should_remove_dist()"

# Generated at 2022-06-21 20:38:53.872676
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo 'This is a test'"
    assert not should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "echo 'This is a test'"
    assert should_build()

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "echo 'This is a test'"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "echo 'This is a test'"
    assert should_build

# Generated at 2022-06-21 20:38:55.327199
# Unit test for function build_dists
def test_build_dists():
    build_dists()

# Generated at 2022-06-21 20:38:56.247110
# Unit test for function build_dists
def test_build_dists():
    build_dists()
    assert True

# Generated at 2022-06-21 20:39:00.918963
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({})
    assert not should_remove_dist()
    config.update({"remove_dist": "true"})
    assert not should_remove_dist()
    config.update({"build_command": "build-command"})
    assert should_remove_dist()
    config.update({"upload_to_pypi": "false"})
    assert not should_remove_dist()
    config.update({"upload_to_release": "true"})
    assert should_remove_dist()
    config.update({"upload_to_release": "false"})
    assert not should_remove_dist()

# Generated at 2022-06-21 20:39:07.940100
# Unit test for function build_dists
def test_build_dists():
    try:
        import invoke
    except ImportError:
        logger.warning("invocate not installed. Test skipped!")
        return
    try:
        build_dists()
    except invoke.exceptions.UnexpectedExit as ue:
        logger.info(f"Command returned non-zero status: {ue.message}")
    else:
        logger.error("Command was expected to return non-zero status")

# Generated at 2022-06-21 20:39:10.770125
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = True
    assert should_remove_dist()