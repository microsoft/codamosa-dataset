

# Generated at 2022-06-26 01:04:19.416505
# Unit test for function should_build
def test_should_build():
    # Test case 0
    var_0 = should_build();
    assert(var_0)

# Generated at 2022-06-26 01:04:22.342268
# Unit test for function should_build
def test_should_build():
    var_1 = config['upload_to_pypi'] = False
    var_2 = config['upload_to_release'] = False
    var_3 = config['build_command'] = "echo"
    var_4 = should_build()


# Generated at 2022-06-26 01:04:23.499414
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Assert
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:04:25.402182
# Unit test for function should_build
def test_should_build():
    # Should return True when upload_to_pypi or upload_to_release is True
    assert should_build()


# Generated at 2022-06-26 01:04:26.021116
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()


# Generated at 2022-06-26 01:04:29.624896
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "True"
    config["upload_to_pypi"] = "True"
    config["upload_to_release"] = "True"
    config["build_command"] = "python setup.py"
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:04:34.720140
# Unit test for function should_build
def test_should_build():
    # No config should return False
    config_1 = config
    assert should_build() is False
    config_1["upload_to_pypi"] = True
    config_1["upload_to_release"] = True
    config_1["build_command"] = "make dist"
    # set config to be true
    assert should_build() is True
    config_1["build_command"] = "false"
    # build_command is not truthy
    assert should_build() is False



# Generated at 2022-06-26 01:04:35.470808
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:04:36.301933
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-26 01:04:37.266156
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()


# Generated at 2022-06-26 01:08:28.502346
# Unit test for function should_build
def test_should_build():
    assert (True == should_build())

# Generated at 2022-06-26 01:08:38.065590
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "echo"
    assert should_build() == False

    config["upload_to_pypi"]

# Generated at 2022-06-26 01:08:39.558707
# Unit test for function should_build
def test_should_build():
    if should_build():
        assert True
    else:
        assert False


# Generated at 2022-06-26 01:08:41.209769
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:08:50.127303
# Unit test for function should_build
def test_should_build():
    # 1. Build should be false if all are false
    config.update(
        {
            "upload_to_pypi": False,
            "upload_to_release": False,
            "build_command": False,
            "remove_dist": False,
        }
    )
    assert should_build() == False

    # 2. Build should be true if only upload_to_release is true
    config.update(
        {
            "upload_to_pypi": False,
            "upload_to_release": True,
            "build_command": "echo 'build'",
            "remove_dist": False,
        }
    )
    assert should_build() == True

    # 3. Build should be true if only upload_to_pypi is true

# Generated at 2022-06-26 01:08:50.831332
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:08:52.027259
# Unit test for function should_build
def test_should_build():
    run("prctl --unaligned=silent")
    assert should_build() == False


# Generated at 2022-06-26 01:08:54.065623
# Unit test for function should_build
def test_should_build():
    """
        Function should_build should return False because config is empty
    """
    assert should_build() == False
    # assert should_build() == True



# Generated at 2022-06-26 01:08:54.866571
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()


# Generated at 2022-06-26 01:08:55.857890
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1 == True
