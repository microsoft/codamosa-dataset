

# Generated at 2022-06-26 01:04:21.137185
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Arrange
    var_0 = False
    var_0 = not var_0
    if var_0: raise NameError('Unexpected value')
    # Act
    ret = should_remove_dist()
    # Assert
    assert ret == var_0



# Generated at 2022-06-26 01:04:22.342865
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:04:26.508764
# Unit test for function should_build
def test_should_build():
    for i in range(2):
        if i == 0:
            config.update({"upload_to_pypi": "false", "upload_to_release": "false", "build_command": "false"})
            assert should_build() == False
        elif i == 1:
            config.update({"upload_to_pypi": "false", "upload_to_release": "true", "build_command": "true"})
            assert should_build() == True
        else:
            break


# Generated at 2022-06-26 01:04:27.618553
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_case_0()
    assert should_remove_dist()

# Generated at 2022-06-26 01:04:29.193749
# Unit test for function should_build
def test_should_build():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 01:04:30.588029
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert (var_0 == False)


# Generated at 2022-06-26 01:04:37.492331
# Unit test for function should_build
def test_should_build():
    build_command = "fake_command --help"
    config["build_command"] = build_command
    assert should_build()

    config["upload_to_release"] = False
    assert not should_build()

    config["upload_to_release"] = True
    assert should_build()

    config["upload_to_release"] = False
    config["upload_to_pypi"] = True
    assert should_build()

    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()



# Generated at 2022-06-26 01:04:45.045874
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py bdist_wheel --universal"
    assert should_build()

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py bdist_wheel --universal"
    assert should_build()


# Generated at 2022-06-26 01:04:46.021867
# Unit test for function should_build
def test_should_build():
    assert False == should_build()

# Generated at 2022-06-26 01:04:47.233288
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1 == True


# Generated at 2022-06-26 01:08:51.903060
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:08:53.156671
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:09:02.277448
# Unit test for function should_build
def test_should_build():
    """Test to see if should_build returns correct value for various upload_pypi/upload_release configurations"""
    case_0 = config.get("upload_to_pypi") and config.get("upload_to_release")
    config["upload_to_pypi"] = case_0
    config["upload_to_release"] = case_0
    assert should_build()

    case_1 = config.get("upload_to_pypi") and (not config.get("upload_to_release"))
    config["upload_to_pypi"] = case_1
    config["upload_to_release"] = case_1
    assert not should_build()

    case_2 = (not config.get("upload_to_pypi")) and config.get("upload_to_release")

# Generated at 2022-06-26 01:09:03.816585
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_1 = config.get("remove_dist")
    assert bool(var_1) == test_case_0()

# Generated at 2022-06-26 01:09:05.856734
# Unit test for function should_remove_dist
def test_should_remove_dist():
    actual_0 = should_remove_dist()
    expected_0 = False
    assert actual_0 == expected_0

test_case_0()

# Generated at 2022-06-26 01:09:10.973591
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Variable initialization
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "test"

    test_case_0()
    # Teardown
    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"

# Generated at 2022-06-26 01:09:16.875213
# Unit test for function should_remove_dist
def test_should_remove_dist():
    for path in [None, "", False, "False", "true"]:
        config.set("remove_dist", path)
        for value in [False, True]:
            config.set("upload_to_release", value)
            for value_1 in [False, True]:
                config.set("upload_to_pypi", value_1)
                for value_2 in [False, True]:
                    config.set("build_command", value_2)
                    if not value_2:
                        assert not should_remove_dist()
                        continue
                    expected = value or value_1
                    assert should_remove_dist() == expected
    # TODO: Loop through every combination of config values
    assert True

# Generated at 2022-06-26 01:09:17.697770
# Unit test for function should_build
def test_should_build():
    assert should_build() is None

# Generated at 2022-06-26 01:09:19.420091
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1



# Generated at 2022-06-26 01:09:22.520378
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_1 = config.get("upload_to_pypi")
    config.update({"upload_to_pypi": False})
    var_2 = should_remove_dist()
    config.update({"upload_to_pypi": True})
    var_3 = should_remove_dist()
    print(var_1, var_2, var_3)
    assert var_1 == var_3 and var_2 == False