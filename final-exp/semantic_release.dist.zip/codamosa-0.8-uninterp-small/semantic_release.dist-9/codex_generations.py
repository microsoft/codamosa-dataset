

# Generated at 2022-06-26 01:04:30.550212
# Unit test for function should_build
def test_should_build():
    var_3 = should_build()
    assert var_3 == True # "Expected function should_build to return True, instead got: " + str(var_3)


# Generated at 2022-06-26 01:04:38.620178
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "")
    assert should_build() == False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "false")
    assert should_build() == False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    config.set("build_command", "test_cmd")
    assert should_build() == True
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)

# Generated at 2022-06-26 01:04:39.533861
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-26 01:04:40.436482
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-26 01:04:49.513903
# Unit test for function should_build
def test_should_build():
    # Remove dists, no upload
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "false"
    assert not should_build()

    # Remove dists, upload
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = True # False string is True

    # Remove dists, no build
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "false"

    assert should_build()



# Generated at 2022-06-26 01:04:57.217848
# Unit test for function should_build
def test_should_build():
    from .settings import config
    # should return True since we have a build_command and upload_to_pypi
    # and upload_to_release
    config["build_command"] = "python setup.py sdist"
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    assert should_build()

    # expect False since build_command is False
    config["build_command"] = False
    assert not should_build()

    # expect False since build_command is "false"
    config["build_command"] = "false"
    assert not should_build()

    # expect True since we have a build_command and upload_to_release
    # and upload_to_pypi and remove_dist
    config["build_command"] = "python setup.py sdist"


# Generated at 2022-06-26 01:05:02.521498
# Unit test for function should_build
def test_should_build():
    config_0 = {"upload_to_pypi": True,
                "upload_to_release": True,
                "build_command": "./setup.py build"}
    assert should_build(config_0)
    config_1 = {"upload_to_pypi": True,
                "upload_to_release": False,
                "build_command": "./setup.py build"}
    assert should_build(config_1)
    config_2 = {"upload_to_pypi": False,
                "upload_to_release": True,
                "build_command": "./setup.py build"}
    assert should_build(config_2)

# Generated at 2022-06-26 01:05:03.303357
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()



# Generated at 2022-06-26 01:05:04.754255
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True, \
        "Error in function should_remove_dist"


# Generated at 2022-06-26 01:05:05.942010
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() is False


if __name__ == "__main__":
    test_should_remove_dist()

# Generated at 2022-06-26 01:07:16.312083
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:07:17.152006
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:07:18.321259
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1 == True

# Generated at 2022-06-26 01:07:19.378480
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0


# Generated at 2022-06-26 01:07:20.117966
# Unit test for function should_build
def test_should_build():
    # Case 0:
    test_case_0()

# Generated at 2022-06-26 01:07:21.507201
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:07:26.831057
# Unit test for function should_build
def test_should_build():
    assert should_build() is False
    config.set('build_command', 'test')
    assert should_build() is True
    config.set('build_command', 'false')
    assert should_build() is False
    config.set('build_command', 'test')
    config.set('upload_to_pypi', 'false')
    assert should_build() is False
    config.set('upload_to_release', 'false')
    assert should_build() is False
    config.set('upload_to_pypi', 'true')
    config.set('upload_to_release', 'true')
    assert should_build() is True
    config.set('build_command', 'false')
    config.set('upload_to_pypi', 'false')

# Generated at 2022-06-26 01:07:28.072114
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:07:34.212299
# Unit test for function should_build
def test_should_build():
    logger.info("Testing should_build function")
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-26 01:07:36.257416
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()

# Generated at 2022-06-26 01:11:56.132745
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()
    assert should_remove_dist()
    assert not should_remove_dist()


# Generated at 2022-06-26 01:11:56.738104
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-26 01:11:57.561969
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:11:58.374941
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:11:59.162807
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True


# Generated at 2022-06-26 01:12:00.120684
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == 0


# Generated at 2022-06-26 01:12:01.924787
# Unit test for function should_build
def test_should_build():
    # Test case 1
    var_1 = should_build()
    assert var_1 == True



# Generated at 2022-06-26 01:12:02.923774
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0
    

# Generated at 2022-06-26 01:12:03.687166
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:12:04.214917
# Unit test for function should_build
def test_should_build():
    assert should_build() == False