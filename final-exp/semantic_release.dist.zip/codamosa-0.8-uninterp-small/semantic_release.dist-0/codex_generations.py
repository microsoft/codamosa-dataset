

# Generated at 2022-06-26 01:04:40.320929
# Unit test for function should_build
def test_should_build():
    assert should_build() == False 


# Generated at 2022-06-26 01:04:45.700640
# Unit test for function should_build
def test_should_build():
    # case 0
    config["build_command"] = "true"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_build()

    # case 1
    config["build_command"] = "true"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build()



# Generated at 2022-06-26 01:04:53.637140
# Unit test for function should_build
def test_should_build():
    test_cases = [
        {"value": {"upload_to_pypi": True, "build_command": "build"}, "expected": True},
        {"value": {"upload_to_release": True, "build_command": "build"}, "expected": True},
        {"value": {"build_command": "build"}, "expected": False},
        {"value": {"upload_to_pypi": False, "upload_to_release": False, "build_command": "build"}, "expected": False},
        {"value": {"upload_to_pypi": True, "upload_to_release": True, "build_command": False}, "expected": False},
    ]
    for case in test_cases:
        config.update(case["value"])
        logger.debug(f"config: {config}")
        assert should_build()

# Generated at 2022-06-26 01:04:57.079081
# Unit test for function should_build
def test_should_build():
    logger.debug("Testing should_build()")
    config["build_command"] = "false"
    assert should_build() == False
    config["build_command"] = False
    assert should_build() == False
    config["build_command"] = "True"
    assert should_build() == True



# Generated at 2022-06-26 01:04:59.024598
# Unit test for function should_remove_dist
def test_should_remove_dist():
    logger.info("Testing should_remove_dist")
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True

# Unit Test for function build_dists

# Generated at 2022-06-26 01:04:59.805411
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:05:01.017937
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False, "The function must to return False"


# Generated at 2022-06-26 01:05:02.165166
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-26 01:05:04.194317
# Unit test for function should_build
def test_should_build():
    build_command = config.get("build_command")
    build_result = should_build()
    assert(build_result == (build_command != "false"))


# Generated at 2022-06-26 01:05:04.870704
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-26 01:07:37.169515
# Unit test for function should_remove_dist
def test_should_remove_dist():
    if config.get("remove_dist") == "true":
        assert should_remove_dist() is True
    else:
        assert should_remove_dist() is False


# Generated at 2022-06-26 01:07:38.150078
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()



# Generated at 2022-06-26 01:07:39.170882
# Unit test for function should_build
def test_should_build():
    should_build()


# Generated at 2022-06-26 01:07:40.354486
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    pass


# Generated at 2022-06-26 01:07:41.891470
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0 is False


# Generated at 2022-06-26 01:07:51.974001
# Unit test for function should_build
def test_should_build():
    # Case 0
    var_0 = config.get("upload_to_pypi")
    var_1 = config.get("upload_to_release")
    var_2 = config.get("build_command")
    var_2 = var_2 if var_2 != "false" else False
    assert var_0 == False
    assert var_1 == True
    assert var_2 == True
    assert should_build() == True

    # Case 1
    config["upload_to_pypi"] = True
    var_1 = config.get("upload_to_pypi")
    assert var_1 == True
    assert should_build() == True

    # Case 2
    config["upload_to_release"] = False
    var_1 = config.get("upload_to_release")
    assert var_1 == False

# Generated at 2022-06-26 01:07:55.841206
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    print(var_0)



# Generated at 2022-06-26 01:08:03.241775
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = "true"
    config["build_command"] = "echo hello-world"
    assert should_build()

    config["upload_to_pypi"] = "false"
    assert not should_build()

    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "true"
    assert should_build()
    config["upload_to_release"] = "false"
    assert should_build()

    config["build_command"] = "false"
    assert not should_build()

# Generated at 2022-06-26 01:08:04.705680
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:08:16.558105
# Unit test for function should_remove_dist
def test_should_remove_dist():
    global config
    config = None
    assert should_remove_dist() == False
    config = {"remove_dist": ""}
    assert should_remove_dist() == False
    config = {"upload_to_pypi": "", "upload_to_release": ""}
    assert should_remove_dist() == False
    config = {"build_command": "", "upload_to_pypi": "", "upload_to_release": ""}
    assert should_remove_dist() == False
    config = {"build_command": "", "upload_to_pypi": "", "upload_to_release": "", "remove_dist": ""}
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:10:53.471526
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() != False
    assert should_remove_dist() == config.get("remove_dist")



# Generated at 2022-06-26 01:10:56.261000
# Unit test for function should_build
def test_should_build():

    # Case where should_build is True
    config["build_command"] = "test"
    config["upload_to_pypi"] = True
    assert should_build() == True

    # Case where should_build is False
    config["build_command"] = "false"
    config["upload_to_pypi"] = True
    assert should_build() == False


# Generated at 2022-06-26 01:10:58.109944
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1 == False


# Generated at 2022-06-26 01:11:06.743556
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = False
    var_0 = config.get("upload_to_pypi")
    var_1 = False
    var_1 = config.get("upload_to_release")
    var_2 = ""
    var_2 = config.get("build_command")
    var_3 = False
    var_3 = var_2 != "false"
    var_4 = False
    var_4 = var_2 if var_3 else False
    var_5 = False
    var_5 = var_4 and (var_0 or var_1)
    var_6 = False
    var_6 = config.get("remove_dist")
    var_7 = True
    var_7 = var_6 and var_5
    return var_7


# Generated at 2022-06-26 01:11:07.236974
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-26 01:11:08.779372
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == False)

# Generated at 2022-06-26 01:11:13.400511
# Unit test for function should_remove_dist
def test_should_remove_dist():
    try:
        config.set("remove_dist", "False")
        result = should_remove_dist()
        assert result == False
    finally:
        config.set("remove_dist", "True")

    try:
        config.set("build_command", "false")
        result = should_remove_dist()
        assert result == False
    finally:
        config.set("build_command", "sphinx-build")

# Generated at 2022-06-26 01:11:14.473635
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-26 01:11:15.490523
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:11:20.245961
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config["build_command"] = True
    assert not should_build()
    config["upload_to_pypi"] = True
    assert should_build()
    del config["upload_to_pypi"]
    config["upload_to_release"] = True
    assert should_build()
    del config["upload_to_release"]

