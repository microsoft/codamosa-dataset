

# Generated at 2022-06-26 01:03:55.928482
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:03:57.936263
# Unit test for function should_build
def test_should_build():
    """Test for should_build
    """
    # WHEN
    var_0 = should_build()
    # THEN
    assert var_0 is True



# Generated at 2022-06-26 01:03:59.023801
# Unit test for function should_build
def test_should_build():
    assert(true == should_build())


# Generated at 2022-06-26 01:04:00.082406
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:04:02.562644
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:04:12.143909
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist()
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist()
    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:04:13.408286
# Unit test for function should_build
def test_should_build():
    assert should_build() in {True, False}


# Generated at 2022-06-26 01:04:15.519385
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:04:16.890003
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()


# Generated at 2022-06-26 01:04:25.566560
# Unit test for function should_build
def test_should_build():
    logger.debug("Testing function should_build")
    command = "echo 'nothing to do'"
    config.set("build_command", command)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    assert should_build() == True
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", False)
    assert should_build() == True
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    assert should_build() == False
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)

# Generated at 2022-06-26 01:06:14.838415
# Unit test for function should_build
def test_should_build():
    config_0 = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "false",
    }
    config.update(config_0)
    var_0 = should_build()
    assert not var_0
    config_0 = {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "false",
    }
    config.update(config_0)
    var_0 = should_build()
    assert not var_0
    config_0 = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "false",
    }
    config.update(config_0)
    var_

# Generated at 2022-06-26 01:06:15.698580
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-26 01:06:19.210083
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() is True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() is False


# Generated at 2022-06-26 01:06:26.759138
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = False
    assert should_build() is False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "false"
    assert should_build() is False

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "./build.sh"
    assert should_build() is True

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "./run.sh"
    assert should_build() is True


# Generated at 2022-06-26 01:06:27.536473
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-26 01:06:29.218143
# Unit test for function should_build
def test_should_build():
    assert should_build() == True, "test_should_build test failed"


# Generated at 2022-06-26 01:06:33.428694
# Unit test for function should_remove_dist
def test_should_remove_dist():
    scenario_0 = should_remove_dist()
    scenario_1 = should_remove_dist()
    scenario_2 = should_remove_dist()
    scenario_3 = should_remove_dist()

    assert scenario_0 == False
    assert scenario_1 == False
    assert scenario_2 == False
    assert scenario_3 == True


# Generated at 2022-06-26 01:06:34.928767
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0 == bool(False)


# Generated at 2022-06-26 01:06:35.675394
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()


# Generated at 2022-06-26 01:06:36.525884
# Unit test for function should_remove_dist
def test_should_remove_dist():
    pass


# Generated at 2022-06-26 01:10:06.042746
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:10:07.355778
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-26 01:10:08.682283
# Unit test for function should_build
def test_should_build():
    # Example test case:
    # var = should_build()
    # assert var == expected
    pass


# Generated at 2022-06-26 01:10:09.880175
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_1 = should_remove_dist()
    assert (var_1 == True)


# Generated at 2022-06-26 01:10:16.386589
# Unit test for function should_build
def test_should_build():
    var_dict = config.as_dict()
    var_dict["config_type"] = "local"
    var_dict["upload_to_pypi"] = True
    var_dict["upload_to_release"] = False
    var_dict["build_command"] = "clean"
    var_dict["remove_dist"] = True

    config.set_vars(var_dict)

    assert should_build()
    assert should_remove_dist()



# Generated at 2022-06-26 01:10:26.009826
# Unit test for function should_build
def test_should_build():
    config.update({"upload_to_pypi": False,
                   "upload_to_release": False,
                   "build_command": "echo 1"})
    assert should_build() == False

    config.update({"upload_to_pypi": True,
                   "upload_to_release": False,
                   "build_command": "echo 1"})
    assert should_build() == True

    config.update({"upload_to_pypi": False,
                   "upload_to_release": True,
                   "build_command": "echo 1"})
    assert should_build() == True

    config.update({"upload_to_pypi": False,
                   "upload_to_release": False,
                   "build_command": False})
    assert should_build() == False


# Generated at 2022-06-26 01:10:27.394531
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:10:33.139928
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("build_command", 'python3 setup.py sdist bdist_wheel')
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("remove_dist", True)
    var_1 = should_remove_dist()
    assert var_1 == False


# Generated at 2022-06-26 01:10:35.352596
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "true"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    result = should_build()
    assert not result



# Generated at 2022-06-26 01:10:38.334515
# Unit test for function should_build
def test_should_build():
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    assert should_build() == bool(build_command)