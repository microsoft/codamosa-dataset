

# Generated at 2022-06-26 01:04:10.085874
# Unit test for function should_build
def test_should_build():
    """Unit test for function should_build"""
    command = "python setup.py sdist"
    var_0 = should_build()
    assert var_0 == False, "Assertion failed"



# Generated at 2022-06-26 01:04:13.393811
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", "true")
    var_0 = should_remove_dist()
    config.set("remove_dist", "false")
    var_1 = should_remove_dist()
    assert var_0 == True
    assert var_1 == False

# Generated at 2022-06-26 01:04:15.519678
# Unit test for function should_build
def test_should_build():
    assert should_build(), "Should remove dist"



# Generated at 2022-06-26 01:04:16.901574
# Unit test for function should_build
def test_should_build():
    assert should_build() == False, 'Unit Test Failed!'


# Generated at 2022-06-26 01:04:22.503224
# Unit test for function should_remove_dist
def test_should_remove_dist():
    cmd0 = "cd /tmp && rm -rf dist"
    cmd1 = "cd /tmp && rm -rf build"
    cmd2 = "cd /tmp && rm -rf *.egg-info"
    commands = [cmd0, cmd1, cmd2]
    config["remove_dist"] = True
    remove_dists("/tmp")
    for cmd in commands:
        with pytest.raises(AssertionError):
            run(cmd)

# Generated at 2022-06-26 01:04:23.211597
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()

# Generated at 2022-06-26 01:04:25.524433
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "command"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() is True


# Generated at 2022-06-26 01:04:26.189056
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-26 01:04:27.828824
# Unit test for function should_build
def test_should_build():
    var_1 = not should_build()
    assert var_1
    assert not var_1
    assert var_1


# Generated at 2022-06-26 01:04:32.100457
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dict_0 = dict({
        "build_command": "python setup.py bdist_wheel sdist",
        "remove_dist": True,
        "upload_to_pypi": True
    })
    var_0 = should_remove_dist()
    logger.debug(f"var_0: {var_0}")


# Generated at 2022-06-26 01:06:27.991427
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", "false")
    config.set("upload_to_release", "false")
    config.set("build_command", "false")
    config.set("remove_dist", "false")
    assert should_build() == False # function should_build return value should be False


# Generated at 2022-06-26 01:06:29.079993
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-26 01:06:29.901757
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:06:37.193286
# Unit test for function should_build
def test_should_build():
    config_0 = {
        "upload_to_pypi": "false",
        "upload_to_release": "false",
        "build_command": "false"
    }
    assert should_build(config_0) == False

    config_1 = {
        "upload_to_pypi": "false",
        "upload_to_release": "false",
        "build_command": "not empty"
    }
    assert should_build(config_1) == False

    config_2 = {
        "upload_to_pypi": "not empty",
        "upload_to_release": "false",
        "build_command": "false"
    }
    assert should_build(config_2) == False


# Generated at 2022-06-26 01:06:37.840236
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:06:39.493995
# Unit test for function should_build
def test_should_build():
    var_1 = True
    assert var_1 == should_build()


# Generated at 2022-06-26 01:06:45.587144
# Unit test for function should_build
def test_should_build():
    conf = config
    conf["build_command"] = "true"
    conf["upload_to_pypi"] = True
    conf["upload_to_release"] = True
    assert should_build()

    conf["upload_to_pypi"] = True
    conf["upload_to_release"] = False
    assert should_build()

    conf["upload_to_pypi"] = False
    conf["upload_to_release"] = True
    assert should_build()

    conf["upload_to_pypi"] = False
    conf["upload_to_release"] = False
    assert not should_build()

    conf["build_command"] = "false"
    conf["upload_to_pypi"] = True
    conf["upload_to_release"] = True
    assert not should_build()

# Unit

# Generated at 2022-06-26 01:06:47.284354
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:06:47.883679
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:06:48.725821
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True


# Generated at 2022-06-26 01:08:43.961248
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()


# Generated at 2022-06-26 01:08:51.931143
# Unit test for function should_build
def test_should_build():
    from .settings import load_config
    settings = load_config(".muty.yaml")
    settings.update({"build_command": "python setup.py bdist_wheel", "upload_to_pypi": True})
    test_case_0()
    assert settings.get("build_command") == "python setup.py bdist_wheel"
    assert settings.get("upload_to_pypi") and True
    settings["build_command"] = "python setup.py bdist_wheel"
    settings["upload_to_pypi"] = False
    settings["upload_to_release"] = False
    assert settings.get("upload_to_release") == False
    settings["build_command"] = "false"
    settings["upload_to_pypi"] = True
    assert settings.get("build_command")

# Generated at 2022-06-26 01:08:52.911879
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-26 01:08:56.142531
# Unit test for function should_build
def test_should_build():
    var_1 = config["upload_to_pypi"]
    var_2 = config["upload_to_release"]
    var_3 = config["build_command"]
    var_4 = config["remove_dist"]
    actual_output = should_build()
    expected_output = True
    assert expected_output == actual_output


# Generated at 2022-06-26 01:09:03.256310
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """Unit test for function should_remove_dist.

    Args:
        remove_dist (bool, optional): remove dists. Defaults to False.
    """
    # True
    config.set("remove_dist", "true")
    assert should_remove_dist() is True
    # False
    config.set("remove_dist", "false")
    assert should_remove_dist() is False
    # False
    config.set("remove_dist", None)
    assert should_remove_dist() is False



# Generated at 2022-06-26 01:09:11.759928
# Unit test for function should_build
def test_should_build():
    build_command_true = "true"
    config.set("build_command", "true")
    upload_pypi_true = True
    config.set("upload_to_pypi", True)
    upload_release_true = True
    config.set("upload_to_release", True)
    assert should_build() == True
    build_command_false = "false"
    config.set("build_command", "false")
    upload_pypi_false = False
    config.set("upload_to_pypi", False)
    upload_release_false = False
    config.set("upload_to_release", False)
    assert should_build() == False
    build_command_true = "true"
    config.set("build_command", "true")

# Generated at 2022-06-26 01:09:14.361098
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Case 0
    assert test_case_0()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(levelname)s %(message)s"
    )
    # Unit test for function should_build
    test_should_build()

# Generated at 2022-06-26 01:09:14.929070
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-26 01:09:17.027209
# Unit test for function should_build
def test_should_build():
    # return True
    assert should_build()
    # return False
    exist_build_command = config.get("build_command")
    config.set("build_command", "false")
    assert not should_build()
    config.set("build_command", exist_build_command)



# Generated at 2022-06-26 01:09:19.271182
# Unit test for function should_build
def test_should_build():
    """Test should_build function
    """
    # Test case 0
    var_0 = should_build()
    assert not var_0



# Generated at 2022-06-26 01:11:23.047490
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()


# Generated at 2022-06-26 01:11:23.829020
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-26 01:11:25.000985
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist(), "This test should be True if a remove_dist setting is set in your config"


# Generated at 2022-06-26 01:11:26.028846
# Unit test for function should_build
def test_should_build():
    assert should_build(), "Failed to get value of config variable build_command"


# Generated at 2022-06-26 01:11:26.861761
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1 == True


# Generated at 2022-06-26 01:11:27.634148
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_1 = should_remove_dist()



# Generated at 2022-06-26 01:11:30.393996
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = config.get("remove_dist")
    var_1 = config("upload_to_pypi")
    var_2 = config("upload_to_release")
    var_3 = config("build_command")
    var_4 = var_0 and (var_1 or var_2)
    var_5 = should_remove_dist()
    assert var_4 == var_5

# Generated at 2022-06-26 01:11:31.454053
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    var_2 = should_build()
    assert var_1 == var_2


# Generated at 2022-06-26 01:11:36.270126
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "python setup.py sdist"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    var_0 = should_build()
    assert var_0
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    var_1 = should_build()
    assert not var_1
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    var_2 = should_build()
    assert var_2
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    var_3 = should_build()
    assert var_3
    config["build_command"] = "false"
   

# Generated at 2022-06-26 01:11:37.865124
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert type(should_remove_dist()) == bool
