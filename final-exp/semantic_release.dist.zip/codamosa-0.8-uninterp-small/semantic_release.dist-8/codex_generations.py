

# Generated at 2022-06-26 01:04:19.463905
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()


# Unit test to test function should_build

# Generated at 2022-06-26 01:04:20.334908
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:04:21.619042
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:04:24.021979
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    config['build_command'] = True
    config['upload_to_pypi'] = True
    result = should_remove_dist()
    assert result


# Generated at 2022-06-26 01:04:24.813243
# Unit test for function should_build
def test_should_build():
    var = should_build()


# Generated at 2022-06-26 01:04:25.639696
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-26 01:04:26.539284
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:04:30.513180
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist bdist_wheel"
    assert should_build()
    config["upload_to_release"] = False
    assert not should_build()



# Generated at 2022-06-26 01:04:31.320127
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()



# Generated at 2022-06-26 01:04:34.340059
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({'remove_dist': 'True', 'upload_to_pypi': 'False', 'upload_to_release': 'False', 'build_command': 'True'})
    var_0 = should_remove_dist()
    assert var_0 == True


# Generated at 2022-06-26 01:06:28.889906
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test 1
    var_0 = should_remove_dist()
    assert var_0 == False


# Generated at 2022-06-26 01:06:29.698721
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:06:34.320723
# Unit test for function should_build
def test_should_build():
    cfg = {
        "upload_to_pypi": True,
        "build_command": "false",
        "upload_to_release": True
    }
    config.update(cfg)
    assert should_build()
    cfg = {
        "upload_to_pypi": True,
        "build_command": "true",
        "upload_to_release": False
    }

# Generated at 2022-06-26 01:06:35.595518
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0 == False


# Generated at 2022-06-26 01:06:42.760110
# Unit test for function should_remove_dist
def test_should_remove_dist():
    logger.info("testing function should_remove_dist")
    config["remove_dist"] = 'true'
    config['upload_to_release'] = 'true'
    config['upload_to_pypi'] = 'false'
    config['build_command'] = 'true'
    assert should_remove_dist()
    config['remove_dist'] = 'false'
    config['upload_to_release'] = 'true'
    config['upload_to_pypi'] = 'false'
    config['build_command'] = 'true'
    assert not should_remove_dist()
    config['remove_dist'] = 'false'
    config['upload_to_release'] = 'true'
    config['upload_to_pypi'] = 'false'
    config['build_command'] = 'false'
    assert not should

# Generated at 2022-06-26 01:06:48.047344
# Unit test for function should_build
def test_should_build():
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    build_command = config.get("build_command")
    build_command = build_command if build_command != "false" else False
    
    for i in range(2):
        for j in range(2):
            for k in range(2):
                upload_pypi = True if i == 1 else False
                upload_release = True if j == 1 else False
                build_command = True if k == 1 else False
                result = bool(build_command and (upload_pypi or upload_release))
                assert should_build() == result


# Generated at 2022-06-26 01:06:49.306067
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True
    var_1 = should_build()


# Generated at 2022-06-26 01:06:53.643277
# Unit test for function should_build
def test_should_build():
    # Test case 0
    try:
        var = should_build()
        assert type(var) == bool, "expected boolean"
    except AssertionError:
        logger.warn(f"data type assertion failed: {var}")
        logger.debug(f"test_should_build: test case 0 failed")
    else:
        logger.debug(f"test_should_build: test case 0 passed")


# Generated at 2022-06-26 01:06:54.426197
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-26 01:06:55.347869
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True


# Generated at 2022-06-26 01:08:59.110049
# Unit test for function should_build
def test_should_build():
    # Should build when there's a build command and we're uploading to pypi or release
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "echo hello"
    assert should_build()

    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "echo hello"
    assert should_build()

    # Should not build when there's no build command
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = False
    assert not should_build()

    config["upload_to_pypi"] = "false"
    config

# Generated at 2022-06-26 01:09:01.677140
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False # True


# Generated at 2022-06-26 01:09:02.561378
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-26 01:09:03.741487
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0


# Generated at 2022-06-26 01:09:04.881077
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True
    assert should_build() == True


# Generated at 2022-06-26 01:09:06.999714
# Unit test for function should_build
def test_should_build():
    # Test case 0
    path = './'
    remove_dists(path)
    assert should_build()


# Generated at 2022-06-26 01:09:07.820483
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:09:09.252222
# Unit test for function should_build
def test_should_build():
    assert (should_build() is False), "Error in should_build, should_build() should be False"


# Generated at 2022-06-26 01:09:12.306728
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", False)
    config.set("build_command", True)
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)

    assert should_remove_dist() == False


# Generated at 2022-06-26 01:09:13.064897
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()

# Generated at 2022-06-26 01:11:24.438386
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == False

# Generated at 2022-06-26 01:11:29.776262
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    assert should_remove_dist() == True

    config['remove_dist'] = False
    assert should_remove_dist() == False

    config['upload_to_release'] = True
    config['upload_to_pypi'] = True
    assert should_remove_dist() == False

    config['upload_to_release'] = True
    config['upload_to_pypi'] = False
    assert should_remove_dist() == False

    config['upload_to_release'] = False
    config['upload_to_pypi'] = True
    assert should_remove_dist() == False

    config['upload_to_release'] = False
    config['upload_to_pypi'] = False
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:11:31.210139
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    assert should_remove_dist() is True
    config["remove_dist"] = "false"
    assert should_remove_dist() is False


# Generated at 2022-06-26 01:11:31.816927
# Unit test for function should_build
def test_should_build():
    assert should_build() is True

# Generated at 2022-06-26 01:11:32.649010
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:11:33.271604
# Unit test for function should_build
def test_should_build():
    assert should_build() is False


# Generated at 2022-06-26 01:11:33.887924
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

# Generated at 2022-06-26 01:11:34.434610
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert not should_remove_dist()

# Generated at 2022-06-26 01:11:35.426887
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Case 0
    config['remove_dist'] = 'false'
    assert should_remove_dist() is False

# Generated at 2022-06-26 01:11:42.088608
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Case 0
    # 
    # Expected result: 
    # 
    # Output: 
    test_case_0()

    # Case 1
    # 
    # Expected result: 
    # 
    # Output: 
    # 
    # var_0 = True
    # remove_dists(var_0)
    # 
    # Case 2
    # 
    # Expected result: 
    # 
    # Output: 
    # 
    # var_0 = False
    # remove_dists(var_0)
    # 
    # Case 3
    # 
    # Expected result: 
    # 
    # Output: 
    # 
    # var_0 = True
    # remove_dists(var_0)
    # 