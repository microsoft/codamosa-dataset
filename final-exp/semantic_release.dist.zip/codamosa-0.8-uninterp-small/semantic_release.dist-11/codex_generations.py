

# Generated at 2022-06-26 01:04:08.757608
# Unit test for function should_build
def test_should_build():
    command = "sphinx-build -b dirhtml output/source output/build/dirhtml"
    upload_pypi = True
    upload_release = True
    assert should_build() == True


# Generated at 2022-06-26 01:04:09.276858
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-26 01:04:10.435898
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-26 01:04:19.325019
# Unit test for function should_build
def test_should_build():
    """Test should_build"""
    from .settings import config
    config["build_command"] = "true"
    var_0 = should_build()
    assert var_0 is True
    config["build_command"] = "false"
    var_1 = should_build()
    assert var_1 is False
    config["build_command"] = "true"
    config["upload_to_pypi"] = "false"
    var_2 = should_build()
    assert var_2 is False
    config["upload_to_release"] = "false"
    var_3 = should_build()
    assert var_3 is False


# Generated at 2022-06-26 01:04:20.213925
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:04:21.056226
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert test_case_0() == True

# Generated at 2022-06-26 01:04:22.019637
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:04:24.101478
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0 == True, "Expected True, Actual: " + str(var_0)


# Generated at 2022-06-26 01:04:24.887411
# Unit test for function should_build
def test_should_build():
    should_build()



# Generated at 2022-06-26 01:04:26.607991
# Unit test for function should_build
def test_should_build():
    config.set("build_command", "make build")
    config.set("remove_dist", True)
    config.set("upload_to_release", True)
    assert should_build()


# Generated at 2022-06-26 01:04:49.020719
# Unit test for function should_build
def test_should_build():
    """Return True if the build command 
    and either upload_to_pypi 
    or upload_to_release are set to True
    """
    config["build_command"] = "python setup.py sdist"

    assert should_build() is False

    config["upload_to_pypi"] = True

    assert should_build() is True

    config["upload_to_release"] = True

    assert should_build() is True

# Generated at 2022-06-26 01:04:50.237026
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:04:51.034046
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:04:51.850964
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-26 01:04:56.363614
# Unit test for function should_build
def test_should_build():
    """Test for should_build"""
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True
    assert should_build() == True


# Generated at 2022-06-26 01:04:58.862633
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    if (var_0 == should_remove_dist()):
        print("test_should_remove_dist() PASSED")
    else:
        print("test_should_remove_dist() FAILED")



# Generated at 2022-06-26 01:04:59.805966
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    assert var_0 == False

# Generated at 2022-06-26 01:05:03.060279
# Unit test for function should_remove_dist
def test_should_remove_dist():
    dist_dir = config.get("dist_directory")
    config.set("remove_dist", "true")
    assert should_remove_dist() == True, "Should remove dist true"
    config.set("remove_dist", "false")
    assert should_remove_dist() == False, "Should remove dist false"


# Generated at 2022-06-26 01:05:05.348951
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("remove_dist", True)
    config.set("upload_to_pypi", True)
    config.set("build_command", "build_command")
    assert should_remove_dist()


# Generated at 2022-06-26 01:05:07.806555
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test case 0 => remove_dist:True, build_command:True, upload_pypi:False, upload_release:False => Should return remove_dist value
    var_0 = should_remove_dist()
    assert var_0 == True


# Generated at 2022-06-26 01:05:23.986375
# Unit test for function should_remove_dist
def test_should_remove_dist():
    logger.info("Testing should_remove_dist function")

    var_0 = should_remove_dist()
    assert var_0 == False



# Generated at 2022-06-26 01:05:29.206061
# Unit test for function should_build
def test_should_build():
    config["build_command"] = "build_command"
    assert should_build() == True

    config["build_command"] = "false"
    assert should_build() == False

    config["build_command"] = "build_command"
    config["upload_to_pypi"] = "upload_to_pypi"
    config["upload_to_release"] = "upload_to_release"
    assert should_build() == True

    config["build_command"] = "false"
    config["upload_to_pypi"] = "upload_to_pypi"
    config["upload_to_release"] = "upload_to_release"
    assert should_build() == False

    config["build_command"] = "build_command"

# Generated at 2022-06-26 01:05:41.258372
# Unit test for function should_build
def test_should_build():
    build_command = config.get("build_command")
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    # If build command is present and one of the upload to pypi or upload to release is True,
    # should_build should return True
    assert should_build() == (bool(build_command) and (upload_pypi or upload_release))
    # If build command is not present should_build should return False
    config.set_config_values({"build_command": "false"})
    assert should_build() == False
    # If both the upload options are set to False should_build should return False

# Generated at 2022-06-26 01:05:46.833003
# Unit test for function should_build
def test_should_build():
    config_0 = {
        "upload_to_pypi": True, # upload_to_pypi = True
        "upload_to_release": False, # upload_to_release = False
        "build_command": "sphinx-build -b html source build"
    }
    config.update(config_0)
    var_0 = should_build()
    assert var_0


# Generated at 2022-06-26 01:05:50.534344
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # case 0
    config.settings = {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "build",
        "remove_dist": True
    }
    expected_0 = True
    actual_0 = should_remove_dist()
    if expected_0 == actual_0:
        print('Test case 0: pass')
    else:
        print('Test case 0: fail')

# Generated at 2022-06-26 01:05:53.632871
# Unit test for function should_build
def test_should_build():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 01:05:56.408648
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist('') == True

# Generated at 2022-06-26 01:05:58.695145
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False



# Generated at 2022-06-26 01:05:59.533272
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:06:00.512466
# Unit test for function should_build
def test_should_build():
    var = should_build()
    assert var is True


# Generated at 2022-06-26 01:06:26.322453
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:06:34.758254
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test case 1: upload_to_pypi == true, upload_to_release == true, build_command == true, remove_dist == true
    config.update(dict(upload_to_pypi=True, upload_to_release=True, build_command=True, remove_dist=True))
    assert should_remove_dist() == True

    # Test case 2: upload_to_pypi == false, upload_to_release == false, build_command == true, remove_dist == true
    config.update(dict(upload_to_pypi=False, upload_to_release=False, build_command=True, remove_dist=True))
    assert should_remove_dist() == True

    # Test case 3: upload_to_pypi == true, upload_to_release == false, build_command == true

# Generated at 2022-06-26 01:06:41.888406
# Unit test for function should_build
def test_should_build():
    """
    test should_build function
    """
    config.clear()

    # Test Case 0
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert not should_build()
    config.clear()

    # Test Case 1
    config["upload_to_pypi"] = "true"
    config["upload_to_release"] = "false"
    config["build_command"] = "true"
    assert not should_build()
    config.clear()

    # Test Case 2
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "true"
    config["build_command"] = "false"
    assert not should_build()


# Generated at 2022-06-26 01:06:43.321862
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == config.get("remove_dist") and \
                                   should_build()


# Generated at 2022-06-26 01:06:48.349871
# Unit test for function should_build
def test_should_build():
    from unittest import mock
    from .settings import config
    from .build import should_build

    with mock.patch("run") as m:
        config["upload_to_pypi"] = True
        assert should_build()

        config["upload_to_pypi"] = False
        config["upload_to_release"] = True
        assert should_build()

        config["upload_to_pypi"] = False
        config["upload_to_release"] = False
        assert not should_build()

        # Testing if 'build_command' is not False, but is still not true
        config["build_command"] = None
        assert not should_build()



# Generated at 2022-06-26 01:06:55.299801
# Unit test for function should_build
def test_should_build():
    from .settings import config

    config["build_command"] = "foo"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False

    config["build_command"] = "foo"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True

    config["build_command"] = "foo"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    config["build_command"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == False


# Generated at 2022-06-26 01:07:00.606102
# Unit test for function should_build
def test_should_build():
    # 1st test case
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    config["build_command"] = "python setup.py sdist"
    assert should_build() == True

    # 2nd test case
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_build() == True

    # 3rd test case
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_build() == True

    # 4th test case
    config["upload_to_pypi"] = True
   

# Generated at 2022-06-26 01:07:04.287724
# Unit test for function should_build
def test_should_build():
    class TestCase(object):
        def __init__(self, description, params, want):
            self.description = description
            self.params = params
            self.want = want

# Generated at 2022-06-26 01:07:10.178263
# Unit test for function should_build
def test_should_build():
    config_0 = config.copy()
    config_1 = config.copy()
    config_2 = config.copy()
    config_3 = config.copy()
    var_0 = False
    config_0["build_command"] = None
    config_1["upload_to_pypi"] = False
    config_2["upload_to_release"] = False
    config_3["build_command"] = "sdsadasd"
    var_1 = should_build()
    return var_0, var_1


# Generated at 2022-06-26 01:07:14.673396
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # arrange
    config.set("remove_dist", "true")
    config.set("build_command", "build_command")
    config.set("upload_to_pypi", "true")
    config.set("upload_to_release", "false")

    # act
    result = should_remove_dist()

    # assert
    assert result

# Generated at 2022-06-26 01:07:42.685553
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-26 01:07:43.814080
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1 == False


# Generated at 2022-06-26 01:07:44.876760
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-26 01:07:47.800695
# Unit test for function should_remove_dist
def test_should_remove_dist():
    run("invoke build-dists --config=tests/.config.yaml")
    assert should_remove_dist() == False
    # build_dists()



# Generated at 2022-06-26 01:07:48.594161
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-26 01:07:50.632383
# Unit test for function should_build
def test_should_build():
    assert should_build()



# Generated at 2022-06-26 01:07:54.850955
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:08:05.173454
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "True"
    config["build_command"] = "True"
    config["upload_to_pypi"] = "True"
    var = should_remove_dist()
    assert var == True
    config["build_command"] = "False"
    var = should_remove_dist()
    assert var == False
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "True"
    var = should_remove_dist()
    assert var == True
    config["upload_to_release"] = "False"
    var = should_remove_dist()
    assert var == False
    config["build_command"] = "True"
    config["upload_to_pypi"] = "True"
    var = should_remove_dist()
   

# Generated at 2022-06-26 01:08:07.028893
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:08:10.087884
# Unit test for function should_remove_dist
def test_should_remove_dist():
    should_remove = should_remove_dist()
    assert should_remove == False
    assert isinstance(should_remove, bool)
    with pytest.raises(TypeError): 
        should_remove_dist(10)


# Generated at 2022-06-26 01:08:36.329435
# Unit test for function should_build
def test_should_build():
    """
    Should build based on value of ``build_command``
    """
    assert should_build()



# Generated at 2022-06-26 01:08:37.527350
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True

# Generated at 2022-06-26 01:08:38.458865
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:08:39.315206
# Unit test for function should_build
def test_should_build():
    assert not should_build()


# Generated at 2022-06-26 01:08:43.627587
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """
    Test if function should_remove_dist() is triggered
    """
    logger.info('Testing function should_remove_dist()')
    assert should_remove_dist() == True, "Function should_remove_dist() should be triggered"
    assert should_build() == True, "Function should_build() should be triggered"

# Generated at 2022-06-26 01:08:50.201282
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False

    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True

    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == True



# Generated at 2022-06-26 01:08:50.886690
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-26 01:08:51.822122
# Unit test for function should_build
def test_should_build():
    assert(should_build() == True)


# Generated at 2022-06-26 01:09:00.953294
# Unit test for function should_build
def test_should_build():

    config_dict = config

    # test case 0: build_command=false, upload_release=false, upload_pypi=false
    config_dict["build_command"] = "false"
    config_dict["upload_release"] = False
    config_dict["upload_pypi"] = False
    assert not should_build()

    # test case 1: build_command=not_false, upload_release=false, upload_pypi=false
    config_dict["build_command"] = "command"
    config_dict["upload_release"] = False
    config_dict["upload_pypi"] = False
    assert not should_build()

    # test case 2: build_command=false, upload_release=true, upload_pypi=false
    config_dict["build_command"] = "false"
    config

# Generated at 2022-06-26 01:09:09.552127
# Unit test for function should_build
def test_should_build():
    # Ensure the build command is defined, and the upload targets
    # are defined
    config["build_command"] = "ls"
    config["upload_to_pypi"] = True
    assert should_build() == True

    # Ensure the build command is defined, and that at least
    # one of the upload targets is defined
    config["build_command"] = "ls"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True

    # Ensure the build command is not defined, and that at least
    # one of the upload targets is defined
    config["build_command"] = "false"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == False

#

# Generated at 2022-06-26 01:09:40.972737
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    if var_1:
        print('Yes, var_1 should be true.')
    else:
        print('No, var_1 should be true!')

# Generated at 2022-06-26 01:09:41.733074
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:09:42.986097
# Unit test for function should_remove_dist
def test_should_remove_dist():
    ex_0 = true
    
    assert test_case_0() == ex_0



# Generated at 2022-06-26 01:09:44.502340
# Unit test for function should_build
def test_should_build():
    should_build_0 = should_build()
    assert should_build_0 == False



# Generated at 2022-06-26 01:09:47.155097
# Unit test for function should_build
def test_should_build():
    assert should_build() is False


# Generated at 2022-06-26 01:09:49.328328
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-26 01:09:51.290601
# Unit test for function should_build
def test_should_build():
    assert not should_build()
    config.config["build_command"] = "falsecmd"
    assert should_build()



# Generated at 2022-06-26 01:09:52.674201
# Unit test for function should_build
def test_should_build():
    assert should_build() == True, "test_should_build failed"


# Generated at 2022-06-26 01:09:55.512010
# Unit test for function should_build
def test_should_build():
    assert should_build() == False, "test_should_build failed"


# Generated at 2022-06-26 01:09:56.657931
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_1 = should_remove_dist()

# Generated at 2022-06-26 01:10:27.263895
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-26 01:10:29.748337
# Unit test for function should_build
def test_should_build():
    build_command = config.get("build_command")
    assert should_build() == bool(build_command), "Should build the package"


# Generated at 2022-06-26 01:10:30.633415
# Unit test for function should_build
def test_should_build():
    assert not should_build()

# Generated at 2022-06-26 01:10:32.752008
# Unit test for function should_build
def test_should_build():
    assert(should_build() is True)


# Generated at 2022-06-26 01:10:40.826522
# Unit test for function should_remove_dist
def test_should_remove_dist():
    build_command = config.get("build_command")
    config["build_command"] = "x"
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() == True
    config["upload_to_release"] = False

    config["build_command"] = "false"
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    assert should_remove_dist() == False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:10:48.071116
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config_0 = {
        "remove_dist": "false",
        "build_command": "false",
        "upload_to_pypi": "false",
        "upload_to_release": "false"
    }
    config_1 = {
        "remove_dist": "false",
        "build_command": "invoke build",
        "upload_to_pypi": "false",
        "upload_to_release": "false"
    }
    config_2 = {
        "remove_dist": "false",
        "build_command": "invoke build",
        "upload_to_pypi": "true",
        "upload_to_release": "false"
    }

# Generated at 2022-06-26 01:10:48.642717
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:10:49.352196
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()


# Generated at 2022-06-26 01:10:49.856849
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:10:57.848645
# Unit test for function should_build
def test_should_build():
    from .settings import config, config_path
    # Case 0: 
    # Build is enabled.
    config.clear()
    config.update({
        'build_command': 'build',
        'upload_to_pypi': True,
        'upload_to_release': True,
        'remove_dist': True
    })

    assert should_build() == True

    # Case 1: 
    # Build is enabled.
    config.clear()
    config.update({
        'build_command': 'build',
        'upload_to_pypi': True,
        'upload_to_release': False,
        'remove_dist': True
    })

    assert should_build() == True

    # Case 2: 
    # Build is disabled.
    config.clear()

# Generated at 2022-06-26 01:11:32.722137
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "false"
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "python setup.py"
    assert should_remove_dist() == False
    config["remove_dist"] = "true"
    config["upload_to_pypi"] = "false"
    config["upload_to_release"] = "false"
    config["build_command"] = "python setup.py"

# Generated at 2022-06-26 01:11:33.155149
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-26 01:11:33.958488
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()
    assert var_1

# Generated at 2022-06-26 01:11:38.048273
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_config_0 = {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "false",
        "remove_dist": "true"
    }
    test_case_0(test_config_0)

# Generated at 2022-06-26 01:11:40.622844
# Unit test for function should_build
def test_should_build():
    build_command = config.get("build_command")
    upload_pypi = config.get("upload_to_pypi")
    upload_release = config.get("upload_to_release")
    assert bool(build_command and (upload_pypi or upload_release)) == should_build()


# Generated at 2022-06-26 01:11:42.242669
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    assert should_remove_dist() == True
    config['remove_dist'] = False
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:11:43.960765
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    # test cases
    if var_0:
        assert True
    else:
        assert False



# Generated at 2022-06-26 01:11:44.612534
# Unit test for function should_build
def test_should_build():
    pass


# Generated at 2022-06-26 01:11:50.119327
# Unit test for function should_build
def test_should_build():
    # Configuration for building and uploading to Pypi
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", True)
    config.set("build_command", "echo")
    assert should_build()

    # Configuration for building only
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", "echo")
    assert should_build()

    # Configuration for not building
    config.set("upload_to_pypi", False)
    config.set("upload_to_release", False)
    config.set("build_command", False)
    assert not should_build()



# Generated at 2022-06-26 01:11:53.403676
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "build"
    config["remove_dist"] = True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_remove_dist() == False
    config["upload_to_pypi"] = True
    assert should_remove_dist() == True
    config["upload_to_release"] = True
    assert should_remove_dist() == True