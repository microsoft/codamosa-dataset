

# Generated at 2022-06-26 01:04:11.011005
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    var_1 = should_build()
    var_2 = should_build()
    var_3 = should_build()
    var_4 = should_build()
    var_5 = should_build()
    var_6 = should_build()
    var_7 = should_build()
    var_8 = should_build()
    var_9 = should_build()
    var_10 = should_build()
    var_11 = should_build()
    var_12 = should_build()
    var_13 = should_build()
    var_14 = should_build()
    var_15 = should_build()
    var_16 = should_build()


# Generated at 2022-06-26 01:04:12.368585
# Unit test for function should_build
def test_should_build():
    val = should_build()
    assert val is True


# Generated at 2022-06-26 01:04:13.272956
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:04:16.349789
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert True == should_remove_dist() == True
    assert True == should_remove_dist() == True


# Generated at 2022-06-26 01:04:17.956982
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_1 = should_remove_dist()
    assert isinstance(var_1, bool)


# Generated at 2022-06-26 01:04:26.358171
# Unit test for function should_build
def test_should_build():
    # a valid build command and only releasing to release
    config["build_command"] = "build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert bool(should_build()) == True

    # a valid build command and only releasing to pypi
    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert bool(should_build()) == True

    # a valid build command and releasing to both pypi and release
    config["build_command"] = "build"
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert bool(should_build()) == True

    # No upload destination and a valid build command

# Generated at 2022-06-26 01:04:27.316528
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == True)


# Generated at 2022-06-26 01:04:30.072699
# Unit test for function should_build
def test_should_build():
    try:
        assert(should_build() == True)
    except AssertionError as error:
        print(error)
    else:
        print('Test Passed')


# Generated at 2022-06-26 01:04:31.137530
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True

# Generated at 2022-06-26 01:04:38.621035
# Unit test for function should_build
def test_should_build():
    # Test should_build when upload_to_pypi is True
    config["upload_to_pypi"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_build()

    # Test should_build when upload_to_release is True
    config["upload_to_pypi"] = False
    config["build_command"] = "python setup.py sdist"
    config["upload_to_release"] = True
    assert should_build()

    # Test should_build when build_command is False
    config["upload_to_pypi"] = True
    config["build_command"] = False
    config["upload_to_release"] = False
    assert not should_build()


# Generated at 2022-06-26 01:08:35.228141
# Unit test for function should_build
def test_should_build():
    upload_pypi = False
    upload_release = True
    build_command = "echo 'build'"
    config["upload_to_pypi"] = upload_pypi
    config["upload_to_release"] = upload_release
    config["build_command"] = build_command
    assert should_build() == True
    config["upload_to_pypi"] = not upload_pypi
    config["upload_to_release"] = not upload_release
    assert should_build() == True
    config["upload_to_pypi"] = not upload_pypi
    config["upload_to_release"] = upload_release
    assert should_build() == True

    config["upload_to_pypi"] = upload_pypi
    config["upload_to_release"] = not upload_release
   

# Generated at 2022-06-26 01:08:42.338985
# Unit test for function should_build
def test_should_build():
    var_1 = config.get("upload_to_pypi")
    var_2 = config.get("upload_to_release")
    var_3 = config.get("build_command")
    var_4 = config.get("upload_to_pypi")
    var_5 = config.get("upload_to_release")
    var_6 = config.get("build_command")
    assert var_1 or var_2 is not None
    assert var_3 is not None
    assert var_4 or var_5 and var_6 is not False


# Generated at 2022-06-26 01:08:43.235567
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:08:44.471328
# Unit test for function should_build
def test_should_build():
    assert should_build(), "should_build returned False when it should be True"

# Generated at 2022-06-26 01:08:45.340907
# Unit test for function should_build
def test_should_build():
    var_1 = should_build()


# Generated at 2022-06-26 01:08:46.701562
# Unit test for function should_build
def test_should_build():
    var = should_build()
    assert var is False


# Generated at 2022-06-26 01:08:47.554362
# Unit test for function should_build
def test_should_build():
    assert should_build() == True



# Generated at 2022-06-26 01:08:48.776922
# Unit test for function should_build
def test_should_build():
    var_0 = should_build()
    assert var_0 == True


# Generated at 2022-06-26 01:08:49.331912
# Unit test for function should_build
def test_should_build():
    assert should_build()

# Generated at 2022-06-26 01:08:52.450497
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False
    config.set("build_command", "false")
    assert should_remove_dist() == False
    config.set("build_command", "python setup.py sdist bdist_wheel")
    assert should_remove_dist() == True

