

# Generated at 2022-06-26 01:04:03.785489
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:04:06.270092
# Unit test for function should_build
def test_should_build():
    # Verifying if should_build returns correct value when upload_to_pypi is set to True
    config.upload_to_pypi = True
    assert should_build()


# Generated at 2022-06-26 01:04:16.808146
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["upload_to_pypi"] = "False"
    config["upload_to_release"] = "False"
    config["build_command"] = "echo hi"
    config["remove_dist"] = "False"
    assert should_remove_dist() == False
    config["build_command"] = "False"
    assert should_remove_dist() == False
    config["build_command"] = "echo hi"
    config["upload_to_pypi"] = "True"
    assert should_remove_dist() == False
    config["upload_to_release"] = "True"
    assert should_remove_dist() == False
    config["remove_dist"] = "True"
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:04:20.374560
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.update({"remove_dist": False})
    result_0 = should_remove_dist()
    assert result_0 == False

    config.update({"remove_dist": True})
    result_1 = should_remove_dist()
    assert result_1 == False



# Generated at 2022-06-26 01:04:27.040593
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = True
    config['build_command'] = "false"
    config['upload_to_pypi'] = False
    config['upload_to_release'] = False
    test_case_0()
    config['build_command'] = "ls -al"
    config['upload_to_pypi'] = True
    config['upload_to_release'] = False
    test_case_0()
    config['upload_to_pypi'] = False
    config['upload_to_release'] = True
    test_case_0()
    config['upload_to_pypi'] = True
    config['upload_to_release'] = True
    test_case_0()

# Generated at 2022-06-26 01:04:27.890815
# Unit test for function should_build
def test_should_build():
    assert should_build() is False


# Generated at 2022-06-26 01:04:30.109110
# Unit test for function should_build
def test_should_build():
    expected = True
    actual = should_build()
    assert expected == actual



# Generated at 2022-06-26 01:04:30.914745
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:04:34.225590
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()
    if (var_0 == true):
        var_1 = should_build()
        assert var_1 == true
    elif (var_0 == false):
        var_1 = should_build()
        assert var_1 == false


# Generated at 2022-06-26 01:04:35.015592
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:06:23.623823
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:06:25.743837
# Unit test for function should_remove_dist
def test_should_remove_dist():
    actual = should_remove_dist()
    assert actual == True



# Generated at 2022-06-26 01:06:26.904780
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert test_case_0() == False


# Generated at 2022-06-26 01:06:29.767574
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config.set("upload_to_pypi", True)
    config.set("upload_to_release", True)
    config.set("build_command", "build")
    config.set("remove_dist", True)

    test_case_0()

# Generated at 2022-06-26 01:06:31.313773
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False


# Generated at 2022-06-26 01:06:32.120000
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:06:33.494148
# Unit test for function should_remove_dist
def test_should_remove_dist():
    for var_0 in range(0, 16):
        if var_0 == 0:
            test_case_0()

# Generated at 2022-06-26 01:06:37.914298
# Unit test for function should_build
def test_should_build():
    var_0 = config["upload_to_pypi"] = True
    var_1 = config["upload_to_release"] = True
    var_2 = config["build_command"] = "true"

    var_3 = should_build()

    config["upload_to_pypi"] = var_0
    config["upload_to_release"] = var_1
    config["build_command"] = var_2

    assert var_3 == True and var_3 != False


# Generated at 2022-06-26 01:06:39.326922
# Unit test for function should_build
def test_should_build():
    assert should_build() == False

# Generated at 2022-06-26 01:06:39.948095
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-26 01:08:38.383255
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config['remove_dist'] = False
    assert should_remove_dist() == False



# Generated at 2022-06-26 01:08:39.219275
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-26 01:08:40.181079
# Unit test for function should_remove_dist
def test_should_remove_dist():
    test_case_0()

# Generated at 2022-06-26 01:08:41.251967
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-26 01:08:44.122079
# Unit test for function should_remove_dist
def test_should_remove_dist():
    print("----- Testing should_remove_dist() -----")
    test_0 = should_remove_dist()
    assert test_0 == True, "Test 0 failed!"
    print("All tests passed!")


# Generated at 2022-06-26 01:08:45.877025
# Unit test for function should_build
def test_should_build():
    # Use command line parameters
    logger.debug("Test 0:")
    test_case_0()



# Generated at 2022-06-26 01:08:53.574726
# Unit test for function should_build

# Generated at 2022-06-26 01:09:00.223328
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["build_command"] = "echo"
    config["upload_to_release"] = True
    config["upload_to_pypi"] = True
    config["remove_dist"] = True
    assert should_remove_dist() == True

    config["remove_dist"] = False
    assert should_remove_dist() == False

    config["upload_to_release"] = False
    assert should_remove_dist() == False

    config["upload_to_pypi"] = False
    assert should_remove_dist() == False

    config["build_command"] = "false"
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:09:01.555090
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == False

# Generated at 2022-06-26 01:09:05.615545
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # case 1: remove_dist = true, should_build = true: True
    config.data["remove_dist"] = True
    assert should_remove_dist()
    # case 2: remove_dist = false, should_build = true: False
    config.data["remove_dist"] = False
    assert not should_remove_dist()
