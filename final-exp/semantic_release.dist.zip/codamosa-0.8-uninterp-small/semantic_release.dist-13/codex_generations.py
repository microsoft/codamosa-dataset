

# Generated at 2022-06-26 01:04:25.157070
# Unit test for function should_build
def test_should_build():
    assert(should_build() == False), "Should not build"
    config["upload_to_pypi"] = True
    config["build_command"] = "echo hello"
    assert(should_build() == True), "Should build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert(should_build() == True), "Should build"
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    config["build_command"] = False
    assert(should_build() == False), "Should not build"
    config["upload_to_pypi"] = True
    config["build_command"] = False
    assert(should_build() == False), "Should not build"



# Generated at 2022-06-26 01:04:33.387460
# Unit test for function should_build
def test_should_build():
    build_pypi_var0 = False
    build_release_var0 = False
    build_command_var0 = "python setup.py sdist bdist_wheel"
    result_var0 = should_build()

    build_pypi_var1 = True
    build_release_var1 = False
    build_command_var1 = "python setup.py sdist bdist_wheel"
    result_var1 = should_build()

    build_pypi_var2 = False
    build_release_var2 = True
    build_command_var2 = "python setup.py sdist bdist_wheel"
    result_var2 = should_build()

    build_pypi_var3 = True
    build_release_var3 = True

# Generated at 2022-06-26 01:04:34.453541
# Unit test for function should_remove_dist
def test_should_remove_dist():
    var_0 = should_remove_dist()



# Generated at 2022-06-26 01:04:35.271163
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True

# Generated at 2022-06-26 01:04:36.039141
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()



# Generated at 2022-06-26 01:04:37.067416
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-26 01:04:44.902957
# Unit test for function should_build
def test_should_build():
    config = {}
    config["build_command"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = False
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    assert should_build() == True
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert should_build() == False
    config["build_command"] = False
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    assert should_build() == False


# Generated at 2022-06-26 01:04:45.869173
# Unit test for function should_build
def test_should_build():
    assert not should_build()



# Generated at 2022-06-26 01:04:46.751562
# Unit test for function should_remove_dist
def test_should_remove_dist():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 01:04:49.638497
# Unit test for function should_build
def test_should_build():
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "ls"
    config["remove_dist"] = False
    assert should_build()



# Generated at 2022-06-26 01:06:52.724821
# Unit test for function should_build
def test_should_build():
    # Case 1:
    # upload pypi = true
    # upload release = true
    # build command = true
    assert should_build() == True



# Generated at 2022-06-26 01:06:53.339756
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert(should_remove_dist() == should_build())

# Generated at 2022-06-26 01:06:53.942449
# Unit test for function should_build
def test_should_build():
    assert should_build() is True


# Generated at 2022-06-26 01:06:54.702627
# Unit test for function should_build
def test_should_build():
    assert should_build() == False


# Generated at 2022-06-26 01:06:56.090547
# Unit test for function should_remove_dist
def test_should_remove_dist():
    """is True if remove_dist config is True"""
    config.set(remove_dist=True)
    assert should_remove_dist()



# Generated at 2022-06-26 01:07:01.185479
# Unit test for function should_build
def test_should_build():
    #test case 1: upload_pypi is false
    config.set('upload_to_pypi', False)
    config.set('upload_to_release', True)
    config.set('build_command', True)
    logger.info("running test case 1: upload_pypi is false")
    assert should_build()
    #test case 2: upload_pypi is empty
    config.set('upload_to_pypi', '')
    logger.info("running test case 2: upload_pypi is empty")
    assert not should_build()
    #test case 3: upload_pypi is true
    config.set('upload_to_pypi', True)
    logger.info("running test case 3: upload_pypi is true")
    assert should_build()


# Unit test

# Generated at 2022-06-26 01:07:01.799850
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()==True

# Generated at 2022-06-26 01:07:02.794666
# Unit test for function should_build
def test_should_build():
    assert should_build() == False



# Generated at 2022-06-26 01:07:04.405102
# Unit test for function should_build
def test_should_build():
    assert should_build() == True


# Generated at 2022-06-26 01:07:05.144503
# Unit test for function should_build
def test_should_build():
    test_case_0()

# Generated at 2022-06-26 01:09:10.542884
# Unit test for function should_remove_dist
def test_should_remove_dist():
    config["remove_dist"] = True
    config["upload_to_pypi"] = True
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = False
    assert not should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_pypi"] = False
    config["upload_to_release"] = True
    config["build_command"] = "python setup.py sdist"
    assert not should_remove_dist()

    config["remove_dist"] = False
    config["upload_to_pypi"] = True

# Generated at 2022-06-26 01:09:11.654201
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist() == True


# Generated at 2022-06-26 01:09:12.436878
# Unit test for function should_build
def test_should_build():
    assert (should_build_utils() == should_build())

# Generated at 2022-06-26 01:09:13.195525
# Unit test for function should_build
def test_should_build():
    assert should_build()


# Generated at 2022-06-26 01:09:19.215480
# Unit test for function should_build
def test_should_build():
    # Test case 0
    print("\nTest case 0:")
    var_0 = config.get("upload_to_pypi")
    print(var_0)
    var_1 = config.get("upload_to_release")
    print(var_1)
    var_2 = config.get("build_command")
    print(var_2)
    print(f"Expected {var_0}")
    test_case_0()
    assert var_0 == True

    var_0 = config.get("upload_to_pypi")
    print(var_0)
    var_1 = config.get("upload_to_release")
    print(var_1)
    var_2 = config.get("build_command")
    print(var_2)

# Generated at 2022-06-26 01:09:21.088702
# Unit test for function should_build
def test_should_build():
    config.set("upload_to_pypi", None)
    config.set("upload_to_release", None)
    config.set("build_command", None)
    assert should_build() is False


# Generated at 2022-06-26 01:09:21.654530
# Unit test for function should_build
def test_should_build():
    assert should_build() == True

# Generated at 2022-06-26 01:09:22.995311
# Unit test for function should_remove_dist
def test_should_remove_dist():
    case_0 = config.get("remove_dist") is True and True
    assert should_remove_dist() == case_0



# Generated at 2022-06-26 01:09:26.572792
# Unit test for function should_remove_dist
def test_should_remove_dist():
    print("unit test for should_remove_dist")
    var_0 = config.get("remove_dist")
    var_1 = should_build()
    var_2 = should_remove_dist()
    assert var_0 and var_1 == var_2

# Generated at 2022-06-26 01:09:27.316824
# Unit test for function should_remove_dist
def test_should_remove_dist():
    assert should_remove_dist()

