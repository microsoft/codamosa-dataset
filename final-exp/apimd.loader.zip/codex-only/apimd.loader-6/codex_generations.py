

# Generated at 2022-06-23 15:19:46.349597
# Unit test for function loader
def test_loader():
    from collections import MutableMapping
    from .parser import block_parser

    def class_exists(name: str) -> bool:
        try:
            eval(name)
        except NameError:
            return False
        else:
            return True

    def method_exists(name: str) -> bool:
        try:
            eval(name)
        except (NameError, AttributeError):
            return False
        else:
            return True

    class_exists('MutableMapping')
    # True
    method_exists('MutableMapping.clear')
    # True

    # Class name
    # MutableMapping

    # Method name
    # MutableMapping.__setitem__

    # Function name
    # block_parser

    # Variable name
    # MutableMapping.__iter__



# Generated at 2022-06-23 15:19:57.687368
# Unit test for function walk_packages
def test_walk_packages():
    from collections import defaultdict
    from tempfile import TemporaryDirectory
    from shutil import copyfileobj
    from zipfile import ZipFile
    from io import BytesIO

    def create_package(name: str, pkg_dict: dict[str, str]) -> str:
        """Create package in zip file."""
        with TemporaryDirectory() as tmp:
            for path, code in pkg_dict.items():
                file = join(tmp, path)
                mkdir(dirname(join(tmp, path)))
                with open(file, 'w+') as f:
                    f.write(code)
            zip = BytesIO()
            with ZipFile(zip, 'w') as f:
                for r, _, fs in walk(tmp):
                    for f in fs:
                        fp = join(r, f)
                        f

# Generated at 2022-06-23 15:20:05.093046
# Unit test for function walk_packages
def test_walk_packages():
    """Tests."""
    from pkgutil import walk_packages
    import numpy as np
    from sympy import sympify, Or, Expr


# Generated at 2022-06-23 15:20:13.737333
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from unittest.mock import patch, Mock
    spec1 = Mock(spec=spec_from_file_location)
    spec2 = Mock(spec=spec_from_file_location)
    spec1.loader = Mock(spec=Loader)
    spec2.loader = Mock(spec=Loader)
    # Load root first
    with patch("importlib.util.find_spec", return_value=spec1):
        with patch("importlib.machinery.EXTENSION_SUFFIXES", ('.exe',)):
            assert loader("test", "", True, 1, True) == ""

# Generated at 2022-06-23 15:20:19.581721
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    with TemporaryDirectory() as d:
        for mod, f in [
            ("root.a", "a.py"),
            ("root.a.b", "b.py"),
            ("root.c", "c.pyi"),
            ("root.d", "d.pyi"),
        ]:
            p = join(d, *mod.split("."))
            if not isdir(p):
                mkdir(p)
            s = [
                "'''",
                f"{mod}",
                "'''",
                "def main(a: int) -> None:",
                "\tpass",
            ]
            _write(join(p, f), "\n".join(s))


# Generated at 2022-06-23 15:20:25.071003
# Unit test for function loader
def test_loader():
    """Test unit."""
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import makedirs

    class Test(TestCase):
        """Test."""

        def test_load(self):
            """Test load."""
            with TemporaryDirectory() as td:
                d = join(td, "foo")
                copytree("tests/loader_test_data/foo", d)
                loader("bar", td, False, 1, False)

                d = join(td, "baz")
                makedirs(d)
                f = join(d, "__init__.py")
                with open(f, 'w') as f:
                    f.write("print('Hello')\n")
                f = join(d, "baz.py")
               

# Generated at 2022-06-23 15:20:30.418044
# Unit test for function gen_api
def test_gen_api():
    roots = {
        'Pyslvs': 'pyslvs',
        'Pyslvs UI': 'pyslvs_ui',
    }
    docs = gen_api(roots, dirname(__file__), prefix='test', dry=True)
    assert len(docs) == len(roots)

# Generated at 2022-06-23 15:20:33.623468
# Unit test for function gen_api
def test_gen_api():
    from shutil import rmtree

    with open('tmp.py', 'w') as f:
        f.write('a = 1\ndef f(x: int, y: int = 1) -> None:\n    pass\n')
    with open('tmp.pyi', 'w') as f:
        f.write('class A:\n    def __init__(self) -> None:\n        pass')
    assert len(gen_api({'API': 'tmp'}, pwd='.')) == 2
    rmtree('docs')
    rmtree('tmp.pyi')
    rmtree('tmp.py')

# Generated at 2022-06-23 15:20:41.253879
# Unit test for function loader
def test_loader():
    from unittest import TestCase
    p = TestCase()
    p.assertEqual(
        loader('pyslvs', './pyslvs', False, 1, False).strip(),
        ''
    )
    p.assertGreater(
        len(loader('pyslvs', './pyslvs', False, 1, False).strip()),
        10
    )
    p.assertGreater(
        len(loader('pyslvs', './pyslvs', True, 1, False).strip()),
        20
    )


# Generated at 2022-06-23 15:20:42.440425
# Unit test for function gen_api
def test_gen_api():
    gen_api({"Vpython", "vp"})

# Generated at 2022-06-23 15:20:52.995484
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, True)
    p.parse('container', '"""container"""')
    p.parse('container.abc', '"""abc"""')
    p.parse('container.abc.def', '"""abc.def"""')
    assert p.compile()[0] == """# container

container

"""

    for name, path in walk_packages('test_package', './test_package'):
        p.parse(name, _read(path))
    assert p.compile() == """- [test_package](test_package.md)
    - [test_package.abc](test_package.abc.md)
    - [test_package.abc.def_](test_package.abc.def.md)

"""

# Generated at 2022-06-23 15:20:58.717104
# Unit test for function walk_packages
def test_walk_packages():
    """Check the walk_packages function."""
    def gen_pwd(target: str, pwd: str) -> str:
        while True:
            if target == pwd:
                return pwd
            pwd = parent(pwd)
        raise RuntimeError("Incorrect path or package name")

    for name, path in walk_packages("numpy", gen_pwd("numpy", __file__)):
        print(name, path)

# Generated at 2022-06-23 15:21:05.069870
# Unit test for function loader
def test_loader():
    """Test case for function loader."""
    import os
    import pslvs_synthesis
    pwd = abspath(pslvs_synthesis.__file__)
    logger.info(f'== Run test case in {pwd} ==')
    logger.info(loader(
        'synthesis',
        pwd,
        True,
        3,
        False,
    ))



# Generated at 2022-06-23 15:21:12.983858
# Unit test for function loader
def test_loader():
    import unittest
    import tempfile
    from os import sep
    from os.path import join
    class TestLoader(unittest.TestCase):
        def setUp(self) -> None:
            self.tmp = tempfile.TemporaryDirectory()
            self.root = self.tmp.name + sep
            mkdir(join(self.root, "pkg"))
            mkdir(join(self.root, "pkg", "pkg1"))
            mkdir(join(self.root, "pkg", "pkg2"))
            mkdir(join(self.root, "pkg", "pkg1", "pkg11"))
            with open(join(self.root, "pkg", "pkg1", "file1.py"), "w+") as f:
                f.write("def foo():\n    pass")

# Generated at 2022-06-23 15:21:17.508417
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({'numpy': 'numpy', 'matplotlib': 'matplotlib'}, '.', dry=True)
    assert all(doc is not '' for doc in docs)



# Generated at 2022-06-23 15:21:24.004590
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from os import path
    from pkgutil import get_data

    root = 'pyslvs_ui'
    pwd = path.dirname(path.abspath(__file__))
    loader(root, pwd, True, 1, False)
    assert get_data(root, '__init__.py').startswith(
        b'"""The PySLVS core module."""'
    )


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:21:25.583901
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({
        "Pyslvs": "pyslvs"
    })

# Generated at 2022-06-23 15:21:36.743953
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages"""
    import os
    import sys
    import zipfile
    from tempfile import TemporaryDirectory

    def _package_path(path: str) -> str:
        """Generate the package path by the file name."""
        if not path.startswith('package'):
            return path
        return 'package' + path.replace('.', os.sep) + '.py'

    def _test_api(name: str):
        """Test the package path."""
        spec = find_spec(name)
        assert spec is not None, f"can not find module: {name}"
        assert isinstance(spec.origin, str), f"invalid origin: {spec.origin}"
        assert isfile(spec.origin), f"{spec.origin} is not a file"


# Generated at 2022-06-23 15:21:46.144431
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    s = """
    class Hello:
        \"\"\"
        class description
        \"\"\"
        def __init__(self, age: int = 0):
            \"\"\"
            init description
            \"\"\"
        def he(self) -> None:
            \"\"\"
            method docstring
            \"\"\"
    def world(name: str = 'World') -> str:
        \"\"\"
        function docstring
        \"\"\"
        return Hello().he() + ' ' + name
    """
    p = Parser.new()
    p.parse("test", s)

# Generated at 2022-06-23 15:21:49.078497
# Unit test for function gen_api
def test_gen_api():
    assert isinstance(gen_api({'title': 'name'}), list)
    assert isinstance(gen_api({'title': 'name'}, dry=True), list)

# Generated at 2022-06-23 15:21:53.747550
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from pyslvs import __version__
    from .__main__ import root_names
    from .main import install_path
    r = gen_api(root_names, install_path)
    assert len(r) > 0
    assert f"pyslvs {__version__}" in r[0]

# Generated at 2022-06-23 15:21:55.820742
# Unit test for function loader
def test_loader():
    loader('pyslvs', abspath(join(dirname(__file__), '..')))

# Generated at 2022-06-23 15:21:59.879196
# Unit test for function gen_api
def test_gen_api():
    # type: () -> None
    """Unit test for function gen_api."""
    assert gen_api({}) is None
    assert gen_api({'test_gen_api': 'tests.gen_api'}, dry=True)

# Generated at 2022-06-23 15:22:06.489535
# Unit test for function loader
def test_loader():
    from pathlib import Path
    from .project import projects
    from .logger import Config
    Config.log_level = 30
    root_names = {
        "Docs": "docs",
        "Bolt": "bolt",
        "LINK": "link",
        "Solver": "solver",
        "SVGEdit": "svg_edit",
        "Pyslvs": "core",
    }
    pwd = str(Path(__file__).with_name("project").absolute())
    gen_api(root_names, pwd)
    gen_api(projects, pwd, dry=True)

# Generated at 2022-06-23 15:22:17.684618
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .parser_text import text
    from .parser_html import html
    from .parser_markdown import markdown

    def _test(
        p: Parser,
        link: bool,
        level: int,
        toc: bool,
        *,
        first_line: str = '',
        suffix: Optional[str] = None
    ) -> None:
        """Compare markdown text with its source."""
        text = p.compile(first_line, suffix).strip()
        html = p.compile(first_line, suffix, html).strip()
        markdown = p.compile(first_line, suffix, markdown).strip()
        # First line
        if first_line:
            assert text.startswith(first_line)
            assert html.startsw

# Generated at 2022-06-23 15:22:23.285541
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    try:
        import pyslvs
        assert isdir(join(dirname(pyslvs.__file__), 'docs'))
    except ImportError:
        pass


if __name__ == "__main__":
    from sys import argv, stderr, exit
    from .option import parser, opts
    from .__init__ import __version__
    args = parser.parse_args(argv[1:])
    if args.version:
        print(__version__)
        exit()
    if 'logger' in args and args.logger is not None:
        logger.setLevel(args.logger.upper())
        logger.addHandler(stderr)
    prefix = join(opts.source, 'docs')

# Generated at 2022-06-23 15:22:31.154675
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os.path import dirname
    from os import chdir, mkdir
    from .util import PkgInfo
    with TemporaryDirectory() as tmp:
        chdir(tmp)
        for i in range(10):
            mkdir(f"test-{i}")
            mkdir(f"test-{i}/sub")
            mkdir(f"test-{i}/sub/subsub")
            with open(f"test-{i}/__init__.py", 'w+') as f:
                f.write("# __init__.py")

# Generated at 2022-06-23 15:22:34.630619
# Unit test for function walk_packages
def test_walk_packages():
    """Test case for function walk_packages."""
    for name, path in walk_packages("pyslvs", "pyslvs"):
        print(name, path)

if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-23 15:22:39.659988
# Unit test for function gen_api
def test_gen_api():
    d = gen_api({"Cython": "Cython", "PyQuantum": "pq"}, "../site-packages")
    if d:
        pq = False
        for i in d:
            if "PyQuantum API" in i:
                pq = True
        assert pq
    else:
        raise RuntimeError("Unable to read test file")

# Generated at 2022-06-23 15:22:41.964195
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    assert gen_api({
        'TEST': 'TEST',
        'TEST2': 'TEST2',
    }, '.', dry=True)

# Generated at 2022-06-23 15:22:44.789966
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader('numpy', 'tests/tests', False, 2, False)
    assert 'numpy.ndarray' in doc


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:22:48.385131
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('pyslvs', 'pyslvs'):
        print(name)
        print(path)
    assert name == 'pyslvs.optimization.scipy.qps'
    assert path.endswith(sep.join(['..', 'pyslvs', 'optimization', 'scipy', 'qps.py']))

# Generated at 2022-06-23 15:22:49.712224
# Unit test for function gen_api
def test_gen_api():
    """Test the function gen_api."""
    assert gen_api({"Solver": "solver"})

# Generated at 2022-06-23 15:22:59.266672
# Unit test for function gen_api
def test_gen_api():
    """Test the gen_api function."""
    import sys
    import os
    import shutil
    os.environ['PYSLVS_CLEAN_ENV'] = '1'
    from . import pkg_info
    from .logger import init_logger
    from .path import get_current_path
    from .compiler import gen_api

    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
    }
    pwd = get_current_path()
    prefix = 'docs/api'
    if isdir(prefix):
        shutil.rmtree(prefix)
    sys.argv = sys.argv[:1]
    sys.argv.extend(['--quiet'])
   

# Generated at 2022-06-23 15:23:07.848662
# Unit test for function gen_api
def test_gen_api():
    from sys import stderr
    from io import StringIO
    from .logger import logger
    from .common import test_path
    name = 'api_test_case'
    root_names = {'Test Case': name}
    stderr = StringIO()
    logger.stream = stderr
    gen_api(root_names, pwd=test_path, prefix='docs', link=True, level=1, toc=True)
    logger.stream = stderr
    log_txt = stderr.getvalue()
    print(log_txt)
    assert name in log_txt
    assert 'create directory' in log_txt.lower()
    assert 'write file' in log_txt.lower()

# Generated at 2022-06-23 15:23:17.668326
# Unit test for function walk_packages
def test_walk_packages():
    logger.info('test_walk_packages')
    from tempfile import mkdtemp
    from os import remove, walk
    from os.path import dirname

    def _touch(path: str) -> str:
        with open(path, 'w') as f:
            f.write(path)
        return path

    # Generate temporary directory
    temp_dir = mkdtemp()
    logger.debug(f"Create temporary directory: {temp_dir}")
    # Create dummy files
    file_list = [
        _touch(f"{temp_dir}{sep}{i}.py")
        for i in range(3)
    ]

# Generated at 2022-06-23 15:23:29.946836
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    import io
    from .logger import setup_logger, VERBOSE
    from .parser import Parser
    from pyslvs import __version__, __path__ as PYSLVS_PATH
    from ..__pkginfo__ import PYSOLVESPACE_PATH
    from ..core import __path__ as CORE_PATH
    from ..core.core import v1 as core_v1
    from ..core.core import v2 as core_v2
    from ..core.core import v3 as core_v3
    from ..core.core import v4 as core_v4
    from ..core.core import v5 as core_v5
    from ..core.constraints import v1 as constraints_v1
    from ..core.constraints import v2 as constraints_v

# Generated at 2022-06-23 15:23:35.683151
# Unit test for function gen_api
def test_gen_api():
    import unittest
    from .test_compiler import test_pyslvs as root_names

    class Test(unittest.TestCase):

        def test_gen_api(self):
            docs = gen_api(root_names, dry=True)
            self.assertEqual(len(docs), 2)

    unittest.main()

# Generated at 2022-06-23 15:23:42.860197
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from pyslvs_ui.package.compiler import walk_packages

    for name, path in walk_packages('pyslvs', '/tmp/site-packages'):
        assert isinstance(name, str)
        assert isinstance(path, str)

    with patch('pyslvs_ui.package.compiler.find_spec') as mock_find_spec:
        mock_find_spec.return_value = MagicMock()
        mock_find_spec.return_value.submodule_search_locations = None
        assert list(walk_packages('pyslvs', '/tmp/site-packages')) == []

# Generated at 2022-06-23 15:23:52.892128
# Unit test for function loader
def test_loader():
    from .test_compiler import test_package
    import sys
    import textwrap
    from contextlib import redirect_stdout
    from io import StringIO
    from tempfile import TemporaryDirectory
    from importlib import import_module
    from .logger import logger

    path = join(dirname(__file__), 'mock')
    if test_package not in sys.path:
        sys.path.append(test_package)
    if path not in sys.path:
        sys.path.append(path)

    with TemporaryDirectory() as pwd:
        with redirect_stdout(StringIO()):
            gen_api({'Site Package': 'test'}, pwd, dry=True)

        with redirect_stdout(StringIO()):
            gen_api({'Test': 'test'}, pwd, dry=True)



# Generated at 2022-06-23 15:24:02.538420
# Unit test for function gen_api
def test_gen_api():
    class FakePkgutilGetsitepackages:
        def return_value(self, _):
            return ['site-packages']
    import unittest
    import sys
    import tempfile

# Generated at 2022-06-23 15:24:05.656714
# Unit test for function gen_api
def test_gen_api():
    """Testcase"""
    sys_path.append(_site_path("numpy"))
    doc = loader("numpy", _site_path("numpy"), link=False, level=2, toc=True)
    logger.info(doc)
    assert doc

# Generated at 2022-06-23 15:24:17.350121
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'Test': 'test'}, '.', prefix='', dry=True)
    assert gen_api({'Test': 'test'}, '.', prefix='', level=2, dry=True)
    assert gen_api({'Test': 'test'}, '.', prefix='', level=2, toc=True, dry=True)


if __name__ == "__main__":

    def main():
        """Main function."""
        import argparse
        parser = argparse.ArgumentParser('gen')
        parser.add_argument(
            '--output',
            '-o',
            dest='prefix',
            default='docs',
            help="The prefix of output file name."
        )

# Generated at 2022-06-23 15:24:22.134532
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api"""
    doc = gen_api({"Pyslvs", "pyslvs"}, dry=True)
    assert doc is not None and isinstance(doc, list) and doc[0] is not None
    logger.info(f"{__name__} passed")


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:24:33.598418
# Unit test for function walk_packages
def test_walk_packages():
    from .test_package import foo, bar, baz
    from .test_pkg import Foo, Bar
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.tmpdir = TemporaryDirectory()

        def tearDown(self):
            self.tmpdir.cleanup()

        def test_walk_packages(self):
            # Rename
            path = join(self.tmpdir.name, 'package', 'foo.py')
            mkdir(dirname(path))
            _write(path, _read(abs(foo)))
            path = join(self.tmpdir.name, 'package', 'bar.pyi')
            _write(path, _read(abs(bar)))

# Generated at 2022-06-23 15:24:36.745503
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs", ".."):
        print(name)
        print(path)

# Generated at 2022-06-23 15:24:47.703095
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import unittest
    import pyslvs

    class Namespace:
        ...

    class TestWalkPackages(unittest.TestCase):

        def setUp(self):
            self.maxDiff = sys.maxsize
            self.names = set()
            self.paths = set()
            self.sys_path = sys.path[:]
            sys.path.append(pyslvs.__path__[0])

        def tearDown(self):
            sys.path.clear()
            sys.path.extend(self.sys_path)

        def test_walk_packages(self):
            for name, path in walk_packages('pyslvs', pyslvs.__path__[0]):
                self.names.add(name)
                self.paths.add(path)

# Generated at 2022-06-23 15:24:49.008695
# Unit test for function loader
def test_loader():
    assert len(gen_api({'title': 'name'})) == 1

# Generated at 2022-06-23 15:25:01.304934
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from os.path import isdir
    data = [
        ('x/a.py', 'x/a.py')
        , ('x/a.pyi', 'x/a.pyi')
        , ('x/a.pyi', 'x/a.py')
        , ('x/__init__.py', 'x')
        , ('x/__init__.pyi', 'x')
        , ('x/__init__.py', 'x/__init__.py')
        , ('x/__init__.pyi', 'x/__init__.pyi')
    ]
    for dn, fn in data:
        makedirs(dn, exist_ok=True)
        with open(fn, 'w') as f:
            f.write('')
   

# Generated at 2022-06-23 15:25:07.047445
# Unit test for function gen_api
def test_gen_api():
    from os import getcwd
    from sys import path as sys_path
    from shutil import rmtree
    sys_path.append(getcwd())
    try:
        gen_api({'test': 'test'}, rmtree('test'))
    except FileNotFoundError:
        pass
    gen_api({'test': 'test'}, 'test', dry=True)


# Generated at 2022-06-23 15:25:12.414851
# Unit test for function gen_api
def test_gen_api():
    root_names = {"Pyslvs": "pyslvs"}
    pwd = "/home/yuan-chang/Projects/Pyslvs/pyslvs"
    docs = gen_api(root_names, pwd, dry=True)
    print(docs)
    assert len(docs) == 1
    assert isinstance(docs[0], str)

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:25:17.616010
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    try:
        import pyslvs
    except ImportError:
        logger.warning("Install pyslvs first to run tests.")
        return
    gen_api({
        "PySLVS": "pyslvs",
        "PySLVS-UI": "pyslvs_ui",
        "SLVS-EC": "slvs",
    }, dry=True)

# Generated at 2022-06-23 15:25:23.277835
# Unit test for function gen_api
def test_gen_api():
    names = {"Solver": "pyslvs", "UI": "pyslvs_ui"}
    docs = gen_api(names, link=False, dry=True)
    assert isinstance(docs, list)
    for d in docs:
        if d.startswith("#"):
            assert "Solver API" in d or "UI API" in d
        else:
            assert "####" in d

# Generated at 2022-06-23 15:25:26.304269
# Unit test for function loader
def test_loader():
    import sys
    import doctest
    sys.path.append('.')
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:25:37.593596
# Unit test for function loader
def test_loader():
    from ..__main__ import cache_path

    class Default(dict):
        """Dictionary default value."""
        def __missing__(self, key):
            return key

    result_dict: Default[str, str] = Default()
    root_name = 'pyslvs'
    result_dict['pyslvs-api.md'] = loader(root_name, _site_path(root_name), True, 1, False)
    root_name = 'e2system'
    result_dict['e2system-api.md'] = loader(root_name, _site_path(root_name), True, 1, False)
    root_name = 'algorithm'
    result_dict['algorithm-api.md'] = loader(root_name, _site_path(root_name), True, 1, False)
   

# Generated at 2022-06-23 15:25:40.238442
# Unit test for function loader
def test_loader():
    root_names = {
        "ROS": "ros",
        "ROSPy": "rospy",
    }
    gen_api(root_names)

# Generated at 2022-06-23 15:25:46.703832
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({"pyslvs": "pyslvs"}, dry=True)
    assert len(docs) == 1
    assert "Python Structural Vibration Solver" in docs[0]
    assert "## Attributes" in docs[0]
    assert "## Classes" in docs[0]
    assert "## Functions" in docs[0]



# Generated at 2022-06-23 15:25:50.248727
# Unit test for function loader
def test_loader():
    """Loader should be able to be tested."""
    assert loader('asdf', '.', False, 1, False) == ""
    assert loader('pyslvs', '.', False, 1, False)[:10] == "## QVariant"


# Generated at 2022-06-23 15:25:51.250100
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []


# Generated at 2022-06-23 15:25:53.670067
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api"""
    gen_api({'example': 'example'}, '../docs/', dry=True)

# Generated at 2022-06-23 15:25:57.150161
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    assert loader('', '', False, 1, False) == ''
    assert loader('', '', True, 1, False) == ''

# Generated at 2022-06-23 15:26:04.695095
# Unit test for function walk_packages
def test_walk_packages():
    def func(name: str, path: str) -> Iterator[tuple[str, str]]:
        yield from ((n, p) for n, p in walk_packages(name, path)
                    if 'site-packages' not in p)
    assert list(func('pyslvs', 'pyslvs'))
    assert list(func('solve_v2', 'solve_v2'))
    assert list(func('py_vtk_visual', 'py_vtk_visual'))
    assert list(func('viewer_data', 'viewer_data'))

# Generated at 2022-06-23 15:26:06.907235
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('compiler', 'compiler'))
    assert list(walk_packages('pyslvs', '..'))

# Generated at 2022-06-23 15:26:13.921765
# Unit test for function gen_api
def test_gen_api():
    from os import getcwd
    import sys

    # pyslvs/ is root directory for testing
    sys_path.append(getcwd() + '../')
    args = {
        "root_names": {"pyslvs": "pyslvs", "pyslvs_ui": "pyslvs_ui"},
        "prefix": 'docs/API',
        "level": 1,
    }
    gen_api(**args)

# Generated at 2022-06-23 15:26:24.836681
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path
    from sys import path as sys_path
    from numpy import sum, sum as csum
    from numpy.linalg import norm
    from .test_all import module_test
    from .parser import normalize_doc

    root_names = {
        'numpy': 'numpy',
        'cvxopt': 'cvxopt',
        'Cython': 'Cython',
    }
    tmp_dir = mkdtemp()
    sys_path.append(tmp_dir)

    def _write_file(name: str, content: str) -> None:
        with open(path.join(tmp_dir, f'{name}.py'), 'w') as f:
            f.write(content)

    _write_

# Generated at 2022-06-23 15:26:33.682767
# Unit test for function walk_packages
def test_walk_packages():
    from .utils import temp_dir
    with temp_dir() as p:
        with open('__init__.py', 'w+') as f:
            f.write('# This is a package')
        with open('a.py', 'w+') as f:
            f.write('def func():\n    pass')
        with open('b.pyi', 'w+') as f:
            f.write('def func(): ...')
        with open('c.py', 'w+') as f:
            f.write('from .a import func')
        with open('d.py', 'w+') as f:
            f.write('from .c import func')

# Generated at 2022-06-23 15:26:41.526096
# Unit test for function loader
def test_loader():
    import sys
    import os.path
    import pkgutil
    import pyslvs_ui
    import pyslvs_ui.info
    cwd = os.path.dirname(os.path.abspath(pkgutil.__file__))
    sys.path.append(cwd)
    print(loader(
        "pyslvs_ui", cwd, True, 1, False
    ))
    assert pyslvs_ui.info.__doc__.strip().startswith("Solver service system.")
    sys.path.pop()


if __name__ == "__main__":
    print(gen_api({"Core": "pyslvs_core"}, ".stubs-cache"))

# Generated at 2022-06-23 15:26:49.924276
# Unit test for function walk_packages
def test_walk_packages():
    """Test package walker."""
    # mkdir('test')
    # _write(join('test', '__init__.py'), 'name = "test"')
    # _write(join('test', 'a.py'), "# a documentation")
    # _write(join('test', 'b.py'), "# b documentation")
    # _write(join('test', 'c.py'), "# c documentation")
    # _write(join('test', 'd.pyi'), "# d documentation")
    count = 0
    for name, f_path in walk_packages('test', 'test'):
        count += 1
        logger.debug(f'{name}: {f_path}')
    assert count == 4

# Generated at 2022-06-23 15:27:00.452744
# Unit test for function walk_packages
def test_walk_packages():
    def path_n(n: int, name: str = '') -> str:
        return '.'.join(['pyslvs_ui', *['c' + str(i) for i in range(n)], name])

    def p1(loc: str) -> str:
        return '.'.join([path_n(1), loc])

    def p2(loc: str) -> str:
        return '.'.join([path_n(2), loc])

    def p4(loc: str) -> str:
        return '.'.join([path_n(4), loc])


# Generated at 2022-06-23 15:27:02.893249
# Unit test for function gen_api
def test_gen_api():
    root_names = {'QuickGraph': 'qglwk'}
    pwd = '.'
    gen_api(root_names, pwd)
test_gen_api()

# Generated at 2022-06-23 15:27:08.257664
# Unit test for function loader
def test_loader():
    """pytest-like test."""
    # pylint: disable=import-outside-toplevel
    import pyslvs as psl

    # Import here to avoid local import error
    assert psl.__package__ == "pyslvs"
    assert psl.__version__ == "19.3.11"
    doc = Parser.new(False, 0, False).compile()
    assert "pyslvs" in doc


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:27:14.244424
# Unit test for function walk_packages
def test_walk_packages():
    """Test `walk_packages`."""
    from pytest import raises

    with raises(FileNotFoundError):
        list(walk_packages("not a package", "."))

    with raises(NotADirectoryError):
        list(walk_packages("pp.test.test", "not a dir"))

    paths = list(walk_packages("pp", "."))
    assert len(paths) == 2
    assert paths[0][0] == 'pp.__main__'
    assert paths[0][1].endswith('pp/__main__.py')
    assert paths[1][0] == 'pp.misc'
    assert paths[1][1].endswith('pp/misc.py')

# Generated at 2022-06-23 15:27:14.938896
# Unit test for function loader
def test_loader():
    """Test function loader"""

# Generated at 2022-06-23 15:27:22.288520
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    # import sys
    # sys.path.append("/Library/Python/3.7/site-packages")
    # import pyslvs
    docs = gen_api({'pyslvs': 'pyslvs'}, "/Library/Python/3.7/site-packages")
    assert len(docs) == 1
    docs = gen_api({'pyslvs': 'pyslvs'}, "/Library/Python/3.7/site-packages", dry=True)
    assert len(docs) == 1
    assert len(docs[0].strip()) > 0

# Generated at 2022-06-23 15:27:25.918011
# Unit test for function loader
def test_loader():
    """Test for function loader()."""
    p = Parser.new(True, 1)
    for name, path in walk_packages('pyslvs', dirname(__file__)):
        print(name, path)
        p.parse(name, _read(path + '.py'))
    print(p.compile())


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:27:37.240625
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function `walk_packages`."""
    def _print(r):
        """Print the result."""
        for n, p in r:
            print(f"{n} <= {p}")
        print()

    r = list(walk_packages('quaternion', 'quaternion'))
    _print(r)
    assert len(r) == 4
    r = list(walk_packages('pyslvs', 'pyslvs'))
    _print(r)
    assert len(r) == 32
    r = list(walk_packages('pyslvs_ui', 'pyslvs_ui'))
    _print(r)
    assert len(r) == 9

# Generated at 2022-06-23 15:27:48.228278
# Unit test for function loader
def test_loader():
    import unittest, shutil, os
    from tempfile import TemporaryDirectory
    from pathlib import Path

    class TestLoader(unittest.TestCase):

        def setUp(self) -> None:
            """Generate temporary directories."""
            self.s = TemporaryDirectory()
            self.d = os.path.join(self.s.name, 'site-packages')
            os.mkdir(self.d)
            os.chdir(self.s.name)

        def tearDown(self) -> None:
            """Clear temporary directories."""
            self.s.cleanup()

        def test_site_path(self) -> None:
            os.mkdir(os.path.join(self.d, 'py_xxx'))
            self.assertEqual(_site_path('py_xxx'), '')
           

# Generated at 2022-06-23 15:27:50.445937
# Unit test for function walk_packages
def test_walk_packages():
    from .syspath import test_path
    for name, path in walk_packages('map_generator', test_path):
        print(name, path)



# Generated at 2022-06-23 15:28:02.495674
# Unit test for function loader
def test_loader():
    from tempfile import mkdtemp
    from shutil import copytree
    from unittest.mock import patch

    # The directory path that provided to `pkgutil`
    pwd = mkdtemp()

# Generated at 2022-06-23 15:28:11.711094
# Unit test for function loader
def test_loader():
    assert _read("tests/test_compiler/__init__.py") == "\"\"\"Hello World.\"\"\"\n"
    assert _read("tests/test_compiler/test1.pyi") == "\"\"\"Test 1\"\"\"\n"
    assert _read("tests/test_compiler/test2.pyi") == "\"\"\"Test 2\"\"\"\n"
    assert _load_module("example", "tests/test_compiler/example.pyi", Parser.new(True, 1, False))

# Generated at 2022-06-23 15:28:16.892189
# Unit test for function loader
def test_loader():
    p = Parser.new(False, 1, False)
    assert _load_module("pyslvs", "pyslvs/__init__.py", p)
    assert "pyslvs" in p.doc_keys


# Generated at 2022-06-23 15:28:25.161198
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api.
    """
    from unittest.mock import patch, mock_open
    from pkgutil import get_importer
    from .__main__ import gen_api as ga
    assert isdir(ga.__name__) == False
    with patch('builtins.open', mock_open(read_data='aa\nbb\ncc\n'), create=True) as m:
        ga({"a": "b"}, ".", prefix="test")
    assert isdir(ga.__name__)
    
    
if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:28:34.634573
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    from os import chdir
    from shutil import copyfile
    from random import randint, choice
    from .fake_module import fake_module
    from .fake_import import fake_import
    from .fake_loader import fake_loader
    # Create the temp directory and go there
    with tempfile.TemporaryDirectory() as tempd:
        chdir(tempd)
        # Create the target
        with fake_loader():
            # Create the module
            with fake_module("test"):
                # Insert some text and import other file
                fake_import("test")
                # Create the target
                name = "test_root"
                with fake_loader():
                    # Create the module
                    with fake_module(name):
                        # Insert some text and import other file
                        fake_import(name)
        # Load

# Generated at 2022-06-23 15:28:37.948662
# Unit test for function loader
def test_loader():
    """Function loader test."""
    logger.debug("Function loader test:")
    logger.debug(loader("pyslvs", dirname(__file__), True, 1, False))


# Generated at 2022-06-23 15:28:45.803386
# Unit test for function gen_api
def test_gen_api():
    import os
    import pyslvs
    this_dir = os.path.abspath(os.path.dirname(__file__))
    root_names = {
        "pyslvs": "pyslvs",
        "Matplotlib 3D": "mpl_toolkits.mplot3d",
    }
    gen_api(root_names, this_dir)
    gen_api(root_names, this_dir, dry=True)

if __name__ == "__main__":
    print(__file__)
    test_gen_api()

# Generated at 2022-06-23 15:28:49.641387
# Unit test for function loader
def test_loader():
    from pkgutil import iter_modules
    p = Parser.new(False, 1, False)
    for name, _ in iter_modules():
        p.parse(name, '')
    doc = p.compile()
    print(doc)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:28:50.713908
# Unit test for function gen_api
def test_gen_api():
    assert len(gen_api({'test': 'test'}, pwd='.'))

# Generated at 2022-06-23 15:28:52.877534
# Unit test for function gen_api
def test_gen_api():
    docs = []
    for name in ['test', 'test2']:
        docs.append(loader(name, f"{name}-stubs", False, 1, False))
    assert len(docs) == 2



# Generated at 2022-06-23 15:29:05.027994
# Unit test for function gen_api
def test_gen_api():
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from os import path
    from pkg_resources import resource_filename
    from pyslvs import __version__
    from . import __file__ as ___file__

    root_names = {
        'pyslvs': 'pyslvs',
        'pyslvs_ui': 'pyslvs_ui',
    }
    pwd = resource_filename('pyslvs', '../')
    prefix = 'api'
    logger.info('=' * 12)
    logger.info(f"Version: {__version__}")
    with TemporaryDirectory() as temp:
        temp = path.abspath(temp)
        old_pwd = path.abspath(path.dirname(___file__))
        path.abspath

# Generated at 2022-06-23 15:29:09.313038
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    # Create a test package
    import tempfile
    from shutil import rmtree
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(join(temp_dir, 'pyslvs.py'), 'w') as f:
            f.write('def func() -> None:\n    pass')
        with open(join(temp_dir, 'pyslvs.pyi'), 'w') as f:
            f.write('def func() -> None: ...')
        with open(join(temp_dir, 'pyslvs-stubs.pyi'), 'w') as f:
            f.write('def func() -> None: ...')

# Generated at 2022-06-23 15:29:19.342597
# Unit test for function gen_api
def test_gen_api():
    from pytest import raises
    from tempfile import TemporaryDirectory
    from os.path import abspath, exists
    from os import rmdir
    with raises(FileNotFoundError, match="^[Nn]o such directory"):
        gen_api({"root": "sisl"}, pwd='sisl', dry=True)
    with TemporaryDirectory() as temp:
        d = abspath(temp)
        # Create a virtual package
        mkdir(join(d, 'sisl'))
        mkdir(join(d, 'sisl', 'geom'))
        mkdir(join(d, 'sisl', 'io'))
        _write(join(d, 'sisl', '__init__.py'), 'from .geom import *\nfrom .io import *')

# Generated at 2022-06-23 15:29:22.613653
# Unit test for function loader
def test_loader():
    """Test function loader."""
    s = loader(
        root="pyslvs",
        pwd="C:/Program Files/Python38/Lib/site-packages",
        link=False,
        level=1,
        toc=False
    )
    print(s)

# Generated at 2022-06-23 15:29:28.197676
# Unit test for function walk_packages
def test_walk_packages():
    def _test(name: str, path: str) -> None:
        for name, path in walk_packages(name, path):
            assert name.startswith(parent(name))
            assert isfile(path)

    _test("math", "D:\\Python\\Python39\\Lib")
    _test(".pyslvs_ui", "D:\\SVN\\SLVS\\SLVS\\SLVS\\ui")

# Generated at 2022-06-23 15:29:39.947499
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from .parser import Package

    def create_package(p_name: str, f_name: str) -> Package:
        def cut_ext(f: str) -> str:
            return basename(f).split('.')[0]
        return Package(p_name, p_name.replace('.', '_'), {cut_ext(f): '' for f in f_name})

    with TemporaryDirectory() as tmp_dir, TemporaryDirectory() as tmp_dir2:
        # Create package a
        mkdir(join(tmp_dir, 'a'))
        copyfile('test/test_data_a/__init__.py', join(tmp_dir, 'a', '__init__.py'))