

# Generated at 2022-06-23 15:19:45.694330
# Unit test for function loader
def test_loader():
    """The function loader is tested here."""
    from importlib import import_module
    from pyslvs.util import pathname

    def func(*args, **kwargs):
        """Test function."""
        return args, kwargs

    def _module(name: str) -> module:
        """Load module."""
        try:
            return import_module(name)
        except ModuleNotFoundError:
            __import__(parent(name))
            import_module(name)
            return import_module(name)

    loader('test.use_loader', pathname(__file__))
    test = _module('test.use_loader')
    assert isinstance(test.func, type(func))

# Generated at 2022-06-23 15:19:57.061205
# Unit test for function loader
def test_loader():
    """Loader should be able to import all packages."""

# Generated at 2022-06-23 15:20:01.384007
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        'Pyslvs': 'pyslvs',
    },
            pwd='D:\\workspaces\\pyslvs\\lib',
            prefix='D:\\workspaces\\pyslvs\\docs\\api',
            link=True,
            level=1,
            toc=False)


# Generated at 2022-06-23 15:20:04.769036
# Unit test for function loader
def test_loader():
    logger.setLevel("WARNING")
    logger.info("Unit test for package searching algorithm.")
    doc = loader("pyslvs", join("..", "..", "..", "src"), True, 1, False)
    assert doc.strip() is not None

# Generated at 2022-06-23 15:20:15.606913
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import raises
    with raises(TypeError):
        for _ in walk_packages(10, "."):
            pass
    from contextlib import redirect_stdout
    from io import StringIO
    sys_path.append("./testpkg")
    sys_path.append("./testpkg-stubs")
    with redirect_stdout(StringIO()) as f:
        for name, path in walk_packages("test", "./testpkg"):
            print(name, path)
        assert f.getvalue() == 'test.__init__ testpkg/test/__init__.pyi\n'
    with redirect_stdout(StringIO()) as f:
        for name, path in walk_packages("test", "./testpkg-stubs"):
            print(name, path)
        assert f.getvalue()

# Generated at 2022-06-23 15:20:19.086944
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    pkg = 'pyslvs_ui.compiler'
    root = dirname(_site_path(pkg))
    if not root:
        raise ValueError(f"Module {pkg} is not in site-packages")
    print(f"\n{root}")
    for name, path in walk_packages(pkg, root):
        print(f"{name} - {path}")

# Generated at 2022-06-23 15:20:21.737733
# Unit test for function loader
def test_loader():
    """Generate test files in the current directory."""
    gen_api({
        "pyslvs": "pyslvs",
        "pyslvs-ui": "pyslvs_ui",
    }, "..",
        prefix=".",
        link=False,
        level=1,
        toc=False,
    )



# Generated at 2022-06-23 15:20:24.060112
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"numpy": "numpy"}, dry=True)


# Generated at 2022-06-23 15:20:32.382182
# Unit test for function walk_packages

# Generated at 2022-06-23 15:20:35.313483
# Unit test for function loader
def test_loader():
    assert loader("pyslvs-ui", dirname(__file__), False, 1, False).strip()
    assert loader("pyslvs", dirname(__file__), False, 1, False).strip()



# Generated at 2022-06-23 15:20:36.871311
# Unit test for function gen_api
def test_gen_api():
    rn = {'title': 'name'}
    gen_api(rn, dry=True)



# Generated at 2022-06-23 15:20:45.546651
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({ 'a': 'a', 'b': 'b' }) == ['', '', '']
    assert gen_api({ 'a': 'a', 'b': 'b' }, dry=True) == ['', '', '']

import sys as _sys

if __name__ == '__main__':
    if not _sys.argv[1:]:
        raise SystemExit('Please provide the package name.')
    _sys.exit(gen_api(*_sys.argv[1:], dry=True, prefix="python"))

# Generated at 2022-06-23 15:20:55.418221
# Unit test for function gen_api
def test_gen_api():
    import io
    import io
    import sys
    import shutil
    import tempfile
    from os.path import isfile, join

    def _mkdirs(name: str, files: dict[str, str]) -> str:
        d = tempfile.mkdtemp(name)
        for f, s in files.items():
            with open(join(d, f), 'w+') as fp:
                fp.write(s)
        return d

    # Test for non-exist directory
    try:
        assert len(gen_api({'Test': 'test'})) == 0
        assert len(gen_api({'Test': 'test'}, dry=True)) == 0
    except AssertionError:
        raise AssertionError("Test failed")

# Generated at 2022-06-23 15:21:00.968508
# Unit test for function gen_api
def test_gen_api():
    root_names = {"PySLVS": "pyslvs"}
    docs = gen_api(root_names, None, prefix=".", dry=True)
    print(docs[0])
    root_names = {"Foo": "foo", "Bar": "bar"}
    docs = gen_api(root_names, ".", link=False, level=3, toc=True, dry=True)
    print(docs[0])

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:21:10.837984
# Unit test for function walk_packages
def test_walk_packages():
    assert next(walk_packages('pkg', 'tests/pkg')) == ('pkg', 'tests/pkg/__init__.py')
    assert next(walk_packages('pkg', 'tests/pkg'), None) == \
        ('pkg.foo', 'tests/pkg/foo/__init__.py')
    assert next(walk_packages('pkg', 'tests/pkg'), None) == \
        ('pkg.foo.bar', 'tests/pkg/foo/__init__.py')
    assert next(walk_packages('pkg', 'tests/pkg'), None) == \
        ('pkg.foo.bar.baz', 'tests/pkg/foo/bar/baz.py')
    assert next(walk_packages('pkg', 'tests/pkg'), None) is None

# Generated at 2022-06-23 15:21:22.408088
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from os import makedirs
    from os.path import join
    from shutil import copy
    from pkg_resources import get_distribution
    from .logger import logger, set_log_level

    set_log_level(1)

    def make_stubs(pwd: str, path: str, name: str) -> None:
        stub_path = join(path, name) + PEP561_SUFFIX
        logger.debug(f"Create stub directory: {stub_path}")
        makedirs(stub_path)
        copy(join(pwd, 'stub.py'), join(stub_path, '__init__.py'))


# Generated at 2022-06-23 15:21:28.549216
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .loader import _read, _write, _site_path, walk_packages
    from .loader import loader, gen_api

    data = ".. code-block:: python\n"
    data += "\n    def hello(a: int, b: int) -> int:\n"
    data += "        return a + b"
    parser = Parser.new()
    parser.parse("hello_world.py", data)
    assert parser.compile() == data
    assert _read("hello_world.py") == data
    _write("hello_world_1.py", data)
    assert _read("hello_world_1.py") == data
    assert _site_path("tqdm")

# Generated at 2022-06-23 15:21:38.618886
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function `walk_packages`."""
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    name = 'test-loader'
    path = mkdtemp()
    logger.debug(f"Test path: {path}")
    a = join(path, name + '.py')
    logger.debug(f"Test path: {a}")
    _write(a, "a")
    b = join(path, name + '.pyi')
    logger.debug(f"Test path: {b}")
    _write(b, "b")
    c = join(path, '__init__.py')
    logger.debug(f"Test path: {c}")
    _write(c, "c")

# Generated at 2022-06-23 15:21:46.410812
# Unit test for function walk_packages
def test_walk_packages():
    def _assert(name, path, *, allow_docs=False):
        assert name == "pyslvs_ui.qt"

        if allow_docs:
            return

        assert path == (
            "/home/yuan/Code/pyslvs-ui/pyslvs_ui/pyslvs_ui/qt/__init__.py"
        )

    for name, path in walk_packages("pyslvs", "/home/yuan/Code/pyslvs-ui/"):
        if name.endswith(".docs"):
            _assert(name, path, allow_docs=True)
        else:
            _assert(name, path)

# Generated at 2022-06-23 15:21:56.811535
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile, move
    from random import choice
    from string import ascii_lowercase
    from os.path import exists, isdir, dirname, basename
    with TemporaryDirectory() as d:
        d1 = join(d, 'python_docs_test')
        d2 = join(d, 'python_docs_test_2')
        mkdir(d1)
        with open(join(d1, "test.py"), 'w+') as f:
            f.write("1")
        with open(join(d1, "test2.py"), 'w+') as f:
            f.write("1")
        with open(join(d1, "test.pyi"), 'w+') as f:
            f.write("1")

# Generated at 2022-06-23 15:22:00.203713
# Unit test for function loader
def test_loader():
    from .test_data import test_loader
    from .parser import Parser

    assert loader('test', test_loader, Parser.new(False, 1, False)) is not None

# Generated at 2022-06-23 15:22:07.828236
# Unit test for function loader
def test_loader():
    """Test for loader."""
    assert loader("numpy", "tests/numpy", True, 1, True)
    assert loader("numpy", "tests/numpy-1.19.1", True, 1, True)
    assert loader("scipy", "tests/scipy-1.5.2", True, 1, True)
    assert loader("matplotlib", "tests/matplotlib-3.3.2", True, 1, True)
    assert loader("mayavi", "tests/mayavi-4.7.1", True, 1, True)
    assert loader("empymod", "tests/empymod-1.16.3", True, 1, True)

# Generated at 2022-06-23 15:22:11.164200
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        assert gen_api({"Test": "test_api"}, d, dry=True)

# Generated at 2022-06-23 15:22:15.641151
# Unit test for function walk_packages
def test_walk_packages():
    print('start walk packages')
    print(f"walk packages #1: {list(walk_packages('math', 'math'))}")
    print(f"walk packages #2: {list(walk_packages('pyslvs', 'pyslvs'))}")

# Generated at 2022-06-23 15:22:19.439189
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    p = Path(__file__).parent
    for name, path in walk_packages('pyslvs', p):
        print(name, path)



# Generated at 2022-06-23 15:22:22.585913
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    name = '_test_'
    sys_path.append(abspath('.'))
    assert len(list(walk_packages(name, _site_path(name)))) == 1

# Generated at 2022-06-23 15:22:31.794449
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import walk_packages
    import pyslvs
    pwd = _site_path('pyslvs')
    for _, name, _ in walk_packages(path=pwd):
        logger.debug(f"{name}")
        dead = {
            'base',
            'collections',
            'cpp_generator',
            'lisp_generator',
            'json_generator',
            'verifier',
            'vtk_generator',
            'drawing',
            'meshpy',
            'miscs',
            'print_tree',
            'verifier',
        }
        if name in dead:
            continue

# Generated at 2022-06-23 15:22:36.181990
# Unit test for function walk_packages
def test_walk_packages():
    path = '/home/yuan/Documents/Python/Project/pyslvs-ui/pyslvs_ui/__init__.py'
    for name, p in walk_packages('pyslvs_ui', path):
        print(name, p)
    assert name == 'pyslvs_ui'



# Generated at 2022-06-23 15:22:38.140255
# Unit test for function gen_api
def test_gen_api():
    print(gen_api({'Project': 'pyslvs'}, prefix='pyslvs'))

# Generated at 2022-06-23 15:22:46.492232
# Unit test for function walk_packages
def test_walk_packages():
    from importlib.util import cache_from_source, source_from_cache
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from .logger import logger as console

    if isdir("test_package"):
        console.debug("Remove test_package")
        rmtree("test_package")
    if isdir("test_stub"):
        console.debug("Remove test_stub")
        rmtree("test_stub")
    if exists("test_package.py"):
        console.debug("Remove test_package.py")
        rmtree("test_package.py")
    if exists("test_folder.py"):
        console.debug("Remove test_folder.py")
        rmtree("test_folder.py")

# Generated at 2022-06-23 15:22:50.114885
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    assert gen_api({"A": "m"}, dry=True)
    assert gen_api({"A": "aa"}, dry=True)
    assert gen_api({"A": "a"}, prefix="a", dry=True)

# Generated at 2022-06-23 15:22:59.586614
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import mkdtemp
    from shutil import rmtree

    def _touch(path: str) -> None:
        with open(path, 'a+') as f:
            pass

    dirpath = mkdtemp()

# Generated at 2022-06-23 15:23:09.199756
# Unit test for function walk_packages
def test_walk_packages():
    """Test for the function 'walk_packages'."""
    # Create test environment
    path = 'test_dummy'
    mkdir(path)
    with open(join(path, '__init__.py'), 'w+'):
        pass
    with open(join(path, 'dummy1.py'), 'w+'):
        pass
    mkdir(join(path, 'dum_dir'))
    with open(join(path, 'dum_dir', '__init__.py'), 'w+'):
        pass
    with open(join(path, 'dum_dir', 'dummy2.py'), 'w+'):
        pass
    with open(join(path, 'dum_dir', 'dummy3.pyi'), 'w+'):
        pass

# Generated at 2022-06-23 15:23:11.962046
# Unit test for function loader
def test_loader():
    gen_api({'Test': 'test'}, '.', toc=True, dry=True)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:23:20.722264
# Unit test for function loader
def test_loader():
    """Unittest of the loader function."""
    from pytest import approx
    from numpy.random import rand
    from .parser import Parser
    doc = """
    # Module docs

    ## Class
    ### class Class(a, b, c)
    Class description.
    """
    p = Parser.new()
    p.parse('module', doc)
    print(p.compile(), '\n')

    def test_doc(name, doc):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            doc_ext = doc + ext
            if not isfile(doc_ext):
                continue
            logger.debug(f"module {name} <= {doc_ext}")
            p.parse(name, _read(doc_ext))


# Generated at 2022-06-23 15:23:22.109917
# Unit test for function gen_api
def test_gen_api():
    gen_api({"solve": "solvespace", "pyslvs": "pyslvs_ui"}, ".")


# Generated at 2022-06-23 15:23:25.656649
# Unit test for function gen_api
def test_gen_api():
    # pylint: disable=import-outside-toplevel
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        assert gen_api({'foo': 'foo'}, temp_dir, prefix="docs", dry=True)

# Generated at 2022-06-23 15:23:37.613321
# Unit test for function walk_packages
def test_walk_packages():
    from pkgutil import walk_packages
    from types import ModuleType
    from importlib import import_module

    def get_mod(name: str) -> ModuleType:
        return import_module(name.replace('.', '_'))

    m = {
        "foo": get_mod("foo"),
        "foo.bar": get_mod("foo.bar"),
        "foo.baz": get_mod("foo.baz"),
        "foo.baz.boom": get_mod("foo.baz.boom"),
        "foo-stubs": get_mod("foo-stubs"),
        "foo-stubs.baz": get_mod("foo-stubs.baz"),
    }

    # Test the import algorithm

# Generated at 2022-06-23 15:23:41.276197
# Unit test for function gen_api
def test_gen_api():
    """Unit test for gen_api"""
    assert not gen_api({'API': 'pyslvs'}, dry=True)
    assert not gen_api({'API': 'pyslvs'}, '/', dry=True)


# Generated at 2022-06-23 15:23:51.688002
# Unit test for function loader

# Generated at 2022-06-23 15:24:02.283990
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os
    import shutil

    p = os.path.join(os.getcwd(), "walk_packages_test")
    if os.path.exists(p):
        shutil.rmtree(p)
    os.mkdir(p)
    os.mkdir(os.path.join(p, "__pycache__"))
    os.mkdir(os.path.join(p, "aaa"))
    os.mkdir(os.path.join(p, "bbb"))
    os.mkdir(os.path.join(p, "ccc"))

    sys.path.append(p)
    assert walk_packages("xxx", p) == []
    for i in sys.path:
        if i.startswith(p):
            sys.path.remove(i)

   

# Generated at 2022-06-23 15:24:09.425364
# Unit test for function gen_api
def test_gen_api():
    import pkg_resources
    # Use try and except to deal with no module
    try:
        root_names = {
            'Matplotlib': 'matplotlib',
            # 'Pyslvs': 'pyslvs_ui',
        }
        logger.setLevel('DEBUG')
        gen_api(root_names, pkg_resources.working_set.by_key['pyslvs'].location, link=True, level=2, toc=True, dry=True)
    except KeyError:
        pass

# Generated at 2022-06-23 15:24:13.361602
# Unit test for function loader
def test_loader():
    """Test module loader."""
    try:
        __import__("_test_loader")
    except ImportError:
        raise Exception("Test module not found")
    assert _load_module("_test_loader.test_loader", "test/_test_loader.py", Parser.new(True, 1, True))
    assert _load_module("_test_loader.module", "test/_test_loader.py", Parser.new(True, 1, True))
    assert _load_module("_test_loader.module.sub", "test/_test_loader.py", Parser.new(True, 1, True))

# Generated at 2022-06-23 15:24:19.596389
# Unit test for function gen_api
def test_gen_api():
    return gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
        'PySVG': 'pysvg',
        'Skew': 'skew'
    })

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:24:22.495578
# Unit test for function loader
def test_loader():
    main = "useless_tools.__main__"
    docs = loader(main, dirname(__file__), False, 2, False)
    assert main in docs
    assert pkgutil.find_loader(main) is not None

# Generated at 2022-06-23 15:24:33.753672
# Unit test for function walk_packages

# Generated at 2022-06-23 15:24:39.805886
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    from shutil import rmtree
    from os.path import dirname, basename
    from .parser import Parser


# Generated at 2022-06-23 15:24:43.724656
# Unit test for function loader
def test_loader():
    import pybweb
    for name, path in walk_packages('pybweb', dirname(pybweb.__file__)):
        logger.info(f"name: {name}")
        logger.info(f"path: {path}")
        logger.info(f"init: {path.endswith('.__init__')}")
        logger.info(f"root: {name.removesuffix('.__init__')}")

# Generated at 2022-06-23 15:24:52.121194
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import tempfile
    pkg_path = os.path.join(tempfile.gettempdir(), 'test_walk_packages')
    os.mkdir(pkg_path)
    with open(os.path.join(pkg_path, '__init__.py'), 'w+') as f:
        f.write('')
    with open(os.path.join(pkg_path, 'a.py'), 'w+') as f:
        f.write('')
    with open(os.path.join(pkg_path, 'a.pyi'), 'w+') as f:
        f.write('')
    with open(os.path.join(pkg_path, 'b.py'), 'w+') as f:
        f.write('')

# Generated at 2022-06-23 15:25:02.516019
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages()"""
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    with TemporaryDirectory() as td:
        root = 'root'
        _site_path(root)
        mkdir(join(td, root))
        # Path error
        assert list(walk_packages(root, join(td, 'root2'))) == []
        # Empty directory
        assert list(walk_packages(root, td)) == []
        # Import error
        copy('tests/test_import.py', join(td, root, 'main.py'))
        assert list(walk_packages(root, td)) == [
            ('root.main', join(td, root, 'main.py'))
        ]
        # .pyfirst

# Generated at 2022-06-23 15:25:06.372884
# Unit test for function loader
def test_loader():
    from os import getcwd
    from .test_parser import test_parser

    pwd = join(getcwd(), 'tests')
    sys_path.append(pwd)
    test_parser(loader('test', pwd))


# Generated at 2022-06-23 15:25:16.025487
# Unit test for function loader
def test_loader():

    class PyiLoader:

        """Simply load stub file."""

        def __init__(self, p: Parser):
            self.p = p

        def path_mtime(self, path):
            """Mock the path mtime."""
            return 0

        def module_repr(self, module):
            """Mock the module repr."""
            return module.__name__

        def create_module(self, spec):
            """Mock the create module."""
            return module_from_spec(spec)

        def exec_module(self, module):
            """Mock the exec module."""
            return self.p.parse(module.__name__, "")

    def _walk_packages(name, path) -> Iterator[tuple[str, str]]:
        """Mock the walk_packages function."""

# Generated at 2022-06-23 15:25:21.354413
# Unit test for function walk_packages
def test_walk_packages():
    assert isinstance(walk_packages("", ""), Iterator)
    assert isinstance(walk_packages("", "."), Iterator)
    assert isinstance(walk_packages("pyslvs", "."), Iterator)
    assert isinstance(walk_packages("pyslvs", ".."), Iterator)
    assert len(list(walk_packages("", "."))) >= 1

# Generated at 2022-06-23 15:25:32.568692
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp, TemporaryDirectory
    from shutil import copy
    from os.path import join, remove
    from pkgutil import get_importer, get_loader
    from .parser import Parser

    class _DummyRoot:

        def __init__(self, name: str, source: str):
            self.__name__ = name
            self.__source__ = source
            self.__file__ = source

    def _init_dummy_root(root: _DummyRoot, path: str) -> None:
        copy(join('test_cases', root.__name__ + '.py'), path)


# Generated at 2022-06-23 15:25:38.523909
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, mock

    with mock.patch('sys.path', ["foo"]), mock.patch('os.walk') as walk:
        walk.return_value = (
            ("foo", "bar", ("baz.py",)),
            ("foo/bar", [], ())
        )
        assert tuple(walk_packages("baz", "foo")) == (
            ("baz", "foo/baz.py"),
        )

# Generated at 2022-06-23 15:25:44.428029
# Unit test for function loader
def test_loader():
    from pathlib import Path
    from shutil import rmtree

    name = 'temp'
    for path in Path().glob(name):
        rmtree(path, ignore_errors=True)

    root_names = {'Testing': name}
    docs = gen_api(root_names,
                   pwd='./',
                   prefix=name,
                   link=True,
                   level=1,
                   toc=True,
                   dry=False)

    assert len(docs) == 1, "API parsing error"
    logger.info("Success")


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:25:49.126063
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from importlib.util import spec_from_file_location, module_from_spec

    with TemporaryDirectory() as temp_dir:
        # Create a package
        mkdir(f"{temp_dir}/root")
        mkdir(f"{temp_dir}/root.subroot")
        mkdir(f"{temp_dir}/root.subroot.subroot")
        mkdir(f"{temp_dir}/root.a")
        mkdir(f"{temp_dir}/root.b")
        mkdir(f"{temp_dir}/root.b.a")
        mkdir(f"{temp_dir}/root.b.b")
        mkdir(f"{temp_dir}/root.b.a.a")

# Generated at 2022-06-23 15:26:00.368168
# Unit test for function walk_packages
def test_walk_packages():
    def test(pwd: str, name: str, path: str):
        path = abspath(path) + sep
        assert next(walk_packages(name, pwd)) == (name, path + name)

    test('.', 'pyslvs', 'pyslvs')
    test('.', 'pyslvs', 'pyslvs.__pycache__')
    test('.', 'pyslvs', 'pyslvs_ui')
    test('.', 'pyslvs', 'pyslvs_ui.__pycache__')
    test('.', 'pyslvs_ui', 'pyslvs_ui')
    test('.', 'pyslvs_ui', 'pyslvs_ui.__pycache__')

# Generated at 2022-06-23 15:26:03.113939
# Unit test for function loader
def test_loader():
    import sys
    sys.path.append('../test_plugins')
    doc = loader('test', '../test_plugins', False, 1, False)
    assert doc.strip().count('\n') == 2 * 4 + 6 * 3
    logger.info('#' * 12)
    logger.info(doc)
    logger.info('#' * 12)
    logger.info("Yes, it works.")

# Generated at 2022-06-23 15:26:06.700568
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    doc = loader(
        "pyslvs",
        "."
    )
    assert len(doc) > 10
    assert all(l.startswith("* [") for l in doc.splitlines()[:6])


# Generated at 2022-06-23 15:26:13.306147
# Unit test for function loader
def test_loader():
    """Check loader."""
    import sys, os
    name = 'pyslvs'
    sys.path.append(parent(__file__))
    if isdir('pyslvs'):
        os.system(f"python -m pyslvs {loader(name, 'pyslvs', True, 2, True)}")
    else:
        print(loader(name, '', True, 1, True))

# Generated at 2022-06-23 15:26:23.281279
# Unit test for function loader
def test_loader():
    pwd = abspath("tests/apis")
    assert not isdir("docs")
    assert loader("numpy", pwd, True, 1, False).strip()
    assert loader("pyslvs_ui", pwd, True, 1, False).strip()
    assert loader("vpoints", pwd, True, 1, False).strip()
    assert loader("ikfast", pwd, True, 1, False).strip()
    assert loader("pyslvs_ui", pwd, True, 1, False).strip()
    assert loader("verify", pwd, True, 1, False).strip()
    assert isdir("docs")
    assert loader("pyslvs_ui", pwd, True, 1, False).strip()

# Generated at 2022-06-23 15:26:30.788614
# Unit test for function walk_packages
def test_walk_packages():
    name = 'pyslvs_ui'
    path = _site_path(name)
    errors = []
    msg = "Error in walk_packages, {}, {}"
    for name, path in walk_packages(name, path):
        if isfile(path + '.pyi') and not isfile(path + '.py'):
            errors.append(msg.format(name, path))
        if isfile(path + '.py') and not isfile(path + '.pyi'):
            errors.append(msg.format(name, path))
    if errors:
        raise AssertionError('\n'.join(errors))

# Generated at 2022-06-23 15:26:32.031732
# Unit test for function walk_packages
def test_walk_packages():
    for i in walk_packages('mylib', 'tests'):
        print(i)



# Generated at 2022-06-23 15:26:33.553607
# Unit test for function loader
def test_loader():
    loader('pyslvs', join(dirname(__file__), '..'), True, 1, True)

# Generated at 2022-06-23 15:26:37.502945
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        for doc in gen_api({
            "Site package": "pkg1",
            "System package": "pkg2",
            "Not found": "pkg3",
        }, temp_dir):
            print('-' * 8)
            print(doc)



# Generated at 2022-06-23 15:26:47.850094
# Unit test for function walk_packages
def test_walk_packages():
    from ._temp import __name__ as temp_name
    import _temp  # pylint: disable=import-outside-toplevel
    temp = dirname(abspath(_temp.__file__))

# Generated at 2022-06-23 15:26:56.628185
# Unit test for function walk_packages
def test_walk_packages():
    from .coreinfo import __version__
    from .coreinfo import __file__ as coreinfo_file
    import pkg_resources
    from os.path import dirname, basename
    pwd = dirname(coreinfo_file)
    root = basename(coreinfo_file).rstrip(".py")
    assert len(list(walk_packages(root, pwd))) == 1
    assert pkg_resources.parse_version(__version__) in pkg_resources.parse_version("1.1.0")
    # Get current directory
    pwd = dirname(__file__)
    root = 'tests'
    assert len(list(walk_packages(root, pwd))) == 1

# Generated at 2022-06-23 15:27:02.092495
# Unit test for function loader
def test_loader():
    from unittest.mock import Mock
    Mock.__doc__ = "Test docstring"
    doc = loader('unittest', "", True, 1, True)
    assert Mock.__doc__ in doc
    assert 'Mock.__doc__' in doc
    assert 'Mock.__name__' in doc

# Test calling directly
if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:27:10.366015
# Unit test for function gen_api
def test_gen_api():
    from .__init__ import __version__
    from .utils import DefaultDict
    from .compiler import (
        gen_api,
        PEP561_SUFFIX,
    )
    from .parser import Parser
    from . import __name__, __path__ as __root__
    name = __name__, __version__
    for path in __root__:
        # Search stubs and py in pyslvs_ui
        for root, path in Parser.walk_packages(name, path):
            if root.endswith(PEP561_SUFFIX):
                continue
            if root.startswith(f"{name}."):
                continue
            yield gen_api, {root: ''}, path
            break
    # Search stubs and py in pyslvs_ui

# Generated at 2022-06-23 15:27:13.777385
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    _ = gen_api({'Pyslvs': 'pyslvs'}, '.', toc=True, dry=True)


# Generated at 2022-06-23 15:27:18.916459
# Unit test for function gen_api
def test_gen_api():
    r = gen_api({'Scrcpy': 'scrcpy'}, './', dry=True)
    assert r
    r = gen_api({'Scrcpy': 'scrcpy'}, '../', dry=True)
    assert r
    r = gen_api({'PySLVS': 'pyslvs'}, './', dry=True)
    assert r

# Generated at 2022-06-23 15:27:22.010374
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test'}) == []
    assert gen_api({'test': 'test'}, '.') == []
    assert gen_api({'test': 'test'}, '.', dry=True) == []
    assert gen_api({'test': 'test'}, '.', dry=True) == []

# Generated at 2022-06-23 15:27:29.272494
# Unit test for function walk_packages

# Generated at 2022-06-23 15:27:34.958358
# Unit test for function gen_api
def test_gen_api():
    '''Unit test for function gen_api'''
    # pylint: disable=line-too-long
    assert gen_api({"Docstring Parser": "pyslvs_parser", "Project Builder": "pyslvs_build"}, pwd=dirname(__file__), dry=True) == ['# Docstring Parser API\n\n', '# Project Builder API\n\n']

# Generated at 2022-06-23 15:27:46.322203
# Unit test for function loader
def test_loader():
    from os.path import realpath
    dirpath = dirname(realpath(__file__))
    assert loader(
        "pyslvs",
        join(dirpath, ".."),
        False,
        1,
        False
    ).strip()
    assert loader(
        "pyslvs",
        join(dirpath, ".."),
        True,
        2,
        True
    ).strip()
    assert loader(
        "pyslvs",
        join(dirpath, ".."),
        True,
        2,
        True
    ).strip()
    assert loader(
        "pyslvs",
        join(dirpath, ".."),
        True,
        2,
        True
    ).strip()


# Generated at 2022-06-23 15:27:51.665028
# Unit test for function gen_api
def test_gen_api():
    root = 'test_module'
    name = 'test_module.test_submodule'
    docs = gen_api({'Test Module': name}, dirname(__file__), dry=True)
    assert len(docs) == 2
    assert root in docs[0]
    assert name in docs[1]
    docs = gen_api({'Test Module': name}, dirname(__file__), toc=True, dry=True)
    assert "## Contents" in docs[1]
    assert "## Modules" in docs[1]

# Generated at 2022-06-23 15:27:58.352941
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from unittest.mock import patch

    # Test for walk_packages()
    def mock_walk(path: str) -> Iterator[tuple[str, str]]:
        """Fake walk function."""
        yield '.', ['__init__.py', 'module_1.c', 'module_2.py', 'submodule_1.py'], None
        yield 'submodule_1.py', ['__init__.py'], None

# Generated at 2022-06-23 15:28:04.760844
# Unit test for function loader
def test_loader():
    import pytest
    from importlib import import_module
    from .test_demo import demo

    demo()
    logger.info('-' * 20)
    loader('test_demo', dirname(abspath(__file__)), True, 2, False)
    logger.info('-' * 20)
    s = find_spec('test_demo')
    assert s is not None
    assert s.submodule_search_locations is not None
    logger.info(f'Submodule search locations: {str(s.submodule_search_locations)}')
    loader('test_demo', s.submodule_search_locations[0], True, 2, False)
    logger.info('-' * 20)
    m = import_module('test_demo.test')

# Generated at 2022-06-23 15:28:13.006789
# Unit test for function gen_api
def test_gen_api():
    """Unit test for gen_api."""
    import tempfile
    import shutil
    from os.path import join, isfile
    from .parser import Parser
    from .logger import Logger, set_logger
    temp = tempfile.mkdtemp()
    set_logger(Logger())

# Generated at 2022-06-23 15:28:20.236915
# Unit test for function gen_api
def test_gen_api():
    from .console import args
    arg = args.parse_args(['-v', '-d', '-l', '-o', '-p', '.', '-r', 'pyslvs', '-w', '.'])
    gen_api(arg.root_names, arg.pwd,
            link=arg.link,
            level=arg.level,
            toc=arg.toc,
            dry=arg.dry)


# Generated at 2022-06-23 15:28:21.684095
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"numpy": "numpy"})

# Generated at 2022-06-23 15:28:30.777394
# Unit test for function loader
def test_loader():
    """Test basic loader."""
    import os
    import sys
    import ctypes
    import importlib
    import pkgutil
    import tempfile
    import shutil

    assert isinstance(sys.path, list)
    assert isinstance(sys_path, list)

    # Test import
    assert importlib is not None
    assert pkgutil is not None
    assert ctypes is not None
    assert os is not None

    # Test current path
    assert os.getcwd() == os.path.abspath(os.curdir)
    assert os.curdir == os.path.curdir
    assert os.path.abspath(os.path.curdir) == os.getcwd()

    # Test path

# Generated at 2022-06-23 15:28:41.520669
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import os
    import shutil
    try:
        os.mkdir('temp')
    except FileExistsError:
        pass
    with open('temp/__init__.pyi', 'w+'):
        pass
    with open('temp/ab.py', 'w+'):
        pass
    with open('temp/ac.py', 'w+'):
        pass
    with open('temp/ad.py', 'w+'):
        pass
    doc = loader('temp', 'temp')
    assert doc == ('# temp'
                   '\n\n'
                   '## ab\n'
                   '\n'
                   '## ac\n'
                   '\n'
                   '## ad\n'
                   '\n'
                   '')
    shutil

# Generated at 2022-06-23 15:28:43.306604
# Unit test for function gen_api
def test_gen_api(): # pragma: no cover
    r = gen_api({"a": "a", "b": "b"})
    assert r == []

# Generated at 2022-06-23 15:28:46.223853
# Unit test for function gen_api
def test_gen_api():
    """Docstring for unit test."""
    gen_api({
        'Python Standard Library': 'stdlib'
    }, 'tests', dry=True)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:28:54.795524
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    from os.path import exists
    from os import rmdir
    from shutil import rmtree
    pwd = mkdtemp()
    for name, title in {
        'numpy': 'NumPy',
        'scipy': 'SciPy',
        'matplotlib': 'MatPlotLib',
    }.items():
        mkdtemp(prefix='pyslvs-api-', dir=pwd)
    assert gen_api({
        'NumPy': 'numpy',
        'SciPy': 'scipy',
        'MatPlotLib': 'matplotlib',
    }, pwd)

# Generated at 2022-06-23 15:29:00.383403
# Unit test for function loader
def test_loader():
    sys_path.append(dirname(__file__))
    pwd = _site_path('pyslvs_ui')
    pwd = pwd if pwd else '.'
    root = 'pyslvs_ui'
    print(loader(root, pwd, link=False, level=1, toc=False))


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:29:02.269525
# Unit test for function loader
def test_loader():
    gen_api({'Test': 'pyslvs_ui.test_api'}, dry=True)

# Generated at 2022-06-23 15:29:04.314732
# Unit test for function loader
def test_loader():
    loader("pyslvs", ".", True, 2, False)

# Generated at 2022-06-23 15:29:13.295897
# Unit test for function walk_packages
def test_walk_packages():
    from .cli import temp_dir, _write, import_hook
    # monkey patch
    orig_path = sys_path
    orig_import = __import__
    sys_path = lambda: orig_path + [temp_dir]
    __import__ = import_hook
    # create a temp path
    with temp_dir() as p:
        # write a temp script
        _write(join(p, 'test', 'foo.py'), 'def foo(): pass')
        _write(join(p, 'test', 'bar.pyi'), 'def bar(): pass')
        _write(join(p, 'test', '__init__.py'), '')
        # test

# Generated at 2022-06-23 15:29:22.814553
# Unit test for function loader
def test_loader():
    """Unit test for loader."""
    from pkgutil import walk_packages as wp
    p = Parser.new(True, 1, False)
    for name, path in wp(["dill"], "dill"):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module here
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext

# Generated at 2022-06-23 15:29:33.572562
# Unit test for function gen_api
def test_gen_api():
    """Test for function: gen_api."""
    from ..core.subsystem.subsystem import subsystem_cmd
    from ..core.subsystem.subsystem_visual import subsystem_visual_cmd
    from ..core.subsystem.subsystem_frame import subsystem_frame_cmd
    from ..core.subsystem.subsystem_solver import subsystem_solver_cmd
    from ..core.subsystem.subsystem_constraint import subsystem_constraint_cmd
    from ..core.subsystem.subsystem_algorithm import subsystem_algorithm_cmd
    from ..core.subsystem.subsystem_pyslvs import subsystem_pyslvs_cmd
    from ..core.subsystem.subsystem_qtcmd import subsystem_qtcmd_cmd
    from ..core.subsystem.subsystem_solvers import subsystem_solvers_cmd



# Generated at 2022-06-23 15:29:41.219734
# Unit test for function walk_packages
def test_walk_packages():
    def _test(name, path, out):
        assert list(walk_packages(name, path)) == out
    # Default