

# Generated at 2022-06-23 15:19:46.260895
# Unit test for function gen_api
def test_gen_api():
    from unittest.mock import patch
    def _mock_loader(*args, **kwargs):
        return """
        .. py:function:: example()

            example function

        .. py:function:: example.func()

            member function of example
        """
    pth = 'tests/mock'
    with patch('pkgvendor.compiler.loader', new=_mock_loader):
        docs = gen_api({'Example': 'example'}, pth, prefix='tests/out', dry=True)
    assert len(docs) == 1
    assert 'example' in docs[0]
    assert 'example.func' in docs[0]

# Generated at 2022-06-23 15:19:57.587313
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename, dirname
    import sys
    import pyslvs
    pyslvs_path = dirname(dirname(pyslvs.__file__))
    with TemporaryDirectory() as t, open(join(pyslvs_path, "TEST_API.md"), 'w+') as f:
        t_pyslvs = 'pyslvs_%s' % basename(pyslvs_path)
        copyfile(join(pyslvs_path, "setup.py"), join(t, "setup.py"))
        copyfile(join(pyslvs_path, "pyslvs", "__init__.py"), join(t, t_pyslvs, "__init__.py"))

# Generated at 2022-06-23 15:20:07.416840
# Unit test for function gen_api
def test_gen_api():
    """Test gen_api()."""
    from .utils import rm_dir
    from .data import root_names as roots

    def mock_logger():
        # Clear last test messages
        logger.info.__func__.__doc__ = ""
        # Mocking
        logger.debug = lambda _: None
        logger.info = lambda s: logger.info.__func__.__doc__.join([s, "\n"])
        logger.warning = lambda _: None

    mock_logger()

    def gen_doc(root: str, link: bool = True) -> str:
        return loader(root, "", link, 1, False)

    def assert_doc(name: str, doc: str) -> None:
        assert doc.startswith(f"# {name} API\n\n")


# Generated at 2022-06-23 15:20:11.340649
# Unit test for function gen_api
def test_gen_api():
    import random
    import string
    d = dict(a=random.choice(string.ascii_letters), b=random.choice(string.ascii_letters))
    gen_api(d)
    gen_api(d, dry=True)

# Generated at 2022-06-23 15:20:13.942284
# Unit test for function gen_api
def test_gen_api():
    """test_gen_api"""
    import doctest
    from .logger import logger_test

    with logger_test():
        doctest.testmod(verbose=True)

# Generated at 2022-06-23 15:20:23.570226
# Unit test for function loader
def test_loader():
    """Test for make API."""
    import pyslvs
    path = _site_path(pyslvs.__name__)
    assert path != ""
    import pyslvs_ui
    path = _site_path(pyslvs_ui.__name__)
    assert path != ""
    import pyslvs_qtc
    path = _site_path(pyslvs_qtc.__name__)
    assert path != ""
    docs = gen_api({'Pyslvs': 'pyslvs',
                    'Pyslvs UI': 'pyslvs_ui',
                    'Pyslvs QTC': 'pyslvs_qtc'},
                   pwd=dirname(dirname(path)),
                   dry=True)
    assert docs != []

# Generated at 2022-06-23 15:20:32.056828
# Unit test for function loader
def test_loader():
    p = Parser(True, 3, False)
    for name, path in walk_packages("pyslvs", "pyslvs/tests"):
        # Load its source
        logger.debug(f"{name} <= {path}.py")
        p.parse(name, _read(path + '.py'))
        # Try to load module here
        logger.debug(f"loading extension module for fully documented:")
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            if _load_module(name, path_ext, p):
                idx = 0
                while p.full_api[idx][0] != name:
                    idx

# Generated at 2022-06-23 15:20:40.248420
# Unit test for function loader
def test_loader():
    class Pwd:
        def __init__(self, pwd: str):
            self.pwd = pwd

        def __enter__(self):
            sys_path.append(self.pwd)

        def __exit__(self, *args, **kwargs):
            sys_path.pop()

    def clear_cache():
        for module in list(sys.modules.values()):
            name = getattr(module, '__name__', '')
            if name.startswith('pyslvs') and not name == 'pyslvs.__main__':
                del sys.modules[name]

    pwd = join(dirname(__file__), '__loader_test__')

# Generated at 2022-06-23 15:20:44.305866
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from .__main__ import __version__ as pyslvs_version
    root = "pyslvs"
    title = f"PySLVS (Python) {pyslvs_version}"
    docs = gen_api({title: root}, prefix=mkdtemp())
    assert len(docs) == 1
    assert docs[0].startswith('# ' + title)
    rmtree(prefix)

# Generated at 2022-06-23 15:20:45.966505
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test'}, dry=True)

# Generated at 2022-06-23 15:20:52.698107
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    packages = list(walk_packages('pyslvs', '/home/yuan/Desktop/pyslvs/pyslvs'))
    assert len(packages) > 0
    names = [name for name, _ in packages]
    assert 'pyslvs.ui.main' in names
    assert 'pyslvs_ui.main' not in names

# Generated at 2022-06-23 15:21:00.299010
# Unit test for function loader
def test_loader():
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkgutil import extend_path

    def to_path(name): return extend_path(__path__, name)

    def to_import(name): return __import__(name)

    args = {
        'root': 'example',
        'pwd': mkdtemp(),
        'link': False,
        'level': 1,
        'toc': False
    }

    def mock(m):
        """mocked PyQt5-sip and pythonxy-sip"""
        if m.startswith('PyQt5'):
            return 'PyQt5.sip'
        if m.startswith('pythonxy'):
            return 'pythonxy.sip'
        return m


# Generated at 2022-06-23 15:21:11.068488
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from pyslvs_ui import packages
    from random import shuffle
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import isfile
    from .logger import logger
    from .exceptions import ArgParserError
    logger.setLevel(10)
    args = [
        '--dry-run',
        '--prefix', 'prefix',
        '--level', '3',
        '--toc',
    ]
    package_names = list(packages.keys())
    shuffle(package_names)
    n = 2
    for n in [0, 1, len(package_names)]:
        logger.info(f"n = {n}")

# Generated at 2022-06-23 15:21:22.736179
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import MagicMock

    def isdir(path: str) -> bool:
        return path == '/lib'


# Generated at 2022-06-23 15:21:28.583191
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copy2
    from multiprocessing import freeze_support
    from pkg_resources import resource_filename
    from os.path import basename, splitext
    freeze_support()
    with TemporaryDirectory() as tmp:
        for f in ['test.py', 'test.pyi']:
            copy2(resource_filename('pyslvs', 'examples/' + f), tmp)
        docs = gen_api({'./' + basename(tmp): splitext(basename(tmp))[0]},
                       tmp, prefix=tmp, dry=True)
    print("=" * 12)
    print("\n".join(docs))

# Generated at 2022-06-23 15:21:38.664474
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        # Prepare
        t = abspath(temp_dir)
        mkdir(join(t, "p1"))
        mkdir(join(t, "p2"))
        mkdir(join(t, "p2", "foo"))
        mkdir(join(t, "p2", "foo", "bar"))
        mkdir(join(t, "p2", "foo", "bar", "__pycache__"))
        mkdir(join(t, "p2", "foo", "bar", "baz"))
        mkdir(join(t, "p3"))
        mkdir(join(t, "p4"))
        mkdir(join(t, "p5"))

        # Make dir and file structure

# Generated at 2022-06-23 15:21:41.372836
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    path = parent(__file__)
    loader("pyslvs", path, True, 1, False)

# Generated at 2022-06-23 15:21:49.409720
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import expanduser, join
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from pkg_resources import working_set, Distribution
    from unittest.mock import Mock
    from .logger import logger

    logger.info("Generate test package")
    root = expanduser('~')
    root += '/pyslvs-test/'
    rmtree(root, ignore_errors=True)
    base_path = join(root, 'test-package')

    with open(join(root, 'setup.cfg'), 'w') as f:
        f.write('[bdist_wheel]\nuniversal=True')


# Generated at 2022-06-23 15:21:52.061159
# Unit test for function gen_api
def test_gen_api():
    gen_api({"Test Title": "test_name"}, dry = True)
    gen_api({"Test Title": "test_name"}, "test", "test_api", dry = True)

# Generated at 2022-06-23 15:21:56.078819
# Unit test for function walk_packages
def test_walk_packages():
    from os import chdir
    from os.path import dirname
    from .logger import logger
    from .parser import path_code
    from .compiler import walk_packages
    logger.debug = True
    chdir(dirname(dirname(dirname(__file__))))
    for name, _ in walk_packages('pyslvs', path_code):
        print(name)

# Generated at 2022-06-23 15:22:06.600643
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from pkgutil import walk_packages as p_walk_packages
    from tempfile import mkdtemp
    from shutil import rmtree
    from sys import path as sys_path
    from os import walk, sep
    from os.path import join, isdir, isfile
    from time import time
    logger.info("# Unit test for function gen_api")
    tmp = join(mkdtemp(), "pyslvs")

    # Fake package for import
    mkdir(tmp)
    with open(join(tmp, "__init__.py"), 'w'):
        pass
    with open(join(tmp, "test_module.py"), 'w'):
        pass
    assert isdir(tmp) and isfile(join(tmp, "__init__.py"))
   

# Generated at 2022-06-23 15:22:17.845374
# Unit test for function loader
def test_loader():
    """Test docstring loader."""
    import json
    from .stubs import pyslvs
    from .util import __meta__
    logger.debug("test_loader:")
    print('\n'.join(
        loader(
            "pyslvs", _site_path("pyslvs"),
            True, 1,
            False
        ).splitlines()[:2]
    ))
    # Public document
    doc = loader('pyslvs', __meta__.__path__[0], True, 2, True)
    # Read stub
    with open(join(__meta__.__path__[0], 'pyslvs-stubs.pyi')) as f:
        stub = f.read()
    assert doc == stub
    # Private document

# Generated at 2022-06-23 15:22:26.705483
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from tempfile import gettempdir
    from shutil import rmtree
    pkg = join(gettempdir(), 'test_walk_packages')
    makedirs(join(pkg, 'src', 'a', 'b', 'c', 'd'), exist_ok=True)
    makedirs(join(pkg, 'src', 'a', 'b', 'c', 'd', '__pycache__'), exist_ok=True)
    makedirs(join(pkg, 'src', 'a', 'b', 'c', 'd-stubs'), exist_ok=True)

# Generated at 2022-06-23 15:22:27.562624
# Unit test for function gen_api
def test_gen_api():
    pass


# Generated at 2022-06-23 15:22:30.506298
# Unit test for function gen_api
def test_gen_api():
    """Test gen_api."""
    from .__main__ import run_main
    from .path import get_data_path
    from . import load_root_names
    run_main(gen_api, load_root_names(get_data_path()), "..", dry=True)

# Generated at 2022-06-23 15:22:40.213934
# Unit test for function loader
def test_loader():
    """Unit test."""
    from shlex import split
    from shutil import rmtree
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        pwd = join(tmp, 'site-packages')
        if isdir(pwd):
            rmtree(pwd)
        else:
            mkdir(pwd)
        p = Parser.new(link=False, level=0, toc=False)
        for name, path in walk_packages('hsh_tools', pwd):
            # Load its source or stub
            pure_py = False
            for ext in [".py", ".pyi"]:
                path_ext = path + ext
                if not isfile(path_ext):
                    continue
                logger.debug(f"{name} <= {path_ext}")

# Generated at 2022-06-23 15:22:49.762350
# Unit test for function loader
def test_loader():
    from os.path import abspath
    from tempfile import TemporaryDirectory
    from subprocess import check_output
    with TemporaryDirectory() as tmpdir:
        for name in ["test", "test.__init__"]:
            path = join(tmpdir, name.replace(".", sep) + ".py")
            with open(path, 'w') as f:
                f.write("""def function(i: int) -> str:
    return f"{i}"
""")
        docs = loader("test", tmpdir, True, 1, True)
        assert '# Test API' in docs
        assert '- [test.function(i)](#test-functioni)' in docs
        assert '`test`' not in docs
        assert "test.function" not in docs
        logger.info(docs)
        # Move directory
        old_

# Generated at 2022-06-23 15:22:52.625604
# Unit test for function loader
def test_loader():
    test_dir = dirname(abspath(__file__))
    docs = gen_api({"Test": "test"}, test_dir)
    assert docs, "No docs was generated."

# Generated at 2022-06-23 15:22:55.721596
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader('pyslvs', '..', False, 2, False)
    print("Length:", len(doc))
    print("Content:", doc.strip())

# Generated at 2022-06-23 15:23:06.272612
# Unit test for function loader
def test_loader():
    def parse(name: str, doc: str) -> str:
        return f"{name}: {len(doc)}"

    p = Parser()
    p.parse = parse
    with open("test_loader.py", 'w') as f:
        f.write("def foo(): ...")
    with open("test_loader.pyi", 'w') as f:
        f.write("def foo(): ...")
    with open("test_loader2.py", 'w') as f:
        f.write("def foo(): ...")
    with open("test_loader2.pyi", 'w') as f:
        f.write("def foo2(): ...")
    doc = loader("test_loader", '.', p)
    assert len(doc.strip().split('\n')) == 2

# Generated at 2022-06-23 15:23:14.327042
# Unit test for function walk_packages
def test_walk_packages():
    """Test the walk packages function."""
    from unittest.mock import patch
    from importlib import import_module
    from . import __path__ as parent_path
    from .package_name.module_name import func

    def _test(name: str, path: str, loader) -> bool:
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            loader(name, m)
            return True
        return False

    def _create_module():
        def _load(name, m):
            nonlocal p
            p.load_docstring(name, m)

        p = Parser.new(False, 1, False)


# Generated at 2022-06-23 15:23:24.768056
# Unit test for function walk_packages
def test_walk_packages():
    from random import randrange
    files = {
        f"{randrange(100)}/{randrange(100)}/{randrange(100)}/{randrange(100)}/{randrange(100)}"
        for _ in range(100)
    }
    from pkg_resources import find_distributions
    from os.path import basename
    for i in find_distributions():
        for f in i.location.split("\\"):
            files.add(f"{randrange(100)}/{f}")
    files = sorted(files)
    assert not any("test" in f for f in files)
    assert all("test" not in f for f in walk_packages("test", "."))
    assert all("test" not in f for f in walk_packages("test", ".."))
    assert all

# Generated at 2022-06-23 15:23:27.709723
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({'Pyslvs': 'pyslvs', 'PyslvsUI': 'pyslvs_ui'}, None)
    assert len(docs) == 2
    assert docs[0].startswith('# Pyslvs API')
    assert docs[1].startswith('# PyslvsUI API')

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:23:35.717553
# Unit test for function loader

# Generated at 2022-06-23 15:23:43.587385
# Unit test for function walk_packages
def test_walk_packages():
    from os import chdir, remove
    from shutil import rmtree
    from tempfile import mkdtemp
    from pathlib import Path
    chdir(mkdtemp())
    Path('site-packages/pyslvs_ui/__init__.py').write_text('')
    Path('site-packages/pyslvs_ui/__init__.pyi').write_text('')
    Path('site-packages/pyslvs_ui/ui/__init__.py').write_text('')
    Path('site-packages/pyslvs_ui/ui/__init__.pyi').write_text('')
    Path('site-packages/pyslvs_ui/ui/info_dialog/__init__.py').write_text('')

# Generated at 2022-06-23 15:23:53.081227
# Unit test for function walk_packages
def test_walk_packages():
    begin = (
        'pkgs.A',
        'pkgs.A.__init__',
        'pkgs.A.B',
        'pkgs.A.B.__init__',
        'pkgs.A.B.C',
        'pkgs.A.B.C.__init__',
        'pkgs.A.B.C.D',
        'pkgs.A.B.C.D.__init__',
        'pkgs.B',
        'pkgs.B.__init__',
        'pkgs.C',
        'pkgs.C.__init__',
    )

# Generated at 2022-06-23 15:23:55.976978
# Unit test for function loader
def test_loader():
    """Test the package loader."""
    from pyslvs import __path__
    r = loader('pyslvs', __path__[0], True, 1, True)
    assert r.startswith('# pyslvs API')



# Generated at 2022-06-23 15:24:06.336956
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os import path
    from sys import path as sys_path
    from shutil import copytree
    from pprint import pprint
    from unittest.mock import patch

    with patch('solve_api.compiler.logger.info'), patch('solve_api.compiler.logger.warning'), patch('solve_api.compiler.logger.debug'), TemporaryDirectory() as td:
        path = path.join(td, 'api')
        copytree(path.join(path.dirname(__file__), '..', 'solve_api'), path.join(td, 'solve_api'))
        sys_path.append(td)

# Generated at 2022-06-23 15:24:10.458436
# Unit test for function loader
def test_loader():
    import os
    root = os.environ['PYSLVS_ROOT']
    pwd = os.environ['PYSLVS_PWD']
    print(loader('pyslvs', pwd))



# Generated at 2022-06-23 15:24:21.125056
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    # Load pyslvs if exist
    import pyslvs
    # Test for the pyslvs
    pyslvs.get_templates_path()
    pyslvs.compiler.gen_api(
        {
            "Pyslvs": "pyslvs",
            "Project": "pyslvs_ui",
        }
    )
    # Test for the pyslvs-ui
    from pyslvs_ui.package_data import get_templates_path
    get_templates_path()
    from pyslvs_ui.compiler import gen_api
    gen_api(
        {
            "Project": "pyslvs_ui",
        }
    )

# Generated at 2022-06-23 15:24:27.536050
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    from unittest import TestCase, main
    from importlib import machinery
    from contextlib import ExitStack
    from shutil import rmtree
    from tempfile import mkdtemp

    class Test(TestCase):

        """Test for function walk_packages."""

        @classmethod
        def setUpClass(cls) -> None:
            """Create some temporary directories."""
            cls.temp = mkdtemp()
            cls.package = join(cls.temp, 'example')
            cls.sub_package = join(cls.package, 'sub_package')
            cls.pep561_package = join(cls.package, 'stub')
            mkdir(cls.package)
            mkdir(cls.sub_package)

# Generated at 2022-06-23 15:24:28.820590
# Unit test for function loader

# Generated at 2022-06-23 15:24:32.136822
# Unit test for function walk_packages
def test_walk_packages():
    name = 'pyslvs'
    path = _site_path(name)
    for module_name, module_path in walk_packages(name, path):
        print(module_name, module_path)

# Generated at 2022-06-23 15:24:36.937589
# Unit test for function loader
def test_loader():
    doc = loader(
        "typing",
        "/home/yuan/.virtualenvs/pyslvs/lib/python3.8/site-packages",
        True,
        1,
        False
    )
    assert doc.strip()
    print(doc)

# Generated at 2022-06-23 15:24:47.736500
# Unit test for function loader
def test_loader():
    import pkgutil
    # Test for sphinx-autoapi
    # https://github.com/sphinx-contrib/sphinx-autoapi
    s, _, _ = pkgutil.find_loader('sphinx_autoapi')
    if not s:
        raise AssertionError("sphinx-autoapi is not installed")
    assert s.path.endswith('sphinx_autoapi')
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('sphinx_autoapi', s.path):
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")

# Generated at 2022-06-23 15:24:59.860439
# Unit test for function walk_packages
def test_walk_packages():
    from importlib import import_module
    from pkgutil import get_importer, iter_modules
    from ..__pkginfo__ import __version__
    from . import logger

    assert __version__ == '0.5.0'
    assert 'pyslvs_ui.package' not in root.__dict__
    assert pwd == dirname(logger.__file__)
    root, pwd = import_module('pyslvs_ui'), os.getcwd()
    assert get_importer(pwd) is not None
    assert isinstance(iter_modules(pwd), Iterator)

# Generated at 2022-06-23 15:25:11.362802
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import shutil
    from tempfile import mkdtemp

    dirname = mkdtemp()
    root1 = join(dirname, "root")
    root2 = join(root1, "sub")
    os.mkdir(root1)
    os.mkdir(root2)
    with open(join(root1, "a.py"), "w+"):
        pass
    with open(join(root1, "b.py"), "w+"):
        pass
    with open(join(root1, "c.pyi"), "w+"):
        pass
    with open(join(root2, "__init__.py"), "w+"):
        pass
    with open(join(root2, "d.py"), "w+"):
        pass

# Generated at 2022-06-23 15:25:12.962903
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("test", "tests"):
        print(name, path)


# Generated at 2022-06-23 15:25:15.782006
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        'Current': 'pyslvs',
        'Solvers': 'pyslvs_ui'
    }, pwd='../../', dry=True)

# Generated at 2022-06-23 15:25:25.168464
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    import shutil
    import tempfile
    from pyperclip import copy, paste

    _root = abspath(".")
    _pwd = tempfile.TemporaryDirectory()

# Generated at 2022-06-23 15:25:29.613984
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'ksparser': 'pyslvs',
        'KM': 'pyslvs_ui'
    }
    gen_api(root_names=root_names, dry=True)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:25:40.211913
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from os import remove
    from os.path import islink, isfile
    docs = gen_api({"Numpy": "numpy"}, dry=True)
    logger.info('=' * 12)
    docs = gen_api({"Scipy": "scipy"}, dry=True, prefix='sp-docs')
    assert len(docs) == 1
    assert isdir('sp-docs')
    assert all(map(isfile, map(lambda p: join('sp-docs', p),
                               (f"{p}" for p, _ in walk_packages("scipy", 'sp-docs')))))
    remove(join('sp-docs', 'scipy-api.md'))
    assert islink('sp-docs')
    assert not isdir('sp-docs')

# Generated at 2022-06-23 15:25:43.693711
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:25:52.774055
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    from os import remove
    from os.path import isfile
    def remove_api(name: str) -> None:
        path = join('docs', f'{name.replace("_", "-")}-api.md')
        if isfile(path):
            remove(path)
    def check_api(name: str, title: str) -> None:
        path = join('docs', f'{name.replace("_", "-")}-api.md')
        assert isfile(path), f'{path} is not exist'
        with open(path, 'r') as f:
            doc = f.read()
            assert doc.startswith("# " + title), f'{path}: {doc[:30]}'
        remove_api(name)

# Generated at 2022-06-23 15:26:04.111782
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from random import random
    from unittest import TestCase

    class LoaderTest(TestCase):

        def _make_module(self, name: str) -> str:
            """Make a module.

            Only support the simple usage.
            """
            doc = [
                f"def test_{name}():",
                f"    '''Test for {name}.'''",
                "    print('Hello, World!')\n"
            ]
            if random() >= 0.5:
                doc.append("\n")
            return '\n'.join(doc)


# Generated at 2022-06-23 15:26:14.115897
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'PVGeo': 'pyslvs',
        'S2PLOT': 's2plot',
        'Structure': 's2s_vtk',
        'Scipy': 'scipy',
        # 'Numpy': 'numpy',
        # 'Pygal': 'pygal',
        # 'Mpl': 'matplotlib',
        # 'VTK': 'vtk',
        # 'Open3D': 'open3d',
        # 'Cgal': 'cgal',
    }
    r = gen_api(root_names, dry=True)
    logger.info('=' * 12 + '\n' * 2 * len(r))

# Generated at 2022-06-23 15:26:17.142583
# Unit test for function loader
def test_loader():
    assert loader("pyslvs", "../", True, 2, True)
    assert loader("pyslvs", "../", False, 3, False)

# Generated at 2022-06-23 15:26:24.369993
# Unit test for function gen_api
def test_gen_api():
    r = {
        "pyslvs": "pyslvs",
        "test_pkg": "test.__init__"
    }
    sys_path.append(sep.join(__file__.split(sep)[:-1]))
    print('\n'.join(gen_api(r, pwd=__file__.replace("__init__.py", ""), dry=True)))


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:26:33.278505
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    import os
    import shutil
    name = "pyslvs_test1"
    name2 = "pyslvs_test2"
    root_names = {
        "Pyslvs": name,
        "Pyslvs_test": name2,
        "test": name
    }
    root_temp_path = tempfile.mkdtemp()

# Generated at 2022-06-23 15:26:38.297442
# Unit test for function gen_api
def test_gen_api():
    import unittest
    pwd = dirname(__file__)
    root_names = {
        "Test 1": "test_doc",
    }
    docs = gen_api(root_names, pwd, dry=False)
    class TestDocstring(unittest.TestCase):
        def test_title(self):
            for doc in docs:
                self.assertTrue(doc.startswith('# Test 1 API'))
    unittest.main(module='tests.test_gen_api', exit=False)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:26:48.683337
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'Pyslvs-UI': 'pyslvs_ui',
        'Pyslvs': 'pyslvs',
    }
    docs = gen_api(root_names, pwd='', link=False, level=1, toc=False)
    assert len(docs) == 2
    assert docs[0].startswith('# Pyslvs-UI API')
    assert docs[1].startswith('# Pyslvs API')
    docs = gen_api(root_names, pwd='', link=True, level=1, toc=False)
    assert docs[0].startswith('# Pyslvs-UI API')
    assert docs[1].startswith('# Pyslvs API')

# Generated at 2022-06-23 15:26:50.632515
# Unit test for function gen_api
def test_gen_api():
    result = gen_api({'Solve': 'pyslvs_ui.solver'})
    assert result[0].startswith('# PySlvs Solver API')

# Generated at 2022-06-23 15:27:01.267774
# Unit test for function loader
def test_loader():
    from os import remove
    from re import sub
    from . import rst_plot
    from .logger import LogLevel
    root = "Python"
    root_path = _site_path(root).replace(sep, '.')
    main_pwd = join(f"{root_path.replace('.', sep)}.{root.lower()}")
    main_parser = Parser.new()
    main_path = join(main_pwd, f"{root.lower()}.py")
    if isfile(main_path):
        main_parser.parse(root, _read(main_path))
    for _, path in walk_packages(root, main_pwd):
        # Load its source or stub
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
           

# Generated at 2022-06-23 15:27:05.369011
# Unit test for function gen_api
def test_gen_api():
    """Test the function gen_api()."""
    gen_api({
        'Pyslvs': 'pyslvs',
        'VAssembly': 'pyslvs_ui',
    }, dry=True)

# Generated at 2022-06-23 15:27:10.838443
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('test', 'tests')) == [
        ('test', 'tests/test'),
        ('test.a', 'tests/test/a'),
        ('test.a.b', 'tests/test/a/b'),
        ('test.a.b.c', 'tests/test/a/b/c'),
        ('test.a.b.c.d', 'tests/test/a/b/c/d'),
        ('test.a.b.c.d.e', 'tests/test/a/b/c/d/e'),
    ]



# Generated at 2022-06-23 15:27:21.050367
# Unit test for function walk_packages
def test_walk_packages():
    assert next(walk_packages("foo", "test/root")) == ("foo.bar", "test/root/foo/bar.pyi")
    assert next(walk_packages("foo", "test/root")) == ("foo.baz", "test/root/foo/baz.py")
    assert next(walk_packages("foo", "test/root")) == ("foo.foo", "test/root/foo/foo/__init__.pyi")
    assert next(walk_packages("foo", "test/root")) == ("foo.foo.bar", "test/root/foo/foo/bar.pyi")
    assert next(walk_packages("foo", "test/root")) == ("foo.foo.baz", "test/root/foo/foo/baz.py")

# Generated at 2022-06-23 15:27:28.561976
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main

    class Test(TestCase):

        def test_walk_packages(self):
            pkg = "pyslvs_ui"
            r = list(walk_packages(pkg, _site_path(pkg)))
            print(r)

# Generated at 2022-06-23 15:27:35.277485
# Unit test for function walk_packages
def test_walk_packages():
    def unit(name: str, pwd: str, count: int) -> bool:
        """Unit test for walk packages."""
        assert len(list(walk_packages(name, pwd))) == count
        return True
    assert all(i for i in [
        unit("xlwings", "xlwings", 4),
        unit("pyslvs_ui", "pyslvs_ui", 2),
        unit("pyslvs_ui", "docs", 0),
    ])

# Generated at 2022-06-23 15:27:45.824455
# Unit test for function gen_api
def test_gen_api():
    """Gen API testing."""
    from tempfile import TemporaryFile as TFile
    from warnings import simplefilter
    from pyslvs import __version__
    from .logger import capture_warnings
    from .api_test import root_names
    for level in [1, 2, 3]:
        for name, title in root_names.items():
            simplefilter("ignore", category=UserWarning)
            with capture_warnings(record=True) as ws, TFile('w+') as f:
                gen_api({name: title}, dry=True, level=level)
            assert f.read()
            assert ws, f"Test {name} in {__version__}"


# Generated at 2022-06-23 15:27:52.579911
# Unit test for function gen_api
def test_gen_api():
    """Test for function `gen_api`."""
    import tempfile
    with tempfile.TemporaryDirectory() as pwd:
        from . import pkgutil
        from .__about__ import (
            __title__,
            __name__ as root_name,
        )
        root_names = {__title__: root_name}
        rtn = gen_api(root_names, pwd=pwd, prefix=__title__, dry=True)
        assert len(rtn) == 1, "Should be one document"
        assert rtn[0].startswith("# " + __title__ + " API"), "Should be right title"
        assert pkgutil.count_lines(rtn[0]) > 100, "Should be enough documents"

# Generated at 2022-06-23 15:28:03.611278
# Unit test for function gen_api
def test_gen_api():
    import os
    import pathlib
    import pyslvs
    import pyslvs_ui
    import pyslvs_ui.entity
    import pyslvs_ui.qt_compat
    import pyslvs_ia

    docs = gen_api({
        'pyslvs': 'pyslvs',
        'pyslvs-ui': 'pyslvs_ui',
        'pyslvs-ia': 'pyslvs_ia',
    }, str(pathlib.Path(__file__).parent), dry=True)

    # Write codes

# Generated at 2022-06-23 15:28:05.200115
# Unit test for function gen_api
def test_gen_api():
    '''Test the function'''
    assert gen_api({}) == []

# Generated at 2022-06-23 15:28:11.661906
# Unit test for function loader
def test_loader():
    from os.path import dirname
    from . import data_dir
    from .tokenizer import dokument
    from .markup import markup
    p = Parser.new(True, 1, False)
    p.parse('dokument', dokument)
    p.parse('markup', markup)
    p.parse('test_loader', _read(join(dirname(__file__), 'loader.py')))
    assert p.compile() == _read(join(data_dir, 'loader.md'))

# Generated at 2022-06-23 15:28:23.866839
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from os import mkdir
    with TemporaryDirectory() as pwd:
        mkdir(join(pwd, 'site_pkgs'))
        mkdir(join(pwd, 'site_pkgs', 'A'))
        mkdir(join(pwd, 'site_pkgs', 'A', 'B'))
        mkdir(join(pwd, 'site_pkgs', 'C'))
        open(join(pwd, 'site_pkgs', 'A', 'B', '_D.py'), 'w+').close()
        open(join(pwd, 'site_pkgs', 'A', 'B', '_D.pyi'), 'w+').close()

# Generated at 2022-06-23 15:28:29.757303
# Unit test for function gen_api
def test_gen_api():
    """Test the output of gen_api."""
    class Test:
        """Test class."""
        def __init__(self, a: int, b: int) -> None:
            self.a = a
            self.b = b
    doc = gen_api({'Test': 'pyslvs_ui.compiler'}, dry=True)[0]
    assert '<a href="#pyslvs_ui.compiler.Test">Test</a>' in doc

# Generated at 2022-06-23 15:28:40.760084
# Unit test for function gen_api
def test_gen_api():
    from collections import defaultdict
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import get_data
    from os.path import isfile, exists
    from .compiler import gen_api
    with TemporaryDirectory() as tmp:
        pkg = join(tmp, 'foo')
        mkdir(pkg)
        mkdir(join(pkg, 'bar'))
        copytree(dirname(__file__), abspath(join(tmp, 'foo', 'bar', '__init__.py')))
        _write(join(pkg, '__init__.py'), get_data('pyslvs', '__init__.py'))
        _write(join(pkg, 'bar', 'baz.py'), get_data('pyslvs', 'compiler.py'))

# Generated at 2022-06-23 15:28:46.154063
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__ as ver, __author__ as author
    logger.setLevel("DEBUG")
    pwd = abspath("../" + ".".join(("pyslvs",) + ver.split(".")))
    gen_api({"Pyslvs", "pyslvs"}, pwd)



# Generated at 2022-06-23 15:28:48.556334
# Unit test for function loader
def test_loader():
    """Test `loader` function."""
    print(loader('pyslvs', dirname(__file__) + '/__pyslvs__', True, 2, True))

# Generated at 2022-06-23 15:28:55.434042
# Unit test for function walk_packages
def test_walk_packages():
    from os import chdir, remove
    from os.path import dirname
    from tempfile import mkdtemp
    from shutil import rmtree
    from importlib.util import find_spec
    from textwrap import dedent

    chdir(mkdtemp())
    mkdir('test_walk_packages')
    _write('test_walk_packages/__init__.py', '')

# Generated at 2022-06-23 15:29:06.647757
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy2
    from os.path import basename

    with TemporaryDirectory() as dir:
        for name in ['hoge', 'fuga']:
            path = join(dir, name)
            copy2(__file__, path + '.py')
            copy2(__file__, path + '.pyi')
            mkdir(path + sep + 'dir')
            copy2(__file__, path + sep + 'dir' + sep + 'file.py')
            copy2(__file__, path + sep + 'dir' + sep + 'file.pyi')
            mkdir(path + sep + 'dir2')
            copy2(__file__, path + sep + 'dir2' + sep + 'file.pyi')


# Generated at 2022-06-23 15:29:16.549724
# Unit test for function walk_packages
def test_walk_packages():
    assert not isdir("test_temp")
    assert not isfile("test_temp/.py")
    assert not isfile("test_temp/__init__.py")
    assert not isfile("test_temp/test.py")
    assert not isfile("test_temp/__init__.pyi")
    assert not isfile("test_temp/test.pyi")
    mkdir("test_temp")
    open("test_temp/.py", 'w+').close()
    open("test_temp/__init__.py", 'w+').close()
    open("test_temp/test.py", 'w+').close()
    open("test_temp/__init__.pyi", 'w+').close()
    open("test_temp/test.pyi", 'w+').close()

# Generated at 2022-06-23 15:29:20.599443
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    doc = gen_api({"Pyslvs": "pyslvs"}, prefix="api", pwd=".", level=2, link=False,
                  toc=True, dry=True)
    assert len(doc)
    assert type(doc) is list


# Generated at 2022-06-23 15:29:30.451127
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        name, path = next(walk_packages("top", td))
        assert name == "top"
        assert path.endswith("top.py")
        name, path = next(walk_packages("top", td))
        assert name == "top.sub"
        assert path.endswith("top.sub.py")
        name, path = next(walk_packages("top", td))
        assert name == "top.sub.child"
        assert path.endswith("top.sub.child.py")
        name, path = next(walk_packages("top", td))
        assert name == "top.sub_"
        assert path.endswith("top.sub_.py")

# Generated at 2022-06-23 15:29:42.093305
# Unit test for function gen_api
def test_gen_api():
    from .parser import module_name
    from os.path import dirname, join
    from copy import copy
    from typing import Dict
    from .__main__ import __version__
    from .logger import logger as log
    d = dirname(dirname(dirname(dirname(__file__))))
    d = join(d, 'docs')
    gen_api(dict(
        slvs=module_name,
        PySLVS=module_name
    ), d, dry=True)
    gen_api(dict(
        slvs=module_name,
        PySLVS=module_name
    ), d, toc=True, dry=True)
    gen_api(dict(
        slvs=module_name,
        PySLVS=module_name
    ), d)