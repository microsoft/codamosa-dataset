

# Generated at 2022-06-23 15:19:47.395095
# Unit test for function walk_packages
def test_walk_packages():
    import pytest
    from os import getcwd, remove
    from os.path import isdir, join

    root = join(getcwd(), "test_walk_packages")
    mkdir(root)
    file_path = join(root, "test_package", "__init__.py")
    # No directory
    with pytest.raises(OSError):
        assert list(walk_packages("test_walk_packages", ".")) == []
    with pytest.raises(OSError):
        assert list(walk_packages("test_walk_packages", root)) == []
    # No file
    mkdir(join(root, "test_package"))
    assert list(walk_packages("test_walk_packages", root)) == []
    # Test result
    _write(file_path, "# This is a test file")


# Generated at 2022-06-23 15:19:51.211225
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .logger import logger
    logger.setLevel(20)
    doc = loader("tests", ".", False, 1, False)
    assert Parser.new(False, 1, False).compile() == doc

# Generated at 2022-06-23 15:19:55.855439
# Unit test for function loader
def test_loader():
    root_names = {"Solver": "solver", "Pyslvs": "pyslvs", "Virtual": "virtual"}
    pwd = r"C:\Program Files\Python38\Lib\site-packages"
    for doc in gen_api(root_names, pwd, dry=True):
        print(doc)

# Generated at 2022-06-23 15:19:57.989314
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test'}) == [
        '# test API\n\n',
    ]

# Generated at 2022-06-23 15:20:01.849430
# Unit test for function loader
def test_loader():
    """docstring"""
    from sys import modules
    del modules['_pyslvs_compiler']
    assert loader('pyslvs', '.', True, 1, False)
    from .parser import Parser
    assert Parser

# Generated at 2022-06-23 15:20:06.103553
# Unit test for function loader
def test_loader():
    """Write API to a file."""
    doc = loader("svg", "./src/pyslvs_ui/icons", True, 1, True)
    with open("output.md", "w+", encoding='utf-8') as f:
        f.write(doc)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:20:16.612898
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk_packages."""
    from collections import defaultdict
    from os.path import join
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    sec = ['__init__.py', 'a.pyi', 'b.py']
    _ = """
# foo.py
"""
    _ = """
# foo.pyi
"""
    _ = """
# a.pyi
"""
    _ = """
# a.py
"""
    _ = """
# b.py
"""
    _ = """
# c.py
"""
    manual = defaultdict(lambda: defaultdict(list))
    manual['foo']['stub'].extend(['foo.pyi'])

# Generated at 2022-06-23 15:20:18.322800
# Unit test for function gen_api
def test_gen_api():
    assert not gen_api({"pyslvs", "pyslvs"}, dry=True, toc=True)

# Generated at 2022-06-23 15:20:24.022296
# Unit test for function walk_packages
def test_walk_packages():
    from os import chdir, environ
    from os.path import dirname, join

    # Run in test environment
    root = dirname(__file__)
    environ["PYTHONPATH"] = join(root, "test", "site-packages") + ":" + root
    chdir(root)

    doc = loader('pyslvs', root, True, 1, True)
    assert doc.startswith('# pyslvs'), "No title for file"

# Generated at 2022-06-23 15:20:32.338735
# Unit test for function loader
def test_loader():
    from importlib import reload
    root = reload(parent(__name__))
    assert not root.__doc__
    assert not root.__loader__
    assert not root.__package__
    assert not root.__path__
    assert not root.__file__
    assert not root.__annotations__
    assert not root.__cached__
    name = root.__name__
    parent_name = parent(name)
    path = _site_path(parent_name)
    assert path
    doc = loader(name, path, link=False, level=1, toc=True)
    assert doc.startswith("# compiler")
    assert doc.endswith("Save data to json file.")
    assert "Load module directly." in doc
    assert "Package searching algorithm." in doc



# Generated at 2022-06-23 15:20:38.209064
# Unit test for function gen_api
def test_gen_api():
    """Return API for "numpy".

    Return:
        API for "numpy".
    """
    import numpy
    docs = gen_api(
        {'Numpy': 'numpy'},
        dirname(numpy.__file__),
        prefix='.',
        dry=True
    )
    assert docs[0].startswith('## Numpy API')
    assert '.. toctree::' in docs[0]
    assert 'def norm(x, ord=None, axis=None, keepdims=False)' in docs[0]

# Generated at 2022-06-23 15:20:49.999265
# Unit test for function gen_api
def test_gen_api():  # pragma: no cover
    from importlib import machinery
    from os import remove
    from os.path import exists
    from sys import path as sys_path
    from tempfile import mkdtemp
    from shutil import rmtree

# Generated at 2022-06-23 15:20:58.541239
# Unit test for function loader
def test_loader():
    """Should return nothing."""
    from pyslvs import (
        VPoint,
        VLink,
        vertex_pair_iter,
    )
    from pyslvs_ui import (
        VPoint,
        VLink,
        vertex_pair_iter,
    )
    from .path_planning import (
        VPoint,
        VLink,
        vertex_pair_iter,
    )
    from .io import (
        VPoint,
        VLink,
        vertex_pair_iter,
    )
    from .util import (
        VPoint,
        VLink,
        vertex_pair_iter,
    )
    from .compiler import (
        VPoint,
        VLink,
        vertex_pair_iter,
    )

# Generated at 2022-06-23 15:21:09.341830
# Unit test for function gen_api
def test_gen_api():
    from unittest.mock import patch
    from .logger import logger
    gen_api({'test': 'test'})
    assert logger.debug.called
    assert logger.info.called
    assert logger.warning.called
    with patch('pyslvs.compiler.logger.debug') as mock_debug:
        with patch('pyslvs.compiler.logger.info') as mock_info:
            with patch('pyslvs.compiler.logger.warning') as mock_warning:
                gen_api({'test': 'test'}, dry=True)
    assert not mock_debug.called
    assert not mock_info.called
    assert not mock_warning.called
    gen_api({'test': 'test'}, dry=True)

# Generated at 2022-06-23 15:21:10.524290
# Unit test for function gen_api
def test_gen_api():
    gen_api({'s': 's'}, dry=True)

# Generated at 2022-06-23 15:21:12.829151
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    from shutil import rmtree
    path = mkdtemp()
    doc = gen_api({'Test': 'test'}, pwd=path, level=3, dry=True)
    rmtree(path)

# Generated at 2022-06-23 15:21:14.309767
# Unit test for function gen_api
def test_gen_api():
    assert isinstance(gen_api({}), list)

# Generated at 2022-06-23 15:21:19.807274
# Unit test for function loader
def test_loader():
    """Test case of document loader."""
    doc = loader("pyslvs_ui", join(dirname(__file__), "..", "..", "..", "src"), True, 1, False)
    assert "ui.py" in doc
    assert "path.py" in doc

# Generated at 2022-06-23 15:21:24.025979
# Unit test for function loader
def test_loader():
    import tempfile
    fd, fp = tempfile.mkstemp()
    p = Parser.new(False, 1, False)
    assert not _load_module('test', fp, p)
    with open(fp, 'w') as f:
        f.write("def test(): return 'ok'")
    assert _load_module('test', fp, p)
    assert len(p.api) == 1

# Generated at 2022-06-23 15:21:30.988727
# Unit test for function loader
def test_loader():
    from importlib import import_module
    from os import remove
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from .logger import LOG

    def delete(name: str) -> None:
        try:
            remove(name)
        except FileNotFoundError:
            pass

    for ext in [".py", ".pyi"]:
        delete(resource_filename('pyslvs', '__init__' + ext))
        delete(resource_filename('pyslvs.ui', '__init__' + ext))
        delete(resource_filename('pyslvs_ui', '__init__' + ext))

    LOG.info("Loading library")
    with TemporaryDirectory() as pwd:
        loader('pyslvs', pwd, False, 0, False)

# Generated at 2022-06-23 15:21:37.486824
# Unit test for function loader
def test_loader():
    """Test API generator with pyslvs_ui as example."""
    sys_path.append("C:\\Users\\ycf\\AppData\\Local\\Programs\\Python\\Python38\\Lib\\site-packages")
    logger.info(f"Generate PySVSL UI API")
    doc = loader("pyslvs_ui", "", True, 3, True)
    assert doc.startswith("# PySVSL UI API")
    logger.info('=' * 12)
    logger.info(doc)

# Generated at 2022-06-23 15:21:44.074677
# Unit test for function walk_packages
def test_walk_packages():
    def get_list(name: str, path: str) -> Sequence[str]:
        return list(walk_packages(name, path))

    assert get_list('test', __file__) == [
        ('test.test_functions', join(abspath(dirname(__file__)), 'test_functions.py')),
        ('test.test_parser', join(abspath(dirname(__file__)), 'test_parser.py'))
    ]
    assert get_list('pyslvs', __file__) == []

# Generated at 2022-06-23 15:21:47.060940
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    assert loader('pyslvs', './pyslvs_win', False, 1, False).startswith(
        '# Pyslvs API\n\n'
    )



# Generated at 2022-06-23 15:21:57.317575
# Unit test for function walk_packages
def test_walk_packages():
    import shutil
    from os import remove
    from os.path import abspath, sep
    from unittest import TestCase

    class Test(TestCase):

        def setUp(self):
            try:
                mkdir("./test_walk-packages")
            except FileExistsError:
                pass
            try:
                mkdir("./test_walk-packages/test")
            except FileExistsError:
                pass
            try:
                mkdir("./test_walk-packages/test/stubs")
            except FileExistsError:
                pass

        def tearDown(self):
            shutil.rmtree("./test_walk-packages")

        def test(self) -> None:
            _write("./test_walk-packages/test_1.pyi", "")

# Generated at 2022-06-23 15:22:07.523700
# Unit test for function walk_packages
def test_walk_packages():
    def walk_and_check(*, path, prefix, name, f, exp_path=None, exp_name=None):
        exp_path = exp_path if exp_path is not None else f
        exp_name = exp_name if exp_name is not None else f.replace(sep, '.').removesuffix('.py')
        for a, b in walk_packages(name, path):
            if a != exp_name or b != prefix + exp_path:
                raise AssertionError
    # name is root
    walk_and_check(path='./tests/data/numbers/site', prefix='./tests/data/numbers/site/',
                   name='numbers', f='__init__.py')

# Generated at 2022-06-23 15:22:18.854345
# Unit test for function gen_api
def test_gen_api():
    import sys
    import os
    import shutil
    name_dict = {'pyslvs': 'pyslvs'}
    ret = gen_api(name_dict, sys.executable, prefix='prefix', link=False, level=1, toc=False, dry=True)
    assert(ret == ['# pyslvs API\n\n# Table of Contents\n\n# Entire API\n\n## pyslvs\n\ndocstring      \n# Table of Contents\n\n* [pyslvs](#pyslvs)\n\n<a name="pyslvs"></a>\n## pyslvs\n\ndocstring      \n'])
    name_dict = {'pyslvs': 'pyslvs'}

# Generated at 2022-06-23 15:22:27.637059
# Unit test for function walk_packages
def test_walk_packages():
    # fmt: off
    p = Parser.new(False, 3, False)
    p.parse("pyslvs_ui.__main__", """
        \"\"\"The main interface for the application.\"\"\"
        class MainWindow:
            \"\"\"The main window class.\"\"\"
            def open_file(self, file_path: str = None) -> None:
                \"\"\"Open a file.\"\"\"
                pass
            def save_file(self, file_path: str = None) -> None:
                \"\"\"Save a file.\"\"\"
                pass
        # File: pyslvs_ui/__main__.py
    """)

# Generated at 2022-06-23 15:22:36.586082
# Unit test for function walk_packages
def test_walk_packages():
    import string
    import random
    import tempfile
    import shutil
    from os.path import isfile

    def random_name() -> str:
        return ''.join(random.choices(string.ascii_letters, k=12))

    def random_path() -> str:
        return random_name() + sep + random_name() + sep

    backups = set(sys_path)
    path = tempfile.mkdtemp()
    sys_path.append(path)

    test_dirs = []
    test_dirs.append(random_path())
    test_dirs.append(random_path())
    test_dirs.append(random_path())
    for _ in range(10):
        test_dirs.append(random_path())


# Generated at 2022-06-23 15:22:38.834970
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('pkgutil', 'site-packages'))
    assert list(walk_packages('pkgutil', '.'))

# Generated at 2022-06-23 15:22:45.916687
# Unit test for function walk_packages
def test_walk_packages():
    _NAME = "test_package"
    _NAME_STUB = _NAME + PEP561_SUFFIX

    class SubModule:
        """This is a package with sub module."""
        pass

    class Module:
        """This is a package."""
        pass

    names = [
        "test_package.__init__",
        "test_package.__init__-stubs",
        "test_package.sub_module",
        "test_package.sub_module-stubs",
    ]

    for name, path in walk_packages(_NAME, "."):
        assert name in names
        assert f"{name}.py" == path
        names.remove(name)

# Generated at 2022-06-23 15:22:56.341773
# Unit test for function loader
def test_loader():
    from PIL import Image

# Generated at 2022-06-23 15:22:58.426336
# Unit test for function loader
def test_loader():
    from doctest import testmod
    testmod(verbose=True)

__all__ = ['gen_api']

# Generated at 2022-06-23 15:23:01.334531
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    for a, b in walk_packages("pyslvs", Path(__file__).parent.parent):
        print(a, b)



# Generated at 2022-06-23 15:23:02.720486
# Unit test for function walk_packages
def test_walk_packages():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:23:10.878522
# Unit test for function loader
def test_loader():
    """Unit test for gen_api."""
    docs = gen_api({
        'Tests': 'pyslvs_ui.tests',
        'Core': 'pyslvs_core',
        'Vtk': 'pyslvs_vtk',
        'UI': 'pyslvs_ui',
        'Qt': 'pyslvs_ui.qt',
        'Modules': 'pyslvs_ui.modules',
    }, dry=True)
    for i, doc in enumerate(docs):
        print(f"document {i + 1}")
        print('-' * 40)
        print(doc)

# Generated at 2022-06-23 15:23:20.151928
# Unit test for function loader
def test_loader():
    # Test custom package
    from .test import test as test_test
    from .test.t import test as test_test_t
    from .test.t.test import test as test_test_t_test
    # Not direct import
    from . import test
    # Test `__all__`
    from .test import *
    assert test_test == "test"
    assert test_test_t == "t"
    assert test_test_t_test == "test"
    assert test == "test"
    doc = _run(
        "test",
        join(dirname(__file__), "..", "..", "tests", "test_loader", "test"),
        ".."
    )
    assert doc

# Generated at 2022-06-23 15:23:23.736904
# Unit test for function walk_packages
def test_walk_packages():
    from .test import name, pwd
    for name, path in walk_packages(name, pwd):
        print(f"{name} <= {path}")

# Generated at 2022-06-23 15:23:35.214256
# Unit test for function loader
def test_loader():
    """Test cases."""
    import platform
    if platform.system() == 'Windows':
        logger.warning('Please disable unit test loader in Windows')
        return True
    from .compiler import (
        _read,
        _write,
        _load_module,
        loader,
        walk_packages
    )
    from PySide2 import QtCore
    from shiboken2 import wrapInstance
    import pyslvs_ui.about
    from .parser import Parser
    from .logger import logger
    import sys

    logger.warning(f"Rebuilding PySide2 C++ modules {QtCore.__file__}")
    sub = sys.executable.rsplit('/', 1)[0] + '/pyside2_postinstall.py'

# Generated at 2022-06-23 15:23:41.270466
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    pwd = tempfile.mkdtemp()
    with open(join(pwd, 'a.py'), 'w+') as f:
        f.write('def a(): pass')
    with open(join(pwd, 'b.py'), 'w+') as f:
        f.write('def b(): pass')
    docs = gen_api({'A': 'a', 'B': 'b'}, pwd, dry=True)
    for doc in docs:
        assert 'a()' in doc
    assert 'b()' in docs[1]

# Generated at 2022-06-23 15:23:48.048180
# Unit test for function gen_api
def test_gen_api():
    from importlib import import_module
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    import shutil
    from pkg_resources import parse_version
    from pyslvs import __version__ as ver
    f = import_module('pyslvs_ui.compiler').gen_api

# Generated at 2022-06-23 15:23:50.141757
# Unit test for function gen_api
def test_gen_api():
    gen_api({'SVGE': 'svge'}, pwd='./', dry=True)


# Generated at 2022-06-23 15:24:00.565757
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        td_path = td + sep
        # Create a folder named `sys`
        mkdir(join(td_path, 'sys'))
        path = join(td_path, 'sys', '__init__.pyi')
        _write(path, "'''Test module 1.'''")
        assert walk_packages('sys', td_path) == [('sys', td_path + 'sys')]
        # Create a nested folder named `sys.sub`
        mkdir(join(td_path, 'sys', 'sub'))
        path = join(td_path, 'sys', 'sub', '__init__.pyi')
        _write(path, "'''Test module 2.'''")
       

# Generated at 2022-06-23 15:24:04.652722
# Unit test for function walk_packages
def test_walk_packages():
    from .tests.test_load_api import test_dir
    print(list(walk_packages('pyslvs', f"{test_dir}/site-packages")))
    from .tests.test_load_api import test_dir_duplicate
    print(list(walk_packages('pyslvs', f"{test_dir_duplicate}/site-packages")))

# Generated at 2022-06-23 15:24:09.830690
# Unit test for function walk_packages
def test_walk_packages():
    """
    >>> from .compiler import walk_packages
    >>> from pprint import pprint
    >>> from sys import path
    >>> from os import getcwd
    >>> path.append(getcwd())
    >>> pprint(dict(walk_packages("test", ".")))
    {'test': '.\\test\\__init__.py',
     'test.test1': '.\\test\\test1\\__init__.py',
     'test.test1.test2': '.\\test\\test1\\test2\\__init__.py'}
    """

# Generated at 2022-06-23 15:24:16.807799
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages."""

    def check(name: str, path: str) -> None:
        """Check package name and path."""
        assert name.startswith('test')
        assert parent(path).endswith(name.replace('.', sep))

    for name, path in walk_packages('test', 'tests'):
        check(name, path)
        check(name.replace('.__init__', ''), path)
    logger.info('All tests passed!')

# Generated at 2022-06-23 15:24:20.443439
# Unit test for function gen_api
def test_gen_api():
    """Test case for function gen_api"""
    print(gen_api({
        "Pyslvs": "pyslvs",
        "Pyslvs-UI": "pyslvs_ui",
    }))



# Generated at 2022-06-23 15:24:27.221861
# Unit test for function loader
def test_loader():
    from pathlib import Path
    from sys import platform
    from importlib import import_module
    from tests.parser import Parser
    from tests.compiler.data import root_names
    pwd = str(Path(__file__).parent)
    p = Parser()
    # TODO: Remove this platform check.
    # The Pyslvs project needs to be updated on Windows and Mac.
    if platform == "win32":
        return
    for _, name in root_names.items():
        for name, path in walk_packages(name, pwd):
            p.parse(name, _read(path + ".py"))
            for ext in EXTENSION_SUFFIXES:
                if not isfile(path + ext):
                    continue

# Generated at 2022-06-23 15:24:38.750820
# Unit test for function walk_packages
def test_walk_packages():
    from os import rmdir, remove as rm
    from tempfile import mkdtemp
    from shutil import move
    from sys import platform

    is_win = platform in ('win32', 'cygwin')

    def tmp_path(*args) -> str:
        return join(*args, dir=pwd)

    def mk_pkg(name: str, sub: Optional[str] = None, n: int = 0) -> None:
        mkdir(tmp_path(name, sub) if sub is not None else tmp_path(name))
        with open(tmp_path(name, sub, f"__init__.py"), 'w+'):
            pass
        for i in range(n):
            with open(tmp_path(name, sub, f"test{i}.py"), 'w+'):
                pass


# Generated at 2022-06-23 15:24:48.501860
# Unit test for function walk_packages
def test_walk_packages():
    def mock_walk(path):
        for root, _, fs in walk(path):
            for f in fs:
                if not f.endswith(('py', 'pyi')):
                    continue
                f_path = root + sep + f
                yield f_path if f_path.endswith('.pyi') else f_path[:-3]
    fake_path = '/home/user/path-to-pkg/pkg'
    fake_pkg = '/home/user/.local/lib/python3.6/site-packages/pkg'
    fake_pkg_stubs = '/home/user/.local/lib/python3.6/site-packages/pkg-stubs'

# Generated at 2022-06-23 15:24:56.271331
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs",
                                    r"D:\Projects\lib\python\site-packages"):
        print(f"{name} <= {path}")
    for name, path in walk_packages("pyslvs",
                                    r"D:\Projects\lib\python\site-packages"):
        print(f"{name} <= {path}")
    assert True

# Generated at 2022-06-23 15:24:58.436879
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in sorted(walk_packages('yaml', '/Users/changyuan/Desktop/py37/lib/python3.7/site-packages')):
        print(name, path)

# Generated at 2022-06-23 15:25:04.701997
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import pyslvs_ui
    prefix, name, title = "docs", "pyslvs_ui", "Pyslvs UI"
    gen_api({title: name}, pwd=dirname(abspath(pyslvs_ui.__file__)))
    assert isfile(join(prefix, f"{name.replace('_', '-')}-api.md"))
    import os, shutil
    os.remove(join(prefix, f"{name.replace('_', '-')}-api.md"))
    shutil.rmtree(prefix)

# Generated at 2022-06-23 15:25:14.957923
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    # This function can only run on Windows for now
    if not __debug__ or sep != '\\':
        return
    from tempfile import TemporaryDirectory

    def create_concreted(name: str) -> None:
        with open(join(tempdir, name), 'w+') as f:
            f.write('import concreted_module')
        with open(join(tempdir, 'concreted_module.py'), 'w+') as f:
            f.write('class M:\n    pass')

    def create_stub(name: str) -> None:
        with open(join(tempdir, f'{name}.pyi'), 'w+') as f:
            f.write('import concreted_module\nclass M:\n    pass')


# Generated at 2022-06-23 15:25:17.154714
# Unit test for function loader
def test_loader():
    print(loader("pyslvs", dirname(__file__), False, 1, False))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:25:25.469617
# Unit test for function gen_api
def test_gen_api():  # pragma: no cover
    """Unit test for function gen_api."""
    import tempfile
    import shutil
    from pkgutil import walk_packages
    from logging import DEBUG, basicConfig
    basicConfig(level=DEBUG)

    with tempfile.TemporaryDirectory() as t:
        shutil.copytree('solvespace', t + '/solvespace')
        gen_api({'Solvespace': 'solvespace.solvespace'}, t, toc=True)

    for _ in walk_packages(t + '/solvespace'):
        print('.', end='', flush=True)
    print()


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:25:28.123108
# Unit test for function walk_packages
def test_walk_packages():
    logger.debug("Walk packages:")
    for name, path in walk_packages("__root__", '.'):
        logger.debug(f"{name} <= {path}")

# Generated at 2022-06-23 15:25:39.182172
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk_packages"""

# Generated at 2022-06-23 15:25:50.285870
# Unit test for function walk_packages
def test_walk_packages():
    "Unit test for function walk_packages"
    import sys
    import tempfile
    import pathlib
    import shutil
    root = 'test'
    pkg = root + '.pkg'
    pyb = root + '.pyb'
    pyi = root + '.pyi'
    pyb2 = pkg + '.pyb2'
    tmpdir = tempfile.mkdtemp()
    srcdir = pathlib.Path(tmpdir) / root
    srcdir.mkdir()
    (srcdir / pkg).mkdir()
    # Create .py
    (srcdir / root).write_text('')
    (srcdir / pkg / pyb2).write_text('')
    # Create .pyi
    (srcdir / pyi).touch()
    (srcdir / pkg / pyb).touch

# Generated at 2022-06-23 15:25:55.213678
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({'Solver': 'solver', 'E2D': 'e2d'})
    assert 'e2d' in docs[1]
    assert "# solver.version" in docs[0]
    assert "# e2d.version" in docs[1]
    assert "solver.__init__" in docs[0]

# Generated at 2022-06-23 15:26:05.889491
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from unittest import TestCase, main
    from hashlib import sha256
    from .utils import get_path
    from .convert import patch_compiler

    class Test(TestCase):

        """Test cases."""

        def setUp(self) -> None:
            """Load the whole script."""
            self.path = get_path('example.py')
            with open(self.path, encoding='utf-8') as f:
                self.script = f.read()
            patch_compiler()

        def test_sha256(self) -> None:
            """Test the function loader."""
            doc = loader('example', get_path(''), True, 4, True)

# Generated at 2022-06-23 15:26:16.501584
# Unit test for function walk_packages
def test_walk_packages():
    from sys import path as sys_path
    from os import remove
    from os.path import dirname
    from importlib.machinery import ExtensionFileLoader
    from tempfile import mkdtemp

    tempdir = mkdtemp()
    sys_path.append(tempdir)

    open(f"{tempdir}{sep}test.py", 'w').close()
    open(f"{tempdir}{sep}test.pyi", 'w').close()

    # Test if the existence of __init__ is skip
    mkdir(f"{tempdir}{sep}__init__")
    open(f"{tempdir}{sep}__init__{sep}__init__.py", 'w').close()

    # Test if the existence of __pycache__ is skip

# Generated at 2022-06-23 15:26:27.045495
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import exists
    from shutil import rmtree
    import random
    import uuid
    test_path = 'tests/test_walk_packages'
    if exists(test_path) and not isdir('tests'):
        rmtree(test_path)
    files = list(walk_packages("test_walk_packages", join(test_path, "..")))
    assert files
    # Create random files
    n = random.randint(100, 200)
    for _ in range(n):
        with open(join(test_path, f"{uuid.uuid4()}.py"), "w"):
            pass
    assert len(files) == len(list(walk_packages("test_walk_packages",
                                                join(test_path, ".."))))
    # Clean the test path

# Generated at 2022-06-23 15:26:29.746226
# Unit test for function loader
def test_loader():
    """Import module from abc."""
    _load_module('collections.abc', join(sep, 'usr', 'lib', 'python3.8', 'abc.py'), Parser.new())

# Generated at 2022-06-23 15:26:37.333741
# Unit test for function walk_packages
def test_walk_packages():
    from slvs.compiler import walk_packages

# Generated at 2022-06-23 15:26:47.850986
# Unit test for function walk_packages
def test_walk_packages():
    pwd = join(dirname(__file__), "example")
    name = "qm"
    paths = []
    for name, path in walk_packages(name, pwd):
        # Ensure the path is right
        path_suffix = path.replace(pwd, '.')
        assert path_suffix.startswith(f"{name}.__init__"), \
            f"{path_suffix} is not `{name}.__init__`"
        paths.append(path_suffix)

# Generated at 2022-06-23 15:26:58.070625
# Unit test for function walk_packages
def test_walk_packages():
    from collections import Counter
    pm = Counter()
    for name, path in walk_packages("numpy", _site_path("numpy")):
        pm[name] += 1
        assert pm[name] == 1
        assert isdir(path)

# Generated at 2022-06-23 15:27:07.121517
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import tempfile
    pwd = tempfile.mkdtemp()

# Generated at 2022-06-23 15:27:19.065916
# Unit test for function walk_packages
def test_walk_packages():
    import pytest
    from tempfile import TemporaryDirectory
    from .core.__main__ import main
    with TemporaryDirectory() as d:
        main(f"--pwd={d}", "--api-list", "--dry", "--level=2")
        for name, _ in walk_packages('', d):
            assert name == 'core'
    with TemporaryDirectory() as d:
        mkdir(join(d, 'a'))
        _write(join(d, 'a', '__init__.py'), 'from b import b')
        _write(join(d, 'a', 'a.py'), 'from b.b import b')
        _write(join(d, 'a', 'd.py'), 'from b.b import b')
        mkdir(join(d, 'b'))

# Generated at 2022-06-23 15:27:24.881954
# Unit test for function gen_api
def test_gen_api():
    import os
    import slvs
    os.chdir(os.path.dirname(os.path.abspath(slvs.__file__)))
    logger.setLevel(10)
    gen_api({'ABC': 'abc'}, prefix='../test_doc', dry=True)
    gen_api({'Solver': 'pyslvs_ui'}, prefix='../test_doc', dry=True)
    gen_api({'Numpy': 'numpy'}, pwd='..', prefix='../test_doc', dry=True)

# Generated at 2022-06-23 15:27:35.233232
# Unit test for function gen_api
def test_gen_api():
    root_names = {str(a): str(a) for a in range(1, 250)}
    from tempfile import TemporaryDirectory
    from os import chdir
    with TemporaryDirectory() as t_dir:
        chdir(t_dir)
        for a in range(1, 250):
            mkdir(f'{a}')
            if a % 5 == 0:
                open(f'{a}/__init__.py', 'w+').close()
            else:
                open(f'{a}/{a}.py', 'w+').close()
        gen_api(root_names, '.', dry=True)
    return True

# Generated at 2022-06-23 15:27:44.602277
# Unit test for function gen_api
def test_gen_api():
    """Test function `gen_api`."""
    assert gen_api({'math': 'math'})
    assert gen_api({'math': 'math'}, pwd=_site_path('math'))
    assert gen_api({'pyslvs': 'pyslvs'})
    assert gen_api({'pyslvs': 'pyslvs'}, pwd=_site_path('pyslvs'))
    assert gen_api({'pyslvs': 'pyslvs'}, dry=True)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:27:52.362630
# Unit test for function walk_packages
def test_walk_packages():
    def check(name, path, valid):
        assert name == valid[0]
        assert path == valid[1]


# Generated at 2022-06-23 15:27:58.992893
# Unit test for function walk_packages
def test_walk_packages():
    a = {}
    for i in walk_packages("temp", "."):
        a[i[0]] = i[1]
    assert a["a"] == ".\\temp\\a.py"
    assert a["b.c.d"] == ".\\temp\\b\\c\\d.pyi"
    assert a["b.c.e"] == ".\\temp\\b\\c\\e.py"

# Generated at 2022-06-23 15:28:05.126085
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api"""
    import qtawesome

    logger.disable()
    docs = gen_api({"QtAwesome": "qtawesome"}, prefix=".test", dry=True, link=False, level=2)
    assert docs[0].startswith('## QtAwesome API\n\n')
    logger.disable(False)
    logger.info(docs[0])

    try:
        logger.disable()
        gen_api({"QtAwesome": "QtAwesome"}, prefix=".test", dry=True, link=False, level=2)
    except ImportError:
        pass
    else:
        raise RuntimeError("Error: should not reach here")
    logger.disable(False)
    logger.info("Successful")

test_gen_api()

# Generated at 2022-06-23 15:28:13.171111
# Unit test for function loader
def test_loader():
    """Test loader function."""
    import sys
    import os
    import shutil
    sys.path.append('tests')
    from .test_loader import mock_package_distribute
    from .logger import logger, logger_post

    def _log(message: str) -> None:
        if logger is not None:
            logger.info(message)

    _log('=' * 12)

    # mkdir & copy to temp files
    path = mock_package_distribute()
    # print(path)
    try:
        # Test loader
        docs = gen_api(
            {"pyslvs", "pyslvs-stubs"},
            path,
            prefix='build/docs',
            dry=True
        )
        assert docs
    finally:
        shutil.rmtree(path)


# Generated at 2022-06-23 15:28:18.820635
# Unit test for function walk_packages
def test_walk_packages():
    l = list(walk_packages("demo_pkg", join(dirname(__file__), "stubs")))
    logger.debug(f"{l}")
    assert len(l) == 3 and ["demo_pkg", "demo_pkg.module_1", "demo_pkg.module_2"] == [i[0] for i in l]



# Generated at 2022-06-23 15:28:28.710345
# Unit test for function loader
def test_loader():
    import pytest
    from .test_script import root
    from .test_script.inner import Inner
    pwd = abspath(root.__file__)
    logger.debug(f"{pwd}")
    parser = loader(root.__name__, pwd, False, 0, False)
    parser.replace('Inner = None', 'Inner = str')
    parser.replace('Inner.__doc__ = None', '')
    assert "# Package" in parser
    assert "# Class Inner" not in parser
    assert "# Function add" in parser
    assert "# Function sub" in parser
    assert ".. py:function::" in parser
    assert "abs" in parser
    assert "print" in parser
    assert "Inner = str" in parser

# Generated at 2022-06-23 15:28:31.302031
# Unit test for function walk_packages
def test_walk_packages():
    print("Test `walk_packages`:")
    path = abspath(join('tests', 'test_package'))
    print(path)
    print(list(walk_packages('test_package', path)))

# Generated at 2022-06-23 15:28:42.164227
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    # Test packages and stubs
    target_dir = TemporaryDirectory()
    path = target_dir.name
    with open(join(path, 'test_file.txt'), 'w'):
        pass
    copyfile(__file__, join(path, '__init__.py'))
    copyfile(__file__, join(path, 'test_file.pyi'))
    copyfile(__file__, join(path, 'pkg1.py'))
    copyfile(__file__, join(path, 'pkg2.py'))
    copyfile(__file__, join(path, 'pkg2.pyi'))
    copyfile(__file__, join(path, 'pkg3.so'))

# Generated at 2022-06-23 15:28:50.361311
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .logger import Logger

    def gen():
        for _ in Parser.new(True, 1, False).compile():
            yield _

    def gen2():
        for _ in Parser.new(True, 1, False).compile():
            yield _

    def test(logger: Logger, *args: str) -> None:
        logger.set_level(10)
        try:
            loader(*args)
        except Exception as e:
            logger.exception(e)
        assert gen() == gen2()

    test(logger, 'collections', './__init__.py')
    test(logger, 'configparser', './__init__.py')
    test(logger, 'contextlib', './__init__.py')

# Generated at 2022-06-23 15:28:54.128774
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    import shutil
    root = tempfile.mkdtemp()
    try:
        p = join(root, 'foo', 'bar', '__init__.pyi')
        mkdir(parent(p))
        _write(p, "\n")
        assert ['foo.bar'] == list(walk_packages('foo', root))
    finally:
        shutil.rmtree(root)

# Generated at 2022-06-23 15:29:00.962976
# Unit test for function walk_packages
def test_walk_packages():
    class Fake:
        @staticmethod
        def find_spec(name):
            return lambda: name

    import importlib
    importlib.import_module = Fake
    root = 'pyslvs'
    path = dirname(dirname(abspath(__file__)))
    names = {name for name, path in walk_packages(root, path)}
    assert 'pyslvs.system' in names
    assert 'pyslvs.system.__init__' in names
    assert len(names) == 8

# Generated at 2022-06-23 15:29:11.454752
# Unit test for function loader
def test_loader():
    from sys import path
    path.append(r"D:\Projects\PySLVS\pyslvs_ui\test\test_module")

# Generated at 2022-06-23 15:29:12.684099
# Unit test for function walk_packages
def test_walk_packages():
    assert tuple(walk_packages('foo', '/bar')) == ()


# Generated at 2022-06-23 15:29:22.255105
# Unit test for function loader
def test_loader():  # pragma: no cover
    import sys
    import os
    import tempfile
    pkg_name: str = 'test_loader'
    root_name: str = 'root'
    name: str = pkg_name + '.' + root_name
    with tempfile.TemporaryDirectory() as tmpdir:
        pkgdir = os.path.join(tmpdir, pkg_name)
        rootdir = os.path.join(pkgdir, root_name)
        os.makedirs(rootdir)
        with open(os.path.join(pkgdir, '__init__.py'), mode='w') as f:
            f.write('from doc_gen import test_loader\n')
        sys.path.insert(0, tmpdir)
        assert _site_path(pkg_name) == pkgdir


# Generated at 2022-06-23 15:29:25.684111
# Unit test for function loader
def test_loader():
    """Test the generator function."""
    r = loader('pyslvs', 'tests', link=True, level=1, toc=False)
    print(r)

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:29:37.150384
# Unit test for function walk_packages
def test_walk_packages():

    def test1():
        text = """
        #!/usr/bin/python3
        # -*- coding:utf-8 -*-

        \"\"\"Module docstring.\"\"\"

        import sys

        class Test:

            \"\"\"Test docstring.\"\"\"

            def f(self):
                \"\"\"F docstring.\"\"\"
                pass

        def f():
            \"\"\"F docstring.\"\"\"
            pass
        """

        def f(name, path):
            assert name == "test.Test" and path == "__init__.py"

        walk_packages("foo.bar", "test")


# Generated at 2022-06-23 15:29:45.990734
# Unit test for function walk_packages
def test_walk_packages():
    def assert_true(func, *args):
        logger.info(f"testing function: {func.__name__}")
        assert func(*args) is True
    logger.info("testing function walk_packages")
    assert_true(isdir, join("test_data", "module1"))
    assert_true(isdir, join("test_data", "module2"))
    assert_true(isdir, join("test_data", "module3"))
    assert_true(isdir, join("test_data", "module4"))
    assert_true(isdir, join("test_data", "module5"))
    assert_true(isdir, join("test_data", "module6"))
    print(">>>")
    for name, path in walk_packages("module1", "test_data"):
        print(name, path)