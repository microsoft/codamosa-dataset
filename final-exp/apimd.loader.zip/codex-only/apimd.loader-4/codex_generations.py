

# Generated at 2022-06-23 15:19:50.957336
# Unit test for function gen_api
def test_gen_api():
    import sys
    import pyslvs_ui
    sys_path.insert(0, dirname(pyslvs_ui.__file__))
    root_names = {
        'Canvas Widget': 'pyslvs_ui.widgets.canvas_widget.canvas_widget',
        'Mechanism Widget': 'pyslvs_ui.widgets.mechanism_widget.mechanism_widget',
        'Options': 'pyslvs_ui.options.options',
        'Preset Data': 'pyslvs_ui.data.preset_data',
        'Project Data': 'pyslvs_ui.data.project_data',
        'VComp Data': 'pyslvs_ui.data.vcomp_data',
    }

# Generated at 2022-06-23 15:19:58.694718
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import dirname, join
    from tempfile import TemporaryDirectory
    from shutil import copy, copytree
    from pprint import pprint

    with TemporaryDirectory() as tmp:
        root = join(tmp, "sp")
        copytree(join(dirname(__file__), "test", "sp"), root)
        copy(join(dirname(__file__), "test", "test.pyi"), join(root, "test", "test.pyi"))
        pprint(list(walk_packages("test", tmp)))

# Generated at 2022-06-23 15:20:01.745609
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'Uno': 'pyslvs', 'Duo': 'pyslvs_ui'}, pwd='../', dry=True)


# Generated at 2022-06-23 15:20:06.338233
# Unit test for function loader
def test_loader():
    from os import chdir
    from os.path import dirname
    print("site-packages:", _site_path("pyslvs_ui"))
    chdir(dirname(__file__))
    print("pyslvs:", loader("pyslvs", "../", True, 1, True))
    print("modules:", loader("test", ".", True, 1, True))

# Generated at 2022-06-23 15:20:16.803782
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    class Root(str):
        """Monkey patch the root."""
        def __getattr__(self, item: str) -> str:
            """Get attributes."""
            # Monkey patch for importlib.util.find_spec
            if item == self:
                return self
            return super().__getattr__(item)

        def __getitem__(self, index: int) -> str:
            """Get items."""
            # Monkey patch for importlib.machinery.EXTENSION_SUFFIXES
            if index == 0:
                return ".so"
            return super().__getitem__(index)

    import sys
    old_path = sys.path
    sys.path = ['']

# Generated at 2022-06-23 15:20:27.807333
# Unit test for function loader
def test_loader():
    from .lib import gen_api

    # Make the parent directory `site-packages`
    mkdir('site-packages')
    # Make a test package structure
    mkdir(join('site-packages', 'test_pkg'))
    _write(join('site-packages', 'test_pkg', '__init__.py'), '')
    _write(join('site-packages', 'test_pkg', '__init__.pyi'), '')
    _write(join('site-packages', 'test_pkg', 'abc.py'), '"""abc."""')
    _write(join('site-packages', 'test_pkg', 'foo.py'), '"""foo."""')
    _write(join('site-packages', 'test_pkg', 'bar.py'), '"""bar."""')

# Generated at 2022-06-23 15:20:30.266555
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('a', 'b')) == []
    assert list(walk_packages('a', 'b')) == []
    assert list(walk_packages('a', 'b')) == []

# Generated at 2022-06-23 15:20:38.958031
# Unit test for function loader
def test_loader():
    """Test the module loader."""
    p = Parser.new(True, 1, True)
    assert _load_module("pyslvs", "pyslvs.py", p)
    assert _load_module("pyslvs.core", "core.py", p)
    assert _load_module("pyslvs", "pyslvs.pyi", p)
    assert _load_module("pyslvs.core", "core.pyi", p)
    assert _load_module("pyslvs", "pyslvs.pyx", p)
    assert _load_module("pyslvs.core", "core.pyx", p)
    assert not _load_module("pyslvs.structure", "structure.py", p)

# Generated at 2022-06-23 15:20:46.580941
# Unit test for function walk_packages
def test_walk_packages():
    """The unit test."""
    test_path = tmpdir()
    mkdir(join(test_path, 'test'))
    with open(join(test_path, 'test', '__init__.py'), 'w+') as f:
        f.write('def hello():\n    print("Hello world")')
    assert walk_packages('test', test_path) == [
        ('test', join(test_path, 'test')),
    ]

# Generated at 2022-06-23 15:20:50.803624
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'API': 'pyslvs',
        'Test API': 'tests',
    }
    gen_api(root_names, '.', prefix='docs/modules')

# Generated at 2022-06-23 15:20:56.224332
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
        'Pyslvs-Extensions': 'pyslvs_extensions',
        'Pyslvs-Solver': 'pyslvs_solver',
        'Pyslvs-Qt': 'pyslvs_qt',
    }, pwd='/path/to/site-packages/', dry=True)

# Generated at 2022-06-23 15:21:03.236973
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from os.path import dirname, join
    from shutil import rmtree
    from pprint import pprint
    temp = join('.', 'temp')
    makedirs(join(temp, 'a', 'a', 'a'))
    makedirs(join(temp, 'a', 'b'))
    makedirs(join(temp, 'b'))
    makedirs(join(temp, 'a', 'a', 'a-stubs'))
    makedirs(join(temp, 'a', 'b-stubs'))

# Generated at 2022-06-23 15:21:11.108665
# Unit test for function gen_api
def test_gen_api():
    from os.path import dirname, exists, getsize
    from os import remove
    import pyslvs
    pwd = dirname(_site_path('pyslvs'))
    docs = gen_api({
        'PySLVS': 'pyslvs',
        'PySLVS-UI': 'pyslvs_ui',
    }, pwd, prefix='test/docs', dry=True)
    assert len(docs) == 2
    assert exists('test/docs/pyslvs-api.md')
    assert exists('test/docs/pyslvs-ui-api.md')
    assert getsize('test/docs/pyslvs-api.md') > 1500
    assert getsize('test/docs/pyslvs-ui-api.md') > 1000

# Generated at 2022-06-23 15:21:22.736662
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from unittest import TestCase, main

    def gen_test(doc: str, name: str) -> None:
        def test(self: TestCase) -> None:
            self.assertEqual(loader(name, "./test", link=False, level=2, toc=False), doc)
        return test

    class Test(TestCase):

        pass


# Generated at 2022-06-23 15:21:25.344332
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    assert gen_api({
        "PySLVS": "pyslvs"
    })
    assert gen_api({
        "PySLVS": "pyslvs"
    }, ".", dry=True)

# Generated at 2022-06-23 15:21:36.631320
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pytest import raises
    from .solver_parser import docstring_parser

    def test_pwd(pwd: str) -> None:
        loader('PACKAGE', pwd, False, 1, False)
        loader('PACKAGE', pwd, False, 2, False)
        loader('PACKAGE', pwd, True, 1, False)
        loader('PACKAGE', pwd, True, 2, False)
        loader('PACKAGE', pwd, False, 1, True)
        loader('PACKAGE', pwd, False, 2, True)
        loader('PACKAGE', pwd, True, 1, True)
        loader('PACKAGE', pwd, True, 2, True)

# Generated at 2022-06-23 15:21:46.033438
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory, TemporaryFile
    from pathlib import Path

    def _dump_code(paths: list[str]):
        for p in paths:
            with open(p, 'w') as f:
                f.write('\n'.join(
                    '    """Docstring for {}.{}."""'.format(parent(p.name), i)
                    for i in range(10)
                ))

    paths: list[str] = []

    # Create a test file tree
    with TemporaryDirectory() as d:
        logger.info(f"Create directory: {d}")
        path = Path(d)
        (path / 'test').mkdir()
        (path / 'test_2').mkdir()
        (path / 'test_3').mkdir()

# Generated at 2022-06-23 15:21:53.898879
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    docs = gen_api({'test': 'pyslvs_test'},
                   pwd=dirname(__file__),
                   prefix='docs',
                   link=True,
                   level=1,
                   toc=False,
                   dry=True)
    assert len(docs) == 1
    assert '# pyslvs_test API' in docs[0]
    assert '## classmethod test_gen_api()' in docs[0]
    assert 'Test for function gen_api.' in docs[0]

# Generated at 2022-06-23 15:21:55.589066
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages('solve', 'solve'))) > 0

# Generated at 2022-06-23 15:21:59.921652
# Unit test for function loader
def test_loader():
    """Test loader."""
    from .parser import Parser
    from .test_module import __file__ as src
    p = Parser.new(False, 1, False)
    _load_module('test_module', src, p)
    p.compile()



# Generated at 2022-06-23 15:22:03.632839
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    import os
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase, main
    from pyfakefs.fake_filesystem_unittest import TestCaseMixin


# Generated at 2022-06-23 15:22:10.415050
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    from os import remove
    from os.path import dirname
    from tempfile import mkdtemp
    from shutil import copytree

    def create_package(path: str):
        with open(join(path, '__init__.py'), 'w+') as f:
            pass

    def create_package_stubs(path: str):
        with open(join(path, '__init__.pyi'), 'w+') as f:
            pass

    def create_module(name: str, path: str, doc: str):
        with open(join(path, f'{name}.py'), 'w+') as f:
            f.write(doc)


# Generated at 2022-06-23 15:22:21.011232
# Unit test for function walk_packages
def test_walk_packages():
    # Make a directory
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pathlib import Path
    with TemporaryDirectory() as root_path:
        # Create a directory
        Path(root_path, 'pyslvs_ui').mkdir(parents=True)
        # Create a package
        Path(root_path, 'pyslvs_ui', '__init__.py').touch()
        Path(root_path, 'pyslvs_ui', 'core.py').touch()
        Path(root_path, 'pyslvs_ui', 'core.pyi').touch()
        # Create a module
        Path(root_path, 'pyslvs_ui', '__main__.py').touch()

# Generated at 2022-06-23 15:22:29.462231
# Unit test for function loader
def test_loader():
    """Unit test for symbol parser."""
    # pylint: disable=import-outside-toplevel
    from .parser import Symbol

    def check_symbol(s: str) -> None:
        """Check the symbol."""
        assert p.s_map[s] is not None, f"Symbol {s} can not be found"

    p = Parser.new(False, 0, False)

# Generated at 2022-06-23 15:22:34.442816
# Unit test for function loader
def test_loader():
    from .test import root_names, create_test_package
    from .test_pytest import test_data
    pwd = create_test_package(test_data)
    for title, name in root_names.items():
        logger.info(f"Load root: {name} ({title})")
        doc = loader(name, pwd, True, 2, True)
        assert doc.strip()
    logger.info("Test complete!")

# Generated at 2022-06-23 15:22:39.223596
# Unit test for function loader
def test_loader():
    import sys
    import os
    import site
    pwd = os.getcwd()
    pwd = pwd + os.sep
    root = "uranium"
    site_path = site.getsitepackages()
    site_path = site_path + os.sep
    path = pwd + root + os.sep
    doc = loader(root, pwd, False, 1, False)
    print(doc)

# Generated at 2022-06-23 15:22:42.156510
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import shutil

    def _mkdir(p):
        if not os.path.isdir(p):
            os.mkdir(p)


# Generated at 2022-06-23 15:22:49.712456
# Unit test for function gen_api
def test_gen_api():
    from os import chdir
    from tempfile import TemporaryDirectory
    from importlib import import_module

    root_names = {'Dummy Title': 'dummy_title'}
    with TemporaryDirectory() as d:
        chdir(d)
        __import__('dummy_title.__init__')
        import_module('dummy_title.A')
        import_module('dummy_title.A.__init__')
        import_module('dummy_title.A.a_stub')
        import_module('dummy_title.A.B')
        import_module('dummy_title.A.B.b_stub')
        import_module('dummy_title.A.B.C')
        import_module('dummy_title.A.B.C.c_stub')
        import_

# Generated at 2022-06-23 15:22:53.394889
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    assert loader('', '', False, 1, False) == ''
    assert loader('', '', True, 1, False) == ''


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:23:01.286129
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import remove
    from . import _scripts_root
    from .parser import Parser

    p = Parser(link=False, level=1, toc=False)
    with TemporaryDirectory() as td:
        root = join(td, '_example')
        copytree(_scripts_root, root, dirs_exist_ok=True)
        assert gen_api({"The Example": "example"}, root, dry=True)
        assert not gen_api({"The Example": "example"}, root, prefix="")
        assert not gen_api({"The Example": "example"}, root, link=False)
        assert not gen_api({"The Example": "example"}, root, level=0)
        assert not gen_api

# Generated at 2022-06-23 15:23:08.668059
# Unit test for function gen_api
def test_gen_api():
    try:
        from os import remove
        from shutil import rmtree
    except ImportError:
        from os import unlink as remove
        from os import rmdir as remove
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp:
        doc = gen_api({'Module': 'numpy'}, tmp, prefix=f'{tmp}/docs', dry=True)
        print(doc[0])
        print('#' * 6, 'FIXME', '#' * 6)
        remove(f'{tmp}/docs/numpy-api.md')
        rmtree(f'{tmp}/docs')

# Generated at 2022-06-23 15:23:18.567042
# Unit test for function gen_api

# Generated at 2022-06-23 15:23:21.064395
# Unit test for function gen_api
def test_gen_api():
    result = gen_api({'Solver': 'pyslvs',
                      'Planar': 'pyslvs_ui',
                      'Assembly2': 'assembly2lib'})
    assert len(result) == 3

# Generated at 2022-06-23 15:23:26.127242
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    assert len(list(walk_packages("sympy", "../../sympy/pytest"))) == 0
    assert len(list(walk_packages("sympy", "../../sympy/sympy"))) > 0



# Generated at 2022-06-23 15:23:32.510606
# Unit test for function loader
def test_loader():
    from os import chdir, getcwd
    from .test import PWD
    from .test_pyslvs_api import test_loader_pyslvs

    chdir(PWD)
    try:
        test_loader_pyslvs()
        assert 'svg.path' in loader('svg', dirname(getcwd()), False, 1, False)
    finally:
        chdir(getcwd())

# Generated at 2022-06-23 15:23:36.110392
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        "pyslvs": "pyslvs",
        "Pyslvs": "pyslvs",
        "PyslvsUI": "pyslvs-ui",
    })

# Generated at 2022-06-23 15:23:45.827153
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main


# Generated at 2022-06-23 15:23:55.395849
# Unit test for function loader
def test_loader():
    from .parser import _test_parser
    from .settings import DOCSTRING_PARSER, get_tag_data
    import pytest

# Generated at 2022-06-23 15:24:04.620049
# Unit test for function walk_packages
def test_walk_packages():
    """Try to walk the packages."""
    import sys_info

# Generated at 2022-06-23 15:24:11.588981
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({"pyslvs", "PySlvs"},
                   root_names={"Root": "pyslvs"},
                   prefix="test_gen_api",
                   level=2,
                   link=False,
                   toc=True,
                   dry=True)
    assert len(docs) == 1
    docs = gen_api({"pyslvs", "PySlvs"},
                   root_names={"Root": "pyslvs"},
                   prefix="test_gen_api",
                   level=2,
                   link=True,
                   dry=True)
    assert len(docs) == 1

# Generated at 2022-06-23 15:24:14.700558
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pyslvs_ui.project import Project
    from qtpy.QtCore import Qt
    from qtpy.QtWidgets import QApplication
    app = QApplication([])
    test = Project()
    pwd = dirname(dirname(__file__))
    loader("pyslvs_ui", pwd, test.link_to, test.level_of_h1, test.enable_toc)
    print(test.compile())


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:24:16.809159
# Unit test for function gen_api
def test_gen_api():
    assert '#' in gen_api(dict(root='os'), dry=True)[0]

# Generated at 2022-06-23 15:24:20.448248
# Unit test for function gen_api
def test_gen_api():
    from os.path import isfile
    assert isfile("pyslvs_ui/docs/sympy-api.md")
    assert isfile("pyslvs_ui/docs/pyslvs_ui-api.md")

# Generated at 2022-06-23 15:24:21.883119
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    assert gen_api({'./tests/compiler/data/': ''})

# Generated at 2022-06-23 15:24:24.064772
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for this function."""
    assert list(walk_packages("sys-lib", __file__))

# Generated at 2022-06-23 15:24:26.232631
# Unit test for function loader
def test_loader():
    """Test function gen_api."""
    gen_api({'Test': 'pyslvs_ui'}, pwd=dirname(__file__))

# Generated at 2022-06-23 15:24:30.842997
# Unit test for function loader
def test_loader():
    """Test the loader."""
    assert _site_path('pyslvs_ui') is not ""
    r = loader('pyslvs_ui', _site_path('pyslvs_ui'), True, 0, True)
    assert r is not ""

# Generated at 2022-06-23 15:24:40.867410
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from logging import DEBUG, getLogger
    from os import chdir
    from os.path import dirname, abspath
    from shutil import rmtree
    from .parser import init_parser
    from . import __version__
    from .__cxx_api__ import test_cxx
    root = abspath(dirname(__file__))
    pwd = f"{root}{sep}docs"
    chdir(root)
    getLogger('slate_gen.parser').setLevel(DEBUG)
    getLogger('slate_gen.compiler').setLevel(DEBUG)
    # Remove old cache
    rmtree('__pycache__', ignore_errors=True)
    rmtree(pwd, ignore_errors=True)

# Generated at 2022-06-23 15:24:44.753661
# Unit test for function walk_packages
def test_walk_packages():
    from .tests.assets import test_path
    # pylint: disable=unreachable
    for i, doc in walk_packages("a", test_path):
        logger.debug(i)
        logger.debug(doc)

# Generated at 2022-06-23 15:24:48.089199
# Unit test for function loader
def test_loader():
    """Test."""
    def m(d):
        assert d["_test"] == "# API\n\n"
    pwd = abspath(dirname(__file__))
    assert loader("test_package", pwd, False, 1, False) == m

# Generated at 2022-06-23 15:24:50.748327
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    print("Function 'walk_packages':")
    for name, path in walk_packages("pyslvs", ".."):
        print(f"{name} from {path}")


# Generated at 2022-06-23 15:24:53.783437
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test_module_generating_api'})

# Generated at 2022-06-23 15:25:03.460606
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import re
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger

    logger.disabled = True

    dir_path = os.path.dirname(os.path.realpath(__file__))
    root_name = "pyslvs"
    root_path = os.path.join(dir_path, "../pyslvs")
    temp_dir = "temp"

    def _walk_packages(root_name: str, temp_dir: str, link: bool, level: int, toc: bool) -> str:
        doc = ""

# Generated at 2022-06-23 15:25:13.394963
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    import shutil
    dirs = []
    for x in range(4):
        d = tempfile.mkdtemp()
        dirs.append(d)
        t = join(d, x)
        open(t, 'w+').close()
    for k, x in enumerate(['pyslvs', 'pyslvs_stubs']):
        t = join(dirs[k], x)
        mkdir(t)
        t = join(t, f'{x}.pyi')
        with open(t, 'w+') as f:
            f.write(f'# {x}/{x}.pyi')
    for x in ['pyslvs-__init__.py', 'pyslvs-stubs-__init__.py']:
        t = join

# Generated at 2022-06-23 15:25:17.862499
# Unit test for function loader
def test_loader():
    import unittest

    class Testing(unittest.TestCase):

        def test_read(self):
            self.assertEqual('', _read('a'))

        def test_write(self):
            _write('a', 'b')

    unittest.main()


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:25:25.673059
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    import shutil
    with tempfile.TemporaryDirectory() as tmp:
        cwd = tmp + '/site-packages'
        mkdir(cwd)
        mkdir(cwd + '/test_package')
        mkdir(cwd + '/test_package/__pycache__')
        mkdir(cwd + '/test_package/nested_package')
        mkdir(cwd + '/test_package/nested_package/__pycache__')
        _write(cwd + '/test_package/__init__.py', '# test')

# Generated at 2022-06-23 15:25:28.612618
# Unit test for function walk_packages
def test_walk_packages():
    from . import __path__ as path
    from .logger import logging_level

    pwd = path[0]
    root = dirname(pwd).rsplit(sep, 1)[-1]

    l = logging_level()
    logging_level(0)
    for name, path in walk_packages(root, pwd):
        print(name)
    logging_level(l)

# Generated at 2022-06-23 15:25:33.324263
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({"SLVS-Python": "pyslvs", "SLVS-Core": "pyslvs_ui"}, level=2, toc=True)
    assert len(docs) == 2
    for doc in docs:
        assert isinstance(doc, str)

# Generated at 2022-06-23 15:25:42.329543
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'pyslvs': 'pyslvs'}, pwd="test/test_data")
    assert gen_api({'pyslvs': 'pyslvs'}, pwd="test/test_data", dry=True)
    assert gen_api({'pyslvs': 'pyslvs'}, pwd="test/test_data", dry=True, link=False)
    assert gen_api({'pyslvs': 'pyslvs'}, pwd="test/test_data", dry=True, level=2)
    assert gen_api({'pyslvs': 'pyslvs'}, pwd="test/test_data", dry=True, toc=True)

# Generated at 2022-06-23 15:25:47.528595
# Unit test for function gen_api
def test_gen_api():
    from sys import argv
    from os import getcwd

    # Remove path because of import error
    sys_path.remove(getcwd())

    # Test module
    if not isfile("pyslvs_ui.pyi"):
        raise ImportError("pyslvs_ui.pyi is not exist!")

    # Test function
    doc = loader("pyslvs_ui", "", False, 1, True)
    assert doc.strip()
    assert "pyslvs_ui.__main__" in doc
    assert "pyslvs_ui.__version__" in doc

    # Test import module
    assert _load_module("test_gen_api", __file__, Parser.new(False, 1, True))

    # Test gen_api

# Generated at 2022-06-23 15:25:50.444822
# Unit test for function loader
def test_loader():
    assert loader('pyslvs', dirname(__file__), False, 1, False).strip() != ""


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:26:02.022779
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api function."""
    from typing import Dict
    from .test_parser import package_test
    from .test_parser import test_parser
    from .test_parser import test_parser_link
    from .test_parser import test_parser_import
    if isdir('docs'):
        print('Clean docs directory ...')
        import shutil
        shutil.rmtree('docs')
    print('Generate site-packages ...')
    package_test()
    print('Test Python source ...')
    test_parser()
    print('Test Python stub ...')
    test_parser_link()
    print('Test import module ...')
    test_parser_import()
    print('Test gen_api ...')

# Generated at 2022-06-23 15:26:05.389640
# Unit test for function gen_api
def test_gen_api():
    from test.python.content.gen_api import run_tests
    run_tests()


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:26:11.870030
# Unit test for function walk_packages
def test_walk_packages():
    d = {}
    for name, path in walk_packages(
        "pyslvs",
        abspath(join(dirname(__file__), "../../"))
    ):
        d[name] = path
    assert d["pyslvs.frame"] == (
        abspath(join(dirname(__file__), "../../pyslvs/frame.py"))
    )

# Generated at 2022-06-23 15:26:17.752773
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api"""
    import pathlib
    from .hcl_pyslvs_ui import __file__ as pyslvs_ui_file
    pyslvs_ui_file = str(pathlib.Path(pyslvs_ui_file).absolute())
    gen_api({"Pyslvs-UI": "pyslvs_ui"}, pwd=pyslvs_ui_file, dry=True)

# Generated at 2022-06-23 15:26:28.215142
# Unit test for function walk_packages
def test_walk_packages():
    pkg = {name: None for name, _ in walk_packages("numpy", "site-packages/numpy")}

# Generated at 2022-06-23 15:26:32.071303
# Unit test for function loader
def test_loader():
    from .test_compiler import TEST_ROOT_NAME
    from .test_parser import TEST_DOC_PLANE
    docs = gen_api({'test': TEST_ROOT_NAME}, dry=True)
    assert len(docs) == 1
    assert docs[0] == '# API\n\n' + TEST_DOC_PLANE

# Generated at 2022-06-23 15:26:40.961901
# Unit test for function walk_packages

# Generated at 2022-06-23 15:26:43.529000
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test_api': 'test_api'})


__all__ = ['gen_api']

# Generated at 2022-06-23 15:26:50.100097
# Unit test for function gen_api
def test_gen_api():
    from sys import executable, stderr
    from os import remove
    root_names = {'Solver': 'pyslvs_ui.solver'}
    pwd = dirname(executable) + '\\Lib\\site-packages\\'
    pwd = pwd.replace('\\', '/')
    docs = gen_api(root_names, pwd)
    print(*docs, sep='\n', file=stderr)
    assert len(docs) == 1
    path = 'docs/pyslvs-ui-solver-api.md'
    assert isfile(path)
    remove(path)

# Generated at 2022-06-23 15:26:51.196767
# Unit test for function gen_api
def test_gen_api():
    """Test case for function gen_api."""
    pass


# Generated at 2022-06-23 15:26:54.122921
# Unit test for function gen_api
def test_gen_api():
    root_name = {"Root name": "root_name"}
    gen_api(root_name, None, dry=True)


# Generated at 2022-06-23 15:26:57.371217
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    assert gen_api(
        root_names={'package': 'package'},
        pwd='pyslvs_ui/tests/packages',
        prefix='tmp',
        dry=True
    )

# Generated at 2022-06-23 15:26:59.822329
# Unit test for function walk_packages
def test_walk_packages():
    from .__init__ import __version__
    assert (__version__, __file__) in list(walk_packages('pyslvs', '.'))



# Generated at 2022-06-23 15:27:08.402912
# Unit test for function loader
def test_loader():
    """Test loader."""
    from argparse import Namespace
    from pkg_resources import Requirement
    from .sys_path import sys_path_context
    from .utils import temp_module
    from .__main__ import args
    root = parent(Requirement.parse('pyslvs').project_name)
    with sys_path_context(args.pwd):
        with temp_module(__package__, "foo", "def bar(): pass") as name:
            q = Namespace(
                pwd=name,
                prefix='',
                debug=False,
                dry=True,
            )
            assert loader(root, q.pwd, True, 1, False)

# Generated at 2022-06-23 15:27:19.794247
# Unit test for function loader
def test_loader():
    from os.path import join, dirname, abspath
    from pkgutil import get_loader
    from .parser import Parser
    from .parser.parser import parser
    from .tokenizer import tokenizer
    from .meta import Meta
    from .ast import AST
    from .compiler import Compiler

    def read(path):
        with open(path, 'r') as f:
            return f.read()

    def gen(name, code):
        meta = Meta()
        ast = AST(parser(name, code, tokenizer, meta))
        o = [f"\n## {meta.docstring}\n\n", f"\n# {ast.name}\n\n"]
        p = Parser.new(False, 1, False)
        p.parse(ast.name, code)

# Generated at 2022-06-23 15:27:25.952082
# Unit test for function gen_api
def test_gen_api():
    from pkgutil import walk_packages
    from platform import machine
    from urllib.request import urlopen
    from urllib.error import HTTPError
    import tkinter
    import tkinter.ttk
    import tkinter.constants
    import tkinter.dialog
    import tkinter.dnd
    import tkinter.filedialog
    import tkinter.font
    import tkinter.image
    import tkinter.messagebox
    import tkinter.scrolledtext
    import tkinter.simpledialog
    import tkinter.ttk
    import tkinter.tix
    import tkinter.ttk
    import tkinter.ttk
    import tkinter.font
    import tkinter.scrolledtext
    import tkinter.ttk

# Generated at 2022-06-23 15:27:37.286927
# Unit test for function gen_api
def test_gen_api():
    from . import __version__
    from .parser import link_parser
    import tempfile
    import shutil
    import unittest

    with tempfile.TemporaryDirectory() as temp_dir:
        docs = gen_api(
            {'pyslvs': 'pyslvs'},
            pwd=dirname(abspath(__file__)),
            prefix=temp_dir,
            link=False,
            level=2,
            dry=True
        )
    for doc in docs:
        unittest.TestCase().assertIsInstance(doc, str)


# Generated at 2022-06-23 15:27:42.791013
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages("solver", dirname(__file__)))) > 1
    assert len(list(walk_packages("solver", dirname(abspath(__file__)) + sep))) > 1
    assert len(list(walk_packages("solver", dirname(abspath(__file__))))) > 1

# Generated at 2022-06-23 15:27:46.393969
# Unit test for function gen_api
def test_gen_api():
    logs = logger.disabled_logs()
    gen_api(dict(pyslvs="pyslvs_ui"), pwd=dirname(abspath(__file__)), dry=True)
    print(*logs, sep='\n', end='\n')


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:27:53.768626
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from os.path import exists
    from shutil import rmtree
    from tempfile import gettempdir
    from pkgutil import walk_packages

    test_path = join(gettempdir(), 'test')
    if exists(test_path):
        rmtree(test_path)
    makedirs(join(test_path, 'test1', 'test2'))
    with open(join(test_path, 'test1', 'test2', 'test3.py'), 'w') as f:
        f.write('"test"')
    with open(join(test_path, 'test1', 'test2', 'test3.pyi'), 'w') as f:
        f.write('"test"')

# Generated at 2022-06-23 15:27:59.511831
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase
    from tempfile import mkdtemp
    from shutil import rmtree

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.path = mkdtemp()

        def tearDown(self):
            rmtree(self.path)

        def test_walk_packages(self):
            import os
            import os.path
            test_str = '''
            #!/usr/bin/env python
            # -*- coding: utf-8 -*-

            """Test docstring."""
            '''
            with open(self.path + '/__init__.pyi', 'w') as f:
                f.write(test_str)

# Generated at 2022-06-23 15:28:01.810731
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({})
    assert gen_api({
        'SVS': 'pyslvs',
    })
    assert gen_api({
        'Valkka': 'valkka',
    })

# Generated at 2022-06-23 15:28:11.173988
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'numpy': 'numpy'}, "/")
    assert len(gen_api({'numpy': 'numpy'}, "/", dry=True)) == 1
    assert gen_api({'numpy': "numpy", 'scipy': 'scipy'}, "/", dry=True)
    assert len(gen_api({'numpy': "numpy", 'scipy': 'scipy'}, "/", dry=True)) == 2
    assert gen_api({'numpy': 'numpy'}, "/", toc=True, dry=True)
    assert len(gen_api({'numpy': "numpy", 'scipy': 'scipy'}, "/", toc=True, dry=True)) == 2

# Generated at 2022-06-23 15:28:16.263425
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({"pyslvs": "pyslvs"}, dry=True)
    assert docs[0].strip(), "This should not be empty"
    assert "API" in docs[0]

# Generated at 2022-06-23 15:28:20.185477
# Unit test for function walk_packages
def test_walk_packages():
    cur_path = dirname(__file__)
    for name, f_path in walk_packages('pyslvs', cur_path):
        assert 'pyslvs' in name
        assert cur_path in f_path
    import numpy

# Generated at 2022-06-23 15:28:27.836969
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main
    from types import ModuleType
    from .parser import Parser

    class Package(ModuleType):
        """Test package load stub."""

        __name__ = 'test'

        def __init__(self, *args, **kwargs):
            super(Package, self).__init__(*args, **kwargs)
            self.__path__ = '.'
            self.__file__ = 'test.py'

    class TestLoader(TestCase):

        def test_load_stub(self, p: Parser):
            """Test load stub."""
            self.assertTrue(p.load_docstring('test', Package()))
            p.parse('test', """\
"""
"""Test data.
        """)
            r = p.compile()

# Generated at 2022-06-23 15:28:36.099102
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import shutil
    from os.path import join, isdir, isfile
    from .release import RELEASE_DIR
    from .logger import logger as logger_

    def test_walk_packages_(name: str, path: str = RELEASE_DIR) -> None:
        logger_.debug(f"name: {name}")
        logger_.debug(f"path: {path}")
        logger_.debug(f"prefix: ({path} + {name})")
        sites = _site_path(name)
        print(sites)
        if sites:
            logger_.debug(f"clear: {sites}")
            shutil.rmtree(sites)
        assert not isdir(sites)
        mkdir(sites)
        assert isdir(sites)

# Generated at 2022-06-23 15:28:44.698833
# Unit test for function walk_packages
def test_walk_packages():
    from .testing import test_pwd
    import numpy as np

    assert walk_packages("numpy", test_pwd.replace("\\", "/"))
    assert len(list(walk_packages("numpy", test_pwd.replace("\\", "/")))) > 600
    for name, path in walk_packages("numpy", test_pwd.replace("\\", "/")):
        if not "__init__.py" in path:
            continue
        if name == "numpy":
            assert np.__doc__ is None
            assert np.inf.__doc__ is not None
            assert np.ones_like.__doc__ is not None
            break

# Generated at 2022-06-23 15:28:53.711266
# Unit test for function loader
def test_loader():
    """Check if the module can be compiled correctly."""
    p = Parser.new(True, 1, False)

# Generated at 2022-06-23 15:29:05.028447
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import gettempdir, mkdtemp
    from shutil import rmtree
    from os.path import split, join
    # Test the case if the package has an already-imported subpackage,
    # which should not load.
    # The path have to be in `split` format, so you can not concat "\\".
    temp_path = join(gettempdir(), mkdtemp(prefix='temp_'))

# Generated at 2022-06-23 15:29:13.719941
# Unit test for function loader
def test_loader():
    from tempfile import mkdtemp
    from os.path import realpath, exists
    from shutil import rmtree
    from .settings import ROOT_FILES

    # Init temp dir
    pwd = mkdtemp()
    prefix = "_doc"
    prog_path = join(dirname(dirname(dirname(realpath(__file__)))), 'pyslvs-ui')
    with open(join(prog_path, '__init__.py'), 'w') as f:
        f.write("#! /usr/bin/python3\nfrom pyslvs_ui.main import run\n")
        f.write("__version__ = 1.2\n__title__ = 1.2\n")

    # Write packages

# Generated at 2022-06-23 15:29:14.844433
# Unit test for function loader
def test_loader():
    logger.info(loader("pyslvs", ".", True, 1, False))

# Generated at 2022-06-23 15:29:23.010748
# Unit test for function gen_api
def test_gen_api():
    """Test the gen_api function."""
    import tempfile
    with tempfile.TemporaryDirectory() as dir:
        assert gen_api({
            "hello": "hello",
            "world": "world",
        }, dir)
        assert gen_api({
            "hello": "hello",
            "world": "world",
        }, dir) == [
            '# hello API\n\n',
            '# world API\n\n',
        ]
        assert gen_api({
            "hello": "hello",
            "world": "world",
        }, dir, dry=True) == [
            '# hello API\n\n\n# world API\n\n',
        ]

# Generated at 2022-06-23 15:29:33.732915
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    sp = _site_path('sklearn')
    if not sp:
        raise Exception('Cannot find the site-packages for "sklearn"')
    ls = list(walk_packages('sklearn', sp))
    assert ls
    assert ('sklearn.decomposition.nmf',
            sp + '/sklearn/decomposition/nmf.py') in ls
    assert ('sklearn.utils.arrayfuncs',
            sp + '/sklearn/utils/arrayfuncs.c') in ls
    assert ('sklearn.utils.arrayfuncs-stubs',
            sp + '/sklearn/utils/arrayfuncs-stubs.pyi') not in ls

# Generated at 2022-06-23 15:29:41.416768
# Unit test for function walk_packages
def test_walk_packages():
    # Find the directory of __file__
    pwd = dirname(abspath(__file__)) + sep
    # The path should be not empty
    assert _site_path("pyslvs")
    # Ensure the path is in the parent of the pyslvs.
    assert _site_path("pyslvs").startswith(pwd.parent)
    # The number of package is not stable, so just test if exist.
    has_pyslvs = False
    has_pyslvs_stubs = False
    # The test should in the _api directory
    assert isdir(pwd)
    # Need to ignore the __pycache__
    assert parent(pwd).endswith("_api")