

# Generated at 2022-06-23 15:19:43.112184
# Unit test for function gen_api
def test_gen_api():
    """Test the function gen_api."""
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        gen_api({
            "Pyslvs": "pyslvs",
            "Pyslvs-core": "pyslvs_core"
        }, d, level=2, dry=True)

# Generated at 2022-06-23 15:19:47.281335
# Unit test for function loader
def test_loader():
    """Function loader test."""
    logger.info("Start script generator testing.")
    logger.info("It can take a long time to execute this test.")
    logger.info("Please be patient.")
    # Because this function would load pylab into Python environment.
    # So we have to restore Python environment.
    funcs = loader("pylab", dirname(__file__), False, 1, False)
    logger.info("Test script generator is finished.")
    assert funcs.count("# ") == 78
    assert funcs.count("cbrt(") == 1
    assert funcs.count("inf") == 1

# Generated at 2022-06-23 15:19:52.719156
# Unit test for function loader
def test_loader():
    module_name = 'pyslvs'
    p = Parser.new(True, 1)
    for n, p in walk_packages(module_name, _site_path(module_name)):
        p.parse(n, _read(p))
    ret = p.compile()
    print(ret)
    assert ret.startswith('# pyslvs API')

# Generated at 2022-06-23 15:19:55.337936
# Unit test for function gen_api
def test_gen_api():
    doc = gen_api({"Test": "test.test"}, prefix="./test-api")
    assert "Test API" in doc[0]

# Generated at 2022-06-23 15:19:57.482620
# Unit test for function gen_api
def test_gen_api():
    gen_api({'Test': 'test'}, pwd='../tests', level=2, dry=True)

# Generated at 2022-06-23 15:20:04.958734
# Unit test for function loader
def test_loader():
    class FakeLoader:
        """Fake Python loader."""
        def create_module(self, spec: object) -> Optional[object]:
            return None

        def exec_module(self, module: object) -> None:
            pass

    class FakeSpec:
        """Fake Python spec."""
        def __init__(self, name: str) -> None:
            self.name = name
            self.loader = FakeLoader()

    p = Parser.new(True, 1, False)

    assert p.parse("__main__", "") is None
    assert p.parse("__main__", "") is None
    assert p.parse("__main__", "") is None
    assert p.parse("__main__", "") is None
    assert p.parse("__main__", "") is None

# Generated at 2022-06-23 15:20:15.644556
# Unit test for function gen_api
def test_gen_api():
    from .util import importer
    from pkgutil import walk_packages
    from importlib import import_module
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import shutil
    test = Path(__file__).parent / 'test'
    with TemporaryDirectory() as pwd:
        shutil.copytree(test, pwd)
        importer(pwd, 'pyslvs_ui')
        root_names = {
            "Pyslvs UI": "pyslvs_ui",
            "Pyslvs UI - tests": "pyslvs_ui.tests",
        }
        if isinstance(root_names, dict):
            for title, name in root_names.items():
                import_module(name)
        else:
            for name in root_names:
                import_module

# Generated at 2022-06-23 15:20:21.982362
# Unit test for function walk_packages

# Generated at 2022-06-23 15:20:27.164102
# Unit test for function loader
def test_loader():
    # Load a test module
    import sys
    import os
    import module_loader
    if sys.platform == 'win32':
        module_loader.lib_path = os.path.join(os.path.dirname(__file__), 'mylib.dll')
    else:
        module_loader.lib_path = os.path.join(os.path.dirname(__file__), 'mylib.so')
    loader('compiler', 'compiler', True, 1, True)

# Generated at 2022-06-23 15:20:35.723521
# Unit test for function gen_api
def test_gen_api():
    # skip unit test in production
    if __name__ != '__main__':
        return

    # Test case
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs UI': 'pyslvs_ui',
        'Pyslvs Joint': 'pyslvs_joint',
        'Pyslvs Solver': 'pyslvs_solver',
        'Pyslvs Struct': 'pyslvs_struct',
    }
    docs = gen_api(root_names, prefix='.test_gen_api', dry=True)

    # Check output
    for doc in docs:
        assert doc is not None
        assert doc.startswith('#')
        assert doc.split('\n')[1].startswith('-')

# Generated at 2022-06-23 15:20:37.206495
# Unit test for function gen_api
def test_gen_api():
    """Test case for function gen_api."""
    gen_api({"Test": "test"})

# Generated at 2022-06-23 15:20:39.659533
# Unit test for function walk_packages
def test_walk_packages():
    _site_path("sip")
    try:
        for i in walk_packages("sip", _site_path("sip")):
            print(i)
    except AttributeError:
        pass

# Generated at 2022-06-23 15:20:42.852608
# Unit test for function gen_api
def test_gen_api():
    print(gen_api({"Pyslvs", "pyslvs"}))

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:20:53.458406
# Unit test for function loader
def test_loader():
    import os
    import sys
    import random

    from .color import decolor
    from .compiler import gen_api, logger as test_logger
    from .parser.parser import Parser

    test_logger.debug = lambda *_, **__: None

    def clean():
        """Remove all files in the directory."""
        for path, _, fs in walk('test'):
            for f in fs:
                os.remove(join(path, f))

    def rand_name(ext: str) -> str:
        """Generate a random name."""
        return f'test/{hex(random.getrandbits(32))[2:]}{ext}'

    def create_file(name: str, content: str) -> None:
        """Create file."""

# Generated at 2022-06-23 15:20:55.666688
# Unit test for function gen_api
def test_gen_api():
    gen_api({'test': 'test_project'}, '../test_project')


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:21:02.294764
# Unit test for function walk_packages
def test_walk_packages():
    def walk_check(name: str, path: str, data: list) -> None:
        data = [abs(p) for p in data]
        assert all(t in data for t in walk_packages(name, path))
        assert all(t in data for t in walk_packages(name, path))

    f = abspath(__file__).replace(".py", "")
    root = "test_pkg"
    root_path = parent(__file__, 3) + sep + root
    data = [
        root + ".a", root + ".a.b", root + ".a.b.c",
        root + ".a.b.c.d.__init__", root + ".a.b.c.d.e",
    ]
    walk_check(root, root_path, data)

    # No suffix


# Generated at 2022-06-23 15:21:12.018351
# Unit test for function walk_packages
def test_walk_packages():
    from os import chdir, getcwd, listdir
    from os.path import exists, isdir
    from shutil import rmtree
    import tempfile
    from sys import platform
    from testing import assert_equal, assert_true, run_module

    temp_dir = tempfile.mkdtemp()
    assert_true(exists(temp_dir))

# Generated at 2022-06-23 15:21:17.765824
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    assert gen_api({
        "mprocgen": "mprocgen",
        "pyslvs_ui": "pyslvs_ui",
    }, "../", prefix="docs", link=True, level=1, toc=True, dry=True)

# Generated at 2022-06-23 15:21:25.190455
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from os.path import sep, exists
    from shutil import rmtree
    from .common import tmp_path
    tmpdir = tmp_path('tempdir')
    makedirs(tmpdir)
    with open(tmpdir + sep + '__init__.py', 'w+'):
        pass
    assert exists(tmpdir + sep + '__init__.py')
    _write(tmpdir + sep + '__init__.pyi', '''
    class Foo:
        pass

    class Bar:
        pass
    ''')
    assert exists(tmpdir + sep + '__init__.pyi')
    path = tmpdir + sep + '__init__.pyi'
    assert path == next(walk_packages('tempdir', tmpdir))[1]
    rmtree

# Generated at 2022-06-23 15:21:29.063304
# Unit test for function gen_api
def test_gen_api():
    gen_api({"pyslvs-api": "pyslvs", "pyslvs-ui-api": "pyslvs_ui"}, dry=True)

# Generated at 2022-06-23 15:21:33.996351
# Unit test for function gen_api
def test_gen_api():
    """Test function: gen_api()."""
    root_names = dict(
        PySLVS="pyslvs",
    )
    import pyslvs_ui
    # Get the directory of this script
    gen_api(root_names, pyslvs_ui.__file__, toc=True, dry=True)

# Generated at 2022-06-23 15:21:43.028628
# Unit test for function loader
def test_loader():
    """The unit test."""
    def _test(name: str, root: str, pwd: Optional[str] = None,
              link: bool = True, level: int = 1, toc: bool = False) -> None:
        logger.info(f"Unit test for package {name}")
        doc = loader(root, pwd, link, level, toc)
        logger.info(f"Documentation:\n{doc}")

    # Run unit test
    _test('PySlvs', 'pyslvs', '.', False, 1, False)
    _test('PySlvs', 'PySlvs', '..', False, 1, False)
    _test('NumPy', 'numpy', None, False, 1, False)

# Generated at 2022-06-23 15:21:50.488881
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import mkdtemp
    from shutil import rmtree
    import re
    from sys import platform

    def _mkdtemp(name: str) -> str:
        dirname = join(mkdtemp(), name)
        mkdir(dirname)
        return dirname

    def _test_function(py_name: str, py_doc: str) -> None:
        """This is a test function."""
        pass

    def _test_class(py_name: str, py_doc: str, init_doc: str) -> None:
        """This is a test class."""
        class TestClass:
            """This is a test class."""
            def __init__(self):
                """This is the __init__ method."""
                pass


# Generated at 2022-06-23 15:21:54.352832
# Unit test for function walk_packages
def test_walk_packages():
    def check(name, path):
        for n, p in walk_packages(name, path):
            if p.endswith("ab.py"):
                assert n == "test.a.b"
                assert p.endswith("site-packages/test/a/ab.py")
                return
        assert False, "not found"
    check("test", "tests/site-packages")
    check("test", "tests/site-packages-stubs")

# Generated at 2022-06-23 15:21:56.162391
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'pyslvs': 'pyslvs'}, dry=True)



# Generated at 2022-06-23 15:22:06.600573
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    def verify(name: str, path: str) -> bool:
        """Verify result."""
        if isdir(join(path, name)):
            logger.error(join(path, name) + ' already exists')
            return False
        with open(join(path, name), 'w'):
            pass
        res = [x[0] for x in walk_packages('name', path)]
        if len(res) != 1:
            logger.error(f"Should load only one, but got {len(res)}")
            return False
        if res[0] != 'name':
            logger.error(f"Should load name, but got {res[0]}")
            return False
        return True

    assert verify('name', '.')
    assert verify('name', './')


# Generated at 2022-06-23 15:22:14.064412
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader('pyslvs', dirname(__file__), True, 2, False)
    assert doc.startswith('## pyslvs Package\n\n')

    doc = loader('pyslvs.data', dirname(__file__), True, 3, False)
    assert doc.startswith('### pyslvs.data Module\n\n')


# Generated at 2022-06-23 15:22:17.991677
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    for name, path in walk_packages("pyslvs", "src"):
        print(name)
        print(path)


# Generated at 2022-06-23 15:22:26.823003
# Unit test for function loader
def test_loader():
    r"""Test case."""
    # A fake root for import
    pwd = dirname(dirname(abspath(__file__)))

    def l(n):
        return loader(n, pwd, link=True, level=1, toc=False)

    assert l('pyslvs')
    assert l('pyslvs_ui')
    assert l('pyslvs-real')
    assert l('pyslvs_dynamics')

    def l2(n):
        return loader(n, pwd, link=False, level=1, toc=False)

    assert l2('pyslvs')
    assert l2('pyslvs_ui')
    assert l2('pyslvs-real')
    assert l2('pyslvs_dynamics')
    assert l

# Generated at 2022-06-23 15:22:35.142523
# Unit test for function loader
def test_loader():
    import pytest
    doc = loader('pyslvs', './tests', False, 3, False)

# Generated at 2022-06-23 15:22:44.445589
# Unit test for function walk_packages
def test_walk_packages():
    """Test the walk package function."""
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from .parser import ARGPARSE_ROOT, ARGPARSE_STUBS

    with TemporaryDirectory() as d:
        logger.info(f"Create tmpdir: {d}")
        mkdir(join(d, 'argparse'))
        mkdir(join(d, 'argparse-stubs'))
        for name in ['__init__.py', '__main__.py', 'abc.py',
                     'abc.__init__.py', 'abc.pyi']:
            path = join(d, ARGPARSE_ROOT, name)
            _write(path, "")
            logger.debug(f"Create {path}")

# Generated at 2022-06-23 15:22:55.494766
# Unit test for function gen_api
def test_gen_api():
    # pylint: disable=unused-import
    from .unit_test import TestCase
    from .unit_test import import_helper
    
    def test_with_modules():
        test_root_names = {
            'Barcodec': 'barcodec',
            'Pyslvs': 'pyslvs',
        }
        # import package path
        import_path = 'pyslvs_ui/algorithm'
        # Generate API documentation
        for title, name in test_root_names.items():
            root = f"{import_path}/{name}"
            pwd = dirname(import_helper(root).__file__)
            gen_api({title: name}, pwd, dry=True)
    
    def test_with_root():
        test_root_names

# Generated at 2022-06-23 15:23:05.890760
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('qtpy', '.')) == []

# Generated at 2022-06-23 15:23:15.965008
# Unit test for function walk_packages
def test_walk_packages():
    """test_walk_packages"""
    import tempfile
    import shutil
    import os
    import pathlib

    temp_path = tempfile.mkdtemp()

# Generated at 2022-06-23 15:23:22.965099
# Unit test for function loader
def test_loader():
    class FakeLoader(Loader):
        def create_module(self, spec):
            pass

        def exec_module(self, module: object) -> None:
            pass

        def module_repr(self, module: object) -> str:
            return "fake module"

    class FakeSpec:
        def __init__(self, loader: Loader) -> None:
            self.loader = loader

    p = Parser.new(False, 0, False)
    assert _load_module("fake", 'fake.py', p) is False, "no fake"
    assert _load_module("fake", 'fake.py', p) is True, "load fake"
    assert _load_module("fake.real", 'fake.py', p) is False, "no real fake"
    s = FakeSpec(FakeLoader())
    assert _load

# Generated at 2022-06-23 15:23:26.154634
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    assert list(walk_packages("pyslvs", '.'))
    assert list(walk_packages("pyslvs", '.'))[0][0].startswith("pyslvs.")
    assert list(walk_packages("pyslvs", '.'))[0][1].startswith(".")
    assert sorted(walk_packages("pyslvs", '.'), key=lambda x: x[0].split("."))

# Generated at 2022-06-23 15:23:38.301951
# Unit test for function gen_api
def test_gen_api():
    def equal(text: str, expected: str) -> bool:
        return text.strip().replace('\r\n', '\n') ==\
            expected.strip().replace('\r\n', '\n')

    root_names = {'test': 'test_module'}
    logger.info('test_module path = ' + __file__)
    docs = gen_api(root_names, pwd=dirname(__file__))
    assert len(docs) == 1

# Generated at 2022-06-23 15:23:44.921022
# Unit test for function walk_packages
def test_walk_packages():
    def walk_test(name: str, path: str):
        for n, p in walk_packages(name, path):
            print(n, p)
    walk_test("pyslvs", "D:\\Python37\\Lib\\site-packages")
    walk_test("pyslvs", "/usr/local/lib/python3.7/dist-packages")
    walk_test("matplotlib", "D:\\Python37\\Lib\\site-packages")
    walk_test("matplotlib", "/usr/local/lib/python3.7/dist-packages")

# Generated at 2022-06-23 15:23:53.423492
# Unit test for function loader
def test_loader():
    import os
    import string
    import tempfile
    # Some code and script

# Generated at 2022-06-23 15:24:02.866287
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    import pkg_resources
    with TemporaryDirectory() as pwd:
        root_names = {
            'Pyslvs': 'pyslvs',
            'Pyslvs UI': 'pyslvs_ui',
            'Pyslvs-Hiwin': 'pyslvs_hiwin',
        }
        gen_api(root_names, pwd)
        for title, name in root_names.items():
            path = join('docs', f'{name.replace("_", "-")}-api.md')
            assert isfile(path)
            data = _read(path)
            assert title in data
        # Test API file
        # pkg_resources.resource_filename for testing

# Generated at 2022-06-23 15:24:05.762808
# Unit test for function gen_api
def test_gen_api():
    gen_api({'Pyslvs API': 'pyslvs_ui.__main__'}, dry=True)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:24:08.876945
# Unit test for function gen_api
def test_gen_api():
    assert isdir('_test-docs')
    assert gen_api({'Test': 'module_name'}, 'tests', dry=True)
    assert not isdir('_test-docs')

# Generated at 2022-06-23 15:24:20.311474
# Unit test for function walk_packages
def test_walk_packages():
    import pathlib
    for p in ['/usr/lib/python3.9', 'core', 'core/pyslvs']:
        assert p in pathlib.Path(__file__).parents[2].joinpath('core/pyslvs').as_posix()

# Generated at 2022-06-23 15:24:27.160986
# Unit test for function walk_packages
def test_walk_packages():
    name = 'sipyco.abcde'
    path = 'tests/testdata'

# Generated at 2022-06-23 15:24:29.409686
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'Pyslvs': 'pyslvs'}, '.', level=2)

# Generated at 2022-06-23 15:24:39.737087
# Unit test for function gen_api
def test_gen_api():
    from pkgutil import iter_modules as _iter_modules
    from .utils import test_resource_path

    def iter_modules(path):
        for info in _iter_modules([test_resource_path("")]):
            if info.ispkg and info.name.startswith(path):
                yield info.name

    def api_gen():
        gen_api({
            "Pyslvs": "pyslvs",
            "Compiler": "pyslvs_compiler",
        }, _site_path("pyslvs"), prefix="test_docs", dry=True)

    logger.debug("Test API generation:")
    logger.debug("=" * 12)
    api_gen()
    logger.debug("=" * 12)
    assert True

# Generated at 2022-06-23 15:24:40.939387
# Unit test for function loader
def test_loader():
    print(loader("pyslvs", ".", True, 2, True))

# Generated at 2022-06-23 15:24:50.349488
# Unit test for function walk_packages
def test_walk_packages():
    """Test the searching algorithm."""
    from importlib import invalidate_caches
    from glob import glob
    from os import remove
    from os.path import splitext
    try:
        site_path = _site_path('astroid')
        logger.info(f"site-packages path: {site_path}")
        invalidate_caches()
        assert isinstance(list(walk_packages('astroid', site_path)), list)
        assert isinstance(list(walk_packages('pylint', site_path)), list)
    except AssertionError:
        import sys
        sys.path.append(site_path)
        try:
            import astroid
        except ImportError:
            import pylint
        except ImportError:
            raise

# Generated at 2022-06-23 15:24:57.900999
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove, rmdir
    from shutil import rmtree
    from .logger import logger
    from .parser import parent
    from .compiler import walk_packages

    name = 'pyslvs'
    pwd = __file__.replace('compiler.py', '')

# Generated at 2022-06-23 15:25:09.033138
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger_mock
    p = Parser.new(False, 1, False)
    for i in range(2, 7 + 1):
        for j in range(1, 5 + 1):
            name = f"pyslvs_ui.util{i}.test{j}"
            if i == 2 and j > 2:
                continue
            logger_mock.debug(f"{name} <= {name}.py")

# Generated at 2022-06-23 15:25:17.696094
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from importlib import import_module
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(False, 0, False)
    for name, path in test_data():
        m = import_module(name)
        p.parse(name, _read(path))
        m.__doc__.replace(" ", "").replace("\t", "").replace("\n", "")
        p.load_docstring(name, m)
    docs = p.compile()

# Generated at 2022-06-23 15:25:19.870433
# Unit test for function walk_packages
def test_walk_packages():
    for _ in walk_packages('proj', '.'):
        pass

# Generated at 2022-06-23 15:25:21.915541
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    src = """
    """
    assert loader("foo", "", True, 5, False) == src.strip()

# Generated at 2022-06-23 15:25:24.564527
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    for mod in gen_api({"Foo": "foo"}, dry=True):
        print(mod)

# Generated at 2022-06-23 15:25:35.698971
# Unit test for function walk_packages
def test_walk_packages():
    test = set(walk_packages('test', 'tests'))
    assert test == {
        ('test', 'tests/test'),
        ('test.module_a', 'tests/test/module_a.py'),
        ('test.module_a.module_b', 'tests/test/module_a/module_b.py'),
        ('test.module_b', 'tests/test/module_b.py'),
        ('test.module_b.module_a', 'tests/test/module_b/module_a.py'),
        ('test.module_b.module_c', 'tests/test/module_b/module_c.py'),
        ('test.module_b.module_c.module_a',
         'tests/test/module_b/module_c/module_a.py'),
    }
    p

# Generated at 2022-06-23 15:25:38.566450
# Unit test for function loader
def test_loader():
    logger.level = 2
    assert gen_api({"test": "test_compiler"})
    print('=' * 12)
    assert gen_api({"test": "test_compiler"}, dry=True)

# Generated at 2022-06-23 15:25:50.070790
# Unit test for function walk_packages
def test_walk_packages():
    from pyslvs.pkg_info import __name__ as root
    s = 'pyslvs.io.__init__'
    # Normal case
    assert list(walk_packages(root, '..'))[0][0] == s
    # Normal case, but not the root
    assert list(walk_packages(parent(s), '../..'))[0][0] == s
    # The file name is unexpected
    assert list(walk_packages(root, '..'))[-1][0] == 'pyslvs.io.ext.pyslvs-visual'
    # The package name is unexpected
    assert list(walk_packages(root, '..'))[-2][0] == 'pyslvs.cli.cli'
    # The file name is unexpected, but not the root

# Generated at 2022-06-23 15:26:01.920423
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .logger import logger
    from .examples import parse_pyslvs_example, export_pyslvs_example
    from .planar import parse_pyslvs_planar, export_pyslvs_planar
    logger.debug(loader('pyslvs_examples', dirname(parse_pyslvs_example.__file__), False, 1, False))
    logger.debug(loader('pyslvs_planar', dirname(parse_pyslvs_planar.__file__), False, 1, False))
    logger.debug(loader('pyslvs_examples', dirname(export_pyslvs_example.__file__), False, 1, False))

# Generated at 2022-06-23 15:26:13.922294
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        td = abspath(td) + sep
        path = join(td, 'pkg')
        mkdir(path)
        mkdir(join(path, 'sub'))
        mkdir(join(path, 'sub', 'sub'))
        for directory in [path, join(path, 'sub'), join(path, 'sub', 'sub')]:
            for n in ["x", "y"]:
                _write(join(directory, f"{n}.py"), f"def {n}():\n    pass")
        root = 'pkg'
        result = sorted(walk_packages(root, td), key=(lambda t: t[0]))

# Generated at 2022-06-23 15:26:24.877606
# Unit test for function walk_packages
def test_walk_packages():
    from json import dumps
    from os import remove
    from re import findall
    from tempfile import TemporaryDirectory

    def create_module(path: str, body: str) -> None:
        with open(path, 'w') as f:
            f.write(body)

    with TemporaryDirectory() as pwd:
        for name in ['a', 'ab', 'ac', 'b', 'c', 'd']:
            create_module(f"{pwd}/{name}.py", f"# {name}")
        create_module(f"{pwd}/__init__.py", "")

        fps = [(n, p) for n, p in walk_packages('', pwd)]

# Generated at 2022-06-23 15:26:31.262940
# Unit test for function gen_api
def test_gen_api():
    gen_api({'test': 'pyslvs_ui'}, f'{dirname(__file__)}/..')
    gen_api({'test': 'pyslvs_ui.package'}, f'{dirname(__file__)}/..')
    gen_api({'test': 'pyslvs_ui.package.utils'}, f'{dirname(__file__)}/..')
    gen_api({'test': 'pyslvs_ui.extension'}, f'{dirname(__file__)}/..')

# Generated at 2022-06-23 15:26:37.343046
# Unit test for function walk_packages

# Generated at 2022-06-23 15:26:39.505621
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    assert isinstance(walk_packages("pyslvs", "tests"), Iterator)

# Generated at 2022-06-23 15:26:49.615993
# Unit test for function loader
def test_loader():
    import sys
    import pkgutil
    sys.path.append('tests/data/package')
    assert pkgutil.get_importer('package') is not None
    assert _site_path('package') != ""
    assert 'package' in sys.modules
    doc = loader('package', 'tests/data/package', False, 1, False)
    assert '\n'.join(doc.split('\n')[4:9]) == '''\
package.a
========

### package.a.A

- **package.a.A(a)**
- **package.a.A.func_a(a)**

### package.a.A.B

- **package.a.A.B(a)**
- **package.a.A.B.func_b(a)**
'''
   

# Generated at 2022-06-23 15:26:54.010995
# Unit test for function gen_api
def test_gen_api():
    name = __name__ + '.test_gen_api'
    def test_factory(file_name: str, root_name: str) -> str:
        path = join(dirname(__file__), 'testdata')
        return loader(root_name, path, link=True, level=1, toc=True)

    # Fix root_names without underscore in the file name
    p = {name: 'testdata'}
    r = test_factory(name, 'testdata')

# Generated at 2022-06-23 15:27:03.797752
# Unit test for function gen_api
def test_gen_api():
    """Test export API document."""
    def check(rname, pwd, prefix):
        assert isdir(prefix)
        path = join(prefix, f"{rname.replace('_', '-')}-api.md")
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()

    test_folder = "tests"
    real = gen_api({
        "editor": "editor",
        "pane": "pane",
    }, test_folder, dry=True)
    assert len(real) == 2
    assert real[0].startswith("## editor API\n")
    assert real[1].startswith("## pane API\n")

# Generated at 2022-06-23 15:27:10.731216
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .constant import PYSLVS
    from .compiler import walk_packages

    # Temporary testing directory
    tmp_dir = mkdtemp()
    tmp_path = abspath(tmp_dir) + sep

    def _touch(name: str, doc: str = None) -> None:
        """Touch a file in testing directory."""
        if not name.endswith('.py'):
            raise NotImplementedError
        with open(tmp_dir + sep + name, 'w+', encoding='utf-8') as f:
            if doc is not None:
                f.write(doc)

    # Empty
    assert list(walk_packages(PYSLVS, tmp_path)) == []

    # Only files

# Generated at 2022-06-23 15:27:21.474502
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import join as pjoin
    from glob import glob

    def create_package(name: str, root: str=''):
        for n in name.split('.'):
            root = pjoin(root, n)
            mkdir(root)
            with open(pjoin(root, '__init__.py'), 'wb'):
                pass

    with TemporaryDirectory() as d:
        create_package('package')
        copyfile(
            pjoin(dirname(__file__), 'test_script.py'),
            pjoin(d, 'package', 'test_script.py'))
        file_paths = list(walk_packages('package', d))

# Generated at 2022-06-23 15:27:27.718644
# Unit test for function walk_packages

# Generated at 2022-06-23 15:27:34.856981
# Unit test for function loader
def test_loader():
    logger.info("Test `loader` function")
    doc = loader("test_module", ".", True, 1, True).strip()
    print(doc)
    assert doc.startswith("# test_module API\n\n")
    assert doc.endswith("# test_module\n")
    assert "**Now:**" in doc
    assert "**Later:**" in doc

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:27:43.871055
# Unit test for function gen_api
def test_gen_api():
    def run_dry_gen(name: str, title: str) -> str:
        return gen_api({title: name}, dry=True)[0]

    assert '# Pyslvs-UI API' in run_dry_gen('pyslvs', 'Pyslvs-UI')
    assert '# Pyslvs API' in run_dry_gen('pyslvs_core', 'Pyslvs')
    assert '# Pyslvs_Graph API' in run_dry_gen(
        'pyslvs_graph', 'Pyslvs_Graph'
    )

# Generated at 2022-06-23 15:27:46.455630
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages("pyslvs_ui", "."))) == 145
    assert len(list(walk_packages("pyslvs", "."))) == 87

# Generated at 2022-06-23 15:27:48.552218
# Unit test for function walk_packages
def test_walk_packages():
    from .path import path_of
    for name, path in walk_packages('pyslvs', path_of(__file__)):
        print(name, path)

# Generated at 2022-06-23 15:27:51.125942
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert loader('pyslvs', '.', True, 1, True)
    assert loader('numpy', '.', True, 1, True).startswith('# Numpy')


# Generated at 2022-06-23 15:27:53.988527
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:28:04.239369
# Unit test for function gen_api
def test_gen_api():
    """function test."""

    from disp import set_log_level
    from os.path import isfile, join, dirname
    from shutil import rmtree
    from os import remove, makedirs

    set_log_level(False, False, None)

    docs = gen_api({'Title': 'foo_bar'}, prefix='test', dry=True)
    assert len(docs) == 1
    assert docs[0].startswith('# Title API')
    assert docs[0].endswith('## Class FooBarClass\n```python\nclass FooBarClass:\n    pass\n```\n\n## Function foo_bar_function\n```python\ndef foo_bar_function(a: int) -> None:\n    pass\n```\n')


# Generated at 2022-06-23 15:28:12.780007
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from . import __path__ as pslvs_base
    logger.debug(f"base: {pslvs_base}")
    pslvs = pslvs_base[0]
    assert f"{pslvs}/__init__.py" == parent(__file__)

# Generated at 2022-06-23 15:28:24.044642
# Unit test for function loader
def test_loader():
    """Run loader."""
    from .parser import Parser
    from .pkg_path import pkg_path

    class Fake(dict):

        def __getitem__(self, key: str) -> str:
            return key

        def __call__(self, path: str) -> 'Fake':
            return self

    class Loader:

        def __init__(self, path: str) -> None:
            self.path = path

        def exec_module(self, mod: 'Fake') -> None:
            """Load module."""
            mod["__file__"] = self.path
            mod["__doc__"] = _read(self.path)

    p = Parser.new(False, 2, False)

# Generated at 2022-06-23 15:28:31.980715
# Unit test for function gen_api
def test_gen_api():
    """Test if this function works."""
    from pytest import raises
    with raises(LookupError):
        gen_api({})
    from .logger import logger_handler
    gen_api({
        "RPL"   : "pyslvs",
        "Solvers": "pyslvs_ui.qt_patch",
        "GPL"   : "pyslvs_ui",
        "VPL"   : "pyslvs_viz",
    }, prefix='tmp', link=False, level=2, toc=True, dry=False)
    logger_handler.clean_log()

# Generated at 2022-06-23 15:28:42.757553
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import sys
    import json
    import re
    from os.path import dirname, join, exists
    from tempfile import TemporaryFile
    from silksnake.api import json_pretty
    from silksnake.api.language import Language
    from silksnake.api.language import pyslvs as pyslvs_dict
    from silksnake.utils.time import time_it

    sys_path.append(dirname(dirname(dirname(__file__))))
    with TemporaryFile('w+', encoding='utf-8') as f:
        with time_it(lambda x: f'load time: {x:.2f} s'):
            logger.info(f"load module:")
            loader('pyslvs', '..', True, 1, False)


# Generated at 2022-06-23 15:28:46.181860
# Unit test for function walk_packages
def test_walk_packages():
    import inspect
    import pyvcp.logger
    path = inspect.getfile(pyvcp.logger)
    assert list(walk_packages('pyvcp', dirname(path))) == [
        ('pyvcp.logger', path)
    ]

# Generated at 2022-06-23 15:28:54.760007
# Unit test for function loader
def test_loader():
    from pkg_resources import resource_filename
    import pkgutil
    import shutil

    def assert_dry(name: str, link: bool = True, level: int = 1, toc: bool = False):
        pwd = resource_filename(__name__, "test_module")
        path = abspath(pwd)
        assert loader(name, path, link, level, toc) == _read(join(path, name + "-api.md"))

    def assert_gen(root: str, name: str):
        path = dirname(dirname(dirname(dirname(dirname(dirname(__file__))))))
        assert gen_api({root: name}, path, dry=True) == [_read(join(path, f"{name}-api.md"))]


# Generated at 2022-06-23 15:29:05.806949
# Unit test for function loader
def test_loader():
    """Testing for loader()."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from .files import Truncate
    from .parser import new_parser

    temp_dir = mkdtemp(prefix="_test_loader-")

    def test_root(name: str, path: str, dry: bool = True):
        if not isdir(path):
            logger.info(f"Create directory: {path}")
            mkdir(path)
        with Truncate(join(path, '__init__.py')) as f:
            f.write('')
        logger.info(f"Create file: {join(path, 'a.py')}")

# Generated at 2022-06-23 15:29:09.631192
# Unit test for function gen_api
def test_gen_api():
    """Test the gen_api method."""
    from .parser import root_names
    docs = gen_api(root_names)
    for doc in docs:
        assert len(doc) > 0

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:29:19.700290
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os.path import dirname
    from pkgutil import get_loader
    from .test_parser import test_parser
    from .test_package import test_package
    from .test_find_link import test_find_link

    with test_find_link(), test_parser(), TemporaryDirectory() as td:
        td_path = dirname(td)
        td_name = get_loader(td_path).get_filename(td_path)
        test_package(td_path, td_name, td_path)
        with test_package(td_name, td_path, td_path) as m:
            gen_api({'Test Package': 'package'}, dirname(dirname(m.__file__)))

# Generated at 2022-06-23 15:29:27.790907
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert not loader("sys", "test_loader-test", False, 1, False).strip()
    assert "test_loader.test_doc\n" in loader("test_loader", ".", True, 1, False)
    assert "test_loader.test_doc\n" in loader("test_loader", ".", True, 1, True)
    assert "test_loader.test_doc\n" not in loader("test_loader", ".", False, 1, False)
    assert "test_loader.test_doc\n" not in loader("test_loader", ".", False, 1, True)

# Generated at 2022-06-23 15:29:32.359386
# Unit test for function walk_packages
def test_walk_packages():
    with open("../tests/pyslvs/__init__.py", "w+") as f:
        f.write("""
__all__ = [
    'compiler',
    'logger',
    'parser',
    'components',
    'plotter',
    'system',
    'solver',
]
""")

# Generated at 2022-06-23 15:29:40.837955
# Unit test for function gen_api
def test_gen_api():
    from .test_lib import temp_cwd
    from pkgutil import get_loader
    from .parser import Linker
    from collections import OrderedDict
    docs = OrderedDict([
        ('Simplex', Linker.new(True, 1).parse(
            "Simplex.reproduce_simple",
            get_loader("Pyslvs_ui.widgets.reproduce").load_module()
        )),
    ])
    with temp_cwd() as t:
        assert gen_api(docs, t.path)