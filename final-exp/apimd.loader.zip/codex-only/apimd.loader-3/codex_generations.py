

# Generated at 2022-06-23 15:19:46.730597
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from pytest import approx
    from .test_data import DOCS, WALK
    from .logger import logger, logger_handler
    with TemporaryDirectory() as tmp:
        for level in [logger.TRACE, logger.DEBUG]:
            logger.setLevel(level)
            logger_handler.setLevel(level)
            for k, v in DOCS.items():
                with open(join(tmp, k), 'w') as f:
                    f.write(v)
            assert list(walk_packages('', tmp)) == approx(WALK, abs=1e-3)

# Generated at 2022-06-23 15:19:58.091172
# Unit test for function walk_packages
def test_walk_packages():
    for n, p in walk_packages('tensorflow', 'D:/Program Files/Python37'):
        assert 'tensorflow' in n
        assert p.endswith(('.py', '.pyi'))

    for n, p in walk_packages('tensorflow_estimator', 'D:/Program Files/Python37'):
        assert 'tensorflow_estimator' in n
        assert p.endswith(('.py', '.pyi'))

    for n, p in walk_packages('tensorflow.python.estimator', 'D:/Program Files/Python37'):
        assert 'tensorflow.python.estimator' in n
        assert p.endswith(('.py', '.pyi'))


# Generated at 2022-06-23 15:20:01.496480
# Unit test for function walk_packages
def test_walk_packages():
    s = _site_path("pyslvs_ui")
    for name, path in walk_packages("pyslvs_ui", s):
        print(f"{name} -- {path}")


# Generated at 2022-06-23 15:20:05.579672
# Unit test for function walk_packages
def test_walk_packages():
    for n, p in walk_packages("pyslvs", "pyslvs"):
        logger.debug(f"{n} <= {p}")
    for n, p in walk_packages("pyslvs", "docs"):
        logger.debug(f"{n} <= {p}")



# Generated at 2022-06-23 15:20:09.640164
# Unit test for function gen_api
def test_gen_api():
    try:
        from pkgutil import walk_packages
    except ImportError:
        return
    assert gen_api({'Test': 'pyslvs'}, pwd=dirname(abspath(__file__)))

# Generated at 2022-06-23 15:20:19.311578
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    from os import remove
    from os.path import dirname, isfile
    from shutil import rmtree
    from pkgutil import get_data
    from .version import __version__
    from .parser import Parser

    # Write files
    pwd = dirname(__file__)
    for name, sub in [
        ("package", ["__init__.py", "__pycache__"]),
        ("module.py", []),
    ]:
        for ext in sub:
            path = f"{pwd}{sep}{name}{ext}"
            try:
                remove(path)
            except FileNotFoundError:
                pass
    __file__ = f"{dirname(__file__)}{sep}test{sep}module.py"

# Generated at 2022-06-23 15:20:25.085852
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'Pyslvs': 'pyslvs',
    }
    gen_api(root_names, './build/lib', prefix='docs', link=True, level=1, toc=False, dry=True)

# Generated at 2022-06-23 15:20:36.445836
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from getter import _chdir
    from tempfile import TemporaryDirectory
    with _chdir(TemporaryDirectory()) as path:
        open('a.py', 'w+').close()
        open('b.pyi', 'w+').close()
        open('c.pyi', 'w+').close()
        # Create a dir and init file
        mkdir('d')
        open('d/__init__.py', 'w+').close()
        open('d/e.py', 'w+').close()
        # No init file and python file
        mkdir('f')
        open('f/e.pyi', 'w+').close()
        # Create a package
        mkdir('g')
        mkdir('g/__pycache__')
        # Create a stubs

# Generated at 2022-06-23 15:20:48.239756
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as d:
        assert tuple(walk_packages("a", d)) == ()
        assert tuple(walk_packages("a", join(d, "foo"))) == ()
        path = join(d, "a.py")
        _write(path, "")
        assert tuple(walk_packages("a", d)) == (("a", path),)
        path = join(d, "b.py")
        _write(path, "")
        assert tuple(walk_packages("a", d)) == (("a", path), ("a.b", path))
        path = join(d, "foo", "c.py")
        _write(path, "")

# Generated at 2022-06-23 15:20:57.860081
# Unit test for function walk_packages
def test_walk_packages():
    root = "test"
    pwd = "test/test_pkgutil"

# Generated at 2022-06-23 15:21:04.251086
# Unit test for function walk_packages
def test_walk_packages():
    dirs = "D:/Projects/home-api/venv/Lib/site-packages"
    name = "homeassistant"
    path = abspath(dirs) + sep
    valid = (path + name, path + name + PEP561_SUFFIX)
    for root, _, fs in walk(path):
        for f in fs:
            if not f.endswith(('.py', '.pyi')):
                continue
            f_path = parent(join(root, f))
            if not f_path.startswith(valid):
                continue
            name = (f_path
                    .removeprefix(path)
                    .replace(PEP561_SUFFIX, "")
                    .replace(sep, '.')
                    .removesuffix('.__init__'))
            print(name)

# Generated at 2022-06-23 15:21:07.973558
# Unit test for function gen_api
def test_gen_api():
    logger.info("Unit test for gen_api")
    docs = gen_api(dict(unittest="tests"), pwd=dirname(__file__), dry=True)
    assert len(docs) == 1
    logger.info("Test passed")


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:21:09.773212
# Unit test for function loader
def test_loader():
    logger.setLevel(20)
    assert len(gen_api(dict(test="test_module"), pwd=__file__[:-11])) > 0

# Generated at 2022-06-23 15:21:11.869395
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    assert gen_api({
        "Sylva API": "sylvester"
    }, dry=True)



# Generated at 2022-06-23 15:21:23.878258
# Unit test for function gen_api
def test_gen_api():
    from . import __path__ as test_path
    from .parser import __parser__

    # p = parser(
    #     link=False,
    #     level=1,
    #     toc=False,
    # )
    docs = gen_api(
        {
            'pyslvs-ui': 'pyslvs_ui'
        },
        pwd=test_path[0],
        prefix='_build',
        link=True,
        level=1,
        toc=False,
        dry=False
    )
    assert docs


# Generated at 2022-06-23 15:21:29.243676
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    import unittest
    import tempfile
    from os import close, remove
    from os.path import isdir, isfile
    from pyslvs_ui.parser import render

    def mkmodule(name: str, docstring: str, *, folder: str = None) -> str:
        """Create stub module file."""
        body = render(docstring)
        if folder is None:
            folder = ""
        path = 'temp' + sep + folder + name + PEP561_SUFFIX
        with open(path, 'w+') as f:
            f.write(body)
        return abspath(path)

    class TestWalk(unittest.TestCase):
        """Test case of class walk."""

        def setUp(self):
            """Create folder and files."""

# Generated at 2022-06-23 15:21:31.911911
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import default_root_names

    docs = gen_api(default_root_names)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:21:41.765487
# Unit test for function walk_packages
def test_walk_packages():
    from .demo_package import __file__ as pwd
    name = "demo_package"
    path = abspath(pwd)
    pkg = list(walk_packages(name, _site_path(name)))
    assert pkg[0][0] == f"{name}.__init__"
    assert pkg[1][0] == f"{name}.__main__"
    assert pkg[2][0] == f"{name}.foo"
    assert pkg[3][0] == f"{name}.foo.__init__"
    assert pkg[4][0] == f"{name}.foo.class_2"
    assert pkg[5][0] == f"{name}.foo.foo"

# Generated at 2022-06-23 15:21:49.701226
# Unit test for function gen_api
def test_gen_api():
    import pytest
    from tempfile import mkdtemp
    from os import chdir, rmdir

    @pytest.yield_fixture
    def temp():
        """Generate a temporary directory."""
        chdir(mkdtemp())
        yield
        rmdir("./docs")

    @pytest.fixture
    def test_docs():
        """The test documents."""
        return {'Test': 'test'}

    def test_gen_api(temp, test_docs):
        """Generate API without dry."""
        gen_api(test_docs)

    def test_gen_api_dry(temp, test_docs):
        """Generate API with dry."""
        gen_api(test_docs, dry=True)


# Generated at 2022-06-23 15:21:50.775996
# Unit test for function gen_api
def test_gen_api():
    gen_api({"Doc": "doc"})

# Generated at 2022-06-23 15:22:00.408811
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    from .utils import tmp_dir
    with tmp_dir() as temp:
        logger.info(f"Start temporary directory: {temp}")
        # Create modules
        with open(join(temp, '__init__.py'), 'w'):
            pass
        with open(join(temp, 'file1.py'), 'w') as f:
            f.write("""
                def foo() -> None:
                    '''
                    >>> foo()
                    'foo'
                    '''
                    return 'foo'
            """)
        with open(join(temp, 'file2.py'), 'w') as f:
            f.write("""
                def bar() -> None:
                    '''
                    >>> bar()
                    'bar'
                    '''
                    return 'bar'
            """)
       

# Generated at 2022-06-23 15:22:08.856918
# Unit test for function loader
def test_loader():
    """Test function."""
    # Create the dummy package
    import tempfile
    temp = tempfile.TemporaryDirectory()
    # Create package root
    mkdir(join(temp.name, 'pkg1'))
    # Create the __init__ file
    logger.info("Create the __init__ file")
    _write(join(temp.name, 'pkg1/__init__.py'), '"""Pkg 1"""')
    # Create package
    logger.info("Create package")
    mkdir(join(temp.name, 'pkg1/pkg2'))
    # Create the __init__ file
    logger.info("Create the __init__ file")
    _write(join(temp.name, 'pkg1/pkg2/__init__.py'), '"""Pkg 2"""')
    # Create test module

# Generated at 2022-06-23 15:22:19.891923
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk_packages."""
    name = "pyslvs"
    path = "./pyslvs/tests/data"

# Generated at 2022-06-23 15:22:28.526913
# Unit test for function loader
def test_loader():
    """Unit test function loader."""
    import pkgutil
    import sysconfig
    import importlib
    import libpath_mod
    importlib.reload(libpath_mod)
    root = '_test_'
    pwd = sysconfig.get_path('data')
    # Load root first
    libpath_mod.add_path(pwd)
    try:
        __import__(root)
    except ImportError:
        logger.warning("Test data is not present, skip for now")
        return
    logger.info(f"Parse module: {root}")
    logger.debug(f"pwd = {pwd}")
    doc = loader(root, pwd, True, 1, True)
    logger.info(f"Write file: {root}-api.md")

# Generated at 2022-06-23 15:22:29.150235
# Unit test for function gen_api
def test_gen_api():
    gen_api({})

# Generated at 2022-06-23 15:22:35.142860
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    from pyslvs import __path__ as pyslvs_path
    with tempfile.TemporaryDirectory() as pwd:
        docs = gen_api(
            {'Pyslvs': 'pyslvs', 'Pyslvsui': 'pyslvs_ui'},
            str(pyslvs_path[0]),
            pwd=pwd,
            dry=True
        )
        assert len(docs) == 2
        assert docs[0].startswith('#### Pyslvs API')

# Generated at 2022-06-23 15:22:44.441012
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import pytest
    from os import devnull, remove
    from os.path import abspath, dirname, join
    from .logger import logger
    from .compiler import gen_api

    # Mocking module files
    devnull = open(devnull, 'w')

    class MockModule(object):
        FILE: str = ""

        def __init__(self, path, name):
            self.__name__ = name
            self.FILE = path

    def mock(path: str, name: str):
        return MockModule(abspath(path), name)

    def mock_import(path: str, name: str):
        m = mock(path, name)
        sys_path.append(dirname(path))
        return __import__(name)


# Generated at 2022-06-23 15:22:52.631489
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    root_names = {"Pyslvs": "pyslvs"}
    pwd = __file__.rsplit(sep, 1)[0]
    assert gen_api(root_names, pwd)
    assert gen_api(root_names, pwd, link=False)
    assert gen_api(root_names, pwd, level=2)
    assert gen_api(root_names, pwd, toc=True)
    assert gen_api(root_names, pwd, dry=True)


# Generated at 2022-06-23 15:23:00.926877
# Unit test for function gen_api
def test_gen_api():
    from random import random
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from os.path import dirname
    from os.path import join as pjoin
    from shutil import copytree

    with TemporaryDirectory() as tmp:
        # copy resources
        copytree(pjoin(dirname(__file__), "test", "resources"), tmp)
        copytree(resource_filename("pyslvs", "examples"), tmp)

        # random test for pure Python module
        docs = gen_api({"slvs": "slvs.examples.random"}, tmp)
        assert len(docs) == 1
        doc = docs[0]
        assert len(doc)
        assert doc.endswith("\n")
        assert doc.startswith("# slvs API\n\n")

# Generated at 2022-06-23 15:23:10.067239
# Unit test for function walk_packages
def test_walk_packages():
    import sysconfig
    # Find the python version
    pyver = sysconfig.get_config_var('py_version_short')
    # Get the python site-packages path
    pkgdir = sysconfig.get_path('purelib')
    # Test for normal package directory
    assert list(walk_packages(
        'pyslvs_ui',
        join(pkgdir, 'pyslvs_ui')
    )) == list(walk_packages(
        'pyslvs_ui',
        join(pkgdir, 'pyslvs_ui-stubs')
    ))
    # Test for the built-in module for Python is not standard library

# Generated at 2022-06-23 15:23:19.452348
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    from shutil import rmtree
    from contextlib import suppress
    from .test_pack_template import test_pack_template

    def test_case(root_name: str, root_path: str) -> None:
        with suppress(FileExistsError):
            mkdir(root_path)
        with suppress(FileExistsError):
            mkdir(join(root_path, 'A'))
        with suppress(FileExistsError):
            mkdir(join(root_path, 'B'))
        mkdir(join(root_path, 'B', 'C'))
        with suppress(FileExistsError):
            mkdir(join(root_path, 'D'))
        with suppress(FileExistsError):
            mkdir(join(root_path, 'D', 'E'))
       

# Generated at 2022-06-23 15:23:30.861535
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    import pkgutil
    from . import __name__ as root_name

    def pkg_path(name: str) -> str:
        path = _site_path(name)
        for child in name.split('.'):
            path = join(path, child)
            if not isfile(path + '.py'):
                break
        return path

    def check(name: str, title: str) -> None:
        with TemporaryDirectory() as pwd:
            sys_path.append(pwd)

# Generated at 2022-06-23 15:23:35.577984
# Unit test for function gen_api
def test_gen_api():
    doc = '# Test\n\n'
    out = gen_api({'Test': 'pyslvs'}, dry=True)[0]
    print(out == doc)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:23:43.473088
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil
    docs = gen_api(
        {
            'Pyslvs': 'pyslvs',
            'Pyslvs UI': 'pyslvs_ui',
            'Pyslvs-web': 'pyslvs_web',
            'Pyslvs-wx': 'pyslvs_wx',
            'Pyslvs-planar': 'pyslvs_planar',
        },
        '/Users/Yuan/anaconda3/envs/pyslvs/lib/python3.8/site-packages',
        dry=True,
        prefix='docs'
    )
    assert len(docs) == 2
    assert docs[0].startswith('# Pyslvs API\n')

# Generated at 2022-06-23 15:23:53.028772
# Unit test for function gen_api
def test_gen_api():
    print("Test for gen_api:")
    print("=" * 12)
    class DummyConsole:
        def __init__(self):
            self.__messages = []

        def log(self, *args, **kwargs):
            self.__messages.append("\n".join(args))

        def log_list(self):
            return self.__messages

    t = DummyConsole()
    try:
        logger.remove_handler('console')
    except KeyError:
        pass
    logger.add_handler('console', t.log)
    logger.level = 'DEBUG'

# Generated at 2022-06-23 15:23:58.387969
# Unit test for function gen_api
def test_gen_api():
    from .handler import init_logger, kill_logger
    from .path_tool import temp_directory
    from .temp_file import temp_file
    init_logger()
    path = temp_directory('pyslvs-')

# Generated at 2022-06-23 15:24:03.455958
# Unit test for function loader
def test_loader():
    from pprint import pprint
    from .demo import demo
    from .demo import name as demo_name
    from .demo import version as demo_version
    print(loader(demo.__name__, dirname(demo.__file__), True, 2, False))
    pprint(demo_name)
    pprint(demo_version)

# Generated at 2022-06-23 15:24:06.288617
# Unit test for function gen_api
def test_gen_api():
    logger.setLevel(40)
    from os.path import curdir
    gen_api({'Solver': 'solver', 'Module': 'module'}, pwd=curdir, dry=True)

# Generated at 2022-06-23 15:24:18.308342
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api()."""
    import unittest
    import sys
    import shutil
    import tempfile
    try:
        from pathlib import Path
    except ImportError:
        # pylint: disable=F0401
        raise unittest.SkipTest("pathlib is not available")
    from .compiler import gen_api, _read

    class TestMain(unittest.TestCase):
        """Unit test."""

        def setUp(self) -> None:
            self.temp_dir = Path(tempfile.mkdtemp())
            sys.path.insert(1, str(self.temp_dir))

        def tearDown(self) -> None:
            shutil.rmtree(str(self.temp_dir))
            sys.path.remove(str(self.temp_dir))



# Generated at 2022-06-23 15:24:26.169011
# Unit test for function gen_api
def test_gen_api():
    from io import StringIO
    from logging import Handler, StreamHandler
    from sys import stdout
    from unittest import TestCase, mock
    from importlib import import_module

    class DummyModule:

        def __init__(self, **kwargs: str):
            attrs = {name: getattr(import_module(name), name)
                     for name in kwargs}
            self.__dict__.update(**attrs)

    class StrHandler(Handler):

        def emit(self, record):
            self.stream.write(record.msg + '\n')

    o_stream = StringIO()
    with mock.patch('sys.stderr', o_stream):
        with mock.patch('sys.stdout', o_stream):
            h = StreamHandler(stdout)

# Generated at 2022-06-23 15:24:38.284578
# Unit test for function loader
def test_loader():
    """Testing the loader."""
    from importlib.util import module_from_spec
    from importlib.machinery import ExtensionFileLoader

    class StubLoader(ExtensionFileLoader):
        """Stub loader."""

        def create_module(self, spec: ModuleSpec) -> None:
            pass

    def load_module(name: str, path: str) -> None:
        """Load module directly."""
        s = spec_from_file_location(name, path)
        assert s is not None
        assert isinstance(s.loader, ExtensionFileLoader)
        m = module_from_spec(s)
        s.loader.exec_module(m)


# Generated at 2022-06-23 15:24:41.278661
# Unit test for function loader
def test_loader():
    assert loader(
        root="pyslvs",
        pwd=dirname(dirname(abspath(__file__))) + sep,
        link=True,
        level=1,
        toc=False
    )


# Generated at 2022-06-23 15:24:50.681777
# Unit test for function gen_api

# Generated at 2022-06-23 15:25:02.084600
# Unit test for function gen_api
def test_gen_api():

    logger.setLevel(40)
    logger.addHandler(logger.StreamHandler())
    import os

    cur_path = os.path.abspath('.')
    print(os.listdir(cur_path))
    import matplotlib
    print(matplotlib.matplotlib_fname())
    root_names = {
        'Matplotlib':'matplotlib',
        'NumPy':'numpy',
    }
    print(root_names)
    print(_site_path('matplotlib'))
    print(_site_path('numpy'))
    # for name, path in walk_packages("matplotlib", _site_path("matplotlib")):
    #     print(name)
    #     print(path)

# Generated at 2022-06-23 15:25:12.209190
# Unit test for function loader
def test_loader():
    """Unittest for function loader."""
    from sys import stderr as stderr_
    from pkgutil import walk_packages as iterator
    from os import remove
    from contextlib import contextmanager

    @contextmanager
    def _prevent_logger():
        # Prevent load file
        _o_logger = logger
        logger.debug = lambda *args, **kwargs: None
        yield
        logger.debug = _o_logger

    with _prevent_logger():
        with open("test.out", "w") as fo:
            sys_path.append("test_data")
            base_path = "pyslvs:test_data.example"
            # Initialize
            parser = Parser.new(False, 1, False)
            # Gather sources

# Generated at 2022-06-23 15:25:17.727206
# Unit test for function gen_api
def test_gen_api():
    from . import PATH
    import xmlrpc.client
    gen_api(
        {f"{xmlrpc.client.__name__}": xmlrpc.client.__name__},
        dirname(dirname(dirname(dirname(
            abspath(__file__))))) + sep + 'Lib' + sep + 'site-packages'
    )
    from .markdown import parse_markdown
    parse_markdown(PATH + '/docs/xmlrpc-client-api.md')

# Generated at 2022-06-23 15:25:26.549105
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import sys
    import unittest
    import logging
    import doctest
    from contextlib import redirect_stdout

    class LoaderTC(unittest.TestCase):
        """Test case for function loader."""

        def test_loader(self) -> None:
            """Test for function loader."""
            with redirect_stdout(sys.stdout):
                DOC = loader("pyslvs", "..", False, 2, False)
            self.assertTrue(DOC.lstrip().startswith('## <a'))
            self.assertTrue(DOC.rstrip().endswith('</a>'))
            self.assertGreater(len(DOC), 10_000)
            logging.info('=' * 12)
            logging.info(DOC)


# Generated at 2022-06-23 15:25:38.022068
# Unit test for function walk_packages
def test_walk_packages():
    from os import listdir
    from os.path import commonpath
    try:
        from importlib_metadata import version
    except ImportError:
        from importlib.metadata import version
    for f in listdir(_site_path("pyslvs")):
        if f.startswith("_"):
            continue
        if f == "configure.py":
            continue
        if f == "__pycache__":
            continue
        files = []
        for title, name in walk_packages(f, _site_path("pyslvs")):
            if not name.endswith(".py"):
                continue
            files.append(name)
        if not files:
            continue
        assert all(commonpath(files).startswith(_site_path("pyslvs"))), files

# Generated at 2022-06-23 15:25:43.688309
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import sys
    print('\n'.join(gen_api({
        'SVGE': 'svge',
        'pyslvs': 'pyslvs',
    }, sys.path[0])))


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:25:47.285784
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages."""
    from shutil import rmtree
    import tempfile
    import os

    # Mock fake package

    path = abspath(tempfile.mkdtemp())
    os.chdir(path)
    mkdir('test')
    mkdir('test/util')
    mkdir('test/numpy_api')
    _write('test/__init__.py', '')
    _write('test/__init__.pyi', '')
    _write('test/__init__.pyi-stubs', '')
    _write('test/test.py', 'class A:\n    pass\n')
    _write('test/test.pyi', 'class A:\n    pass\n')

# Generated at 2022-06-23 15:25:54.222082
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    root_names = {
        'Dynamics': 'pyslvs_ui.dynamics',
        'GUI': 'pyslvs_ui.qt_ui',
        'Model': 'pyslvs_ui.data_model',
        'UI': 'pyslvs_ui.ui',
    }
    docs = gen_api(root_names)
    assert all(doc.strip() for doc in docs)

# Generated at 2022-06-23 15:26:05.224439
# Unit test for function loader
def test_loader():
    from unittest import mock
    from numpy import pi

    class MockLoader:

        def __init__(self, name: str):
            self.__name = name

        @staticmethod
        def exec_module(module: 'module'):
            if module.__name__ == 'numpy':
                module.pi = pi

    class MockSpec:

        def __init__(self, name: str, loader: 'Loader'):
            self.name = name
            self.loader = loader


# Generated at 2022-06-23 15:26:15.911121
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from pkgutil import iter_modules
    from pyslvs_ui.package_info import get_package_path, lib_path
    root = get_package_path('matplotlib')
    # Get all modules
    mods = list(iter_modules([root]))
    stubs = list(walk_packages('matplotlib', lib_path))
    # Check all stubs modules are located
    for name, path in stubs:
        name = name.replace('_', '-')
        if not isfile(path + '.py'):
            raise RuntimeError(f"module {path}.py not exists")
        if not isfile(path + '.pyi'):
            raise RuntimeError(f"module {path}.pyi not exists")

# Generated at 2022-06-23 15:26:26.407562
# Unit test for function loader
def test_loader():
    import sys
    import os
    import shutil
    from ..parser import parent
    from ..logger import log_disable
    log_disable()
    sys.path.append(os.getcwd())
    def test_write(name: str, doc: str) -> None:
        print(f"write: {name}")
        path = os.path.join('test_case', name)
        if os.path.isdir(path):
            shutil.rmtree(path)
        os.makedirs(path)
        for line in doc.splitlines():
            print(line)
            if not line.startswith('#'):
                file = os.path.join(path, f"{parent(line)}.py")
                with open(file, 'w') as f:
                    ext = line.split

# Generated at 2022-06-23 15:26:34.771599
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api functions."""
    from tempfile import TemporaryDirectory
    from shutil import copy2
    from os.path import exists
    from os import symlink
    from pkgutil import walk_packages
    from .logger import reset

    def get_path(name: str) -> str:
        """Get the path of pyslvs modules."""
        for loader, _, _ in walk_packages([dirname(__file__)]):
            spec = find_spec(name)
            if spec is not None and loader.path == dirname(spec.origin):
                return spec.origin
        raise FileNotFoundError(f"File {name} not found!")

    def get_file_path(name: str) -> str:
        """Get the file path of pyslvs."""

# Generated at 2022-06-23 15:26:44.560419
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages function."""
    from unittest.mock import patch
    from os import remove
    from os.path import isdir
    from sys import modules
    from .logger import LOGGER_NAME, LOGGER
    from .builder import build_pyslvs
    from .core import VPoint, VLink, SubElement, Property, Topology
    from .core.cp2t import CP

    def t_case(root, path):
        """Test case template."""
        modules.clear()
        with patch('sys.path', [path]):
            name, _ = next(walk_packages(root, path))
            assert len(modules) == 0
            assert __import__(name).__all__[0] != LOGGER_NAME
            assert LOGGER.Level != 10

# Generated at 2022-06-23 15:26:53.827850
# Unit test for function walk_packages
def test_walk_packages():
    """Test with some existing libraries."""
    logger.info(f"Testing walking package:")
    e = (_ for _ in walk_packages('numpy', '/usr/lib/python3.9') if 'core' in _[0])
    for _ in e:
        logger.info(_)
    e = (_ for _ in walk_packages('matplotlib', '/usr/lib/python3.9/site-packages')
         if 'rcsetup' in _[0])
    for _ in e:
        logger.info(_)
    e = (_ for _ in walk_packages('pyslvs', '/usr/lib/python3.9/site-packages')
         if 'plugins' in _[0])
    for _ in e:
        logger.info(_)


# Generated at 2022-06-23 15:26:56.441813
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages."""
    assert list(walk_packages('pyslvs', '..'))[0][0] == 'pyslvs'



# Generated at 2022-06-23 15:27:06.358336
# Unit test for function walk_packages

# Generated at 2022-06-23 15:27:18.379137
# Unit test for function gen_api

# Generated at 2022-06-23 15:27:26.666719
# Unit test for function walk_packages
def test_walk_packages():
    import shutil, tempfile
    t = tempfile.mkdtemp()
    def m(name, content):
        open(join(t, name), "w").writelines(content)
    m("foo.py", ['def foo():\n', '  "doc"\n'])
    m("foo.pyi", ['def foo() -> None:\n', '  """doc"""\n'])
    m("foo/__init__.py", ['def _():\n', '  "doc"\n'])
    m("foo/__init__.pyi", ['def _() -> None:\n', '  """doc"""\n'])
    m("foo/bar.py", ['def bar():\n', '  "doc"\n'])

# Generated at 2022-06-23 15:27:31.617235
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test'}, '.') is not None
    docs = gen_api({'pyslvs': 'pyslvs'}, '.')
    assert len(docs) > 0
    assert docs[0].startswith('## pyslvs')

# Generated at 2022-06-23 15:27:35.142870
# Unit test for function loader
def test_loader():
    from unittest.mock import patch
    from .test_doc import test_doc

    with patch.object(__builtins__, '__import__', test_doc):
        loader('pyslvs', '.', False, 1, False)

# Generated at 2022-06-23 15:27:46.845091
# Unit test for function gen_api
def test_gen_api():
    from . import arg_parse
    from .logger import test_log_setup
    from .parser import PREFIX
    from .loader import _compile
    from shutil import rmtree
    from os.path import isfile
    test_log_setup()

    if isdir(PREFIX):
        rmtree(PREFIX)
    g = gen_api({'examples': 'examples'}, dry=True)
    assert len(g) == 1, "Must be existed"
    assert _compile(g[0], True, 1, True) == "", "Must be empty"

    g = gen_api({'examples': 'examples'})
    assert len(g) == 1, "Must be existed"

# Generated at 2022-06-23 15:27:52.529085
# Unit test for function loader
def test_loader():
    from os.path import curdir
    from io import StringIO
    from contextlib import redirect_stdout
    docs = gen_api({'test': 'pyslvs'}, curdir, prefix='test', dry=True)
    f = StringIO()
    with redirect_stdout(f):
        for doc in docs:
            pass
    assert '<a href="#nodes" class="anchor"><svg xmlns="http://www.w3.org' in f.getvalue()
    assert 'Constraint system setup' in f.getvalue()
    assert '* [`variables`](#variables)' in f.getvalue()

# Generated at 2022-06-23 15:27:57.707216
# Unit test for function gen_api
def test_gen_api():
    root_names = {"test": "test"}
    pwd = abspath(__file__) + sep
    title, name = list(root_names.items())[0]
    doc = f'# {title} API\n\n## test.a\n\n### test.a.a1\n\n```python\ndef a1() -> None\n```\n\n'
    path = join('docs', f"{name.replace('_', '-')}-api.md")
    assert gen_api(root_names, pwd, prefix='docs', dry=True) == [doc]

# Generated at 2022-06-23 15:28:02.808891
# Unit test for function loader
def test_loader():
    from os.path import dirname
    from pkgutil import get_loader
    from importlib import import_module
    from .test_config import this_dir

    mock_path = abspath(join(this_dir, '..', 'mock_package'))
    assert get_loader('mock_package') is None
    assert 'mock_package' not in sys_path
    __import__('mock_package')
    assert get_loader('mock_package') is not None
    assert mock_path in sys_path

    assert not isdir('temp')
    __import__('mock_package.__main__')
    assert isdir('temp')
    path = join('temp', 'temp.py')

# Generated at 2022-06-23 15:28:11.066392
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory

    arg = dict(
        name='test',
        path='test',
    )
    with TemporaryDirectory() as temp_path:
        for i, ext in enumerate(['.pyi', '.py', '.so']):
            with open(temp_path + '/test' + ext, 'w') as file:
                file.write(str(i))
        assert len(list(walk_packages(**arg))) == 2
        for ext in ['.pyi', '.so']:
            with open(temp_path + '/test' + ext, 'w') as file:
                file.write(str(1))
        assert len(list(walk_packages(**arg))) == 0



# Generated at 2022-06-23 15:28:18.350411
# Unit test for function gen_api
def test_gen_api():
    from .sys_path import sys_path
    from .home import home
    prefix = join(home, 'docs')
    gen_api(
        root_names={"Pyslvs": "pyslvs"},
        pwd=sys_path,
        link=True,
        prefix=prefix,
        level=1,
        toc=True,
        dry=False
    )

# Generated at 2022-06-23 15:28:22.150687
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    import pkg_resources
    pkg = pkg_resources.require('pyslvs')[0]
    assert list(walk_packages('pyslvs', dirname(pkg.location)))

# Generated at 2022-06-23 15:28:31.617850
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages without import them."""
    def wp(name: str) -> set[str]:
        return set(walk_packages(name, '.'))
    assert wp('tests') == {('a', './a.py'),
                           ('b', './b.py'),
                           ('c', './c.py'),
                           ('d', './b/d.py'),
                           ('e', './e.py'),
                           ('f', './f.py'),
                           ('g', './g.py'),
                           ('h', './h.py')}
    assert wp('b') == {('b.d', './b/d.py'),
                       ('d', './b/d.py')}

# Generated at 2022-06-23 15:28:36.842769
# Unit test for function walk_packages
def test_walk_packages():
    t = list(walk_packages("pkgutil_parent", "tests"))
    assert len(t) == 2
    assert t[0] == ("pkgutil_parent.py2", "tests/pkgutil_parent.py")
    assert t[1] == ("pkgutil_parent.py3", "tests/pkgutil_parent.py")

# Generated at 2022-06-23 15:28:47.391024
# Unit test for function loader
def test_loader():
    from unittest import TestCase, mock, main

    class LoaderTest(TestCase):
        """Test loader function."""

        @mock.patch('sphinx_svd_theme.loader.Parser.new')
        @mock.patch('sphinx_svd_theme.loader.walk_packages')
        @mock.patch('sphinx_svd_theme.loader._load_module')
        def test_loader(self, mock_load_module, mock_walk_packages, mock_parser):
            # Parser object
            p = mock_parser.return_value
            # Load module with stub module
            mock_walk_packages.return_value = [('a', 'b'), ('a.b', 'c')]
            p.load_docstring.return_value = True
            # Pure py module
           

# Generated at 2022-06-23 15:28:54.952415
# Unit test for function walk_packages
def test_walk_packages():

    # Test with a simple package
    assert list(walk_packages('abc', 'abc')) == [('abc', 'abc/__init__.py')]

    # Test with a complex packages

# Generated at 2022-06-23 15:29:06.346533
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import exists
    from shutil import copytree, rmtree
    from tempfile import gettempdir

    def assert_dir(dirname: str) -> str:
        if not exists(dirname):
            mkdir(dirname)
            assert exists(dirname)
        return dirname

    def assert_file(filepath: str, content: str) -> None:
        with open(filepath, 'w+') as f:
            f.write(content)
        assert exists(filepath)

    def assert_walk_packages(
        name: str,
        path: str,
        expect: Sequence[tuple[str, str]]
    ) -> None:
        actual = sorted(walk_packages(name, path))
        assert actual == expect

    # Temporarily copy a "site-packages" directory
   

# Generated at 2022-06-23 15:29:12.323778
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("test", __file__)) == [
        ('test.__init__', __file__),
        ('test.a', __file__.replace('.py', '.a.py')),
        ('test.a.b', __file__.replace('.py', '.a.b.py')),
        ('test.a.c', __file__.replace('.py', '.a.c.py')),
        ('test.a.d', __file__.replace('.py', '.a.d.py'))
    ]

# Generated at 2022-06-23 15:29:21.932261
# Unit test for function loader
def test_loader():
    import unittest
    from os import remove
    from os.path import isfile
    from itertools import chain

    def file_test(m: str, l: str, d: str) -> None:
        """Check if file is created."""
        if not isfile(m):
            raise unittest.TestCase.failureException(f"{l} no file created")
        if not isfile(d):
            raise unittest.TestCase.failureException(f"{l} no dir created")

    class LoaderTest(unittest.TestCase):

        def test_loader(self):
            """Test for loader."""
            # Clean all files

# Generated at 2022-06-23 15:29:24.511919
# Unit test for function gen_api
def test_gen_api():
    assert(gen_api({
        "pyslvs": "pyslvs",
        "PyQt5": "PyQt5"
    }, "..")[0].startswith("# PyQt5 API"))

# Generated at 2022-06-23 15:29:27.352103
# Unit test for function walk_packages
def test_walk_packages():
    name = "pyslvs"
    path = join(dirname(__file__), "..")
    n = len(name) + 1
    for name, _ in walk_packages(name, path):
        assert name[:n] == f'{name}.__init__'
    assert list(walk_packages(name, path))

# Generated at 2022-06-23 15:29:39.081308
# Unit test for function walk_packages
def test_walk_packages():
    from .test_cases.package_test import package_test
    from .test_cases.package_test2 import package_test2

# Generated at 2022-06-23 15:29:46.889560
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from pytest import mark, raises

    @mark.parametrize("api_name, api_title", [
        ('solvespace_core', 'SolveSpace Core'),
        ('solvespace_ui', 'SolveSpace UI'),
        ('solvespace_g2c', 'SolveSpace Geometry to C'),
    ])
    def test_generate(api_name, api_title, tmpdir):
        """Test the generated API."""
        path = tmpdir / "docs"
        docs = gen_api({api_title: api_name}, prefix=path, dry=True)
        assert docs[0] is not None
        with raises(FileNotFoundError):
            gen_api({api_title: api_name}, prefix=path, dry=False)