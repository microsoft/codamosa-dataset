

# Generated at 2022-06-23 15:19:39.495824
# Unit test for function gen_api
def test_gen_api():
    """Test."""
    assert not gen_api(dict(IV=''), level=0, pwd='../', dry=True)


# Generated at 2022-06-23 15:19:46.715935
# Unit test for function walk_packages
def test_walk_packages():
    from .test_common import assert_equal

# Generated at 2022-06-23 15:19:58.040289
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from shutil import copytree

    def _assert_walk_packages(name: str, path: str) -> None:
        package = set([
            (name, path + ".py"),
            (name, path + ".__init__.py"),
            (name, path + ".__main__.py"),
            (name, path + "-stubs.pyi"),
            (name, path + ".__init__-stubs.pyi"),
            (name, path + ".__main__-stubs.pyi"),
        ])
        assert package == set(walk_packages(name, path))

    test_path = Path(__file__).parent / 'tests' / 'package_loader_test'
    temp_path = Path(__file__).parent / 'package_temp'
    temp_path.mkdir

# Generated at 2022-06-23 15:20:06.571183
# Unit test for function loader
def test_loader():
    from unittest import TestCase
    from pyslvs_ui.parser import Parser

    class TestLoader(TestCase):

        def test_loader(self):
            p = Parser()
            fake_path = abspath('.')
            for name, path in walk_packages('fake_package', fake_path):
                print("=" * 80)
                print(name, path)
                p.parse(name, _read(path + ".py"))
                print("-" * 40)
                print(p)
                p = Parser()

    TestLoader().test_loader()


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:20:09.883703
# Unit test for function walk_packages
def test_walk_packages():
    """Test the walk_packages unit test."""
    assert len(list(walk_packages("test", __file__[:__file__.rfind("/")]))) == 4

# Generated at 2022-06-23 15:20:18.849809
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'clipper': 'pyslvs_ui.clipper',
        'compiler': 'pyslvs_ui.compiler',
        'drawer': 'pyslvs_ui.drawer',
        'loader': 'pyslvs_ui.loader',
        'math': 'pyslvs_ui.math',
        'parser': 'pyslvs_ui.parser',
        'solver': 'pyslvs_ui.solver',
        'ui': 'pyslvs_ui.ui',
    }
    gen_api(root_names, pwd=abspath(dirname(__file__)))

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:20:24.393130
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from .parser import gen_nav
    from .logger import set_log_level

    set_log_level(2)
    with TemporaryDirectory() as temp_dir:
        root_names = {'pyslvs': 'pyslvs', 'math': 'pyslvs_math'}
        pk = resource_filename('pyslvs_ui', 'data')
        pk_math = resource_filename('pyslvs_math', 'data')
        docs = gen_api(root_names, temp_dir, pk, prefix=temp_dir, dry=True)
        assert isinstance(docs, list)
        docs1 = gen_api(root_names, pk_math, prefix=pk_math, dry=True)

# Generated at 2022-06-23 15:20:26.110839
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    path = dirname(abspath(__file__))
    print(loader("test", path, link=False, level=1, toc=False))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:20:33.123461
# Unit test for function loader
def test_loader():
    """Test function loader."""
    filename = "unittest.py"
    filename_ext = filename + ".cpython-38.pyc"
    # Module not found
    find_spec("pkg_resources") is None
    find_spec("PySide2") is None
    # Insert path
    sys_path.append(dirname(__file__))
    # Load module from source
    p = Parser.new(False, 1, False)
    assert _load_module("unittest", filename, p)
    # Test the built-in name or absolute path
    assert _load_module("os", "", p) is False
    # Load module from compiled code
    assert _load_module("unittest", filename_ext, p)
    # Load module from package
    p = Parser.new(False, 1, False)

# Generated at 2022-06-23 15:20:44.906115
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages()."""
    def _init_data(root: str):
        mkdir(root)
        _write(join(root, "__init__.py"), "")
        _write(join(root, "__init__.pyi"), "")
        _write(join(root, "b.py"), "")
        _write(join(root, "c.pyi"), "")
        mkdir(join(root, "test.foo"))
        _write(join(root, "test.foo", "__init__.py"), "")
        _write(join(root, "test.foo", "__init__.pyi"), "")
        _write(join(root, "test.foo", "__init__.bar"), "")

# Generated at 2022-06-23 15:20:47.242556
# Unit test for function gen_api
def test_gen_api():
    gen_api({f"{i}": f"{i}" for i in range(10)}, toc=True, dry=True)

# Generated at 2022-06-23 15:20:54.097570
# Unit test for function loader
def test_loader():
    """Function loader."""
    from argparse import Namespace
    from collections import UserDict
    assert loader(
        "pyslvs", "..",
        Namespace(link=True, level=1, toc=False),
        UserDict({
            "title": "Pyslvs",
            "pyslvs": "pyslvs",
        })
    )
    from .io_output import pyslvs_api
    assert pyslvs_api()

# Generated at 2022-06-23 15:21:01.185380
# Unit test for function gen_api

# Generated at 2022-06-23 15:21:06.606042
# Unit test for function loader
def test_loader():
    _write(join(_site_path('typing'), 'annotations.pyi'), '')
    _write(join(_site_path('typing'), 'overload.pyi'), '')
    assert loader('typing', _site_path('typing'), True, 1, False)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:21:14.445225
# Unit test for function walk_packages
def test_walk_packages():
    def _print_root(root):
        return ".".join(filter(None, (root.rsplit(".", 1)[0], "__init__.py")))

    def _walk_packages():
        yield from walk_packages("pyslvs_ui", ".")


# Generated at 2022-06-23 15:21:21.434247
# Unit test for function loader
def test_loader():
    """Unit test."""
    name = "pyslvs_ui"
    import pyslvs_ui
    p = "C:/f/GitHub/PySLVS/PySLVS/pyslvs_ui"
    pyslvs_ui.__path__.append(p)
    logger.info(f"{name} <= {p}")
    for _, path in walk_packages(name, p):
        print(path)

# Generated at 2022-06-23 15:21:25.836571
# Unit test for function gen_api
def test_gen_api():
    import argparse
    parser = argparse.ArgumentParser(description='Unit test for pyslvs')
    parser.add_argument('--debug', type=bool, default=False)
    args = parser.parse_args()
    debug = args.debug
    gen_api({"Pyslvs-core": 'pyslvs', "Pyslvs-ui": 'pyslvs_ui'}, prefix='docs', debug=debug, dry=False)
    

# Generated at 2022-06-23 15:21:29.061486
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test':'test', 'test2':'test2'}, prefix='test_api', dry=True)

# Generated at 2022-06-23 15:21:39.026219
# Unit test for function walk_packages

# Generated at 2022-06-23 15:21:46.720997
# Unit test for function walk_packages
def test_walk_packages():
    from pkgutil import walk_packages
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    for ext in ('.py', '.pyi'):
        with TemporaryDirectory(prefix='pyslvs-') as pydir:
            for name in ('test', 'test.__init__', 'test.test'):
                mkdir(pydir + '/' + parent(name))
                copyfile(__file__, pydir + '/' + name + ext)
            for n, p in walk_packages('test', pydir):
                assert n == p.removeprefix(pydir).removesuffix(ext).replace(sep, '.')
                assert exists(p + ext)

# Generated at 2022-06-23 15:21:51.956767
# Unit test for function walk_packages
def test_walk_packages():
    assert next(walk_packages("pyslvs", "../pyslvs_ui/libs/pyslvs")) == (
        "pyslvs.ops.paths.path_storage",
        "../pyslvs_ui/libs/pyslvs/pyslvs/ops/paths/path_storage.py",
    )

# Generated at 2022-06-23 15:21:55.632483
# Unit test for function gen_api
def test_gen_api():
    gen_api(
        {"Pyslvs": "pyslvs", "VPoint": "pyslvs_ui.qt_ui"},
        pwd=dirname(dirname(__file__)),
        dry=True
    )

# Generated at 2022-06-23 15:22:06.093316
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import vge
    from pyslvs_ui import __version__
    from time import time as now
    d = now()
    docs = gen_api({'PythonSLVS': 'pyslvs_ui', 'VGE': 'vge'}, dry=True)
    print('-' * 12)
    print(f"API: {vge.__version__}, UI: {__version__}")
    print(f"Compile time: {now() - d} s")
    print(f"Documentation links:")
    for doc in docs:
        for line in doc.splitlines():
            if line.startswith('https://') or line.startswith('http://'):
                print(line)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:22:14.270416
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os import listdir
    from os.path import join, expanduser
    from shutil import which
    from pytest import raises


# Generated at 2022-06-23 15:22:23.580221
# Unit test for function gen_api
def test_gen_api():
    def update_dict(d: dict, k, v):
        d[k] = v

    def read_file(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    name = 'pyslvs'
    path = join('docs', 'source', f"{name}-api.md")
    assert isfile(path)
    doc = loader(name, _site_path(name), True, 3, False)
    assert doc
    assert doc.strip() != ''
    update_dict(globals(), 'doc', doc)
    assert read_file(path) == doc


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:22:29.339028
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from shutil import rmtree
    pwd = abspath('../pyslvs-core')
    sys_path.append(pwd)
    assert gen_api({"Pyslvs": "pyslvs"}, pwd)
    rmtree('docs')
    logger.info("Testing completed")
    sys_path.remove(pwd)

# Generated at 2022-06-23 15:22:31.225647
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"test": "test_package"}, prefix="test", dry=True)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:22:34.955498
# Unit test for function loader
def test_loader():
    "Unit test for function loader"
    pwd = dirname(__file__)
    gen_api({'pyslvs': 'pyslvs'}, pwd=pwd, dry=True)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:22:40.957244
# Unit test for function loader
def test_loader():
    """Test function."""
    import sys
    import site
    import pkgutil
    root = pkgutil.walk_packages([site.getsitepackages()[0]])
    root_names = {k.name: k.name for k in root}
    gen_api(root_names, prefix="docs")


if __name__ == '__main__':
    try:
        test_loader()
    except Exception as e:
        logger.exception(e)

# Generated at 2022-06-23 15:22:47.666881
# Unit test for function gen_api
def test_gen_api():
    logger.debug("Start test gen_api")
    def test_loader():
        logger.debug("Start test loader")
        doc = loader("pyslvs", "./pyslvs/", False, 2, False)
        assert doc.count("def") > 0
    test_loader()
    def test_gen_md():
        logger.debug("Start test gen_md")
        docs = gen_api({"API": "pyslvs"}, "./pyslvs/", dry=True)
        assert len(docs) == 1
    test_gen_md()
    logger.debug("Passed")

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:22:53.046966
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1)
    class TestLoader(Loader):
        def create_module(self, spec: object) -> None:
            pass

        def exec_module(self, module: object) -> None:
            module.__doc__ = f"*test* {module.__name__}"

    spec = ModuleSpec(name='test_loader', loader=TestLoader())
    m = module_from_spec(spec)
    spec.loader.exec_module(m)
    p.load_docstring('test_loader', m)
    assert p.compile() == "*test* test_loader\n"

# Generated at 2022-06-23 15:23:01.117021
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    import unittest
    import sys
    import pkgutil
    import tempfile

    class TestWalkPackages(unittest.TestCase):
        """Unit test for function walk_packages."""
        @classmethod
        def setUpClass(cls) -> None:
            """Create temp directory and files."""
            cls._dir = tempfile.TemporaryDirectory()
            cls._dir_path = cls._dir.name
            cls._cwd = os.getcwd()
            os.chdir(cls._dir_path)
            sys.path.append(cls._dir_path)
            cls._sub_dir_path = os.path.join(cls._dir_path, "sub")

# Generated at 2022-06-23 15:23:07.370172
# Unit test for function walk_packages
def test_walk_packages():
    """walk_packages test."""
    names = []
    for name, path in walk_packages("example", "example"):
        names.append(name)
        print(f"{name} <= {path}")
    assert names == ["example.__init__", "example.a", "example.b", "example.c"]


if __name__ == "__main__":
    from pathlib import Path

    test_walk_packages()
    print(gen_api({"example": "example"}, Path(__file__).parent, dry=True))

# Generated at 2022-06-23 15:23:08.760354
# Unit test for function gen_api
def test_gen_api():
    print(gen_api({"Pyslvs", "pyslvs"}))

# Generated at 2022-06-23 15:23:18.527717
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk package with import them."""
    from importlib.util import find_spec
    from .version_ import __version__
    root = parent(find_spec('pyslvs').submodule_search_locations[0])
    yield len, walk_packages('pyslvs', root), 22
    yield len, walk_packages('pyslvs_ui', root), 12
    yield str, next(walk_packages('pyslvs_ui', root))[0], 'pyslvs_ui'
    yield str, next(walk_packages('pyslvs', root))[0], 'pyslvs'
    yield str, next(walk_packages('pyslvs.__version__', root))[0], 'pyslvs.__version__'

# Generated at 2022-06-23 15:23:27.006448
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch
    from importlib import import_module
    from .logger import set_log_level
    set_log_level(0)
    for _, _, fs in walk('tests/modules'):
        for f in fs:
            if not f.endswith('.py'):
                continue
            logger.info(f"file: {f}")
            with patch.dict(sys_path, {"": "tests/modules"}):
                import_module(f.replace('.py', ''))

# Generated at 2022-06-23 15:23:29.344459
# Unit test for function walk_packages
def test_walk_packages():
    for i, t in enumerate(walk_packages('abc', '.')):
        print(f'{i}: {t}')

# Generated at 2022-06-23 15:23:41.535588
# Unit test for function loader
def test_loader():
    """Test case for function loader."""
    from unittest.mock import patch, call
    from os.path import join, dirname
    bound_pwd = dirname(__file__)
    file_path = join(bound_pwd, 'test.pyi')
    spec = spec_from_file_location('test', file_path)
    m = module_from_spec(spec)
    with patch.object(spec.loader, 'exec_module', return_value=m):
        p = Parser.new(True, 1, False)
        assert _load_module('test', file_path, p)
        assert p.root.nodes.keys().pop() == 'test'
        assert p.root.nodes.values().pop().type == 'module'
        assert p.root.nodes.values().pop

# Generated at 2022-06-23 15:23:47.115754
# Unit test for function gen_api
def test_gen_api():
    assert not gen_api({})
    assert len(gen_api({"Numpy": "numpy"}, ".")) == 1
    assert len(gen_api({"Numpy": "numpy"}, link=False, dry=True)) == 1
    assert len(gen_api({"Sklearn": "sklearn"}, ".")) == 1
    assert len(gen_api({"Scipy": "scipy"}, ".")) == 1
    assert len(gen_api({"Matplotlib": "matplotlib"}, ".")) == 1

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:23:55.978629
# Unit test for function loader
def test_loader():
    """Unit test for loader."""
    root = ['pyslvs', 'pyslvs_ui', 'pyslvs_ui.package']
    doc = loader(root, parent(parent(parent(__file__))), False, 1, False)
    print(doc)
    # Update the file
    with open(__file__) as f:
        text_doc = f.read().rstrip()
    if doc != text_doc:
        print(doc)
        print('=' * 12)
        print(text_doc)
        print('=' * 12)
        with open(__file__, 'w+') as f:
            f.write(doc)
    assert doc == text_doc, "Update the file for test"

# Generated at 2022-06-23 15:24:06.388194
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase
    from pyls_msgs.msg import ColorRGBA, Float64, Point
    from unittest.mock import MagicMock

    class mock_spec(MagicMock):

        loader: Loader = MagicMock()

    class mock_loader(MagicMock):

        def exec_module(self, _: object) -> None:
            """For unit test."""

    path = lambda *args: abspath(join(*args))

    def _walk(name: str, path: str) -> Iterator[tuple[str, str]]:
        return (a
                for a in walk_packages(name, path)
                if a[0] == "test_walk_packages.ColorRGBA")


# Generated at 2022-06-23 15:24:09.074545
# Unit test for function walk_packages
def test_walk_packages():
    logger.info("Test walk_packages ...")
    assert list(walk_packages("pyslvs", "../pyslvs/"))



# Generated at 2022-06-23 15:24:20.485677
# Unit test for function walk_packages

# Generated at 2022-06-23 15:24:27.744443
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('a', 'tests')) == [
        ('a.__init__', 'tests/a/__init__.py'),
        ('a.b', 'tests/a/b.pyi'),
        ('a.b.__init__', 'tests/a/b/__init__.py'),
        ('a.b.c', 'tests/a/b/c.py'),
        ('a.b.c.__init__', 'tests/a/b/c/__init__.py'),
    ]

# Generated at 2022-06-23 15:24:39.090804
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import unittest
    import tempfile
    import shutil
    import importlib
    import pyslvs
    from pkgutil import get_loader
    class LoaderPtest(unittest.TestCase):

        def setUp(self):
            self.dir_name = tempfile.mkdtemp()
            self.sample_name = 'sample'
            self.sample_path = join(self.dir_name, self.sample_name)
            self.sample_py = join(self.sample_path, self.sample_name + '.py')
            self.sample_pyi = join(self.sample_path, '__init__.pyi')
            self.sample_pyi_stubs = join(self.sample_path, '__init__-stubs.pyi')
           

# Generated at 2022-06-23 15:24:47.528502
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch, Mock
    from unittest import TestCase

    class Case(TestCase):
        def setUp(self):
            self.spec = Mock()
            self.spec.submodule_search_locations = ['/foo/package/']

        def test_walk(self):
            with patch('importlib.util.find_spec', return_value=self.spec):
                result = list(walk_packages('bar', '/foo/package/'))
            self.assertEqual(result, [('bar.a', '/foo/package/bar/a.pyi'), ('bar.b.c', '/foo/package/bar/b/c.pyi')])

# Generated at 2022-06-23 15:24:55.591538
# Unit test for function loader
def test_loader():
    import pyslvs
    from pyslvs import __version__ as version
    from pyslvs_ui.mainwindow import _

    assert loader("pyslvs", dirname(pyslvs.__file__), link=True, level=1, toc=False)

    s = _("API")
    assert gen_api({s: f"pyslvs=={version}"}, dry=True)

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:25:02.477413
# Unit test for function gen_api
def test_gen_api():
    from shutil import rmtree
    from pathlib import Path
    from pyslvs_ui.io import load_apis
    rmtree('docs', ignore_errors=True)
    gen_api({
        "Pyslvs": "pyslvs",
        "Pyslvs-ui": "pyslvs_ui",
    }, Path(__file__).parent.parent)
    assert load_apis()[0][0] == "Pyslvs"


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:25:05.629743
# Unit test for function gen_api
def test_gen_api():
    try:
        for i in gen_api({"Test": "pyslvs"}, dry=True):
            assert i is not None
    except ImportError:
        logger.warning('Tools import error.')

# Generated at 2022-06-23 15:25:15.659838
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import dirname
    from importlib.util import find_spec
    from pyslvs_ui.qt_patch import qApp
    from .settings import AppState, global_state
    global_state = AppState()
    qApp.setApplicationName("test")
    import pyslvs
    root_name = pyslvs.root()
    root_path = _site_path(root_name)
    assert root_name == global_state.app_name
    global_state.app_dir = dirname(dirname(dirname(find_spec(pyslvs).origin)))
    assert root_path == "", "This test must run in developer mode"
    assert root_path != ""
    assert root_path == global_state.app_dir

# Generated at 2022-06-23 15:25:16.905388
# Unit test for function gen_api
def test_gen_api():
    assert not gen_api({'test': 'test'})



# Generated at 2022-06-23 15:25:22.292828
# Unit test for function gen_api
def test_gen_api():
    name = "pyslvs_ui"
    pwd = _site_path(name)
    print(loader(name, pwd, True, 1, False))
    print(gen_api({
        "pyslvs_ui": name,
    }, pwd, dry=True))


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:25:30.855676
# Unit test for function gen_api
def test_gen_api():
    def test_dry():
        docs = gen_api({}, None, dry=True)
        assert docs[0] == ""

    def test_example_dry():
        docs = gen_api({"Model": "pyslvs_ui.model"}, None, dry=True)
        assert docs[0] == "# Model API\n"

    def test_example_output():
        docs = gen_api({"Model": "pyslvs_ui.model"}, None)
        assert docs[0] == "# Model API\n\n"

    test_dry()
    test_example_dry()
    test_example_output()

# Generated at 2022-06-23 15:25:32.133400
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    logger.info("Test: gen_api")
    assert '# API' in gen_api({'title': 'name'})[0]

# Generated at 2022-06-23 15:25:38.690582
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import approx
    from .styles import NoneType
    from .configs import pypi_api
    # Test case
    assert None not in walk_packages(*pypi_api)
    # Test value
    for name, path in walk_packages(*pypi_api):
        if name == 'PyPI':
            assert path == 'pypi_api/__init__.py'
        elif name == 'PyPI.__init__':
            assert path == 'pypi_api/__init__.py'
        else:
            assert name.startswith('PyPI.')
            assert path.startswith('pypi_api/')
    # Test None module
    assert NoneType is None

# Generated at 2022-06-23 15:25:50.156300
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    from tempfile import TemporaryDirectory, mkdtemp
    from shutil import rmtree
    from os import chdir, getcwd
    from sys import path as sys_path
    from .example_generator import gen_examples
    from .parser import Parser
    from .compiler import gen_api
    with TemporaryDirectory() as pwd:
        # Create temporary project
        chdir(pwd)
        logger.info(f"Temporary directory: {pwd}")
        pwd = getcwd()
        sys_path.append(pwd)
        gen_examples(pwd)
        logger.info(f"Project created: {gen_api.__name__}.py")
        # pylint: disable=unused-argument

# Generated at 2022-06-23 15:25:59.126798
# Unit test for function loader
def test_loader():
    from .helper import setup_api
    data = [
        '# Example API\n',
        '\n',
        '## Example\n',
        '\n',
        ".. automodule:: example\n",
        '    :noindex:\n',
        '\n',
        '## Example2\n',
        '\n',
        ".. automodule:: example2\n",
        '    :noindex:\n',
        '\n',
    ]
    assert setup_api(lambda x: x, 'example', 'example2') == ''.join(data)
    pass



# Generated at 2022-06-23 15:26:07.733239
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from unittest.mock import Mock
    from importlib import PathFinder
    from importlib.util import spec_from_file_location
    mock_site_pkgs = Mock()
    mock_site_pkgs.return_value = [
        Path('/home/usr/site-packages/aaa/__init__.pyi'),
        Path('/home/usr/site-packages/aaa/bbb.pyi')
    ]
    PathFinder.find_spec = mock_site_pkgs
    path = '../site-packages'
    root = 'aaa'
    name = 'aaa.bbb'
    assert spec_from_file_location(name, '../site-packages/aaa/bbb.pyi') is None

# Generated at 2022-06-23 15:26:13.875444
# Unit test for function gen_api
def test_gen_api():
    logger.info("Test gen_api function ...")
    root_names = {"PySLVS": "pyslvs"}
    try:
        path = gen_api(root_names, dry=True)
    except Exception as e:
        logger.error(f"Error! {e}")
        return False
    logger.info(f"Gen API result: \n{path}")
    return True

# Generated at 2022-06-23 15:26:19.845141
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    assert gen_api({'Foo': 'foo'}) == []
    assert gen_api({'Foo': 'foo'}, pwd=dirname(__file__), dry=True)
    print()
    assert gen_api({'Pyslvs': 'pyslvs'}, pwd=dirname(__file__), dry=True)

# Generated at 2022-06-23 15:26:24.412737
# Unit test for function loader
def test_loader():
    """Tests for the `loader` function."""
    import sys
    import pkgutil
    sys.path.append('tests')
    assert loader('test_pkg', '.', pkgutil, True, 1, False) != ''
    assert loader('test_pkg', '.', pkgutil, True, 2, True) != ''

# Generated at 2022-06-23 15:26:26.341284
# Unit test for function gen_api
def test_gen_api():
    # Just a test case, no error should be raised.
    assert not gen_api({'pyslvs': 'pyslvs'})

# Generated at 2022-06-23 15:26:33.206187
# Unit test for function loader
def test_loader():
    r = [
        "platform",
        "sys",
        "os",
        "pathlib",
        "importlib",
        "cmath",
        "time",
        "inspect",
        "collections.abc",
    ]
    s = loader(
        "pyslvs",
        dirname(dirname(dirname(dirname(dirname(dirname(dirname(abspath(__file__)))))))),
        True,
        2,
        False
    )
    for i in r:
        assert f"\n## {i} API\n" in s


# Generated at 2022-06-23 15:26:42.454647
# Unit test for function walk_packages

# Generated at 2022-06-23 15:26:51.286294
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    p = Parser.new()
    p.parse('pyslvs', '\n'.join([
        '"""Test.',
        '',
        '.. code-block:: python',
        '',
        '    >>> import pyslvs',
        '',
        '.. seealso::',
        '',
        '    .. autosummary::',
        '',
        '        int',
        '        str',
        '',
        '"""',
        '',
        'import math',
        '',
        '#: test',
        'int = 1',
        ''
    ]))

# Generated at 2022-06-23 15:26:55.739195
# Unit test for function loader
def test_loader():
    """Test for `loader` function."""
    from tests.test_imports import *
    from tests.test_compiler import *
    from tests.test_paths import *
    assert loader(__name__, dirname(__file__), False, 1, False)

# Generated at 2022-06-23 15:27:05.120566
# Unit test for function loader
def test_loader():
    """Test functions."""
    import json
    import os
    import pyslvs
    # Generate API doc with version
    doc = loader(
        "pyslvs",
        os.path.dirname(pyslvs.__file__),
        True,
        1,
        False
    ).split('\n')
    with open("pyslvs-api.temp", "w") as f:
        f.write('\n'.join(doc))
    with open("pyslvs-api.json") as f:
        json.load(f)
    with open("pyslvs-api.temp") as f:
        json.load(f)
    os.remove("pyslvs-api.temp")
    assert doc

# Generated at 2022-06-23 15:27:06.841450
# Unit test for function walk_packages
def test_walk_packages():
    """The prefix is automatically removed."""
    assert len(list(walk_packages("pyslvs", ".."))) > 0



# Generated at 2022-06-23 15:27:12.482603
# Unit test for function loader
def test_loader():
    """Simple test for loader."""
    from .compiler import loader
    from tempfile import TemporaryDirectory
    from pyslvs_ui.package import test_root_names

    with TemporaryDirectory() as tmpdir:
        loader(test_root_names[0], tmpdir, True, 1, True)

# Generated at 2022-06-23 15:27:13.538575
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'a': 'a_module'})


# Generated at 2022-06-23 15:27:20.485859
# Unit test for function gen_api
def test_gen_api():
    from os import remove
    name = 'test'
    root_names = {'Some Class': 'test'}
    prefix = 'docs'
    pwd = 'C:/Python37/Lib/site-packages'
    gen_api(root_names, pwd, prefix=prefix, dry=True)
    if isdir(prefix):
        for _, _, files in walk(prefix):
            for f in files:
                remove(join(prefix, f))
    else:
        logger.warning("prefix is not a directory!")

# Generated at 2022-06-23 15:27:28.152827
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({
        'basic': 'basic',
        'test': 'test',
    }, prefix='test_docs')[0].split('\n')[0] == '# basic API'
    assert gen_api({
        'basic': 'basic',
        'test': 'test',
    })[0].split('\n')[0] == '## basic API'
    assert gen_api({
        'basic': 'basic',
        'test': 'test',
    }, pwd='.')[0].split('\n')[0] == '## basic API'
    assert gen_api({
        'basic': 'basic',
        'test': 'test',
    }, pwd='.', prefix='test_docs3')[0].split('\n')[0] == '# basic API'
    assert gen_api

# Generated at 2022-06-23 15:27:32.125214
# Unit test for function loader
def test_loader():
    """Load pyslvs_ui API."""
    print(loader("pyslvs_ui", "../pyslvs_ui", True, 1, False))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:27:35.582523
# Unit test for function gen_api
def test_gen_api():
    r = gen_api({'pyslvs': 'pyslvs'}, pwd=dirname(__file__))
    assert len(r) == 1
    assert r[0].startswith('# pyslvs API')

# Generated at 2022-06-23 15:27:46.888402
# Unit test for function walk_packages
def test_walk_packages():
    from os import environ
    from os.path import join
    assert isinstance(list(walk_packages("numpy", environ['PYTHONPATH'])), list)
    assert isinstance(list(walk_packages("numpy", "."))[0], tuple)
    assert isinstance(list(walk_packages("numpy", "."))[0][0], str)
    assert isinstance(list(walk_packages("numpy", "."))[0][1], str)
    assert isinstance(list(walk_packages("numpy", ".")), list)
    assert isinstance(list(walk_packages("numpy", "./solver/numpy")), list)
    assert isinstance(list(walk_packages("numpy", "./solver/numpy/core")), list)

# Generated at 2022-06-23 15:27:52.830351
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api.
    It should not generate docs when the conditions are not met.
    """
    assert gen_api({}) == []
    # Raise error when pwd directory does not exist
    try:
        assert gen_api({'no_exist': 'no_exist'}, './no_exist') == []
    except FileNotFoundError:
        pass
    # Raise error when root_names is not a dict
    try:
        assert gen_api('no_exist') == []
    except AssertionError:
        pass
    # Raise error when docs directory does not exist
    try:
        assert gen_api({'name': 'name'}, pwd='./docs', prefix='./no_exist') == []
    except FileNotFoundError:
        pass

# Generated at 2022-06-23 15:27:59.399944
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory(prefix='pyslvs-') as d:
        (d / "md").mkdir()
        (d / "md" / "core.py").touch()
        (d / "md" / "core.pyi").touch()
        (d / "md" / "core.pyx").touch()
        (d / "md" / "__init__.py").touch()
        # Find
        assert tuple(walk_packages('md', d)) == (('md', str(d / 'md')),)
        assert tuple(walk_packages('md', d / 'md')) == (('md', str(d / 'md')),)
        (d / "md" / "core.py").unlink()
        (d / "md" / "core.pyi").un

# Generated at 2022-06-23 15:28:00.321985
# Unit test for function loader
def test_loader():
    assert '1-api.md' not in walk_packages('pkg', 'test')

# Generated at 2022-06-23 15:28:07.238661
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main
    from sys import path as sys_path

    class TestLoader(TestCase):

        def test_gen_api(self):
            logger.setLevel('CRITICAL')
            sys_path.append(dirname(__file__))
            with self.assertLogs(logger):
                for doc in gen_api({'pyslvs': 'pyslvs', 'Solvespace': 'solvespace'}, pwd=dirname(__file__), dry=True):
                    print(doc)

    main()

# Generated at 2022-06-23 15:28:11.067168
# Unit test for function gen_api
def test_gen_api():
    def test_pwd() -> str:
        return dirname(abspath(__file__)) + sep + '..' + sep + 'site-packages'

    test_root_names = {
        "Main": "pyslvs"
    }

    return gen_api(test_root_names, test_pwd(), dry=True)

# Generated at 2022-06-23 15:28:13.842954
# Unit test for function walk_packages
def test_walk_packages():
    assert all(isinstance(me, tuple) and len(me) == 2 for me in
               walk_packages('pyslvs', './tests/src'))
    assert all(me[0].startswith('pyslvs.') for me in
               walk_packages('pyslvs', './tests/src'))

# Generated at 2022-06-23 15:28:21.153595
# Unit test for function loader
def test_loader():
    """Unit test for function ``loader``."""
    from os.path import dirname, join
    from sys import path
    from .parser import Link
    path.append(dirname(__file__))
    logger.info("Importable test:")
    print(loader("pyslvs_test", ".", Link.LINKED, 1, True))
    logger.info("Loading module test:")
    print(loader("pyslvs_test2", ".", Link.LINKED, 1, True))

# Generated at 2022-06-23 15:28:25.693387
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    print(gen_api(
        {
            'Pyslvs Solver': 'pyslvs',
            'Pyslvs UI': 'pyslvs_ui',
        },
        dirname(__file__),
        dry=True
    ))


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:28:33.257396
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from pyslvs_ui.compiler.parser import DOUBLE_HASH_PATTERN
    from pyslvs.__about__ import __version__ as VERSION
    doc = loader(
        'pyslvs',
        _site_path('pyslvs'),
        True,
        2,
        True
    )
    assert doc.count('## Descriptor') == 3
    assert doc.count(VERSION) == 2
    assert doc.count("## Nodes") == 3
    assert doc.count("## VPoints") == 3
    assert doc.count("## Widgets") == 3
    assert doc.count(DOUBLE_HASH_PATTERN) == 95

# Generated at 2022-06-23 15:28:43.880968
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main as unittest_main
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from . import PYSLVS

    class LoaderTest(TestCase):
        """Test case for function loader."""

        def test_loader(self):
            """Test case for function loader."""
            # Generate __init__.py and test.py
            doc = '# This is the root module docstring.\n'
            init_py = 'print("This is the __init__.py")\n'

# Generated at 2022-06-23 15:28:51.850089
# Unit test for function loader
def test_loader():
    logger.setLevel('DEBUG')
    from os import chdir
    from os.path import dirname as this_dir
    from shutil import rmtree
    from hashlib import sha1
    from .parser import parent, get_hash_code
    chdir(this_dir(__file__))
    for path in ['docs', 'solve', 'solve-stubs']:
        if isdir(path):
            rmtree(path)
    mkdir('solve-stubs')
    _write('solve-stubs/__init__.pyi', '"""Docstring"""\n')

# Generated at 2022-06-23 15:28:59.302185
# Unit test for function loader
def test_loader():
    import tempfile
    # Write a test module
    def _write_file(name: str, text: str) -> str:
        path = join(tempfile.gettempdir(), f"{name}.py")
        logger.debug(f"Create file: {path}")
        _write(path, text)
        return path

    # Create a test module
    test_path1 = _write_file("test1", '"""A test\n"""\na = 1')
    test_path2 = _write_file("test2", '"""A test\n"""\nfrom test1 import a\ndef test(a):\n    "Test doc"\n    print(a)\n    return a')
    # Create a pseudo module for `test1`

# Generated at 2022-06-23 15:29:10.168181
# Unit test for function loader
def test_loader():
    """Unit test for function loader"""
    name = "load_module"
    path = join(dirname(__file__), 'test_module.py')

    content = """
    def __init__():
        pass
    """

    # Dependency test
    loader("tesss", dirname(__file__), False, 1, False)

    p = Parser.new(False, 1, False)
    _load_module(name, path, p)
    assert name in p.docs
    assert content == p.docs[name]['content']
    assert name == p.docs[name]['origin']
    path = join(dirname(__file__), 'test_module.pyi')
    p = Parser.new(False, 1, False)
    _load_module(name, path, p)
    assert name

# Generated at 2022-06-23 15:29:16.926759
# Unit test for function loader
def test_loader():
    logger.info("-" * 12)
    logger.info("Running testing with current package:")
    logger.info("-" * 12)
    # Write API of the current Pyslvs package
    api = gen_api(dict(pyslvs="pyslvs"), pwd='..', toc=True)
    logger.info("-" * 12)
    assert len(api) == 1
    logger.info("All tests passed.")


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:29:19.202678
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({'Qt': 'PyQt5.Qt'}, dry=True)
    assert len(docs) == 1

# Generated at 2022-06-23 15:29:24.344687
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from os.path import exists
    from shutil import rmtree

    def _gen(n, p):
        try:
            makedirs(n)
        except FileExistsError:
            pass
        _write(p, '')


# Generated at 2022-06-23 15:29:32.398583
# Unit test for function gen_api
def test_gen_api():
    from io import StringIO
    from sys import stdout
    from .logger import logger
    logger.set_level(0)
    logger.set_output(StringIO())
    prefix = 'docs'
    root_names = {"Dummy": "dummy"}
    docs = gen_api(root_names, prefix=prefix)
    assert isdir(prefix), "The path of output documentation is not exists."
    assert docs
    logger.set_output(stdout)
    logger.set_level(2)
    test_gen_api.__doc__ = "Unit test for function gen_api"

# Generated at 2022-06-23 15:29:43.680942
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import shutil
    from importlib import reload

    def _test_structure(title: str, success: bool):
        def _(self):
            with unittest.mock.patch('pyslvs.main.compile.logger.info') as f:
                package = 'pyslvs'
                parent_path = 'site-packages'
                __import__(package)
                modules = list(walk_packages(package, parent_path))
                self.assertEqual(len(modules) > 0, success)
                reload(package)
                p = f.mock_calls[0][1][0]
                p = p[p.find(':') + 1:p.find('(')].strip()
                self.assertEqual(p, parent_path)