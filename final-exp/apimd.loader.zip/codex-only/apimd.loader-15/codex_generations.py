

# Generated at 2022-06-23 15:19:43.201844
# Unit test for function gen_api
def test_gen_api():
    """Unit test for gen_api."""
    gen_api(
        {
            "pyslvs": "pyslvs"
        },
        "src/pyslvs_ui/build/lib.win32-3.7",
        prefix="docs/yuan_chang_04052797_assignment_2",
        dry=True
    )

# Generated at 2022-06-23 15:19:48.344830
# Unit test for function gen_api
def test_gen_api():
    """Test case."""
    from .parser import Parser
    from .api_creator import API, APIDoc
    from .api_creator import _get_apis
    from .api_creator import _flat_apidocs
    from .api_creator import _flat_classes
    from .api_creator import _flat_functions
    from .api_creator import _flat_parameters
    from .api_creator import _flat_decorators
    from .api_creator import _APIInfo
    from .api_creator import _construct_apidoc
    from .api_creator import _build_toc
    from .api_creator import _add_meta_data
    from .api_creator import _build_api_content
    from .api_creator import _build_api_toc
    from .api_creator import _build_api_

# Generated at 2022-06-23 15:19:59.204319
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    # Create a temp directory
    with tempfile.TemporaryDirectory() as tempdirname:
        import os
        import shutil
        # Copy the test data to temp directory
        shutil.copy('test_data/test_doc.py', tempdirname)
        shutil.copy('test_data/test_doc2.py', tempdirname)
        # Call the function with test data directory
        gen_api({'Test data': 'test_doc'}, tempdirname, prefix='test', dry=True)
        assert os.path.isdir('test')
        assert os.path.isfile('test/test-api.md')
        assert os.path.isfile('test/test-doc2-api.md')
        shutil.rmtree('test')

# Generated at 2022-06-23 15:20:08.439536
# Unit test for function gen_api
def test_gen_api():
    import os
    import tempfile
    for n in [f for f in os.listdir()
              if f.startswith('_') and f.endswith('.py')]:
        logger.warning(f'Do not run unit test in the main script!')
        break
    else:
        import unittest
        from pkg_resources import resource_listdir, resource_filename

        class TestGenApi(unittest.TestCase):
            """Check the compiler output."""

            def check_api(self, name: str, level: int) -> None:
                """Check API compiler."""
                with tempfile.TemporaryDirectory() as tmp_dir:
                    pwd = resource_filename('tests', 'data')

# Generated at 2022-06-23 15:20:12.119399
# Unit test for function gen_api
def test_gen_api():
    from pyslvs_ui.compiler import gen_api
    for i in gen_api({"Test Pyslvs": "pyslvs_ui"}, "./src/docs"):
        print(i)


__all__ = ['gen_api']

# Generated at 2022-06-23 15:20:15.567888
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import pyslvs
    assert gen_api({'PySLVS': 'pyslvs'}, pwd=dirname(pyslvs.__file__))[0].strip()

# Generated at 2022-06-23 15:20:17.580068
# Unit test for function walk_packages
def test_walk_packages():
    assert not list(walk_packages('msvcrt', 'D:/'))
    assert not list(walk_packages('svgwrite', 'D:/'))



# Generated at 2022-06-23 15:20:21.692899
# Unit test for function loader
def test_loader():
    """Loader unit test."""
    print(loader(
        "pyslvs",
        abspath(dirname(__file__)),
        link=False,
        level=2,
        toc=True
    ))


# Generated at 2022-06-23 15:20:24.137342
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("test_walk_packages", "."):
        assert name == "test_walk_packages"
        logger.debug(name, path)

# Generated at 2022-06-23 15:20:31.064995
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .pkgs import _write_pkgs

    root_names = {
        'Pyslvs': 'pyslvs_ui',
        'PySlvs-Core': 'pyslvs',
        'PySlvs-Structure': 'pyslvs_structure',
    }
    pwd = mkdtemp()
    _write_pkgs(pwd, root_names)
    gen_api(root_names, pwd=pwd, dry=True)
    rmtree(pwd)

# Generated at 2022-06-23 15:20:32.976474
# Unit test for function loader
def test_loader():
    print(loader(
        'pyslvs',
        '..',
        True,
        2,
        False
    ))

# Generated at 2022-06-23 15:20:44.955814
# Unit test for function walk_packages
def test_walk_packages():
    from importlib.util import spec_from_loader, module_from_spec
    from os.path import sep
    from types import ModuleType
    from .logger import logger
    from .module import __name__ as root

    def _make_module(name: str) -> ModuleType:
        s = spec_from_loader(name, None)
        return module_from_spec(s)


# Generated at 2022-06-23 15:20:45.969994
# Unit test for function loader
def test_loader():
    assert loader("pyslvs", ".", False, 1, False)

# Generated at 2022-06-23 15:20:49.237058
# Unit test for function gen_api
def test_gen_api():
    root_names = {"Pyslvs": "pyslvs"}
    pwd = './'
    assert gen_api(root_names, pwd)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:20:58.107171
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from unittest import TestCase, main
    from pkgutil import extend_path
    from tempfile import mkdtemp
    from shutil import rmtree

    class TestWalkPackage(TestCase):
        """Test case for walk_packages."""

        def setUp(self):
            """Test set up."""
            self.pwd = mkdtemp()

        def tearDown(self):
            """Test tear down."""
            rmtree(self.pwd)

        def test_walk(self):
            """Test walk_packages."""
            self.assertEqual(list(walk_packages('test', self.pwd)), [])
            path = abspath(self.pwd) + sep

# Generated at 2022-06-23 15:21:00.126083
# Unit test for function gen_api
def test_gen_api():
    gen_api({'test': 'pyslvs_ui'})

# test_gen_api()

# Generated at 2022-06-23 15:21:10.953848
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase
    from unittest.mock import patch, MagicMock
    walk = MagicMock()

# Generated at 2022-06-23 15:21:21.235531
# Unit test for function walk_packages
def test_walk_packages():
    import shutil
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp:
        test_site = join(tmp, 'site-packages')
        shutil.copytree(dirname(__file__), join(test_site, 'pyslvs_ui'))
        result = [*walk_packages('pyslvs_ui', test_site)]
    assert len(result) == 8
    assert result[-1] == ('pyslvs_ui.compiler.test_walk_packages',
                          join(test_site, 'pyslvs_ui', 'compiler',
                               'test_walk_packages'))

# Generated at 2022-06-23 15:21:28.093783
# Unit test for function gen_api
def test_gen_api():
    """Tests for function gen_api."""
    import unittest
    from sys import platform
    root_names = {
        'pyslvs': 'pyslvs_ui',
        'pyslvs-ui': 'pyslvs_ui',
        'pyslvs-vplot': 'pyslvs_vplot',
    }
    pwd = dirname(dirname(abspath(__file__)))
    path = dirname(pwd) + '/docs/api'
    docs = gen_api(root_names, pwd, prefix=path)
    p = Parser.new(True, 1, False)
    # The number of modules in pyslvs-ui and pyslvs-vplot
    if platform in ('linux', 'darwin'):
        number = 29
    el

# Generated at 2022-06-23 15:21:38.257602
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def test(root, expect):
        with TemporaryDirectory() as dirname:
            for path in expect:
                path = Path(path)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.touch()
            assert sorted(walk_packages(root, dirname)) == sorted(expect)


# Generated at 2022-06-23 15:21:40.693314
# Unit test for function loader
def test_loader():
    """Function loader test."""
    print(loader("pyslvs", dirname(__file__) + sep, False, 1, False))

# Generated at 2022-06-23 15:21:42.606979
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('test', '.')) == [('test.test_module', './test/test_module.pyi')]

# Generated at 2022-06-23 15:21:44.908319
# Unit test for function gen_api
def test_gen_api():
    print(gen_api({"Pyslvs": "pyslvs"}))

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:21:56.353611
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory() as dir_path:
        mkdir(dir_path)
        path1 = join(dir_path, 'pkg')
        mkdir(path1)
        _write(join(path1, '__init__.py'), '')
        _write(join(path1, 'mod1.py'), '')
        path2 = join(path1, 'pkg2')
        mkdir(path2)
        _write(join(path2, '__init__.py'), '')
        _write(join(path2, 'mod2.py'), '')

# Generated at 2022-06-23 15:22:00.083964
# Unit test for function walk_packages
def test_walk_packages():
    import pkgutil
    assert walk_packages('pyslvs', _site_path('pyslvs')) == tuple(
        pkgutil.walk_packages('pyslvs')
    )

# Generated at 2022-06-23 15:22:06.423289
# Unit test for function gen_api
def test_gen_api():
    test_root_names = {
        "pyslvs": "pyslvs",
        "pyslvs-ui": "pyslvs_ui"
    }
    r = gen_api(test_root_names, dry=True)
    assert len(r) == 2
    assert r[0].split('\n')[0] == '# pyslvs API'
    assert r[1].split('\n')[0] == '# pyslvs-ui API'

# Generated at 2022-06-23 15:22:17.571293
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk package."""
    def check(names: list[str], path: str) -> None:
        """Check if the result of walking packages is correct."""
        assert sorted(names) == sorted(i[0] for i in walk_packages('a', path))

    check(['a', 'a.b'], 'a')
    check(['a', 'a.b'], 'a/b')
    check(['a', 'a.b'], 'a\\b')
    check(['a', 'a.b'], 'b/a')
    check(['a', 'a.b'], 'b\\a')
    check(['a', 'a.b'], 'b/a/c')
    check(['a', 'a.b'], 'b\\a\\c')

# Generated at 2022-06-23 15:22:23.991294
# Unit test for function gen_api
def test_gen_api():
    def _test_api_doc(path: str) -> bool:
        with open(path.strip(), 'r') as f:
            return f.read().startswith('## pyslvs API')
    root_names = {
        'pyslvs': 'pyslvs',
        'pyslvs-ui': 'pyslvs_ui',
    }
    assert all([_test_api_doc(x) for x in gen_api(
        root_names,
        pwd='.',
        dry=True,
    )]
    )

# Generated at 2022-06-23 15:22:32.755882
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    temp = tempfile.mkdtemp()
    pkg = join(temp, 'test')
    mkdir(pkg)
    with open(join(pkg, '__init__.py'), 'w+'):
        pass
    with open(join(pkg, 'm1.py'), 'w+'):
        pass
    with open(join(pkg, 'm2.pyi'), 'w+'):
        pass
    with open(join(pkg, 'm3.py'), 'w+'):
        pass
    with open(join(pkg, 'sub', '__init__.py'), 'w+'):
        pass
    with open(join(pkg, 'sub', 'm1.py'), 'w+'):
        pass

# Generated at 2022-06-23 15:22:37.314783
# Unit test for function walk_packages
def test_walk_packages():
    """Test the function walk_packages."""
    from pyslvs import __path__ as pyslvs_path
    for name, path in walk_packages('pyslvs', pyslvs_path[-1]):
        print(name, path)


if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-23 15:22:41.244453
# Unit test for function loader
def test_loader():
    """Test."""
    from pathlib import Path
    from .logger import set_logger
    set_logger()
    pwd = str(Path(__file__).parent.joinpath('../../build/lib'))
    _ = loader('pyslvs', pwd, True, 1, True)

# Generated at 2022-06-23 15:22:44.401851
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({
        'pyslvs': 'pyslvs'
    })
    assert gen_api({
        'pyslvs': 'pyslvs',
        'pyslvs_ui': 'pyslvs_ui'
    })

# Generated at 2022-06-23 15:22:48.878734
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api()."""
    from .pyslvs_ui.utils import get_default_package_path
    logger.setLevel(10)
    gen_api({ "pyslvs": "pyslvs_ui" }, get_default_package_path())

# Generated at 2022-06-23 15:22:52.880122
# Unit test for function walk_packages
def test_walk_packages():
    from pyslvs_ui.package import walk_packages
    for n, p in walk_packages('pyslvs-ui', dirname(__file__)):
        print(n, p)


if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-23 15:23:01.086903
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    from .logger import logger
    from .parser import Parser

    def fake(name: str, path: str, p: Parser) -> bool:
        """Faking functions."""
        if name == 'imp':
            return False
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.load_spec(name, f"{path_ext!r}")
            return True
        return False

    logger.setLevel('DEBUG')
    assert loader('abc', 'abc', True, 1, False) == ""
    assert loader('abc', 'abc', True, 1, False, True) == ""

# Generated at 2022-06-23 15:23:03.149602
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({'Solver': 'solver'})
    assert docs[0].startswith('# Solver API\n\n')

# Generated at 2022-06-23 15:23:05.415530
# Unit test for function gen_api
def test_gen_api():
    """Test for the function gen_api."""
    gen_api({"Title": "module"}, "", dry=True)

# Generated at 2022-06-23 15:23:13.775001
# Unit test for function gen_api
def test_gen_api():
    import io
    import sys
    from pyslvs import __version__
    from logging import getLogger, StreamHandler, DEBUG
    from .logger import setup_logger
    log = getLogger("gen_api")
    log.setLevel(DEBUG)
    log.addHandler(StreamHandler(sys.stderr))
    setup_logger("", "", "", "", "", "")
    pyslvs_docs = gen_api({"PySLVS": "pyslvs"}, dry=True)
    assert isinstance(pyslvs_docs, list)
    assert len(pyslvs_docs) == 1
    assert "pyslvs-"+__version__ in pyslvs_docs[0]
    doc = io.StringIO()
    sys.stdout = doc
    gen_api

# Generated at 2022-06-23 15:23:24.044482
# Unit test for function walk_packages
def test_walk_packages():
    from .parser import parent
    from .compiler import walk_packages
    assert tuple(walk_packages('docs.compiler', __file__.replace('__init__.py', ''))) == (
        ('docs.compiler', __file__.replace('__init__.py', 'compiler_test.pyi')),
        ('docs.compiler', __file__.replace('__init__.py', 'compiler.py'))
    )

# Generated at 2022-06-23 15:23:27.252410
# Unit test for function loader
def test_loader():
    from pytest import raises
    from .tests.test_api.test_api import loader as l
    logger.info(l())
    with raises(ModuleNotFoundError):
        l('unknown')

# Generated at 2022-06-23 15:23:39.134096
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api"""
    # pylint: disable=C0103,R0201
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import copy, copytree

    def make_pkg(pkg, file_template, data):
        """Make package."""
        with TemporaryDirectory(prefix="pyslvs_temp") as tempdir:
            copytree(Path(__file__).parent.parent / "PySlvs", join(tempdir, pkg))
            for name, val in data.items():
                path = join(tempdir, pkg, name)
                copy(Path(__file__).parent.parent / pkg / file_template, path)
                with open(path, 'r+') as f:
                    text = f.read()
                    f.seek(0)

# Generated at 2022-06-23 15:23:42.520554
# Unit test for function loader
def test_loader():
    print(loader("pyslvs", "..", False, 1, False))
    # print(loader("pyslvs_ui", "..", False, 1, False))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:23:52.864496
# Unit test for function walk_packages
def test_walk_packages():
    import shutil
    import unittest

    def _write_stub(r: str, n: str, d: str) -> None:
        _write(join(r, n + PEP561_SUFFIX + '.pyi'), d.strip())

    def _write_source(r: str, n: str, d: str) -> None:
        _write(join(r, n + '.py'), d.strip())

    class TestWalkPackages(unittest.TestCase):

        @staticmethod
        def _create_dir(d: str) -> None:
            if isdir(d):
                shutil.rmtree(d)
            mkdir(d)

        def setUp(self) -> None:
            self._create_dir('test')


# Generated at 2022-06-23 15:24:00.324554
# Unit test for function loader
def test_loader():
    """Test function loader."""
    doc = loader(
        "pyslvs",
        ".",
        True,
        1,
        False
    )
    assert doc.startswith("# Pyslvs API\n")
    assert ":class:`~pyslvs.graph.Graph`" in doc
    assert ":meth:`~pyslvs.graph.Graph.basic_data`" in doc
    assert ":meth:`~pyslvs.graph.Graph.draw`" in doc

# Generated at 2022-06-23 15:24:10.931264
# Unit test for function walk_packages

# Generated at 2022-06-23 15:24:15.416692
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert '#' in loader('pyslvs', '.', True, 1, True)
    assert '#' in loader('pyslvs_ui', '.', True, 2, False)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:24:18.307062
# Unit test for function walk_packages
def test_walk_packages():
    for i in walk_packages('asyncio', 'C:\\Python38\\lib'):
        print(i)

# Generated at 2022-06-23 15:24:22.134342
# Unit test for function loader
def test_loader():
    """Compile unit test code."""
    test_dir = dirname(__file__)
    logger.setLevel('debug')
    assert loader('test_loader', test_dir, link=True, level=1, toc=False)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:24:33.494496
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    import sys
    with TemporaryDirectory() as tmp:
        sys_path.append(tmp)
        mkdir(join(tmp, 'test'))
        with open(join(tmp, 'test', 'test.py'), 'w+') as f:
            f.write('def foo() -> str:\n    return "bar"\n')
        with open(join(tmp, 'test', 'test.pyi'), 'w+') as f:
            f.write('def foo() -> str:\n    ...\n')

        assert next(walk_packages('test', tmp)) == ('test.test', join(tmp, 'test\\test.py'))


if __name__ == '__main__':
    from sys import stdout

    def main() -> None:
        """Help document."""
        print

# Generated at 2022-06-23 15:24:38.142045
# Unit test for function walk_packages
def test_walk_packages():
    def _test_package(n: str, p: str):
        for n_ in walk_packages(n, p):
            print(n_)

    _test_package("test", "tests/files")
    _test_package("test", "tests/files/test")



# Generated at 2022-06-23 15:24:48.131085
# Unit test for function gen_api
def test_gen_api():
    """Generate API."""
    import random, time
    random.seed(time.time())
    test_dir = f"test_dir_{random.randint(0, 100)}"
    test_file = f"test_{random.randint(0, 100)}.py"
    test_api_file = f"test-api.md"

# Generated at 2022-06-23 15:24:56.721803
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('__main__', '.')) == [
        ('__main__', './__main__.py')
    ]
    assert list(walk_packages('test', '.')) == [
        ('test.__main__', './test/__main__.py'),
        ('test.func', './test/func.py'),
        ('test.func', './test/func.pyi')
    ]

# Generated at 2022-06-23 15:24:58.706978
# Unit test for function gen_api
def test_gen_api():
    print(gen_api({'Test module': 'tests.test_module'}, pwd='tests', dry=True))

# Generated at 2022-06-23 15:25:04.421005
# Unit test for function loader
def test_loader():
    """Unit test for function loader"""
    assert loader('math', dirname(dirname(__file__)), True, 1, True).strip()
    assert loader('numpy', dirname(dirname(__file__)), True, 1, True).strip()
    assert loader('sympy', dirname(dirname(__file__)), True, 1, True).strip()

# Generated at 2022-06-23 15:25:14.325081
# Unit test for function loader
def test_loader():
    """Test loading packages."""
    doc = loader('pyslvs', 'pyslvs', link=True, level=1, toc=True)

# Generated at 2022-06-23 15:25:24.151129
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove

# Generated at 2022-06-23 15:25:26.635299
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import tempfile
    import pkgutil
    import shutil


# Generated at 2022-06-23 15:25:32.410625
# Unit test for function loader
def test_loader():
    pwd, name = 'packages', 'pyslvs'
    p = Parser.new(True, 1, False)
    for root_name, path in walk_packages(name, pwd):
        try:
            p.parse(root_name, _read(path + '.py'))
        except FileNotFoundError:
            continue
    p.compile()

# Generated at 2022-06-23 15:25:39.381530
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import pathlib
    sys_path.append(pathlib.Path(__file__).parent)
    t = list(walk_packages("bpy", pathlib.Path(__file__).parent))
    print(t)
    assert len(t) != 0
    t = list(walk_packages("pyslvs", pathlib.Path(__file__).parent))
    print(t)
    assert len(t) != 0

if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-23 15:25:50.536221
# Unit test for function loader
def test_loader():
    import pytest
    from .parser import Parser
    from .docstring import Docstring

    docs = loader(
        'numpy',
        'tests/test-apis/numpy',
        link=False,
        level=1,
        toc=True
    )
    p = Parser(link=False, level=1, toc=True)
    p.parse('numpy', docs)
    assert p.api_docs['numpy'].name == 'numpy'
    assert p.api_docs['numpy'].summary == 'NumPy API docs.'
    assert p.api_docs['numpy'].brief == 'NumPy API docs.\n'
    assert p.api_docs['numpy'].root == 'numpy'

# Generated at 2022-06-23 15:25:57.422221
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({
        "SparSE 2D": "sparse.pyslvs",
        "SparSE 3D": "sparse.pyslvs_3d",
    }, pwd=dirname(__file__), dry=True)
    assert len(docs) > 0

if __name__ == "__main__":
    # run module doctest
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:25:59.913183
# Unit test for function gen_api
def test_gen_api():
    """Test function."""
    gen_api({'Test': 'test'}, ".", toc=True)


# Generated at 2022-06-23 15:26:05.680073
# Unit test for function gen_api
def test_gen_api():
    doc = gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
        'Pyslvs-UI (lite)': 'pyslvs_ui_lite',
    }, '/home/unknown/site-packages', link=False, level=3, dry=True)
    assert doc[0].startswith("#")
    assert doc[0].strip().endswith("API")

# Generated at 2022-06-23 15:26:16.319494
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import pathlib
    from itertools import islice

    class TestWalkPackages(unittest.TestCase):
        """Unit test for function walk_packages."""
        def test_walk(self):
            """Test walk packages."""
            l = list(walk_packages("test_package", "pytest_test"))
            self.assertTupleEqual(l[0], ("test_package.__init__",
                                         "pytest_test/test_package/__init__.py"))
            self.assertTupleEqual(l[-1], ("test_package.test_module",
                                          "pytest_test/test_package/test_module.py"))

# Generated at 2022-06-23 15:26:26.824588
# Unit test for function loader
def test_loader():
    from os import mkdir, remove, walk
    from os.path import isfile, join
    from .parser import Parser
    from .parser import parent, parent_parent
    path = join(parent_parent(__file__), 'tests', 'tmp')
    if isfile(path):
        remove(path)
    elif not isfile(path):
        mkdir(path)
    path_1 = join(path, 'test_dir', '__init__.py')
    path_2 = join(path, 'test_dir_stubs', '__init__.pyi')
    path_3 = join(path, 'test_dir', 'test_file.py')
    path_4 = join(path, 'test_dir_stubs', 'test_file.pyi')

# Generated at 2022-06-23 15:26:30.975216
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({
        "Pyslvs": "pyslvs",
    }, pwd=dirname(__file__), dry=True)
    assert gen_api({
        "Pyslvs": "pyslvs",
        "Numpy": "numpy",
    }, pwd=dirname(__file__), dry=True)

# Generated at 2022-06-23 15:26:38.031389
# Unit test for function walk_packages
def test_walk_packages():
    """Test the `walk_packages` function."""
    from tempfile import TemporaryDirectory
    from random import choice, random
    from string import ascii_letters


# Generated at 2022-06-23 15:26:47.100379
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from os import environ, chdir, getcwd
    from distutils.sysconfig import get_python_lib
    import os.path

    environ['PYTHONPATH'] = os.pathsep + os.path.abspath('tests')
    chdir('/tmp')
    docs = gen_api(root_names={'Test': 'test'}, pwd=get_python_lib())
    print('=' * 12)
    print(docs[0])
    print('=' * 12)
    assert docs
    chdir(getcwd())
    environ['PYTHONPATH'] = ""


# Simple and stupid compiler

# Generated at 2022-06-23 15:26:55.412488
# Unit test for function loader
def test_loader():
    from . import dirs
    loader('pyslvs', dirs.pkg_dir, False, 1, False)
    loader('pyslvs_ui', dirs.pkg_dir, False, 1, True)
    loader('pyslvs', dirs.pkg_dir, True, 1, False)
    loader('pyslvs_ui', dirs.pkg_dir, True, 1, True)
    loader('pyslvs', dirs.pkg_dir, False, 2, False)
    loader('pyslvs_ui', dirs.pkg_dir, False, 2, True)
    loader('pyslvs', dirs.pkg_dir, True, 2, False)
    loader('pyslvs_ui', dirs.pkg_dir, True, 2, True)

# Generated at 2022-06-23 15:27:02.441930
# Unit test for function gen_api
def test_gen_api():
    from os.path import join, dirname, abspath
    from os import getcwd
    name = 'pyslvs'
    title = 'Pyslvs'
    path = dirname(abspath(__file__))
    src_path = dirname(path)
    docs_path = join(path, '..', '..', 'docs')
    f = join(docs_path, f'{name}-api.md')
    if isfile(f):
        from os import remove
        logger.warning(f"Remove {f} for unit test")
        remove(f)
    gen_api({title: name}, dirname(src_path))
    with open(f, 'r') as f:
        assert f.read()
    logger.warning(f"Clean {f} for unit test")
    assert remove

# Generated at 2022-06-23 15:27:10.393297
# Unit test for function gen_api
def test_gen_api():
    import os
    import sys
    from pyslvs import gen_api
    from pyslvs_ext.compiler import gen_api as orig
    import logging as log
    log.basicConfig(level=log.DEBUG)
    cwd = os.getcwd()
    orig_path = sys.path.copy()
    sys.path.append('')
    doc_dir = os.path.dirname(os.path.abspath(__file__))
    gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs-ext': 'pyslvs_ext',
    }, doc_dir, prefix=os.path.join(doc_dir, '..', 'docs'), dry=True)
    sys.path = orig_path
    os.chdir(cwd)

# Generated at 2022-06-23 15:27:13.256084
# Unit test for function gen_api
def test_gen_api():
    """Test generate API."""
    _ = gen_api({'hello': 'hello'}, dry=True)
    assert _ == ['# Hello API']

# Generated at 2022-06-23 15:27:21.317336
# Unit test for function loader
def test_loader():
    """Test loader."""
    import unittest
    import doctest
    root_path = dirname(__file__)
    pwd = join(root_path, 'tests', 'site_packages')
    sys_path.append(pwd)
    class TestLoader(unittest.TestCase):
        """Test loader."""

        def test_loader(self):
            """Test function loader."""
            docs = loader('data', pwd, False, 1, False)
            doctest.testmod(verbose=False)
            self.assertTrue(docs.strip())
            logger.debug(docs)

    unittest.main()

# Generated at 2022-06-23 15:27:23.075681
# Unit test for function loader
def test_loader():
    """Unit test of function loader."""
    assert loader('pyslvs', '.', True, 2, True)


# Generated at 2022-06-23 15:27:28.177298
# Unit test for function loader
def test_loader():
    logger.info('=' * 12)
    from os.path import dirname
    from .utils import import_module

    def gen_lib(root_name: str, path: str) -> None:
        os.mkdir(join(path, root_name))
        os.mkdir(join(path, root_name, 'sub'))
        os.mkdir(join(path, root_name, 'sub2'))
        os.mkdir(join(path, root_name, 'sub3'))
        _write(join(path, root_name, 'sub', 'test.py'), '"""test\n"""\ndef test(): ...')
        _write(join(path, root_name, 'sub2', 'test2.py'), '"""test2\n"""\ndef test(): ...')

# Generated at 2022-06-23 15:27:38.025480
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from unittest import TestCase, main
    from importlib import import_module

    class TestLoader(TestCase):
        """Test for function loader."""

        def test_loader(self):
            """Test for function loader."""
            text = loader("project", "tests", True, link=False, level=1, toc=False)
            self.assertTrue(text)
            text = loader("project", "tests", False, link=False, level=1, toc=False)
            self.assertTrue(text)

    class TestGenApi(TestCase):
        """Test for function gen_api."""

        def test_gen_api(self):
            """Test for function gen_api."""
            gen_api({'Project': 'project'}, 'tests', dry=True)

# Generated at 2022-06-23 15:27:48.801637
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import sys
    import pkgutil
    here = dirname(__file__)

    class LoaderTest(unittest.TestCase):
        def test_walk_packages(self):
            self.assertSequenceEqual(
                tuple(walk_packages('', 'package')),
                (
                    ('package.test', 'package/test'),
                    ('package.test.test_compiler', 'package/test/test_compiler')
                )
            )

# Generated at 2022-06-23 15:27:50.936061
# Unit test for function gen_api
def test_gen_api():
    """Make sure that it can create files."""
    assert gen_api({"title": "sys"})
    assert gen_api({"title": "solve"}, pwd=".", dry=True)

# Generated at 2022-06-23 15:28:02.959963
# Unit test for function loader
def test_loader():
    p = Parser.new()
    for name, path in walk_packages("math", "libs"):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module here
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
           

# Generated at 2022-06-23 15:28:09.991542
# Unit test for function gen_api
def test_gen_api():
    from platform import system
    if system() != 'Windows':
        name = 'networkx'
        root_names = {name: name}
        assert len(gen_api(root_names=root_names, dry=True)) == 1
    else:
        path = r'C:\ProgramData\Anaconda3\envs\py36\Lib\site-packages'
        root_names = {'SimPy': 'simpy', 'NetworkX': 'networkx'}
        assert len(gen_api(root_names=root_names, pwd=path, dry=True)) == 2

# Generated at 2022-06-23 15:28:15.153019
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs.data import default_doc
    import pyslvs
    logger.setLevel(0)
    doc = ''.join(gen_api(
        root_names={"PySLVS": "pyslvs"},
        pwd=pyslvs.__path__[0],
        link=False,
        level=1,
        toc=True,
        dry=True
    ))
    return doc.strip() == default_doc.strip()

# Generated at 2022-06-23 15:28:18.296985
# Unit test for function gen_api
def test_gen_api():
    """Unit test for gen_api()."""
    assert gen_api({"test": "test_gen_api"}) == ["""\
# test API

## test_gen_api
"""]

# Generated at 2022-06-23 15:28:22.852631
# Unit test for function loader
def test_loader():
    """Test for `loader` function."""
    from .path import src_path
    sys_path.append(src_path)
    root_name = 'pyslvs_ui'
    doc = loader(root_name, src_path, False, 1, False)
    print(doc)



# Generated at 2022-06-23 15:28:32.395329
# Unit test for function loader
def test_loader():
    """Test module loader."""
    print(loader("pyslvs", abspath("."), False, 3, False))
    # pyslvs
    # |-- __init__.py
    # |-- exporter
    # |   |-- __init__.py
    # |   |-- abaqus_exporter.pyi
    # |-- parser
    # |   |-- __init__.py
    # |   |-- common.pyi
    # |   |-- specification.pyi
    # |-- ui
    #     |-- __init__.py
    #     |-- parametric_analysis
    #     |   |-- __init__.py
    #     |   |-- constraints.pyi
    #     |   |-- dialog.pyi
    #     |   |-- linkages.pyi
    #     |   |-- optimizer.pyi
    #

# Generated at 2022-06-23 15:28:43.064394
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api.

    This function will create a temporary directory "test" for testing.
    """
    import shutil
    from os import getcwd
    from pathlib import Path
    from tempfile import mkdtemp
    from .parser import Parser
    from .pyslvs import __path__ as pyslvs_path

    cwd = getcwd()
    tmpdir = mkdtemp()

# Generated at 2022-06-23 15:28:48.331820
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    name, path = 'pyslvs_ui.info', '/usr/lib/python3.8/site-packages/pyslvs_ui/info.py'
    assert _load_module('pyslvs_ui.info', path, p) is True
    assert 'pyslvs_ui.info' in p.docs
    assert 'Project description' in p.docs['pyslvs_ui.info']

# Generated at 2022-06-23 15:28:56.343246
# Unit test for function loader
def test_loader():
    """Test case."""
    from importlib import reload
    import sys
    from os.path import dirname, join

    sys.path.append(dirname(dirname(dirname(__file__))))
    s = dirname(__file__)
    for _ in 'pyslvs', 'vge', 'solvespace':
        s = join(s, '..')
        sys.path.append(s)
    del _
    reload(sys)

    def check(p):
        assert "Python API" in p
        assert "PyQt5" in p
        assert "docs/solvers.md" in p
        assert "Pyhon API" not in p

    p = loader("pyslvs", s, True, 1, False)
    check(p)

# Generated at 2022-06-23 15:29:07.571311
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from os.path import relpath
    with TemporaryDirectory() as t:
        mkdir(join(t, 'a', 'b'))
        mkdir(join(t, 'a', 'c'))
        mkdir(join(t, 'a', 'd'))
        mkdir(join(t, 'a', 'e'))
        mkdir(join(t, 'a', 'b', 'f'))
        _write(join(t, 'a', 'b', 'f', '__init__.py'), '')
        _write(join(t, 'a', 'b', 'f', 'g.py'), '')
        _write(join(t, 'a', 'c', '__init__.py'), '')

# Generated at 2022-06-23 15:29:15.318636
# Unit test for function loader
def test_loader():
    """Unit test for `loader`."""
    from . import pyslvs

    def _test(l: int) -> str:
        return loader(
            'pyslvs',
            dirname(abspath(pyslvs.__file__)),
            True,
            l,
            False
        )

    assert "<!-- TOC" in _test(0)
    assert "##" in _test(2)
    assert "###" in _test(3)
    assert "####" in _test(4)
    assert "#####" in _test(5)


# Generated at 2022-06-23 15:29:16.686286
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"name": "pylvs"}) != []

# Generated at 2022-06-23 15:29:21.016122
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from .pkg_util import set_cwd, pwd
    assert set_cwd(Path(__file__).parent)

    def _l(t):
        return list(walk_packages('pyslvs', pwd))

    assert _l(True) == []
    assert _l(False) != []

# Generated at 2022-06-23 15:29:22.574594
# Unit test for function loader
def test_loader():
    from . import fixture
    assert '##' not in loader(fixture, dirname(fixture))

# Generated at 2022-06-23 15:29:28.211270
# Unit test for function gen_api
def test_gen_api():
    path = dirname(__file__)
    assert gen_api({
        'Modules': 'solvespace',
    }, path, prefix='foo', dry=True)
    assert gen_api({
        'Modules': 'solvespace',
        'Collections': 'collections',
    }, path, prefix='foo', dry=True)
    assert gen_api({
        'Modules': 'solvespace',
        'Algorithms': 'algorithms',
    }, path, prefix='foo', dry=True)
    assert gen_api({
        'Modules': 'solvespace',
        'Platforms': 'platforms',
    }, path, prefix='foo', dry=True)



# Generated at 2022-06-23 15:29:32.759516
# Unit test for function walk_packages
def test_walk_packages():
    def mkdir_p(p):
        if not isdir(p):
            mkdir(p)

    def mkfile(name, text):
        logger.debug(f"create file: {name}")
        _write(name, text)


# Generated at 2022-06-23 15:29:43.874454
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from tempfile import TemporaryDirectory
    from shutil import move
    import os.path
    import os

    def _current_path(path):
        return os.path.dirname(os.path.abspath(path))

    def gen_test_package(name, module, version="0.0.0", path=None):
        path = path if path else os.path.join(tmpdir.name, name)
        os.mkdir(path)
        init = os.path.join(path, "__init__.py")
        with open(init, "w") as fd:
            fd.write(module)
        meta = os.path.join(path, "pyproject.toml")
        with open(meta, "w") as fd:
            f