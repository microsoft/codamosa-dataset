

# Generated at 2022-06-23 15:19:43.537919
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import pathlib
    p = sys_path.pop()
    sys_path.append(pathlib.Path(__file__).parent.parent.parent)
    for n, p in walk_packages('pyslvs', '.'):
        print(n, p)
    sys_path.pop()
    sys_path.append(p)

if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-23 15:19:55.033343
# Unit test for function walk_packages
def test_walk_packages():
    from .test_data import PWD
    name = 'pyslvs_ui'
    path = abspath(join(PWD, '..', 'pyslvs_ui'))
    for p in walk_packages(name, path):
        print(p)

# Generated at 2022-06-23 15:20:05.703226
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy2
    dummy = dict(
        a='# noqa',
        a1='# noqa',
        b='# noqa',
        c='# noqa',
        c1='# noqa',
        c1c='# noqa',
        c1c1='# noqa',
        py='# noqa',
        pyi='# noqa',
        a_stubs='# noqa',
        b_stubs='# noqa',
        c_stubs='# noqa',
    )

    with TemporaryDirectory() as temp:
        for name, body in dummy.items():
            copy2('conftest.py', f"{temp}/{name}.py")

# Generated at 2022-06-23 15:20:16.342330
# Unit test for function walk_packages
def test_walk_packages():
    from os import system
    from os.path import isdir, abspath, join
    print("Testing for function walk_packages() ...")
    pip = system("pip install -r requirements.txt")
    assert not pip, "requirements.txt not install correctly"
    pwd = abspath(".")
    # Add module path
    sys_path.append(join(pwd, "setup.py"))
    sys_path.append(join(pwd, "doc", "sphinx", "ext", "sphinx_pyslvs"))
    assert pwd == _site_path("sphinx_pyslvs")
    # List modules
    modules = list(walk_packages("sphinx_pyslvs", pwd))
    assert len(modules) > 10
    for name, path in modules:
        assert isdir

# Generated at 2022-06-23 15:20:22.400347
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("abc", ".")) == [
        ("abc", "./abc"),
        ("abc.__init__", "./abc/__init__.py"),
        ("abc.defg", "./abc/defg.py"),
        ("abc.defg.__init__", "./abc/defg/__init__.py"),
        ("abc.defg.hijk", "./abc/defg/hijk.py"),
        ("abc.defg.hijk.__init__", "./abc/defg/hijk/__init__.py"),
    ]

# Generated at 2022-06-23 15:20:25.084928
# Unit test for function walk_packages
def test_walk_packages():
    import pprint
    pprint.pprint(list(walk_packages("my_lib", "foo/lib/python3.8/site-packages/")))

# Generated at 2022-06-23 15:20:32.758922
# Unit test for function loader
def test_loader():
    from unittest import TestCase, mock
    from os import remove
    from os import name as os_name
    from os.path import sep
    from io import StringIO
    from sys import stdout, stderr
    from importlib import import_module

    class Module:

        """A module to test parser."""

        __file__ = "Module.py"

        name = "Module"


# Generated at 2022-06-23 15:20:36.828045
# Unit test for function gen_api
def test_gen_api():
    def single_test(name, title, level):
        assert gen_api({title: name}, pwd=f"{__file__}/../", prefix='build/docs', level=level)

    for level in range(1, 5):
        yield single_test, 'pyslvs', 'Pyslvs', level

# Generated at 2022-06-23 15:20:42.024285
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .setup import ROOT_NAME
    from . import __file__ as path
    from .__main__ import main
    doc = loader(ROOT_NAME, dirname(path), False, 0, False)
    main(root=ROOT_NAME, doc=doc, dry=True)

# Generated at 2022-06-23 15:20:48.477193
# Unit test for function gen_api
def test_gen_api():
    import sys
    import os.path
    import pytest
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    logger.info("Test start")
    assert not gen_api({}, None, prefix='docs_unit_test', dry=True)
    logger.info("Test done")

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:20:55.217872
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'Family': 'family',
        'Solver': 'solver',
        'Program': 'record',
        'Skeletons': 'skeletons',
        'Joints': 'joints',
        'VSpec': 'vspec',
    }
    gen_api(root_names, pwd=abspath(dirname(__file__)))
    gen_api(root_names, pwd=abspath(dirname(__file__)), dry=True)

# Generated at 2022-06-23 15:21:01.981203
# Unit test for function gen_api
def test_gen_api():
    """
    for n, p in [
        ("numpy", "numpy"),
        ("scipy", "scipy"),
        ("sympy", "sympy"),
        ("pint", "pint"),
        ("matplotlib", "matplotlib"),
        ("Pillow", "PIL"),
        ("wxPython", "wx"),
        ("PyQt5", "PyQt5"),
        ("PySide2", "PySide2"),
        ("tensorflow", "tensorflow"),
        ("Cython", "Cython"),
    ]:
        doc = gen_api({n: p}, dry=True)
        assert doc
        assert doc[0].startswith(f"# {n} API")
    """
    import pandas

# Generated at 2022-06-23 15:21:06.692836
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import doctest
    test = unittest.TestSuite()
    test.addTest(doctest.DocTestSuite(walk_packages))
    unittest.TextTestRunner().run(test)

if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-23 15:21:14.560330
# Unit test for function walk_packages
def test_walk_packages():
    from .atoms import atoms
    from .screw import screw

    site_path_atoms = _site_path('atoms')
    if not site_path_atoms:
        print('atoms can not be imported')
        return


# Generated at 2022-06-23 15:21:25.295712
# Unit test for function loader
def test_loader():
    with open('tests/source.py', 'r') as f:
        source = f.read()
    parser = Parser(link=True, level=1, toc=False)
    parser.parse('tests.source', source)

# Generated at 2022-06-23 15:21:36.637616
# Unit test for function gen_api
def test_gen_api():
    from shutil import rmtree
    from os import environ, remove
    from os.path import isdir, isfile
    from contextlib import nullcontext
    from importlib import import_module
    from pkgutil import walk_packages
    from .test_compiler_api_extension import test_api_extension
    from .test_compiler_api_package import test_api_package

    def test_gen_api_gen(prefix: str, root_names: dict[str, str],
                         level: int, toc: bool = False):
        logger.info("Generate API")
        p = Parser.new(True, level, toc)
        for name, path in walk_packages(root_names[list(root_names)[0]], prefix):
            module = import_module(name)
            doc = inspect

# Generated at 2022-06-23 15:21:39.673342
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({
        "PySLVS": "pyslvs",
        "Pyslvs-UI": "pyslvs_ui",
    }, dry=True)



# Generated at 2022-06-23 15:21:43.217551
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        "PySVSLib": "Pyslvs",
    }, dry=True)

    gen_api({
        "PySVSLib": "Pyslvs",
        "NURBS-Python": "nurbs",
    }, dry=True)

# Generated at 2022-06-23 15:21:44.799134
# Unit test for function loader
def test_loader():
    """Test case for function loader."""
    import pyslvs
    loader("pyslvs", _site_path("pyslvs"), False, 1, False)
    number: int
    assert number == 0


# Generated at 2022-06-23 15:21:56.352663
# Unit test for function loader

# Generated at 2022-06-23 15:21:59.877946
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'title': 'root'}, '.') != []
    assert gen_api({'title': 'not_exist'}, '.') == []

# Generated at 2022-06-23 15:22:07.874029
# Unit test for function loader
def test_loader():
    import sys
    import random
    import io
    import unittest.mock
    logger.add(sys.stderr, level="DEBUG")
    loader(
        "pyslvs",
        "..",
        True,
        1,
        False
    )
    loader(
        "not_exist_package",
        "..",
        True,
        1,
        False
    )
    # Check if it can load extension module
    s_loader = unittest.mock.Mock()
    s_loader.exec_module.return_value = None
    s_spec = unittest.mock.Mock()
    s_spec.loader = s_loader
    m = unittest.mock.Mock()
    m.__doc__ = "This is a documentation."
    del m

# Generated at 2022-06-23 15:22:15.341758
# Unit test for function loader
def test_loader():
    """Testing function loader."""
    import doctest
    parser = Parser.new()
    loader('httplib2', '', False, 1, True)
    print(parser.compile())
    parser.clear()
    loader('numpy', '', False, 1, True)
    print(parser.compile())
    doctest.run_docstring_examples(loader, globals())


# Generated at 2022-06-23 15:22:20.987261
# Unit test for function walk_packages
def test_walk_packages():
    def test_path(path: str) -> None:
        logger.debug(f"Testing path: {path}")
        assert isdir(path)
        for name, f_path in walk_packages("foo", path):
            assert isfile(f_path)
        logger.debug(f"Passed: {path}")

    test_path('./test')
    test_path('../test')



# Generated at 2022-06-23 15:22:25.836505
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 2, False)
    for name, path in walk_packages("test", "tests"):
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
    assert p.compile()

# Generated at 2022-06-23 15:22:28.317927
# Unit test for function gen_api
def test_gen_api():
    doc = gen_api({'pyslvs': 'pyslvs'}, dry=True)
    assert len(doc) == 1
    assert len(doc[0]) > 400

# Generated at 2022-06-23 15:22:29.892263
# Unit test for function walk_packages
def test_walk_packages():
    for n, p in walk_packages('python', 'test'):
        assert 'python' + sep in p and p.endswith('.pyi')

# Generated at 2022-06-23 15:22:30.672727
# Unit test for function loader
def test_loader():
    print(loader.__doc__)


# Generated at 2022-06-23 15:22:40.593810
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages."""
    path = 'pyslvs_ui/slvs/packages'
    # Test root
    res = [i for i in walk_packages('packages', path)]

# Generated at 2022-06-23 15:22:43.521945
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    s = loader(
        'pyslvs',
        join(abspath(dirname(__file__)), '..'),
        False,
        3,
        False
    )
    print(s)

# Generated at 2022-06-23 15:22:52.365276
# Unit test for function walk_packages
def test_walk_packages():
    results = list(walk_packages('pyslvs', 'pyslvs'))
    assert results[0] == ('pyslvs.file', 'pyslvs\\__init__.py')
    assert results[-1] == ('pyslvs.package', 'pyslvs\\package.py')
    assert 'pyslvs-stubs' in results[-1][-1]
    assert '__pycache__' not in results[-1][-1]
    assert '.pyi' in results[-1][-1]


# Generated at 2022-06-23 15:23:00.762693
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    from pathlib import Path
    from pyslvs import __path__
    # PEP 561
    for name, path in walk_packages('pyslvs', Path(__path__[0])):
        # pyslvs_ui.collections_ext
        assert '.' in name
        assert isfile(path + '.py')
    # PEP 562
    for name, path in walk_packages('pyslvs_ui', Path(__path__[0])):
        # pyslvs_ui.collections_ext
        assert '.' in name
        assert isfile(path + '.py')
    # sys
    sys_name = sys.__name__

# Generated at 2022-06-23 15:23:09.882837
# Unit test for function walk_packages
def test_walk_packages():
    from os import getcwd
    from itertools import combinations
    from unittest import TestCase, main

    class TestPath(TestCase):
        def setUp(self) -> None:
            self.pwd = getcwd()

        def test_path(self) -> None:
            path = join(sep, "usr", "lib", "python3.9", "site-packages", "pyslvs")
            self.assertEqual(path, _site_path("pyslvs"))

        def test_walk_name(self) -> None:
            paths = []
            for name, path in walk_packages("pyslvs", _site_path("pyslvs")):
                paths.append(name + " <=> " + path)
            self.assertEqual(len(paths), 17)
           

# Generated at 2022-06-23 15:23:17.081648
# Unit test for function loader
def test_loader():
    # Initialize a parser
    p = Parser.new(True, 1)
    p.parse("test", "# function\n## test")
    assert p.compile() == '# [test](#test)\n\n- test\n'
    # Load extension module
    assert _load_module("test", "./test_loader.py", p)
    assert p.compile() == '# [test](#test)\n\n- test\n- test_loader\n'
    assert _load_module("test", "./test_loader.py", p)

# Generated at 2022-06-23 15:23:18.630350
# Unit test for function gen_api
def test_gen_api():
    r1 = gen_api({'Pyslvs': 'pyslvs'}, '..', level=2, dry=True)
    assert r1

# Generated at 2022-06-23 15:23:21.355701
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    assert gen_api(
        {'Pyslvs': 'pyslvs', 'Pyslvs-UI': 'pyslvs_ui'},
        None,
        prefix='test_docs',
        dry=True
    )

# Generated at 2022-06-23 15:23:23.788512
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    assert gen_api({"Test": "test"}) != []

# Generated at 2022-06-23 15:23:33.688331
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    from io import StringIO
    from pkg_resources import Requirement, resource_filename

    class Test(unittest.TestCase):

        def test(self):
            resolver = Requirement.parse('pyslvs')
            path = resource_filename(resolver, 'pyslvs')
            itr = walk_packages('pyslvs', path)
            self.assertEqual(len(list(itr)), 61)

    with StringIO() as buf:
        logger.logger.handlers.append(logger.StreamHandler(buf))
        unittest.main(argv=[__file__], exit=False)
        logger.info(buf.getvalue())

# Generated at 2022-06-23 15:23:44.351532
# Unit test for function walk_packages
def test_walk_packages():
    from .__init__ import __path__

# Generated at 2022-06-23 15:23:47.814713
# Unit test for function gen_api
def test_gen_api():
    gen_api({'Pyslvs': 'pyslvs'}, '.', dry=True)


__all__ = ['gen_api']

# Generated at 2022-06-23 15:23:52.618508
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages(
        "pyslvs", "../pyslvs/"
    ))[0][0] == "pyslvs"


if __name__ == "__main__":
    from .test_api_gen import test_gen_api
    test_gen_api()

# Generated at 2022-06-23 15:23:56.874356
# Unit test for function walk_packages
def test_walk_packages():
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', __file__.removeprefix('__init__.py')):
        p.parse(name, _read(path))
    logger.info(p.compile())

# Generated at 2022-06-23 15:23:59.414612
# Unit test for function walk_packages
def test_walk_packages():
    l = []
    for name, path in walk_packages("pyslvs", "pyslvs"):
        l.append((name, path))
    print(l)

# Generated at 2022-06-23 15:24:08.671892
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    from core.Kernel import Kernel
    from core.QtModules import QtCore, QtWidgets

    root_names = {
        'Kernel': 'Kernel',
        'Qt': 'QtCore',
        'QtWidgets': 'QtWidgets',
    }
    with tempfile.TemporaryDirectory() as tmp:
        gen_api(
            root_names,
            pwd=tmp,
            prefix=".",
            dry=True,
        )
        gen_api(
            root_names,
            pwd=tmp,
            prefix=".",
        )


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:24:16.701931
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    def func(title, name):
        logger.warning(f"'{name}' can not be found")
        return '#' * 1 + f" {title} API\n\n"
    logger.warning = func
    result = gen_api({"Test1": "pyslvs", "Test2": "pyslvs2"})
    assert result == [
        '# Test1 API\n\n',
        '# Test2 API\n\n',
    ]


# Generated at 2022-06-23 15:24:25.513281
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages function."""
    from os import remove
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import module_name

    def path(name: str, sep: str = sep) -> str:
        return '.'.join(module_name(name).split(sep))

    pwd = mkdtemp()

# Generated at 2022-06-23 15:24:37.489946
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    from random import randint, choice
    from string import ascii_lowercase
    from tempfile import TemporaryDirectory as temp

    class Test(unittest.TestCase):

        def setUp(self):
            self.temp = temp()
            self.temp.__enter__()
            self.pth = self.temp.name

        def tearDown(self):
            self.temp.__exit__(None, None, None)

        def randstr(self, length: int) -> str:
            return "".join(choice(ascii_lowercase) for _ in range(length))

        def random_module(self, depth: int) -> str:
            return '.'.join([self.randstr(randint(1, 5)) for _ in range(depth)])


# Generated at 2022-06-23 15:24:38.891995
# Unit test for function gen_api
def test_gen_api():
    pass


# Generated at 2022-06-23 15:24:48.661220
# Unit test for function loader
def test_loader():
    from .functions import get_packages
    from .__init__ import __package__, __version__
    p = Parser.new(True, 1, False)
    modules = get_packages(__package__)
    p.parse(__package__, """
        pyslvs
        ======

        PYthon Structural Linkage Visual Simulation.

        This is an easy linkage simulation program.
        """)
    p.parse(__package__ + ".__init__", """
        __init__
        ========

        This is an easy linkage simulation program.
        """)
    p.parse(__package__ + "._version", """
        _version
        ========

        This is an easy linkage simulation program.
        """)

# Generated at 2022-06-23 15:25:00.838653
# Unit test for function walk_packages
def test_walk_packages():
    """Test: walk_packages."""
    from sys import path as sys_path
    from os.path import dirname
    from shutil import rmtree
    from tempfile import mkdtemp

    # Test 1
    name = 'os'
    path = sys_path[-1]
    s = set()
    for _, f_path in walk_packages(name, path):
        s.add(f_path)
    assert isdir(dirname(s.pop()))

    # Test 2
    root_name = 'root_name'
    root_path = mkdtemp()
    test_path = mkdtemp(dir=root_path)
    test_name = '.test_name'
    test_file_name = '__init__.py'

# Generated at 2022-06-23 15:25:08.366060
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    from tempfile import gettempdir
    from os import chdir
    from math import pi
    from sys import path as sys_path
    from sys import argv as sys_argv

# Generated at 2022-06-23 15:25:14.745760
# Unit test for function gen_api
def test_gen_api():
    """
    assert gen_api({
        "Pyslvs": "pyslvs",
        "Pyslvs UI": "pyslvs_ui",
        "Pyslvs Core": "pyslvs_core",
    })
    """
    assert gen_api({
        "Pyslvs": "pyslvs",
        "Pyslvs UI": "pyslvs_ui",
        "Pyslvs Core": "pyslvs_core",
    }, dry=True)

# Generated at 2022-06-23 15:25:16.989170
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    doc = gen_api({"Test": "test"}, dry=True)
    if not doc:
        raise RuntimeError("doc is empty!")

# Generated at 2022-06-23 15:25:26.046646
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os.path import join

    with TemporaryDirectory(prefix="pyslvs_doc_gen_api_") as tmp:
        with open(join(tmp, "__init__.py"), "w") as file:
            file.write("")


# Generated at 2022-06-23 15:25:37.328317
# Unit test for function loader
def test_loader():
    from pkgutil import walk_packages
    from tempfile import mkdtemp

    def gen_sub_module(name: str, text: str) -> None:
        _write(join(temp, name.replace('.', sep)), text)

    def walk_sub_module(root: str) -> Sequence[tuple[str, str]]:
        return [(name[len(root) + 1:], path)
                for name, path in walk_packages([root])]

    temp = mkdtemp()
    gen_sub_module("a.a", "def a(): pass")
    gen_sub_module("a.b", "def b(): pass")
    gen_sub_module("a.c.__init__", "")
    gen_sub_module("a.c.d", "def d(): pass")
    gen_sub_

# Generated at 2022-06-23 15:25:41.574885
# Unit test for function gen_api
def test_gen_api():
    doc = gen_api({"DummyAPI": "dummy_api"}, ".")[0]
    assert doc.startswith('## DummyAPI API')
    assert "dummy_api.AAAA = None" in doc
    assert "AAAAAAAAAA: int" in doc
    assert "dummy_api.BBBB" in doc
    assert "dummy_api.CCCC" in doc
    assert "dummy_api.DDDD" in doc
    assert "dummy_api.EEEE" in doc
    assert "dummy_api.FFFF" in doc
    assert "dummy_api.GGGG" in doc
    assert "dummy_api.HHHH" in doc
    assert "dummy_api.IIII" in doc
    assert "dummy_api.JJJJ" in doc

# Generated at 2022-06-23 15:25:47.911335
# Unit test for function loader
def test_loader():
    """Test function _load_module."""
    from importlib import import_module
    p = Parser.new(False, 0, False)
    r = _load_module('json', '', p)
    assert isinstance(r, bool)
    assert r is True
    assert p.docs != {}
    assert p.docs['']['json'] is not None
    assert isinstance(import_module('json'), object)

# Generated at 2022-06-23 15:25:55.181398
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from unittest.mock import patch, MagicMock

    class TestWalkPackages(TestCase):

        @patch('pyslvs_ui.compiler.isfile')
        @patch('pyslvs_ui.compiler.walk')
        @patch('pyslvs_ui.compiler.abspath')
        def test_walk(self, abspath_mock, walk_mock, isfile_mock):
            """Test for walk packages."""
            abspath_mock.return_value = '.'

# Generated at 2022-06-23 15:26:05.855196
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from json import dumps
    from pyslvs import __version__
    from pyslvs_ui.compiler import gen_api
    from pyslvs import __doc__ as pyslvs_doc
    from pyslvs_ui.__doc__ import __doc__ as pyslvs_ui_doc
    from pyslvs_ui.locale import __doc__ as locale_doc
    gen_api({
        'PySLVS': "pyslvs",
        'PySLVS-UI': "pyslvs_ui",
        'Locale': "pyslvs_ui.locale",
    }, dry=True)
    assert dumps(pyslvs_doc, indent=2)

# Generated at 2022-06-23 15:26:10.630166
# Unit test for function gen_api
def test_gen_api():
    """Tests for gen_api."""
    import tempfile
    test_path = tempfile.TemporaryDirectory()
    test_prefix = 'docs'

# Generated at 2022-06-23 15:26:19.775478
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil

    logger.setLevel('DEBUG')

    r = os.path.dirname(os.path.abspath(__file__))
    os.chdir(r)
    assert os.path.exists(os.path.join(r, "docs")) == False
    docs = gen_api(root_names={
        "Module1": "module1",
        "Module2": "module2"
    }, pwd=os.path.join(r, "tests"), prefix="docs", dry=True)
    assert os.path.exists(os.path.join(r, "docs"))
    assert len(docs) == 2
    print(docs[0])
    print(docs[1])

    shutil.rmtree(os.path.join(r, "docs"))

# Local

# Generated at 2022-06-23 15:26:29.694092
# Unit test for function loader
def test_loader():
    import site
    import json
    import pytest
    from importlib.machinery import EXTENSION_SUFFIXES
    from io import StringIO
    from contextlib import redirect_stdout
    from .parser import parser
    from .logger import logger

    def cmp_doc(name: str, path: str, p: Parser):
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            assert isinstance(s.loader, Loader)
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
        elif isfile(path):
            assert False, f"Not a module: {path}"

# Generated at 2022-06-23 15:26:32.393229
# Unit test for function gen_api
def test_gen_api():
    from .logger import logger
    logger.info(gen_api({"Test": "test", "Test2": "test2"}, '.'))
    logger.info(gen_api({"Test": "test"}, '.', dry=True))


__all__ = ['gen_api']

# Generated at 2022-06-23 15:26:35.805275
# Unit test for function walk_packages
def test_walk_packages():
    import pkg_resources

    pkg = pkg_resources.get_distribution('pyslvs')
    g = walk_packages('pyslvs', dirname(pkg.location))
    assert next(g) == ('pyslvs.__init__', pkg.location)

# Generated at 2022-06-23 15:26:37.781867
# Unit test for function gen_api
def test_gen_api():
    gen_api({"solve": "solver"}, "../pyslvs", dry=True)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:26:48.180564
# Unit test for function loader
def test_loader():
    from ast import node_classes
    from pkg_resources import parse_version
    from pyslvs import __version__
    from .parser import parent
    exports = []
    p = Parser.new(False, 2, False)
    for _, path in walk_packages('pyslvs', _site_path("pyslvs")):
        if not path.endswith('.py'):
            continue
        p.parse(parent(path), _read(path))
    assert 'pyslvs' in p.modules
    assert set(p.modules) == set(parent(path) for _, path in walk_packages('pyslvs', _site_path("pyslvs")))

# Generated at 2022-06-23 15:26:50.888569
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        "Pyslvs": "pyslvs",
    }, pwd="../", dry=True)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:26:52.548065
# Unit test for function gen_api
def test_gen_api():
    gen_api({'SOLVS': 'solvs'})

# Generated at 2022-06-23 15:27:02.977054
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function: walk_packages"""
    from tempfile import TemporaryDirectory

    def _test_walk(name: str, path: str, packs: Sequence[str]) -> None:
        items = list(walk_packages(name, path))
        assert items
        for name, path in items:
            logger.debug(f"{name} <= {path}")
        assert all(name in packs for name, _ in items)

    with TemporaryDirectory() as temp:
        # mkdir
        pack_name = 'test_walk'
        mkdir(join(temp, pack_name))
        # make file
        path = join(temp, pack_name, '__init__.py')
        _write(path, '')
        _test_walk(pack_name, temp, [pack_name])

# Generated at 2022-06-23 15:27:10.659945
# Unit test for function loader
def test_loader():
    from pprint import pprint
    from .parser import Parser
    from sys import path as sys_path
    from os import getcwd
    from os.path import isdir, join
    sys_path.append(getcwd())
    pwd = join(getcwd(), 'test')
    if isdir(pwd):
        sys_path.append(pwd)
    pwd = join(getcwd(), 'test', 'subpkg')
    if isdir(pwd):
        sys_path.append(pwd)
    p = Parser()
    for name, path in walk_packages('test', pwd):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext

# Generated at 2022-06-23 15:27:12.584725
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages("pyslvs", _site_path("pyslvs")))) == 5

# Generated at 2022-06-23 15:27:18.935165
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    from os import makedirs
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from pyslvs_ui.manager import main

    class TestWalkPackage(unittest.TestCase):
        @classmethod
        def setUpClass(cls) -> None:
            cls.name = "docsTest"
            cls.temp = mkdtemp()
            cls.path = join(cls.temp, cls.name)
            makedirs(join(cls.path, "stub"))
            makedirs(join(cls.path, "src"))
            makedirs(join(cls.path, "stub", "a"))
            makedirs(join(cls.path, "src", "a"))
           

# Generated at 2022-06-23 15:27:20.221012
# Unit test for function gen_api
def test_gen_api():
    gen_api({
        "Module": "compiler"
    }, '../pyslvs', prefix='compiler', dry=True)

# Generated at 2022-06-23 15:27:24.643358
# Unit test for function loader
def test_loader():
    logger.debug("=" * 100)
    logger.debug("Test function: walk_packages")
    for name, path in walk_packages("pyslvs", "."):
        logger.debug(name)
    logger.debug("=" * 100)
    logger.debug("Test function: loader")
    logger.debug("")
    logger.debug("Style:")
    logger.debug("API:")
    logger.debug("")
    doc = loader("pyslvs", ".", True, 1, True)
    logger.debug(doc)


# Generated at 2022-06-23 15:27:30.066699
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import pvgeom
    result = gen_api({
        'PySLVS': pvgeom.__name__,
    }, pwd=dirname(pvgeom.__file__))
    print(result[0])

# Generated at 2022-06-23 15:27:34.365001
# Unit test for function walk_packages
def test_walk_packages():
    path = r'c:\users\yuan\appdata\roaming\python\python37\site-packages\pyslvs'
    for p in walk_packages('pyslvs', path):
        print(p[1])


if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-23 15:27:41.393073
# Unit test for function gen_api
def test_gen_api():
    logger.info("Unit test for function gen_api")
    logger.info("Result:")
    logger.info('=' * 12)
    logger.info("\n\n".join(gen_api({"Test 1": "pyslvs_ui"}, dry=True)))
    logger.info("End of unit test for function gen_api\n")


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:27:50.433301
# Unit test for function walk_packages
def test_walk_packages():
    """Test `walk_packages` function."""
    p = Parser.new()
    for name, path in walk_packages('overlays', 'overlays'):
        p.parse(name, _read(path))
    assert p.compile() == (
        '## overlay.core\n\n'
        '```\n'
        'overlay.core\n'
        '```\n\n'
        '## overlay.overlay\n\n'
        '```\n'
        'overlay.overlay\n'
        '```\n\n'
        '## overlay.utils\n\n'
        '```\n'
        'overlay.utils\n'
        '```\n\n'
    )

# Generated at 2022-06-23 15:27:53.128008
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test'})


# Generated at 2022-06-23 15:28:03.662223
# Unit test for function loader
def test_loader():
    """Test function `loader()`."""
    from os import remove
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as d:
        mkdir(join(d, "aaa"))
        _write(join(d, "aaa", "__init__.py"), "")
        _write(join(d, "aaa", "__init__.pyi"), "")
        _write(join(d, "aaa", "__init__.pxd"), "")
        # aaa.bbb
        mkdir(join(d, "aaa", "bbb"))
        _write(join(d, "aaa", "bbb", "__init__.py"), "")
        _write(join(d, "aaa", "bbb", "__init__.pyi"), "")

# Generated at 2022-06-23 15:28:09.211950
# Unit test for function walk_packages
def test_walk_packages():
    """Check whether walk_packages works."""
    logger.info("Test walk_packages function ...")
    names = []
    for name, path in walk_packages('pkgutil', '.'):
        names.append(name)
        assert path.endswith(('.py', '.pyi', '.so'))
    names.sort()
    assert 'pkgutil.__init__' in names
    assert 'pkgutil.utils' in names



# Generated at 2022-06-23 15:28:13.469059
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import dirname
    from sys import executable
    from unittest.mock import patch
    with patch.object(sys_path, 'insert'),\
         patch.object(sys_path, 'append'):
        sys_path.insert.side_effect = lambda *_, **__: sys_path.insert(0, *_, **__)
        sys_path.append.side_effect = lambda *_, **__: sys_path.insert(0, *_, **__)
        sys_path.insert(0, dirname(executable))
        assert list(walk_packages('math', '.'))

# Generated at 2022-06-23 15:28:21.102281
# Unit test for function walk_packages
def test_walk_packages():
    pwd = "pyslvs/__init__.py"
    for name, path in walk_packages("pyslvs", pwd):
        logger.debug(f"{name=}, {path=}")
    for name, path in walk_packages("pyslvs_ui", pwd):
        logger.debug(f"{name=}, {path=}")
    for name, path in walk_packages("vse", pwd):
        logger.debug(f"{name=}, {path=}")

# Generated at 2022-06-23 15:28:27.484115
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os.path import join as path_join
    from shutil import copy
    try:
        with TemporaryDirectory() as tmp_dir:
            pkg_dir = path_join(tmp_dir, 't_pkg')
            mkdir(pkg_dir)
            with open(path_join(pkg_dir, 'pkg.py'), 'w') as f:
                f.write('''
''')
            docs = gen_api({'Title': 't_pkg'}, tmp_dir, dry=True, prefix=tmp_dir)
    except:
        pass
    finally:
        pass

# Generated at 2022-06-23 15:28:34.843697
# Unit test for function loader
def test_loader():
    from unittest.mock import Mock
    from unittest import TestCase
    from .parser import Linker

    class ParserMock(Mock):
        parse = Mock()
        load_docstring = Mock()

    class LoaderMock(Mock):
        def exec_module(self, m):
            pass

    class DummyLoader(Loader):
        def exec_module(self, m):
            pass

    class LoaderTest(TestCase):

        def test_success_load(self):
            name = "pyslvs"
            ParserMock.parse.return_value = True
            spec = Mock(spec=spec_from_file_location(name, ""))
            spec.loader = LoaderMock()
            spec_from_file_location.return_value = spec

# Generated at 2022-06-23 15:28:45.430291
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    from shutil import rmtree
    from os.path import basename
    import sys
    logger.info('Unit test: walk_packages')
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 15:28:49.474610
# Unit test for function walk_packages
def test_walk_packages():
    try:
        import numpy as np
    except ImportError:
        logger.exception('Please install `numpy` library')
        return
    name = np.__name__
    path = _site_path(np.__name__)
    logger.info(f'Search {name} in {path}')
    for n, p in walk_packages(name, path):
        logger.info(f'Load {n} in {p}')

# Generated at 2022-06-23 15:28:56.029118
# Unit test for function walk_packages
def test_walk_packages():
    from .examples.site_packages import site_packages
    from .examples.site_packages import install_module
    from os import rmdir, remove
    try:
        path = site_packages()
        # Install the project
        name = 'pyslvs_ui'
        install_module(name)
        # Test iteration
        _walk = dict(walk_packages(name, path))
        assert _walk['pyslvs_ui'] == path + name + sep + '__init__.py'
        # Test PEP561
        assert 'pyslvs_ui.__version__' in _walk
        assert 'pyslvs_ui.__version__' not in dict(walk_packages(
            name,
            path,
        ))
    finally:
        rmdir(join(path, name))
       

# Generated at 2022-06-23 15:29:07.254834
# Unit test for function walk_packages

# Generated at 2022-06-23 15:29:09.784813
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'docstring' : 'pyslvs_ui.docstring'})


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:29:19.520782
# Unit test for function gen_api
def test_gen_api():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from os.path import isdir
    from os import chdir
    try:
        cwd = Path.cwd()
        d = Path(mkdtemp())
        (d / 'foo').mkdir()
        chdir(d)
        sys_path.insert(0, str(d))
        gen_api({'foo': 'foo'}, '.')
        assert isdir('docs')
        assert (d / 'docs' / 'foo-api.md').exists()
    finally:
        chdir(str(cwd))
        rmtree(str(d))

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:29:29.944788
# Unit test for function walk_packages
def test_walk_packages():
    from os import mkdir
    from shutil import rmtree

    def _write(path: str, text: str) -> None:
        with open(path, 'w+') as f:
            f.write(text)

    def _site_path(name: str) -> str:
        s = find_spec(name)
        return s.submodule_search_locations[0] if s is not None else ""


# Generated at 2022-06-23 15:29:41.628756
# Unit test for function walk_packages
def test_walk_packages():
    from os import getcwd
    from os.path import join, dirname, pardir
    from tempfile import mkdtemp
    from shutil import rmtree
    from pathlib import Path
    from pkgutil import get_data
    from importlib import util
    import sys
    sys_path.append(getcwd())
    logger.setLevel(40)

    def _create_file(path: str, content: str) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        _write(path, content)

    # Official <https://docs.python.org/3/library/pkgutil.html#pkgutil.walk_packages>
    def _get_data(module):
        # Find the path of the module
        spec = util.find_spec(module)
       