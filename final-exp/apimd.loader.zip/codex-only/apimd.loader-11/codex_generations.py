

# Generated at 2022-06-23 15:19:46.605112
# Unit test for function walk_packages
def test_walk_packages():
    from sys import argv
    from os import chdir, getcwd
    from shutil import rmtree
    logger.debug("test_walk_packages start. Try to write some file.")
    doc = """class Test:

    def func(self):
        '''test func'''
        return True

    @property
    def prop(self) -> int:
        return 5
    """
    dir_name = r"__tmp_walk_package_test"
    dir_path = join(getcwd(), dir_name)
    if isdir(dir_path):
        rmtree(dir_path)
    mkdir(dir_path)
    chdir(dir_path)
    mkdir("a")
    mkdir("b")
    mkdir("c")
    mkdir("c\\d")

# Generated at 2022-06-23 15:19:57.993749
# Unit test for function loader
def test_loader():
    import tempfile
    import shutil
    import os
    import sys

    root = 'test'
    prefix = 'test_docs'
    with tempfile.TemporaryDirectory() as tmp:
        site = os.path.join(tmp, 'test_site')
        os.mkdir(site)
        os.mkdir(os.path.join(site, root))

# Generated at 2022-06-23 15:20:05.299674
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pkgutil import walk_packages as real_walk
    from unittest.mock import patch
    from importlib.util import find_spec as real_find
    from .test_pyslvs_ui.qtsolver.solvespace_2d import serial_chain
    from .test_pyslvs_ui.qtsolver.solvespace_3d import input_info
    from .test_pyslvs_ui.widgets.drawer import draw_system
    from .test_pyslvs_ui.widgets.color_picker import ColorPicker

# Generated at 2022-06-23 15:20:12.117161
# Unit test for function loader
def test_loader():
    """Test import module error."""
    # Importing a module that does not exist
    name = "numpy"
    loader(name, _site_path(name), link=False, level=1, toc=False)
    name = "pyslvs_ui.pyslvs_config"
    loader(name, _site_path(name), link=False, level=1, toc=False)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:20:17.492041
# Unit test for function gen_api
def test_gen_api():
    root_names = {"K3D": "pyslvs_ui",
                  "K3D-core": "pyslvs",
                  "K3D-ext": "pyslvs_ext"}
    pwd = abspath(dirname(__file__) + '/../')
    docs = gen_api(root_names, pwd)
    for doc in docs:
        print(doc)

# Generated at 2022-06-23 15:20:19.178609
# Unit test for function loader
def test_loader():
    """Test function loader."""
    pwd = dirname(abspath(__file__))
    loader("pyslvs", pwd, True, 1, True)

# Generated at 2022-06-23 15:20:30.335978
# Unit test for function loader
def test_loader():
    from pkgutil import walk_packages
    from .parser import parent
    from .compiler import find_spec, walk_packages as new_walk_packages

    sp = "tests"
    sys_path.append(sp)

    packages = set(name for _, name, _ in walk_packages([sp]))

    s = find_spec("test_stubs")

    if s is None:
        raise EnvironmentError(
            "No test packages found. Please run 'make install-test-stubs' first!"
        )

    search = set(f[0] for f in new_walk_packages("test", s.submodule_search_locations[0]))

    for name, _ in search:
        print(name)
        assert parent(name) in packages


if __name__ == '__main__':
    test_loader

# Generated at 2022-06-23 15:20:37.280503
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    with TemporaryDirectory() as tmp:
        copyfile(__file__, join(tmp, '__init__.py'))
        copyfile(__file__, join(tmp, 'test.py'))
        copyfile(__file__, join(tmp, 'test.pyi'))
        assert set(walk_packages('test', tmp)) == {
            ('__init__', f'{tmp}{sep}__init__.py'),
            ('test', f'{tmp}{sep}test.py'),
            ('test', f'{tmp}{sep}test.pyi'),
        }

# Generated at 2022-06-23 15:20:38.874060
# Unit test for function gen_api
def test_gen_api():
    gen_api({'Test': 'testpkg'}, pwd=abspath('testpkg'), dry=True)

# Generated at 2022-06-23 15:20:41.300123
# Unit test for function walk_packages
def test_walk_packages():
    assert 'numpy.__init__' in list(walk_packages('numpy', _site_path('numpy')))

# Generated at 2022-06-23 15:20:49.071701
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from numpy import zeros, ndarray
    from numpy.linalg import LinAlgError, eig
    try:
        eig(zeros((2, 2)))
    except LinAlgError:
        pass
    else:
        raise AssertionError("No LinAlgError!")
    assert isinstance(zeros((2, 2)), ndarray)
    assert loader("numpy", dirname(__file__), True, 2, True).strip()

# Generated at 2022-06-23 15:20:58.104524
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from io import StringIO
    from unittest.mock import patch
    import pylvs

    class _pylvs:
        """Mock."""

        def _():
            """Mock."""
            ...
        foo = _
        bar = _
        __doc__ = _

    with patch.dict(sys_path, {pylvs.__path__[0]: pylvs, '': pylvs}, clear=True):
        with patch('logging.StreamHandler') as s:
            with patch.object(_pylvs, 'foo', new=lambda: False):
                print(loader("pylvs", "", False, 1, False))
                assert "pylvs.foo(): <-- mocked" in s.out.getvalue()

# Generated at 2022-06-23 15:21:05.298051
# Unit test for function gen_api
def test_gen_api():
    names = {
        "Base": "pyslvs",
        "UI": "pyslvs_ui"
    }
    path = join(dirname(__file__), "..", "..")
    docs = gen_api(names, path, prefix="test", dry=True)
    assert all(doc.startswith("# API\n") for doc in docs)
    assert all(len(doc) > 10 for doc in docs)

# Generated at 2022-06-23 15:21:11.982004
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    # Use @ignore here to avoid runtime error

# Generated at 2022-06-23 15:21:14.661540
# Unit test for function gen_api
def test_gen_api():
    assert gen_api(dict(t="test"), pwd=__file__, dry=True)
test_gen_api()

# Generated at 2022-06-23 15:21:16.763236
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"pyslvs": "pyslvs"})

# Generated at 2022-06-23 15:21:26.411478
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from itertools import chain
    from os.path import join

    def make_tree(*args: str) -> None:
        for s in args:
            with open(s, 'w+') as f:
                f.write(s)

    with TemporaryDirectory() as temp_dir:
        pwd = abspath(temp_dir)
        name = 'sample'
        root = join(pwd, name)
        mkdir(root)

        # Test for nested root
        sub = join(root, '__init__.py')
        make_tree(sub)

        path = join(root, 'sample.py')
        make_tree(path)

# Generated at 2022-06-23 15:21:33.152909
# Unit test for function gen_api
def test_gen_api():
    # gen_api({'name': 'numpy'}, '/usr/local/lib/python3.7/site-packages')
    print(gen_api({'name': 'numpy'}, '/Users/yuan/Library/Python/3.7/lib/python/site-packages'))
    # gen_api([('name', 'numpy')])

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:21:42.577848
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import __version__
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import path, mkdir

    def test_fun(dry: bool) -> int:
        def mock_import(name: str, path: str, p: Parser):
            try:
                __import__(name)
            except ImportError:
                return False

# Generated at 2022-06-23 15:21:49.285922
# Unit test for function gen_api
def test_gen_api():
    test_data = {
        'sys': 'sys'
    }
    class TestParser(Parser):
        def __init__(self, *args):
            self.test = args

    def test_loader(name, pwd, link, level, toc):
        return TestParser(name, pwd, link, level, toc).test
    pwd = "path"
    dry = bool()
    level = int()
    toc = bool()
    link = bool()
    prefix = "dir"
    gen_api(test_data, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)
    pass

# Generated at 2022-06-23 15:21:58.877020
# Unit test for function loader
def test_loader():
    from os import chdir, getcwd
    from os.path import exists, dirname
    from shutil import rmtree
    from ._test_package.__main__ import _test_package_main
    from .sys_paths import sys_paths
    try:
        # Convenient for changing the system path
        with sys_paths():
            # Change the current path to test-package
            chdir(dirname(__file__) + '/_test_package/')
            # Run unittest
            _test_package_main(False)
            # Create documentation
            gen_api({"Test Package": "test_package"}, getcwd())
            assert exists('docs/test-package-api.md')
    finally:
        if exists('docs/test-package-api.md'):
            rmtree('docs')

# Generated at 2022-06-23 15:22:07.999241
# Unit test for function loader
def test_loader():
    from .data import qt
    from .data import calc
    from .data import sympy
    from .data import pyqtgraph
    from .data import mpl
    from .data import yaml
    from .data import new_root
    from .data import no_root
    from .data import as_comment
    from .data import class_doc
    from .data import short_doc
    from .data import long_doc
    from .data import para_doc
    p = Parser.new(True, 1, False)
    p.parse("QtCore", qt)
    p.parse("calc", calc)
    p.parse("sympy", sympy)
    p.parse("pyqtgraph", pyqtgraph)
    p.parse("pyqtgraph.Qt", pyqtgraph)


# Generated at 2022-06-23 15:22:19.346697
# Unit test for function walk_packages

# Generated at 2022-06-23 15:22:28.173701
# Unit test for function walk_packages
def test_walk_packages():
    from . import pyslvs
    from .__init__ import __version__
    from .__main__ import __doc__ as __main__doc__
    from . import alglib
    from . import alglib_doc
    from . import test_alglib
    from . import test_alglib_doc
    from .alglib import Point2D
    from .alglib import Point3D
    from .alglib_doc import Point2D as Point2DD
    from .__init__ import __name__ as __init__name__
    from .__main__ import __name__ as __main__name__
    from .alglib import __name__ as alglibname
    from .alglib_doc import __name__ as alglib_docname

# Generated at 2022-06-23 15:22:35.955783
# Unit test for function walk_packages
def test_walk_packages():
    # Dummy package
    mkdir('testing')
    _write('testing/__init__.py', '# Dummy packge\n')
    _write('testing/module.py', '# Dummy module\n')
    _write('testing/module-stubs.pyi', '# Dummy module\n')
    _write('testing/subpackage/__init__.py', '# Dummy subpackage\n')
    _write('testing/subpackage/submodule.py', '# Dummy submodule\n')
    _write('testing/subpackage/submodule-stubs.pyi', '# Dummy submodule\n')
    packages = list(walk_packages('testing', '.'))

# Generated at 2022-06-23 15:22:45.133219
# Unit test for function loader
def test_loader():
    """Test function."""
    from shutil import rmtree
    from pkg_resources import resource_filename
    rmtree('docs', ignore_errors=True)
    gen_api(
        {
            'Pyslvs': 'pyslvs',
            'Numpy': 'numpy',
            'PyQt5': 'PyQt5',
            'WxPython': 'wx',
        },
        resource_filename('pyslvs_ui', '.'),
        prefix='docs',
        link=False,
        toc=True,
        dry=True)
    gen_api({"Pyslvs": "pyslvs"}, dry=True)
    gen_api({"Pyslvs": "pyslvs"}, dry=True, level=2)

# Generated at 2022-06-23 15:22:50.896235
# Unit test for function loader
def test_loader():
    import unittest
    import tempfile

    class TestLoader(unittest.TestCase):

        def test_read_write(self):
            """Test read and write function."""
            path = tempfile.mktemp()
            doc = "This is a test"
            _write(path, doc)
            self.assertEqual(_read(path), doc)

    unittest.main()  # pragma: no coverage

# Generated at 2022-06-23 15:22:59.961817
# Unit test for function walk_packages
def test_walk_packages():
    import re
    from os import path
    from os.path import join as pjoin, expanduser
    from .logger import logger
    from shutil import rmtree
    from .parser import parse

    def _loader(pwd: str, name: str) -> Parser:
        """Local directory walking."""
        p = Parser.new(False, 1, True)
        for name_, path in walk_packages(expanduser(pwd), name):
            try:
                p.parse(name_, _read(path))
            except FileNotFoundError:
                logger.warning(f"{path} is not found")
        return p

    def _parse(p: Parser) -> str:
        """Only for builtin package."""
        p.load_docstring('', parse(''))
        return p.comp

# Generated at 2022-06-23 15:23:09.543526
# Unit test for function loader
def test_loader():
    log = logger.getChild("test_loader")
    p = Parser.new(True, 1, False)
    p.parse("builtins", "")
    p.parse("builtins.float", "")
    p.parse("builtins.int", "")
    p.parse("builtins.bool", "")
    p.parse("builtins.dict", "")
    loader("builtins", "", True, 1, False)
    p.parse("sys", "")
    p.parse("sys.platform", "")
    loader("sys", "", True, 1, False)
    for k, v in p.docs.copy().items():
        del p.docs[parent(k)]
    for k, v in p.docs.items():
        log.info(f"{k} => {v}")

# Generated at 2022-06-23 15:23:12.224165
# Unit test for function loader
def test_loader():
    assert isdir("test")
    locals()['__name__'] = '__main__'
    print(loader("test", "test", False, 1, True))

# Generated at 2022-06-23 15:23:15.963273
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    path = abspath(join(dirname(__file__), '..', '..', '..', 'tests', 'solver'))
    print(path)
    for pkg in walk_packages("solver", path):
        print(pkg)

# Generated at 2022-06-23 15:23:17.214195
# Unit test for function loader
def test_loader():
    print(loader("pyslvs", "../pyslvs", False, 1, True))

# Generated at 2022-06-23 15:23:22.892471
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test."""
    assert list(walk_packages('pkgutil', '../pyslvs/examples')) == [
        ('pkgutil.__init__', '../pyslvs/examples/pkgutil/__init__.py'),
        ('pkgutil.__main__', '../pyslvs/examples/pkgutil/__main__-stubs.py'),
        ('pkgutil.pkg1', '../pyslvs/examples/pkgutil/pkg1/__init__.py'),
        ('pkgutil.pkg1.mod1', '../pyslvs/examples/pkgutil/pkg1/mod1.py'),
        ('pkgutil.pkg2', '../pyslvs/examples/pkgutil/pkg2/__init__.py'),
    ]

# Generated at 2022-06-23 15:23:27.852495
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree
    from .logger import logger

    logger.setLevel(10)
    test_path = Path(mkdtemp())

# Generated at 2022-06-23 15:23:30.045217
# Unit test for function loader
def test_loader():
    """Tests for package searching."""



# Generated at 2022-06-23 15:23:37.612435
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert loader('pyslvs', '', False, 1, False)
    assert loader('pyslvs', '', True, 1, False)
    assert loader('pyslvs', '', True, 2, False)
    assert loader('pyslvs', '', True, 1, True)
    assert loader('pyslvs', '', True, 2, True)



# Generated at 2022-06-23 15:23:41.966159
# Unit test for function walk_packages
def test_walk_packages():
    pwd = dirname(__file__)
    for name, path in walk_packages("solvespace", pwd):
        print(f"{name}: {path}")
    # solvespace.__init__
    # solvespace.pyslvs
    # solvespace.pyslvs: ${tools}/solvespace/src/pyslvs/__init__.py
    # solvespace.pyslvs.__main__
    # ...

# Generated at 2022-06-23 15:23:52.549988
# Unit test for function loader
def test_loader():
    def walk_packages_test():
        assert root_names == {
            "A": "pkg_a",
            "B": "pkg_b",
        }

# Generated at 2022-06-23 15:24:01.409282
# Unit test for function gen_api
def test_gen_api():
    """Test function gen API."""
    root = {
        "PySLVS": "pyslvs",
        "SLVS-EC": "slvs",
    }
    from pyslvs import __path__ as pyslvs_path
    from slvs_ec.version import __path__ as slvs_path
    docs = gen_api(root, pyslvs_path[0], link=True, level=1, dry=True)
    for doc in docs:
        assert doc
    docs = gen_api(root, slvs_path[0], link=True, level=1, dry=True)
    for doc in docs:
        assert doc

# Generated at 2022-06-23 15:24:09.131231
# Unit test for function gen_api
def test_gen_api():
    import io
    import contextlib
    from unittest import TestCase
    from .logger import StdOut, logger

    @contextlib.contextmanager
    def capture_stdout():
        oldout = sys.stdout
        newout = io.StringIO()
        sys.stdout = newout
        try:
            yield newout
        finally:
            sys.stdout = oldout

    with capture_stdout() as out:
        gen_api({"pyslvs": "pyslvs"}, "../../")
    logger.info(out.getvalue())

# Generated at 2022-06-23 15:24:20.530302
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from pkgutil import iter_modules
    from os.path import dirname
    from sys import modules
    from .parser import pep561_import, __version__

    assert __version__ == '0.3.0'

    for mod in iter_modules():
        mod_path = modules[mod.name].__file__
        if mod_path is None:
            continue
        # Assert the mod is not extension module
        assert mod_path.endswith('.py')
        print(f"{mod.name} <= {mod_path}")

    for mod in iter_modules(dirname(modules[pep561_import.__name__].__file__)):
        mod_path = modules[mod.name].__file__

# Generated at 2022-06-23 15:24:22.137179
# Unit test for function loader
def test_loader():
    from .test_package import run_unit_test
    run_unit_test('test_loader')

# Generated at 2022-06-23 15:24:33.495958
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from numpy.distutils import numpy_distutils
    from numpy.testing import assert_array_equal

    def _define(s: str, m: str) -> None:
        obj = numpy_distutils.fcompiler.new_fcompiler(compiler=s)
        with open(m, 'w+') as f:
            f.write(f"# distutils: language = {obj.language}\n")
            if obj.options:
                f.write(f"# distutils: options = {repr(obj.options)}\n")
            if obj.executables:
                f.write(f"# distutils: executable = {repr(obj.executables)}\n")


# Generated at 2022-06-23 15:24:39.906939
# Unit test for function loader
def test_loader():
    from os.path import dirname
    from .logger import init_logger
    from .parser import Parser
    init_logger(level='DEBUG')
    pwd = dirname(__file__) + '/tests'
    sys_path.append(pwd)
    p = Parser(link=True, level=1, toc=False, title='test')
    assert loader('test', pwd, True, 1, False) == p.compile()

# Generated at 2022-06-23 15:24:42.651480
# Unit test for function loader
def test_loader():
    doc = loader('sympy', '../', True, 1, False)
    from sympy.utilities.pytest import XFAIL
    if XFAIL:
        assert False, "Can't import sympy module"
    assert doc.count("##") < 10

# Generated at 2022-06-23 15:24:51.685423
# Unit test for function walk_packages

# Generated at 2022-06-23 15:24:54.747694
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert loader('pyslvs_ui', '.', True, 1, True)



# Generated at 2022-06-23 15:25:00.431773
# Unit test for function gen_api

# Generated at 2022-06-23 15:25:11.406644
# Unit test for function loader
def test_loader():
    from pprint import pprint
    from .parser import Parser
    from .__init__ import __version__
    from .linear_solver import VPoint, VLink

    parser = Parser.new(False, 1, False)

    for name, path in walk_packages("pyslvs", dirname(__file__)):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            parser.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        # Try to load module here

# Generated at 2022-06-23 15:25:19.350380
# Unit test for function loader
def test_loader():
    """Test: Loader."""
    import os
    import subprocess

    def clean() -> None:
        """Clean the test environment."""
        try:
            os.chdir("..")
        except FileNotFoundError:
            pass
        try:
            os.remove("test.py")
        except FileNotFoundError:
            pass
        try:
            subprocess.run(["rm", "-rf", "pyslvs"])
        except FileNotFoundError:
            pass

    # Test for cleaning
    clean()

    # Test for generate API for pyslvs
    root_names = {
        "PySLVS": "pyslvs",
    }
    # gen_api(root_names, pwd="../../")

    # Test for generate API for the package in test-module directory
    root_

# Generated at 2022-06-23 15:25:26.521861
# Unit test for function walk_packages
def test_walk_packages():
    from pkgutil import get_loader
    from pkg_resources import get_distribution
    from .testpkg import __name__, __file__
    sp = _site_path(__name__)

    class NullLoader:
        pass

    for p in [__file__, sp]:
        for name, path in walk_packages(__name__, p):
            assert name == __name__
            assert isfile(path + ".py")
            assert isfile(path + ".pyi")
            assert get_loader(name) == get_distribution(name)

    for name, path in walk_packages('pyslvs', dirname(__file__)):
        assert isfile(path + ".py")
        assert isfile(path + ".pyi")

# Generated at 2022-06-23 15:25:31.157945
# Unit test for function loader
def test_loader():  # pragma: no cover
    root = 'pyslvs_ui'
    path = parent(__file__)
    print(loader(root, path, link=False, level=2, toc=False).strip())


if __name__ == '__main__':  # pragma: no cover
    test_loader()

# Generated at 2022-06-23 15:25:41.268320
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os import path, getcwd
    from os.path import basename, extsep, abspath
    from shutil import rmtree
    from .api_testcase import ApiTestCase

    class TestGenApi(ApiTestCase):
        """Test for gen_api."""

        def test_gen_api(self):
            """Test for gen_api."""
            with TemporaryDirectory() as prefix:
                prefix = abspath(prefix)
                docs = gen_api(
                    {
                        "Test": "test_api",
                    },
                    prefix=prefix
                )
                self.assertEqual(path.isfile(path.join(prefix, "test-api-api.md")), True)
                self.assertEqual(len(docs), 1)


# Generated at 2022-06-23 15:25:44.113756
# Unit test for function loader
def test_loader():
    assert isinstance(loader("os", dirname(__file__), False, 1, False), str)



# Generated at 2022-06-23 15:25:50.992438
# Unit test for function loader
def test_loader():
    """Loader unit test."""
    p = Parser.new(False, 1)
    for n, p_ in walk_packages('numpy', './'):
        for ext in ['.py', '.pyi']:
            p_ext = p_ + ext
            if not isfile(p_ext):
                continue
            logger.debug(f"{n} <= {p_ext}")
            p.parse(n, _read(p_ext))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:25:58.397970
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from importlib import resources
    from pyslvs import __version__

    with resources.path("pyslvs_ui.resources", "docs_template.md") as doc:
        with open(doc, encoding="utf-8") as f:
            test_load = f.read()
    new_load = loader("pyslvs", dirname(__file__), True, 0, False)
    assert test_load == new_load

# Generated at 2022-06-23 15:26:01.247269
# Unit test for function walk_packages

# Generated at 2022-06-23 15:26:04.196425
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('pyslvs', '/home/ych/.local/lib/python3.8/site-packages'):
        print(f"'{name}' in '{path}'")

# Generated at 2022-06-23 15:26:13.549928
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    root_names = {
        "pyslvs": "pyslvs",
        "pyslvs.system": "pyslvs_ui",
        "pyslvs.internal": "pyslvs_ui_impl"
    }
    doc = gen_api(root_names, dry=True)
    assert len(doc) == 2
    assert len(doc[0]) > len(doc[1])
    assert len(doc[1]) > 0
    assert len([c for d in doc for c in d if c == '\n']) > len(doc[0]) // 4

# Generated at 2022-06-23 15:26:17.041579
# Unit test for function loader
def test_loader():
    assert isinstance(loader("pyslvs", "", False, 1, False), str)
    assert isinstance(loader("pyslvs", "", True, 3, True), str)

# Generated at 2022-06-23 15:26:22.679229
# Unit test for function gen_api
def test_gen_api():
    logger.info("Function-test for gen_api.")
    root_names = {
        "Extensions": "pyslvs_extension"
    }
    pwd = dirname(abspath(__file__))
    gen_api(root_names, pwd)
    logger.info("OK")

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:26:31.699476
# Unit test for function walk_packages
def test_walk_packages():
    from typing import NamedTuple
    from unittest import TestCase
    from unittest.mock import patch
    from importlib import import_module

    class Test(NamedTuple):

        name: str
        path: str

    class Mock(TestCase):

        def setUp(self) -> None:
            self.mock = patch('solvespace.compiler._site_path', return_value="")
            self.mock.start()
            import_module('pyslvs_ui.qt_patch')
            self.tests = [
                Test('pyslvs_ui', 'pyslvs_ui'),
                Test('pyslvs_ui.__init__', 'pyslvs_ui'),
            ]

        def tearDown(self) -> None:
            self.mock.stop()



# Generated at 2022-06-23 15:26:36.859325
# Unit test for function gen_api
def test_gen_api():
    import os
    import sys
    import shutil
    # Set sys path
    sys.path.append(os.path.abspath("../.."))
    # Base directory
    base_dir = os.path.abspath(".")
    # Test module
    root_names = {
        "MES",
        "pyslvs",
    }
    # Generate API
    gen_api(root_names, base_dir)
    # Delete API folder
    shutil.rmtree("docs")

test_gen_api()

# Generated at 2022-06-23 15:26:42.306065
# Unit test for function gen_api
def test_gen_api():
    from unittest import TestCase, main

    class Test(TestCase):
        def test_get_api(self):
            self.assertEqual(
                gen_api({'Pyslvs': 'pyslvs'}, dry=True),
                ['# Pyslvs API\n\n'],
            )

    main()

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:26:52.163058
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import shutil
    import tempfile

    class Test(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)

        def test(self):
            p1 = join(self.tmpdir, "a", "b", "c")
            p2 = join(self.tmpdir, "a", "b", "d")
            p3 = join(self.tmpdir, "a", "d", "d")
            mkdir(p1)
            mkdir(p2)
            mkdir(p3)
            _write(join(p1, "c.py"), "")
            _write(join(p1, "c.pyi"), "")


# Generated at 2022-06-23 15:26:55.404773
# Unit test for function walk_packages
def test_walk_packages():
    from pylvs import _test_data
    assert [("pyslvs", join(_test_data, 'pyslvs.pyi'))] == list(walk_packages("pyslvs", _test_data))

# Generated at 2022-06-23 15:26:59.789052
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil
    try:
        gen_api({"SVScalc": "svscalc", "SVSC": "svs_c"}, dry=True)
    finally:
        shutil.rmtree('docs')
        os.remove('svs-c.so')

# Generated at 2022-06-23 15:27:08.402447
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pkgutil import write_file
    with TemporaryDirectory() as temp_dir:
        # Folder structure:
        # |- package
        #    |- __init__.pyi
        #    |- module
        #       |- __init__.py
        #       |- class.py
        #       |- class.pyi
        pkg_dir = join(temp_dir, 'package')
        mkdir(pkg_dir)
        write_file(join(pkg_dir, '__init__.pyi'), 'from typing import overload')
        mod_dir = join(pkg_dir, 'module')
        mkdir(mod_dir)
        write_file(join(mod_dir, '__init__.py'), 'from typing import overload')


# Generated at 2022-06-23 15:27:15.408298
# Unit test for function walk_packages
def test_walk_packages():
    # Set current path to the root
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    os.chdir('..')
    assert len(list(walk_packages('pyslvs', './pyslvs'))) > 10
    assert len(list(walk_packages('pyslvs_ui', './pyslvs_ui'))) > 2

# Generated at 2022-06-23 15:27:24.582586
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages(name, path)

    Note that this test is meant to be executed in the source directory.
    The directory structure should be:

    pyslvs/
        __init__.py
        package/
            __init__.py
            module.py
            another.pyi
    """
    name = "pyslvs"
    path = dirname(__file__)
    assert tuple(walk_packages(name, path)) == (
        ("pyslvs", path + '/__init__.py'),
        ("pyslvs.package", path + '/package/__init__.py'),
        ("pyslvs.package.module", path + '/package/module.py'),
        ("pyslvs.package.another", path + '/package/another.pyi'),
    )

# Generated at 2022-06-23 15:27:36.577161
# Unit test for function walk_packages
def test_walk_packages():
    """Test function."""
    root, path = "pyslvs_ui", "~/.local/lib/python3.6/site-packages/pyslvs-ui"

# Generated at 2022-06-23 15:27:47.570768
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs import about, exprs, solvers, ui

    class FakeParser(Parser):
        """Fake parser for test."""

        def __init__(self):
            self.doc = ""

        def parse(self, _, doc: str) -> None:
            """To test the subclasses."""
            self.doc += doc + '\n\n'

        def compile(self) -> str:
            """To test the subclasses."""
            return self.doc

    p = FakeParser()
    loader(about.__name__, dirname(about.__file__), False, 1, False, p)
    loader(exprs.__name__, dirname(exprs.__file__), False, 1, False, p)

# Generated at 2022-06-23 15:27:53.760026
# Unit test for function loader
def test_loader():
    """Unit test."""
    from os import path as os_path, chdir
    import shutil
    root = os_path.expanduser("~/Documents/pyslvs_temp")
    root_p = os_path.join(root, "solver")
    root_d = os_path.join(root, "solver.docs")
    if os_path.exists(root_d):
        print("Remove exists folder:", root_d)
        shutil.rmtree(root_d)
    if os_path.exists(root_p):
        print("Remove exists folder:", root_p)
        shutil.rmtree(root_p)
    mkdir(root_p)

# Generated at 2022-06-23 15:27:58.616086
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import path
    from . import __version__
    from .parser import root_names

    with TemporaryDirectory() as temp:
        gen_api(root_names, temp, prefix=temp, dry=True)
        copyfile(__file__, path.join(temp, f"pyslvs_{__version__}.py"))
        gen_api(root_names, temp, prefix=temp, dry=False)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:28:05.048287
# Unit test for function walk_packages
def test_walk_packages():
    path = 'example/test'
    for name in [
        'walk_packages.walk_packages',
        'walk_packages.sub.sub_package',
    ]:
        assert name in dict(walk_packages('walk_packages', path))
    for name in [
        'walk_packages.sub.sub_package.sub',
        'walk_packages.sub.sub_package.sub_sub',
        'walk_packages.sub.sub_package.sub_sub_sub.sub_sub_sub',
        'walk_packages.sub.sub_package.sub_sub_sub.sub_sub_sub.sub_sub_sub'
    ]:
        assert not name in dict(walk_packages('walk_packages', path))

# Generated at 2022-06-23 15:28:13.117052
# Unit test for function loader
def test_loader():
    from unittest.mock import patch
    from .logger import patch_logger

    with patch_logger(), patch('pathlib.Path.exists') as mock_exists,\
            patch('io.open') as mock_open,\
            patch('importlib.machinery.EXTENSION_SUFFIXES', return_value=[]):
        mock_exists.return_value = True
        mock_open.side_effect = [
            mock_open.return_value.__enter__.return_value,
            mock_open.return_value.__enter__.return_value,
            mock_open.return_value.__enter__.return_value,
            mock_open.return_value.__enter__.return_value
        ]
        mock_open.return_value.__enter__.return_

# Generated at 2022-06-23 15:28:15.039334
# Unit test for function loader
def test_loader():
    logger.setLevel(10)

# Generated at 2022-06-23 15:28:25.368608
# Unit test for function walk_packages

# Generated at 2022-06-23 15:28:33.794430
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        sys_path.append(tmp)
        name = 'test_api'
        doc = "# Root\n\n"
        doc += "## Prefix\n\n"
        doc += "Hello World"
        with open(join(tmp, f"{name}.py"), "w+") as f:
            f.write(doc)
        doc = "# Root API\n\n"
        doc += "## Prefix\n\n"
        doc += "Hello World"
        assert gen_api({'Root': name}, tmp, dry=True) == [doc]


# Generated at 2022-06-23 15:28:43.324459
# Unit test for function loader
def test_loader():
    import pkg_resources
    from os.path import dirname, join
    from sys import path as sys_path
    sys_path.append(dirname(dirname(pkg_resources.resource_filename('pyslvs', ''))))
    from pyslvs import __file__ as path, __version__
    path = dirname(dirname(path))
    p = Parser.new(link=True, level=2, toc=False)
    for name, path in walk_packages("pyslvs", path):
        p.parse(name, _read(path + ".py"))
    doc = p.compile()
    assert doc and doc.strip()
    assert doc.startswith(f"# Pyslvs {__version__} API")

# Generated at 2022-06-23 15:28:46.109280
# Unit test for function loader
def test_loader():
    """Test for module loader."""
    import doctest
    print("Checking API loader ...")
    doctest.testmod()

# Generated at 2022-06-23 15:28:53.640066
# Unit test for function walk_packages
def test_walk_packages():
    import pathlib
    import tempfile
    class FakeNone:
        def __repr__(self) -> str:
            return 'None'
        submodule_search_locations = None
    with tempfile.TemporaryDirectory() as folder:
        folder = pathlib.Path(folder)
        folder.joinpath('a', 'b', 'c.py').touch()
        folder.joinpath('a', 'b', 'd.pyi').touch()
        folder.joinpath('a', 'b', 'e.py').touch()
        folder.joinpath('a', 'b', 'e.pyi').touch()
        folder.joinpath('a', 'b', '__init__.py').touch()
        folder.joinpath('a', 'b', '__init__.pyi').touch()

# Generated at 2022-06-23 15:28:58.361819
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    import os
    import shutil
    # Create a test module

# Generated at 2022-06-23 15:29:09.423143
# Unit test for function walk_packages
def test_walk_packages():
    def make_package(name: str) -> Loader:
        return module_from_spec(spec_from_file_location(name, '.')).__loader__

    # The function works when the package is not installed
    paths = list(walk_packages("collections", "collections"))
    assert paths == [
        ('collections.counter', './collections/__init__.py'),
        ('collections.namedtuple', './collections/namedtuple.py'),
        ('collections.deque', './collections/deque.py'),
    ]

    # The function works when the package is installed
    paths = list(walk_packages("collections", _site_path("collections")))
    assert paths == []

    # The function works when the package has been loaded

# Generated at 2022-06-23 15:29:14.231416
# Unit test for function gen_api
def test_gen_api():
    from os.path import dirname, join
    r = gen_api(
        {
            "Pyslvs": "pyslvs",
        },
        join(dirname(__file__), ".."),
        dry=True,
    )
    assert r
    assert len(r) == 1
    assert '*' * 12 in r[0]

# Generated at 2022-06-23 15:29:23.602545
# Unit test for function loader
def test_loader():
    from importlib.machinery import EXTENSION_SUFFIXES
    from zlib import crc32
    from os.path import isfile
    EXTENSION_SUFFIXES = [x for x in EXTENSION_SUFFIXES if isfile(f"/usr/lib/libpython{x}")]
    doc = loader("zlib", "./zlib", link=False, level=2, toc=False)
    doc2 = loader("zlib", "./zlib", link=False, level=2, toc=True)
    assert crc32(doc2.encode('utf-8')) == 0x27bdddf3
    assert crc32(doc.encode('utf-8')) == 0x5c5b5b5d
    print(doc)

# Generated at 2022-06-23 15:29:35.051909
# Unit test for function walk_packages
def test_walk_packages():
    def test(name: str, path: str, expected: list[str]) -> None:
        actual = list(walk_packages(name, path))
        assert expected == actual, f"{expected} != {actual}"


# Generated at 2022-06-23 15:29:44.869211
# Unit test for function loader
def test_loader():
    """Test for package loading."""
    # Create folder
    for i in ['test_a', 'test_b', 'test_c']:
        if not isdir(i):
            mkdir(i)
    # Create source
    sources = [
        ("test_a/a.pyi", ""),
        ("test_a/abc.py", ""),
        ("test_b/b.pyi", ""),
        ("test_b/abc.py", ""),
        ("test_c/c.pyi", ""),
        ("test_c/abc.py", ""),
    ]
    for path, content in sources:
        with open(path, 'w') as f:
            f.write(content)
    # Test walk
    _test_walk()
    # Test parse
    _test_parse()

