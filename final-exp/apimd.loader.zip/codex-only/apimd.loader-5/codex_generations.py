

# Generated at 2022-06-23 15:19:43.028722
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    root_path = dirname(abspath(__file__))
    assert [
        ('pyslvs_ui.compiler', 'pyslvs_ui/compiler.py'),
        ('pyslvs_ui.compiler.loader', 'pyslvs_ui/compiler/loader.py'),
    ] == list(walk_packages('compiler', join(root_path, '..')))
    assert [] == list(walk_packages('compiler', './'))

# Generated at 2022-06-23 15:19:44.087749
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"Test module": "pyslvs_ui"})

# Generated at 2022-06-23 15:19:50.387191
# Unit test for function gen_api
def test_gen_api():
    from os import remove, rmdir
    from tempfile import TemporaryDirectory
    from .parser import Parser
    from .logger import logger
    from .__file__ import replaceprefix

    def __test_parser(
        parent_name: str,
        name: str,
        *,
        doc: str = "",
        parent_doc: str = "",
        args: dict[str, str] = None,
        ret: dict[str, str] = None,
    ):
        if args is None:
            args = {}
        if ret is None:
            ret = {}
        p.parse(f"{parent_name}.{name}", f"""\
{ret.get(name, "")}
{doc}

{parent_doc}
{args.get(name, "")}
""")
        return

# Generated at 2022-06-23 15:19:56.974742
# Unit test for function gen_api
def test_gen_api():
    def _():
        root = {'foo': 'foo', 'bar': 'bar', 'baz': 'foo.bar'}
        root_path = abspath(join(dirname(__file__), '__doc__', 'root_names'))
        sys_path.append(root_path)
        prefix = join(root_path, 'tmp')
        docs = gen_api(root, root_path, prefix=prefix, level=3, toc=True)
        for doc in docs:
            print(doc)
    _()

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:19:59.067633
# Unit test for function gen_api
def test_gen_api():
    """Test case for gen_api."""
    gen_api({'Solver API': 'pyslvs'}, '../', dry=True)

# Generated at 2022-06-23 15:20:03.734769
# Unit test for function loader
def test_loader():
    from .config import script_root
    from .parser import Parser
    p = Parser.new(False)
    cur_path = dirname(abspath(__file__))
    walk_packages(script_root, cur_path)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:20:15.495415
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory as TD
    from unittest.mock import patch, MagicMock
    from pkgutil import extend_path

    root = 'package'
    root_names = {
        'Package': root,
    }
    logger.setLevel(1)

    def set_up(root: str) -> TD:
        import os
        with TD() as td:
            with open(os.path.join(td, root, '__init__.py'), 'w+') as f:
                f.write("__path__ = extend_path(__path__, __name__)")

# Generated at 2022-06-23 15:20:21.266439
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import tempfile
    name = 'foo'
    with tempfile.TemporaryDirectory() as temp:
        path = join(temp, 'foo.pyi')
        with open(path, 'w+') as f:
            f.write('def foo() -> None:\n    r"""Docstring."""\n    pass')
        assert loader(name, temp, link=False, level=1, toc=False) == '# Foo API\n\n```python\n\ndef foo() -> None:\n    """Docstring."""\n    ...\n\n```\n' # noqa

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:20:25.607482
# Unit test for function loader
def test_loader():
    doc = loader(
        'pyslvs',
        dirname(dirname(dirname(dirname(abspath(__file__))))),
        True,
        1,
        True
    )
    assert doc


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_loader()

# Generated at 2022-06-23 15:20:30.228059
# Unit test for function walk_packages
def test_walk_packages():
    """Function `walk_packages`."""
    from pyslvs_ui import collections
    assert next(walk_packages(
        'collections',
        dirname(collections.__file__)
    ))[0] == collections.__name__



# Generated at 2022-06-23 15:20:38.920661
# Unit test for function loader
def test_loader():
    """This is a unit test.

    Mock package "pyslvs_ui" under root directory.
    """
    from unittest import TestCase
    from unittest.mock import patch, mock_open, MagicMock
    from tempfile import TemporaryDirectory

    class Test(TestCase):
        """Unit test for function loader."""

        def test_site_path(self) -> None:
            """Test for function _site_path."""
            self.assertEqual(_site_path("os.path"), "/usr/lib/python")

        def test_read(self) -> None:
            """Test for function _read."""
            m = mock_open(read_data="test")
            with patch('builtins.open', m, create=True):
                self.assertEqual(_read("test.txt"), "test")

# Generated at 2022-06-23 15:20:48.859628
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    import os
    import shutil
    from json import dumps

    test = "test-site"

    # Initialization
    try:
        shutil.rmtree(test)
        shutil.rmtree("docs")
    except FileNotFoundError:
        pass

    # Set up test data
    os.mkdir(test)
    os.mkdir(test + "/foo")
    os.mkdir(test + "/foo/bar")
    os.mkdir(test + "/package")
    os.mkdir(test + "/package/module")


# Generated at 2022-06-23 15:20:52.988071
# Unit test for function loader
def test_loader():
    # Pretend in project root directory
    pwd = "test"
    root_names = {'test': 'test'}
    gen_api(root_names, pwd, prefix="..", dry=True)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:21:00.495109
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    import pyslvs_ui.__main__ as p
    path = abspath('.')
    p.logger.setLevel('DEBUG')
    path_save = p._main.__globals__.get('Builder').__globals__.get('save', None)
    if path_save:
        p._main.__globals__.get('Builder').__globals__['save'] = lambda path, module: True
    logger.info(f"Start to load: pyslvs")
    assert loader('pyslvs', path, True, 3, True)
    p._main.__globals__.get('Builder').__globals__['save'] = path_save
    logger.info(f"Complicated package load test success!")

# Generated at 2022-06-23 15:21:11.209474
# Unit test for function gen_api
def test_gen_api():
    """Test for pkgutil.gen_api."""
    from importlib import import_module
    from pkgutil import walk_packages
    from pkg_resources import iter_entry_points

    def wp(n: str) -> Sequence[tuple[str, str]]:
        """Wrapper for pkgutil."""
        r = []
        for i in walk_packages(import_module(n)):
            r.append((i.name, i.path))
        return r

    def ep(n: str) -> Sequence[tuple[str, str]]:
        """Loader for entry points."""
        return [(i.name, i.value) for i in iter_entry_points(n)]

    def _ep_test():
        """Test for entry_points."""
        r = ep("pyslvs_plugins")

# Generated at 2022-06-23 15:21:22.736470
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""

# Generated at 2022-06-23 15:21:24.719362
# Unit test for function gen_api
def test_gen_api():
    assert gen_api(dict(foo='')) == []
    assert gen_api(dict(foo='bar'), dry=True) == ['# \n\n# bar API\n\n']

test_gen_api()

# Generated at 2022-06-23 15:21:26.334223
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"foo": "foo"}) == []

# Generated at 2022-06-23 15:21:37.405064
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function `walk_packages`."""
    from os import remove
    from os.path import abspath
    from tempfile import mkdtemp
    from shutil import copytree
    from .logger import silent
    from .parser import Parser
    from .core import generate_package_to
    from .structure import Structure, create_structure
    from .specification import Specification, create_specification

    def _check_packages(structure: Structure, spec: Specification) -> None:
        """Check packages."""
        # Create packages
        with silent():
            temp_folder = mkdtemp(suffix='_solvespace_packages')

# Generated at 2022-06-23 15:21:40.864243
# Unit test for function walk_packages
def test_walk_packages():
    lst = list(walk_packages('pyslvs', '../site-packages'))
    assert lst
    assert 'pyslvs' in lst[0][0]
    assert 'pyslvs' in lst[0][1]

# Generated at 2022-06-23 15:21:49.036667
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from os import makedirs
    from .compile import walk_packages, write_package
    from .logger import logger

    temp = TemporaryDirectory()
    pkg = temp.name + "/test"
    makedirs(pkg + "/sub")
    makedirs(pkg + "/sub/subsub")
    makedirs(pkg + "/sub/subsub/subsubsub")
    write_package(pkg, "", True)
    write_package(pkg + "/sub", "", True)
    write_package(pkg + "/sub", "a", False)
    write_package(pkg + "/sub/subsub", "b", False)
    write_package(pkg + "/sub/subsub/subsubsub", "c", False)


# Generated at 2022-06-23 15:21:50.472181
# Unit test for function gen_api
def test_gen_api():
    gen_api({'test': 'test'}, dry=True)

# Generated at 2022-06-23 15:21:54.983286
# Unit test for function walk_packages
def test_walk_packages():
    from importlib import import_module
    from .data import link_source, root_names
    for name, _ in walk_packages(root_names['Solver'], _site_path(root_names['Solver'])):
        if name in link_source:
            assert import_module(name)
            print(name)

# Generated at 2022-06-23 15:21:56.113593
# Unit test for function gen_api
def test_gen_api():
    pass



# Generated at 2022-06-23 15:22:05.980599
# Unit test for function loader
def test_loader():
    """Unit test."""
    import json

    # Load another package
    __import__('pyslvs', globals(), locals(), ('__version__',), 0)
    from pyslvs import __version__

    logger.info(f"Unit test for loader: v{__version__}")
    logger.info(f"Current directory: {__file__}")
    doc = loader('pyslvs', dirname(abspath(__file__)), True, 1, True)
    logger.info(f"Write result to: {abspath('pyslvs-test.json')}")
    with open('pyslvs-test.json', 'w+') as f:
        json.dump(doc, f, indent=2)

# Generated at 2022-06-23 15:22:07.301431
# Unit test for function gen_api
def test_gen_api():
    """Test if the `gen_api` works."""
    gen_api({'Test': 'test'})

# Generated at 2022-06-23 15:22:18.607420
# Unit test for function loader
def test_loader():
    import pytest
    from os import remove
    from shutil import rmtree
    from .path import resource_path
    from .importer import find_module
    from .parser import Parser

    test_path = resource_path("modules")[0]
    p = Parser.new(True, 2)

    def get_stub(index: str) -> str:
        path = join(test_path, "__pycache__", f"{index}.cpython-37.pyc")
        f = open(path, "rb")
        data = f.read()
        f.close()
        return data[8:].decode('utf-8')

    def get_pyi() -> str:
        return get_stub("test_import")


# Generated at 2022-06-23 15:22:24.768438
# Unit test for function loader
def test_loader():
    class FakeParser(object):
        def __init__(self):
            self.name = ''
            self.docstring = []

        def load_docstring(self, name, module):
            self.name = name
            self.docstring = module.__doc__

    p = FakeParser()
    # The module name in cwd
    root = 'cwd'
    name = 'fake_module'
    path = '/path/to/fake_module'
    _load_module(name, path, p)
    assert p.name == name
    assert p.docstring

# Generated at 2022-06-23 15:22:32.993457
# Unit test for function walk_packages
def test_walk_packages():
    logger.info("Unit test for function walk_packages")
    r = []
    for name, path in walk_packages('pyslvs', 'tests'):
        r.append(name)
        logger.info(f"{name} <= {path}")

# Generated at 2022-06-23 15:22:42.748872
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from types import ModuleType
    from .set_path import set_path
    from .parser import DocString
    from .logger import mute_logger, unmute_logger

    def global_test(name: str, path: str) -> ModuleType:
        mute_logger()
        m = module_from_spec(spec_from_file_location(name, path))
        doc = global_test.__doc__
        m.__doc__ = doc
        global_test.__doc__ = "Hello world!"
        m.__globals__ = globals()
        return m

    def test():
        """Test, test!
        """
        pass


# Generated at 2022-06-23 15:22:43.629713
# Unit test for function gen_api
def test_gen_api():
    gen_api({"Python": "python", "Python2": "python2"})

# Generated at 2022-06-23 15:22:46.273543
# Unit test for function walk_packages
def test_walk_packages():
    from .__init__ import __path__ as pkg_path
    from .__init__ import __name__ as pkg_name
    for name, path in walk_packages(pkg_name, pkg_path[0]):
        print(name, path)

# Generated at 2022-06-23 15:22:48.734729
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    from os import remove
    gen_api({'pyslvs': 'solvespace'}, dry=True)

    remove('docs/solvespace-api.md')

# Generated at 2022-06-23 15:22:56.298939
# Unit test for function loader
def test_loader():
    """Load API for unit test."""
    p = Parser(False, 1, False)
    for name, path in walk_packages("matplotlib", r"tests\matplotlib"):
        for ext in [".pyi", ".py"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
    print(p.compile())


__all__ = [
    "gen_api"
]

# Generated at 2022-06-23 15:22:59.756692
# Unit test for function loader
def test_loader():
    assert len(_site_path("numpy")) > 0
    import numpy
    assert len(_site_path("numpy")) > 0
    assert _load_module("numpy", numpy.__file__, Parser.new(False, 1, False))
    assert len(tuple(walk_packages("__main__", "./pyslvs_ui"))) > 0
    parser = Parser.new(False, 1, False)
    parser.parse("__main__", '"""Hello world!"""')
    assert parser.compile().strip() == '# Hello world!'

# Generated at 2022-06-23 15:23:06.453903
# Unit test for function loader
def test_loader():
    import pyslvs
    from pyslvs import __version__
    from pyslvs.extension import extension_modules
    from pyslvs import __pdoc__
    assert __pdoc__.api(__version__) is not None
    logger.debug(__pdoc__.api(__version__))
    assert extension_modules() is not None
    load = loader(pyslvs, _site_path(pyslvs), True, 2, False)
    assert load is not None
    logger.debug(load)

# Generated at 2022-06-23 15:23:14.440937
# Unit test for function walk_packages

# Generated at 2022-06-23 15:23:17.339030
# Unit test for function gen_api
def test_gen_api():
    import logging
    import sys
    logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    logger.info('=' * 12)
    gen_api({'test': 'pyslvs'}, 'test_data', dry=True)
    logger.removeHandler(handler)

# Generated at 2022-06-23 15:23:22.398621
# Unit test for function loader
def test_loader():
    """Test case for compiler.loader."""
    assert loader('collections', 'src')
    assert loader('collections', 'src', link=False)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:23:33.593390
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp:
        foo = 'foo'
        bar = 'foo.bar'
        foobar = 'foo.bar.foobar'
        __init__ = '__init__.py'
        mkdir(join(tmp, foo))
        mkdir(join(tmp, join(foo, 'bar')))
        mkdir(join(tmp, join(foo, 'bar', 'foobar')))
        for i in [foo, bar, foobar, join(foo, bar), join(foo, bar, foobar)]:
            _write(join(tmp, i + __init__), '')
        _write(join(tmp, foobar + '.py'), '')
        _write(join(tmp, foobar + '.pyi'), '')

# Generated at 2022-06-23 15:23:35.681998
# Unit test for function walk_packages
def test_walk_packages():
    for _, path in walk_packages('pyslvs', ".."):
        print(path)

# Generated at 2022-06-23 15:23:43.614292
# Unit test for function gen_api
def test_gen_api():
    from copy import copy
    from os import remove
    from os.path import isfile
    pwd = dirname(__file__)
    docs = gen_api({'API': 'pyslvs'}, pwd, prefix='api', link=False, level=2, dry=True)
    assert ''.join(docs).startswith('#' * 2 + ' ' + 'API API')
    docs = gen_api({'API': 'pyslvs'}, pwd, prefix='api', link=False, level=2)
    assert not ''.join(docs).startswith('#' * 2 + ' ' + 'API API')
    docs = gen_api({'API': 'pyslvs'}, pwd, prefix='api', link=False, level=2)

# Generated at 2022-06-23 15:23:48.982013
# Unit test for function loader
def test_loader():
    _site_path("pyslvs")
    names = [name for name, _ in walk_packages("pyslvs", _site_path("pyslvs"))]
    assert "pyslvs.__main__" in names
    assert "pyslvs_ui.main_window" in names



# Generated at 2022-06-23 15:23:59.272676
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    from unittest import TestCase, main
    from os import sep, mkdir, rmdir
    from os.path import isdir, join

    class Test(TestCase):

        def test_walk_packages(self):
            tmp = join('/', 'tmp', 'tmp_pkgs')

# Generated at 2022-06-23 15:24:08.522257
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import Mock, patch

    def walk(path: str) -> Iterator[tuple[str, list[str], list[str]]]:
        for p in (parent("a"), parent("a.b"), parent("a.b.c")):
            yield p, [], [p.split(".")[-1] + ".py"]

    with patch("sphinxcontrib.autoprogram.api_gen.walk", side_effect=walk):
        assert set(walk_packages("a", ".")) == {("a", "./a.py"), ("a.b", "./a/b.py"), ("a.b.c", "./a/b/c.py")}



# Generated at 2022-06-23 15:24:12.455461
# Unit test for function gen_api
def test_gen_api():  # pragma: no cover
    from sys import path as sys_path
    from os.path import dirname
    sys_path.append(dirname(__file__))
    import pyslvs
    gen_api({'Pyslvs': 'pyslvs'})

# Generated at 2022-06-23 15:24:17.441775
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import tempfile, shutil
    with tempfile.TemporaryDirectory() as tmpdir:
        # Make sample package
        # No docstring
        mod = tmpdir + '/mod.py'
        _write(mod, 'a = 0')
        # Only root docstring
        mod2 = tmpdir + '/mod2.py'
        _write(mod2, '"""root module""""')
        sub = tmpdir + '/mod2/sub.py'
        _write(sub, '"""module docstring"""')
        # Multiple inheritance
        mod3 = tmpdir + '/mod3.py'
        _write(mod3, '"""root module""""')
        sub = tmpdir + '/mod3/sub.py'
        _write(sub, '"""module docstring"""')
        sub2

# Generated at 2022-06-23 15:24:22.204194
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    # pylint: disable=import-error
    from pyslvs_ui.package.pyslvs_ui import entry_points
    assert entry_points["main"][0]._name.endswith(
        "pyqt5.QtWidgets.QApplication"
    )
    assert entry_points["widgets"][0]._name.endswith(
        "pyqt5.QtWidgets.QDialog"
    )
    assert entry_points["widgets"][1]._name.endswith(
        "pyqt5.QtWidgets.QAction"
    )
    assert entry_points["widgets"][2]._name.endswith(
        "pyqt5.QtWidgets.QWidget"
    )


# Generated at 2022-06-23 15:24:33.599676
# Unit test for function loader
def test_loader():
    """Package searching algorithm unit test."""
    from pkgutil import iter_modules
    p = Parser.new(True, 2, False)
    for _, name, is_pkg in iter_modules('test'):
        if is_pkg:
            for _, name, is_pkg in iter_modules(name, 'test.'):
                if is_pkg:
                    for _, name, is_pkg in iter_modules(name, 'test.'):
                        if is_pkg:
                            for _, name, is_pkg in iter_modules(name, 'test.'):
                                pass
                        else:
                            pass
                else:
                    pass
        else:
            pass
    p.compile()
    assert p._roots['test']['pyslvs_ui']['solver']['_solver']

# Generated at 2022-06-23 15:24:42.479091
# Unit test for function gen_api
def test_gen_api():
    import tempfile, shutil, os

    pwd = tempfile.gettempdir()
    sys_path.append(pwd)
    # Create test folder
    root_path = os.path.join(pwd, "root_example")
    os.mkdir(root_path)
    # Create test pkg
    (os.makedirs(os.path.join(root_path, "root_example", "sub_example"))
        .touch(os.path.join(root_path, "root_example", "sub_example", "__init__.py"))
        .touch(os.path.join(root_path, "root_example", "sub_example", "test1.py")))
    root_names = {"sPySlvsExam": "root_example"}

# Generated at 2022-06-23 15:24:51.447002
# Unit test for function walk_packages
def test_walk_packages():
    # Test for walking __init__.py and __init__-stubs.py
    init_path = abspath(join(dirname(__file__), '__init__.py'))
    init_paths = [(path, name) for name, path in walk_packages('pyslvs', '.')]
    assert init_path in init_paths
    # Test for walking modules
    assert any(path.startswith(abspath('.')) for _, path in init_paths)
    # Test for finding the site-packages path of "pyslvs"
    assert _site_path('pyslvs') in [path for _, path in init_paths]
    # Test for walking sub-modules
    sub_path = abspath(join(dirname(__file__), '.'))
    sub_paths

# Generated at 2022-06-23 15:24:55.492434
# Unit test for function gen_api
def test_gen_api():
    from .data import pyslvs_dict
    logs = gen_api(pyslvs_dict, f"{abspath(__file__).replace(__file__, '')}pyslvs")
    assert logs

# Generated at 2022-06-23 15:25:03.460732
# Unit test for function loader
def test_loader():
    """Test function of loader."""
    from os.path import dirname

    path = f"{dirname(__file__)}/hjson"
    p = Parser.new(True, 2, False)
    for name, path in walk_packages(path, path):
        assert name
        assert path
        ext = path[-4:]
        assert ext == ".pyi"
        assert path.startswith(f"{path}{path}")
        if isfile(path + ".py"):
            p.parse(name, _read(path + ".py"))
        p.parse(name, _read(path))
    # print(p.compile())

# Generated at 2022-06-23 15:25:13.544173
# Unit test for function loader

# Generated at 2022-06-23 15:25:23.747961
# Unit test for function walk_packages
def test_walk_packages():
    import time
    from os import remove
    from os.path import exists, basename

    # Remove all files
    for _, _, fs in walk("."):
        for f in fs:
            if basename(f).startswith("test_"):
                remove(f)

    # Simulate an API
    _write("test_base.pyi", "")
    _write("test_base.py", "")
    _write("test_c_base.py", "")
    _write("test_d.py", "")
    _write("test_e.py", "")
    _write("test_f.py", "")
    _write("test_f.pyi", "")
    _write("test_dir/__init__.py", "")

# Generated at 2022-06-23 15:25:30.737605
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from .parser import PEP561_SUFFIX
    from .logger import init_logger as _
    from . import __version__ as v
    from .conf import _conf_test_output
    _()
    logger.info(f"pyslvs version {v}")
    gen_api({'pyslvs': 'pyslvs'}, pwd=_conf_test_output, dry=False)
    logger.info("Test complete")



# Generated at 2022-06-23 15:25:39.382477
# Unit test for function gen_api
def test_gen_api():
    """Unit test generator API."""
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        assert len(gen_api({'Numpy': 'numpy'}, d)) == 1
        assert len(gen_api({'NO': 'NO'}, d)) == 0
        assert len(gen_api({'NO': 'NO'}, d, dry=True)) == 0
        assert len(gen_api({'Numpy': 'numpy', 'NO': 'NO'}, d)) == 1
        assert len(gen_api({'Numpy': 'numpy', 'NO': 'NO'}, d, dry=True)) == 1

# Generated at 2022-06-23 15:25:40.993108
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'lib': 'Lib'}, "")[0].strip()

# Generated at 2022-06-23 15:25:47.537904
# Unit test for function gen_api
def test_gen_api():
    """Test case for gen_api."""
    import sys
    sys_path.append("D:\\Github\\pyslvs")
    print(gen_api({
        'Pyslvs API': 'pyslvs',
        'Pyslvs UI API': 'pyslvs_ui',
    }, pwd="D:\\Github\\pyslvs", level=2))

# Generated at 2022-06-23 15:25:59.176175
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    # 1. [F] Not in the `sys.path`
    assert not list(walk_packages("pyslvs", "/dev"))
    # 2. [F] Not a package
    assert not list(walk_packages("pyslvs", __file__))
    # 3. [F] Not a valid package
    assert not list(walk_packages("pyslvs", "lib"))
    # 4. [P] Check for packages
    for name, path in walk_packages("pyslvs", "src"):
        assert name.startswith("pyslvs.")
        assert name.endswith(".__init__.pyi")
        assert path.startswith("src")
        assert not isfile(path)
    # 5. [F] Not a valid source
   

# Generated at 2022-06-23 15:26:00.129017
# Unit test for function loader
def test_loader():
    from .tests.loader import ttt
    assert ttt
    assert loader('ttt', dirname(ttt.__file__), True, 1, True)

# Generated at 2022-06-23 15:26:03.232829
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({"Pyslvs", "pyslvs"}, '', dry=True)
    for doc in docs:
        assert '## ' in doc
        assert '#' in doc

# Generated at 2022-06-23 15:26:10.122479
# Unit test for function loader
def test_loader():
    root_names = {'Pyslvs': 'pyslvs', 'SVGeo': 'svgeo'}
    pwd = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    prefix = os.path.join(pwd, 'test', 'api')
    gen_api(root_names, pwd, prefix=prefix, dry=True)

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:26:19.553248
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os.path
    import unittest
    if not os.path.exists('test_walk_packages.py'):
        print('File test_walk_packages.py not exist!')
        sys.exit(0)
    if not os.path.exists('test_walk_packages'):
        print('File test_walk_packages not exist!')
        sys.exit(0)
    class Test(unittest.TestCase):
        def test_walk_packages(self):
            import pkgutil
            def _walk(name, path):
                for f in pkgutil.walk_packages([path]):
                    if name in f.module_finder.files:
                        yield f.module_finder.files[name]

# Generated at 2022-06-23 15:26:23.803704
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("fake", "test_packages")) == [
        ('fake', 'test_packages/fake.py'),
        ('fake.bar', 'test_packages/fake/bar.py'),
        ('fake.foo', 'test_packages/fake/foo.py'),
    ]



# Generated at 2022-06-23 15:26:28.795174
# Unit test for function walk_packages
def test_walk_packages():
    _tmp = []

    def _test_function(name: str, path: str) -> None:
        _tmp.append([name, path])

    walk_packages('__foo__', './tests/test_packages')
    for item in _tmp:
        print(item)


if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-23 15:26:36.786183
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api()."""
    from unittest import TestCase
    from unittest.mock import patch
    from os import remove
    from shutil import rmtree
    from random import randint
    from .logger import logger_init
    from .utils import load_json
    from .settings import ROOT_PATH

    class LoaderTest(TestCase):
        """Something to test the API generator."""

        def setUp(self):
            """Initialize the logger and temporary files."""
            logger_init(__name__)
            self.tmp = 'tests'
            self.tmp_file = join(self.tmp, 'tmp.py')
            self.tmp_file_i = join(self.tmp, 'tmp.pyi')

# Generated at 2022-06-23 15:26:41.487554
# Unit test for function walk_packages
def test_walk_packages():
    class name:
        pass

    assert name.__module__ == '__main__'
    for ns, path in walk_packages(name.__module__, dirname(name.__file__)):
        assert name.__module__ == ns
        assert name.__file__.replace('.py', '').replace(sep, '.') == path

# Generated at 2022-06-23 15:26:49.746827
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    import pyslvs
    test_root = dirname(dirname(abspath(__file__)))
    for name, path in walk_packages("", test_root):
        assert find_spec(name) is not None
        assert isfile(path)
    for name, path in walk_packages("pyslvs", pyslvs.__path__[0]):
        assert find_spec(name) is not None
        assert isfile(path)
    assert 'pyslvs.kinematics' in root_names
    assert 'pyslvs' in root_names

# Generated at 2022-06-23 15:26:57.786080
# Unit test for function walk_packages
def test_walk_packages():
    import itertools


# Generated at 2022-06-23 15:27:04.584698
# Unit test for function loader
def test_loader():
    logger.info(loader('pyslvs', '/home/yuan/opt/lib/python3.8/site-packages',
                       link=False, level=1, toc=True))
    logger.info(loader('scipy', '/home/yuan/opt/lib/python3.8/site-packages',
                       link=False, level=1, toc=True))
    logger.info(loader('numpy', '/home/yuan/opt/lib/python3.8/site-packages',
                       link=False, level=1, toc=True))

# Generated at 2022-06-23 15:27:07.442601
# Unit test for function gen_api
def test_gen_api():
    print(
        gen_api(dict(root="solver", pwd=None, prefix="docs", link=True, level=1, toc=False, dry=False))
    )


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:27:19.342412
# Unit test for function gen_api
def test_gen_api():
    from os.path import isfile
    from shutil import rmtree
    from .parser import Parser
    import pyslvs

    p = Parser(True, 1, False)
    p.parse("pyslvs", _read("../pyslvs/__init__.py"))
    p.parse("pyslvs.assemble", _read("../pyslvs/assemble/__init__.py"))
    p.parse("pyslvs.exceptions", _read("../pyslvs/exceptions.py"))
    doc = p.compile()
    assert doc

    gen_api({'Pyslvs': 'pyslvs'}, '../', prefix='docs', level=3, toc=True)
    assert isfile('docs/pyslvs-api.md')
    r

# Generated at 2022-06-23 15:27:24.126758
# Unit test for function gen_api
def test_gen_api():
    """Test gen_api."""
    from .logger import logger, logger_setup
    from .argparser import argparser, parser_setup
    logger_setup(level='WARNING', max_len=35)
    args = argparser().parse_args('-D --link=false --level=3 pyslvs'.split())
    parser_setup(args, '/')
    logger.warning(gen_api({"PySLVS": "pyslvs"}, 'pyslvs'))


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:27:36.170597
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import shutil
    from tempfile import mkdtemp

    class Test(unittest.TestCase):

        def setUp(self):
            self.path = mkdtemp()
            self.root = "a.b"
            self.root_path = join(self.path, self.root)
            self.root_stub_path = join(self.path, self.root + PEP561_SUFFIX)
            self.mkdir(self.root_path)
            self.mkdir(self.root_stub_path)
            self.open(join(self.root_path, "c.py"), "def c(): pass")
            self.open(join(self.root_path, "d.pyi"), "def d() -> int: ...")

# Generated at 2022-06-23 15:27:42.004785
# Unit test for function loader
def test_loader():
    assert loader('pyslvs', dirname(__file__), False, 0, False)
    assert loader('pyslvs_ui', dirname(__file__), False, 0, False)
    assert loader('pyslvs', dirname(__file__), True, 1, False)
    assert loader('pyslvs_ui', dirname(__file__), True, 1, False)


# Generated at 2022-06-23 15:27:50.980492
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    import tempfile
    import shutil
    import sys
    import os

    print("test_walk_packages:")
    path = tempfile.mkdtemp()
    name = "mypackage"
    os.makedirs(os.path.join(path, name))
    os.makedirs(os.path.join(path, name + PEP561_SUFFIX))
    for root, _, fs in walk_packages(name, path):
        assert root.endswith(name)
        assert root.startswith(path)
        assert root[len(path):].endswith(name)
        assert fs[0].endswith(".py") or fs[0].endswith(".pyi")
        print(root, fs)

    shutil.rmtree

# Generated at 2022-06-23 15:28:03.004891
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os import path
    from shutil import rmtree
    from unittest import TestCase
    from .logger import logger

    class GenTest(TestCase):

        """Test cases for the package rtd_api."""

        def setUp(self):
            """Temporary directory."""
            self.dir = TemporaryDirectory()
            self.dir_path = self.dir.name
            sys_path.append(self.dir_path)
            self.site_path = path.join(self.dir_path, 'site-packages')
            mkdir(self.site_path)

        def tearDown(self):
            """Remove temporary directory."""
            rmtree(self.dir_path)

        def test_empty(self):
            """Empty root module."""

# Generated at 2022-06-23 15:28:12.050837
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from re import escape, search
    from shutil import rmtree

    # Init test directory
    with TemporaryDirectory() as temp:
        # Create test source code
        deep_path = "a" + sep + "b" + sep
        deep_name = "a.b.c"
        _write(join(temp, "__init__.py"), "")
        _write(join(temp, "a", "__init__.py"), "")
        _write(join(temp, "a", "b", "__init__.py"), "")
        _write(join(temp, deep_path, "c.py"), "from enum import Enum")
        _write(join(temp, deep_path, "c.pyi"), "def f(): ...")

        # Test load module

# Generated at 2022-06-23 15:28:16.048368
# Unit test for function walk_packages
def test_walk_packages():
    assert not list(walk_packages("", dirname(__file__)))
    assert len(list(walk_packages("tests", dirname(__file__)))) == 4

# Generated at 2022-06-23 15:28:26.160619
# Unit test for function loader
def test_loader():
    import sys
    parser = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', _site_path('pyslvs')):
        assert _load_module(name, path, parser)
    import pyslvs
    spec: object = find_spec(pyslvs.__name__)
    paths = spec.submodule_search_locations
    assert paths is not None
    assert len(paths) >= 1
    for path in paths:
        assert isdir(path)
        for root, _, files in walk(path):
            for f in files:
                if f.endswith(('.py', '.pyi')):
                    assert _load_module(parent(path), path, parser)
    sys.modules.pop('pyslvs')
    logger

# Generated at 2022-06-23 15:28:29.014576
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    doc = loader('pyslvs', '.', True, 1, True)
    logger.info(doc)

# Generated at 2022-06-23 15:28:30.571437
# Unit test for function gen_api
def test_gen_api():
    gen_api({'example': 'example'}, pwd='docs/example/lib', prefix='docs/example')

# Generated at 2022-06-23 15:28:32.502676
# Unit test for function loader
def test_loader():
    doc = loader('solvespace', '../solvespace', True, 1, True)
    assert 'API' in doc

# Generated at 2022-06-23 15:28:43.151472
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages"""
    # Test for walk_packages
    import tempfile
    def create_dummy_file(path: str, suffix: str = "") -> str:
        path = join(tempfile.gettempdir(), path)
        if not isdir(dirname(path)):
            mkdir(dirname(path))
        if isfile(path + suffix):
            return path + suffix
        with open(path + suffix, 'w+') as f:
            f.write(path)
        return path + suffix
    def remove_dummy_file(path: str, suffix: str = "") -> None:
        if isfile(path + suffix):
            remove(path + suffix)
    # Make a dummy file
    path1 = create_dummy_file("a.py")

# Generated at 2022-06-23 15:28:45.758022
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    with TemporaryDirectory() as tmpdir:
        gen_api({'numpy': 'numpy'}, Path(tmpdir).absolute().as_posix())

# Generated at 2022-06-23 15:28:54.393188
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as td:
        path = Path(td)
        path.mkdir(parents=True, exist_ok=True)
        (path / '__init__.py').touch()
        (path / '__init__.pyi').touch()
        (path / '__init__.pyc').touch()
        (path / 'module.py').touch()
        (path / 'module.pyi').touch()
        (path / 'module.pyc').touch()
        (path / 'module.so').touch()
        (path / 'hello.py').touch()
        (path / 'hello.pyi').touch()
        (path / 'hello.pyc').touch()
        (path / 'hello.so').touch()

# Generated at 2022-06-23 15:29:02.167906
# Unit test for function loader
def test_loader():
    res = loader("solvespace", "../solvespace/python", False, 1, False)
    assert '<a href="#solvespace.enum.color' in res
    assert '# <span id="solvespace.enum.color">class solvespace.enum.color' in res
    assert '<a href="#solvespace.enum.hsv_color' in res
    assert '# <span id="solvespace.enum.hsv_color">class solvespace.enum.hsv_color' in res
    assert res.count('solvespace') > 100

# Generated at 2022-06-23 15:29:12.310232
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    import tempfile
    path = tempfile.mkdtemp()
    p = Path(path)
    (p / 'a').mkdir(parents=True, exist_ok=True)
    (p / 'a' / 'b.py').touch()
    (p / 'a' / 'b').mkdir(exist_ok=True)
    (p / 'a' / 'b' / 'c.py').touch()
    (p / 'a' / 'b' / '__init__.py').touch()
    (p / 'a' / 'b' / '__init__.pyi').touch()
    assert [name for name, _ in walk_packages('a', path)] == ["a", "a.b", "a.b.c", "a.b"]

# Generated at 2022-06-23 15:29:18.828366
# Unit test for function gen_api
def test_gen_api():
    # Test import error
    assert not gen_api({"": "xxxxxxxxxxxxxxxxxx"})
    # Test not exist
    assert not gen_api({"": "this_is_not_exist"})
    # Test normal
    assert gen_api({"": "pyslvs"})
    # Test only generate markdown
    assert gen_api({"": "pyslvs"}, dry=True)
    # Test with site-packages path
    assert gen_api({"": "pyslvs"}, pwd=".")

# Generated at 2022-06-23 15:29:26.491819
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import approx
    from collections import Counter

    def test_package(name: str) -> None:
        """Test package walk."""
        c = Counter()
        for n, p in walk_packages(name, _site_path(name)):
            assert n.startswith(name)
            assert p.startswith(_site_path(name))
            if n.endswith('.__init__'):
                c['__init__'] += 1
            else:
                c[parent(n)] += 1
        if c['__init__'] > 0:
            assert c['__init__'] == approx(len(c) + 1)

    # Test some packages
    test_package('numpy')
    test_package('pandas')
    test_package('matplotlib')

# Generated at 2022-06-23 15:29:32.947046
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader('test.root', 'tests/samples', link=False, level=2, toc=False)
    assert (
r"""
## Class A

### __init__(a: int, b: int)

### func(c: int, d: int = 42)
""".strip() == doc.strip())
    assert not loader('test.root', 'tests/samples', True, 2, True)



# Generated at 2022-06-23 15:29:44.034052
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk package."""
    def _test_walk(name: str, path: str):
        """Test walk package."""