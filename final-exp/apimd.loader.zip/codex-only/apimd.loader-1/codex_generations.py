

# Generated at 2022-06-23 15:19:46.168678
# Unit test for function loader
def test_loader():
    from os import pardir
    from os.path import dirname
    from tempfile import TemporaryDirectory
    from shutil import copytree

    def _mock_path(dep, src, dst):
        copytree(join(src, dep), join(dst, dep))
        _write(join(dst, dep, '__init__.py'), """\
# -*- coding: utf-8 -*-

from .__dep__ import *
""")

    with TemporaryDirectory() as root:
        _mock_path("dep_1", pardir, root)
        _mock_path("dep_2", pardir, root)
        # Write mock module

# Generated at 2022-06-23 15:19:57.483414
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from unittest.mock import Mock
    from pyslvs import sys_path as mod_path
    from pyslvs import __file__ as pyslvs_path

    def test_import(root: str) -> None:
        """Test if the package is importable."""
        try:
            __import__(root)
        except ImportError:
            raise AssertionError(f"{root} can not be imported!")

    def test_write(root: str, title: str, pwd: str) -> None:
        """Test if the doc is writable."""
        mock = Mock()
        with mock:
            gen_api({title: root}, pwd, dry=True)
        assert mock.info.call_count > 0


# Generated at 2022-06-23 15:20:07.348791
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import exists, basename
    from zipfile import ZipFile
    from .logger import set_log_level

    set_log_level('error')

    name = __name__ + '.test_walk_packages'
    with TemporaryDirectory() as site_path:
        site_path, name = abspath(site_path), name.replace('.', sep)
        makedirs(join(site_path, 'foo', '__pycache__'))
        makedirs(join(site_path, 'bar'))
        makedirs(join(site_path, name))
        with open(join(site_path, name, '__init__.py'), 'w+'):
            pass

# Generated at 2022-06-23 15:20:17.239925
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    import pkgutil
    import pyslvs
    import pyslvs_ui as ui

    path = _site_path('pyslvs_ui')
    assert path
    assert pyslvs.__file__.startswith(path)
    assert ui.__file__.startswith(path)

    for name, path in pkgutil.walk_packages():
        print(name, path)

    for a, b in walk_packages('pyslvs_ui', path):
        print(a, b)

    # A hack that can't cost too much time
    for name, path in walk_packages('pyslvs', path):
        for a, b in walk_packages(name, path):
            print('.'.join([name, a]), b)

# Generated at 2022-06-23 15:20:28.667116
# Unit test for function walk_packages

# Generated at 2022-06-23 15:20:35.445271
# Unit test for function loader
def test_loader():
    """Unit test for loader."""
    from os.path import expanduser, join
    docs = gen_api(
        {'Subclassing': 'numpy.lib.mixins.numeric'},
        join(expanduser('~'), 'Anaconda3', 'envs', 'pyslvs'),
        dry=True,
        level=3
    )
    if not docs:
        raise RuntimeError(f"`{docs[0]}` is empty")


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:20:47.243867
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree
    from tempfile import mkdtemp
    from io import StringIO
    from pyslvs import sys_path_backup

# Generated at 2022-06-23 15:20:55.416179
# Unit test for function walk_packages
def test_walk_packages():
    path = 'D:\\Python'
    name = 'pyslvs'
    sub_name = 'solver'
    for n, p in walk_packages(name, path):
        print(repr(n))
        print(repr(p))
    for n, p in walk_packages(sub_name, _site_path(sub_name)):
        print(repr(n))
        print(repr(p))
    for n, p in walk_packages('os', 'D:\\Python\\Lib'):
        print(repr(n))
        print(repr(p))

# Generated at 2022-06-23 15:21:04.119463
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk_packages"""
    from tempfile import TemporaryDirectory
    import pkgutil
    import pyslvs as pys
    from .gen_api import walk_packages

    def _add_version(m):
        return m.split(".")[0] + f"-{pys.__version__}"

    with TemporaryDirectory() as dirname:
        # Add sys.path to pkgutil
        sys_path.append(dirname)
        # Create a empty dir path
        with open(join(dirname, '__init__.py'), 'w'):
            pass
        # Create some modules
        pkgutil.extend_path([dirname], 'pyslvs')
        pkgutil.write_bytecode(dirname, join(dirname, 'pyslvs/__init__.pyc'))

# Generated at 2022-06-23 15:21:05.366097
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"Pyslvs", "pyslvs"})

# Generated at 2022-06-23 15:21:09.577728
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import os
    import shutil
    from pyslvs_ui.package_info import PACKAGE_INFO
    os.chdir(os.path.dirname(__file__))
    gen_api({pkg[0]: pkg[1] for pkg in PACKAGE_INFO.items()}, dry=True)
    shutil.rmtree("docs")

# Generated at 2022-06-23 15:21:20.761740
# Unit test for function walk_packages
def test_walk_packages():
    r = []
    for name, path in walk_packages("abc", "tests/abc"):
        r.append((name, path))

# Generated at 2022-06-23 15:21:23.539639
# Unit test for function gen_api
def test_gen_api():
    assert gen_api(
        {'': 'site'},
        sep.join(__file__.split(sep)[:-2]),
        prefix='test',
        link=True,
        level=1,
        toc=True,
        dry=True
    )



# Generated at 2022-06-23 15:21:24.918138
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"Solverlib": "solverlib"}, "../..") is not None

# Generated at 2022-06-23 15:21:36.082827
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch, mock_open
    m = mock_open(read_data='spec = "TensorSpec"')
    with patch(__name__ + '.open', m, create=True):
        with patch(__name__ + '.isfile', lambda p: True):
            assert list(walk_packages('a', 'b')) == [('a.c', 'b/a/c')]
            assert list(walk_packages('a', 'b')) == [('a.c.d', 'b/a/c/d')]
            assert list(walk_packages('a', 'b')) == [('a.c', 'b/a/c-stubs')]

# Generated at 2022-06-23 15:21:44.695971
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory(prefix='pyslvs_doc') as path:
        # Create the package directory
        mkdir(join(path, 'test_pkg'))
        mkdir(join(path, 'test_pkg/subpkg'))
        # Create the package init file
        open(join(path, 'test_pkg/__init__.py'), 'w').close()
        open(join(path, 'test_pkg/subpkg/__init__.py'), 'w').close()
        # Create the python file
        doc = '"""Test module."""\n\n\nclass Test:\n    """Test class."""\n'
        _write(join(path, 'test_pkg/subpkg/test.py'), doc)
        # Create the stub file

# Generated at 2022-06-23 15:21:56.354048
# Unit test for function gen_api
def test_gen_api():
    from os.path import isfile
    from pyslvs_ui.package import __file__ as pyslvs_ui_file

    def test_gen(root_names: dict[str, str]):
        docs = gen_api(
            root_names,
            dirname(abspath(pyslvs_ui_file)),
            prefix="test_api",
            dry=True
        )
        assert all(isinstance(i, str) for i in docs)
        assert all(i.startswith("# API") for i in docs)
        assert all("### Class" in i for i in docs)
        assert all("### Static Method" in i for i in docs)
        assert all("### Method" in i for i in docs)


# Generated at 2022-06-23 15:21:57.984919
# Unit test for function walk_packages
def test_walk_packages():
    print(walk_packages('test_walk_packages', 'pyslvs_ui/doc/test/packages'))

# Generated at 2022-06-23 15:22:04.497894
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from pkgutil import walk_packages
    class Test(TestCase):
        """Test the walk packages function."""
        def test_basic(self):
            self.assertEqual(
                walk_packages('test', 'tests/test_data').__next__(),
                ('test.func', 'tests/test_data/test/func.py')
            )
    main()

# Generated at 2022-06-23 15:22:13.748980
# Unit test for function gen_api
def test_gen_api():
    import shutil
    import subprocess
    with subprocess.Popen(
        ['python3', '-m', 'pyslvs_ui', '--version'],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    ) as proc:
        v = proc.stdout.read()
    gen_api(
        {
            'Package UI': 'pyslvs_ui',
            'Package OpenCV': 'pyslvs_ui.cv',
            'Package PIL': 'pyslvs_ui.pil',
            'Package Pyslvs': 'pyslvs',
        },
        dry=True
    )

# Generated at 2022-06-23 15:22:16.431012
# Unit test for function loader
def test_loader():
    doc = loader("pyslvs", "pyslvs", False, 0, False)
    assert doc
    assert r"\b[0-9.]*\b" in doc



# Generated at 2022-06-23 15:22:19.356791
# Unit test for function gen_api
def test_gen_api():
    d = {
        'name': 'path'
    }
    s = gen_api(d)
    assert len(s) == 1

# Generated at 2022-06-23 15:22:23.210792
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"test": "test"}) == []
    assert find_spec("test") is not None
    assert gen_api({"test": "test"}) == [
        '# API\n\n## test\n\n# test.unit_test\n\n'
        '> A unit test module.'
    ]

# Generated at 2022-06-23 15:22:32.231458
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from tempfile import TemporaryDirectory
    from shutil import copy2
    from pkg_resources import iter_entry_points

    class MyException(Exception):
        pass

    with TemporaryDirectory() as d:
        # Create a fake directory
        copy2('pyslvs/core.py', d)
        spec = find_spec(module_name='pyslvs', path=d)
        if spec is not None:
            raise MyException('dont run this function in unit test')

        # Test the function
        doc = loader('pyslvs', d, link=True, level=3, toc=True)
        print(doc)

        # Test the entry point

# Generated at 2022-06-23 15:22:41.829419
# Unit test for function walk_packages
def test_walk_packages():
    """Test for the walk packages function."""
    from .test_parser import tmp_path
    from pkgutil import find_loader
    import_path = abspath('./import_test')
    path = join(tmp_path, import_path)
    mkdir(path)
    # Create package
    mkdir(join(path, 'test_package'))
    _write(join(path, 'test_package', '__init__.py'), '')
    _write(join(path, 'test_package', '__main__.py'), 'import test')
    # Create module
    _write(join(path, 'test_module.py'), 'import test')
    # Create extension
    _write(join(path, 'test_extension.so'), 'import test')
    # Create script

# Generated at 2022-06-23 15:22:47.121648
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile

    # Make a temporary directory
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = abspath(tmpdir)
        # Create a '__init__.py'
        open(join(tmpdir, '__init__.py'), 'w+').close()
        # Create a '__init__.pyi'
        open(join(tmpdir, '__init__.pyi'), 'w+').close()
        # Create a 'foo.py'
        open(join(tmpdir, 'foo.py'), 'w+').close()
        # Create a 'foo.pyi'
        open(join(tmpdir, 'foo.pyi'), 'w+').close()
        # Create a 'foo.c'
        open(join(tmpdir, 'foo.c'), 'w+').close()


# Generated at 2022-06-23 15:22:53.732323
# Unit test for function walk_packages
def test_walk_packages():
    from .__init__ import __name__ as pyslvs_name
    from .path import __name__ as pyslvs_path_name
    from .network import __name__ as pyslvs_network_name
    from .core import __name__ as pyslvs_core_name
    from .core import _core_name
    from .core import _core_name as pyslvs_core__core_name
    pyslvs_path_name
    pyslvs_network_name
    pyslvs_core_name
    pyslvs_core__core_name
    pyslvs_name
    _core_name
    walk_packages(pyslvs_name, abspath('..'))
    # Load the extension module to get the docstring by `inspect`
    _load_

# Generated at 2022-06-23 15:22:57.913952
# Unit test for function gen_api
def test_gen_api():
    root_name = {"Test":"test"}
    pwd = "lib"
    prefix = 'docs'
    link = True
    level = 1
    toc = False
    dry = False
    gen_api(root_name, pwd, prefix = prefix, link = link, level = level, toc = toc, dry = dry)


# Generated at 2022-06-23 15:23:07.621452
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy2
    with TemporaryDirectory() as temp_dir:
        copy2('pyslvs_ui/__init__.py', join(temp_dir, 'pyslvs_ui.py'))
        copy2('pyslvs_ui/__init__.pyi', join(temp_dir, 'pyslvs_ui.pyi'))
        copy2('test.py', join(temp_dir, 'test.py'))

# Generated at 2022-06-23 15:23:12.671750
# Unit test for function gen_api
def test_gen_api():
    import os
    packge_name = "Pyslvs"
    root_names = {packge_name: packge_name}
    pwd = os.path.dirname(__file__)
    output_file = f"{os.path.join(pwd, 'test_api.md')}"
    logger.info("=== Test for function gen_api(...):")
    gen_api(root_names, pwd, prefix=output_file, dry=True)

# Generated at 2022-06-23 15:23:16.006910
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('test', dirname(abspath(__file__))):
        logger.debug(f"{name} <= {path}")


if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-23 15:23:22.851819
# Unit test for function walk_packages
def test_walk_packages():
    p = Parser.new(False, 1, False)
    root_names = {
        "VPM": "pyslvs",
        "VPM-UI": "pyslvs_ui",
        "VPM-qrcode": "pyslvs_qrcode",
    }
    walk_packages(root_names["VPM"], _site_path(root_names["VPM"]))

# Generated at 2022-06-23 15:23:25.987127
# Unit test for function gen_api
def test_gen_api():
    """Run the API generator for test."""
    gen_api({"SOLVESYS": "pyslvs", "SOLVESYS LIB": "pyslvs_lib"}, dry=True)

# Generated at 2022-06-23 15:23:27.979173
# Unit test for function loader
def test_loader():
    import doctest
    from .parser import Parser
    doctest.testmod(Parser, verbose=False)

# Generated at 2022-06-23 15:23:40.099598
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import unittest
    import pytest

    @pytest.fixture
    def loader_test_prepare():
        import os
        orig_path = os.getcwd()
        root = 'test'
        path = os.path.join(orig_path, root)
        os.chdir(path)
        with open('test/__init__.py', 'w'):
            pass
        with open('test/test.pyi', 'w'):
            pass
        with open('test/test.py', 'w'):
            pass
        yield
        os.chdir(orig_path)
        os.remove(os.path.join(path, '__init__.py'))

# Generated at 2022-06-23 15:23:47.541480
# Unit test for function gen_api
def test_gen_api():
    from unittest.mock import patch
    from sys import path as _path
    from os.path import join as _join
    from tempfile import TemporaryDirectory

    def _gen_api(
            root_names: dict[str, str],
            pwd: Optional[str] = None,
            *,
            prefix: str = 'docs',
            link: bool = True,
            level: int = 1,
            toc: bool = False,
            dry: bool = False
    ) -> Sequence[str]:
        """Generate API. All rules are listed in the readme."""
        if pwd is not None:
            _path.append(pwd)
        p = Parser.new(link, level, toc)

# Generated at 2022-06-23 15:23:49.618380
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-23 15:23:53.112346
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    assert sorted(walk_packages('a', 'test')) == [
        ('a.b', 'test/a/b.py'),
        ('a.b.c', 'test/a/b/c.py')
    ]

# Generated at 2022-06-23 15:23:57.773390
# Unit test for function walk_packages
def test_walk_packages():
    path = abspath(dirname(__file__))
    assert all('pyslvs_ui' in p for p in walk_packages('pyslvs_ui', path))
    assert all('pyslvs_ui' not in p for p in walk_packages('pyslvs', path))

# Generated at 2022-06-23 15:24:06.856714
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os import getcwd, chdir
    from shutil import copy
    cwd = getcwd()
    with TemporaryDirectory() as temp_dir:
        docs_a = gen_api(
            {
                'Statsmodels': 'statsmodels',
                'Scikit-learn': 'sklearn',
            },
            temp_dir,
            prefix=temp_dir+'/api',
            dry=True,
        )
        assert docs_a[0][:12] == '############'
        docs_a = list(map(lambda x: '#' in x, docs_a[0].splitlines()))
        assert docs_a == [True, True, True, True, True, True, True, True, True, True]
        assert len(docs_a) == 10

# Generated at 2022-06-23 15:24:18.765751
# Unit test for function walk_packages
def test_walk_packages():
    from .gui.settings import get_temp_dir
    import subprocess
    from typing import List, Tuple
    from os.path import isfile

    def remove(items: List[str]) -> None:
        for item in items:
            if isfile(item):
                subprocess.call(['rm', item])
            else:
                subprocess.call(['rmdir', item])


# Generated at 2022-06-23 15:24:26.500607
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from subprocess import run
    with TemporaryDirectory() as temp:
        docs = gen_api({'test': 'pyslvs_test'}, temp, dry=True, prefix='.')
        assert len(docs) == 1
        assert isdir('./docs')
        assert isdir('./docs/pyslvs-test')
        run(['rm', '-r', './docs'])
    with TemporaryDirectory() as temp:
        docs = gen_api({'test': 'pyslvs'}, temp, dry=True, prefix='.')
        assert len(docs) == 1
        assert isdir('./docs')
        assert isdir('./docs/pyslvs')
        run(['rm', '-r', './docs'])

# Generated at 2022-06-23 15:24:33.752815
# Unit test for function walk_packages
def test_walk_packages():
    with open("test", 'w') as f:
        import sys
        f.write("test_test_test")
    with open("test.py", 'w') as f:
        import sys
        f.write("test_test")
    with open("test.pyi", 'w') as f:
        import sys
        f.write("test_test")
    for doc in walk_packages("test", "."):
        print(doc)
    return True

# Generated at 2022-06-23 15:24:35.256861
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'pyslvs': 'pyslvs'})

# Generated at 2022-06-23 15:24:38.527887
# Unit test for function loader
def test_loader():
    test_dir = join(dirname(__file__), '..', 'tests', 'module')
    assert sys_path[-1] == abspath(test_dir)
    assert loader("foo", test_dir, True, 1, False)
    assert loader("foo", test_dir, False, 1, False)

# Generated at 2022-06-23 15:24:43.183418
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'path',
        help='Path of PEP 561 compatible site-packages'
    )
    args = parser.parse_args(sys.argv[1:])
    for n, p in walk_packages('pyslvs', args.path):
        print(f"{n} -> {p}.py")

# Generated at 2022-06-23 15:24:51.818739
# Unit test for function gen_api
def test_gen_api():
    """Test."""
    # pylint: disable=import-outside-toplevel
    from pyslvs_ui import __file__ as path
    from .test_compiler import example_class

    # Without stub
    doc = loader('example', dirname(path), level=3, toc=True)
    assert example_class in doc
    assert "torch" not in doc

    class A:
        """Test."""

    class C:
        """C."""

        @staticmethod
        def f(a: A):
            """A -> B."""

    doc = loader('example', dirname(path), level=3, toc=True)

    assert "torch" in doc
    assert "tuple" in doc
    assert "A" not in doc
    assert "C" in doc

# Generated at 2022-06-23 15:25:02.239572
# Unit test for function walk_packages
def test_walk_packages():
    """Test the walk_packages."""
    import math
    assert parent('a.b') == 'a'
    assert parent('.a.b') == '.a'
    assert tuple(walk_packages('math', '.')) == (('math', './math'), ('math.e', './math/e'), ('math.nan', './math/nan'), ('math.nan.hoge', './math/nan/hoge'))
    assert tuple(walk_packages('math', './math')) == (('math', './math'), ('math.e', './math/e'), ('math.nan', './math/nan'), ('math.nan.hoge', './math/nan/hoge'))

# Generated at 2022-06-23 15:25:12.311967
# Unit test for function loader
def test_loader():
    """Function test for loader."""
    from pathlib import Path
    from pkgutil import get_data
    from .parser import parent, Parser
    from .api_tree import get_api_root
    from .meta import __doc__ as doc, __version__ as version
    p = Parser.new(link=True, level=1, toc=False)
    p.parse(parent(__name__), doc)
    p.parse(parent(getattr(get_api_root, '__module__', '?')), get_api_root.__doc__)
    p.parse(parent(getattr(get_data, '__module__', '?')), get_data.__doc__)
    p.parse(parent(getattr(Path, '__module__', '?')), Path.__doc__)
    p.parse

# Generated at 2022-06-23 15:25:15.901395
# Unit test for function gen_api
def test_gen_api():
    assert isdir('docs')
    assert not isdir('docs-unit')
    assert gen_api({
        'UrScript': 'ur_script',
        'Pyslvs': 'pyslvs',
    })
    assert isdir('docs-unit')

# Generated at 2022-06-23 15:25:21.958290
# Unit test for function walk_packages
def test_walk_packages():
    from .common import data_dir
    from json import dumps
    print('test_walk_packages:')
    print(dumps(list(walk_packages(
        "PyQt5",
        join(data_dir, "site-packages")
    )), indent=4))
    print(dumps(list(walk_packages(
        "pyslvs",
        join(data_dir, "site-packages")
    )), indent=4))

# Generated at 2022-06-23 15:25:25.290415
# Unit test for function gen_api
def test_gen_api():
    gen_api({"SciPy": "scipy"}, "/home/yuan/Anaconda3/lib/python", dry=True)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:25:36.557190
# Unit test for function walk_packages
def test_walk_packages():
    name = "pyslvs_ui"
    path = _site_path(name)

# Generated at 2022-06-23 15:25:40.815502
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    sys.path.append(".")
    data = walk_packages('test', '.')
    assert ('test.__init__', './test/__init__.py') in data
    assert ('test.sub', './test/sub/__init__.py') in data
    assert ('test.sub.subsub', './test/sub/subsub/subsubsub.py') in data
    assert ('test.sub.subsub_subsubsub', './test/sub/subsub/subsubsub.py') in data
    assert ('test.sub.subsubsub_subsubsub', './test/sub/subsub/subsubsub/subsubsubsub/__init__.py') in data

# Generated at 2022-06-23 15:25:50.577421
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    # Generate empty document
    assert loader("", "", True, 1, True) == ""
    # Repository
    assert loader(
        "sisl", "sisl", True, 1, True
    ).startswith(
        "# sisl\n\n"
    )
    # Module
    assert loader(
        "gvar", "gvar", True, 1, True
    ).startswith(
        "# gvar\n\n"
    )
    # Package
    assert loader(
        "pylvs", "pylvs/pylvs", True, 1, True
    ).startswith(
        "# pylvs\n\n"
    )

# Generated at 2022-06-23 15:26:02.178523
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import tempfile
    import shutil
    from io import StringIO
    from .capture import capture_stdout

    tmp_dir = tempfile.mkdtemp()
    root = join(tmp_dir, 'root')
    mkdir(root)
    mkdir(join(root, '__pycache__'))
    mkdir(join(root, 'subroot'))
    mkdir(join(root, 'subroot', 'subsubroot'))
    mkdir(join(root, 'subroot', 'subsubroot', 'subsubsubroot'))

    # Python source
    _write(join(root, '__init__.py'), 'def func_1(): pass\n')
    _write(join(root, 'subroot', '__init__.py'), 'def func_2(): pass\n')

# Generated at 2022-06-23 15:26:13.970272
# Unit test for function loader
def test_loader():
    from os import getcwd
    from tempfile import gettempdir
    from shutil import rmtree
    from importlib.util import find_spec
    from .test_tools import test_functions, create_dir, create_files

    # Prepare
    if find_spec('pyslvs_ui') is None:
        logger.warning('pyslvs_ui can not be loaded.')
        return 0

    def test_clean():
        try:
            rmtree(tmp_path)
        except FileNotFoundError:
            pass

    def gen_doc(root: str, link: bool, toc: bool, level: int) -> str:
        return loader(root, tmp_path, link, level, toc).strip()

    logger.info('Test function "loader"')


# Generated at 2022-06-23 15:26:24.878468
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from os.path import dirname
    from importlib import reload
    import pyslvs_ui
    reload(pyslvs_ui)
    logger.debug(f"{dirname(pyslvs_ui.__file__)} =?= {dirname(__file__)}")
    assert dirname(pyslvs_ui.__file__) == dirname(__file__)
    doc = loader("pyslvs_ui", _site_path("pyslvs_ui"), True, 1, True)
    logger.info('=' * 12)
    logger.info(doc)
    assert pyslvs_ui.__all__ == ['app', 'app_version']
    assert doc
    assert '### Base`' in doc
    assert '### Widget`' in doc

# Generated at 2022-06-23 15:26:33.724633
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""

# Generated at 2022-06-23 15:26:43.486307
# Unit test for function walk_packages

# Generated at 2022-06-23 15:26:52.400233
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from pytest import raises
    from os import makedirs, remove
    from os.path import join, sep

    root = 'test' + sep + 'imps' + sep + 'pkg' + sep + 'a'
    a, ab, abc, b, bd, d = (
        join(root, f) for f in ('a.py', 'a.b.py', 'a.b.c.py', 'b.py', 'b.d.py', 'd.py')
    )

    # Case 1
    # Structure:
    # - root
    #   - a/a.py
    #   - a/b/c.py
    #   - b/b.py
    #   - b/d.py
    #   - d.py
   

# Generated at 2022-06-23 15:27:02.809026
# Unit test for function loader
def test_loader():
    from os.path import dirname, join
    from .parser import Parser
    from .api_parser import API_INFO
    import pyslvs_ui
    p = Parser.new(True, 3, True)
    p.parse('pyslvs_ui', API_INFO)
    p.parse('pyslvs_ui.__main__', API_INFO)
    p.parse('pyslvs_ui.io', API_INFO)
    p.parse('pyslvs_ui.io.exprtk_types', API_INFO)
    p.parse('pyslvs_ui.pyslvs', API_INFO)
    p.parse('pyslvs_ui.pyslvs.__main__', API_INFO)

# Generated at 2022-06-23 15:27:04.980710
# Unit test for function gen_api
def test_gen_api():
    test_dict = {'aaa': 'bbb',}
    gen_api(test_dict)

# Generated at 2022-06-23 15:27:10.957961
# Unit test for function walk_packages
def test_walk_packages():
    from json import loads
    from os import listdir
    from os.path import join

    def walk_packages(name: str, path: str) -> Iterator[tuple[str, str]]:
        return [i[0] for i in gen_api({'test': name}, path).items()]

    def _test(name: str) -> None:
        path = join('tests', 'test_data', name)
        docs = walk_packages(name, path)
        with open(join(path, 'test.json'), 'r') as f:
            assert loads(f.read()) == docs

    for f in listdir('tests/test_data'):
        if f not in ['__pycache__']:
            _test(f)

# Generated at 2022-06-23 15:27:13.857192
# Unit test for function gen_api
def test_gen_api():
    assert not gen_api({})
    assert len(gen_api({'Pyslvs': 'pyslvs'})) == 1

# Generated at 2022-06-23 15:27:23.401207
# Unit test for function walk_packages
def test_walk_packages():
    def assert_walk_packages(name: str, path: str, result: tuple[str, str]) -> None:
        assert tuple(walk_packages(name, path)) == result


# Generated at 2022-06-23 15:27:28.429500
# Unit test for function loader
def test_loader():
    def docstring(name: str, doc: str) -> str:
        """Get a docstring from the module."""
        return f"_{name}: {doc}"

    class Loader:

        """Mock importlib.abc.Loader."""

        @staticmethod
        def exec_module(m: str) -> None:
            """Mock exec_module."""
            pass

    class Spec:

        """Mock importlib.machinery.ModuleSpec."""

        def __init__(self, name: str, loader: Loader) -> None:
            """Mock init."""
            self.name = name
            self.loader = loader

    class M:

        """Mock module for importlib.module_from_spec."""

        pass

    # Module list:
    #     module  :  docstring

# Generated at 2022-06-23 15:27:31.871167
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import root_names, pwd
    from .test import TEST_DIR
    print(gen_api(root_names, pwd, prefix=TEST_DIR))

# Generated at 2022-06-23 15:27:35.710922
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from timeit import default_timer as timer
    from tempfile import TemporaryDirectory
    from pathlib import Path

    logger.info("Test for function loader")

# Generated at 2022-06-23 15:27:46.931953
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import sys
    import shutil
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        sys_path.append(temp_dir)

        os.mkdir(os.path.join(temp_dir, 'test'))
        os.mkdir(os.path.join(temp_dir, 'test', 'a'))
        with open(os.path.join(temp_dir, 'test', 'a', 'b.py'), 'w') as file:
            file.write('pass')
        for name, path in walk_packages('test', temp_dir):
            assert name == 'test.a.b'
            assert path == os.path.join(temp_dir, 'test', 'a', 'b')


# Generated at 2022-06-23 15:27:48.030767
# Unit test for function loader
def test_loader():
    """Unit test."""
    doc = loader("pyslvs", "pyslvs", True, 1, False)
    print(doc)
    assert doc.strip()

# Generated at 2022-06-23 15:27:49.643134
# Unit test for function gen_api
def test_gen_api():
    assert isinstance(gen_api({'pyslvs': 'pyslvs'}), list)

# Generated at 2022-06-23 15:28:01.339492
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('tstpkg', './tests')) == []

# Generated at 2022-06-23 15:28:09.434487
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from os import chdir, getcwd
    from shutil import rmtree
    from tempfile import mkdtemp
    from pkg_resources import resource_filename
    from unittest import TestCase, main as unittest_main

    def get_test_api_docs() -> Iterator[str]:
        chdir(mkdtemp())

# Generated at 2022-06-23 15:28:14.530926
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .solver.constraint import Constraint
    from .solver.constraint_link import ConstraintLink
    from .solver.constraint_link_cutter import ConstraintLinkCutter
    from .solver.constraint_link_changer import ConstraintLinkChanger
    from .solver.constraint_link_intersection import ConstraintLinkIntersection
    from .solver.constraint_link_puller import ConstraintLinkPuller
    from .solver.constraint_link_mapper import ConstraintLinkMapper
    from .solver.constraint_link_mapper import MapperSetup
    from .solver.constraint_shape import ConstraintShape
    from .solver.constraint_shape import Constr

# Generated at 2022-06-23 15:28:18.501051
# Unit test for function walk_packages
def test_walk_packages():
    site_path = _site_path('numpy')
    assert site_path != ""
    names = [name for name, _ in walk_packages('numpy', site_path)]
    assert len(names) > 5
    assert names[0] == "numpy"

# Generated at 2022-06-23 15:28:25.160301
# Unit test for function walk_packages
def test_walk_packages():
    """Test the walk_packages function."""
    walked = list(walk_packages('django', '/home/yuan/Python/3.7/lib/python3.7/site-packages'))
    assert 'django.utils.translation' in [i[0] for i in walked]
    assert '/home/yuan/Python/3.7/lib/python3.7/site-packages/django/utils/translation' in [i[1] for i in walked]


# Generated at 2022-06-23 15:28:29.337413
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    pwd = abspath(dirname(__file__))
    assert loader('pyslvs', pwd, link=False, level=1, toc=False) != ""
    assert loader('non-exist', pwd, link=False, level=1, toc=False) == ""

# Generated at 2022-06-23 15:28:31.573882
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    assert len(loader("pyslvs", "pyslvs", False, 2, False))

# Generated at 2022-06-23 15:28:34.529326
# Unit test for function loader
def test_loader():
    """Test loader."""
    assert loader("solvespace", "./solvespace", False, 1, False).startswith(
        "# Solvespace"
    )

# Generated at 2022-06-23 15:28:45.329860
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    # Setup
    from copy import copy
    from os.path import dirname, join
    from sys import path as sys_path

    sys_path.append(dirname(dirname(dirname(dirname(__file__)))))
    from pkg_resources import find_distributions
    from pyslvs import __title__, __version__
    from pyslvs_ui.info import package_path
    from pyslvs import root_name as pyslvs_root_name

    info = find_distributions(package_path)[0].metadata
    name = info['Name']
    sys_path.append(join(package_path, name, name))

# Generated at 2022-06-23 15:28:47.959265
# Unit test for function gen_api
def test_gen_api():
    """Test for unit test."""
    from .parser import item_ref, link_ref
    doc = gen_api({'Test': 'test_api'}, '.', dry=True)
    assert item_ref(parent(__file__)).strip() in doc[0]
    assert link_ref('test_api.test_unit', 'test_unit') in doc[0]

# Generated at 2022-06-23 15:28:50.155449
# Unit test for function gen_api
def test_gen_api():
    import sys
    print(gen_api(dict(a='a'), sys.exec_prefix+'/site-packages',), end='')

# Generated at 2022-06-23 15:28:57.630139
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function `walk_packages`."""
    from .parser import parent

    def wp(name: str) -> Iterator[tuple[str, str]]:
        yield from walk_packages(name, 'tests')

    assert list(wp('test_compiler')) == \
        [('test_compiler.test_walk_packages', 'tests/test_compiler/test_walk_packages.py'),
         ('test_compiler.test_walk_packages', 'tests/test_compiler/test_walk_packages.pyi')]
    assert parent(join('tests/test_compiler/test_walk_packages.pyi')) == \
        'tests/test_compiler/test_walk_packages.pyi'

# Generated at 2022-06-23 15:29:08.823348
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import glob
    import shutil
    from tempfile import TemporaryDirectory
    from pathlib import Path
    d = Path(__file__).parent
    # Prepare the testing files
    with TemporaryDirectory() as temp:
        temp = Path(temp)

# Generated at 2022-06-23 15:29:18.931837
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil
    import tempfile
    def make_package(name: str, parent: str) -> None:
        os.mkdir(os.path.join(parent, name))
        with open(os.path.join(parent, name, f'__init__.py'), 'w'):
            pass
        with open(os.path.join(parent, name, 'test.py'), 'w') as f:
            f.write('def foo():\n    """A function."""\n    pass\n')
        with open(os.path.join(parent, name, 'test.pyi'), 'w') as f:
            f.write('def foo() -> None:\n    """A function."""\n')

# Generated at 2022-06-23 15:29:26.520797
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import normpath
    from .logger import logger
    from .compiler import walk_packages
    logger.set_level(0)
    logger.info(f"Root is: {sys_path[0]}")
    logger.info(f"Output should be 'a.b.c': {normpath('a/b/c')}")
    logger.info(f"Output should be 'a.b.d': {normpath('a/b/d')}")
    logger.info(f"Output should be 'a.b.d': {normpath('a/b/d')}")
    logger.info(f"Output should be 'a.b.e': {normpath('a/b/e')}")

# Generated at 2022-06-23 15:29:30.858232
# Unit test for function gen_api
def test_gen_api():
    import tempfile, os
    from os.path import isfile
    from pylvs import to_token

    def gen_file(f_name: str, doc: str) -> str:
        with open("t" + f_name, 'w+') as f:
            f.write(doc)
        return "t" + f_name

    def gen_root(f_name: str) -> str:
        root = "root"
        with open(gen_file(f_name, f"# Root API\n\n{root}"), 'r') as f:
            return f.read().split("\n")[-1].split(" ")[-1]

    with tempfile.TemporaryDirectory() as tmp:
        old_pwd = os.getcwd()
        os.chdir(tmp)

# Generated at 2022-06-23 15:29:42.525532
# Unit test for function loader
def test_loader():
    import pkgutil

    def name2path(name: str) -> str:
        return pkgutil.get_loader(name).filename

    def run_loader(pwd: str, name: str) -> str:
        return loader(name, pwd, False, 1, False)

    def make_sphinx(name: str) -> str:
        path = parent(name2path(name))
        s = find_spec(name)
        if s is None or s.submodule_search_locations is None:
            return ""
        return parent(s.submodule_search_locations[0])

    assert name2path('PyQt5') != name2path('PyQt5.QtWidgets')
    assert name2path('pyslvs') != name2path('pyslvs.system')
