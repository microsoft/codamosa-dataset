

# Generated at 2022-06-23 15:19:46.237204
# Unit test for function gen_api
def test_gen_api():
    """Test case for function gen_api."""
    from tempfile import TemporaryDirectory
    from subprocess import call
    from os import path
    from shutil import rmtree
    temp_dir = TemporaryDirectory()

# Generated at 2022-06-23 15:19:57.536813
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from random import randint
    from .utils import uncompiled_api

    with TemporaryDirectory() as temp:
        a = gen_api({"Solve": "solve", "Solver": "solver"}, temp, dry=True)
        root_api = uncompiled_api(a[0])
        solver_api = uncompiled_api(a[1])
        assert len(root_api) == 292
        assert len(solver_api) == 31
        m = len(root_api)
        n = len(solver_api)
        for i in range(100):
            x, y = randint(0, m - 1), randint(0, n - 1)
            assert root_api[x][0] == solver_api[y][0]


# Generated at 2022-06-23 15:19:59.712805
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'test': 'test'}, '.')
    assert gen_api({'test': 'test'}, '.', dry=True)

# Generated at 2022-06-23 15:20:08.803149
# Unit test for function gen_api
def test_gen_api():
    from unittest import TestCase, mock, main
    from unittest.mock import patch

    class GenAPITest(TestCase):

        @mock.patch('pkgutil.walk_packages')
        def test_no_root(self, mock_walk: mock.Mock) -> None:
            mock_walk.return_value = [('', '', '')]
            output = gen_api({})
            self.assertListEqual(output, [])


# Generated at 2022-06-23 15:20:17.837294
# Unit test for function walk_packages
def test_walk_packages():
    """Test the function `walk_packages`."""
    root = 'pyslvs'
    pwd = dirname(dirname(abspath(__file__)))
    for _, f in walk_packages(root, pwd):
        logger.info(f)


if __name__ == "__main__":
    import sys
    import os
    from pprint import pprint

    logger.setLevel('DEBUG')
    if len(sys.argv) == 1:
        logger.info('No arguments, run unit tests')
        logger.info(__file__ + '.py ' + '<name> [path]')
        logger.info('Unit tests:')
        test_walk_packages()

# Generated at 2022-06-23 15:20:26.756878
# Unit test for function walk_packages
def test_walk_packages():
    """In this case, should be found:

    - pyslvs
    - pyslvs_ui
    - pyslvs_ui.editor.frames.canvas
    - pyslvs_ui.editor.frames.config
    - pyslvs_ui.editor.frames.info
    - pyslvs_ui.editor.frames.part_selection
    - pyslvs_ui.editor.frames.sksolv
    """
    # Current path

# Generated at 2022-06-23 15:20:28.893305
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader('scipy', '.', False, 0, False)
    assert doc.strip(), 'The doctest is empty'

# Generated at 2022-06-23 15:20:36.318856
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    from shutil import rmtree

    for root, cmds in [("solve", ["solve", "robust"]), ("_qdar_core", ["qdar"])]:
        print(root)
        with mkdtemp() as pwd:
            print(f"{pwd}/{root}.py")
            print(f"{pwd}/{root}.__init__.py")
            assert gen_api({'Test': root}, pwd, prefix=pwd)
            rmtree(pwd)


__all__ = ['gen_api']

# Generated at 2022-06-23 15:20:48.157022
# Unit test for function gen_api
def test_gen_api():
    from os import remove
    from os.path import dirname
    from .logger import logger_init, logger
    logger_init()

    def test_api():
        root_names = {"Test": "test_pkg"}
        pwd = dirname(__file__)
        gen_api(root_names, pwd)
        docs = gen_api(root_names, pwd, dry=True)
        assert len(docs) == 1

# Generated at 2022-06-23 15:20:56.970506
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    logger.info("Generate API ...")
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
        'Python-Solvespace': 'solvespace',
        'Pyslvs-Plan': 'pyslvs_plan',
        'Qt for Python': 'PySide2',
    }
    output = gen_api(root_names, dry=True)
    for doc in output:
        assert type(doc) == str
        assert len(doc) > 0
        assert '\n' in doc
    assert len(output) == len(root_names)



# Generated at 2022-06-23 15:21:03.632444
# Unit test for function gen_api
def test_gen_api():
    from unittest.mock import patch
    import sys
    import pyslvs
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    spec = find_spec(pyslvs)
    if spec is None:
        logger.info(f"Skip: {pyslvs}")
        return
    pwd = dirname(spec.__file__)
    with patch.object(sys, "argv", ['']):
        docs = gen_api({
            "Pyslvs": pyslvs,
            "Pyslvs-ui": "pyslvs_ui"
        }, pwd, dry=True)
    for doc in docs:
        print(doc)
        print("-" * 12)

# Generated at 2022-06-23 15:21:11.721948
# Unit test for function loader
def test_loader():
    """Test for `loader` function."""
    import logging
    logger.setLevel(logging.DEBUG)
    for name, path in walk_packages('pyslvs', '..'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module here
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext

# Generated at 2022-06-23 15:21:14.001543
# Unit test for function loader
def test_loader():
    """Test script generator."""
    assert gen_api({'DocTest': 'pyslvs_ui.api'})


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:21:19.543873
# Unit test for function loader
def test_loader():
    """Test for loader."""
    doc = loader('pyslvs_ui', "..", False, 1, True)
    assert len(doc.strip()) > 100
    assert '* [pyslvs_ui](#pyslvs-ui)' in doc

# Generated at 2022-06-23 15:21:22.770764
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    from .logger import unittest_logger
    logger = unittest_logger('compiler')
    for name, path in walk_packages("pyslvs_ui", "./pyslvs_ui"):
        logger.info(f"{name} <= {path}")

# Generated at 2022-06-23 15:21:25.218945
# Unit test for function gen_api
def test_gen_api():
    """Unit test."""
    root_names = {"Python Standard Library": "stdlib"}
    pwd = dirname(dirname(abspath(__file__)))
    gen_api(root_names, pwd)

# Generated at 2022-06-23 15:21:36.589813
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase
    from tempfile import TemporaryDirectory

    class TestWalkPackages(TestCase):

        def test_node(self):
            with TemporaryDirectory() as tmp:
                path = join(tmp, "v1", "solver")
                mkdir(path)
                scripts = {
                    "solver": ("""
                        class Solver:
                            """
                            ),
                    "geometry": ("""
                        from .__init__ import *
                        """),
                    "version": ("""
                        from .__init__ import *
                        def version():
                            pass
                        """),
                }
                for name, doc in scripts.items():
                    path_tmp = join(path, name + ".py")
                    with open(path_tmp, "w") as f:
                        f.write(doc)
                   

# Generated at 2022-06-23 15:21:39.185491
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'Pyslvs': 'pyslvs',
    }
    pwd = join(dirname(__file__), '..')
    gen_api(root_names, pwd)

# Generated at 2022-06-23 15:21:47.437698
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from unittest.mock import patch
    from pkgutil import find_loader
    from tempfile import TemporaryDirectory
    from .robotics import link, joint, body
    from .compiler import gen_api, loader

    with TemporaryDirectory() as td:
        with patch("sys.path", [td]):
            assert find_loader("pyslvs_ui") is None
            loader("pyslvs_ui", td, False, 3, False)
            assert find_loader("pyslvs_ui") is not None

    with TemporaryDirectory() as td:
        with patch("pyslvs.compiler.logger.error") as p:
            gen_api({"test": "pyslvs_test"}, td)
            assert p.called


# Generated at 2022-06-23 15:21:50.573201
# Unit test for function walk_packages
def test_walk_packages():
    assert isinstance(walk_packages('__name__', '..'), Iterator)

if __name__ == "__main__":
    print(gen_api({'Pyslvs': 'pyslvs'}))

# Generated at 2022-06-23 15:21:56.892298
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logger.critical("Unit test for 'loader' function")
    msg = "It is a sample docstring."
    doc = loader("loader", dirname(__file__), True, 2, False)
    assert msg in doc, "Invalid document."
    logger.critical("Unit test passed!")


if __name__ == "__main__":

    test_loader()

# Generated at 2022-06-23 15:22:05.794697
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    from pytest import raises
    from os import remove
    import xmlrunner

    result = gen_api({"test": "xmlrunner"}, pwd=dirname(abspath(__file__)))
    assert len(result) == 1
    assert "xmlrunner" in result[0]
    with raises(FileNotFoundError):
        result = gen_api({"test": "xmlrunner"}, pwd="")
    with raises(FileNotFoundError):
        result = gen_api({"test": "xmlrunner"}, pwd="test")
    remove("./docs/test-api.md")



# Generated at 2022-06-23 15:22:15.769783
# Unit test for function loader
def test_loader():
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", dirname(__file__)):
        p.parse(name, _read(path + ".py"))
    assert p.compile()
    assert _load_module("pyslvs.constraint.constraint", pwd + "/pyslvs/constraint/constraint.cpython-38-darwin.so", p)
    assert _load_module("pyslvs.ui.main_window.main_window_ui", pwd + "/pyslvs/ui/main_window/main_window_ui.cpython-38-darwin.so", p)

# Generated at 2022-06-23 15:22:18.460816
# Unit test for function gen_api
def test_gen_api():
    assert len(gen_api({'title': 'name'}, prefix='test', dry=True)) == 1

# Generated at 2022-06-23 15:22:27.257809
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree
    from os.path import exists
    from tempfile import TemporaryDirectory
    from contextlib import redirect_stdout

    with redirect_stdout(open('./tmp-packages.txt', 'w')):
        with TemporaryDirectory() as tmp:
            t = join(tmp, 'test')
            mkdir(t)
            mkdir(join(t, 'a'))
            _write(join(t, "a.pyi"), "")
            _write(join(t, "__init__.py"), "")
            mkdir(join(t, 'a', 'b'))
            mkdir(join(t, 'pkg'))
            mkdir(join(t, 'pkg', '__pycache__'))
            mkdir(join(t, 'test-stubs'))
            _write

# Generated at 2022-06-23 15:22:35.002310
# Unit test for function gen_api
def test_gen_api():
    from sys import argv
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import realpath, join as join_path
    from pkgutil import get_loader

    l = get_loader('pyslvs')
    if l is None:
        print("It's not possible to run unit test for gen_api.")
        return

    def _get_pyslvs_path():
        """Get PySLVS path."""
        # Try to extract the path by __file__
        if l.is_package():
            return parent(l.get_filename())
        # Assume PySLVS is a single file
        return dirname(l.get_filename())

    root_dir = mkdtemp(prefix='gen_api_test_')

# Generated at 2022-06-23 15:22:44.320682
# Unit test for function walk_packages

# Generated at 2022-06-23 15:22:47.113754
# Unit test for function gen_api
def test_gen_api():
    gen_api({'test': 'pyslvs'}, pwd=parent(__file__), dry=True)

# Generated at 2022-06-23 15:22:53.706069
# Unit test for function walk_packages
def test_walk_packages():
    package = 'tests.fixtures.testpack'
    path = abspath("tests/fixtures/testpack")

# Generated at 2022-06-23 15:22:58.806641
# Unit test for function gen_api
def test_gen_api():
    import shutil
    from pprint import pprint
    # Reduce number of test files
    shutil.rmtree(join(dirname(__file__), 'data', 'VPython'))
    docs = gen_api(
        {'VPython': 'vpython'},
        join(dirname(__file__), 'data'),
        level=2,
        dry=True
    )
    pprint(docs)
    assert len(docs) > 0

# Generated at 2022-06-23 15:23:01.436008
# Unit test for function loader
def test_loader():
    """Test loader algorithm."""
    doc = loader('tkinter', dirname(__file__), False, 1, True)
    print(doc)

# Generated at 2022-06-23 15:23:03.880944
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages("pyslvs", "."))) > 100
    assert len(list(walk_packages("pyslvs", "tests"))) == 0

# Generated at 2022-06-23 15:23:06.440850
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    for name, path in walk_packages("pyslvs", ".."):
        print(name, path)

# Generated at 2022-06-23 15:23:08.234107
# Unit test for function loader
def test_loader():
    assert len(loader("math", abspath("."), True, 1, True).strip()) > 0

# Generated at 2022-06-23 15:23:18.038094
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    t = iter(walk_packages('pyslvs', 'pyslvs'))
    name, path = next(t)
    assert name == 'pyslvs'
    assert path.endswith(sep + 'pyslvs' + sep + '__init__.py')
    name, path = next(t)
    assert name == 'pyslvs.core'
    assert path.endswith(sep + 'pyslvs' + sep + 'core' + sep + '__init__.py')
    name, path = next(t)
    assert name == 'pyslvs.core.plan'
    assert path.endswith(sep + 'pyslvs' + sep + 'core' + sep + 'plan.py')

# Generated at 2022-06-23 15:23:23.181940
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api"""
    gen_api({"VSEPR", "pyslvs_ui.vsepr"}, dry=True)

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:23:34.319336
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    import os
    import shutil
    from os.path import abspath
    from tempfile import gettempdir
    from .constants import __version__
    from .project_path import pyslvs_file
    from .generate_api import generate_api
    title = 'Test Document'
    module = 'test_module'
    assert f'v{__version__}' in generate_api(__file__, title,
        module, '.', f'- {__version__}')[0]
    assert 'test function' in generate_api(__file__, title,
        module, '.', f'# {title}')[0]
    assert 'test method' in generate_api(__file__, title,
        module, '.', f'# {title}')[0]

# Generated at 2022-06-23 15:23:44.849767
# Unit test for function loader
def test_loader():
    import unittest
    import sys
    import re
    from .parser import get_location

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.site_path = ""
            for path in sys.path:
                for d in ["site-packages", "dist-packages"]:
                    site_path = join(path, d)
                    if isdir(site_path):
                        self.assertEqual(self.site_path, "")
                        self.site_path = site_path
            self.assertNotEqual(self.site_path, "")

        def test_main(self):
            """Package searching algorithm."""
            text = loader('pyslvs', self.site_path, False)
            # Nothing to test

# Generated at 2022-06-23 15:23:50.358517
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from unittest.mock import patch

    def walk_mock(p: str, *_) -> Iterator[tuple[str, str]]:
        return walk_packages("pyslvs_ui", p)

    with patch('os.walk', walk_mock):
        assert len(list(walk_packages("pyslvs_ui", "."))) > 0

# Generated at 2022-06-23 15:24:00.792972
# Unit test for function loader
def test_loader():
    from pkg_resources import resource_filename, Requirement
    import slvs

    root_names = {
        "SLVS": "slvs",
    }

    pwd = resource_filename(Requirement.parse('pyslvs'), 'pyslvs/')

    docs = gen_api(root_names, pwd, dry=True)
    assert len(docs) == 1
    assert "SLVS API" in docs[0]
    assert "SLVS Solver" in docs[0]
    assert "SLVS Solver class" in docs[0]
    assert "solve" in docs[0]
    assert "solve" not in docs[0]
    assert "CompileError" in docs[0]
    assert "SolverError" in docs[0]
    assert "expr.linkage" in docs[0]

# Generated at 2022-06-23 15:24:10.262150
# Unit test for function walk_packages
def test_walk_packages():
    path = 'docs/example-packages'
    result = {
        'pkg.__init__': 'docs/example-packages/pkg/__init__.py',
        'pkg.subpkg.__init__': 'docs/example-packages/pkg/subpkg/__init__.py',
        'pkg.subpkg.module': 'docs/example-packages/pkg/subpkg/module.py',
        'pkg.subpkg.package_data': 'docs/example-packages/pkg/subpkg/package_data.data'
    }
    for k, v in walk_packages('pkg', path):
        assert k == v.removeprefix(path + '/').replace('/', '.')
        assert result[k] == v

# Generated at 2022-06-23 15:24:12.717868
# Unit test for function loader
def test_loader():
    """Test function loader."""
    print(loader('pyslvs', '.', False, 0, False))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:24:18.660455
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import __ROOT__ as name

    def _print(s: str) -> str:
        print(s)
        return s

    for d in gen_api({'PYSLVS': name}, '/usr/lib/python3.8',
                     prefix=_print,
                     dry=True):
        pass

# Generated at 2022-06-23 15:24:24.556663
# Unit test for function gen_api
def test_gen_api():
    from unittest import TestCase

    class GenApiTest(TestCase):
        """Test function gen_api."""

        def test_gen_api(self):
            self.assertEqual(len(gen_api(
                {'pyslvs': 'pyslvs', 'pyslvs_ui': 'pyslvs_ui'},
                pwd=_site_path('pyslvs'),
                dry=True
            )), 2)

    return GenApiTest


__all__ = ['gen_api', ]

# Generated at 2022-06-23 15:24:35.666492
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from .test_data import package_tree

    with TemporaryDirectory() as temp_dir:
        for name, content in package_tree.items():
            logger.info(f"Create file: {name}")
            _write(join(temp_dir, name), content)
        logger.info(f"Load root: 'a' from {temp_dir}")
        assert loader('a', temp_dir, True, 1, False) == '''
[a.b](./#a-b)

[a.b.c](./#a-b-c) (c)

[a.b.d](./#a-b-d)

[a.c](./#a-c) (c)

[a.d](./#a-d)'''

# Generated at 2022-06-23 15:24:44.920313
# Unit test for function walk_packages
def test_walk_packages():
    S = []
    for n, p in walk_packages('root', './tests/test_parser'):
        S.append((n, p))
    S.sort()

# Generated at 2022-06-23 15:24:48.860014
# Unit test for function gen_api
def test_gen_api():
    root_names = {"Test": "test_mail"}
    logger.setLevel('DEBUG')
    logger.info('=' * 12)
    docs = gen_api(root_names, pwd=dirname(__file__))
    logger.info(docs)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:24:57.683834
# Unit test for function loader
def test_loader():
    root_names = {
        'numpy': 'numpy',
        'scipy': 'scipy',
    }
    gen_api(root_names)
    root_names = {
        'QtCore': 'PyQt5.QtCore',
        'QtGui': 'PyQt5.QtGui',
        'QtWidgets': 'PyQt5.QtWidgets',
    }
    gen_api(root_names)

# Generated at 2022-06-23 15:25:08.944386
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from os import makedirs

    def path_info(filename: str) -> str:
        return f"{filename}: {join(path, filename)}"

    with TemporaryDirectory() as path:
        a = join(path, "test", "a.py")
        b = join(path, "test", "b.py")
        mkdir(join(path, "test"))
        _write(a, "")
        _write(b, '"""This is B.')

        names = {"test": join(path, "test")}
        assert {name: path_info(f) for name, f in walk_packages(path, path)} == \
               {name: path_info(f) for name, f in names.items()}

        # Check stubs

# Generated at 2022-06-23 15:25:10.593338
# Unit test for function gen_api
def test_gen_api():
    return f"{gen_api(dict(test='testlib', pyslvs='pyslvs'), '..')}"

# Generated at 2022-06-23 15:25:18.830193
# Unit test for function walk_packages
def test_walk_packages():
    import pytest
    from _pytest.monkeypatch import MonkeyPatch
    from tempfile import gettempdir
    from shutil import rmtree
    from random import random
    from os import sep
    from pathlib import Path

    assert ("a", "a") == next(walk_packages("a", gettempdir()))
    assert ("a.b", "a" + sep + "b") == next(walk_packages("a", gettempdir()))
    assert ("b.a", "a" + sep + "b") == next(walk_packages("a", gettempdir()))
    with MonkeyPatch([(sys_path, [])]):
        assert ("a", "a") == next(walk_packages("a", gettempdir()))
        assert ("b", "b") == next(walk_packages("b", gettempdir()))

# Generated at 2022-06-23 15:25:26.763285
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os import remove, makedirs
    from os.path import exists, dirname
    from pkg_resources import resource_string, resource_filename
    from .parser import Parser
    from .utils import remove_prefix

    def _test_file(root: str, pwd: str, *, level: int = 1, link: bool = True, dry = False):
        api = gen_api({'Pyslvs': root}, pwd, level = level, link = link, dry = dry)

        logger.debug(f"Read file: {root}.md")
        with open(resource_filename(__name__, f"docs/{root}.md"), 'r', encoding='utf-8') as f:
            expected = f.read()

        assert api
        assert api[0] == expected

   

# Generated at 2022-06-23 15:25:37.948521
# Unit test for function walk_packages
def test_walk_packages():
    path = parent(__file__)

# Generated at 2022-06-23 15:25:49.321082
# Unit test for function gen_api
def test_gen_api():
    # Assume CWD is test
    # And you have to run `pip install wheel` once
    pwd = join('..', 'test_data')
    root_names = {'test_package': 'test_package'}
    assert len(gen_api(root_names, pwd, prefix='test')) == 1
    root_names = {'test_not_found': 'test_not_found'}
    assert len(gen_api(root_names, pwd, prefix='test')) == 0
    root_names = {'test_package': 'test_package'}
    assert len(gen_api(root_names, pwd, prefix='test', link=False)) == 1
    root_names = {'test_package': 'test_package'}

# Generated at 2022-06-23 15:25:50.672666
# Unit test for function gen_api
def test_gen_api():
    assert len(gen_api({"VBench": "vbench"}, dry=True)) == 1

# Generated at 2022-06-23 15:25:58.453771
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages"""
    sys_path.append('')
    paths = list(walk_packages('pyslvs', '.'))
    assert paths
    names = {p[0] for p in paths}
    assert 'pyslvs.__main__' in names
    assert 'pyslvs' not in names
    assert 'pyslvs_' not in names
    for n, _ in paths:
        assert 'pyslvs.' in n


# Generated at 2022-06-23 15:26:07.398176
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory() as dirname:
        package = "test"
        for i, n in enumerate([
            "__init__",
            "pkg",
            "pdk/__init__",
            "pdk/a",
            "pdk/b"
        ]):
            path = join(dirname, n + ".py")
            code = f"def f{i}() -> None: pass"
            logger.info(f"Create file: {path}")
            with open(path, 'w+') as f:
                f.write(code)
        result = list(walk_packages("test", dirname))

# Generated at 2022-06-23 15:26:18.242384
# Unit test for function walk_packages
def test_walk_packages():
    def _rm(d: str) -> None:
        for p in walk(d):
            for f in p[2]:
                remove(join(p[0], f))
            rmdir(p[0])

    _rm('test')
    mkdir('test/test/test')
    open('test/test/test/test.py', 'a').close()
    for name, path in walk_packages('test', 'test'):
        print(name, path)
    open('test/test/test/test.pyi', 'a').close()
    for name, path in walk_packages('test', 'test'):
        print(name, path)
    open('test/test/test/test.so', 'a').close()

# Generated at 2022-06-23 15:26:21.654224
# Unit test for function gen_api
def test_gen_api():
    """Test the unit of function gen_api."""
    res = gen_api({'Test': 'test'}, pwd=__spec__.origin)
    assert res[0]
    print(res[0])

# Generated at 2022-06-23 15:26:25.182959
# Unit test for function gen_api
def test_gen_api():
    test_name = {'pyslvs': 'pyslvs'}
    test_path = f"{dirname(dirname(abspath(__file__)))}"
    return gen_api(test_name, test_path, prefix='apidoc', dry=True)

# Generated at 2022-06-23 15:26:34.000711
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    from collections import OrderedDict

    t = tempfile.TemporaryDirectory()
    os.mkdir(os.path.join(t.name, "root"))

    with open(os.path.join(t.name, "root", "__init__.py"), "w") as f:
        f.write("root = 0")
    with open(os.path.join(t.name, "root", "a.py"), "w") as f:
        f.write("def a(): pass")
    with open(os.path.join(t.name, "root", "b.py"), "w") as f:
        f.write("def b(): pass")

    gen_api(OrderedDict([("title", "root")]), t.name)


# Generated at 2022-06-23 15:26:35.457483
# Unit test for function loader
def test_loader():
    assert loader('sisl', 'sisl', False, 2, True)

# Generated at 2022-06-23 15:26:38.277331
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import NamedTemporaryFile

# Generated at 2022-06-23 15:26:48.638711
# Unit test for function loader
def test_loader():
    import logging
    import pkgutil
    from .__main__ import parser
    from .parser import Parser, is_new_line
    root = 'pyslvs'
    pwd = '.'
    sys_path.append(pwd)
    logging.getLogger('compiler').setLevel(logging.DEBUG)
    logging.getLogger('parser').setLevel(logging.DEBUG)
    argv = ['--link', '--toc', '--level', '2', root]
    p = Parser.new(*parser.parse_args(argv))
    for _, name, is_pkg in pkgutil.walk_packages([pwd]):
        if root not in name:
            continue

# Generated at 2022-06-23 15:26:50.929355
# Unit test for function loader
def test_loader():
    from .__main__ import _test_loader
    assert _test_loader() == [
        '# PySlvs',
        '# Pyslvs_UI',
    ]

# Generated at 2022-06-23 15:27:01.834261
# Unit test for function walk_packages
def test_walk_packages():
    def wp(name: str, path: str) -> str:
        return '\n'.join(f'{a} <= {b}' for a, b in walk_packages(name, path))

# Generated at 2022-06-23 15:27:08.500853
# Unit test for function loader
def test_loader():
    """Test API generator."""
    from .parser import Parser
    from .utils import __version__
    p = Parser.new(link=True, level=1, toc=False)
    for name, path in walk_packages("pyslvs_ui", pwd=".."):
        p.parse(name, _read(path + ".pyi"))
    doc = p.compile()
    assert doc.startswith("# Pyslvs-UI API")
    assert f"version: {__version__}" in doc



# Generated at 2022-06-23 15:27:14.990782
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    logger.debug("[Unit Test] gen_api")
    pwd = "./tests/src"
    sys_path.append(pwd)
    name = "root"
    doc = loader(name, pwd, True, 1, False)
    logger.debug(doc)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:27:19.660109
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    assert len(loader('bs4', 'site-packages', True, 1, False))
    assert len(loader('sip', 'site-packages', True, 1, False))
    assert len(loader('PyQt5', 'site-packages', True, 1, False))



# Generated at 2022-06-23 15:27:22.525705
# Unit test for function walk_packages
def test_walk_packages():
    from .__main__ import print_module_information
    from .__main__ import EXAMPLE_PACKAGE_NAME
    for name, path in walk_packages(EXAMPLE_PACKAGE_NAME, '.'):
        print(name)
        print_module_information(name)
        print()

# Generated at 2022-06-23 15:27:28.254955
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, skipIf
    from os.path import dirname, exists, join
    from shutil import rmtree
    from tempfile import mkdtemp

    class TestLoader(TestCase):

        @classmethod
        def setUpClass(cls):
            cls.path = mkdtemp()
            cls.name = 'test_package'
            cls.stubs = join(cls.path, cls.name + PEP561_SUFFIX)
            mkdir(join(cls.stubs, 'subpackage'))
            open(join(cls.stubs, 'a.pyi'), 'w+', encoding='utf-8').close()
            open(join(cls.stubs, 'b.py'), 'w+', encoding='utf-8').close()

# Generated at 2022-06-23 15:27:30.041378
# Unit test for function loader
def test_loader():
    """The loader should work."""
    name = "pyslvs"
    path = _site_path(name)
    assert loader(name, path, 1, True, True).strip()



# Generated at 2022-06-23 15:27:32.273999
# Unit test for function loader
def test_loader():
    """Testing function loader."""
    text = loader('pyslvs', 'dist', True, 1, True)
    assert text.strip() != ''

# Generated at 2022-06-23 15:27:41.100456
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from os import remove, rmdir
    from os.path import basename, isfile
    from .judge import judge

    # Pass wrong name
    assert gen_api({'a': 'not exists'}) == [], "It will show warning and continue"

    # Pass wrong type
    assert gen_api([]) == [], "Must be a dict"
    assert gen_api((('a', 'b'),)) == [], "Must be a dict"

    # Default
    gen_api({'test': 'pylvs'})
    assert isfile('docs/pylvs-api.md')
    remove('docs/pylvs-api.md')
    rmdir('docs')

    # Custom prefix
    gen_api({'test': 'pylvs'}, prefix='document')


# Generated at 2022-06-23 15:27:45.642996
# Unit test for function loader
def test_loader():
    app_dir = dirname(dirname(dirname(dirname(abspath(__file__)))))
    code = loader('pyslvs_ui', join(app_dir, 'pyslvs_ui'), False, 2, False)
    assert code

# Generated at 2022-06-23 15:27:52.814833
# Unit test for function walk_packages
def test_walk_packages():
    def _package(name: str) -> str:
        return join(dirname(dirname(abspath(__file__))), pkg, name)

    pkg = "pyslvs"

# Generated at 2022-06-23 15:27:56.478511
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil
    root = 'pyslvs'
    os.makedirs('tests')
    os.chdir('tests')
    gen_api({'Pyslvs': 'pyslvs'}, toc=True, dry=True)
    os.chdir('..')
    try:
        shutil.rmtree('tests')
    except PermissionError:
        pass

# Generated at 2022-06-23 15:28:06.954121
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('test', '.'):
        assert name == 'test.test1'
        assert path == '.\\test\\test1.py'
        break
    for name, path in walk_packages('test', '.'):
        assert name == 'test.test2'
        assert path == '.\\test\\test2.py'
        break
    for name, path in walk_packages('test', '.'):
        assert name == 'test.test3'
        assert path == '.\\test\\test3.py'
        break
    for name, path in walk_packages('test', '.'):
        assert name == 'test.test4'
        assert path == '.\\test\\test4.pyi'
        break
    else:
        raise AssertionError('Not all packages are tested.')

# Generated at 2022-06-23 15:28:15.666306
# Unit test for function walk_packages
def test_walk_packages():
    """Run unit test for function walk_packages."""
    from .test.test_file import pwd
    from .test import package_test
    from .test.package_test import class_test
    from .test.package_test.class_test import func_test
    from .test.package_test.class_test import func_test2
    from .test.package_test2 import func_test
    from .test.package_test2 import func_test2
    assert package_test is func_test.__self__
    assert class_test is func_test2.__self__
    package_test_path = parent(package_test.__file__)
    package_test3_path = join(package_test_path, '__init__.py')

# Generated at 2022-06-23 15:28:25.855116
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from .logger import logger
    from .parser import Parser
    from .utils import pkg_dir
    from .__main__ import load_root
    from pkgutil import get_loader
    from os import chdir
    from os.path import dirname, exists
    from tempfile import TemporaryDirectory
    from importlib import import_module
    import unittest

    class TestNameRoot(unittest.TestCase):

        def test_load_root(self):
            self.assertEqual(load_root("pyslvs"), "pyslvs")
            self.assertEqual(load_root("dummy"), "dummy_module")


# Generated at 2022-06-23 15:28:28.884269
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import raises
    with raises(FileNotFoundError):
        next(walk_packages("pyslvs", "pyslvs"))

# Generated at 2022-06-23 15:28:31.423219
# Unit test for function loader
def test_loader():
    """Test for loading module."""
    # Fail
    assert not _load_module("None", "None", None)
    # Pass
    assert _load_module("sys", "sys", None)

# Generated at 2022-06-23 15:28:37.451732
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os
    import shutil
    import importlib
    import unittest
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from pyslvs_ui.compiler import walk_packages


# Generated at 2022-06-23 15:28:41.334762
# Unit test for function loader
def test_loader():
    """Test parser with `loader`."""
    from pkgutil import iter_modules
    p = Parser.new(True, 1, True)
    # Load root first to avoid import error
    for __, name, ___ in iter_modules(sys_path):
        p.parse(name, _read(find_spec(name).origin))
    return p.compile()

# Generated at 2022-06-23 15:28:49.608448
# Unit test for function gen_api
def test_gen_api():
    title = "Test"
    name = "pyslvs"
    root = {
        title: name,
    }
    logger.debug(f"{root}")

    init = "__init__.py"
    doc = "# Hello World"

    site_path = abspath("test-dir")
    mkdir(site_path)

    mkdir(site_path + sep + name)
    mkdir(site_path + sep + name + sep + "a")

    for i in range(4):
        path = (site_path + sep + name +
                ("" if i == 0 else "a" + sep + "b") + sep + ("" if i < 3 else "c") + init)

        with open(path, 'w') as f:
            f.write(doc)


# Generated at 2022-06-23 15:28:54.786431
# Unit test for function gen_api
def test_gen_api():
    """Generate API for unit test."""
    from pyslvs import __root__
    p = gen_api(
        {
            "Pyslvs": __root__,
            "PySlvs-UI": "pyslvs_ui",
            "Pyslvs-Qt": "pyslvs_qt",
        },
        ".",
        link=False,
        level=2,
        toc=False
    )
    print(p[0])

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:28:56.746997
# Unit test for function loader
def test_loader():
    doc = loader('pyslvs', '.', True, 1, False)
    assert '```python' in doc

# Generated at 2022-06-23 15:29:08.025334
# Unit test for function loader
def test_loader():
    from .parser import Parser
    p = Parser.new(True, 1, False)
    p.parse('test', '"test module"')
    assert p.compile() == "# test\n[test](test.md)\n\n"
    assert p.compile(True) == "# test\n\n**test** `module`\n\n"
    p.parse('test.test_func', '"""test function"""')
    assert p.compile() == "# test\n[test.test_func](test.test_func.md)\n\n"
    p.parse('test.test_func2', '"""test function"""')
    assert p.compile() == "# test\n[test.test_func](test.test_func.md)\n\n"

# Generated at 2022-06-23 15:29:15.513711
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    assert isinstance(p, Parser)
    assert _site_path("numpy") != ""
    name, path = next(walk_packages("numpy", _site_path("numpy")))
    s = find_spec(name)
    # numpy's submodule_search_locations is None
    assert s is not None and s.submodule_search_locations is None
    assert name == "numpy.core.defchararray._ndarray"
    assert path.startswith(_site_path("numpy"))
    assert path.endswith(".pyi")
    for name, path in walk_packages("pyslvs", "."):
        assert name.startswith("pyslvs")
        assert path.startswith(".")

# Generated at 2022-06-23 15:29:23.850982
# Unit test for function walk_packages
def test_walk_packages():
    path = 'tests/test_pkgutil'
    for m, p in walk_packages('test_pkgutil', path):
        assert m in {
            'test_pkgutil',
            'test_pkgutil.__init__',
            'test_pkgutil.foo',
            'test_pkgutil.foo.__init__',
            'test_pkgutil.foo.foo',
            'test_pkgutil.foo.bar',
        }, m
        assert p.startswith(path), p
        if m.endswith('foo.__init__'):
            assert m + '.pyi' == p, f"{m} <= {p}"
        else:
            assert m + '.py' == p, f"{m} <= {p}"

# Generated at 2022-06-23 15:29:26.202243
# Unit test for function loader
def test_loader():
    """Test case for function loader."""
    for _ in walk_packages('pyslvs', '../..'):
        pass


# Generated at 2022-06-23 15:29:37.670715
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs", "package"):
        assert name == "pyslvs", name
        assert path == "package/pyslvs", path
    for name, path in walk_packages("pyslvs", "package/pyslvs"):
        assert name == "pyslvs.info", name
        assert path == "package/pyslvs/info", path
    for name, path in walk_packages("info", "package/pyslvs"):
        assert name == "pyslvs.info.__init__", name
        assert path == "package/pyslvs/info/__init__", path

# Generated at 2022-06-23 15:29:46.306365
# Unit test for function loader
def test_loader():
    """Unit test for function loader.

    This is a functional test to test the function loader.
    """
    from re import findall
    from .__init__ import __version__
    from .logger import logger_patch

    logger.setLevel(10)
    logger_patch()

    doc = loader('pyslvs', abspath(dirname(__file__)), True, 1)

    version = findall(r'Version: (\d+\.\d+\.\d+)', doc)[0]
    assert version == __version__

    no_link = doc.count('*')

    doc = loader('pyslvs', abspath(dirname(__file__)), False, 1)

    assert no_link == doc.count('*')
    assert not doc.count('\n\n\n')

    logger.setLevel