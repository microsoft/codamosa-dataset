

# Generated at 2022-06-23 15:19:49.648938
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory, TemporaryFile
    tmpdir = TemporaryDirectory()
    path = tmpdir.name
    logger.info('=' * 12)
    for p, f in walk_packages('foo', path):
        logger.info(f"{p} <= {f}")
    mkdir(join(path, 'foo'))
    mkdir(join(path, 'bar'))
    mkdir(join(path, 'baz'))
    with TemporaryFile(mode='w', dir=path) as f:
        f.write('# Hello\n# World')
    with TemporaryFile(mode='w', dir=join(path, 'foo')) as f:
        f.write('# Hello\n# World')
    with TemporaryFile(mode='w', dir=join(path, 'bar')) as f:
        f

# Generated at 2022-06-23 15:20:01.108942
# Unit test for function gen_api
def test_gen_api():
    import os
    import pkgutil
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        _, path, _ = pkgutil.find_loader("pyslvs")
        path = os.path.dirname(path)
        # Test the normal way
        _, doc = gen_api({"Python Solves": "pyslvs"})[0].split("\n", maxsplit=2)
        assert doc.strip() == "**pyslvs** - Python Solves"
        # Test error
        assert not gen_api({"Python Solves": "pyslvs2"})
        # Test dry-run

# Generated at 2022-06-23 15:20:03.852127
# Unit test for function gen_api
def test_gen_api():
    """Test gen_api."""
    assert len(gen_api({"Title": ""}, dry=True)) == 1
    assert len(gen_api({}, dry=True)) == 0

# Generated at 2022-06-23 15:20:15.490545
# Unit test for function walk_packages
def test_walk_packages():
    def cks(pkg: str, path: str) -> bool:
        return any(pkg.startswith(p) for p in path)

    assert list(walk_packages('a', '.')) == [
        ('a.b', '.\\a\\b'),
        ('a.b.c', '.\\a\\b\\c'),
        ('a.b.c-stubs', '.\\a\\b\\c-stubs'),
        ('a.b.c-stubs.d', '.\\a\\b\\c-stubs\\d'),
    ]

# Generated at 2022-06-23 15:20:16.625641
# Unit test for function gen_api
def test_gen_api():
    # TODO
    ...

# Generated at 2022-06-23 15:20:18.846667
# Unit test for function walk_packages
def test_walk_packages():

    def bla(d, files):
        d.extend(files)
    d = []
    walk('.', bla, d)
    assert d == [f for f, _ in walk_packages("pys", ".")]

# Generated at 2022-06-23 15:20:21.737255
# Unit test for function loader
def test_loader():
    """Test function loader()."""
    from .parser import Link
    from .logger import logger
    logger.setLevel(30)
    assert 10 > len(loader('pyslvs', '..', Link(True, 1, False))) > 1
    assert 10 > len(loader('pyslvs-ui', '..', Link(True, 1, False))) > 1

# Generated at 2022-06-23 15:20:29.546501
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api.

    .. code-block:: python

        import os
        import sys
        import shutil
        from pyslvs_ui.compiler import gen_api

        logger.setLevel('DEBUG')

        def test_gen_api_main():
            pwd = os.path.dirname(os.path.realpath(__file__))
            sys.path.append(pwd)
            try:
                gen_api({
                    'Path' : 'pyslvs.path',
                }, pwd, dry=True, prefix='api-doc')
            finally:
                shutil.rmtree('api-doc')
    """
    print(test_gen_api.__doc__)
    test_gen_api_main()

# Generated at 2022-06-23 15:20:35.479576
# Unit test for function loader
def test_loader():
    """Unit test."""
    import sys
    import pkgutil
    import doctest
    f = pkgutil.get_data("pyslvs_ui", "example/trajectory_planning.py")
    m = module_from_spec(spec_from_file_location("test_loader", None, is_package=False))
    m.__doc__ = f.decode()
    m.__test__ = True
    sys.modules['test_loader'] = m
    doctest.testmod(m)

# Generated at 2022-06-23 15:20:47.192744
# Unit test for function gen_api
def test_gen_api():
    ...

"""This module is a standalone script."""
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(
        description="""
            Generate API documents.
            Arguments are similar to `pip install`.
            """
    )
    parser.add_argument(
        'package',
        nargs='*',
        help='Packages for generating API documents.'
    )
    parser.add_argument(
        '-m', '--module',
        help="""
            The name of the root module in the package.
            If not provided, the package name will be used.
            """
    )
    parser.add_argument(
        '-p', '--prefix',
        default='docs',
        help="The output directory."
    )
    parser.add_

# Generated at 2022-06-23 15:20:50.027595
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    assert any(walk_packages('test', '.'))


# Generated at 2022-06-23 15:20:58.537778
# Unit test for function loader
def test_loader():
    from tempfile import mkdtemp
    import pkg_resources as pkg
    pwd = mkdtemp()
    for nm, pk in [("sys", "python3"), ("sphinx", "sphinx"), ("sphinxcontrib_trio", "sphinxcontrib.trio")]:
        p = pkg.get_distribution(pk)
        if p is None:
            logger.warning(f"{nm} is not installed")
            continue
        sp = p.location
        open(f"{pwd}{sep}{nm}.py", 'w+').close()
        open(f"{sp}{sep}{nm}.py", 'w+').close()
        open(f"{sp}{sep}{nm}.pyi", 'w+').close()

# Generated at 2022-06-23 15:21:02.104811
# Unit test for function loader
def test_loader():
    """Test loader."""
    import logging
    logging.basicConfig(level=10)
    print(loader('pyslvs', '../site-packages', True, 1, True))



# Generated at 2022-06-23 15:21:07.153483
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    # Use your own docstrings package
    docs = gen_api({'Docstrings package': 'docstrings'}, dry=True)
    assert len(docs) > 0
    docs = gen_api({'Docstrings package': 'docstrings'})
    assert len(docs) > 0

# Generated at 2022-06-23 15:21:14.863567
# Unit test for function walk_packages
def test_walk_packages():
    assert tuple(walk_packages('a', 'tests/data')) == (
        ('a.sub', 'tests/data/a/sub/__init__.py'),
    )
    assert tuple(walk_packages('b', 'tests/data')) == (
        ('b', 'tests/data/b.py'),
        ('b.sub', 'tests/data/b/sub.py'),
    )
    assert tuple(walk_packages('c', 'tests/data')) == (
        ('c', 'tests/data/c.py'),
        ('c.sub', 'tests/data/c/sub.py'),
        ('c.sub.subsub', 'tests/data/c/sub/subsub.py'),
    )

# Generated at 2022-06-23 15:21:20.887567
# Unit test for function walk_packages
def test_walk_packages():
    from .extension_test.package import __file__ as package_file
    from .extension_test.package.module import __file__ as module_file
    from .extension_test.package.module.sub_module import __file__ as sub_module_file
    for name, path in walk_packages('package', dirname(package_file)):
        if name == 'package':
            assert path.endswith('package')
        elif name == 'package.module':
            assert path.endswith('package/module')
        elif name == 'package.module.sub_module':
            assert path.endswith('package/module/sub_module')


# Generated at 2022-06-23 15:21:21.983482
# Unit test for function gen_api
def test_gen_api():
    gen_api({'Test': 'test'}, 'test', dry=True)

# Generated at 2022-06-23 15:21:28.663490
# Unit test for function gen_api
def test_gen_api():
    import pytest
    from pytest import raises
    from os.path import exists
    from os import remove
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        assert gen_api({'s': 'sys'}, tmpdir)
        assert gen_api({'s': 'sys'}, tmpdir, level=2)
        assert gen_api({'s': 'sys'}, tmpdir, prefix="test")
        assert gen_api({'s': 'sys'}, tmpdir, prefix=join(tmpdir, "test"))
        assert gen_api({'s': 'sys'}, tmpdir, prefix="test", level=2)
        assert gen_api({'s': 'sys'}, tmpdir, prefix=join(tmpdir, "test"), level=2)

# Generated at 2022-06-23 15:21:30.208323
# Unit test for function loader
def test_loader():
    logger.warning("Test function 'test_loader' is not implemented.")

# Generated at 2022-06-23 15:21:40.392595
# Unit test for function walk_packages
def test_walk_packages():
    root, start, paths = "root", "start", [
        "root/start/a.py", "root/start/a.pyi",
        "root/start/b.py", "root/start/b.pyi",
        "root/start/__init__.py", "root/start/__init__.pyi",
        "root/start/c/__init__.py", "root/start/c/__init__.pyi",
        "root-stubs/start/d.pyi",
        "root-stubs/start/e.pyi",
        "root-stubs/start/__init__.pyi",
        "root-stubs/start/f/__init__.pyi",
    ]

# Generated at 2022-06-23 15:21:48.675371
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import unittest
    import os
    from .parser import collect_docs
    from .test.test_project.test_module import test_var


    class Tester(unittest.TestCase):
        """Unit test for function gen_api."""

        def setUp(self):
            """Set up."""
            self.root_names = {"Test module": "test_project.test_module"}
            self.prefix = "test_docs"

        def tearDown(self):
            """Tear down."""
            os.system("rm -rf " + self.prefix)

        def test_gen_api(self):
            """Test gen_api."""

# Generated at 2022-06-23 15:21:50.521632
# Unit test for function loader
def test_loader():
    print(loader('pyslvs', './pyslvs', False, 2, False))

# Generated at 2022-06-23 15:21:55.431707
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from importlib import reload
    import pyslvs
    reload(pyslvs.compiler)
    print(loader(
        'pyslvs',
        dirname(pyslvs.__file__),
        link=True,
        level=0,
        toc=False
    ))

# Generated at 2022-06-23 15:21:57.996444
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"test": "a.b"}, "") == ["## test API\n\n### a\n\n---\n\n#### b\n\n"]
    assert gen_api({}) == []

# Generated at 2022-06-23 15:22:03.362226
# Unit test for function walk_packages

# Generated at 2022-06-23 15:22:06.233047
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages('pyslvs', 'pyslvs'))) == 0
    assert sum(1 for _ in walk_packages('pyslvs', '../')) > 0

# Generated at 2022-06-23 15:22:13.866927
# Unit test for function gen_api
def test_gen_api():
    # Test package
    root_names = {"Test Package": 'test_pkg', "Root Package": 'test'}
    assert gen_api(root_names, pwd=dirname(__file__), dry=True)

    # Pyslvs package
    from pyslvs import __version__
    root_names = {f"Pyslvs {__version__} API": 'pyslvs'}
    assert gen_api(root_names, dry=True)


# Generated at 2022-06-23 15:22:23.903417
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory

    class Test(TestCase):

        def setUp(self) -> None:
            """Create a directory and write some files."""
            self.pwd = TemporaryDirectory()
            self.name = 'temp_package'
            self.path = join(self.pwd.name, self.name)
            mkdir(self.path)
            _write(join(self.path, '__init__.py'), '')

            sub_path = join(self.path, 'sub')
            mkdir(sub_path)
            _write(join(sub_path, '__init__.py'), '')
            _write(join(sub_path, 'a.py'), 'a')

# Generated at 2022-06-23 15:22:31.584528
# Unit test for function walk_packages
def test_walk_packages():
    # pylint: disable=import-outside-toplevel
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import chdir, remove, makedirs
    from os.path import isdir, exists

    # TODO: Develop a unit test case
    # Note: You can use this way to make temp package
    #       you want to test your function.
    # Setup env
    #   tmp = mkdtemp()
    #   tmp = '/tmp/pyslvs/pyslvs'
    #   makedirs(tmp, exist_ok=True)
    #   chdir(tmp)

    # Prepare modules
    #   with open('test.py', 'w+') as f:
    #       f.write('# This is just a test.\n')
    #   with open

# Generated at 2022-06-23 15:22:35.750761
# Unit test for function loader
def test_loader():
    assert len(gen_api({"Topology", "pyslvs"}))
    assert len(gen_api({"Topology", "pyslvs"}, dry=True))
    assert len(
        gen_api({"Topology", "pyslvs"}, pwd="../..", dry=True)
    )

# Generated at 2022-06-23 15:22:40.423307
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    assert gen_api({'Hello': 'hello'}) == []
    assert gen_api({'Hello': 'hello'}, pwd=__file__) == []
    assert gen_api({'Hello': 'hello'}, pwd=__file__, prefix='docs', toc=True) == []

# Generated at 2022-06-23 15:22:44.003133
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    root_name = "svs"
    example = loader(
        root_name,
        _site_path(root_name),
        True,
        1,
        False
    )
    assert example.startswith("# svs API")



# Generated at 2022-06-23 15:22:51.065845
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    import sys
    import random
    import tempfile
    try:
        path = tempfile.TemporaryDirectory().name
    except:
        path = tempfile.mkdtemp()
    pwd = abspath(path) + sep
    # Try to set up packages for test
    for i in range(random.randrange(4, 6)):
        mkdir(join(path, f"name-{i}.egg-info"))
    for i in range(random.randrange(4, 6)):
        mkdir(join(path, f"name-{i}"))
    for i in range(random.randrange(4, 6)):
        mkdir(join(path, 'name-a-a'))
        mkdir(join(path, 'name-a'))
   

# Generated at 2022-06-23 15:23:00.106318
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages test."""

# Generated at 2022-06-23 15:23:06.408057
# Unit test for function gen_api
def test_gen_api():
    """Gen docs test."""
    from pyslvs_ui.qt_patch import QPushButton
    from qtpy.QtWidgets import QApplication
    docs = gen_api({
        "SLVS-UI": "pyslvs_ui",
        "SLVS": "pyslvs",
    }, prefix=".", dry=True)
    for doc in docs:
        print(doc)
    # Dummy QApplication to avoid error
    QApplication([])
    QPushButton()

# Generated at 2022-06-23 15:23:08.484672
# Unit test for function gen_api
def test_gen_api():
    assert not gen_api({}).strip()
    from pyslvs.examples import test
    assert 'pyslvs' in test()

# Generated at 2022-06-23 15:23:15.811710
# Unit test for function loader
def test_loader():
    """Test API generater."""
    from importlib import util
    from os import remove
    from os.path import isfile
    from types import ModuleType
    from .logger import StreamLogger
    from .logger import sys_logger
    StreamLogger.start()

    def _try_import(name: str, path: str) -> ModuleType:
        s = util.spec_from_file_location(name, path)
        if s is None or s.loader is None:
            raise ImportError
        return s.loader.create_module(s)

    def _remove_files(files: Sequence[str]) -> None:
        for file in files:
            if isfile(file):
                remove(file)

    print("Testing function loader")
    p = Parser.new(False, 1, False)
    root

# Generated at 2022-06-23 15:23:19.338694
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('pyslvs', dirname(dirname(dirname(abspath(__file__))))):
        print(name, path)
    print(list(walk_packages('pyslvs', dirname(dirname(dirname(abspath(__file__)))))))

# Generated at 2022-06-23 15:23:21.850847
# Unit test for function gen_api
def test_gen_api():
    """Unit test for funtion gen_api."""
    gen_api({'pyslvs': 'pyslvs'}, dry=True)
    # pylint: disable=import-outside-toplevel
    from importlib import reload  # type: ignore
    reload(logger)  # Reset logger



# Generated at 2022-06-23 15:23:25.515823
# Unit test for function gen_api
def test_gen_api():
    """Generate API for testing."""
    gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs UI': 'pyslvs_ui',
    }, "./build/lib/")

# Generated at 2022-06-23 15:23:36.025649
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import shutil
    from os.path import isfile
    from .logger import logger
    from .__main__ import sys_argv
    from .builtin import BUILTIN_DOC
    logger.info("Unit test for function gen_api")
    logger.debug(f"sys.argv = {sys_argv}")
    root_names = {
        'Builtin': 'pyslvs',
    }
    docs = gen_api(root_names, dry=True, prefix='docs')
    assert docs == [BUILTIN_DOC]
    if isfile('docs'):
        shutil.rmtree('docs')
    logger.info("All tests passed!")

# Generated at 2022-06-23 15:23:42.264884
# Unit test for function gen_api
def test_gen_api():
    sys_path.append(dirname(__file__))
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
        'Pyslvs-Planner': 'pyslvs_planner'
    }
    dry = True
    assert gen_api(root_names, dry=dry)


# Generated at 2022-06-23 15:23:50.394987
# Unit test for function walk_packages
def test_walk_packages():
    """Run the function with unit test."""
    try:
        test_dir = join(dirname(__file__), 'test_data', 'walk')
        assert isdir(test_dir)
        assert list(walk_packages('s', test_dir)) == \
            [('s', join(test_dir, 's.py')), ('s.test', join(test_dir, 's', 'test.py'))]
    finally:
        logger.info("Test passed")



# Generated at 2022-06-23 15:23:54.665179
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api(
        {
            "Solver": "pyslvs",
            "UI": "pyslvs_ui",
        },
        pwd=dirname(__file__),
        prefix="test",
        dry=True,
    )
    assert docs
    print(docs)

# Generated at 2022-06-23 15:24:04.893076
# Unit test for function loader
def test_loader():
    """Test case."""
    from pkgutil import get_loader
    assert get_loader('pyslvs') is not None
    root = 'pyslvs'
    assert loader(root, pwd=_site_path(root), link=False, level=1, toc=False)
    assert loader(root, pwd=_site_path(root), link=True, level=1, toc=False)
    assert loader(root, pwd=_site_path(root), link=False, level=3, toc=False)
    assert loader(root, pwd=_site_path(root), link=True, level=3, toc=False)
    assert loader(root, pwd=_site_path(root), link=False, level=1, toc=True)

# Generated at 2022-06-23 15:24:09.401966
# Unit test for function gen_api
def test_gen_api():
    from .server import API
    from .app import APP
    API.create_all()
    title = 'Pyslvs API'
    name = 'pyslvs'
    doc = loader(name, None, True, 1, True)
    assert isinstance(doc, str)
    assert 1 == len(_site_path(name))
    assert title == API.gen_prefix(1)
    assert f'# {title}\n\n' in API.gen_link_page()
    log_messages = []
    for message in APP.logger.messages:
        if 'packages' in message:
            continue
        log_messages.append(message)

# Generated at 2022-06-23 15:24:14.742629
# Unit test for function loader
def test_loader():
    result = []
    for name, path in walk_packages('test', './testsuites'):
        result.append((name, path))
    assert result == [
        ('test.a.a', './testsuites/test/a/a.py'),
        ('test.a.b', './testsuites/test/a/b.py'),
        ('test.c', './testsuites/test/c.py'),
        ('test.d', './testsuites/test/d.py'),
        ('test.e', './testsuites/test/e.py'),
        ('test.f', './testsuites/test/f.py'),
    ]
    assert loader('test', './testsuites') == """\
# test a

## test.a.a
"""
    assert loader

# Generated at 2022-06-23 15:24:24.745261
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from io import StringIO
    from collections import OrderedDict
    with StringIO() as buf, logger.redirect(buf):
        tuples = tuple(walk_packages("pyslvs", "./src/pyslvs"))
        tuples = OrderedDict(tuples)
        for path in tuples.values():
            print(path)
        assert len(tuples) == 32

# Generated at 2022-06-23 15:24:27.586591
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import expanduser
    fp = expanduser('~')
    assert next(walk_packages('tensorflow', fp))[0] == 'tensorflow'

# Generated at 2022-06-23 15:24:38.978333
# Unit test for function walk_packages
def test_walk_packages():
    import shutil
    import tempfile
    from os.path import basename
    from .path import make_path as mp
    from .vlink import vlink
    from .docs import sep_docs
    path = mp(__file__).parent
    with tempfile.TemporaryDirectory() as tmpdir:
        shutil.copytree(path / 'test_api', tmpdir / 'test_api')
        for name, f_path in walk_packages('test', tmpdir):
            assert name.replace('.', sep) == basename(f_path)

    # Search into `src`
    root = str(path / 'src')
    assert root in sys_path
    docs = ''
    for name, path in walk_packages('pyslvs_ui', root):
        f_path = parent(path) + '.py'


# Generated at 2022-06-23 15:24:40.743895
# Unit test for function gen_api
def test_gen_api():
    """Test function."""
    gen_api({'SVS': 'pyslvs'}, dry=True)

# Generated at 2022-06-23 15:24:48.251842
# Unit test for function loader
def test_loader():
    import tempfile
    with tempfile.TemporaryDirectory() as pwd, \
         tempfile.NamedTemporaryFile(mode='w', dir=pwd, suffix='.py') as fp:

        fp.write('''
            def hello() -> str:
                """Hello world."""
                return "Hello world!"
        ''')
        fp.seek(0)
        root = fp.name.split(sep)[-1].replace('.py', '')
        p = Parser.new(False, 1, False)
        loader(root, pwd, p)

# Generated at 2022-06-23 15:25:00.556898
# Unit test for function walk_packages
def test_walk_packages():

    def walk_test(path: str, base: str) -> None:
        logger.info(f"walk from: {path}")
        for name, path in walk_packages('load', path):
            logger.info(f"{name} <= {path}")
            assert name.startswith(base)

    logger.info("walk_packages test...")
    walk_test(
        join(dirname(__file__), '..', '..', 'pyslvs', 'load', 'verifier'),
        'pyslvs.load.verifier'
    )

# Generated at 2022-06-23 15:25:11.449683
# Unit test for function gen_api
def test_gen_api():
    from numpy import pi
    from svgwrite import Drawing
    from pyslvs import expr, vmath
    from pyslvs_ui.compiler import gen_api

    assert gen_api({'pyslvs': 'pyslvs'})
    assert gen_api({'pyslvs': 'pyslvs'}, '..')
    assert gen_api({'pyslvs': 'pyslvs'}, 'pyslvs')
    assert gen_api({'pyslvs': 'pyslvs'}, 'pyslvs_ui')
    assert gen_api({'pyslvs': 'pyslvs'}, 'pyslvs_ui', prefix='../docs')


# Generated at 2022-06-23 15:25:18.002132
# Unit test for function gen_api
def test_gen_api():
    class Root:
        name: str
        title: str
    def gen(root):
        return gen_api({root.title: root.name}, dry=True)
    class Test:
        root: Root
        count: int
    tests = (
        Test(Root("pyslvs", "PySLVS"), 2),
        Test(Root("pyslvs-ui", "PySLVS-UI"), 3),
    )
    for test in tests:
        docs = gen(test.root)
        assert len(docs) == test.count
        for doc in docs:
            assert len(doc) > 0

# Generated at 2022-06-23 15:25:26.623678
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api"""
    from .testing import ProjectConfig

    # Get root path of the project.
    root_path = ProjectConfig().root_path

    # Get test folder path
    test_path = join(root_path, 'tests', 'data')

    # Testing function
    def _test_gen_api(*,
                      docs_path,
                      root_names,
                      pwd=None,
                      prefix='docs',
                      link=True,
                      level=1,
                      toc=False):
        """Test _gen_api"""
        root_names = root_names if isinstance(root_names, dict) else {
            'Title': root_names
        }

# Generated at 2022-06-23 15:25:34.679754
# Unit test for function walk_packages
def test_walk_packages():
    pk = {
        ("foo", "foo.__init__"),
        ("foo.a", "foo.a"),
        ("foo.a.b", "foo.a.b"),
        ("foo.c", "foo.c"),
        ("foo.c.d", "foo.c.d"),
        ("foo.e", "foo.e"),
    }
    for name, path in walk_packages("foo", "tests/pkg"):
        assert name, path in pk
        pk.remove((name, path))
    assert not pk

# Generated at 2022-06-23 15:25:43.200139
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .api import module_to_api
    from .parser import Parser
    parser = Parser(True, 1, False)

    def _fake_load(name: str, path: str, parser: Parser) -> bool:
        """Fake load method."""
        parser.parse(name, _read(path))
        return True

    # load module directly

# Generated at 2022-06-23 15:25:46.557207
# Unit test for function loader
def test_loader():
    """Unit test import error."""
    logger.info("\nTest loader:")
    assert '`' not in loader('pyslvs_ui', '../pyslvs_ui', True, 1, False)

# Generated at 2022-06-23 15:25:51.743156
# Unit test for function loader
def test_loader():
    pwd = dirname(abspath(__file__))
    root_names = {
        "Pyslvs": "pyslvs",
        "Pyslvs Algorithm": "algorithm",
        "Pyslvs Package Compiler": "compiler"
    }
    gen_api(root_names, pwd, level=2, dry=False)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-23 15:26:03.277997
# Unit test for function gen_api
def test_gen_api():
    from unittest import mock
    logger.info = mock.Mock()
    logger.warning = mock.Mock()
    logger.debug = mock.Mock()
    logger.info.reset_mock()
    logger.warning.reset_mock()
    logger.debug.reset_mock()
    root_names = {'test': 'test', 'PYSCHEDULE': 'pyschedule'}
    pwd = './pyslvs_ui/tests'
    docs = gen_api(root_names, pwd)
    assert logger.info.mock_calls
    assert logger.warning.mock_calls
    assert logger.debug.mock_calls
    assert docs
    assert isinstance(docs, list)
    assert len(docs) == 2
    assert docs[0]
   

# Generated at 2022-06-23 15:26:14.184964
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree
    from os import remove
    from os.path import isdir, isfile, join
    from tempfile import mkdtemp
    from contextlib import contextmanager
    from slvs import __path__ as PATH
    ROOT = PATH[0]

    @contextmanager
    def tmpdir(path: str) -> Iterator[str]:
        p = join(path, 'tmp')
        mkdir(p)
        try:
            yield p
        finally:
            rmtree(p)

    def mk_pyfile(p: str, name: str) -> None:
        with open(join(p, f"{name}.py"), 'w+') as f:
            f.write(f"'''{name} mod'''\n")


# Generated at 2022-06-23 15:26:17.570338
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import gen_api
    docs = gen_api({"Pyslvs": "pyslvs"}, dry=True)



# Generated at 2022-06-23 15:26:21.759006
# Unit test for function loader
def test_loader():
    """Test the loader."""
    import sys
    sys.path.append("..")
    assert loader("pyslvs", "..", True, 1, False).strip()
    assert loader("extra_data", "./test_data", True, 1, False).strip()


# Generated at 2022-06-23 15:26:24.754156
# Unit test for function gen_api
def test_gen_api():
    r = gen_api({'Test': 'pyslvs_test'})
    assert len(r) == 1
    assert r[0].startswith('#' * 1 + " Test API")

# Generated at 2022-06-23 15:26:25.693975
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:26:31.777365
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from array import array
    from shlex import shlex
    from csv import QUOTE_NONE
    from .parser import Parser
    from .compiler import loader
    p = Parser.new()
    for name, path in walk_packages("array", "."):
        if name == "array":
            p.parse(name, _read(path + '.py'))
    doc = p.compile()
    assert doc == loader("array", ".", True, 1, False)

# Generated at 2022-06-23 15:26:40.678794
# Unit test for function loader
def test_loader():
    from dataclasses import dataclass

    @dataclass(order=True)
    class _Root:
        item: tuple[str, str]
        name: str = ""
        path: str = ""
        part: str = ""
        unit: str = ""

    @dataclass(order=True)
    class _Doc:
        name: str
        text: str

    def get_info(root: str, pwd: str) -> Sequence[_Root]:
        l = []
        for name, path in walk_packages(root, pwd):
            # Load its source or stub
            for ext in [".py", ".pyi"]:
                path_ext = path + ext
                if not isfile(path_ext):
                    continue
                # Parse

# Generated at 2022-06-23 15:26:45.224910
# Unit test for function gen_api
def test_gen_api():
    import sys
    root_names = {
        'pyslvs': 'pyslvs_ui'
    }
    pwd = dirname(sys.argv[0])
    prefix = abspath('docs')
    docs = gen_api(root_names, pwd, prefix=prefix, dry=True)
    assert len(docs) == 1, "No docs"

# Generated at 2022-06-23 15:26:54.743148
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from .logger import logger_level
    from os.path import dirname, join

    class TestWalkPackages(TestCase):
        def get_spec(self, name: str) -> Optional[str]:
            s = find_spec(name)
            if s is None or s.submodule_search_locations is None:
                return
            return dirname(s.submodule_search_locations[0])

        def test_walk(self):
            logger_level('disable')
            pwd = abspath(join(dirname(__file__), '..'))
            root = 'pyslvs'
            self.assertEqual(self.get_spec('pyslvs'), walk_packages(root, pwd).__next__()[1])

# Generated at 2022-06-23 15:27:04.590104
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import dirname
    from shutil import copy2
    from collections import defaultdict
    from importlib import import_module
    from .core import gen_api as g
    from .core._lang import root_names
    from .core._lang import pwd as lang_pwd

    def walk(d):
        for root, _, fs in walk(d):
            for f in fs:
                yield join(root, f)

    assert isinstance(lang_pwd, str)
    assert lang_pwd
    _ = g(root_names, pwd=lang_pwd)


# Generated at 2022-06-23 15:27:11.107282
# Unit test for function walk_packages
def test_walk_packages():
    from .unittest.parametrize import parametrize
    from .unittest import TestCase
    logger.setLevel(logger.DEBUG)

    @parametrize(
        ('test_0',
            'test_0/__init__.py',
            ('test_0.test_1', 'test_0.test_1.__init__')),
        ('test_0',
            'test_0/test_1/__init__.py',
            ('test_0.test_1', 'test_0.test_1.__init__')),
    )
    def unit_test(root, path, expected):
        actual = [x[0] for x in walk_packages(root, dirname(path))]
        assert actual == expected


# Generated at 2022-06-23 15:27:21.681282
# Unit test for function walk_packages
def test_walk_packages():
    func = walk_packages

    class DummyPath:
        def __init__(self, path: str) -> None:
            self.path = abspath(path)

        def __eq__(self, other: str) -> bool:
            return abspath(other).startswith(self.path)

        def __repr__(self) -> str:
            return f"DummyPath({self.path})"

    def mock(
        name: str,
        path: str,
        files: list[str],
        dirs: list[str],
        *,
        pep561_stub: bool = True,
        should_fail: bool = False
    ) -> None:
        """Mock a package for test."""
        if should_fail:
            assert walk_packages(name, path) is None
            return

# Generated at 2022-06-23 15:27:25.589734
# Unit test for function walk_packages
def test_walk_packages():
    from .__main__ import abs_path
    import unittest

    class TestWalkPackages(unittest.TestCase):

        def test_walk(self):
            ep = abs_path('example')
            p = list(walk_packages('pkg', ep))
            self.assertEqual(p, [('pkg.__init__', ep + '/pkg/__init__.py')])
            self.assertTrue(isdir(ep + '/pkg.__pycache__'))

    unittest.main()

# Generated at 2022-06-23 15:27:36.954709
# Unit test for function gen_api
def test_gen_api():
    global logger, sys_path
    try:
        from .logger import logger
    except ImportError:
        from .libs.logger import logger
    logger.debug('=' * 12 + ' Unit Test ' + '=' * 13)
    from .libs import sys_path
    from .libs.directory import pdir
    from .libs.svg2gcode import __name__ as __root__
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--pwd', type=pdir)
    parser.add_argument('--show', action='store_true')
    args = parser.parse_args()
    pwd = args.pwd if args.pwd else __file__
    # -2 for "../" in __file__

# Generated at 2022-06-23 15:27:41.244551
# Unit test for function gen_api
def test_gen_api():
    name = "pyslvs"
    doc = gen_api({
        "Pyslvs": name,
    }, pwd=dirname(__file__), prefix="./test", dry=True)
    assert doc
    assert "{} API".format(name) in doc[0]

# Generated at 2022-06-23 15:27:46.845039
# Unit test for function gen_api
def test_gen_api():
    """Unit test for gen_api."""
    assert gen_api({"numpy": "numpy"})
    assert gen_api({"numpy": "numpy", "scipy": "scipy"})
    assert gen_api({"numpy": "numpy", "scipy": "scipy", "matplotlib": "matplotlib"})

# Generated at 2022-06-23 15:27:51.503270
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .test.test_module import __name__ as name
    p = Parser.new()
    for name, path in walk_packages(name, dirname(__file__)):
        p.parse(name, open(path + ".py", "r").read())
    assert len(p.classes) == 0
    assert len(p.modules) == 0
    assert len(p.functions) == 3
    assert '.'.join(sorted(p.functions)) == 'module_function.module.mod_function'

# Generated at 2022-06-23 15:28:03.338005
# Unit test for function walk_packages
def test_walk_packages():
    """Test algorithm walk_packages"""
    def call(root: str, path: str) -> list[tuple[str, str]]:
        """Call the walk_packages() function."""
        return list(walk_packages(root, path))
    pwd = dirname(abspath(__file__))
    assert call('compiler', pwd) == [('compiler.compiler', 'compiler.py')]
    assert call('compiler', 'compiler') == [('compiler.compiler', 'compiler.py')]
    assert call('compiler.__init__', 'compiler') == [('compiler.compiler', 'compiler.py')]

# Generated at 2022-06-23 15:28:12.228817
# Unit test for function walk_packages
def test_walk_packages():
    paths = {
        './test/test_pkg1/pkg1/test.py':
        'test_pkg1.pkg1.test',
        './test/test_pkg2/pkg2/test.py':
        'test_pkg2.pkg2.test',
        './test/test_pkg2/pkg2/test.pyi':
        'test_pkg2.pkg2.test',
        './test/test_pkg2/pkg2/test2.py':
        'test_pkg2.pkg2.test2',
        './test/test_pkg3/pkg3/__init__.py':
        'test_pkg3.pkg3',
        './test/test_pkg3/pkg3/test.py':
        'test_pkg3.pkg3.test',
    }

# Generated at 2022-06-23 15:28:23.956064
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main

    class Test(TestCase):
        """Test functions."""

        def test_walk_packages(self):
            """Test walk_packages"""
            from . import const
            result = [(name, path) for name, path in walk_packages(const.ROOT_NAME, const.PWD)]

# Generated at 2022-06-23 15:28:33.655205
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    assert list(walk_packages('svgwrite', dirname(__file__))) == [
        ('svgwrite', join(dirname(__file__), 'svgwrite.py'))
    ]

# Generated at 2022-06-23 15:28:38.514250
# Unit test for function loader
def test_loader():
    from shutil import rmtree
    logger.setLevel(99)
    try:
        rmtree('_test')
    except OSError:
        pass
    gen_api({'libs': 'libs'}, '..', prefix='_test', level=1, toc=True)
    logger.setLevel(20)

# Generated at 2022-06-23 15:28:41.568575
# Unit test for function walk_packages
def test_walk_packages():
    assert walk_packages('numpy', '/usr/lib/python3.8/site-packages') is not None
    assert walk_packages('numpy', '.') is not None


# Generated at 2022-06-23 15:28:47.395212
# Unit test for function loader
def test_loader():
    """Test package searching algorithm."""
    from tempfile import TemporaryDirectory
    from shutil import copytree, copy
    from os.path import join

    with TemporaryDirectory() as d:
        for s, d_ in [(".", d), ("group_theory", join(d, "group_theory"))]:
            copytree(s, d_)
        copy("group_theory_ext.so", join(d, "group_theory_ext.so"))
        print(loader("python_group_theory", d))


# Generated at 2022-06-23 15:28:51.876720
# Unit test for function gen_api
def test_gen_api():
    title = 'test_gen_api'
    root_names = {'test gen api': 'pyslvs'}
    pwd = '/Users/yc/Desktop/pyslvs'
    prefix = 'docs'
    link = True
    level = 1
    toc = False
    dry = True

    gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-23 15:29:02.370520
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import exists
    from pkg_resources import Distribution

    prefix = "pytest"
    with TemporaryDirectory() as site_path:
        spec = Distribution(project_name=prefix, version='0.0.1')
        spec.location = site_path
        spec.has_metadata('top_level.txt')
        spec.extras.pop('test', None)
        spec.has_metadata('test/test_top_level.txt')
        spec.extras.pop('tests', None)
        spec.has_metadata('tests/test_top_level.txt')
        spec.has_metadata('foo/__init__.txt')

# Generated at 2022-06-23 15:29:12.445428
# Unit test for function loader
def test_loader():
    """Test for generate API."""
    info = logger.info
    from tempfile import TemporaryDirectory
    from os.path import join as pjoin
    from pyslvs import __version__ as pyslvs_version
    from pyslvs_ui import __version__ as pyslvs_ui_version
    from pyslvs_ui.io import __version__ as pyslvs_ui_io_version

    def assert_doc(doc: str) -> None:
        assert "Packages" in doc
        info("The package is found.")
        assert "pyslvs" in doc
        info("The module is found.")
        assert "Pyslvs: V-REP" in doc
        info("The class is found.")
        assert "pyslvs_ui" in doc
        info("The module is found.")


# Generated at 2022-06-23 15:29:15.084878
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    _ = gen_api({"Test": "test"}, "/tmp/PySLVS-test/site-packages", dry=True)

# Generated at 2022-06-23 15:29:18.453034
# Unit test for function gen_api
def test_gen_api():
    root_names = {"Test": "doc_tester_api_gen", "Test2": "doc_tester_api_gen2"}
    path = dirname(__file__)
    gen_api(root_names, path, dry=True)

# Generated at 2022-06-23 15:29:26.228979
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch
    from shutil import rmtree
    path = "/tmp/site-packages"
    if isdir(path):
        rmtree(path)
    mkdir(path)
    with patch.object(sys_path, 'append', return_value=None):
        with patch.object(sys_path, 'pop', return_value=None):
            sys_path.append(path)
            with open(join(path, "__init__.py"), 'w+') as f:
                f.write("")
            with open(join(path, "test_1.py"), 'w+') as f:
                f.write("def test(): pass")

# Generated at 2022-06-23 15:29:31.673855
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from tempfile import TemporaryDirectory
    from os import mknod
    from shutil import copytree
    from os.path import exists

    with TemporaryDirectory() as tp:
        name = "a"
        path = join(tp, name)
        mkdir(path)
        mknod(join(path, "__init__.py"))
        mknod(join(path, f"{name}.py"))
        b = join(path, "b")
        mkdir(b)
        mknod(join(b, "__init__.py"))
        mknod(join(b, f"{name}.py"))
        copytree(tp, join(tp, "x"))
        b = join(join(tp, "x"), "b")
        mkdir(b)


# Generated at 2022-06-23 15:29:32.911212
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs", "../../"):
        print(name, path)

# Generated at 2022-06-23 15:29:40.674957
# Unit test for function walk_packages