

# Generated at 2022-06-23 15:19:46.290181
# Unit test for function loader
def test_loader():
    from unittest import mock
    from importlib.machinery import SourceFileLoader
    mock_module = mock.Mock()
    mock_module.__doc__ = "docstring"
    mock_module.__file__ = "test.py"
    mock_module.__package__ = "pyslvs_ui"
    pwd = "./"
    root_name = "pyslvs_ui"
    mock_loader = mock.Mock(spec=SourceFileLoader)
    mock_loader.name = 'mock_loader'
    mock_loader.get_source.return_value = "# Test module!!"
    mock_loader.exec_module.return_value = mock_module
    with mock.patch.object(mock_loader, 'exec_module', return_value=mock_module):
        _load_module

# Generated at 2022-06-23 15:19:53.331448
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    p = Parser.new(True, 1)
    assert list(walk_packages('pyslvs', dirname(__file__))) == [
        ('parser.parser', join(dirname(__file__), 'parser.py')),
        ('parser.interpreter', join(dirname(__file__), 'interpreter.py')),
    ]
    assert _load_module('parser.parser', __file__, p) is False


# Generated at 2022-06-23 15:20:01.852293
# Unit test for function loader
def test_loader():
    from re import findall
    from sys import path
    root = "pyslvs"
    path.append(parent(__file__))
    for name, path in walk_packages(root, ".."):
        print(f"{name} <= {path}")
    doc = loader(root, parent(__file__), True, 1, True)
    assert name in doc
    print(doc)
    assert 'def plot_color_map(color_map)' in findall(
        r'```python([^`]+)```',
        doc,
    )[0]

# Generated at 2022-06-23 15:20:07.095096
# Unit test for function loader
def test_loader():
    from os import chdir
    from os.path import dirname, join
    root_path = dirname(__file__)
    for i in range(4):
        chdir(root_path)
        path = join('_build', 'test_api.md')
        with open(path, 'w+') as f:
            f.write(loader('test_api', '.', False, i, False))
    chdir(root_path)

# Generated at 2022-06-23 15:20:12.496284
# Unit test for function walk_packages
def test_walk_packages():
    logger.info("Test: walk_packages")
    path = join(_site_path("matplotlib"), 'axes')
    logger.info(f"path: {path}")
    logger.info("Result:")
    for name, path in walk_packages("axes", path):
        logger.info(f"{name} <= {path}")


# Generated at 2022-06-23 15:20:22.297323
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, TestLoader, main
    from os.path import dirname

    class TestWalk(TestCase):

        def test_walk_packages(self):
            for _, path in walk_packages("test_walk", dirname(__file__)):
                self.assertIn(path, [
                    f"{dirname(__file__)}/test_walk.pyi",
                    f"{dirname(__file__)}/test_walk/__init__.pyi",
                    f"{dirname(__file__)}/test_walk/test.pyi",
                    f"{dirname(__file__)}/test_walk/test.py",
                ], "error while walking package")

    test_cases = [TestWalk]
    loader = TestLoader()

# Generated at 2022-06-23 15:20:31.489270
# Unit test for function loader
def test_loader():
    from .test import log_clear

    log_clear()
    logger.setLevel('DEBUG')
    assert loader('numpy', '.', link=True, level=1, toc=False) != ""
    assert loader('numpy', '.', link=False, level=1, toc=False) != ""
    assert loader('sipython', '.', link=True, level=1, toc=False) != ""
    assert loader('sipython', '.', link=False, level=1, toc=False) != ""
    assert loader('scipy', '.', link=True, level=1, toc=False) != ""
    assert loader('scipy', '.', link=False, level=1, toc=False) != ""

# Generated at 2022-06-23 15:20:39.824782
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages test."""
    sp = _site_path('pyslvs')
    ans = ['pyslvs', 'pyslvs.__main__', 'pyslvs.__init__',
           'pyslvs.data', 'pyslvs.data.__init__',
           'pyslvs.data.a', 'pyslvs.data.a.__init__',
           'pyslvs.data.b', 'pyslvs.data.b.__init__',
           'pyslvs.data.b.c', 'pyslvs.data.b.c.__init__',
           'pyslvs.data.b.c.d', 'pyslvs.data.b.c.d.__init__']

# Generated at 2022-06-23 15:20:44.330897
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    for n, p in walk_packages("tkinter", "."):
        print(n, p)
        assert '.' in n
        assert isfile(p + ".py")

# Generated at 2022-06-23 15:20:47.487388
# Unit test for function loader
def test_loader():
    root = 'pyslvs'
    pwd = '../../'
    print(loader(root, pwd, True, 1, True))


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:20:57.583302
# Unit test for function loader
def test_loader():
    from unittest import TestCase
    from sys import modules as sys_modules
    from os import remove

    class TestLoader(TestCase):

        class T1:
            """This is a test case."""

        class T2:
            """This is another test case."""

        t1 = T1()
        t2 = T2()

        def setUp(self):
            # Prepare the script
            with open("test.py", "w") as f:
                f.write(self.t1.__doc__)
            with open("test.pyi", "w") as f:
                f.write(self.t2.__doc__)

        def tearDown(self):
            remove("test.py")
            remove("test.pyi")

        def test_classic(self):
            from .parser import Parser


# Generated at 2022-06-23 15:21:09.328382
# Unit test for function loader
def test_loader():
    from unittest import TestCase, mock
    from types import ModuleType
    from os import getcwd

    class Module(ModuleType):
        """Simple module stub."""
        __file__ = 'test.py'
        __doc__ = "# test.py\n\n::\n\t>>> test\n\tNone\n"

    def _import_module(name: str) -> ModuleType:
        if name == 'test':
            return Module(name)
        raise ImportError(f"No module named {name}")

    class TestLoader(TestCase):
        """Test for the API with stubs."""
        @mock.patch('importlib.import_module', _import_module)
        def test_loader_api(self) -> None:
            """Loader API."""

# Generated at 2022-06-23 15:21:15.567833
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import getcwd, chdir
    from importlib import import_module

    root = 'api_loader'
    pwd = mkdtemp(prefix='pyslvs-')
    chdir(pwd)
    mkdir(root)
    try:
        doc = loader(root, getcwd(), False, 1, False)
        assert not doc
        pkg = import_module(root)
        assert pkg.__doc__
        doc = loader(root, getcwd(), False, 1, False)
        assert pkg.__doc__.strip() in doc
    finally:
        rmtree(pwd)


# Generated at 2022-06-23 15:21:22.561929
# Unit test for function walk_packages
def test_walk_packages():
    from importlib import import_module
    from pyslvs_ui.compiler import walk_packages
    name = 'pyslvs_ui'
    path = _site_path(name)
    modules = set()
    for name, path in walk_packages(name, path):
        modules.add(name)
    assert len(modules) == len(set(import_module(name).__all__))
    assert all(hasattr(import_module(m), "__all__") for m in modules)
    # Should raise error
    import_module(name).__all__.append('abc')
    try:
        for name, path in walk_packages(name, path):
            modules.add(name)
    except ValueError:
        pass
    else:
        raise Exception

# Generated at 2022-06-23 15:21:28.649365
# Unit test for function gen_api
def test_gen_api():
    # Test simple package
    root_names = {
        'Pyslvs Package': 'pyslvs',
    }
    pwd = abspath(dirname(__file__))
    assert len(gen_api(root_names, pwd, level=2)) == 1
    # Test subpackage
    root_names = {
        'Vpython Package': 'vpython',
        'Numpy Package': 'numpy',
    }
    assert len(gen_api(root_names, pwd, level=2, toc=True)) == 2
    # Test the "pyslvs-stubs" package
    root_names = {
        'Pyslvs-stubs Package': 'pyslvs-stubs',
    }

# Generated at 2022-06-23 15:21:34.494794
# Unit test for function walk_packages
def test_walk_packages():
    from pkgutil import get_loader

    l = get_loader('pyslvs_ui')
    assert l is not None

    logger.info(f"Loading root: 'pyslvs_ui' from {l.path}")
    for name, path in walk_packages('pyslvs_ui', dirname(l.path)):
        logger.info(f"{name.ljust(100)} <= {path}")


# Generated at 2022-06-23 15:21:42.192576
# Unit test for function gen_api
def test_gen_api():
    doc = gen_api({
        "[Pyslvs](https://pyslvs.org)": 'pyslvs_ui.async_',
        "Pyslvs-Core": 'pyslvs_core',
        "Pyslvs-Dynamics": 'pyslvs_dynamics',
        "Pyslvs-Graph": 'pyslvs_graph',
        "Pyslvs-SP": 'pyslvs_sp',
    }, pwd='../pyslvs', dry=True)
    logger.info(f"Total docs: {len(doc)}")

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:21:44.246654
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    assert gen_api({'useless': 'pkg_resources'}, dry=True)



# Generated at 2022-06-23 15:21:45.909763
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"dummy": "dummy"})  # type: ignore

# Generated at 2022-06-23 15:21:56.687879
# Unit test for function walk_packages
def test_walk_packages():
    from .parser import parent
    from .compiler import walk_packages
    from .test_compiler import stest

    stest(parent, 'a.b.c', 'a.b.c', 'a.b', 'a')
    stest(parent, 'a.b.c.__init__', 'a.b.c', 'a.b', 'a')
    stest(parent, 'a.b.c.d', 'a.b.c.d', 'a.b.c', 'a.b', 'a')
    stest(parent, 'a.b.c.d.__init__', 'a.b.c.d', 'a.b.c', 'a.b', 'a')


# Generated at 2022-06-23 15:22:07.039062
# Unit test for function gen_api
def test_gen_api():
    """Test."""

    def test_module(name: str, *, doc: str) -> None:
        """Test the function."""
        sys_path.append(pkg_path)
        assert gen_api({name: name}, pkg_path) == [
            "# " + name + " API\n\n" + doc
        ]
        assert gen_api({name: name}, pkg_path, dry=True) == [
            "# " + name + " API\n\n" + doc
        ]

    import tempfile
    pkg_path = tempfile.mkdtemp()

# Generated at 2022-06-23 15:22:09.064332
# Unit test for function loader
def test_loader():
    assert _load_module("foo", "foo", Parser.new(False, 1, False))



# Generated at 2022-06-23 15:22:14.320652
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api()."""
    from .logger import logger
    for lvl in range(5):
        logger.setLevel(lvl)
        assert len(gen_api({"title": "test"}, dry=True)) == 1
    assert logger.level_name == "INFO"

# Generated at 2022-06-23 15:22:18.588564
# Unit test for function walk_packages
def test_walk_packages():
    assert all(name.startswith("pyslvs-ui") for name, _ in walk_packages("ui", "./"))
    assert all("__init__.py" in path for _, path in walk_packages("ui", "./"))

# Generated at 2022-06-23 15:22:27.411096
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from io import StringIO
    from .builder import package_builder

    with TemporaryDirectory() as td, StringIO() as io:
        # Build testing package
        path = join(td, 'test')
        package_builder(path)
        # Path to `test_loader`
        this_directory = abspath(dirname(__file__))
        # Path to `test`
        sys_path.insert(0, path)
        # Write the log to buffer
        logger.add(io)
        logger.opt(level='DEBUG')
        # Load package `test`
        doc = loader('test', this_directory, False, 2, True)
        logger.remove()
        # Write to file
        _write(join(path, 'README.md'), doc)
        # Assert log

# Generated at 2022-06-23 15:22:28.208982
# Unit test for function gen_api
def test_gen_api():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:22:37.271677
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from unittest.mock import patch
    loader("pyslvs", "tests/resources", False, 1, False)
    loader("pyslvs", "tests/resources", True, 1, False)
    loader("pyslvs", "tests/resources", True, 1, True)
    with patch("pyslvs_ui.compiler.read", side_effect=_read):
        with patch("pyslvs_ui.compiler.write", side_effect=_write):
            gen_api({"Pyslvs": "pyslvs"}, pwd="tests/resources", dry=True)
            gen_api({"Pyslvs": "pyslvs"}, pwd="tests/resources", link=False)

# Generated at 2022-06-23 15:22:46.027538
# Unit test for function loader
def test_loader():
    import os
    import os.path
    import sys
    sys.path.append(os.path.abspath(os.path.dirname(__file__)))
    import pyslvs
    import pint
    import qtpy.QtCore
    import qtpy.QtGui
    import qtpy.QtWidgets
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pint': 'pint',
        'PyQtCore': 'qtpy.QtCore',
        'PyQtGui': 'qtpy.QtGui',
        'PyQtWidgets': 'qtpy.QtWidgets',
    }
    dry = True
    from ..logger import logger
    from ..compiler import gen_api

# Generated at 2022-06-23 15:22:56.426066
# Unit test for function walk_packages
def test_walk_packages():
    from .helper import delete_dir, make_dir
    from .site_packages import site_packages
    assert site_packages()
    make_dir(join(site_packages(), 'a'))
    make_dir(join(site_packages(), 'b'))

    def make_package(p):
        doc = '\n'.join(f'    """{n}"""\n    def {n}():\n        pass' for n in ('abc', 'xyz'))
        _write(join(site_packages(), p + '.py'), f'class {p.title()}:\n{doc}')
        _write(join(site_packages(), p + '.pyi'), f'class {p.title()}:\n{doc}')

    make_dir(join(site_packages(), 'a', 'a1'))
   

# Generated at 2022-06-23 15:22:59.116781
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil
    import tempfile
    import pyslvs as slvs
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        output = gen_api({"Solver": slvs.__name__})
        assert output and output[0]
        shutil.rmtree(os.path.join(tmpdir, "docs"))

test_gen_api()

# Generated at 2022-06-23 15:23:08.896258
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    p = Path(".") / "pyslvs"

# Generated at 2022-06-23 15:23:18.646313
# Unit test for function gen_api
def test_gen_api():
    from ast import parse
    from pkgutil import get_loader
    from pathlib import Path
    from importlib import import_module, reload
    from shutil import rmtree
    from .parser import parse_imports

    def create_module(name: str, path: str) -> None:
        with open(path, 'w+') as f:
            f.write(f'from {name} import func')
        ldr = get_loader(name)
        reload(import_module(name))

    def create_module_with_doc(name: str, path: str, doc: str) -> None:
        with open(path, 'w+') as f:
            f.write('"""This is a module.\n')
            f.write(f'{doc}\n"""')

# Generated at 2022-06-23 15:23:23.877404
# Unit test for function gen_api
def test_gen_api():
    def _gen(root_name: str, dry: bool = False) -> None:
        gen_api({'Test': root_name}, None, dry=dry)
    _gen('test')
    assert isfile('docs/test-api.md')
    _gen('test', True)
    assert isfile('docs/test-api.md')
    _gen('test_test')
    assert not isfile('docs/test-test-api.md')
    _gen('test_test', True)
    assert not isfile('docs/test-test-api.md')
    _gen('__main__')
    assert not isfile('docs/__main___api.md')
    _gen('__main__', True)
    assert not isfile('docs/__main___api.md')


# Generated at 2022-06-23 15:23:25.364501
# Unit test for function loader
def test_loader():
    import doctest
    return doctest.testmod(verbose=True)



# Generated at 2022-06-23 15:23:32.097498
# Unit test for function walk_packages
def test_walk_packages():
    p = Parser.new()
    for name, path in walk_packages("pyslvs", "./"):
        # Load its source or stub
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
    assert p.compile().strip()

# Generated at 2022-06-23 15:23:36.238121
# Unit test for function gen_api
def test_gen_api():
    logger.info(gen_api({
        'pyslvs': 'pyslvs'
    }, pwd='.', prefix='_build'))


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:23:45.889241
# Unit test for function loader
def test_loader():
    """Function loader."""
    import os
    import sys
    import doctest
    os.environ['PYSLVS_LOGLEVEL'] = 'INFO'
    sys.argv = ['', '-v']
    parser = Parser.new(link=False, level=0, toc=True, test=True)
    for name, path in walk_packages('pyslvs', os.path.dirname(__file__)):
        if not path.endswith('.py'):
            continue
        parser.parse(name, _read(path))
    root = parser.compile()
    for i, r in enumerate(root):
        logger.debug(f'{i}: {r}')
    assert root.startswith('# API\n\n## Modules')

# Generated at 2022-06-23 15:23:55.439831
# Unit test for function walk_packages
def test_walk_packages():
    import pkgutil
    import site
    import os
    import sys
    import tempfile
    import shutil
    import importlib.util
    import io

    def _create_package(p, n, s):
        os.mkdir(p)
        f = tempfile.NamedTemporaryFile(dir=p, delete=False)
        f.write('{} = {}'.format(n, repr(s)).encode())
        f.close()

    def _get_init(p):
        init = '__init__.py'
        if not os.path.exists(os.path.join(p, init)):
            with open(os.path.join(p, init), 'w') as f:
                f.write('\n')


# Generated at 2022-06-23 15:24:01.599594
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'merpy': 'merpy'}, './test/')
    assert gen_api({'merpy': 'merpy'}, './test/', dry=True)
    assert gen_api({'merpy': 'merpy'}, './test/', level=2, dry=True)
    assert gen_api({'merpy': 'merpy'}, './test/', level=2, toc=True, dry=True)

# Generated at 2022-06-23 15:24:12.096072
# Unit test for function walk_packages

# Generated at 2022-06-23 15:24:13.416290
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"Pyslvs": "pyslvs"}, pwd="..", prefix="test", dry=True)

# Generated at 2022-06-23 15:24:20.311390
# Unit test for function gen_api
def test_gen_api():
    """Unit test function gen_api."""
    import sys
    import os
    test_dir = "_test_docs"
    if "PYSLVS_DOCS_TEST_DOCS" in os.environ:
        test_dir = os.environ["PYSLVS_DOCS_TEST_DOCS"]
    sys.argv.append(test_dir)
    from . import main
    main()



# Generated at 2022-06-23 15:24:23.440276
# Unit test for function gen_api
def test_gen_api():
    """Unit test: gen_api."""
    import tempfile
    with tempfile.TemporaryDirectory() as pwd:
        root_names = {'Fake': 'fake'}
        gen_api(root_names, pwd)

# Generated at 2022-06-23 15:24:34.529152
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy

    def create_test_package_tree(tmpdir: str) -> None:
        """Create a test package tree with the following structure:

        tmpdir
        ├── some
        │   └── package
        │       ├── __init__.py
        │       └── module.py
        ├── some
        │   └── package2
        │       ├── __init__.py
        │       ├── module.py
        │       └── module.pyi
        └── some
            └── package3
                ├── __init__.py
                ├── module.py
                └── module.c
        """

# Generated at 2022-06-23 15:24:42.946421
# Unit test for function walk_packages
def test_walk_packages():
    name = 'pyslvs'
    path = _site_path(name)
    logger.info(f"Find module: {path}")
    modules = walk_packages(name, path)
    assert 'pyslvs' in [name for name, _ in modules]
    assert 'ui.project.editor_widget' in [name for name, _ in modules]
    count = 0
    for _, path in modules:
        if isfile(path + '.pyi'):
            assert isfile(path + '.py')
            assert isfile(path + '.pyi')
            count += 2
        else:
            assert isfile(path + '.py')
            count += 1
    logger.info(f"Modules: {count}")
    assert count != 0


if __name__ == "__main__":
    test

# Generated at 2022-06-23 15:24:50.426566
# Unit test for function loader
def test_loader():
    """Test for loader"""
    from .parser import Parser
    from enum import Enum
    from copy import copy
    from math import log
    from threading import Thread
    from typing import Optional
    from .logger import logger
    from .export import gen_api, PEP561_SUFFIX

    class Float(float, Enum):
        ZERO = 0.0
        ONE = 1.0
        TWO = 2.0
        THREE = 3.0
        NONE = None

    class Item:
        """Single element for testing."""
        i: int
        f: float
        text: str
        default: Optional[int] = None

        # No effect on documentation

# Generated at 2022-06-23 15:24:56.854560
# Unit test for function gen_api
def test_gen_api():
    class A:
        def foo(self, a: int) -> int:
            pass

        def bar(self, b: int, c: int) -> int:
            pass

    class B:
        pass

    class C(B):
        def foo(self, a: int) -> int:
            pass

    class D:
        def __init__(self, *_: int, d: int = 0) -> None:
            pass

    class E:
        def __init__(self, f: int = 0) -> None:
            pass

    gen_api({
        "Test": test_gen_api.__module__,
    }, dry=True)


# Generated at 2022-06-23 15:25:00.455683
# Unit test for function walk_packages
def test_walk_packages():
    fs = [
        'a',
        'b/a.py',
        'b/b',
        'b/b.pyi',
        'b/b/a.py',
    ]
    names = [
        ('a', 'b.a'),
        ('b.b', 'b.b')
    ]
    i = 0
    for name, path in walk_packages('b', '.'):
        assert names[i] == (name, path)
        i += 1
    assert i == len(names)

# Generated at 2022-06-23 15:25:07.976658
# Unit test for function walk_packages
def test_walk_packages():
    a = {
        ('demo.__init__', 'demo' + sep + '__init__.py'),
        ('demo.__init__', 'demo' + sep + '__init__.pyi'),
        ('demo.a', 'demo' + sep + 'a.py'),
        ('demo.b', 'demo' + sep + 'b.pyi'),
        ('demo.b', 'demo' + sep + 'b.py'),
    }
    b = {
        'doc.a',
        'doc.b',
        'doc.c',
    }

# Generated at 2022-06-23 15:25:10.845721
# Unit test for function gen_api
def test_gen_api():
    class Dict(dict):
        def __setitem__(self, key, value):
            raise AssertionError
    print(gen_api(Dict({'My Package': 'my_package'})))

# Generated at 2022-06-23 15:25:14.320886
# Unit test for function gen_api
def test_gen_api():
    api = gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
    }, '.', level=2, dry=True)
    assert api

# Generated at 2022-06-23 15:25:20.596769
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('parent', join('parent', 'docs', '_build'))) == [
        ('parent', 'parent/parent/__init__.py'),
        ('parent.__init__', 'parent/parent/__init__.py'),
        ('parent.child', 'parent/parent/child.py'),
        ('parent.child.__init__', 'parent/parent/child/__init__.py'),
    ]

# Generated at 2022-06-23 15:25:29.518342
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api function."""
    docs = gen_api({'Test1': 'test1'}, dry=True)
    assert len(docs) == 1
    docs = gen_api({'Test2': 'test2'}, dry=True)
    assert len(docs) == 1
    docs = gen_api({'Test2': 'test2', 'Test1': 'test1'}, dry=True)
    assert len(docs) == 2
    gen_api({'Test1': 'test1'})
    gen_api({'Test2': 'test2'})
    gen_api({'Test2': 'test2', 'Test1': 'test1'})

# Generated at 2022-06-23 15:25:40.173803
# Unit test for function loader
def test_loader():
    import shutil
    import tempfile
    from os.path import join as pjoin

    def _mkdir(p):
        if not isdir(p):
            mkdir(p)

    tdir = tempfile.mkdtemp()
    _mkdir(pjoin(tdir, 'pytest'))
    _mkdir(pjoin(tdir, 'pytest', 'test'))
    _mkdir(pjoin(tdir, 'pytest', 'test', 'conftest'))
    _mkdir(pjoin(tdir, 'pytest', 'test', 'unit'))
    _mkdir(pjoin(tdir, 'pytest', 'test', 'unit', 'test_doc'))

# Generated at 2022-06-23 15:25:51.387386
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import record_xml_property
    from tempfile import mkdtemp
    import shutil
    path = mkdtemp()
    logger.debug(f"A temporary directory is created: {path}")

# Generated at 2022-06-23 15:26:03.045298
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    from .test_parser import _import
    from .test_parser import _file
    from .test_parser import _dir
    from .test_parser import __file__ as __path__

    _test = join(abspath(dirname(__path__)), 'test_module')
    assert _file(_test, 'a.py')
    assert _file(_test, 'a.pyi')
    assert _file(_test, 'b.py')
    assert _file(_test, 'b.pyi')
    assert _file(_test, 'c.py')
    assert _file(_test, 'c.pyi')
    assert _file(_test, 'd.py')
    assert _file(_test, 'd.pyi')

# Generated at 2022-06-23 15:26:09.475974
# Unit test for function loader
def test_loader():
    # Generate a package with only one "core.py" module
    _write('test/core.py', 'def say():\n    """Hello world!"""')
    _write('test/__init__.py', 'from .core import say')
    p = Parser.new(False)
    for name, path in walk_packages('test', 'test'):
        p.parse(name, _read(path + '.py'))
    assert p.compile() == '## `test`\n\n### `test.core`\n\n#### `test.core.say()`\n\nHello world!\n'

    # Test the main function
    _write('test/__init__.py', '')

# Generated at 2022-06-23 15:26:19.314551
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .core import PYSLVS_TEST_DIR

    p = Parser.new()
    for name, path in walk_packages("core", PYSLVS_TEST_DIR):
        logger.info(f"{name} <= {path}")
        p.parse(name, _read(path + ".py"))

# Generated at 2022-06-23 15:26:25.030809
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    from ._version import get_versions
    assert p.parse('pyslvs._version', get_versions.__doc__) is None
    assert p.parse('pyslvs', __doc__) is None
    assert p.parse('pyslvs', """
    This is a test.

    Ignore this line.

    """
    ).strip() == "This is a test."

# Generated at 2022-06-23 15:26:29.506321
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"AAA": "aaa"})
    assert gen_api({"BBB": "sys"})
    assert gen_api({"CCC": "os"})
    assert gen_api({"DDD": "os.path"})
    assert gen_api({"EEE": "math", "FFF": "pyslvs"})



# Generated at 2022-06-23 15:26:37.138643
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree, copytree
    from tempfile import mkdtemp
    from distutils.dir_util import copy_tree
    from .config import get_root_names

    def make_simple_package():
        """Make a simple package.

        package/
            variable.py

        package/sub_package/
            something.py
        """
        path = mkdtemp()
        logger.info(f"Create directory: {path}")
        with open(join(path, "variable.py"), 'w') as f:
            f.write("if False:")
            f.write("\n    a = 1")
            f.write("\n    b = 2")

# Generated at 2022-06-23 15:26:47.654017
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os.path import dirname, basename
    from .logger import log_format, log_level, set_log_level
    from .testing import test_dir
    from .imports import import_module
    from .script_gen import gen_script

    set_log_level(log_level.DEBUG)
    with TemporaryDirectory() as pwd:
        path = join(pwd, 'pyslvs')
        mkdir(path)
        gen_script(join(test_dir(), 'tests'), path)
        gen_api({'PySLVS': 'pyslvs'}, pwd)
        spec = find_spec('pyslvs')
        assert spec is not None, 'Failed to find module'
        import_module('numpy', spec.origin)

# Generated at 2022-06-23 15:26:50.804524
# Unit test for function gen_api
def test_gen_api():
    from . import loader
    from .parser import Parser
    from .logger import silent
    with silent():
        gen_api({"Pyslvs": "pyslvs"},
                pwd=loader.__path__[0])

# Generated at 2022-06-23 15:26:58.809243
# Unit test for function loader
def test_loader():
    import sys
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        # Fill the empty folder
        tmp_path = join(tmpdir, 'tmp_package')
        mkdir(tmp_path)
        # Write `__init__.py` for package
        _write(join(tmp_path, "__init__.py"), "a = 0\n")
        # Write `tmp_package.py` for package
        _write(join(tmp_path, "tmp_package.py"), "a = 1\n")
        # Write `tmp_package.pyi` for package
        _write(join(tmp_path, "tmp_package.pyi"), "a: int\n")
        # Write `tmp_package.c` for package

# Generated at 2022-06-23 15:27:07.734193
# Unit test for function walk_packages
def test_walk_packages():
    from .test_files import example_modules as pwd
    from .test_files.example_modules.demo.__init__ import __doc__ as init_doc
    from .test_files.example_modules.demo.sub.__init__ import __doc__ as sub_doc
    from .test_files.example_modules.demo.sub.subsub.__init__ import __doc__ as subsub_doc
    modules = [
        "demo", "demo.__init__", "demo.sub", "demo.sub.__init__",
        "demo.sub.subsub", "demo.sub.subsub.__init__"
    ]
    items = [
        init_doc, init_doc, sub_doc, sub_doc, subsub_doc, subsub_doc
    ]

# Generated at 2022-06-23 15:27:17.197962
# Unit test for function walk_packages
def test_walk_packages():
    def check(p1: str, p2: str) -> None:
        i = 0
        while True:
            n1, _ = next(p1)
            n2, _ = next(p2)
            assert n1 == n2
            i += 1
        assert i == 264

    p1 = walk_packages("pyslvs", "D:\\GitHub\\Slvs-Core\\pyslvs")
    p2 = walk_packages("pyslvs", "D:\\GitHub\\Slvs-Core\\pyslvs")
    check(p1, p2)

# Generated at 2022-06-23 15:27:25.827752
# Unit test for function gen_api
def test_gen_api():
    from sys import getfilesystemencoding
    from importlib import reload
    from .locale import setup_locale
    from .logger import setup_logger
    from .parser import Parser
    from .api_doc import get_api_dict
    if 'PYSLVS_PWD' in os.environ:
        pwd = os.environ['PYSLVS_PWD']
    else:
        pwd = dirname(abspath(__file__))
        if pwd.endswith('/tools'):
            pwd = dirname(pwd)
    os.environ['PYSLVS_PWD'] = pwd
    sys_path.append(pwd)

# Generated at 2022-06-23 15:27:37.171747
# Unit test for function gen_api
def test_gen_api():
    """Unit test: gen_api"""
    import tempfile
    import shutil

    def _remove_dir(path):
        shutil.rmtree(path, ignore_errors=True)

    def _write_file(path, data):
        with open(path, 'w+') as f:
            f.write(data)

    def _test(name, version, data, *, dryrun=False):
        with tempfile.TemporaryDirectory() as tmpdir:
            _write_file(join(tmpdir, '__init__.py'), data)
            root_names = {'Temp_script': name}
            return gen_api(root_names, tmpdir, toc=True, dry=dryrun)

    def test_simple():
        """Test simple script."""

# Generated at 2022-06-23 15:27:48.150683
# Unit test for function gen_api
def test_gen_api():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        os.chdir(td)
        os.mkdir('foo')
        with open(os.path.join(td, 'foo', '__init__.py'), 'w+', encoding='utf-8') as f:
            f.write('"""Docstring for root.\n\n@attr1: 123\n"""\n')
        os.mkdir('bar')
        with open(os.path.join(td, 'bar', '__init__.py'), 'w+', encoding='utf-8') as f:
            f.write('"""Docstring for root.\n\n@attr1: 123\n"""\n')
        os.mkdir('baz')

# Generated at 2022-06-23 15:27:52.378895
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({
        "Pyslvs": "pyslvs",
        "Revolute": "pyslvs_ui.revolute",
        "Pobil": "pyslvs_ui.pobil",
        "VChart": "pyslvs_ui.vchart",
        "QtCore": "PySide2.QtCore",
    })


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-23 15:28:03.561104
# Unit test for function walk_packages
def test_walk_packages():
    from .__main__ import __file__ as __main__
    src = abspath(dirname(__main__))

    def find(name: str) -> list:
        return [path for _, path in walk_packages(name, src)]

    def test(name: str, paths: list):
        assert find(name) == paths

    test('dockt', [
        src + '/dockt/__init__.py',
        src + '/dockt/__main__.py',
        src + '/dockt/__version__.py',
        src + '/dockt/gen_api.py',
        src + '/dockt/logger.py',
        src + '/dockt/parser.py',
        src + '/dockt/yaml_docs.py',
    ])

# Generated at 2022-06-23 15:28:12.349990
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import dirname, normpath
    from .parser import Parser
    from .__init__ import __file__
    from ._compiler import gen_api
    for _ in sys_path:
        if _.endswith('site-packages'):
            sys_path.remove(_)
    with TemporaryDirectory() as pwd:
        copytree(normpath(dirname(__file__) + '/../tests'), pwd)
        # Create the `site-packages` directory,
        # and copy the `pyslvs` section to it.
        mkdir(join(pwd, 'site-packages'))
        copytree(join(pwd, 'pyslvs'), join(pwd, 'site-packages', 'pyslvs'))


# Generated at 2022-06-23 15:28:16.938667
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    root_names = {
        'test': 'test_package',
    }
    pwd = mkdtemp()
    gen_api(root_names, pwd, dry=True)


# Generated at 2022-06-23 15:28:26.806102
# Unit test for function walk_packages
def test_walk_packages():
    from os import rmdir, remove
    from os.path import exists
    from shutil import copy2

    def make_dir(path: str, name: str, stub: bool = False) -> None:
        mkdir(path)
        for i in range(4):
            for ext in ('.py', '.pyi'):
                if not exists(path + ext):
                    copy2(name + ext, path + ext)
                    continue
            stub = not stub
            name += '1'
            path = join(path, name)
            make_dir(path, name, stub)

    make_dir('000', '000')
    make_dir('111', '111')
    make_dir('222', '222')
    make_dir('333', '333', True)
    root = 'test_walk_packages'
   

# Generated at 2022-06-23 15:28:28.104941
# Unit test for function gen_api
def test_gen_api():
    # TODO
    return True

# Generated at 2022-06-23 15:28:36.252976
# Unit test for function gen_api
def test_gen_api():
    import pkgutil
    import test
    docs = gen_api({'Imported Package': 'test'}, pkgutil.get_loader('test').path)
    assert docs
    assert docs[0].endswith('gen-api.md')
    assert not 'Imported Package API' in test.__doc__
    assert all(i in test.__doc__ for i in [
        '# Test',
        '## Test Class',
        '### Attributes',
        '### Methods',
        '## Test Class 2',
        '### Attributes',
        '### Methods',
        '## test_func',
        '## test_func2',
        '## test_func3',
        '## Test Class 3',
        '### Attributes',
        '### Methods',
    ])

# Generated at 2022-06-23 15:28:40.515135
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    docs = gen_api({'Pyslvs': 'pyslvs'}, level=3)
    assert docs[0].startswith('### Pyslvs API')
    assert docs[0].find('pyslvs.ui') != -1

# Generated at 2022-06-23 15:28:48.539056
# Unit test for function loader
def test_loader():
    import pytest
    from os.path import dirname, join, realpath
    from .parser import Parser

    def _parser(pwd: str) -> Parser:
        return loader('op2d', realpath(join(dirname(__file__), pwd)), link=False, level=1, toc=False)

    def _s():
        p = Parser.new()
        p.parse("op2d.geometry", """[op2d.geometry]""")

# Generated at 2022-06-23 15:28:50.136673
# Unit test for function loader
def test_loader():
    doc = loader('example', 'example', True, 1, True)
    assert doc



# Generated at 2022-06-23 15:28:56.464793
# Unit test for function walk_packages
def test_walk_packages():

    from .test import TEST_PATH

    # Example: test.a.b
    assert list(walk_packages("a", TEST_PATH)) == [('a.b', join(TEST_PATH, 'a', 'b.py'))]

    # Example: test.__init__
    assert list(walk_packages("", TEST_PATH)) == [('test.__init__', join(TEST_PATH, '__init__.py'))]

    # Example: test.a.b.c
    assert list(walk_packages("a", join(TEST_PATH, 'a'))) == [('a.b.c', join(TEST_PATH, 'a', 'b', 'c.py'))]

    # Example: test.a.b.c.pyi

# Generated at 2022-06-23 15:29:05.806447
# Unit test for function walk_packages
def test_walk_packages():
    assert(list(walk_packages("foo", "./tests/pkg")) == \
           [("foo", "./tests/pkg/foo/__init__.py"),
            ("foo.bar", "./tests/pkg/foo/bar/__init__.py"),
            ("foo.bar.baz", "./tests/pkg/foo/bar/baz/__init__.py"),
            ("foo.bar.baz.qux", "./tests/pkg/foo/bar/baz/qux/__init__.py"),
            ("foo.bar.baz.qux.spam", "./tests/pkg/foo/bar/baz/qux/spam.py")])

# Generated at 2022-06-23 15:29:07.849411
# Unit test for function loader
def test_loader():
    """Unit test."""
    assert loader('pyslvs', 'pyslvs', False, 1, False) != ""

# Generated at 2022-06-23 15:29:17.981421
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory

    title = 'TestAPI'
    root = 'testapi'
    root_names = {title: root}
    dir_path = 'test_data'

    def make_dir() -> None:
        try:
            mkdir(dir_path)
        except FileExistsError:
            return
        mkdir(join(dir_path, f'{root}'))
        mkdir(join(dir_path, f'{root}', 'test'))
        mkdir(join(dir_path, f'{root}', 'test-stubs'))
        mkdir(join(dir_path, f'{root}', 'test', 'test2'))

# Generated at 2022-06-23 15:29:23.533737
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        mkdir(join(temp, 'test'))
        mkdir(join(temp, 'test', '__pycache__'))
        mkdir(join(temp, 'test', 'subtest'))
        # Write test file
        _write(join(temp, 'test', '__init__.py'), "__all__ = 'test'")
        _write(join(temp, 'test', 'subtest', '__init__.py'), "__all__ = 'subtest'")
        _write(join(temp, 'test.py'), "import test")
        # Data
        logger.debug('loader test')
        logger.debug('=' * 30)
        # >>> import test

# Generated at 2022-06-23 15:29:27.105882
# Unit test for function loader
def test_loader():
    """Test loader function."""
    loader(
        "numpy",
        _site_path("numpy"),
        False,
        1,
        False
    )


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-23 15:29:29.383260
# Unit test for function gen_api
def test_gen_api():
    print(gen_api(dict(pyslvs="pyslvs", svgwrite="svgwrite")))


# Generated at 2022-06-23 15:29:30.857624
# Unit test for function walk_packages
def test_walk_packages():
    import doctest
    assert doctest.testmod().failed == 0

# Generated at 2022-06-23 15:29:38.194799
# Unit test for function loader

# Generated at 2022-06-23 15:29:46.334207
# Unit test for function walk_packages
def test_walk_packages():
    import shutil
    from tempfile import mkdtemp
    import pkg_resources
    from .pyslvs import __file__ as exe_path

    root = mkdtemp()
    shutil.copytree(dirname(exe_path), join(root, 'pyslvs'))
    shutil.copytree(dirname(pkg_resources.__file__), join(root, 'pkg_resources'))
    names = ['pyslvs.api', 'pkg_resources.extern.appdirs', 'pkg_resources.extern.packaging']
    for name, path in walk_packages('pyslvs', root):
        assert names.pop(0) == name
        assert path.startswith(abspath(root))
    assert not names
