

# Generated at 2022-06-17 16:32:49.574851
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser

    class Test(TestCase):

        def setUp(self) -> None:
            self.temp = mkdtemp()

        def tearDown(self) -> None:
            rmtree(self.temp)

        def test_walk_packages(self):
            p = Parser.new(False, 1, False)
            for name, path in walk_packages('test', self.temp):
                p.parse(name, _read(path))

# Generated at 2022-06-17 16:32:55.232316
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .compiler import loader

    def _test(name: str, pwd: str, link: bool, level: int, toc: bool) -> None:
        """Test for function loader."""
        p = Parser.new(link, level, toc)
        loader(name, pwd, p)
        assert p.compile()

    _test('pyslvs', resource_filename('pyslvs', '..'), True, 1, False)
    _test('pyslvs', resource_filename('pyslvs', '..'), True, 2, True)

# Generated at 2022-06-17 16:33:05.194136
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename

    def _test(name: str, path: str, expect: str) -> None:
        assert name == expect, f"{name} != {expect}"
        assert path.endswith(expect + '.py'), f"{path} != {expect}.py"

    with TemporaryDirectory() as tmp:
        copyfile('tests/test_package/__init__.py', join(tmp, '__init__.py'))
        copyfile('tests/test_package/test_package.py', join(tmp, 'test_package.py'))
        copyfile('tests/test_package/test_package.pyi', join(tmp, 'test_package.pyi'))

# Generated at 2022-06-17 16:33:14.661233
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load

# Generated at 2022-06-17 16:33:25.469302
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkg_resources import resource_filename
    from .test_parser import test_parse
    from .test_parser import test_load_docstring

    # Copy test package to temporary directory
    with TemporaryDirectory() as tmp:
        copytree(resource_filename(__name__, 'test_package'), tmp)
        # Test for loader
        assert loader('test_package', tmp, False, 1, False) == test_parse()
        assert loader('test_package', tmp, False, 1, True) == test_parse(True)
        # Test for load_module
        p = Parser.new(False, 1, False)

# Generated at 2022-06-17 16:33:35.532600
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from os import chdir
    from os.path import dirname
    from pkgutil import get_loader
    from importlib.util import module_from_spec
    from importlib.machinery import SourceFileLoader
    from .parser import Parser
    from .logger import logger
    logger.setLevel(40)
    p = Parser.new(False, 1, False)
    # Test for import error
    assert not _load_module('pyslvs', 'pyslvs.py', p)
    # Test for import success
    assert _load_module('pyslvs', 'pyslvs.py', p)
    # Test for import success
    assert _load_module('pyslvs.core', 'pyslvs.py', p)
    # Test for

# Generated at 2022-06-17 16:33:44.346066
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    for name, path in test_data.items():
        print(f"{name} <= {path}")
        print(loader(name, path, False, 1, False))
        print('=' * 12)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-17 16:33:49.303475
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    assert loader("pyslvs", dirname(__file__), False, 1, False).startswith(
        f"# pyslvs {__version__} API\n\n"
    )

# Generated at 2022-06-17 16:33:56.501399
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages function."""
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    from pkgutil import walk_packages
    from .parser import parent
    with TemporaryDirectory() as temp:
        for pkg in walk_packages(temp):
            copy(__file__, join(temp, basename(__file__)))
            copy(__file__, join(temp, '__init__.py'))
            assert list(walk_packages(parent(__file__), temp)) == [pkg]

# Generated at 2022-06-17 16:34:08.261321
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os import remove
    from os.path import basename, splitext

    with TemporaryDirectory() as temp:
        # Create a package
        mkdir(join(temp, 'test'))
        with open(join(temp, 'test', '__init__.py'), 'w+') as f:
            f.write('#')
        # Create a module
        with open(join(temp, 'test', 'test.py'), 'w+') as f:
            f.write('#')
        # Create a submodule
        mkdir(join(temp, 'test', 'sub'))
        with open(join(temp, 'test', 'sub', '__init__.py'), 'w+') as f:
            f.write('#')

# Generated at 2022-06-17 16:36:18.990526
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", "../.."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-17 16:36:25.308490
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger

    def _write(path: str, doc: str) -> None:
        """Write text to the file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        """Read the script from file."""
        with open(path, 'r') as f:
            return f.read()

    def _load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        #

# Generated at 2022-06-17 16:36:35.481898
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import get_data
    from .parser import Parser
    from .compiler import walk_packages

    def _test(name: str, path: str, p: Parser) -> None:
        """Test function."""
        logger.info(f"Test: {name}")
        for n, p in walk_packages(name, path):
            logger.info(f"{n} <= {p}")
            p.parse(n, _read(p))
        logger.info(f"Compile: {name}")
        logger.info(p.compile())


# Generated at 2022-06-17 16:36:44.344581
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test_loader(root: str, pwd: str, link: bool, level: int, toc: bool) -> str:
        """Test function loader."""
        p = Parser.new(link, level, toc)
        for name, path in walk_packages(root, pwd):
            # Load its source or stub
            pure_py = False
            for ext in [".py", ".pyi"]:
                path_ext = path + ext
                if not exists(path_ext):
                    continue
                p.parse(name, _read(path_ext))
                if ext == ".py":
                    pure_

# Generated at 2022-06-17 16:36:52.019533
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import remove
    from os.path import basename

    def _test(name: str, path: str, expect: Sequence[str]) -> None:
        assert [basename(p) for _, p in walk_packages(name, path)] == expect

    with TemporaryDirectory() as temp:
        copytree('./tests/test_walk_packages', temp)
        _test('test_walk_packages', temp, ['__init__.py', '__init__.pyi'])
        _test('test_walk_packages.a', temp, ['__init__.py', '__init__.pyi'])
        _test('test_walk_packages.a.b', temp, ['__init__.py', '__init__.pyi'])
        _

# Generated at 2022-06-17 16:37:02.753249
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.docks import __version__ as docks_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.panels import __version__ as panels_version

# Generated at 2022-06-17 16:37:13.583601
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os import remove

    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))
        mkdir(join(tmp, 'test', '__pycache__'))
        mkdir(join(tmp, 'test', 'sub'))
        mkdir(join(tmp, 'test', 'sub', '__pycache__'))
        mkdir(join(tmp, 'test', 'sub', 'sub'))
        mkdir(join(tmp, 'test', 'sub', 'sub', '__pycache__'))
        copy(__file__, join(tmp, 'test', '__init__.py'))
        copy(__file__, join(tmp, 'test', 'sub', '__init__.py'))


# Generated at 2022-06-17 16:37:25.516482
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from importlib import import_module
    from os import remove
    from os.path import isfile
    from .logger import logger
    from .parser import Parser
    from .compiler import _load_module, _read, _write, _site_path, walk_packages
    from .compiler import loader

    def _test_loader(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_