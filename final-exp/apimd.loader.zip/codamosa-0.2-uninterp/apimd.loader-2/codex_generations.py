

# Generated at 2022-06-17 16:33:26.005679
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import iter_modules
    from importlib import import_module
    from os import getcwd
    from os.path import dirname
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for _, name, _ in iter_modules([getcwd()]):
        m = import_module(name)
        p.load_docstring(name, m)
    print(p.compile())
    print(loader('pyslvs', dirname(__file__), True, 1, False))

# Generated at 2022-06-17 16:33:36.728896
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.abc import Loader

    def _test_walk_packages(name: str, path: str) -> bool:
        """Test for walk_packages."""
        for n, p in walk_packages(name, path):
            if n != name:
                return False
            if p != path:
                return False
        return True

    with TemporaryDirectory() as tmp:
        # Test for package
        name = 'test_package'
        path = join(tmp, name)
        mkdir(path)

# Generated at 2022-06-17 16:33:50.693476
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from unittest import TestCase, main

    class TestWalkPackages(TestCase):

        def test_walk_packages(self):
            with TemporaryDirectory() as tmp:
                copyfile(__file__, join(tmp, basename(__file__)))
                self.assertEqual(list(walk_packages('', tmp)), [])
                self.assertEqual(list(walk_packages('test_compiler', tmp)), [])
                self.assertEqual(list(walk_packages('test_compiler', __file__)), [])

# Generated at 2022-06-17 16:33:58.770333
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname, abspath
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        chdir(temp)
        copytree(resource_filename('pyslvs_ui', 'tests/test_package'), 'test')
        p = Parser.new(False, 1, False)
        for name, path in walk_packages('test', '.'):
            p.parse(name, _read(path + '.py'))

# Generated at 2022-06-17 16:34:10.383066
# Unit test for function loader
def test_loader():
    """Test the loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.docks import __version__ as docks_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.tabs import __version__ as tabs_version

# Generated at 2022-06-17 16:34:21.290428
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module

# Generated at 2022-06-17 16:34:29.151487
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    from .utils import remove_prefix
    logger.setLevel('DEBUG')
    p = Parser.new(link=True, level=1, toc=False)
    for name, path in walk_packages('pyslvs', '.'):
        logger.debug(f"{name} <= {path}")
        p.parse(name, _read(path + '.py'))
    assert p.compile() == remove_prefix(_read('test_loader.md'), '#')


# Generated at 2022-06-17 16:34:37.030217
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import walk_packages
    from pyslvs_ui.compiler import walk_packages as walk_packages_
    from pyslvs_ui.compiler import _site_path
    from pyslvs_ui.compiler import _load_module
    from pyslvs_ui.compiler import Parser
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.compiler import gen_api
    from pyslvs_ui.compiler import _read
    from pyslvs_ui.compiler import _write
    from pyslvs_ui.compiler import _site_path
    from pyslvs_ui.compiler import walk_packages
    from pyslvs_ui.compiler import _load_module


# Generated at 2022-06-17 16:34:48.373479
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import pkgutil
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.parser import Parser
    from pyslvs_ui.logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for _, name, _ in pkgutil.iter_modules(['pyslvs_ui']):
        loader(name, 'pyslvs_ui', p)
    assert p.compile()

# Generated at 2022-06-17 16:34:55.394927
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load