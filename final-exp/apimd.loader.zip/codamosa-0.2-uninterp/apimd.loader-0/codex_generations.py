

# Generated at 2022-06-17 16:29:54.101160
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(False, 0, False)
    for name, path in walk_packages("pyslvs", ".."):
        p.parse(name, _read(path + ".py"))
    assert p.compile() == test_data

# Generated at 2022-06-17 16:30:00.794460
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import exists
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.abc import Loader

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _load_module(name: str, path: str) -> bool:
        s = find_spec(name)

# Generated at 2022-06-17 16:30:10.244416
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import isfile
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser
    from .logger import logger
    logger.setLevel('ERROR')
    p = Parser.new(False, 1, False)
    p.parse('test', '"""test"""')
    p.parse('test.sub', '"""test.sub"""')
    p.parse('test.sub.sub', '"""test.sub.sub"""')
    p.parse('test.sub.sub.sub', '"""test.sub.sub.sub"""')
    p.parse('test.sub.sub.sub.sub', '"""test.sub.sub.sub.sub"""')

# Generated at 2022-06-17 16:30:19.398417
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages function."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import exists
    from pkgutil import walk_packages as pkg_walk_packages
    from pkgutil import get_data as pkg_get_data
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import SourceFileLoader

    def _write_file(path: str, content: str) -> None:
        """Write file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(content)

    def _read_file(path: str) -> str:
        """Read file."""

# Generated at 2022-06-17 16:30:29.346309
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .parser import link, level, toc
    from .parser import load_docstring, parse
    from .parser import compile
    from .parser import new
    from .parser import parent
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser
    from .parser import Parser

# Generated at 2022-06-17 16:30:36.352961
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import remove
    from os.path import isdir, isfile, join
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.abc import Loader
    from importlib.util import spec_from_file_location, module_from_spec
    from .parser import Parser

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)


# Generated at 2022-06-17 16:30:49.443365
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from .logger import logger
    from .parser import Parser
    from .compiler import walk_packages

    def _write(path: str, doc: str) -> None:
        """Write text to the file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        """Read the script from file."""
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-17 16:30:54.998083
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    class TestWalkPackages(TestCase):

        def setUp(self) -> None:
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            self.temp_pkg = join(self.temp_path, 'test_pkg')
            mkdir(self.temp_pkg)
            copyfile('test_pkg/__init__.py', join(self.temp_pkg, '__init__.py'))
            copyfile('test_pkg/test_module.py', join(self.temp_pkg, 'test_module.py'))

# Generated at 2022-06-17 16:31:00.445250
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import chdir, getcwd
    from os.path import dirname, join
    from .logger import logger
    from .parser import Parser
    from .compiler import walk_packages, _read, _write, _load_module
    from .compiler import loader, gen_api
    logger.setLevel('DEBUG')
    # Test walk_packages
    chdir(dirname(__file__))
    for name, path in walk_packages('pyslvs', '..'):
        print(name, path)
    # Test _read
    print(_read('../pyslvs/__init__.py'))
    # Test _write
    _write('../pyslvs/__init__.py', '# Test')
    #

# Generated at 2022-06-17 16:31:10.496289
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        # Create a package
        copyfile(resource_filename(__name__, '__init__.py'),
                 join(temp, '__init__.py'))
        copyfile(resource_filename(__name__, '__main__.py'),
                 join(temp, '__main__.py'))
        copyfile(resource_filename(__name__, '__version__.py'),
                 join(temp, '__version__.py'))

# Generated at 2022-06-17 16:33:38.391935
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import isfile
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.abc import Loader
    from importlib.util import spec_from_file_location, module_from_spec
    from .parser import Parser

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)


# Generated at 2022-06-17 16:33:50.986229
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    path = mkdtemp()
    try:
        for name, path in walk_packages("pyslvs", path):
            print(name, path)
        for name, path in walk_packages("pyslvs", resource_filename("pyslvs", "")):
            print(name, path)
    finally:
        rmtree(path)
    path = mkdtemp()

# Generated at 2022-06-17 16:33:56.222627
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import iter_modules
    from os.path import dirname
    from sys import path as sys_path
    sys_path.append(dirname(__file__))
    for _, name, _ in iter_modules():
        if name.startswith('_'):
            continue
        print(loader(name, dirname(__file__), False, 1, False))


# Generated at 2022-06-17 16:34:04.781983
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pprint import pprint
    from unittest import TestCase

    class TestWalkPackages(TestCase):

        def test_walk_packages(self):
            with TemporaryDirectory() as path:
                copyfile(__file__, join(path, basename(__file__)))
                pprint(list(walk_packages('', path)))

    TestWalkPackages().test_walk_packages()

# Generated at 2022-06-17 16:34:15.258581
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    from .compiler import loader
    from .compiler import _read, _write
    from .compiler import _site_path, walk_packages
    from .compiler import _load_module
    from .compiler import gen_api
    from .compiler import PEP561_SUFFIX
    from .compiler import EXTENSION_SUFFIXES
    from .compiler import PEP561_SUFFIX
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.util import find_spec, spec_from_file_location, module_from_spec
    from sys import path as sys_path
    from os import mkdir, walk
    from os.path import isdir, isfile, abs

# Generated at 2022-06-17 16:34:25.974544
# Unit test for function loader
def test_loader():
    from os import chdir
    from os.path import dirname
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import get_data
    from .parser import Parser
    from .compiler import loader
    from .logger import logger

    logger.setLevel(10)
    with TemporaryDirectory() as tmp:
        chdir(tmp)
        copytree(dirname(__file__) + '/test/test_pkg', 'test_pkg')
        copytree(dirname(__file__) + '/test/test_pkg_stubs', 'test_pkg-stubs')
        assert loader('test_pkg', '.', True, 1, False) == get_data(
            'test.test_compiler', 'test_api.md'
        ).decode('utf-8')

# Generated at 2022-06-17 16:34:36.692421
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from unittest import TestCase, main
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory

    class TestLoader(TestCase):

        def test_loader(self):
            with TemporaryDirectory() as tmp:
                # Create a package
                mkdir(join(tmp, 'test'))
                _write(join(tmp, 'test', '__init__.py'), '"""Test package."""')
                _write(join(tmp, 'test', 'test.py'), '"""Test module."""')
                # Create a module
                _write(join(tmp, 'test.py'), '"""Test module."""')
                # Create a package with sub-package
                mkdir(join(tmp, 'test2'))

# Generated at 2022-06-17 16:34:50.704133
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        p.parse(name, _read(path + ".py"))

# Generated at 2022-06-17 16:34:59.629205
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.docks import __version__ as docks_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.tabs import __version__ as tabs_version

# Generated at 2022-06-17 16:35:09.414754
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import dirname
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase, main

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.temp_dir = mkdtemp()

        def tearDown(self):
            rmtree(self.temp_dir)

        def test_walk_packages(self):
            root = join(self.temp_dir, 'test')
            mkdir(root)
            mkdir(join(root, 'a'))
            mkdir(join(root, 'b'))
            mkdir(join(root, 'b', 'c'))
            mkdir(join(root, 'b', 'd'))