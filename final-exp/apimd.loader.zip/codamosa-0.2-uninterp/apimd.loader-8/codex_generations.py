

# Generated at 2022-06-17 16:32:38.060746
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES

    def _create_package(path: str, name: str, *,
                        ext: bool = False,
                        stub: bool = False) -> None:
        """Create a package."""
        if ext:
            for ext in EXTENSION_SUFFIXES:
                copy(find_spec(name).origin, path + ext)
        else:
            with open(path + '.py', 'w+') as f:
                f.write(f"def {name}(): pass")

# Generated at 2022-06-17 16:32:50.206174
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger

    logger.setLevel(10)
    with TemporaryDirectory() as tmp:
        copytree('tests/test_loader', tmp)
        p = Parser.new(False, 1, False)
        for name, path in walk_packages('test_loader', tmp):
            p.parse(name, _read(path + '.py'))
        assert p.compile() == _read('tests/test_loader.md')
        remove(join(tmp, 'test_loader', '__init__.py'))
        p = Parser.new(False, 1, False)

# Generated at 2022-06-17 16:33:00.357599
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os import remove
    from os.path import basename, splitext
    from pkgutil import walk_packages
    from pkg_resources import resource_filename
    from .logger import logger
    logger.setLevel(0)
    with TemporaryDirectory() as tmp:
        for p in walk_packages(__name__):
            copy(resource_filename(__name__, p.path), tmp)
        for name, path in walk_packages(__name__, tmp):
            assert name == __name__ + '.' + splitext(basename(path))[0]
            remove(path)

# Generated at 2022-06-17 16:33:11.412978
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .__main__ import __version__
    from .__main__ import __author__
    from .__main__ import __copyright__
    from .__main__ import __license__
    from .__main__ import __email__
    from .__main__ import __url__
    from .__main__ import __status__
    from .__main__ import __description__
    from .__main__ import __keywords__
    from .__main__ import __classifiers__
    from .__main__ import __requires__
    from .__main__ import __provides__
    from .__main__ import __requires_dist__
    from .__main__ import __provides_dist__
    from .__main__ import __obsoletes_dist__
    from .__main__ import __project_urls

# Generated at 2022-06-17 16:33:16.854549
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree

    class TestWalkPackages(TestCase):
        """Test for function walk_packages."""

        def setUp(self) -> None:
            """Create a temporary directory."""
            self.temp_dir = mkdtemp()

        def tearDown(self) -> None:
            """Remove the temporary directory."""
            rmtree(self.temp_dir)

        def test_walk_packages(self) -> None:
            """Test for function walk_packages."""
            # Create a package
            package_dir = join(self.temp_dir, 'package')
            mkdir(package_dir)

# Generated at 2022-06-17 16:33:23.835895
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        p.parse(name, _read(path + ".py"))
    print(p.compile())


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-17 16:33:30.113119
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import isfile
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    logger.debug("Unit test for function loader")
    pwd = mkdtemp()
    logger.debug(f"Create temporary directory: {pwd}")
    root = "test"
    logger.debug(f"Create root: {root}")
    mkdir(join(pwd, root))
    logger.debug(f"Create package: {root}.a")
    mkdir(join(pwd, root, "a"))
    logger.debug(f"Create module: {root}.a.b")

# Generated at 2022-06-17 16:33:38.598310
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import spec_from_file_location, module_from_spec
    from importlib.machinery import SourceFileLoader
    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, "test"))
        copyfile("test/test_compiler.py", join(tmp, "test", "__init__.py"))
        # Create a module
        copyfile("test/test_compiler.py", join(tmp, "test_compiler.py"))
        # Create a stub
        copyfile("test/test_compiler.pyi", join(tmp, "test_compiler.pyi"))
        # Create

# Generated at 2022-06-17 16:33:51.014695
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import remove
    from os.path import isfile
    from .logger import logger
    from .parser import Parser
    from .compiler import loader

    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(__name__):
        p.parse(name, _read(name + '.py'))
    p.parse(__name__, _read(__file__))
    doc = p.compile()
    path = 'test.md'
    _write(path, doc)
    assert isfile(path)
    remove(path)
    assert not isfile(path)

# Generated at 2022-06-17 16:33:58.819604
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main

    class Test(TestCase):

        def test_walk_packages(self):
            from os import remove
            from os.path import exists
            from shutil import rmtree
            from tempfile import mkdtemp
            from .parser import Parser

            def _write(path: str, doc: str) -> None:
                with open(path, 'w+', encoding='utf-8') as f:
                    f.write(doc)

            def _read(path: str) -> str:
                with open(path, 'r') as f:
                    return f.read()

            def _test(name: str, path: str, p: Parser) -> None:
                self.assertTrue(exists(path))
                self.assertTrue(exists(path + '.py'))
               