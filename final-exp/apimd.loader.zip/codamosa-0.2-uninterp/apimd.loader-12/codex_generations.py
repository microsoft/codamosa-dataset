

# Generated at 2022-06-17 16:30:18.915266
# Unit test for function loader
def test_loader():
    from os.path import dirname, join
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', dirname(__file__)):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue

# Generated at 2022-06-17 16:30:28.388384
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import Parser
    from .logger import logger
    from .compiler import loader

    logger.setLevel(10)

    def _write(path: str, doc: str) -> None:
        """Write text to the file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        """Read the script from file."""
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-17 16:30:32.795574
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", "."):
        p.parse(name, _read(path + ".py"))
    print(p.compile())

# Generated at 2022-06-17 16:30:43.921831
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_parser import test_parser
    from .test_parser import test_parser_link
    from .test_parser import test_parser_toc
    from .test_parser import test_parser_link_toc
    from .test_parser import test_parser_level
    from .test_parser import test_parser_link_level
    from .test_parser import test_parser_toc_level
    from .test_parser import test_parser_link_toc_level
    from .test_parser import test_parser_level_2
    from .test_parser import test_parser_link_level_2
    from .test_parser import test_parser_toc_level_2
    from .test_parser import test_parser_link_toc_level_2
    from .test_parser import test_parser

# Generated at 2022-06-17 16:30:52.882047
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import makedirs
    from os.path import join
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES

    def _test_walk_packages(name: str, path: str) -> Iterator[tuple[str, str]]:
        """Walk packages without import them."""
        path = abspath(path) + sep
        valid = (path + name, path + name + PEP561_SUFFIX)
        for root, _, fs in walk(path):
            for f in fs:
                if not f.endswith(('.py', '.pyi')):
                    continue
                f_path = parent

# Generated at 2022-06-17 16:30:59.569890
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import remove
    from os.path import isfile
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, "")
    assert p.compile() == ""
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, "")
    assert p.compile() == ""
    p = Parser.new(False, 1, False)

# Generated at 2022-06-17 16:31:10.249215
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import walk_packages
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        copytree('tests/test_pkg', tmp)
        assert exists(tmp + '/test_pkg/__init__.py')
        assert exists(tmp + '/test_pkg/__init__.pyi')
        assert exists(tmp + '/test_pkg/test_pkg.py')
        assert exists(tmp + '/test_pkg/test_pkg.pyi')
        assert exists(tmp + '/test_pkg/test_pkg.so')
        assert exists(tmp + '/test_pkg/test_pkg.pyd')

# Generated at 2022-06-17 16:31:17.073541
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs_ui.package_info import __version__
    from pyslvs_ui.package_info import __title__
    from pyslvs_ui.package_info import __author__
    from pyslvs_ui.package_info import __email__
    from pyslvs_ui.package_info import __license__
    from pyslvs_ui.package_info import __copyright__
    from pyslvs_ui.package_info import __url__
    from pyslvs_ui.package_info import __description__
    from pyslvs_ui.package_info import __long_description__
    from pyslvs_ui.package_info import __keywords__
    from pyslvs_ui.package_info import __classifiers__

# Generated at 2022-06-17 16:31:27.706389
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import get_data
    from .__init__ import __path__ as pyslvs_path

    with TemporaryDirectory() as temp_dir:
        copytree(pyslvs_path[0], temp_dir)
        for name, path in walk_packages('pyslvs', temp_dir):
            assert exists(path)
            assert get_data('pyslvs', name.replace('.', '/') + '.py')
        for name, path in walk_packages('pyslvs', temp_dir):
            remove(path)
            remove(path + '.pyi')

# Generated at 2022-06-17 16:31:36.205811
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        copytree('tests/test_data', tmp)
        assert isfile(join(tmp, 'test_data', '__init__.py'))
        assert isfile(join(tmp, 'test_data', 'test_data.py'))
        assert isfile(join(tmp, 'test_data', 'test_data.pyi'))
        assert isfile(join(tmp, 'test_data', 'test_data.so'))