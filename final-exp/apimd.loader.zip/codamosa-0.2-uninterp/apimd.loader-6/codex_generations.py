

# Generated at 2022-06-17 16:29:08.287893
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import remove
    from os.path import join
    from pkgutil import get_data
    from .parser import Parser
    from .logger import logger
    from .compiler import loader

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        copytree(get_data('pyslvs_ui', 'tests/test_compiler'), tmp)
        p = Parser.new(False, 1, False)
        loader('test_compiler', tmp, p)

# Generated at 2022-06-17 16:29:18.087830
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .parser import parent
    from .parser import removeprefix, removesuffix
    from .parser import replace
    from .parser import join
    from .parser import sep
    from .parser import walk
    from .parser import isfile
    from .parser import abspath
    from .parser import dirname
    from .parser import find_spec
    from .parser import spec_from_file_location
    from .parser import module_from_spec
    from .parser import Loader
    from .parser import EXTENSION_SUFFIXES
    from .parser import __import__
    from .parser import open
    from .parser import read
    from .parser import write
    from .parser import debug
    from .parser import warning
    from .parser import info
    from .parser import new
    from .parser import parse


# Generated at 2022-06-17 16:29:27.708303
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test(name: str, path: str) -> None:
        """Test the package."""
        p = Parser.new(False, 1, False)
        for n, p in walk_packages(name, path):
            p = p + ".py"
            if not exists(p):
                continue
            p = _read(p)
            p = p.replace("\r", "").replace("\n", "")
            p = p.replace(" ", "").replace("\t", "")
            p = p.replace("#", "")
            p = p

# Generated at 2022-06-17 16:29:30.984891
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", test_data):
        p.parse(name, _read(path + ".py"))
    assert p.compile() == _read(test_data + "/api.md")

# Generated at 2022-06-17 16:29:37.860227
# Unit test for function loader
def test_loader():
    from os import chdir
    from os.path import dirname
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        chdir(tmp)
        copytree(dirname(__file__) + '/test_loader', '.')
        p = Parser.new(False, 1, False)
        for name, path in walk_packages('test_loader', '.'):
            p.parse(name, _read(path + '.py'))
        assert p.compile() == _read('test_loader.md')

# Generated at 2022-06-17 16:29:50.530695
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    with TemporaryDirectory() as tmp:
        copyfile(__file__, join(tmp, '__init__.py'))
        copyfile(__file__, join(tmp, '__init__.pyi'))
        copyfile(__file__, join(tmp, '__init__.pyc'))
        copyfile(__file__, join(tmp, '__init__.pyo'))
        copyfile(__file__, join(tmp, '__init__.so'))
        copyfile(__file__, join(tmp, '__init__.pyd'))
        copyfile(__file__, join(tmp, '__init__.dll'))

# Generated at 2022-06-17 16:29:58.768266
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from os import chdir
    from os.path import dirname, join
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    with TemporaryDirectory() as tmp:
        chdir(tmp)
        copyfile(resource_filename('pyslvs_ui', '__init__.py'), 'pyslvs_ui.py')
        copyfile(resource_filename('pyslvs_ui', '__init__.pyi'), 'pyslvs_ui.pyi')

# Generated at 2022-06-17 16:30:04.410911
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkg_resources import resource_filename
    from .parser import parent

# Generated at 2022-06-17 16:30:14.181888
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from pkg_resources import resource_filename
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        for name, path in walk_packages(__name__, resource_filename(__name__, '.')):
            logger.debug(f"{name} <= {path}")
            copyfile(path, join(tmp, basename(path)))
        for name, path in walk_packages(__name__, tmp):
            logger.debug(f"{name} <= {path}")
            remove(path)


# Generated at 2022-06-17 16:30:21.309764
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-17 16:32:19.202539
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.parser import Parser
    from pyslvs_ui.logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    loader('pyslvs', '.', p)
    assert p.compile()
    p = Parser.new(True, 1, False)
    loader('pyslvs_ui', '.', p)
    assert p.compile()
    p = Parser.new(True, 1, False)
    loader('pyslvs_ui.compiler', '.', p)
    assert p.compile()
    p = Parser.new(True, 1, False)

# Generated at 2022-06-17 16:32:25.310219
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_loader
    from importlib.machinery import SourceFileLoader
    from unittest import TestCase, main

    class Test(TestCase):

        def setUp(self):
            self.path = mkdtemp()
            self.name = 'test'
            self.module = module_from_spec(spec_from_loader(
                self.name, SourceFileLoader(self.name, join(self.path, self.name + '.py'))
            ))

        def tearDown(self):
            rmtree(self.path)


# Generated at 2022-06-17 16:32:32.520113
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from unittest import TestCase, main
    from pkgutil import iter_modules
    from os import remove
    from os.path import exists

    class TestLoader(TestCase):

        """Test case for function loader."""

        def test_loader(self):
            """Test function loader."""
            # Test for import error
            self.assertFalse(_load_module("pyslvs", "pyslvs.py", Parser.new()))
            # Test for module load
            self.assertTrue(_load_module("pyslvs", "pyslvs.py", Parser.new()))
            # Test for walk packages

# Generated at 2022-06-17 16:32:39.530939
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.info import __title__ as info_title
    from pyslvs_ui.info import __author__ as info_author
    from pyslvs_ui.info import __email__ as info_email
    from pyslvs_ui.info import __url__ as info_url
    from pyslvs_ui.info import __license__ as info_license
    from pyslvs_ui.info import __copyright__ as info_copyright
    from pyslvs_ui.info import __description__ as info_description

# Generated at 2022-06-17 16:32:50.639633
# Unit test for function loader
def test_loader():
    """Test case for function loader."""
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import join as pjoin

    class TestLoader(TestCase):
        """Test case for function loader."""

        def setUp(self) -> None:
            """Create a temporary directory."""
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            self.temp_root = pjoin(self.temp_path, 'root')
            self.temp_sub = pjoin(self.temp_path, 'root', 'sub')
            mkdir(self.temp_root)
            mkdir(self.temp_sub)

        def tearDown(self) -> None:
            """Remove the temporary directory."""
           

# Generated at 2022-06-17 16:33:02.257236
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    class Test(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_dir_path = self.temp_dir.name
            self.path = join(self.temp_dir_path, 'test')
            mkdir(self.path)
            copyfile('__init__.py', join(self.path, '__init__.py'))
            copyfile('__init__.py', join(self.path, '__init__.pyi'))
            copyfile('__init__.py', join(self.path, '__init__.py-stubs'))

# Generated at 2022-06-17 16:33:13.125765
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import iter_modules
    from importlib import import_module
    from os import remove
    from os.path import isfile
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from .logger import logger
    from .parser import Parser
    from .compiler import loader

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        # Create a package
        pkg = join(temp, 'pkg')
        mkdir(pkg)
        # Create a module
        with open(join(pkg, '__init__.py'), 'w+') as f:
            f.write("""
            def test():
                '''Test function.'''
                pass
            """)
        # Create a sub-package

# Generated at 2022-06-17 16:33:23.373109
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.parser import Parser
    from pyslvs_ui.logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(path=['pyslvs_ui']):
        if name.startswith('pyslvs_ui.parser'):
            continue
        p.parse(name, loader(name, 'pyslvs_ui', False, 1, False))
    print(p.compile())

# Generated at 2022-06-17 16:33:29.792736
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import get_data
    from .logger import logger
    from .parser import Parser
    from .compiler import loader

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        chdir(tmp)
        copytree(dirname(__file__) + '/test/test_pkg', 'test_pkg')
        copytree(dirname(__file__) + '/test/test_pkg2', 'test_pkg2')

# Generated at 2022-06-17 16:33:36.217625
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', test_data):
        p.parse(name, _read(path))
    assert p.compile() == _read(join(test_data, 'pyslvs-api.md'))

# Generated at 2022-06-17 16:35:46.901094
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", "."):
        p.parse(name, _read(path + ".py"))
    print(p.compile())

# Generated at 2022-06-17 16:35:57.999249
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    from .__main__ import __version__
    from .__main__ import __version_info__
    from .__main__ import __author__
    from .__main__ import __copyright__
    from .__main__ import __license__
    from .__main__ import __email__
    from .__main__ import __url__
    from .__main__ import __description__
    from .__main__ import __long_description__
    from .__main__ import __long_description_content_type__
    from .__main__ import __keywords__
    from .__main__ import __classifiers__
    from .__main__ import __platforms__
    from .__main__ import __requires__

# Generated at 2022-06-17 16:36:05.174869
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from importlib import import_module
    from os import getcwd
    from os.path import dirname
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for _, name, _ in walk_packages(path=[getcwd()]):
        m = import_module(name)
        p.load_docstring(name, m)
    assert p.compile() == loader('pyslvs', dirname(__file__), True, 1, False)

# Generated at 2022-06-17 16:36:12.548632
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        copyfile(resource_filename(__name__, '__init__.py'), join(temp, '__init__.py'))
        copyfile(resource_filename(__name__, 'parser.py'), join(temp, 'parser.py'))
        copyfile(resource_filename(__name__, 'logger.py'), join(temp, 'logger.py'))

# Generated at 2022-06-17 16:36:20.848465
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser

# Generated at 2022-06-17 16:36:26.842080
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from os import remove
    from pkgutil import walk_packages

    with TemporaryDirectory() as d:
        # Create a package
        mkdir(join(d, 'test'))
        copyfile('test/test.py', join(d, 'test/test.py'))
        copyfile('test/test.pyi', join(d, 'test/test.pyi'))
        # Create a subpackage
        mkdir(join(d, 'test', 'sub'))
        copyfile('test/sub/sub.py', join(d, 'test/sub/sub.py'))
        copyfile('test/sub/sub.pyi', join(d, 'test/sub/sub.pyi'))
        # Create

# Generated at 2022-06-17 16:36:37.311667
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import join
    from unittest import TestCase, main

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            makedirs(join(self.temp_path, 'test_pkg'))
            makedirs(join(self.temp_path, 'test_pkg', 'sub_pkg'))
            makedirs(join(self.temp_path, 'test_pkg', 'sub_pkg', 'sub_sub_pkg'))

# Generated at 2022-06-17 16:36:50.375770
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))
        _write(join(tmp, 'test', '__init__.py'), '')
        _write(join(tmp, 'test', 'test.py'), '"""Test."""')
        _write(join(tmp, 'test', 'test.pyi'), '"""Test."""')
        # Create a package with submodule
        mkdir(join(tmp, 'test', 'sub'))

# Generated at 2022-06-17 16:37:01.875418
# Unit test for function loader
def test_loader():
    from os import chdir
    from os.path import dirname, join
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser
    from .logger import logger
    from .compiler import loader
    from .test_parser import test_parser
    logger.setLevel(10)
    root = 'test'
    pwd = mkdtemp()
    chdir(pwd)
    mkdir(root)
    with open(join(root, '__init__.py'), 'w+') as f:
        f.write("""
        def test():
            pass
        """)
    with open(join(root, 'test.py'), 'w+') as f:
        f.write("""
        def test():
            pass
        """)

# Generated at 2022-06-17 16:37:06.139786
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    from .parser import Parser
    from .logger import logger
    logger.setLevel(40)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages(test_data, dirname(__file__)):
        p.parse(name, _read(path))
    assert p.compile() == _read(join(dirname(__file__), 'test_data.md'))