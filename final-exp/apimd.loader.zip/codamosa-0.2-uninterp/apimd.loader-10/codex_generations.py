

# Generated at 2022-06-17 16:30:50.085818
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename, splitext
    from pkg_resources import resource_filename
    from .parser import parent

    def _test(name: str, path: str, pwd: str) -> None:
        """Test for walk_packages."""
        for n, p in walk_packages(name, pwd):
            assert p == path
            assert n == parent(name)

    with TemporaryDirectory() as temp:
        # Test for package
        name = 'test'
        path = join(temp, name)
        mkdir(path)
        _test(name, path, temp)
        # Test for module
        name = 'test.py'

# Generated at 2022-06-17 16:30:54.571226
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        p.parse(name, _read(path + '.py'))
    assert p.compile()

# Generated at 2022-06-17 16:31:00.424656
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pkgutil import iter_modules
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser
    from .logger import logger

    def _test_loader(root: str, pwd: str, link: bool, level: int, toc: bool) -> str:
        """Test function loader."""
        p = Parser.new(link, level, toc)
        for _, name, _ in iter_modules([pwd]):
            p.parse(name, "")
        return p.compile()


# Generated at 2022-06-17 16:31:10.495763
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname, join
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    chdir(dirname(__file__))
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
       

# Generated at 2022-06-17 16:31:13.760013
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    assert loader('pyslvs', dirname(__file__), False, 1, False).startswith(
        f"# pyslvs {__version__} API\n\n"
    )

# Generated at 2022-06-17 16:31:20.079304
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import iter_modules
    from os import remove
    from os.path import isfile
    from .logger import logger
    from .parser import Parser
    from .compiler import loader

    logger.setLevel(10)
    logger.info("Test for function loader")
    # Create a test module

# Generated at 2022-06-17 16:31:28.787921
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from sys import path as sys_path
    from os.path import dirname, abspath
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    sys_path.append(dirname(abspath(__file__)))
    p = Parser.new(True, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, _read(f"{name}.py"))
    doc = p.compile()
    assert doc.strip()
    logger.info(doc)

# Generated at 2022-06-17 16:31:37.295014
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", "../pyslvs"):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")


# Generated at 2022-06-17 16:31:43.002565
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", test_data):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        # Try to load module here
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext
            if not isfile(path_ext):
                continue


# Generated at 2022-06-17 16:31:52.485612
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    from .parser import _load_docstring
    from .parser import _load_docstring_from_module
    from .parser import _load_docstring_from_extension_module
    from .parser import _load_docstring_from_stub
    from .parser import _load_docstring_from_stub_extension_module
    from .parser import _load_docstring_from_stub_module
    from .parser import _load_docstring_from_stub_extension_module
    from .parser import _load_docstring_from_stub_module
    from .parser import _load_docstring_from_stub_extension_module
    from .parser import _load_docstring_from_stub_

# Generated at 2022-06-17 16:35:58.649226
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module

# Generated at 2022-06-17 16:36:07.487287
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import join, isfile

    class Test(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.path = self.temp_dir.name
            self.root = 'test'
            makedirs(join(self.path, self.root))
            self.pwd = join(self.path, self.root)
            self.prefix = 'docs'
            self.link = True
            self.level = 1
            self.toc = False
            self.dry = False

        def tearDown(self):
            self.temp_dir.cleanup()

        def test_empty(self):
            self.assertE

# Generated at 2022-06-17 16:36:14.916821
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import path
    from sys import path as sys_path
    sys_path.append(path.dirname(path.abspath(__file__)))
    import pyslvs

# Generated at 2022-06-17 16:36:22.576120
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename

    def _test_walk_packages(name: str, path: str, expected: Sequence[str]):
        assert list(walk_packages(name, path)) == expected

    with TemporaryDirectory() as temp_dir:
        # Create a package
        mkdir(join(temp_dir, 'test'))
        copyfile('test/test.py', join(temp_dir, 'test/__init__.py'))
        copyfile('test/test.pyi', join(temp_dir, 'test/test.pyi'))
        copyfile('test/test.py', join(temp_dir, 'test/test.py'))
        # Create a subpackage

# Generated at 2022-06-17 16:36:33.385094
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load

# Generated at 2022-06-17 16:36:42.743896
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from unittest import TestCase, main
    from os import remove
    from os.path import isfile
    from .logger import logger
    from .parser import Parser

    class TestLoader(TestCase):

        def setUp(self):
            self.root = 'test_loader'
            self.pwd = '.'
            self.link = True
            self.level = 1
            self.toc = False
            self.path = join(self.pwd, self.root)
            self.parser = Parser.new(self.link, self.level, self.toc)

        def tearDown(self):
            if isfile(self.path + '.py'):
                remove(self.path + '.py')

# Generated at 2022-06-17 16:36:48.599785
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    from .compiler import loader
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    loader('pyslvs', '.', p)
    assert p.compile()

# Generated at 2022-06-17 16:36:53.113415
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .test_parser import test_parser
    from .test_parser import test_parser_link
    from .test_parser import test_parser_toc
    from .test_parser import test_parser_link_toc
    from .test_parser import test_parser_level
    from .test_parser import test_parser_link_level
    from .test_parser import test_parser_toc_level
    from .test_parser import test_parser_link_toc_level
    from .test_parser import test_parser_level_2
    from .test_parser import test_parser_link_level_2
    from .test_parser import test_parser_toc_level_2
    from .test_parser import test_parser_link_toc_level_2
    from .test_parser import test_parser_

# Generated at 2022-06-17 16:37:03.593572
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(30)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-17 16:37:14.404422
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkgutil import walk_packages as pkg_walk

    def _mkdir(path: str) -> None:
        if not exists(path):
            mkdir(path)

    def _mkfile(path: str, doc: str) -> None:
        with open(path, 'w+') as f:
            f.write(doc)

    def _mkpkg(path: str, name: str, doc: str) -> None:
        _mkdir(path)
        _mkfile(path + '/__init__.py', doc)
