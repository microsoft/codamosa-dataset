

# Generated at 2022-06-17 16:28:57.665217
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import Parser
    from .compiler import walk_packages
    from .logger import logger

    logger.info("Testing walk_packages ...")
    tmp_dir = mkdtemp()

# Generated at 2022-06-17 16:29:02.170752
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import chdir, getcwd
    from os.path import dirname
    from sys import path as sys_path
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    pwd = getcwd()
    chdir(dirname(__file__))
    sys_path.append(pwd)
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, _read(name + '.py'))

# Generated at 2022-06-17 16:29:09.076511
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import chdir
    from os.path import dirname, join
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import EXTENSION_SUFFIXES

    def _load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)


# Generated at 2022-06-17 16:29:18.656575
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pkgutil import iter_modules
    from os.path import dirname
    from sys import path
    from os import getcwd
    from importlib import import_module
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for _, name, _ in iter_modules(path):
        try:
            m = import_module(name)
        except ImportError:
            continue
        p.load_docstring(name, m)
    logger.debug(p.compile())
    assert p.compile()
    assert gen_api({'Pyslvs': 'pyslvs'}, getcwd(), prefix='docs', dry=True)
    assert gen_api

# Generated at 2022-06-17 16:29:28.123178
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test_loader(name: str, path: str, p: Parser) -> bool:
        """Test for function loader."""
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
            return True
        return False


# Generated at 2022-06-17 16:29:30.452696
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    for name, path in walk_packages('test_data', '.'):
        print(name, path)
    assert loader('test_data', '.', True, 1, False) == test_data

# Generated at 2022-06-17 16:29:38.665557
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import Parser
    from .compiler import walk_packages

    def _create_file(path: str, name: str, doc: str) -> None:
        with open(join(path, name), 'w+') as f:
            f.write(doc)

    def _create_package(path: str, name: str, doc: str) -> None:
        _create_file(path, '__init__.py', doc)
        _create_file(path, '__init__.pyi', doc)

    def _create_module(path: str, name: str, doc: str) -> None:
        _create_file(path, name + '.py', doc)
       

# Generated at 2022-06-17 16:29:50.714760
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import iter_modules
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp_dir:
        # Create a test package
        copytree('tests/test_package', temp_dir)
        # Load the package
        p = Parser.new(False, 1, False)
        for _, name, _ in iter_modules([temp_dir]):
            p.parse(name, _read(join(temp_dir, name + '.py')))
        # Test the result

# Generated at 2022-06-17 16:29:58.896727
# Unit test for function loader
def test_loader():
    from os import chdir
    from os.path import dirname, join
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        chdir(temp)
        copytree(join(dirname(__file__), '..', 'test', 'test_loader'), '.')
        p = Parser.new(False, 1, False)
        loader('test_loader', '.', p)

# Generated at 2022-06-17 16:30:06.236551
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkgutil import write_file
    from .parser import Parser

    def _test_walk_packages(name: str, path: str, p: Parser) -> None:
        for n, p in walk_packages(name, path):
            assert n == p.replace(sep, '.').removeprefix(path + '.')
            p = p.replace(sep, '.')
            assert p in p.root_names
            assert p.root_names[p] == p.docstrings[p]
