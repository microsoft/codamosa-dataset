

# Generated at 2022-06-17 16:30:35.665195
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import parent
    from .compiler import walk_packages
    with TemporaryDirectory() as temp:
        copytree('tests/test_compiler', temp)
        assert exists(join(temp, 'test_compiler', '__init__.py'))
        assert exists(join(temp, 'test_compiler', 'test_compiler.py'))
        assert exists(join(temp, 'test_compiler', 'test_compiler.pyi'))
        assert exists(join(temp, 'test_compiler', 'test_compiler.so'))
        assert exists(join(temp, 'test_compiler', 'test_compiler.pyd'))

# Generated at 2022-06-17 16:30:49.249653
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import find_spec

    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))
        copyfile('__init__.py', join(tmp, 'test', '__init__.py'))
        copyfile('__init__.py', join(tmp, '__init__.py'))
        # Create a module
        copyfile('__init__.py', join(tmp, 'test.py'))
        # Create a module with stub
        copyfile('__init__.py', join(tmp, 'test.pyi'))
        # Create a module with extension

# Generated at 2022-06-17 16:30:58.405863
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import join as pjoin
    from pkgutil import get_data
    from importlib.machinery import SourceFileLoader
    from importlib.util import module_from_spec, spec_from_loader
    from .parser import Parser

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _load_module(name: str, path: str, p: Parser) -> bool:
        s = spec_from_loader(name, SourceFileLoader(name, path))
        if s is not None:
            m = module_from_spec(s)
            s.loader

# Generated at 2022-06-17 16:31:09.328614
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .test_data import TEST_ROOT_NAMES
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import makedirs
    from os.path import join as pjoin
    from pkg_resources import resource_filename

    def _create_test_dir(name: str) -> str:
        """Create a test directory."""
        path = resource_filename(__name__, name)
        with TemporaryDirectory() as tmp:
            copytree(path, tmp)
            return tmp

    def _create_test_file(name: str, content: str) -> str:
        """Create a test file."""
        with TemporaryDirectory() as tmp:
            path = pjoin(tmp, name)
            makedirs(dirname(path), exist_ok=True)
           

# Generated at 2022-06-17 16:31:12.736468
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", "pyslvs"):
        p.parse(name, _read(path + ".py"))
    assert p.compile()

# Generated at 2022-06-17 16:31:18.437846
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import pkgutil
    import pyslvs
    import pyslvs_ui
    import pyslvs_ui.info
    import pyslvs_ui.widgets
    import pyslvs_ui.widgets.canvas
    import pyslvs_ui.widgets.canvas.geometry
    import pyslvs_ui.widgets.canvas.geometry.solver
    import pyslvs_ui.widgets.canvas.geometry.solver.constraint
    import pyslvs_ui.widgets.canvas.geometry.solver.constraint.constraint_solver
    import pyslvs_ui.widgets.canvas.geometry.solver.constraint.constraint_solver_pyslv

# Generated at 2022-06-17 16:31:23.434463
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from . import __path__
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', __path__[0]):
        p.parse(name, _read(path + '.py'))
    assert p.compile()

# Generated at 2022-06-17 16:31:33.147832
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.abc import Loader

    with TemporaryDirectory() as temp:
        # Create a package
        mkdir(join(temp, 'test'))
        copyfile(__file__, join(temp, 'test', '__init__.py'))
        copyfile(__file__, join(temp, 'test', 'test.py'))
        # Create a extension module
        for ext in EXTENSION_SUFFIXES:
            copyfile(__file__, join(temp, 'test', 'test' + ext))
        #

# Generated at 2022-06-17 16:31:40.221723
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname, join
    from pkgutil import get_loader
    from importlib import import_module
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    pwd = dirname(__file__)
    chdir(pwd)
    root = 'pyslvs'
    p = Parser.new(True, 1, False)
    for name, path in walk_packages(root, pwd):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue

# Generated at 2022-06-17 16:31:50.997445
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from importlib import import_module
    from os import getcwd
    from os.path import dirname
    from sys import path as sys_path
    from .parser import Parser

    def _load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)


# Generated at 2022-06-17 16:33:13.921136
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os.path import dirname
    from sys import path as sys_path
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    sys_path.append(dirname(__file__))
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(__name__):
        p.parse(name, _read(name + '.py'))

# Generated at 2022-06-17 16:33:24.886931
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkgutil import walk_packages
    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))
        copyfile(__file__, join(tmp, 'test', '__init__.py'))
        # Create a subpackage
        mkdir(join(tmp, 'test', 'sub'))
        copyfile(__file__, join(tmp, 'test', 'sub', '__init__.py'))
        # Create a module
        copyfile(__file__, join(tmp, 'test', 'module.py'))
        # Create a submodule
        copyfile(__file__, join(tmp, 'test', 'sub', 'module.py'))
        #

# Generated at 2022-06-17 16:33:34.110759
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import isfile
    from .parser import Parser
    from .logger import logger
    logger.setLevel(40)
    p = Parser.new(False, 1, False)
    assert not _load_module("pyslvs", "pyslvs.py", p)
    assert not _load_module("pyslvs", "pyslvs.pyi", p)
    assert not _load_module("pyslvs", "pyslvs.so", p)
    assert not _load_module("pyslvs", "pyslvs.pyd", p)
    assert not _load_module("pyslvs", "pyslvs.dll", p)

# Generated at 2022-06-17 16:33:43.102023
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from pkgutil import walk_packages
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.parser import Parser
    from pyslvs_ui.logger import logger
    from pyslvs_ui.__main__ import __version__
    from pyslvs_ui.__main__ import __author__
    from pyslvs_ui.__main__ import __copyright__
    from pyslvs_ui.__main__ import __license__
    from pyslvs_ui.__main__ import __email__
    from pyslvs_ui.__main__ import __url__
    from pyslvs_ui.__main__ import __description__
    from pyslvs_ui.__main__ import __long_description__


# Generated at 2022-06-17 16:33:51.589131
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import get_data
    from .logger import logger
    logger.setLevel(20)
    with TemporaryDirectory() as temp:
        chdir(temp)
        copytree(dirname(__file__) + '/../tests/test_package', 'test_package')
        assert loader('test_package', '.', False, 1, False) == get_data(
            'pyslvs_ui.tests', 'test_package-api.md'
        ).decode('utf-8')

# Generated at 2022-06-17 16:33:59.066985
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from os import chdir
    from os.path import dirname, join
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from .parser import Parser
    from .logger import logger
    from .compiler import loader
    logger.setLevel(10)
    with TemporaryDirectory() as temp:
        chdir(temp)
        mkdir('pkg')
        mkdir('pkg/__pycache__')
        mkdir('pkg/sub')
        mkdir('pkg/sub/__pycache__')
        mkdir('pkg/sub/sub')
        mkdir('pkg/sub/sub/__pycache__')
        mkdir('pkg/sub/sub/sub')
        mkdir('pkg/sub/sub/sub/__pycache__')

# Generated at 2022-06-17 16:34:10.712988
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from importlib import import_module
    from os import chdir
    from os.path import dirname, join
    from sys import path as sys_path
    from .logger import logger
    from .parser import Parser
    from .compiler import walk_packages, _read, _write, loader

    logger.setLevel('DEBUG')
    pwd = dirname(__file__)
    sys_path.append(pwd)
    chdir(pwd)
    p = Parser.new(True, 1, False)

# Generated at 2022-06-17 16:34:21.329014
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load

# Generated at 2022-06-17 16:34:29.186990
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages function."""
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    from pkg_resources import resource_filename
    from .parser import parent
    with TemporaryDirectory() as temp:
        for name in ['pyslvs', 'pyslvs_ui']:
            for ext in ['.py', '.pyi']:
                copy(resource_filename(name, f"{name}{ext}"), temp)
        for name, path in walk_packages('pyslvs', temp):
            assert name == parent(basename(path))

# Generated at 2022-06-17 16:34:36.489219
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import join as join_path
    from pkgutil import get_data
    from .parser import Parser
    from .logger import logger
    from .compiler import loader

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        copytree(join_path(dirname(__file__), 'test'), temp)
        p = Parser.new(False, 1, False)
        loader('test', temp, p)
        assert p.compile() == get_data('pyslvs_ui.test', 'test.md').decode('utf-8')

# Generated at 2022-06-17 16:37:14.602758
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os.path import dirname, join
    from sys import path as sys_path
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    sys_path.append(dirname(__file__))
    p = Parser.new(True, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, _read(join(dirname(__file__), name + '.py')))
    print(p.compile())

# Generated at 2022-06-17 16:37:20.284177
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    from .compiler import loader
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    loader("pyslvs", "../..", p)
    assert p.compile()