

# Generated at 2022-06-17 16:31:26.449129
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os import remove
    from os.path import exists
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES
    from .logger import logger
    from .parser import parent
    from .compiler import walk_packages as wp

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)


# Generated at 2022-06-17 16:31:35.079200
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test_loader(root: str, pwd: str, link: bool, level: int, toc: bool) -> str:
        """Test function loader."""
        p = Parser.new(link, level, toc)
        for name, path in walk_packages(root, pwd):
            # Load its source or stub
            pure_py = False
            for ext in [".py", ".pyi"]:
                path_ext = path + ext
                if not isfile(path_ext):
                    continue

# Generated at 2022-06-17 16:31:41.318969
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        # Create a package
        mkdir(join(temp, 'foo'))
        _write(join(temp, 'foo', '__init__.py'), '')
        _write(join(temp, 'foo', 'bar.py'), '')
        _write(join(temp, 'foo', 'bar.pyi'), '')
        _write(join(temp, 'foo', 'baz.py'), '')
        _write(join(temp, 'foo', 'baz.pyi'), '')
        # Create a subpackage
        mkdir(join(temp, 'foo', 'sub'))
        _write(join(temp, 'foo', 'sub', '__init__.py'), '')
       

# Generated at 2022-06-17 16:31:52.136238
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    p = Parser.new(False, 1, False)
    p.parse("test", "def test() -> int: ...")
    assert p.compile() == "## test\n\n```python\ndef test() -> int: ...\n```\n"
    p = Parser.new(False, 1, False)
    p.parse("test", "class Test: ...")
    assert p.compile() == "## test\n\n```python\nclass Test: ...\n```\n"
    p = Parser.new(False, 1, False)
    p.parse("test", "class Test(object): ...")

# Generated at 2022-06-17 16:32:01.993420
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkg_resources import resource_filename
    from .parser import parent
    from .logger import logger
    logger.setLevel('DEBUG')

# Generated at 2022-06-17 16:32:13.439635
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import iter_modules
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from unittest import TestCase, main

    class TestLoader(TestCase):
        """Test loader."""

        def setUp(self):
            """Create a temporary directory."""
            self.temp_dir = TemporaryDirectory()
            self.temp_dir_path = self.temp_dir.name
            self.root_name = 'test_root'
            self.root_path = join(self.temp_dir_path, self.root_name)
            mkdir(self.root_path)
            self.root_file_path = join(self.root_path, '__init__.py')

# Generated at 2022-06-17 16:32:21.034632
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from .parser import Parser
    p = Parser.new(False, 1, False)
    p.parse('test', '"""Test docstring."""')
    assert p.compile() == '# Test\n\nTest docstring.\n'
    assert p.compile(True) == '# Test\n\nTest docstring.\n'
    p.parse('test.sub', '"""Test docstring."""')
    assert p.compile() == '# Test\n\nTest docstring.\n\n## Sub\n\nTest docstring.\n'
    assert p.compile(True) == '# Test\n\nTest docstring.\n\n## Sub\n\nTest docstring.\n'

# Generated at 2022-06-17 16:32:30.424966
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.docks import __version__ as docks_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.properties import __version__ as properties_version

# Generated at 2022-06-17 16:32:35.611198
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .compiler import loader
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    loader('pyslvs', '../../', p)
    print(p.compile())

# Generated at 2022-06-17 16:32:42.767280
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        p.parse(name, _read(path + ".py"))
    assert p.compile()