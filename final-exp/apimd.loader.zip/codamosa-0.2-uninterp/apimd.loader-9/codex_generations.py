

# Generated at 2022-06-17 16:29:52.358537
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename

    with TemporaryDirectory() as temp:
        # Create a package
        mkdir(join(temp, 'test'))
        copyfile('__init__.py', join(temp, 'test', '__init__.py'))
        copyfile('__init__.py', join(temp, 'test', '__init__.pyi'))
        copyfile('__init__.py', join(temp, 'test', 'test.py'))
        copyfile('__init__.py', join(temp, 'test', 'test.pyi'))
        copyfile('__init__.py', join(temp, 'test', 'test.so'))
        # Create

# Generated at 2022-06-17 16:30:00.038197
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import remove
    from os.path import basename
    from .parser import Parser

    def create_package(name: str, path: str) -> None:
        """Create a package."""
        mkdir(path)
        for f in ['__init__.py', '__init__.pyi', 'a.py', 'a.pyi', 'b.py', 'b.pyi']:
            copytree(join(dirname(__file__), '__test__', 'test_package', f), join(path, f))

    def remove_package(path: str) -> None:
        """Remove a package."""
        for root, _, fs in walk(path):
            for f in fs:
                remove(join(root, f))



# Generated at 2022-06-17 16:30:08.796446
# Unit test for function walk_packages
def test_walk_packages():
    def _test(name: str, path: str) -> None:
        for n, p in walk_packages(name, path):
            print(n, p)
    _test("pyslvs", "../../pyslvs")
    _test("pyslvs", "../../pyslvs-ui")
    _test("pyslvs", "../../pyslvs_ui")
    _test("pyslvs", "../../pyslvs_ui/pyslvs_ui")
    _test("pyslvs", "../../pyslvs_ui/pyslvs_ui/__init__.py")
    _test("pyslvs", "../../pyslvs_ui/pyslvs_ui/__init__.pyi")

# Generated at 2022-06-17 16:30:18.574939
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", "../../pyslvs"):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")

# Generated at 2022-06-17 16:30:27.626776
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import walk_packages
    from .logger import logger
    logger.setLevel(10)
    with TemporaryDirectory() as tmp:
        copytree('tests/test_package', tmp)
        assert exists(tmp + '/test_package/__init__.py')
        assert exists(tmp + '/test_package/test_package.py')
        assert exists(tmp + '/test_package/test_package.pyi')
        assert exists(tmp + '/test_package/test_package-stubs/__init__.py')
        assert exists(tmp + '/test_package/test_package-stubs/test_package.pyi')

# Generated at 2022-06-17 16:30:35.522341
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load

# Generated at 2022-06-17 16:30:49.204429
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from os.path import dirname
    from os import remove
    from shutil import rmtree
    from tempfile import mkdtemp
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test_loader(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)


# Generated at 2022-06-17 16:30:58.382678
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from os import remove
    from os.path import isfile
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .compiler import loader

    def _test_loader(name: str, link: bool, level: int, toc: bool) -> str:
        """Test for function loader."""
        p = Parser.new(link, level, toc)
        p.parse(name, _read(resource_filename(__name__, f"{name}.py")))
        return p.compile()

    def _test_loader_ext(name: str, link: bool, level: int, toc: bool) -> str:
        """Test for function loader."""

# Generated at 2022-06-17 16:31:05.977781
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .test_data import test_data
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', test_data):
        p.parse(name, _read(path))
    assert p.compile() == _read(join(test_data, 'pyslvs-api.md'))

# Generated at 2022-06-17 16:31:14.563724
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkgutil import walk_packages

    def _test_walk_packages(name: str, path: str) -> None:
        """Test walk_packages."""
        for n, p in walk_packages(name, path):
            assert basename(p) == n.replace('.', '_') + '.py'

    with TemporaryDirectory() as temp:
        # Create a package
        mkdir(join(temp, 'package'))
        copyfile(__file__, join(temp, 'package', '__init__.py'))
        copyfile(__file__, join(temp, 'package', 'module.py'))
        # Create a module