

# Generated at 2022-06-17 16:29:32.493874
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from unittest import TestCase, main
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copytree

    class TestLoader(TestCase):

        def setUp(self) -> None:
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            copytree(join(dirname(__file__), 'test_loader'), self.temp_path)

        def tearDown(self) -> None:
            self.temp_dir.cleanup()

        def test_loader(self) -> None:
            """Test function loader."""
            path = join(self.temp_path, 'docs', 'test-api.md')
            self.assertFalse(isfile(path))
            gen

# Generated at 2022-06-17 16:29:39.862116
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.properties import __version__ as properties_version
    from pyslvs_ui.widgets.toolbars import __version__ as toolbars_version

# Generated at 2022-06-17 16:29:50.894406
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import walk_packages
    from os import chdir
    from os.path import dirname
    from sys import path as sys_path
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from .logger import logger
    from .parser import Parser
    from .compiler import loader

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        chdir(temp)
        sys_path.append(temp)
        mkdir('test')
        with open('test/__init__.py', 'w') as f:
            f.write("""
            def test_func():
                \"\"\"Test function.\"\"\"
                pass
            """)

# Generated at 2022-06-17 16:29:58.896536
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import chdir, getcwd
    from os.path import dirname, join
    from importlib import import_module
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    pwd = getcwd()
    chdir(dirname(__file__))
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui'], onerror=lambda _: None):
        if name == 'pyslvs_ui':
            continue
        logger.debug(f"{name} <= {join(pwd, name.replace('.', '/') + '.py')}")

# Generated at 2022-06-17 16:30:06.237088
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import isfile

    class TestLoader(TestCase):
        """Test function loader."""

        def setUp(self) -> None:
            """Set up."""
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            self.root = 'root'
            self.root_path = join(self.temp_path, self.root)
            self.root_py = join(self.root_path, '__init__.py')
            self.root_pyi = join(self.root_path, '__init__.pyi')

# Generated at 2022-06-17 16:30:16.295204
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import join
    from pkgutil import walk_packages as pkg_walk_packages
    from pkgutil import get_loader
    from importlib.util import spec_from_loader
    from importlib.machinery import SourceFileLoader
    from importlib.abc import Loader
    from .logger import logger
    from .parser import Parser
    from .compiler import walk_packages

    def _mock_loader(name: str) -> Loader:
        return SourceFileLoader(name, name)

    def _mock_spec(name: str) -> Optional[Loader]:
        return spec_from_loader(name, _mock_loader(name))


# Generated at 2022-06-17 16:30:22.431226
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import get_loader
    from importlib import import_module
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree

    def _test_loader(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
            return True
       

# Generated at 2022-06-17 16:30:32.149580
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .compiler import walk_packages
    from .logger import logger
    logger.setLevel(10)
    with TemporaryDirectory() as tmp:
        copytree(resource_filename(__name__, 'test_data'), tmp)
        for name, path in walk_packages('test_data', tmp):
            logger.debug(f"{name} <= {path}")
        remove(join(tmp, 'test_data', '__init__.py'))

# Generated at 2022-06-17 16:30:43.888498
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", "../../"):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-17 16:30:50.997318
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-17 16:34:37.444001
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import remove
    from os.path import isfile
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, "")
    assert p.compile() == ""
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, "")
    assert p.compile() == ""
    p = Parser.new(False, 1, False)

# Generated at 2022-06-17 16:34:50.879312
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-17 16:34:59.718962
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename, splitext
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test_file(name: str, p: Parser) -> None:
        """Test file."""
        path = resource_filename(__name__, f"test_files/{name}")
        p.parse(name, _read(path))

    with TemporaryDirectory() as temp:
        # Copy test files
        for name in ["test_a.py", "test_b.py", "test_c.py"]:
            copy(resource_filename(__name__, f"test_files/{name}"), temp)
        # Test

# Generated at 2022-06-17 16:35:09.532164
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import spec_from_loader, module_from_spec
    from importlib.machinery import SourceFileLoader
    from .parser import Parser

    def _load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        s = spec_from_loader(name, SourceFileLoader(name, path))
        if s is not None:
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
            return True
        return False


# Generated at 2022-06-17 16:35:20.200323
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import join as join_path

    class TestLoader(TestCase):

        """Test for function loader."""

        def setUp(self) -> None:
            """Set up."""
            self.tmp = TemporaryDirectory()
            self.tmp_path = self.tmp.name
            self.root = 'test_root'
            self.root_path = join_path(self.tmp_path, self.root)
            mkdir(self.root_path)
            self.root_file = join_path(self.root_path, '__init__.py')

# Generated at 2022-06-17 16:35:28.001215
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from tempfile import mkdtemp
    from pkgutil import get_data
    from .parser import Parser
    from .compiler import walk_packages

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _test(name: str, doc: str, p: Parser) -> None:
        assert p.parse(name, doc) is None
        assert p.compile() == doc


# Generated at 2022-06-17 16:35:38.288467
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import SourceFileLoader

    def _test_walk_packages(name: str, path: str) -> None:
        """Test walk_packages."""
        for n, p in walk_packages(name, path):
            assert n == basename(p).replace('.py', '')
            assert p.startswith(path)
            assert isfile(p + '.py')
            assert isfile(p + '.pyi')

    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))


# Generated at 2022-06-17 16:35:52.074513
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import EXTENSION_SUFFIXES
    from .parser import Parser
    from .logger import logger

    def _read(path: str) -> str:
        """Read the script from file."""
        with open(path, 'r') as f:
            return f.read()

    def _write(path: str, doc: str) -> None:
        """Write text to the file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)


# Generated at 2022-06-17 16:36:02.650010
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname
    from pkgutil import get_loader
    from importlib import import_module
    from .logger import logger
    from .parser import Parser
    from .compiler import loader

    logger.setLevel('DEBUG')
    chdir(dirname(__file__))
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', '..'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")

# Generated at 2022-06-17 16:36:10.359250
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", "../.."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to