

# Generated at 2022-06-17 16:29:25.006187
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copytree

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            copytree('tests/test_pkg', self.temp_path)

        def tearDown(self):
            self.temp_dir.cleanup()


# Generated at 2022-06-17 16:29:31.675068
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from .parser import Parser
    from .logger import logger

    def _test_loader(root: str, pwd: str, link: bool, level: int, toc: bool) -> str:
        """Test function loader."""
        p = Parser.new(link, level, toc)
        for _, name, _ in walk_packages([pwd]):
            p.parse(name, "")
        return p.compile()

    with TemporaryDirectory() as tmp:
        copytree('tests/test_loader', tmp)
        logger.info(f"Test directory: {tmp}")
        assert _test_

# Generated at 2022-06-17 16:29:39.222649
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try

# Generated at 2022-06-17 16:29:41.946046
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        p.parse(name, _read(path + ".py"))
    print(p.compile())


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-17 16:29:49.513504
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    with TemporaryDirectory() as tmp:
        copyfile('test/test_package/__init__.py', tmp + '/__init__.py')
        copyfile('test/test_package/test_module.py', tmp + '/test_module.py')
        copyfile('test/test_package/test_module.pyi', tmp + '/test_module.pyi')
        copyfile('test/test_package/test_module.c', tmp + '/test_module.c')
        copyfile('test/test_package/test_module.so', tmp + '/test_module.so')
        assert isfile(tmp + '/__init__.py')

# Generated at 2022-06-17 16:29:57.959130
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename

    def _test_walk_packages(path: str, name: str, *,
                            stub: bool = False,
                            sub: bool = False) -> None:
        with TemporaryDirectory() as tmp:
            if stub:
                copyfile(path, join(tmp, basename(path) + PEP561_SUFFIX))
            if sub:
                copyfile(path, join(tmp, 'sub', basename(path)))
            else:
                copyfile(path, join(tmp, basename(path)))
            assert name in [n for n, _ in walk_packages(name, tmp)]


# Generated at 2022-06-17 16:30:01.234760
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', 'pyslvs'):
        p.parse(name, _read(path + '.py'))
    print(p.compile())

# Generated at 2022-06-17 16:30:06.424071
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import makedirs
    from os.path import join
    from pkgutil import walk_packages
    with TemporaryDirectory() as temp:
        makedirs(join(temp, 'a', 'b', 'c'))
        makedirs(join(temp, 'a', 'b', 'c', 'd'))
        makedirs(join(temp, 'a', 'b', 'c', 'd', 'e'))
        makedirs(join(temp, 'a', 'b', 'c', 'd', 'e', 'f'))
        makedirs(join(temp, 'a', 'b', 'c', 'd', 'e', 'f', 'g'))

# Generated at 2022-06-17 16:30:10.014606
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    p = Parser.new(False, 1, False)
    p.parse("test", "test")
    assert p.compile() == "test"

# Generated at 2022-06-17 16:30:19.240859
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_file_location

    def _create_module(name: str, path: str) -> None:
        with open(path, 'w+') as f:
            f.write(f"'''{name}'''\n")

    with TemporaryDirectory() as temp:
        # Create package
        mkdir(join(temp, 'test_package'))
        # Create sub-package
        mkdir(join(temp, 'test_package', 'sub_package'))
        # Create module
        _create_module('test_package', join(temp, 'test_package', '__init__.py'))
        _create

# Generated at 2022-06-17 16:31:18.416303
# Unit test for function walk_packages

# Generated at 2022-06-17 16:31:28.912387
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    from .test_data import test_data_pwd
    from .test_data import test_data_root
    from .test_data import test_data_root_name
    from .test_data import test_data_root_title
    from .test_data import test_data_root_names
    from .test_data import test_data_root_names_title
    from .test_data import test_data_root_names_pwd
    from .test_data import test_data_root_names_pwd_title
    from .test_data import test_data_root_names_pwd_title_link
    from .test_data import test_data_root_names_pwd_title_link_level

# Generated at 2022-06-17 16:31:37.453436
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
   

# Generated at 2022-06-17 16:31:43.112283
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.docks import __version__ as docks_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.popup import __version__ as popup_version

# Generated at 2022-06-17 16:31:52.487997
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import Parser
    from .logger import set_logger
    set_logger(False)
    temp_dir = mkdtemp()

# Generated at 2022-06-17 16:32:00.409057
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import chdir
    from os.path import dirname
    from sys import path as sys_path
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    sys_path.append(dirname(__file__))
    chdir(dirname(__file__))
    p = Parser.new(True, 1, False)
    for _, name, _ in walk_packages(['pyslvs_ui']):
        p.parse(name, _read(name + '.py'))
    print(p.compile())

# Generated at 2022-06-17 16:32:06.638252
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as td:
        td = abspath(td)
        # Create a package
        pkg_path = join(td, 'pkg')
        mkdir(pkg_path)
        # Create a module
        with open(join(pkg_path, '__init__.py'), 'w+') as f:
            f.write('__version__ = "0.0.0"\n')

# Generated at 2022-06-17 16:32:16.002804
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import join as pjoin
    from pkg_resources import resource_filename
    from .parser import Parser

    def _write(path: str, doc: str) -> None:
        """Write text to the file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        """Read the script from file."""
        with open(path, 'r') as f:
            return f.read()

    def _load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error

# Generated at 2022-06-17 16:32:22.857091
# Unit test for function walk_packages
def test_walk_packages():
    from . import __path__ as p

# Generated at 2022-06-17 16:32:28.895756
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import path
    from sys import path as sys_path
    sys_path.append(path.dirname(path.abspath(__file__)))
    for _, name, _ in walk_packages(path=[path.dirname(path.abspath(__file__))]):
        print(loader(name, path.dirname(path.abspath(__file__)), False, 1, False))

# Generated at 2022-06-17 16:33:28.185966
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import SourceFileLoader
    from .parser import Parser

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _load_module(name: str, path: str, p: Parser) -> bool:
        s = spec_from_file_location(name, path)

# Generated at 2022-06-17 16:33:36.532617
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import join as join_path
    from pkg_resources import resource_filename
    from .parser import parent

    with TemporaryDirectory() as tmp:
        copytree(resource_filename(__name__, 'test'), join_path(tmp, 'test'))
        for name, path in walk_packages('test', tmp):
            assert name == parent(path).replace(sep, '.')

# Generated at 2022-06-17 16:33:50.632227
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import walk_packages
    from importlib import import_module
    from os import remove
    from os.path import isfile
    from .logger import logger
    logger.setLevel(10)
    root = "pyslvs"
    pwd = _site_path(root)
    assert pwd
    assert isdir(pwd)
    assert isfile(join(pwd, "__init__.py"))
    assert isfile(join(pwd, "__init__.pyi"))
    assert isfile(join(pwd, "__version__.py"))
    assert isfile(join(pwd, "__version__.pyi"))
    assert isfile(join(pwd, "__main__.py"))

# Generated at 2022-06-17 16:33:58.770871
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        for f in ['__init__.py', '__init__.pyi', 'a.py', 'a.pyi', 'b.py', 'b.pyi']:
            copyfile(resource_filename(__name__, f), join(tmp, f))
        for name, path in walk_packages('', tmp):
            logger.debug(f"{name} <= {path}")

# Generated at 2022-06-17 16:34:03.720260
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from .test_data import test_data
    assert loader(
        "pyslvs",
        dirname(dirname(__file__)),
        False,
        1,
        False
    ) == test_data

# Generated at 2022-06-17 16:34:09.588088
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    for name, path in walk_packages("pyslvs", ".."):
        if name == "pyslvs.__main__":
            continue
        p = Parser.new(False, 1, False)
        p.parse(name, _read(path + ".py"))
        assert p.compile() == test_data[name]

# Generated at 2022-06-17 16:34:17.252157
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import walk_packages
    from os import getcwd
    from os.path import dirname
    from .parser import Parser
    p = Parser.new(False, 1, False)
    for _, name, _ in walk_packages(['pyslvs'], getcwd()):
        p.parse(name, _read(join(dirname(__file__), '..', name.replace('.', sep) + '.py')))
    assert p.compile()

# Generated at 2022-06-17 16:34:21.064540
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .test_data import test_data
    for name, path in walk_packages(test_data, dirname(__file__)):
        print(name, path)
    print(loader(test_data, dirname(__file__), False, 1, False))

# Generated at 2022-06-17 16:34:30.543529
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.info import __doc__ as pyslvs_ui_doc
    from pyslvs_ui.info import __version__ as pyslvs_ui_version
    from pyslvs_ui.info import __author__ as pyslvs_ui_author
    from pyslvs_ui.info import __email__ as pyslvs_ui_email
    from pyslvs_ui.info import __copyright__ as pyslvs_ui_copyright
    from pyslvs_ui.info import __license__ as pyslvs_ui_license
    from pyslvs_ui.info import __url__ as pyslvs_

# Generated at 2022-06-17 16:34:37.741525
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename

    with TemporaryDirectory() as temp_dir:
        # Create a package
        mkdir(join(temp_dir, "test_package"))
        copyfile("__init__.py", join(temp_dir, "test_package", "__init__.py"))
        copyfile("__init__.py", join(temp_dir, "__init__.py"))
        # Create a module
        copyfile("__init__.py", join(temp_dir, "test_module.py"))
        # Create a subpackage
        mkdir(join(temp_dir, "test_package", "test_subpackage"))

# Generated at 2022-06-17 16:36:31.117295
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from random import randint
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import SourceFileLoader
    from .parser import Parser
    from .logger import logger

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-17 16:36:39.877681
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    from pyslvs_ui.compiler import gen_api
    from pyslvs_ui.info import __title__
    from pyslvs_ui.__main__ import __doc__ as ui_doc
    from pyslvs_ui.__main__ import __version__ as ui_version
    from pyslvs_ui.__main__ import __title__ as ui_title
    from pyslvs_ui.__main__ import __author__ as ui_author
    from pyslvs_ui.__main__ import __copyright__ as ui_copyright
    from pyslvs_ui.__main__ import __license__ as ui_license
    from pyslvs_ui.__main__ import __email

# Generated at 2022-06-17 16:36:51.049234
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.io import __version__ as io_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.widgets.canvas import __version__ as canvas_version
    from pyslvs_ui.widgets.dialogs import __version__ as dialogs_version
    from pyslvs_ui.widgets.frames import __version__ as frames_version
    from pyslvs_ui.widgets.properties import __version__ as properties_version

# Generated at 2022-06-17 16:37:01.980275
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from pkg_resources import resource_filename
    from pyslvs_ui.package import __name__ as pkg_name
    from pyslvs_ui.package import __file__ as pkg_file
    from pyslvs_ui.package import __version__ as pkg_version


# Generated at 2022-06-17 16:37:07.927758
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module

# Generated at 2022-06-17 16:37:16.308742
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from os import chdir
    from os.path import dirname, abspath
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser
    from .logger import logger
    from .compiler import loader
    from .__main__ import __version__

    logger.setLevel(10)
    pwd = abspath(dirname(__file__))
    chdir(mkdtemp())
    logger.info(f"Current path: {pwd}")
    logger.info(f"Current version: {__version__}")
    logger.info(f"Current path: {pwd}")
    logger.info(f"Current version: {__version__}")
    logger.info(f"Current path: {pwd}")
    logger

# Generated at 2022-06-17 16:37:20.977604
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os.path import dirname, join
    from sys import path as sys_path
    sys_path.append(dirname(__file__))
    assert loader('test', '.', False, 1, False)