

# Generated at 2022-06-17 16:29:20.227895
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import Parser
    from .compiler import walk_packages

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _test_walk_packages(path: str, name: str, doc: str) -> None:
        _write(join(path, f"{name}.py"), doc)
        p = Parser.new(False, 1, False)

# Generated at 2022-06-17 16:29:25.506708
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        p.parse(name, _read(path + '.py'))
    assert p.compile() == test_data

# Generated at 2022-06-17 16:29:32.038489
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import remove
    from os.path import exists
    from pkgutil import walk_packages
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import SourceFileLoader
    from importlib.abc import Loader
    from .parser import Parser

    def _load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
            return True


# Generated at 2022-06-17 16:29:39.539921
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import join

    class TestWalkPackages(TestCase):

        def test_walk_packages(self):
            with TemporaryDirectory() as temp_dir:
                copyfile(__file__, join(temp_dir, '__init__.py'))
                copyfile(__file__, join(temp_dir, '__init__.pyi'))
                copyfile(__file__, join(temp_dir, 'test.py'))
                copyfile(__file__, join(temp_dir, 'test.pyi'))
                copyfile(__file__, join(temp_dir, 'test.so'))

# Generated at 2022-06-17 16:29:50.828376
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from unittest import TestCase

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            self.temp_path_1 = join(self.temp_path, 'test_1')
            self.temp_path_2 = join(self.temp_path, 'test_2')
            self.temp_path_3 = join(self.temp_path, 'test_3')
            self.temp_path_4 = join(self.temp_path, 'test_4')
            self.temp_path_5 = join(self.temp_path, 'test_5')


# Generated at 2022-06-17 16:29:55.428653
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages("pyslvs", ".."):
        p.parse(name, _read(path + ".py"))
    assert p.compile()

# Generated at 2022-06-17 16:30:01.780579
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copy
    from .parser import parent
    from .compiler import walk_packages
    with TemporaryDirectory() as tmp:
        copy('setup.py', tmp)
        copy('pyslvs_ui/__init__.py', tmp)
        copy('pyslvs_ui/__main__.py', tmp)
        copy('pyslvs_ui/info/__init__.py', tmp)
        copy('pyslvs_ui/info/about.py', tmp)
        copy('pyslvs_ui/info/about.pyi', tmp)
        copy('pyslvs_ui/info/__main__.py', tmp)

# Generated at 2022-06-17 16:30:10.985323
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", "."):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load

# Generated at 2022-06-17 16:30:19.955557
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copytree

    class Test(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_path = self.temp_dir.name
            copytree(
                'tests/test_package',
                join(self.temp_path, 'test_package')
            )

        def tearDown(self):
            self.temp_dir.cleanup()


# Generated at 2022-06-17 16:30:27.583081
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from pkg_resources import resource_filename
    from .parser import parent

    with TemporaryDirectory() as tmp:
        for name, path in walk_packages(__name__, resource_filename(__name__, '.')):
            copyfile(path, join(tmp, basename(path)))
        for name, path in walk_packages(parent(__name__), tmp):
            remove(path)
            assert name == __name__

# Generated at 2022-06-17 16:31:49.990919
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import chdir
    from os.path import dirname, join
    from pkg_resources import resource_filename
    chdir(dirname(resource_filename(__name__, '__init__.py')))
    print(loader('pyslvs', '.', False, 1, False))
    print(loader('pyslvs', '.', False, 1, True))
    print(loader('pyslvs', '.', True, 1, False))
    print(loader('pyslvs', '.', True, 1, True))
    print(loader('pyslvs', join('..', '..', '..', 'pyslvs'), False, 1, False))

# Generated at 2022-06-17 16:32:01.205004
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .parser import Parser
    from .logger import logger
    from .__main__ import __version__
    from .__main__ import __author__
    from .__main__ import __copyright__
    from .__main__ import __license__
    from .__main__ import __email__
    from .__main__ import __url__
    from .__main__ import __status__
    from .__main__ import __description__
    from .__main__ import __keywords__
    from .__main__ import __platforms__
    from .__main__ import __classifiers__
    from .__main__ import __requires__
    from .__main__ import __provides__
    from .__main__ import __requires_dist__
    from .__main__ import __provides_dist

# Generated at 2022-06-17 16:32:05.676436
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from pkgutil import get_data
    from unittest import TestCase, main

    class TestLoader(TestCase):

        def test_loader(self):
            """Test the loader function."""
            p = Parser.new(True, 1, False)
            p.parse("test", get_data("pyslvs_ui", "test/test_parser.py"))
            self.assertEqual(p.compile(), get_data("pyslvs_ui", "test/test_parser.md"))

    main()

# Generated at 2022-06-17 16:32:15.825859
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import dirname
    from tempfile import mkdtemp
    from shutil import rmtree
    from .parser import Parser
    from .logger import logger

    logger.setLevel(40)
    p = Parser.new(False, 1, False)

    def _write(path: str, doc: str) -> None:
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    def _load_module(name: str, path: str, p: Parser) -> bool:
        try:
            __import__(parent(name))
        except ImportError:
            return False


# Generated at 2022-06-17 16:32:22.725441
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    from .parser import Parser
    from .logger import logger
    from .__init__ import __file__ as pyslvs_path
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp_dir:
        copy(pyslvs_path, temp_dir)
        pyslvs_path = join(temp_dir, basename(pyslvs_path))
        p = Parser.new(True, 1, False)
        for name, path in walk_packages('pyslvs', temp_dir):
            p.parse(name, _read(path + '.py'))
        assert p.compile() == loader('pyslvs', temp_dir, True, 1, False)

# Generated at 2022-06-17 16:32:27.809246
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", test_data):
        p.parse(name, _read(path + ".py"))
    assert p.compile() == _read(test_data + "/api.md")

# Generated at 2022-06-17 16:32:37.754686
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import getcwd
    from os.path import dirname
    from sys import path as sys_path
    sys_path.append(dirname(getcwd()))
    from pyslvs_ui import __version__
    assert __version__ == '20.2.0'
    from pyslvs_ui.info import __version__
    assert __version__ == '20.2.0'
    from pyslvs_ui.info import __version__
    assert __version__ == '20.2.0'
    from pyslvs_ui.info import __version__
    assert __version__ == '20.2.0'
    from pyslvs_ui.info import __version__
    assert __version__ == '20.2.0'

# Generated at 2022-06-17 16:32:50.098375
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkg_resources import resource_filename
    from .parser import Parser

    def _test_walk_packages(
        name: str,
        path: str,
        p: Parser,
        expect: int,
        expect_name: Sequence[str]
    ) -> None:
        assert len(list(walk_packages(name, path))) == expect
        for n in expect_name:
            assert p.has_doc(n)

    p = Parser.new(False, 1, False)
    path = mkdtemp()

# Generated at 2022-06-17 16:33:01.779517
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import exists
    from pkgutil import walk_packages as pkg_walk_packages
    from pkg_resources import working_set
    from pkg_resources import DistributionNotFound, VersionConflict
    from importlib import import_module

    def _test_walk_packages(name: str, path: str) -> None:
        """Test walk_packages."""
        for name, path in walk_packages(name, path):
            assert exists(path)
            assert import_module(name) is not None

    with TemporaryDirectory() as temp:
        # Test for pure python package
        copyfile('setup.py', join(temp, 'setup.py'))

# Generated at 2022-06-17 16:33:12.712675
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import isfile
    from shutil import rmtree
    from tempfile import mkdtemp
    from .parser import Parser
    from .compiler import walk_packages
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(False, 1, False)
    pwd = mkdtemp()
    with open(join(pwd, '__init__.py'), 'w+') as f:
        f.write("")
    with open(join(pwd, 'a.py'), 'w+') as f:
        f.write("def a():\n    pass")
    with open(join(pwd, 'b.py'), 'w+') as f:
        f.write("def b():\n    pass")