

# Generated at 2022-06-17 16:30:22.787476
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename

    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))
        mkdir(join(tmp, 'test', '__pycache__'))
        copyfile(__file__, join(tmp, 'test', '__init__.py'))
        copyfile(__file__, join(tmp, 'test', '__init__.pyi'))
        copyfile(__file__, join(tmp, 'test', '__init__.pyc'))
        copyfile(__file__, join(tmp, 'test', '__init__.pyo'))

# Generated at 2022-06-17 16:30:32.518386
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os.path import dirname
    from pyslvs_ui.compiler import loader
    from pyslvs_ui.parser import Parser
    from pyslvs_ui.logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", dirname(__file__)):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))

# Generated at 2022-06-17 16:30:41.769379
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import walk_packages
    from os import getcwd
    from os.path import dirname
    from importlib import import_module
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, True)
    for _, name, _ in walk_packages(path=[dirname(__file__)]):
        m = import_module(name)
        p.load_docstring(name, m)
    logger.info(p.compile())
    logger.info(loader('pyslvs', getcwd(), True, 1, True))

# Generated at 2022-06-17 16:30:50.557400
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser
    from .parser import parent, Parser

# Generated at 2022-06-17 16:30:58.549101
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copytree

    class TestWalkPackages(TestCase):

        def setUp(self):
            self.temp = TemporaryDirectory()
            self.path = self.temp.name
            copytree('./tests/test_walk_packages', self.path)

        def tearDown(self):
            self.temp.cleanup()


# Generated at 2022-06-17 16:31:09.405923
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    p = Parser.new(True, 1, False)
    p.parse("test", "")
    assert p.compile() == ""
    p.parse("test", "test")
    assert p.compile() == "test"
    p.parse("test", "test\n")
    assert p.compile() == "test"
    p.parse("test", "test\n\n")
    assert p.compile() == "test"
    p.parse("test", "test\n\n\n")
    assert p.compile() == "test"
    p.parse("test", "test\n\n\n\n")
    assert p.compile() == "test"

# Generated at 2022-06-17 16:31:12.550811
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    assert loader('pyslvs', 'pyslvs', True, 1, False).startswith(
        f"# pyslvs {__version__} API\n\n"
    )

# Generated at 2022-06-17 16:31:17.096629
# Unit test for function loader
def test_loader():
    """Test for loader."""
    from pkgutil import walk_packages
    from sys import path
    from os.path import dirname, abspath
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for _, name, _ in walk_packages(['pyslvs'], path=[dirname(abspath(__file__))]):
        p.parse(name, _read(name + '.py'))
    assert p.compile()

# Generated at 2022-06-17 16:31:27.737501
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove
    from os.path import dirname, join
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES

    def _create_module(path: str, name: str, doc: str) -> None:
        with open(join(path, name + '.py'), 'w+') as f:
            f.write(doc)

    def _create_extension(path: str, name: str, doc: str) -> None:
        with open(join(path, name + '.pyx'), 'w+') as f:
            f.write(doc)

# Generated at 2022-06-17 16:31:36.237260
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    from .parser import Parser
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", test_data):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        # Try to load module here
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext
            if not isfile(path_ext):
                continue

# Generated at 2022-06-17 16:34:08.262249
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", "pyslvs"):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
       

# Generated at 2022-06-17 16:34:15.406690
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pyslvs import __version__
    from pyslvs_ui import __version__ as ui_version
    from pyslvs_ui.info import __version__ as info_version
    from pyslvs_ui.widgets import __version__ as widgets_version
    from pyslvs_ui.io import __version__ as io_version
    from pyslvs_ui.dialogs import __version__ as dialogs_version
    from pyslvs_ui.graphics import __version__ as graphics_version
    from pyslvs_ui.graphics.canvas import __version__ as canvas_version
    from pyslvs_ui.graphics.drawing import __version__ as drawing_version

# Generated at 2022-06-17 16:34:26.159369
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkgutil import walk_packages
    from .parser import Parser
    from .logger import logger
    from .compiler import loader

    logger.setLevel('DEBUG')
    with TemporaryDirectory() as tmp:
        copytree(__file__.replace('compiler.py', 'test'), tmp)
        for _, name, _ in walk_packages([tmp]):
            if name == 'test':
                continue
            logger.info(f"Load root: {name}")
            doc = loader(name, tmp, True, 1, False)
            assert doc.strip()

# Generated at 2022-06-17 16:34:33.196432
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from os import remove
    from os.path import isfile
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel('DEBUG')
    with TemporaryDirectory() as temp:
        copytree(resource_filename(__name__, 'test_data'), temp)
        assert isfile(join(temp, 'test_data', '__init__.py'))
        assert isfile(join(temp, 'test_data', 'test_data.py'))
        assert isfile(join(temp, 'test_data', 'test_data.pyi'))
        assert isfile(join(temp, 'test_data', 'test_data.so'))
       

# Generated at 2022-06-17 16:34:36.722403
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from pkgutil import iter_modules
    from os.path import dirname
    from sys import path as sys_path
    sys_path.append(dirname(__file__))
    for _, name, _ in iter_modules():
        if name.startswith('_'):
            continue
        loader(name, dirname(__file__), True, 1, False)


# Generated at 2022-06-17 16:34:42.149806
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_data import test_data
    for name, path in walk_packages('test_data', dirname(test_data.__file__)):
        print(name, path)

# Generated at 2022-06-17 16:34:52.766243
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from os import remove
    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from pkg_resources import resource_filename
    from .parser import Parser
    from .logger import logger
    logger.setLevel(10)
    with TemporaryDirectory() as td:
        copytree(resource_filename(__name__, 'test_data'), td)
        assert exists(join(td, '__init__.py'))
        assert exists(join(td, 'test_data.py'))
        assert exists(join(td, 'test_data.pyi'))
        assert exists(join(td, 'test_data.so'))
        assert exists(join(td, 'test_data.pyd'))

# Generated at 2022-06-17 16:35:01.512065
# Unit test for function loader
def test_loader():
    from os import chdir, getcwd
    from os.path import dirname
    from shutil import rmtree
    from tempfile import mkdtemp
    from pkg_resources import resource_filename
    from .parser import Parser
    from .compiler import loader
    from .logger import logger

    logger.setLevel(10)
    pwd = getcwd()
    chdir(dirname(__file__))
    root = 'pyslvs_ui'
    p = Parser.new(True, 1, False)
    for name, path in walk_packages(root, resource_filename(__name__, '../')):
        p.parse(name, _read(path + '.py'))
    assert loader(root, resource_filename(__name__, '../'), True, 1, False) == p.comp

# Generated at 2022-06-17 16:35:11.468362
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import remove
    from os.path import basename
    from pkgutil import walk_packages
    from importlib.util import find_spec
    from importlib.machinery import EXTENSION_SUFFIXES

    with TemporaryDirectory() as tmp:
        # Create a package
        mkdir(join(tmp, 'test'))
        with open(join(tmp, 'test', '__init__.py'), 'w'):
            pass
        # Create a module
        with open(join(tmp, 'test', 'test.py'), 'w'):
            pass
        # Create a extension module

# Generated at 2022-06-17 16:35:22.566044
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages function."""
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os.path import basename
    from os import remove
    from pkg_resources import resource_filename
    from .parser import Parser
    from .compiler import walk_packages

    def _test_walk_packages(name: str, path: str, p: Parser) -> None:
        """Test walk_packages function."""
        for n, p in walk_packages(name, path):
            assert p.endswith('.py')
            assert n == 'test.test'
            assert p.endswith('test.py')
            assert p.startswith(path)
            assert p.startswith(path + 'test')
            assert p.startswith(path + 'test-stubs')
           