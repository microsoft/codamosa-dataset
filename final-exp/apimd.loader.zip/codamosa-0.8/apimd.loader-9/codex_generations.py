

# Generated at 2022-06-11 19:27:25.026059
# Unit test for function walk_packages
def test_walk_packages():
    def t(name: str, path: str) -> None:
        for n, p in walk_packages(name, path):
            print(n, p)
    t('test', './test_data')
    assert not list(walk_packages('test', './undefined'))
    assert not list(walk_packages('test', './test_data/test/tp3'))
    t('test', './test_data/test/tp3')

# Generated at 2022-06-11 19:27:30.325557
# Unit test for function loader
def test_loader():
    """Test case."""
    working_path = dirname(__file__)
    result = gen_api(
        {
            "pyslvs": "pyslvs",
        },
        working_path,
        prefix="tests",
        dry=True
    )
    assert len(result) > 0

# Generated at 2022-06-11 19:27:35.166855
# Unit test for function walk_packages
def test_walk_packages():
    assert "colorama.__init__" in {parent(i[0]) for i in walk_packages("colorama", "colorama.py")}
    assert "colorama.tests.__init__" not in {parent(i[0]) for i in walk_packages("colorama", "colorama.py")}
    assert "colorama.ansi.__init__" in {parent(i[0]) for i in walk_packages("colorama", "colorama/")}


if __name__ == "__main__": test_walk_packages()

# Generated at 2022-06-11 19:27:44.287029
# Unit test for function loader
def test_loader():
    import tempfile
    from pathlib import Path
    from shutil import rmtree
    from os import environ, pathsep

    def _test_env(name: str) -> None:
        if name not in environ:
            environ[name] = ""

    def _create_files(files: list[tuple[str, str]]) -> tuple[str, str]:
        tmp = tempfile.mkdtemp()
        for f, text in files:
            p = Path(tmp) / f
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text)
        return tmp, tmp + PEP561_SUFFIX


# Generated at 2022-06-11 19:27:47.646055
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .parser import root_names
    from .test_settings import pwd_path
    print(loader(root_names[0][1], pwd_path))

# Generated at 2022-06-11 19:27:55.193415
# Unit test for function walk_packages
def test_walk_packages():
    assert dict(walk_packages("pyslvs", "./pyslvs")) == {
        "pyslvs": "pyslvs/__init__.py",
        "pyslvs.data": "pyslvs/data/__init__.py",
        "pyslvs.data.constraint_icons": "pyslvs/data/constraint_icons.py",
        "pyslvs.data.extension_modules": "pyslvs/data/extension_modules.py",
        "pyslvs.data.package_data": "pyslvs/data/package_data.py",
    }

# Generated at 2022-06-11 19:28:03.730130
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from unittest import TestCase, main
    from os import getcwd

    class LoaderTest(TestCase):

        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_dir.__enter__()

        def tearDown(self):
            self.temp_dir.__exit__(None, None, None)

        def _create_package(self, name: str) -> str:
            mkdir(join(self.temp_dir.name, name))
            return name

        def _create_module(self, name: str, doc: str = "") -> str:
            filename = join(self.temp_dir.name, f"{name}.py")
            with open(filename, "w") as f:
                f.write(doc)
            return

# Generated at 2022-06-11 19:28:10.479533
# Unit test for function loader
def test_loader():
    s = loader(
        "pyslvs",
        r"C:\Users\VSL\Desktop\pyslvs",
        link=True,
        level=1,
        toc=False,
    )
    with open(r"C:\Users\VSL\Desktop\pyslvs\API.md", 'w+', encoding='utf-8') as f:
        f.write(s)



# Generated at 2022-06-11 19:28:18.507418
# Unit test for function walk_packages
def test_walk_packages():
    xs = list(walk_packages("pyslvs", "C:/Python37/lib/site-packages"))

# Generated at 2022-06-11 19:28:19.949275
# Unit test for function loader
def test_loader():
    assert loader('pyslvs', '.', False, 2, False).strip()



# Generated at 2022-06-11 19:29:51.030215
# Unit test for function loader
def test_loader():
    """Test module loader."""
    from .docstring import build_docstring
    from .examples.factory import build_example
    from .examples.parser import parse_example
    from .examples.faker import list_example
    from .examples.faker import set_fake_example
    from .examples.faker import set_fake_module
    from .examples.faker import set_fake_examples
    from .examples.faker import get_fake_examples

    # Test the empty module
    _write('empty.py', '')
    assert [] == list_example('empty')
    assert '' == build_docstring('empty')
    assert '' == build_example('empty', 'add')
    # Test the module with add function

# Generated at 2022-06-11 19:29:56.766988
# Unit test for function loader
def test_loader():
    """Test func: test_loader"""
    assert loader('pyslvs', join(dirname(abspath(__file__)), '..'), False, 1, False)
    assert loader('core', '..', False, 1, False)
    assert _load_module('test.test_compiler', 'test/test_compiler.py', Parser.new(False, 1, False))

# Generated at 2022-06-11 19:30:06.934025
# Unit test for function loader
def test_loader():
    import doctest
    parser = Parser.new(link=True, level=1, toc=False)
    parser.load_docstring('test',
                          """
    >>> def a() -> str:
    ...     '''
    ...     bbb
    ...     '''
    ...     return ""
    >>>
    """)
    parser.parse('test', """
    >>> def a() -> float:
    ...     '''
    ...     aaa
    ...     '''
    ...     return 0.0
    >>>
    """)
    parser.parse('test', """
    >>> def b() -> None:
    ...     '''
    ...     bbb
    ...     '''
    ...     return
    ...
    """)
    doc = parser.compile()

# Generated at 2022-06-11 19:30:09.728322
# Unit test for function loader
def test_loader():
    from os import remove
    from tempfile import gettempdir
    test_path = gettempdir() + '/test'

# Generated at 2022-06-11 19:30:14.918732
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    logger.setLevel('DEBUG')
    doc = loader('pyslvs', '..', True, 1, True)
    assert doc.strip()
    logger.setLevel('INFO')
    #
    doc = loader('pyslvs', '..', True, 1, False)
    logger.info(doc)

# Generated at 2022-06-11 19:30:18.951566
# Unit test for function loader
def test_loader():
    loader(root='pyslvs', pwd='../../src/')

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:30:21.771778
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    loader("pyslvs", ".", link=False, level=2, toc=True)

# Generated at 2022-06-11 19:30:29.591107
# Unit test for function walk_packages
def test_walk_packages():
    from itertools import takewhile
    from os import getcwd, remove
    from os.path import basename, exists
    from glob import glob

    # Get the path
    cwd = parent(getcwd())
    test_name = f"{basename(cwd)}.test"
    test_path = join(cwd, 'test')
    sys_path.append(cwd)

    def create_file(path, name, remark="", content=""):
        nonlocal test_path
        path = join(test_path, f"{path}.py")
        with open(path, 'w') as f:
            if remark:
                f.write(f"# {remark}\n")
            f.write(f"from {test_name} import {name}\n")
            if content:
                f.write

# Generated at 2022-06-11 19:30:36.982930
# Unit test for function loader
def test_loader():
    """Integration test for the `loader` function."""
    import re
    import inspect

    def assert_doc(doc: str) -> None:
        nonlocal count
        assert inspect.getdoc(test_loader) == f"""Integration test for the `loader` function.

{doc}
        """
        assert re.search(r'cfg=\[8\]', doc)
        assert re.search(r'_gen_api\(root_names=\[12\]\):', doc)
        count += 1

    count = 0
    assert_doc(loader('pyslvs', join(dirname(__file__), '..')))
    assert_doc(loader('pyslvs', join(dirname(__file__), '..'), level=2))

# Generated at 2022-06-11 19:30:43.217808
# Unit test for function loader
def test_loader():
    """Test function loader."""
    logger.info(loader('collections', __file__, True, 2, False))
    logger.info(loader('sys', __file__, False, 1, False))
    logger.info(loader('pyslvs', __file__, True, 3, False))

# Generated at 2022-06-11 19:33:30.312169
# Unit test for function loader
def test_loader():
    def run_tests(name: str, path: str) -> bool:
        logger.info(f"Search for {name} at {path}")
        doc = loader(name, path)
        logger.info(f"\n{doc}")
        return bool(doc)
    assert run_tests("doc", ".")
    assert run_tests("pyslvs", "pyslvs")
    assert run_tests("pyslvssynth", "pyslvssynth")
    assert run_tests("synthpyx", "synthpyx")
    return True


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:33:35.492968
# Unit test for function loader
def test_loader():
    """Unit test."""
    s = loader('pyslvs', dirname(__file__) + '/../../../pyslvs', False, 1, False)
    assert s == '## pyslvs API\n\n\n### Module pyslvs\n'


if __name__ == "__main__":
    logger.setLevel("DEBUG")
    test_loader()

# Generated at 2022-06-11 19:33:42.657484
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    name = "PyQt5"
    sys_path.append(r'D:\Program Files (x86)\Python39\Lib\site-packages')
    pkgs = list(walk_packages(name, sys_path[-1]))
    sys.path.pop()
    assert pkgs[0][0] == 'PyQt5.QtCore'
    assert pkgs[0][1].endswith('PyQt5\\QtCore.pyi')

# Generated at 2022-06-11 19:33:50.549304
# Unit test for function loader
def test_loader():
    from os import getcwd
    from .vexpr import joint

    pwd = getcwd() + sep + 'test'
    r = loader('test_joint', pwd, link=False, level=1, toc=False)
    print(r)
    r = loader('test_joint', pwd, link=False, level=1, toc=True)
    print(r)
    r = loader('test_joint', pwd, link=True, level=1, toc=True)
    print(r)
    r = loader('test_joint', pwd, link=True, level=2, toc=True)
    print(r)
    r = gen_api({'joint': 'test_joint'}, pwd, dry=False)
    print(r)

# Generated at 2022-06-11 19:34:01.843707
# Unit test for function loader
def test_loader():
    import pkgutil
    from pyslvs_ui.compiler import Parser
    from .compiler import walk_packages
    from .info import __pyslvs_ui_version__

    # Test for walk_packages
    assert ("pyslvs_ui.compiler", "pyslvs_ui/compiler.py") in walk_packages(
        "pyslvs_ui", __site_path__
    )

    # Test for Parser
    p = Parser.new(True)
    p.parse("pyslvs-ui", "All APIs are listed in [here](../..)")
    assert p.compile() == (
        '# pyslvs-ui\n'
        '\n'
        'All APIs are listed in [here](../..)\n'
    )
    p