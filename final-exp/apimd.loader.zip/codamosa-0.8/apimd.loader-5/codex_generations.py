

# Generated at 2022-06-11 19:28:04.018858
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase
    from tempfile import TemporaryDirectory
    from shutil import copyfile

    class TestGen(TestCase):

        @staticmethod
        def copy_all(p: str, f: str, *ext: str) -> None:
            for e in ext + [".py"]:
                copyfile(f + e, join(p, parent(f) + e))

        def setUp(self) -> None:
            self.pwd = TemporaryDirectory()
            self.pwd_path = abspath(self.pwd.name)
            self.copy_all(
                self.pwd_path,
                join("..", "test_package", "pyslvs"),
                ".pyi",
                ".py",
                "-stubs.pyi"
            )

# Generated at 2022-06-11 19:28:15.002779
# Unit test for function loader
def test_loader():
    import unittest

    class TestLoader(unittest.TestCase):

        def test_parent(self):
            self.assertEqual(parent("a"), "")
            self.assertEqual(parent("a.b.c"), "a.b")
            self.assertEqual(parent("a.b.c.d"), "a.b.c")


# Generated at 2022-06-11 19:28:20.729946
# Unit test for function loader
def test_loader():
    from os import remove
    from shutil import rmtree, move
    from tempfile import mkdtemp
    from .parser import Parser
    from . import parser
    examples = 'examples'
    parser.__file__ = parser.__file__.replace('parser.cpython-37', 'parser')
    sys_path.append(examples)
    sys_path.append(dirname(parser.__file__))
    tmp = mkdtemp()
    p = Parser.new(True, 2, True)
    # Walk root `pyslvs` package
    name, path = next(walk_packages('pyslvs', examples))
    assert name == 'pyslvs'
    assert path == 'examples/pyslvs'
    assert _load_module(name, path + '.py', p)
   

# Generated at 2022-06-11 19:28:28.561722
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function `walk_packages`."""
    from pathlib import Path

    # Test for packages in site-packages
    for name, path in walk_packages("numpy", "numpy"):
        assert Path(path + '.py').is_file()

    # Test for packages in local directory
    for name, path in walk_packages("test", __file__):
        assert Path(path + '.py').is_file()
        assert Path(path + '.pyi').is_file()

    # No such packages
    for _ in walk_packages("no_such_package", "numpy"):
        assert False

# Generated at 2022-06-11 19:28:35.658962
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pathlib import Path
    from importlib import import_module
    from itertools import repeat
    from unittest.mock import patch
    with patch("sphinxcontrib.pyslvs_api.compiler.Parser.new", return_value=Parser()):
        assert loader("pyslvs_graph", Path(__file__).parent.parent.parent, False, 1, False) == ""
    package = import_module("pyslvs_graph")
    for item in repeat("_", 2):
        delattr(package, item)
    assert package.__all__ == ()

# Generated at 2022-06-11 19:28:44.521216
# Unit test for function loader
def test_loader():
    from unittest.mock import patch
    with patch.dict(sys_path, {}, clear=True):
        sys_path.append('.')
        sys_path.append(abspath('pyvcpkg'))
        doc = loader('site-packages', 'pyvcpkg', True, 2, False)
        assert '#' * 2 + " Pyvcpkg API" in doc
        assert "__main__" not in doc
        assert "long documentation" in doc


# Generated at 2022-06-11 19:28:46.245996
# Unit test for function loader
def test_loader():
    """Unit test."""
    logger.info(loader('pyslvs_ui', dirname(__file__)))


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:28:58.060812
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from os.path import curdir, realpath
    from sys import platform
    from unittest import TestCase, main

    class Dummy:

        """Test dummy package."""

        def __init__(self, *, a: int = 1, b: float = 1.1) -> None:
            self.a = a
            self.b = b

    class Test(TestCase):

        """Test cases."""

        def test_package(self) -> None:
            """Test walking in dummy package."""
            name = Dummy.__module__
            path = _site_path(name)
            if path is None:
                self.fail('Module not installed.')
            if platform == 'win32':
                path = realpath(path)
            count = 0

# Generated at 2022-06-11 19:29:01.111046
# Unit test for function loader
def test_loader():
    from .pytest import test_doc
    doc = loader('pyslvs', 'pyslvs', True, 2, False)
    assert isinstance(doc, str)
    test_doc(doc)

# Generated at 2022-06-11 19:29:08.856841
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        (tmp_path / 'a/b').mkdir(parents=True, exist_ok=True)
        (tmp_path / 'a/b/x.pyi').touch()
        (tmp_path / 'a/b/c.pyi').touch()
        (tmp_path / 'a/b/d.pyi').touch()
        (tmp_path / 'a/b/t.py').touch()
        (tmp_path / 'a/b/__init__.pyi').touch()
        (tmp_path / 'a/b/__init__.py').touch()
        (tmp_path / 'a/b/__cached__').mkdir()