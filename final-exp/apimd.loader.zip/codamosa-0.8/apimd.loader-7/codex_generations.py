

# Generated at 2022-06-11 19:26:18.041662
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import pytest
    from pyslvs.io import parse_json
    pytest.importorskip('solver')
    pytest.importorskip('pyperclip')
    pytest.importorskip('gspread')

    data = parse_json(
        "https://raw.githubusercontent.com/pyslvs-ui/pyslvs-ui/master/pyslvs_ui/collector_ui/project.json"
    )
    root_names = {d['title']: d['name'] for d in data}
    pwd = dirname(__file__)
    docs = gen_api(root_names, pwd, dry=True)

# Generated at 2022-06-11 19:26:21.387478
# Unit test for function loader
def test_loader():
    from importlib import util
    from os import remove
    from os.path import dirname
    from glob import glob
    prefix = 'docs'
    # Create test module in runtime
    code = 'def test(): ...\n'
    test_module = 'test_module'
    test_path = join(prefix, f'{test_module}.py')
    _write(test_path, code)
    # Create stub for it

# Generated at 2022-06-11 19:26:28.053133
# Unit test for function loader
def test_loader():
    def w(cmd: str, p: str, f: str) -> None:
        print(cmd)
        assert isfile(f)
        with open(f, 'r') as fp:
            print(fp.read().strip())
        print('-' * 12)

    # noinspection PyUnresolvedReferences
    from importlib import reload
    from .test_parser import c
    from .test_parser import Parser as P
    from .test_parser import debug, info, warning

    class _P(P):
        @staticmethod
        def new(link: bool, level: int, toc: bool) -> P:
            c.update('@logger.debug', debug)
            c.update('@logger.info', info)
            c.update('@logger.warning', warning)
            return P.new

# Generated at 2022-06-11 19:26:39.196768
# Unit test for function walk_packages
def test_walk_packages():
    """Test cases for `walk_packages`."""
    import sys
    import os
    if sys.platform == 'win32':
        return
    relpath = os.path.relpath
    # pylint:disable=unused-import
    from .__meta__ import __version__
    _, path = find_spec('pyslvs').submodule_search_locations[0].split('/', 1)
    for name, path in walk_packages('pyslvs', '/' + path):
        sys.stdout.write(f"{name} <= {relpath(path, os.getcwd())}\n")
    # pylint:enable=unused-import


if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-11 19:26:39.808294
# Unit test for function loader
def test_loader():
    pass

# Generated at 2022-06-11 19:26:45.194722
# Unit test for function loader
def test_loader():
    # Use local site-packages
    import sys, os
    sys.path.append(os.getcwd())
    assert sys.path[-1] == os.getcwd()
    assert loader("pyslvs", "site-packages", False, 2, False)
    loader("numpy", "site-packages", False, 2, False)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:26:51.191193
# Unit test for function walk_packages

# Generated at 2022-06-11 19:27:01.145743
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from unittest.mock import patch, Mock
    from types import ModuleType

    pwd = './'
    name = 'pyslvs'
    path = _site_path(name)
    if path == "":
        logger.error(f"{name} not found in site-packages")
        return

    module_a = ModuleType('a')
    module_b = ModuleType('b')
    module_a.__doc__ = 'Doc A'
    module_b.__doc__ = 'Doc B'
    module_a.b = module_b
    module_b.a = module_a

    def test_load_module(name_str: str, path: str) -> bool:
        """Simple module load function for testing."""

# Generated at 2022-06-11 19:27:05.968203
# Unit test for function loader
def test_loader():
    logger.setLevel('DEBUG')
    lib = "numpy"
    lib_path = _site_path(lib)
    if not lib_path:
        raise ImportError(f'module `{lib}` is not installed')

    print(loader(lib, lib_path, False, 1, False))

# Generated at 2022-06-11 19:27:13.127173
# Unit test for function walk_packages
def test_walk_packages():
    class Mock:

        """Mock object."""

        @staticmethod
        def spec_from_file_location(name: str, path: str) -> object:
            """Mock."""
            return 'spec'

        class MockLoader:

            """MockLoader."""

            @staticmethod
            def exec_module(mod: object) -> None:
                """Mock."""
                pass

        def __init__(self):
            """Init."""
            self.submodule_search_locations = ['path']
            self.loader = Mock.MockLoader()

    file_path = 'path'
    name = 'name'
    importlib.machinery.EXTENSION_SUFFIXES.append('.py')

# Generated at 2022-06-11 19:28:56.756757
# Unit test for function loader
def test_loader():
    import sys
    import os
    import pyslvs_ui
    assert _read(__file__) == loader('compiler', os.path.dirname(pyslvs_ui.__file__), True, 1, False)
    assert _read(__file__) == loader('src.' + __name__, os.path.join(sys.base_prefix, 'lib', 'site-packages'), True, 1, False)

# Generated at 2022-06-11 19:29:05.988626
# Unit test for function loader
def test_loader():
    from .__main__ import __path__ as path
    from .parser import Parser
    from . import cvxopt
    pwd = parent(cvxopt.__file__)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('cvxopt', pwd):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        # Try to load module here

# Generated at 2022-06-11 19:29:12.116942
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        mkdir(join(tmp_dir, 'c'))
        mkdir(join(tmp_dir, 'c', '__pycache__'))
        _write(join(tmp_dir, 'a.py'), "a = 1")
        _write(join(tmp_dir, 'b.pyi'), "b = 1")
        _write(join(tmp_dir, 'c', 'a.py'), "a = 1")
        _write(join(tmp_dir, 'c', 'a.cpython-35.pyc'), "")
        _write(join(tmp_dir, 'c', 'b.cpython-36.pyc'), "")

# Generated at 2022-06-11 19:29:17.730054
# Unit test for function loader
def test_loader():
    def demo():
        """
        >>> dry = True
        >>> docs = gen_api({'math': 'math'}, abspath(dirname(__file__)), dry=dry, level=2)
        >>> len(docs) > 0
        True
        """
    import doctest
    doctest.testmod(verbose=False)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:29:25.303192
# Unit test for function loader
def test_loader():
    from .parser import Parser
    p = Parser.new(False, 1, False)
    # Without pwd argument, we can only load the module if it was registered.
    assert loader("pyslvs", "site-packages", False, 1, False)
    # With pwd argument, we can fully load all modules and sub modules
    assert loader("pyslvs", "site-packages", False, 1, False)

# Generated at 2022-06-11 19:29:36.614809
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import doctest
    doctest.testmod()
    assert loader('pyslvs', __file__, True, 1, False)


if __name__ == "__main__":
    test_loader()
    print(gen_api({'Pyslvs': 'pyslvs'}, pwd=__file__))
    # print(gen_api({'numpy': 'numpy'}))
    # print(gen_api({'pyopengl': 'OpenGL'}))
    # print(gen_api({'scipy': 'scipy'}, pwd='/usr/local/lib/python3.8/dist-packages'))
    # print(gen_api({'matplotlib': 'matplotlib'}, pwd='/usr/local/lib/python

# Generated at 2022-06-11 19:29:38.575046
# Unit test for function loader
def test_loader():
    """Test function loader."""
    l = loader("pyslvs", "../..", True, 1, False)
    assert len(l.strip().split('\n')) == 11
    assert len(l.split('\n## ')) == 3
    assert len(l.split('\n### ')) == 8


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:29:50.761172
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import sys
    import pkgutil

    def get_spec(name: str) -> dict[str, str]:
        spec = pkgutil.get_loader(name)
        return {'get_code': spec.get_code,
                'get_filename': spec.get_filename,
                'get_source': spec.get_source,
                'is_package': spec.is_package,
                'load_module': spec.load_module,
                'origin': spec.origin,
                'loader': str(spec.loader)}

    def test_pkg_loader() -> None:
        """Test function get_loader."""
        sp = sys.modules[__name__].__spec__.submodule_search_locations[0]

# Generated at 2022-06-11 19:29:52.096499
# Unit test for function loader
def test_loader():
    assert loader("test", "tests/data", True, 1, True)

# Generated at 2022-06-11 19:29:56.843703
# Unit test for function walk_packages
def test_walk_packages():
    with open('pattern.txt', 'w+') as f:
        for name, path in walk_packages('regex', 'site-packages'):
            f.write(f"{name} <= {path}\n")
    logger.info("Test result: pattern.txt")

