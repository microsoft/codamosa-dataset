

# Generated at 2022-06-11 19:26:31.992736
# Unit test for function loader
def test_loader():
    """Test function loader."""
    doc = loader("pyslvs", "..", False, 1, False)
    print(doc)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:26:36.797810
# Unit test for function loader
def test_loader():
    r = loader("math", "tests", True, 1, False)
    assert r.startswith("# math\n\n")
    assert r.endswith("# random\n\n## Methods\n\n### random(self) -> float\n\n")



# Generated at 2022-06-11 19:26:45.982206
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import gettempdir
    from os import path
    from shutil import rmtree
    from pyslvs_ui.compiler import walk_packages
    import subprocess

    tmp_path = path.join(gettempdir(), "slvs-test")
    subprocess.check_call(["pip", "install", "--force-reinstall", "-t", tmp_path, "pyslvs"])
    namespace = {
        'a': 'pyslvs_ui',
        'b': 'pyslvs',
        'c': 'pyslvs.system',
        'd': 'pyslvs.ui.widget',
        'e': 'pyslvs.ui.dialogs'
    }

# Generated at 2022-06-11 19:26:56.831571
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import tempfile
    import shutil
    class TestLoader(unittest.TestCase):
        def setUp(self):
            self.tmp = tempfile.mkdtemp()
            self.modules = [
                "module1.submodule",
                "module2",
                "module3",
                "module4.submodule1.subsubmodule",
                "module4.submodule2"
            ]
            for m in self.modules:
                name = f"{self.tmp}{sep}{m}"
                mkdir(name)
                _write(f"{name}{sep}__init__.py", "")
            _write(f"{self.tmp}{sep}{self.modules[0]}{sep}submodule.py", "")

# Generated at 2022-06-11 19:27:07.900985
# Unit test for function loader
def test_loader():
    script = r"""
r"""
    assert not Parser.new(True, 1, False).parse(
        'module_name',
        """
module_name = "haha"
    """
    ).strip()
    assert Parser.new(True, 1, False).parse(
        'module_name',
        """
module_name = "haha"
    """
    ).strip()
    assert Parser.new(True, 1, False).parse(
        'module_name',
        r"""
"""
    ).strip()
    assert Parser.new(True, 1, False).parse(
        'module_name',
        r"""
    """
    ).strip()
    assert Parser.new(True, 1, False).parse(
        'module_name',
        script
    ).strip()



# Generated at 2022-06-11 19:27:13.931132
# Unit test for function walk_packages
def test_walk_packages():
    import sys, shutil
    # Write files

# Generated at 2022-06-11 19:27:21.093729
# Unit test for function loader
def test_loader():
    from .__stubs__ import test
    from .compiler import loader, _read, Parser
    logger.info(f"Load {test.__file__}")
    p = Parser.new(False, 1, False)
    p.parse("test", _read(test.__file__))
    with open('test.md', 'w+') as f:
        f.write(p.compile())
    loader("test", "/Users/yuan/Documents/GitHub/pyslvs-ui/pyslvs_ui/", False, 1, False)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:27:32.510595
# Unit test for function loader
def test_loader():
    from os.path import dirname, abspath

    def _check(dox: str, name: str):
        assert dox.startswith(f"# {name}\n")

    def _check_docstring(name: str, root: str) -> str:
        dox = _read(dirname(abspath(__file__)) + f"/{root}/{name}.md")
        _check(dox, name)
        return dox

    # Test target: pyslvs_ui.data
    # PEP 561
    p = Parser.new(False, 1, False)
    p.parse("pyslvs_ui.data.core", _read("./core.pyi"))

# Generated at 2022-06-11 19:27:43.472635
# Unit test for function loader
def test_loader():
    import os
    from .tempdir import TemporaryDirectory
    from .examples import get_simple_robot, get_l2_robot

    def check(root_name: str, level: int) -> bool:
        logger.info(f"{root_name} test for module loader")
        root = get_simple_robot() if root_name == 'simple' else get_l2_robot()
        with TemporaryDirectory() as d:
            gen_api({'Root': root_name}, d, level=level, dry=True)
            return os.path.isdir(d + f"/{root_name.replace('_', '-')}-api.md")

    assert check('simple', 1)



# Generated at 2022-06-11 19:27:52.173077
# Unit test for function loader
def test_loader():
    import os
    import sys
    if sys.platform == 'win32':
        _pwd = "C:/Users/Yuan Chang/AppData/Local/Programs/Python/Python38-32/Lib/site-packages"
    else:
        _pwd = "~/anaconda3/envs/tst/lib/python3.8/site-packages"
    if not os.path.isdir(_pwd):
        raise Exception('cannot find site-packages directory')
    p = Parser.new(True, 1, True)
    for name, path in walk_packages('scipy', _pwd):
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not os.path.isfile(path_ext):
                continue