

# Generated at 2022-06-11 19:27:46.197021
# Unit test for function loader
def test_loader():
    assert loader('venv', 'example/pyslvs', True, 1, True)



# Generated at 2022-06-11 19:27:48.949026
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from .test.test_walk_packages_walk import name, path as pwd, pkg
    assert set(walk_packages(name, pwd)) == set(pkg)

# Generated at 2022-06-11 19:27:50.058005
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    pass

# Generated at 2022-06-11 19:27:55.757358
# Unit test for function loader
def test_loader():
    """Test suite for loader."""
    assert loader('pyslvs', '', False, 1, False)
    assert loader('pyslvs', 'pyslvs', False, 1, False)
    assert loader('pyslvs', 'pyslvs/tests', False, 1, False)
    assert loader('svgwrite', '', True, 2, True)
    assert loader('svgwrite', 'svgwrite', True, 2, True)
    assert loader('svgwrite', 'svgwrite/tests', True, 2, True)



# Generated at 2022-06-11 19:28:04.221473
# Unit test for function loader
def test_loader():
    from unittest.mock import patch
    from .compiler import (_read, _write, walk_packages, _load_module)

    with patch('builtins.open', side_effect=[_read, _write]):
        assert _read(__file__)
        _write(__file__, "123")
    with patch('builtins.open', side_effect=[_read, _write]):
        assert _read(__file__)
        _write(__file__, "123")


# Generated at 2022-06-11 19:28:09.038439
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    text = loader('test', './test', False, 1, False)
    assert "test.hello" in text
    assert "test.world" in text
    assert "test.book" in text
    assert "test.book.page" not in text

# Generated at 2022-06-11 19:28:14.049821
# Unit test for function walk_packages
def test_walk_packages():
    from .test import test_foo
    from .test.test_foo import test_foo_1, test_foo_2
    assert list(walk_packages("test", dirname(test_foo.__file__))) \
        == [("test_foo", test_foo_1.__file__),
            ("test_foo.test_foo_1", test_foo_2.__file__)]

# Generated at 2022-06-11 19:28:16.772740
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    root = 'numpy'
    pwd = _site_path(root)
    assert isdir(pwd)
    assert loader(root, pwd, True, 1, False)



# Generated at 2022-06-11 19:28:19.823363
# Unit test for function loader
def test_loader():
    import os
    os.chdir('tests')
    assert loader('abc', '__pycache__', False, 1, False)

# Generated at 2022-06-11 19:28:21.445521
# Unit test for function loader
def test_loader():
    """Test function loader."""

# Generated at 2022-06-11 19:31:04.532904
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from sys import path as sys_path
    sys_path.insert(0, '.')
    r = loader("sample", ".", False, 2, False)
    assert r.startswith("## Sample Module")
    assert r.endswith("[sample.submodule B]\n\n")
    import sample.submodule
    assert hasattr(sample.submodule, "B")

# Generated at 2022-06-11 19:31:10.691526
# Unit test for function loader
def test_loader():
    # Test for walk_packages()
    assert tuple(walk_packages("pyslvs", "pyslvs_test")) == (
        ("pyslvs.test.test_compiler", "pyslvs_test/pyslvs/test/test_compiler.pyi"),
        ("pyslvs.test.test_compiler", "pyslvs_test/pyslvs/test/test_compiler.py"),
    )
    assert tuple(walk_packages("pyslvs", "pyslvs_test")) != (
        ("pyslvs.test_compiler", "pyslvs_test/pyslvs/test_compiler.pyi"),
    )

# Generated at 2022-06-11 19:31:18.961516
# Unit test for function loader
def test_loader():
    def build(a: str, b: str, c: str) -> str:
        return f"```python\n{a}\n```\n{b}\n{c}\n"

    def load(s: str) -> str:
        return loader(s, 'tests', True, 1, False)

    assert load('a.b') == build('a', '## b', '- [x, x, x]')
    assert load('a.b.c') == build('a.b', '## c', '- [x, x, x]')
    assert load('a.b.c.d') == build('a.b.c', '## d', '- [x, x, x]')
    assert load('a.b.c.d.e') == ""

# Generated at 2022-06-11 19:31:29.604137
# Unit test for function loader
def test_loader():
    from pkgutil import WALK_ONLY
    from os import path
    from pyslvs_ui.info import HOMEPAGE_URL, DOCS_URL

    for _, module, _ in WALK_ONLY:
        if module == "pyslvs":
            break
    else:
        raise ImportError('Not found pyslvs!')

    p = Parser(True, 1, False)
    for name, path in walk_packages(module, path.dirname(path.dirname(__file__))):
        p.parse(name, _read(path + '.pyi'))
    assert 'pyslvs' in p.modules
    p.modules['pyslvs'].set_link(HOMEPAGE_URL, DOCS_URL)
    print(p.compile())

# Generated at 2022-06-11 19:31:32.378461
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pyslvs import __version__
    from .logger import set_level
    set_level("debug")
    print(loader("pyslvs", ".", True, 2, False))
    print(__version__)

# Generated at 2022-06-11 19:31:42.020377
# Unit test for function loader
def test_loader():
    from .test import unittest
    from .unittest_utils import TestCase

    class LoaderTest(TestCase):
        def test_loader(self):
            txt = loader('solve', 'solve')
            self.assertRegex(txt, r'^# solve API\n+'
                                  r'## solve\n+'
                                  r'### solve_by_vl\n+'
                                  r'#### class Kinematics\n+'
                                  r'##### solve\n+'
                                  r'##### solve_p\n')

    unittest.main(module="test_loader", argv=[__file__])

# Generated at 2022-06-11 19:31:47.742786
# Unit test for function loader
def test_loader():
    """test the function: loader"""
    docs = gen_api({"Test": "test"}, pwd=".", dry=True)
    assert len(docs) == 1

# Generated at 2022-06-11 19:31:53.812717
# Unit test for function loader
def test_loader():

    def foo() -> int:
        """foo"""
        return 1

    def bar() -> float:
        """bar"""
        return 3.14

    import collections
    # No doc:
    assert isinstance(collections.defaultdict, type)

    # No dot
    assert foo() == 1
    # Two dots
    assert 3.14 == round(bar(), 2)

    import os
    # Use system model
    assert isinstance(os.altsep, str)

    # The name with dot
    import xml.sax.saxutils as s
    assert s.escape('<a>') == '&lt;a&gt;'

    # No __init__.py
    import json
    assert json.load is not None

    # No __init__.pyi
    import numpy

# Generated at 2022-06-11 19:32:06.181868
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from itertools import product
    from .sys_path_guard import Guard
    from .compiler_support import (
        PWD_VALID,
        ROOT_VALID,
        DICT_VALID,
        DICT_INVALID,
        PWD_INVALID,
        ROOT_INVALID,
    )
    with Guard():
        for pwd, root in product(PWD_VALID, ROOT_VALID):
            logger.debug(f"Test: {root} ===> {pwd}")
            assert loader(root, pwd, False, 1, False)
        for pwd, root in product(PWD_INVALID, ROOT_INVALID):
            logger.debug(f"Test: {root} ===> {pwd}")


# Generated at 2022-06-11 19:32:07.257109
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod()