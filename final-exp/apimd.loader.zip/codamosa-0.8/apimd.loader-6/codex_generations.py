

# Generated at 2022-06-11 19:26:01.245327
# Unit test for function loader
def test_loader():
    """Test for function _loader."""
    from pkg_resources import ensure_directory
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        logger.debug(tmpdir)
        # Create fake package
        mkdir(join(tmpdir, "test_package"))
        with open(join(tmpdir, "test_package", "__init__.py"), 'w+') as f:
            f.write("Test package")

# Generated at 2022-06-11 19:26:04.955303
# Unit test for function loader
def test_loader():
    from sys import path as sys_path
    from os.path import expanduser, dirname
    sys_path.append(dirname(expanduser('~/.local/lib/python3.8/site-packages')))
    import numpy as np
    doc = loader('numpy', '~/.local/lib/python3.8/site-packages', True, 1, True)
    print(doc)
    print(list(walk_packages('numpy', '~/.local/lib/python3.8/site-packages')))

# Generated at 2022-06-11 19:26:13.949023
# Unit test for function loader
def test_loader():
    """Unit test for function 'loader'."""
    import pkgutil
    import numpy as np
    n = 'numpy'
    root = np.__file__
    dir_path = _site_path(n)
    assert len(dir_path) != 0, "Can not load numpy module"
    for name, _, is_pkg in pkgutil.iter_modules([dir_path]):
        if not is_pkg:
            continue
        logger.debug(f"{n}.{name}")
        loader(f"{n}.{name}", dir_path, True, 1)
        loader(f"{n}.{name}", dir_path, True, 1, True)

# Generated at 2022-06-11 19:26:18.469715
# Unit test for function loader
def test_loader():
    def test(name: str, pwd: str, link: bool, level: int, toc: bool) -> str:
        return loader(name, pwd, link, level, toc)
    assert test('test', '.', True, 1, False).strip()


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:26:27.322209
# Unit test for function loader
def test_loader():
    from shutil import rmtree
    from tempfile import mkdtemp
    from .utils import capture_stdout
    from .parser import Parser

    def _write(path: str, doc: str) -> None:
        """Write text to the file."""
        with open(path, 'w+', encoding='utf-8') as f:
            f.write(doc)

    def _test(p: Parser, path: str) -> str:
        """Read the script from file."""
        with open(path, 'r') as f:
            return f.read()

    fortoctest = "test.py"
    fortoc = f"""
from .test import *
from .test import foo as bar, baz as qux
from .test import * as hello
"""

# Generated at 2022-06-11 19:26:38.998112
# Unit test for function walk_packages

# Generated at 2022-06-11 19:26:47.761123
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from importlib import import_module

    suffixes = ["/build/temp.linux-x86_64-3.7/test.cpython-37m-x86_64-linux-gnu.so"]
    for suffix in suffixes:
        print('-' * 10)
        print(suffix)
        with TemporaryDirectory() as dirname:
            test_module_name = 'test'
            test_module_path = join(dirname, test_module_name + '.py')
            with open(test_module_path, 'w') as f:
                f.write('def foo():\n    """Docstring."""\n    pass\n')

# Generated at 2022-06-11 19:26:58.963394
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import Mock
    from .compiler import walk_packages
    m = Mock()

# Generated at 2022-06-11 19:27:09.157412
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""

# Generated at 2022-06-11 19:27:20.344835
# Unit test for function walk_packages
def test_walk_packages():
    from .data import TEMP_DIR
    from .utility import import_from
    from .unittest import TestCase

    class Test(TestCase):

        def test_walk(self):
            out = list(walk_packages('test_package', TEMP_DIR))

# Generated at 2022-06-11 19:29:02.871228
# Unit test for function loader
def test_loader():
    import unittest
    import pyslvs
    from .util import extract_doc

    class TestLoader(unittest.TestCase):

        def test_loader(self):
            self.assertNotEqual('', extract_doc(loader(
                "pyslvs", dirname(pyslvs.__file__), link=False, level=1, toc=False
            )))

    unittest.main(argv=[''], verbosity=2, exit=False)

# Generated at 2022-06-11 19:29:10.065142
# Unit test for function loader
def test_loader():
    """Unit test for loader."""
    # pylint: disable=no-member
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, '__init__.pyi'), 'w'):
            pass
        with open(os.path.join(tmp, 'root.py'), 'w') as f:
            f.write("def foo() -> None: ...\n")
        with open(os.path.join(tmp, 'foo.py'), 'w') as f:
            f.write("def bar() -> None: ...\n")
        with open(os.path.join(tmp, 'sub', '__init__.pyi'), 'w'):
            pass

# Generated at 2022-06-11 19:29:19.221861
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .logger import logger_set
    logger_set(console=False, file=False)
    with TemporaryDirectory() as tmpdir:
        site_dir = Path(tmpdir)
        package = site_dir / "pack"
        package.mkdir()
        (package / "__init__.py").touch()
        (package / "__init__.pyi").touch()
        (package / "__main__.py").touch()
        (package / "a.py").touch()
        (package / "a.pyi").touch()
        (package / "b.py").touch()
        (package / "dec.so").touch()
        (package / "enc.so").touch()

# Generated at 2022-06-11 19:29:28.826884
# Unit test for function loader
def test_loader():
    import sys
    from io import StringIO
    from os import getcwd, chdir, remove
    from os.path import join as join_path
    from contextlib import redirect_stdout
    from .logger import logger_handler
    from . import __version__

    cwd = getcwd()
    chdir(dirname(__file__))

    root = "docs_builder"

    # Generate API
    p = Parser.new()
    p.import_all(root)
    p.parse("docs_builder_api", p.compile())

    # Generate site
    logger.info(f"Build {root}")
    logger.info("-" * 20)
    # Write API
    API_doc = join_path("tests", "API.md")

# Generated at 2022-06-11 19:29:39.409851
# Unit test for function loader
def test_loader():
    from unittest import TestCase, mock
    from importlib.machinery import ModuleSpec
    from importlib.util import find_spec
    from .parser import load_docstring as m_load_docstring

    class TestLoader(Loader):
        """Mock module loader to change docstring."""

        def exec_module(self, module: str) -> None:
            """Mock module."""
            setattr(module, '__doc__', 'mock docstring')

    def create_module_spec(name: str, loader: Optional[Loader] = None) -> None:
        """Create a module spec."""
        spec = ModuleSpec(name, loader)
        spec.submodule_search_locations = ['mock path']
        return spec


# Generated at 2022-06-11 19:29:46.667460
# Unit test for function walk_packages
def test_walk_packages():
    logger.info("Test walk_packages:")
    for name, path in walk_packages("math", _site_path('math') + sep):
        logger.info(f"{name} <= {path}")
    for name, path in walk_packages("FooPackage", dirname(__file__)):
        logger.info(f"{name} <= {path}")

# Generated at 2022-06-11 19:29:53.991239
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    import shutil
    from os import sep

    class TestAll(TestCase):

        def setUp(self) -> None:
            self.tmp = TemporaryDirectory(prefix="pyslvs_")
            self.addCleanup(shutil.rmtree, self.tmp.name)
            self.lib = join(self.tmp.name, "lib")
            mkdir(self.lib)

        def test_walk_packages(self):
            """Test the process."""
            # Create package
            mkdir(join(self.lib, "pkg"))
            # Create subpackage
            mkdir(join(self.lib, "pkg", "subpkg"))
            # Create subpackage with modified name

# Generated at 2022-06-11 19:30:03.525837
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from os import chdir
    from os.path import dirname, realpath
    from tempfile import TemporaryDirectory
    from pkgutil import get_loader
    from shutil import copyfileobj

    with TemporaryDirectory(prefix='tmp-') as temp_dir:
        chdir(temp_dir)
        logger.info(f"Change path to {temp_dir}")
        # Prepare
        copyfileobj(open(realpath(__file__), 'rb'), open('module.py', 'wb'))
        copyfileobj(open(realpath(__file__), 'rb'), open('module.pyi', 'wb'))
        # Write for unit test
        doc = loader('module', temp_dir, True, 3, False)
        logger.info('=' * 12)
        logger.info(doc)

# Generated at 2022-06-11 19:30:09.639156
# Unit test for function loader
def test_loader():
    from .quotes import quotes
    from .human_body import m
    from .units import si
    from .units.prefixes import e, m, p
    from .units.prefixes import symbols as prefix_sym
    from .units.symbols import meter
    assert m == meter
    assert si
    assert prefix_sym
    assert p
    assert m
    assert e
    assert quotes


# Generated at 2022-06-11 19:30:14.509920
# Unit test for function loader
def test_loader():
    from .__init__ import __path__
    from unittest.mock import patch
    with patch('pyslvs.compiler.logger.level', 'debug'):
        gen_api({'Test': 'pyslvs'}, __path__[0], link=False, toc=True)

# Generated at 2022-06-11 19:31:59.077435
# Unit test for function loader
def test_loader():
    path = 'tests/unit_tests'
    sys_path.append(path)
    if not isdir(path):
       raise FileNotFoundError(f"'{path}' can not be found")
    assert loader('test_find_stubs', path, True, 1, True) == False

# Generated at 2022-06-11 19:32:00.127608
# Unit test for function loader
def test_loader():
    """Unit test for loader."""

# Generated at 2022-06-11 19:32:07.752490
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import raises
    from .gen_api import gen_api
    from .utility import load_api
    gen_api({"Pyslvs", "svs"}, pwd="..", dry=True)
    load_api("svs", "..")
    with raises(ImportError):
        load_api("svs.pyslvs", "..")
    load_api("pyslvs.svs.pyslvs", "..")

# Generated at 2022-06-11 19:32:17.388789
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pytest import approx
    from pkgutil import get_data
    from .parser import LinkType
    from .fresh_version import get_project_version

    root = 'docs'
    link = LinkType.LINK
    level = 2
    toc = True
    dry = True
    root_names = {
        f'Pyslvs {get_project_version()} API': 'pyslvs',
        f'Pyslvs-ui {get_project_version()} API': 'pyslvs_ui',
        f'pyslvs-demo {get_project_version()} API': 'pyslvs_demo',
        f'pyslvs-mini {get_project_version()} API': 'pyslvs_mini',
    }

# Generated at 2022-06-11 19:32:24.668185
# Unit test for function loader
def test_loader():
    """Test for the function.

    This function will look for the path:
        ../../../site-packages/
    It's expected that the path can be found.
    Or the test will fail.
    """
    from .test_config import pwd
    from .test_docstr import root_names
    gen_api(root_names, pwd, prefix='build', dry=True)
    assert True, 'Test is done.'

# Generated at 2022-06-11 19:32:34.191939
# Unit test for function loader
def test_loader():
    """Test Function

    >>> Parser.set_log(0)
    >>> test_loader()
    >>> Parser.set_log(None)
    """
    p = Parser.new(True, 1, False)
    for name, path in walk_packages("pyslvs", ".") + walk_packages("compiler", "compiler"):
        p.parse(name, _read(path + ".py"))
        _load_module(name, path + ".py", p)
    logger.debug(p.compile())

# Generated at 2022-06-11 19:32:40.775387
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from tempfile import TemporaryDirectory
    from pkg_resources import resource_filename

    def path(filename: str) -> str:
        return resource_filename('pyslvs', 'data/' + filename)

    with TemporaryDirectory() as temp:
        for name, path in walk_packages(
            'pyslvs',
            join(temp, 'site-packages')
        ):
            assert name.startswith('pyslvs')
            assert path.startswith(temp)

        for name, path in walk_packages(
            'pyslvs_ui',
            join(temp, 'site-packages')
        ):
            assert name.startswith('pyslvs_ui')
            assert path.startswith(temp)


# Generated at 2022-06-11 19:32:48.283322
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .parser import CodeBlock, Link
    p = Parser.new(True, 2, False)
    p.parse('test.test_text', """
    '''
    test_text
    '''
    """)
    p.parse('test.test_link', """
    '''
    test_link
    '''
    """)
    p.parse('test.test_code', """
    '''
    test_code

    :param one:
        A long description.
    '''
    """)
    assert CodeBlock('test_text', 'test.test_text') in p.text
    assert CodeBlock('test_link', 'test.test_link') in p.text
    assert CodeBlock('test_code', 'test.test_code') in p.text
   

# Generated at 2022-06-11 19:32:56.697135
# Unit test for function walk_packages
def test_walk_packages():
    path = abspath('.')
    pwd = parent(path) + sep
    s = list(walk_packages("Compiler", path))
    assert s[0] == ("Compiler.logger", f"{pwd}Compiler{sep}logger.pyi")
    assert s[1] == ("Compiler.parser", f"{pwd}Compiler{sep}parser.pyi")
    assert s[2] == ("Compiler.compiler", f"{pwd}Compiler{sep}compiler.pyi")

# Generated at 2022-06-11 19:32:58.296261
# Unit test for function loader
def test_loader():
    logger.debug("Test Function loader")
    from .__test__ import test_loader
    return test_loader()