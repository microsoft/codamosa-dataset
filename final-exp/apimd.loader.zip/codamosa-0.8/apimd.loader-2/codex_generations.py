

# Generated at 2022-06-11 19:26:37.109392
# Unit test for function loader
def test_loader():
    from .__init__ import __version__
    from .logger import LogManager
    LogManager.set_logger_level("warning")
    assert len(gen_api({__version__: "pyslvs"})) == 1
    LogManager.set_logger_level("info")
    assert len(gen_api({__version__: "os"})) == 1

# Generated at 2022-06-11 19:26:46.269335
# Unit test for function loader
def test_loader():
    from types import ModuleType
    from .parser import Parser
    from .fix_import import generate_pyi
    # Test for generate stub
    assert generate_pyi("pkg", "")
    assert generate_pyi("pkg", "")
    assert generate_pyi("pkg.b", "pkg.")
    assert generate_pyi("pkg.pkg", "pkg.")
    assert generate_pyi("pkg.pkg.a.b", "pkg.")
    assert generate_pyi("pkg.pkg.c", "pkg.")
    assert generate_pyi("pkg.pkg.a.b.c.d", "pkg.")
    assert generate_pyi("pkg.pkg.c.d", "pkg.")
    # Test for parser
    p = Parser.new()
    m = ModuleType("m")

# Generated at 2022-06-11 19:26:56.988941
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from os.path import join, sep
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    def create_package(folder: str, name: str) -> str:
        head, *_ = name.split('.')
        with open(join(folder, head + '.py'), 'w+') as f:
            f.write(f"# {name}")
        return join(folder, head)

    def create_folder(folder: str, name: str) -> str:
        path = create_package(folder, name)
        makedirs(path, exist_ok=True)
        return path

    def create_module(folder: str, name: str) -> str:
        path = create_package(folder, name)

# Generated at 2022-06-11 19:27:03.729945
# Unit test for function loader
def test_loader():
    from pkg_resources import resource_filename
    from .parser import link_parser, level_parser, toc_parser
    from .cli import argtable

    argtable(['-e', '-l', '2', '-r', resource_filename(__name__, '__init__.py')])
    assert link_parser.value is True
    assert level_parser.value == 2
    assert toc_parser.value is False

    def _test_gen(dry=True):
        from .api import ROOT_NAMES
        from .cli import argtable

        argtable(['-l', '2', '-p', 'none', '-d'] if dry else ['-l', '2', '-p', 'none'])
        return gen_api(ROOT_NAMES, None, dry=dry)

    assert _test

# Generated at 2022-06-11 19:27:10.895729
# Unit test for function loader
def test_loader():
    import pkgutil
    import sys
    import random
    path = sys.path[random.randrange(len(sys.path))]
    logger.info(f"Test path: {path}")

    def walk_packages() -> Iterator[tuple[str, str]]:
        for importer, modname, ispkg in pkgutil.walk_packages(path):
            logger.debug(f"walk_packages: {modname}")
            yield modname, root

    root = 'pyslvs'
    doc = loader(root, path, True, 3, False)
    logger.info(f"Doc len: {len(doc)}")
    assert len(doc) > len(_read('README.md'))

# Generated at 2022-06-11 19:27:20.740324
# Unit test for function loader
def test_loader():
    from unittest.mock import Mock
    from .parser import parser
    from .logger import logger
    logger.info = Mock()
    logger.warning = Mock()
    logger.debug = Mock()
    p = parser(False, 0, False)
    _load_module('foo', 'foo.so', p)
    p.parse('foo', "foo")
    p.parse('bar', "bar")
    p.parse('a.b', "a.b")
    assert p.compile().strip() == '## foo\n```\nfoo\n```\n## bar\n' \
        '```\nbar\n```\n## a\n### b\n```\na.b\n```\n'

# Generated at 2022-06-11 19:27:27.660303
# Unit test for function walk_packages
def test_walk_packages():
    res = dict(walk_packages('pyslvs', '../pyslvs'))
    assert isinstance(res, dict)
    assert res
    assert res['pyslvs.info'].endswith('/__init__.pyi')
    assert res['pyslvs.info.infos'].endswith('/infos.pyi')
    assert res['pyslvs.graph.graph'].endswith('/graph.pyi')

# Generated at 2022-06-11 19:27:35.855064
# Unit test for function loader
def test_loader():
    from os.path import dirname, abspath
    from tempfile import TemporaryDirectory
    from importlib import reload
    from unittest import TestCase
    from .parser import Parser

    class DummySite(object):
        """Dummy site path."""
        _dir = None

        @classmethod
        def __call__(cls, name):
            """Find it."""
            return cls._dir

    def install():
        """Install modules."""
        P = join(DummySite._dir, 'pyslvs_ui', 'meta')
        mkdir(P)
        with open(join(P, '__init__.py'), 'w') as f:
            f.write('import pyslvs\nfrom pyslvs_ui.meta import *')

# Generated at 2022-06-11 19:27:43.158824
# Unit test for function loader
def test_loader():
    import unittest
    from os import remove
    from os.path import isfile
    from .parser import Parser

    def _parser(name: str, *, link: bool = True) -> Parser:
        p = Parser.new(link)
        _load_module(name, f"{name}.py", p)
        return p

    class TestLoader(unittest.TestCase):
        def test_simple(self):
            p = _parser("test_module")

# Generated at 2022-06-11 19:27:53.607363
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import copytree, rmtree
    from os import remove
    from .make import write_module
    from tempfile import mkdtemp

    name = "pkg"
    root = mkdtemp()
    path = join(root, name)
    mkdir(path)
    copytree(dirname(__file__), join(path, f"{name}_mod"))
    for f in ['__init__.py', '__init__.pyi']:
        remove(join(path, f))
    write_module(path, 'pkg.mod', name)
    write_module(path, 'pkg.pkg_mod', name, True)
    pkgs = list(walk_packages(name, root))
    rmtree(root)

# Generated at 2022-06-11 19:29:27.889739
# Unit test for function loader
def test_loader():
    """Test cases for function loader"""
    # case 1:
    docs = loader("pyslvs", ".", True, 1, True)
    assert docs.startswith("# Pyslvs API")
    # case 2:
    assert not loader("pyslvs", ".", True, 1, True).strip(" \n")
    # case 3:
    assert loader("pyslvs", "./pyslvs", True, 1, True).startswith("# Pyslvs API")

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:29:29.237911
# Unit test for function loader
def test_loader():
    logger.info(_site_path('pyslvs'))



# Generated at 2022-06-11 19:29:33.335215
# Unit test for function loader
def test_loader():
    """Unit test case."""
    doc = loader('pyslvs', _site_path('pyslvs'), link=False, level=1, toc=False)
    assert len(doc) > 10000, "Can not parser api."

# Generated at 2022-06-11 19:29:41.524298
# Unit test for function walk_packages
def test_walk_packages():
    def _test(name: str, path: str) -> None:
        logger.debug(f"generate packages: {path}")
        if not isdir(path):
            mkdir(path)
        _write(join(path, f"__init__.py"), "")
        _write(join(path, f"__init__.pyi"), "")
        _write(join(path, f"__init__.py.pys"), "")
        _write(join(path, f"__init__.pyi.pys"), "")
        _write(join(path, f"test.py"), '"""test"""')
        _write(join(path, f"test.pyi"), '"""test"""')
        _write(join(path, f"abc.so"), "")

# Generated at 2022-06-11 19:29:51.742310
# Unit test for function loader
def test_loader():
    from .vendor import tempfile
    from .parser import Parser
    with tempfile.TemporaryDirectory() as td:
        td += sep + 'test_api'
        mkdir(td)
        _write(td + sep + '__init__.pyi', dedent("""
        def foo(a: int, b: int) -> int: ...
        """))
        _write(td + sep + 'bar.pyi', dedent("""
        def bar(x: str, y: str) -> str: ...
        """))
        doc = loader('test_api', td, False, False, False)
        assert doc == """
        def foo(a: int, b: int) -> int: ...


        def bar(x: str, y: str) -> str: ...
        """
        p = Parser.new

# Generated at 2022-06-11 19:30:02.141201
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    import tempfile
    import shutil
    import os
    import site
    from importlib.util import module_from_spec
    from unittest import TestCase
    from test_parser import is_str, is_dict

    def _test(p: Parser, m: dict) -> None:
        """Test parser."""
        assert is_dict(m)
        assert is_str(m['__doc__'])
        assert is_str(m['__file__'])
        assert '__package__' in m
        assert '__path__' in m
        assert is_dict(m['__builtins__'])
        assert is_dict(m['__spec__'])

# Generated at 2022-06-11 19:30:12.901442
# Unit test for function walk_packages
def test_walk_packages():
    t1 = ["pack1", "pack2", "pack2.__init__", "pack2.test1", "pack2.test2",
          "pack3", "pack3.__init__", "pack3.test3", "pack3.test4"]
    t2 = ["pack1-stubs", "pack2-stubs", "pack2-stubs.__init__",
          "pack2-stubs.test1", "pack2-stubs.test2", "pack3-stubs",
          "pack3-stubs.__init__", "pack3-stubs.test3", "pack3-stubs.test4"]
    assert all(t == n for t, n in zip(t1, walk_packages("test", ".")))

# Generated at 2022-06-11 19:30:20.692219
# Unit test for function walk_packages
def test_walk_packages():
    """Tester for function walk_packages."""
    TEST_DATA = {
        'module.py': 'module.py',
        'module.pyi': 'module.pyi',
        'module.pyc': '',
        'module': ''
    }
    for k, v in TEST_DATA.items():
        assert v == (join(k)
                     .removeprefix(sep)
                     .removeprefix('module.py')
                     .removeprefix(PEP561_SUFFIX)
                     .replace(sep, '.')
                     .removesuffix('.__init__'))
    assert list(walk_packages('module', 'module')) == []
    assert list(walk_packages('module', 'module.py')) == [('module', 'module.py')]

# Generated at 2022-06-11 19:30:28.642192
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from pkgutil import write_file, write_init

    def test_case(name: str, root: str, result: list[str]):
        with TemporaryDirectory() as tmp:
            for n in result:
                if '.' in n:
                    module, package = n.rsplit('.', 1)
                else:
                    module, package = n, '.'
                write_file(package, module + ".py", b"")
                if package != '.':
                    write_init(package)
            assert list(walk_packages(name, tmp)) == list(result)


# Generated at 2022-06-11 19:30:30.875005
# Unit test for function loader
def test_loader():
    """Test function loader."""
    p = Parser.new(True, 1, False)

# Generated at 2022-06-11 19:33:50.161605
# Unit test for function walk_packages
def test_walk_packages():
    # -*- coding: utf-8 -*-
    import sys
    import unittest
    from pyslvs import __version__
    from pyslvs_ui.compiler import walk_packages

    class TestWalkPackages(unittest.TestCase):
        def test_walk_packages(self):
            """Test walk packages function."""
            sys.path.append(dirname(__file__))
            self.assertIn((f'pyslvs_ui.__init__',
                           join(dirname(__file__), '__init__.pyi')),
                          walk_packages(
                              'pyslvs_ui',
                              abspath(__file__) + sep + '..' + sep
                          ))

# Generated at 2022-06-11 19:33:54.211677
# Unit test for function walk_packages
def test_walk_packages():
    from .utils import assert_equal

    from .test_package.pkg1 import sub1
    from .test_package.pkg1.sub1.sub1 import subsub1
    from .test_package.pkg2 import sub2
    from .test_package.pkg2.sub2.sub2 import subsub2
    for name, path in walk_packages('test_package', __file__):
        assert name == '.'.join(s.replace('.', '_')
                                for s in (path + ".py").split(sep))
    assert_equal(sub1, subsub1)
    assert_equal(sub2, subsub2)

# Generated at 2022-06-11 19:34:04.603434
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import mkstemp
    from os import close, remove
    from os.path import basename, splitext
    from random import sample

    # Create two random py files
    names = sample(['a', 'b'], 2)
    paths = []
    for name in names:
        fd, fp = mkstemp(suffix='.py')
        close(fd)
        open(fp, 'w').close()
        paths.append(fp)
    # Create two random pyi files
    names = sample(['a', 'b'], 2)
    paths += [splitext(path)[1] + 'i' for path in paths]
    for name in names:
        fd, fp = mkstemp(suffix='.pyi')
        close(fd)