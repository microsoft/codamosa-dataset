

# Generated at 2022-06-11 19:27:23.973492
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader("solver", "solver", False, 1, False)
    print(doc)

# Generated at 2022-06-11 19:27:33.828853
# Unit test for function loader
def test_loader():
    """Test loader."""
    from tempfile import TemporaryDirectory
    from .serializer import dump_yaml
    from .module import __file__ as package_root

    with TemporaryDirectory() as tmp:
        logger.info(f"Create temporary directory: {tmp}")
        p = Parser.new(True, 1, True)
        # Create test stubs

# Generated at 2022-06-11 19:27:35.926800
# Unit test for function loader
def test_loader():
    """Test the API loader."""
    path = dirname(__file__)
    assert loader("test", path, False, 1, False).strip() == 'test_loader'
    assert loader("test.subtest", path, False, 1, False)



# Generated at 2022-06-11 19:27:43.946981
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from os.path import abspath, join
    from .data import DATA_PATH

    def test(name: str, pwd: str):
        print(f"# {name}")
        for m, p in walk_packages(name, pwd):
            print(f"{m} = {p}")
        print()

    test(
        'numkit',
        abspath(join(DATA_PATH, 'numkit-table-support'))
    )
    test(
        'docutils',
        abspath(join(DATA_PATH, 'docutils-0.15.2'))
    )


# Generated at 2022-06-11 19:27:53.717825
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import join

    temp_dir = mkdtemp()

# Generated at 2022-06-11 19:28:00.848411
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pytest import fixture, raises
    from .parser import Parser
    from .reader import Reader
    from .symbol import UniSymbol
    from .structs import Function, DocString, Arguments, TypeVars

    @fixture
    def mock_p():
        info = {
            'name': 'example',
            'version': '1.2.3',
            'url': 'https://example.com',
            'author': 'Yuan Chang',
            'author_email': 'pyslvs@gmail.com',
            'license': 'MIT'
        }
        return Parser.new(link=False, level=1, toc=False, **info)


# Generated at 2022-06-11 19:28:07.967197
# Unit test for function loader
def test_loader():
    """test_loader."""
    p = Parser.new(True, 1, False)
    p.parse("foo", "")
    p.parse("foo.bar", "")
    assert p.toc == ["- [`foo`](#foo)"]
    assert p.toc == p.toc_row

    p.parse("foo.bar", "")
    assert p.toc == ["- [`foo`](#foo)"]
    assert p.toc_row == ["- [`foo`](#foo)", "  - [`foo.bar`](#foo.bar)"]

    p.parse("foo.bar.baz", "")
    assert p.toc == ["- [`foo`](#foo)"]

# Generated at 2022-06-11 19:28:17.373158
# Unit test for function loader
def test_loader():
    from unittest import TestCase, mock
    from importlib import import_module
    from os import remove
    from os.path import exists, join

    class TestLoader(TestCase):
        """Test cases."""

        def test_loader(self):
            """Test cases."""
            self.assertTrue(exists('test'))

            doc = loader(
                'test',
                f"{dirname(__file__)}{sep}test",
                False,
                1,
                False
            )
            self.assertTrue(doc.strip())

            # Load the module again
            out = join(dirname(__file__), 'test', 'test.py')
            with open(out, 'w+') as f:
                f.write("# Test comment\n")

# Generated at 2022-06-11 19:28:28.018130
# Unit test for function loader
def test_loader():
    """Test case."""
    from .compile_pyslvs import parser

    # Dry run
    docs = gen_api(
        {
            'pyslvs': 'pyslvs',
            'pyslvs-ui': 'pyslvs_ui',
        },
        dry=True
    )
    assert len(docs) == 2
    assert docs[0].startswith('## pyslvs API\n\n')
    assert docs[1].startswith('## pyslvs-ui API\n\n')

    # Real run
    docs = gen_api(
        {
            'pyslvs': 'pyslvs',
            'pyslvs-ui': 'pyslvs_ui',
        },
        prefix='test',
        dry=False
    )


# Generated at 2022-06-11 19:28:35.430099
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import join
    from unittest.mock import patch, MagicMock
    with TemporaryDirectory() as tempdir:
        t = join(tempdir, 'test')
        copytree(join(dirname(__file__), 'test'), t)
        with patch('importlib.util.find_spec', return_value=MagicMock(submodule_search_locations=[t])):
            assert walk_packages('test', t) == [
                ('test.b', join(t, 'b.py')),
                ('test.b.a', join(t, 'b', 'a.py')),
                ('test.b', join(t, 'b.pyi')),
            ]

# Generated at 2022-06-11 19:31:43.928852
# Unit test for function loader
def test_loader():
    """Test loader()."""
    from pytest import raises
    with raises(RuntimeError) as excinfo:
        loader('__not_existed__', '.', False, 1, False)
    assert 'Failed loading module' in str(excinfo.value)

# Generated at 2022-06-11 19:31:51.854541
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    from importlib import reload as reload_import
    global Parser
    from .parser import Parser

    from tempfile import TemporaryDirectory
    from . import pyslvs_ui
    from .pyslvs_ui import __doc__ as ui_doc
    from . import pyslvs_cli
    from .pyslvs_cli import __doc__ as cli_doc
    from . import pyslvs_vpp
    from .pyslvs_vpp import __doc__ as vpp_doc
    from . import pyslvs_io
    from .pyslvs_io import __doc__ as io_doc
    from . import pyslvs_frame
    from .pyslvs_frame import __doc__ as frame_doc


# Generated at 2022-06-11 19:32:02.182145
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch
    from pathlib import Path


# Generated at 2022-06-11 19:32:10.950009
# Unit test for function loader
def test_loader():
    """Test all modules in builtin."""
    from importlib import reload
    import os
    import locale
    import sys
    import types
    import builtins
    reload(os)
    reload(locale)
    reload(sys)
    reload(types)
    reload(builtins)
    root = 'builtin'
    pwd = ''
    # Test for PEP561
    logger.info('Test for PEP561:')
    f_path = _site_path(root) + '/'
    for m_name, _ in walk_packages(root, f_path):
        logger.debug(f"{root} <= {m_name}")
        __import__(m_name)
    logger.info('=' * 12)
    # Test for loader
    logger.info('Test for loader:')

# Generated at 2022-06-11 19:32:15.350369
# Unit test for function loader
def test_loader():
    import tempfile

    tmpd = tempfile.TemporaryDirectory()
    tmp = tmpd.name
    print(tmp)

    import os
    import shutil
    from .parser import create_package

    # Create the package

# Generated at 2022-06-11 19:32:25.532488
# Unit test for function loader
def test_loader():
    from unittest.mock import patch
    from .test import *
    from os import remove
    root = "root"
    dir_ = "dir"
    path = f"{root}.{dir_}"
    root_py = root + ".py"
    p = patch('pkgutil.walk_packages', lambda *_: [(root, "", False)])
    with p, patch('sys.path', [PWD]):
        doc = loader(root, PWD, False)
        assert isfile(root_py)
        assert root_py in doc
        doc = loader(root, PWD, False)
        assert root_py in doc
        remove(root_py)
        assert not isfile(root_py)
        doc = loader(root, PWD, False)
        assert root_py in doc
    p1

# Generated at 2022-06-11 19:32:33.154986
# Unit test for function loader
def test_loader():
    """API document generator for the test project."""
    logger.info("Starting API document generator ...")
    pwd = dirname(__file__) + f"{sep}test_project"
    root_names = {'Test API': 'test_api'}
    gen_api(root_names, pwd)
    logger.info("Finished!")


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:32:39.924229
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk_packages."""
    # Normal case
    for name, f_path in walk_packages("tensorflow", "C:/Program Files/Python38/Lib/site-packages"):
        logger.info(f"{name} <= {f_path}")

    # Error case
    for name, f_path in walk_packages("t3nsorfl0w", "C:/Program Files/Python38/Lib/site-packages"):
        logger.info(f"{name} <= {f_path}")

    # Empty case
    for name, f_path in walk_packages("tensorflow", "C:/Program Files/Python38"):
        logger.info(f"{name} <= {f_path}")

# Generated at 2022-06-11 19:32:43.061108
# Unit test for function loader
def test_loader():
    """Test case for a single file package."""
    pwd = join(dirname(__file__), '..', 'tests', 'package_loader')
    doc = loader('test', pwd, False, 1, False)
    print(doc)

# Generated at 2022-06-11 19:32:46.499681
# Unit test for function loader
def test_loader():
    loader(
        'svs',
        r'C:\Users\YC.SLVS-PC\AppData\Roaming\Python\Python38\site-packages',
        False,
        1,
        False
    )

if __name__ == "__main__":
    test_loader()