

# Generated at 2022-06-11 19:27:04.388404
# Unit test for function walk_packages
def test_walk_packages():
    from sys import path as sys_path
    from os import makedirs
    from os.path import isfile, dirname
    from shutil import rmtree
    from .logger import logger

    # Initiate the pure Python package
    # Directories
    # - /pyslvs
    #   - __init__.py
    #   - api_test/
    #     - __init__.py
    #     - pure.py
    #     - not_pure.py
    # - /pyslvs-stubs
    #   - __init__.py
    #   - api_test/
    #     - __init__.py
    #     - pure.pyi
    #     - not_pure.pyi
    # - /site-packages
    #   - __init__.py
    #  

# Generated at 2022-06-11 19:27:12.081492
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import isfile
    from pprint import pprint
    from shutil import rmtree
    from distutils.sysconfig import get_python_lib
    tmp = "tmp"
    pwd = get_python_lib()
    root_names = {
        "numpy": "numpy",
        "scipy": "scipy",
        "pandas": "pandas",
    }
    if isdir(tmp):
        rmtree(tmp)
    if isfile("numpy-api.md"):
        remove("numpy-api.md")
    if isfile("scipy-api.md"):
        remove("scipy-api.md")

# Generated at 2022-06-11 19:27:21.423559
# Unit test for function walk_packages
def test_walk_packages():
    def assert_len(name: str, path: str, expect: int) -> None:
        it = list(walk_packages(name, path))
        assert len(it) == expect

    def assert_name(name: str, path: str, expect: bool) -> None:
        """Assert that a package is found"""
        it = list(walk_packages(name, path))
        assert any(e[0] == name for e in it) == expect

    def assert_parent(name: str, path: str, expect: bool) -> None:
        """Assert that the parent package is found"""
        it = list(walk_packages(name, path))
        assert any(parent(e[0]) == name for e in it) == expect


# Generated at 2022-06-11 19:27:32.546641
# Unit test for function loader
def test_loader():
    import sys
    import random
    from io import StringIO
    from os.path import isdir, dirname, join
    from importlib.machinery import EXTENSION_SUFFIXES
    from importlib.util import find_spec
    from pkgutil import iter_modules
    sys.path.append(dirname(__file__))

    def _get_ext_suffix() -> str:
        return random.choice(EXTENSION_SUFFIXES)

    logger.debug(f"Begin to test {__file__}")
    f_path = dirname(__file__)
    # Create a random package name
    pkgname = ''.join(random.choice(__name__) for _ in range(3))
    pkg = join(f_path, 'test', pkgname)
    # Create package directory

# Generated at 2022-06-11 19:27:42.442569
# Unit test for function walk_packages
def test_walk_packages():
    from .test_data import directory
    for name, path in walk_packages("test", directory):
        assert isfile(path)
        assert name == 'test.__init__' or name.startswith('test.')
    # Check PEP 561
    for name, path in walk_packages("test_data", directory):
        pass
    for name, path in walk_packages("test_data/test_data", directory):
        assert isfile(path)
        assert name.startswith('test_data.test_data.')
    logger.info("Test walk_packages: passed")


# Generated at 2022-06-11 19:27:45.623984
# Unit test for function walk_packages
def test_walk_packages():
    print(list(walk_packages('pyslvs', '../pyslvs')))

# Generated at 2022-06-11 19:27:54.647773
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from sys import path as sys_path
    from os import path as os_path
    from time import time
    from os.path import dirname
    from .logger import TEST_LOGGER
    logger.setLevel(TEST_LOGGER)
    start = time()
    module = 'pyslvs'
    sys_path.append(os_path.join(os_path.dirname(__file__), '..'))
    pwd = os_path.join(dirname(__file__), '..', '..', '..', '..')
    doc = loader(module, pwd, False, 1, False)
    logger.info(f"Time cost: {round(time() - start, 5)} sec")
    # Have 518 lines in module pyslvs
    logger

# Generated at 2022-06-11 19:28:03.693627
# Unit test for function loader
def test_loader():
    # Run in project root
    from os import chdir
    chdir(dirname(dirname(__file__)))
    # No root name
    assert not gen_api({})
    # Should not crash even the root name is not exist
    assert gen_api({"pyslvs": "pyslvs"})
    assert gen_api({"pyslvs": "pyslvs"}, dry=True)
    # Test the `dry` option
    assert gen_api({"pyslvs": "pyslvs"}, dry=True)
    # Test the `pwd` option
    assert gen_api({"pyslvs": "pyslvs"}, ".", dry=True)
    # Test special module

# Generated at 2022-06-11 19:28:14.966885
# Unit test for function walk_packages
def test_walk_packages():
    """Test function `walk_packages`."""
    from string import ascii_letters
    from tempfile import TemporaryDirectory
    from os import remove
    from shutil import rmtree
    from .utils import random_alnum

    def test_seq(name: str, path: str) -> Iterator[tuple[str, str]]:
        """Make a package sequence."""
        yield ".".join((name, random_alnum(5))), join(path, random_alnum(5))
        for _ in range(3):
            stub = join(path, random_alnum(5))
            mkdir(stub)
            yield test_seq(name + f".{random_alnum(5)}", stub)


# Generated at 2022-06-11 19:28:17.761784
# Unit test for function loader
def test_loader():
    """Test loader function."""
    assert loader('pyslvs_ui', dirname(__file__), False, 1, False)
    assert loader('pyslvs', abspath(dirname(dirname(dirname(__file__)))), False, 1, False)

# Generated at 2022-06-11 19:30:03.826209
# Unit test for function loader
def test_loader():
    from unittest import TestCase, mock
    from os import listdir
    from os.path import getsize

    class Test(TestCase):

        @classmethod
        def setUpClass(cls) -> None:

            def fake_walk(path: str) -> Iterator[tuple[str, str]]:
                if path == 'test_loader':
                    return [("os.path", "test_loader/os.path")]
                raise NotImplementedError()

            def fake_read(path: str) -> str:
                return f"## {path}"

            cls.mock_walk = mock.patch("pyslvs_ui.api.compiler.walk_packages", new=fake_walk)

# Generated at 2022-06-11 19:30:15.234838
# Unit test for function loader
def test_loader():
    from pytest import raises
    from tempfile import TemporaryDirectory
    from .parser import Parser

    def _gen_dummy() -> str:
        s = 'a.b.d'
        return (
            f"class {s}.C:\n"
            f"    @staticmethod\n"
            f"    def f(): ...\n\n"
            f"@{s}.C.f.register\n"
            f"def f_test() -> None: ...\n"
        )

    def _check(name: str, path: str, p: Parser) -> None:
        contents = _read(path)
        assert contents == _gen_dummy()
        p.parse(name, contents)

# Generated at 2022-06-11 19:30:21.354257
# Unit test for function loader
def test_loader():
    """Unit test."""
    from doctest import testmod
    testmod()


if __name__ == '__main__':
    import sys
    if not __package__:
        sys.path.append(dirname(__file__))
    sys.exit(test_loader())

# Generated at 2022-06-11 19:30:29.302171
# Unit test for function walk_packages
def test_walk_packages():
    from os import mkdir, rmdir
    from os.path import exists

    test_dir = 'test_dir'
    assert (not exists(test_dir))

    # Create
    mkdir(test_dir)
    with open(test_dir + '/__init__.py', mode='w') as f:
        f.write('from pathlib import Path\n\n')
    with open(test_dir + '/a.py', mode='w') as f:
        f.write('from pathlib import Path\n\n')
    with open(test_dir + '/b.py', mode='w') as f:
        f.write('from pathlib import Path\n\n')

# Generated at 2022-06-11 19:30:36.791286
# Unit test for function loader
def test_loader():
    p = Parser.new(False, 0, False)
    print(list(walk_packages('numpy', '/usr/local/lib/python3.6/dist-packages')))
    # for name, path in walk_packages('numpy', '/usr/local/lib/python3.6/dist-packages'):
    #     # Load module here
    #     for _, ext, is_pkg in pkgutil.iter_modules([path]):
    #         if is_pkg:
    #             continue
    #         full_path = join(path, f"{ext}{ext}")
    #         if not isfile(full_path):
    #             continue
    #         print(name, full_path)
    #         p.parse(name, "")
    #         _load_module(name, full_path,

# Generated at 2022-06-11 19:30:47.480165
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages"""
    def _test(root: str, path: str, name: str, path_: str) -> None:
        """General testing function."""
        n, p = tuple(walk_packages(root, path))[0]
        assert n == name
        assert p == path_

    # Normal module
    _test('tst_module', './test_data/modules', 'tst_module.__init__',
          'test_data/modules/tst_module/__init__.pyi')
    # Normal package
    _test('tst_package', './test_data/packages', 'tst_package.__init__',
          'test_data/packages/tst_package/__init__.pyi')

# Generated at 2022-06-11 19:30:48.976105
# Unit test for function loader
def test_loader():
    assert loader('collections', '.', False, 1, False)



# Generated at 2022-06-11 19:30:53.830153
# Unit test for function walk_packages
def test_walk_packages():
    """Test function."""
    root = 'foo'
    path = join('bar', 'baz')
    a, b = 'a.py', 'a.pyi'
    assert list(walk_packages(root, path)) == [
        (f'{root}.{parent(a)}', join(path, parent(a))),
        (f'{root}.{parent(b)}', join(path, parent(b)))
    ]

# Generated at 2022-06-11 19:31:05.472864
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from shlex import quote
    from pathlib import Path
    from subprocess import run

    def _assert_api(doc: str, name: str) -> None:
        assert name in doc
        if _read(f'{name}-api.md') != doc:
            raise RuntimeError("Output API document is different.")

    with TemporaryDirectory() as temp:
        temp = Path(temp)
        packages = temp / 'packages'
        run(f'mkdir -p {quote(packages)}', shell=True, check=True)
        run(f'cp -r {quote(dirname(__file__))}/temp/packages/* {quote(packages)}', shell=True, check=True)

# Generated at 2022-06-11 19:31:07.605495
# Unit test for function loader
def test_loader():
    logger.info("Test")
    assert loader("pyslvs", "pyslvs", False, 2, False)
    assert loader("pyslvs", "pyslvs", False, 2, True)