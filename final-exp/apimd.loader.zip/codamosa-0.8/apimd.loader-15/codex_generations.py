

# Generated at 2022-06-11 19:26:00.047411
# Unit test for function loader
def test_loader():
    """Test function loader."""
    # Parser is a class
    import pyslvs
    doc = loader(pyslvs.__name__, dirname(pyslvs.__file__), False, 1, False)
    assert len(doc) > 0

# Generated at 2022-06-11 19:26:02.165912
# Unit test for function loader
def test_loader():
    from pytest import raises
    with raises(KeyError):
        gen_api(dict(Pyslvs='pyslvs'))

# Generated at 2022-06-11 19:26:06.054740
# Unit test for function loader
def test_loader():
    """"""
    Parser.new(True, 1, False)
    for n, p in walk_packages('numpy', 'site-packages'):
        if n == 'numpy.polynomial':
            break
    else:
        raise ModuleNotFoundError("numpy not found")
    assert _load_module('numpy.polynomial.chebyshev', p + '.cp37-win_amd64.pyd', Parser.new(True, 1, False))
    assert _load_module('numpy.polynomial.chebyshev_test', p + '.py', Parser.new(True, 1, False))

# Generated at 2022-06-11 19:26:16.077450
# Unit test for function walk_packages
def test_walk_packages():
    from timeit import timeit
    import sys
    import os
    import shutil
    count = 0
    try:
        os.mkdir('pkg')
        sys.path.append('pkg')
        for x in range(100):
            os.mkdir(f'pkg/__pycache__{x}')
        os.mkdir('pkg/pyslvs')
        for x in range(1000):
            count += 1
            os.mkdir(f"pkg/pyslvs/abc{x}")
            with open(f"pkg/pyslvs/abc{x}/__init__.py", 'w'):
                pass
    except FileExistsError:
        pass
    for item in walk_packages('pyslvs', 'pkg'):
        pass

# Generated at 2022-06-11 19:26:22.084474
# Unit test for function loader
def test_loader():
    """Test."""
    import unittest
    from .build import root_names
    from .templates import simple_page, base_page

    class LoaderTest(unittest.TestCase):
        """Test for loader."""

        def test_loader(self):
            """Test for function loader."""
            for root in root_names:
                doc = loader(root, dirname(__file__), True, 2, True)
                self.assertGreater(len(doc), 0)
                self.assertLess(len(doc), 1000)

    class TemplateTest(unittest.TestCase):
        """Test for templates."""

        def test_simple_page(self):
            """Test for function simple_page."""
            self.assertGreater(len(simple_page('test', '# Test\n')), 5)

# Generated at 2022-06-11 19:26:28.446233
# Unit test for function loader
def test_loader():
    """Testing."""
    from pkgutil import iter_modules
    from pkg_resources import iter_entry_points
    from importlib import import_module
    for _, name, _ in iter_modules(iter_entry_points('pyslvs_ui.plugins')):
        m = import_module(name)
        if hasattr(m, '__doc__'):
            doc = m.__doc__
        else:
            doc = ""
        if hasattr(m, '__all__'):
            doc += '\n'.join(f'* :py:obj:`{k}`' for k in m.__all__)
        doc = loader(name, dirname(m.__path__[0]), False, 1, False)
        assert doc == doc.strip()



# Generated at 2022-06-11 19:26:37.776763
# Unit test for function loader
def test_loader():
    assert loader('pyslvs', '.', True, 1, False)
    assert loader('pyslvs', '.', True, 2, False)
    assert loader('pyslvs', '.', True, 1, True)
    assert loader('pyslvs_ui', '.', True, 1, False)
    assert loader('pyslvs_ui', '.', True, 1, True)
    assert loader('pyslvs_ui.widgets', '.', True, 1, False)
    assert loader('pyslvs_ui.widgets', '.', True, 1, True)

# Generated at 2022-06-11 19:26:46.882115
# Unit test for function loader
def test_loader():
    """Parse root."""
    from pkgutil import walk_packages
    p = Parser.new(link=False, level=2)
    for _, name, _ in walk_packages(
            [a for a in sys_path if a.endswith('site-packages')][0]):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path = find_spec(name).origin + ext
            if not isfile(path):
                continue
            logger.debug(f"{name} <= {path}")
            p.parse(name, _read(path))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        # Try to load module here

# Generated at 2022-06-11 19:26:57.632381
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os
    import pytest

    # Create folder tree
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp:
        folder = os.path.join(tmp, "test")
        os.makedirs(folder)

# Generated at 2022-06-11 19:27:08.400591
# Unit test for function loader
def test_loader():
    """Test for functions: `loader`."""
    from .context import unittest, installed_packages

    class TestLoader(unittest.TestCase):
        """Test for functions: `loader`."""

        def test_loader(self):
            """Test for functions: `loader`."""
            logger.debug("Test for function loader")
            names = {
                "Trajectory API": "pyslvs_ui.trajectory",
                "V-Rep API": "pyslvs_ui.vrep",
                "Pyslvs API": "pyslvs",
                "Pyslvs Algo API": "pyslvs_algo",
                "Pyslvs UI API": "pyslvs_ui",
            }

# Generated at 2022-06-11 19:28:37.458620
# Unit test for function walk_packages
def test_walk_packages():
    # Test walk
    from .generate import walk_packages
    from .utils import get_pyslvs_api
    from os.path import abspath, dirname
    pwd = dirname(abspath(__file__)) + '/../..'
    prefix = pwd + '/tests/stdlib/'
    for name, path in walk_packages('math', prefix):
        logger.debug(f'name: {name}')
        logger.debug(f'path: {path}')

    # Test write
    from os import makedirs, remove
    gen_api({'math': 'math'}, pwd, prefix='tests/stdlib', dry=True)
    # Clean temp file
    remove(prefix + '/math-api.md')
    remove(prefix + '/math-stubs-api.md')
    # Recre

# Generated at 2022-06-11 19:28:42.722351
# Unit test for function walk_packages
def test_walk_packages():
    from .test_helper import test_folder
    pkg = 'test'
    root_path = test_folder
    list(walk_packages(pkg, root_path)) == [
        'test.test_child',
        'test.test_parent',
    ]

# Generated at 2022-06-11 19:28:51.495154
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from .logger import logger
    from sys import platform
    from os.path import splitext
    from .parser import Parser
    from .compiler import walk_packages, walk_packages
    import numpy as np
    import slvs
    import pyperclip
    import qtmodern
    logger.error("The version of Numpy is %s" % np.__version__)
    logger.error("The version of SLVS is %s" % slvs.__version__)
    logger.error("The version of Pyperclip is %s" % pyperclip.__version__)
    logger.error("The version of QtModern is %s" % qtmodern.__version__)
    logger.error("The platform is %s" % platform)

# Generated at 2022-06-11 19:29:01.578863
# Unit test for function loader
def test_loader():
    from pkgutil import get_loader
    from .parser import Parser
    from sys import path as sys_path
    from .logger import logger
    from .debug import markdown_lint
    from os import walk

    logger.debug(sys_path)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', '/home/yc/Pyslvs/test/test_api'):
        logger.debug(f"{name} <= {path}")
        if 'ml' in name:
            p.parse(name, _read(path + '.py'))
    assert "import" in p.compile()
    assert "e3_api" in p.compile()
    res = markdown_lint(p.compile())
    assert res

# Generated at 2022-06-11 19:29:07.557670
# Unit test for function walk_packages
def test_walk_packages():
    def run_test(name: str, path: str) -> None:
        l = list(walk_packages(name, path))
        print(l)
        assert l[0] == (parent(name), parent(path + '.py'))

    run_test('solve_ik.__init__', 'solve_ik')
    run_test('solve_ik', 'solve_ik')
    run_test('abc', 'abc')
    run_test('abc.__init__', 'abc')


if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-11 19:29:10.450032
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 19:29:18.960103
# Unit test for function walk_packages
def test_walk_packages():
    pwd = 'test'
    root = '__main__'
    name = 'test'
    name_stub = name + PEP561_SUFFIX
    mods = {'test', 'test.__init__'}
    mods_stub = map(lambda i: i + PEP561_SUFFIX, mods)
    sub_mods = {'test.a', 'test.a.__init__'}
    sub_mods_stub = map(lambda i: i + PEP561_SUFFIX, sub_mods)
    result = set()
    for i, j in walk_packages(root, pwd):
        result.add(i)
    assert result == mods | sub_mods | mods_stub | sub_mods_stub

# Generated at 2022-06-11 19:29:28.453474
# Unit test for function loader
def test_loader():
    assert loader(
        "pyslvs",
        "..",
        link=False,
        level=2,
        toc=True
    ).startswith(
        "\n" + "#" * 2 + " PySVLS API"
    )


if __name__ == "__main__":
    from .__main__ import args
    gen_api(
        {
            "SVLS": "pyslvs",
            "SVLS UI": "pyslvs_ui"
        },
        pwd="..",
        prefix=args.prefix,
        link=args.link,
        level=args.level,
        toc=args.toc,
        dry=args.dry
    )

# Generated at 2022-06-11 19:29:30.460181
# Unit test for function loader
def test_loader():
    # Test cases: Test/test_doc/test_loader.py
    pass

# Generated at 2022-06-11 19:29:37.309494
# Unit test for function loader
def test_loader():
    from pprint import pprint
    pwd = dirname(__file__)
    prefix = "test_docs"
    if not isdir(prefix):
        mkdir(prefix)
    pprint(list(walk_packages("paintlib", pwd)))
    logger.info("")
    doc = loader("paintlib", pwd, True, 3, True)
    pprint(doc)


if __name__ == '__main__':
    test_loader()