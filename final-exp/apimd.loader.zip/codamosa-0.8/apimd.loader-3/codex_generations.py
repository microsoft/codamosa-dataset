

# Generated at 2022-06-11 19:32:28.835690
# Unit test for function loader
def test_loader():
    from os import getcwd

    assert loader("tkinter", "src/tkinter", False, 2, False) == \
        """[tk](https://docs.python.org/3/library/tkinter.html)

## tkinter.Tcl()

## tkinter.TclError

## tkinter.TclVersion

## tkinter.TkVersion

## tkinter.Tk()

## tkinter.Toplevel()

## tkinter.__version__

## tkinter.code_asterisk()"""

# Generated at 2022-06-11 19:32:38.797089
# Unit test for function loader
def test_loader():
    """Unit test."""
    import sys
    import tempfile
    import importlib
    import pkgutil
    from .parser import Parser
    from .logger import debug_log

    def _gen_stub(root: str, name: str, text: str = '') -> None:
        assert isdir(root)
        assert name.count('.') > 0
        path = parent(root + '/' + name)
        if not isdir(path):
            import os
            os.makedirs(path)
        path += '.pyi'
        debug_log(f"Write stub: {path}")
        with open(path, 'w') as f:
            f.write(text)

    def _gen_py(root: str, name: str, text: str = '') -> None:
        assert isdir

# Generated at 2022-06-11 19:32:46.136762
# Unit test for function loader
def test_loader():
    """Test for loader."""
    import pkgutil
    import pyslvs_ui.__about__ as root_package
    # The test is pass on Windows
    path = abspath('.')
    root_name = root_package.__name__
    sys_path.append(dirname(path))
    next(pkgutil.iter_modules(path))
    docs = gen_api({root_package.__title__: root_name, }, pwd=path)
    assert len(docs) == 1
    assert docs[0].startswith('# ')

# Generated at 2022-06-11 19:32:57.140244
# Unit test for function loader
def test_loader():
    root = 'test_loader'
    import test_loader as tl

# Generated at 2022-06-11 19:33:02.004949
# Unit test for function loader
def test_loader():
    import pyslvs
    assert len(gen_api({"PySLVS": "pyslvs"})) > 0
    assert len(gen_api({"PySLVS": "pyslvs"}, dry=True)) == 0
    assert len(gen_api({"PySLVS test": "pyslvs_test"}, pyslvs.__path__[0])) > 0

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:33:06.811137
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    from .test_parser import pwd
    from .test_parser import ParserTest
    from .test_parser import root
    from .test_parser import s

    p = Parser(True, 1, False)
    p.parse(*root, s)
    assert loader(*root, pwd, True, 1, False) == p.compile()

# Generated at 2022-06-11 19:33:11.664475
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    import random
    import string
    for _ in range(100):
        path = ''.join(random.choices(string.ascii_uppercase, k=random.randint(1, 16)))
        root = ''.join(random.choices(string.ascii_uppercase, k=random.randint(1, 16)))
        p = Parser.new(True, 1, False)
        for name, path in walk_packages(root, path):
            p.parse(name, f"test test test")
        assert len(p.docs) > 0

# Generated at 2022-06-11 19:33:22.358112
# Unit test for function loader
def test_loader():
    """Should be equal after executing."""
    import sys; sys.path.append('.')
    rv = loader('pyslvs', '.', False, 1, False)

# Generated at 2022-06-11 19:33:27.563791
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs", join(dirname(__file__), "..")):
        logger.info(name)
        logger.info(path)
    logger.info(find_spec('pyslvs.algorithm'))
    logger.info(find_spec('pyslvs_ui'))

# Generated at 2022-06-11 19:33:38.414993
# Unit test for function loader
def test_loader():
    from tests.unittest_tools import do_test
    logger.info('=' * 12)
    logger.info('Testing function loader()')
    logger.info('=' * 12)
    do_test(
        loader,
        'tests.test_packages',
        'tests',
        False,
        1,
        True,
    )
    do_test(
        loader,
        'tests.test_packages',
        'tests',
        False,
        1,
        False,
    )
    do_test(
        loader,
        'tests.test_packages',
        'tests',
        True,
        2,
        True,
    )