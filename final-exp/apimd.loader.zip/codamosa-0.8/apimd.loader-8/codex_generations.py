

# Generated at 2022-06-11 19:26:42.248989
# Unit test for function loader
def test_loader():
    """Test loader function."""
    p = Parser.new(False, 0, True)
    for name, path in walk_packages("a", "./test_data/test_loader"):
        logger.debug(f"{name} <= {path}")
        p.parse(name, _read(path + ".py"))

# Generated at 2022-06-11 19:26:45.410411
# Unit test for function loader
def test_loader():
    """Gen API for sympy."""
    try:
        import sympy
    except ImportError:
        logger.warning("Please install sympy first.")
        return
    gen_api({"SYMPY": "sympy"})

# Generated at 2022-06-11 19:26:48.755306
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    _load_module('pyslvs_ui.compiler', './pyslvs_ui/compiler.cpython-38.so', p)
    # p.parse('pyslvs_ui.compiler', _read('./pyslvs_ui/compiler.py'))
    assert p.compile()

# Generated at 2022-06-11 19:26:59.161313
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages test case."""
    pkg = next(walk_packages('test', ''))
    assert pkg[0] == 'test'
    assert pkg[1] == 'test.py'

    pkg = next(walk_packages('test', 'test'))
    assert pkg[0] == 'test.mod'
    assert pkg[1] == 'test/mod.py'

    pkg = next(walk_packages('test', 'test/mod'))
    assert pkg[0] == 'test.mod.m'
    assert pkg[1] == 'test/mod/m.py'

    pkg = next(walk_packages('test', 'test/mod/m'))
    assert pkg[0] == 'test.mod.m.s'

# Generated at 2022-06-11 19:27:09.363210
# Unit test for function loader
def test_loader():
    cl = "hello", "hello"
    p = {"left": cl, "right": cl}
    doc = loader("pkg", "tests/pkg", True, 1, False)
    assert doc.strip()
    assert "pkg" in doc
    assert "cl1" in doc
    assert "cl2" in doc
    assert "__init__" in doc
    assert p["left"] not in doc
    assert "hello" in doc
    assert ">>>" not in doc
    assert " +" not in doc
    assert ".." not in doc
    assert "function_2" in doc
    assert "function_1" not in doc
    assert "function_3" in doc
    assert "function_4" not in doc
    assert "function_5" not in doc
    assert "function_6" in doc

# Generated at 2022-06-11 19:27:13.120146
# Unit test for function loader
def test_loader():
    """Test loader."""
    import pkgutil
    pkgutil.walk_packages(path='tests')[0]
    loader('pyslvs', '.')

# Generated at 2022-06-11 19:27:19.823060
# Unit test for function loader
def test_loader():
    """Test function loader."""
    # Test document generation
    name = "pyslvs_ui"
    root = "pyslvs_ui"
    doc = loader(root, _site_path(name), True, 1, False)
    assert doc.strip()
    # Test document generation from the root path
    name = "pyslvs_ui"
    root = "pyslvs"
    doc = loader(root, _site_path(name), True, 1, False)
    assert doc.strip()

# Generated at 2022-06-11 19:27:31.101118
# Unit test for function walk_packages
def test_walk_packages():
    from os import mkdir, rmdir
    from os.path import isdir

    def valid_package_name(name: str) -> bool:
        for c in name:
            if c.isalpha() or c.isdigit() or c == '_' or c == '.':
                continue
            return False
        if name.endswith('.'):
            return False
        return True

    t = "pyslvs-core"
    tp = f"{t}.tests"
    tc = f"{tp}.ops"
    tg = f"{tp}.geometry"
    name = f"{tp}.__init__"
    content = [name, "__init__", "core", "geometry", "ops"]


# Generated at 2022-06-11 19:27:35.260136
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from os.path import dirname, exists
    from pkgutil import walk_packages
    from importlib import import_module
    # Test for walk_packages
    pkg = import_module("Pyslvs")
    path = dirname(pkg.__file__) + "/"
    assert exists(path + "__init__.pyi")
    assert exists(path + "__init__.pyi-stubs")
    assert exists(path + "__init__-stubs.pyi")
    assert exists(path + "__init__-stubs.py")
    pkg_path = path + "__init__.py"
    stub_path = path + "__init__.pyi"

# Generated at 2022-06-11 19:27:37.397094
# Unit test for function loader
def test_loader():
    f = open('test__loader.log', 'w')
    import logging
    logger.addHandler(logging.StreamHandler(f))
    logger.setLevel(logging.DEBUG)
    assert loader('example', '.', False, 2, False)
    logger.removeHandler(f)
    f.close()

# Generated at 2022-06-11 19:30:05.248375
# Unit test for function loader
def test_loader():
    """Test loader function."""
    import numpy as np
    with open('tests/test.txt', 'w+') as f:
        f.write(loader('numpy', np.__path__[0], False, 1, False))

# Generated at 2022-06-11 19:30:16.034720
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import shutil
    pwd = None

# Generated at 2022-06-11 19:30:22.336711
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    root = "pyslvs"
    pwd = join(dirname(__file__), '..')
    logger.info(f"Load root: {root}")
    logger.info(f"Current path: {pwd}")
    doc = loader(root, pwd, False, 1, False)
    print(doc)

# Generated at 2022-06-11 19:30:29.926861
# Unit test for function loader
def test_loader():
    def _parse(doc: str) -> Parser:
        p = Parser.new()
        p.parse("test", doc)
        return p
    assert len(_parse("").compile()) == 0
    assert len(_parse("#").compile()) == 0
    assert len(_parse("# x").compile()) == 0
    assert len(_parse("## x").compile()) == 0
    assert (
        _parse("### x\n\n```python\nprint('hello')\n```\n\n```python\nx = 1\n```").compile()
        == "```python\nprint('hello')\n```\n\n```python\nx = 1\n```\n"
    )

# Generated at 2022-06-11 19:30:31.988746
# Unit test for function loader
def test_loader():
    assert loader('solver', 'solver', True, 1, True).strip()

# Generated at 2022-06-11 19:30:43.548966
# Unit test for function loader
def test_loader():
    """Test the loader."""
    assert loader(__name__, dirname(__file__), True, 1, False)
    assert loader(__name__, dirname(__file__), True, 2, False)
    output = loader(__name__, dirname(__file__), True, 1, True)
    assert '- [set_logger](#set_logger)' in output
    assert '- [PEP561_SUFFIX](#PEP561_SUFFIX)' in output
    assert '- [_read](#_read)' in output
    assert '- [_write](#_write)' in output
    assert '- [_site_path](#_site_path)' in output
    assert '- [walk_packages](#walk_packages)' in output

# Generated at 2022-06-11 19:30:46.925583
# Unit test for function loader
def test_loader():
    from .utils import test_root
    p = Parser.new(False, 1, False)
    for name, path in walk_packages(test_root, '.'):
        p.parse(name, _read(path + ".py"))
    assert p.compile().strip()

# Generated at 2022-06-11 19:30:58.571541
# Unit test for function loader
def test_loader():
    import os
    import sys
    import sysconfig
    import importlib

    def test_dist_info(root: str, name: str, pkg_name: str):
        # Test dist-info file
        path = abspath(root) + sep + name + sep + pkg_name + '-' + sysconfig.get_config_var('VERSION') + '.dist-info'
        path += EXTENSION_SUFFIXES[0]
        assert isdir(path)
        for name, path in walk_packages(root, path):
            assert not (name.endswith(PEP561_SUFFIX) or name.endswith('.__init__'))
            assert isfile(path + '.py') or isfile(path + '.pyi')

# Generated at 2022-06-11 19:31:07.920476
# Unit test for function loader
def test_loader():
    import sys
    import logging
    logger.setLevel(logging.DEBUG)
    sys_path.append('tests/walk_packages')

# Generated at 2022-06-11 19:31:17.706660
# Unit test for function walk_packages
def test_walk_packages():
    assert walk_packages("pyslvs", "pyslvs/tests/json") == [
        ('pyslvs.tests.json.constraints', 'pyslvs/tests/json/constraints.py', 'pyslvs/tests/json/constraints.pyi'),
        ('pyslvs.tests.json.links', 'pyslvs/tests/json/links.py'),
        ('pyslvs.tests.json.metas', 'pyslvs/tests/json/metas.py'),
        ('pyslvs.tests.json.entities', 'pyslvs/tests/json/entities.py'),
        ('pyslvs.tests.json.vpoints', 'pyslvs/tests/json/vpoints.py'),
    ]