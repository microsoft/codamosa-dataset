

# Generated at 2022-06-11 19:27:03.895901
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import isdir as is_dir, isfile as is_file, dirname
    from os import mkdir, walk, remove
    from tempfile import gettempdir
    from shutil import rmtree

    def is_root(path: str) -> bool:
        for root, dirs, _ in walk(path):
            return root in dirs
        return False

    def is_package(path: str) -> bool:
        return is_root(path) or is_file(path + sep + '__init__.py') or \
            is_file(path + sep + '__init__.pyi')

    def has_stub(path: str) -> bool:
        return is_file(path + PEP561_SUFFIX + sep + '__init__.pyi')

    path = gettempdir()

# Generated at 2022-06-11 19:27:08.174206
# Unit test for function walk_packages
def test_walk_packages():
    assert "sklearn" not in list(walk_packages("sklearn", _site_path("sklearn")))
    assert "sklearn.__init__" in list(walk_packages("sklearn", _site_path("sklearn")))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 19:27:14.055901
# Unit test for function walk_packages
def test_walk_packages():
    from os import mkdir
    from os.path import exists, isdir
    from shutil import rmtree
    from tempfile import mkdtemp
    from .path_parse import path_parse
    from .logger import enable_debug

    enable_debug()
    temp = mkdtemp()
    for f, path in path_parse(temp):
        logger.debug(f"create file: {path}")
        with open(path, 'w') as f:
            f.write(path)
    logger.debug(f"create directory: {temp}/deep")
    mkdir(f"{temp}/deep")
    logger.debug(f"create file: {temp}/deep/deep_file.py")

# Generated at 2022-06-11 19:27:16.980329
# Unit test for function loader
def test_loader():
    p = Parser(True, 1, False)
    for name, path in walk_packages('pyqt5', 'site-packages'):
        p.parse(name, _read(path + ".pyi"))
    return p.compile()

# Generated at 2022-06-11 19:27:22.513494
# Unit test for function loader
def test_loader():
    logger.info("Begin unit test for function loader")
    # test for import with symbol "_"
    try:
        from . import compiler
        logger.info("Add current path to search path")
        sys_path.append(dirname(__file__))
        logger.info("Begin function loader")
        doc = loader('compiler', dirname(__file__), False, 1, False)
        assert isinstance(doc, str)
    except ImportError:
        pass
    logger.info("Begin unit test for function loader - done")

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:27:26.615444
# Unit test for function loader
def test_loader():
    """Package search unit test."""
    for p in ('matplotlib', 'pygame'):
        ret = loader(p, _site_path(p), True, 1, True)
        print(f"{p} => {len(ret)}")

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:27:35.539016
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    from tempfile import TemporaryDirectory
    import shutil
    from pyslvs_ui.package import TARGET_NAMES

    def test(name: str, path: str):
        with TemporaryDirectory() as pth:
            for p in path:
                mkdir(join(pth, p))
            for m in TARGET_NAMES:
                mkdir(join(pth, m))
                _write(join(pth, m, '__init__.py'), '')
                _write(join(pth, m, '__init__.pyi'), '')
            wp = list(walk_packages(name, pth))
            print(wp)
            assert len(wp) == len(TARGET_NAMES)
            for n, p in wp:
                assert n

# Generated at 2022-06-11 19:27:44.491996
# Unit test for function walk_packages
def test_walk_packages():
    from unittest import TestCase, main
    import site
    import pkgutil
    from pathlib import Path
    from inspect import cleandoc

    class WalkPackagesTest(TestCase):

        def test_walk_packages(self):
            path = Path(site.getsitepackages()[0], 'pyiges')
            packages = [
                package
                for package in pkgutil.walk_packages(
                    path=path.as_posix(), prefix='pyiges.')
            ]
            self.assertEqual(len(packages), 10)
            root_names = {}
            for package in packages:
                root_names[package.module_finder.module_name]\
                    = package.module_finder.path.as_posix()
            self.assertEqual(len(root_names), 10)


# Generated at 2022-06-11 19:27:46.582512
# Unit test for function walk_packages
def test_walk_packages():
    assert all(len(i) > 0 for i in walk_packages('pyslvs', '.'))

# Generated at 2022-06-11 19:27:52.278750
# Unit test for function loader
def test_loader():
    from pathlib import Path
    from unittest import TestCase
    from .api_gen import gen_api as _gen_api

    class GenApiTests(TestCase):
        def setUp(self) -> None:
            self.path = Path(__file__).parent / 'tmp'

        def test_gen_api(self) -> None:
            sys_path.append(str(self.path))
            _gen_api({'numpy': 'numpy'})

# Generated at 2022-06-11 19:29:41.823529
# Unit test for function walk_packages
def test_walk_packages():
    from .__main__ import arg
    if arg.algorithm == 'compiler':
        test_walk_packages.__doc__ = (
            "Test walk packages without importing them."
        )
        print("<Test function walk_packages>")
        wp = list(walk_packages("pyslvs", "."))
        print("Test result:", "success" if wp else "fail")
        print("Test data:")
        print("  ", '\n  '.join(f"{name} => {path}" for name, path in wp))
        print("</Test function walk_packages>")

# Generated at 2022-06-11 19:29:51.772855
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from .solver import structure_solver
    from .parser import Parser
    from .linker import Linker
    from .linker import compiler_link
    from .linker import local_link
    from .strategy import toc_strategy
    from pyslvs.parser import LinkList
    from pyslvs import __version__

    def compile_test(prefix: str, p: Parser, l: Linker) -> str:
        a = p.compile()
        local_link(p, l)
        b = compiler_link(p, l, prefix, pyslvs=__version__)
        return a + b + toc_strategy(b) + l.compile(prefix)

    # Create test folder
    prefix = './docs/test/'

# Generated at 2022-06-11 19:29:55.106298
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""
    items = list(walk_packages("dist", "./src"))
    assert len(items) > 0
    assert items[0][0] == "dist.__main__"

# Generated at 2022-06-11 19:30:05.332327
# Unit test for function loader
def test_loader():
    logger.setLevel(3)
    p = Parser.new(False, 1, False)
    for name, path in walk_packages('pyslvs', '.'):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module here
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext

# Generated at 2022-06-11 19:30:14.552888
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    assert list(walk_packages("pkg", "tests")) == [
        ("pkg.foo", "tests/pkg/foo.py"),
        ("pkg.foo", "tests/pkg/foo-stubs.py"),
        ("pkg.foo.bar", "tests/pkg/foo/bar.py"),
        ("pkg.foo.bar", "tests/pkg/foo/bar-stubs.py"),
        ("pkg.foo.baz", "tests/pkg/foo/baz.py"),
        ("pkg.foo.baz", "tests/pkg/foo/baz-stubs.py"),
    ]

# Generated at 2022-06-11 19:30:26.600371
# Unit test for function loader
def test_loader():
    """Unit test for loader function."""
    from tempfile import TemporaryDirectory
    from shutil import copytree, copy
    from pyslvs_ui.objects import Project
    from .parser import check_import
    from .sympy import sympy_str

    # Copy PySlamSim to temporary directory
    temp_dir = TemporaryDirectory()
    assert temp_dir is not None
    copytree(Project.site_path, temp_dir.name)
    copy(Project.site_path + '.pth', temp_dir.name)
    old = sys_path
    sys_path.append(temp_dir.name)
    # Import modules
    import pyslamsim  # pylint: disable=import-outside-toplevel,unused-import
    import pyslamsim.slam
    import pyslamsim.s

# Generated at 2022-06-11 19:30:32.098718
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .__init__ import __version__
    from pkgutil import walk_packages
    from importlib import import_module
    from .parser import Parser

    def assert_version(p: Parser, name: str) -> None:
        """Test PEP561."""
        v = __version__.rsplit('.', maxsplit=1)[0]
        assert p.pep561(name, v) == f"from {name} {v} import *"

    p = Parser.new(link=False, level=1, toc=False)
    for loader, name, _ in walk_packages(import_module(__name__)):
        if name == "pyslvs_ui":
            continue

# Generated at 2022-06-11 19:30:33.758741
# Unit test for function loader
def test_loader():
    assert loader("pyslvs", "/opt/pyslvs", False, 2, False).strip()

# Generated at 2022-06-11 19:30:45.139345
# Unit test for function loader
def test_loader():
    def test_walk(pname: str, path: str) -> None:
        count = 0
        for name, f in walk_packages(pname, path):
            count += 1
            assert name == f.replace(sep, ".")
        assert count > 0

    test_walk('pyslvs', '.')
    test_walk('pyslvs', 'pyslvs')
    test_walk('pyslvs', 'pyslvs/__init__.py')
    test_walk('pyslvs', 'pyslvs/core/__init__.py')
    test_walk('pyslvs', 'pyslvs/core/vge/__init__.py')

# Generated at 2022-06-11 19:30:49.505015
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from importlib import find_loader
    for i in ["pkgutil", "nbconvert", "wx", "tkinter"]:
        path = find_loader(i).path
        assert isfile(path)
        loader(i, path, False, 1, False)

# Generated at 2022-06-11 19:32:37.032964
# Unit test for function walk_packages

# Generated at 2022-06-11 19:32:44.872210
# Unit test for function loader
def test_loader():
    from .auto_doc import auto_doc
    from .parser import Parser
    root_names = {'pyslvs': 'pyslvs', 'pyslvs-ui': 'pyslvs_ui', 'pyslvs-ui-test': 'pyslvs_ui_test'}
    for title, name in root_names.items():
        logger.info(f"Load root: {name} ({title})")
        doc = loader(name, _site_path(name), True, 1, False)
        assert str(auto_doc(title, Parser.new(True, 1, False))) == str(doc)

# Generated at 2022-06-11 19:32:46.426552
# Unit test for function loader
def test_loader():
    assert isinstance(loader('sys', '.', True, 1, False), str)

# Generated at 2022-06-11 19:32:53.402841
# Unit test for function loader
def test_loader():
    import os
    import sys
    os.chdir('test')
    sys.path.append('..')
    log = logger.getChild('test')
    from pyslvs_ui.plugin import root_names
    for name, path in root_names.items():
        log.info(f"{name}")
        for line in loader(name, path, False, 1, False).split("\n"):
            log.info(f"  {line}")
    os.chdir('..')

# Generated at 2022-06-11 19:33:02.980370
# Unit test for function loader
def test_loader():
    from os import makedirs
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from pkgutil import get_importer, walk_packages

    site_path = str(sys_path[0])
    test_path = join(site_path, 'pyslvs_test')
    makedirs(test_path, exist_ok=True)

    def make_module(name: str, content: str) -> None:
        with open(join(test_path, name + '.py'), 'w+') as f:
            f.write(content)
        with open(join(test_path, name + '.pyi'), 'w+') as f:
            f.write(f"__version__ = '1.0.0'\n")


# Generated at 2022-06-11 19:33:10.948021
# Unit test for function loader
def test_loader():
    from pytest import approx
    from pathlib import Path

    def walk_dir(dirname: str) -> Iterator[str]:
        for path in Path(dirname).iterdir():
            if path.is_dir():
                yield from walk_dir(path.name)
            else:
                yield path.name

    def same(name: str) -> int:
        cnt = 0
        for f in walk_dir(name):
            p = Parser.new(link=False)
            p.parse(f, _read(f))
            if p.compile():
                cnt += 1
        return cnt

    pwd = dirname(__file__)
    assert same('doc') == approx(len(walk_dir('doc')), rel=1e-1)

# Generated at 2022-06-11 19:33:17.182389
# Unit test for function loader
def test_loader():
    root = 'pyslvs'
    pwd = join(dirname(abspath(__file__)), '..')
    docs = gen_api({'PySLVS': root}, pwd, prefix='tests', dry=True)
    assert len(docs) == 1
    assert '# PySLVS API' in docs[0]

# Generated at 2022-06-11 19:33:24.980542
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from unittest import TestCase
    from tempfile import TemporaryDirectory
    from os import makedirs
    from os.path import join as join_path
    from importlib import import_module
    from io import StringIO
    from sys import stdout

    class T(TestCase):
        """Test case."""

        def setUp(self):
            """Set up."""
            self.test_dir = TemporaryDirectory()
            makedirs(join_path(self.test_dir.name, 'pyslvs-ui'))
            makedirs(join_path(self.test_dir.name, 'pyslvs_ui'))
            makedirs(join_path(self.test_dir.name, '.hg'))

# Generated at 2022-06-11 19:33:35.603030
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main
    from pytest import raises
    from tempfile import TemporaryDirectory
    from shutil import copytree

    test_dir = dirname(__file__)
    sys_path.append(test_dir)
    ts = test_dir + sep
    pk = '..' + sep + 'bin'
    root = 'pyslvs_ui'
    pk_path = ts + pk

    def parse_no_errors(name: str, api: str) -> None:
        assert name in api
        assert root in api
        assert pk in api
        assert name + PEP561_SUFFIX in api
        assert 'from pyslvs' in api
        assert name + "." not in api
        assert name + "." + root not in api

# Generated at 2022-06-11 19:33:45.830737
# Unit test for function loader
def test_loader():
    assert len(_site_path('pyslvs')) > 0
    assert find_spec('pyslvs.ui') is not None
    assert find_spec('pyslvs') is not None
    assert isinstance(walk_packages('pyslvs', 'site-packages'), Iterator)
    assert _load_module('pyslvs.data_convert', '', None) is False
    assert _load_module('pyslvs', '', None) is False
    # Skip this test
    if not isdir(dirname(dirname(dirname(dirname(dirname(abspath(__file__)))))) + '/pyslvs'):
        return
    assert isinstance(loader('pyslvs', '../../../../../..', False, 1, False), str)