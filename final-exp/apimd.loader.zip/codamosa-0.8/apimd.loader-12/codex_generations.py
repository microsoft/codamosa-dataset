

# Generated at 2022-06-11 19:26:07.786894
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import sys
    from io import StringIO
    from pyslvs_ui.io import root_names

    for r in root_names:
        sys.stdout = StringIO()
        loader(r, "../pyslvs", False, 1, False)
        print(sys.stdout.getvalue(), end='')

# Generated at 2022-06-11 19:26:10.574472
# Unit test for function loader
def test_loader():
    doc = loader('pyslvs', '', False, 3, False)
    assert '.. _pyslvs.dicts.default_settings:' in doc

# Generated at 2022-06-11 19:26:19.628975
# Unit test for function loader
def test_loader():
    p = Parser.new(link=True, level=1, toc=False)
    p.parse('solver', '''
    def solve(self, *args, **kwargs): ...
    ''')
    p.parse('solver.__init__', '''
    class Solver: ...
    ''')
    p.parse('solver.Solver', '''
    __init__(self, *args, **kwargs): ...
    input_data(self, *args, **kwargs): ...
    solve(self, *args, **kwargs): ...
    output_data(self, *args, **kwargs): ...
    ''')
    p.parse('solver.abstract_solver', '''
    class AbstractSolver: ...
    ''')

# Generated at 2022-06-11 19:26:27.447778
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import tempfile
    site_packages = tempfile.TemporaryDirectory()
    sys.path.append(site_packages.name)

    from shutil import copy
    from os import listdir
    from os.path import join

    package_name = "pyslvs_ui"
    package_path = join(site_packages.name, package_name)
    test_path = join(package_path, "test")
    copy("pyslvs_ui/__init__.py", package_path)
    copy("pyslvs_ui/test/test_parallel_compiler.py", test_path)


# Generated at 2022-06-11 19:26:39.157131
# Unit test for function loader
def test_loader():
    p = Parser.new(link=True, level=1, toc=False)
    p.parse("pkg1.sub1.sub11", """
        :doc:`[sub11] </sub1/sub11.html>`

        .. inheritance-diagram:: pkg1.sub1.sub11

        .. autoclass:: pkg1.sub1.sub11.Sub11
           :members:

        .. autoclass:: pkg1.sub1.sub11.Sub11Sub
           :members:
    """)
    p.parse("pkg1.sub1.sub12", """
        :doc:`[sub12] </sub1/sub12.html>`

        .. autoclass:: pkg1.sub1.sub12.Sub12
           :members:
    """)

# Generated at 2022-06-11 19:26:47.931590
# Unit test for function loader
def test_loader():
    from os import (
        remove,
        environ,
        listdir,
        chdir,
        mkdir,
    )
    from os.path import (
        join,
        isfile,
        isdir,
        abspath,
    )
    import atexit
    from tempfile import gettempdir
    from shutil import rmtree
    from pyslvs.constants import (
        SV_BLACK_LIST,
        SV_BLACK_LIST_PATHS,
        SV_BLACK_LIST_PATHS_RE,
    )
    from pyslvs_ui.compiler import (
        loader,
        gen_api,
    )

    def cleanup():
        if isdir(TEST_DIR):
            chdir(TEST_DIR)

# Generated at 2022-06-11 19:26:57.564519
# Unit test for function walk_packages
def test_walk_packages():
    def assert_pkgs(pkgs: Sequence[tuple[str, str]], *names: str) -> None:
        assert all(name in pkgs for name in names)
        assert all(isinstance(name, str) for name in names)

    root = 'foo'
    path = 'site-packages/foo'
    pkgs = walk_packages(root, path)
    assert_pkgs(pkgs, 'foo.bar.baz', 'foo.bar.baz-stubs')

    # Test import error:
    root = 'invalid'
    path = 'site-packages/invalid'
    pkgs = walk_packages(root, path)
    assert not pkgs

# Generated at 2022-06-11 19:27:04.312655
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs", "pyslvs"):
        logger.info(f"{name} <= {path}")
    from sys import version
    from site import getusersitepackages
    path = getusersitepackages()
    for name, path in walk_packages("matplotlib", path):
        logger.info(f"{name} <= {path}")

test_walk_packages()

# Generated at 2022-06-11 19:27:10.866157
# Unit test for function walk_packages
def test_walk_packages():
    from .utils import diff_output, cwd

    with cwd():
        for name, path in walk_packages("slvs", "."):
            print(path)
            assert name.startswith("slvs")
    with cwd(join('test', 'packages')):
        for name, path in walk_packages("pyslvs", "."):
            print(path)
            assert name.startswith("pyslvs")

    with cwd(join('test', 'packages')):
        output = loader('pyslvs', '.', False, 2, False)

    diff_output(output, "packages.md")

# Generated at 2022-06-11 19:27:18.664806
# Unit test for function loader
def test_loader():
    import sys
    import pkgutil
    # remove pyslvs.compiler
    path_this = __file__
    sys.path.remove(parent(path_this))
    sys.path.remove(parent(parent(path_this)))
    assert loader("pyslvs", parent(path_this), False, 2, False)
    # Try to load built-in module
    assert loader("sys", pkgutil.extend_path([""], "sys"), False, 2, False)

# Generated at 2022-06-11 19:28:30.796785
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from importlib.util import spec_from_loader
    from pkgutil import get_loader

    def test_package(name):
        s = spec_from_loader(name, get_loader(name))
        m = module_from_spec(s)
        s.loader.exec_module(m)
        return m

    # Test for pure python package
    assert loader(
        "test_package",
        dirname(__file__) + sep + "test-data",
        True, 1, True,
    ).strip()

    # Test for extension module
    loader(
        "test_extension",
        dirname(__file__) + sep + "test-data",
        True, 1, True,
    ).strip()

# Generated at 2022-06-11 19:28:37.770693
# Unit test for function loader
def test_loader():

    def load(name: str, *exts) -> None:
        for ext in exts:
            s = spec_from_file_location(name, f"{name}.{ext}")
            if s is not None and isinstance(s.loader, Loader):
                m = module_from_spec(s)
                s.loader.exec_module(m)
                return m
        raise RuntimeError(f"no compiled extension module for {name}")

    class MyStr(str):
        pass

    class MyList(list):
        pass

    class MyDict(dict):
        pass

    class MyTuple(tuple):
        pass

    class MySet(set):
        pass

    class MyFrozenset(frozenset):
        pass

    class MySlice(slice):
        pass


# Generated at 2022-06-11 19:28:47.494564
# Unit test for function loader
def test_loader():
    def gen_docs(name: str, pwd: str, link: bool, level: int, toc: bool) -> str:
        return f"""
# API for {name}

{loader(name, pwd, link, level, toc)}
        """.strip()


# Generated at 2022-06-11 19:28:59.173816
# Unit test for function walk_packages
def test_walk_packages():
    """Test function walk_packages."""

# Generated at 2022-06-11 19:29:07.557556
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    import shutil

    # Clean up the testing environment
    shutil.rmtree('test', ignore_errors=True)
    Path('spam-stubs').mkdir(parents=True, exist_ok=True)

    # Prepare the test script
    _write('spam-stubs/__init__.pyi', 'import math')
    _write('spam-stubs/spam.pyi', 'import math')
    _write('spam-stubs/spam/__init__.pyi', 'import math')
    _write('spam-stubs/spam/eggs.pyi', 'import math')

    # Testing code

# Generated at 2022-06-11 19:29:18.709622
# Unit test for function walk_packages
def test_walk_packages():
    from . import test_path
    from pkg_resources import Distribution, PathMetadata

    from .test_path import test_name
    from .test_path import test_py, test_stub
    from .test_path import test_py_pyi, test_pyi
    from .test_path import test_name_nest
    from .test_path import test_py_nest, test_stub_nest
    from .test_path import test_py_pyi_nest, test_pyi_nest

    # Create the distribution
    dist = Distribution(None, metadata=PathMetadata(test_path, None))
    dist.location = test_path

    # 1. test simple root
    assert list(walk_packages(test_name, test_path)) == [(test_name, test_py)]

   

# Generated at 2022-06-11 19:29:22.030852
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('numpy', _site_path('numpy')):
        print(name, path)

# Generated at 2022-06-11 19:29:29.524081
# Unit test for function loader
def test_loader():
    """Test function loader."""
    assert len(_site_path("Pyslvs")) != 0
    assert len(_site_path("Pyslvs_ui")) != 0
    assert len(_site_path("Pyslvs_tdraw")) != 0
    assert len(_site_path("Pyslvs_PlanAhead")) != 0
    from pyslvs.construction import generator
    from pyslvs_ui.qt_patch import QtCore
    from Pyslvs_ui.widgets import Widget
    from pyslvs_ui.io.project_setup import ProjectSetup
    for name, path in walk_packages("pyslvs", _site_path("Pyslvs")):
        assert isdir(path)

# Generated at 2022-06-11 19:29:31.975495
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    doc = loader(
        "pyslvs", "/".join(__file__.split("/")[:-1]),
        link=False, level=1, toc=False
    )
    print(doc)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:29:38.948349
# Unit test for function loader
def test_loader(): # pragma: no cover
    import tempfile
    import shutil
    import subprocess

    path = tempfile.mkdtemp()
    try:
        subprocess.check_call([
            "pip",
            "install",
            "--target",
            f"{path}",
            "requests",
            "--no-deps"
        ])
        print(loader("requests", path, True, 1, False))
    finally:
        shutil.rmtree(path)

# Generated at 2022-06-11 19:32:05.993784
# Unit test for function loader

# Generated at 2022-06-11 19:32:16.222924
# Unit test for function walk_packages
def test_walk_packages():
    from os import mkdir, rmdir
    from os.path import join
    from tempfile import mkdtemp
    from shutil import copy2
    test = join(mkdtemp(), 'test')
    mkdir(test)
    mkdir(join(test, 'common'))
    mkdir(join(test, 'package'))
    mkdir(join(test, 'stubs'))
    copy2(__file__, join(test, 'common.py'))
    copy2(__file__, join(test, 'package/__init__.py'))
    copy2(__file__, join(test, 'package/subpackage.py'))
    copy2(__file__, join(test, 'stubs/__init__.pyi'))

# Generated at 2022-06-11 19:32:19.968336
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    print(loader("pyslvs_ui", "pyslvs_ui", False, 1, False))


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:32:25.249391
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    root = "pyslvs"
    pwd = "dist"
    link = False
    level = 1
    toc = False
    doc = loader(root, pwd, link, level, toc)
    assert doc.startswith("# Pyslvs API\n\n")
    assert 'anaconda' not in doc



# Generated at 2022-06-11 19:32:33.800456
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('sklearn', '../sklearn'):
        print(name, path)
    for name, path in walk_packages('sklearn', '../sklearn-stubs'):
        print(name, path)
    for name, path in walk_packages('./sklearn', '../sklearn'):
        print(name, path)
    for name, path in walk_packages('./sklearn', '../sklearn-stubs'):
        print(name, path)

# Generated at 2022-06-11 19:32:37.120885
# Unit test for function loader
def test_loader():
    """Unit test for function `loader`."""
    assert loader(".", dirname(__file__), False, 1, False).startswith("# API")
    assert loader(".", dirname(__file__), True, 1, True).startswith("# API")

# Generated at 2022-06-11 19:32:46.847894
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .utils import md_link, md_h1, md_h2, md_h3
    from .utils import md_h4, md_h5, md_h6, md_li, md_ul
    from .utils import md_ol, md_code_block, md_text
    import pytest

    def test_parse(p: Parser, text: str) -> None:
        assert p.parse('', text) == text

    def test_parse_err(p: Parser, text: str) -> None:
        with pytest.raises(Exception):
            p.parse('', text)


# Generated at 2022-06-11 19:32:58.114990
# Unit test for function loader
def test_loader():
    from .link import Linker
    from .toc import TOC

    l = Linker(level=2)
    t = TOC(title='API', level=1)
    p = Parser.new(l, 2, t)
    # test file py
    parts = 'os\npath\nstat'.split('\n')
    for part in parts:
        name = 'os.path.stat' + part
        with open(name + '.py', 'w+', encoding='utf-8') as f:
            f.write(f'"""{name}"""')
    # test file pyi
    parts = 'os\npath'.split('\n')
    for part in parts:
        name = 'os.path' + part

# Generated at 2022-06-11 19:33:07.123225
# Unit test for function loader
def test_loader():
    from pytest import approx
    from .vlink import vlink
    doc = loader('pyslvs', 'pyslvs', False, 1, False)
    logger.info(len(doc))
    assert len(doc) == approx(40200, abs=1000)
    doc = loader('pyslvs', 'pyslvs', True, 1, False)
    assert len(doc) == approx(49500, abs=1000)
    # Test links
    assert vlink('pyslvs.data.config') == vlink('data.config')
    assert vlink('pyslvs.expression.symbol_table') == vlink('expression.symbol_table')
    assert vlink('pyslvs.expression.parse_expression') == vlink('expression.parse_expression')

# Generated at 2022-06-11 19:33:12.772055
# Unit test for function loader
def test_loader():
    from .config import parser
    import argparse
    args = parser.parse_args(args=[
        '--root', 'pyslvs',
        '--pwd', './pyslvs',
        '--prefix', './docs',
    ])

    def _test():
        with open(abspath(args.pwd) + '/pyslvs/__init__.py', 'r', encoding='utf-8') as f:
            init_doc = f.readline()
        assert init_doc.startswith('"""')
        assert init_doc.strip().endswith('"""')
        name = init_doc.replace('"""', '').strip()
        print(gen_api({"PYSolver": "pyslvs"}, './pyslvs'))