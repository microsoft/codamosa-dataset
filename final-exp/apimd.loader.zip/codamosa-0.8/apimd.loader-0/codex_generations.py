

# Generated at 2022-06-11 19:26:06.783374
# Unit test for function loader
def test_loader():
    """Check loader."""
    logger.setLevel('DEBUG')
    assert loader('pyslvs', join(dirname(__file__), '..'), link=False, level=2, toc=False) is not None



# Generated at 2022-06-11 19:26:17.201696
# Unit test for function loader
def test_loader():
    """Generate API for unit test."""
    from .logger import logger
    from .parser import Parser
    from .menu import APIMenu
    from .doc import Document
    from .repo import Repository
    from .collections import VLink
    from .completion import Completion
    from .vscode_extension import VSCodeExtension
    from .vscode_debug import VSCodeDebug
    from .search import Search
    from .rename import Rename
    from .workspace import Workspace
    root = '.'
    p = Parser.new(True, 1, False)
    p.parse(VLink.__module__, VLink.__doc__)
    p.parse(APIMenu.__module__, APIMenu.__doc__)

# Generated at 2022-06-11 19:26:18.845503
# Unit test for function loader
def test_loader():
    """Test for package searching algorithm."""
    import doctest
    return doctest.testmod(verbose=False)[0] == 0

# Generated at 2022-06-11 19:26:24.896622
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    # On this environment this command will create two files:
    # - docs/pyslvs-api.md
    # - docs/pyslvs_ui-api.md
    gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs UI': 'pyslvs_ui',
    }, pwd=dirname(abspath(__file__)))

# Generated at 2022-06-11 19:26:30.245940
# Unit test for function loader
def test_loader():
    logger.setLevel('DEBUG')
    gen_api({
        'NumPy': 'numpy',
        'SciPy': 'scipy',
        'Matplotlib': 'matplotlib',
    }, dry=True)
    logger.setLevel('INFO')

# Generated at 2022-06-11 19:26:40.908771
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile
    with tempfile.TemporaryDirectory(prefix="test-svg2dxf") as temp:
        assert len(list(walk_packages("test", temp))) == 0
        assert len(list(walk_packages("svg2dxf", temp))) == 0
        assert len(list(walk_packages("gui", temp))) == 0
        mkdir(join(temp, "svg2dxf"))
        mkdir(join(temp, "svg2dxf", "limitation"))
        mkdir(join(temp, "svg2dxf", "limitation", "pyclipper"))
        mkdir(join(temp, "svg2dxf", "limitation", "pyclipper", "__pycache__"))
        mkdir(join(temp, "svg2dxf", "__pycache__"))
        mk

# Generated at 2022-06-11 19:26:48.822490
# Unit test for function walk_packages
def test_walk_packages():
    """Test function: walk_packages."""
    import pkgutil
    import unittest
    import sys
    import inspect
    from os import pardir

    class Test(unittest.TestCase):

        def test_walk_packages(self):
            """Test function: walk_packages."""
            self.assertEqual(
                {k for k, _ in walk_packages("PyQt4", dirname(inspect.getfile(sys)))},
                {k for k, _ in pkgutil.walk_packages(dirname(inspect.getfile(sys)))},
            )

# Generated at 2022-06-11 19:26:54.398389
# Unit test for function loader
def test_loader():
    """Test for loader() function."""
    from re import findall
    from PIL import Image
    from .random_color import random_color
    from .logger import logger_setup
    from .exceptions import CompileError

    logger_setup(logger)

    # Test for PEP 561 stub file
    doc = loader('PIL', _site_path('PIL'), False, 2, False)
    assert "Image\n--\n" in doc
    assert ".. py:class:: Image" in doc

    # Test for import
    docs = gen_api({'PIL': 'PIL'}, prefix='build')

# Generated at 2022-06-11 19:26:59.474253
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from . import __path__
    print('\n'.join(gen_api({
        "Pyslvs": "pyslvs",
    }, __path__[0])))


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-11 19:27:09.630383
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from pyslvs import __path__ as p


# Generated at 2022-06-11 19:31:06.426484
# Unit test for function loader
def test_loader():
    from os import chdir, remove
    from os.path import exists
    from shutil import rmtree
    from .logger import set_logger
    from .utils import data_path

    set_logger('DEBUG')

    def _rmdir(path: str) -> None:
        if exists(path):
            rmtree(path)
    root_names = {"Pyslvs": "pyslvs", "PyVCP": "pyslvs_ui"}

    # Empty root_names
    assert gen_api(dict(), prefix='test') == []

    # Empty words
    _rmdir('test')
    assert gen_api(root_names, prefix='test') == []
    _rmdir('test')

    # With some words
    chdir(data_path)

# Generated at 2022-06-11 19:31:14.303926
# Unit test for function loader
def test_loader():
    import sys
    import os
    from .logger import logger

    logger.setLevel("DEBUG")
    os.chdir("..")
    test_root = 'tests.data'
    sys.path.append('tests')
    doc = loader(test_root, sys.path[-1], True, 1, True)
    with open(join("tests", "test-api.md"), 'w+', encoding='utf-8') as f:
        f.write(doc)

# Generated at 2022-06-11 19:31:19.156215
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages."""
    pkgs = list(walk_packages('a', 'site-packages/test'))
    assert pkgs[0] == ('a', "site-packages/test/a")
    assert pkgs[1] == ('a.b', "site-packages/test/a/b")
    assert pkgs[2] == ('a.b.c', "site-packages/test/a/b/c")

# vim: panose-1:shiftwidth=4:expandtab:fo-=t

# Generated at 2022-06-11 19:31:26.055943
# Unit test for function loader
def test_loader():
    """Test function loader."""
    p = Parser.new(False, 0, False)
    _load_module('t2', 't2.so', p)
    assert p.doc_string('t2') == ('"""\n'
                                  'auto import\n'
                                  '\n'
                                  ':func:`~t1.func`\n'
                                  '"""\n')



# Generated at 2022-06-11 19:31:33.578990
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    from dataclasses import dataclass
    from sys import getframeinfo

    @dataclass
    class Module:
        """A fake module."""
        doc: str

    def fake_spec(path: str) -> Optional[Module]:
        """Fake spec."""
        if path == 'no valid':
            return None
        return Module(f"{path}.__doc__")

    def fake_imp(name: str):
        """Fake import."""
        if name == 'no import':
            raise ImportError
        return Module(f"{name}.__doc__")

    def fake_gen(root: str, pwd: str) -> tuple[Module]:
        """Fake package walk."""
        if root == 'no valid':
            return ()

# Generated at 2022-06-11 19:31:36.210032
# Unit test for function loader
def test_loader():
    """Test suite for the module 'loader'."""
    p = Parser.new(False, 1, False)

# Generated at 2022-06-11 19:31:47.170087
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from unittest import TestCase, main

    class LoaderTestCase(TestCase):

        float_doc = """
        The float class is a built-in class available in Python.
        It allows the user to convert a given number or a string containing
        numbers to a floating-point number."""

        doc_set = {"math", "builtins", "name", *float_doc.split()}

        def test_loader(self):
            """Test loader."""
            name, path = next(walk_packages("math", "."))
            self.assertEqual(name, "math")
            self.assertEqual(path, "math")
            self.assertTrue(loader(name, path, False, 1, False).split())


# Generated at 2022-06-11 19:31:49.663335
# Unit test for function walk_packages
def test_walk_packages():
    one = 0
    for _, path in walk_packages("sys", "./"):
        one += int(isfile(path + ".py"))
        one += int(isfile(path + ".pyi"))
    assert one > 1

# Generated at 2022-06-11 19:32:00.852628
# Unit test for function walk_packages
def test_walk_packages():
    """PEP561 walk test."""
    from os import getcwd
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        for _ in range(5):
            folder = temp + f"/PySlvs{_}/"
            sub_folder = folder + "sub_folder/"
            mkdir(folder)
            mkdir(sub_folder)
            py = sub_folder + "test.py"
            pyi = sub_folder + "test.pyi"
            _write(py, "")
            _write(pyi, "")
            assert len(tuple(walk_packages("PySlvs", folder))) == 1
            assert len(tuple(walk_packages("PySlvs", sub_folder))) == 1
            assert len(tuple(walk_packages("PySlvs", temp)))

# Generated at 2022-06-11 19:32:02.752324
# Unit test for function loader
def test_loader():
    logger.setLevel('DEBUG')
    gen_api({'VCS': 'pyslvs_ui.vcs'})