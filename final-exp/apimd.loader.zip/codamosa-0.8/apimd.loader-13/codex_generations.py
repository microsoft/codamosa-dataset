

# Generated at 2022-06-11 19:26:44.208775
# Unit test for function loader
def test_loader():
    # Only test in Windows
    doc = loader("pathlib", parent(__file__), False, 1, False)
    logger.info('=' * 12)
    logger.info(doc)
    assert doc.startswith("# [PosixPath")

# Generated at 2022-06-11 19:26:47.086924
# Unit test for function loader
def test_loader():
    """Testing function loader."""
    assert loader('pyslvs', '.', True, 1, True)
    assert loader('pyslvs', '.', True, 2, True)
    assert not loader('pyslvs', '.', True, 0, True)

# Generated at 2022-06-11 19:26:57.846948
# Unit test for function loader
def test_loader():
    """Loader is the main function for searching module."""
    from tempfile import TemporaryDirectory
    from shutil import copy
    import os
    from os.path import expanduser
    from typing import Dict, Tuple
    from pkgutil import iter_modules
    import pytest

    tp = TemporaryDirectory()
    fp = tp.name
    os.mkdir(fp + '/pyslvs_test')
    with open(fp + '/pyslvs_test/__init__.py', 'w') as f:
        f.write('from pyslvs_test.test1 import *\n'
                'from pyslvs_test.test2 import *\n')

# Generated at 2022-06-11 19:27:04.141621
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main

    class UnitTest(TestCase):

        def test_simple(self):
            pwd = dirname(abspath(__file__)) + sep + 'example'
            result = loader('example', pwd, False, 1, False)
            self.assertIn('# example.__init__', result)
            self.assertIn('# example.a', result)
            self.assertIn('# example.b', result)
            self.assertIn('# example.c', result)
            self.assertIn('# example.d', result)
            self.assertIn('# example.e', result)
            self.assertIn('# example.f.__init__', result)
            self.assertIn('# example.f.g', result)

# Generated at 2022-06-11 19:27:11.922092
# Unit test for function loader
def test_loader():
    assert _site_path("numpy")
    assert _site_path("pyslvs").endswith("pyslvs")
    assert _site_path("pyslvs-ui").endswith("pyslvs-ui")
    assert _site_path("pyslvs_ui") != _site_path("pyslvs-ui")
    d = list(walk_packages("pyslvs-ui", _site_path("pyslvs-ui")))
    assert "pyslvs_ui.__init__" in [n for n, _ in d]
    assert "pyslvs_ui.__main__" in [n for n, _ in d]
    assert "pyslvs_ui.solver" in [n for n, _ in d]

# Generated at 2022-06-11 19:27:21.398735
# Unit test for function walk_packages

# Generated at 2022-06-11 19:27:32.547387
# Unit test for function loader
def test_loader():
    # pylint: disable=unused-variable, no-member
    from .parser import Member
    from .colorize import c
    from .logger import set_logger, Logger
    set_logger(Logger.DEBUG)
    doc = loader('pyslvs', dirname(__file__), link=True, level=1, toc=False)
    assert PEP561_SUFFIX not in doc
    assert PEP561_SUFFIX in loader('pyslvs', dirname(__file__), link=True,
                                   toc=True, level=1)
    assert 'pyslvs.__version__' in doc
    assert 'pyslvs.data.vpoints' in doc
    assert '# pyslvs.ui.dialogs.plot_curves' not in doc

# Generated at 2022-06-11 19:27:43.975546
# Unit test for function walk_packages

# Generated at 2022-06-11 19:27:49.174943
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    assert loader(root="pyslvs", pwd="..", link=False, level=1, toc=False)
    assert loader(root="pyslvs_ui", pwd="..", link=False, level=1, toc=False)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-11 19:27:57.131871
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("test", ".")) == [
        ('test', './test.py'),
        ('test.security', './test/security.py'),
        ('test.security.__init__', './test/security/__init__.py'),
        ('test.security.base', './test/security/base.py'),
        ('test.security.base.__init__', './test/security/base/__init__.py'),
        ('test.security.base.auth', './test/security/base/auth.py'),
        ('test.security.base.basic', './test/security/base/basic.py'),
    ]
