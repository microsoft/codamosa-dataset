

# Generated at 2022-06-21 09:50:41.379595
# Unit test for function walk_packages
def test_walk_packages():
    case = [
        'root/a.pyi',
        'root/b.py',
        'root/c.py',
        'root/d.pyi',
        'root/e/__init__.py',
        'root/f/a.pyi',
        'root/f/d.pyi',
        'root-stubs/a.pyi',
        'root-stubs/b.pyi',
        'root-stubs/c.pyi',
    ]
    for f in case:
        open(f, 'w').close()
    result = list(walk_packages('root', '.'))
    for f in case:
        try:
            remove(f)
        except OSError:
            pass

# Generated at 2022-06-21 09:50:48.774231
# Unit test for function gen_api
def test_gen_api():
    from importlib import reload
    from .__main__ import log_level
    from .parser import Parser
    from .util import color
    reload(log_level)

    def test_from_mock(name, title, level, link, toc):
        logger.info(f"Load root: {name} ({title})")
        doc = loader(name, 'docs/mock', link, level, toc)
        path = f"docs/{name}-api.md"
        logger.info(f"Write file: {path}")
        doc = '#' * level + f" {title} API\n\n" + doc
        _write(path, doc)
        logger.info('=' * 12)
        logger.info(doc)


# Generated at 2022-06-21 09:50:54.084964
# Unit test for function walk_packages
def test_walk_packages():
    name = 'unittest_pyslvs'
    path = '.'
    for _ in walk_packages(name, path):
        break
    else:
        raise RuntimeError(f"{name} can not be found")
    path = ''
    for _ in walk_packages(name, path):
        raise RuntimeError(f"{name} should not be found")

# Generated at 2022-06-21 09:50:56.380893
# Unit test for function loader
def test_loader():
    from . import rim_compiler
    assert rim_compiler.loader("pyslvs", ".", False, 1, False)

# Generated at 2022-06-21 09:51:02.579866
# Unit test for function loader
def test_loader():
    from hashlib import md5
    code = s = ""
    for n, p in walk_packages("pyslvs", ".."):
        code += (f"{p},{n}\n")
        s += _read(f"{p}.py")
    assert code == ""
    assert md5(s.encode()).hexdigest() == "acc9e9606f3b3fb6725b68f55b03f986"



# Generated at 2022-06-21 09:51:04.877541
# Unit test for function loader
def test_loader():
    assert loader(
        'pyslvs',
        dirname(__file__),
        False,
        3,
        False
    )


# Generated at 2022-06-21 09:51:10.084396
# Unit test for function loader
def test_loader():
    from .__main__ import load_config

    with open(abspath('solvespace.yaml'), 'r', encoding='utf-8') as f:
        cfg = load_config(f.read())
    docs = gen_api(cfg['root'], prefix='.', dry=True)
    # assert len(docs) == 1
    # assert docs[0].startswith('# Solvespace API\n\n')

# Generated at 2022-06-21 09:51:17.777097
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    assert isdir('build')
    assert next(walk_packages('solver', 'build'))[0] == 'solver'
    assert next(walk_packages('solver', 'build')).__next__()[0] == 'solver.__main__'
    assert next(walk_packages('solver', 'build'))[0] == 'solver'
    assert next(walk_packages('solver', 'build')).__next__()[0] == 'solver.__main__'

# Generated at 2022-06-21 09:51:24.870986
# Unit test for function loader
def test_loader():
    """Test loader function."""
    from unittest import TestCase
    from os.path import isfile
    from os import remove

    class APITest(TestCase):
        """Testing for API."""
        def test_api(self):
            """Simple API generator."""
            if isfile("compiler.log"):
                remove("compiler.log")
            gen_api({"Module": "__main__"})
            self.assertTrue(isfile("docs/module-api.md"))

    APITest("test_api").test_api()

# Generated at 2022-06-21 09:51:27.303133
# Unit test for function gen_api
def test_gen_api():
    """Unit test: function gen_api"""
    gen_api({'Pyslvs': 'pyslvs'}, dry = True)