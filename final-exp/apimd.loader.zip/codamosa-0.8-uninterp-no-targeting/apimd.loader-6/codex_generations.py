

# Generated at 2022-06-21 09:50:49.392965
# Unit test for function loader
def test_loader():
    from .__init__ import __version__
    from .test import test_pyslvs_ui
    from .test import test_api_gen
    r = loader(
        'pyslvs_ui',
        test_pyslvs_ui.__path__._path[0],
        link=False,
        level=1,
    )
    assert r.strip(), "Can't generate package API."
    assert r.endswith('\n'), 'API should be end with "\n" character.'
    assert '## Classes\n' in r
    assert '#' + test_pyslvs_ui.__name__ + '.' in r
    assert '#' + test_api_gen.__name__ not in r

# Generated at 2022-06-21 09:50:51.270081
# Unit test for function loader
def test_loader():
    """Write API to standard output."""
    print(loader("pyslvs", "src", True, 2, True))

# Generated at 2022-06-21 09:51:01.498872
# Unit test for function gen_api
def test_gen_api():
    from unittest import TestCase
    from unittest.mock import patch

    def _raise(e):
        """Raise a ImportError"""
        raise e

    class Test(TestCase):
        """Unit tests for the function."""
        @patch('pyslvs_build.syst_doc.gen_api.loader', side_effect=_raise)
        def test_not_found(self, _):
            """Unit test for not found package."""
            doc = gen_api(root_names={'Test': "test"})
            self.assertEqual(doc, [])
            doc = gen_api(root_names={'Test': "test"}, dry=True)
            self.assertEqual(doc, [])

    return (Test, )

# Generated at 2022-06-21 09:51:10.421290
# Unit test for function gen_api
def test_gen_api():
    def test_root(link: bool, level: int, toc: bool, dry: bool):
        root_names = {
            "NumPy": "numpy",
            "SciPy": "scipy",
            "Matplotlib": "mpl",
            "SymPy": "sympy",
            "Numba": "numba",
            "Blender": "bpy",
            "Maya": "maya",
            "Django": "django",
        }
        docs = gen_api(
            root_names,
            pwd=dirname(__file__),
            link=link,
            level=level,
            toc=toc,
            dry=dry
        )
        assert len(docs) == len(root_names)


# Generated at 2022-06-21 09:51:20.379517
# Unit test for function gen_api
def test_gen_api():
    from os import chdir, getcwd, remove
    from os.path import join, isdir, isfile
    from shutil import rmtree
    from .logger import quiet

    chdir(dirname(__file__))
    assert getcwd().endswith('tests')

    logger.setLevel(quiet)
    try:
        rmtree('docs')
    except FileNotFoundError:
        pass
    assert not isdir('docs')

    doc = gen_api({'test': 'solve2d'}, '..', dry=True)[0]
    assert 'Solver class' in doc
    assert 'def __init__(' in doc
    assert 'API that only used in internal.' not in doc
    assert 'compiled result' in doc
    assert 'the above and the below' in doc


# Generated at 2022-06-21 09:51:23.924738
# Unit test for function loader
def test_loader():
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    docs = gen_api({'Test': 'test'}, '..')
    assert len(docs) == 1
    assert 'Pylvs' in docs[0]

# Generated at 2022-06-21 09:51:29.453264
# Unit test for function gen_api
def test_gen_api():
    gen_api({"a": "a"})
    gen_api({"a": "a"}, path=__file__)
    gen_api({"a": "a"}, pwd=__file__)
    gen_api({"a": "a"}, prefix="docs", link=True, level=1, toc=False, dry=False)

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:51:32.614650
# Unit test for function loader
def test_loader():
    """Test for function loader.

    The path must be the current path,
    otherwise it may cause the "site-packages" error.
    """
    pwd = dirname(__file__) + sep
    doc = loader('pyslvs', pwd, False, 1, False)
    assert doc.strip() != ""



# Generated at 2022-06-21 09:51:41.312249
# Unit test for function loader
def test_loader():
    from collections import OrderedDict
    from pyslvs import __version__
    from .logger import logger
    logger.setLevel(100)

# Generated at 2022-06-21 09:51:45.471212
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from .__main__ import __path__
    from . import __package__

    logger.info(f"Test for `{__package__}.{test_walk_packages.__name__}`")
    for name, path in walk_packages(__package__, __path__[0]):
        logger.debug(f"{name} <= {path}.py")
    logger.info(f"Test done")

# Generated at 2022-06-21 09:53:44.121729
# Unit test for function gen_api
def test_gen_api():
    import_error = ImportError("No module named '__main__.not_exist'")
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

# Generated at 2022-06-21 09:53:46.569614
# Unit test for function walk_packages
def test_walk_packages():
    assert not any(walk_packages("foo", "./"))
    assert any(walk_packages("test", "tests"))



# Generated at 2022-06-21 09:53:53.557873
# Unit test for function gen_api
def test_gen_api():
    import tempfile
    import shutil
    from pkg_resources import EntryPoint
    from importlib import machinery
    import sys
    import os
    from pylatexenc.latexwalker import LatexWalker

    tmp = tempfile.mkdtemp()
    directory = os.path.join(tmp, 'testpkg')
    os.mkdir(directory)
    os.mkdir(os.path.join(directory, 'docs'))
    os.mkdir(os.path.join(directory, 'testpkg'))
    with open(os.path.join(directory, 'testpkg', '__init__.py'), 'w') as f:
        f.write("""
__version__ = '1.0'
__package_name__ = 'testpkg'
"""
        )

# Generated at 2022-06-21 09:54:02.283368
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree
    from tempfile import mkdtemp
    from os.path import dirname
    from os import mkdir
    test_path = lambda x: join(mkdtemp(), x)

    def _create(data_dict):
        for path, content in data_dict.items():
            if isinstance(content, dict):
                _create(content)
                continue
            if path.endswith(".py"):
                with open(path, "w+") as f:
                    f.write(content)
            else:
                mkdir(path)

    with open("test.py", "w+") as f:
        f.write("")

    with open("test.pyi", "w+") as f:
        f.write("")


# Generated at 2022-06-21 09:54:04.649762
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api(
        {
            "Test": "test",
        },
        '.',
        prefix='test_dir',
        dry=True,
    )
    assert len(docs) == 1

# Generated at 2022-06-21 09:54:09.725169
# Unit test for function loader
def test_loader():
    """Unit test."""
    import sys
    import platform
    import numpy

    logger.warning(f"Skip function test for loader() in {platform.system()}")
    if sys.executable.endswith('pythonw.exe'):
        return
    import pyslvs
    assert loader('pyslvs', dirname(pyslvs.__file__), False, 1, False).strip()

# Generated at 2022-06-21 09:54:18.397927
# Unit test for function walk_packages
def test_walk_packages():
    from importlib import import_module
    from json import dumps
    from re import sub
    from .logger import set_log_debug
    set_log_debug(True)
    p = Parser.new(False, 1, False)
    dname = dirname(dirname(abspath(__file__)))
    dname = abspath(dname + "/solvespace/solvespace")
    for name, path in walk_packages("solvespace", dname):
        ext = path.suffixes[-1]
        if ext in (".py", ".pyi"):
            p.parse(name, _read(path))
        else:
            print("interface:", path)
            import_module(name)
    p.load_hash("solvespace")

# Generated at 2022-06-21 09:54:21.260138
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'pyslvs': 'pyslvs'})
    assert gen_api({'pyslvs': 'pyslvs', 'vamos': 'vamos'}, dry=True)

# Generated at 2022-06-21 09:54:29.372310
# Unit test for function gen_api
def test_gen_api():
    rn = {
        "Pyslvs API": "pyslvs",
        "Pyslvs UI API": "pyslvs_ui",
        "Pyslvs JSON API": "pyslvs_json",
        "Pyslvs Plugin API": "pyslvs_plugin",
        "pyslvs_parse API": "pyslvs_parse",
        "pyslvs_parse UI API": "pyslvs_parse_ui",
        "sipyco API": "sipyco",
    }
    docs = gen_api(rn, pwd=r'C:\Users\User\AppData\Local\Programs\Python\Python37\Lib\site-packages', dry=True)
    assert len(docs) == len(rn)
    for doc in docs:
        assert doc

# Generated at 2022-06-21 09:54:32.971808
# Unit test for function gen_api
def test_gen_api():
    """Test script."""
    docs = gen_api(
        {
            "PySLVS": "pyslvs",
            "PySLVS UI": "pyslvs_ui",
        },
        "../pyslvs_ui/solver/site-packages"
    )
    assert len(docs) == 2
    for doc in docs:
        assert len(doc) > 100
