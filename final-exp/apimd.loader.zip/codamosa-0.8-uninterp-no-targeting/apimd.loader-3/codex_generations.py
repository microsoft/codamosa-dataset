

# Generated at 2022-06-21 09:50:24.340892
# Unit test for function loader
def test_loader():
    """Test function loader in this module."""
    from os.path import expanduser
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('-v', help="verbose", action='store_true')
    p.add_argument('-c', help="show config", action='store_true')
    p.add_argument('-l', help="show logs", action='store_true')
    p.add_argument('-d', help="make a dry run", action='store_true')
    p.add_argument('-x', help="examples code", action='store_true')
    p.add_argument('--level', help="heading level", type=int, default=4)
    p.add_argument('--site', help="site-packages root", type=str)
    p.add

# Generated at 2022-06-21 09:50:33.039874
# Unit test for function walk_packages
def test_walk_packages():
    # To avoid random error in the system
    assert list(walk_packages('test2', '.')) == []

# Generated at 2022-06-21 09:50:34.631333
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'Title': 'aa'}, dry=True) == ['# Title API\n']


# Generated at 2022-06-21 09:50:43.317311
# Unit test for function gen_api
def test_gen_api():
    from importlib.util import module_from_spec
    from importlib.machinery import SourceFileLoader

    SOURCE_FILE_PATH = r'D:\tt.py'
    MODULE_NAME = 'tt'

    # Create python spec.
    spec = importlib.util.spec_from_file_location(MODULE_NAME, SOURCE_FILE_PATH)

    # Create module
    mod = module_from_spec(spec)

    # Load python file into module
    spec.loader.exec_module(mod)

    # Print module variables
    print(mod.__dict__)


# Generated at 2022-06-21 09:50:44.796309
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'Solver': 'pyslvs_ui'}) == list()



# Generated at 2022-06-21 09:50:49.465736
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from .console import console, parser
    args = parser().parse_args(['kivy_base', '--debug', '--dry'])
    ret = console(args)
    assert ret == []


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-21 09:51:00.139494
# Unit test for function gen_api
def test_gen_api():
    from unittest import TestCase, mock
    from collections import namedtuple
    from pytest import raises

    logger.setLevel(4)

    TestName = namedtuple('TestName', 'name, title')

# Generated at 2022-06-21 09:51:09.571685
# Unit test for function loader
def test_loader():
    """Test module loader."""
    import os
    import shutil
    import tempfile
    import importlib.util as util
    import tempfile
    from unittest.mock import patch

    def _make_file(path: str, code: str):
        with open(path, 'w+') as f:
            f.write(code)

    pwd = tempfile.mkdtemp()
    os.makedirs(os.path.join(pwd, 'pack', 'sub'))
    _make_file(os.path.join(pwd, 'pack', '__init__.py'), '')
    _make_file(os.path.join(pwd, 'pack', 'pack.py'), '"""Root level"""\n')

# Generated at 2022-06-21 09:51:15.561566
# Unit test for function walk_packages
def test_walk_packages():
    from .gen_path import gen_path
    from multiprocessing import freeze_support
    freeze_support()
    for _, doc in gen_api(gen_path("packages")):
        if not doc.strip():
            pass
        else:
            # It seems that the VScode markdown previewer has some limitations.
            print("=" * 24)
            print(doc)

# Generated at 2022-06-21 09:51:21.529034
# Unit test for function gen_api
def test_gen_api():
    def _check(root: str, level: int, link: bool, toc: bool) -> bool:
        return gen_api({'Test': root}, pwd=dirname(__file__),
                       prefix='docs', level=level, link=link, toc=toc, dry=True)

    assert _check('test_api', 1, True, False)
    assert _check('test_api', 2, True, False)
    assert _check('test_api', 1, False, False)
    assert _check('test_api', 1, True, True)
    assert _check('test_api', 2, True, True)

# Generated at 2022-06-21 09:52:38.224504
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os.path import exists
    from .compiler import gen_api
    from .logger import logger
    from .utils import check_file_content
    from .my_types import StringDict
    
    logger.setLevel('ERROR')
    with TemporaryDirectory() as d:
        gen_api(
            StringDict({
                'My Docs': 'pyslvs_ui',
                'Package Docs': 'pyslvs_ui',
            }),
            join(d, 'site-packages'),
            prefix=join(d, 'docs'),
            dry=True
        )
        dir_name = 'site-packages'
        assert exists(join(d, dir_name))
        rmtree(join(d, dir_name))


# Generated at 2022-06-21 09:52:45.559201
# Unit test for function loader
def test_loader():
    from .compiler import _load_module, Parser

    def _m():
        """Docstring."""
        pass

    name = __name__ + ".test_loader"
    p = Parser.new()
    assert _load_module(name, __file__, p)
    assert name in p.docs
    assert p.docs[name].__doc__ == _m.__doc__
    name = __name__ + ".test_loader_no_doc"
    assert not _load_module(name, __file__, p)
    assert name not in p.docs

# Generated at 2022-06-21 09:52:50.609430
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import relpath
    from pkgutil import walk_packages
    # Test with pkgutil
    for _, name, _ in walk_packages(path=['pyslvs']):
        print(name)
    for _, name, _ in walk_packages(path=['pyslvs_ui']):
        print(name)
    # Test with function walk_packages
    for name, path in walk_packages(root='ui', path='.'):
        print(name, relpath(path))



# Generated at 2022-06-21 09:52:54.271880
# Unit test for function gen_api
def test_gen_api():
    assert gen_api(
        {'matplotlib': 'matplotlib', 'numpy': 'numpy'},
        pwd='site-packages',
        dry=True
    )

# Generated at 2022-06-21 09:53:05.424342
# Unit test for function walk_packages

# Generated at 2022-06-21 09:53:14.234098
# Unit test for function walk_packages
def test_walk_packages():
    """test_walk_packages"""
    from os.path import exists, join
    from os import getcwd, chdir, remove
    from shutil import rmtree
    from tempfile import mkdtemp

    _old_pwd = getcwd()
    _temp_dir = mkdtemp()
    chdir(_temp_dir)

# Generated at 2022-06-21 09:53:24.509566
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch
    from collections import defaultdict
    from io import StringIO
    from pathlib import Path

    def create_mock_package(path: Path, module_name: str, level: int = 0) -> None:
        """Create a mock python package."""
        path.mkdir(parents=True)
        spec_list = [f"from {module_name} import a"]
        for i in range(level):
            for j in range(2):
                sub_module_name = module_name + f".sub{i}_{j}"
                Path(path / f"sub{i}_{j}.py").write_text(
                    "\n".join(spec_list).format(sub_module_name)
                )
    # Create mock package structure

# Generated at 2022-06-21 09:53:27.574847
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader("pyslvs", ".", True, 2, True)
    _write("example.md", doc)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-21 09:53:36.401303
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from os.path import isdir, isfile, join
    from .test_cases import gen_test_case

    with TemporaryDirectory() as temp_dir:
        api_dir = join(temp_dir, 'docs')
        assert not isdir(api_dir)
        docs = gen_api({'test': 'pyslvs'}, dry=True, pwd=temp_dir)
        assert isdir(api_dir)
        assert not isfile(join(api_dir, 'test-api.md'))

        gen_test_case(temp_dir)
        docs = gen_api({'test': 'pyslvs'}, pwd=temp_dir)
        assert isfile(join(api_dir, 'test-api.md'))


# Generated at 2022-06-21 09:53:38.477590
# Unit test for function loader
def test_loader():
    name = "pyslvs_ui"
    pwd = "P:/lib"
    print(loader(name, pwd, link=True, level=1, toc=False))

# Generated at 2022-06-21 09:54:22.514449
# Unit test for function gen_api
def test_gen_api():
    from unittest.mock import Mock
    from pyslvs import __path__
    pwd = __path__[0]
    p = Parser(Mock(), Mock(), Mock())
    assert isinstance(gen_api({"Library": "pyslvs"}, pwd), list)
    assert isinstance(gen_api({"Library": "pyslvs"}, pwd, dry=True), list)

# Generated at 2022-06-21 09:54:30.509328
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy

    with TemporaryDirectory() as path:
        files = {
            'test.py': '"""Test."""',
            'test.pyi': '"""Test."""',
            'a.py': '"""Test."""',
            'a/b/c.py': '"""Test."""',
        }
        for name, body in files.items():
            with open(join(path, name), 'w', encoding='utf-8') as f:
                f.write(body)
        print("Test original.")
        for name, path in walk_packages('test', path):
            print(name, sep, path)
        # Copy other python code
        print("Test override.")

# Generated at 2022-06-21 09:54:33.225806
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({'NumPy': 'numpy'})

test_gen_api()

# Generated at 2022-06-21 09:54:42.569283
# Unit test for function gen_api
def test_gen_api():
    root_names = {'Pyslvs': 'pyslvs_ui'}
    pwd = '.'
    prefix = '__api__'
    link = True
    level = 1
    toc = False
    dry = False
    docs = gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)

# Generated at 2022-06-21 09:54:49.211715
# Unit test for function loader
def test_loader():
    class FakeModule:
        """Fake module."""
        pass

    class FakeLoader(Loader):
        """Fake loader."""

        def exec_module(self, m: FakeModule):
            m.__doc__ = "# Fake Module"
            m.__foo = "foo"
            m.__bar = "bar"

    def fake_find_spec(name: str) -> Loader:
        """Fake find_spec."""
        return FakeLoader()
    from unittest.mock import patch
    from pkgutil import get_importer
    from .parser import Parser
    p = Parser()
    with patch('importlib.util.find_spec', new=fake_find_spec):
        _load_module('foo.bar', '', p)

# Generated at 2022-06-21 09:54:54.364126
# Unit test for function walk_packages
def test_walk_packages():
    r = []
    for name, path in walk_packages("pyslvs", "../.."):
        r.append(name)

# Generated at 2022-06-21 09:55:01.527464
# Unit test for function loader
def test_loader():  # pragma: no cover
    p = Parser.new(False, -1, False)
    loader("dynawind", ".dynawind/venv/lib/python3.7/site-packages", p)
    loader("dynawind", ".dynawind/venv/lib/python3.7/site-packages", p)
    loader("pyslvs", ".pyslvs/venv/lib/python3.7/site-packages", p)
    loader("pyslvs", ".pyslvs/venv/lib/python3.7/site-packages", p)
    loader("pyslvs_ui", ".pyslvs_ui/venv/lib/python3.7/site-packages", p)

# Generated at 2022-06-21 09:55:10.674810
# Unit test for function walk_packages
def test_walk_packages():
    root = 'tests.test-packages'
    path = 'tests/test-packages'

# Generated at 2022-06-21 09:55:20.902457
# Unit test for function loader
def test_loader():
    class FakeLoader(object):
        def exec_module(self, module):
            module.__doc__ = r"""
                A test description.

                A test description.

                A test description.

                A test description.

                """
            module.__all__ = ('a', 'b', 'c')
    def import_module(name: str) -> None:
        module = module_from_spec(spec_from_file_location(name, ""))
        module.__loader__ = FakeLoader()
        module.__loader__.exec_module(module)
    logger.info('=' * 12)
    logger.info(loader('test', './test', link=False, level=1))
    logger.info('=' * 12)
    logger.info(loader('test', './test', link=True, level=1))
   

# Generated at 2022-06-21 09:55:32.301780
# Unit test for function loader
def test_loader():
    def _m(doc: str, ext: str) -> str:
        return f"def __module_doc__():\n    return {repr(doc)}\n"

    class _mock_module:
        docstring = 'test doc'

    def _load_stub(*_) -> _mock_module:
        return _mock_module()

    class _mock_loader:
        def exec_module(self, m: object) -> None:
            m.__module_doc__ = _load_stub
            m.__doc__ = self.__doc__

        def __init__(self, doc: str) -> None:
            self.__doc__ = doc

    # test walk_packages

# Generated at 2022-06-21 09:56:28.829065
# Unit test for function loader
def test_loader():
    from unittest import TestCase, main

    class TestCompiler(TestCase):

        def test_loader(self):
            parser = Parser.new(True, 1, False)
            pwd = parent(__file__)
            for name, path in walk_packages("compiler", pwd):
                if name != "compiler.compiler":
                    continue
                parser.parse(name, _read(path + ".py"))
            self.assertIn("compiler.compiler", parser.doc)
            self.assertIn("Compiler functions.", parser.doc['compiler.compiler'])
            self.assertIn("compiler.compiler.test_loader", parser.doc)
            self.assertIn("Unit test for function loader", parser.doc['compiler.compiler.test_loader'])

# Generated at 2022-06-21 09:56:31.600825
# Unit test for function gen_api
def test_gen_api():
    gen_api(dict(solvespace="solvespace"), dry=True)
    gen_api(dict(pyslvs="pyslvs"), dry=True)

# Generated at 2022-06-21 09:56:39.446814
# Unit test for function loader
def test_loader():
    """Function loader test."""
    p = Parser.new(False, 1, False)
    p.parse('pyslvs', '''
        # Configuration file
        class Config:
            """Configuration base class."""
            def __init__(self, **kwargs):
                """Update the default registry."""
    ''')

# Generated at 2022-06-21 09:56:49.156616
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove, rmdir
    from os.path import join, sep
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase, main

    class WalkPackagesTests(TestCase):

        def setUp(self):
            self.path = mkdtemp()

        def tearDown(self):
            rmtree(self.path, True)

        def test_root(self):
            self.assertEqual(list(walk_packages('name', self.path)), [])

        def test_root_init_py(self):
            s = join(self.path, '__init__.py')
            open(s, 'w+').close()
            self.assertEqual(list(walk_packages('name', self.path)), [])


# Generated at 2022-06-21 09:56:58.287884
# Unit test for function loader
def test_loader():
    name, path = next(walk_packages('pyslvs', 'pyslvs'))
    assert name == 'pyslvs'
    assert path.endswith('/pyslvs/__init__.py')

    name, path = next(walk_packages('pyslvs', 'pyslvs_ui'))
    assert name == 'pyslvs_ui.model'
    assert path.endswith('/pyslvs_ui/model.py')

    name, path = next(walk_packages('pyslvs', 'pyslvs_ui'))
    assert name == 'pyslvs_ui.model'
    assert path.endswith('/pyslvs_ui/model.pyi')


# Generated at 2022-06-21 09:57:01.675468
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    gen_api({
        "SLVS-Qt": "SLVSQt",
        "SLVS-Qt": "SLVSQt",
    },
            pwd=parent(__file__),
            dry=True)



# Generated at 2022-06-21 09:57:11.814736
# Unit test for function walk_packages
def test_walk_packages():
    from os import makedirs
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp:
        tmp += '/pkg'
        makedirs(join(tmp, 'a'))
        makedirs(join(tmp, 'a', 'b'))
        makedirs(join(tmp, 'x'))
        makedirs(join(tmp, 'x', 'y'))
        with open(join(tmp, 'a', 'x.py'), 'w+') as f:
            f.write("print('It works')")
        with open(join(tmp, 'a', 'b', 'y.py'), 'w+') as f:
            f.write("print('It works')")

# Generated at 2022-06-21 09:57:14.044055
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages."""
    for name, path in walk_packages("sims", "sims"):
        print(name, path)

# Generated at 2022-06-21 09:57:16.500384
# Unit test for function loader
def test_loader():
    print(loader('sys', '/usr/local/lib/python3.9', False, 0, False))


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-21 09:57:21.640267
# Unit test for function gen_api
def test_gen_api():
    api = gen_api({"unit test": "unittest"}, dry=True)
    assert len(api) == 1
    assert api[0].strip().endswith('2.TestCase.assertEqual(first, second, msg=None)')
    assert "TestCase.skipTest()" not in api[0]

if __name__ == '__main__':
    test_gen_api()