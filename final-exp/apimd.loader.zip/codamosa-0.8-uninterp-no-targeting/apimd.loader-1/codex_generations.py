

# Generated at 2022-06-21 09:50:02.846896
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    f = []
    for name, _ in walk_packages("test_compiler", "tests"):
        f.append(name)
    assert "test_compiler.api" in f
    assert "test_compiler.__init__" in f
    assert "test_compiler.package.api" in f
    assert "test_compiler.package" in f
    assert "test_compiler.package.__init__" in f
    assert "test_compiler.package.subpackage.api" in f
    assert "test_compiler.package.subpackage" in f
    assert "test_compiler.package.subpackage.__init__" in f

# Generated at 2022-06-21 09:50:08.216893
# Unit test for function gen_api
def test_gen_api():
    root_names = {
        'pyslvs': 'pyslvs',
    }
    docs = gen_api(root_names, pwd=__file__, dry=True)
    assert all(d.startswith('##') for d in docs)

if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:50:12.185798
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    assert len(_site_path('numpy')) > 0
    assert len(_site_path('non-exist-module')) == 0
    assert 'def' in loader('pyslvs', 'pyslvs', True, 1, False)

# Generated at 2022-06-21 09:50:13.818063
# Unit test for function gen_api
def test_gen_api():
    # TODO
    pass

# Generated at 2022-06-21 09:50:17.812045
# Unit test for function gen_api
def test_gen_api():
    """Demo for function gen_api."""
    gen_api({
        "Pyslvs": "pyslvs",
        "Pyslvs-UI": "pyslvs_ui",
    }, dry=True)

# Generated at 2022-06-21 09:50:28.252868
# Unit test for function walk_packages
def test_walk_packages():
    from unittest.mock import patch
    from types import ModuleType
    _ = spec_from_file_location
    find_spec_mocked = (
        patch('importlib.util.find_spec')
    )
    spec_from_file_location_mocked = (
        patch('importlib.util.spec_from_file_location')
    )
    module_from_spec_mocked = (
        patch('importlib.util.module_from_spec')
    )
    name = 'test_walk_packages'
    pwd = 'tests'
    path = join(pwd, name)
    valid = (path, path + PEP561_SUFFIX)
    root = path + PEP561_SUFFIX + sep
    main = ModuleType('__main__')

# Generated at 2022-06-21 09:50:39.425579
# Unit test for function walk_packages
def test_walk_packages():
    import shutil
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as t:
        root = join(t, 'foo')
        mkdir(root)
        with open(join(root, '__init__.py'), 'w') as f:
            f.write('')
        for i in range(10):
            with open(join(root, f'{i}.py'), 'w') as f:
                f.write(f'def foo{i}() -> int:\n    return {i}')
        for i in range(10, 15):
            with open(join(root, f'{i}.pyi'), 'w') as f:
                f.write(f'def foo{i}() -> int: ...')
        shutil.copytree(root, join(t, 'foo-stubs'))


# Generated at 2022-06-21 09:50:47.804843
# Unit test for function walk_packages

# Generated at 2022-06-21 09:50:51.554301
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    p = [p for p in walk_packages("test", ".") if p[1].endswith(('test.py', 'test.pyi'))]
    assert len(p) == 1, "walk packages error"

# Generated at 2022-06-21 09:50:54.542895
# Unit test for function gen_api
def test_gen_api():
    assert len(gen_api({"test": "test"})) == 1
    assert len(gen_api({"test": "test", "test1": "test1"})) == 2
    assert len(gen_api({"test": "test", "test2": "test2"})) == 2
    assert len(gen_api({"test": "test", "test1": "test1"}, dry=True)) == 2
    assert len(gen_api({"test": "test", "test2": "test2"}, dry=True)) == 2

# Generated at 2022-06-21 09:52:52.318284
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from importlib import import_module
    from pathlib import Path
    from os import remove
    from os.path import realpath, dirname, isfile
    from .logger import log_set
    from pkg_resources import resource_filename

    log_set(9)
    script = dirname(realpath(__file__))
    to = Path(resource_filename(import_module('pyslvs_ui'), '..'))
    to /= 'docs'
    assert to.exists()
    # Test gen_api basic
    docs = gen_api({'Test': 'test'}, script, to)
    api = to / 'test-api.md'
    assert isfile(api)
    assert docs[0] == _read(api)
    remove(api)
   

# Generated at 2022-06-21 09:53:04.539504
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .examples.functions import example
    p = Parser.new(False, 1, False)
    for name, path in walk_packages(example.__name__, example.__path__[0]):
        # Load its source or stub
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        # Try to load module here

# Generated at 2022-06-21 09:53:13.175927
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages."""
    assert list(walk_packages('geom3d', '../__init__.py')) == [
        ('geom3d.geom', '../geom.py'),
        ('geom3d.partial', '../partial.py'),
        ('geom3d.partial', '../partial.pyi'),
        ('geom3d.structure', '../structure.py'),
        ('geom3d.structure', '../structure.pyi'),
        ('geom3d.solver', '../solver.py'),
        ('geom3d.solver', '../solver.pyi'),
    ]
    assert list(walk_packages('geom3d', '../../.git')) == []

# Generated at 2022-06-21 09:53:23.544863
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('test', '.')) == \
        [('test', './test'),
         ('test.foo_bar', './test/foo_bar'),
         ('test.foo_bar.spam', './test/foo_bar/spam')]
    assert list(walk_packages('test', 'test')) == \
        [('test', 'test/test'),
         ('test.foo_bar', 'test/test/foo_bar'),
         ('test.foo_bar.spam', 'test/test/foo_bar/spam')]

# Generated at 2022-06-21 09:53:30.395336
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api"""
    import pyslvs_ui
    from .misc import remove_prefix
    from .logger import init_logging
    init_logging()
    prefix = "a"
    docs = gen_api({"Pyslvs-ui": "pyslvs_ui"}, pwd=remove_prefix(pyslvs_ui.__file__, "pyslvs_ui"), prefix=prefix, dry=True)
    assert len(docs) == 1

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-21 09:53:38.276089
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from os.path import dirname
    from os import sep
    p = Parser.new(link=True, level=1, toc=False)
    for name, path in list(walk_packages('test', dirname(__file__))):
        # Load source first
        path += ".py"
        if not isfile(path):
            continue
        logger.debug(f"{name} <= {path}")
        p.parse(name, _read(path))
    doc = p.compile()
    assert "pyslvs" in doc
    assert "pyslvs_ui" in doc
    for name in ['compiler', 'logger', 'parser', 'structures']:
        assert 'module' in doc
        assert name in doc

# Generated at 2022-06-21 09:53:45.497840
# Unit test for function loader
def test_loader():
    """Function loader :func:`loader`.
    >>> loader("asyncio", "/home/user/.local/lib/python3.8/site-packages", True)
    '# asyncio API\\n\\n## asyncio\\n\\n### asyncio.iscoroutinefunction(obj)\\n[source](https://github.com/python/cpython/blob/3.8/Lib/asyncio/__init__.py#L1758)\\n'
    """
    pass

# Generated at 2022-06-21 09:53:53.110270
# Unit test for function loader
def test_loader():
    p = Parser.new(False, 1, False)
    assert _load_module("pyslvs", "pyslvs.pyslvs", p)
    assert _load_module("pyslvs", "pyslvs.__init__", p)
    assert _load_module("pyslvs", "pyslvs.pyslvs.pyslvs_extra", p)
    assert _load_module("pyslvs", "pyslvs.pyslvs.pyslvs_extra.pyslvs_extra", p)
    assert _load_module("pyslvs", "pyslvs.pyslvs.pyslvs_core", p)

# Generated at 2022-06-21 09:54:01.981658
# Unit test for function gen_api
def test_gen_api():
    from os import getcwd
    from pkgutil import walk_packages
    from tempfile import TemporaryDirectory
    from shutil import copytree
    for item in walk_packages([], 'pyslvs_ui'):
        if item.name in ['pyslvs_ui', 'pyslvs_ui.__main__']:
            continue
        package, _, _ = item
        docs = gen_api(dict(UI=package.name), pwd=getcwd())
        assert len(docs) == 1 and docs[0].startswith(f"# UI API\n\n")
        with TemporaryDirectory() as pwd:
            copytree(package.path, pwd)
            sys_path.append(pwd)
            docs = gen_api(dict(UI=package.name), pwd=pwd)


# Generated at 2022-06-21 09:54:04.267964
# Unit test for function walk_packages
def test_walk_packages():
    import pkgutil
    import pyslvs
    assert _site_path('pyslvs') == dirname(pkgutil.get_loader('pyslvs').filename)
    asser