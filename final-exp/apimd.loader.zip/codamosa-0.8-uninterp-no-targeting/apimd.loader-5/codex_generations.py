

# Generated at 2022-06-21 09:49:40.385721
# Unit test for function walk_packages
def test_walk_packages():
    """Test function `walk_packages`."""
    names = []
    for name, path in walk_packages('file_scanner', '../pyslvs_ui'):
        names.append(name)
    assert names
    assert 'file_scanner.__init__' in names
    assert 'file_scanner.main_window' in names
    assert 'file_scanner.main_window.__init__' in names
    assert 'file_scanner.main_window.error_dialog' in names



# Generated at 2022-06-21 09:49:45.283075
# Unit test for function gen_api
def test_gen_api():
    print("============= Compiler test =============\n")
    from sys import path_importer_cache
    path_importer_cache.clear()
    docs = gen_api({'Pyslvs': 'pyslvs'}, dry = True)
    assert docs[0]

# Generated at 2022-06-21 09:49:54.103813
# Unit test for function walk_packages
def test_walk_packages():
    from importlib import reload
    from pathlib import Path
    from .settings import Settings
    from shutil import rmtree

    s = Settings()
    inst = s.instance
    s.data.setdefault('file_path', dict())['pwd'] = inst.storage_path
    test_path = Path(inst.storage_path) / 'test'
    test_path.mkdir()
    (test_path / 'test.py').write_text('test_1 = 1')
    (test_path / 'test.pyi').write_text('test_2: int = 2')
    (test_path / 'test_dir').mkdir()
    (test_path / 'test_dir' / 'test.py').write_text('test_3 = 3')

# Generated at 2022-06-21 09:49:58.577275
# Unit test for function loader
def test_loader():
    from .python_docs import PYTHON_DOCS
    from tempfile import TemporaryDirectory
    from shutil import copy
    from os.path import basename
    from zlib import compress
    from unittest.mock import patch
    from importlib import import_module

    def _exec(m):
        """Mock the exec statement."""
        if m in PYTHON_DOCS:
            return None
        m_n = m.__name__.split('.', 1)[-1]
        if m_n in PYTHON_DOCS:
            m.__doc__ = PYTHON_DOCS[m_n]
            return None
        return import_module(m.__name__)


# Generated at 2022-06-21 09:50:03.184330
# Unit test for function gen_api
def test_gen_api():
    pwd = 'examples'
    docs = gen_api({'svgx', 'matplotlib'}, pwd, dry=True)
    assert len(docs) == 2
    assert all(doc.splitlines()[1].startswith('#') for doc in docs)

test_gen_api()

# Generated at 2022-06-21 09:50:07.745607
# Unit test for function gen_api
def test_gen_api():
    assert isinstance(
        gen_api(
            {"Pyslvs-Core": "pyslvs"},
            None,
            prefix="docs",
            link=False,
            level=2,
            dry=True,
        ),
        list
    )

# Generated at 2022-06-21 09:50:17.331860
# Unit test for function loader
def test_loader():
    t = """
#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pyslvs import __about__

__author__ = __about__.author
__copyright__ = __about__.copyright
__license__ = __about__.license
__version__ = __about__.version
__email__ = __about__.email
__status__ = __about__.status
"""
    logger.debug(loader('pyslvs', sep + 'mnt' + sep + 'd' + sep + 'anaconda3' + sep + 'lib' + sep + 'site-packages', True, 1, True))

# Generated at 2022-06-21 09:50:22.963286
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk packages."""
    import shutil
    from os.path import dirname, exists
    from tempfile import TemporaryDirectory
    from .logger import logger

    def mkdir(path: str, *files: Sequence[str]) -> None:
        """Create the directory and files."""
        for f in files:
            with open(path + f, 'w'):
                pass
        assert exists(path)

    # Test without create dir
    with TemporaryDirectory(dir=".") as t:
        logger.debug(f"tempdir: {t}")
        assert not exists(t + "/a")
        assert list(walk_packages('a', t)) == []

    # Test create dir
    with TemporaryDirectory(dir=".") as t:
        logger.debug(f"tempdir: {t}")

# Generated at 2022-06-21 09:50:32.368819
# Unit test for function gen_api
def test_gen_api():
    import random
    import tempfile
    from shutil import rmtree
    from pkgutil import walk_packages

    def random_string(n: int = 10) -> str:
        s = ""
        for _ in range(n):
            s += chr(random.randint(65, 122))
        return s

    def random_pkg(path: str, n: int = 5):
        for i in range(n):
            name = random_string()
            mkdir(f"{path}{sep}{name}")
            init = open(f"{path}{sep}{name}{sep}__init__.py", "w")
            init.write(f"A_{random_string()}")
            init.close()
            mkdir(f"{path}{sep}{name}{sep}stubs")


# Generated at 2022-06-21 09:50:43.416385
# Unit test for function gen_api
def test_gen_api():
    from os import rmdir, remove
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import dirname

    def _compare(a, b):
        a = a.replace('\r\n', '\n')
        b = b.replace('\r\n', '\n')
        return a == b

    with TemporaryDirectory() as pwd:
        pwd = abspath(pwd)
        py_path = abspath(dirname(__file__))
        copytree(f"{py_path}{sep}test_module", f"{pwd}{sep}test")

# Generated at 2022-06-21 09:52:01.062897
# Unit test for function loader
def test_loader():
    from sys import path as p
    p.append('test')
    import os
    import sys
    assert sys.platform in ('win32', 'win64', 'linux', 'darwin')
    assert all(os.name == ('nt', 'posix')[platform == 'linux'])
    root = 'test.test_package'
    path = './test/test_package'
    pkg = 'test.test_package'
    resp = loader(root, path, False, 1, False)
    assert (f"{pkg}.a" in resp)
    assert ("```python\n" in resp)
    assert ("## Class *A*\n" in resp)
    assert ("### A.b" in resp)
    assert ("### A.c" in resp)

# Generated at 2022-06-21 09:52:04.293906
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    for n, p in walk_packages('tensorflow', abspath('./')):
        p.parse(_read(p))
    p.compile()

# Generated at 2022-06-21 09:52:10.352983
# Unit test for function gen_api
def test_gen_api():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from pkg_resources import parse_version
    from importlib.util import module_from_spec, spec_from_loader, find_spec
    from textwrap import dedent

    def _mk_module(name, loader, code):
        spec = spec_from_loader(name, loader)
        module = module_from_spec(spec)
        loader.exec_module(module)
        exec(code, module.__dict__)
        return module

    def _load_module(name, path, loader=None, code=''):
        if loader is None:
            loader = spec_from_file_location('temp', path).loader
        return _mk_module(name, loader, code)

    def _load_file(name, path):
        loader = spec_from

# Generated at 2022-06-21 09:52:20.655893
# Unit test for function walk_packages
def test_walk_packages():
    """Test the walk_packages()."""
    names = set(n for n, _ in walk_packages('pyslvs', '..'))

# Generated at 2022-06-21 09:52:26.286695
# Unit test for function loader
def test_loader():
    logger.handlers[:] = []
    import pyslvs_ui
    logger.addHandler(logger.handlers[0])
    loader('pyslvs_ui', dirname(abspath(pyslvs_ui.__file__)), True, 1, True)
    logger.handlers[:] = []
    import pyslvs
    logger.addHandler(logger.handlers[0])
    loader('pyslvs', dirname(abspath(pyslvs.__file__)), True, 1, True)


# Generated at 2022-06-21 09:52:32.634201
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory

# Generated at 2022-06-21 09:52:33.395616
# Unit test for function loader
def test_loader():
    from .test.test_docs import *
    pytest.main()

# Generated at 2022-06-21 09:52:41.291101
# Unit test for function gen_api
def test_gen_api():
    logger.info('=' * 12)
    logger.info('Testing function gen_api:')
    logger.info('\tCurrent directory: ' + dirname(abspath(__file__)))
    logger.info('\tSite-packages directory: ' + _site_path('pyslvs'))
    root_names = {"PySLVS": "pyslvs", "Jupyter": "pyslvs_ui"}
    docs = gen_api(root_names, prefix="docs_api", dry=True)
    logger.info('=' * 12)
    for doc in docs:
        logger.info(doc)


# Generated at 2022-06-21 09:52:49.537233
# Unit test for function gen_api
def test_gen_api():
    from os import remove
    from os.path import dirname
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from urllib.request import urlretrieve

    def test_case(*, prefix, pwd, name, title, link=True, level=1, toc=False):
        assert gen_api({title: name}, pwd, prefix=prefix, link=link, level=level, toc=toc)


# Generated at 2022-06-21 09:53:01.296922
# Unit test for function walk_packages
def test_walk_packages():
    from importlib import import_module, invalidate_caches

    # Ignore error, it's the test
    invalidate_caches()

    def import_test(name):
        try:
            return import_module(name)
        except ImportError:
            return None

    import mock
    import_module = mock.Mock(side_effect=import_test)

    import pyslvs as _
    import pyslvs_ui
    assert import_module.call_args_list == [
        mock.call('pyslvs'),
        mock.call('pyslvs_ui'),
    ]


# Generated at 2022-06-21 09:54:32.430347
# Unit test for function gen_api
def test_gen_api():
    from io import StringIO
    from contextlib import redirect_stdout

    out = StringIO()
    with redirect_stdout(out):
        from .test.test_api import (
            root_names,
            pwd,
            prefix,
            link,
            level,
            toc,
            dry
        )
        gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)

# Generated at 2022-06-21 09:54:37.020251
# Unit test for function gen_api
def test_gen_api():
    from pyslvs import __version__

    docs = gen_api({"Pyslvs": "pyslvs"}, dry=True)
    print(docs)
    assert docs[0].startswith(f"# PySLVS {__version__}\n\n## Pyslvs API")

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-21 09:54:45.100996
# Unit test for function gen_api
def test_gen_api():
    from os import getcwd, chdir
    from os.path import dirname
    from shutil import rmtree
    from pyslvs import __path__ as pyslvs_path
    pwd = dirname(pyslvs_path[0])
    prefix = "docs"
    rmtree(prefix)
    gen_api({
        "PySLVS": "pyslvs",
        "PySLVS-Core": "pyslvs_core",
        "PySLVS-UI": "pyslvs_ui"
    }, pwd, prefix=prefix, dry=True)
    gen_api({
        "PySLVS": "pyslvs"
    }, pwd, prefix=prefix, dry=True)

# Generated at 2022-06-21 09:54:50.211102
# Unit test for function loader
def test_loader():
    content = [
        "# titile",
        "```python",
        "def f() -> None: ...",
        "```",
        '```python-class',
        "class C: ...",
        "```",
    ]
    assert loader('root', '.', False, 1, False) == '\n'.join(content)


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-21 09:54:51.655824
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({
        "API name": "root_name"
    })

# Generated at 2022-06-21 09:54:59.643813
# Unit test for function loader
def test_loader():
    """Test loader function."""
    logger.warning("Warning message.")
    logger.info("Info message.")
    logger.debug("Debug message.")
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', 'pyslvs'):
        p.parse(name, _read(path + '.pyi'))
    doc = p.compile()
    logger.info(doc)
    assert "pyslvs.core" in doc
    assert "pyslvs.core.compiler" in doc
    assert "pyslvs.core.parse" in doc
    assert "pyslvs.core.parse.parser" in doc
    assert "pyslvs.io.slvs" in doc

# Generated at 2022-06-21 09:55:09.428833
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    from os.path import split
    
    class TestWalkPackages(unittest.TestCase):
        def test_package(self):
            packages = set()
            for name, path in walk_packages('pyslvs', pwd):
                packages.add(name)
                self.assertEqual(path, join(pwd, name.replace('.', sep)))
            self.assertTrue({'pyslvs', 'pyslvs.graphics', 'pyslvs.io'}.issubset(packages))
            self.assertEqual(len(packages), 3)

    pwd = split(abspath(__file__))[0]

# Generated at 2022-06-21 09:55:19.946802
# Unit test for function walk_packages
def test_walk_packages():
    from collections import Counter
    from shutil import rmtree
    path = join(dirname(__file__), '..', '..', 'tests', 'walk_packages')
    c = Counter()

    def t(name: str, path: str) -> None:
        assert path.startswith(path)
        c[name] += 1

    def t2(name: str, path: str) -> None:
        if name == 'P.x':
            assert path == join(path, 'P', 'x.pyi')
        elif name == 'P.y':
            assert path == join(path, 'P', 'y.py')
        else:
            assert name == 'P'
            assert path == join(path, 'P', '__init__.py')


# Generated at 2022-06-21 09:55:31.052655
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os.path import join
    from PIL import Image

    # Generate temp files
    with TemporaryDirectory() as tmpdir:
        copytree(f"{dirname(__file__)}/temp", tmpdir)

        def convert(image_name: str, image_format: str) -> None:
            Image.open(join(tmpdir, image_name)).save(join(tmpdir, f'{image_name}.{image_format}'))

        # Convert png to gif and jpeg
        convert('a.png', 'gif')
        convert('a.png', 'jpeg')

        # Create __init__.py for package 'c'
        with open(join(tmpdir, 'c', '__init__.py'), 'w'):
            pass

# Generated at 2022-06-21 09:55:39.033382
# Unit test for function gen_api
def test_gen_api():
    # type: () -> None
    """Small unit test for function gen_api."""
    from unittest.mock import patch
    from pathlib import Path

    p = Path(__file__)
    with patch('sys.path', new=sys_path), \
            patch('builtins.Exception', Exception), \
            patch('builtins.print', logger.warning), \
            patch('builtins.open', lambda path, mode: None):
        # No output
        gen_api({'NoImport': 'no_import'})
        # Cannot found package
        gen_api({'NoImport': 'no_import'}, p.parent)
        # Cannot found module
        gen_api({'NoImport': 'noimport'}, p.parent)
        # Import error