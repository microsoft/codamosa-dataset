

# Generated at 2022-06-21 09:49:30.659893
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import copy

    with TemporaryDirectory() as tmp_path:
        path = abspath(tmp_path)
        mkdir(path + r"\pkg")
        copy("pyslvs.py", path + r"\pkg\module.py")
        walk_result = list(walk_packages("pkg.module", path))
        assert walk_result[0][0] == 'pkg.module'
        mkdir(path + r"\pkg\pyslvs")
        copy("pyslvs.py", path + r"\pkg\pyslvs\__init__.py")
        walk_result = list(walk_packages("pkg.pyslvs", path))
        assert walk_result[0][0] == 'pkg.pyslvs'

# Generated at 2022-06-21 09:49:41.424580
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .parser import Parser
    from .parser import parent
    from .parser import build_link
    from .parser import build_toc
    root = "pyslvs"
    pwd = _site_path(root)
    link = True
    level = 1
    toc = True
    p = Parser.new(link, level, toc)
    for name, path in walk_packages(root, pwd):
        if parent(name) != "pyslvs":
            break
        logger.debug(f"{name} <== {path}")
        # Load its source or stub
        for ext in ['.py', '.pyi']:
            path_ext = path + ext
            if not isfile(path_ext):
                continue

# Generated at 2022-06-21 09:49:51.392307
# Unit test for function gen_api
def test_gen_api():
    # gen_api({"pyslvs": "pyslvs"}, link=False, toc=True, level=2)
    # gen_api({"pyslvs": "pyslvs"}, link=True, toc=True, level=2)
    # gen_api({"pyslvs": "pyslvs"}, link=True, toc=False, level=2)
    # gen_api({"pyslvs": "pyslvs"}, dry=True)
    print(gen_api({"pyslvs": "pyslvs"}))
    # print(gen_api({
    #     "pyslvs": "pyslvs",
    #     "vpoint": "pyslvs_vpoint",
    #     "vlink": "pyslvs_vlink",


# Generated at 2022-06-21 09:50:02.846413
# Unit test for function loader
def test_loader():
    """Test for loader function."""
    from .utils import copy_file
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    with TemporaryDirectory() as tmp:
        copy_file("venv-path.py", "venv-path.pyi", tmp)
        docs = loader("venv_path", tmp, False, 1, False)
    assert docs == '# venv_path\n' \
        '\n' \
        '## path\n' \
        '\n' \
        '`venv_path.path` is a list.\n' \
        '\n' \
        '## path1\n' \
        '\n' \
        '`venv_path.path1` is a list.'
    rmtree(tmp)

# Generated at 2022-06-21 09:50:14.678503
# Unit test for function walk_packages
def test_walk_packages():
    """Test for function walk_packages."""
    from unittest import TestCase, mock, main
    from unittest.mock import call

    with mock.patch('pyslvs_ui.project.utils.compiler.walk') as walk_mock:
        # walk() line
        walk_mock.return_value = (
            ('first/foo', [], ['__init__.py']),
            ('first/foo/second', [], ['hello.py']),
            ('first/foo/second/third', [], ['world.py']),
        )

        result = list(walk_packages('foo', 'first'))

        assert result == [('foo.second', 'first/foo/second/hello.py')]


# Generated at 2022-06-21 09:50:18.478985
# Unit test for function gen_api
def test_gen_api():
    root_names = {"PVGeo": "pvgeo", "PySlvs": "pyslvs"}
    try:
        gen_api(root_names)
        assert True
    except BaseException:
        assert False

# Generated at 2022-06-21 09:50:23.095506
# Unit test for function walk_packages
def test_walk_packages():
    """Test for walk_packages function."""
    assert tuple(walk_packages("__init__", "./_test")) == (
        ("__init__", "./_test/__init__.py"),
        ("__init__.c1", "./_test/__init__/c1.pyi"),
        ("__init__.c2", "./_test/__init__/c2.py"),
        ("__init__.c2.q", "./_test/__init__/c2/q.pyi"),
        ("__init__.c3", "./_test/__init__/c3.py"),
    )

# Generated at 2022-06-21 09:50:32.369838
# Unit test for function walk_packages
def test_walk_packages():
    from numpy import array
    r = list(walk_packages('numpy', _site_path('numpy') + sep + 'core'))

# Generated at 2022-06-21 09:50:36.327819
# Unit test for function gen_api
def test_gen_api():
    import pkg_resources
    pwd = abspath(dirname(pkg_resources.__file__))
    docs = gen_api(dict(
        PkgResources=pkg_resources.__name__,
        SysConfig=sys_path.__name__,
        Path=abspath.__name__
    ), pwd, dry=True)
    assert len(docs) == 3
    for d in docs:
        assert len(d.split('\n')) >= 3

# Generated at 2022-06-21 09:50:46.358599
# Unit test for function gen_api
def test_gen_api():
    import os
    import pkgutil
    import sys
    import pytest
    from tempfile import TemporaryDirectory
    # Prepare directories
    with TemporaryDirectory() as tmp:
        cwd = os.getcwd()
        os.chdir(tmp)
        with open('SConstruct', 'w+') as f:
            f.write('''
import os
env = Environment()
env.SharedLibrary('ext', 'ext.c')
env.Install('dist', 'ext.so')
env['SHLIBPREFIX'] = ''
env['SHOBJSUFFIX'] = ''
''')
        os.mkdir('dist')