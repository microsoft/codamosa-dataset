

# Generated at 2022-06-21 09:53:53.117467
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    doc = loader('src', '.', False, 2, False)
    assert len(doc.strip()) > 0

# Generated at 2022-06-21 09:54:02.011416
# Unit test for function walk_packages

# Generated at 2022-06-21 09:54:08.324439
# Unit test for function gen_api
def test_gen_api():
    gen_api({})
    gen_api({'Dummy': '__dummy__'})
    gen_api({'Dummy': '__dummy__'}, '~')
    gen_api({'Dummy': '__dummy__'}, '/')
    gen_api({'Dummy': '__dummy__'}, '/', dry=True)
    gen_api({'Dummy': '__dummy__'}, '~', dry=True)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:54:10.538745
# Unit test for function gen_api
def test_gen_api():
    """Generate API without parameters."""
    from .doc import DOC_LIST
    assert len(gen_api(DOC_LIST, dry=True)) == len(DOC_LIST)

# Generated at 2022-06-21 09:54:14.007458
# Unit test for function gen_api
def test_gen_api():
    f = gen_api({"qm", "qm_data"})
    assert f.__class__ is list
    assert len(f) == 2
    assert "/docs/qm-api.md" in f[0]
    assert "/docs/qm-data-api.md" in f[1]

# Generated at 2022-06-21 09:54:16.809366
# Unit test for function gen_api
def test_gen_api():
    """Single root test."""
    from . import test_api

    assert gen_api({'Test API': 'test_api'}, dirname(test_api.__file__))


# Generated at 2022-06-21 09:54:22.885234
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages test.

    script: pyslvs_ui
    ├── __init__.py
    ├── __init__.pyi
    └── canvas.py
    """
    path = abspath('./test/walk_packages')
    assert list(walk_packages('pyslvs_ui', path)) == [
        ('pyslvs_ui', path + sep + 'pyslvs_ui'),
        ('pyslvs_ui.canvas', path + sep + 'pyslvs_ui.canvas'),
    ]

# Generated at 2022-06-21 09:54:30.670691
# Unit test for function gen_api
def test_gen_api():
    from os import remove
    from tempfile import gettempdir
    from shutil import rmtree
    from .pyslvs_ui.core import ref_dir
    from .parser import Parser

    tmp_dir = gettempdir()
    s = Parser.new()

    def _test_api(
        title: str, pyslvs_path: str,
        prefix: str = '', link: bool = False, level: int = 1, toc: bool = False
    ) -> None:
        """Unit test for gen_api."""
        name = f"{pyslvs_path.replace('/', '.')}.__init__"
        doc = loader(name, ref_dir, link, level, toc)
        assert title in doc and doc.startswith('#' * level)

# Generated at 2022-06-21 09:54:36.024835
# Unit test for function loader
def test_loader():
    from json import loads
    from tempfile import TemporaryDirectory
    from shutil import copy
    from .__init__ import __file__ as __package__
    from .bake import create_stub_file, create_spec_file

    with TemporaryDirectory() as tmpdir:
        # Copy current package to tmpdir
        copy(__package__, tmpdir)
        # Create Spec file
        create_spec_file(tmpdir)
        # Create stub file
        create_stub_file(tmpdir)
        # Test the output of document
        doc = loader('pyslvs_ui', tmpdir, False, 3, False)
        doc_json = loads(doc)
        assert doc_json["name"] == "pyslvs_ui"
        assert doc_json["doc"] == "Parameter input dialog"

# Generated at 2022-06-21 09:54:44.904099
# Unit test for function walk_packages
def test_walk_packages():
    doc = """
    # Package docstring
    """
    path = 'testpkg'
    if isdir(path):
        raise RuntimeError(f"folder {path} exists, remove it first")
    mkdir(path)
    _write(f"{path}/__init__.py", doc)
    _write(f"{path}/__init__.pyi", doc)
    _write(f"{path}/module-stubs.pyi", doc)
    for i in range(3):
        doc = f"# Module level {i}\n" + doc
        _write(f"{path}/module-{i}.py", doc)
        _write(f"{path}/module-{i}.pyi", doc)