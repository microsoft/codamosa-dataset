

# Generated at 2022-06-21 09:50:32.294577
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    for name, path in walk_packages('pyslvs', "../src/pyslvs"):
        assert p.parse(name, _read(path + ".py")), f"Error at {name}"
    assert p.parse(
        'pyslvs',
        _read('../src/pyslvs.py')
    )
    assert p.parse(
        'pyslvs',
        _read('../src/pyslvs.pyi')
    )

# Generated at 2022-06-21 09:50:43.366685
# Unit test for function walk_packages
def test_walk_packages():
    from . import __path__
    from unittest import mock
    # Mock `open` function
    open_mock = mock.mock_open()
    @mock.patch('{0:s}.open'.format(__name__), open_mock)
    def test(name: str, path: str) -> None:
        """Test walk_packages."""
        pkg_path = __path__[0]
        module = join(pkg_path, 'compiler.py')
        module_base = join(pkg_path, '__init__.py')
        module_stub = join(pkg_path, '__init__.pyi')

# Generated at 2022-06-21 09:50:49.596422
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from importlib.util import module_from_spec, spec_from_file_location
    from importlib.machinery import SourceFileLoader
    from string import ascii_letters, digits
    from random import choice

    def random_string(length: int) -> str:
        return ''.join(choice(ascii_letters + digits) for _ in range(length))

    with TemporaryDirectory() as pwd:

        # Make site-packages
        site_packages = join(pwd, 'site-packages')
        mkdir(site_packages)
        mkdir(join(site_packages, '__pycache__'))
        # Make test package
        name = 'test_' + random_string(8)
        pkg = join(site_packages, name)
        mkdir(pkg)


# Generated at 2022-06-21 09:51:00.273534
# Unit test for function walk_packages
def test_walk_packages():
    def path(name: str) -> str:
        abs_path = abspath(name)
        if not isdir(abs_path):
            mkdir(abs_path)
        return abs_path

    p = path("a")
    # Make a directory
    _write(join(p, "__init__.py"), "")
    for i in range(1, 4):
        # Make a submodule
        _write(join(p, f"m{i}"), "")
        _write(join(p, f"m{i}.py"), "")
        # Make a submodule.__init__
        _write(join(p, f"m{i}/__init__.py"), "")

# Generated at 2022-06-21 09:51:09.671984
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    from os.path import join as p
    from os import makedirs
    from shutil import rmtree
    from unittest.mock import patch
    from importlib import reload
    from .parser import Parser
    from .core_api import core_api

    Parser.new = lambda *a, **k: Parser(root=("pyslvs",))
    rmtree("build")
    makedirs("build")
    makedirs("build/docs")
    makedirs("build/site-packages")


# Generated at 2022-06-21 09:51:14.581547
# Unit test for function loader
def test_loader():
    """Test of function loader."""
    root_names = {
        "PySLVS": 'pyslvs'
    }
    docs = gen_api(root_names, link=False, toc=True)
    assert len(docs) == len(root_names)

# Generated at 2022-06-21 09:51:22.252888
# Unit test for function walk_packages

# Generated at 2022-06-21 09:51:26.323773
# Unit test for function gen_api
def test_gen_api():
    from sys import path as sys_path
    from os.path import dirname
    sys_path.append(dirname(__file__))
    gen_api({'matplotlib': 'matplotlib'}, pwd=dirname(__file__), dry=True)

# Generated at 2022-06-21 09:51:27.492806
# Unit test for function gen_api
def test_gen_api():
    assert gen_api(dict(title="sPyslvs", name="sPyslvs"))


# Generated at 2022-06-21 09:51:32.728691
# Unit test for function gen_api
def test_gen_api():
    """Test the exporter."""
    api = gen_api({'Collection': 'collections'}, dry=True)
    import unittest
    unittest.TestCase().assertGreater(len(api), 0)
    unittest.TestCase().assertIn("LinkedList", api[0])
    unittest.TestCase().assertIn("mutable_sequence", api[0])


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:52:49.299972
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    import pyslvs
    _ = gen_api({'Solver': 'pyslvs'}, pwd=dirname(pyslvs.__file__), dry=True)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:52:50.836390
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages("pyslvs", _site_path("pyslvs")))) == 34

# Generated at 2022-06-21 09:53:03.205038
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api.

    If assert failed, the whole process is wrong.
    """
    from .auxiliary import git_origin
    from .logger import logger
    from .parser import link_url
    import pyslvs_ui.logger
    pyslvs_ui.logger.logger.setLevel(logger.debug)
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs-ui': 'pyslvs_ui',
        'Pyslvs-lib': 'pyslvs_lib',
    }
    assert gen_api(root_names)
    assert gen_api(root_names, prefix='test')
    assert gen_api(root_names, prefix='test', dry=True)

# Generated at 2022-06-21 09:53:09.194304
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages('Pyslvs', '../')[:3])) == 3
    assert len(list(walk_packages('Pyslvs', '../')[:4])) == 4
    assert len(list(walk_packages('Pyslvs', '../')[:5])) == 5
    assert len(list(walk_packages('Pyslvs', '../')[:6])) == 6
    assert len(list(walk_packages('Pyslvs', '../')[:7])) == 7
    assert len(list(walk_packages('Pyslvs', '../')[:8])) == 8

# Generated at 2022-06-21 09:53:17.794220
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("test", "tests/compiler")) == [
        ("test", "tests/compiler/test.py"),
        ("test.__init__", "tests/compiler/test/__init__.py"),
        ("test.foo", "tests/compiler/test/foo/__init__.py"),
        ("test.foo.bar", "tests/compiler/test/foo/bar/__init__.py"),
        ("test.foo.bar.math", "tests/compiler/test/foo/bar/math.py"),
        ("test.foo.bar.math2", "tests/compiler/test/foo/bar/math2.pyi"),
    ]

# Generated at 2022-06-21 09:53:19.650114
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"Foo": "foo"}, pwd=dirname(__file__))

# Generated at 2022-06-21 09:53:27.531583
# Unit test for function gen_api
def test_gen_api():
    """ */
    from os import remove
    from shutil import rmtree

    root_names = {'Pyslvs-core': 'core', 'Pyslvs-ui': 'ui'}
    pwd = '.'
    prefix = 'docs'
    link = True
    level = 1
    toc = False
    dry = True
    docs = gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)
    print(docs)

    if not dry:
        rmtree(prefix)
    else:
        try:
            remove(join(prefix, 'core-api.md'))
            remove(join(prefix, 'ui-api.md'))
        except FileNotFoundError:
            pass
    """

# Generated at 2022-06-21 09:53:32.762919
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('app', 'app')) == [('app', 'app/app'),
                                                 ('app.package', 'app/app/package.py')]
    assert list(walk_packages('app', 'app-stubs')) == [('app', 'app-stubs/app'),
                                                       ('app.package', 'app-stubs/app/package.pyi')]

# Generated at 2022-06-21 09:53:36.306658
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    assert gen_api({"test": "test"}) == []
    assert gen_api({"test": "pyslvs"}, pwd=__file__) == ["# test API\n\n# <ref>\n\n# <table>\n\n# <content>\n\n"]

# Generated at 2022-06-21 09:53:46.683711
# Unit test for function loader
def test_loader():
    """Test the default packages."""
    import sys
    import pkgutil
    from pkg_resources import get_entry_map
    from .parse_default_package import parse_default_package
    for _, p in pkgutil.iter_modules():
        if parse_default_package(p.name, p.version) is None:
            continue
        e_map = get_entry_map(p.name)
        logger.info(f"========================")
        logger.info(f"root: {p.name}")
        logger.info(f"path: {p.path}")
        logger.info(f"version: {p.version}")
        logger.info(f"entry: {e_map}")
        locate = pkgutil.get_loader(p.name).path

# Generated at 2022-06-21 09:55:03.204526
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from os.path import join
    from .logger import catch_stdout
    from .compiler import (
        walk_packages,
        PEP561_SUFFIX,
        EXTENSION_SUFFIXES
    )
    from importlib import machinery
    from random import choice
    from functools import partial
    root = "test_root"
    with TemporaryDirectory() as pwd, catch_stdout():
        for f in [
            join(pwd, root, '__init__.py'),
            join(pwd, root, 'sub', '__init__.py'),
            join(pwd, root + PEP561_SUFFIX, 'sub', '__init__.py'),
        ]:
            open(f, 'w').close()

# Generated at 2022-06-21 09:55:07.049066
# Unit test for function loader
def test_loader():
    from io import StringIO
    from .core import logger

    logger.add(StringIO(), format='{level.name}: {message}')
    logger.info('=' * 12)
    print(loader('pyslvs', '../pyslvs', False, 1, True))

# Generated at 2022-06-21 09:55:17.287541
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import tempfile
    from shutil import rmtree
    from os import getcwd

    with tempfile.TemporaryDirectory() as tmpdirname:
        temp_dir = join(tmpdirname, 'temp')
        mkdir(temp_dir)
        open(join(temp_dir, '__init__.py'), 'w').close()
        # Dependencies
        mkdir(join(temp_dir, 'dep'))
        open(join(temp_dir, 'dep', '__init__.py'), 'w').close()
        open(join(temp_dir, 'dep', 'A.py'), 'w').write(
            'from .B import a\na = A\n'
        )

# Generated at 2022-06-21 09:55:19.886459
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages('pyslvs', 'pyslvs'))) == 1
    assert len(list(walk_packages('pyslvs', 'doc'))) == 1

# Generated at 2022-06-21 09:55:31.015658
# Unit test for function gen_api
def test_gen_api():
    """This is the unit test for generating api"""
    # pylint: disable=unused-variable
    import pkg_resources
    import pyslvs

    path = join(dirname(pkg_resources.__file__), '..', '..', '..')
    docs = gen_api({'Pyslvs': 'pyslvs'}, path)

    assert '## Units' in docs[0]
    assert '### `pyslvs.units.Units`' in docs[0]
    assert '#### `units.Units.__init__()`' in docs[0]

    assert '## Topology optimization' in docs[0]
    assert '### `pyslvs.topology.Topology`' in docs[0]

# Generated at 2022-06-21 09:55:36.804743
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    import os
    from pyslvs.unit_test import TEMPORARY_PATH
    os.chdir(TEMPORARY_PATH)
    os.mkdir('docs')
    root_names = {
        'PySLVS': 'pyslvs',
        'PySLVS-UI': 'pyslvs_ui',
        'PySLVS-CLI': 'pyslvs_cli',
    }
    for doc in gen_api(root_names, '.', prefix='docs', dry=True):
        print(doc)

# Generated at 2022-06-21 09:55:44.297200
# Unit test for function walk_packages
def test_walk_packages():
    import hashlib
    def sha1(name: str) -> str:
        return hashlib.sha1(name.encode('utf-8')).hexdigest()[:5]
    assert list(walk_packages('sys', 'docs')) == [
        ('docs.sys.path', 'docs/sys/path.py'),
        ('docs.sys', 'docs/sys/__init__.py'),
    ]

# Generated at 2022-06-21 09:55:48.158328
# Unit test for function walk_packages
def test_walk_packages():
    assert len([_ for _ in walk_packages('pyslvs', '.')]) > 0
    assert len([_ for _ in walk_packages('pyslvs', 'src')]) > 0
    assert len([_ for _ in walk_packages('pyslvs', 'dist')]) > 0
    assert len([_ for _ in walk_packages('pyslvs', 'test')]) == 0

# Generated at 2022-06-21 09:55:57.237642
# Unit test for function walk_packages
def test_walk_packages():
    """Run unit test."""
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from random import randint
    from string import ascii_letters, punctuation

    def rand_string(l: int, *, ascii: bool = True) -> str:
        """Random string."""
        if not ascii:
            return ''.join(chr(randint(0, 0xFFFF)) for _ in range(l))
        return ''.join(chr(randint(0x21, 0x7e)) for _ in range(l))

    def rand_file(
        l: int,
        *,
        suffix: bool = True,
        pyi: bool = False
    ) -> str:
        """Create random file."""

# Generated at 2022-06-21 09:56:03.722953
# Unit test for function gen_api
def test_gen_api():
    import unittest
    from types import ModuleType
    from importlib.util import module_from_spec, spec_from_file_location
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import sep
    from os.path import join, splitext

    class Test(unittest.TestCase):

        def test_compiler(self):
            with TemporaryDirectory() as td:

                # create temp module
                module_name = '__test_module'
                module_suffix = '.py'
                module_path = join(td, module_name + module_suffix)
                copyfile(
                    join('docs', '__test_module.py'),
                    module_path
                )
                # load module

# Generated at 2022-06-21 09:57:20.757931
# Unit test for function loader
def test_loader():
    """Test case."""
    __import__("pyslvs")
    from . import __file__ as pyslvs_path
    pyslvs_path = abspath(pyslvs_path)
    pwd = parent(parent(parent(parent(pyslvs_path))))
    doc = loader('pyslvs', pwd, False, 1, False)

# Generated at 2022-06-21 09:57:30.315601
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .parser import Linker, CodeBlock, ImageBlock
    from .parser import TableColumn, TableRow
    name = "pyslvs_ui"
    pwd = _site_path(name)
    parser = Parser(True, 1, False)
    loader(name, pwd, parser)
    assert isinstance(parser.docs, list)
    assert isinstance(parser.docs[0], (str, Linker))
    assert isinstance(parser.docs[1], ImageBlock)
    assert isinstance(parser.docs[2], CodeBlock)
    assert isinstance(parser.docs[3], TableColumn)
    assert isinstance(parser.docs[3].rows[0], TableRow)
    assert isinstance(parser.docs[3].rows[0][0], Linker)

# Generated at 2022-06-21 09:57:37.232433
# Unit test for function loader
def test_loader():
    """Test the compiler."""
    from tempfile import mkdtemp
    import shutil

    subdir = "test_dir"
    root_name = "test"
    root_file = root_name + ".py"
    
    # Create directory and files for walking
    temp_dir = mkdtemp()
    os.makedirs(os.path.join(temp_dir, root_name), exist_ok=True)
    os.makedirs(os.path.join(temp_dir, root_name, subdir), exist_ok=True)
    # Create two __init__.py files
    os.mknod(os.path.join(temp_dir, root_name, "__init__.py"))

# Generated at 2022-06-21 09:57:42.928630
# Unit test for function walk_packages
def test_walk_packages():
    target = {
        "package.module": "module.py",
        "package.module.submodule": "module/submodule.py",
        "package.module.submodule.submodule": "module/submodule/submodule.pyi",
        "package.module.submodule.submodule.submodule":
        "module/submodule/submodule/submodule.pyi"
    }
    for name, path in walk_packages('package', '.'):
        logger.info(f"{name} <= {path}")
        assert name in target
        assert path.endswith(target[name])

# Generated at 2022-06-21 09:57:51.670248
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from pkgutil import get_importer, walk_packages
    from tempfile import TemporaryDirectory
    from os import makedirs, symlink, environ
    from os.path import join as join_path, isdir as p_isdir, isfile as p_isfile

    # Manually setup a test case
    with TemporaryDirectory() as prefix:
        path = join_path(prefix, 'test')
        environ['PYTHONPATH'] = path
        makedirs(join_path(path, 'test', '__pycache__'))
        symlink('..', join_path(path, 'test', '__pycache__', 'test.cpython-37.opt-1.pyc'))

# Generated at 2022-06-21 09:57:57.121027
# Unit test for function gen_api
def test_gen_api():
    logger.info('Unit test: test_gen_api')
    assert gen_api({'Qt for Python': 'PySide2'})  # docs/PySide2-api.md
    assert len(gen_api({'Qt for Python': 'PySide2'}, dry=True)) == 1
    assert len(gen_api({'Qt for Python': 'PySide2', 'Python': 'Python'},
                       pwd='E:\\Github\\pyslvs_ui\\pyslvs_ui\\src',
                       dry=True, link=False, toc=True)) == 2