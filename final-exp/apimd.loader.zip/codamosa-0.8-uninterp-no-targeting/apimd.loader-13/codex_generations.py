

# Generated at 2022-06-21 09:49:10.016505
# Unit test for function gen_api
def test_gen_api():
    from os import getcwd, chdir
    from shutil import rmtree
    name = 'pyslvs'
    prefix = 'docs'
    root_names = {"Solvespace API": name}
    cur_path = getcwd()
    chdir(dirname(__file__))
    gen_api(root_names, cur_path, prefix=prefix, dry=True)
    chdir(cur_path)
    rmtree(prefix)


__all__ = ["gen_api"]

# Generated at 2022-06-21 09:49:18.061411
# Unit test for function gen_api
def test_gen_api():
    from unittest.mock import patch
    from importlib import reload
    from . import parser
    from .pyslvs_ui.package_manager import get_site_packages
    root_names = {'Pyslvs': 'pyslvs', 'tkinter': 'tkinter'}
    docs = gen_api(root_names, prefix='test_api')
    assert len(docs) == 1
    assert 'pyslvs' in docs[0]
    assert 'tkinter' not in docs[0]
    patch('os.path.expanduser', lambda _: '').start()
    patch('os.getcwd', lambda: '').start()
    reload(parser)
    parser.readline = input

# Generated at 2022-06-21 09:49:26.293537
# Unit test for function loader
def test_loader():
    """Unit test for `loader`."""
    from shutil import rmtree
    from os.path import isdir
    from unittest.mock import patch
    from importlib import reload
    from .logger import init_logger
    init_logger(logger)
    logger.setLevel("DEBUG")
    root_names = {
        'Demo': 'demo',
    }
    pwd = './test/test_package'
    prefix = './test/test_package/docs'
    isdir(prefix) or mkdir(prefix)
    docs = gen_api(root_names, pwd, prefix=prefix, level=2, dry=False)
    assert isinstance(docs, Sequence)
    assert len(docs) == 1

# Generated at 2022-06-21 09:49:27.937243
# Unit test for function loader
def test_loader():
    log_ = logger.setLevel(100)
    assert gen_api({}) == []
    logger.setLevel(log_)

# Generated at 2022-06-21 09:49:30.430069
# Unit test for function loader
def test_loader():
    logger.info(loader('math', './tests/data/math'))


if __name__ == "__main__":
    test_loader()
    # from pprint import pprint
    # pprint(list(walk_packages('math', './tests/data/math')))

# Generated at 2022-06-21 09:49:41.192032
# Unit test for function gen_api
def test_gen_api():
    class Dict(dict):
        def __missing__(self, key):
            return key

# Generated at 2022-06-21 09:49:47.994332
# Unit test for function gen_api
def test_gen_api():
    from pytest import mark
    from shutil import rmtree

    @mark.parametrize("dry", (True, False))
    def t(dry: bool) -> None:
        gen_api({'test': 'pyslvs.test'}, dry=dry)
        rmtree('docs', ignore_errors=True)

    t(dry=True)
    t(dry=False)


__all__ = ['gen_api', 'test_gen_api']

# Generated at 2022-06-21 09:49:58.531940
# Unit test for function loader
def test_loader():
    """Unit test."""
    from . import __version__
    from .modules.qt_compat import QWidget
    root = 'pyslvs'
    logger.info(f"Version: {__version__}")
    logger.info(f"Root: {root}")
    logger.info(f"Qt: {QWidget}")
    s = loader(root, dirname(__file__), True, 1, True)
    logger.info(f"Result: {s}")

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-21 09:49:59.227537
# Unit test for function gen_api
def test_gen_api():
    pass

# Generated at 2022-06-21 09:50:10.582064
# Unit test for function gen_api
def test_gen_api():
    _ = gen_api({'pyslvs': 'pyslvs'}, '.')

# Codes below are used for benchmark tests.
# import time
# _ = gen_api({'pyslvs': 'pyslvs'}, '.')
# _ = gen_api({'pySolve': 'py_solve'}, '.')
# _ = gen_api({'pyslvs': 'pyslvs', 'pySolve': 'py_solve'}, '.')
# start = time.perf_counter()
# _ = gen_api({'pyslvs': 'pyslvs', 'pySolve': 'py_solve'}, '.')
# end = time.perf_counter()
# print(end - start)
# start = time.perf_counter()
# _

# Generated at 2022-06-21 09:50:40.075058
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 09:50:48.083574
# Unit test for function gen_api
def test_gen_api():
    from itertools import product

    def gen_api_test(title, name, pwd, prefix, link, level, toc, dry):
        try:
            gen_api(
                {title: name},
                pwd,
                prefix=prefix,
                link=link,
                level=level,
                toc=toc,
                dry=dry
            )
        except Exception as e:
            logger.error(f"Error: {str(e)}")
        else:
            logger.info("Done.")

    logger.setLevel("INFO")
    logger.setLevel("DEBUG")

# Generated at 2022-06-21 09:50:50.113503
# Unit test for function gen_api
def test_gen_api():
    logger.info(gen_api({'test-name': 'test_name'}, __file__, dry=True))



# Generated at 2022-06-21 09:50:56.019403
# Unit test for function gen_api
def test_gen_api():
    res = gen_api({
        "Matrix": "matrix",
        "OpenCV": "opencv_python",
        "PyQt5": "PyQt5",
        "numpy": "numpy",
        "Pyslvs UI": "ui",
        "Pyslvs": "pyslvs",
    }, "docs", link=False, dry=True)
    assert len(res) == 6

# Generated at 2022-06-21 09:51:03.982552
# Unit test for function loader
def test_loader():
    """Test function loader."""
    from pkgutil import iter_modules
    p = Parser.new(False, 1, False)
    for _, name, _ in iter_modules():
        try:
            logger.debug(f"loading {name}")
            __import__(name)
            p.load_docstring(name)
        except ImportError:
            logger.debug(f"import {name} failed")
    doc = p.compile()
    if doc.strip():
        logger.info(doc)
        logger.info("test success")
    else:
        logger.warning("test failed")
    assert doc.strip()

# Generated at 2022-06-21 09:51:09.390312
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .symbol import Symbol
    import numpy
    s = Symbol()
    p = Parser.new(False, 1, False)
    p.load_symbol(numpy.__name__, s)
    loader(numpy.lib.__name__, numpy.__path__[0] + '/lib', False, 1, False)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-21 09:51:19.897862
# Unit test for function loader
def test_loader():
    from unittest.mock import patch
    from importlib import reload
    from .parser import docstrings
    from .compiler import loader

    with patch('builtins.print', lambda *a, **kw: None):

        with patch('sys.path', new=['.', '.']):

            def module_spec(
                name: str,
                loader: object,
                is_package: bool = False,
                origin: str = '',
                submodule_search_locations=None
            ) -> object:
                return type('Spec', (object, ), {
                    'name': name,
                    'loader': loader,
                    'origin': origin,
                    'submodule_search_locations': submodule_search_locations,
                    'is_package': is_package,
                })

            # No module

# Generated at 2022-06-21 09:51:24.691784
# Unit test for function loader
def test_loader():
    from time import time
    s = time()
    for k, v in [
        ('pyslvs', '../pyslvs'),
        ('collections', '../../..'),
    ]:
        doc = loader(k, v, link=False, level=3)
        if doc.strip():
            print(doc)
    print(time() - s)



# Generated at 2022-06-21 09:51:30.996623
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os

    current_path = os.path.abspath(os.path.dirname(__file__))
    sys.path.append(os.path.abspath(current_path + "/../.."))

    root = 'pyslvs'
    pwd = _site_path(root)
    if not pwd:
        raise RuntimeError("Can't find PySLVS in site-packages")
    for name, path in walk_packages(root, pwd):
        print(name, path)

# Generated at 2022-06-21 09:51:38.991225
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import dirname

# Generated at 2022-06-21 09:52:51.554246
# Unit test for function loader
def test_loader():
    """Test package loader."""
    print(loader("numpy", "dist-packages", True, 2, True))

# Generated at 2022-06-21 09:53:01.635803
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("pyslvs", "/usr/lib/python3.7")) == [
        ('pyslvs', '/usr/lib/python3.7/pyslvs'),
        ('pyslvs', '/usr/lib/python3.7/pyslvs.pyi'),
    ]
    assert list(walk_packages("pyslvs", "/usr/lib64/python3.7")) == [
        ('pyslvs', '/usr/lib64/python3.7/pyslvs'),
        ('pyslvs', '/usr/lib64/python3.7/pyslvs.pyi'),
    ]

# Generated at 2022-06-21 09:53:10.041641
# Unit test for function walk_packages
def test_walk_packages():
    from dataclasses import dataclass
    @dataclass
    class Test:
        name: str
        pkg: str
        root: str
        path: str
        stub: str

    def is_sequence(x):
        return isinstance(x, Sequence)


# Generated at 2022-06-21 09:53:13.187734
# Unit test for function walk_packages
def test_walk_packages():
    # the current directory
    pwd = dirname(__file__)
    names = [n for n, _ in walk_packages('pyslvs', pwd)]
    assert 'pyslvs' in names
    assert 'pyslvs.__main__' in names
    assert 'pyslvs_ui' not in names
    assert 'pyslvs_ui.__main__' not in names

# Generated at 2022-06-21 09:53:20.147255
# Unit test for function walk_packages
def test_walk_packages():
    from .package_name import PACKAGE_NAME
    from .catcher import TrapException

    def do_check(name, path):
        assert tuple(walk_packages(name, path)) == (
            ('pyslvs', path + '/pyslvs'),
            (f'{name}', path + f'/{name}')
        )
    with TrapException():
        for path in [None, abspath('.')]:
            do_check(PACKAGE_NAME, path)

# Generated at 2022-06-21 09:53:21.831885
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("test", r"..\test"):
        print(name, path)



# Generated at 2022-06-21 09:53:23.665768
# Unit test for function walk_packages
def test_walk_packages():
    assert len(list(walk_packages('key', '../tests/data'))) == 1
    assert len(list(walk_packages('key', '../tests'))) == 1


# Generated at 2022-06-21 09:53:27.009619
# Unit test for function gen_api
def test_gen_api():
    """Check if it works."""
    gen_api({'pyslvs': "pyslvs", 'pyslvs-ui': "pyslvs_ui"}, dry=True)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:53:28.432679
# Unit test for function loader
def test_loader():
    """Run unit tests with `pytest`."""



# Generated at 2022-06-21 09:53:36.843721
# Unit test for function gen_api
def test_gen_api():
    for i in range(3):
        p = Parser.new(False, i, False)
        p.parse("root", "root\n")
        p.parse("root.foo", "root.foo\n")
        p.parse("root.foo.bar", "root.foo.bar\n")
        p.parse("root.foo.baz", "root.foo.baz\n")
        p.parse("root.some", "root.some\n")
        p.parse("root.some.other", "root.some.other\n")

# Generated at 2022-06-21 09:56:16.409049
# Unit test for function walk_packages
def test_walk_packages():
    with open('tmp.py', 'w') as f:
        f.write(
            """from del_root import del_root
from del_root.__init__ import INIT\n"""
        )
    with open('tmp.pyi', 'w') as f:
        f.write(
            """from del_root import del_root
from del_root.__init__ import INIT\n"""
        )
    with open('tmp-stubs.pyi', 'w') as f:
        f.write(
            """from del_root import del_root
from del_root.__init__ import INIT\n"""
        )

# Generated at 2022-06-21 09:56:22.471931
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        path = join(temp_dir, "test_pkg")
        mkdir(path)
        _write(join(path, '__init__.py'), "")
        _write(join(path, 'a__init__.py'), "")
        _write(join(path, 'A__init__.pyi'), "")
        _write(join(path, 'a.py'), "")
        _write(join(path, 'b.pyi'), "")
        _write(join(path, 'module.c'), "")
        _write(join(path, 'module.cpp'), "")

# Generated at 2022-06-21 09:56:25.387856
# Unit test for function walk_packages
def test_walk_packages():
    result = list(walk_packages('test', dirname(__file__)))
    assert result == [('test', join(dirname(__file__), 'test.py'))]



# Generated at 2022-06-21 09:56:35.146391
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as root:
        root += sep
        mkdir(join(root, 'package'))
        mkdir(join(root, 'package', 'subpackage'))
        mkdir(join(root, 'package', 'subpackage', 'subsubpackage'))
        # Normal
        with open(join(root, 'package', '__init__.py'), 'w+') as l:
            l.write('pass')
        with open(join(root, 'package', 'subpackage', '__init__.py'), 'w+') as l:
            l.write('pass')
        with open(join(root, 'package', 'subpackage', 'subsubpackage', '__init__.py'), 'w+') as l:
            l.write('pass')

# Generated at 2022-06-21 09:56:38.742787
# Unit test for function walk_packages
def test_walk_packages():
    from examples.api_generator import root_names
    for name in root_names:
        for _, path in walk_packages(name, _site_path(name)):
            assert isfile(path + '.py') or isfile(path + '.pyi')

# Generated at 2022-06-21 09:56:41.044397
# Unit test for function gen_api
def test_gen_api():
    docs = gen_api({"Test": "test"}, dry=True, level=2)
    assert len(docs) == 1
    assert docs[0].startswith("## Test API")

# Generated at 2022-06-21 09:56:50.548590
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove, makedirs
    from os.path import exists
    from tempfile import mkdtemp
    assert_p, path = mkdtemp(), join(mkdtemp(), 'my_lib')
    makedirs(path)
    _write(join(path, '__init__.py'), '')
    _write(join(path, '__init__.pyi'), '')
    _write(join(path, '__init__.pyx'), '')
    _write(join(path, '__init__.pyc'), b'\x00\x00\x00\x00')
    _write(join(path, 'test.py'), '')
    _write(join(path, 'test.pyi'), '')
    _write(join(path, 'foo.py'), '')

# Generated at 2022-06-21 09:56:59.493850
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import mkdtemp
    from shutil import rmtree
    from random import sample
    from itertools import permutations
    from pathlib import Path
    root = '_test_package'
    pwd = str(Path(mkdtemp()).resolve())
    sep_path = [pwd, root]
    sep_path.extend(sample(range(10), 5))
    pkg_path = sep.join(map(str, sep_path))
    mkdir(join(pkg_path, '__init__.py'))
    sep_path.extend(['some_module'])
    mod_path = sep.join(map(str, sep_path))
    _write(join(mod_path, '__init__.py'), "__all__ = 'child_module'")
    sep_

# Generated at 2022-06-21 09:57:09.505726
# Unit test for function gen_api
def test_gen_api():
    r"""Test case in readme.md"""
    from pyslvs_ui.io import import_string
    from pyslvs import __version__ as slvs_version

    name = f"pyslvs-{slvs_version}"
    root_names = {
        "Pyslvs": "pyslvs",
        "Solver": "solver",
        "GUI": "gui_core",
        "Logger": "logger",
        "File IO": "io",
        "Extension": "extension",
    }
    gen_api(root_names, pwd=name, prefix=name, dry=True)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-21 09:57:18.653120
# Unit test for function gen_api
def test_gen_api():
    # pylint: disable=import-outside-toplevel
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import copy2

    def stub_file(path: str, name: str) -> None:
        with open(path / name, "a") as f:
            f.write("\"\"\"Stub file.\"\"\"\n\n")

    with TemporaryDirectory() as tmpdir:
        pkgdir = tmpdir / "test"
        pkgdir.mkdir()
        (pkgdir / "__init__.py").touch()
        copy2("__main__.py", pkgdir)
        for name in "foo", "bar":
            (pkgdir / name).mkdir()
            stub_file(pkgdir / name, "__init__.py")