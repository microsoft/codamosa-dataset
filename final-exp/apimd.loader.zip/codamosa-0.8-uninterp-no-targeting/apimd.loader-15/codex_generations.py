

# Generated at 2022-06-21 09:50:10.880729
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    from os import remove
    from os.path import exists
    from pkgutil import iter_modules
    from pyslvs import __version__
    from shutil import rmtree

    # Create some packages
    module_root = "tests_modules"
    if exists(module_root):
        rmtree(module_root)
    mkdir(module_root)

    test_root = join(module_root, "test")
    mkdir(test_root)
    with open(join(test_root, "__init__.py"), 'w+') as f:
        f.write("from pkgutil import extend_path\n__path__ = extend_path(__path__, __name__)")

# Generated at 2022-06-21 09:50:18.260279
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    path = dirname(__file__)
    pwd = join(path, '..', '..', 'tests', 'data')
    root_names = {
        "Pyslvs": "pyslvs",
        "Solvespace": "solvespace",
    }
    gen_api(root_names, pwd, dry=True)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-21 09:50:23.782377
# Unit test for function walk_packages
def test_walk_packages():
    """Test package walking algorithm."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        import_path = abspath(tmp) + sep
        sys_path.append(import_path)
        assert _site_path("test") == ""
        assert isinstance(walk_packages("test", import_path),
                          Iterator[tuple[str, str]])
        from package_generator import gen_package
        gen_package("test", "test", path=import_path)
        assert _site_path("test") == import_path
        assert isinstance(walk_packages("test", import_path),
                          Iterator[tuple[str, str]])
        root = 'root'
        sub = 'sub'
        sub2 = 'sub2'
        root_md = None
        sub_

# Generated at 2022-06-21 09:50:32.647265
# Unit test for function walk_packages
def test_walk_packages():
    def _func(path: str, it: Iterator[tuple[str, str]]) -> None:
        assert isinstance(it, Iterator)
        ite = list(it)
        assert isinstance(ite, list)
        assert len(ite) == 2
        assert ite[0][0] == "test.test_pack"
        assert ite[0][1] == join(path, "test", "test_pack.py")
        assert ite[1][0] == "test.test_pack_stubs"
        assert ite[1][1] == join(path, "test", "test_pack_stubs.pyi")

    from . import _root_dir
    import os
    path_test = join(_root_dir, 'test')

# Generated at 2022-06-21 09:50:43.492279
# Unit test for function loader
def test_loader():
    class Tester:

        def __init__(self, args):
            self.args = args

    import sys
    from pyslvs_ui.dyn_api import demo
    from .dynlink import UnitTest

    sys.modules['demo'] = demo
    sys.modules['demo.__init__'] = demo.__init__
    sys.modules['demo.test'] = demo.test
    sys.modules['demo.main'] = demo.main
    sys.modules['demo.main.__init__'] = demo.main.__init__
    sys.modules['demo.main.sub'] = demo.main.sub
    sys.modules['demo.main.sub.__init__'] = demo.main.sub.__init__
    sys.modules['demo.test.__init__'] = demo

# Generated at 2022-06-21 09:50:54.131505
# Unit test for function gen_api
def test_gen_api():
    from os import remove
    from unittest import TestCase, main
    from doctest import DocTestSuite

    class GenApiTest(TestCase):

        def test_empty(self):
            from collections import defaultdict
            from copy import copy
            root_names = defaultdict(lambda: '')
            self.assertSequenceEqual([], gen_api(root_names))
            self.assertSequenceEqual([], gen_api(copy(root_names), dry=True))

        def test_default(self):
            root_names = {
                'pyslvs': 'pyslvs',
                'pyslvs-ui': 'pyslvs_ui',
            }
            docs = gen_api(root_names, dry=True)

# Generated at 2022-06-21 09:51:04.151081
# Unit test for function walk_packages
def test_walk_packages():
    from .test.test_loader import walk_test

    def _add(name: str, path: str) -> None:
        assert name not in walk_test
        walk_test[name] = path

    for name, path in walk_packages("test", '.'):
        _add(name, path)
    for name, path in walk_packages("test", './test'):
        _add(name, path)
    for name, path in walk_packages("test", './test/test'):
        _add(name, path)
    assert "test" in walk_test
    assert "test.test" in walk_test
    assert "test.test.test" in walk_test
    assert "test.test.test.test" in walk_test
    assert "test.test.test.test.test" in walk_test

# Generated at 2022-06-21 09:51:09.240451
# Unit test for function loader
def test_loader():
    """Function loader."""
    p = Parser.new(False, 1, False)
    p.parse("m", "def f(): pass")
    assert p.compile() == "## Module: m\n\n#### f()\n\n    def f(): pass\n\n"
    assert loader("m", "", False, 1, False) == p.compile()


# Generated at 2022-06-21 09:51:13.282596
# Unit test for function walk_packages
def test_walk_packages():
    path = '/Users/yuanchang/Python/pyslvs-ui/pyslvs_ui/ui_qt'
    walk_packages('ui_qt', path)

# Generated at 2022-06-21 09:51:16.699465
# Unit test for function gen_api
def test_gen_api():
    # For CI
    root_names = {"test": "pyslvs_ui"}
    docs = gen_api(root_names, dry=True)
    print(docs)


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:53:03.247988
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    assert next(walk_packages("a", "testdata")) == (
        "a.__init__",
        "testdata/a/__init__.py")
    assert next(walk_packages("a", "testdata")) == (
        "a.b1",
        "testdata/a/b1.py")
    assert next(walk_packages("a", "testdata")) == (
        "a.b1.c1",
        "testdata/a/b1/c1.py")
    assert next(walk_packages("a", "testdata")) == (
        "a.b1.c2",
        "testdata/a/b1/c2.py")

# Generated at 2022-06-21 09:53:06.066949
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    assert gen_api({'Test': 'test'}, dry=True) == [
        '### Test API\n\n'
        '###### `test` module\n\n'
        '## test.test2 module\n\n'
        '##### `test2`:  test2'
    ]

# Generated at 2022-06-21 09:53:08.877965
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages('numpy', '..'):
        print(name, path)
    for name, path in walk_packages('pyslvs', '..'):
        print(name, path)

# Generated at 2022-06-21 09:53:19.012600
# Unit test for function walk_packages
def test_walk_packages():
    """Test case for walk_packages."""
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as d:
        t_path1 = join(d, 'foo')
        mkdir(t_path1)
        t_path2 = join(d, 'foo', 'bar')
        mkdir(t_path2)
        t_path3 = join(d, 'foo', 'bar', '__init__.py')
        _write(t_path3, '')
        t_path4 = join(d, 'foo', 'bar', 'module.pyi')
        _write(t_path4, '"""foo"""\nclass Bar: ...\n')
        t_path5 = join(d, 'foo', 'baz')
        mkdir(t_path5)

# Generated at 2022-06-21 09:53:27.198917
# Unit test for function walk_packages
def test_walk_packages():
    from os import remove, listdir
    from os.path import join as pjoin, dirname
    from shutil import copy
    from .utils import temp_dir

    logger.info("walk_packages unit test")
    with temp_dir() as p:
        path = pjoin(p, 'pyslvs_ui')
        mkdir(path)
        logging_path = pjoin(dirname(dirname(__file__)), 'logging.py')
        copy(logging_path, pjoin(path, 'logging.py'))
        _write(pjoin(path, '__init__.py'), '')
        mkdir(pjoin(path, '__pycache__'))
        _write(pjoin(path, '__pycache__', '__init__.cpython-37.pyc'), '')
       

# Generated at 2022-06-21 09:53:30.830830
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({}) == []
    assert len(gen_api({'測試用': 'mod'})) == 0
    assert len(gen_api({'測試用': 'pyslvs'})) == 1

# Generated at 2022-06-21 09:53:38.416305
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    def all_docs():
        """Collect all docs."""
        return ''.join(gen_api({
            "pyslvs": "pyslvs",
            "pyslvs-paint": "pyslvs_paint",
        }, "../..", level=2, toc=True, dry=True))
    assert '#' in all_docs()
    assert "Syntax" in all_docs()
    assert ".. _Paint API" in all_docs()
    assert ".. _pyslvs-paint.data" in all_docs()
    assert ".. code-block:: python" in all_docs()
    assert ".. doctest::" in all_docs()
    assert ".. py:class::" in all_docs()

# Generated at 2022-06-21 09:53:42.443360
# Unit test for function gen_api
def test_gen_api():
    assert gen_api({"Solver": "pyslvs"}, toc=False, level=1)
    assert gen_api({"Solver": "pyslvs", "GUI": "pyslvs_ui"}, toc=False, level=1)

# Generated at 2022-06-21 09:53:45.863306
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    root_names = {'Changelog': 'CHANGELOG'}
    doc = gen_api(root_names, '..', dry=True)
    assert doc



# Generated at 2022-06-21 09:53:53.243174
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    prefix = 'docs'
    if not isdir(prefix):
        mkdir(prefix)
    for title, name in {
        "Solver": "ylpy.solver",
        "Nodes": "ylpy.nodes",
        "Links": "ylpy.links",
    }.items():
        logger.info(f"Load root: {name} ({title})")
        doc = loader(name, '', True, 2, False)
        if not doc.strip():
            logger.warning(f"'{name}' can not be found")
            continue
        doc = '#' * 2 + f" {title} API\n\n" + doc
        _write(join(prefix, f"{name.replace('_', '-')}-api.md"), doc)


