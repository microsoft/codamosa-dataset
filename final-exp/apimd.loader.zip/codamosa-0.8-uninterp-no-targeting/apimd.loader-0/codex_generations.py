

# Generated at 2022-06-21 09:52:45.398257
# Unit test for function loader
def test_loader():

    assert "pytest" in _site_path("pytest")

    test_path = dirname(abspath(__file__))
    sys_path.append(test_path)
    sys_path.append(join(test_path, "data"))
    try:
        from .data.sphinxcontrib_trio import async_gen
        async_gen.__doc__ = None
    except ImportError:
        logger.warning("no module for 'sphinxcontrib_trio'")
    from .data import test, test_pyi, test_sphinxcontrib_trio


# Generated at 2022-06-21 09:52:45.787150
# Unit test for function gen_api
def test_gen_api():
    pass

# Generated at 2022-06-21 09:52:49.762797
# Unit test for function loader
def test_loader():
    # pylint: disable=invalid-name
    from os.path import relpath
    from unittest.mock import patch

    with patch('solve_engine.compiler.logger.debug') as d:
        loader("solve_engine", "tests/solve_engine", False, 3, False)
        d.assert_called()
    # pylint: enable=invalid-name


# Generated at 2022-06-21 09:53:01.593367
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    # Create the temp directory
    with TemporaryDirectory() as temp:
        # Create the directory
        mkdir(join(temp, "mock_api"))
        mkdir(join(temp, "mock_api-stubs"))
        # Create the file
        with open(join(temp, "mock_api", "__init__.py"), "w+") as f:
            f.write('"""Mock API."""')
        with open(join(temp, "mock_api-stubs", "__init__.pyi"), "w+") as f:
            f.write('"""Mock API stub."""')
        # Load the module

# Generated at 2022-06-21 09:53:10.011446
# Unit test for function loader
def test_loader():
    """Test for package searching algorithm."""
    from logging import ERROR
    logger.setLevel(ERROR)
    from .test import test_prefix
    the_prefix = test_prefix / 'test_loader'
    the_prefix.mkdir(parents=True, exist_ok=True)

    with (the_prefix / '__init__.py').open('w') as init:
        init.write('name = "test"\n')

    with (the_prefix / 'test.py').open('w') as test:
        test.write('"""\nThis is the document.\n"""\n')
        test.write('def func():\n    """This is the function."""\n')

    the_prefix_stubs = the_prefix / 'stubs'
    the_prefix_stubs.mkdir()

# Generated at 2022-06-21 09:53:15.500968
# Unit test for function loader
def test_loader():
    """Test for whole package loading."""
    from importlib import import_module
    from .data import to_dot
    from .parser import as_link
    from .compiler import loader, gen_api

    def test_gen_api(name: str, title: str, dry: bool = False) -> str:
        """Test for gen_api."""
        return gen_api({title: name}, dry=dry)[0]

    def eq(lhs: str, rhs: str) -> None:
        print("=" * 12)
        print("LHS")
        print("-" * 12)
        print(lhs)
        print("=" * 12)
        print("RHS")
        print("-" * 12)
        print(rhs)
        assert lhs == rhs


# Generated at 2022-06-21 09:53:24.943848
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os.path import basename
    from random import randint
    for isfile_ in (False, True):
        for isdir_ in (False, True):
            with TemporaryDirectory() as tmp:
                if isfile_:
                    with open(join(tmp, 'a.py'), 'w') as f:
                        f.write('#')
                if isdir_:
                    mkdir(join(tmp, 'b'))
                    with open(join(tmp, 'b', '__init__.py'), 'w') as f:
                        f.write('#')
                if isfile_ and isdir_:
                    with open(join(tmp, 'b', 'c.py'), 'w') as f:
                        f.write('#')

# Generated at 2022-06-21 09:53:27.195368
# Unit test for function loader
def test_loader():
    """Test for loader."""
    assert loader('math', 'math', False, 0, False)
    assert loader('numpy', 'numpy', False, 0, False)

# Generated at 2022-06-21 09:53:28.639940
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 09:53:30.523086
# Unit test for function loader
def test_loader():
    """Test function `loader`."""
    d = gen_api({'Pyslvs': 'pyslvs'})
    print(d)

# Generated at 2022-06-21 09:57:25.384863
# Unit test for function loader
def test_loader():
    logger.info('Start testing loader')
    from pathlib import Path

    home = Path.home()
    os_name = home.name
    root = 'pyslvs'
    pwd = (home / 'Documents' / 'GitHub' / 'pyslvs-ui' / 'pyslvs' / 'docs' /
           'api' / 'loader' / 'data' / os_name)

    # Link test
    api_doc = loader(root, pwd, True, 2, False)
    assert 'https://pyslvs.readthedocs.io/en/latest/api/editor.html#function' \
        in api_doc, f"Links should be found in {api_doc}"

    # Depth test
    api_doc = loader(root, pwd, True, 1, False)


# Generated at 2022-06-21 09:57:34.162421
# Unit test for function walk_packages
def test_walk_packages():
    import tempfile

# Generated at 2022-06-21 09:57:39.700332
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test function 'walk_packages'."""
    try:
        import PySide2
    except ImportError:
        print("test_walk_packages: skipped")
        return
    import inspect
    # pylint: disable=import-outside-toplevel,cyclic-import
    from os import path
    from pyslvs.api import __package__
    from pyslvs import __version__ as version
    from .logger import set_logger
    set_logger(None)
    files = {}
    for name, path in walk_packages(__package__, path.abspath(path.dirname(PySide2.__file__))):
        with open(path + '.py', "r") as f:
            files[name] = f.read()

# Generated at 2022-06-21 09:57:44.502278
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    class FakeLogger:
        def __init__(self):
            self.stdout = ""
        def info(self, text: str) -> None:
            self.stdout += f"[I] {text}\n"
        def warning(self, text: str) -> None:
            self.stdout += f"[W] {text}\n"
        def debug(self, text: str) -> None:
            self.stdout += f"[D] {text}\n"
    logger = FakeLogger()

    # Custom CLI options
    class FakeOptions:
        def __init__(self) -> None:
            self.path = None

# Generated at 2022-06-21 09:57:52.365308
# Unit test for function loader
def test_loader():
    """Test loading API."""
    from pyslvs.loader import walk_packages
    from pyslvs import __version__
    docs = [
        "# API for pyslvs " + __version__,
    ]
    for name, path in walk_packages("pyslvs", "pyslvs"):
        with open(path + ".py", "rt", encoding='utf8') as f:
            docs.append("## " + name)
            docs.append("```python")
            docs.append("%s" % f.read())
            docs.append("```")
    with open("test_loader.md", "wt", encoding='utf8') as f:
        f.writelines("\n".join(docs))

# Generated at 2022-06-21 09:58:00.256150
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import copytree
    from os import sep as os_sep
    from os.path import abspath as ospath_abs
    from pathlib import Path
    import pkg_resources
    from .compiler import gen_api
    from .parser import Parser

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = ospath_abs(tmp_dir)
        logger.debug(tmp_dir)

        pwd = ospath_abs(pkg_resources.resource_filename('pyslvs', '.'))
        logger.debug(pwd)
