

# Generated at 2022-06-21 09:50:33.333499
# Unit test for function walk_packages
def test_walk_packages():
    pass

# Generated at 2022-06-21 09:50:44.014137
# Unit test for function walk_packages
def test_walk_packages():
    def p(*path: str) -> str:
        return 'foo' + sep + sep.join(path)

# Generated at 2022-06-21 09:50:49.897648
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    from unittest import TestCase, main
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from shutil import rmtree
    from os import listdir
    from os.path import isfile, join

    class Test(TestCase):
        def setUp(self) -> None:
            self.path = TemporaryDirectory()
            self.path.name = abspath(self.path.name)
            logger.info(f"Test path: {self.path.name}")
            self.test_file = join(self.path.name, 'test.solver')
            logger.info(f"Generator file: {self.test_file}")
            copyfile('tests/unit/data/test.solver', self.test_file)
            self.test_

# Generated at 2022-06-21 09:51:00.544524
# Unit test for function gen_api
def test_gen_api():
    root_names = {'sG': 'solver'}
    pwd = '.'
    prefix = 'docs'
    link = True
    level = 1
    toc = False
    dry = False
    gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)
    root_names = {'sG': 'solver'}
    pwd = '.'
    prefix = 'docs'
    link = True
    level = 1
    toc = True
    dry = False
    gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)
    root_names = {'sG': 'solver'}
    pwd = '.'
    prefix = 'docs'

# Generated at 2022-06-21 09:51:01.963775
# Unit test for function gen_api
def test_gen_api():
    assert isinstance(gen_api(dict(test='test')), list)

# Generated at 2022-06-21 09:51:06.765571
# Unit test for function loader
def test_loader():
    docs = gen_api({
        "SVGElems": "svg.elements",
        "SVGProps": "svg.properties",
    }, dry=True)
    # Test functions
    assert len(docs) == 2

if __name__ == "__main__":
    logger.debug("Start unit test")
    test_loader()
    logger.debug("Success")

# Generated at 2022-06-21 09:51:09.390249
# Unit test for function gen_api
def test_gen_api():
    from .__main__ import __doc__ as root_doc
    docs = gen_api({'Root': 'pyslvs_ui'}, prefix='docs', dry=True)
    assert docs == [root_doc]

# Generated at 2022-06-21 09:51:19.897014
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import mkdtemp
    from shutil import rmtree
    from string import ascii_lowercase
    from itertools import product
    from random import choice
    from os.path import exists as path_exists

    # Generate a random string
    alphabet = ascii_lowercase
    letters = list(product(alphabet, repeat=3))
    letters = [''.join(x) for x in letters if ''.join(x) not in ['lib', 'loc']]

    def random_string(n: int = 5):
        return ''.join([choice(alphabet) for _ in range(n)])

    # Generate a temp dir
    temp_dir = mkdtemp()

# Generated at 2022-06-21 09:51:21.992179
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert loader('pyslvs', '../..', link=True, level=1, toc=True)

# Generated at 2022-06-21 09:51:31.622552
# Unit test for function gen_api
def test_gen_api():
    import shutil
    from tempfile import mkdtemp
    from os import chdir
    root = mkdtemp()
    chdir(root)
    title, name = 'test', 'pyslvs_test'
    root_names = {
        title: name,
    }
    prefix = 'docs'
    pwd = None
    link, level, toc, dry = True, 2, True, False
    docs = gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)
    import pyslvs
    assert isinstance(docs, list) and len(docs) == 1 and docs[0].strip() and pyslvs.__version__ in docs[0]
    shutil.rmtree(root)
    del root, title, name

# Generated at 2022-06-21 09:55:37.592523
# Unit test for function walk_packages
def test_walk_packages():
    """Testing a package structure, which may be built by `setuptools`."""
    import os
    import shutil
    test_root = 'test_package_root'
    root = 'package_root'
    append = 'package_root/__init__.py'

# Generated at 2022-06-21 09:55:43.643620
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_doc."""
    from sys import path as sys_path
    from os.path import dirname, abspath, join
    sys_path.append(dirname(dirname(abspath(__file__))))
    gen_api({'Solver': 'solver'}, dirname(dirname(abspath(__file__))))
    gen_api({'Version': 'version'}, join(dirname(dirname(abspath(__file__))), '__init__.py'))
    gen_api({'Module': 'module'})

if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-21 09:55:50.098144
# Unit test for function gen_api
def test_gen_api():
    from .gen_api import gen_api
    from ._version import get_versions
    assert '#' in gen_api({'pyslvs': 'pyslvs'})[0], "No docs generated."
    assert '#' in gen_api({str(k): k for k in range(3)}, prefix='./gen_api')[0]
    assert '#' in gen_api({'pyslvs': 'pyslvs'}, pwd=abspath('./.'))[0]
    assert '#' in gen_api({'pyslvs': 'pyslvs'}, pwd=abspath('./src'))[0]

# Generated at 2022-06-21 09:55:52.402741
# Unit test for function loader
def test_loader():
    code = loader('numpy', '', link=False)
    assert len(code) > 0
    print('=' * 12)
    print(code)
    print('=' * 12)



# Generated at 2022-06-21 09:56:00.402836
# Unit test for function gen_api
def test_gen_api():
    """Test ``gen_api`` function."""
    from pkgutil import get_data
    from io import StringIO
    from tempfile import TemporaryDirectory
    from .parser import expand_tab

    class TestLoader(Loader):
        """Loader for module."""
        def create_module(self, spec):
            return None

        def exec_module(self, module):
            stream = StringIO(get_data("tests.data", "math.py").decode("cp950"))
            module.__doc__ = stream.read()

    # Load stub first
    spec = find_spec("math")
    assert spec is not None
    spec.loader = TestLoader()
    math_module = spec.loader.load_module()
    Parser.new(True, 1, False).load_docstring("math", math_module)

    # Load

# Generated at 2022-06-21 09:56:07.609826
# Unit test for function gen_api
def test_gen_api():
    import pkgutil
    from .parser import linkify
    from .parser import get_docstring_content, get_docstring_restructuredtext
    from .parser import _parse_method, _parse_restructuredtext
    assert gen_api(
        root_names={"pyslvs": "Pyslvs"},
        pwd=_site_path("pyslvs"),
        prefix="temp",
        link=True,
        level=2,
        toc=False,
        dry=True
    )
    assert linkify("test", "pyslvs") == "test"
    assert get_docstring_content("test") == "test"
    assert get_docstring_restructuredtext("test", level=2) == "test"

# Generated at 2022-06-21 09:56:14.497599
# Unit test for function gen_api
def test_gen_api():
    """Test for function gen_api."""
    docs = gen_api({
        "Pyslvs": "pyslvs",
        "Pyslvs UI": "pyslvs_ui"
    }, prefix="../docs", toc=True, dry=True)
    for doc in docs:
        print(doc)
    assert "Module" in docs[0]
    assert "#" * 5 in docs[0]



# Generated at 2022-06-21 09:56:19.288850
# Unit test for function loader
def test_loader():
    doc = loader("pyslvs", _site_path("pyslvs"), True, 1, True)
    assert doc.startswith("# API for Pyslvs")
    assert doc.strip().endswith("</div>")
    doc = loader("tkinter", _site_path("tkinter"), True, 1, True)
    assert doc.startswith("# API for tkinter")
    assert doc.strip().endswith("</div>")

# Generated at 2022-06-21 09:56:23.588680
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('pyslvs', 'pyslvs')) == [
        ('pyslvs', 'pyslvs/__init__.py'),
        ('pyslvs.logger', 'pyslvs/logger.py'),
        ('pyslvs_ui', 'pyslvs_ui/__init__.py')
    ]

# Generated at 2022-06-21 09:56:32.027763
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        _write(join(temp, '__init__.py'), "")
        _write(join(temp, 'foo.py'), "")
        _write(join(temp, 'foo.pyi'), "")
        mkdir(join(temp, 'bar'))
        _write(join(temp, 'bar/__init__.py'), "")
        _write(join(temp, 'bar/bar.pyi'), "")
        assert list(walk_packages("", temp)) == [
            ('foo', join(temp, 'foo')),
            ('bar', join(temp, 'bar/bar'))
        ]