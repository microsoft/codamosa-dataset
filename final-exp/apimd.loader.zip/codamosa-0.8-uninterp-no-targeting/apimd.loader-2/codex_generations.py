

# Generated at 2022-06-21 09:51:52.751206
# Unit test for function loader
def test_loader():
    """Loader unit test."""
    # pylint: disable=import-error,import-outside-toplevel
    import os
    import sys
    import pyslvs
    test_dir = os.path.dirname(os.path.abspath(os.path.abspath(pyslvs.__file__)))
    pwd = os.path.join(test_dir, "tests", "package")
    sys.path.append(pwd)
    doc = loader("test", pwd, True, 1, False)
    assert "Class test_pkg.MyClass" in doc
    assert "def A(b: int, c: Optional[bool] = None) -> int" in doc
    assert "def B(c: Optional[bool] = None) -> None" in doc

# Generated at 2022-06-21 09:52:02.490303
# Unit test for function walk_packages
def test_walk_packages():
    from pyslvs_ui.parser import parent
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    import subprocess

    with TemporaryDirectory() as td:
        subprocess.run("pip3 install --target . pyslvs-ui", shell=True, cwd=td)
        assert isdir(join(td, 'pyslvs_ui'))
        packages = {pth.replace(sep, '.'): pth for pth, _ in walk_packages('pyslvs_ui', td)}
        # All package in pyslvs_ui
        assert 'pyslvs_ui' in packages
        assert 'pyslvs_ui.compiler' in packages
        assert 'pyslvs_ui.exporter' in packages
        assert 'pyslvs_ui.parser'

# Generated at 2022-06-21 09:52:06.517509
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages()."""
    root = 'test_package'
    path = abspath(__file__)
    while path.endswith('.py'):
        path = dirname(path)
    path = join(path, root)
    names = list(walk_packages(root, path))
    assert len(names) == 1
    assert names[0][0] == "test_package.api"
    assert names[0][1].endswith(join('test_package', 'api.pyi'))

# Generated at 2022-06-21 09:52:12.398096
# Unit test for function gen_api
def test_gen_api():
    import os
    import tempfile
    from shutil import rmtree
    from pdoc.html import serve

    def setup_gen_api() -> None:
        logger.setLevel("DEBUG")
        nonlocal site_packages
        nonlocal pwd
        nonlocal dirpath
        nonlocal root_names
        nonlocal serve_thread
        site_packages = os.path.dirname(os.__file__)
        pwd = os.getcwd()
        dirpath = tempfile.mkdtemp()
        os.chdir(dirpath)
        root_names = {"Pyslvs", "pyslvs"}
        serve_thread = serve("docs")
        serve_thread.start()

    def teardown_gen_api() -> None:
        logger.setLevel("INFO")
        serve_thread.stop()

# Generated at 2022-06-21 09:52:20.075534
# Unit test for function walk_packages
def test_walk_packages():
    sp = _site_path('matplotlib')
    if sp != '':
        assert list(walk_packages('matplotlib', sp))[0] == \
            ('matplotlib.axes._subplots', join(sp, 'matplotlib', 'axes', '_subplots.py'))
        assert list(walk_packages('matplotlib', sp))[-1] == \
            ('matplotlib.widgets', join(sp, 'matplotlib', 'widgets', '__init__.py'))



# Generated at 2022-06-21 09:52:27.790419
# Unit test for function walk_packages
def test_walk_packages():
    from io import StringIO
    from os import mkdir, remove, rmdir
    from tempfile import TemporaryDirectory
    from unittest import TestCase, mock

    class Test(TestCase):

        def test_basic(self):
            with TemporaryDirectory() as tmp:
                for name in ["test", "test_path", "test_path.test1"]:
                    mkdir(join(tmp, *name.split(".")))
                    with open(join(tmp, *name.split(".")) + ".py", 'w+') as f:
                        f.write("")

# Generated at 2022-06-21 09:52:33.604361
# Unit test for function gen_api
def test_gen_api():
    import os
    import shutil

    # Create temporary directory
    tmp_name = os.path.join(os.getcwd(), 'pyslvs_api_test')
    os.mkdir(tmp_name)

    # Create test files
    os.chdir(tmp_name)
    os.mkdir('test')
    os.mkdir('test_a')
    os.mkdir('test_a/__pycache__')
    os.mkdir('test_a/generate')
    os.mkdir('test_a/generate/__pycache__')
    os.mkdir('test_a/generate/__init__')
    os.mkdir('test_a/generate/__init__/__pycache__')

# Generated at 2022-06-21 09:52:43.262605
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages."""
    # pylint: disable=protected-access
    keys = [x.__name__ for x in Parser._CONV.keys()]
    for root, path in walk_packages('pyslvs', '.'):
        assert not any(map(lambda x: x in root, keys))
    assert all(map(lambda x: x not in path, keys))
    for name, path in walk_packages('pyslvs', './docs/api'):
        assert 'pyslvs' in name
        assert name.endswith('api')
        assert name.removeprefix('pyslvs.').count('.') == 1
        assert path.endswith('.py')

# Generated at 2022-06-21 09:52:50.863401
# Unit test for function gen_api
def test_gen_api():
    class Msg:
        """Mockup logger class."""
        def __call__(self, *_, **__):
            pass
        @staticmethod
        def info(*_, **__):
            pass
        @staticmethod
        def warning(*_, **__):
            pass
        @staticmethod
        def debug(*_, **__):
            pass

    class Pkg:
        """Mockup pkgutil module class."""
        def __init__(self, val: str):
            self.__val = val
        def __call__(self, *_, **__):
            return self
        def __iter__(self):
            return iter([('module', 'a', self.__val), ('module', 'b', self.__val)])


# Generated at 2022-06-21 09:52:51.520579
# Unit test for function gen_api
def test_gen_api():
    pass

# Generated at 2022-06-21 09:55:35.523134
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import shutil
    from .__init__ import __file__ as root
    from tempfile import mkdtemp
    from .parser import parent
    for _, _, fs in walk(os.path.dirname(root)):
        if '__init__.py' not in fs or '__init__.pyi' in fs:
            continue
        break
    path = parent(root)
    name = parent(path)
    # Create a temporary directory
    temp_path = mkdtemp()
    for f in fs:
        if f == "__init__.py":
            continue
        shutil.copy(join(path, f), temp_path)

# Generated at 2022-06-21 09:55:39.481426
# Unit test for function walk_packages
def test_walk_packages():
    """Load packages without import them."""
    assert list(walk_packages('test', '.')) == [
        ('test.data', '.\\test\\data.pyi'),
        ('test.data.test', '.\\test\\data\\test.pyi'),
    ]


if __name__ == "__main__":
    """Test for function `gen_api`."""
    for doc in gen_api(root_names={"test": "test"}, prefix="docs/test"):
        print(doc)

# Generated at 2022-06-21 09:55:48.138741
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from tempfile import TemporaryDirectory
    from pyslvs_ui.io import write_file
    from pytest import approx, raises
    from os.path import exists, isfile
    from .parser import no_link
    from .constants import STANDARD_TOC

    with TemporaryDirectory() as tmpdir:
        spec = {}
        root = 'pyslvs_ui'

# Generated at 2022-06-21 09:55:57.168961
# Unit test for function gen_api
def test_gen_api():
    from tempfile import TemporaryDirectory
    from shutil import which
    from subprocess import Popen, PIPE

    with TemporaryDirectory() as temp:
        with open(join(temp, '__init__.py'), 'w'):
            pass
        if which('python') is not None:
            with open(join(temp, 'a.py'), 'w') as f:
                f.write('"""Module A."""\n\nclass A: ...\n')
            with open(join(temp, 'b.py'), 'w') as f:
                f.write('"""Module A.B."""\n')
            with open(join(temp, 'c.py'), 'w') as f:
                f.write('"""Module A.C."""\n')

# Generated at 2022-06-21 09:56:00.171766
# Unit test for function walk_packages
def test_walk_packages():
    """Walk packages."""
    assert isinstance(parent(''), str)
    for name, path in walk_packages('pyslvs', '.'):
        assert isinstance(name, str)
        assert isinstance(path, str)
        assert isdir(parent(path))
        assert isfile(path + '.py') or isfile(path + '.pyi')

# Generated at 2022-06-21 09:56:07.313794
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from sys import platform
    from os.path import curdir, join, basename
    from doctest import testmod
    from . import __file__ as PYSLVS_MODULES
    pkg_path = dirname(PYSLVS_MODULES)
    docs = gen_api({'Pyslvs': 'pyslvs', 'Pytopo': 'pytopo'}, pkg_path, level=2, dry=True)
    testmod()
    if platform == 'darwin' or platform.startswith('linux'):
        path = curdir + '/' + 'docs'
        with open(join(path, basename(PYSLVS_MODULES))) as f:
            assert ''.join(docs) in f.read()

# Generated at 2022-06-21 09:56:14.049889
# Unit test for function gen_api
def test_gen_api():

    def dummy_loader(name: str, path: str,
                     p: Parser) -> bool: return True

    root_names = {'test1': 'test1', 'test2': 'test2'}
    p = Parser.new(True, 1, False)
    p.parse = dummy_loader
    assert gen_api(root_names, 'pyslvs/pyslvs', prefix='api', dry=True)

# Generated at 2022-06-21 09:56:21.306646
# Unit test for function loader
def test_loader():
    """Test the package searching algorithm."""
    from ..pathlinker.__main__ import test_docstring
    from ..pathlinker.op_compiler import op_compiler
    from ..pathlinker.path_compiler import path_compiler
    from ..pathlinker.link_compiler import link_compiler
    from ..pathlinker.constraint_compiler import constraint_compiler

# Generated at 2022-06-21 09:56:23.900081
# Unit test for function loader
def test_loader():
    from .test_utils import check_tmp_dir

# Generated at 2022-06-21 09:56:25.188022
# Unit test for function loader
def test_loader():
    print(gen_api(dict(SLVS='pyslvs')))