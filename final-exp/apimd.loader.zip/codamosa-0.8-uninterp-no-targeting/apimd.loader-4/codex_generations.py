

# Generated at 2022-06-21 09:50:15.091734
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    logger.info('Testing function `loader`')
    import pyslvs
    doc = loader('pyslvs', dirname(pyslvs.__file__), True, 2, False)
    _write('test_doc.md', doc)

# Generated at 2022-06-21 09:50:26.184817
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    import tempfile
    from os import path

    with tempfile.TemporaryDirectory() as tmpdirname:
        root1 = path.join(tmpdirname, "root1")
        root2 = path.join(tmpdirname, "root2")
        h1 = path.join(root1, "__init__.py")
        h2 = path.join(root2, "__init__.py")
        m1 = path.join(root1, "mixin.py")
        m2 = path.join(root2, "mixin.py")
        _write(h1, "'''Docstring for __init__.py'''")
        _write(h2, "'''Docstring for __init__.py'''")

# Generated at 2022-06-21 09:50:34.185428
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('pyslvs', 'tests')) == [
        ('pyslvs.math', 'tests\\pyslvs\\math.py'),
        ('pyslvs_ui.project', 'tests\\pyslvs_ui\\project.py'),
        ('pyslvs_ui.info.package_info', 'tests\\pyslvs_ui\\info\\package_info.py'),
        ('pyslvs_ui.widgets.canvas.geometry', 'tests\\pyslvs_ui\\widgets\\canvas\\geometry.py'),
        ('pyslvs_ui.widgets.canvas.geometry.__init__', 'tests\\pyslvs_ui\\widgets\\canvas\\geometry\\__init__.py'),
    ]

# Generated at 2022-06-21 09:50:44.797403
# Unit test for function walk_packages
def test_walk_packages():
    from shutil import rmtree
    import json
    import tempfile
    TEMP_DIR = tempfile.mkdtemp()

    def autogen(path, content):
        path = path.replace('.', sep)
        dirs = path.split(sep)
        for d in dirs[:-1]:
            d = join(TEMP_DIR, d)
            if not isdir(d):
                mkdir(d)
        if path.endswith(sep):
            with open(join(TEMP_DIR, path + '__init__.pyi'), 'w') as f:
                f.write(f'"""\n{content}\n"""\n')

# Generated at 2022-06-21 09:50:55.885192
# Unit test for function loader
def test_loader():
    """Test function loader."""
    import os
    import random
    from .logger import set_logging_level

    set_logging_level(40)
    root = "BOOM"
    pwd = os.path.dirname(__file__)
    for _ in range(1):
        logger.info(f"Start test: {root}")
        prefix = f"{root}-api{random.randint(1, 10000)}"
        docs = gen_api(
            {root: root},
            pwd,
            prefix=prefix,
            link=False,
            level=1,
            toc=False,
            dry=False
        )
        assert len(docs) == 1
        logger.info(f"Remove directory: {prefix}")

# Generated at 2022-06-21 09:51:00.138517
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from shutil import copy
    from .parser import link
    from .search import has_base_link
    from pathlib import Path

# Generated at 2022-06-21 09:51:09.572991
# Unit test for function gen_api
def test_gen_api():
    """Test for gen_api."""
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os.path import join as join_path
    from subprocess import Popen, PIPE

    with TemporaryDirectory(prefix='pyslvs_site_') as site_path, \
        TemporaryDirectory(prefix='pyslvs_api_') as api_path:

        # Write base templates
        open(join_path(site_path, '__init__.py'), 'w')
        open(join_path(site_path, 'a.py'), 'w')
        open(join_path(site_path, 'b.pyi'), 'w')
        open(join_path(site_path, 'c.py'), 'w')

# Generated at 2022-06-21 09:51:19.895860
# Unit test for function loader
def test_loader():
    # pylint: disable=C0103
    # pylint: disable=pointless-statement
    import os
    import unittest

    class LoaderTestCase(unittest.TestCase):
        """Loader test case."""

        pwd = os.getcwd()
        name = "pyslvs_ui"

# Generated at 2022-06-21 09:51:25.018249
# Unit test for function loader
def test_loader():
    def test_tuple(tup: tuple[str, str]) -> None:
        mod_name, file_path = tup
        print(mod_name, file_path)

    p = r"C:\Users\Yuan Chang\AppData\Local\Programs\Python\Python38\Lib\site-packages"
    for path in walk_packages('pyslvs_ui', p):
        test_tuple(path)

# Generated at 2022-06-21 09:51:33.888639
# Unit test for function walk_packages
def test_walk_packages():
    def create(r):
        mkdir(r)
        _write(join(r, '__init__.py'), '#! /usr/bin/env python3')
        _write(join(r, 'a.py'), '# comment')
        mkdir(join(r, 'b'))
        _write(join(r, 'b', '__init__.py'), '# comment')

    with Parser.mock_import():
        create('root')
        for name, path in walk_packages('root', '.'):
            assert path == 'root' + sep + name.replace('.', sep)
        create('root-stubs')
        for name, path in walk_packages('root', '.'):
            assert path == 'root-stubs' + sep + name.replace('.', sep)


# Unit test

# Generated at 2022-06-21 09:52:50.690541
# Unit test for function walk_packages

# Generated at 2022-06-21 09:53:03.083110
# Unit test for function walk_packages
def test_walk_packages():
    assert next(walk_packages("math", "/usr/lib/python3")) == (
        "math.__init__",
        "/usr/lib/python3/math/__init__.py",
    )
    assert next(walk_packages("math", "/usr/lib/python3.8")) == (
        "math.__init__",
        "/usr/lib/python3.8/math/__init__.py",
    )
    assert next(walk_packages("math", "/usr/lib/python3.9")) == (
        "math.__init__",
        "/usr/lib/python3.9/math/__init__.py",
    )

# Generated at 2022-06-21 09:53:05.852081
# Unit test for function walk_packages
def test_walk_packages():
    from collections.abc import Iterator
    import pkgutil
    pwd = dirname(pkgutil.__file__)
    root = 'pkgutil'
    fs = []
    for name, path in walk_packages(root, pwd):
        fs.append((name, path))
    assert isinstance(fs, Iterator)


# Generated at 2022-06-21 09:53:09.594837
# Unit test for function loader
def test_loader():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pathlib import Path
    from importlib import reload
    import pytest
    doc = "# Module A\n\n" \
          "## Class A\n\n" \
          "### a"

# Generated at 2022-06-21 09:53:20.113294
# Unit test for function loader
def test_loader():
    from json import load as json_load
    from tempfile import TemporaryDirectory
    from .logging import init_logger
    from .module import make_doc

    init_logger('ERROR')
    with TemporaryDirectory() as pwd:
        json_load(open('./tests/package.json'))["path"] = f"{pwd}/site-packages"
        json_load(open('./tests/package2.json'))["path"] = f"{pwd}/site-packages"
        json_load(open('./tests/module.json'))["path"] = f"{pwd}/site-packages"
        make_doc(
            "./tests/package.json",
            "./tests/package2.json",
            "./tests/module.json",
            "./package",
        )

# Generated at 2022-06-21 09:53:21.790047
# Unit test for function gen_api
def test_gen_api():
    assert len(gen_api({"Skeletons": "skeletons"}, dry=True)) > 0

# Generated at 2022-06-21 09:53:24.268880
# Unit test for function gen_api
def test_gen_api():
    pwd = dirname(__file__)
    gen_api(
        {'Example': 'example'},
        pwd,
        prefix=join(pwd, 'docs'),
        level=2,
        dry=True
    )

# Generated at 2022-06-21 09:53:28.475198
# Unit test for function walk_packages
def test_walk_packages():
    from pytest import raises
    # Find local module
    p = Parser.new()
    for name, path in walk_packages("hello", "."):
        p.parse(name, _read(path))
    assert p.compile()

    with raises(ImportError):
        walk_packages("error", ".")

# Generated at 2022-06-21 09:53:35.623831
# Unit test for function walk_packages
def test_walk_packages():
    from pyslvs import __path__ as pyslvs_path
    from .structopt import __path__ as structopt_path
    test_set = {
        'pyslvs': next(walk_packages('pyslvs', pyslvs_path[0])),
        'structopt': next(walk_packages('structopt', structopt_path[0])),
    }
    assert test_set['pyslvs'] == ('pyslvs', abspath(pyslvs_path[0])), test_set
    assert test_set['structopt'] == ('structopt', abspath(structopt_path[0])), test_set

# Generated at 2022-06-21 09:53:45.539914
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from .vendor import pytest
    from .vendor.importlib_resources import path
    from .confs import ROOT_NAMES
    from .version import __version__
    from .parser import __doc__

    root_names = {"Pyslvs": "pyslvs", **ROOT_NAMES}
    prefix = "."
    with path(__name__, '../CHANGELOG.md') as changelog:
        changelog_doc = "#" + _read(changelog)

    def _test_gen(title, name, link, level, toc, docs):
        pyslvs_doc = '#' * level + f" {title} API\r\n\r\n"

# Generated at 2022-06-21 09:57:14.954764
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("pyslvs", dirname(dirname(__file__)))) == \
        [("pyslvs", __file__), ("pyslvs.core", __file__)]

# Generated at 2022-06-21 09:57:21.607125
# Unit test for function gen_api
def test_gen_api():
    from tempfile import gettempdir
    from os import mkdir, removedirs
    from os.path import join
    from .parser import module_name_dict

    pwd = join(gettempdir(), 'pyslvs_test')
    prefix = join(pwd, 'docs')
    if isdir(pwd):
        removedirs(pwd)
    mkdir(pwd)
    _write(join(pwd, '__init__.py'), '')
    _write(join(pwd, '__init__.py'), '"""A brief introduction."""')
    _write(join(pwd, 'a.py'), '"""A brief introduction."""\n')
    _write(join(pwd, 'b.py'), '"""A brief introduction."""\n')

# Generated at 2022-06-21 09:57:25.679421
# Unit test for function gen_api
def test_gen_api():
    test_case = {
        "pyslvs": "pyslvs_ui",
        "PySlvs-UI": "pyslvs_ui",
    }
    assert gen_api(test_case)


if __name__ == '__main__':
    test_gen_api()

# Generated at 2022-06-21 09:57:27.997072
# Unit test for function loader
def test_loader():
    doc = loader('pyslvs', 'tests', False, 1, False)
    assert doc, 'Document is empty.'



# Generated at 2022-06-21 09:57:33.449019
# Unit test for function gen_api
def test_gen_api():
    """Test the function: gen_api"""
    import os
    import pyslvs
    root_names = {
        "Core": "pyslvs_core",
        "UI": "pyslvs_ui",
        "Qt": "pyslvs_qt",
    }
    docs = gen_api(root_names, prefix="tmp", pwd=os.path.dirname(pyslvs.__file__), dry=True)
    assert len(docs) == 3

# Generated at 2022-06-21 09:57:34.074355
# Unit test for function gen_api
def test_gen_api():
    pass

# Generated at 2022-06-21 09:57:39.551461
# Unit test for function loader
def test_loader():
    """Test package loader."""
    if _site_path("pyslvs"):
        raise AssertionError("[BUG] pyslvs already exist")
    if _site_path("tkinter"):
        raise AssertionError("[BUG] tkinter already exist")

# Generated at 2022-06-21 09:57:40.647156
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages("test", "test")) == [("test", "test/test")]

# Generated at 2022-06-21 09:57:45.120535
# Unit test for function gen_api
def test_gen_api():
    from tempfile import mkdtemp
    from os import rmdir
    from os.path import dirname, isdir, isfile
    from shutil import rmtree
    from subprocess import run
    from importlib import import_module
    from importlib.util import find_spec


# Generated at 2022-06-21 09:57:47.151047
# Unit test for function gen_api
def test_gen_api():
    """Test function `gen_api`."""
    logger.error(
        "Please execute `python setup.py develop` first to gen_api in unit test."
    )