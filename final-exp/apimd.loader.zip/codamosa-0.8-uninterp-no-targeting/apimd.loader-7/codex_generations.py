

# Generated at 2022-06-21 09:51:11.295970
# Unit test for function loader
def test_loader():
    from .test_inject import test_spec
    # Test for name
    assert test_spec.name == "test_inject"
    assert test_spec.__name__ == "test_inject"
    assert test_spec.__package__ == "pyslvs_ui.api"
    # Test for attributes
    assert test_spec.__loader__ is not None
    assert test_spec.__loader__.path == "test_inject.py"
    assert test_spec.__file__ is not None
    assert test_spec.__file__.replace("\\", "/") == abspath("test_inject.py")
    assert test_spec.__doc__ is not None
    assert test_spec.__doc__.strip().startswith("Unit test for function ")
    assert test_spec.__path__ is None

# Generated at 2022-06-21 09:51:20.476020
# Unit test for function loader
def test_loader():
    """Test package searching algorithm."""
    from .data import loader_data
    assert loader_data[0] == loader('fake', '.', 1, True, False)
    assert loader_data[1] == loader('fake', '.', 1, True, True)
    assert loader_data[2] == loader('fake', '.', 2, True, False)
    assert loader_data[3] == loader('fake', '.', 2, True, True)
    assert loader_data[4] == loader('fake', '.', 1, False, False)
    assert loader_data[5] == loader('fake', '.', 1, False, True)
    assert loader_data[6] == loader('fake', '.', 2, False, False)

# Generated at 2022-06-21 09:51:28.200544
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages."""
    def t(path: str, pwd: str, result: tuple[str, str]):
        """Test walk_packages."""
        assert next(walk_packages(path, pwd)) == result
    t("pyslvs", "tests/data/pyslvs", ("pyslvs.core", "tests/data/pyslvs/core.py"))
    t("pyslvs_ui", "tests/data/pyslvs_ui", ("pyslvs_ui.qt", "tests/data/pyslvs_ui/qt.py"))

# Generated at 2022-06-21 09:51:35.685829
# Unit test for function loader
def test_loader():
    """Test loader function."""
    path = parent(__file__)
    doc = loader("test_compiler", path, True, 2, True)
    # Check API
    assert "## hello" in doc
    assert "### def hello(word: str)" in doc
    assert "### def word(word: str)" in doc
    assert "#### def world" in doc
    assert "#### def aotw" in doc
    assert "##### class Hello" in doc
    # Check TOC
    assert "- [Definitions](#definitions)" in doc
    assert "- [Types](#types)" in doc
    assert "- [Classes](#classes)" in doc
    # Check class
    assert "#### def __init__(self, name: str)" in doc
    assert "#### def looks(self, name: str) -> bool" in doc


# Generated at 2022-06-21 09:51:44.258570
# Unit test for function walk_packages
def test_walk_packages():
    from os import chdir, pardir
    from os.path import abspath
    from io import StringIO
    from contextlib import redirect_stdout
    chdir(abspath(join(__file__, pardir, pardir, pardir)))
    with redirect_stdout(StringIO()) as buf:
        p = Parser.new()
        for name, path in walk_packages("pyslvs", "pyslvs"):
            p.parse(name, _read(path + ".py"))
        p.parse("pyslvs.ui.g2", _read("pyslvs/ui/g2.py"))
    assert buf.getvalue() == ''
    assert p.link == {}
    assert 'Solver' in p.docs
    assert 'frame' not in p.docs["Solver"]

# Generated at 2022-06-21 09:51:50.853321
# Unit test for function walk_packages
def test_walk_packages():
    l1 = list(walk_packages("Pyslvs", ".."))

# Generated at 2022-06-21 09:52:00.350825
# Unit test for function walk_packages
def test_walk_packages():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from io import StringIO

    with patch("sys.stdout", new=StringIO()) as test_out:
        with TemporaryDirectory() as temp_dir:
            # Create a dir structure which contains package
            Path(temp_dir).joinpath("my_package").mkdir()
            Path(temp_dir).joinpath("my_package", "__init__.py").touch()
            Path(temp_dir).joinpath("my_package", "foo_package").mkdir()
            Path(temp_dir).joinpath("my_package", "foo_package", "__init__.py").touch()
            Path(temp_dir).joinpath("my_package", "foo_package", "some.py").touch()

# Generated at 2022-06-21 09:52:04.761197
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for walk packages."""
    import matplotlib.pyplot as plt
    for name, path in walk_packages('matplotlib', plt.__path__[0]):
        print(f"{name} -> {path}")


if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-21 09:52:09.659557
# Unit test for function loader
def test_loader():
    """Test for function loader."""
    p = Parser.new(True, 1, False)
    assert _load_module('argparse', 'argparse-stubs.so', p)
    assert p.get_doc('argparse.ArgumentParser.add_argument') is not None
    assert p.get_doc(
        'argparse._ActionsContainer.add_argument'
    ) is not None
    assert p.get_doc(
        'argparse._ActionsContainer.add_argument_group'
    ) is not None
    assert p.get_doc(
        'argparse._ActionsContainer.add_mutually_exclusive_group'
    ) is not None

# Generated at 2022-06-21 09:52:19.967486
# Unit test for function loader
def test_loader():
    from os import system, remove
    from tempfile import TemporaryDirectory
    from .parse_api import parse_py

    with TemporaryDirectory() as path:
        for folder in ["a", "b", "c"]:
            system(f'mkdir {path}{sep}{folder}')
        for file in ["a.py", "b.py", "c.py"]:
            system(f'echo "" > {path}{sep}{file}')
        for name, f in [
            ("a.b", "b.py"),
            ("a.c.d", "c.py"),
            ("a", "a.py"),
        ]:
            parse_py(name, join(path, f), link=False, level=1, toc=False)


# Generated at 2022-06-21 09:53:44.091366
# Unit test for function loader
def test_loader():
    """Unit test for loader()."""
    assert isinstance(loader("__main__", __file__.replace("main.py", "")), str)

# Generated at 2022-06-21 09:53:52.312794
# Unit test for function gen_api
def test_gen_api():
    """Test function gen_api."""
    from os import remove
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from pkg_resources import resource_filename
    from .structures import Registry

    def add_fake_module(name, package_name):
        paths = sys_path[:]
        spec = find_spec(package_name)
        if spec is not None:
            path = spec.submodule_search_locations[0]
            if not path.endswith(sep):
                path += sep
        else:
            sys_path.append(abs_path)
            path = abs_path + sep
        with open(path + name + '.py', 'w+') as f:
            print("def test(): pass", file=f)
        sys_

# Generated at 2022-06-21 09:54:01.303593
# Unit test for function gen_api
def test_gen_api():

    assert not gen_api(
        {
            "Configuration": "config",
            "Controller": "controller",
            "Evaluate": "evaluate",
            "Path Solver": "path_solver",
            "Simulation": "simulation",
            "V-Plotter": "vplotter",
        },
        pwd=None,
        link=False,
        toc=False,
        level=1,
    )

# Generated at 2022-06-21 09:54:09.761894
# Unit test for function loader
def test_loader():
    """Extension module is not loaded on PyPy."""
    import sys
    import subprocess
    if sys.platform.startswith('win'):
        logger.info(f"Skip test: {__name__}")
        return
    if 'PYPY_VERSION' in dir(sys):
        logger.warning("Extension module is not loaded on PyPy")
        return
    from .toy import hello_world
    path = dirname(dirname(abspath(__file__)))
    hello_world.greet()

# Generated at 2022-06-21 09:54:10.843046
# Unit test for function gen_api
def test_gen_api():
    import pkgutil
    api = gen_api({'pyslvs': 'pyslvs'}, pkgutil.get_loader('pyslvs').path)

# Generated at 2022-06-21 09:54:19.997475
# Unit test for function walk_packages
def test_walk_packages():
    """Test walk_packages function."""
    root_names = {
        "Numpy": "numpy",
        "Scikit-learn": "sklearn",
        "Scikit-image": "skimage",
    }
    from pkgutil import walk_packages
    from os.path import sep, dirname, abspath
    from .compiler import walk_packages as c_walk
    from .logger import set_log_level
    from .compiler import loader, gen_api

    set_log_level("debug")
    for title, name in root_names.items():
        logger.info(f"Load root: {name} ({title})")
        logger.debug("Test walk_packages:")

# Generated at 2022-06-21 09:54:22.107170
# Unit test for function walk_packages
def test_walk_packages():
    """Unit test for function walk_packages"""
    for name, path in walk_packages('PySlvs', '.'):
        print(name, path)


# Generated at 2022-06-21 09:54:30.112315
# Unit test for function loader
def test_loader():
    import sys, io
    assert loader('builtins',
                  sep.join(sys.executable.split(sep)[:-1]),
                  True, 1, True)
    sys.stdout = io.StringIO()
    i = loader('os',
               sep.join(sys.executable.split(sep)[:-1]),
               True, 1, True)
    sys.stdout = sys.__stdout__
    b = i.split('`')  # type: ignore
    assert 'os.open' in b and 'os.scandir' in b
    assert len(b) < 41
    sys.stdout = io.StringIO()
    i = loader('os',
               sep.join(sys.executable.split(sep)[:-1]),
               True, 1, False)
    sys.stdout = sys

# Generated at 2022-06-21 09:54:34.854173
# Unit test for function gen_api
def test_gen_api():
    logger.info(
        '=' * 12 +
        '\nGenerate API test' +
        '\n=' * 12
    )
    logger.info(
        '\n## Unit test for functions, skip it when testing the whole module.\n'
    )


if __name__ == "__main__":
    test_gen_api()

# Generated at 2022-06-21 09:54:40.697901
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""
    from importlib.util import spec_from_loader
    docs = gen_api({'Solver': 'Solver'}, '.', dry=True)
    assert docs == ['# Solver API\n\n', '## Class `Solver`\n\n', 'Document.']
    spec = spec_from_loader('Test', None)
    assert spec is not None
    assert type(spec.loader)

# Generated at 2022-06-21 09:56:20.415013
# Unit test for function gen_api
def test_gen_api():
    from .logger import silence_logger
    for _ in range(2):
        gen_api({'Pyslvs': 'pyslvs'})
        gen_api({'Pyslvs': 'pyslvs', 'PyslvsUI': 'pyslvs_ui'})
    for _ in range(2):
        with silence_logger():
            gen_api({'Pyslvs': 'pyslvs'}, dry=True)
            gen_api({'Pyslvs': 'pyslvs', 'PyslvsUI': 'pyslvs_ui'}, dry=True)
    assert gen_api({'Pyslvs': 'pyslvs'})

# Generated at 2022-06-21 09:56:30.482296
# Unit test for function loader
def test_loader():
    """Test the loader function."""
    # pylint: disable=no-self-use
    class Parser:
        """Parser mock."""

        def __init__(self) -> None:
            """Initialize."""
            self.load_docstring = 0

        def __call__(self, _: str, __: str) -> None:
            """Call."""
            self.load_docstring += 1

    b_doc = "b module\n========="
    b_doc_stubs = "b module\n=========\n\nThis is not a stubs."
    c_doc = "c module\n========="
    c_doc_stubs = "c module\n=========\n\nThis is not a stubs."
    p = Parser()

# Generated at 2022-06-21 09:56:34.574179
# Unit test for function gen_api
def test_gen_api():
    assert 'show' in dir(gen_api)
    assert 'show' in dir(gen_api.show)
    assert 'show' in dir(gen_api.show.show)
    assert 'show' in dir(gen_api.show.show.show)
    assert 'show' in dir(gen_api.show.show.show.show)

# Generated at 2022-06-21 09:56:39.358970
# Unit test for function gen_api
def test_gen_api():
    """Unit test for function gen_api."""

# Generated at 2022-06-21 09:56:42.516497
# Unit test for function walk_packages
def test_walk_packages():
    p = parent(__file__)
    i = 0
    for name, path in walk_packages(__name__, p):
        assert name == __name__
        assert path.endswith(join(p, __file__))
        i += 1
    assert i == 1



# Generated at 2022-06-21 09:56:52.321920
# Unit test for function loader
def test_loader():
    logger.setLevel(10)

# Generated at 2022-06-21 09:57:00.592536
# Unit test for function walk_packages
def test_walk_packages():
    def read(name: str) -> str:
        """Read the script from file."""
        with open(name, 'r') as f:
            return f.read()
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    path = temp_dir.name
    mkdir(join(path, "spam"))
    with open(join(path, "spam", "egg.py"), 'w'):
        pass
    with open(join(path, "spam", "__init__.py"), 'w'):
        pass
    with open(join(path, "spam-stubs", "egg.pyi"), 'w'):
        pass
    for name, path in walk_packages("spam", path):
        assert read(path)

# Generated at 2022-06-21 09:57:05.285162
# Unit test for function gen_api
def test_gen_api():
    def fact(n: int) -> int:
        if n < 0:
            raise ValueError
        return 1 if n == 0 else n * fact(n - 1)
    gen_api({'Fact': 'test_compile'}, dry=True, prefix='.')
    assert fact(3) == 6
    assert fact(4) == 24

# Generated at 2022-06-21 09:57:15.614839
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import basename, dirname, exists
    from shutil import rmtree
    from .parser import _symbol, _definition, _docstring, _join

    def _assert(output, expect):
        return output == expect, f"{output}\n----\n{expect}"

    def _create():
        return open("test.py", "w+", encoding="utf-8")

    def _remove():
        remove("test.py")

    def _test_def(doc, func, docstring, depth):
        assert _assert(_symbol(doc, 0), func[0])
        assert _assert(_definition(doc, 0), func[1])
        assert _assert(_docstring(doc, 0), docstring)

# Generated at 2022-06-21 09:57:19.319278
# Unit test for function loader
def test_loader():
    """Test the function loader."""
    assert loader('pyslvs', '..', False, 1, False).strip()
    assert loader('pyslvs', '..', True, 1, False).strip()
    assert loader('pyslvs', '..', True, 3, True).strip()