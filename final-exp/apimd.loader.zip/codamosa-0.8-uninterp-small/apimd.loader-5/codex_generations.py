

# Generated at 2022-06-25 14:27:15.270441
# Unit test for function loader
def test_loader():
    import re

    def _text(text: str) -> str:
        text = re.sub('[^a-zA-Z0-9_]', '', text)
        return text, '+'.join(map(str.capitalize, text.split('_')))

    _root = 'draw2d'
    _title, _name = _text(_root)

    _pwd = '.'
    _prefix = '.'
    _link = True
    _level = 1
    _toc = False
    _dry = True

    print(gen_api({_root: _title}, _pwd, prefix=_prefix, link=_link, level=_level, toc=_toc, dry=_dry))

if __name__=='__main__':
    test_loader()

# Generated at 2022-06-25 14:27:15.813950
# Unit test for function loader
def test_loader():
    assert True

# Generated at 2022-06-25 14:27:17.709111
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('O-a+KCh\nbH', 'O-a+KCh\nbH')) == []


# Generated at 2022-06-25 14:27:24.441492
# Unit test for function loader
def test_loader():
    """Test function."""
    # O-a+KCh
    # bH

    result_0 = loader(str_0, str_0, True, 1, True)
    str_1 = '__main__'
    str_2 = ''
    int_0 = 5
    int_1 = 7
    dict_0 = {}
    dict_0[str_1] = str_0
    dict_0['pyslvs'] = str_0
    gen_api(dict_0, str_2, prefix=str_0, link=True, level=int_0, toc=True, dry=True)
    dict_1 = dict_0  # null
    dict_1['pyslvs'] = str_0

# Generated at 2022-06-25 14:27:31.411870
# Unit test for function loader
def test_loader():
    str_0 = '__main__'
    int_1 = 1
    bool_2 = True
    bool_3 = True
    bool_4 = False
    str_5 = 'X5'
    str_6 = 'docs'
    str_7 = ''
    list_8 = [str_7]
    tuple_9 = ('B' * 100, 'A' * 100)
    dict_10 = {tuple_9: list_8}
    str_11 = 'B' * 100
    bool_12 = True
    bool_13 = True
    bool_14 = True
    dict_15 = {str_11: loader(str_0, tuple_9, bool_12, int_1, bool_13)}



# Generated at 2022-06-25 14:27:32.178881
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()


# Generated at 2022-06-25 14:27:35.936447
# Unit test for function loader
def test_loader():
    assert(loader('', '', True, 1, True) == '')
    assert(loader('', '', False, 1, True) == '')
    assert(loader('', '', True, 1, False) == '')
    assert(loader('', '', False, 1, False) == '')

# Generated at 2022-06-25 14:27:39.899023
# Unit test for function loader
def test_loader():
    test_root_1 = 'pathlib'
    test_pwd_1 = 'D:\\home\\OneDrive - i.cn'
    test_link_1 = root_names = {}
    test_level_1 = 1
    test_toc_1 = True
    test_case_0()
    gen_api(root_names, test_pwd_1)

# Generated at 2022-06-25 14:27:45.431349
# Unit test for function loader
def test_loader():
    str_0 = 'O-a+KCh\nbH'
    str_1 = 'O-a+KCh\nbH'
    bool_0 = True
    int_0 = 1
    bool_1 = True
    bool_2 = True
    str_2 = loader(str_0, str_1, bool_0, int_0, bool_1)
    bool_3 = not bool_2
    assert str_2
    assert bool_3

# Generated at 2022-06-25 14:27:46.493755
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-25 14:28:44.863440
# Unit test for function loader
def test_loader():
    root_names = {
        "pyslvs_ui": "pyslvs_ui",
        "pyslvs": "pyslvs",
    }
    sequence_0 = gen_api(root_names, prefix="docs")

# Generated at 2022-06-25 14:28:52.841342
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 'test_import'
    str_1 = '1'
    str_2 = 'test_import'
    str_3 = 'api'
    str_4 = 'test_import'
    str_5 = '__init__'
    str_6 = 'test_import'
    str_7 = '__init__'
    str_8 = 'test_import'
    str_9 = 'api'
    str_10 = 'test_import'
    str_11 = '__init__'
    str_12 = 'test_import'
    str_13 = '__init__'
    str_14 = 'test_import'
    str_15 = 'api'
    str_16 = 'test_import'
    str_17 = '__init__'

# Generated at 2022-06-25 14:29:01.236403
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 'path'
    str_1 = 'name'
    iterator_0 = walk_packages(str_1, str_0)
    for sequence_0 in iterator_0:
        str_2, str_3 = sequence_0
        assert type(str_2) is str
        assert type(str_3) is str
    str_4 = 'f"{str_2} <= {str_3}"'
    str_5 = 'path/a.py'
    str_6 = 'path/b.py'
    str_7 = 'path/b/c.py'
    str_8 = 'path/b/d.py'
    str_9 = 'path/b/d/e.py'
    str_10 = 'path/b/f.pyi'

# Generated at 2022-06-25 14:29:09.120303
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import tempfile
    from io import open
    from pathlib import Path
    from unittest import TestCase

    def _createPackage(path, name):
        os.makedirs(os.path.join(path, name))
        with open(os.path.join(path, name, '__init__.py'), 'w') as f:
            f.write('')

    def _createStub(path, name, contents=None):
        stub_path = os.path.join(path, name + '-stubs')
        os.makedirs(stub_path)
        with open(os.path.join(stub_path, '__init__.pyi'), 'w') as f:
            f.write((contents or '') + '\n')


# Generated at 2022-06-25 14:29:15.087942
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import exists

    test_data = []
    for item in walk_packages('pyslvs', 'pyslvs'):
        if item[0] == 'pyslvs':
            test_data.append(item)
        if item[0] == 'pyslvs.algorithm':
            test_data.append(item)
    assert test_data[0] == ('pyslvs', 'pyslvs')
    assert test_data[1] == ('pyslvs.algorithm', 'pyslvs/algorithm')
    assert exists(test_data[0][1] + '.py')
    assert exists(test_data[1][1] + '.pyi')


# Generated at 2022-06-25 14:29:17.075695
# Unit test for function loader
def test_loader():
    dict_0 = {}
    str_0 = 'set'
    sequence_0 = gen_api(dict_0, prefix=str_0)


# Function loader

# Generated at 2022-06-25 14:29:25.440590
# Unit test for function loader
def test_loader():
    path_0 = 'set'
    path_1 = 'set'
    str_0 = 'set/__init__'
    str_1 = 'set/__init__'
    bool_0 = True
    # bool_1 = False
    num_0 = 8

    # Test Case 1
    path_0 = 'set'
    path_1 = 'set'
    str_1 = 'set/__init__'
    str_0 = 'set/__init__'
    bool_0 = True
    # bool_1 = False
    num_0 = 8

    print(loader(path_0, path_1, str_0, str_1, bool_0, num_0))



# Generated at 2022-06-25 14:29:28.998013
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = '~/github/grand_project/src/site-packages'

# Generated at 2022-06-25 14:29:30.280235
# Unit test for function loader
def test_loader():
    dict_0 = {}
    str_0 = 'set'
    sequence_0 = loader(dict_0, str_0, True, -1, False)

# Generated at 2022-06-25 14:29:36.831509
# Unit test for function walk_packages
def test_walk_packages():
    dict_0 = {}
    str_0 = 'sel'
    str_1 = 'sela'
    sequence_0 = walk_packages(str_0, str_1)
    int_0 = 0
    for item_0 in sequence_0:
        str_2, str_3 = item_0
        dict_0[str_2] = str_3
        int_0 = int_0 + 1
    assert int_0 == 7
    assert 'selenium' in dict_0
    assert 'selenium.webdriver.common.by' in dict_0
    assert dict_0['selenium'] == 'sel\\selenium'
    assert dict_0['selenium.webdriver.common.by'] == 'sel\\selenium\\webdriver\\common\\by'



# Generated at 2022-06-25 14:33:59.586860
# Unit test for function loader
def test_loader():
    assert not _load_module("~\\C[tWY{4U(A4 ", "~\\C[tWY{4U(A4 ", Parser.new())
    assert not _load_module("~\\C[tWY{4U(A4 ", "~\\C[tWY{4U(A4.py", Parser.new())
    assert not _load_module("~\\C[tWY{4U(A4 ", "~\\C[tWY{4U(A4.pyi", Parser.new())
    # None
    assert not _load_module("~\\C", "~\\C", Parser.new())


if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:34:07.291039
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import dirname, abspath, join
    from types import ModuleType
    from importlib.util import spec_from_file_location, module_from_spec

    def load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
            return True
        return False


# Generated at 2022-06-25 14:34:11.983587
# Unit test for function loader

# Generated at 2022-06-25 14:34:17.204446
# Unit test for function loader
def test_loader():
    site_path_1 = 'C:\\WINDOWS\\system32\\python38.zip'
    parser_1 = Parser.new(True, 1, False)
    name_1 = 'C:\\WINDOWS\\system32\\site-packages\\foo\\bar.py'
    bool_0 = _load_module('foo.bar', name_1, parser_1)
    assert bool_0 == False


if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:34:18.044856
# Unit test for function loader
def test_loader():
    print(loader("solver", ".", False, 1, True))



# Generated at 2022-06-25 14:34:21.835614
# Unit test for function loader
def test_loader():
    str_0 = '\\f8W3p_'
    str_1 = '\\C9cW'
    str_2 = '\\FZ"^dWD'
    str_3 = 'U&l|'
    str_4 = '\\C9cW'
    dict_0 = {str_0: str_1, str_2: str_3, str_4: str_4}
    loader(str_0, str_1, True, 1, False)


# Generated at 2022-06-25 14:34:24.398043
# Unit test for function loader
def test_loader():
    sys_path.append('')
    logger.info('=' * 12)
    gen_api({'jupyterlab': 'jupyterlab'}, '', dry=True)


if __name__ == "__main__":
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:34:33.085243
# Unit test for function walk_packages
def test_walk_packages():
    root = 'collections'
    path = 'C:\\Users\\User\\AppData\\Local\\Programs\\Python\\Python38\\lib\\site-packages'
    gen = walk_packages(root, path)
    assert next(gen) == ('collections', 'C:\\Users\\User\\AppData\\Local\\Programs\\Python\\Python38\\lib\\site-packages\\collections')
    assert next(gen) == ('collections.abc', 'C:\\Users\\User\\AppData\\Local\\Programs\\Python\\Python38\\lib\\site-packages\\collections\\abc')
    assert next(gen) == ('collections.abc.__init__', 'C:\\Users\\User\\AppData\\Local\\Programs\\Python\\Python38\\lib\\site-packages\\collections\\abc\\__init__')

# Generated at 2022-06-25 14:34:33.704950
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:34:34.320563
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()