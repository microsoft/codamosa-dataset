

# Generated at 2022-06-25 14:27:21.997942
# Unit test for function loader
def test_loader():
    list_0 = ['&', '&', '&', '&', '&']
    gen_api(dict(zip(list_0, list_0)))

# Generated at 2022-06-25 14:27:29.512968
# Unit test for function walk_packages
def test_walk_packages():
    # Check type hint
    assert isinstance(test_case_0(), Iterator[tuple[str, str]])

test_case_2 = None
test_case_4 = None
test_case_6 = None
test_case_8 = None
test_case_10 = None
test_case_12 = None
test_case_14 = None
test_case_16 = None
test_case_18 = None
test_case_20 = None
test_case_22 = None
test_case_24 = None
test_case_26 = None
test_case_28 = None
test_case_30 = None
test_case_32 = None
test_case_34 = None
test_case_36 = None
test_case_38 = None


# Generated at 2022-06-25 14:27:31.377508
# Unit test for function loader
def test_loader():
    dict_0 = dict()
    dict_0['pyslvs_ui'] = 'pyslvs_ui'
    test_case_1(dict_0)


# Generated at 2022-06-25 14:27:38.095867
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = ''
    str_1 = 'docs'
    str_2 = 'docs'
    list_0 = []
    tuple_0 = ()
    iterator_0 = walk_packages(str_0, str_1)
    for tuple_0 in iterator_0:
        str_0 = tuple_0[0]
        str_1 = tuple_0[1]
    test_case_0()
    iterator_0 = walk_packages(str_2, str_2)
    for tuple_0 in iterator_0:
        str_0 = tuple_0[0]
        str_1 = tuple_0[1]


# Generated at 2022-06-25 14:27:39.136242
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()


if __name__ == '__main__':
    test_walk_packages()

# Generated at 2022-06-25 14:27:42.424947
# Unit test for function loader
def test_loader():
    root_names = {'Pyslvs': 'pyslvs', 'Compiler': 'pyslvs_compiler'}

    def test_import():
        for title, name in root_names.items():
            __import__(name)

    test_import()
    gen_api(root_names, toc=True)

# Generated at 2022-06-25 14:27:45.440647
# Unit test for function walk_packages
def test_walk_packages():
    logger.info('Testing function walk_packages')
    try:
        test_case_0()
    except Exception as e:
        logger.error('Test failed!')
        logger.error(e)
        exit(-1)


# Generated at 2022-06-25 14:27:48.678170
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = '&'
    iterator_0 = walk_packages(str_0, str_0)
    list_0 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's']
    for index_0 in list_0:
        try:
            next(iterator_0)
        except StopIteration:
            pass



# Generated at 2022-06-25 14:27:50.847544
# Unit test for function loader
def test_loader():
    pwd = ""
    root_names = {}
    dry = True
    gen_api(root_names, pwd, dry=dry)


# Generated at 2022-06-25 14:27:54.905742
# Unit test for function loader
def test_loader():
    str_0 = 'pkgutil.html'
    dict_0 = {'pkgutil': 'pkgutil'}
    result = gen_api(dict_0)
    str_1 = '#'
    str_2 = ' pkgutil API\n\n'
    str_3 = '#'
    str_4 = '&'
    str_5 = '&'
    # print(result)


# Generated at 2022-06-25 14:29:04.148055
# Unit test for function walk_packages
def test_walk_packages():
    list_0 = []
    for value in walk_packages('', './'):
        list_0.append(value)
    assert(list_0[-1][1] == './compiler.py')


# Generated at 2022-06-25 14:29:11.779924
# Unit test for function loader
def test_loader():
    import math

    logger.setLevel(logging.DEBUG)
    # math.pi
    doc = loader('math', _site_path('math'), link=False, level=2, toc=True)

    # matplotlib.pyplot.legend
    doc = loader('matplotlib.pyplot', _site_path('matplotlib'), link=True, level=3, toc=False)

    # sympy.core.sympify
    doc = loader('sympy.core', _site_path('sympy'), link=True, level=4, toc=True)

    # sympy.core.sympify
    doc = loader('sympy.core', _site_path('sympy'), link=True, level=4, toc=True)

    # sympy.core.sympify
   

# Generated at 2022-06-25 14:29:13.305843
# Unit test for function loader
def test_loader():
    test_case_0()

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:29:15.666275
# Unit test for function loader
def test_loader():
    root = "pyslvs"
    pwd = "E:/Python37/Lib/site-packages/pyslvs"
    link = True
    level = 1
    toc = False
    output = loader(root, pwd, link, level, toc)
    print(output)


# Generated at 2022-06-25 14:29:20.208400
# Unit test for function loader
def test_loader():
    assert loader('_test', '.', True, 1, True)
    assert loader('_test', '.', True, 2, True)
    assert loader('_test', '.', True, 3, True)
    assert loader('_test', '.', True, 4, True)
    assert loader('_test', '.', True, 5, True)
    assert loader('_test', '.', True, 6, True)
    assert loader('_test', '.', True, 7, True)
    assert loader('_test', '.', True, 8, True)
    assert loader('_test', '.', True, 9, True)
    assert loader('_test', '.', True, 10, True)
    assert loader('_test', '.', True, 11, True)

# Generated at 2022-06-25 14:29:26.993396
# Unit test for function loader
def test_loader():
    from sys import path as sys_path
    sys_path.append('./')

    loader(
        'pyslvs',
        './',
        True,
        1,
        False
    )

    loader(
        'pyslvs',
        './',
        True,
        1,
        False
    )

    loader(
        'pyslvs',
        './',
        True,
        1,
        False
    )

    loader(
        'pyslvs',
        './',
        True,
        1,
        False
    )
    return True


# Generated at 2022-06-25 14:29:32.492879
# Unit test for function loader
def test_loader():
    # pylint: disable=C0116,C0115
    from unittest.mock import patch
    root_names = {'Pyslvs': 'pyslvs_ui'}
    with patch('pyslvs_ui.compiler.gen_api') as mock_gen_api, \
            patch('pyslvs_ui.compiler.sys_path.append') as mock_append:
        gen_api(root_names=root_names, dry=True, pwd='test_path')
        assert mock_append.call_args[0][0] == 'test_path'
        assert mock_gen_api.call_args[1]['root_names'] == root_names

# Generated at 2022-06-25 14:29:34.834086
# Unit test for function walk_packages
def test_walk_packages():
    print("Test for walk_packages")
    for name, path in walk_packages("pyslvs", "pyslvs"):
        print("  " + name)
        print("  " + path)
        print("-----")


# Generated at 2022-06-25 14:29:38.442562
# Unit test for function loader
def test_loader():
    test_case_0()
    assert gen_api({'test' : 'test_case_0'}, pwd='') == ['# API\n\n## test_module.py\n\n  * [test_case_0](#test_case_0)\n\n<a name="test_case_0"></a>\n\n### test_case_0\n\n    bool_0 = True']

# Generated at 2022-06-25 14:29:39.349230
# Unit test for function walk_packages
def test_walk_packages():
    walk_packages("test_case_0", "..")


# Generated at 2022-06-25 14:31:01.438215
# Unit test for function walk_packages
def test_walk_packages():
    import platform
    import os

    def walk_packages_test(name='__main__'):
        test_path = os.path.join(os.path.dirname(__file__), 'test_packages')
        for name, path in walk_packages(name, test_path):
            print(f'{name} => {path}')

    if platform.system() == 'Windows':
        walk_packages_test('test_main')
        walk_packages_test('test_main_stubs')
    else:
        walk_packages_test()
        walk_packages_test(name='test_main')
        walk_packages_test(name='test_main_stubs')

if __name__ == '__main__':
    test_case_0()
    test_walk_packages()

# Generated at 2022-06-25 14:31:03.318918
# Unit test for function loader

# Generated at 2022-06-25 14:31:04.927760
# Unit test for function loader
def test_loader():
    print(loader('pyslvs', "E:/github/pyslvs-ui/src/pyslvs_ui", True, 1, True))


# Generated at 2022-06-25 14:31:07.227007
# Unit test for function loader
def test_loader():
    p = Parser.new()
    for name, path in walk_packages("test_loader", "./test_loader"):
        print(name, path)
        p.parse(name, _read(path + ".py"))
    print(p.compile())


# Generated at 2022-06-25 14:31:08.151161
# Unit test for function loader
def test_loader():
    print(loader('pyslvs', 'docs', True, 1, False))

# Generated at 2022-06-25 14:31:11.600079
# Unit test for function walk_packages
def test_walk_packages():
    for name, path in walk_packages("pyslvs", "/Users/YuanChang/Desktop/Sites/SVN/pyslvs/pyslvs"):
        if name == "mpl_toolkits.mplot3d":
            assert path == "/Users/YuanChang/Desktop/Sites/SVN/pyslvs/pyslvs/mpl_toolkits/mplot3d"
    return True

# Generated at 2022-06-25 14:31:19.744277
# Unit test for function loader
def test_loader():
    """Test case for function loader"""

    # Test case for function _read
    def test_case_1():
        path_0 = "/root/pyslvs/pyslvs/__init__.py"
        __return_value = _read(path_0)
        assert __return_value is not None

    # Test case for function _write
    def test_case_2():
        path_0 = "/root/pyslvs/pyslvs/__init__.py"
        doc_0 = "from .color import *"
        __return_value = _write(path_0, doc_0)

    # Test case for function loader
    def test_case_3():
        root_0 = "pyslvs"
        pwd_0 = "/root/pyslvs"

# Generated at 2022-06-25 14:31:21.720569
# Unit test for function loader
def test_loader():
    assert loader('test_pkg', '.', True, 1, False)


# Generated at 2022-06-25 14:31:26.386310
# Unit test for function walk_packages
def test_walk_packages():
    # Test walk_packages_0
    assert walk_packages('zpy', '.') is not None and type(walk_packages('zpy', '.')) == iterator
    # Test walk_packages_1
    assert walk_packages('Python', '.') is not None and type(walk_packages('Python', '.')) == iterator
    # Test walk_packages_2
    assert walk_packages('', '.') is not None and type(walk_packages('', '.')) == iterator


# Generated at 2022-06-25 14:31:30.953422
# Unit test for function walk_packages
def test_walk_packages():
    pwd = dirname(abspath(__file__)) + sep + 'data'
    for name, path in walk_packages('test', pwd):
        if name != 'test':
            assert(name == 'test.test_ext')
            assert(path.endswith(sep + name.replace('.', sep)))
        else:
            assert(path.endswith(sep + 'test' + sep + '__init__.py'))

# Generator for test cases

# Generated at 2022-06-25 14:32:46.919279
# Unit test for function loader
def test_loader():
    # loader(root: str, pwd: str, link: bool, level: int, toc: bool) -> str:
    print(loader("acaduv") == "")

# Generated at 2022-06-25 14:32:53.841902
# Unit test for function loader
def test_loader():
    """Import modules and dump docstring."""
    root = "pyslvs"
    toc = '<!-- API TOC -->'
    p = Parser.new(True, 2, True)
    p.parse("pyslvs", '# API\n')
    p.toc += '<!-- API TOC -->\n'
    p.toc += f'- [{root}](#{root}-api)\n'
    for name, path in walk_packages(root, _site_path(root)):
        for ext in [".py", ".pyi", ".pyd", ".so"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")

# Generated at 2022-06-25 14:32:54.942271
# Unit test for function walk_packages
def test_walk_packages():
    walk_packages('pyslvs', '/usr/local/lib/python3.9/dist-packages')

# Generated at 2022-06-25 14:32:56.554029
# Unit test for function loader
def test_loader():
    assert list(walk_packages('pyslvs', r'C:\Users\pengx\AppData\Roaming\Python\Python38\site-packages')) != []


# Generated at 2022-06-25 14:33:02.801679
# Unit test for function loader
def test_loader():
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)
    loader('pyslvs', '.', False, 0, False)


# Generated at 2022-06-25 14:33:04.345275
# Unit test for function loader
def test_loader():
    test_case_0()
    assert loader("pkgutil", "./", True, 1, True)

# Generated at 2022-06-25 14:33:04.958465
# Unit test for function loader
def test_loader():
    # TODO

    pass

# Generated at 2022-06-25 14:33:10.768343
# Unit test for function walk_packages
def test_walk_packages():
    for _name, _path in walk_packages("test_case_0",""):
        str_0 = _name
        str_1 = _path
        str_2 = ""
        str_3 = ""
        bool_0 = _name == str_2
        bool_1 = _path == str_3
        bool_2 = bool_0 and bool_1
        str_4 = ""
        bool_3 = bool_2 and str_0 == str_2
        assert bool_3


# Generated at 2022-06-25 14:33:11.949647
# Unit test for function walk_packages
def test_walk_packages():
    walk_packages('../../../', '../../../')


# Generated at 2022-06-25 14:33:13.225352
# Unit test for function loader
def test_loader():
    assert len(gen_api(
        {
            "Unit test": "loader"
        },
        ".",
        link=False, level=1, toc=True, dry=True
    )) == 1