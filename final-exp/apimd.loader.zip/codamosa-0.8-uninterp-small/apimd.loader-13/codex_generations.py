

# Generated at 2022-06-25 14:28:20.993223
# Unit test for function loader
def test_loader():
    PWD = 'pyslvs'
    prefix = 'docs'
    root_name = 'pyslvs.api'
    if not isdir(prefix):
        mkdir(prefix)
    logger.info(f"Load root: {root_name} ({'Pyslvs API'})")
    doc = loader(root_name, _site_path(root_name), True, 1, False)
    doc = '#' + f" Pyslvs API\n\n" + doc
    _write(join(prefix, f"{root_name.replace('_', '-')}-api.md"), doc)
    # Test for walk package API
    test_case_0()

# Test for function gen_api

# Generated at 2022-06-25 14:28:23.042280
# Unit test for function loader
def test_loader():
    logger.info(loader(
        'pyslvs',
        '.',
        False,
        1,
        False
    ))


# Generated at 2022-06-25 14:28:29.838092
# Unit test for function loader
def test_loader():
    # test case
    # list 0
    list_0 = []
    # str 0
    str_0 = '-T7HtFQ'
    # str 1
    str_1 = '-T7HtFQ-stubs'
    # str 2
    str_2 = '-T7HtFQ-stubs.__init__'
    # str 3
    str_3 = '-T7HtFQ.__init__'
    str_4 = '-T7HtFQ.__init__'
    str_5 = '-T7HtFQ.__init__'
    # list 1
    list_1 = []
    # list 2

# Generated at 2022-06-25 14:28:34.293872
# Unit test for function loader
def test_loader():
    path_0 = 'r'
    str_0 = '*'
    str_1 = 'void'
    str_2 = 'void'
    str_3 = 'void'
    bool_0 = True
    int_0 = 0
    bool_1 = False
    str_4 = loader(str_0, path_0, bool_0, int_0, bool_1)
    if str_2 == str_3:
        str_5 = loader(str_1, path_0, bool_0, int_0, bool_1)


# Generated at 2022-06-25 14:28:36.710809
# Unit test for function walk_packages
def test_walk_packages():
    import pkgutil
    try:
        str_0 = '-T7HtFQ'
        iterator_0 = walk_packages(str_0, str_0)
    except (
        FileNotFoundError,
        ImportError,
        TypeError,
    ):
        print('Error:Walk Packages Fail')


# Generated at 2022-06-25 14:28:37.580736
# Unit test for function loader
def test_loader():
    loader('collections', 'collections', True, 2, False)



# Generated at 2022-06-25 14:28:38.625682
# Unit test for function loader
def test_loader():
    test_dict = {}
    gen_api(test_dict, prefix='./docs', dry=True)

# Generated at 2022-06-25 14:28:46.614796
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 'foo'
    str_1 = 'foo'
    str_2 = 'foo-stubs'
    str_3 = 'foo/__init__.py'
    str_4 = 'foo/foo.py'
    str_5 = 'foo/foo.pyi'
    list_0 = [str_3, str_4]
    list_1 = [str_3, str_5]

# Generated at 2022-06-25 14:28:55.028160
# Unit test for function walk_packages
def test_walk_packages():
    files = [
        'test/test_module.py',
        'test/test_module.pyi',
        'tests/__init__.py',
        'tests/__init__.pyi',
        'tests/test_module.py',
        'tests/test_module.pyi',
        'tests/stub/__init__.py',
        'tests/stub/test_module.py',
    ]

# Generated at 2022-06-25 14:28:55.844732
# Unit test for function loader
def test_loader():
    loader('',"",True,0,True)

# Generated at 2022-06-25 14:30:57.865062
# Unit test for function loader
def test_loader():
    pass


# Generated at 2022-06-25 14:30:58.783755
# Unit test for function loader
def test_loader():
    pass


# Generated at 2022-06-25 14:31:04.020258
# Unit test for function loader
def test_loader():
    # Test no root
    assert loader("wevsc", "wevsc", True, 2, False) == ""
    # Test no directory
    assert loader("_", "asdf", True, 2, False) == ""
    # Test no modules
    assert loader("_", "pyslvs", True, 2, False) == ""
    # Test with valid modules
    assert loader("_", "pyslvs.ui", True, 2, False) == loader(
        "_", "pyslvs", True, 2, False
    )


# Generated at 2022-06-25 14:31:05.649043
# Unit test for function loader
def test_loader():
    assert loader(
        root="test.example",
        pwd="test.example",
        link=True,
        level=1,
        toc=False
    )

# Generated at 2022-06-25 14:31:08.705089
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    # pylint: disable=unused-variable
    root = 'root_names'
    pwd = 'pwd'
    prefix = 'prefix'
    link = True
    level = 1
    toc = False
    dry = False
    gen_api(root, pwd, prefix, link, level, toc, dry)

# Generated at 2022-06-25 14:31:09.258681
# Unit test for function loader
def test_loader():
    pass



# Generated at 2022-06-25 14:31:12.705122
# Unit test for function loader
def test_loader():
    str_0 = '-T7HtFQ'
    bool_0 = True
    int_0 = 1
    bool_1 = False
    bool_2 = True
    bool_3 = False
    loader(str_0, str_0, bool_0, int_0, bool_1)
    loader(str_0, str_0, bool_2, int_0, bool_3)
    loader(str_0, str_0, bool_0, int_0, bool_3)
    loader(str_0, str_0, bool_2, int_0, bool_1)


# Generated at 2022-06-25 14:31:19.396719
# Unit test for function loader
def test_loader():
    str_0 = '/home/yuan/pyslvs/pyslvs_ui'
    dict_0 = {'a':'b'}
    # Exception raised for the next two lines:
    # AttributeError: 'NoneType' object has no attribute 'submodule_search_locations'
    # loader(dict_0, str_0)
    # loader(str_0, dict_0)
    dict_0 = {'a': 'b', 'c': 'd'}
    loader(str_0, str_0, True, 1, True)


# Generated at 2022-06-25 14:31:24.413858
# Unit test for function loader
def test_loader():
    str_0 = '-T7HtFQ'
    str_1 = '/png'
    int_0 = 0
    parser_0 = Parser.new(bool_0, int_0, bool_1)
    bool_0 = False
    bool_1 = False
    str_2 = loader(str_0, str_1, bool_0, int_0, bool_1)


# Generated at 2022-06-25 14:31:31.461667
# Unit test for function loader
def test_loader():
    """Test the logic of the API loader."""
    # Empty root
    assert loader("", ".", True, 1, True) == "### API\n"

    # Package does not exist
    assert loader("helloworld", ".", True, 1, True) == "### API\n"

    # Regression test.
    # This test is to verify that pyslvs correctly parses
    # API documents from both Python source code and stub files.
    vp_s = '#' * 2 + " `vpoint.py`\n"
    vp_s += "## `class vpoint.VPoint`\n"
    vp_s += "### `.x`\n"
    vp_s += "\n"
    vp_s += "```python\n"

# Generated at 2022-06-25 14:32:48.311409
# Unit test for function loader
def test_loader():
    dict_0 = dict()
    dict_0['collections'] = 'collections'
    str_0 = '../pyslvs/solvers/direct'
    sequence_0 = gen_api(dict_0, str_0)


if __name__ == "__main__":
    pass

# Generated at 2022-06-25 14:32:54.778646
# Unit test for function loader
def test_loader():
    str_0 = 'c'
    str_1 = '__init__'
    str_2 = 'a'
    str_3 = '.py'
    str_4 = '/a'
    str_5 = str_4 + '/b'
    str_6 = str_0 + str_0
    str_7 = 'e'
    str_8 = str_2 + 'a'
    str_9 = str_0 + str_0 + str_0
    str_10 = str_7 + str_0 + str_0
    str_11 = str_5 + '/' + str_0
    str_12 = '/' + str_9
    str_13 = str_10 + str_3
    str_14 = str_8 + str_3
    str_15 = str_5 + '/' + str_2


# Generated at 2022-06-25 14:32:59.636381
# Unit test for function loader
def test_loader():
    sequence_0 = []
    sequence_0.append((tuple(('.', '.', 'test.py')), (tuple(('.', '.', 'test.py')))))
    sequence_0.append((tuple(('./pyslvs/parser', '.', 'test.py')), (tuple(('.', '.', 'test.py')))))
    sequence_0.append((tuple(('./pyslvs/parser', '.', 'test.pyi')), (tuple(('.', '.', 'test.pyi')))))

# Generated at 2022-06-25 14:33:01.722068
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    sequence_0 = gen_api(dict_0)


# Generated at 2022-06-25 14:33:04.518185
# Unit test for function loader
def test_loader():
    try:
        from .test_files import test_path
    except ImportError:
        logger.error('Testing skipped. Please run `make test` for testing.')
        return
    res = loader(
        'test_data',
        test_path,
        link=False,
        level=1,
        toc=False
    )
    print(res)

# Generated at 2022-06-25 14:33:06.200644
# Unit test for function loader
def test_loader():
    loader('collections', '',
        link=True,
        level=1,
        toc=False,
    )

# Generated at 2022-06-25 14:33:10.656682
# Unit test for function loader
def test_loader():
    root = 'xml.etree.ElementTree'
    pwd = r'C:\Users\Chang Yuan\Anaconda3\lib\xml\etree'
    test_doc = loader(root, pwd, True, 1, False)
    assert isinstance(test_doc, str)
    assert test_doc.strip()


# Generated at 2022-06-25 14:33:12.356892
# Unit test for function loader
def test_loader():
    sys_path.append(abspath('.'))
    print(loader('collections', '', True, 1, False))


# Generated at 2022-06-25 14:33:16.246224
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    str_1 = 'C:\\Python38\\Lib\\site-packages'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    sequence_0 = gen_api(dict_0, str_1)

# Generated at 2022-06-25 14:33:19.247144
# Unit test for function loader
def test_loader():
    assert len(loader('collections', '', True, True, True))
    assert len(loader('collections', '', False, False, False))


# Generated at 2022-06-25 14:34:43.181799
# Unit test for function loader
def test_loader():
    loader('collections', '/home/yuan/anaconda3/envs/pyslvs_ui_docker/lib/python3.8/site-packages', True, 1, True)

if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:34:46.605901
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    pwd = None
    prefix = 'docs'
    link = True
    level = 1
    toc = False
    dry = False
    gen_api(str_0, pwd, prefix, link, level, toc, dry)


# Generated at 2022-06-25 14:34:54.013493
# Unit test for function loader

# Generated at 2022-06-25 14:34:56.212542
# Unit test for function loader
def test_loader():
    assert 'collections' in loader('collections', dirname(__file__), True, 1, False)


# Generated at 2022-06-25 14:34:57.557113
# Unit test for function loader
def test_loader():
    s_loader = loader('collections', '/usr/lib/python3.7/', True, 1, False)
    assert len(s_loader) > 0

# Generated at 2022-06-25 14:35:01.289142
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = True
    loader(str_0, dict_0, bool_0, 1, False)



# Generated at 2022-06-25 14:35:05.118716
# Unit test for function loader
def test_loader():
    sys_path.append(r'D:\Programming\python\packages')
    d = {'pyslvs': 'pyslvs'}
    for i in gen_api(d, pwd=r'D:\Programming\python\packages', dry=True):
        assert i

# Generated at 2022-06-25 14:35:07.286779
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    gen_api(dict_0, '', dry=True)


# Generated at 2022-06-25 14:35:09.430088
# Unit test for function loader
def test_loader():
    loader('collections', '/usr/lib/python3.8/collections')


# Generated at 2022-06-25 14:35:11.607693
# Unit test for function loader
def test_loader():
    print(loader('collections', '/usr/local/lib/python3.6/site-packages', True, 1, True))
