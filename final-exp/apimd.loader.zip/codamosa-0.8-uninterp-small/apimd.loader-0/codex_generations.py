

# Generated at 2022-06-25 14:28:38.652847
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 't>lMa;%>nbR^y9j]Z'
    iterator_0 = walk_packages(str_0, str_0)

# Generated at 2022-06-25 14:28:45.953886
# Unit test for function walk_packages
def test_walk_packages():
    str_var_0 = 't>lMa;%>nbR^y9j]Z'
    iterator_var_0 = walk_packages(str_var_0, str_var_0)
    for tuple_var_0 in iterator_var_0:
        str_var_1, str_var_2 = tuple_var_0
    dict_var_0 = {'__slots__': str_var_1}
    str_var_3, int_var_0 = dict_var_0['__slots__']
    str_var_4, int_var_1 = dict_var_0['__slots__']
    str_var_5, int_var_2 = dict_var_0['__slots__']

# Generated at 2022-06-25 14:28:46.814252
# Unit test for function loader
def test_loader():
    assert parser({'a': 'a'}) is None

# Generated at 2022-06-25 14:28:55.219344
# Unit test for function loader
def test_loader():
    import unittest
    import logging
    import tempfile
    import shutil
    import os

    class Test(unittest.TestCase):
        def __init__(self, *args):
            super().__init__(*args)
            logging.basicConfig(level=logging.DEBUG)

        def test_loader(self):
            with tempfile.TemporaryDirectory() as temp:
                os.chdir(temp)
                shutil.copy(os.path.join(os.path.dirname(
                        os.path.realpath(__file__)), "test", "empty.py"), "test.py")
                os.mkdir("test1")

# Generated at 2022-06-25 14:28:57.978745
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 't>lMa;%>nbR^y9j]Z'
    test_case_0()
    # for k, v in walk_packages(str_0, str_0):
    #     print(k, v)


# Generated at 2022-06-25 14:29:01.640617
# Unit test for function loader
def test_loader():
    # Compile the API
    docs = gen_api({'pyslvs': 'pyslvs', 'pyslvs_ui': 'pyslvs_ui'}, dry=True)
    assert len(docs) == 2
    assert 'pyslvs_ui' in docs[0]

# Generated at 2022-06-25 14:29:02.947823
# Unit test for function loader
def test_loader():
    assert loader('collections', '', True, 1, True).strip()


# Generated at 2022-06-25 14:29:03.751329
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

# Generated at 2022-06-25 14:29:07.713450
# Unit test for function loader
def test_loader():
    str_0 = 'PySlvs'
    dict_0 = {'PySlvs': 'PySlvs'}
    list_0 = gen_api(dict_0, str_0, prefix='docs', link=True, level=2, toc=True, dry=True)

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-25 14:29:10.114982
# Unit test for function loader
def test_loader():
    str_0 = 't>lMa;%>nbR^y9j]Z'
    dict_0 = {'test': str_0}
    list_0 = gen_api(dict_0, str_0)
