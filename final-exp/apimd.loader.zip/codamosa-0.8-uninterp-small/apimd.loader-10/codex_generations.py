

# Generated at 2022-06-25 14:27:55.597767
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

# Generated at 2022-06-25 14:27:56.328958
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()


# Generated at 2022-06-25 14:27:57.490144
# Unit test for function loader
def test_loader():
    assert len(gen_api({
        'pyslvs': 'pyslvs'
    })) == 1

# Generated at 2022-06-25 14:28:05.557865
# Unit test for function loader
def test_loader():
    str_0 = "ag-8>&\nl_+'q5"
    str_1 = 'A>o]#7&VASlSth\rl|5'
    str_2 = 'a xO:Ef?X7V_NfB+0'
    str_3 = "tV(?\n&F>]2:0q3"
    boolean_0 = loader(str_0, str_1, True, 1, True)
    boolean_1 = loader(str_2, str_1, True, 6, True)
    boolean_2 = loader(str_2, str_1, False, 6, True)
    boolean_3 = loader(str_2, str_1, True, 6, False)

# Generated at 2022-06-25 14:28:06.371606
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 14:28:10.229188
# Unit test for function loader
def test_loader():
    str_0 = "j|2*1Nurw?R[}'(a]g&"
    str_1 = 'H?&+j<\x0b$d(>4'
    bool_0 = True
    int_0 = 1
    bool_1 = False
    str_2 = loader(str_0, str_1, bool_0, int_0, bool_1)


# Generated at 2022-06-25 14:28:15.378795
# Unit test for function loader
def test_loader():
    str_0 = "ag-8>&\nl_+'q5"
    str_1 = 'A>o]#7&VASlSth\rl|5'
    int_0 = 1 + 1 + 1
    bool_0 = True
    bool_1 = True
    bool_2 = False
    str_2 = loader(str_0, str_1, bool_1, int_0, bool_2)

# Generated at 2022-06-25 14:28:21.734130
# Unit test for function loader
def test_loader():
    str_0 = "mj-V7o3=F-wv^b*T6T/9"
    map_0 = {
        "yW8": "sN~",
        "]0ra": "I:Z$",
        "!E0": "l&zn",
    }
    str_1 = "Og"
    str_2 = 'q3M]t'
    bool_0 = False
    int_0 = 5
    bool_1 = True
    bool_2 = True
    str_3 = loader(map_0, str_0, str_1, int_0, bool_1, bool_2)


# Generated at 2022-06-25 14:28:28.653145
# Unit test for function walk_packages
def test_walk_packages():
    mut_str_1 = str()
    mut_str_0 = str()
    mut_str_0 = "ag-8>&\nl_+'q5"
    mut_str_1 = 'A>o]#7&VASlSth\rl|5'
    mut_iterator_0 = walk_packages(mut_str_0, mut_str_1)
    mut_int_0 = int(-3)
    if mut_iterator_0:
        mut_tuple_1 = next(mut_iterator_0)
        mut_str_1 = str()
        mut_str_1 = mut_tuple_1[0]
        mut_str_2 = str()
        mut_str_2 = mut_tuple_1[1]

# Generated at 2022-06-25 14:28:34.354240
# Unit test for function loader
def test_loader():
    print(loader('numpy', '/path/to/numpy/source', True, 1))
    print(loader('numpy.lib.recfunctions', '/path/to/numpy/source', True, 1))
    print(loader('numpy.lib.recfunctions', '/path/to/numpy/source', False, 1))
    print(loader('numpy.lib.recfunctions', '/path/to/numpy/source', True, 2))
    print(loader('numpy.lib.recfunctions', '/path/to/numpy/source', True, 1, True))
    print(loader('numpy.lib.recfunctions', '/path/to/numpy/source', True, 2, True))


# Generated at 2022-06-25 14:29:52.726957
# Unit test for function loader
def test_loader():
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 14:29:59.646771
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    import sys
    import os
    import hashlib
    import tempfile
    import shutil

    from .parser import Parser
    from . import walk_packages, gen_api

    MODULE = """
        from typing import List
        def foo() -> List[int]:
            return []
        """
    STUB = """
        from typing import List
        def foo() -> List[int]: ...
        """
    SUBMODULE = """
        def bar() -> None: pass
        """
    fd, temp_dir = tempfile.mkstemp()
    os.close(fd)
    os.mkdir(temp_dir)
    sys.path.insert(0, temp_dir)

# Generated at 2022-06-25 14:30:03.726389
# Unit test for function loader
def test_loader():
    str_0 = "pyslvs_ui"
    str_1 = "__init__.py"
    str_2 = "test_site-packages"
    bool_true = True
    int_0 = 0
    bool_false = False
    bool_0 = loader(str_0, str_1, bool_true, int_0, bool_false)


# Generated at 2022-06-25 14:30:08.107237
# Unit test for function loader
def test_loader():
    path = 'test_modules'
    root = 'test_loader'
    pwd = abspath(path)
    sys_path.append(pwd)
    print('\n' + '=' * 12)
    print(loader(root, _site_path(root), True, 1, False))
    for name, path_ in walk_packages(root, pwd):
        print(f'{name} ==> {path_}')


# Generated at 2022-06-25 14:30:15.627103
# Unit test for function walk_packages
def test_walk_packages():
    import os
    root = os.getcwd()
    print("\n")
    print("root: " + root)
    walk_packages("", root)
    # Expect:
    # parser => /home/yuan/Documents/PySLVS/pyslvs/compiler/parser.py
    # parser => /home/yuan/Documents/PySLVS/pyslvs/compiler/parser.pyi
    # test_case_0 => /home/yuan/Documents/PySLVS/pyslvs/compiler/test_case_0.py
    # test_case_1 => /home/yuan/Documents/PySLVS/pyslvs/compiler/test_case_1.py
    # test_case_2 => /home/yuan/Documents/PySLVS/pyslvs/

# Generated at 2022-06-25 14:30:18.463888
# Unit test for function loader
def test_loader():
    str_0, str_1 = '', ''
    sequence_0 = loader(str_0, str_1)
    return sequence_0

if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-25 14:30:27.043100
# Unit test for function loader
def test_loader():
    parser_0 = Parser.new(True, 1, False)
    for name, path in walk_packages('sys', sys_path[0]):
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.debug(f"{name} <= {path_ext}")
            parser_0.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.debug(f"loading extension module for fully documented:")
        for ext in EXTENSION_SUFFIXES:
            path_ext = path + ext
            if not isfile(path_ext):
                continue

# Generated at 2022-06-25 14:30:28.002792
# Unit test for function walk_packages
def test_walk_packages():
    walk_packages('tests', '../tests')


# Generated at 2022-06-25 14:30:35.400157
# Unit test for function loader
def test_loader():
    root = "test"
    pwd = "test_case"
    link = True
    level = 1
    toc = False
    loader(root, pwd, link, level, toc)

    link = True
    level = 1
    toc = False
    loader(root, pwd, link, level, toc)

    root = "test"
    pwd = "test_case"
    link = True
    level = 1
    toc = True
    loader(root, pwd, link, level, toc)

    root = "test"
    pwd = "test_case"
    link = True
    level = 1
    toc = False
    loader(root, pwd, link, level, toc)

    root = "test"
    pwd = "test_case"

# Generated at 2022-06-25 14:30:42.318659
# Unit test for function loader
def test_loader():
    import pygame
    import pyslvs
    import app
    import solvers
    assert pygame.__name__ == 'pygame'
    assert pyslvs.__name__ == 'pyslvs'
    assert app.__name__ == 'app'
    assert solvers.__name__ == 'solvers'
    sys_path.append(dirname(abspath(__file__)))
    assert loader('app', dirname(app.__file__))
    assert loader('solvers', dirname(solvers.__file__))
    assert loader('pygame', dirname(pygame.__file__))
    assert loader('pyslvs', dirname(pyslvs.__file__))



# Generated at 2022-06-25 14:32:35.662754
# Unit test for function loader
def test_loader():
    # test case 1
    root_names_1 = {'Pyslvs': 'pyslvs', 'PyslvsUI': 'pyslvs_ui', 'PyslvsDynamics': 'pyslvs_dynamics', 'PyslvsQt': 'pyslvs_qt'}
    pwd_1 = 'pyslvs'
    prefix_1 = 'docs'
    link_1 = True
    level_1 = 1
    toc_1 = False
    dry_1 = False
    gen_api(root_names_1, pwd_1, prefix=prefix_1, link=link_1, level=level_1, toc=toc_1, dry=dry_1)

    # test case 2

# Generated at 2022-06-25 14:32:42.417286
# Unit test for function loader
def test_loader():

    def test_case_0():
        """Unit test for test case 0"""
        # Arrange
        root = ''
        pwd = ''
        link = True
        level = 1
        toc = False
        # Act
        result = loader(root, pwd, link, level, toc)
        # Assert
        assert result == '', "result == ''"

    def test_case_1():
        """Unit test for test case 1"""
        # Arrange
        root = ''
        pwd = ''
        link = True
        level = 1
        toc = True
        # Act
        result = loader(root, pwd, link, level, toc)
        # Assert
        assert result == '', "result == ''"

# Generated at 2022-06-25 14:32:46.524117
# Unit test for function loader
def test_loader():
    # Modify the path if needed
    pwd = 'site-packages'
    # If it is not empty, the text will be printed to standard output
    dry = True
    gen_api({'Pyslvs': 'pyslvs'}, pwd=pwd, dry=dry)

# Generated at 2022-06-25 14:32:53.491129
# Unit test for function loader
def test_loader():
    from os import chdir, getcwd
    from pkgutil import get_loader
    from pathlib import Path
    from functools import partial

    # Searching algorithm
    pwd = getcwd()
    pwd = Path(pwd)
    pwd = Path(pwd, 'tests')
    pwd = str(pwd)
    pkgs = {'pkg_1': 'pkg_1', 'pkg_2': 'pkg_2', 'pkg_3': 'pkg_3'}
    link = False

    # Result
    result = {}
    for pkg in pkgs:
        print(f"load {pkg}")
        print("-" * 12)
        doc = loader(pkg, pwd, link, 1, False)
        print(doc)
        result[pkg] = doc

# Generated at 2022-06-25 14:32:56.690256
# Unit test for function loader
def test_loader():
    """Test case for function loader."""
    assert loader('sctool', '.', False, 0, False)
    assert loader('sctool', '.', True, 1, True)
    assert loader('sctool', '.', True, 2, True)
    assert loader('sctool', '.', True, 3, True)
    assert loader('sctool', '.', True, 4, True)

# Generated at 2022-06-25 14:33:03.196434
# Unit test for function walk_packages
def test_walk_packages():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as dir_path:
        dir_path = abspath(dir_path)
        name_0 = dirname(dir_path)

        class TestLoader(Loader):
            pass

        for _ in sys_path:
            if not _.startswith(name_0):
                continue
            sys_path.remove(_)
            logger.debug(f"Remove '{_}' from sys.path")
        logger.debug(f"Temporary directory: {dir_path}")

        # Generate dummy module
        mkdir(join(dir_path, 'dummy'))
        mkdir(join(dir_path, 'dummy-stubs'))

# Generated at 2022-06-25 14:33:05.515115
# Unit test for function loader
def test_loader():
    logger.info("Unit test for function loader start\n")
    test_case_0()
    logger.info("Unit test for function loader end\n")

# Generated at 2022-06-25 14:33:11.483769
# Unit test for function walk_packages
def test_walk_packages():
    rooted_path = {
        'test_compiler': 'tests/test_compiler/test_compiler.py',
        'test_compiler.test': 'tests/test_compiler/test/test.py',
        'test_compiler.test.test_walk_packages': 'tests/test_compiler/test/test_walk_packages.py'
    }
    for name, path in walk_packages('test_compiler', 'tests'):
        assert path == rooted_path[name]


# Generated at 2022-06-25 14:33:12.490702
# Unit test for function loader
def test_loader():
    assert [] == loader('', '', True, 1, False)

# Generated at 2022-06-25 14:33:18.329380
# Unit test for function walk_packages
def test_walk_packages():
    """Test Walk Packages

    Arguments:
        default {[type]} -- [description]
    """
    def add_path(path):
        if path not in sys_path:
            sys_path.append(path)
    add_path("./solving_repo/pyslvs_ui/pyslvs/group/")
    add_path("./solving_repo/pyslvs_ui/pyslvs/")
    for name, path in walk_packages('pyslvs', './solving_repo/'):
        logger.info(f"{name} <= {path}")
