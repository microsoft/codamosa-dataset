

# Generated at 2022-06-25 14:27:41.650537
# Unit test for function walk_packages
def test_walk_packages():
    # Test init
    test_case_0()

# Generated at 2022-06-25 14:27:42.393119
# Unit test for function loader
def test_loader():
    loader("builtins", "", True, 1, True)

# Generated at 2022-06-25 14:27:44.752094
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    logger.info("test")
    iterator_0 = walk_packages(str_0, str_0)
    test_case_0()

# Generated at 2022-06-25 14:27:46.189618
# Unit test for function loader
def test_loader():
    loader("pyslvs", None, True, 2, False)

# Generated at 2022-06-25 14:27:49.739704
# Unit test for function walk_packages
def test_walk_packages():
    from os import getcwd
    current_path = getcwd()
    package_name = "pyclipper"
    for name, path in walk_packages(package_name, current_path):
        assert isinstance(name, str)
        assert isinstance(path, str)


# Generated at 2022-06-25 14:27:50.604527
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:27:53.282718
# Unit test for function loader
def test_loader():
    """Unit test for loader function."""
    assert loader("numpy", "", True, 1, True)\
        .lstrip().startswith("# numpy API")


if __name__ == '__main__':
    test_loader()

# Generated at 2022-06-25 14:27:58.122738
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    iterator_0 = walk_packages(str_0, str_0)
    str_0 = None
    str_1 = None
    iterator_1 = walk_packages(str_0, str_1)
    str_0 = None
    str_1 = None
    iterator_2 = walk_packages(str_1, str_0)
    str_0 = None
    str_1 = None
    iterator_3 = walk_packages(str_1, str_1)


# Generated at 2022-06-25 14:28:03.276657
# Unit test for function loader
def test_loader():
    import sys
    import os
    print('\n')
    print(sys.path)
    print(os.getcwd())
    print('\n')
    root_names = {
        "bob": "bob",
    }
    prefix = ''
    link = True
    level = 1
    toc = False
    dry = False
    gen_api(
        root_names,
        "",
        prefix=prefix,
        link=link,
        level=level,
        toc=toc,
        dry=dry
    )

# Generated at 2022-06-25 14:28:08.792582
# Unit test for function walk_packages
def test_walk_packages():
    from .compiler_test_data import compiler_test_data
    def test_func(name, path):
        for name_cur, path_cur in walk_packages(name, path):
            assert name_cur == compiler_test_data[name][path]['name']
            assert path_cur == compiler_test_data[name][path]['path']

    for name in compiler_test_data:
        for path in compiler_test_data[name]:
            test_func(name, path)


# Generated at 2022-06-25 14:30:08.193685
# Unit test for function loader
def test_loader():
    # If the root_names is not a dict
    AssertionError = AssertionError
    try:
        gen_api([1, 2, 3], pwd=__file__)
    except AssertionError:
        pass
    try:
        gen_api(["1", "2", "3"], pwd=__file__)
    except AssertionError:
        pass
    # If the pwd is not a dir
    try:
        gen_api({"c": "test"}, pwd=__file__)
    except AssertionError:
        pass
    try:
        gen_api({"c": "test"}, pwd=__file__ + ".py")
    except AssertionError:
        pass
    # If the level is not an int

# Generated at 2022-06-25 14:30:10.482544
# Unit test for function loader
def test_loader():
    """Test for loader"""
    assert loader('bpy', './tests/', True, 2, True)
    assert loader('test_module', './tests/', True, 2, True)


# Generated at 2022-06-25 14:30:11.527452
# Unit test for function loader
def test_loader():
    assert loader('__main__', '.', True, 1, True)


# Generated at 2022-06-25 14:30:14.790473
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import dirname as dn
    ap = dn(dn(dn(abspath(__file__))))
    assert next(walk_packages('root', ap)) == (
        'root.parser',
        f'{ap}{sep}root{sep}parser.py'
    )

# Generated at 2022-06-25 14:30:18.874816
# Unit test for function loader
def test_loader():
    str_0 = 'hy`{i3m\x0c9V}|PUL\ro'
    dict_0 = {str_0: str_0, str_0: str_0}
    sequence_0 = gen_api(dict_0, prefix=str_0)
    assert sequence_0, 'empty list'


# Generated at 2022-06-25 14:30:21.567848
# Unit test for function loader
def test_loader():
    name = "test_py"
    root = name
    loader(root, "./tests", False, 1, False)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:30:29.436246
# Unit test for function loader
def test_loader():
    """Test for module loader."""
    assert loader('pyslvs', '.', False, 1, False).strip() != ""
    assert loader('pyslvs', '.', False, 1, False) == loader('pyslvs', '.', True, 1, False)
    assert (loader('pyslvs', '.', False, 3, False) ==
            loader('pyslvs', '.', False, 1, False) ==
            loader('pyslvs', '.', False, 2, False))
    assert (loader('pyslvs', '.', False, 3, True) ==
            loader('pyslvs', '.', False, 1, True) ==
            loader('pyslvs', '.', False, 2, True))

# Generated at 2022-06-25 14:30:37.165522
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os.path, contextlib
    from tempfile import TemporaryDirectory

    @contextlib.contextmanager
    def _syspath_context(path):
        path = os.path.abspath(path)
        sys.path.insert(0, path) # insert it at beginning to make it "top" priority.
        try:
            yield
        finally:
            sys.path.pop(0)

    with TemporaryDirectory() as tmpdir:
        tmppath = str(tmpdir)
        assert( os.path.isdir(tmppath) )
        pkg0 = "package_0"
        pkg1 = "package_1"
        pkg2 = "package_2"
        basename = "module_"

# Generated at 2022-06-25 14:30:41.114725
# Unit test for function walk_packages
def test_walk_packages():
    import unittest

    class TestWalkPackages(unittest.TestCase):

        def test_walk_packages(self):
            with unittest.mock.patch('sys.path', ["a", "b", "c"]):
                gen_api({}, pwd="b", dry=True)

    unittest.main(module=__name__)


if __name__ == "__main__":
    test_walk_packages()

# Generated at 2022-06-25 14:30:48.244909
# Unit test for function walk_packages
def test_walk_packages():
    packages = dict(walk_packages('pyslvs', '.'))
    assert packages['pyslvs.network'] == './pyslvs/network.pyi'
    assert packages['pyslvs.parser'] == './pyslvs/parser.pyi'
    assert packages['pyslvs.parser.parser'] == './pyslvs/parser/parser.pyi'
    assert packages['pyslvs.parser.parser.node'] == './pyslvs/parser/parser/node.pyi'
    assert packages['pyslvs_ui'] == './pyslvs_ui.pyi'
    assert packages['pyslvs_ui.dialogs'] == './pyslvs_ui/dialogs.pyi'

# Generated at 2022-06-25 14:34:26.810198
# Unit test for function walk_packages
def test_walk_packages():
    import os.path
    import sys

    def walk_packages_check(top, prefix=''):
        for path, dirs, files in os.walk(top):
            for dir in dirs:
                if dir in ('test', 'tests', 'testing'):
                    dirs.remove(dir)
            for file in files:
                if file != '__init__.py':
                    continue
                relpath = os.path.relpath(os.path.join(path, file), top)
                for name, pypath in walk_packages(prefix, top):
                    if relpath == pypath.replace(os.path.sep, '/'):
                        break
                else:
                    assert False, f"__init__.py missing in {prefix!r} " \
                                  f"({relpath!r})"

   

# Generated at 2022-06-25 14:34:31.246030
# Unit test for function loader
def test_loader():
    assert loader('', '.', True, 1, False) == ""
    assert loader('', '__init__.py', True, 1, False) == ""
    assert loader('test_loader', '.', True, 1, False) == ""
    assert loader('test_loader', 'pyslvs_ui', True, 1, False) == ""
    assert loader('pyslvs_ui', '.', True, 1, False) == ""


# Generated at 2022-06-25 14:34:38.244530
# Unit test for function walk_packages
def test_walk_packages():
    def test_case_0():
        str_0 = ';\x0b$9H\x17BsN'
        dict_0 = {}
        dict_0 = walk_packages(str_0, dict_0)
        for tuple_0 in dict_0:
            int_0 = len(tuple_0)
            str_1 = tuple_0[int_0]
            int_1 = len(str_1)
            int_2 = int_1 - 1
            str_2 = str_0[int_2]
            str_3 = str_1[int_0]
            int_0 = int_1 + int_2
            int_2 = int_2 + 1
            str_1 = str_1[int_2]
            int_2 = int_0 * int_1
            int_1

# Generated at 2022-06-25 14:34:43.951065
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 'yf@E\x0c\x7f{F\x0bO'
    dict_0 = {str_0: str_0, str_0: str_0}
    sequence_0 = gen_api(dict_0, prefix=str_0)
    for tuple_0 in walk_packages(str_0, str_0):
        assert isinstance(tuple_0, tuple)


# Generated at 2022-06-25 14:34:52.084677
# Unit test for function loader
def test_loader():
    from .logger import logger
    logger.info("Test for function loader")
    p = Parser.new()
    root = "robot"
    path = join("..", root)
    for name, path in walk_packages(root, path):
        logger.info(f"{name} <= {path}")
        pure_py = False
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            if not isfile(path_ext):
                continue
            logger.info(f"|- {path_ext}")
            p.parse(name, _read(path_ext))
            if ext == ".py":
                pure_py = True
        if pure_py:
            continue
        logger.info(f"|- loading extension module for fully documented:")
        # Try to

# Generated at 2022-06-25 14:34:55.263407
# Unit test for function loader
def test_loader():
    from pyslvs_ui.compiler import loader
    assert isinstance(loader("pyslvs", ".", True, 1, True), str)
    assert isinstance(loader("pyslvs", ".", True, 1, True), str)
    assert isinstance(loader("pyslvs", ".", True, 1, True), str)
    assert isinstance(loader("pyslvs", ".", True, 1, True), str)

# Generated at 2022-06-25 14:34:57.166604
# Unit test for function loader
def test_loader():
    logger.info(loader('pkgutil', '/usr/lib/python3.9', True, 2, True))

if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:35:06.269055
# Unit test for function walk_packages
def test_walk_packages():
    assert list(walk_packages('.__init__', 'a' + sep + 'b')) == [
        ('__init__', 'a' + sep + 'b' + sep + '.__init__'),
    ]

# Generated at 2022-06-25 14:35:10.729274
# Unit test for function loader
def test_loader():
    # Test case that can not find the module
    assert loader('abcde', '', True, 1, False) == ''
    # Test case that can not find the module
    assert loader('abcde', '', True, 1, False) == ''
    # Test case that has package but can not import
    assert loader('asdf', '', True, 1, False) == ''
    # Test case that has package but can not import
    assert loader('asdf', '', True, 1, False) == ''

# Generated at 2022-06-25 14:35:14.138451
# Unit test for function walk_packages
def test_walk_packages():
    p = "/Users/yuanchang/Library/Python/3.7/lib/python/site-packages/pyslvs"
    for i, j in walk_packages("pyslvs", p):
        print(i, j)
