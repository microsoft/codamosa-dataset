

# Generated at 2022-06-25 14:28:02.260782
# Unit test for function loader
def test_loader():
    str_0 = 'KcqCYnBd}fb*yjKt'
    str_1 = 'HwHa'
    bool_0 = True
    int_0 = 0
    bool_1 = False
    str_2 = ''
    str_3 = '~o'
    loader(str_0, str_1, bool_0, int_0, bool_1)
    loader(str_2, str_2, bool_0, int_0, bool_1)
    loader(str_3, str_0, bool_1, int_0, bool_1)

# Generated at 2022-06-25 14:28:08.963399
# Unit test for function loader
def test_loader():
    """Test case for loader."""
    gen_api({
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
        'Pyslvs-UI-Qt': 'pyslvs_ui_qt',
    })
    gen_api({'Pyslvs': 'pyslvs'})
    gen_api({'Pyslvs': 'pyslvs', 'Pyslvs-UI': 'pyslvs_ui'})

if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:28:09.460302
# Unit test for function loader
def test_loader():
    loader('', '')

# Generated at 2022-06-25 14:28:13.003839
# Unit test for function loader
def test_loader():
    # Test case 0
    for _ in range(0, 5):
        try:
            test_case_0()
        except Exception as e0:
            logger.error(f"Test case 0 failed: {e0}")
        else:
            logger.info("Test case 0 succeed.")



# Generated at 2022-06-25 14:28:19.936736
# Unit test for function loader
def test_loader():
    from os.path import join

    # Loader for python library
    assert len(
        loader(
            'xml',
            join('.', 'tests'),
            False,
            1,
            False
        )
    ) > 0

    # Loader for C++ extension module
    assert len(
        loader(
            '_elementtree',
            join('.', 'tests'),
            False,
            1,
            False
        )
    ) > 0

    # Loader for C extension module
    assert len(
        loader(
            'numpy.core.multiarray',
            join('.', 'tests'),
            False,
            1,
            False
        )
    ) > 0


# Generated at 2022-06-25 14:28:20.697176
# Unit test for function loader
def test_loader():
    test_case_0()

# Unit test

# Generated at 2022-06-25 14:28:24.665217
# Unit test for function loader
def test_loader():
    str_0 = 'docs'
    str_1 = 'pyslvs'
    str_2 = 'site-packages'
    str_3 = 'docs'
    str_4 = 'pyslvs'
    bool_0 = True
    int_0 = 1
    bool_1 = False
    loader(str_4, str_2, bool_0, int_0, bool_1)


# Generated at 2022-06-25 14:28:26.527729
# Unit test for function loader
def test_loader():
    gen_api({'test': 'test'})


if __name__ == "__main__":
    # test_case_0()
    test_loader()

# Generated at 2022-06-25 14:28:32.868609
# Unit test for function loader
def test_loader():
    str_0 = 'PP?NDFDa:`n]}JcB*dQk'
    str_1 = 'PP?NDFDa:`n]}JcB*dQk'
    str_2 = 'PP?NDFDa:`n]}JcB*dQk'
    str_3 = 'PP?NDFDa:`n]}JcB*dQk'
    str_4 = 'PP?NDFDa:`n]}JcB*dQk'
    str_5 = 'PP?NDFDa:`n]}JcB*dQk'
    str_6 = 'PP?NDFDa:`n]}JcB*dQk'
    str_7 = 'PP?NDFDa:`n]}JcB*dQk'

# Generated at 2022-06-25 14:28:37.976906
# Unit test for function loader
def test_loader():
    str_0 = 'gw;>1f}G3qH.@<h'
    str_1 = 'pJ(L#U6F5d;ex z'
    str_2 = '$2^U:N6Gn.6.yf'
    str_3 = 'W}#[n<n>c@#|*Q'
    str_4 = 'yS%*&a~]|+wf1'
    str_5 = 'D-kp$B.htX%-g'
    str_6 = '7Eo;)kDct1V<'
    str_7 = 'zA.[E*0@lzY>!'
    str_8 = 'GxCAsZ&95(!<'

# Generated at 2022-06-25 14:29:58.428471
# Unit test for function loader
def test_loader():
    gen_api(
        {
            'Test case 0': 'test_case_0',
        },
        '.'
    )

# Generated at 2022-06-25 14:29:59.524592
# Unit test for function loader
def test_loader():
    assert loader('io', '.', True, 1, True) == '# I/O API\n'


# Generated at 2022-06-25 14:30:00.206648
# Unit test for function loader
def test_loader():
    print('Test loader succeed.')


# Generated at 2022-06-25 14:30:01.507610
# Unit test for function loader
def test_loader():
    assert 'test_case_0' in loader('test', '', False, 1, False)

# Generated at 2022-06-25 14:30:03.093334
# Unit test for function loader
def test_loader():
    # Test case 0
    s = ''
    test_case_0()
    assert s == str_0

# Generated at 2022-06-25 14:30:06.610474
# Unit test for function loader
def test_loader():
    """Test case 0 succeed."""
    gen_api({"Pyslvs-core": "pyslvs_core", "V-rep": "vrep"}, "E:/My Documents/Visual Studio 2019/Projects/Release/LLT-2020-06/pyslvs_core")
    test_case_0()
    return

# Generated at 2022-06-25 14:30:08.708434
# Unit test for function loader
def test_loader():
    # Test case 0
    assert loader('', '', True, 1, True) == '', 'Test case 0 failed.'
    print('Test case 0 succeed.')


# Generated at 2022-06-25 14:30:10.021135
# Unit test for function loader
def test_loader():
    assert loader('slvs', 'package_tests', True, 3, True) != ''


# Generated at 2022-06-25 14:30:16.163159
# Unit test for function loader
def test_loader():
    import sys
    import os

    os.chdir('test_case')
    
    if sys.platform == 'win32':
        pwd = 'C:\\Users\\yua\\AppData\\Local\\Programs\\Python\\Python38-32\\Lib\\site-packages'
    else:
        pwd = '/Users/yua/Library/Python/3.8/lib/python/site-packages'
    
    # Run the test case
    gen_api({'Test case 0': 'test_case_0'}, pwd, prefix='.', dry=True)
    
    # Recover the directory
    os.chdir('..')

# Generated at 2022-06-25 14:30:16.670526
# Unit test for function loader
def test_loader():
    pass

# Generated at 2022-06-25 14:31:22.910311
# Unit test for function loader
def test_loader():
    path = abspath(__file__)
    root = dirname(path)
    pwd = parent(root)
    import test_pkg.core
    import test_pkg as test_pkg_1
    assert parent(test_pkg_1.core.__file__) == root + '/core'
    assert test_pkg_1.core.__file__ == root + '/core/__init__.py'
    assert test_pkg_1.core.__init__.__doc__.startswith(
        'This module provides :func:`core`'
    )
    assert test_pkg_1.core.feature.__doc__.strip() == ''
    assert test_pkg_1.core.feature.__name__ == test_pkg_1.core.__name__ + '.feature'
    assert test_pkg_1.core

# Generated at 2022-06-25 14:31:28.003002
# Unit test for function loader
def test_loader():
    from .parser import Parser

    def _read(path: str) -> str:
        with open(path, 'r') as f:
            return f.read()

    p = Parser.new(False, 1, False)
    for name, path in walk_packages('test_parser', 'tests'):
        p.parse(name, _read(path + '.py'))
    assert p.compile().strip()


if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:31:32.372048
# Unit test for function loader
def test_loader():
    for ext in EXTENSION_SUFFIXES:
        path = f"{__file__.replace('compiler.py', '')}pyslvs_ui{ext}"
        if not isfile(path):
            continue
        name = 'pyslvs_ui'
        p = Parser.new(True, 1, False)
        assert _load_module(name, path, p)
        break
    else:
        logger.warning('no test case for loading extensions')


# Generated at 2022-06-25 14:31:37.961681
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .solver_info import SolverInfo

    info = SolverInfo()
    info.add_module('test')
    info.add_field('test', 'a', 'int')
    info.add_field('test', 'b', 'float')
    info.add_field('test', 'c', '"NoneType"')
    info.add_method('test', 'd', ['x: "NoneType"'])
    info.add_method('test', 'e', ['x: "NoneType"'], '"NoneType"')
    info.add_method('test', 'f', ['x: "NoneType"'], '"NoneType"',
                    doc='Return x.')

# Generated at 2022-06-25 14:31:39.716642
# Unit test for function loader
def test_loader():
    loader('numpy', 'C:\\Users\\ychang\\AppData\\Roaming\\Python\\Python38\\site-packages')


# Generated at 2022-06-25 14:31:42.021848
# Unit test for function loader
def test_loader():
    str_0 = 'eanMu4'
    str_1 = 'docs'
    sequence_0 = gen_api({str_0: str_0}, pwd=str_0, prefix=str_1, dry=True)

# Generated at 2022-06-25 14:31:45.696465
# Unit test for function loader
def test_loader():
    p = Parser.new()
    # Test 1
    _load_module("collections.abc", "/tmp/collections/abc.pyi", p)
    # Test 2
    _load_module("collections.abc", "/tmp/collections/abc.py", p)
    # Test 3
    _load_module("collections.abc", "/tmp/collections/abc.c", p)

# Generated at 2022-06-25 14:31:48.986790
# Unit test for function loader
def test_loader():
    from .parser import Parser
    p = Parser(False, 1, False)
    for name, path in walk_packages('lxml', '/usr/local/lib/python3.8/dist-packages'):
        logger.debug(f"{name} <= {path}")
        p.parse(name, _read(path + '.pyi'))
    logger.info(p.compile())


# Generated at 2022-06-25 14:31:51.665949
# Unit test for function loader
def test_loader():
    root = 'eanMu4'
    pwd = '/Users/changyuan/PycharmProjects/GVSU/test/test_case_0'
    assert 'test_case_0' in loader(root, pwd, True, 1, False)


# Generated at 2022-06-25 14:31:54.207926
# Unit test for function loader
def test_loader():
    path_0 = "."
    str_0 = 'eanMu4'
    dict_0 = {str_0: str_0}
    sequence_0 = gen_api(dict_0, path_0, level=2)


# Generated at 2022-06-25 14:34:02.743827
# Unit test for function loader
def test_loader():
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs-UI': 'pyslvs_ui',
    }
    for d in gen_api(root_names):
        print(d)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:34:07.259195
# Unit test for function loader
def test_loader():
    try:
        import eanMu4
    except ImportError as e:
        logger.warning(f"Please install {e.name}")
        return
    logger.info("loader test case")
    assert loader("eanMu4", _site_path("eanMu4"), True, 1, False)


if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:34:10.820197
# Unit test for function loader
def test_loader():
    loader(__name__, dirname(abspath(__file__)), True, 0, False)

# Test case for unit test

# Generated at 2022-06-25 14:34:12.945021
# Unit test for function loader
def test_loader():
    dict_0 = {'dict_0': 'dict_0'}
    sequence_0 = loader('dict_0', '', True, 1, False)
    assert sequence_0 == ''


# Generated at 2022-06-25 14:34:20.067689
# Unit test for function loader
def test_loader():
    import os
    import sys
    data_file_path = os.path.join(os.path.dirname(__file__), 'root', 'test.py')
    dir_name = os.path.dirname(data_file_path)
    if dir_name not in sys.path:
        sys.path.append(dir_name)
    if data_file_path not in sys.path:
        sys.path.append(data_file_path)
    doc = loader('root', dir_name, True, 2, False)
    print('-'*10)
    print(doc)
    print('-'*10)

if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:34:21.980260
# Unit test for function loader
def test_loader():
    assert loader('pyslvs_ui', dirname(__file__), True, 2, True).strip() != ''
    assert loader('Qt', dirname(__file__), True, 2, True).strip() != ''

# Generated at 2022-06-25 14:34:26.161088
# Unit test for function loader
def test_loader():
    """Generate API of pyslvs."""
    gen_api({
        "pyslvs": "pyslvs",
        "pyslvs-ui": "pyslvs_ui"
    }, pwd=dirname(dirname(__file__)))

    gen_api({
        "Qt-for-Python": "PySide2"
    }, pwd=join(dirname(dirname(__file__)), 'pyslvs_ui'))

    gen_api({
        "NumPy": "numpy"
    }, pwd=join(dirname(dirname(__file__)), 'pyslvs_ui'))

# Generated at 2022-06-25 14:34:34.362192
# Unit test for function loader
def test_loader():
    current = "/home/changyuan/Desktop/pyslvs-examples-master/"
    root = "pyslvs"
    p = Parser.new(True, 1, False)
    for name, path in walk_packages(root, current):
        for ext in [".py", ".pyi"]:
            path_ext = path + ext
            logger.debug(f"{name} <= {path_ext}")
            if not isfile(path_ext):
                continue
            p.parse(name, _read(path_ext))
            if ext == ".py":
                continue
            for ext in EXTENSION_SUFFIXES:
                path_ext = path + ext
                if not isfile(path_ext):
                    continue
                logger.debug(f"{name} <= {path_ext}")

# Generated at 2022-06-25 14:34:36.637309
# Unit test for function loader
def test_loader():
    if '-v' in sys.argv[1:]:
        logger.setLevel(logging.INFO)
    test_case_0()


if __name__ == '__main__':
    import sys
    import logging
    sys.path.append('/usr/local/lib/python3.8/dist-packages')
    # logger.setLevel(logging.DEBUG)
    test_loader()

# Generated at 2022-06-25 14:34:37.290068
# Unit test for function loader
def test_loader():
    unit_test = True
    assert unit_test == True

