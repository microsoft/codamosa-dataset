

# Generated at 2022-06-25 14:28:54.533472
# Unit test for function walk_packages
def test_walk_packages():
    parser = Parser.new(True, 1, False)

# Generated at 2022-06-25 14:28:55.071080
# Unit test for function walk_packages
def test_walk_packages():
    pass

# Generated at 2022-06-25 14:28:56.456885
# Unit test for function loader
def test_loader():
    loader('svg', '../pyslvs_ui/solver', True, 1, True)

# Generated at 2022-06-25 14:29:00.902540
# Unit test for function loader
def test_loader():
    # Error case: no such module
    try:
        test_loader.__package__ = '_NO_SUCH_MODULE_'
        loader('logger', 'logger', True, 1, True)
    except Exception as e:
        # get module name from exception
        logger.error(f"Can't find root module: {str(e).split(':')[1].strip()}")


# Generated at 2022-06-25 14:29:01.722767
# Unit test for function loader
def test_loader():
    pass


# Generated at 2022-06-25 14:29:09.567714
# Unit test for function walk_packages
def test_walk_packages():
    str_1 = '_b'
    result_1 = list(walk_packages(str_1, str_1))

# Generated at 2022-06-25 14:29:13.209732
# Unit test for function loader
def test_loader():
    root_names = {'B': '_b'}
    pwd: Optional[str] = None
    prefix: str = 'docs'
    link: bool = True
    level: int = 1
    toc: bool = False
    dry: bool = False
    gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)

# Generated at 2022-06-25 14:29:13.861559
# Unit test for function loader
def test_loader():
    loader('_', '.', False, 1, False)

# Generated at 2022-06-25 14:29:15.785410
# Unit test for function loader
def test_loader():
    gen_api({"Solver": "solver"}, __file__, dry=True)


# import unittest
# class Test_Compile(unittest.TestCase):
#     def test_1(self):
#         test_case_0()

# Generated at 2022-06-25 14:29:16.878434
# Unit test for function loader
def test_loader():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 14:30:49.627539
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:30:51.487043
# Unit test for function loader
def test_loader():
    str_0 = 'logger'
    str_1 = loader(str_0, str_0, True, True, True)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 14:30:52.332260
# Unit test for function loader
def test_loader():
    test_case_0()

# Generate API

# Generated at 2022-06-25 14:30:54.012074
# Unit test for function loader
def test_loader():
    assert callable(loader)
    assert isinstance(loader('', '', False, False, False), str)



# Generated at 2022-06-25 14:31:01.761992
# Unit test for function walk_packages
def test_walk_packages():
    print('\nFunction: walk_packages')
    from os import sep
    from os.path import join, normcase
    from pylvs import walk_packages
    packages = []
    for name, path in walk_packages('test_logger', join('.', 'test')):
        # Filter out non-packages from test data
        if name == 'test':
            continue
        if sep in name:
            name = name[name.rindex(sep)+1:]
        if 'test_logger' in path:
            path = path[path.find('test_logger'):]
        packages.append(normcase(name + ' (' + path + ')'))
    print(packages)
    if packages != ['logger']:
        raise AssertionError('walk_packages')


# Generated at 2022-06-25 14:31:02.658580
# Unit test for function walk_packages
def test_walk_packages():
    def func_0():
        pass

# Generated at 2022-06-25 14:31:05.735565
# Unit test for function loader
def test_loader():
    test_case_0()
    # Code for unit test in VSCode
    # print(gen_api({ "pyslvs": "pyslvs", "pyslvs-ui": "pyslvs_ui" }, "pyslvs", link=False, level=3, toc=True, dry=False))

# Generated at 2022-06-25 14:31:11.803441
# Unit test for function loader
def test_loader():
    str_0 = 'logger'
    str_1 = 'logger'
    str_2 = loader(str_0, str_1, True, True, True)
    assert str_2 == '# ## logger API\n\n\n## Class Logger\n\n\n'
    str_3 = 'logger'
    str_4 = loader(str_3, str_1, True, True, True)
    assert str_4 == '# ## logger API\n\n\n## Class Logger\n\n\n'
    str_5 = 'logger'
    str_6 = 'logger'
    str_7 = loader(str_5, str_6, True, True, True)

# Generated at 2022-06-25 14:31:20.193607
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = 'dummy-package'
    str_1 = 'dummy-package-stubs'
    str_2 = 'dummy-package/__init__.py'
    str_3 = 'dummy-package/__init__.pyi'
    str_4 = 'dummy-package/dummy-sub-package/__init__.py'
    str_5 = 'dummy-package/dummy-sub-package/__init__.pyi'
    str_6 = 'dummy-package/dummy-sub-package/dummy-sub-sub-package/__init__.py'
    str_7 = 'dummy-package/dummy-sub-package/dummy-sub-sub-package/__init__.pyi'

# Generated at 2022-06-25 14:31:22.722526
# Unit test for function loader
def test_loader():
    from . import logger
    import sys
    sys.path.append('./tests/loader')
    _check(logger)
