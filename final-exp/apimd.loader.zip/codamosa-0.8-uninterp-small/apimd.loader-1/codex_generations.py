

# Generated at 2022-06-25 14:27:40.647891
# Unit test for function loader
def test_loader():
    str_0 = 'T'
    str_1 = 'U'
    bool_0 = True
    int_0 = 1
    bool_1 = False
    str_2 = loader(str_0, str_1, bool_0, int_0, bool_1)


# Generated at 2022-06-25 14:27:42.715979
# Unit test for function loader
def test_loader():
    assert loader(test_case_0, '', '') is None


if __name__ == '__main__':
    test_case_0()
    test_loader()
    logger.info('Test passed')

# Generated at 2022-06-25 14:27:45.848380
# Unit test for function loader
def test_loader():
    from pyslvs.pyslvs import gen_api
    gen_api({'Test': 'pyslvs_test'})
    gen_api({'Test': 'pyslvs_test'}, prefix='Test')


# Generated at 2022-06-25 14:27:49.378002
# Unit test for function loader
def test_loader():
    dry_0 = True
    str_0 = ''
    str_1 = ''
    link_0 = True
    int_0 = 1
    toc_0 = False
    loader(str_0, str_1, link_0, int_0, toc_0)


# Generated at 2022-06-25 14:27:53.283417
# Unit test for function loader
def test_loader():
    str_0 = ''

    str_1 = ''

    str_2 = ''

    str_3 = 'T'

    str_4 = ''

    str_5 = 'T'
    seq_0 = gen_api({str_0: str_1}, str_2, prefix=str_3, link=str_4, level=str_5)
    print(seq_0)

# Generated at 2022-06-25 14:27:54.050290
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

# Generated at 2022-06-25 14:27:54.532124
# Unit test for function loader
def test_loader():
    pass

# Generated at 2022-06-25 14:27:55.268972
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()


# Generated at 2022-06-25 14:27:57.441629
# Unit test for function loader
def test_loader():
    # Check for walk_packages
    test_case_0()

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:27:59.646481
# Unit test for function loader
def test_loader():
    root = 'collections'
    pwd = 'U'
    link = True
    level = 1
    toc = False
    loader(root, pwd, link, level, toc)

# Generated at 2022-06-25 14:29:33.487791
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    str_1 = '__init__'
    str_2 = 'collections.abc'
    str_3 = 'abc'
    str_4 = '__doc__'
    str_5 = 'str'
    str_6 = 'collections'
    str_7 = 'collections.__init__'
    str_8 = 'collections.abc.__init__'
    str_9 = 'collections.abc'
    str_10 = '[]'
    str_11 = 'Sequence'
    str_12 = 'Iterator'
    str_13 = '__module__'
    str_14 = '__name__'
    str_15 = 'abc'
    str_16 = 'collections'
    str_17 = 'collections.abc'
    str_18

# Generated at 2022-06-25 14:29:40.125069
# Unit test for function loader
def test_loader():
    import os

    class MockParser(Parser):

        def __init__(self, link: bool) -> None:
            super().__init__(link)
            self.content: str = ""
            self.title: str = ""

        def compile(self) -> str:
            return self.content

        def parse(self, name: str, doc: str) -> None:
            self.content += f"## {name}\n\n{doc}"

        def load_docstring(self, name: str, module: module) -> None:
            self.content += f"## {name}\n\n{module.__doc__}"

        @property
        def has_toc(self) -> bool:
            return True

    root = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-25 14:29:45.088790
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert loader("collections", "~/.local/lib/python3.9/site-packages", False, 1, False).strip()
    assert loader("collections", "~/.local/lib/python3.9/site-packages", True, 1, False).strip()
    assert loader("collections", "~/.local/lib/python3.9/site-packages", True, 2, False).strip()
    assert loader("collections", "~/.local/lib/python3.9/site-packages", True, 3, False).strip()
    assert loader("collections", "~/.local/lib/python3.9/site-packages", True, 1, True).strip()


# Generated at 2022-06-25 14:29:52.929945
# Unit test for function loader
def test_loader():
    parser = Parser(False, 1, False)
    # Try to import package
    importpkg = "python_qt_binding"
    try:
        path = _site_path(importpkg)
    except Exception:
        path = ""
    # Error messages
    assert loader("python_qt_binding", path, False, 1, False) == ""
    assert loader("python_qt_binding", path, False, 1, False) == ""
    assert loader("python_qt_binding", path, False, 1, False) == ""
    # Try to load the module
    path = abspath(path) + sep
    assert all(map(lambda x:
        _load_module(x[0], x[1], parser),
        walk_packages(importpkg, path)))

# Generated at 2022-06-25 14:29:53.792688
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:29:55.974752
# Unit test for function loader
def test_loader():
    """This function tests function loader."""
    str_0 = 'pyslvs'
    dict_0 = {str_0: str_0}
    gen_api(dict_0)


# Generated at 2022-06-25 14:30:01.890498
# Unit test for function loader
def test_loader():
    # Test case 1
    str_0 = 'pyslvs'
    int_0 = 1
    bool_0 = False
    dict_0 = {str_0: str_0, str_0: str_0}
    str_1 = 'site-packages'
    loader(str_0, str_1, bool_0, int_0, bool_0)
    # Test case 2
    loader(str_0, str_1, bool_0, int_0, bool_0)
    # Test case 3
    loader(str_0, str_1, bool_0, int_0, bool_0)
    # Test case 4
    loader(str_0, str_1, bool_0, int_0, bool_0)


# Generated at 2022-06-25 14:30:03.170699
# Unit test for function loader
def test_loader():
    # FIXME: refactor gen_api() to test
    pass

# Generated at 2022-06-25 14:30:04.555270
# Unit test for function loader
def test_loader():
    assert len(loader('collections', _site_path('collections'), False, 1, False)) > 0


# Generated at 2022-06-25 14:30:09.055771
# Unit test for function loader
def test_loader():
    names = ['pyslvs', 'pyvcpkg']
    modules = [None, None]
    loader(names[0], '', True, 1, False)
    try:
        logger.error("Start test `loader`")
        loader("pygears", '', False, 1, False)
        logger.error("`loader` failed")
        assert False
    except ModuleNotFoundError:
        assert True


# Generated at 2022-06-25 14:32:49.142047
# Unit test for function loader
def test_loader():
    from .parser import str_0, str_1
    loader(str_0, str_1)


# Generated at 2022-06-25 14:32:55.388747
# Unit test for function loader
def test_loader():
    name = 'test'
    path = f'{name}.py'
    if not isfile(path):
        assert False, f'File {path} not exist.'
    p = Parser.new()
    p.parse(name, _read(path))
    assert p.compile().strip()
    for ext in EXTENSION_SUFFIXES:
        path_ext = path + ext
        if not isfile(path_ext):
            continue
        logger.debug(f"{name} <= {path_ext}")
        if _load_module(name, path_ext, p):
            break
    assert p.compile().strip()
    # This module contains invalid syntax, should be ignored

# Generated at 2022-06-25 14:32:59.091862
# Unit test for function loader
def test_loader():
    import unittest
    from .test_loader import TestLoader
    from .test_parser import TestParser
    test_case = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(TestLoader),
        unittest.defaultTestLoader.loadTestsFromTestCase(TestParser),
    ])
    unittest.TextTestRunner().run(test_case)

# Generated at 2022-06-25 14:33:01.634694
# Unit test for function loader
def test_loader():
    # root, pwd, link, level, toc
    loader("i3", "./_tests/sample", True, 1, False)
    loader("i3", "./_tests/sample", True, 1, True)
    loader("i3", "./_tests/sample", False, 1, False)

# Generated at 2022-06-25 14:33:02.290037
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:33:04.415133
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    bool_0 = False
    dict_0 = {str_0: str_0, str_0: str_0}
    sequence_0 = gen_api(dict_0, toc=bool_0)


# Generated at 2022-06-25 14:33:06.922096
# Unit test for function loader
def test_loader():
    test_root = 'pyslvs'
    test_pwd = '/home/jianhong/Desktop/Project/pyslvs/src'
    test_link = True
    test_level = 1
    test_toc = True
    test_result = loader(test_root, test_pwd, test_link, test_level, test_toc)


# Generated at 2022-06-25 14:33:08.820712
# Unit test for function loader
def test_loader():
    name_0 = "pyslvs"
    pwd_0 = "../../../"
    str_0 = ""
    sequence_0 = gen_api({name_0: str_0}, pwd_0)


if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:33:17.235710
# Unit test for function loader
def test_loader():
    import pytest
    import pkgutil

    def readFile(name: str) -> str:
        path = pkgutil.get_data('pyslvs_ui', name)
        if path:
            return path.decode('utf-8')
        raise FileNotFoundError(f"Can't found file: '{name}'")

    data = readFile('api_data.txt')
    data = data.split('\n')
    data = dict(zip(data[::2], data[1::2]))
    for i in data:
        data[i] = data[i][1:].replace('\n', '').split(' ')
    data = {i: f"({j[0]})" for i, j in data.items()}


# Generated at 2022-06-25 14:33:20.803552
# Unit test for function loader
def test_loader():
    dict_0 = {'str_0': 'str_0'}
    loader_0 = loader('str_0', 'str_0', False, 0, True)

test_case_0()
test_loader()