

# Generated at 2022-06-25 14:34:32.111560
# Unit test for function walk_packages
def test_walk_packages():
    try:
        test_case_0()
    except ValueError:
        pass

# Unit tests for this module

# Generated at 2022-06-25 14:34:33.812614
# Unit test for function loader
def test_loader():
    isinstance(
        loader(str_0, str_0, bool_0, int_0, bool_0),
        str
    )

# Generated at 2022-06-25 14:34:35.268727
# Unit test for function loader
def test_loader():
    root = '_test_root'
    pwd = '_test_pwd'
    link = True
    level = 1
    toc = False
    loader(root, pwd, link, level, toc)



# Generated at 2022-06-25 14:34:40.000565
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    iterator_0 = walk_packages(str_0, str_0)
    tuple_0 = next(iterator_0)
    str_1 = tuple_0[0]
    assert isinstance(str_1, str)
    str_2 = tuple_0[1]
    assert isinstance(str_2, str)
    int_0, int_1 = tuple_0
    bool_0 = isinstance(int_0, int)
    bool_1 = isinstance(int_1, int)
    assert bool_0 and bool_1



# Generated at 2022-06-25 14:34:43.283201
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    assert isinstance((walk_packages(str_0, str_0)), Iterator)
    assert isinstance((next(walk_packages(str_0, str_0))), tuple)


# Generated at 2022-06-25 14:34:45.122846
# Unit test for function loader
def test_loader():
    test_case_0()
    assert loader('math', '..', True, 1, True) is not None

# Generated at 2022-06-25 14:34:50.922817
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    assert len(gen_api({'Pyslvs': 'pyslvs'})) > 0
    assert len(gen_api({'Pyslvs': 'pyslvs', 'VPython': 'vpython'})) > 0
    assert len(gen_api({'Pyslvs': 'pyslvs', 'VPython': 'vpython'}, link=False)) > 0
    assert len(gen_api({'Pyslvs': 'pyslvs', 'VPython': 'vpython'}, toc=True)) > 0

# Generated at 2022-06-25 14:34:52.411096
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    str_1 = None
    if __name__ == '__main__':
        test_case_0()



# Generated at 2022-06-25 14:34:53.280936
# Unit test for function loader
def test_loader():
    assert loader('', '', False, 1, False).strip() == ''


# Generated at 2022-06-25 14:34:57.365234
# Unit test for function walk_packages
def test_walk_packages():
    from os.path import isdir
    test_dir = "test_dir"
    mkdir(test_dir)
    map_1 = {}
    path_0 = test_dir
    for name, target in walk_packages(test_dir, path_0):
       map_1[name] = target
    logger.info(map_1)
    assert isdir(test_dir)
    assert map_1["test_dir.test_file"] == test_dir + "/test_file"
    assert map_1["test_dir.test_file1"] == test_dir + "/test_file1"
    assert len(map_1) == 2
