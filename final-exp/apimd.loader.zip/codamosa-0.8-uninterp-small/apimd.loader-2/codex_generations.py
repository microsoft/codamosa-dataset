

# Generated at 2022-06-25 14:27:55.250920
# Unit test for function loader
def test_loader():
    dict_0 = {}

# Generated at 2022-06-25 14:27:55.719746
# Unit test for function loader
def test_loader():
    assert loader == _loader

# Generated at 2022-06-25 14:28:03.776552
# Unit test for function walk_packages

# Generated at 2022-06-25 14:28:08.052096
# Unit test for function loader
def test_loader():
    str_0 = '/home/yc/GitHub/PySLVS/docs'
    str_1 = 'pyslvs'
    int_0 = 9
    bool_0 = False
    sequence_0 = loader(str_1, str_0, bool_0, int_0, bool_0)
    assert sequence_0 is not None


# Generated at 2022-06-25 14:28:16.316653
# Unit test for function loader
def test_loader():
    p = Parser.new(True, 1, False)
    name = 'pyslvs_ui.widgets.compact_drawer.q_list_view'
    path = 'C:/Users/yucch/pyslvs_ui/widgets/compact_drawer/q_list_view.pyi'

    # Test for loading module
    assert find_spec('turtle') is not None
    assert find_spec('turtle.speed') is not None
    assert find_spec('turtle.speedz') is None

    # Test for read
    assert _read(path).strip() == 'def append_items(self, items: List[Any]): ...'

    # Test for compile
    assert p.compile().strip() == ''

    # Test for write
    _write(path, 'a')
   

# Generated at 2022-06-25 14:28:22.111249
# Unit test for function loader
def test_loader():
    parser = Parser.new(True, 3, False)
    _load_module("pyvcp", "../src/pyvcp/__init__.pyi", parser)
    assert parser.parse("pyvcp", _read("../src/pyvcp/__init__.pyi"))
    _load_module("pyvcp.submodule", "../src/pyvcp/submodule/__init__.pyi", parser)
    assert parser.parse("pyvcp.submodule", _read("../src/pyvcp/submodule/__init__.pyi"))
    assert parser.compile()

# Generated at 2022-06-25 14:28:23.409991
# Unit test for function loader
def test_loader():
    assert loader("_test", "./_test", True, 1, False)


# Generated at 2022-06-25 14:28:30.168277
# Unit test for function loader
def test_loader():
    """Test case for loader"""
    p = Parser.new()
    logger.info("Test case for loader")
    logger.info("Test case 0")
    doc_0 = loader("__future__", "C:/ProgramData/Miniconda3/lib/python36.zip", True, 2, True)
    assert doc_0 is not None
    logger.info("Test case 1")
    doc_1 = loader("pyslvs", "C:/ProgramData/Miniconda3/lib/site-packages", True, 2, True)
    assert doc_1 is not None
    p.parse("yaml", "yaml = 4\n")
    logger.info("Test case 2")
    doc_2 = p.compile()
    assert doc_2 is not None
    logger.info("Test case 3")
    doc_3

# Generated at 2022-06-25 14:28:33.737993
# Unit test for function loader
def test_loader():
    gen_api({'pyslvs': 'pyslvs'})
    gen_api({'pyslvs': 'pyslvs'}, pwd=dirname(__file__))
    loader('pyslvs', _site_path('pyslvs'), False, 1, False)


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-25 14:28:36.240608
# Unit test for function walk_packages
def test_walk_packages():
    dict_0 = {'pyqt-pyslvs': 'PyQt5', 'pyslvs': 'PySLVS', 'pyslvs-ui': 'PySLVS-UI'}
    str_0 = ',g,2poZ\x0c(&DFG'
    sequence_0 = gen_api(dict_0, prefix=str_0)

# Generated at 2022-06-25 14:29:51.397564
# Unit test for function loader
def test_loader():
    from pyslvs_ui.parser import parent
    from pyslvs import __path__
    from test.test_parser import TEST_DOC_DIR

    def load_module(name: str, path: str, p: Parser) -> bool:
        """Load module directly."""
        # Load root first to avoid import error
        try:
            __import__(parent(name))
        except ImportError:
            return False
        s = spec_from_file_location(name, path)
        if s is not None and isinstance(s.loader, Loader):
            m = module_from_spec(s)
            s.loader.exec_module(m)
            p.load_docstring(name, m)
            return True
        return False


# Generated at 2022-06-25 14:29:58.441692
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import exists
    from shutil import rmtree
    from importlib.metadata import version, metadata
    name = f"pyslvs-{version(metadata('pyslvs'))}"
    path = f"pyslvs{sep}pyslvs"
    path_stubs = path + PEP561_SUFFIX
    p = Parser.new(False, 1, True)
    assert p.compile() == ""
    root_names = {'pyslvs': path, 'pyslvs-stubs': path_stubs}

# Generated at 2022-06-25 14:30:01.094871
# Unit test for function walk_packages
def test_walk_packages():
    # Usage of `walk_packages`
    str_1 = r"C:\Python36\Lib\site-packages"
    str_2 = "pyslvs"
    _ = {tuple_1: tuple_1 for tuple_1 in walk_packages(str_2, str_1)}


# Generated at 2022-06-25 14:30:06.690510
# Unit test for function loader
def test_loader():
    from os import remove
    from os.path import join, exists
    loader('pyslvs-ui', '', False, 1, False)
    for fn in ('pyslvs-ui-api.md', 'pyslvs-ui-stubs-api.md'):
        assert exists(join('docs', fn))
        remove(join('docs', fn))
    assert not exists('docs')

if __name__ == "__main__":
    """For Python compiler test."""
    name = 'pyslvs_ui'
    gen_api({'pyslvs_ui': name}, None, dry=True)
    gen_api({'pyslvs_ui': name}, None, link=False, toc=True, dry=True)

# Generated at 2022-06-25 14:30:14.426623
# Unit test for function loader
def test_loader():
    assert load_module('pyslvs', 'D:\\Pyslvs\\pyslvs\\pyslvs\\__init__.py')
    assert load_module('pyslvs', 'D:\\Pyslvs\\pyslvs\\pyslvs\\__init__.pyi')
    assert not load_module('pyslvs', 'D:\\Pyslvs\\pyslvs\\pyslvs\\__init__.pyi2')
    assert not load_module('pyslvs2', 'D:\\Pyslvs\\pyslvs\\pyslvs\\__init__.pyi2')

# Generated at 2022-06-25 14:30:19.763724
# Unit test for function loader
def test_loader():
    """Unit test for function `loader`."""
    assert 'module' in loader('__future__', abspath('.'), True, 1, False)
    assert 'module' in loader('__future__', abspath('.'), True, 1, True)
    assert 'module' in loader('__future__', abspath('.'), False, 1, False)
    assert 'module' in loader('__future__', abspath('.'), False, 1, True)


# Generated at 2022-06-25 14:30:20.655873
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:30:27.456360
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import pkg_resources
    import PySimpleGUI as sg
    pkg_path = pkg_resources.resource_filename(sg.__name__, "PySimpleGUI.pyi")
    print(pkg_path)
    print(sg.__name__)
    print(pkg_resources.resource_filename(sg.__name__, "PySimpleGUI.pyi"))
    print(sys_path)
    for name, path in walk_packages(sg.__name__, "/home/yc/anaconda3/lib/python3.7/site-packages"):
        print(name, path)



# Generated at 2022-06-25 14:30:29.858498
# Unit test for function loader
def test_loader():
    from time import time
    start_time = time()
    for _ in range(20):
        test_case_0()
    logger.info(f"Test time {(time() - start_time) * 1000:.2f} ms.")

# Generated at 2022-06-25 14:30:32.327899
# Unit test for function loader
def test_loader():
    if __name__ == '__main__':
        gen_api({'Test': 'scipy'}, 'C:\\Users\\Yuan Chang\\AppData\\Local\\Programs\\Python\\Python37\\Lib\\site-packages', dry=True)

# Generated at 2022-06-25 14:34:33.525474
# Unit test for function loader
def test_loader():
    """Main test function."""
    print("Test: unit test for function loader")
    root_names = {
        "numpy": "numpy",
        "scipy": "scipy",
        "pandas": "pandas",
        "sympy": "sympy",
        "matplotlib": "matplotlib",
        "sipy": "sipy",
    }
    gen_api(root_names, pwd='../venv/lib/python3.6/site-packages')

if __name__ == '__main__':
    test_loader()
    test_case_0()

# Generated at 2022-06-25 14:34:35.367857
# Unit test for function walk_packages
def test_walk_packages():
    gen_api({'test': 'pyslvs'})
    gen_api({'test': 'pyslvs'})

test_case_0()
test_walk_packages()

# Generated at 2022-06-25 14:34:36.218645
# Unit test for function loader
def test_loader():
    assert loader('pyslvs', '.', True, 1, True)


# Generated at 2022-06-25 14:34:39.937023
# Unit test for function walk_packages
def test_walk_packages():
    dict_0 = {'sys': '@sys'}
    list_1 = ['./test_pesho.py', './test_pesho.pyi']
    str_2 = '__init__.py'
    str_3 = '_test_pesho'
    dict_4 = {str_3: '@sys'}
    list_5 = ['__init__.py', '__init__.pyi']
    list_6 = test_walk_packages.__dict__.items()
    bool_7 = False
    for tuple_8 in walk_packages(str_0, dict_0):
        str_0 = tuple_8[0]
        dict_0 = tuple_8[1]
        pass
        if dict_0 == list_1:
            bool_7 = True
        pass


# Generated at 2022-06-25 14:34:48.514376
# Unit test for function walk_packages
def test_walk_packages():
    import unittest
    from os import remove
    from os.path import join as joinpath, dirname
    from importlib import util
    test_spec = util.spec_from_loader('__test_module', util.SourceFileLoader('__test_module', '__test_module'))
    test_mod = util.module_from_spec(test_spec)
    path = dirname(__file__)
    remove(joinpath(path, '__test_module.py'))
    res = list(walk_packages('__test_module', path))
    class TestWalkPackages(unittest.TestCase):
        def test__walk_packages_should_return_a_list(self):
            self.assertEqual(
                type(res),
                list
            )


# Generated at 2022-06-25 14:34:51.850694
# Unit test for function loader
def test_loader():
    """Test loader function."""
    path = _site_path('pyslvs')
    logger.info(loader('pyslvs', path, True, 1, True))

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:34:54.500429
# Unit test for function loader
def test_loader():
    root_names = {
        'Qt for Python': 'PySide2',
        'numpy': 'numpy',
        'scipy': 'scipy',
        'matplotlib': 'matplotlib',
    }
    gen_api(root_names, None, link=False, level=3)


# Generated at 2022-06-25 14:35:03.287031
# Unit test for function walk_packages
def test_walk_packages():
    def in_range(n: int) -> bool:
        return 0 <= n < 5

    def is_str(s: str) -> bool:
        return isinstance(s, str)

    def is_str_or_none(s: Optional[str]) -> bool:
        return s is None or isinstance(s, str)

    def equal_union(s: str, t: str) -> bool:
        return (s is None and t is None) or s == t

    def equal_union_int(i: int, j: int) -> bool:
        return (i is None and j is None) or i == j

    def equal_union_str_or_none(s: Optional[str], t: Optional[str]) -> bool:
        return (s is None and t is None) or s == t


# Generated at 2022-06-25 14:35:05.408623
# Unit test for function loader
def test_loader():
    dict_0 = {}
    dict_0['pyslvs'] = 'pyslvs'
    gen_api(dict_0)

# Generated at 2022-06-25 14:35:06.709383
# Unit test for function loader
def test_loader():
    gen_api({'test': 'test'}, '.', prefix="test_docs", dry=True)