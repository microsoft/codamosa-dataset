

# Generated at 2022-06-25 14:30:20.883981
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

# Generated at 2022-06-25 14:30:26.625841
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = '}Rgo^hWr/[[C'
    iterator_0 = walk_packages(str_0, str_0)
    try:
        while True:
            test_case_0()
            tuple_0 = next(iterator_0)
            str_1 = tuple_0[0]
            str_2 = tuple_0[1]
            str_3 = tuple_0[0]
            str_4 = tuple_0[1]
    except StopIteration:
        pass



# Generated at 2022-06-25 14:30:27.852462
# Unit test for function loader
def test_loader():
    loader('Pyslvs', '')
    loader('Pyslvs', '')


# Generated at 2022-06-25 14:30:29.499269
# Unit test for function walk_packages
def test_walk_packages():
    assert isinstance(walk_packages('', ''), Iterator)
    assert isinstance(walk_packages('', '').__next__(), tuple)


# Generated at 2022-06-25 14:30:37.226937
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = '}Rgo^hWr/[[C'
    iterator_0 = walk_packages(str_0, str_0)
    assert(len(iterator_0) == 0)
    str_0 = '4mBWN;]>]Y}'
    iterator_0 = walk_packages(str_0, str_0)
    assert(len(iterator_0) == 0)
    str_0 = 'pw(>3<cz~{I'
    iterator_0 = walk_packages(str_0, str_0)
    assert(len(iterator_0) == 0)
    str_0 = '4.guz.YX6xc'
    iterator_0 = walk_packages(str_0, str_0)
    assert(len(iterator_0) == 0)

# Generated at 2022-06-25 14:30:39.482251
# Unit test for function loader
def test_loader():
    _loader_0 = loader('sys', '', True, 3, True)
    print(_loader_0)
    print(len(_loader_0))
    assert len(_loader_0) > 0



# Generated at 2022-06-25 14:30:41.144758
# Unit test for function loader
def test_loader():
    dict_0 = {}
    logger.setLevel(10)
    test_case_0()
    list_0 = gen_api(dict_0, "", dry=True)

# Generated at 2022-06-25 14:30:42.873853
# Unit test for function loader
def test_loader():
    logger.info('Unit test: loader')
    try:
        loader('pyslvs', '.', True, 1, False)
    except Exception:
        raise ValueError
    else:
        logger.info('Passed')


if __name__ == "__main__":
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:30:46.256465
# Unit test for function loader
def test_loader():
    from os.path import dirname, join
    from unittest.mock import patch
    with patch('sys.path', ['C:\\dir\\dir']):
        root = 'pyslvs'
        loader(root, join(dirname(__file__), '__fixtures__'), True, 1, True)


# Generated at 2022-06-25 14:30:52.538248
# Unit test for function loader
def test_loader():
    import requests  # type: ignore
    assert len(loader('requests', '.', True, 3, True))
    assert len(loader('requests', _site_path('requests'), True, 3, True))
    assert loader('requests', '', True, 3, True).startswith('[TOC]')
    assert loader('requests', '', True, 3, False).startswith('# requests')
    assert loader('requests', '', True, 1, True).startswith('[TOC]')
    assert loader('requests', '', True, 1, False).startswith('# requests')
    assert loader('requests', '', False, 3, True).startswith('# requests')
    assert loader('requests', '', False, 3, False).startswith('# requests')

# Generated at 2022-06-25 14:34:26.562377
# Unit test for function loader
def test_loader():
    test_case_0()
    logger.warning("test_loader is not implement")



# Generated at 2022-06-25 14:34:27.936917
# Unit test for function loader
def test_loader():
    loader('pyslvs', '../pyslvs/', True, 1, True)

# Generated at 2022-06-25 14:34:28.741599
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()


# Generated at 2022-06-25 14:34:30.710115
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = abspath(__file__)
    iterator_0 = walk_packages(str_0, str_0)
    for item in iterator_0:
        print(item)

# Generated at 2022-06-25 14:34:32.198882
# Unit test for function loader
def test_loader():
    assert loader('math', '.', True, 1, True) == "# `math` API\n\n"

# Generated at 2022-06-25 14:34:33.306142
# Unit test for function loader
def test_loader():
    if __name__ == '__main__':
        pass


# Generated at 2022-06-25 14:34:34.202725
# Unit test for function walk_packages
def test_walk_packages():
    '''
    Test case 0
    '''

    print('\n**Test case 0**')

    test_case_0()


# Generated at 2022-06-25 14:34:34.830850
# Unit test for function loader
def test_loader():
    assert isinstance(loader("test", ""), str)

# Generated at 2022-06-25 14:34:40.217045
# Unit test for function loader
def test_loader():
    str_0 = 'docs'
    str_1 = 'docs'
    str_2 = 'docs'
    str_3 = 'docs'
    str_4 = 'docs'
    str_5 = 'docs'
    bool_0 = True
    bool_1 = True
    bool_2 = True
    bool_3 = True
    bool_4 = True
    bool_5 = True
    bool_6 = True
    bool_7 = True
    bool_8 = True
    bool_9 = True
    bool_10 = True
    bool_11 = True
    bool_12 = True
    bool_13 = True
    bool_14 = True
    bool_15 = True
    bool_16 = True
    bool_17 = True
    bool_18 = True
    bool_19 = True

# Generated at 2022-06-25 14:34:46.424980
# Unit test for function loader
def test_loader():
    import time

    start_time = time.time()
    print('Start time: %f s' % start_time)
    print(gen_api({'pyslvs_ui': 'pyslvs_ui'}, dry=True))
    end_time = time.time()
    print('End   time: %f s' % end_time)
    print('Running time: %f s' % (end_time - start_time))

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:35:42.273912
# Unit test for function loader
def test_loader():
    str_0 = '.'
    bool_0 = True
    str_1 = loader(str_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 14:35:45.853225
# Unit test for function loader
def test_loader():
    str_2 = "import sys; sys.path = ['', '..', '..', '..'] + sys.path"
    exec(str_2)

    dict_0 = {}
    str_3 = loader(dict_0, dict_0, dict_0, dict_0, dict_0)
    str_4 = "Compiled document should not be empty."
    assert str_3, str_4


if __name__ == "__main__":
    from tests import test_loader

# Generated at 2022-06-25 14:35:48.457885
# Unit test for function loader
def test_loader():
    str_0 = 'pyslvs'
    str_1 = 'pyslvs'
    bool_0 = True
    bool_1 = False
    int_0 = 10
    str_2 = loader(str_0, str_1, bool_0, int_0, bool_1)
    assert str_2


# Generated at 2022-06-25 14:35:55.205621
# Unit test for function walk_packages
def test_walk_packages():
    import os
    import pyslvs
    result_0 = test_walk_packages.__name__
    result_1 = os.getcwd()
    result_2 = pyslvs.__path__[0]
    result_3 = False
    result_4 = False
    result_5 = False
    result_6 = loader(result_0, result_1, result_3, result_4, result_5)
    result_7 = loader(result_0, result_2, result_3, result_4, result_5)
    result_8 = False
    result_9 = True
    result_10 = True
    result_11 = True
    result_12 = True
    result_13 = loader(result_0, result_2, result_8, result_9, result_10)
    result_14

# Generated at 2022-06-25 14:36:02.143294
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = ''
    str_1 = ''
    gen_0 = walk_packages(str_0, str_1)
    iter_0 = iter(gen_0)
    str_2 = '__main__'
    str_3 = ''
    for tuple_0 in iter_0:
        str_4 = tuple_0[0]
        str_5 = tuple_0[1]
        str_6 = str_2
        str_7 = str_3
        assert str_6 == str_7
        str_8 = str_4
        str_9 = str_5
        str_10 = str_2
        str_11 = str_3
        assert str_10 == str_11
        str_12 = str_8
        str_13 = str_9
        str_14 = str_2
       

# Generated at 2022-06-25 14:36:04.215900
# Unit test for function loader
def test_loader():
    str_0 = '.'
    str_1 = loader(str_0, str_0, bool, bool, bool)


# Generated at 2022-06-25 14:36:08.715917
# Unit test for function walk_packages
def test_walk_packages():
    # Positional arguments
    str_0 = '.'
    str_1 = '.'
    # Return type
    ret = Iterator[tuple[str, str]]
    for item in walk_packages(str_0, str_1):
        with open(item[1], 'r') as f:
            f.read()
            print(f.read())
    ret
