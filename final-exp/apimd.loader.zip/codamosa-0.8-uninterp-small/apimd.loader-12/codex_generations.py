

# Generated at 2022-06-25 14:27:13.545935
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = '0ceD%cf}'
    iterator_0 = walk_packages(str_0, str_0)
    iterator_1 = walk_packages(str_0, str_0)
    print('\n'.join(str(i) for i in iterator_1))
    print('\n'.join(str(i) for i in iterator_0))


# Generated at 2022-06-25 14:27:16.270267
# Unit test for function walk_packages
def test_walk_packages():
    def setUpModule():
        # FIXME: create some file here
        return None
    def tearDownModule():
        # FIXME: delete some file here
        return None
    for test in [test_case_0]:
        test()

# Generated at 2022-06-25 14:27:18.144197
# Unit test for function walk_packages
def test_walk_packages():
    path = 'test_path'
    name = 'test_name'
    walk_packages(name, path)

# Generated at 2022-06-25 14:27:19.274767
# Unit test for function loader
def test_loader():
    loader('', '', False, 1, False)


# Generated at 2022-06-25 14:27:22.448676
# Unit test for function loader
def test_loader():
    loader('os', '/Users/yc/Documents/SVN/Python', True, 2, False)
    loader('site', '/Users/yc/Documents/SVN/Python', True, 2, False)
    loader('__main__', '/Users/yc/Documents/SVN/Python', True, 2, False)

# Generated at 2022-06-25 14:27:23.228382
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 14:27:30.693907
# Unit test for function loader
def test_loader():
    str_0 = '.__init__'
    str_1 = '__init__'
    str_2 = '---'
    str_3 = '.. module:: '
    str_4 = '--'
    str_5 = '*'
    str_6 = '----'
    str_7 = '-'
    list_0 = [str_7]
    int_0 = 8
    list_1 = [str_6]
    int_1 = 5
    list_2 = [str_5]
    int_2 = 8
    list_3 = [str_4]
    list_4 = [str_3]
    list_5 = [str_2]
    list_6 = [str_1]
    list_7 = [str_0]
    bool_0 = True
    bool_1 = False

# Generated at 2022-06-25 14:27:32.590644
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = '0ceD%cf}'
    iterator_0 = walk_packages(str_0, str_0)
    assert iterator_0 is not None


# Generated at 2022-06-25 14:27:33.346478
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

# Generated at 2022-06-25 14:27:36.002151
# Unit test for function loader
def test_loader():
    gen_api({
        "Pyslvs": "pyslvs",
        "pyslvs-cli": "pyslvs_cli",
    })

# Generated at 2022-06-25 14:28:40.933358
# Unit test for function walk_packages
def test_walk_packages():
    from sys import path as sys_path
    from os.path import dirname, sep
    from itertools import chain

    # Simulate the execution environment
    sys_path.append(dirname(__file__))

    import_dir = __import__(dirname(__file__))
    module = __import__(import_dir.__name__ + '.api_compiler_test')

    # Start test
    test_1 = module.__name__
    test_2 = module.api_compiler_test.__name__
    test_3 = module.api_compiler_test.test_function_0.__name__
    test_4 = module.api_compiler_test.test_function_1.__name__
    (test_5,) = module.api_compiler_test.test_function_2.__annot

# Generated at 2022-06-25 14:28:43.936115
# Unit test for function loader
def test_loader():
    """Test pypi package module loading."""
    loader('numpy', _site_path('numpy'), True, 1, True)
    loader('pandas', _site_path('pandas'), True, 1, True)
    loader('sklearn', _site_path('sklearn'), True, 1, True)

# Generated at 2022-06-25 14:28:48.248498
# Unit test for function loader
def test_loader():
    root_names = {
        'Pyslvs': 'pyslvs',
        'Pyslvs-stubs': 'pyslvs-stubs',
        'Pyslvs-ui': 'pyslvs_ui',
        'Pyslvs-ui-stubs': 'pyslvs_ui-stubs',
    }
    gen_api(root_names, prefix='docs/api', dry=True)

# Generated at 2022-06-25 14:28:56.731052
# Unit test for function loader
def test_loader():
    from .parser import Parser
    from .printer import Printer


# Generated at 2022-06-25 14:28:57.816440
# Unit test for function loader
def test_loader():
    import doctest
    doctest.testmod()


# Generated at 2022-06-25 14:28:58.649490
# Unit test for function walk_packages
def test_walk_packages():
    assert test_case_0() is None

# Generated at 2022-06-25 14:29:02.397005
# Unit test for function loader
def test_loader():
    str_0 = '0ceD%cf}'
    iterator_0 = walk_packages(str_0, str_0)
    dict_0 = {'0ceD%cf}': '{ceD}'}
    gen_api(dict_0, '0ceD%cf}')

# Generated at 2022-06-25 14:29:03.786997
# Unit test for function loader
def test_loader():
    gen_api({'pyslvs': 'pyslvs'})



# Generated at 2022-06-25 14:29:05.412087
# Unit test for function loader
def test_loader():
    root = 'pathlib'
    pwd = abspath('.')
    loader(root, pwd, link=True)

# Generated at 2022-06-25 14:29:07.958570
# Unit test for function loader
def test_loader():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

test_loader()

# Generated at 2022-06-25 14:33:22.533652
# Unit test for function loader
def test_loader():
    root_names = {
        "test": "test",
        "Test": "test",
    }
    sequence_0 = gen_api(root_names, "D:/Documents/PySLVS/PySLVS")


# Generated at 2022-06-25 14:33:23.697615
# Unit test for function loader
def test_loader():
    loader('pyslvs', 'pyslvs', True, 1, False)

# Generated at 2022-06-25 14:33:27.982025
# Unit test for function loader
def test_loader():
    from os.path import dirname, join
    from tests.test_compiler import test_module
    assert loader(test_module, dirname(__file__), False, 1, False)
    with open(join(dirname(__file__), test_module), encoding='utf-8') as f:
        assert f.read() == test_module

# Generated at 2022-06-25 14:33:31.409429
# Unit test for function loader
def test_loader():
    str_0 = 'pyslvs'
    str_1 = '../'
    int_1 = 1
    bool_0 = True
    bool_1 = False
    dict_0 = {str_0: str_0}
    sequence_0 = gen_api(dict_0, str_1, prefix='docs', link=bool_0, level=int_1, toc=bool_1, dry=bool_1)

# Generated at 2022-06-25 14:33:32.421850
# Unit test for function loader
def test_loader():
    print(loader('pyslvs', './site-packages', True, 1, False))


# Generated at 2022-06-25 14:33:40.998029
# Unit test for function loader
def test_loader():
    import os
    import sys
    import subprocess
    import tempfile
    from textwrap import dedent

    try:
        os.mkdir('test')
        os.mkdir('test/package')
        os.mkdir('test/package/subpackage')
    except FileExistsError:
        pass

    def generate(name, source):
        with open('test/package/%s.py' % name, 'w') as f:
            print(dedent(source), file=f)


# Generated at 2022-06-25 14:33:43.696876
# Unit test for function loader
def test_loader():
    root = "pyslvs"
    pwd = dirname(dirname(abspath(__file__)))
    loader(root, pwd, True, 1, False)


if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:33:44.317376
# Unit test for function loader
def test_loader():
    pass



# Generated at 2022-06-25 14:33:50.930139
# Unit test for function loader
def test_loader():
    from pyslvs_ui.compiler import walk_packages, loader
    from sys import path as sys_path
    from os.path import dirname, abspath
    from os import sys_path_names
    path = {path: path for path in sys_path}
    for name, base in sys_path_names:
        path[name] = abspath(path[name])
    if '__name__' not in path:
        path['__name__'] = dirname(abspath(__file__))
    if '__package__' not in path:
        path['__package__'] = path['__name__']
    for _, path in walk_packages(str(path), path[str(path)]):
        loader(str(path), path, True, 1, True)

# Generated at 2022-06-25 14:33:51.818050
# Unit test for function loader
def test_loader():
    loader('os', '.', False, 2, False)