

# Generated at 2022-06-25 14:33:57.004216
# Unit test for function loader
def test_loader():
    from .definitions import DOCS, PATH
    import os
    import inspect
    g = gen_api(DOCS, PATH, dry=True)
    for _ in range(3):
        _ = next(g)



# Generated at 2022-06-25 14:34:05.108603
# Unit test for function loader
def test_loader():
    from os import pathsep
    from sys import path as sys_path
    from sys import platform
    from importlib import import_module
    from .common import is_pyqt_available
    from .parser import parent
    from .logger import logger

    logger.info('Running tests from `loader` module ...')

    # This is a test module for verifying the parser.
    logger.info('Testing for `test.dummy` (pyslvs_ui)')
    assert is_pyqt_available()
    # pyslvs_ui depends on PyQt5. Some tests can only be passed in linux system.
    if platform != 'linux':
        logger.warning('This test can only be passed in linux system.')
    else:
        # Load the module
        import_module('pyslvs_ui.dummy')
       

# Generated at 2022-06-25 14:34:07.315282
# Unit test for function loader
def test_loader():
    root = 'pyslvs'
    doc = loader(root, '../site-packages', False, 1, False)
    with open('api.md', 'w+', encoding='utf-8') as f:
        f.write(doc)

# Generated at 2022-06-25 14:34:09.563876
# Unit test for function loader
def test_loader():
    test_case_0()

# Build API document from the script

# Generated at 2022-06-25 14:34:17.985254
# Unit test for function loader
def test_loader():
    str_1 = 'f*)"N\'\\p\rd\x0bE`I \'#Lw'
    str_2 = 'k[\'\\D\x1c{A\x0bF*Hq'
    str_3 = 'gv:8W!\x1f%>A\x0cc'
    str_4 = 'X`Uk#\x0bQ"i'
    str_5 = 'u0{\x1b<\x1a5>X\x0cGm'
    str_6 = 'H^jw@\x1eU/b'
    str_7 = 'RjN^'
    str_8 = 'P`K'
    str_9 = 'I\x0cE\x1bJ\x1a'

# Generated at 2022-06-25 14:34:24.514501
# Unit test for function loader
def test_loader():
    list_0 = ('2\x17\x0c', '\x14{\x06e\x1a', '\x01\x14\t\x06\x1e', '\x04\x0b\x1e\x03', '\x04\x0b\x1e\x03', '\x1c\x08\x18\x03k', '\x1c\x08\x18\x03k', '\x0b\x1c\x1a', '\x0f\x1d\x0eG', '\x0c\x06\x19\x01', '\x1bx\t\x06Y')

# Generated at 2022-06-25 14:34:25.519432
# Unit test for function loader
def test_loader():
    assert loader('a', 'some_path', True, 1, False) == '\n'

# Generated at 2022-06-25 14:34:34.062728
# Unit test for function loader
def test_loader():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from shutil import copy
    import subprocess
    from logging import basicConfig, INFO

    basicConfig(level=INFO)

    with TemporaryDirectory() as tempdir:
        pkg = "test_pkg"
        root = join(tempdir, pkg)
        copy("LICENSE", tempdir)
        copy("CONTRIBUTING.md", tempdir)
        mkdir(root)
        with open(join(root, "__init__.py"), "w+") as f:
            f.write("from matplotlib import pyplot\nfrom .test_pkg import Test\n")

# Generated at 2022-06-25 14:34:35.494279
# Unit test for function loader
def test_loader():
    root = '_test_case'
    pwd = '.'
    link = True
    level = 1
    toc = False
    str_0 = loader(root, pwd, link, level, toc)


# Generated at 2022-06-25 14:34:36.968715
# Unit test for function loader
def test_loader():
    import sys
    for path in sys.path:
        for i, j in walk_packages("trix", path):
            print(i, abspath(j))

if __name__ == "__main__":
    test_loader()