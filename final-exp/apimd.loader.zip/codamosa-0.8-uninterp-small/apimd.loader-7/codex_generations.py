

# Generated at 2022-06-25 14:27:13.700890
# Unit test for function loader
def test_loader():
    str_0 = 'typing'
    str_1 = 'typing-stubs'
    parser_0 = Parser.new(True, 2, False)
    str_2 = 'typing.AbstractSet.__subclasscheck__'
    str_3 = '/home/ubuntu/typing-stubs/typing/AbstractSet.pyi'
    parser_0.parse(str_2, _read(str_3))
    str_4 = 'typing.AbstractSet'
    str_5 = 'typing/AbstractSet.pyi'
    str_6 = '/home/ubuntu/typing-stubs/typing/AbstractSet.pyi'
    str_7 = '/home/ubuntu/typing/__init__.py'
    str_8 = 'typing.__init__'
    parser_0.parse

# Generated at 2022-06-25 14:27:15.792773
# Unit test for function loader
def test_loader():
    t0 = "typing.AbstractSet"
    p0 = "typing"
    loader(t0, p0, True, 0, False)



# Generated at 2022-06-25 14:27:19.161359
# Unit test for function loader
def test_loader():
    """Function loader test."""
    from doctest import testmod, NORMALIZE_WHITESPACE, ELLIPSIS, REPORT_NDIFF
    return testmod(verbose=False, optionflags=NORMALIZE_WHITESPACE | ELLIPSIS | REPORT_NDIFF)

# Generated at 2022-06-25 14:27:21.884298
# Unit test for function loader
def test_loader():
    pwd = "D:\\ProgramData\\Anaconda3\\lib\\site-packages\\"
    name = "sympy.polys"
    link = False
    level = 1
    toc = False
    loader(name, pwd, link, level, toc)

# Generated at 2022-06-25 14:27:24.594131
# Unit test for function loader
def test_loader():
    # Unit test for function find_spec
    module_path = find_spec('collections')
    path = module_path.submodule_search_locations[0]
    print(path)
    test_case_1()


# Generated at 2022-06-25 14:27:26.388931
# Unit test for function loader
def test_loader():
    gen_api(
        {'Dummy': 'dummy.dummy'},
        '/Users/yuan/PycharmProjects/pyslvs/tests'
    )

# Generated at 2022-06-25 14:27:28.445688
# Unit test for function loader
def test_loader():
    print(loader('pyslvs', '/home/changyuan/Projects/pyslvs/pyslvs', True, 1, True))

# Generated at 2022-06-25 14:27:36.399623
# Unit test for function walk_packages
def test_walk_packages():
    import random
    import string
    import os.path
    import tempfile
    
    def rand_str():
        return ''.join(random.choices(string.ascii_letters, k=random.randint(5, 10)))

    test_dir = tempfile.mkdtemp()
    try:
        test_list = []
        for i in range(random.randint(5, 10)):
            test_list.append(os.path.join(test_dir, rand_str()))

        for test_name in test_list:
            with open(test_name, "w") as f:
                f.write("test")

        for name, path in walk_packages('', test_dir):
            assert name in test_list
            assert path in test_list
    finally:
        shutil.rmt

# Generated at 2022-06-25 14:27:43.642932
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = "collections"

# Generated at 2022-06-25 14:27:46.105810
# Unit test for function walk_packages
def test_walk_packages():
    # Test case 0
    test_case_0()
    raise AssertionError('walk_packages returns a generator, that\'s all I know.')


# Generated at 2022-06-25 14:28:51.217480
# Unit test for function loader
def test_loader():
    from .parser import link
    from .__pkginfo__ import __version__, __title__
    doc = loader(
        "collections",
        f"/usr/lib/python3.6/site-packages",
        True,
        1,
        False
    )
    assert doc.startswith(f"# {__title__} {__version__}")
    assert "class defaultdict" in doc
    assert "deque objects.\n\n    """ in doc
    assert "class deque([iterable[, maxlen]])" in doc
    assert f"`deque` on {link('collections.deque')}" in doc

# Generated at 2022-06-25 14:28:56.552461
# Unit test for function loader
def test_loader():
    # Import collections
    import collections
    # Get the path for collections
    path = _site_path(collections.__name__)
    # Load the collections
    doc = loader(collections.__name__, path, False, 0, False)
    # Write the text
    _write('collections.md', doc)

if __name__ == "__main__":
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:28:59.895755
# Unit test for function loader
def test_loader():
    import json
    loader('collections', '/usr/lib/python3.8/', True, 0, False)
    with open('tmp.json', 'w') as f:
        json.dump(doc_map, f)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 14:29:08.096571
# Unit test for function walk_packages
def test_walk_packages():
    print('Unit test for walk_packages')
    import pprint
    # Declare the set of packages
    set_of_packages = walk_packages('setuptools', '.')
    set_of_packages_iter = iter(set_of_packages)
    first_package_name, first_package_location = next(set_of_packages_iter)
    second_package_name, second_package_location = next(set_of_packages_iter)
    third_package_name, third_package_location = next(set_of_packages_iter)
    forth_package_name, forth_package_location = next(set_of_packages_iter)
    fifth_package_name, fifth_package_location = next(set_of_packages_iter)
    # Print the name and path of the set of packages

# Generated at 2022-06-25 14:29:14.511927
# Unit test for function loader
def test_loader():
    root_names = {
        'Slaves': 'Slaves',
        'Utilities': 'Slaves.Utilities',
        'Core': 'Slaves.Core',
        'Data': 'Slaves.Data',
        'Plot': 'Slaves.Plot',
        'Dialog': 'Slaves.Dialog',
        'UI': 'Slaves.UI'
    }
    path_0 = '../'
    prefix_0 = 'docs'
    link_0 = True
    level_0 = 1
    toc_0 = False
    dry_0 = False
    docs_0 = gen_api(root_names, path_0, prefix=prefix_0, link=link_0, \
        level=level_0, toc=toc_0, dry=dry_0)

# Generated at 2022-06-25 14:29:19.251702
# Unit test for function walk_packages
def test_walk_packages():
    # case_0: test call function with no arguments
    test_0 = walk_packages()
    assert isinstance(test_0, Iterator)
    # case_1: test call function with arguments
    test_1 = walk_packages('collections', '/Users/yuan/anaconda3/lib/python3.7')
    assert isinstance(test_1, Iterator)


# Generated at 2022-06-25 14:29:22.765639
# Unit test for function loader
def test_loader():
    import sys
    path = sys.path[0]
    pwd = './site-packages'
    name = 'collections'
    link = True
    level = 1
    toc = False
    loader(name, pwd, link, level, toc)


# Generated at 2022-06-25 14:29:28.427605
# Unit test for function loader
def test_loader():
    d = {
        'Collections': 'collections',
        'Math': 'math',
        'Random': 'random',
        'Sys': 'sys',
        'Re': 're',
        'Datetime': 'datetime'
    }
    import pyslvs
    test_loader.pwd = pyslvs.__path__[0]
    gen_api(d, test_loader.pwd)

if __name__ == '__main__':
    test_case_0()
    test_loader()

# Generated at 2022-06-25 14:29:34.965423
# Unit test for function loader
def test_loader():
    test_case_0()
    # return
    p_0 = Parser.new(True, 1, False)
    for name_0, path_0 in walk_packages('collections', _site_path('collections')):
        path_0 = path_0 + '.py'
        if isfile(path_0):
            p_0.parse(name_0, _read(path_0))
        else:
            for ext_0 in EXTENSION_SUFFIXES:
                path_1 = path_0 + ext_0
                if isfile(path_1):
                    _load_module(name_0, path_1, p_0)
                    break
    doc_0 = p_0.compile()
    # print(doc_0)

if __name__ == '__main__':
    test

# Generated at 2022-06-25 14:29:40.207754
# Unit test for function walk_packages
def test_walk_packages():
    # initialize list of strings
    list_of_strings = ['collections', 'sys']
    list_of_full_strings = ['collections', 'collections-stubs', 'sys', 'sys-stubs']
    # initialize the root
    path = '.'
    # initialize the full path
    full_path = './docs'
    # iterate over the strings
    for name in list_of_strings:
        print(name)
        name = f'{name}.__init__'
        print(name)
        # iterate walk_packages
        for name, _ in walk_packages(name, full_path):
            print(name)

# Generated at 2022-06-25 14:32:06.276497
# Unit test for function loader
def test_loader():
    root_names = {'Python 3.8.8': 'collections'}
    pwd = '.'
    prefix = 'docs'
    link = True
    level = 1
    toc = False
    dry = False
    gen_api(root_names, pwd, prefix=prefix, link=link, level=level, toc=toc, dry=dry)

# Generated at 2022-06-25 14:32:09.146283
# Unit test for function loader
def test_loader():
    pwd = 'C:\\Users\\Yuan\\AppData\\Local\\Programs\\Python\\Python39\\Lib\\site-packages'
    for name, path in walk_packages('collections', pwd):
        print(name, path)
    doc = loader('collections', pwd, True, 1, True)
    print(doc)

# Generated at 2022-06-25 14:32:10.075603
# Unit test for function loader
def test_loader():
    loader()

# Generated at 2022-06-25 14:32:13.010639
# Unit test for function loader
def test_loader():
    root_names = {
        'Collections': 'collections',
        'Hebi': 'hebi',
        'Numpy': 'numpy'
    }
    for title, name in root_names.items():
        logger.info(f"Load root: {name} ({title})")
        loader(name, _site_path(name), True)


# Generated at 2022-06-25 14:32:14.333562
# Unit test for function loader
def test_loader():
    # test_case_0()
    print('')


# Generated at 2022-06-25 14:32:16.154320
# Unit test for function loader
def test_loader():
    root_names = {
        'collections': 'collections'
    }
    gen_api(root_names, pwd = '.')


# Generated at 2022-06-25 14:32:17.244711
# Unit test for function loader
def test_loader():
    # Test case 0
    str_0 = test_case_0()
    print(str_0)


# Generated at 2022-06-25 14:32:19.146146
# Unit test for function loader
def test_loader():
    str_1 = str(loader(str_0, pwd=None, link=True, level=1, toc=False))
    print(str_1)


# Generated at 2022-06-25 14:32:21.268990
# Unit test for function loader
def test_loader():
    assert len(loader(
        root='collections',
        pwd=None,
        link=True,
        level=1,
        toc=False,
    )) > 0

# Generated at 2022-06-25 14:32:29.194477
# Unit test for function loader
def test_loader():
    # Type test
    # Test for function loader
    # Test for argument root_names
    test_loader_str_argname_0 = 'collections'
    # Test for argument pwd
    test_loader_str_argname_1 = '/home/docs_api'
    # Test for argument prefix
    test_loader_str_argname_2 = 'docs'
    # Test for argument link
    test_loader_bool_argname_0 = True
    # Test for argument level
    test_loader_int_argname_0 = 1
    # Test for argument toc
    test_loader_bool_argname_1 = False
    # Test for argument dry
    test_loader_bool_argname_2 = False


# Generated at 2022-06-25 14:35:00.850133
# Unit test for function loader
def test_loader():
    result = loader("collections", "/usr/lib/python3.8/site-packages", True, 1, False)
    assert result != None, f"test_loader() failed."

# Generated at 2022-06-25 14:35:01.540827
# Unit test for function loader
def test_loader():
    test_case_0()

# Generated at 2022-06-25 14:35:02.918757
# Unit test for function loader
def test_loader():
    test_case_0()

test_loader()

# Generated at 2022-06-25 14:35:07.855233
# Unit test for function loader
def test_loader():
    assert loader('math', './', True, 1, True)
    path = ['/usr/lib/python3.7/site-packages', '/usr/local/lib/python3.7/dist-packages', '/usr/lib/python3/dist-packages']
    sys_path.append(path[0])
    sys_path.append(path[1])
    sys_path.append(path[2])
    assert loader('collections', './', True, 1, True)
    logger.info("Passed")


# Generated at 2022-06-25 14:35:12.177543
# Unit test for function loader
def test_loader():
    str_0 = 'collections'
    str_1 = 'c:/users/ychang/appdata/local/programs/python/python38-32/lib/site-packages'
    str_2 = 'd:/github/pyslvs/pyslvs_ui/tools/api'
    gen_api({'Collections': str_0}, str_1, level=2, toc=True, dry=True)

if __name__ == "__main__":
    test_loader()

# Generated at 2022-06-25 14:35:14.296922
# Unit test for function loader
def test_loader():
    loader('collections', 'C:\\Python38\\Lib', False, 2, False)


# Generated at 2022-06-25 14:35:16.884317
# Unit test for function loader
def test_loader():
    root = 'collections'
    pwd = 'C:/programData/Anaconda3/lib/site-packages'
    link = True
    level = 2
    toc = False
    loader(root, pwd, link, level, toc)


# Generated at 2022-06-25 14:35:18.672794
# Unit test for function loader
def test_loader():
    assert len(gen_api({'Collections': str_0})) == 1

# Generated at 2022-06-25 14:35:20.056358
# Unit test for function loader
def test_loader():
    assert not _load_module('module_not_exist', '', Parser.new(False, 1, False))



# Generated at 2022-06-25 14:35:23.294758
# Unit test for function loader
def test_loader():
    root = 'collections'
    pwd = 'C:\\Users\\ychang\\AppData\\Local\\Programs\\Python\\Python38\\lib'
    link = True
    level = 1
    toc = False
    logger.info(loader(root, pwd, link, level, toc))
