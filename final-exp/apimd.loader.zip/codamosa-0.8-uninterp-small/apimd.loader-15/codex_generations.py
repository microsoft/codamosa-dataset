

# Generated at 2022-06-25 14:28:12.580890
# Unit test for function walk_packages
def test_walk_packages():
    import sys
    import os
    import pytest

    path_lib = os.path.dirname(__file__)
    path_list = os.listdir(path_lib)

    try:
        import pytest_ast
    except ImportError:
        path_list.append("pytest_ast")
    else:
        path_list.remove("pytest_ast")

    path_list_str = str(path_list)

    @pytest.mark.parametrize("path", path_list)
    def test_case_1(path):
        """Test case 1"""
        str_1 = str(path)
        iterator_2 = walk_packages(str_1, str_1)
        str_2 = ""

# Generated at 2022-06-25 14:28:15.651436
# Unit test for function loader
def test_loader():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    assert loader(str_0, str_1, None, None, None) == ""

# Generated at 2022-06-25 14:28:19.868887
# Unit test for function loader
def test_loader():
    str_0 = None
    int_0 = 0
    bool_0 = True
    bool_1 = False
    _0 = loader(str_0, str_0, bool_0, int_0, bool_1)
    _1 = loader(str_0, str_0, bool_1, int_0, bool_1)
    assert _0 is not None
    assert _1 is not None
    assert _0 != _1

# Generated at 2022-06-25 14:28:21.138734
# Unit test for function loader
def test_loader():
   loader("mytest", "E:\\test", True, 1, True)

test_loader()

# Generated at 2022-06-25 14:28:22.977685
# Unit test for function loader
def test_loader():
    str_0 = ''
    print(loader(str_0, str_0, bool, int, bool))


# Generated at 2022-06-25 14:28:24.284464
# Unit test for function walk_packages
def test_walk_packages():
    iterator_0 = walk_packages(str, type)
    for _ in iterator_0:
        pass


# Generated at 2022-06-25 14:28:24.995193
# Unit test for function walk_packages
def test_walk_packages():
    test_case_0()

# Generated at 2022-06-25 14:28:29.166577
# Unit test for function walk_packages
def test_walk_packages():
    class Sequence_0:
        def __getitem__(self, index_0: int) -> str:
            return 'str_1'

        def __len__(self) -> int:
            return 0

    sequence_0 = Sequence_0()
    bool_0 = isdir(sequence_0)
    iterator_1 = walk_packages(sequence_0, sequence_0)

if __name__ == '__main__':
    test_case_0()
    test_walk_packages()

# Generated at 2022-06-25 14:28:35.160110
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    str_1 = 'pyslvs'
    str_2 = '.py'
    str_3 = '.pyi'
    str_4 = 'utils'
    str_5 = 'compiler'
    str_6 = 'compiler.py'
    str_7 = 'compiler.pyi'
    str_8 = 'compiler-stubs'
    str_9 = 'compiler-stubs.py'
    str_10 = 'compiler-stubs.pyi'
    str_11 = '/opt/local/Library/Frameworks/Python.framework/Versions/3.8/lib/python3.8/site-packages'

# Generated at 2022-06-25 14:28:40.449366
# Unit test for function walk_packages
def test_walk_packages():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ()
    tuple_5 = ()
    tuple_6 = ()
    tuple_7 = ()
    tuple_8 = ()
    tuple_9 = ()
    tuple_10 = ()
    tuple_11 = ()
    tuple_12 = ()
    tuple_13 = ()
    tuple_14 = ()
    tuple_15 = ()
    tuple_16 = ()
    tuple_17 = ()
    tuple_

# Generated at 2022-06-25 14:34:28.402368
# Unit test for function loader
def test_loader():
    """Unit test for function loader."""
    from .test import test_loader
    assert loader(*test_loader)
    from .test import test_loader
    assert loader(*test_loader)

# Generated at 2022-06-25 14:34:29.202132
# Unit test for function loader
def test_loader():
    test_case_0()


# Generated at 2022-06-25 14:34:31.543536
# Unit test for function walk_packages
def test_walk_packages():
    for value in walk_packages("pyslvs", r"C:\Users\YUAN\AppData\Local\Programs\Python\Python38"):
        print(value)


# Generated at 2022-06-25 14:34:32.580650
# Unit test for function walk_packages
def test_walk_packages():
    # docstring is on first line
    a = "b"
    c, d = b
    return c


# Generated at 2022-06-25 14:34:39.365317
# Unit test for function walk_packages
def test_walk_packages():
    import pkgutil
    mkdir('test_dir')
    with open('test_dir/__init__.py', 'w+') as f:
        pass
    with open('test_dir/a.py', 'w+') as f:
        pass
    with open('test_dir/b.pyi', 'w+') as f:
        pass
    g = walk_packages('test_dir', '.')
    assert next(g) == ('test_dir', 'test_dir/__init__.py')
    assert next(g) == ('test_dir.a', 'test_dir/a.py')
    assert next(g) == ('test_dir.b', 'test_dir/b.pyi')

# Generated at 2022-06-25 14:34:43.446457
# Unit test for function loader
def test_loader():
    # test_case_0
    docs = gen_api({'test': 'test'}, pwd=None, prefix='docs', link=True, level=1, toc=False, dry=False)
    assert len(docs) == 1
    assert docs[0] == '# test API\n\n'

# Generated at 2022-06-25 14:34:51.750675
# Unit test for function walk_packages
def test_walk_packages():
    def on_start_walk(name: str, path: str):
        if name == 'examples.aa':
            return
        print('='*80)
        print('start walk')
        print(name)
        print(path)
        print('='*80)

    def on_walk_packages(name: str, path: str):
        if name == 'examples.aa':
            return
        print('='*80)
        print('walk')
        print(name)
        print(path)
        print('='*80)

    def on_find_import_error(name: str, path: str):
        print('='*80)
        print('find import error')
        print(name)
        print(path)
        print('='*80)


# Generated at 2022-06-25 14:34:52.714171
# Unit test for function loader
def test_loader():
    assert loader('sys', '', link=True, level=0, toc=False)

# Generated at 2022-06-25 14:35:00.860386
# Unit test for function walk_packages
def test_walk_packages():
    if "unit_test" not in sys_path:
        sys_path.append("unit_test")
    #test_case_0
    ret_0 = [[name, path] for name, path in walk_packages("walk_packages", "unit_test")]
    ret_0.sort()

# Generated at 2022-06-25 14:35:05.409053
# Unit test for function walk_packages
def test_walk_packages():
    name_1 = "pyslvs"
    path_1 = "E:/Desktop/web"
    for args in walk_packages(name_1, path_1):
        str_1 = args[0]
        str_2 = args[1]
        print(f'string 1: {str_1}\nstring 2: {str_2}')
