

# Generated at 2022-06-20 13:52:03.889198
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    assert ConfigManager() is not None



# Generated at 2022-06-20 13:52:10.471985
# Unit test for function get_config_type
def test_get_config_type():
    # test for an empty config file
    assert get_config_type(None) is None

    cfile = './test/ansible.cfg'
    # test for an unsupported config file type
    try:
        get_config_type(cfile)
    except AnsibleOptionsError as e:
        assert "Unsupported configuration file extension for" in to_native(e)
        assert cfile in to_native(e)

    cfile = './test/ansible.cfg.template'
    # test for yaml config file
    assert get_config_type(cfile) == 'yaml'

    cfile = './test/ansible.cfg.j2'
    # test for ini config file
    assert get_config_type(cfile) == 'ini'



# Generated at 2022-06-20 13:52:15.737842
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    TestAnsibleCoreUnitTestCase._config_manager._plugins = {'action': {'action_plugin': {'run_as_become': {'default': True, 'type': 'boolean'}}}}
    TestAnsibleCoreUnitTestCase._config_manager.get_plugin_vars('action', 'action_plugin')
    # TODO: test return value


# Generated at 2022-06-20 13:52:23.085769
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    class FakeConfig:
        def __init__(self, path=None, mode=None, umask=None):
            self.orig_getcwd = os.getcwd
            self.orig_getenv = os.getenv
            self.orig_stat = os.stat
            self.orig_path_exists = os.path.exists
            self.orig_path_access = os.access
            self.orig_mkstemp = tempfile.mkstemp
            self.orig_unlink = os.unlink
            self.orig_chmod = os.chmod
            self.orig_chown = os.chown
            self.orig_makedirs = os.makedirs

            self.tmp_path = None
            self.tmp_fd = None
            self.tmp_mode = '0777'
            self

# Generated at 2022-06-20 13:52:34.793553
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager(
        defaults=None,
        validator=None,
        loader=None,
    )

    with pytest.raises(AnsibleError):
        config_manager.get_configuration_definitions()

    with pytest.raises(AnsibleError):
        config_manager.get_configuration_definitions(plugin_type="invalid_plugin_type")

    config_manager.initialize_plugin_configuration_definitions(
        plugin_type="invalid_plugin_type",
        name="invalid_name",
        defs={},
    )


# Generated at 2022-06-20 13:52:38.928383
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    ''' test config file precedence '''

    ini_config_file = find_ini_config_file()

    assert len(ini_config_file) >= 1

    assert ini_config_file == '/etc/ansible/ansible.cfg'



# Generated at 2022-06-20 13:52:44.980934
# Unit test for constructor of class Plugin
def test_Plugin():
    import ansible.plugins.connection.ssh
    plugin = Plugin(ansible.plugins.connection.ssh, 'ssh', C.DEFAULT_CONNECTION_PLUGIN_PATH)
    assert isinstance(plugin, ansible.plugins.connection.ssh.Connection)
    assert plugin._load_name == 'ssh'
    assert plugin._name == 'ssh'
    assert plugin._subdir == None
    assert plugin._class_name == 'Connection'
    assert plugin._class_path == 'ansible.plugins.connection.ssh.Connection'
    assert plugin._path == C.DEFAULT_CONNECTION_PLUGIN_PATH


# Generated at 2022-06-20 13:52:50.572069
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    ''' test config file load order '''
    cfg_fp = None
    cfg_path = None
    ftype = None

    # FIXME: test search path when config file specified in ENV
    warnings = set()


# Generated at 2022-06-20 13:52:56.328213
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('test/test.ini') == 'ini'
    assert get_config_type('test/test.cfg') == 'ini'
    assert get_config_type('test/test.yaml') == 'yaml'
    assert get_config_type('test/test.yml') == 'yaml'
    assert get_config_type('test/test') is None



# Generated at 2022-06-20 13:53:04.163901
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    Unit test method (ConfigManager.get_config_value_and_origin)
    '''
    from ansible.utils.display import Display

    display = Display()
    config_manager = ConfigManager(['/etc/ansible/ansible.cfg', '~/.ansible.cfg'], display, None)
    config_manager.USER_CONFIG_FILE = '/etc/ansible/ansible.cfg'
    config_manager.DATA_PLUGIN_CONFIG_FILE = '/etc/ansible/ansible.cfg'
    config_manager.DEFAULTS_PLUGIN_CONFIG_FILE = '/etc/ansible/ansible.cfg'
    config_manager.INVENTORY_PLUGIN_CONFIG_FILE = '/etc/ansible/ansible.cfg'
    config_manager.VARS_