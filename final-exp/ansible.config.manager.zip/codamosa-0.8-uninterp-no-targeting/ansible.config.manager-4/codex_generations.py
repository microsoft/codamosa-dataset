

# Generated at 2022-06-20 13:50:24.913618
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('TEST_TYPE', 'TEST_NAME', {'TEST_SETTING': {'default': 'TEST_DEFAULT_VALUE'}})
    assert config_manager._plugins == {'TEST_TYPE': {'TEST_NAME': {'TEST_SETTING': {'default': 'TEST_DEFAULT_VALUE'}}}}


# Generated at 2022-06-20 13:50:27.456264
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.get_plugin_vars('connection', 'paramiko_ssh')
    config.get_plugin_vars('shell', 'powershell')
    config.get_plugin_vars('strategy', 'linear')
    config.get_plugin_vars('strategy', 'free')
    config.get_plugin_vars('lookup', 'password_lookup')
    config.get_plugin_vars('lookup', 'file')


# Generated at 2022-06-20 13:50:28.855852
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    '''
    Unit test for method get_configuration_definition
    '''
    config_manager = ConfigManager()
    assert config_manager.get_configuration_definition('')


# Generated at 2022-06-20 13:50:30.428254
# Unit test for constructor of class Setting
def test_Setting():
    assert Setting('CONFIG_FILE', 'ansible.cfg', "{'deprecated': 'Use ANSIBLE_CONFIG'}", type='string')


# Generated at 2022-06-20 13:50:31.263273
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    test_obj = ConfigManager()
    assert test_obj is not None


# Generated at 2022-06-20 13:50:35.687664
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    test = ConfigManager()
    
    # There was no expection raised. 
    # Test with a valid arguments.
    test.initialize_plugin_configuration_definitions('Basic', 'Basic', None)
    
    # Test with a valid arguments.
    test.initialize_plugin_configuration_definitions('Basic', 'Basic', {})
    
    # Test with a valid arguments.
    test.initialize_plugin_configuration_definitions('Basic', 'Basic', {'test': {}})
    
    # Test with a valid arguments.
    test.initialize_plugin_configuration_definitions('Basic', 'test', {'test': {}})
    
    # Test with a valid arguments.
    test.initialize_plugin_configuration_definitions(123, 'Basic', {'test': {}})
    

# Generated at 2022-06-20 13:50:38.421196
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    #This code is executed when run the unit test
    #TODO: Move the test code from here to the init class's test method
    unit_test_instance = ConfigManager()
    #TODO: Add the relevant lines from here to the init method of the class
    #TODO: Add lines here to clear the instance state before running the actual assert test
    #TODO: Add actual assert test statement here
    assert unit_test_instance.get_config_value_and_origin() is None


# Generated at 2022-06-20 13:50:46.444663
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.read('test/fixtures/test_config_parse.ini')
    # Positive test with defaults
    entry = {'section': 'defaults', 'key': 'internal_poll_interval'}
    assert get_ini_config_value(p, entry) == '10'
    # Positive test overriding defaults
    entry = {'section': 'ssh_connection', 'key': 'scp_if_ssh'}
    assert get_ini_config_value(p, entry) == 'True'
    # Negative test for None
    entry = {'section': 'michael_scott', 'key': 'branch_name'}
    assert get_ini_config_value(p, entry) is None
    
    
    
        
# FIXME: see if this can be moved to common

# Generated at 2022-06-20 13:50:50.665813
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    data = ConfigManager()
    if is_failed(data.__init__()):
        raise Exception("Error in ConfigManager.__init__(): %s" % data.error_msg)

    # test for plugin_type = None, name = None

    expected = []
    actual = data.get_plugin_vars(None, None)
    if sorted(actual) != sorted(expected):
        raise Exception("Error in ConfigManager.get_plugin_vars(): Actual result differs from expected result.\nActual: %s\nExpected: %s" % (actual, expected))

    # test for plugin_type = u'callback', name = None

    expected = []
    actual = data.get_plugin_vars(u'callback', None)

# Generated at 2022-06-20 13:51:00.660146
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager()
    config_defs = {
        'TEST_CONFIG': {
            'default': 'test_config_value',
            'choices': ['test_config_value'],
            'env': [{'name': 'TEST_ENV'}],
            'ini': [{'key': 'test_config', 'section': 'default'}],
            'yaml': ['test_config'],
        }, 'OTHER_CONFIG': {
            'required': True,
            'env': [{'name': 'OTHER_ENV'}],
            'ini': [{'key': 'other_config', 'section': 'default'}],
            'yaml': ['other_config'],
        },
    }