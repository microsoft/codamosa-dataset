

# Generated at 2022-06-20 13:51:34.012425
# Unit test for function get_config_type
def test_get_config_type():

    cfile = None
    ftype = get_config_type(cfile)
    assert ftype is None

    cfile = "testfile.ini"
    ftype = get_config_type(cfile)
    assert ftype == 'ini'

    cfile = "testfile.cfg"
    ftype = get_config_type(cfile)
    assert ftype == 'ini'

    cfile = "testfile.yaml"
    ftype = get_config_type(cfile)
    assert ftype == 'yaml'

    cfile = "testfile.yml"
    ftype = get_config_type(cfile)
    assert ftype == 'yaml'


# Generated at 2022-06-20 13:51:39.180489
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    Unit test for method get_config_value_and_origin of class ConfigManager
    '''

    # Initialize test values
    plugin_type = ''
    name = ''
    defs = {}

    config = init_config(args=[])
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    plugin_type = ''
    name = ''
    defs = {}

    config = init_config(args=[])
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    # Initialize test values
    plugin_type

# Generated at 2022-06-20 13:51:47.901868
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():

    # Setup
    config = ConfigManager()
    config.base_defs = {'config': {'default': None, 'type': 'string'}}

    # Test body
    plugin_type = 'plugin_type'
    name = 'name'
    keys = {'config': 'value'}
    variables = {}
    direct = None
    # Should fail with TypeError since there is no such method
    # config.get_plugin_options(plugin_type, name, keys, variables, direct)
    with pytest.raises(TypeError):
        config.get_plugin_options(plugin_type, name, keys, variables, direct)


# Generated at 2022-06-20 13:51:50.492261
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # For now, just make sure that it runs without throwing exceptions.
    config_manager = ConfigManager(args=[])
    config_manager.update_config_data()

# Generated at 2022-06-20 13:51:53.067874
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_manager = ConfigManager()
    assert config_manager.data._settings
    assert config_manager.data._constants


# Generated at 2022-06-20 13:52:01.919196
# Unit test for function get_config_type
def test_get_config_type():
    """
    Test function get_config_type() for paramiko_ssh connection plugin
    """
    assert 'ini' == get_config_type("./lib/ansible/plugins/connection/paramiko_ssh.cfg")
    assert 'ini' == get_config_type("./lib/ansible/plugins/connection/paramiko_ssh.ini")
    assert 'yaml' == get_config_type("./lib/ansible/plugins/connection/paramiko_ssh.yaml")
    assert 'yaml' == get_config_type("./lib/ansible/plugins/connection/paramiko_ssh.yml")

# Generated at 2022-06-20 13:52:09.865849
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    class MockConfig:
        def __init__(self):
            self.plugin_name = "test"
            self.plugin_type = "test"
            self.plugin_defs = {}
            self.config = None

        def initialize_plugin_configuration_definitions(self, plugin_type, name, defs):
            self.plugin_defs[name] = defs

        def _walk(self, path, **kwargs):
            return []

        def get_config_value(self, config, cfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None):
            if self.plugin_name == plugin_name:
                return self.plugin_defs[plugin_name]
            else:
                return None

    # Replace 'C.DEFAULT_CFG_

# Generated at 2022-06-20 13:52:20.071206
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    assert config.get_plugin_vars('connection','local') == ['ansible_connection','ansible_python_interpreter','ansible_shell_type','ansible_shell_executable','ansible_playbook_python','ansible_playbook_python']
    assert config.get_plugin_vars('become','sudo') == ['ansible_become_method','ansible_become_user','ansible_become_pass','ansible_become']
    assert config.get_plugin_vars('lookup','env') == ['ansible_lookup_plugins']
    assert config.get_plugin_vars('shell','bash') == ['ansible_shell_type']

# Generated at 2022-06-20 13:52:25.051574
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.read('/etc/ansible/ansible.cfg')
    assert get_ini_config_value(p, dict(section='defaults', key='remote_port')) == '22'
    assert get_ini_config_value(p, dict()) is None



# Generated at 2022-06-20 13:52:26.343594
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    # testing this method would require fully implementing a plugin
    pass