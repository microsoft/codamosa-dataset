

# Generated at 2022-06-20 13:51:00.894516
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    # Create a config manager to test
    config_manager = ConfigManager()

    # Set local variables for testing (config_manager.get_plugin_options(plugin_type, name, keys=None, variables=None, direct=None)):
    plugin_type = 'action'
    name = 'run'
    keys=None
    variables=None
    direct = None

    # Test variable assignment
    # Test the assignment of the variable plugin_type
    assert plugin_type == plugin_type
    # Test the assignment of the variable name
    assert name == name
    # Test the assignment of the variable config_manager
    assert config_manager == config_manager

# Generated at 2022-06-20 13:51:07.720249
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    config_parser = configparser.ConfigParser()
    config_parser.add_section('p')
    config_parser.set('p', 'foo', 'bar')
    entry1 = {'section':'p', 'key':'foo'}
    entry2 = {'section':'q', 'key':'bar'}
    entry3 = {'section':'r'}
    entry4 = {'key':'baz'}
    assert 'bar' == get_ini_config_value(config_parser, entry1)
    assert get_ini_config_value(config_parser, entry2) is None
    assert get_ini_config_value(config_parser, entry3) is None
    assert get_ini_config_value(config_parser, entry4) is None


# FIXME: can move to module_utils for

# Generated at 2022-06-20 13:51:10.339059
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    ''' test for configmanager constructor '''
    config_manager = ConfigManager()
    assert isinstance(config_manager.data, ConfigData)
    assert config_manager.get_config_value('CONFIGURABLE_PLUGINS') == config_manager.data.get_setting('CONFIGURABLE_PLUGINS')

# Generated at 2022-06-20 13:51:12.756533
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.parse()
    # get_configuration_definitions(plugin_type=None, name=None, ignore_private=False)
    spec = inspect.getargspec(config.get_configuration_definitions)
    assert len(spec.args) == 4



# Generated at 2022-06-20 13:51:13.261798
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    pass

# Generated at 2022-06-20 13:51:18.479018
# Unit test for function resolve_path
def test_resolve_path():
    os.chdir('/')
    assert resolve_path('/etc') == '/etc'
    assert resolve_path('/etc', basedir='/') == '/etc'
    assert resolve_path('/etc', basedir='/root/argstest') == '/etc'
    assert resolve_path('{{CWD}}/etc') == '/etc'
    assert resolve_path('{{CWD}}/etc', basedir='/root/argstest') == '/etc'
    assert resolve_path('../etc', basedir='/root/argstest') == '/etc'
    assert resolve_path('../../etc', basedir='/root/argstest') == '/etc'
    assert resolve_path('./etc', basedir='/root/argstest') == '/root/argstest/etc'

# Generated at 2022-06-20 13:51:19.297313
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin('lightbar')
    assert plugin.name == 'lightbar'

# Generated at 2022-06-20 13:51:24.890928
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():

    config_name = 'test_config.cfg'
    test_config = b'''[defaults]
host_key_checking = True

[ssh_connection]
scp_if_ssh = False

[persistent_connection]
command_timeout = 10
'''

# Generated at 2022-06-20 13:51:29.974157
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('3', 'integer') == 3
    assert ensure_type('3', 'int') == 3
    assert ensure_type('3.0', 'float') == 3.0
    assert ensure_type('true', 'bool')
    assert ensure_type('True', 'bool')
    assert ensure_type('TRUE', 'bool')
    assert ensure_type(True, 'bool')
    assert ensure_type('false', 'bool')
    assert ensure_type('False', 'bool')
    assert ensure_type('FALSE', 'bool')
    assert not ensure_type(False, 'bool')
    assert ensure_type('foo, bar', 'list') == ['foo', 'bar']
    assert ensure_type('None', 'none') is None
    assert ensure_type('$HOME', 'path') == '/home/username'


# Generated at 2022-06-20 13:51:33.212933
# Unit test for function get_config_type
def test_get_config_type():
    ''' config_loader: get_config_type() '''

    assert get_config_type(None) is None
    assert get_config_type('foo.cfg') == 'ini'
    assert get_config_type('foo.yaml') == 'yaml'
    assert get_config_type('foo.yml') == 'yaml'

try:
    from ansible.parsing.yaml.loader import AnsibleLoader
    HAS_YAMLLOADER = True
except ImportError:
    HAS_YAMLLOADER = False

