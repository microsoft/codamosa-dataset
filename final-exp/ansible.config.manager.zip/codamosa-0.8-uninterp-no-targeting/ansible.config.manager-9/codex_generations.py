

# Generated at 2022-06-20 13:50:33.052085
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    '''test ConfigManager'''

    # setup
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('strategy', 'linear',
                                                   {'num_hosts': {'default': 30, 'type': 'int'},
                                                    'timeout': {'default': 30, 'type': 'int', 'ini': [{'section': 'strategy:linear', 'key': 'timeout', 'vault_key': None, 'conf_type': 'setting'}], 'vars': [{'name': 'strategy_timeout', 'conf_type': 'setting'}]}})

# Generated at 2022-06-20 13:50:42.560645
# Unit test for function ensure_type
def test_ensure_type():
    # pylint: disable=missing-docstring
    import json
    import datetime
    from ansible.module_utils._text import to_text

    assert False is ensure_type(False, ensure_type, 'bool')
    assert True is ensure_type(True, ensure_type, 'bool')
    assert 5 == ensure_type(5, ensure_type, 'int')
    assert 5 is ensure_type(5, ensure_type, 'int')
    assert 5 is ensure_type('5', ensure_type, 'int')
    assert 5.6 == ensure_type('5.6', ensure_type, 'float')
    assert 5.6 is ensure_type('5.6', ensure_type, 'float')
    assert [1, 2, 3] == ensure_type('1,2,3', ensure_type, 'list')


# Generated at 2022-06-20 13:50:49.862572
# Unit test for function get_config_type
def test_get_config_type():
    # Test passing config ini
    cfile = tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.ini')
    cfile.write('[defaults]\n'
                'inventory = /etc/ansible/hosts\n')
    cfile.close()
    try:
        assert get_config_type(cfile.name) == 'ini'
    finally:
        os.unlink(cfile.name)

    # Test passing config yaml
    cfile = tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.yaml')
    cfile.write('---\n'
                'defaults:\n'
                '  inventory: /etc/ansible/hosts\n')
    cfile.close()

# Generated at 2022-06-20 13:50:54.046601
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    ini_cfg = '''
[defaults]
ansible_python_interpreter = /some/path/to/python
ansible_managed = ansible managed: {file} modified on %Y-%m-%d %H:%M:%S by {uid} on {host}
force_handlers = False
nocows = 1
nocolor = 0
'''
    cm = ConfigManager(defs=ConfigDefs, config_file="<string>")
    cm._parse_config_file = MagicMock(return_value=ini_cfg)
    cm._config_file = "<string>"
    cm.update_config_data()
    assert cm.data['ANSIBLE_CONFIG'] == "<string>"

# Generated at 2022-06-20 13:51:02.608420
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(123, 'int') == 123
    assert ensure_type(123, 'integer') == 123
    assert ensure_type('123', 'integer') == 123
    assert ensure_type('INVALID', 'integer') == 'INVALID'
    assert ensure_type(123, 'float') == 123.0
    assert ensure_type('123.5', 'float') == 123.5
    assert ensure_type('INVALID', 'float') == 'INVALID'
    assert ensure_type('a,b,c', 'list') == ['a', 'b', 'c']
    assert ensure_type('a, b, c', 'list') == ['a', 'b', 'c']
    assert ensure_type('a, b, c', 'string') == 'a, b, c'



# Generated at 2022-06-20 13:51:08.258405
# Unit test for constructor of class Setting
def test_Setting():
    setting = Setting(config='test', value='test', origin='test', setting_type='test')
    assert setting.config == 'test'
    assert setting.value == 'test'
    assert setting.setting_type == 'test'
    assert setting.origin == 'test'

    setting.config = 'test2'
    assert setting.config == 'test2'

    setting.value = 'test2'
    assert setting.value == 'test2'

    setting.origin = 'test2'
    assert setting.origin == 'test2'

    setting.setting_type = 'test2'
    assert setting.setting_type == 'test2'

    # Setting should be hashable
    assert isinstance(hash(setting), int)

# Generated at 2022-06-20 13:51:10.935605
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    a = ConfigManager()
    a.initialize_plugin_configuration_definitions(plugin_type='action_plugin', name='media_upload', defs={'a': {'default': 'b'}})
    assert a.get_plugin_vars(plugin_type='action_plugin', name='media_upload') == []



# Generated at 2022-06-20 13:51:11.992929
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # FIXME: use fixture for config manager
    # FIXME: need to have a config type that will take precedence from the command line
    pass


# Generated at 2022-06-20 13:51:15.630993
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(None, 'path') == None
    assert ensure_type('', 'path').endswith('/')
    assert ensure_type('~', 'path') == '/root/'
    assert ensure_type('/', 'tmppath') == '/'
    assert ensure_type('/etc', 'path') == '/etc/'
    assert ensure_type('~/', 'path') == '/root/'
    assert ensure_type('~/foo', 'path') == '/root/foo'
    assert isinstance(ensure_type('1', 'int'), int)
    assert isinstance(ensure_type('1', 'float'), float)
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type(['1'], 'list') == ['1']

# Generated at 2022-06-20 13:51:17.438085
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager(parser=DictParser())
    # validate the contract of the method
    assert callable(config.initialize_plugin_configuration_definitions)
