

# Generated at 2022-06-20 13:48:53.746126
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    ''' basic test for ConfigManager '''

    # empty class test to show coverage
    c = ConfigManager()
    assert c.get_config_value('deprecate_commands') is False
    assert c.get_config_value('environment') == ['USER', 'LANG', 'LC_ALL']

    # undocumented feature on readability
    assert 'HELLO' in c.get_config_value('environment')
    c.get_config_value('environment').remove('HELLO')
    assert 'HELLO' not in c.get_config_value('environment')

    # single value test
    c = ConfigManager(confnames=["ansible.cfg"])
    assert c.get_config_value('deprecate_commands') is False

    # multi value test, simple

# Generated at 2022-06-20 13:49:06.294308
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader, lookup_loader

    p = Play.load({'gather_facts': False, 'connection': 'local', 'hosts': 'localhost', 'name': 'test', 'roles': [], 'tasks': [{'action': {'args': {'_': 'user,key1,key2', 'key1': 'val1', 'key2': 'val2'}, 'module': 'debug'}}]}, base_vars=[], vars_plugins=[], vars_files=[], connection_loader=connection_loader, lookup_loader=lookup_loader)
    entry = dict(section='defaults', key='vars_plugins')
    result1 = get_ini_config_value(p, entry)
    assert result1 == ''



# Generated at 2022-06-20 13:49:20.799589
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    #
    # set up
    #
    config_manager = ConfigManager()
    config_name = "foo"
    plugin_type = "dummy_plugin_type"
    plugin_name = "dummy_plugin_name"

    #
    # test against config_manager.CONFIG_SOURCE_SECRETS_FILE in the config file
    #
    # set up
    #
    config_name2 = "__ansible_vault_password_file"
    plugin_type2 = None
    plugin_name2 = None
    config_manager.CONFIG_DATA[config_name2] = "~/.ansible/myvault_password_file"
    config_manager.CONFIG_SOURCE_PREFIX = ""

# Generated at 2022-06-20 13:49:23.154655
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    print('Testing ConfigManager.get_config_value')
    assert False, "Tests haven't been implemented yet"

# Generated at 2022-06-20 13:49:36.303944
# Unit test for function resolve_path
def test_resolve_path():
    '''
    resolve_path should replace {{CWD}} with the cwd
    It should not follow symlinks
    It should expand envvars and user dirs (~)
    It should return absolute paths if given relative paths
    It should return relative paths if given relative paths and basedir is unset.
    It should return paths relative to basedir if given relative paths and basedir is set.
    '''

    cwd = os.getcwd()
    homedir = os.path.expanduser('~')
    #test_dir = tempfile.mkdtemp()
    test_dir = "/tmp/testdir"
    test_file = os.path.join(test_dir, "test_file")
    os.makedirs(test_dir)
    tempfile.mkstemp(dir=test_dir)
    os.ch

# Generated at 2022-06-20 13:49:40.642845
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    global_config = ConfigManager('/etc/ansible/ansible.cfg')
    assert global_config.DEFAULT_VAULT_ID_MATCH is not None
    assert global_config.DEFAULT_AGENT_ENV_KEYS == ['SSH_AUTH_SOCK']

# Generated at 2022-06-20 13:49:52.029093
# Unit test for function resolve_path
def test_resolve_path():
    assert(resolve_path('/etc/ansible') == '/etc/ansible')
    assert(resolve_path('/etc/../etc/ansible') == '/etc/ansible')
    # Currently disabled on Windows (see #29662)
    if not sys.platform.startswith('win'):
        assert(resolve_path('~/ansible') == os.path.expanduser('~/ansible'))
    assert(resolve_path('../ansible', basedir='/etc/ansible/playbooks') == '/etc/ansible')

# FIXME: see if this can live in utils/path

# Generated at 2022-06-20 13:49:55.414147
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('connection', 'local', {})
    cm.get_plugin_vars('connection', 'local')



# Generated at 2022-06-20 13:50:05.660049
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    const = C()
    m = ConfigManager(['/non_existing/ansible.cfg', '/etc/ansible/ansible.cfg', '~/.ansible.cfg'])
    m.update_config_data(base_defs)
    assert m.get_config_value('host_key_checking') == False
    assert m.get_config_value('host_key_checking', variables={'host_key_checking': True}) == True
    assert m.get_config_value('host_key_checking', variables={'host_key_checking': True}, direct={'host_key_checking': True}) == True

    # only allow lowercase when type=boolean
    assert m.get_config_value('host_key_checking', variables={'host_key_checking': 'True'}) == 'True'

# Generated at 2022-06-20 13:50:07.334857
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    result = get_ini_config_value(p=None, entry='/fake/path')

# FIXME: can move to module_utils for use for yaml plugins also?