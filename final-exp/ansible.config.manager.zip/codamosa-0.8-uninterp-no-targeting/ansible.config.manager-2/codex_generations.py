

# Generated at 2022-06-20 13:53:21.345743
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config = dict(
        prompt = dict(
            default = 'False',
            type = 'bool',
            env = [ dict(name='ANSIBLE_PROMPT') ]
        )
    )
    cm = ConfigManager(config, "invalid_filename")
    assert cm.get_config_value("prompt") == False
    assert cm.get_config_value("prompt", direct=dict(prompt=True)) == True
    assert cm.get_config_value("prompt", direct=dict(prompt=False)) == False

    # add a non-bool value, and test to ensure the type is properly set.
    config['prompt']['choices'] = [ False, True, None ]
    assert cm.get_config_value("prompt", direct=dict(prompt=None)) is None

    # now test

# Generated at 2022-06-20 13:53:24.469948
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    cm = ConfigManager()
    # .data.data.setting_defs.setting_defs
    assert len(cm.data.setting_defs.setting_defs) > 80

# Test for get_configuration_definitions
# - get_configuration_definitions works for None, plugin_type and plugin_name

# Generated at 2022-06-20 13:53:26.275529
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
   c = ConfigManager()
   c.initialize_plugin_configuration_definitions("type","name", "defs")
   assert c.get_plugin_vars("type","name") == []



# Generated at 2022-06-20 13:53:28.748281
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('test.ini').lower() == 'ini'
    assert get_config_type('test.cfg').lower() == 'ini'
    assert get_config_type('test.yaml').lower() == 'yaml'
    assert get_config_type('test.yml').lower() == 'yaml'



# Generated at 2022-06-20 13:53:30.535286
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    con = ConfigManager()
    result = ConfigManager.get_plugin_options(con, 'test', 'test')
    assert result is None


# Generated at 2022-06-20 13:53:39.769892
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    defs = config_manager.get_configuration_definitions('host_key_checking')