

# Generated at 2022-06-20 13:51:23.748770
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager('tests/test_config.cfg')
    config._parse_config_file(False)
    config.update_config_data()
    assert config.data._settings['ANSIBLE_CALLBACK_WHITELIST'] == 'async_wrapper,debug,profile_roles,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks,profile_tasks'
    assert config.data._settings['ANSIBLE_CACHE_PLUGIN'] == 'memory_key_value'
    assert config.data._settings['ANSIBLE_CACHE_PLUGIN_CONNECTION'] == ''
    assert config

# Generated at 2022-06-20 13:51:25.167493
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    plugin_type = 'cache'
    name = 'memory'
    assert config.get_plugin_vars(plugin_type, name) == []

# Generated at 2022-06-20 13:51:30.249997
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    def test(tmpdir, monkeypatch, *a, **kw):
        class Warning(object):
            def __init__(self):
                self.calls = []
            def __call__(self, message):
                self.calls.append(message)
        warnings = Warning()
        cwd = os.getcwd()
        tmpdir = to_text(tmpdir)

        monkeypatch.chdir(tmpdir)
        monkeypatch.setattr(os, 'getcwd', lambda: tmpdir)

        # Create a file we would skip. We need this so that there is a file to check for when
        # we go to warn about it later.
        open(os.path.join(tmpdir, "ansible.cfg"), 'a').close()

# Generated at 2022-06-20 13:51:31.039176
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # test code
    # test code
    # test code
    pass

# Generated at 2022-06-20 13:51:32.447827
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    pass

    # FIXME: implement unit test for ConfigManager.update_config_data
    #       No unit testable method found for ConfigManager.update_config_data



# Generated at 2022-06-20 13:51:36.175495
# Unit test for function resolve_path
def test_resolve_path():
    def tmp_resolve_path():
        return resolve_path('{{CWD}}')
    assert tmp_resolve_path() == unfrackpath(os.path.curdir, follow=False)



# Generated at 2022-06-20 13:51:41.741809
# Unit test for function get_config_type
def test_get_config_type():

    assert get_config_type('/path/to/files/foo.yaml') == 'yaml'
    assert get_config_type('/path/to/files/foo.cfg') == 'ini'
    try:
        get_config_type('/path/to/files/foo.bar')
        assert False
    except AnsibleOptionsError:
        assert True
    try:
        get_config_type('/path/to/files/foo')
        assert False
    except AnsibleOptionsError:
        assert True
# end of Unit test for function get_config_type


# Generated at 2022-06-20 13:51:52.504271
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('True', 'bool') is True
    assert ensure_type('False', 'bool') is False
    assert ensure_type('101', 'int') == 101
    assert ensure_type('101', 'integer') == 101
    assert ensure_type('105', 'float') == 105.0
    assert ensure_type('/foo/bar,/tmp/abc', 'pathlist') == ['/foo/bar', '/tmp/abc']
    assert ensure_type('foo,bar', 'list') == ['foo', 'bar']
    assert ensure_type('/tmp/abc', 'path') == '/tmp/abc'
    assert ensure_type('None', 'none') is None
    assert ensure_type(None, 'none') is None
    assert ensure_type('hello world', 'str') == 'hello world'

# Generated at 2022-06-20 13:52:01.470579
# Unit test for function get_config_type
def test_get_config_type():
    dir = os.path.dirname(__file__)
    assert get_config_type(os.path.join(dir, 'test_data/test.ini')) == 'ini'
    assert get_config_type(os.path.join(dir, 'test_data/test.yaml')) == 'yaml'
    assert get_config_type(os.path.join(dir, 'test_data/test.yml')) == 'yaml'
    assert get_config_type(os.path.join(dir, 'test_data/test.cfg')) == 'ini'
    # test invalid file type
    try:
        get_config_type(os.path.join(dir, 'test_data/test.pdf'))
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-20 13:52:08.401657
# Unit test for constructor of class Setting
def test_Setting():
    setting = Setting('ANSIBLE_TEST_CONSTANT', 'test_value')
    assert setting._name == 'ANSIBLE_TEST_CONSTANT'
    assert setting._value == 'test_value'
    assert setting._origin == None
    assert setting._type == 'string'
    assert len(setting._defaults) == 0
    assert len(setting._vars) == 0
    assert len(setting._choices) == 0
    assert setting._required == False
    assert setting._deprecated_version is None
    assert setting._deprecated_msg is None
    assert not setting._aliases
    assert not setting._cli_options

