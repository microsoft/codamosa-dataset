

# Generated at 2022-06-20 13:53:21.280047
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    print('FIXME: write unit test for get_ini_config_value')

# FIXME: a lot of this could be moved to playbook.yml

# Generated at 2022-06-20 13:53:23.603710
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = []
    name = []
    defs = []
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs, )

# Generated at 2022-06-20 13:53:32.876087
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    cm = ConfigManager()
    cm.CACHE_PLUGIN_TYPE = 'foo'
    cm.CACHE_INVENTORIES = [{'name': 'test', 'plugin_type': 'test_plugin_type'}]
    cm.CACHE_EXTENSIONS = {'test_plugin_type': ['test_plugin_name']}
    cm.CACHE_PLUGIN_TEMPLATES = {'test_plugin_type': {'test_plugin_name': {'name': 'test_plugin_name'}}}
    cm.CACHE_KEYS = {'test_plugin_type': {'test_plugin_name': ['test']}}
    cm.CACHE_FILENAME = None
    cm._config_file = 'test_config_file'
    cm._base_defs