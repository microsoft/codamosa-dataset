

# Generated at 2022-06-20 13:51:39.709710
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    config_manager = ConfigManager()
    result = config_manager.get_config_value('DEFAULT_DIFF')
    assert result == False


# Generated at 2022-06-20 13:51:44.184124
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    mgr = ConfigManager()
    plugin_type = 'parser'
    name = 'ini'

    options = mgr.get_plugin_options(plugin_type, name)
    assert isinstance(options, dict)
    assert len(options) > 0
    assert options

# Generated at 2022-06-20 13:51:54.019472
# Unit test for constructor of class Plugin
def test_Plugin():

    from ansible.plugins.connection.fake import Connection as FakeConnection
    from ansible.plugins.inventory.fake import InventoryModule as FakeInventory
    from ansible.plugins.lookup.fake import LookupModule as FakeLookup
    from ansible.plugins.shell.fake import ShellModule as FakeShellModule
    from ansible.plugins.strategy.linear import StrategyModule as FakeLinearStrategy

    plug = Plugin()

    plugin_type = 'connection'
    name = 'fake'
    connection = FakeConnection()

    plug.add_plugin(plugin_type, name, connection)

    assert plug.has_plugin(plugin_type, name)

    plugin_type = 'inventory'
    name = 'fake'
    inventory = FakeInventory()

    plug.add_plugin(plugin_type, name, inventory)

    assert plug.has_

# Generated at 2022-06-20 13:52:03.565791
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # Test with empty config definition
    config = ConfigManager(['defaults/unittest'], [])
    config.parse_config_files()
    names = config.get_configuration_definitions()
    assert names == {}
    # Test with normal config definition
    config = ConfigManager(['defaults/unittest'], ['defaults/unittest/config.cfg'])
    config.parse_config_files()
    names = config.get_configuration_definitions('test', 'hello')

# Generated at 2022-06-20 13:52:07.058376
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    x = ConfigManager()
    defs = { 'one': { 'default': '1', 'type': 'int'} }
    if    x.initialize_plugin_configuration_definitions('plugin_type', 'name', defs) != None     : return 1

    return 0


# Generated at 2022-06-20 13:52:09.774582
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager(definitions={})
    assert config.get_plugin_vars('test_plugin', 'test_name') == []



# Generated at 2022-06-20 13:52:14.212102
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = ConfigManager()
    cm.parse(config_file="ansible.cfg")
    cm.get_config_value_and_origin("inventory")
    cm.get_config_value_and_origin("unknown")

# ===================================================================================
# main()
# ===================================================================================


# Generated at 2022-06-20 13:52:21.785913
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # initialize
    manager = ConfigManager()
    manager._base_defs = {'c': {}}

    # mock file exists method
    def mock_file_exists(file):
        if file in (None, '/nonexistent_file'):
            return False
        else:
            return True

    # mock get_ini_config_value
    def mock_get_ini_config_value(parser, key):
        return

    # patch
    with patch.object(manager, 'file_exists', mock_file_exists):
        with patch.object(manager, 'get_ini_config_value', mock_get_ini_config_value):
            manager.update_config_data()


# Generated at 2022-06-20 13:52:29.560941
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    cm = ConfigManager()
    assert cm.get_configuration_definition('DEFAULT_PRIVATE_KEY_FILE')=={'alias': 'private_key_file', 'env': [{'name': 'ANSIBLE_PRIVATE_KEY_FILE'}], 'ini': [{'key': 'private_key_file', 'section': 'defaults'}, {'key': 'private_key_file', 'section': 'ssh_connection'}], 'name': 'DEFAULT_PRIVATE_KEY_FILE', 'type': 'path'}


# Generated at 2022-06-20 13:52:39.604399
# Unit test for function resolve_path
def test_resolve_path():
    currentPath = os.path.dirname(os.path.realpath(__file__))
    testFails = 0
    pathToTest, expectedResult = ['../../lib/ansible/constants.py', '[...]/lib/ansible/constants.py']
    result = resolve_path(pathToTest, basedir=currentPath)
    if result != expectedResult:
        testFails += 1
        print("resolve_path - Test #1 failed!")
        print("Input: " + pathToTest)
        print("Expected result: " + expectedResult)
        print ("Actual result: " + result)

    pathToTest, expectedResult = ['~/mySource', os.path.expanduser('~') + '/mySource']
    result = resolve_path(pathToTest, basedir=currentPath)
   