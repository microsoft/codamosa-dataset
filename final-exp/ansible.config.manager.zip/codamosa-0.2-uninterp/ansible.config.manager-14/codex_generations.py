

# Generated at 2022-06-16 20:43:05.688732
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()


# Generated at 2022-06-16 20:43:07.577293
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager()
    config.update_config_data()
    assert config.data.CONFIG_FILE == 'ansible.cfg'


# Generated at 2022-06-16 20:43:14.322436
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    """
    Test the find_ini_config_file function.
    """
    # Test with no environment variable set
    os.environ.pop("ANSIBLE_CONFIG", None)
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set
    os.environ["ANSIBLE_CONFIG"] = "/tmp/ansible.cfg"
    assert find_ini_config_file() == "/tmp/ansible.cfg"

    # Test with environment variable set to a directory
    os.environ["ANSIBLE_CONFIG"] = "/tmp"
    assert find_ini_config_file() == "/tmp/ansible.cfg"

    # Test with environment variable set to a directory that doesn't exist

# Generated at 2022-06-16 20:43:21.817336
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with a config file that doesn't exist
    config_manager = ConfigManager()
    config_manager._config_file = 'doesntexist'
    config_manager._base_defs = {'test_config': {'default': 'default_value', 'type': 'string'}}
    value, origin = config_manager.get_config_value_and_origin('test_config')
    assert value == 'default_value'
    assert origin == 'default'
