

# Generated at 2022-06-16 20:36:28.985154
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    assert config_manager.get_configuration_definitions('test_plugin_type', 'test_plugin_name') == {'test_config': {'default': 'test_default', 'type': 'string'}}
    assert config_manager.get_configuration_definitions('test_plugin_type') == {'test_plugin_name': {'test_config': {'default': 'test_default', 'type': 'string'}}}

# Generated at 2022-06-16 20:36:38.788746
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type("True", "bool") is True
    assert ensure_type("False", "bool") is False
    assert ensure_type("1", "int") == 1
    assert ensure_type("1.1", "float") == 1.1
    assert ensure_type("1,2,3", "list") == ["1", "2", "3"]
    assert ensure_type("None", "none") is None
    assert ensure_type("/tmp/foo", "path") == "/tmp/foo"
    assert ensure_type("/tmp/foo", "tmppath") == "/tmp/foo"
    assert ensure_type("/tmp/foo", "pathspec") == "/tmp/foo"
    assert ensure_type("/tmp/foo", "pathlist") == "/tmp/foo"

# Generated at 2022-06-16 20:36:48.113962
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we find the config file in the current working directory
    # even if it is world writable
    with tempfile.TemporaryDirectory() as tmpdir:
        cwd = os.getcwd()
        os.chdir(tmpdir)
        with open("ansible.cfg", "w") as f:
            f.write("[defaults]\n")
            f.write("inventory = /tmp/inventory\n")
        os.chmod(tmpdir, 0o777)
        assert find_ini_config_file() == os.path.join(tmpdir, "ansible.cfg")
        os.chdir(cwd)

    # Test that we find the config file in the current working directory
    # even if it is world writable, but we have ANSIBLE_CONFIG set

# Generated at 2022-06-16 20:36:49.802848
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.get_config_value_and_origin('foo', 'bar', 'baz', 'qux')


# Generated at 2022-06-16 20:36:50.740521
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager()
    config.update_config_data()


# Generated at 2022-06-16 20:36:58.205338
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config = ConfigManager()
    config.parse()
    config.finalize()
    plugin_type = 'connection'
    name = 'local'
    keys = None
    variables = None
    direct = None

# Generated at 2022-06-16 20:37:03.684240
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with a config file that does not exist
    config_manager = ConfigManager(config_file='/tmp/ansible.cfg')
    config_manager.get_config_value_and_origin('config_file')
    # Test with a config file that does exist
    config_manager = ConfigManager(config_file=os.path.join(os.path.dirname(__file__), 'test.cfg'))
    config_manager.get_config_value_and_origin('config_file')
    # Test with a config file that does exist and a config that does not exist
    config_manager = ConfigManager(config_file=os.path.join(os.path.dirname(__file__), 'test.cfg'))
    config_manager.get_config_value_and_origin('config_file_does_not_exist')

# Generated at 2022-06-16 20:37:06.459999
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.get_plugin_vars('lookup', 'file')


# Generated at 2022-06-16 20:37:14.461713
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with a config file
    config_file = 'test/ansible.cfg'
    config_manager = ConfigManager(config_file)
    value, origin = config_manager.get_config_value_and_origin('log_path', configfile=config_file)
    assert value == '/tmp/ansible.log'
    assert origin == config_file

    # Test with a config file and a direct setting
    direct = {'log_path': '/tmp/ansible2.log'}
    value, origin = config_manager.get_config_value_and_origin('log_path', configfile=config_file, direct=direct)
    assert value == '/tmp/ansible2.log'
    assert origin == 'Direct'

    # Test with a config file and a direct setting and a variable

# Generated at 2022-06-16 20:37:26.651368
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('True', 'bool') is True
    assert ensure_type('False', 'bool') is False
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1.1', 'float') == 1.1
    assert ensure_type('1,2,3', 'list') == ['1', '2', '3']
    assert ensure_type('None', 'none') is None
    assert ensure_type('/tmp', 'path') == '/tmp'
    assert ensure_type('/tmp', 'tmppath').startswith('/tmp/ansible-local-')
    assert ensure_type('/tmp', 'pathspec') == ['/tmp']
    assert ensure_type('/tmp', 'pathlist') == ['/tmp']
    assert ensure_type('/tmp', 'string') == '/tmp'

# Generated at 2022-06-16 20:40:09.393792
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    assert find_ini_config_file() is None

    # Test with environment variable set
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set to a directory
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set to a non-existent file
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg.not_exist"

# Generated at 2022-06-16 20:40:17.784513
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'type': 'string', 'default': 'test_default_value', 'env': [{'name': 'TEST_ENV_VAR'}]}})
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default_value', 'default')
    os.environ['TEST_ENV_VAR'] = 'test_env_value'

# Generated at 2022-06-16 20:40:25.757512
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz/') == '/tmp/bar/baz/foo'



# Generated at 2022-06-16 20:40:32.507734
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar/baz') == '/tmp/{{CWD}}/foo'

# Generated at 2022-06-16 20:40:38.574192
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set
    os.environ["ANSIBLE_CONFIG"] = "/tmp/ansible.cfg"
    assert find_ini_config_file() == "/tmp/ansible.cfg"

    # Test with environment variable set to a directory
    os.environ["ANSIBLE_CONFIG"] = "/tmp"
    assert find_ini_config_file() == "/tmp/ansible.cfg"

    # Test with environment variable set to a directory that doesn't exist
    os.environ["ANSIBLE_CONFIG"] = "/tmp/doesnotexist"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set to a directory

# Generated at 2022-06-16 20:40:47.347111
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1', 'float') == 1.0
    assert ensure_type('1', 'boolean') is True
    assert ensure_type('1', 'bool') is True
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type('1', 'none') is None
    assert ensure_type('1', 'path') == '1'
    assert ensure_type('1', 'pathspec') == ['1']
    assert ensure_type('1', 'pathlist') == ['1']
    assert ensure_type('1', 'str') == '1'
    assert ensure_type('1', 'string') == '1'

# Generated at 2022-06-16 20:40:52.435697
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    assert config.get_configuration_definitions('test', 'test') == {'test': {'default': 'test', 'type': 'string'}}


# Generated at 2022-06-16 20:40:59.793707
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with a config file that does not exist
    config_manager = ConfigManager(config_file='/tmp/does_not_exist')
    config_manager.get_config_value_and_origin('DEFAULT_MODULE_LANG')
    # Test with a config file that exists
    config_manager = ConfigManager(config_file='/etc/ansible/ansible.cfg')
    config_manager.get_config_value_and_origin('DEFAULT_MODULE_LANG')


# Generated at 2022-06-16 20:41:01.016825
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # FIXME: write unit test
    pass


# Generated at 2022-06-16 20:41:04.452539
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('connection', 'local', {'foo': {'default': 'bar'}})
    assert config.get_plugin_options('connection', 'local') == {'foo': 'bar'}


# Generated at 2022-06-16 20:43:10.667990
# Unit test for method update_config_data of class ConfigManager

# Generated at 2022-06-16 20:43:19.310043
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()