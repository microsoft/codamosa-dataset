

# Generated at 2022-06-16 20:41:35.966051
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find a config file in the current working directory
    # even if it's world writable
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chmod(tmpdir, 0o777)
        with open(os.path.join(tmpdir, "ansible.cfg"), "w") as f:
            f.write("[defaults]\n")
        os.chdir(tmpdir)
        assert find_ini_config_file() == os.path.join(tmpdir, "ansible.cfg")

    # Test that we can find a config file in the current working directory
    # even if it's world writable
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chmod(tmpdir, 0o777)

# Generated at 2022-06-16 20:41:36.717134
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # FIXME: implement
    pass

# Generated at 2022-06-16 20:41:42.726429
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/file.yaml') == 'yaml'
    assert get_config_type('/path/to/file.yml') == 'yaml'
    assert get_config_type('/path/to/file.ini') == 'ini'
    assert get_config_type('/path/to/file.cfg') == 'ini'
    assert get_config_type('/path/to/file.txt') == None



# Generated at 2022-06-16 20:41:49.055110
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = 'some_plugin_type'
    name = 'some_name'
    defs = {'some_key': {'type': 'string', 'default': 'some_value'}}
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config_manager._plugins[plugin_type][name] == defs


# Generated at 2022-06-16 20:41:54.030595
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'

# Generated at 2022-06-16 20:42:04.438698
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1.0', 'float') == 1.0
    assert ensure_type('1.0', 'float') == 1.0
    assert ensure_type('1,2,3', 'list') == ['1', '2', '3']
    assert ensure_type('1,2,3', 'list') == ['1', '2', '3']
    assert ensure_type('None', 'none') is None
    assert ensure_type('None', 'none') is None
    assert ensure_type('/tmp/foo', 'path') == '/tmp/foo'
    assert ensure_type('/tmp/foo', 'path') == '/tmp/foo'

# Generated at 2022-06-16 20:42:10.126896
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config_name': {'default': 'test_default_value', 'type': 'string'}})
    config_manager.update_config_data(defs={'test_config_name': {'default': 'test_default_value', 'type': 'string'}}, configfile='test_config_file')
    assert config_manager.get_config_value_and_origin('test_config_name', cfile='test_config_file', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default_value', 'default')


# Generated at 2022-06-16 20:42:11.332537
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()


# Generated at 2022-06-16 20:42:17.245794
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    assert config.get_configuration_definitions('test') == {'test': {'default': 'test', 'type': 'string'}}
    assert config.get_configuration_definitions('test', 'test') == {'test': {'default': 'test', 'type': 'string'}}
    assert config.get_configuration_definitions('test', 'test', ignore_private=True) == {}


# Generated at 2022-06-16 20:42:21.431703
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/tmp/test.ini') == 'ini'
    assert get_config_type('/tmp/test.cfg') == 'ini'
    assert get_config_type('/tmp/test.yaml') == 'yaml'
    assert get_config_type('/tmp/test.yml') == 'yaml'
    try:
        get_config_type('/tmp/test.txt')
        assert False
    except AnsibleOptionsError:
        assert True

