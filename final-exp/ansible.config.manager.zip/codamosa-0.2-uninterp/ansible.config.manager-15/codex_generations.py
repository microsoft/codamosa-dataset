

# Generated at 2022-06-16 20:39:12.195129
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test'}})
    assert config.get_config_value_and_origin('test', plugin_type='test', plugin_name='test') == ('test', 'default')


# Generated at 2022-06-16 20:39:20.508947
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('{{CWD}}/test') == os.path.join(os.getcwd(), 'test')
    assert resolve_path('{{CWD}}/test', basedir='/tmp') == os.path.join(os.getcwd(), 'test')
    assert resolve_path('{{CWD}}/test', basedir='/tmp/') == os.path.join(os.getcwd(), 'test')
    assert resolve_path('{{CWD}}/test', basedir='/tmp/test') == os.path.join(os.getcwd(), 'test')
    assert resolve_path('{{CWD}}/test', basedir='/tmp/test/') == os.path.join(os.getcwd(), 'test')

# Generated at 2022-06-16 20:39:26.490622
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('connection', 'local', {'foo': {'vars': [{'name': 'ANSIBLE_FOO'}]}})
    assert config.get_plugin_vars('connection', 'local') == ['ANSIBLE_FOO']


# Generated at 2022-06-16 20:39:31.269512
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/etc/ansible/ansible.cfg') == 'ini'
    assert get_config_type('/etc/ansible/ansible.yaml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.yml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.json') == None



# Generated at 2022-06-16 20:39:40.234112
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find the config file in the current directory
    # when ANSIBLE_CONFIG is not set
    os.environ.pop('ANSIBLE_CONFIG', None)
    assert find_ini_config_file() == os.path.join(os.getcwd(), 'ansible.cfg')

    # Test that we can find the config file in the current directory
    # when ANSIBLE_CONFIG is set to a directory
    os.environ['ANSIBLE_CONFIG'] = os.getcwd()
    assert find_ini_config_file() == os.path.join(os.getcwd(), 'ansible.cfg')

    # Test that we can find the config file in the current directory
    # when ANSIBLE_CONFIG is set to a file
    os.environ['ANSIBLE_CONFIG'] = os

# Generated at 2022-06-16 20:39:44.599111
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'type': 'string', 'default': 'test_default', 'env': [{'name': 'TEST_ENV'}], 'ini': [{'section': 'test_section', 'key': 'test_key'}]}})
    config_manager._parsers['test_config_file'] = {'test_section': {'test_key': 'test_value'}}
    config_manager._config_file = 'test_config_file'
    assert config_manager.get_config_value_and_origin('test_config', 'test_config_file') == ('test_value', 'test_config_file')
    assert config_

# Generated at 2022-06-16 20:39:55.578839
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set
    os.environ["ANSIBLE_CONFIG"] = "/tmp/ansible.cfg"
    assert find_ini_config_file() == "/tmp/ansible.cfg"
    del os.environ["ANSIBLE_CONFIG"]

    # Test with environment variable set to a directory
    os.environ["ANSIBLE_CONFIG"] = "/tmp"
    assert find_ini_config_file() == "/tmp/ansible.cfg"
    del os.environ["ANSIBLE_CONFIG"]

    # Test with environment variable set to a directory that doesn't exist
    os.environ["ANSIBLE_CONFIG"] = "/tmp/doesnotexist"
    assert find_ini

# Generated at 2022-06-16 20:40:03.693711
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar/baz') == '/tmp/{{CWD}}/foo'



# Generated at 2022-06-16 20:40:11.256608
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar') == '/tmp/{{CWD}}/bar/foo'

# Generated at 2022-06-16 20:40:16.836746
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    config = ConfigManager()
    config.parse()
    config.get_config_value('DEFAULT_MODULE_LANG')
    config.get_config_value('DEFAULT_MODULE_LANG', direct={'DEFAULT_MODULE_LANG': 'python'})
    config.get_config_value('DEFAULT_MODULE_LANG', direct={'DEFAULT_MODULE_LANG': 'python'}, cfile='/etc/ansible/ansible.cfg')
    config.get_config_value('DEFAULT_MODULE_LANG', direct={'DEFAULT_MODULE_LANG': 'python'}, cfile='/etc/ansible/ansible.cfg', plugin_type='strategy')