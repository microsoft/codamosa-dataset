

# Generated at 2022-06-16 20:39:40.299095
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no ANSIBLE_CONFIG set
    assert find_ini_config_file() == unfrackpath("~/.ansible.cfg", follow=False)

    # Test with ANSIBLE_CONFIG set
    os.environ["ANSIBLE_CONFIG"] = "~/ansible.cfg"
    assert find_ini_config_file() == unfrackpath("~/ansible.cfg", follow=False)

    # Test with ANSIBLE_CONFIG set to a directory
    os.environ["ANSIBLE_CONFIG"] = "~/ansible.cfg.d"
    assert find_ini_config_file() == unfrackpath("~/ansible.cfg.d/ansible.cfg", follow=False)

    # Test with ANSIBLE_CONFIG set to a directory that doesn't exist

# Generated at 2022-06-16 20:39:44.636482
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/etc/ansible/ansible.cfg') == 'ini'
    assert get_config_type('/etc/ansible/ansible.yml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.yaml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.txt') is None



# Generated at 2022-06-16 20:39:47.869507
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')


# Generated at 2022-06-16 20:39:50.309731
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # TODO: implement test
    pass


# Generated at 2022-06-16 20:39:56.672685
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('test.yaml') == 'yaml'
    assert get_config_type('test.yml') == 'yaml'
    assert get_config_type('test.ini') == 'ini'
    assert get_config_type('test.cfg') == 'ini'
    try:
        get_config_type('test.txt')
    except AnsibleOptionsError as e:
        assert 'Unsupported configuration file extension for test.txt' in to_native(e)
    else:
        assert False, "AnsibleOptionsError not raised"



# Generated at 2022-06-16 20:39:59.566883
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # config_manager = ConfigManager()
    # defs = None
    # configfile = None
    # config_manager.update_config_data(defs, configfile)
    pass


# Generated at 2022-06-16 20:40:05.701963
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('True', 'bool') is True
    assert ensure_type('False', 'bool') is False
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1.1', 'float') == 1.1
    assert ensure_type('1,2,3', 'list') == ['1', '2', '3']
    assert ensure_type('None', 'none') is None
    assert ensure_type('/tmp', 'path') == '/tmp'
    assert ensure_type('/tmp', 'tmppath').startswith('/tmp/ansible-local-')
    assert ensure_type('/tmp', 'pathspec') == ['/tmp']
    assert ensure_type('/tmp', 'pathlist') == ['/tmp']

# Generated at 2022-06-16 20:40:12.517017
# Unit test for function find_ini_config_file

# Generated at 2022-06-16 20:40:22.531870
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar/baz') == '/tmp/{{CWD}}/foo'

# Generated at 2022-06-16 20:40:26.250697
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    assert config.get_configuration_definitions('test', 'test') == {'test': {'default': 'test', 'type': 'string'}}
