

# Generated at 2022-06-16 20:38:46.751627
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'

    # Test with environment variable set
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'
    del os.environ["ANSIBLE_CONFIG"]

    # Test with environment variable set to a directory
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible"
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'
    del os.environ["ANSIBLE_CONFIG"]

    # Test with environment variable set to a directory that doesn't exist

# Generated at 2022-06-16 20:38:54.207995
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('1', 'float') == 1.0
    assert ensure_type('1', 'boolean') is True
    assert ensure_type('1', 'bool') is True
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type('1', 'none') is None
    assert ensure_type('1', 'path') == '1'
    assert ensure_type('1', 'tmppath') == '1'
    assert ensure_type('1', 'temppath') == '1'
    assert ensure_type('1', 'tmp') == '1'
    assert ensure_type('1', 'pathlist') == ['1']

# Generated at 2022-06-16 20:38:58.673687
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find the config file in the current directory
    cwd = os.getcwd()
    os.chdir(os.path.join(os.path.dirname(__file__), 'test_config_data'))
    assert find_ini_config_file() == 'ansible.cfg'
    os.chdir(cwd)

    # Test that we can find the config file in the user's home directory
    assert find_ini_config_file() == unfrackpath('~/.ansible.cfg', follow=False)

    # Test that we can find the config file in the system directory
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'

    # Test that we can find the config file when set in the environment

# Generated at 2022-06-16 20:39:02.831702
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string', 'env': [{'name': 'TEST_ENV_VAR'}]}})
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')
    os.environ['TEST_ENV_VAR'] = 'test_env_var'

# Generated at 2022-06-16 20:39:10.149673
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config_key': {'default': 'test_default_value'}})
    assert config.get_configuration_definitions('test_plugin_type', 'test_plugin_name') == {'test_config_key': {'default': 'test_default_value'}}


# Generated at 2022-06-16 20:39:20.047955
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we find the config file in the expected order
    # We'll use a temp directory to simulate the various locations
    # and then set ANSIBLE_CONFIG to override the order
    # We'll also use a temp file to simulate the config file
    # so that we can ensure that we don't read it if it's not readable
    # or if it's a directory

    import tempfile
    import shutil
    import os

    # Create a temp directory to use as a cwd
    cwd = tempfile.mkdtemp()
    # Create a temp directory to use as a config dir
    config_dir = tempfile.mkdtemp()
    # Create a temp file to use as a config file
    config_file = tempfile.NamedTemporaryFile(dir=config_dir, delete=False)
    config_file.close()

   

# Generated at 2022-06-16 20:39:31.201952
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/{{CWD}}/bar') == '/tmp/{{CWD}}/foo'

# Generated at 2022-06-16 20:39:32.360423
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.get_config_value_and_origin('config')


# Generated at 2022-06-16 20:39:36.511723
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    c = ConfigManager()
    c.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    value, origin = c.get_config_value_and_origin('test', plugin_type='test', plugin_name='test')
    assert value == 'test'
    assert origin == 'default'


# Generated at 2022-06-16 20:39:39.196510
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # Setup
    config_manager = ConfigManager()
    plugin_type = 'test_plugin_type'
    name = 'test_name'
    ignore_private = False

    # Exercise
    config_manager.get_configuration_definitions(plugin_type, name, ignore_private)

    # Verify
    assert True


# Generated at 2022-06-16 20:41:52.154628
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we don't find a config file in a world writable directory
    # We'll create a temp directory and make it world writable
    import tempfile
    import shutil
    import stat
    import os
    import os.path
    import sys

    # Create a temp directory and make it world writable
    temp_dir = tempfile.mkdtemp()
    os.chmod(temp_dir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)
    # Create a config file in the temp directory
    temp_cfg = os.path.join(temp_dir, "ansible.cfg")
    with open(temp_cfg, "w") as f:
        f.write("[defaults]\n")

# Generated at 2022-06-16 20:41:53.433410
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # TODO: implement test
    pass


# Generated at 2022-06-16 20:42:04.365060
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test'}})
    assert config_manager.get_config_value_and_origin('test') == ('test', 'default')
    assert config_manager.get_config_value_and_origin('test', direct={'test': 'test2'}) == ('test2', 'Direct')
    assert config_manager.get_config_value_and_origin('test', variables={'test': 'test3'}) == ('test3', 'var: test')
    assert config_manager.get_config_value_and_origin('test', keys={'test': 'test4'}) == ('test4', 'keyword: test')
    assert config_manager.get_config_value_and

# Generated at 2022-06-16 20:42:09.942930
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('lookup', 'file', {'_file_path': {'type': 'path', 'vars': [{'name': 'file_path'}]}})
    assert config.get_plugin_vars('lookup', 'file') == ['file_path']


# Generated at 2022-06-16 20:42:11.975295
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-16 20:42:13.209239
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # TODO: implement unit test
    pass


# Generated at 2022-06-16 20:42:19.146566
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    assert config._plugins['test']['test']['test']['default'] == 'test'
    assert config._plugins['test']['test']['test']['type'] == 'string'

# Generated at 2022-06-16 20:42:23.247524
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/config.yaml') == 'yaml'
    assert get_config_type('/path/to/config.yml') == 'yaml'
    assert get_config_type('/path/to/config.ini') == 'ini'
    assert get_config_type('/path/to/config.cfg') == 'ini'
    assert get_config_type('/path/to/config.txt') == None



# Generated at 2022-06-16 20:42:26.402540
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()

# Generated at 2022-06-16 20:42:32.882269
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')
