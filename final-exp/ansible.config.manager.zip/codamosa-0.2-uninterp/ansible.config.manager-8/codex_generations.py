

# Generated at 2022-06-16 20:41:18.335666
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name2', {'test_config2': {'default': 'test_default2', 'type': 'string'}})
    assert config_manager.get_configuration_definitions('test_plugin_type', 'test_plugin_name') == {'test_config': {'default': 'test_default', 'type': 'string'}}

# Generated at 2022-06-16 20:41:19.424736
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    assert config_manager.get_configuration_definitions() == {}


# Generated at 2022-06-16 20:41:24.698575
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Setup
    config_manager = ConfigManager()

# Generated at 2022-06-16 20:41:30.192253
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with a config file that does not exist
    config_manager = ConfigManager()
    config_manager._config_file = '/tmp/does_not_exist'
    config_manager._base_defs = {
        'ANSIBLE_CONFIG': {
            'default': '/etc/ansible/ansible.cfg',
            'env': [{'name': 'ANSIBLE_CONFIG'}],
            'ini': [{'key': 'config_file', 'section': 'defaults'}],
            'vars': [],
            'type': 'path',
        },
    }
    config_manager._parsers = {}
    config_manager.get_config_value_and_origin('ANSIBLE_CONFIG')

# Generated at 2022-06-16 20:41:33.153001
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = 'test_plugin_type'
    name = 'test_name'
    defs = {'test_config': {'default': 'test_default', 'type': 'string'}}
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config_manager._plugins[plugin_type][name] == defs


# Generated at 2022-06-16 20:41:41.957988
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz/') == '/tmp/bar/baz/foo'

# Generated at 2022-06-16 20:41:46.857701
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    assert config_manager.get_configuration_definitions() == config_manager._base_defs
    assert config_manager.get_configuration_definitions('foo') == {}
    assert config_manager.get_configuration_definitions('foo', 'bar') == {}
    assert config_manager.get_configuration_definitions('foo', 'bar', ignore_private=True) == {}
    assert config_manager.get_configuration_definitions('foo', ignore_private=True) == {}
    assert config_manager.get_configuration_definitions(ignore_private=True) == config_manager._base_defs


# Generated at 2022-06-16 20:41:53.742956
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    assert config.get_configuration_definitions('test') == {'test': {'default': 'test', 'type': 'string'}}
    assert config.get_configuration_definitions('test', 'test') == {'test': {'default': 'test', 'type': 'string'}}
    assert config.get_configuration_definitions('test', 'test', ignore_private=True) == {}


# Generated at 2022-06-16 20:42:04.438568
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with no arguments
    config = ConfigManager()
    assert config.get_config_value_and_origin() == (None, None)

    # Test with invalid arguments
    assert config.get_config_value_and_origin(config=None) == (None, None)
    assert config.get_config_value_and_origin(config=1) == (None, None)
    assert config.get_config_value_and_origin(config=1.0) == (None, None)
    assert config.get_config_value_and_origin(config=True) == (None, None)
    assert config.get_config_value_and_origin(config=False) == (None, None)
    assert config.get_config_value_and_origin(config=[]) == (None, None)
    assert config.get_

# Generated at 2022-06-16 20:42:14.689015
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find a config file in the current working directory
    # This is the only test that will fail if you run it from the root of the source tree
    # We don't want to create a file in the source tree, so we'll create one in a temp dir
    # and then change to that dir.
    import shutil
    import tempfile
    import os
    import stat

    # Create a temp dir
    tmpdir = tempfile.mkdtemp()
    # Create a file in that dir
    tmpfile = os.path.join(tmpdir, "ansible.cfg")
    with open(tmpfile, "w") as f:
        f.write("[defaults]\n")
    # Make the dir world writable
    os.chmod(tmpdir, stat.S_IWOTH)

    # Change to the temp