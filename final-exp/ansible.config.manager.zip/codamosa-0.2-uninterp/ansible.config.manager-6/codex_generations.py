

# Generated at 2022-06-16 20:41:24.057608
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/file.ini') == 'ini'
    assert get_config_type('/path/to/file.cfg') == 'ini'
    assert get_config_type('/path/to/file.yaml') == 'yaml'
    assert get_config_type('/path/to/file.yml') == 'yaml'
    try:
        get_config_type('/path/to/file.txt')
    except AnsibleOptionsError:
        pass
    else:
        assert False, 'AnsibleOptionsError not raised'



# Generated at 2022-06-16 20:41:26.829139
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    plugin_type = 'test_plugin_type'
    name = 'test_name'
    defs = {'test_defs': 'test_defs'}
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config._plugins[plugin_type][name] == defs


# Generated at 2022-06-16 20:41:29.621321
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    plugin_type = 'test_plugin_type'
    name = 'test_name'
    defs = {'test_key': {'default': 'test_value'}}
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config._plugins[plugin_type][name] == defs

# Generated at 2022-06-16 20:41:34.698085
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/etc/ansible/ansible.cfg') == 'ini'
    assert get_config_type('/etc/ansible/ansible.yaml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.yml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.txt') == None
    assert get_config_type('/etc/ansible/ansible.json') == None



# Generated at 2022-06-16 20:41:40.142362
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()

# Generated at 2022-06-16 20:41:43.945403
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # TODO: implement test
    pass


# Generated at 2022-06-16 20:41:53.349483
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('lookup', 'file', {'_file_path': {'default': '', 'type': 'path', 'vars': [{'name': 'ANSIBLE_LOOKUP_FILE_PATH'}]}})
    config.initialize_plugin_configuration_definitions('lookup', 'file', {'_file_path': {'default': '', 'type': 'path', 'vars': [{'name': 'ANSIBLE_LOOKUP_FILE_PATH'}]}})

# Generated at 2022-06-16 20:42:04.288414
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz/') == '/tmp/bar/baz/foo'

# Generated at 2022-06-16 20:42:14.656338
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set to a directory
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"

    # Test with environment variable set to a non-existent file
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg.not_exist"

# Generated at 2022-06-16 20:42:21.374570
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'type': 'string', 'default': 'test_default'}})
    assert config.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')
    assert config.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name', direct={'test_config': 'test_direct'}) == ('test_direct', 'Direct')