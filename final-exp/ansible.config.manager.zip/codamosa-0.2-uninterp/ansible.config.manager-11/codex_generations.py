

# Generated at 2022-06-16 20:37:49.164193
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.readfp(io.BytesIO(b'''
[defaults]
key=value
'''))
    assert get_ini_config_value(p, {'section': 'defaults', 'key': 'key'}) == 'value'
    assert get_ini_config_value(p, {'section': 'defaults', 'key': 'key2'}) is None
    assert get_ini_config_value(p, {'section': 'defaults2', 'key': 'key'}) is None
    assert get_ini_config_value(p, {'key': 'key'}) == 'value'
    assert get_ini_config_value(p, {'key': 'key2'}) is None

# Generated at 2022-06-16 20:37:54.419891
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}') == '/tmp/{{CWD}}'
    assert resolve_path('/tmp/{{CWD}}', basedir='/tmp') == '/tmp/{{CWD}}'
    assert resolve_path('/tmp/{{CWD}}', basedir='/tmp/') == '/tmp/{{CWD}}'
    assert resolve_path('/tmp/{{CWD}}', basedir='/tmp/{{CWD}}') == '/tmp/{{CWD}}'
    assert resolve_path('/tmp/{{CWD}}', basedir='/tmp/{{CWD}}/') == '/tmp/{{CWD}}'
    assert resolve_path('/tmp/{{CWD}}', basedir='/tmp/{{CWD}}/test') == '/tmp/{{CWD}}'

# Generated at 2022-06-16 20:38:01.102650
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/file.ini') == 'ini'
    assert get_config_type('/path/to/file.cfg') == 'ini'
    assert get_config_type('/path/to/file.yaml') == 'yaml'
    assert get_config_type('/path/to/file.yml') == 'yaml'
    try:
        get_config_type('/path/to/file.txt')
    except AnsibleOptionsError:
        pass
    else:
        assert False, "Should have thrown an AnsibleOptionsError"



# Generated at 2022-06-16 20:38:06.037202
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    path = find_ini_config_file()
    assert path is not None
    assert os.path.exists(path)

    # Test with environment variable set
    path = find_ini_config_file()
    assert path is not None
    assert os.path.exists(path)



# Generated at 2022-06-16 20:38:11.028060
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find an ansible.cfg in the current working directory
    # even if it is world writable
    with tempfile.TemporaryDirectory() as tmpdir:
        cwd = os.getcwd()
        os.chdir(tmpdir)
        with open('ansible.cfg', 'w') as f:
            f.write('[defaults]\n')
            f.write('inventory = /etc/ansible/hosts\n')
        os.chmod(tmpdir, 0o777)
        warnings = set()
        assert find_ini_config_file(warnings) == os.path.join(tmpdir, 'ansible.cfg')
        assert len(warnings) == 1
        assert warnings.pop() == u"Ansible is being run in a world writable directory (%s)," \
                                

# Generated at 2022-06-16 20:38:18.573449
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find the config file in the current working directory
    # when ANSIBLE_CONFIG is not set
    assert find_ini_config_file() == os.path.join(os.getcwd(), "ansible.cfg")

    # Test that we can find the config file in the current working directory
    # when ANSIBLE_CONFIG is set
    os.environ["ANSIBLE_CONFIG"] = os.path.join(os.getcwd(), "ansible.cfg")
    assert find_ini_config_file() == os.path.join(os.getcwd(), "ansible.cfg")

    # Test that we can find the config file in the user's home directory
    # when ANSIBLE_CONFIG is not set
    os.environ.pop("ANSIBLE_CONFIG")
    assert find_ini

# Generated at 2022-06-16 20:38:24.425833
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1', 'float') == 1.0
    assert ensure_type('1', 'bool') is True
    assert ensure_type('1', 'boolean') is True
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type('1', 'none') is None
    assert ensure_type('1', 'path') == '1'
    assert ensure_type('1', 'pathspec') == ['1']
    assert ensure_type('1', 'pathlist') == ['1']
    assert ensure_type('1', 'str') == '1'
    assert ensure_type('1', 'string') == '1'
    assert ensure_type('1', 'dict') == '1'
    assert ensure_type('1', 'dictionary')

# Generated at 2022-06-16 20:38:27.942875
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/tmp/test.yml') == 'yaml'
    assert get_config_type('/tmp/test.yaml') == 'yaml'
    assert get_config_type('/tmp/test.ini') == 'ini'
    assert get_config_type('/tmp/test.cfg') == 'ini'
    try:
        get_config_type('/tmp/test.txt')
    except AnsibleOptionsError:
        pass
    else:
        assert False, "AnsibleOptionsError not raised"



# Generated at 2022-06-16 20:38:31.751219
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/etc/ansible/ansible.cfg') == 'ini'
    assert get_config_type('/etc/ansible/ansible.yml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.yaml') == 'yaml'
    assert get_config_type('/etc/ansible/ansible.txt') == None
    assert get_config_type('/etc/ansible/ansible.json') == None
    assert get_config_type('/etc/ansible/ansible.conf') == None



# Generated at 2022-06-16 20:38:43.084740
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with ANSIBLE_CONFIG set
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"
    del os.environ["ANSIBLE_CONFIG"]

    # Test with ansible.cfg in cwd
    cwd = os.getcwd()
    os.chdir(os.path.dirname(__file__))
    assert find_ini_config_file() == os.path.join(os.getcwd(), "ansible.cfg")
    os.chdir(cwd)

    # Test with ansible.cfg in home directory
    assert find_ini_config_file() == unfrackpath("~/.ansible.cfg", follow=False)

    # Test with ans

# Generated at 2022-06-16 20:40:29.892827
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()


# Generated at 2022-06-16 20:40:36.019317
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('/tmp/foo', 'path') == '/tmp/foo'
    assert ensure_type('/tmp/foo', 'pathspec') == ['/tmp/foo']
    assert ensure_type('/tmp/foo,/tmp/bar', 'pathspec') == ['/tmp/foo', '/tmp/bar']
    assert ensure_type('/tmp/foo', 'pathlist') == ['/tmp/foo']
    assert ensure_type('/tmp/foo,/tmp/bar', 'pathlist') == ['/tmp/foo', '/tmp/bar']
    assert ensure_type('/tmp/foo', 'tmppath') == '/tmp/foo'
    assert ensure_type('/tmp/foo', 'tmp') == '/tmp/foo'
    assert ensure_type('/tmp/foo', 'temppath') == '/tmp/foo'

# Generated at 2022-06-16 20:40:44.473829
# Unit test for method get_config_value_and_origin of class ConfigManager

# Generated at 2022-06-16 20:40:47.243115
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.get_config_value_and_origin('foo', 'bar', 'baz', 'qux')


# Generated at 2022-06-16 20:40:48.759241
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_manager = ConfigManager()
    config_manager.update_config_data()


# Generated at 2022-06-16 20:40:55.980238
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1', 'float') == 1.0
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type('1', 'none') == None
    assert ensure_type('1', 'path') == '1'
    assert ensure_type('1', 'pathspec') == ['1']
    assert ensure_type('1', 'pathlist') == ['1']
    assert ensure_type('1', 'str') == '1'
    assert ensure_type('1', 'string') == '1'
    assert ensure_type('1', 'boolean') == True
    assert ensure_type('1', 'bool') == True

# Generated at 2022-06-16 20:40:57.508162
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.get_config_value_and_origin()


# Generated at 2022-06-16 20:41:06.719699
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with no environment variable set
    os.environ.pop('ANSIBLE_CONFIG', None)
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'

    # Test with environment variable set
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'

    # Test with environment variable set to a directory
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible'
    assert find_ini_config_file() == '/etc/ansible/ansible.cfg'

    # Test with environment variable set to a directory that does not exist
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible_does_not_exist'

# Generated at 2022-06-16 20:41:13.020301
# Unit test for function find_ini_config_file

# Generated at 2022-06-16 20:41:14.898145
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    # Test with a valid config name
    config_manager = ConfigManager()
    config_manager.get_config_value('DEFAULT_MODULE_NAME')
