

# Generated at 2022-06-16 20:41:56.377584
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager._base_defs = {'ANSIBLE_CONFIG': {'default': 'ansible.cfg', 'type': 'path'}}
    config_manager._config_file = 'ansible.cfg'
    config_manager._parsers = {'ansible.cfg': {'defaults': {'ANSIBLE_CONFIG': 'ansible.cfg'}}}
    config_manager.data = DataLoader()
    config_manager.data.update_setting(Setting('ANSIBLE_CONFIG', 'ansible.cfg', '', 'string'))
    config_manager.data.update_setting(Setting('ANSIBLE_CONFIG', 'ansible.cfg', '', 'string'))

# Generated at 2022-06-16 20:42:05.932558
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()

# Generated at 2022-06-16 20:42:15.904904
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz/') == '/tmp/bar/baz/foo'

# Generated at 2022-06-16 20:42:20.663393
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/file.ini') == 'ini'
    assert get_config_type('/path/to/file.cfg') == 'ini'
    assert get_config_type('/path/to/file.yaml') == 'yaml'
    assert get_config_type('/path/to/file.yml') == 'yaml'
    try:
        get_config_type('/path/to/file.txt')
        assert False, "Should have raised an exception"
    except AnsibleOptionsError:
        pass



# Generated at 2022-06-16 20:42:26.252036
# Unit test for method get_config_value_and_origin of class ConfigManager

# Generated at 2022-06-16 20:42:37.736509
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    assert config.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')
    assert config.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name', direct={'test_config': 'test_direct'}) == ('test_direct', 'Direct')

# Generated at 2022-06-16 20:42:43.514670
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    plugin_type = 'test_plugin_type'
    name = 'test_name'
    defs = {'test_def': {'default': 'test_default', 'type': 'string'}}
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config._plugins[plugin_type][name] == defs


# Generated at 2022-06-16 20:42:53.767197
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test'}})
    assert config.get_config_value_and_origin('test', plugin_type='test', plugin_name='test') == ('test', 'default')
    assert config.get_config_value_and_origin('test', plugin_type='test', plugin_name='test', direct={'test': 'test2'}) == ('test2', 'Direct')
    assert config.get_config_value_and_origin('test', plugin_type='test', plugin_name='test', variables={'test': 'test3'}) == ('test3', 'var: test')

# Generated at 2022-06-16 20:42:56.689779
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name')


# Generated at 2022-06-16 20:43:03.067711
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find the config file in the current working directory
    cwd = os.getcwd()
    os.chdir(os.path.dirname(__file__))
    assert find_ini_config_file() == os.path.join(os.path.dirname(__file__), "ansible.cfg")
    os.chdir(cwd)

