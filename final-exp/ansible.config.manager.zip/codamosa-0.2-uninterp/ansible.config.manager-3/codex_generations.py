

# Generated at 2022-06-16 20:37:13.062819
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()
    assert config_manager.get_configuration_definition('DEFAULT_HOST_LIST') == {'default': '/etc/ansible/hosts', 'type': 'path', 'ini': [{'key': 'hostfile', 'section': 'defaults'}], 'env': [{'name': 'ANSIBLE_HOSTS'}], 'vars': [{'name': 'ansible_hosts'}], 'cli': [{'name': 'inventory'}], 'description': 'inventory file, or comma separated host list. --inventory-file is deprecated\n'}

# Generated at 2022-06-16 20:37:14.393871
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()

# Generated at 2022-06-16 20:37:26.506503
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1.1', 'float') == 1.1
    assert ensure_type('1.1', 'int') == 1
    assert ensure_type('1.1', 'string') == '1.1'
    assert ensure_type('1.1', 'path') == '1.1'
    assert ensure_type('1.1', 'list') == ['1.1']
    assert ensure_type('1.1', 'pathlist') == ['1.1']
    assert ensure_type('1.1', 'pathspec') == ['1.1']
    assert ensure_type('1.1', 'boolean') == True
    assert ensure_type('1.1', 'bool') == True

# Generated at 2022-06-16 20:37:35.475866
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/foo') == '/tmp/foo'
    assert resolve_path('/tmp/foo', basedir='/tmp') == '/tmp/foo'
    assert resolve_path('/tmp/foo', basedir='/tmp/bar') == '/tmp/foo'
    assert resolve_path('/tmp/foo', basedir='/tmp/bar/baz') == '/tmp/foo'
    assert resolve_path('/tmp/foo', basedir='/tmp/bar/baz/') == '/tmp/foo'
    assert resolve_path('/tmp/foo', basedir='/tmp/bar/baz/') == '/tmp/foo'
    assert resolve_path('/tmp/foo', basedir='/tmp/bar/baz/') == '/tmp/foo'

# Generated at 2022-06-16 20:37:39.672023
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find the config file in the current directory
    old_cwd = os.getcwd()
    try:
        os.chdir(os.path.dirname(__file__))
        assert find_ini_config_file() == os.path.join(os.path.dirname(__file__), "ansible.cfg")
    finally:
        os.chdir(old_cwd)
    # Test that we can find the config file in the home directory
    old_home = os.environ.get("HOME")

# Generated at 2022-06-16 20:37:44.001230
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    assert config.get_configuration_definitions('test_plugin_type', 'test_plugin_name') == {'test_config': {'default': 'test_default', 'type': 'string'}}
    assert config.get_configuration_definitions('test_plugin_type') == {'test_plugin_name': {'test_config': {'default': 'test_default', 'type': 'string'}}}
    assert config.get_configuration_definitions() == {'test_config': {'default': 'test_default', 'type': 'string'}}
    assert config.get_

# Generated at 2022-06-16 20:37:48.222834
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # Test with no arguments
    config_manager = ConfigManager()

# Generated at 2022-06-16 20:37:52.350756
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'type': 'string', 'default': 'test_default'}})
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name', direct={'test_config': 'test_direct'}) == ('test_direct', 'Direct')

# Generated at 2022-06-16 20:37:54.958570
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()

# Generated at 2022-06-16 20:38:03.334041
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1', 'float') == 1.0
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type('1', 'none') is None
    assert ensure_type('1', 'path') == '1'
    assert ensure_type('1', 'tmppath') == '1'
    assert ensure_type('1', 'temppath') == '1'
    assert ensure_type('1', 'tmp') == '1'
    assert ensure_type('1', 'pathspec') == ['1']
    assert ensure_type('1', 'pathlist') == ['1']
    assert ensure_type('1', 'str') == '1'