

# Generated at 2022-06-16 20:40:25.580864
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that we can find the config file in the current directory
    # even if it's world writable
    try:
        # Create a temporary directory
        tmpdir = tempfile.mkdtemp()
        # Create a temporary file in the temporary directory
        tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
        # Make the temporary directory world writable
        os.chmod(tmpdir, 0o777)
        # Change to the temporary directory
        os.chdir(tmpdir)
        # Check that we can find the config file in the current directory
        assert find_ini_config_file() == tmpfile.name
    finally:
        # Clean up
        tmpfile.close()
        os.chdir(os.path.expanduser("~"))
        os.rmdir(tmpdir)



# Generated at 2022-06-16 20:40:31.854330
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz/') == '/tmp/bar/baz/foo'



# Generated at 2022-06-16 20:40:33.109367
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()


# Generated at 2022-06-16 20:40:39.614994
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with ANSIBLE_CONFIG set
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"
    del os.environ["ANSIBLE_CONFIG"]

    # Test with ansible.cfg in cwd
    cwd = os.getcwd()
    os.mkdir(os.path.join(cwd, "ansible.cfg"))
    assert find_ini_config_file() == os.path.join(cwd, "ansible.cfg")
    os.rmdir(os.path.join(cwd, "ansible.cfg"))

    # Test with ansible.cfg in home directory
    assert find_ini_config_file() == os.path.expanduser

# Generated at 2022-06-16 20:40:48.490368
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/{{CWD}}/foo') == '/tmp/{{CWD}}/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/') == '/tmp/bar/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz') == '/tmp/bar/baz/foo'
    assert resolve_path('/tmp/{{CWD}}/foo', basedir='/tmp/bar/baz/') == '/tmp/bar/baz/foo'

# Generated at 2022-06-16 20:40:55.819165
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1', 'float') == 1.0
    assert ensure_type('1', 'bool') is True
    assert ensure_type('1', 'boolean') is True
    assert ensure_type('1', 'list') == ['1']
    assert ensure_type('1', 'none') is None
    assert ensure_type('1', 'path') == '1'
    assert ensure_type('1', 'tmp') == '1'
    assert ensure_type('1', 'pathspec') == ['1']
    assert ensure_type('1', 'pathlist') == ['1']
    assert ensure_type('1', 'dict') == {'1': None}
    assert ensure_type('1', 'string') == '1'

# Generated at 2022-06-16 20:40:57.356655
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()


# Generated at 2022-06-16 20:41:06.688233
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.add_section('defaults')
    p.set('defaults', 'foo', 'bar')
    assert get_ini_config_value(p, {'key': 'foo'}) == 'bar'
    assert get_ini_config_value(p, {'key': 'foo', 'section': 'defaults'}) == 'bar'
    assert get_ini_config_value(p, {'key': 'foo', 'section': 'defaults'}) == 'bar'
    assert get_ini_config_value(p, {'key': 'foo', 'section': 'defaults'}) == 'bar'
    assert get_ini_config_value(p, {'key': 'foo', 'section': 'defaults'}) == 'bar'

# Generated at 2022-06-16 20:41:11.909147
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/file.ini') == 'ini'
    assert get_config_type('/path/to/file.cfg') == 'ini'
    assert get_config_type('/path/to/file.yaml') == 'yaml'
    assert get_config_type('/path/to/file.yml') == 'yaml'
    try:
        get_config_type('/path/to/file.txt')
    except AnsibleOptionsError as e:
        assert 'Unsupported configuration file extension for /path/to/file.txt: .txt' in to_native(e)
    else:
        assert False, 'AnsibleOptionsError not raised'



# Generated at 2022-06-16 20:41:18.360985
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    assert config.get_configuration_definitions('test') == {'test': {'default': 'test', 'type': 'string'}}
    assert config.get_configuration_definitions('test', 'test') == {'test': {'default': 'test', 'type': 'string'}}
    assert config.get_configuration_definitions('test', 'test', ignore_private=True) == {}
    assert config.get_configuration_definitions('test', 'test', ignore_private=False) == {'test': {'default': 'test', 'type': 'string'}}