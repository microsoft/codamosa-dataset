

# Generated at 2022-06-16 20:41:05.357491
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/foo') == '/tmp/foo'
    assert resolve_path('/tmp/foo/../bar') == '/tmp/bar'
    assert resolve_path('/tmp/foo/../bar/') == '/tmp/bar/'
    assert resolve_path('/tmp/foo/../bar/baz') == '/tmp/bar/baz'
    assert resolve_path('/tmp/foo/../bar/baz/') == '/tmp/bar/baz/'
    assert resolve_path('/tmp/foo/../bar/baz/../') == '/tmp/bar/'
    assert resolve_path('/tmp/foo/../bar/baz/../../') == '/tmp/'
    assert resolve_path('/tmp/foo/../bar/baz/../../../') == '/'
    assert resolve

# Generated at 2022-06-16 20:41:09.633733
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test', 'test', {'test': {'default': 'test', 'type': 'string'}})
    config_manager.get_config_value_and_origin('test', plugin_type='test', plugin_name='test')
    config_manager.get_config_value_and_origin('test', plugin_type='test', plugin_name='test', direct={'test': 'test'})
    config_manager.get_config_value_and_origin('test', plugin_type='test', plugin_name='test', direct={'test': 'test'}, variables={'test': 'test'})

# Generated at 2022-06-16 20:41:11.881433
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    plugin_type = 'test_plugin_type'
    name = 'test_name'
    defs = 'test_defs'
    config.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config._plugins[plugin_type][name] == defs


# Generated at 2022-06-16 20:41:18.283993
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1.1', 'float') == 1.1
    assert ensure_type('1.1', 'int') == 1
    assert ensure_type('1.1', 'string') == '1.1'
    assert ensure_type('1.1', 'path') == '1.1'
    assert ensure_type('1.1', 'pathspec') == '1.1'
    assert ensure_type('1.1', 'pathlist') == '1.1'
    assert ensure_type('1.1', 'tmppath') == '1.1'
    assert ensure_type('1.1', 'list') == '1.1'
    assert ensure_type('1.1', 'dict') == '1.1'

# Generated at 2022-06-16 20:41:19.374363
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    config_manager.get_configuration_definitions()

# Generated at 2022-06-16 20:41:27.618371
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test with ANSIBLE_CONFIG set
    os.environ["ANSIBLE_CONFIG"] = "/etc/ansible/ansible.cfg"
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"
    del os.environ["ANSIBLE_CONFIG"]

    # Test with ansible.cfg in cwd
    cwd = os.getcwd()
    os.chdir("/etc/ansible")
    assert find_ini_config_file() == "/etc/ansible/ansible.cfg"
    os.chdir(cwd)

    # Test with ansible.cfg in home dir
    assert find_ini_config_file() == unfrackpath("~/.ansible.cfg", follow=False)

    # Test with ansible.cfg in /etc/ansible

# Generated at 2022-06-16 20:41:32.896182
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager._base_defs = {'ANSIBLE_CONFIG': {'default': 'ansible.cfg', 'env': [{'name': 'ANSIBLE_CONFIG'}], 'ini': [{'key': 'config_file', 'section': 'defaults'}], 'vars': [{'name': 'ansible_config'}], 'type': 'path'}}
    config_manager._parsers = {'ansible.cfg': ConfigParser.ConfigParser()}
    config_manager._parsers['ansible.cfg'].add_section('defaults')
    config_manager._parsers['ansible.cfg'].set('defaults', 'config_file', 'ansible.cfg')
    config_manager._config_file = 'ansible.cfg'
    config_

# Generated at 2022-06-16 20:41:33.515071
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # FIXME: implement
    pass


# Generated at 2022-06-16 20:41:38.642389
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string', 'env': [{'name': 'TEST_ENV'}]}})
    assert config_manager.get_config_value_and_origin('test_config', plugin_type='test_plugin_type', plugin_name='test_plugin_name') == ('test_default', 'default')
    os.environ['TEST_ENV'] = 'test_env'

# Generated at 2022-06-16 20:41:45.991019
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})
    assert config.get_configuration_definition('test_config', 'test_plugin_type', 'test_plugin_name') == {'default': 'test_default', 'type': 'string'}
