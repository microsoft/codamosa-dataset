

# Generated at 2022-06-24 18:29:23.492539
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import json
    import os

    config_manager_test = ConfigManager()

    ######################################################################
    #
    # test_case_0:
    #
    ######################################################################
    # target method: get_config_value_and_origin
    #
    # Target test case:
   

# Generated at 2022-06-24 18:29:29.151020
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    """
    Test method get_config_value_and_origin of class ConfigManager
    """
    config_manager_0 = ConfigManager()
    config =  'ansible_python_interpreter'
    plugin_type =  None
    plugin_name =  'accelerate'
    keys =  None
    variables =  None
    direct =  None
    config_manager_0.get_config_value_and_origin(config, cfile=None, plugin_type=plugin_type, plugin_name=plugin_name, keys=keys, variables=variables, direct=direct)


# Generated at 2022-06-24 18:29:30.648541
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    path = find_ini_config_file()
    print(path)


# Generated at 2022-06-24 18:29:35.312769
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()
    assert config_manager.get_configuration_definitions() != {}

# Bring in some legacy configs from constants to see if we get the same results

# Generated at 2022-06-24 18:29:41.812324
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    defs = {'plugin_type': 'plugin_name',
            'plugin_def_0': 'plugin_def_1'}
    config_manager.initialize_plugin_configuration_definitions('plugin_type', 'plugin_name', defs)
    assert config_manager._plugins['plugin_type']['plugin_name'] == defs
    config_manager._plugins['plugin_type'] = {}
    defs = {'plugin_type': {'plugin_name': None,
                            'plugin_name_1': defs}}
    config_manager.initialize_plugin_configuration_definitions('plugin_type', 'plugin_name_1', defs)
    assert config_manager._plugins == defs



# Generated at 2022-06-24 18:29:48.772611
# Unit test for function resolve_path
def test_resolve_path():
    basedir = '/etc/ansible'
    path = '{{CWD}}/test/foo.txt'
    result = resolve_path(path, basedir)
    expected = basedir + '/' + os.getcwd().split('/')[-1] + '/test/foo.txt'
    assert(result == expected)


# Generated at 2022-06-24 18:29:51.857332
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('test1.ini') == 'ini'
    assert get_config_type('test2.cfg') == 'ini'
    assert get_config_type('test3.yaml') == 'yaml'


# Generated at 2022-06-24 18:29:55.906070
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    print("test_find_ini_config_file\n")
    print("test_find_ini_config_file\n")
    print("test_find_ini_config_file\n")
    print("test_find_ini_config_file\n")
    print("test_find_ini_config_file\n")
    print("test_find_ini_config_file\n")



# Generated at 2022-06-24 18:30:02.929119
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_1 = ConfigManager()
    result = config_manager_1.get_config_value_and_origin('DEFAULT_SUDO_USER')
    assert result[0] == 'root'
    assert result[1] == 'default'


# Generated at 2022-06-24 18:30:07.785816
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    f = open('conf.ini', 'w')
    print('[section]', file=f)
    print('key0 = value0', file=f)
    print('key1 = value1', file=f)
    print('key2 = value2', file=f)
    print('key3 = value3', file=f)
    f.close()
    f = open('conf.ini', 'r')
    p = configparser.ConfigParser()
    p.read_file(f)
    entry = {'section': 'section', 'key': 'key0'}
    assert get_ini_config_value(p, entry) == p.get(entry.get('section', 'defaults'), entry.get('key', ''), raw=True)
    os.remove('conf.ini')
