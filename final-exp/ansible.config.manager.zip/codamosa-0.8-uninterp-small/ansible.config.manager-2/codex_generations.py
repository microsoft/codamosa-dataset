

# Generated at 2022-06-24 18:30:43.905892
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    config_manager = ConfigManager()
    #print(config_manager.cfg_files)
    for path in config_manager.cfg_files:
        print("%s: %s" % (path, os.path.exists(path)))
        

# Generated at 2022-06-24 18:30:53.159692
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_1 = ConfigManager()

    # Test with default values
    config_manager_1.parse(['-f'])

    # Test for the following combinations
    # plugin_type, plugin_name, config
    # base, empty, empty
    # base, empty, not empty
    # not base, empty, empty
    # not base, empty, not empty
    # not base, not empty, empty
    # not base, not empty, not empty

    # Test with base and config
    assert config_manager_1.get_config_value_and_origin('ANSIBLE_HOST_KEY_CHECKING', cfile='ansible.cfg') == (True, 'default')
    # Test with base and non-config

# Generated at 2022-06-24 18:30:58.862848
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_0 = ConfigManager(loader=None, variables=None)
    config_manager_0._parse_config_file()
    # value, origin = config_manager_0.get_config_value_and_origin('_DEFAULT_VARS_PATH')
    # assert origin == 'default', "ConfigManager.get_config_value_and_origin() : 'origin' value is not correct"

# Generated at 2022-06-24 18:31:08.711613
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():

    # Test case 0
    # Initializing config_manager to an object of class ConfigManager
    config_manager_0 = ConfigManager(
        data = SettingData(
                plugin_defs = {},
                plugin_vars = {},
                constants = {}),
        defaults = {})

    # data and configfile are not passed to update_config_data(), so defaults are used
    # Defaults used: data=SettingData(plugin_defs = {}, plugin_vars = {}, constants = {}), configfile=None
    config_manager_0.update_config_data()

    # Initializing config_manager to an object of class ConfigManager

# Generated at 2022-06-24 18:31:14.871431
# Unit test for function ensure_type
def test_ensure_type():
    value_type = 'Path'
    origin = '/tmp'
    value = '~/some_path'
    expected_value_0 = '/home/user/some_path'

    result = ensure_type(value, value_type, origin)
    assert result == expected_value_0


# Generated at 2022-06-24 18:31:17.486566
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    with pytest.raises(AnsibleError):
        ConfigManager().get_config_value_and_origin('test')


# Generated at 2022-06-24 18:31:22.693211
# Unit test for function resolve_path
def test_resolve_path():
    base_dir = '/tmp'
    path_str = '{{CWD}}/test'
    path_str_2 = '../test'
    path_str_3 = '/home/sunny/test'
    actual_path = resolve_path(path_str, base_dir)
    actual_path_2 = resolve_path(path_str_2, base_dir)
    actual_path_3 = resolve_path(path_str_3, base_dir)
    expect_path = os.getcwd() + '/test'
    expect_path_2 = '/tmp/../test'
    expect_path_3 = '/home/sunny/test'
    assert actual_path == expect_path, "actual path: " + actual_path + 'expect path:' + expect_path
    assert actual_path_2 == expect_

# Generated at 2022-06-24 18:31:32.650023
# Unit test for function ensure_type
def test_ensure_type():
    print(ensure_type("none", "none"))
    print(ensure_type("None", "none"))
    print(ensure_type("none", "none"))
    print(ensure_type("False", "bool"))
    print(ensure_type("false", "bool"))
    print(ensure_type("True", "bool"))
    print(ensure_type("true", "bool"))
    print(ensure_type("100", "integer"))
    print(ensure_type("100.5", "float"))
    print(ensure_type("100,100.5", "list"))
    print(ensure_type("/usr/bin", "path"))
    print(ensure_type("/tmp/ansible-test", "tmppath"))

# Generated at 2022-06-24 18:31:34.067692
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    file1 = find_ini_config_file()


# Generated at 2022-06-24 18:31:42.709621
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.read('ansible.cfg')
    entry = {'section': 'defaults'}
    assert get_ini_config_value(p, entry) == None
    entry['key'] = 'inventory'
    assert get_ini_config_value(p, entry) == None
    entry['key'] = 'roles_path'
    assert get_ini_config_value(p, entry) == '~/.ansible/roles:/usr/share/ansible/roles'
