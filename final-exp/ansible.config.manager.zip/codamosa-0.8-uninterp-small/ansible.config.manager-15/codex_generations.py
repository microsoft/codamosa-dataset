

# Generated at 2022-06-24 18:34:31.395002
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_manager = ConfigManager()
    config_manager._base_defs = dict({
        "somedefault": {"default": 42, "type": int}
    })
    config_manager.update_config_data(defs=config_manager._base_defs)
    assert config_manager.data.somedefault == 42


# Generated at 2022-06-24 18:34:39.241720
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_1 = ConfigManager()
    config_manager_1.update_config_data()
    config_manager_1.data.update_setting(Setting('DEFAULT_LOG_PATH', '/tmp/ansible.log', 'DEFAULT', 'string'))
    config_manager_1.data.update_setting(Setting('DEFAULT_HOST_LIST', '/tmp/ansible_hosts', 'DEFAULT', 'string'))

    # test case 1
    ansible_hosts_file_path = "/tmp/ansible_hosts"
    ansible_log_file_path = "/tmp/ansible.log"
    value, origin = config_manager_1.get_config_value_and_origin("DEFAULT_LOG_PATH")

# Generated at 2022-06-24 18:34:44.434200
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()

# Generated at 2022-06-24 18:34:46.470245
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    pathname = find_ini_config_file()
    print(pathname)
    assert pathname is not None
    # print('Test for find_ini_config_file: Success')



# Generated at 2022-06-24 18:34:49.236071
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager_1 = ConfigManager()
    dict_1 = config_manager_1.get_configuration_definitions(ignore_private=False)
    dict_2 = config_manager_1.get_configuration_definitions(ignore_private=True)
    assert dict_2 != dict_1


# Generated at 2022-06-24 18:34:54.265198
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    defs = dict(a=1,b=2,c=3)
    config_manager_0 = ConfigManager()
    config_manager_0.initialize_plugin_configuration_definitions('a','b',defs)
    config_manager_0.initialize_plugin_configuration_definitions('c','d',defs)
    config_manager_0.initialize_plugin_configuration_definitions('e','f',defs)
    res = []
    res.append(config_manager_0.get_configuration_definitions() == {})
    res.append(config_manager_0.get_configuration_definitions('a') == {'b': {'a': 1, 'b': 2, 'c': 3}})

# Generated at 2022-06-24 18:34:59.398043
# Unit test for function get_config_type
def test_get_config_type():
    cfile = "/etc/ansible/ansible.cfg"

    ftype = get_config_type(cfile)
    assert ftype == 'ini'

    cfile = "/ansible/ansible.yml"
    ftype = get_config_type(cfile)
    assert ftype == 'yaml'

if __name__ == '__main__':
    test_case_0()
    test_get_config_type()

# Generated at 2022-06-24 18:35:04.831079
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_1 = ConfigManager()
    config_manager_1._parse_config_file("ansible.cfg")
    # Test case no:1
    config_key = "ACME_CITY"
    config_type = None
    config_name = None
    config_keys = None
    config_variables = None
    config_direct = None
    expected_result = (None, None)
    actual_result = config_manager_1.get_config_value_and_origin(config_key, configfile=None, plugin_type=config_type, plugin_name=config_name, keys=config_keys, variables=config_variables, direct=config_direct)
    assert actual_result == expected_result
    del config_manager_1


# Generated at 2022-06-24 18:35:10.959996
# Unit test for function resolve_path
def test_resolve_path():
    # Case 1, both path and basedir are absolute path
    path1 = '/some/path'
    basedir1 = '/basedir1'
    resolved_path1 = resolve_path(path1, basedir1)
    print(repr(resolved_path1))

    # Case 2, path is absolute path and basedir is a relative path
    path2 = '/some/path'
    basedir2 = 'basedir1'
    resolved_path2 = resolve_path(path2, basedir2)
    print(repr(resolved_path2))

    # Case 3, path is a relative path and basedir is an absolute path
    path3 = 'some/path'
    basedir3 = '/basedir1'
    resolved_path3 = resolve_path(path3, basedir3)

# Generated at 2022-06-24 18:35:14.726130
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_manager_0 = ConfigManager() # config_manager instance
    defs_0 = {} # @UnusedVariable
    configfile_0 = get_config_file() # config_manager attribute
    try:
        config_manager_0.update_config_data(defs_0, configfile_0)
    except Exception as e:
        print(e)

if __name__ == '__main__':

    # Run unit tests
    test_ConfigManager_update_config_data()