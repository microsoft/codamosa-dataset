

# Generated at 2022-06-24 18:30:46.844997
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/home/c1.yaml') == 'yaml'
    assert get_config_type('/home/c2.ini') == 'ini'
    assert get_config_type('/home/c3.cfg') == 'ini'
    try:
        get_config_type('/home/c4.txt')
        assert False
    except:
        pass


# Generated at 2022-06-24 18:30:53.390215
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager_1 = ConfigManager()
    assert config_manager_1.get_configuration_definition("ANSIBLE_LOCAL_TEMP") is not None
    assert config_manager_1.get_configuration_definition("ANSIBLE_LOCAL_TEMP", "default") is not None
    assert config_manager_1.get_configuration_definition("ANSIBLE_LOCAL_TEMP", "default", "command") is not None


# Generated at 2022-06-24 18:31:02.744420
# Unit test for function get_config_type
def test_get_config_type():
    test_case_1_file = './a.ini'
    test_case_1_result = get_config_type(test_case_1_file)
    print (test_case_1_result)
    if test_case_1_result != 'ini':
        raise ValueError('The result of test case 1 is not correct.')
    test_case_2_file = './a.cfg'
    test_case_2_result = get_config_type(test_case_2_file)
    if test_case_2_result != 'ini':
        raise ValueError('The result of test case 2 is not correct.')
    test_case_3_file = './a.yaml'
    test_case_3_result = get_config_type(test_case_3_file)

# Generated at 2022-06-24 18:31:07.168780
# Unit test for function resolve_path
def test_resolve_path():
    print("Testing of resolve_path function")
    path = ''
    # FIXME: still to fix deletion of files etc
    basedir = '/tmp'
    resolved_path = resolve_path(path,basedir)
    print("Resolved path is: ", resolved_path)
    assert(resolved_path == '/tmp')
    print("resolve_path() PASSED")


# Generated at 2022-06-24 18:31:18.935746
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_1 = ConfigManager()
    result = config_manager_1.get_config_value_and_origin(config="default_module_name", cfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None)
    try:
        assert len(result) == 2
        print("... Successfully validated get_config_value_and_origin")
    except AssertionError:
        print("... get_config_value_and_origin returns an array.  Expecting an array of len 2.")


if __name__ == '__main__':
    # print(ansible.__version__)
    # test_case_0()
    test_ConfigManager_get_config_value_and_origin()

# Generated at 2022-06-24 18:31:22.268657
# Unit test for function get_config_type
def test_get_config_type():
    ansible_config_file_path = '/etc/ansible/ansible.cfg'
    assert get_config_type(ansible_config_file_path) == 'ini'


# Generated at 2022-06-24 18:31:32.246745
# Unit test for function resolve_path
def test_resolve_path():
    if (sys.version_info < (3, 5)):
        assert resolve_path('/tmp') == '/tmp'
        assert resolve_path('/tmp', '.') == '/tmp'

        # For Python 3.4 and below, paths are not expanded
        assert resolve_path('~/bin') == '~/bin'
        assert resolve_path('~/bin', '.') == '~/bin'
        assert resolve_path('$PATH') == '$PATH'
    else:
        assert resolve_path('/tmp') == '/tmp'
        assert resolve_path('/tmp', '.') == '/tmp'

        # For Python 3.5 and above, paths are expanded
        assert resolve_path('~/bin') == os.path.expanduser('~/bin')

# Generated at 2022-06-24 18:31:35.377745
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = "iam"
    name = "name"
    defs = {}
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 18:31:46.404602
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager_1 = ConfigManager()
    assert config_manager_1.get_config_value_and_origin('accelerate_port') == (None, None)
    assert config_manager_1.get_config_value_and_origin('accelerate_port', direct={'accelerate_port': 1234}) == (1234, 'Direct')
    assert config_manager_1.get_config_value_and_origin('accelerate_port', direct={'accelerate_port_for_winrm': 1234}) == (1234, 'Direct')
    assert config_manager_1.get_config_value_and_origin('accelerate_port', configfile='./ansible.cfg') == (None, None)

# Generated at 2022-06-24 18:31:57.365176
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager_1 = ConfigManager()
    plugin_type = 'vars'
    name = 'test'
    ignore_private = False
    result = config_manager_1.get_configuration_definitions(plugin_type, name, ignore_private)
    assert isinstance(result, dict)
    assert result == {}
    plugin_type = 'test'
    name = 'test'
    ignore_private = False
    result = config_manager_1.get_configuration_definitions(plugin_type, name, ignore_private)
    assert isinstance(result, dict)
    assert result == {}
    plugin_type = 'vars'
    name = 'test'
    ignore_private = True
    result = config_manager_1.get_configuration_definitions(plugin_type, name, ignore_private)
   