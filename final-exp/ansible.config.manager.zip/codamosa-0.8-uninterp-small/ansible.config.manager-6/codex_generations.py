

# Generated at 2022-06-24 18:35:09.225702
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    print("\ntest_ConfigManager_get_config_value_and_origin()")

    # 1. Simple case
    plugin_type = "callback"
    name = "mail"
    # 1.1. Default value
    print("    1.1. Default value")
    config = "to"
    config_manager_1_1 = ConfigManager()
    value, origin = config_manager_1_1.get_config_value_and_origin(config, plugin_type=plugin_type, plugin_name=name)
    print("        Value:{} -- Origin:{}".format(value, origin))
    assert value == DEFAULT_MAIL_TO
    assert origin == "default"
    # 1.2. Invalid variable
    print("    1.2. Invalid variable")
    config = "port"
    config_manager_1

# Generated at 2022-06-24 18:35:10.852565
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    pass


# Generated at 2022-06-24 18:35:16.390695
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():

    action_type = 'shell'
    param = 'command'
    plugin_type = 'action'
    plugin_name = 'shell'
    ignore_private = False
    config_manager = ConfigManager()

    # Test with all the parameters
    config_manager.get_configuration_definitions(plugin_type,
                                                 plugin_name,
                                                 ignore_private)

    # Test with action_type as param
    config_manager.get_configuration_definitions(plugin_type,
                                                 action_type)

    # Test with param as plugin_name
    config_manager.get_configuration_definitions(plugin_type,
                                                 param)

    # Test with only one parameter
    config_manager.get_configuration_definitions(plugin_name)

    # Test with no parameter
    config_manager

# Generated at 2022-06-24 18:35:23.108760
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    print("Testing function get_ini_config_value")
    p = configparser.ConfigParser()
    sample_config_file = './test/test_vars.ini'
    p.read(sample_config_file)

    parsed_value = get_ini_config_value(p, {'key': 'sub_tree_level_3.sub_tree_level_4.sub_tree_level_5.sub_tree_level_6'})
    if parsed_value != 'sub_tree_value':
        raise Exception("Parsed value %s does not match sub_tree_value"  % parsed_value)
