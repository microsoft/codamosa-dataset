

# Generated at 2022-06-24 18:30:06.897529
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager_1 = ConfigManager()

    test_1 = config_manager_1.get_configuration_definitions()
    assert type(test_1) == dict

    test_2 = config_manager_1.get_configuration_definitions('a')
    assert type(test_2) == dict

    test_3 = config_manager_1.get_configuration_definitions('a', 'b')
    assert type(test_3) == dict


# Generated at 2022-06-24 18:30:20.254028
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager_def = ConfigManager()
    config_manager_def.load()
    config_manager_def.get_configuration_definitions()
    config_manager_def.get_configuration_definitions('connection')
    config_manager_def.get_configuration_definitions('connection', 'chroot')
    config_manager_def.get_configuration_definitions('connection', 'paramiko_ssh')
    config_manager_def.get_configuration_definitions('connection', 'ssh')
    config_manager_def.get_configuration_definitions('connection', 'local')
    config_manager_def.get_configuration_definitions('strategy')
    config_manager_def.get_configuration_definitions('strategy', 'free')

# Generated at 2022-06-24 18:30:30.066144
# Unit test for function resolve_path

# Generated at 2022-06-24 18:30:36.328330
# Unit test for function get_config_type
def test_get_config_type():
    print("Testing function get_config_type")
    assert get_config_type("/etc/ansible/ansible.cfg") == "ini", "This should be ini"
    assert get_config_type("~/.ansible/myansible.cfg") == "ini", "This should be ini"


# Generated at 2022-06-24 18:30:39.282716
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    from ansible.module_utils.six import PY2
    cfg = find_ini_config_file()
    print ("Find ini config file: {}".format(cfg))

    with open(cfg) as f:
        if PY2:
            data = f.read()
        else:
            data = f.read().encode()
    print(data)


# Generated at 2022-06-24 18:30:50.034545
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager_1 = ConfigManager()
    #Check for a base definition
    config_manager_1.get_configuration_definition('DEFAULT_SUDO_USER')
    #Check for a plugin definition
    config_manager_1.get_configuration_definition('DEFAULT_SUDO', 'sudo')
    #Check for a plugin with a name definition
    config_manager_1.get_configuration_definition('DEFAULT_SUDO_FLAGS', 'sudo', 'default')
    #Check for a non existing definition
    config_manager_1.get_configuration_definition('SOMETHING')


# Generated at 2022-06-24 18:30:58.967994
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    config_manager = ConfigManager()
    # config  #TODO: define a dummy config
    # cfile  #TODO: define a dummy cfile
    # plugin_type  #TODO: define a dummy plugin_type
    # plugin_name  #TODO: define a dummy plugin_name
    # keys  #TODO: define a dummy keys
    # variables  #TODO: define a dummy variables
    # direct  #TODO: define a dummy direct
    ret = config_manager.get_config_value(config, cfile, plugin_type, plugin_name, keys, variables, direct)
    assert isinstance(ret, object)


# Generated at 2022-06-24 18:31:06.089226
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config_manager_0 = ConfigManager()
    test_case_1_plugin_type_0 = ''
    test_case_1_name_0 = ''
    result_1 = config_manager_0.get_plugin_vars(test_case_1_plugin_type_0, test_case_1_name_0)
    # Verifying that the result of get_plugin_vars matches with the expected value.
    assert result_1 == []


# Generated at 2022-06-24 18:31:08.426823
# Unit test for function resolve_path
def test_resolve_path():
    print("Calling test_resolve_path ...")
    path = "home/user1/test_dir"
    print("Resolving path: %s" % path)
    resolve_path(path)



# Generated at 2022-06-24 18:31:14.677529
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    # Assign values to variables
    config_manager_0 = ConfigManager()
    config_manager_0.get_config_value_and_origin(config, cfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None)
