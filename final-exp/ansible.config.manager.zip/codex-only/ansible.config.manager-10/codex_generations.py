

# Generated at 2022-06-22 19:30:32.053495
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    conf_manager = ConfigManager()
    try:
        conf_manager.get_configuration_definition(None, None, None)
    except Exception as e:
        print("Test #1 Failed - get_configuration_definition: " + str(e))


# Generated at 2022-06-22 19:30:37.343363
# Unit test for function get_config_type
def test_get_config_type():
    cfile = get_config_type('test.ini')
    assert cfile == 'ini'
    cfile = get_config_type('test.yml')
    assert cfile == 'yaml'
    cfile = get_config_type('test.cfg')
    assert cfile == 'ini'
    cfile = get_config_type('test.yaml')
    assert cfile == 'yaml'
    try:
        cfile = get_config_type('test.log')
        assert False
    except AnsibleOptionsError as e:
        assert to_native(e) == "Unsupported configuration file extension for test.log: .log"

# Generated at 2022-06-22 19:30:44.629097
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    configManager = ConfigManager()
    # test with positional arguments
    configManager.get_config_value("ANSIBLE_CONFIG")
    configManager.get_config_value("ANSIBLE_CONFIG", cfile="")
    configManager.get_config_value("ANSIBLE_CONFIG", cfile='', plugin_type='', plugin_name='', keys=None, variables=None, direct=None)

# Generated at 2022-06-22 19:30:56.175056
# Unit test for function resolve_path
def test_resolve_path():
    # Tests with CWD
    # Test os.path.isabs() in resolve_path function
    assert resolve_path('/tmp', basedir='/') == '/tmp'
    assert resolve_path('/tmp', basedir='/foo/bar') == '/tmp'

    # Test os.path.expanduser() in resolve_path function
    assert resolve_path('~/foo', basedir='/tmp') == os.path.expanduser('~/foo')

    # Test os.path.expandvars() in resolve_path function
    os.environ['FOO'] = '/tmp'
    assert resolve_path('$FOO/foo', basedir='/tmp') == os.path.expandvars('$FOO/foo')

    # Test os.path.normpath() in resolve_path function
    assert resolve_path

# Generated at 2022-06-22 19:31:08.888637
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    c = ConfigManager()
    assert c.get_plugin_vars('callback','default') == ['api_password', 'api_token', 'api_url', 'api_user', 'delegated_vars', 'job_id', 'job_url', 'playbook_name', 'playbook_path', 'project_id', 'project_name', 'project_url', 'play_hosts', 'playbook_version', 'target_host', 'team_id', 'team_name', 'team_url']
    assert c.get_plugin_vars('cache','jsonfile') == []
    assert c.get_plugin_vars('cache','memory') == []
    assert c.get_plugin_vars('cache','redis') == []
    assert c.get_plugin_vars('callback','tree') == []

# Generated at 2022-06-22 19:31:14.459732
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()

    assert config_manager._base_defs is not None
    assert len(config_manager._base_defs) > 0

    try:
        assert config_manager.get_configuration_definition(None) is None
        assert config_manager.get_configuration_definition('') is None
        assert config_manager.get_configuration_definition(' ') is None
    except AnsibleError:
        assert False, 'unexpected AnsibleError exception'

    for plugin_type in config_manager._plugins:
        for name in config_manager._plugins[plugin_type]:
            assert config_manager.get_configuration_definition(name, plugin_type) is not None


# Generated at 2022-06-22 19:31:24.220949
# Unit test for function resolve_path
def test_resolve_path():

    answers = {
        '~/.ansible': '/home/%s/.ansible' % os.environ['LOGNAME'],
        '~nobody/.ansible': '~nobody/.ansible',
        '~/.ansible/roles': '/home/%s/.ansible/roles' % os.environ['LOGNAME']
    }

    for answer_key in answers:
        assert answers[answer_key] == resolve_path(answer_key)


# NOTE: see if we can unify this with the ini_config parser in utils/module_docs

# Generated at 2022-06-22 19:31:33.645350
# Unit test for constructor of class Setting
def test_Setting():
    """Check Setting constructor"""
    from collections import namedtuple
    import sys

    Setting_t = namedtuple('Setting_t', 'constant, value, origin, _type, desc')

# Generated at 2022-06-22 19:31:45.229841
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    assert get_ini_config_value(None, {}) == None
    test_config = to_bytes("""[defaults]
key1 = value1
key2 = value2
""")
    with tempfile.NamedTemporaryFile() as f:
        f.write(test_config)
        f.flush()
        p = configparser.ConfigParser()
        p.read(f.name)
        entry = {}
        assert get_ini_config_value(p, entry) == None
        assert get_ini_config_value(p, dict(key='key1')) == 'value1'
        assert get_ini_config_value(p, dict(key='key2')) == 'value2'

# Generated at 2022-06-22 19:31:49.131403
# Unit test for constructor of class Setting
def test_Setting():
    # Unbound function '[' not allowed as rcfile_path
    s = Setting('CONFIG_FILE', '../ansible.cfg', '')


# Generated at 2022-06-22 19:32:00.726260
# Unit test for method get_plugin_options of class ConfigManager

# Generated at 2022-06-22 19:32:05.982298
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    c = ConfigManager()
    with pytest.raises(AnsibleOptionsError):
        c.update_config_data(defs='string' , configfile='/etc/ansible/ansible.cfg')

# Generated at 2022-06-22 19:32:18.693676
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    # Testing with valid option names which have default values set.
    config_manager = ConfigManager()
    options = config_manager.get_config_value('DEFAULT_ACTION_PLUGIN_PATH')
    assert options == '~/.ansible/plugins/action_plugins:/usr/share/ansible/plugins/action_plugins'
    options = config_manager.get_config_value('DEFAULT_CACHE_PLUGIN')
    assert options == 'memory'
    options = config_manager.get_config_value('DEFAULT_CALLBACK_PLUGINS')
    assert options == '/usr/share/ansible/plugins/callback:/home/ansible/.ansible/plugins/callback'
    options = config_manager.get_config_value('DEFAULT_CONNECTION_TIMEOUT')
    assert options == 30
    options = config

# Generated at 2022-06-22 19:32:28.602767
# Unit test for function ensure_type
def test_ensure_type():

    assert ensure_type('/tmp/foo', 'path') == '/tmp/foo'
    assert ensure_type('/tmp/foo', 'tmppath') == ensure_type('/tmp/foo', 'tmp') == ensure_type('/tmp/foo', 'temppath') == to_text(to_bytes(startswith='/tmp/ansible-local-'))
    assert ensure_type('/tmp/foo/', 'path') == '/tmp/foo'
    assert ensure_type('foo', 'path') == 'foo'
    assert ensure_type('foo,bar', 'list') == ['foo', 'bar']
    assert ensure_type(['foo', 'bar'], 'list') == ['foo', 'bar']
    assert ensure_type('True', 'bool') == True
    assert ensure_type('asdf', 'bool') == False

# Generated at 2022-06-22 19:32:36.960292
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():

    for plugin in PLUGIN_DEFINITIONS:
        plugin_type = plugin.split('.')[0]
        plugin_name = plugin.split('.')[1]
        defs = PLUGIN_DEFINITIONS[plugin]
        config = ConfigManager()
        config.initialize_plugin_configuration_definitions(plugin_type, plugin_name, defs)
        assert all(v in config.get_plugin_vars(plugin_type, plugin_name) for v in defs['vars'])

    return True

# Generated at 2022-06-22 19:32:45.868855
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    buf = io.StringIO()
    buf.write(u'[defaults]\n')
    buf.write(u'foo=BAR\n')
    buf.seek(0)
    p = configparser.ConfigParser()
    p.readfp(buf)
    value = get_ini_config_value(p, {'section': 'defaults', 'key': 'foo'})
    assert value == u'BAR'

    buf = io.StringIO()
    buf.write(u'[defaults]\n')
    buf.write(u'foo=BAR\n')
    buf.seek(0)
    p = configparser.ConfigParser()
    p.readfp(buf)

# Generated at 2022-06-22 19:32:47.837189
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    pass


# FIXME: move to module_utils

# Generated at 2022-06-22 19:32:49.652073
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # TODO: implement this
    return True



# Generated at 2022-06-22 19:32:57.681037
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    c = ConfigManager()
    c._base_defs = {
        'test': {
            'default': ['a', 'b'],
            'required': False,
            'type': 'list',
            'choices':[['c', 'd'], ['a', 'b']],
            'env': [{'name': 'TEST_ENV'}],
            'ini': [{'section':'defaults', 'key': 'test', 'path': os.path.join('files', 'test.cfg'), 'vars': ['vars']}],
            'cli': [{'name': 'test'}]
        }
    }

# Generated at 2022-06-22 19:33:09.921547
# Unit test for constructor of class Plugin
def test_Plugin():
    ''' setup configuration for the plugins to prevent errors '''

    global Plugin
    from ansible.constants import PLUGIN_PATH_CACHE

    # create a plugin to test
    from ansible.plugins.loader import collection_loader
    from ansible.plugins.loader import module_loader

    plugin_loaders = (
        collection_loader,
        module_loader,
    )

    Plugin = Plugin(config_manager=CONFIG_MANAGER, plugin_loaders=plugin_loaders, plugin_paths=PLUGIN_PATH_CACHE)


# test if the plugin class is already defined, if not define it
if not hasattr(sys.modules[__name__], 'Plugin'):
    test_Plugin()



# Generated at 2022-06-22 19:33:18.056412
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.SafeConfigParser()
    try:
        p.read(os.path.join(os.path.dirname(__file__), '../tests/test_lookup.cfg'))
    except Exception:
        pass
    assert get_ini_config_value(p, {'section': 'lookup_plugins', 'key': '_terms'}) == 'auto'
    assert get_ini_config_value(p, {'section': 'lookup_plugins', 'key': 'other_plugin'}) is None


# Generated at 2022-06-22 19:33:29.639313
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin(): 
    # 1. test the case where configuration is None
    if config is None:
        config = ConfigManager()

    # 2. test other cases
    defs = self.get_configuration_definitions(plugin_type, plugin_name)

    # 3. test other cases
    value = None
    origin = None


    if config in defs:

        aliases = defs[config].get('aliases', [])

        # direct setting via plugin arguments, can set to None so we bypass rest of processing/defaults
        direct_aliases = []
        if direct:
            direct_aliases = [direct[alias] for alias in aliases if alias in direct]
        if direct and config in direct:
            value = direct[config]
            origin = 'Direct'
        elif direct and direct_aliases:
            value = direct_aliases

# Generated at 2022-06-22 19:33:33.709063
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    plugin_type = 'first'
    name = 'second'
    defs = {}
    test_instance = ConfigManager()
    actual = test_instance.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert actual == {}
    actual = test_instance._plugins
    assert actual == {'first': {'second': {}}}

# Generated at 2022-06-22 19:33:42.993562
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    host_list = [
      dict(
        hostname = 'server1.domain.com',
        port=50000,
        connection='ssh',
        ssh_user='root',
        become_method='sudo',
        become_user='root',
        ansible_ssh_pass='password1',
        ansible_sudo_pass='password2',
        groups=['local_server'],
        vars={'key': 'value'}
      ),
      dict(
        hostname = 'server2.domain.com',
        port=50001,
        connection='local',
        groups=['local_server'],
        vars={'key': 'value'}
      )
    ]
    inventory = InventoryManager(loader=DataLoader(), sources=host_list)

# Generated at 2022-06-22 19:33:44.763672
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_manager = ConfigManager()
    assert config_manager is not None
    assert isinstance(config_manager, ConfigManager)


# Generated at 2022-06-22 19:33:47.062497
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    configmanager = ConfigManager()
    assert configmanager.get_configuration_definition(None, None, None) == {}, "The test case is empty" 



# Generated at 2022-06-22 19:33:51.591050
# Unit test for constructor of class Plugin
def test_Plugin():
    assert getattr(Plugin, '_singleton_instance', None) is None
    p = Plugin()
    assert getattr(Plugin, '_singleton_instance', None) is p
    return p


# Generated at 2022-06-22 19:34:03.263488
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    """
    Test get_configuration_definitions()

    :return:
    """

# Generated at 2022-06-22 19:34:04.369439
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    cm = ConfigManager()
    cm.get_config_value('abc')


# Generated at 2022-06-22 19:34:09.480651
# Unit test for constructor of class Setting
def test_Setting():
    setting = Setting('FOO', 'bar', 'from config', 'string')
    assert setting.name == 'FOO'
    assert setting.value == 'bar'
    assert setting.origin == 'from config'
    assert setting.string_type == 'string'


# Generated at 2022-06-22 19:34:16.651364
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.read(['./tests/unit/ansible_test/test_config.ini'])
    entry = {'key': 'testdata', 'section': 'test'}
    assert get_ini_config_value(p, entry) == "hello"


# FIXME: see if this can move to module_utils with similar function used by argspec

# Generated at 2022-06-22 19:34:21.272469
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # testing method get_configuration_definition(name, plugin_type=None, plugin_name=None)
    global config_manager_instance
    config_manager_instance = config_manager_instance = get_config_manager()

# Generated at 2022-06-22 19:34:26.198387
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager()
    # update_config_data() takes exactly 1 argument (0 given)
    assert_raises(exception_class=TypeError, callable_obj=config.update_config_data)


# Generated at 2022-06-22 19:34:39.697105
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    c_mgr = ConfigManager()

# Generated at 2022-06-22 19:34:52.557102
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('type1','name1','defs1')
    assert cm._plugins == {'type1': {'name1': 'defs1'}}
    cm.initialize_plugin_configuration_definitions('type2','name2','defs2')
    assert cm._plugins == {'type1': {'name1': 'defs1'}, 'type2': {'name2': 'defs2'}}
    cm.initialize_plugin_configuration_definitions('type1','name3','defs3')
    assert cm._plugins == {'type1': {'name1': 'defs1', 'name3':'defs3'}, 'type2': {'name2': 'defs2'}}

# Generated at 2022-06-22 19:35:04.276095
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    plugintype = 'lookup'
    pluginnames = ['fileglob', 'dummy']
    configmanager = ConfigManager()
    cdata = configmanager._base_defs['syslog_facility']
    configmanager._base_defs['syslog_facility'] = {'default': 'LOG_USER', 'env': [{'name': 'ANSIBLE_SYSLOG_FACILITY'}]}
    configmanager._base_defs['log_path'] = {'default': u'/dev/null', 'env': [{'name': 'ANSIBLE_LOG_PATH'}]}
    for pluginn in pluginnames:
        bop1 = configmanager.get_plugin_options(plugintype, pluginn)

# Generated at 2022-06-22 19:35:11.354122
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    c = ConfigManager()
    # These are just sanity tests to make sure the constants
    # match what's in the config spec.
    assert c.get_configuration_definition('CONFIG_FILE')['default'] == '/etc/ansible/ansible.cfg'
    assert c.get_configuration_definition('FORKS')['default'] == 5
    assert c.get_configuration_definition('HOST_KEY_CHECKING')['type'] == 'boolean'


# Generated at 2022-06-22 19:35:23.064795
# Unit test for method get_config_value of class ConfigManager

# Generated at 2022-06-22 19:35:31.563270
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():

    import os
    import sys
    import tempfile
    import textwrap

    class MockConfig (object):

        def __init__(self, settings):
            self._settings = settings

        def get_config_value(self, config, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None):
            return self._settings.get(config, None)

    def test_options(config, plugin_type, plugin_name, options):

        plugin_options = config.get_plugin_options(plugin_type, plugin_name)

        for option in options:
            expected = options[option]
            actual = plugin_options.get(option)
            assert expected == actual, \
                "Expected %s to be '%s', but received '%s'" % (option, expected, actual)

    tmp

# Generated at 2022-06-22 19:35:39.490407
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    host = Host()
    variable_manager = VariableManager()
    loader = DataLoader()
    config_manager = ConfigManager()

    plugin_type = 'action_plugin'
    name = 'accelerate'
    keys = {}
    variables = {}
    direct = {}
    pvars = config_manager.get_plugin_vars(plugin_type, name)

    assert len(pvars) == 0

    plugin_type = 'become_method'
    name = 'dummy'
    keys = {}
    variables = {}
    direct = {}
    pvars = config_manager.get_plugin_vars(plugin_type, name)

    assert len(pvars) == 0

    plugin_type = 'cache_plugin'
    name = 'dummy'
    keys = {}
    variables = {}
   

# Generated at 2022-06-22 19:35:50.838863
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    print("Test get_configuration_definition")
    config = ConfigManager()
    config.parse()
    definition = config.get_configuration_definition('remote_port')
    assert definition['type'] == 'integer'
    assert definition['default'] == 22
    assert definition['env'] == [{"name": "ANSIBLE_REMOTE_PORT"}, {"name": "ANSIBLE_REMOTE_PORTS"}]
    definition = config.get_configuration_definition('privilege_escalation', '', 'become')
    assert definition['type'] == 'bool'
    assert definition['default'] == False
    assert definition['ini'] == [{"key": "become", "section": "privilege_escalation"}]

# Generated at 2022-06-22 19:35:57.490390
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    manager = ConfigManager()
    manager.initialize_plugin_configuration_definitions('test_plugin_type', 'test_plugin_name', {'test_config': {'default': 'test_default', 'type': 'string'}})

    assert manager._plugins['test_plugin_type']['test_plugin_name'] == {'test_config': {'default': 'test_default', 'type': 'string'}}


# Generated at 2022-06-22 19:36:06.164255
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
  
  # Test with config file
  config_mgr = ConfigManager(cfile='tests/inventory_manager_config.ini')
  # Test with config
  config_val = config_mgr.get_configuration_definition('core', 'plugin_filters_core')
  assert config_val == {'default': '_default', 'required': True, 'type': 'string', 'ini': [{'section': 'inventory_manager', 'key': 'plugin_filters_core'}], 'env': [{'name': 'ANSIBLE_INVENTORY_PLUGIN_FILTERS_CORE'}]}



# Generated at 2022-06-22 19:36:19.139176
# Unit test for function ensure_type
def test_ensure_type():
    assert u"boolean" == ensure_type("TRUE", "string")
    assert u"boolean" == ensure_type("TRUE", "str")
    assert u"boolean" == ensure_type("TRUE", "string")
    assert u"boolean" == ensure_type("TRUE", "str")
    assert u"boolean" == ensure_type("TRUE", "string")
    assert u"boolean" == ensure_type("TRUE", "str")
    assert u"boolean" == ensure_type("TRUE", "string")
    assert u"boolean" == ensure_type("TRUE", "str")
    assert u"boolean" == ensure_type("TRUE", "string")
    assert u"boolean" == ensure_type("TRUE", "str")
    assert u"boolean" == ensure

# Generated at 2022-06-22 19:36:30.038860
# Unit test for function ensure_type
def test_ensure_type():
    ''' test ensure_type function '''

    assert ensure_type('true', 'boolean') is True
    assert ensure_type('false', 'bool') is False
    assert ensure_type(str(5), 'int') == 5
    assert ensure_type('5.5', 'float') == 5.5
    assert ensure_type('a,b,c', 'list') == ['a', 'b', 'c']
    assert ensure_type('None', 'none') is None
    assert ensure_type('~', 'path') == u'/Users/test'
    assert ensure_type('~test/my/path', 'path') == u'/Users/test/my/path'
    assert ensure_type('~test/my/path', 'path') == u'/Users/test/my/path'

# Generated at 2022-06-22 19:36:35.797757
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    configmanager = ConfigManager()
    plugin_type = 'callback'
    name = 'default'
    defs = None
    configmanager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert configmanager._plugins == {'callback': {'default': None}}

# Generated at 2022-06-22 19:36:41.704270
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    cwd = os.getcwd()
    perms = os.stat(cwd)
    os.chmod(cwd, 0o700)
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tmp:
        tmp.write("[defaults]\n")

# Generated at 2022-06-22 19:36:49.356078
# Unit test for function resolve_path
def test_resolve_path():
    test_path = '/my/path:{{CWD}}'
    test_basedir = '/my/basedir'
    test_unfracked_path = '/my/path:{{CWD}}'
    test_fracked_path = '/my/path:{{CWD}}'
    assert resolve_path(test_path, test_basedir) == test_unfracked_path
    assert resolve_path(test_fracked_path, test_basedir) == test_unfracked_path

# Generated at 2022-06-22 19:36:56.080448
# Unit test for constructor of class Plugin
def test_Plugin():

    # test default
    p = Plugin('Test', 'doc', 'fname')
    assert p.get_name() == 'Test'
    assert p.get_doc() == 'doc'
    assert p.get_filename() == 'fname'

    # test all options
    p = Plugin('Test', 'doc', 'fname', 'weird_error')
    assert p.get_name() == 'Test'
    assert p.get_doc() == 'doc'
    assert p.get_filename() == 'fname'
    assert p.get_error() == 'weird_error'



# Generated at 2022-06-22 19:37:02.056601
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config_manager = ConfigManager()

    plugin_type = 'lookup'
    name = 'csvfile'
    keys=None
    variables=None
    direct={}
    direct['foo']='bar'

    config_manager.get_plugin_options(plugin_type, name, keys, variables, direct)

# Generated at 2022-06-22 19:37:08.212435
# Unit test for function resolve_path
def test_resolve_path():
    ''' for testing resolve_path function '''
    if not os.path.exists('/tmp/test_resolve_path_dir'):
        os.makedirs('/tmp/test_resolve_path_dir')
    out = resolve_path('./test_resolve_path_dir')
    assert out == '/tmp/test_resolve_path_dir'
    os.rmdir('/tmp/test_resolve_path_dir')



# Generated at 2022-06-22 19:37:18.303473
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():

    config_manager = ConfigManager()

    ansible_config = ConfigManager()
    assert isinstance(ansible_config, ConfigManager)
    assert ansible_config.data is not None
    assert ansible_config._parsers is not None
    assert ansible_config._base_defs is not None
    assert ansible_config._plugins is not None
    assert isinstance(ansible_config.console, Console)
    assert ansible_config.console.display is not None
    # setup config file to use
    set_default_conf_file('ansible_config.ini')
    assert ansible_config._config_file == 'ansible_config.ini'

# Generated at 2022-06-22 19:37:26.413362
# Unit test for function find_ini_config_file
def test_find_ini_config_file():

    # these are the INI config locations that we check for, in order
    # this unit test will check the first location that exists only
    ini_locations = [
        # ENV
        'ANSIBLE_CONFIG',

        # CWD
        os.path.join(os.getcwd(), 'ansible.cfg'),

        # HOME
        os.path.join(os.path.expanduser("~"), ".ansible.cfg"),

        # /etc/ansible
        '/etc/ansible/ansible.cfg',
    ]

    # where do we expect to find the config?
    locations_to_use = []

    for location in ini_locations:
        if os.path.isfile(location):
            locations_to_use.append(location)

    # generate warnings if config was not in expected location


# Generated at 2022-06-22 19:37:34.615946
# Unit test for constructor of class ConfigManager

# Generated at 2022-06-22 19:37:42.959079
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    assert config.get_configuration_definition("DEFAULT_LOG_PATH") == {'default': u'/var/log/ansible.log', 'type': 'path'}
    assert config.get_configuration_definition("DEFAULT_LOG_PATH", "callback") == {'default': u'/var/log/ansible.log', 'type': 'path'}
    assert config.get_configuration_definition("DEFAULT_LOG_PATH", "callback", "default") == {'default': u'/var/log/ansible.log', 'type': 'path'}
    assert config.get_configuration_definition("DEFAULT_LOG_PATH", "callback", "notexistingcallback") == None
    assert config.get_configuration_definition("DEFAULT_LOG_PATH", "notexistingplugintype") == None


# Generated at 2022-06-22 19:37:46.491826
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    cm = ConfigManager()
    assert cm._base_defs is not None
    assert cm.data is not None


# Generated at 2022-06-22 19:37:48.486667
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    obj = ConfigManager()
    assert True


# Generated at 2022-06-22 19:37:52.653728
# Unit test for function get_config_type
def test_get_config_type():
    assert(get_config_type('/path/to/file.yml') == 'yaml')
    assert(get_config_type('/path/to/file.yaml') == 'yaml')
    assert(get_config_type('/path/to/file.ini') == 'ini')



# Generated at 2022-06-22 19:37:57.095275
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    defs = dict()
    config.initialize_plugin_configuration_definitions(None, None, defs)
    # AssertionError: Expected: {'_': None, '__': None, '___': None}
    # Actual: [{'_': None, '__': None, '___': None}]



# Generated at 2022-06-22 19:38:03.294802
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/usr/lib/myfile') == '/usr/lib/myfile'
    if sys.platform.startswith('win'):
        assert resolve_path('c:\\\\windows\\system32\\myfile') == 'c:\\\\windows\\system32\\myfile'
    else:
        assert resolve_path('/windows/system32/myfile') == '/windows/system32/myfile'



# Generated at 2022-06-22 19:38:04.568899
# Unit test for constructor of class Plugin
def test_Plugin():
    assert Plugin


# Generated at 2022-06-22 19:38:13.968769
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    test_config_manager = ConfigManager()
    test_plugin_type = 'vault'
    test_plugin_name = 'identity'
    test_config_key = 'list_tokens'
    test_value = test_config_manager.get_configuration_definition(test_config_key, plugin_type=test_plugin_type, plugin_name=test_plugin_name)
    assert test_value is not None
    assert test_value.get('choices') == ['True', 'False']
    assert test_value.get('default') is False
    assert test_value.get('type') == 'boolean'
    assert test_value.get('env') is None
    assert test_value.get('ini') is None
    assert test_value.get('yaml') is None
    assert test_value.get

# Generated at 2022-06-22 19:38:24.307158
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    mock_options = MagicMock()
    mock_keys = MagicMock()
    mock_vars = MagicMock()
    mock_defs = MagicMock()
    mock_config = MagicMock(
        get_plugin_options=MagicMock(return_value=mock_options),
        get_configuration_definitions=MagicMock(return_value=mock_defs),
    )
    c = ConfigManager(mock_config)
    res = c.get_plugin_options(mock_options, mock_keys, mock_vars)
    assert res == mock_options
    mock_config.get_plugin_options.assert_called_once_with(mock_options, mock_keys, mock_vars)

# Generated at 2022-06-22 19:38:35.474512
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.SafeConfigParser()
    p.read("test/ansible_ini_config_parser/ansible.cfg")

    # test get value
    assert(get_ini_config_value(p, {'section': 'defaults', 'key': 'host_key_checking'}) == "False")
    assert(get_ini_config_value(p, {'section': 'defaults', 'key': 'empty_key'}) == "")
    assert(get_ini_config_value(p, {'section': 'defaults', 'key': 'not_exist_key'}) is None)
    # test get value from section with no key
    assert(get_ini_config_value(p, {'section': 'ascii_output', 'key': 'not_exist_key'}) is None)


# FIX

# Generated at 2022-06-22 19:38:39.696040
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    assert find_ini_config_file() is None

    with py3compat.tempfile_context(mode='w+b', suffix='.cfg', delete=False) as f:
        assert find_ini_config_file() == f.name



# Generated at 2022-06-22 19:38:48.459562
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():

    # function name 'config_manager' that exists in this file
    config_manager_func = sys._getframe().f_code.co_name
    config_manager_func_nested_func = sys._getframe(1).f_code.co_name

    # config.manager is needed in test_utils.py
    if config_manager_func in sys.modules[__name__].__dict__:
        del sys.modules[__name__].__dict__[config_manager_func]

    # nested function config_manager is needed in test_utils.py
    if config_manager_func_nested_func in sys.modules[__name__].__dict__:
        del sys.modules[__name__].__dict__[config_manager_func_nested_func]

    cm = ConfigManager()
    # redirection of sys

# Generated at 2022-06-22 19:38:51.508990
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    assert isinstance(config.get_configuration_definitions(), dict)
    assert isinstance(config.get_configuration_definitions('default'), dict)
    assert isinstance(config.get_configuration_definitions('default', 'default'), dict)

# Generated at 2022-06-22 19:39:01.063121
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager(None, [])

    types = [
        'connection',
        'module_utils',
        'shell',
        'strategy',
        'lookup',
        'callback',
        'vars',
        'filter',
        'test',
        'cache',
        'httpapi',
        'terminal',
        'connection_plugins',
        'shell_plugins'
    ]

    assert isinstance(config._plugins, dict)
    assert set(config._plugins.keys()) == set(types)


test_ConfigManager()

# Generated at 2022-06-22 19:39:02.585835
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # TODO: implement test
    pass

# Generated at 2022-06-22 19:39:12.647308
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    from ansible.utils.path import makedirs_safe

    def test_cwd(cwd, expected_cfg):
        if os.path.isdir(to_bytes(cwd)):
            os.rmdir(to_bytes(cwd))
        makedirs_safe(cwd, mode=0o700)
        old_cwd = os.getcwd()

# Generated at 2022-06-22 19:39:19.733616
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    config_manager = ConfigManager()
    config_manager.parse()
    assert config_manager.get_config_value('DEFAULT_ANSIBLE_LIBRARY') == '/usr/share/ansible'
    assert config_manager.get_config_value('DEFAULT_ANSIBLE_LIBRARY') == '/usr/share/ansible'
    assert config_manager.get_config_value('DEFAULT_HOST_LIST') == '/etc/ansible/hosts'

# Generated at 2022-06-22 19:39:25.806918
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager()

    assert len(config.data) > 0
    assert len(config.data) == config.data.count()
    assert isinstance(config.data, ConfigData)

    # config files have type set to string and prefixed with CONFIG_FILE_
    for key, val in config.data.iteritems():
        if key.startswith('CONFIG_FILE_'):
            assert val.type == 'string'



# Generated at 2022-06-22 19:39:30.255311
# Unit test for constructor of class Setting
def test_Setting():
    s = Setting('FOO', 'bar', 'magic')
    assert s.value == 'bar'
    assert s.origin == 'magic'

    s.value = 'baz'
    assert s.value == 'baz'

    # Assert that the "name" property is a read-only property
    with pytest.raises(AttributeError):
        s.name = 'bar'


# Generated at 2022-06-22 19:39:40.723908
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    data = """
- hosts: localhost
  tasks:
    - name: test
      shell: echo hello >/tmp/{{ foo }}/hello.txt
      delegate_to: localhost
      check_mode: no
"""
    args = [Argument(connection=DEFAULT_CONNECTION), Argument(inventory=Inventory()) ]
    connection.set_runner(Runner(args, data=data))
    manager = ConfigManager()
    manager.update_config_data(defs=C.configuration_definitions)
    plugin_vars = manager.get_plugin_vars('connection', 'local')
    assert len(plugin_vars) == 0


# Generated at 2022-06-22 19:39:50.529565
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(True, 'boolean') == True
    assert ensure_type('True', 'boolean') == True
    assert ensure_type('False', 'boolean') == False
    assert ensure_type(1, 'integer') == 1
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('1.1', 'float') == 1.1
    assert ensure_type(None, 'none') is None
    assert ensure_type(1, 'none') is None
    assert ensure_type('True', 'none') is None
    assert ensure_type('1', 'none') is None
    assert ensure_type([1, 2], 'none') is None
    assert ensure_type({'a': 1}, 'none') is None
    assert ensure_type(u'/tmp', 'path') == u'/tmp'


# Generated at 2022-06-22 19:39:52.928321
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager(os.devnull)
    config.get_config_value('foo')

# Generated at 2022-06-22 19:39:54.957950
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # TODO: write test for ConfigManager.get_configuration_definition
    pass


# Generated at 2022-06-22 19:39:58.051534
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin_obj = Plugin('/path/to/test/plugins')
    assert plugin_obj._directory == '/path/to/test/plugins'
    assert plugin_obj._module_cache == set()


# Generated at 2022-06-22 19:40:03.975837
# Unit test for constructor of class Setting
def test_Setting():
    s = Setting('CONFIG_FILE', 'DEFAULT_CONFIG_FILE', '', 'string')
    assert s.name == 'CONFIG_FILE'
    assert s.value == 'DEFAULT_CONFIG_FILE'
    assert s.origin == ''
    assert s.type == 'string'
    assert s.value == 'DEFAULT_CONFIG_FILE'

# Unit tests for constructor of class ConfigData

# Generated at 2022-06-22 19:40:10.214329
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path("/tmp/foo.file") == '/tmp/foo.file'         # AbsolutePath
    assert resolve_path("../../tmp/foo.file") == '../../tmp/foo.file'  # RelativePath
    assert resolve_path("~/tmp/foo.file") == os.path.expanduser("~/tmp/foo.file")  # ExpandUserPath


# FIXME: see if this can live in utils/path
# FIXME: this really really needs to be refactored, it's a mess

# Generated at 2022-06-22 19:40:21.223990
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config_manager = ConfigManager()
    config_manager._base_defs = {
        'ANSIBLE_CONFIG': dict(
            env=[dict(name='ANSIBLE_CONFIG')],
            ini=[dict(section='defaults', key='config_file')],
            )
    }

# Generated at 2022-06-22 19:40:24.365365
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # This is not a proper unit test.  Don't use it as an example.
    cm = ConfigManager()
    cm.update_config_data()
    assert 'DEFAULT_STDOUT_CALLBACK' in cm.data.settings
    assert 'STDOUT_CALLBACK' in cm.data.settings
    assert 'STDOUT_CALLBACK' in cm.data.settings


# Generated at 2022-06-22 19:40:26.244676
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    cfg = ConfigManager()
    assert cfg.get_configuration_definitions() == {}

# Generated at 2022-06-22 19:40:29.353468
# Unit test for constructor of class Setting
def test_Setting():
    assert Setting('one', '1', 'place1', defs.BOOL) == {'one': '1', 'place1': defs.BOOL}
