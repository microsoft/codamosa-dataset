

# Generated at 2022-06-22 19:30:29.880660
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():

    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions("test", "test", {"test1":{"required" : False}})


# Generated at 2022-06-22 19:30:35.967719
# Unit test for function get_ini_config_value
def test_get_ini_config_value():

    try:
        import configparser
    except ImportError:
        import ConfigParser as configparser

    buf = "[defaults]\nstring=foo\nlist=1,2,3\n"
    buf += "[plugintype: module_utils.basic]\n_terms=a,b,c\naccelerate=no\nfoo=bar\n"
    buf += "[plugintype: connection]\nlocal=localhost\n"
    buf += "[plugintype: framework]\nfilter_loaded_tasks=True\n"
    buf += "[plugintype: callback]\naction_on_async_poll=continuation\n"
    buf += "[plugintype: module_utils.b_c]\n"
    buf += "[plugintype: callback.yaml]\n"

    p = config

# Generated at 2022-06-22 19:30:41.050601
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    my_fixture = ConfigManager()
    plugin_type = 'shell'
    name = 'foo'
    keys = None
    variables = None
    direct = None
    actual = my_fixture.get_plugin_options(plugin_type, name, keys, variables, direct)
    assert actual == {}

# Generated at 2022-06-22 19:30:49.986830
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type("/path/to/file.ini") == "ini"
    assert get_config_type("/path/to/file.cfg") == "ini"
    assert get_config_type("/path/to/file.yaml") == "yaml"
    assert get_config_type("/path/to/file.yml") == "yaml"
    try:
        get_config_type("/path/to/file.foo")
        assert False, "AnsibleOptionsError not raised"
    except AnsibleOptionsError as e:
        assert str(e) == "Unsupported configuration file extension for /path/to/file.foo: .foo"



# Generated at 2022-06-22 19:30:59.924273
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    '''
    Unit test for method initialize_plugin_configuration_definitions of class ConfigManager.
    '''
    # create the mock configuration file
    config_file = b'[defaults]\n'\
                  b'roles_path = /etc/ansible/roles\n'\
                  b'\n'\
                  b'[inventory]\n'\
                  b'enable_plugins = auto\n'\
                  b'\n'\
                  b'[privilege_escalation]\n'\
                  b'become = True\n'\
                  b'become_method = sudo\n'\
                  b'become_user = root\n'

    # create a temporary file
    temp_file = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    temp

# Generated at 2022-06-22 19:31:10.929729
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    """
        This method unit tests get_config_value_and_origin of class ConfigManager
    """
    configManager = ConfigManager(config_file_path="../ansible_test/ansible.cfg")

# Generated at 2022-06-22 19:31:12.426255
# Unit test for constructor of class Setting
def test_Setting():
    x = Setting('name', 'value', 'src', 'str')
    return x


# Generated at 2022-06-22 19:31:15.674283
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    cm = ConfigManager()

    # NOTE: the argument to this function is not a real config setting, just a mock
    value, origin = cm.get_config_value_and_origin('foo')
    assert value == None
    assert origin == None



# Generated at 2022-06-22 19:31:28.447199
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    '''
    This function will test the find_ini_config_file function. For this test
    to work the home directory for the user running the test must be writable.

    This test will only be ran if the ANSIBLE_CONFIG env var is not set and
    no ansible.cfg.

    NOTE: This test is not very robust, we're just trying to ensure that the
    correct file is chosen.
    '''
    path = find_ini_config_file()
    if os.getenv("ANSIBLE_CONFIG", None) is None and path is None:

        # Create an ansible.cfg
        current_dir = os.getcwd()
        ansible_cfg = os.path.join(current_dir, 'ansible.cfg')
        with open(ansible_cfg, 'a'):
            os.utime

# Generated at 2022-06-22 19:31:36.056359
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    # test the base_defs and plugin_defs parsing
    from ansible.config.manager import ConfigManager
    from ansible.config.manager import ConfigManagerParser

    # base class for parsing config file
    class BaseParser(ConfigManagerParser):

        def __init__(self, config_file):
            super(BaseParser, self).__init__(config_file)

            self.config = {}

            self.valid_sections = ['defaults', 'system_install']
            self.valid_keys = None

        def parse(self):
            # load values from file into self.config
            pass

        def _get_config_value(self, section, key, value, origin=None, vars=None):
            ''' return the value, converted to the correct type '''

            # assume value is string and convert to type

# Generated at 2022-06-22 19:31:39.310926
# Unit test for function resolve_path
def test_resolve_path():
    ''' return True if a path is absolute '''
    path_list = os.path.abspath("/tmp/foo")
    if path_list:
        assert True
    else:
        assert False

# Generated at 2022-06-22 19:31:44.792279
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    mgr = ConfigManager()

    defs = mgr.get_configuration_definitions(ignore_private=True)
    assert isinstance(defs, dict)
    assert len(defs) > 0

    # try plugins
    defs = mgr.get_configuration_definitions("callback", ignore_private=True)
    assert isinstance(defs, dict)
    assert len(defs) > 0

    # try plugin
    defs = mgr.get_configuration_definitions("callback", "debug", ignore_private=True)
    assert isinstance(defs, dict)
    assert len(defs) > 0


# Generated at 2022-06-22 19:31:45.892787
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    assert ConfigManager()

# Generated at 2022-06-22 19:31:52.666734
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    a = '''
    '''
    b = '''
    '''
    c = '''
    '''
    global_namespace['a'] = a
    global_namespace['b'] = b
    global_namespace['c'] = c
    config_manager = ConfigManager(None)
    # TODO: Write unit test
    assert False


# Generated at 2022-06-22 19:31:59.393187
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    defs = get_configuration_definitions()
    parser = CmdLineParser(module_name='foo', module_args={'bar': 'baz'}).parse()
    try:
        config_manager = ConfigManager(module_args=parser).update_config_data(defs=defs)
    except AnsibleError as e:
        print(e)
        assert False
    assert type(config_manager.data) == ConfigData


# Generated at 2022-06-22 19:32:03.319343
# Unit test for constructor of class Plugin
def test_Plugin():
    test_display = Display()
    test_config = ConfigManager(options=Options(), config_file=CONFIG_FILE, usage='test', display=test_display)
    assert test_display == test_config.display


# Generated at 2022-06-22 19:32:09.788253
# Unit test for function get_ini_config_value
def test_get_ini_config_value():

    config = configparser.ConfigParser(allow_no_value=True)
    config.add_section('defualts')
    config.set('defualts', 'foo', 'bar')
    assert get_ini_config_value(config, {'key': 'foo'}) == 'bar'

    config = configparser.ConfigParser(allow_no_value=True)
    config.add_section('defualts')
    config.set('defualts', 'foo', 'bar')
    assert get_ini_config_value(config, {'key': 'foo', 'section': 'defualts'}) == 'bar'

    config = configparser.ConfigParser(allow_no_value=True)
    config.add_section('defualts')
    config.set('defualts', 'foo', 'bar')
    assert get

# Generated at 2022-06-22 19:32:19.881292
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    """
    Test case for 'get_plugin_vars' of class 'ConfigManager'.
    """
    # Create an instance of ConfigManager
    obj = ConfigManager()

    # Create mock arguments
    plugin_type = MagicMock(spec=str)
    name = MagicMock(spec=str)

    obj.get_configuration_definition = MagicMock()
    obj.get_configuration_definitions = MagicMock(return_value={'a':'b'})

    # Invoke method
    result = obj.get_plugin_vars(plugin_type, name)

    # Tests
    assert result == ['a']
##### Unit test for method get_plugin_options of class ConfigManager

# Generated at 2022-06-22 19:32:29.041997
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    def1 = { 'foo': {'default': 'hello', 'env': [{'name': 'FOO'}]}}
    def2 = { 'bar': {'default': 'world'}}
    def3 = { 'foo': {'default': 'bye'}}

    if sys.version_info >= (3,):
        py2_env = copy.copy(os.environ)
        py2_env[b'FOO'] = b'bar'
        with patch.object(py3compat.environ, 'copy', return_value=py2_env):
            cm = ConfigManager(def1)
            cm.update_config_data(def2)
            cm.update_config_data(def3)
            assert cm.data['foo'] == 'bar'
            assert cm.data['bar'] == 'world'

# Generated at 2022-06-22 19:32:32.622099
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    assert 'vault_password_file' in config.get_plugin_vars(u'vars', u'vault')


# Generated at 2022-06-22 19:32:34.587580
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    assert isinstance(ConfigManager().get_configuration_definitions(), dict)


# Generated at 2022-06-22 19:32:35.784189
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    pass


# Generated at 2022-06-22 19:32:45.089150
# Unit test for function ensure_type
def test_ensure_type():
    ''' ensure_type() should convert strings to the correct data types '''
    assert ensure_type('foo', 'str') == 'foo'
    assert ensure_type('foo', 'string') == 'foo'
    assert ensure_type('foo', 'none') is None
    assert ensure_type('foo', 'path') == 'foo'
    assert ensure_type('foo', 'list') == ['foo']
    assert ensure_type('true', 'boolean') is True
    assert ensure_type('false', 'boolean') is False
    assert ensure_type('3', 'integer') == 3
    assert ensure_type('3.1', 'float') == 3.1

    try:
        ensure_type('foo', 'integer')
    except Exception:
        pass
    else:
        raise Exception('Type conversion did not raise an exception')




# Generated at 2022-06-22 19:32:55.374940
# Unit test for function ensure_type
def test_ensure_type():
    # Test ensure_type's boolean value handling
    if ensure_type("True", "bool") != True or \
       ensure_type("False", "bool") != False or \
       ensure_type("yes", "bool") != None or \
       ensure_type("no", "bool") != None:
        raise ValueError("bool type not handled correctly")
    # Test ensure_type's integer value handling
    if ensure_type("99", "int") != 99 or \
       ensure_type("0", "int") != 0 or \
       ensure_type("100", "int") != 100:
        raise ValueError("int type not handled correctly")
    # Test ensure_type's string value handling

# Generated at 2022-06-22 19:32:59.277737
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    Test method get_config_value_and_origin
    '''
    cm = ConfigManager()
    assert cm.get_config_value_and_origin("ANSIBLE_RETRY_FILES_ENABLED") == (True, "default")

# Generated at 2022-06-22 19:33:02.479140
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
   test_obj = ConfigManager()
   assert id(test_obj) != 0


# Generated at 2022-06-22 19:33:08.541057
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():

    # Test no parameters
    c = ConfigManager()

    # Test empty parameter
    c = ConfigManager('')

    # Test two parameters
    c = ConfigManager('', '')

    # Test three parameters
    c = ConfigManager('', '', '')

    # Test valid parameters
    c = ConfigManager(DEFAULTS, CONFIG_FILE)


# Generated at 2022-06-22 19:33:20.878521
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    ansible = Mock()
    ansible.config = Config()

# Generated at 2022-06-22 19:33:25.162734
# Unit test for constructor of class Setting
def test_Setting():
    s = Setting('FOO', 'bar', 'default', 'string')
    assert s.name == 'FOO'
    assert s.value == 'bar'
    assert s.origin == 'default'
    assert s.string_type == 'string'


# Generated at 2022-06-22 19:33:29.935278
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # Note: This test method cannot be executed at present as the method depends on
    #       other methods that do not yet exist in a testable form.  This method
    #       is here to serve as a place holder for when the other methods are
    #       available.
    pass

# Generated at 2022-06-22 19:33:34.124354
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    plugin_type = 'str'
    name = 'str'
    # Execute the code to be tested
    config_manager = ConfigManager()
    config_manager.get_plugin_vars(plugin_type, name)
    assert False # TODO: implement your test here


# Generated at 2022-06-22 19:33:37.314794
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    assert find_ini_config_file() is None

# FIXME: use INI code from module_utils?

# Generated at 2022-06-22 19:33:46.844781
# Unit test for function resolve_path
def test_resolve_path():
    # test that resolve_path(path) matches the behaviour of os.path.abspath(path)
    # and that resolve_path(path, basedir) matches the behaviour of os.path.join(basedir, path) when path is a relative path
    for (path, basedir) in [('', None),
                            ('/usr/bin/python', None),
                            ('python', '/usr/bin'),
                            ('python', '/usr/bin/')
                            ]:
        assert resolve_path(path, basedir) == os.path.abspath(path)
        assert resolve_path(os.path.join(path, 'python'), basedir) == os.path.abspath(os.path.join(path, 'python'))

    # test that if path is an absolute path, it returns the path unchanged and can

# Generated at 2022-06-22 19:33:59.325035
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    from ansible.playbook.play import Play

    defs = dict(
        a=dict(
            default='a',
            type='string',
            env=[dict(name='ANSIBLE_A')],
        ),
        b=dict(
            default='b',
            type='string',
            env=[dict(name='ANSIBLE_B')],
        ),
    )
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('test', 'test', defs)

    # test using a dict
    os.environ['ANSIBLE_A'] = 'a_from_env'
    os.environ['ANSIBLE_B'] = 'b_from_env'

# Generated at 2022-06-22 19:34:08.558648
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # create sample data
    cfile = './test/unittests/test_runner/test_config.ini'
    plugin_type = 'con'
    plugin_name = 'test'
    config = 'configfile'
    variables = {'testvar': 'testvalue'}
    direct = {'configfile': './test/unittests/test_runner/test_config.ini'}

    # create a ConfigManager object and get the value and origin
    cm = ConfigManager()
    cm.get_config_value_and_origin(config, cfile=cfile, plugin_type=plugin_type, plugin_name=plugin_name, variables=variables, direct=direct)

    # Get the value from ConfigManager object

# Generated at 2022-06-22 19:34:13.607737
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = ''
    name = ''
    defs = {}
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)

# Generated at 2022-06-22 19:34:16.817061
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    defs = None
    configfile = None
    cm = ConfigManager()
    cm.update_config_data(defs=defs, configfile=configfile)


# Generated at 2022-06-22 19:34:26.749478
# Unit test for function resolve_path

# Generated at 2022-06-22 19:34:30.020319
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager

# Generated at 2022-06-22 19:34:42.672314
# Unit test for function get_config_type
def test_get_config_type():
    # Test for unsupported file extensions
    try:
        get_config_type('test.txt')
        assert False
    except AnsibleOptionsError:
        assert True

    try:
        get_config_type('test.vault')
        assert False
    except AnsibleOptionsError:
        assert True

    try:
        get_config_type('test.j2')
        assert False
    except AnsibleOptionsError:
        assert True

    # Test for supported file extensions
    assert get_config_type('test.ini') == 'ini'
    assert get_config_type('test.cfg') == 'ini'
    assert get_config_type('test.yaml') == 'yaml'
    assert get_config_type('test.yml') == 'yaml'



# Generated at 2022-06-22 19:34:46.006839
# Unit test for constructor of class Setting
def test_Setting():
    s = Setting('test_name', 'test_value', 'test_origin', 'test_type')
    assert s.name == 'test_name'
    assert s.value == 'test_value'
    assert s.origin == 'test_origin'
    assert s.type == 'test_type'


# Generated at 2022-06-22 19:34:50.623481
# Unit test for constructor of class Plugin
def test_Plugin():
    p = Plugin('name', 'path', 'doc', 'info', {}, {}, {}, {}, {})
    assert p.name == 'name'
    assert p.path == 'path'
    assert p.doc == 'doc'
    assert p.info == 'info'
    assert p.subdirs == {}
    assert p.plugins == {}
    assert p.aliases == {}
    assert p.submodules == {}
    assert p.subclasses == {}


# Generated at 2022-06-22 19:35:02.842007
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    o = ConfigManager()
    o.get_config_value('awx_job_timeout')

    o = ConfigManager()
    o.get_config_value('display_skipped_hosts')

    o = ConfigManager()
    o.get_config_value('display_ok_hosts')

    o = ConfigManager()
    o.get_config_value('callback_plugins')

    o = ConfigManager()
    o.get_config_value('any_errors_fatal')

    o = ConfigManager()
    o.get_config_value('host_key_checking')

    o = ConfigManager()
    o.get_config_value('host_key_auto_add')

    o = ConfigManager()
    o.get_config_value('sudo_flags')

    o = ConfigManager()
    o.get_

# Generated at 2022-06-22 19:35:11.259255
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    if sys.version_info < (2, 7):
        return

    from ansible.module_utils.six.moves.mock import patch

    # We're patching a lot of functions in this test, so let's just do it once
    with patch('ansible.config.Config.find_ini_config_file') as m_ficf:
        m_ficf.return_value = None

        # Test 1: No ANSIBLE_CONFIG
        warnings = set()
        path = Config.find_ini_config_file(warnings=warnings)
        assert path is None
        # TODO: Add a test case where we're in a world-writable directory

        # Test 2: ANSIBLE_CONFIG is set and is a directory
        with patch('os.getenv') as m_ge:
            m_

# Generated at 2022-06-22 19:35:22.806410
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    return config.get_configuration_definition('HOST_KEY_CHECKING') == {'default': True, 'ini': [{'key': 'host_key_checking', 'section': 'defaults', 'vars': []}], 'env': [{'name': 'ANSIBLE_HOST_KEY_CHECKING', 'section': 'defaults', 'vars': []}], 'cli': [{'cli': 'host-key-checking', 'env': 'ANSIBLE_HOST_KEY_CHECKING', 'ini': 'host_key_checking', 'vars': [{'name': 'ansible_host_key_checking'}], 'section': 'defaults'}], 'vars': [{'name': 'ansible_host_key_checking'}], 'type': 'boolean'}
# Unit test

# Generated at 2022-06-22 19:35:31.467060
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    """
    This is an auto-generated unittest for method get_config_value
    of class ConfigManager in module ansible.config.manager.
    """
    try:
        import ConfigParser
    except ImportError:
        import configparser as ConfigParser

    config = ConfigManager()
    configfile = os.path.join(os.path.dirname(__file__), 'test_default.cfg')
    config._parse_config_file(configfile)

    defs = config._base_defs

    for config in defs:
        actual = config.get_config_value(config, defs=defs, configfile=configfile)
        parser = ConfigParser.SafeConfigParser()
        parser.read(configfile)

# Generated at 2022-06-22 19:35:34.996776
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    defs = None
    configfile = None
    configManager = ConfigManager()
    configManager.update_config_data(defs, configfile)
    # No exception thrown, so success

# Generated at 2022-06-22 19:35:39.752714
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    c = ConfigManager()
    c._parse_config_file('/debian_config')
    c.initialize_plugin_configuration_definitions(plugin_type='module', name='apt', defs={'some_setting': {'default': True, 'type': 'bool', 'env': [{'name': 'ANSIBLE_APT_SOME_SETTING'}]}})
    assert c.get_plugin_options('module', 'apt') == {'some_setting': True}


# Generated at 2022-06-22 19:35:40.800658
# Unit test for constructor of class Setting
def test_Setting():
    pass


# Generated at 2022-06-22 19:35:53.113069
# Unit test for function ensure_type
def test_ensure_type():
    assert '2' == ensure_type('2', 'string')
    assert '2' == ensure_type(2, 'string')
    assert '2' == ensure_type('2', None)
    assert '2' == ensure_type(2, None)
    assert 2 == ensure_type('2', 'integer')
    assert 2.0 == ensure_type('2', 'float')
    assert 2 == ensure_type(2, 'integer')
    assert 2.0 == ensure_type(2, 'float')
    assert 2 == ensure_type('2', None)
    assert 2.0 == ensure_type('2', None)
    assert 2 == ensure_type(2, 'integer')
    assert 2.0 == ensure_type(2, 'float')
    assert True is ensure_type('True', 'boolean')

# Generated at 2022-06-22 19:36:01.155499
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    """ Test the get_ini_config_value function """
    fake_p = configparser.ConfigParser(strict=False)
    config_file_path = os.path.join(os.path.dirname(__file__), '../../../test/sanity/code/syntax-error-config.cfg')
    config_file_path = os.path.normpath(config_file_path)
    fake_p.read(config_file_path)
    assert isinstance(get_ini_config_value(fake_p, {'section': 'defaults', 'key': 'action_plugins'}), str)



# Generated at 2022-06-22 19:36:07.508965
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type("test.ini") == 'ini'
    assert get_config_type("test.cfg") == 'ini'
    assert get_config_type("test.yaml") == 'yaml'
    assert get_config_type("test.yml") == 'yaml'
    assert get_config_type("test.txt") == 'yaml'
    try:
        get_config_type("test.txt") == 'yaml'
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-22 19:36:12.561808
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()
    test_plugin_type = "test"
    test_plugin_name = "test"
    test_name = "test"
    result = config_manager.get_configuration_definition(test_name, test_plugin_type, test_plugin_name)
    assert not result


# Generated at 2022-06-22 19:36:18.241013
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = ConfigManager(None, '/etc/ansible/ansible.cfg')
    assert cm.get_config_value('ansible_managed') == '#####'
    assert cm.get_config_value('nonsense') == None


# Generated at 2022-06-22 19:36:24.510305
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    cm = ConfigManager()
    assert cm is not None
    assert cm.data is not None
    assert cm._base_defs is not None
    assert cm._config_file is not None
    assert cm._parsers is not None
    assert cm._plugins is not None
    assert cm.get_config_file()
    assert cm.get_config_file()

# Generated at 2022-06-22 19:36:26.548837
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():

    assert config.get_configuration_definition('DEFAULT_FORKS')['default'] == 5


# Generated at 2022-06-22 19:36:39.123753
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # We need to initialize some default object for config_manager
    # Since there is no real config file, let's just do it manually
    # FIXME: This is a workaround and needs to be updated to be cleaner
    config_manager = config_manager_class()
    config_manager._config_file = 'test_ansible.cfg'

    # The config file defaults (config_manager._base_defs) contains the default
    # values for the config manager.
    # But since we have no config file, we must add them manually
    config_manager._base_defs['DEFAULT_MODULE_NAME'] = {
        'default': 'command',
        'type': 'string',
        'env': [{'name': 'ANSIBLE_DEFAULT_MODULE_NAME'}]
    }

# Generated at 2022-06-22 19:36:42.330951
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    c = ConfigManager()
    assert c.get_plugin_vars('shell', 'powershell') == ['ansible_shell_type']


# Generated at 2022-06-22 19:36:45.308204
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_mgr = ConfigManager()
    config_mgr.get_configuration_definition('DEFAULT_HOST_LIST')



# Generated at 2022-06-22 19:36:55.342412
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():

    #def test_ConfigManager_get_config_value(self):
    ######################################################################################################################
    #  Initialize
    ######################################################################################################################
    config_manager = ConfigManager()
    config_manager._config_file = '../config/ansible.cfg'

# Generated at 2022-06-22 19:36:58.267808
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    m = ConfigManager()


# Generated at 2022-06-22 19:37:08.898305
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    entry = {'section': 'defaults', 'key': 'foo'}
    assert get_ini_config_value(p, entry) is None
    p.add_section('defaults')
    p.set('defaults', 'foo', 'bar')
    assert get_ini_config_value(p, entry) == 'bar'
    p.set('defaults', 'foo', 'baz')
    assert get_ini_config_value(p, entry) == 'baz'
    # check that we don't find a section that doesn't exist
    entry = {'section': 'bogus', 'key': 'foo'}
    assert get_ini_config_value(p, entry) is None
    p.add_section('bogus')

# Generated at 2022-06-22 19:37:20.231014
# Unit test for function get_config_type
def test_get_config_type():
    """
    Test for get_config_type
    """

    # Loop through all files in the test directory, if the file ends in
    # in '.ini|.yaml|.yml', then it is a test case.  Otherwise, it is a
    # file that should be sharded.
    this_dir, this_filename = os.path.split(__file__)
    test_dir = os.path.join(this_dir, 'lib', 'ansible', 'config', 'data')

    for fname in os.listdir(test_dir):
        test_file = os.path.abspath(os.path.join(test_dir, fname))
        if not os.path.isfile(test_file):
            continue

        test_case = os.path.splitext(fname)[-1]


# Generated at 2022-06-22 19:37:33.877863
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    # Unit test for constructor of class ConfigManager
    from ansible.module_utils._text import to_bytes

    config_manager = ConfigManager()

    # When
    result = config_manager.get_config_value('WARNINGS')

    # Then
    assert isinstance(result, set)
    assert len(result) == 0

    # When
    result = config_manager.get_config_value('DEFAULT_LOG_PATH')

    # Then
    assert isinstance(result, string_types)
    assert result == './ansible.log'

    # When
    result = config_manager.get_config_value('CACHE_PLUGIN')

    # Then
    assert isinstance(result, string_types)
    assert result == 'jsonfile'

    # When
    result = config_manager.get_config_value

# Generated at 2022-06-22 19:37:34.989691
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_manager = ConfigManager(None)
    assert config_manager

# Generated at 2022-06-22 19:37:43.193321
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    x = ConfigManager(infile=['x.yml', 'y.yml'], config_defs=dict(a='path', b='bool'))
    cfg = dict(a='x', b=True)
    x.update_config_data(cfg, 'configfile')
    assert x.data.a == 'x' and x.data.b is True
    cfg = dict(a='y', b=True)
    x.update_config_data(cfg, 'configfile')
    assert x.data.a == 'y' and x.data.b is True
    cfg = dict(a='z', b=False)
    x.update_config_data(cfg, 'configfile')
    assert x.data.a == 'z' and x.data.b is False
    x.update_config_

# Generated at 2022-06-22 19:37:49.312766
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    _config_manager = ConfigManager()
    _plugin_type = None
    _plugin_name = None
    _ignore_private = False
    _output = _config_manager.get_configuration_definitions(_plugin_type, _plugin_name, _ignore_private)
    print(_output)

# Generated at 2022-06-22 19:37:53.876834
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    import os

    cm = ConfigManager()
    cm.update_config_data(DEFAULT_CONFIG_DATA)
    ansible_vault_password_file = './passwordfile'
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = ansible_vault_password_file
    ret = cm.get_config_value_and_origin('vault_password_file')



# Generated at 2022-06-22 19:37:58.781542
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    assert config.get_configuration_definitions()
    assert config.get_configuration_definitions("any_plugin_type")
    assert config.get_configuration_definitions("any_plugin_type", "any_plugin_name")
    assert config.get_configuration_definitions("any_plugin_type", "any_plugin_name", ignore_private=True)


# Generated at 2022-06-22 19:38:00.201039
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    assert True


# Generated at 2022-06-22 19:38:08.851754
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    cm = ConfigManager()
    test_config = 'DEFAULT_HOST_LIST'
    result = cm.get_configuration_definition(test_config)
    expected = {'default': DEFAULT_HOST_LIST, 'ini': [{'key': None, 'section': 'defaults', 'vars': None}], 'env': [{'name': 'ANSIBLE_HOSTS', 'vars': None}], 'name': 'DEFAULT_HOST_LIST', 'vars': None, 'type': 'path', 'ini_details': {'section': 'defaults', 'key': None}}
    assert result == expected, "Expected {}, got {}".format(expected, result)
    test_config = 'FOOBAR'
    result = cm.get_configuration_definition(test_config)
    expected = None
   

# Generated at 2022-06-22 19:38:14.611557
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    manager = ConfigManager()
    assert manager.get_configuration_definition("host_key_checking") == {'default': True, 'env': [{'name': 'ANSIBLE_HOST_KEY_CHECKING'}], 'ini': [{'key': 'host_key_checking', 'section': 'defaults'}], 'type': 'boolean', 'choices': ['True', 'False'], 'descr': 'enable additional SSH security by checking host keys (no/false/0 = disabled, yes/true/1 = enabled)'}

# Generated at 2022-06-22 19:38:25.818950
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    from ansible.module_utils.common._collections_compat import Mapping
    configManager = ConfigManager()
    # init config
    # plugin_type, name, defs
    plugin_type = 'module'
    name = 'shell'

# Generated at 2022-06-22 19:38:35.780551
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # initialize a ConfigManager object
    configmanager = ConfigManager()

    # set defs to a dict that contains the data for test

# Generated at 2022-06-22 19:38:41.130737
# Unit test for function ensure_type
def test_ensure_type():
    # Testing None
    assert ensure_type(None, 'none') is None
    assert ensure_type(None, 'boolean') is None
    assert ensure_type(None, 'integer') is None
    assert ensure_type(None, 'float') is None
    assert ensure_type(None, 'list') is None
    assert ensure_type(None, 'path') is None
    assert ensure_type(None, 'tmppath') is None
    assert ensure_type(None, 'pathlist') is None
    assert ensure_type(None, 'pathspec') is None
    assert ensure_type(None, 'string') is None
    # Testing empty string
    assert ensure_type('', 'none') is None
    assert ensure_type('', 'boolean') is None
    assert ensure_type('', 'integer') == 0
    assert ensure

# Generated at 2022-06-22 19:38:52.439587
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # Test if a new constant was created for the config file and for the
    # value and origin of the config.
    # This test is over complicated because ConfigManager has become so complex
    # and is riddled with side effects. The config data is originally populated
    # from DEFAULTS in the constructor.
    # We need to restore this data to its original state before calling the
    # method we want to test, otherwise the test will fail because the wrong
    # value for CONFIG_FILE (blank) is in the config data.
    # The easiest way to do this is to make a new ConfigManager, get its data,
    # and then call the method we want to test using that config data.
    # If a side effect of the method later changes the config data, this test
    # will fail, or cause subsequent tests to fail elsewhere.

    # setup
    config_manager = Config

# Generated at 2022-06-22 19:39:04.193643
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # We're going to monkeypatch os.path.exists and os.access,
    # so we need to save the original functions
    old_path_exists = os.path.exists
    old_path_access = os.access


# Generated at 2022-06-22 19:39:07.328298
# Unit test for function resolve_path
def test_resolve_path():
    path = "./test_dir"
    basedir = ""
    assert resolve_path(path, basedir) == path

# FIXME: this appears to be unused

# Generated at 2022-06-22 19:39:08.789439
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # TODO: Write unit test
    raise NotImplementedError()

# Generated at 2022-06-22 19:39:14.822490
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('callback', 'json', {})
    configfile = '/home/cgibson/.ansible/cfg/ansible.cfg'
    defs = {}
    result = cm.get_config_value('json_indent', configfile, 'callback', 'json', defs)
    # assert result == 4
    return result


# Generated at 2022-06-22 19:39:18.465814
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # TODO: add unit test
    # ansible.parsing.config.manager.ConfigManager.get_configuration_definition()
    pass


# Generated at 2022-06-22 19:39:24.671420
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    # We should not do a full init of config manager, but
    # test only the constructor
    config_manager = ConfigManager()
    # FIXME: how to test the constructor?
    assert config_manager._config_file == os.path.expanduser('~/.ansible.cfg'), \
        'wrong '.format(config_manager._config_file)
    # FIXME: test if all other attributes have been initialized properly


# Generated at 2022-06-22 19:39:28.711261
# Unit test for constructor of class Setting
def test_Setting():
    tst = Setting('ANSIBLE_STDOUT_CALLBACK', 'debug', 'config file', 'string')
    assert tst.name == 'ANSIBLE_STDOUT_CALLBACK'
    assert tst.value == 'debug'
    assert tst.origin == 'config file'
    assert tst.type == 'string'



# Generated at 2022-06-22 19:39:37.695951
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    print("get_config_value_and_origin")
    # Test with empty class
    my_object = ConfigManager()
    try:
        my_object.get_config_value_and_origin("whatever")
    except AttributeError:
        pass
    except Exception as err:
        assert False, "unexpected exception %s %s" % (type(err), err)
    else:
        assert False, "expected exception not raised"
    # Test with old-style class
    ansible = BaseManager()
    ansible.get_config_value_and_origin("whatever")
    # Test with new-style class
    config_manager = ConfigManager()
    try:
        config_manager.get_config_value_and_origin("whatever")
    except AnsibleOptionsError:
        pass

# Generated at 2022-06-22 19:39:49.109740
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    C = ConfigManager()
    #
    # plugin name empty
    #
    assert C.get_config_value('ANSIBLE_LOG_PATH') == b'/var/log/ansible.log'
    assert C.get_config_value('ANSIBLE_CONFIG') == '/etc/ansible/ansible.cfg'
    assert C.get_config_value('ANSIBLE_DEBUG') == False
    assert C.get_config_value('ANSIBLE_CALLBACK_PLUGINS') == '/usr/lib/python2.7/dist-packages/ansible/plugins/callback:/root/.ansible/plugins/callback:/etc/ansible/plugins/callback'

# Generated at 2022-06-22 19:39:51.166691
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    f = config.get_configuration_definition('INVENTORY')
    assert f['type'] == 'url'



# Generated at 2022-06-22 19:39:54.045808
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    # FIXME: mock options

    config_manager = ConfigManager()
    config_manager.get_plugin_options('name', '')



# Generated at 2022-06-22 19:40:04.730552
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # set up test case
    from ansible.config import ConfigManager, Setting
    test_config_manager = ConfigManager()
    test_config_manager.config_file = 'foobar'
    test_config_manager._base_defs = {
        'TEST_1': {
            'default': 'test_1_default',
            'type': 'string',
            'required': False
        },
        'TEST_2': {
            'default': 'test_2_default',
            'type': 'string',
            'required': False
        },
    }
    test_config_manager._parsers = {}
    test_data = DefaultVars()

    # try with empty args
    test_config_manager.update_config_data()

# Generated at 2022-06-22 19:40:11.119129
# Unit test for function find_ini_config_file
def test_find_ini_config_file():

    cwd = os.getcwd()
    unittestdir = os.path.dirname(sys.modules['__main__'].__file__)

    old_env = os.environ.get("ANSIBLE_CONFIG", SENTINEL)
    os.environ["ANSIBLE_CONFIG"] = "/does/not/exist/ansible.cfg"
    assert find_ini_config_file() is None

    # Set the ANSIBLE_CONFIG env var to the ansible.cfg in the tests directory
    os.environ["ANSIBLE_CONFIG"] = os.path.join(unittestdir, "data", "ansible.cfg")
    assert find_ini_config_file() == os.path.join(unittestdir, "data", "ansible.cfg")

    # Put an ansible.cfg in

# Generated at 2022-06-22 19:40:19.268350
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    config._base_defs = {'ANSIBLE_LOG_PATH': {'default': 'null', 'env': [{'name': 'ANSIBLE_LOG_PATH'}]}}
    config.get_configuration_definition('ANSIBLE_LOG_PATH')
    assert config._base_defs == {'ANSIBLE_LOG_PATH': {'default': 'null', 'env': [{'name': 'ANSIBLE_LOG_PATH'}]}}


# Generated at 2022-06-22 19:40:31.255544
# Unit test for function get_config_type
def test_get_config_type():
    # file with ini extension
    assert get_config_type('/path/to/file.ini') == 'ini'
    # file with cfg extension
    assert get_config_type('/path/to/file.cfg') == 'ini'
    # file with yml extension
    assert get_config_type('/path/to/file.yml') == 'yaml'
    # file with yaml extension
    assert get_config_type('/path/to/file.yaml') == 'yaml'
    # file with no extension
    assert get_config_type('/path/to/file') == None
    # file with unknown extension