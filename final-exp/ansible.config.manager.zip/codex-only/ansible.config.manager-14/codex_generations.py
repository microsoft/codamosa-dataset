

# Generated at 2022-06-22 19:30:30.990453
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    '''
    Tested as part of test_config().
    '''
    pass


# FIXME: can move to module_utils for use for ini plugins also?

# Generated at 2022-06-22 19:30:34.732366
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('foo.ini') == 'ini'
    assert get_config_type('foo.cfg') == 'ini'
    assert get_config_type('foo.yml') == 'yaml'
    assert get_config_type('foo.yaml') == 'yaml'
    try:
        get_config_type('foo.bar')
        assert False, "Expecting exception"
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-22 19:30:47.264622
# Unit test for constructor of class Setting
def test_Setting():
    # test construction
    setting = Setting('FOO', 'baR', 'origin', 'string')
    assert setting.name == 'FOO'
    assert setting.value == 'baR'
    assert setting.origin == 'origin'
    assert setting.type == 'string'
    # test repr
    assert repr(setting) == 'Setting(FOO, baR, origin, string)'
    # test typing
    setting.value = u'\u0128'
    assert isinstance(setting.value, text_type)
    setting.type = 'bytes'
    assert isinstance(setting.value, binary_type)
    # test equality
    assert setting == Setting('FOO', u'\u0128', 'origin', 'bytes')
    assert setting != Setting('FOO', 'baR', 'origin', 'bytes')

# Generated at 2022-06-22 19:30:48.914906
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    with pytest.raises(NotImplementedError):
        ConfigManager.get_configuration_definition()

# Generated at 2022-06-22 19:30:54.486486
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    module = AnsibleModule(
        argument_spec = dict(
            var_name = dict(required=True, type='str')
        )
    )
    if not HAS_YAML or not HAS_INIPARSE or not HAS_INI_READER:
        module.fail_json(msg='missing required imports')
    cm = ConfigManager()
    # get_plugin_vars()
    module.exit_json(changed=False, var_name=cm.get_plugin_vars(module.params['var_name'], module.params['var_name']))

# Generated at 2022-06-22 19:31:01.477338
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('test.ini') == 'ini'
    assert get_config_type('test.cfg') == 'ini'
    assert get_config_type('test.yaml') == 'yaml'
    assert get_config_type('test.yml') == 'yaml'
    assert get_config_type('test.txt') == None
    assert get_config_type('test') == None



# Generated at 2022-06-22 19:31:11.673946
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    from ansible.parsing.splitter import split_args

    # explicitly load the config, since it's not usually available for unit tests
    config = ConfigManager()

    # Test parsing of config
    defs = config._base_defs
    assert 'DEFAULT_PRIVATE_KEY_FILE' in defs
    assert 'DEFAULT_PRIVATE_KEY_FILE' in config.data.keys()

    # Test parsing of config to split_args
    args = split_args('some_module -a arg1 arg2 -b arg3 arg4', posix=False)
    assert 'arg1 arg2' in args.get('_raw_args')
    assert 'arg3 arg4' in args.get('_raw_args')

# Generated at 2022-06-22 19:31:19.624138
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type("4.2", "float") == 4.2
    assert ensure_type("4", "float") == 4.0
    assert ensure_type("4.2", "int") == 4
    assert ensure_type("4", "str") == "4"
    assert ensure_type(["item1"], "str") == "['item1']"
    assert ensure_type(None, "dict") is None


# Generated at 2022-06-22 19:31:29.587680
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/etc/hosts') is None
    assert get_config_type('/root/file.yaml') == 'yaml'
    assert get_config_type('/root/file.yml') == 'yaml'
    assert get_config_type('/root/file.ini') == 'ini'
    assert get_config_type('/root/file.cfg') == 'ini'
    try:
        assert get_config_type('/root/file.foo') == 'ini'
    except AnsibleError:
        pass
    else:
        raise Exception("should have failed for extension .foo")



# Generated at 2022-06-22 19:31:35.078201
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    test_value = get_ini_config_value('foo',
                                      {'section': 'bar', 'key': 'hello'})
    assert test_value is None

# FIXME: need to ensure that builtin defaults are correct
# FIXME: standardize on from_file and from_ini

# Generated at 2022-06-22 19:31:42.018934
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = ConfigManager('/dev/null')
    env_var_name = 'ANSIBLE_TEST_GET_CONFIG_VALUE'
    env_var_value = 'env_var_value'
    py3compat.environ[env_var_name] = env_var_value

    def _cleanup_env():
        if env_var_name in py3compat.environ:
            del py3compat.environ[env_var_name]

    def _test_for_value_and_origin(value, origin):
        assert cm.get_config_value_and_origin('env_var') == (value, origin)


# Generated at 2022-06-22 19:31:48.864252
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    parser = argparse.ArgumentParser()
    manager = ConfigManager(parser)
    config = "_deprecated"
    cfile = None
    plugin_type = "lookup"
    plugin_name = "password"
    keys = None
    variables = {u'_deprecated': u'foo'}
    direct = None
    manager.get_config_value_and_origin(config, cfile=cfile, plugin_type=plugin_type, plugin_name=plugin_name, keys=keys, variables=variables, direct=direct)
    
    
    
    
    

# Generated at 2022-06-22 19:31:49.646399
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    assert True

# Generated at 2022-06-22 19:31:53.110147
# Unit test for constructor of class Setting
def test_Setting():

    t = Setting(config_name, config_value, origin)
    assert t.name == config_name
    assert t.origin == origin
    assert t.value == config_value



# Generated at 2022-06-22 19:31:55.802488
# Unit test for constructor of class Plugin
def test_Plugin():
    ''' unit test for Plugin class '''
    plugin = Plugin()

    assert plugin.get_option('name') is None


# Generated at 2022-06-22 19:32:06.123211
# Unit test for constructor of class Setting
def test_Setting():
    data = Setting('DATA', 'data', 'config', 'string')
    assert data.name == 'DATA'
    assert data.value == 'data'
    assert data.origin == 'config'
    assert data.type == 'string'
    assert data.get() == 'data'

    bool_data = Setting('BOOL_DATA', True, 'config', 'bool')
    assert bool_data.name == 'BOOL_DATA'
    assert bool_data.value == 'True'
    assert bool_data.origin == 'config'
    assert bool_data.type == 'bool'
    assert bool_data.get() == True

    float_data = Setting('FLOAT_DATA', 1.1, 'config', 'float')
    assert float_data.name == 'FLOAT_DATA'

# Generated at 2022-06-22 19:32:10.996877
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    fake_file = io.BytesIO(b'''[defaults]
test_key = valid_value
[plugin:example_plugin]
test_key=plugin_value
[plugin:example_plugin2]
test_key=plugin_value2
    ''')
    my_cfile = configparser.ConfigParser(allow_no_value=True)
    my_cfile.readfp(fake_file)
    assert get_ini_config_value(my_cfile, {}) == None
    assert get_ini_config_value(my_cfile, {'key':'test_key'}) == 'valid_value'
    assert get_ini_config_value(my_cfile, {'section':'plugin:example_plugin', 'key':'test_key'}) == 'plugin_value'
    assert get_ini

# Generated at 2022-06-22 19:32:20.127820
# Unit test for function get_config_type
def test_get_config_type():
    # test file names
    config_files_ini = ["/path/to/file.cfg", "/path/to/file.ini"]
    config_files_yaml = ["/path/to/file.yml", "/path/to/file.yaml"]
    config_files_other = ["/path/to/file", "/path/to/file.txt"]

    # the test
    for config_file in config_files_ini:
        assert get_config_type(config_file) == 'ini'
    for config_file in config_files_yaml:
        assert get_config_type(config_file) == 'yaml'

# Generated at 2022-06-22 19:32:29.041825
# Unit test for function resolve_path

# Generated at 2022-06-22 19:32:30.194166
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin()
    assert plugin is not None

# Generated at 2022-06-22 19:32:32.811202
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    # Verify that we can create an instance of the object.
    config_manager = ConfigManager(None)



# Generated at 2022-06-22 19:32:42.171915
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = 'core'
    name = 'setup'
    defs = dict()

    # test empty definitions
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config_manager._plugins['core']['setup'] == dict()

    # test a few random definitions
    defs = {'gid': {'default': 'root'}, 'uid': {'default': 'root'}}
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config_manager._plugins['core']['setup'] == defs
    config_manager._plugins = dict()



# Generated at 2022-06-22 19:32:43.859887
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    assert False # TODO: implement your test here


# Generated at 2022-06-22 19:32:44.513907
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    pass

# Generated at 2022-06-22 19:32:52.505236
# Unit test for constructor of class Plugin
def test_Plugin():
    p = Plugin()
    p.get_option_definitions()
    p.get_option('foobar')
    p.set_option('foobar', 'value')
    p.get_option('foobar')
    p.has_option('foobar')
    os.environ['ANSIBLE_FOOBAR'] = 'foobarvalue'
    p.get_plugin_options('foobar')
    os.environ.pop('ANSIBLE_FOOBAR')
    p.get_plugin_options('foobar')


# Generated at 2022-06-22 19:32:54.566999
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    c = ConfigManager()
    assert c.get_config_value('DEFAULT_REMOTE_TMP') == '~/.ansible/tmp'


# Generated at 2022-06-22 19:33:04.313375
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    c = ConfigManager()
    config = 'core'
    cfile = None
    plugin_type = None
    plugin_name = None
    keys = {'core': {'project_path': 'FOO'}}
    variables = None
    direct = None
    value, origin = c.get_config_value_and_origin(config, cfile=cfile, plugin_type=plugin_type, plugin_name=plugin_name, keys=keys, variables=variables, direct=direct)
    assert value == 'FOO'
    assert origin == 'keyword: core'



# Generated at 2022-06-22 19:33:15.501184
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()
    result = config_manager.get_plugin_vars(plugin_type='connection', name='smart')

# Generated at 2022-06-22 19:33:23.856158
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    # _config gets created when the first ConfigManager is constructed.
    # Subsequent calls to ConfigManager() will just return that instance,
    # meaning the constructor won't get called again.  We need to destroy
    # _config so that it goes back to the uninitialized state, otherwise
    # we can't validate proper construction.
    ConfigManager._config = None

    cm = ConfigManager()
    cm._load_configuration_definitions(DEFAULT_CONFIG_DATA)
    cm._parse_config_file(cm._config_file)
    cm.get_config_value('library')



# Generated at 2022-06-22 19:33:35.982810
# Unit test for method get_configuration_definition of class ConfigManager

# Generated at 2022-06-22 19:33:46.317475
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes, to_text

    # test unset config gives default value
    config_mgr = ConfigManager()
    config_mgr.get_config_value('ANSIBLE_CONFIG')

    # test simple config file setting overrides default
    temp_config = '%s/ansible.cfg' % tempfile.mkdtemp()
    # all these tests assume ansible.cfg exists
    with open(temp_config, 'w') as f:
        f.write('[defaults]\n')
        f.write('ansible_shell_type=sh\n')

# Generated at 2022-06-22 19:33:58.785225
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    '''
    Make sure ConfigManager().update_config_data() works as expected
    '''

    # Test 1: The called function should return None if defs is None
    mock_self = Mock()
    mock_self.data = Mock()
    config = ConfigManager('')
    output = config.update_config_data()
    assert output is None, "ConfigManager().update_config_data() should return None if defs is None"

    # Test 2: The called function should raise AnsibleOptionsError if defs is not of type dict
    mock_self = Mock()
    mock_self.data = Mock()
    config = ConfigManager('')
    defs = 'This is the defs'
    with pytest.raises(AnsibleOptionsError):
        config.update_config_data(defs=defs)



# Generated at 2022-06-22 19:34:00.029366
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    cm = ConfigManager()
    cm.get_config_value("config")


# Generated at 2022-06-22 19:34:08.906040
# Unit test for constructor of class Plugin
def test_Plugin():
    pass


# ===========================================================================
# Main execution
# ===========================================================================

if __name__ == '__main__':
    import logging

    logging.basicConfig(level=logging.DEBUG, filename=u'/tmp/ansible-setting.log', filemode='w')
    logging.debug(u'Running tests')

    logging.debug(u'===')
    logging.debug(u'testing initialization')
    s = Setting(u'FOO', u'bar')
    logging.debug(u'%s', s)
    s.set_value(u'baz')
    logging.debug(u'%s', s)
    try:
        s.set_value(u'baz', origin='invalid')
    except AnsibleError:
        logging.debug(u'caught exception (expected)')

# Generated at 2022-06-22 19:34:13.330271
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # initialize the config manager
    config_manager = ConfigManager([])
    # get a single configuration definition, which is a dict
    config_manager.get_configuration_definition('foo')

# Generated at 2022-06-22 19:34:23.681168
# Unit test for constructor of class Setting

# Generated at 2022-06-22 19:34:31.008537
# Unit test for constructor of class Setting
def test_Setting():
    import ansible.constants

    # Pre-check of Setting class
    assert Setting.ISA == 'setting'
    assert Setting.PRIORITY == 1000
    assert Setting.CACHEABLE is False
    assert Setting(name='ANSIBLE_CONFIG', value='/etc/ansible/ansible.cfg', origin='default', string_type='string')
    assert Setting(name='ANSIBLE_CONFIG', value='/etc/ansible/ansible.cfg', origin='default', string_type='string').name == 'ANSIBLE_CONFIG'
    assert Setting(name='ANSIBLE_CONFIG', value='/etc/ansible/ansible.cfg', origin='default', string_type='string').value == '/etc/ansible/ansible.cfg'

# Generated at 2022-06-22 19:34:39.330231
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    import tempfile

    tmp = tempfile.mkdtemp()

    os.environ["ANSIBLE_CONFIG"] = tmp + "/test_1.cfg"
    assert find_ini_config_file() == tmp + "/test_1.cfg"
    del os.environ["ANSIBLE_CONFIG"]

    try:
        old_cwd = os.getcwd()
        os.chdir(tmp)
        assert find_ini_config_file() == tmp + "/ansible.cfg"
        os.chdir(old_cwd)
    except OSError:
        pass

    with open(os.path.expanduser("~/.ansible.cfg"), 'w') as f:
        f.write("[defaults]\ninventory = hosts\n")
    assert find_ini_config_file() == os

# Generated at 2022-06-22 19:34:44.210696
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    plugin_type = fake_plugin_type()
    name = fake_plugin_name()
    defs = fake_defs()

    config_manager = ConfigManager()
    result = config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert result is None



# Generated at 2022-06-22 19:34:46.826490
# Unit test for constructor of class Plugin
def test_Plugin():
    # TODO: need tests here
    assert False


# Generated at 2022-06-22 19:34:55.237551
# Unit test for constructor of class Plugin
def test_Plugin():

    p1 = Plugin()

    # Create a couple of mock objects
    config_options = {
        'foo': {'required': False, 'default': 'bar'},
        'zap': {'required': False, 'default': 'baz'},
    }

    config_options_2 = {
        'bar': {'required': False, 'default': 'foo'},
        'zap': {'required': False, 'default': 'bzz'},
    }

    # unregistered plugin should still return its defaults
    assert p1.get_plugin_options(INTERNAL, None) == {}
    assert p1.get_plugin_vars(INTERNAL, None) == []
    assert p1.get_plugin_options(INTERNAL, 'foo') == {}

# Generated at 2022-06-22 19:34:59.517276
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    test_obj = ConfigManager()
    defs = {}
    configfile = None
    rc = test_obj.update_config_data(defs, configfile)
    assert rc is None


# Generated at 2022-06-22 19:35:02.933078
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    cli_value = '{"ANSIBLE_CONFIG": "/home/me/.ansible.cfg"}'
    config_manager = ConfigManager(cli_value)
    assert config_manager.get_config_value('ANSIBLE_CONFIG', cfile='/home/me/.ansible.cfg') == '/home/me/.ansible.cfg'



# Generated at 2022-06-22 19:35:03.621195
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    pass

# Generated at 2022-06-22 19:35:10.030819
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.add_section('foo')
    p.set('foo', 'bar', 'baz')
    assert get_ini_config_value(p, {'section': 'foo', 'key': 'bar'}) == 'baz'
    assert get_ini_config_value(p, {'section': 'foo', 'key': 'bar2'}) is None
    assert get_ini_config_value(p, {'section': 'foo2', 'key': 'bar'}) is None


# FIXME: can we move to module_utils for use for ini plugins also?

# Generated at 2022-06-22 19:35:19.784734
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
  from ansible.utils.display import Display
  from ansible.config.constants import DEFAULTS, get_config_type
  from ansible.config.manager import ConfigManager
  from ansible.errors import AnsibleError
  from ansible.config.data import Setting

  display = Display()
  config_manager = ConfigManager(display, config_file='ansible.cfg')
  config_manager._parsers['ansible.cfg'] = None
  config_type = get_config_type('ansible.cfg')
  try:
    config_manager.update_config_data(DEFAULTS, 'ansible.cfg')
  except AnsibleError:
    pass



# Generated at 2022-06-22 19:35:29.347864
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    skip_if_not_imported('ansible.plugins.loader')
    # local imports so we don't depend on ansible.plugins.loader
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.action import ActionBase

    cm = ConfigManager()

    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))

    # test that things work when not defined
    cm.get_configuration_definitions('action_plugins', 'test')
    cm.get_config_value('test1')

    # add a plugin without configs
    cm.initialize_plugin_configuration_definitions('action_plugins', 'test', {'test2': {'default': 'default2', 'type': 'string'}})
    assert cm.get

# Generated at 2022-06-22 19:35:35.956860
# Unit test for constructor of class Plugin
def test_Plugin():
    from ansible import constants as C

    p = Plugin('anselmo', 'fletcher', 'https://api.github.com/users/anselmofletcher')
    assert p.name.name == 'anselmo'
    assert p.name.path == 'fletcher'
    assert p.name.fullname == 'anselmo.fletcher'
    assert p.api_url == 'https://api.github.com/users/anselmofletcher'
    assert p.pypi_name == 'ansible-anselmo-fletcher'
    assert p.dist_name == 'ansible_anselmo_fletcher'
    assert p.class_name == 'AnselmoFletcher'
    assert p.class_path == 'anselmo.fletcher'

# Generated at 2022-06-22 19:35:48.753733
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('True', 'boolean') == True
    assert ensure_type('false', 'bool') == False
    assert ensure_type('1', 'int') == 1
    assert ensure_type('2', 'integer') == 2
    assert ensure_type('3.3', 'float') == 3.3
    assert ensure_type('4,4', 'list') == ['4', '4']
    assert ensure_type('None', 'none') == None
    # FIXME: This test depends on the external environment
    #assert ensure_type('.', 'path') == os.getcwd()
    #assert ensure_type('.', 'tmppath') == os.path.realpath(os.path.join(os.getcwd(), 'ansible-local'))

# Generated at 2022-06-22 19:35:51.314703
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    # setup the test
    testConfig()
    # test the results
    assert True == True

# Generated at 2022-06-22 19:35:56.824399
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    config_file = tempfile.NamedTemporaryFile(mode='w+t', suffix='ini', delete=False)
    config_file.write('[defaults]\n')
    config_file.write('test_setting=test_setting_value\n')
    config_file.close()
    entry = {'section': 'defaults', 'key': 'test_setting'}
    p = configparser.ConfigParser()
    p.read(config_file.name)
    value = get_ini_config_value(p, entry)
    os.remove(config_file.name)
    assert value == 'test_setting_value'


# FIXME: can move to module_utils for use for yaml plugins also?

# Generated at 2022-06-22 19:36:01.296713
# Unit test for function resolve_path
def test_resolve_path():
    path = "./abc/../../bcd/../cde/dir"
    print("The test path is: %s"%path)
    resolved_path = resolve_path(path)
    print("The resolved path is: %s"%resolved_path)



# Generated at 2022-06-22 19:36:10.774871
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    # test get_config_value_and_origin()

    # test basic value and origin
    cm = ConfigManager(['../test/units/config/ansible.cfg'])
    assert cm.get_config_value_and_origin('retry_files_enabled') == (
        'True', 'default'), "ConfigManager basic get_config_value_and_origin() test failed"

    # test CLI override
    cm = ConfigManager(['../test/units/config/ansible.cfg'])
    cm.CONFIG_FILE = None
    assert cm.get_config_value_and_origin(
        'retry_files_enabled') == ('False', 'cli: retry_files_enabled'), "ConfigManager CLI get_config_value_and_origin() test failed"

    # test config file value override

# Generated at 2022-06-22 19:36:18.400323
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin_defs = dict(
        foo=dict(default='bar', type='string'),
        baz=dict(default='qux', type='string'),
        _internal1=dict(default='quux', type='string'),
        _internal2=dict(default='corge', type='string'),
        routing=dict(default=dict(
            listen=dict(default='localhost', type='string'),
            port=dict(default=12345, type='int'),
            ), type='dict')
    )
    plugin = Plugin(plugin_defs, ['foo'])
    assert plugin.get_plugin_vars() == []
    assert plugin.get_plugin_options('foo') == dict(foo='bar', baz='qux', routing=dict(listen='localhost', port=12345))
    assert plugin.get_plugin_

# Generated at 2022-06-22 19:36:29.538309
# Unit test for function ensure_type
def test_ensure_type():
    ensure_type(True, 'bool')
    ensure_type(True, 'boolean')

    ensure_type(1, 'int')
    ensure_type(1, 'integer')

    ensure_type(1.1, 'float')

    ensure_type(None, 'none')

    ensure_type(['/foo', '/bar'], 'pathlist')

    ensure_type('foo,bar', 'list')
    ensure_type(['foo', 'bar'], 'list')
    ensure_type(('foo', 'bar'), 'list')
    ensure_type((x for x in ['foo', 'bar']), 'list')

    ensure_type({'foo': 'bar'}, 'dict')
    ensure_type({'foo': 'bar'}, 'dictionary')

    ensure_type('foo', 'str')
    ensure_type

# Generated at 2022-06-22 19:36:35.590262
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('filter', 'debug', {'var': [{'name': 'foo'}]})
    pvars = config.get_plugin_vars('filter', 'debug')
    assert 'foo' == pvars[0]


# Generated at 2022-06-22 19:36:41.650447
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    # Create a config manager object
    cm = ConfigManager(['/home/navdeep/.ansible.cfg'])
    # Check whether the plugin_type and plugin_name is None
    if cm.get_configuration_definitions() == cm._base_defs:
        print("Passed get_configuration_definitions method of config_manager unit test")

# Generated at 2022-06-22 19:36:52.846626
# Unit test for function resolve_path
def test_resolve_path():
    curr_dir = os.getcwd()
    os.chdir("/tmp/")


# Generated at 2022-06-22 19:36:53.305731
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    pass

# Generated at 2022-06-22 19:36:58.546981
# Unit test for function resolve_path
def test_resolve_path():
    # Return value should be absolute path
    # path = None
    assert resolve_path(None) == None

    # path = ''
    assert resolve_path('') == ''

    # path != '' and path != None
    assert resolve_path('.') == os.path.abspath(os.path.expanduser('.'))

    # path = '{{CWD}}'
    assert resolve_path('{{CWD}}') == os.getcwd()

    # basedir != None
    assert resolve_path('{{CWD}}', basedir=os.getcwd()) == os.getcwd()


# Generated at 2022-06-22 19:37:07.242874
# Unit test for function get_config_type
def test_get_config_type():
    cfile = None
    assert get_config_type(cfile) is None
    cfile = "test.ini"
    assert get_config_type(cfile) == "ini"
    cfile = "test.cfg"
    assert get_config_type(cfile) == "ini"
    cfile = "test.yaml"
    assert get_config_type(cfile) == "yaml"
    cfile = "test.yml"
    assert get_config_type(cfile) == "yaml"
    raises(AnsibleOptionsError, get_config_type, "test.txt")



# Generated at 2022-06-22 19:37:11.699295
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()

    # TODO: update for the config file
    with pytest.raises(AnsibleError):
        config_manager.get_configuration_definition('foobar', 'foobar', 'foobar')


# Generated at 2022-06-22 19:37:22.640859
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = ConfigManager()

    defs = dict(
        foo=dict(
            type='string',
            default='def',
            env='FOO',
        )
    )
    cm._base_defs = defs

    configfile = MagicMock()
    configfile.get = MagicMock(return_value='conf')
    cm._parsers = dict(configfile)

    env = dict(FOO='env')
    cm.get_env = MagicMock(return_value=env)

    # Use defaults
    value, origin = cm.get_config_value_and_origin('foo')
    assert value == 'def'
    assert origin == 'default'

    # Use env
    value, origin = cm.get_config_value_and_origin('foo', configfile='configfile')
    assert value

# Generated at 2022-06-22 19:37:35.697909
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    mock_configfile = MagicMock(
        side_effect=AnsibleError(
            'error_parsing_variable',
            'AnsibleError: Parsing error in'
        )
    )
    with patch.object(ConfigManager, 'get_config_value', mock_configfile):
        config_manager = ConfigManager('')
        config_manager.initialize_plugin_configuration_definitions('action', 'copy','copy')
        pvars = config_manager.get_plugin_vars('action', 'copy')
        assert isinstance(pvars, list) == True
        assert isinstance(pvars[0], str) == True
        assert pvars[0] == 'src'


# Generated at 2022-06-22 19:37:48.230376
# Unit test for constructor of class Setting
def test_Setting():
    # Test for constructor of class Setting
    # -------------------------------------

    # Test 1:
    # Pass an empty Setting
    # Expect an instance of Setting class with value = '', origin = '' and type = 'string'
    #
    # test 1
    setting = Setting('', '')
    assert setting._value == ''
    assert setting._origin == ''
    assert setting._type == 'string'

    # Test 2:
    # Pass default value = '10' with no origin
    # Expect an instance of Setting class with value = '10', origin = '' and type = 'string'
    #
    # test 2
    setting = Setting('test', '10')
    assert setting._value == '10'
    assert setting._type == 'string'
    assert setting._origin == ''

    # Test 3:
    # Pass default value = 10 as an int

# Generated at 2022-06-22 19:37:53.056268
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    cm = ConfigManager()
    config = "DEFAULT_CALLBACK_WHITELIST"
    plugin_type = None
    plugin_name = None
    cm.get_configuration_definition(config, plugin_type, plugin_name)


# Generated at 2022-06-22 19:37:54.895370
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    # This method is tested in test_ConfigManager_get_configuration_definitions
    pass


# Generated at 2022-06-22 19:38:00.572663
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    c = ConfigManager()
    c.initialize_plugin_configuration_definitions('some_plugin_type', 'plugin_name', {'a': 'b'})
    assert c._plugins == {'some_plugin_type': {'plugin_name': {'a': 'b'}}}


# Generated at 2022-06-22 19:38:03.338616
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager(contents=None, extra_configs=None)
    config.get_option_configuration_definitions(None, None)



# Generated at 2022-06-22 19:38:06.297170
# Unit test for constructor of class Setting
def test_Setting():
    s = Setting('foo', 'bar', 'file')
    assert s.name == 'foo'
    assert s.value == 'bar'
    assert s.origin == 'file'


# Generated at 2022-06-22 19:38:15.190812
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    warnings = set()
    # test ANSIBLE_CONFIG
    data_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'ansible.cfg')
    assert os.path.isfile(data_path)
    env = dict(ANSIBLE_CONFIG=data_path)
    assert find_ini_config_file(warnings=warnings, env=env) == data_path
    assert not warnings

    # test working directory
    cwd = os.getcwd()
    new_cwd = os.path.dirname(cwd)
    os.chdir(new_cwd)
    assert find_ini_config_file(warnings=warnings) == cwd
    assert not warnings

    # test user directory

# Generated at 2022-06-22 19:38:26.374988
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager()
    defs = None
    configfile = None
    with pytest.raises(AssertionError):
        config.update_config_data(defs, configfile)

    defs = {}
    configfile = None
    with pytest.raises(AssertionError):
        config.update_config_data(defs, configfile)

    defs = 'hi'
    configfile = None
    with pytest.raises(AssertionError):
        config.update_config_data(defs, configfile)

    defs = {'key': 'value'}
    configfile = None
    with pytest.raises(AnsibleOptionsError):
        config.update_config_data(defs, configfile)


# Generated at 2022-06-22 19:38:32.629493
# Unit test for function ensure_type
def test_ensure_type():
    # type: () -> None
    assert ensure_type(3, 'str') == u'3'
    assert ensure_type(3, 'none') is None
    assert ensure_type("3", 'none') is None
    assert ensure_type("/tmp", 'tmppath') != to_text("/tmp")

# FIXME: see if we can unify in module_utils with similar function used by argspec

# Generated at 2022-06-22 19:38:43.413849
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    try:
        import ansible.cli.playbook
        import ansible.constants
        import ansible.utils
        import ansible.utils.vault
    except ImportError:
        print('skipping due to failure to import ansible modules')
        return
    cli_vars = {'roles_path': '', 'ansible_managed': 'Ansible managed: Do NOT edit this file manually!',
                'playbook_dir': '', 'groups': 'all'}
    options = ansible.cli.playbook.PlaybookCLI.parse(['testConfigManager_get_config_value'])
    options.private_key_file = 'testConfigManager_get_config_value'
    options.become_method = 'do_not_use'

# Generated at 2022-06-22 19:38:53.637515
# Unit test for function ensure_type
def test_ensure_type():
    global original_value

# Generated at 2022-06-22 19:39:00.560845
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    def test_method(self):
        config = ConfigManager()
        defs = {}
        # Define the method the test suite should execute.
        config.initialize_plugin_configuration_definitions('module', 'ping', defs)
        # Validate the results of the method execution.
        assert True

    # Execute the test method.
    test_method(ConfigManager)
    return True

# Generated at 2022-06-22 19:39:03.677147
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    c = ConfigManager()
    # c.get_config_value_and_origin(config, cfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None):
    #assert False

# Generated at 2022-06-22 19:39:11.159965
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # test this
    config = ConfigManager()
    l1 = 'common'
    l2 = 'console'
    l3 = 'console_timestamp'
    config.get_config_value_and_origin(l1, cfile='/etc/ansible/ansible.cfg')
    config.get_config_value_and_origin(l2, cfile='/etc/ansible/ansible.cfg')
    config.get_config_value_and_origin(l3, cfile='/etc/ansible/ansible.cfg')

# Generated at 2022-06-22 19:39:22.716937
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    mgr = ConfigManager()
    plugin_type = 'connection'
    name = 'accelerate'
    keys = {'accelerate': {'user': 'test'}}
    variables = None
    direct = None

# Generated at 2022-06-22 19:39:31.281618
# Unit test for function resolve_path
def test_resolve_path():
    """
    Function resolve_path: test against various paths and basedirs
    """
    base_dir = '/home/user1'

# Generated at 2022-06-22 19:39:44.021213
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    c = ConfigManager()
    c.initialize_plugin_configuration_definitions('test', 'test_config', {'a': {'default': 'a', 'type': 'str'}})
    assert 'a' in c.get_configuration_definitions('test')
    assert 'a' in c.get_configuration_definitions('test', 'test_config')
    assert 'a' in c.get_configuration_definitions('test', 'test_config', ignore_private=True)

    c.initialize_plugin_configuration_definitions('test', 'test_config', {'_b': {'default': 'a', 'type': 'str'}})
    assert '_b' in c.get_configuration_definitions('test', 'test_config')
    assert '_b' not in c.get

# Generated at 2022-06-22 19:39:52.143859
# Unit test for function get_ini_config_value

# Generated at 2022-06-22 19:40:01.056021
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    # setup
    p = configparser.ConfigParser()
    p.read(os.path.join(os.path.dirname(__file__), 'config_ini.txt'))
    # Tests
    # 1. If section exists, it is used
    # 2. If section does not exist, 'defaults' is used
    # 3. If key exists, its value is returned
    # 4. If key does not exist, empty string is returned
    assert get_ini_config_value(p, {'section': 'all', 'key': 'foo'}) == "bar"
    assert get_ini_config_value(p, {'section': 'all', 'key': 'foo2'}) == "bar2"

# Generated at 2022-06-22 19:40:08.881988
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    manager = ConfigManager(['--private-key=private_key', '--private-key=private_key2'], 'configfile')
    manager.DEBUG = True
    manager.WARNINGS = []
    manager.DEPRECATED = []
    manager._parsers = { 'configfile': configparser.ConfigParser() }

    # If the 'type' is not specified, string is assumed
    manager.get_config_value_and_origin('host_key_checking')
    assert manager.data['host_key_checking'] == 'True'
    assert manager.data.values['host_key_checking']['origin'] == 'default'
    assert manager.data.values['host_key_checking']['type'] == 'bool'

    # Test string-valued configuration option

# Generated at 2022-06-22 19:40:20.264924
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    import tempfile
    import yaml

    def _write_config_file(basedir, config_dict):
        config = dict(config_dict)

        # yaml is dumped with default flow_style=None
        with open(os.path.join(basedir, 'test.yml'), 'w') as f:
            f.write(yaml.dump(config, default_flow_style=False))

        # ini is dumped with default delimiter=None
        ini = '\n'.join(['[defaults]'] + ["%s=%s" % (k, v) for k, v in config.items()])
        with open(os.path.join(basedir, 'test.ini'), 'w') as f:
            f.write(ini)


# Generated at 2022-06-22 19:40:23.471434
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_manager = ConfigManager()

# Generated at 2022-06-22 19:40:24.889562
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    assert ConfigManager().get_config_value("ANSIBLE_CONFIG") is None

# Generated at 2022-06-22 19:40:31.234103
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    test_config = '/etc/ansible.cfg'