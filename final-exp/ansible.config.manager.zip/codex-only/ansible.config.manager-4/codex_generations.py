

# Generated at 2022-06-22 19:30:34.583249
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    this = ConfigManager()
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None
    mock_plugin_type = None
    mock_name = None


# Generated at 2022-06-22 19:30:38.500327
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():

    config_manager = ConfigManager()

    assert(config_manager.get_configuration_definitions() != None)

# Generated at 2022-06-22 19:30:49.350986
# Unit test for function ensure_type

# Generated at 2022-06-22 19:30:50.597438
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    conf = ConfigManager()
    assert conf._base_defs is not None


# Generated at 2022-06-22 19:30:54.601361
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    from ansible.constants import DEFAULTS, DEFAULT_HOST_LIST, DEFAULT_MODULE_PATH
    config = ConfigManager()
    assert config.get_configuration_definition('host_key_checking') == DEFAULTS['host_key_checking']
    assert config.get_configuration_definition('library') == DEFAULTS['library']
    assert config.get_configuration_definition('moduledir') == DEFAULTS['moduledir']
    assert config.get_configuration_definition('roles_path') == DEFAULTS['roles_path']

# Generated at 2022-06-22 19:31:07.564987
# Unit test for constructor of class Plugin
def test_Plugin():
    from ansible.plugins.loader import load_plugins
    from ansible.plugins.action import ActionBase

    class TestAction(ActionBase):
        pass

    tmp_directory = tempfile.mkdtemp()
    ansible_path = os.path.join(tmp_directory, 'ansible')
    os.mkdir(ansible_path)

# Generated at 2022-06-22 19:31:16.990105
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    plugin_type = 'accelerate'
    name = 'foo'
    defs = [{'name': 'key1', 'aliases': ['key1a'], 'default': False, 'required': False, 'choices': [0, 1, 2]}]

    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)

    assert config_manager._plugins['accelerate']['foo']['key1'] == {
        'default': False,
        'required': False,
        'choices': [0, 1, 2],
        'name': 'key1',
        'aliases': ['key1a']
    }


# Generated at 2022-06-22 19:31:29.501575
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    # test with empty config
    cfg = ConfigManager(config_file=None,
                        defaults=None,
                        defaults_file=None,
                        env_vars=None,
                        args=None,
                        plugin_dirs=None,
                        include_task_plugins=None,
                        include_vars_plugins=None,
                        include_lookup_plugins=None,
                        include_callback_plugins=None,
                        include_filter_plugins=None,
                        connection_loader=None)

    # test with config

# Generated at 2022-06-22 19:31:38.770339
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
  configmgr = ConfigManager()
  # No arguments
  configmgr.get_configuration_definitions()
  # Arguments number 1 (plugin_type)
  configmgr.get_configuration_definitions('plugin_type')
  # Arguments number 2 (plugin_type, name)
  configmgr.get_configuration_definitions('plugin_type', 'name')
  # Arguments number 3 (plugin_type, name, ignore_private)
  configmgr.get_configuration_definitions('plugin_type', 'name', True)

# Generated at 2022-06-22 19:31:48.834358
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    '''
    Test ConfigManager constructor, which is supposed to find the configuration files in the
    specified search paths and parse all of them into one
    '''
    # Create a temporary directory
    fd, d = tempfile.mkstemp()
    os.close(fd)
    os.mkdir(d)

    # Create a test configuration file in the temporary directory
    f = open(os.path.join(d, 'test.cfg'), "w")

# Generated at 2022-06-22 19:31:53.215154
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    # Create the object
    obj = ConfigManager()

    # Call the method
    obj.get_config_value_and_origin('config', configfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None)

# Generated at 2022-06-22 19:31:56.872169
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    manager = ConfigManager

    plugin_type = 'foo'
    name = 'bar'

    # setup return values
    manager._plugins.get.return_value.get.return_value.get.return_value = dict(vars=['foo', 'bar'])

    result = manager.get_plugin_vars(plugin_type, name)
    assert result == ['foo', 'bar']



# Generated at 2022-06-22 19:32:02.886253
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    defs = {}
    defs['foo'] = {'default': 'test_default_1', 'type': 'string', 'env': [{'name': 'TEST_VAR_1'}]}
    defs['bar'] = {'default': 'test_default_2', 'type': 'string', 'env': [{'name': 'TEST_VAR_2'}]}

    cm = ConfigManager(defs)

    # test env, then default
    assert cm.get_config_value_and_origin('foo') == ('test_default_1', 'default')
    assert cm.get_config_value_and_origin('bar') == ('test_default_2', 'default')
    os.environ['TEST_VAR_1'] = 'test_env_1'
    assert cm.get_config_

# Generated at 2022-06-22 19:32:05.785683
# Unit test for constructor of class Setting
def test_Setting():
    settings = Setting('A', 'a', 'A', 'string')
    assert settings._constant == 'A'
    assert settings.value == 'a'
    assert settings.origin == 'A'
    assert settings.string == 'a'


# Generated at 2022-06-22 19:32:12.248934
# Unit test for constructor of class Plugin
def test_Plugin():
    p = Plugin('cache', 'yum', BaseCacheModule())
    assert p.name == 'yum'
    assert p.category == 'cache'
    assert p.obj is not None



# Generated at 2022-06-22 19:32:15.952041
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    c = ConfigManager()
    c.parse()
    assert c.data.host_key_auto_add
    assert c.data.syslog_facility == 'SYSLOG_FACILITY'


# Generated at 2022-06-22 19:32:26.676513
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    config = ConfigManager({"plugin_dirs": [], "fact_caching": []}, [])
    config.get_configuration_definition("not_found")

    config.get_configuration_definitions("not_found")

    config.get_configuration_definitions("not_found", "not_found")

    # defaults
    config.get_configuration_definitions()
    config.get_configuration_definitions(ignore_private=True) # ignore deprecations
    config.get_configuration_definition("deprecated_default")
    config.get_configuration_definition("deprecated_default", ignore_private=True) # ignore deprecations


# Generated at 2022-06-22 19:32:37.778270
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Test that find_ini_config_file() finds a config file
    temp_dir = tempfile.mkdtemp()
    config_file = os.path.join(temp_dir, "ansible.cfg")
    os.environ['ANSIBLE_CONFIG'] = config_file
    open(config_file, 'a').close()
    assert find_ini_config_file() == config_file
    del os.environ['ANSIBLE_CONFIG']
    os.remove(config_file)
    os.rmdir(temp_dir)
    assert not os.path.exists(temp_dir)

    # Test that find_ini_config_file() doesn't find a missing config file
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:32:46.283097
# Unit test for function get_config_type
def test_get_config_type():
    """Unit test for function get_config_type
    """
    assert get_config_type(None) is None
    assert get_config_type('/tmp/abc/xyz') == 'yaml'
    assert get_config_type('/tmp/abc/xyz.ini') == 'ini'
    assert get_config_type('/tmp/abc/xyz.cfg') == 'ini'
    assert get_config_type('/tmp/abc/xyz.yml') == 'yaml'
    assert get_config_type('/tmp/abc/xyz.yaml') == 'yaml'
    assert get_config_type('/tmp/abc/xyz.ymlx') == 'yaml'
    assert get_config_type('/tmp/abc/xyz.yamlx') == 'yaml'




# Generated at 2022-06-22 19:32:53.897499
# Unit test for function resolve_path
def test_resolve_path():
    """Test if resolve_path returns correct result"""
    assert resolve_path('~/ansible') == os.path.expanduser('~/ansible'), \
        "Resolve path does not work for a path with tilde"
    assert resolve_path('{{CWD}}') == os.getcwd(), \
        "Resolve path does not work for a path with variable syntax"
    assert resolve_path('./relative_path') == os.path.join(os.getcwd(), 'relative_path'), \
        "Resovle path does not work for a path with relative path"



# Generated at 2022-06-22 19:32:55.395084
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    do_test(ConfigManager, 'get_plugin_vars')


# Generated at 2022-06-22 19:33:08.087894
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('') == os.getcwd()
    assert resolve_path('{{CWD}}') == os.getcwd()
    assert resolve_path('{{CWD}}', '/tmp') == '/tmp'
    assert resolve_path(None) == os.getcwd()
    assert resolve_path(None, '/tmp') == '/tmp'
    assert resolve_path('/tmp', '/tmp') == '/tmp'
    assert resolve_path('/tmp') == '/tmp'
    assert resolve_path('./test', '/tmp') == '/tmp/test'
    assert resolve_path('test/test', '/tmp') == '/tmp/test/test'
    assert resolve_path('test/../test', '/tmp') == '/tmp/test'

# Generated at 2022-06-22 19:33:12.216757
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    manager = ConfigManager()
    manager.add_configuration_definition('foo', 'foo description', 'string', 'bar')
    assert 'foo description' == manager.get_configuration_definition('foo')['description']


# Generated at 2022-06-22 19:33:24.253032
# Unit test for constructor of class Setting
def test_Setting():
    assert Setting('foo', 'bar', 'xyz', 'string').key == 'foo'
    assert Setting('foo', 'bar', 'xyz', 'string').value == 'bar'
    assert Setting('foo', 'bar', 'xyz', 'string').origin == 'xyz'
    assert Setting('foo', 'bar', 'xyz', 'string').type == 'string'
    assert str(Setting('foo', 'bar', 'xyz', 'string')) == "Setting('foo', 'bar', 'xyz', 'string')"

    # Test type coercion and validation errors
    assert Setting('foo', "123", 'xyz', 'integer').value == 123
    assert Setting('foo', "123.4", 'xyz', 'float').value == 123.4
    assert Setting('foo', "t", 'xyz', 'bool').value is True


# Generated at 2022-06-22 19:33:27.980949
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    CONFIG = ConfigManager()

    # testing with some internal config
    assert CONFIG.get_configuration_definitions('module') == CONFIG._plugins['module']


# Generated at 2022-06-22 19:33:38.328785
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    data = {'foo': '', 'bar': '', 'baz': '', 'foobar': '', 'foobarbaz': '', 'bazbar': '', 'preview_dir': '', 'a': '', 'b': '', 'ab': '', 'a_b': '',
            'a.b.c': '', 'a_b_c': '', 'abc': '', 'abc_de': '', 'abc_de.f': '', 'abc.def': '', 'abc-def': ''}

# Generated at 2022-06-22 19:33:46.913171
# Unit test for function ensure_type
def test_ensure_type():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.parsing.convert_bool import boolean

    errmsg = ''
    basedir = None

    value = b'i\xe8\xaa\x9e'
    value_type = 'string'
    if isinstance(value, (string_types, AnsibleVaultEncryptedUnicode, bool, int, float, complex)):
        value = unquote(to_text(value, errors='surrogate_or_strict'))
    else:
        errmsg = 'string'

    if errmsg:
        raise ValueError('Invalid type provided for "%s": %s' % (errmsg, to_native(value)))


# Generated at 2022-06-22 19:33:59.547286
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    def get_valid_configuration_definitions_options(self):
        ret = []
        for plugin_type in self._plugins:
            for plugin_name in self._plugins.get(plugin_type, []):
                for name in self._plugins[plugin_type][plugin_name]:
                    ret.append((name, plugin_type, plugin_name))
        return ret
    def should_pass(self, name, plugin_type, plugin_name):
        defs = self.get_configuration_definition(name, plugin_type, plugin_name)
        if not isinstance(defs, dict):
            self.fail("config definition %s doesn't return dict" % name)

# Generated at 2022-06-22 19:34:08.622980
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    """ Test the method get_config_value of class ConfigManager """

    # Test ansible.config.ConfigManager.get_config_value()
    print()
    print('Test ansible.config.ConfigManager.get_config_value()')
    print()

    # Print the current configuration variables
    print()
    print('Current CONFIGURATION variables:')
    print()
    configManager.write_configuration_settings()
    print()

    # Test the method get_config_value()
    print()
    print('Test ansible.config.ConfigManager.get_config_value()')
    print()
    print('configManager.get_config_value("loglevel"):')
    print(configManager.get_config_value('loglevel'))
    print()

# Generated at 2022-06-22 19:34:20.634671
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()

    # default is global options (from constants)
    assert_equal(config.get_configuration_definitions(None), constants.COMMAND_LINE_CONFIG_SETTINGS)
    assert_equal(config.get_configuration_definitions('fooby'), {})
    assert_equal(config.get_configuration_definitions('foobar', 'foo'), {})

    # add a fake plugin type and a fake plugin
    defs = dict(a=dict(default='', description='foobar'), b=dict(default='', description='foobar'))
    config.initialize_plugin_configuration_definitions('foobar', 'foo', defs)
    assert_equal(config.get_configuration_definitions('foobar', 'foo'), defs)

    # test ignore private
    config.initial

# Generated at 2022-06-22 19:34:27.281014
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config1 = ConfigManager()
    plugin_type = None 
    name = None 
    ignore_private = False 
    # make sure we don't crash when no type is provided
    ignore_private = False 
    ret = config1.get_configuration_definitions(plugin_type, name, ignore_private)
    assert isinstance(ret, dict) 

# Generated at 2022-06-22 19:34:29.105073
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin()
    assert isinstance(plugin, Plugin)

# Generated at 2022-06-22 19:34:30.540815
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    pass

# Generated at 2022-06-22 19:34:33.408023
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    assert isinstance(config.get_configuration_definitions(), dict)


# Generated at 2022-06-22 19:34:41.181077
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    p = find_ini_config_file()
    if 'ANSIBLE_CONFIG' in os.environ:
        assert os.environ['ANSIBLE_CONFIG'] in p
    else:
        assert p.endswith('ansible.cfg')
    assert os.path.exists(p)
    assert os.path.isfile(p)


# FIXME: someday this can be removed, its part of the ini var deprecations
INI_CONFIG_VALID_PLUGINS = set(('callback', 'lookup', 'filter', 'vars', 'test', 'cliconf', 'netconf', 'inventory', 'connection', 'shell', 'strategy', 'terminal', 'cache'))
INI_CONFIG_DEPRECATED_PLUGINS = set(('strategy', 'terminal'))



# Generated at 2022-06-22 19:34:46.854354
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.add_section('section')
    p.set('section', 'key', 'value')
    entry = {'section': 'section', 'key': 'key'}
    assert get_ini_config_value(p, entry) == 'value'

    p = configparser.ConfigParser()
    p.add_section('section')
    p.set('section', 'key', 'value')
    entry = {'section': 'section2', 'key': 'key'}
    assert get_ini_config_value(p, entry) is None

    p = configparser.ConfigParser()
    p.add_section('section')
    p.set('section', 'key', 'value')
    entry = {'section': 'section', 'key': 'key2'}
    assert get_ini

# Generated at 2022-06-22 19:34:58.485933
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    # Tested with both the -vault-password-file and -ask-vault-pass options.
    # Since the behavior is the same, and only the function of update_vault_secrets()
    # is explicitly tested, only the -vault-password-file option was used.
    vault_password_file = 'ansible/test/test_utils/test_vault_fixtures/test_vault_pass'
    host_list = 'localhost,'
    config_file = ''
    init_filedata = '''
[defaults]
host_key_checking = False
host_list = localhost,
'''

    with open('ansible.cfg', 'w') as f:
        f.write(init_filedata)

# Generated at 2022-06-22 19:35:09.554019
# Unit test for function get_config_type
def test_get_config_type():
    cfile = 'test/test.yaml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'test/test.yml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'test/test.ini'
    assert get_config_type(cfile) == 'ini'
    cfile = 'test/test.cfg'
    assert get_config_type(cfile) == 'ini'
    cfile = 'test/test.unsupported'
    try:
        get_config_type(cfile)
    except AnsibleOptionsError:
        assert True
    else:
        assert False


# FIXME: ini/yaml specific logic
# FIXME: merge with get_config_type or use a plugin instead

# Generated at 2022-06-22 19:35:19.837490
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    mock_data_manager = MagicMock()
    config_manager = ConfigManager(['ansible.cfg'], mock_data_manager)

    config_manager._config_file = MagicMock()
    mock_plugin_type = 'plugin_type'
    mock_plugin_name = 'plugin_name'
    mock_plugin_defs = {}

    config_manager.initialize_plugin_configuration_definitions(mock_plugin_type, mock_plugin_name, mock_plugin_defs)

    assert mock_plugin_type in config_manager._plugins
    assert mock_plugin_name in config_manager._plugins[mock_plugin_type]
    assert config_manager._plugins[mock_plugin_type][mock_plugin_name] == mock_plugin_defs


# Generated at 2022-06-22 19:35:26.716896
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    ''' test_ConfigManager_initialize_plugin_configuration_definitions '''
    # FIXME: If a code change is done that causes ConfigManager to import AnsiblePluginLoader, this test will be broken
    # by an import error.  This happens because the AnsiblePluginLoader imports config, which causes the config
    # module to try and create an instance of ConfigManager.  The reason for this is that we have three (3)
    # different entry points that create an instance of ConfigManager.  The first one encountered is the one
    # that is actually used, but the ConfigManager constructor is a NO-OP.  The next time that config is imported
    # it tries to create a ConfigManager again.  This is used as a workaround to load the configuration a second
    # time so the state of the configuration is properly reflected in the config module.  This is required to
    #

# Generated at 2022-06-22 19:35:29.208041
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    configManager = ConfigManager()
    assert type(configManager.get_plugin_options(None, None)) == dict

# Generated at 2022-06-22 19:35:31.654740
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
  manager = ConfigManager()
  result = manager.get_config_value_and_origin("name")
  assert(isinstance(result, tuple))
  assert(len(result) == 2)


# Generated at 2022-06-22 19:35:36.941418
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    config = ConfigManager()
    params = {
        'name': 'test_name',
    }
    expected = {}
    with patch.object(ConfigManager, '__init__', lambda x, **kargs: None):
        config.get_configuration_definition(**params)
        assertNotEqual(expected, None)


# Generated at 2022-06-22 19:35:49.641842
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    from ansible.config.manager import ConfigManager
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import find_plugin_config_file
    display = Display()
    config = ConfigManager(parse_only=True)
    cli = CLI(args=['-C'])
    config.parse(cli=cli, display=display)
    config_file = find_plugin_config_file(display.verbosity, display._deprecate_str, config)
    assert config_file

    config.get_config_value_and_origin('log_path', config_file)
    config.get_config_value_and_origin('ansible_log_path', config_file)



# Generated at 2022-06-22 19:36:00.784585
# Unit test for function get_config_type
def test_get_config_type():
    cfile = 'foo.ini'
    assert get_config_type(cfile) == 'ini'
    cfile = 'foo.bar.ini'
    assert get_config_type(cfile) == 'ini'
    cfile = 'foo.bar.ini.cfg'
    assert get_config_type(cfile) == 'ini'
    cfile = 'foo.yaml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'foo.yml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'foo.bar.yaml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'foo.bar.yml'
    assert get_config_type(cfile) == 'yaml'

# Generated at 2022-06-22 19:36:04.761287
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
	
    # Execute the code to be tested
    test = ConfigManager()

    # Verify that the expected and actual results are equal
    assert test.get_configuration_definition() == ''

    # Verify that the expected and actual results are equal
    assert test.get_configuration_definition() == ''



# Generated at 2022-06-22 19:36:17.842576
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    from ansible.config.manager import ConfigManager, Setting
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import iteritems

    mgr = ConfigManager(defs=deepcopy(INTERNAL_DEFS))

    # simple test, no plugin_type, name to test base values
    opts = mgr.get_plugin_options(None, None)

    assert opts['action_plugins'] == u'~/.ansible/plugins/action'
    assert opts['action_plugins'] != u'~/../plugins/action'
    assert opts['action_plugins'] != u'~/.ansible/plugins/action_plugins'
    assert opts['action_plugins'] != u'~/../plugins'
   

# Generated at 2022-06-22 19:36:24.875258
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    entry = {'name': 'foo'}

    config = ConfigManager()
    config.data = FakeVars()
    config.get_config_definition = Mock(return_value={'default': 'bar', 'type': 'string'})

    assert config.get_config_value_and_origin('foo') == ('bar', 'default')

    config.get_config_definition.assert_called_with('foo')



# Generated at 2022-06-22 19:36:30.486931
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    try:
        import ansible
    except Exception:
        pytest.skip('cannot import ansible')

    # dummy AnsibleModule with options and argument_spec
    class AnsibleModule:
        class ModuleDeprecationWarning(UserWarning): pass
        def __init__(self):
            self.argument_spec = {'vault_password_file': {'type': 'bool', 'default': False, 'const': True}}
            self.params = {'vault_password_file': 'foo'}
    module = AnsibleModule()

    # initialize the config manager
    configmgr = ConfigManager(module)

    # get the configuration definitions
    configmgr.get_configuration_definitions(plugin_type='default', name='foo')

    # and verify that the expected warning was triggered
    warnings = warn_about_deprecated

# Generated at 2022-06-22 19:36:43.069460
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    c = ConfigManager(None, read_config_files=False)
    # check legacy defaults
    assert c.get_plugin_options('test', 'default') == {'test_option': 'random_default'}
    # check explicit plugin defaults
    assert c.get_plugin_options('test', 'default', 'test_option') == 'random_default'
    assert c.get_plugin_options('test', 'default', 'missing_option') is None
    # check explicit plugin defaults
    assert c.get_plugin_options('test', 'explicit', 'test_option') == 'explicit_default'
    assert c.get_plugin_options('test', 'explicit', 'missing_option') is None
    # check templated explicit plugin defaults

# Generated at 2022-06-22 19:36:47.340066
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
  # Assume that:
  # defs is None
  # configfile is None
  # an error should be raised
  # init(configfile=None, defs=None)
  # update_config_data(self, defs=None, configfile=None)
  from ansible.config.manager import ConfigManager
  from ansible.errors import AnsibleError
  from ansible.plugins.loader import plugin_loader
  from ansible.parsing.utils.addresses import parse_address
  from ansible.utils.vars import combine_vars
  # create a configManager object
  configManager = ConfigManager()
  # check if the configManager object is initialized properly

# Generated at 2022-06-22 19:36:58.107875
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    import datetime
    _config = ConfigManager()

# Generated at 2022-06-22 19:37:07.038220
# Unit test for function get_config_type
def test_get_config_type():
    ''' unit test to cover the get_config_type function '''
    cases = [('test.ini', 'ini'),
             ('test.cfg', 'ini'),
             ('test.yaml', 'yaml'),
             ('test.yml', 'yaml'),
             ('test.json', 'json'),
             ('test', None)]

    for test_case in cases:
        test_file, result = test_case
        got = get_config_type(test_file)
        assert got == result, \
            "For %s, got %s, expected %s" % \
            (test_file, got, result)



# Generated at 2022-06-22 19:37:16.960719
# Unit test for function get_config_type
def test_get_config_type():
    '''Test config_type function'''
    try:
        get_config_type('test')
    except AnsibleOptionsError:
        pass
    else:
        assert False, "Failed to raise AnsibleOptionsError"

    ftype = get_config_type('test.yaml')
    assert ftype == 'yaml', "Failed to set ftype to yaml"

    ftype = get_config_type('test.yml')
    assert ftype == 'yaml', "Failed to set ftype to yaml when using ftype.yml"

    ftype = get_config_type('test.ini')
    assert ftype == 'ini', "Failed to set ftype to ini"

    ftype = get_config_type('test.cfg')

# Generated at 2022-06-22 19:37:24.586684
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    
    # create instance of class ConfigManager with one argument
    config = ConfigManager('/etc/ansible/ansible.cfg')
    
    # call method initialize_plugin_configuration_definitions of class ConfigManager on object 'config' with one argument
    config.initialize_plugin_configuration_definitions('type', 'name', defs)
    
    # assert that ... ?
    assert True


# Generated at 2022-06-22 19:37:33.929300
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    testConfigManager = ConfigManager()
    assert testConfigManager.get_configuration_definition("artifacts_dir") == {'env': [{'name': 'ANSIBLE_ARTIFACTS_DIR'}], 'ini': [{'section': 'defaults', 'key': 'artifacts_dir'}], 'name': 'artifacts_dir', 'deprecated': {'description': 'Moved to ANSIBLE_ARTIFACTS_DIR'}, 'type': 'path', 'default': ''}


# Generated at 2022-06-22 19:37:41.111809
# Unit test for function resolve_path
def test_resolve_path():
    if os.getcwd() == '/':
        root_dir = '/'
    else:
        root_dir = os.path.join('/', os.getcwd().split('/')[1])

    assert resolve_path('/tmp') == '/tmp'
    assert resolve_path('/tmp', '/root') == '/tmp'
    assert resolve_path('/tmp', '/root/cwd') == '/tmp'
    assert resolve_path('/tmp/cwd1', '/root/cwd') == '/tmp/cwd1'
    assert resolve_path('cwd2', '/tmp/cwd') == '/tmp/cwd/cwd2'
    assert resolve_path('cwd3', '/') == root_dir + '/cwd3'

# Generated at 2022-06-22 19:37:48.588843
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/path/to/file.ini') == 'ini'
    assert get_config_type(None) == None
    assert get_config_type('/path/to/file.cfg') == 'ini'
    assert get_config_type('/path/to/file.yml') == 'yaml'
    assert get_config_type('/path/to/file.yaml') == 'yaml'


# Generated at 2022-06-22 19:37:52.688680
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    '''
    Unit test for method get_config_value of class ConfigManager
    '''
    config_manager = ConfigManager()
    # TODO: add tests for get_config_value method
    # See tests/unit/test_config.py
    raise NotImplementedError



# Generated at 2022-06-22 19:38:01.076099
# Unit test for method get_config_value of class ConfigManager

# Generated at 2022-06-22 19:38:02.633640
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # TODO: test current working dir
    pass


# FIXME: can this be moved to plugin_loader?

# Generated at 2022-06-22 19:38:04.817867
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin()
    assert isinstance(plugin, Plugin)


# Generated at 2022-06-22 19:38:14.096977
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    os.environ.pop('ANSIBLE_CONFIG', None)
    # Current working directory is world writable
    os.mkdir('test_find_ini_config_file_cwd')

# Generated at 2022-06-22 19:38:16.505832
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config=ConfigManager()
    config.get_configuration_definition(config=None, plugin_type=None, plugin_name=None)


# Generated at 2022-06-22 19:38:25.917856
# Unit test for constructor of class Setting
def test_Setting():
    ''' run unit tests for class Setting below '''

    s = Setting('MY_TEST_OPT', 'test', 'origin_test', 'string')
    assert s.name == 'MY_TEST_OPT'
    assert s.value == 'test'
    assert s.origin == 'origin_test'
    assert s.type == 'string'

    s = Setting('MY_TEST_OPT', 11, 'origin_test', 'int')
    assert s.name == 'MY_TEST_OPT'
    assert s.value == 11
    assert s.origin == 'origin_test'
    assert s.type == 'int'

    s = Setting('MY_TEST_OPT', ['list', 'of', 'entries'], 'origin_test', 'list')

# Generated at 2022-06-22 19:38:35.749682
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()
    config_manager.initialize(loader)
    
    config_manager.initialize_plugin_configuration_definitions('strategy', 'linear', {'BAR': {'default': 'bar'}, 'FOO': {'default': 'foo'}})
    assert config_manager._plugins['strategy']['linear'] == {'BAR': {'default': 'bar'}, 'FOO': {'default': 'foo'}}
    
    assert config_manager.get_configuration_definition('FOO', plugin_type='strategy', plugin_name='linear') == {'default': 'foo'}
    assert config_manager.get_configuration_definition('BAR', plugin_type='strategy', plugin_name='linear') == {'default': 'bar'}

# Generated at 2022-06-22 19:38:41.082993
# Unit test for function find_ini_config_file
def test_find_ini_config_file():

    # This is gives us a path for testing.  The 'ansible' dir
    # must be in the same dir as this python file.  This cannot
    # be inside a function since we must have access to the path
    ansible_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    test_dir = os.path.join(ansible_dir, 'test')
    test_config = os.path.join(test_dir, 'test.cfg')
    test_config2 = os.path.join(test_dir, 'test2.cfg')

    # Create a new config file to use while testing
    with open(test_config, 'w') as fp:
        fp.write('[defaults]')

    # Create a second config file to use while testing


# Generated at 2022-06-22 19:38:45.089145
# Unit test for function resolve_path
def test_resolve_path():
    if sys.version_info[0] < 3:
        path = b'~/ansible'
        assert resolve_path(path) == os.path.expanduser(path)
        assert resolve_path('{{CWD}}/out') == os.getcwd() + '/out'



# Generated at 2022-06-22 19:38:49.183957
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    from ansible.config.manager import ConfigManager
    config = ConfigManager(['/etc/ansible/ansible.cfg'])
    result = config.update_config_data()
    assert result is None


# Generated at 2022-06-22 19:38:51.991275
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    plugin_type = 'str'
    name = 'str'
    defs = 'str'

    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert config_manager._plugins[plugin_type][name] == defs
# unit test for method __getattr__ of class ConfigManager

# Generated at 2022-06-22 19:39:04.077954
# Unit test for constructor of class Plugin
def test_Plugin():
    # empty plugins
    plugin = Plugin()
    assert plugin._plugins == {}, '__init__() creates _plugins'

    # non-empty plugins
    plugin = Plugin(plugins={'callback': {'minimal':
                                          {'name': 'minimal',
                                           'env': [{'name': 'MINIMAL_CALLBACK', 'value': {'type': 'bool', 'choices': [False, True]}}],
                                           'default': False}}})

# Generated at 2022-06-22 19:39:07.064410
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager()
    with pytest.raises(AnsibleError):
        config.initialize_plugin_configuration_definitions(None, None, None)

# Generated at 2022-06-22 19:39:13.914899
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    tp = configparser.ConfigParser()
    tp.add_section('def')
    tp.set('def', 'name', 'testvalue')
    assert get_ini_config_value(tp, {'key': 'name'}) == 'testvalue'
    assert get_ini_config_value(tp, {'key': 'name', 'section': 'def'}) == 'testvalue'
    assert get_ini_config_value(tp, {'section': 'def', 'key': 'name'}) == 'testvalue'


# FIXME: this is the same as utils/yaml.get_yaml_config_value

# Generated at 2022-06-22 19:39:25.070583
# Unit test for constructor of class Setting

# Generated at 2022-06-22 19:39:27.505553
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    c = ConfigManager()
    c.parser.set('meh', 'testing', 'True')
    assert c.get_config_value('testing', cfile='meh') == True


# Generated at 2022-06-22 19:39:37.766443
# Unit test for constructor of class Setting
def test_Setting():
    setting1 = Setting('foo', 'bar', 'baz', 'boolean')
    assert setting1.name == 'FOO'
    assert setting1.value == 'bar'
    assert setting1.origin == 'baz'
    assert setting1.value_type == 'boolean'

    setting2 = Setting('ansible_python_interpreter', '/usr/bin/python3', 'config file', 'path', False)
    assert setting2.name == 'ANSIBLE_PYTHON_INTERPRETER'
    assert setting2.value == '/usr/bin/python3'
    assert setting2.origin == 'config file'
    assert setting2.value_type == 'path'
    assert setting2.runtime is False


# Generated at 2022-06-22 19:39:45.922092
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    '''
    Unit test for ConfigManager::get_plugin_options()
    '''

    config = ConfigManager()

    options = config.get_plugin_options('callback', 'default')
    assert 'callback_whitelist' in options

    options = config.get_plugin_options('callback', 'foobar')
    assert 'callback_whitelist' in options

    options = config.get_plugin_options(None, None)
    assert 'callback_whitelist' in options



# Generated at 2022-06-22 19:39:51.257938
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    # Test when p is a ConfigParser object
    p = configparser.ConfigParser()
    p.add_section('section')
    p.set('section', 'key', 'value')
    entry = dict(section='section', key='key')
    assert get_ini_config_value(p, entry) == 'value'
    # Test when p is None
    assert get_ini_config_value(None, entry) is None


# FIXME: could we use the same class for both ini and yaml?

# Generated at 2022-06-22 19:39:54.454343
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    # Initialize test environment
    config_manager = get_config_manager()

    # Test execution of method get_plugin_options
    config_manager.get_plugin_options()

# Generated at 2022-06-22 19:40:04.574260
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    cfg = ConfigManager(['/tmp/ansible.cfg'])
    assert cfg.get_plugin_vars(u'playbook', u'static') == []
    assert cfg.get_plugin_vars(u'connection', u'local') == [u'ansible_connection']
    assert cfg.get_plugin_vars(u'stdout_callback', u'yaml') == []
    assert cfg.get_plugin_vars(u'lookup', u'password') == []
    assert cfg.get_plugin_vars(u'filter', u'jsonquery') == []
    assert cfg.get_plugin_vars(u'action_plugin', u'copy') == [u'action_copy']

# Generated at 2022-06-22 19:40:06.546377
# Unit test for constructor of class Plugin
def test_Plugin():
    """
    Plugin - constructor
    """

    plugin = Plugin()
    assert isinstance(plugin, Plugin)

# Generated at 2022-06-22 19:40:15.729618
# Unit test for constructor of class Setting
def test_Setting():
    config = Setting('config1', 1, 'constant', 'int')
    assert config == Setting('config1', 1, 'constant', 'int')
    assert config < Setting('config2', 1, 'constant', 'int')
    assert config < Setting('config1', 2, 'constant', 'int')
    assert config < Setting('config1', 1, 'constant2', 'int')
    assert config < Setting('config1', 1, 'constant', 'str')


__all__ = ['Setting', 'AnsibleOptions', 'AnsibleOptionsError', 'CLIARGS', 'test_Setting']

# Generated at 2022-06-22 19:40:24.246928
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # TODO: Add additional tests
    set_env = os.environ.copy()
    # Test where ANSIBLE_CONFIG is specified but does not exist
    os.environ["ANSIBLE_CONFIG"] = "Unexistant Path"
    assert find_ini_config_file() is None
    del os.environ["ANSIBLE_CONFIG"]

    # Test where there's a file that we can't read, but can't go further because it's world writable
    cwd = os.getcwd()
    assert cwd == find_ini_config_file()

    os.environ.clear()
    os.environ.update(set_env)



# Generated at 2022-06-22 19:40:25.403317
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    assert False



# Generated at 2022-06-22 19:40:30.943397
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    # Create empty ConfigManager object
    configmanager_object = ConfigManager()

    # Get args needed to instantiate defs
    defs = configmanager_object.get_configuration_definition('config')
    configfile = configmanager_object.get_config_value('config')

    # Run method under test
    configmanager_object.update_config_data(defs=defs, configfile=configfile)
