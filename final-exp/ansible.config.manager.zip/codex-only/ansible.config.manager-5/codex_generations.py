

# Generated at 2022-06-22 19:30:29.904172
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    return None


# Generated at 2022-06-22 19:30:34.976983
# Unit test for function get_config_type
def test_get_config_type():
    ''' test get_config_type '''
    yaml_file = sys.modules['__main__'].__file__.replace('.pyc', '.yml')
    ini_file = sys.modules['__main__'].__file__.replace('.pyc', '.ini')
    assert get_config_type(yaml_file) == 'yaml'
    assert get_config_type(ini_file) == 'ini'
    try:
        get_config_type(__file__)
    except AnsibleOptionsError:
        pass
    else:
        raise Exception('expected an exception')


# FIXME: generic file type?

# Generated at 2022-06-22 19:30:47.481948
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    assert not get_ini_config_value(None, {'section': 'defaults', 'key': None})
    assert get_ini_config_value(configparser.RawConfigParser(), {'section': 'defaults', 'key': 'ssh_args'}) == "-C -o ControlMaster=auto -o ControlPersist=60s"
    assert get_ini_config_value(configparser.RawConfigParser(), {'section': 'defaults', 'key': 'roles_path'}) == "~/.ansible/roles:/etc/ansible/roles:/usr/share/ansible/roles"
    assert get_ini_config_value(configparser.RawConfigParser(), {'section': 'defaults', 'key': 'private_key_file'}) == '~/.ssh/id_rsa'

# FIXME: can move

# Generated at 2022-06-22 19:30:53.591911
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
  from ansible.config.manager import ConfigManager
  from ansible.config.data import Setting, ConfigData
  
  config_data = ConfigData()
  config_data.update_setting(Setting('CONFIG_FILE', '/path/to/my/ansible.cfg'))

  object_under_test = ConfigManager(config_data=config_data)

  defs = {'ANSIBLE_FOO': {'default': 'my_default', 'type': 'string'}}

  return_value = object_under_test.update_config_data(defs)

  assert return_value is None

# Generated at 2022-06-22 19:30:55.292769
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
  config = ConfigManager()


# Generated at 2022-06-22 19:30:59.256565
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    try:
        c = ConfigManager()
        c.get_config_value('core')
    except Exception as e:
        assert False, "Unable to get_config_value: %s" % e

# Generated at 2022-06-22 19:31:07.803844
# Unit test for function get_config_type
def test_get_config_type():
    assert('ini' == get_config_type('/etc/ansible/ansible.cfg'))
    assert('yaml' == get_config_type('/etc/ansible/ansible.yaml'))
    assert('yaml' == get_config_type('/etc/ansible/ansible.yml'))
    try:
        get_config_type('/etc/ansible/ansible.conf')
    except AnsibleOptionsError as e:
        pass
    else:
        assert False



# Generated at 2022-06-22 19:31:15.864708
# Unit test for constructor of class Setting
def test_Setting():
    assert Setting('foo', 'bar', 'baz', 'string').name=='foo'
    assert Setting('foo', 'bar', 'baz', 'string').value=='bar'
    assert Setting('foo', 'bar', 'baz', 'string').origin=='baz'
    assert Setting('foo', 'bar', 'baz', 'string').string_type=='string'
    assert repr(Setting('foo', 'bar', 'baz', 'string'))=="<Setting name='foo', value='bar', origin='baz', string_type='string'>"


# Generated at 2022-06-22 19:31:19.903062
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    '''
    ConfigManager.get_config_value()
    '''

    # test with no args
    try:
        ConfigManager.get_config_value()
    except SystemExit as e:
        assert e.code == 1



# Generated at 2022-06-22 19:31:22.754283
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    myConfigManager = ConfigManager()
    print(myConfigManager.get_configuration_definitions())

# Generated at 2022-06-22 19:31:27.527524
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()
    print(ConfigManager._ConfigManager__diagnose_config_update_error(config_manager, test_AnsibleError, 'bar'))
    print(config_manager.get_configuration_definition(test_Unicode))


# Generated at 2022-06-22 19:31:28.763668
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    pass


# Generated at 2022-06-22 19:31:30.778077
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    c = ConfigManager(None)
    c._base_defs = {'FOO': {}}
    assert c.get_config_value('FOO') is None



# Generated at 2022-06-22 19:31:44.129759
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config_manager = ConfigManager()
    assert config_manager.initialize_plugin_configuration_definitions is not None

    # ConfigManager.initialize_plugin_configuration_definitions() when plugin_type, name and defs are passed.
    config_manager.initialize_plugin_configuration_definitions('plugin_type', 'name', 'defs')
    assert config_manager._plugins.get('plugin_type') == {'name': 'defs'}

    # ConfigManager.initialize_plugin_configuration_definitions() when name and defs are passed.
    config_manager.initialize_plugin_configuration_definitions('name', 'defs')
    assert config_manager._base_defs.get('name') == 'defs'

    # ConfigManager.initialize_plugin_configuration_definitions() when plugin_

# Generated at 2022-06-22 19:31:55.990010
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    ''' returns the path of the first config file found in the lookup order '''
    cwd = os.getcwd()
    ansible_cfg = os.path.join(cwd, "ansible.cfg")


# Generated at 2022-06-22 19:32:06.264641
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    unit test for method get_config_value_and_origin

    '''
    # test for config is not valid
    with pytest.raises(Exception) as e:
        config = 'test_get_config_value_and_origin'
        from ansible.cli import CLI
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.inventory import Inventory
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager

        # create object
        variable_manager = VariableManager()
        loader = DataLoader()

# Generated at 2022-06-22 19:32:18.722725
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Values that can't be a path (there are more than this, but these are sufficient)
    SENTINEL = object

    # Imitate an environment that doesn't exist (for coverage's sake)
    os.path.isdir = lambda x: False

    os.getenv = lambda x: {}.get(x, SENTINEL)
    os.path.exists = lambda x: False
    os.path.isfile = lambda x: False
    os.access = lambda x, y: False
    assert find_ini_config_file() is None

    from ansible.constants import DEFAULT_CFG_PATH
    os.getenv = lambda x: {'ANSIBLE_CONFIG': DEFAULT_CFG_PATH}.get(x, SENTINEL)
    os.path.exists = lambda x: False
    assert find

# Generated at 2022-06-22 19:32:24.469858
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    obj = ConfigManager()
    obj._base_defs = _get_base_defs(obj)

    #TODO: test this
    #obj.get_config_value(config, cfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None)

# Generated at 2022-06-22 19:32:29.059684
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    '''
    >>> from ansible.config.manager import ConfigManager
    >>> cm = ConfigManager()
    
    # make sure we can retrieve the config file if it's set
    >>> cm.get_config_file()
    '''
    pass


# Generated at 2022-06-22 19:32:36.191979
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    CONFIG = ConfigManager()

    # constants
    assert(CONFIG.DEFAULTS == DEFAULTS)
    assert(CONFIG.BOOLEANS == BOOLEANS)

    # empty configs
    for c in CONFIG.data.settings:
        assert(c.origin != 'default')

    # empty configs
    for c in CONFIG.data.settings:
        assert(c.origin != 'default')

    # empty configs
    for c in CONFIG.data.settings:
        assert(c.origin != 'default')

# Reading config data from command line

# Generated at 2022-06-22 19:32:42.878746
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    c = ConfigManager()
    assert c.data is not None
    assert c.data.settings is not None
    assert c.data.settings.get("CONFIG_FILE", None) is not None
    assert c.data.settings.get("HOST_KEY_CHECKING", None) is not None
    assert c.data.settings.get("HOST_KEY_CHECKING").origin is not None
    assert c.data.settings.get("HOST_KEY_CHECKING").value is not None


# Generated at 2022-06-22 19:32:53.972809
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    print("Testing method get_configuration_definition")
    c = ConfigManager(dict(), None)
    print(" ... testing defaults")
    # given no arguments should return all default settings
    assert c.get_configuration_definition() == c._base_defs
    print(" ... testing plugin type")
    # given no name should return all settings for that type
    assert c.get_configuration_definition('module') == c._plugins['module']
    print(" ... testing plugin name")
    # given a name should return all settings for that name
    assert c.get_configuration_definition('module', 'command') == c._plugins['module']['command']
    print(" ... testing key in plugin name")
    # given a specific key should return the setting for that key

# Generated at 2022-06-22 19:33:06.698903
# Unit test for function resolve_path
def test_resolve_path():
    ''' test resolve_path '''
    test_path = os.path.realpath(__file__)
    test_rel_path = '../../lib/ansible/modules/core/cloud/rackspace/rax.py'
    test_rel_path_expected = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(test_path))))
    test_rel_path_expected = os.path.join(test_rel_path_expected, 'lib/ansible/modules/core/cloud/rackspace/rax.py')
    test_rel_path_expected = os.path.realpath(test_rel_path_expected)
    test_rel_path_cwd = '{{CWD}}/' + test_rel_path
    test_expand_path = os

# Generated at 2022-06-22 19:33:09.662454
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    manager = ConfigManager()
    assert manager.get_config_value_and_origin('ANSIBLE_HOST_KEY_CHECKING')[0] == False



# Generated at 2022-06-22 19:33:16.179741
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():

    # initialize_plugin_configuration_definitions(self, plugin_type, name, defs)
    # test with plugin_type = None
    try:
        # initialization without arguments should fail
        config_manager = ConfigManager()
        config_manager.initialize_plugin_configuration_definitions()
        assert(False)
    except TypeError as e:
        assert(True)


# Generated at 2022-06-22 19:33:26.133273
# Unit test for function resolve_path
def test_resolve_path():
    ''' return the result of a unit test '''

    if sys.platform == 'darwin':
        path_sep = '/'
    else:
        path_sep = os.path.sep

    current_dir = os.getcwd()

    assert resolve_path('') == ''
    assert resolve_path(None) is None
    assert resolve_path('foo') == 'foo'
    assert resolve_path(path_sep) == path_sep
    assert resolve_path(current_dir) == current_dir
    assert resolve_path(os.path.join(path_sep, 'foo', 'bar')) == os.path.join(path_sep, 'foo', 'bar')

    return True



# Generated at 2022-06-22 19:33:37.145754
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    import os
    import shutil
    import tempfile

    # Assert that we have a clean environment before running this test
    assert not os.getenv("ANSIBLE_CONFIG")
    assert not os.path.exists("ansible.cfg")
    assert not os.path.exists("/etc/ansible/ansible.cfg")

    cwd = os.getcwd()
    warnings = set()


# Generated at 2022-06-22 19:33:43.282540
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    ''' Test case for initializing plugin configuration definitions'''
    configmanager = ConfigManager()
    test_plugin_type = 'test'
    test_name = 'test'
    test_defs = {}
    configmanager.initialize_plugin_configuration_definitions(test_plugin_type, test_name, test_defs)
    assert configmanager._plugins.get(test_plugin_type, {}).get(test_name) == test_defs


# Generated at 2022-06-22 19:33:48.019944
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager(module_path='module_path', module_name='module_name')
    plugin_type = 'plugin_type'
    name = 'name'
    ignore_private = 'ignore_private'
    defs = config.get_configuration_definitions(plugin_type=plugin_type, name=name, ignore_private=ignore_private)
    assert isinstance(defs, dict)


# Generated at 2022-06-22 19:33:54.348023
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    cm = ConfigManager(config_data=ConfigData())
    cm.update_config_data()
    cm.update_config_data({'CONFIG_FILE': {}})

# Generated at 2022-06-22 19:33:57.368227
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
  plugin_type='callback'
  
  # test normal behavior
  # test__ConfigManager_initialize_plugin_configuration_definitions_1()
  c = config.ConfigManager()
  # test with non-default parameters
  # test__ConfigManager_initialize_plugin_configuration_definitions_2()
  c = config.ConfigManager()


# Generated at 2022-06-22 19:34:07.406026
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('./test.txt') == os.getcwd() + '/test.txt'
    assert resolve_path('~/test.txt') == os.getenv('HOME') + '/test.txt'
    assert resolve_path('test.txt') == os.getcwd() + '/test.txt'
    if os.getenv('HOME'):
        assert resolve_path('~/test.txt', basedir='/tmp') == os.getenv('HOME') + '/test.txt'
    assert resolve_path('./test.txt', basedir='/tmp') == '/tmp/test.txt'
    assert resolve_path('test.txt', basedir='/tmp') == '/tmp/test.txt'
    assert resolve_path('~/test.txt', basedir='/tmp') == os.getenv('HOME')

# Generated at 2022-06-22 19:34:09.801949
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    assert ConfigManager().get_configuration_definition('_') == None


# Generated at 2022-06-22 19:34:14.096326
# Unit test for constructor of class Plugin
def test_Plugin():
    from ansible.utils.vars import combine_vars

    p = Plugin('/does-not-exist')
    assert p.name == 'None of the above'
    assert p.path is None

    p = Plugin('/usr/lib/python2.7/dist-packages/ansible/plugins/strategies/__init__.py')
    assert p.name == 'strategies'
    assert p.path == '/usr/lib/python2.7/dist-packages/ansible/plugins/strategies'

    p = Plugin('/usr/lib/python2.7/dist-packages/ansible/plugins/strategies/free.py')
    assert p.name == 'free strategy plugin'

# Generated at 2022-06-22 19:34:16.707716
# Unit test for constructor of class Plugin
def test_Plugin():
    p = Plugin()
    assert p.name  == '_default'
    assert p.config  == DEFAULT_CONFIG


# Generated at 2022-06-22 19:34:26.680606
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    manager = ConfigManager()

# Generated at 2022-06-22 19:34:40.661122
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test with defaults
    c = ConfigManager()
    assert c.get_config_value_and_origin('fact_cache_enabled', None) == (True, 'default')

    # Test with environment variable
    os.environ['ANSIBLE_FACT_CACHE_ENABLED'] = 'True'
    assert c.get_config_value_and_origin('fact_cache_enabled', None) == (True, 'env:ANSIBLE_FACT_CACHE_ENABLED')
    del os.environ['ANSIBLE_FACT_CACHE_ENABLED']

    # Test with direct variable override
    assert c.get_config_value_and_origin('fact_cache_enabled', None, direct={'fact_cache_enabled': False}) == (False, 'Direct')

    # Test with variable override

# Generated at 2022-06-22 19:34:49.035883
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager

# Generated at 2022-06-22 19:35:01.511375
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    '''
    This test uses a fixture located at 'test/sanity/test-find_ini_config_file.ini'

    The file is copied over the default ansible.cfg to avoid the presence of the ~/.ansible.cfg
    affecting the test.
    '''

    import shutil
    import tempfile
    import pytest

    # Create temp folder that will be used as current working directory
    cwd = tempfile.mkdtemp(prefix='ansible_test_find_ini_config_file')

    # Get location of ansible.cfg fixture
    ansible_cfg_fixture = 'test/sanity/test-find_ini_config_file.ini'
    ansible_cfg_fixture = unfrackpath(ansible_cfg_fixture)

    # Copy fixture ansible.cfg to the current working directory
    shutil

# Generated at 2022-06-22 19:35:06.192635
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    assert find_ini_config_file() is not None


# FIXME: can move to module_utils for use for ini plugins also?

# Generated at 2022-06-22 19:35:17.316602
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    import sys
    import ansible.utils.template as template
    import ansible.errors as errors
    import ansible.constants as constants
    import ansible.constants as constants

    CM = ConfigManager(constants.CLI_CONFIG_FILE, constants.DEFAULT_CONFIG_FILE)
    plugin_type = 'parser'
    name = 'ansible-inventory'
    defs = CM.get_configuration_definitions(plugin_type, name)
    config = 'vars'
    ret = CM.get_configuration_definition(config, plugin_type, name)
    assert 'vars' in ret
    assert ret['required'] == False
    assert ret['name'] == 'vars'
    assert ret['type'] == 'list'

# Generated at 2022-06-22 19:35:20.682113
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(u'hello', u'boolean') == u'true'
    assert ensure_type(u'1.0', u'float') == 1.0



# Generated at 2022-06-22 19:35:25.220991
# Unit test for function get_config_type
def test_get_config_type():
    cfg_file = './test/fixtures/get_config_type/' \
            'test_get_config_type.yaml'

    ftype = get_config_type(cfg_file)
    assert ftype == 'yaml'

# FIXME: merge this with bin/action_plugins/config_reader.yaml

# Generated at 2022-06-22 19:35:27.292846
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager()
    return config

# Create instance of class ConfigManager and assign it as a global variable
CONFIG = test_ConfigManager()


# Generated at 2022-06-22 19:35:30.070894
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_manager = ConfigManager()
    assert isinstance(config_manager, ConfigManager)


# Generated at 2022-06-22 19:35:42.906279
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    '''
    test init with good config file
    test init with bad config file
    test init with good config dir, no config file
    '''

    import tempfile

    # minimal config file
    conf_data = '''
[defaults]
roles_path = /etc/ansible/roles
'''

    # create temp dir and config file
    tmp_dir = tempfile.mkdtemp(prefix="ansible_test_")
    tmp_config = os.path.join(tmp_dir, 'ansible.cfg')
    with open(tmp_config, 'w') as f:
        f.write(conf_data)

    # make sure we find it
    assert os.path.exists(tmp_config)

    c = ConfigManager(tmp_config)
    assert c.config_file == tmp_config


# Generated at 2022-06-22 19:35:54.878993
# Unit test for function get_config_type
def test_get_config_type():
    if get_config_type(None) != None:
        print("Error for get_config_type(None)!")

    if get_config_type("/path/to/file.ini") != "ini":
        print("Error for get_config_type(\"/path/to/file.ini\")!")

    if get_config_type("/path/to/file.cfg") != "ini":
        print("Error for get_config_type(\"/path/to/file.cfg\")!")

    if get_config_type("/path/to/file.yaml") != "yaml":
        print("Error for get_config_type(\"/path/to/file.yaml\")!")


# Generated at 2022-06-22 19:36:06.012786
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()

# Generated at 2022-06-22 19:36:19.098270
# Unit test for function get_config_type
def test_get_config_type():

    # file type: yaml
    yaml_test_file = "test.yaml"
    with pytest.raises(AnsibleOptionsError) as err:
        get_config_type(yaml_test_file)
    assert 'Unsupported configuration file extension for %s' % yaml_test_file in to_native(err.value)

    # file type: ini
    ini_test_file = "test.ini"
    with pytest.raises(AnsibleOptionsError) as err:
        get_config_type(ini_test_file)
    assert 'Unsupported configuration file extension for %s' % ini_test_file in to_native(err.value)

    # file type: unknown
    unknown_test_file = "unknown_test_file"

# Generated at 2022-06-22 19:36:26.407272
# Unit test for function get_config_type
def test_get_config_type():
    cfg = ConfigData()
    assert 'ini' == get_config_type(cfg.config_file)
    assert 'yaml' == get_config_type(cfg.ansible_config_file)
    try:
        get_config_type('test.txt')
        assert False, "ansible_options_error not raised"
    except AnsibleOptionsError:
        assert True


# Generated at 2022-06-22 19:36:34.751312
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    import tempfile
    import os
    import shutil
    import textwrap
    
    # Assume ansible.cfg is not present, we're running in test mode or development mode
    # (code to detect ansible.cfg in same directory as this file removed)
    # so create a new one
    tmpdir = tempfile.mkdtemp()
    cfg_file = os.path.join(tmpdir, 'ansible.cfg')
    with open(cfg_file, 'w') as fp:
        fp.write(textwrap.dedent("""
            [ssh_connection]
            ssh_args = -o ControlMaster=auto -o ControlPersist=60s
        """))
    assert os.path.exists(cfg_file), 'Test setup failed to create temp cfg file'
    

# Generated at 2022-06-22 19:36:44.534097
# Unit test for function get_config_type
def test_get_config_type():
    '''unit tests for get_config_type'''

    cfile = 'foo.cfg'
    assert get_config_type(cfile) == 'ini'
    cfile = 'bar.ini'
    assert get_config_type(cfile) == 'ini'
    cfile = 'foo.yaml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'bar.yml'
    assert get_config_type(cfile) == 'yaml'
    cfile = 'baz.bar'
    try:
        get_config_type(cfile)
    except AnsibleOptionsError:
        pass
    else:
        assert False



# Generated at 2022-06-22 19:36:54.807930
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # Initialize Mock object
    config_manager = ConfigManager("")
    
    # We replace the method get_configuration_definitions with a Mock object
    # because get_configuration_definitions is too complex to test
    config_manager.get_configuration_definitions = Mock(return_value = {})
    
    # Test that this method will return an empty dict if the dict returned by get_configuration_definitions is empty
    assert config_manager.get_configuration_definition("foo") == {}
    
    # Test that if we provide a name as argument, if the dict returned by get_configuration_definitions contains a foo key
    # the value for this key is returned, otherwise an empty dict is returned
    config_manager.get_configuration_definitions = Mock(return_value = {"foo" : "value"})

# Generated at 2022-06-22 19:37:05.388278
# Unit test for constructor of class Plugin
def test_Plugin():

    assert issubclass(Plugin, object)
    assert getattr(Plugin, '__init__', None)
    assert getattr(Plugin, 'get_plugin_class', None)
    assert getattr(Plugin, 'get_plugins', None)
    assert getattr(Plugin, 'has_plugin', None)
    assert getattr(Plugin, 'cleanup_plugins', None)
    assert getattr(Plugin, 'load_plugins', None)
    assert getattr(Plugin, 'register_plugin', None)
    assert getattr(Plugin, 'register_plugins', None)



# Generated at 2022-06-22 19:37:07.295085
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    # TODO: Add tests
    pass

# Generated at 2022-06-22 19:37:18.821328
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    from ansible.errors import AnsibleOptionsError
    from ansible.constants import DEFAULT_LOG_PATH
    from ansible.constants import DEFAULT_PRIVATE_KEY_FILE

    defs = {
        'action_plugins': {
            'foo': {
                'bar': {
                    'default': 'somedefault',
                    'type': 'string',
                    'ini': [{'key': 'bar', 'section': 'defaults'}],
                    'yaml': [{'key': 'bar'}],
                    'env': [{'name': 'ANSIBLE_ACTION_PLUGINS_FOO_BAR'}],
                    'ini_parser': True
                }
            }
        }
    }


# Generated at 2022-06-22 19:37:23.091493
# Unit test for function get_config_type
def test_get_config_type():
    cfile = '/etc/ansible/ansible.cfg'
    config_type = get_config_type(cfile)
    assert config_type in ('ini', 'yaml')



# Generated at 2022-06-22 19:37:28.956500
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    Test get_config_value_and_origin with invalid data
    '''
    config_manager = ConfigManager()
    with pytest.raises(AnsibleOptionsError):
        config_manager.get_config_value_and_origin("config_name", configfile="junk")


# Generated at 2022-06-22 19:37:40.809481
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    import ansible.constants
    import ansible.plugins.cliconf

    constants.HOST_KEY_CHECKING = None
    constants.DEPRECATION_WARNINGS = None

    m = ConfigManager()
    m.initialize_plugin_configuration_definitions('cliconf', 'ios', ansible.plugins.cliconf.ios.CLICONF_ARGS)
    assert m.get_plugin_options('cliconf', 'ios', keys={'host_key_checking': False}) == {'host_key_checking': False}
    assert constants.HOST_KEY_CHECKING is False

    constants.HOST_KEY_CHECKING = None
    constants.DEPRECATION_WARNINGS = set()
    constants.CONFIG_FILE = ''
    constants.DEFAULT_MODULE_NAME = 'command'

    m

# Generated at 2022-06-22 19:37:43.914315
# Unit test for constructor of class Plugin
def test_Plugin():

    plugin = Plugin()
    assert plugin is not None
    plugin.CONSTANT = 'value'
    assert plugin.CONSTANT == 'value'


# Generated at 2022-06-22 19:37:48.772390
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    import pytest
    args = [ConfigManager]
    kwargs = {}
    config_manager = ConfigManager()
    results = config_manager.get_configuration_definition(*args, **kwargs)
    assert results == {}

# Generated at 2022-06-22 19:37:58.639496
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
	# Need to make sure that the global config is loaded but not parsed.
	# Otherwise, parse errors will break tests that expect certain option
	# values to not be set.
	config = ConfigManager()
	config._load_config_file()

	# test getting options
	option = 'host_key_checking'
	option_def = config.get_configuration_definition(option)
	assert option_def is not None
	assert 'description' in option_def
	assert 'name' in option_def
	assert option_def['name'] == option
	assert 'env' in option_def
	assert 'type' in option_def
	assert option_def['type'] == 'bool'

	# test getting options with env and ini configs
	# we do this here to make sure the config has not been parsed
	# (b/c

# Generated at 2022-06-22 19:38:08.128916
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():

    # setup test config and parser
    config_manager = ConfigManager()
    plugin_type = 'callback'
    plugin_name = 'junit'
    plugin_defs = {
        '_config_file': [{'section': 'defaults', 'key': 'callback_whitelist', 'type': 'string', 'required': False, 'vars': [{'name': 'ANSIBLE_CALLBACK_WHITELIST', 'type': 'string'}]}],
        'callback_whitelist': [],
        'output_dir': [],
        'exclude_paths': [],
        'include_paths': [],
        'host': [],
        'host_pattern': [],
        'record_host': []
    }

# Generated at 2022-06-22 19:38:16.369296
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():

    import ansible.constants as C
    import tempfile
    import os

    # create a temp config file
    fd, configfile = tempfile.mkstemp()

    with os.fdopen(fd, 'w') as tmp:
        tmp.write("# a test file\n")
        tmp.write("LOG_FILE=/var/log/test.log\n")
        tmp.write("\n")
        tmp.write("[inventory]\n")
        tmp.write("script = /etc/ansible/hostfile\n")
        tmp.write("\n")
        tmp.write("# this is a comment\n")
        tmp.write("vars_plugins = /etc/ansible/varplugins\n")
        tmp.write("# another comment\n")
        tmp.write("\n")
        tmp

# Generated at 2022-06-22 19:38:27.791576
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config = ConfigManager()
    plugin_type = 'FooType'
    name = 'FooName'
    keys = {}
    variables = {}
    direct = {}
    if sys.version_info[0] >= 3:
        assert isinstance(config.get_plugin_options(plugin_type, name, keys, variables, direct), dict)
    else:
        assert isinstance(config.get_plugin_options(plugin_type, name, keys, variables, direct), dict)
    config = ConfigManager()
    plugin_type = 'FooType'
    name = 'FooName'
    keys = {}
    variables = {}
    direct = {}
    if sys.version_info[0] >= 3:
        assert isinstance(config.get_plugin_options(plugin_type, name, keys, variables, direct), dict)

# Generated at 2022-06-22 19:38:36.496573
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    '''
       Test for ConfigManager constructor
    '''
    #Null initialization
    configManager = ConfigManager()

    #Invalid initialization
    try:
        configManager = ConfigManager('invalid')
        assert False, 'ConfigManager should have failed to initialize with invalid config file path'
    except IOError:
        pass

    #Valid initialization
    configManager = ConfigManager(None)
    configManager = ConfigManager('~/nonexistent')

    #Valid initialization with env variable test
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'True'
    configManager = ConfigManager(None)
    assert not configManager.data.HOST_KEY_CHECKING, 'HOST_KEY_CHECKING should be False'
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    config

# Generated at 2022-06-22 19:38:42.505514
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin('test', './test/ansible')
    assert plugin._subdir == 'test'
    assert plugin._subdir_full is not None
    assert plugin._subdir_full.endswith('/test/ansible')
    assert plugin._basedir.endswith('/test')
    assert plugin._basename == 'ansible'
    assert plugin.configuration_definitions() is None


# Generated at 2022-06-22 19:38:50.828335
# Unit test for function get_config_type
def test_get_config_type():
    exts = {
        "ini": [
            ".ini",
            ".cfg"
        ],
        "yaml": [
            ".yaml",
            ".yml"
        ]
    }
    for ftype, extensions in exts.items():
        for ext in extensions:
            cfile = 'config' + ext
            assert get_config_type(cfile) == ftype
            assert get_config_type('config_file') == None


# FIXME: generic file type?

# Generated at 2022-06-22 19:38:54.392545
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    test_obj = ConfigManager()
    defs = {}
    configfile = ""
    test_obj.update_config_data(defs=defs, configfile=configfile)

# Generated at 2022-06-22 19:38:56.664368
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    try:
        config_manager = ConfigManager()
        config_manager.get_configuration_definitions()
    except:
        assert False, "ConfigManager should have a method called get_configuration_definitions()"


# Generated at 2022-06-22 19:39:01.761553
# Unit test for constructor of class Setting
def test_Setting():
    setting = Setting('ANSIBLE_CALLBACK_WHITELIST', ['default'], 'constant', 'list')
    assert setting.name == 'ANSIBLE_CALLBACK_WHITELIST'
    assert setting.value == ['default']
    assert setting.origin == 'constant'
    assert setting.type == 'list'
    assert setting.default_value == ['default']
    assert setting.value_type == 'list'

    setting.set_value(['email'])
    assert setting.value == ['default', 'email']
    assert setting.origin == 'constant'
    assert setting.type == 'list'

    setting.set_value(None)
    assert setting.value == ['default', 'email']
    assert setting.origin == 'constant'
    assert setting.type == 'list'


# Generated at 2022-06-22 19:39:12.204638
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():

    from ansible.config.manager import ConfigManager, Setting
    from ansible.config.data import ConfigData

    def test_load_config_file(self):
        self.load_config_file('./test/ansible.cfg')
        settings = ConfigManager._load_plugin_vars(self._parsers['/root/src/ansible/test/ansible.cfg'], 'test', 'test_variable_manager')
        assert(len(settings) > 0)

    def test_load_config_file_manager_test_version2(self):
        # set ANSIBLE_INVENTORY if not set
        if 'ANSIBLE_INVENTORY' not in os.environ:
            os.environ['ANSIBLE_INVENTORY'] = './test/hosts'

        self.load_config_

# Generated at 2022-06-22 19:39:23.446529
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()

# Generated at 2022-06-22 19:39:34.369007
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/foo/{{CWD}}') == '/foo/{{CWD}}'
    assert resolve_path('/tmp') == '/tmp'
    assert resolve_path('/{{CWD}}/tmp') == '/{{CWD}}/tmp'
    # On Windows, resolve_path() isn't viable: we can't set os.path.realpath()
    #   to return 'bad' results, and resolve_path() is based on realpath().
    #   This makes the test for "following symlinks" invalid.
    #   See https://github.com/ansible/ansible/issues/42311 for details.
    if sys.platform != 'win32':
        assert resolve_path("/tmp/foo") != resolve_path("/tmp/foo/../foo")

# Generated at 2022-06-22 19:39:46.247420
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    test_instance = ConfigManager()
    def test_get_configuration_definitions(self):
        ret = self.get_configuration_definitions(None, None)

# Generated at 2022-06-22 19:39:51.117513
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # Put your unit-test code here !!!
    configManager = None
    testCases = []
    for testCase in testCases:
        configManager.get_configuration_definition(*testCase[0])

# Generated at 2022-06-22 19:40:02.123928
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    c = ConfigManager()
    config_file = "tests/files/ansible.cfg"
    config = "inventory"

    value = c.get_config_value(config, config_file)
    assert value == 'tests/files/hosts'

    config = "roles_path"

    value = c.get_config_value(config, config_file)
    assert value == 'test/files/roles'

    config = "host_key_checking"

    value = c.get_config_value(config, config_file)
    assert value == False

    config = "ansible_managed"

    value = c.get_config_value(config, config_file)
    assert value == "Ansible managed: Do NOT edit this file manually!"


# Generated at 2022-06-22 19:40:14.245459
# Unit test for function get_config_type
def test_get_config_type():
    # test ini file
    filename = tempfile.NamedTemporaryFile(mode='w', suffix='.ini', delete=False)
    filename.write('[defaults]\n')
    filename.close()
    assert get_config_type(filename.name) == 'ini'
    os.unlink(filename.name)

    # test yaml file
    filename = tempfile.NamedTemporaryFile(mode='w', suffix='.yml', delete=False)
    filename.write('---\n')
    filename.close()
    assert get_config_type(filename.name) == 'yaml'
    os.unlink(filename.name)

    # test no file type
    filename = tempfile.NamedTemporaryFile(mode='w', suffix='.foo', delete=False)

# Generated at 2022-06-22 19:40:24.733102
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    config = 'pipelining'
    cfile = None
    plugin_type = None
    plugin_name = None
    keys = None
    variables = None
    direct = {'pipelining': True}
    config_manager.get_config_value_and_origin(config, cfile, plugin_type, plugin_name, keys, variables, direct)
    c = C()
    c.a = 1
    c.b = 2
    assert c.a == 1
    assert c.b == 2
    c.add(1,2)
    assert c.c == 3

# Generated at 2022-06-22 19:40:27.654962
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    '''
    Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
    '''
    print('\nUnit test for method initialize_plugin_configuration_definitions of class ConfigManager')
    print('Unit test implemented but not yet run')

# Generated at 2022-06-22 19:40:38.928411
# Unit test for constructor of class Setting
def test_Setting():

    # constructor setting's class
    s = Setting("foo", "bar", "test", "string")
    if s.name != "foo":
        raise AssertionError("name error")
    if s.value != "bar":
        raise AssertionError("value error")
    if s.origin != "test":
        raise AssertionError("origin error")
    if s.type != "string":
        raise AssertionError("type error")

    # constructor setting's class with type
    s = Setting("foo", "bar", "test", "str")
    if s.name != "foo":
        raise AssertionError("name error")
    if s.value != "bar":
        raise AssertionError("value error")
    if s.origin != "test":
        raise AssertionError("origin error")