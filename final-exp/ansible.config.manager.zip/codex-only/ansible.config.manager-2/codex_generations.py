

# Generated at 2022-06-22 19:30:35.301650
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    current_dir_config = tempfile.NamedTemporaryFile()
    etc_config = tempfile.NamedTemporaryFile()
    home_dir_config = tempfile.NamedTemporaryFile()
    with open(home_dir_config.name, 'wb') as f:
        f.write(b"# this is a fake test file")
    temp_dir = tempfile.mkdtemp()
    temp_dir_config = os.path.join(urlparse(temp_dir).path, "ansible.cfg")

# Generated at 2022-06-22 19:30:47.565559
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    cmanager = ConfigManager()

    cmanager._base_defs['ANSIBLE_CONFIG'] = {'type': 'string', 'default': 'default_file', 'env': [{'name': 'ANSIBLE_CONFIG'}]}
    cmanager.data._settings['ANSIBLE_CONFIG'] = Setting('ANSIBLE_CONFIG', 'old_value', 'origin', 'string')

    # Test case 1: make sure setting the env var overrides config value
    with patch.dict(py3compat.environ, {'ANSIBLE_CONFIG': 'env_value'}):
        cmanager.update_config_data()
        assert cmanager.data._settings['ANSIBLE_CONFIG'].value == 'env_value', \
            "Expected env var to override config file setting!"

    # Test case 2: make sure config value overr

# Generated at 2022-06-22 19:30:51.902988
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    cMgr = ConfigManager()
    defs = cMgr.get_configuration_definitions()
    configfile = u'/home/wille/ansible/ansible/ansible.cfg'
    cMgr.update_config_data(defs, configfile=configfile)
    cMgr.DEFAULTS = cMgr.DEFAULTS.copy()

# Generated at 2022-06-22 19:31:03.733140
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    cm = ConfigManager()
    assert isinstance(cm, ConfigManager)
    assert cm.get_plugin_options(None, "default") == {}
    #assert cm.get_plugin_options("callback", "json") == {}
    #assert cm.get_plugin_options("callback", "log_plays") == {}
    assert cm.get_plugin_options("connection", "local") == {}
    assert cm.get_plugin_options("connection", "paramiko") == {}
    assert cm.get_plugin_options("connection", "smart") == {}
    assert cm.get_plugin_options("connection", "ssh") == {}
    #assert cm.get_plugin_options("lookup", "csvfile") == {}
    #assert cm.get_plugin_options("lookup", "file") == {}
    #assert cm.get_plugin_

# Generated at 2022-06-22 19:31:12.712089
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    warnings = set()

    # No ENV
    os.environ.pop("ANSIBLE_CONFIG", None)
    find_ini_config_file()

    # No ENV, nothing in cwd
    os.environ.pop("ANSIBLE_CONFIG", None)
    path = find_ini_config_file()
    assert path is None

    # ENV, nothing in cwd
    os.environ.pop("ANSIBLE_CONFIG", None)
    os.environ["ANSIBLE_CONFIG"] = "/foo/bar"

    # ENV, nothing in cwd
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:31:17.941226
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    cm = ConfigManager()
    # plg = config.get_config_value(config.Setting)
    cm.get_config_value('setting')
    # plg = pl.config.get_config_value(config.Setting)
    # config.get_config_value(config.Setting)


# Generated at 2022-06-22 19:31:23.796939
# Unit test for function get_config_type
def test_get_config_type():
    os.environ["ANSIBLE_CONFIG"] = 'ini'
    assert get_config_type('ini') == 'ini'
    os.environ["ANSIBLE_CONFIG"] = 'yaml'
    assert get_config_type('yaml') == 'yaml'


# FIXME: generic file type?

# Generated at 2022-06-22 19:31:30.769603
# Unit test for constructor of class Plugin
def test_Plugin():
    import sys
    from ansible.module_utils.six import PY3
    plugin = Plugin(sys.argv[1])
    assert plugin is not None
    assert plugin._plugin_name == sys.argv[1]
    assert plugin._aliases is not None
    assert plugin._aliases == {}
    if PY3:
        assert plugin._aliases == dict()
    assert plugin._version is not None
    assert plugin._version == "1"
    assert plugin._verbosity == 0


# Generated at 2022-06-22 19:31:36.124490
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('action_plugin', 'copy', {})
    assert cm.get_plugin_options('action_plugin', 'copy', direct={'foo': 'bar'}) == {'foo': 'bar'}

# Generated at 2022-06-22 19:31:46.698746
# Unit test for constructor of class Setting
def test_Setting():
    # legal constructors
    print("test empty constructor:")
    setting  = Setting()
    print("setting:", setting)

    # name missing
    print("test name missing:")
    try:
        setting  = Setting(None, 'value')
    except AnsibleOptionsError as e:
        print("Caught expected exception:", e)

    print("test value missing:")
    setting  = Setting('name', None)
    print("setting:", setting)

    print("test normal:")
    setting  = Setting('name', 'value')
    print("setting:", setting)

    # origin missing
    print("test origin missing:")
    setting  = Setting('name', 'value', None)
    print("setting:", setting)


# Generated at 2022-06-22 19:31:58.318637
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    # initialize
    config_mgr = ConfigManager()

    # test get_configuration_definitions()
    base_defs = config_mgr.get_configuration_definitions()
    assert len(base_defs) == len(INTERNAL_DEFS)
    assert set(base_defs.keys()) == set(INTERNAL_DEFS.keys())

    # test get_configuration_definitions() with invalid key
    with pytest.raises(AnsibleError):
        config_mgr.get_configuration_definitions(None, 'invalid')

    # test get_configuration_definitions() for base options
    base_defs = config_mgr.get_configuration_definitions(None, None)
    assert len(base_defs) == len(INTERNAL_DEFS)


# Generated at 2022-06-22 19:32:09.359479
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    # create an instance of the class
    config_manager = ConfigManager()
    # create mock objects with appropriate methods
    # create unittest.mock.Mock object
    mock_config = unittest.mock.Mock()
    mock_plugin_type = unittest.mock.Mock()
    mock_plugin_name = unittest.mock.Mock()
    mock_keys = unittest.mock.Mock()
    mock_variables = unittest.mock.Mock()
    mock_direct = unittest.mock.Mock()

    # set return values of mock methods
    # mock return value of mock_plugin_type
    mock_plugin_type.return_value = "network"
    # mock return value of mock_plugin_name
    mock_plugin_name.return_

# Generated at 2022-06-22 19:32:19.474265
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('~/hello') == os.path.expanduser('~/hello')
    assert resolve_path('~/hello', '/var') == os.path.expanduser('~/hello')
    assert resolve_path('/tmp', '/var') == '/tmp'
    assert resolve_path('/tmp', '/var/lib') == '/tmp'
    assert resolve_path('./test', '/var/lib') == '/var/lib/test'
    assert resolve_path('test', '/var/lib') == '/var/lib/test'
    assert resolve_path('test') == os.path.join(os.getcwd(), 'test')
    assert resolve_path('~/hello', '~/test') == os.path.expanduser('~/hello')

# Generated at 2022-06-22 19:32:28.808687
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('boolean', 'boolean') is True
    assert ensure_type('0', 'boolean') is False
    assert ensure_type('1', 'boolean') is True
    assert ensure_type('bool', 'boolean') is True
    assert ensure_type('yes', 'boolean') is True
    assert ensure_type('no', 'boolean') is False
    assert ensure_type('true', 'boolean') is True
    assert ensure_type('false', 'boolean') is False
    assert ensure_type('on', 'boolean') is True
    assert ensure_type('off', 'boolean') is False

    assert ensure_type('123', 'integer') == 123
    assert ensure_type('123.45', 'integer') == 123
    assert ensure_type('123.45', 'float') == 123.45


# Generated at 2022-06-22 19:32:34.680367
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():

    with pytest.raises(AttributeError):
        config = ConfigManager()

    config = ConfigManager(os.path.join(os.path.dirname(__file__), 'ansible.cfg'))
    definition = config.get_configuration_definitions(plugin_type='inventory', name='yaml')
    assert_equal(len(definition), 3)


# Generated at 2022-06-22 19:32:39.517733
# Unit test for constructor of class Setting
def test_Setting():
    setting_one = Setting('CONFIG_FILE', '/etc/ansible.cfg', '', 'string')
    try:
        setting_two = Setting('FOO', 'bar', '', 'string')
    except Exception:
        pass
    else:
        raise Exception('Failed to detect that FOO is not a valid config option')


# Generated at 2022-06-22 19:32:42.488234
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config_manager = ConfigManager()
    assert "vars_plugins" == config_manager.get_plugin_options(config_manager.PLUGIN_TYPE_VARS, "vars_plugins")


# Generated at 2022-06-22 19:32:53.635323
# Unit test for function resolve_path
def test_resolve_path():
    testpath = 'hello/world'
    assert resolve_path(testpath) == 'hello/world'
    testpath = '/hello/world'
    assert resolve_path(testpath) == '/hello/world'
    testpath = '/hello/{{CWD}}/world'
    assert resolve_path(testpath) == '/hello/%s/world' % os.getcwd()
    testpath = '/hello/{{CWD}}'
    assert resolve_path(testpath) == '/hello/%s' % os.getcwd()
    testpath = '{{CWD}}/world'
    assert resolve_path(testpath) == '%s/world' % os.getcwd()
    testpath = '{{CWD}}'
    assert resolve_path(testpath) == '%s' % os.getcwd()

# Generated at 2022-06-22 19:32:58.197494
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    ''' Unit test for function get_ini_config_value '''
    p = configparser.ConfigParser()
    p.add_section('defaults')
    p.set('defaults', 'foo', 'bar')
    assert get_ini_config_value(p, {'key': 'foo'}) == 'bar'



# Generated at 2022-06-22 19:33:04.629637
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    args = dict(
        config = None,
        plugin_type = None,
        plugin_name = None,
        cfile = None,
        keys = None,
        variables = None,
        direct = None
    )
    config = ConfigManager()
    assert config.get_config_value(**args) is None

# Generated at 2022-06-22 19:33:15.650105
# Unit test for function get_ini_config_value

# Generated at 2022-06-22 19:33:16.813107
# Unit test for constructor of class Plugin
def test_Plugin():
    p = Plugin()
    assert isinstance(p, Plugin)

# Generated at 2022-06-22 19:33:24.575837
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    """ test get_ini_config_value """
    test_ini = """
[defaults]
foo=1
[other]
"bar"],=2
"""
    p = configparser.ConfigParser()
    p.readfp(io.BytesIO(to_bytes(test_ini)))
    assert get_ini_config_value(p, {'key': 'foo'}) == '1'
    assert get_ini_config_value(p, {'section': 'other', 'key': '"bar"]'}) == '2'



# Generated at 2022-06-22 19:33:36.190992
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    c = ConfigManager()
    assert c.get_plugin_options('connection', 'local') == {'cp_remote_tmp': "/home/user/.ansible/tmp", 'cp_local_tmp': "/home/user/.ansible/tmp", 'executable': '/bin/sh', '_extras': [], '_raw_params': '', '_original_basename': 'runner', '_load_name': 'runner', '_usage': '', '_term': None, 'cp_min_free_space': 1024, 'cp_remote_src': None, 'cp_container_dir': '~/.ansible/tmp'}

# Generated at 2022-06-22 19:33:41.066778
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    """Unit test for method initialize_plugin_configuration_definitions of class ConfigManager."""
    test_config_manager = ConfigManager()
    test_plugin_type = 'test_plugin_type'
    test_plugin_name = 'test_plugin_name'
    test_configuration_definition = {'test_config' : {'default' : 'test_default', 
                                                     'type' : 'string',
                                                     'env' : [{'name' : 'TEST_CONFIG'}]}}
    test_config_manager.initialize_plugin_configuration_definitions(test_plugin_type, test_plugin_name, test_configuration_definition)

# Generated at 2022-06-22 19:33:43.457027
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    cm = ConfigManager()
    cm.update_config_data(defs=cm.get_configuration_definitions())

# Generated at 2022-06-22 19:33:45.410912
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()
    config.parse()
    config.finalize()
    plugin_type = "bin"
    name = "test"
    ignore_private = False

    ret = config.get_configuration_definitions(plugin_type, name, ignore_private)

# Generated at 2022-06-22 19:33:52.331884
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Single file
    def assert_ini_config_file(expected, env=None, cwd=None, home=None, system=None):
        # Where the defaults are
        dirdef = '/etc/ansible'
        filedef = 'ansible.cfg'
        defdir = os.path.join(dirdef, filedef)
        # Where we're going to make dummy files
        cwddir = tempfile.mkdtemp()
        homedir = tempfile.mkdtemp()
        # Files to create
        files = []
        for filename in [cwd, home, system]:
            if filename is not None:
                if not os.path.isabs(filename):
                    filename = os.path.join(cwddir, filename)
                files.append(filename)
        # Make the files

# Generated at 2022-06-22 19:34:03.715095
# Unit test for method get_config_value_and_origin of class ConfigManager

# Generated at 2022-06-22 19:34:16.596829
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    Unit test to check each possible way to set config value and origin
    '''

    # create test cases

# Generated at 2022-06-22 19:34:28.021697
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    from ansible.config.data import Setting

    # Test with a constant in the environment
    env_constant = 'ANSIBLE_CONSTANT_FOR_TEST_ENV'
    env_value = u'constant_from_env_for_test'
    os.putenv(env_constant, env_value)
    cfg = ConfigManager(defs=dict(ANSIBLE_CONSTANT_FOR_TEST_ENV=dict(env=dict(name=env_constant))), args=[])
    assert cfg.data.ANSIBLE_CONSTANT_FOR_TEST_ENV == env_value
    assert cfg.data._settings[Setting('ANSIBLE_CONSTANT_FOR_TEST_ENV', env_value, None, 'string')]

    # Test with a constant in the config file
   

# Generated at 2022-06-22 19:34:34.357046
# Unit test for function resolve_path
def test_resolve_path():
    '''
        Test resolve_path path function
    '''
    assert resolve_path('/tmp') == '/tmp'
    assert resolve_path('/tmp', basedir='/etc') == '/tmp'
    assert resolve_path('./tmp', basedir='/etc') == '/etc/tmp'
    assert resolve_path('{{CWD}}/tmp', basedir='/etc') == os.getcwd() + '/tmp'



# Generated at 2022-06-22 19:34:45.465152
# Unit test for function resolve_path
def test_resolve_path():
    from ansible.utils import module_docs
    from ansible.utils.display import Display
    display = Display()
    module_docs.prepare(None, display)
    os.chdir('/tmp')
    test = {}
    test['vartmp'] = tempfile.mkdtemp()
    test['varcwd'] = os.getcwd()
    test['varenv'] = os.path.expandvars('$PATH')
    test['varhomedir'] = os.path.expanduser('~')
    test['user'] = os.getenv('USER')
    for t in ('vartmp', 'varcwd', 'varenv', 'varhomedir', 'user'):
        test[t+'_resolved'] = resolve_path('{{%s}}' % t)

# Generated at 2022-06-22 19:34:54.800742
# Unit test for function ensure_type
def test_ensure_type():
    '''
    Tests to ensure the function returns the proper pythonic type based on the
    type provided to it.
    '''
    # string types should just be returned
    # boolean
    assert ensure_type('true', 'boolean') is True
    assert ensure_type('False', 'bool') is False
    # integer
    assert ensure_type('1', 'integer') == 1
    assert ensure_type('-1', 'int') == -1
    # float
    assert ensure_type('0.1', 'float') == 0.1
    # list
    assert ensure_type('a,b,c', 'list') == ['a', 'b', 'c']
    assert ensure_type(['a', 'b', 'c'], 'list') == ['a', 'b', 'c']
    # none

# Generated at 2022-06-22 19:35:03.306802
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    class AnsibleOptionsError(Exception):
        pass

    class AnsibleError(Exception):
        pass

    config = ConfigManager()

    # Begin unit test
    try:
        # FIXME: This function is not implemted yet.
        # value, origin = config.get_config_value_and_origin()
        pass
    except Exception as exception:
        # FIXME: This unit test is not implemted yet.
        cls = type(exception)
        assert cls is AnsibleOptionsError or cls is AnsibleError
        fail(exception)


# Generated at 2022-06-22 19:35:14.782345
# Unit test for function find_ini_config_file
def test_find_ini_config_file():

    # create a temp directory with world write permissions
    tmpdir = tempfile.mkdtemp()
    os.chmod(tmpdir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    # create a ansible.cfg file in the tmp directory
    warnings = set()
    cwd = os.getcwd()
    try:
        os.chdir(tmpdir)
        f = open("ansible.cfg", "w")
        f.write("[defaults]")
        f.close()
        config_paths = find_ini_config_file(warnings)
        assert config_paths is None
        print("Warning message received:")
        for warning in warnings:
            print(warning)

    finally:
        os.chdir(cwd)



# Generated at 2022-06-22 19:35:24.788662
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    c = ConfigManager()
    # Test 1: defs is dict
    local_defs = dict()
    try:
        c.update_config_data(defs=local_defs)
    except Exception as e:
        print("expected: No error")
        print("received: {}".format(e))
        return False
    # Test 2: defs is not dict
    local_defs = "this is not a dict"
    try:
        c.update_config_data(defs=local_defs)
    except Exception as e:
        print("expected: Invalid configuration definition type")
        print("received: {}".format(e))
        return False
    return True



# Generated at 2022-06-22 19:35:28.093887
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    cm = ConfigManager()
    assert type(cm) == ConfigManager, "Failed to create a ConfigManager object."
    assert hasattr(cm, '_config_file'), "Failed to create a ConfigManager object."


# Generated at 2022-06-22 19:35:37.795370
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:35:48.082526
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    conf1 = ConfigManager(configfile='ansible.cfg')

    # Testing the case with configfile extension
    assert (conf1.config_type == 'ini')

    conf2 = ConfigManager(configfile='ansible.yaml')
    assert (conf2.config_type == 'yaml')

    conf3 = ConfigManager(configfile='ansible.json')
    assert (conf3.config_type == 'json')

    # Testing the case with no matching extension
    conf4 = ConfigManager(configfile='ansible.yml')
    assert (conf4.config_type == 'yaml')


# Generated at 2022-06-22 19:36:00.519025
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Mock os.environ for use during tests
    mock_environ = {
        "ANSIBLE_CONFIG": "/path/to/ansible.cfg",
        "HOME": "/home/user",
    }
    org_environ = os.environ
    os.environ = mock_environ
    at_exit_list = []

    # We have to ensure that we clean up anything we've changed
    def exit_cleanup():
        os.environ = org_environ
        while at_exit_list:
            at_exit_list.pop()()
    atexit.register(exit_cleanup)

    # Don't use the actual ansible.cfg in use by the tests
    try:
        del os.environ["ANSIBLE_CONFIG"]
    except KeyError:
        pass

    # Mock os.get

# Generated at 2022-06-22 19:36:01.924277
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    configManager = ConfigManager()
    assert isinstance(configManager, ConfigManager)

# Generated at 2022-06-22 19:36:07.091814
# Unit test for function get_config_type
def test_get_config_type():
    ''' test for function get_config_type '''

    pfile = 'test/support/test-foo.yml'
    ftype = get_config_type(pfile)
    assert ftype == 'yaml'

    pfile = 'test/support/test-foo.cfg'
    ftype = get_config_type(pfile)
    assert ftype == 'ini'



# Generated at 2022-06-22 19:36:08.200499
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    assert 0

# Generated at 2022-06-22 19:36:09.558889
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    cm = ConfigManager()
    # ...


# Generated at 2022-06-22 19:36:11.535313
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    configmanager = ConfigManager()
    assert configmanager is not None


# Generated at 2022-06-22 19:36:24.112085
# Unit test for constructor of class Plugin
def test_Plugin():
    from ansible.parsing.plugin_docs import get_docstring

    source = """
    foo:
        description: hello
        type: list
        default: [1, 2, 3]
    """
    plugin = Plugin('bar', get_docstring(source))

    assert plugin.name == 'bar'
    assert plugin.description is None
    assert plugin.short_description is None
    assert plugin.notes == []
    assert not plugin.hidden
    assert plugin.has_multiple_files

    assert len(plugin.attributes) == 4
    plugin.get_attribute('description')

    assert plugin.get_attribute('description').value == 'hello'
    assert plugin.get_attribute('description').skip == False

    assert plugin.get_attribute('type').value == 'list'

# Generated at 2022-06-22 19:36:29.327888
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
  configm = ConfigManager()
  defs = {'test': {'default': 'foo', 'type': 'string'}}
  configm.initialize_plugin_configuration_definitions(plugin_type='test', name='test', defs=defs)
  assert configm._plugins['test']['test'] == {'test': {'default': 'foo', 'type': 'string'}}


# Generated at 2022-06-22 19:36:30.536761
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    assert False # How to test this?



# Generated at 2022-06-22 19:36:32.155981
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin()
    assert plugin


# Generated at 2022-06-22 19:36:44.128287
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    test_data = {
          'FOO': {
              'default': 'FOO',
              'type': 'string'
           },
          'BAR': {
              'default': 'BAR',
              'type': 'string'
           }
        }
    constants = PluginDataLoader.load_constants(test_data)

    cm = ConfigManager('', test_data, constants=constants)
    cm.update_config_data({'BAZ': {'default': 'BAZ', 'type': 'string'}})
    assert cm.get_config_value('BAR') == 'BAR'
    assert cm.get_config_value('BAZ') == 'BAZ'
    assert cm.data.get(Setting('FOO')).value == 'FOO'
# need to import here so we can get at the module

# Generated at 2022-06-22 19:36:49.618926
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    from ansible.errors import AnsibleError
    from ansible.utils.plugin_docs import get_docstring

    m = ConfigManager()

    # Test exception cases
    try:
        m.get_plugin_options('test', None)
    except AnsibleError:
        pass
    else:
        fail('No exception raised when None is passed in')

    try:
        m.get_plugin_options('test', {})
    except AnsibleError:
        pass
    else:
        fail('No exception raised when {} is passed in')

    # Test all the types of plugins

# Generated at 2022-06-22 19:36:58.520541
# Unit test for function ensure_type
def test_ensure_type():
    # test int
    value = '1'
    output = ensure_type(value, 'integer')
    assert type(output) is int

    # test float
    value = '1.5'
    output = ensure_type(value, 'float')
    assert type(output) is float

    # test path
    value = '~/test'
    output = ensure_type(value, 'path')
    assert output == os.path.expanduser(value)

    # test pathspec
    value = '~/test:/tmp:/usr/bin'
    output = ensure_type(value, 'pathspec')
    assert output == [os.path.expanduser('~/test'), '/tmp', '/usr/bin']

    # test pathlist
    value = '~/test,/tmp,/usr/bin'

# Generated at 2022-06-22 19:37:00.518006
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    # FIXME: implementation test
    # FIXME: docstring test
    pass



# Generated at 2022-06-22 19:37:02.479263
# Unit test for constructor of class Plugin
def test_Plugin():

    p = Plugin()
    assert p is not None
    assert isinstance(p, Plugin)


# Generated at 2022-06-22 19:37:08.168846
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    import mock

    plugin_type = 'type1'
    name = 'name1'
    defs = {'def1':'v1', 'def2':'v2'}
    _config_manager = ConfigManager()
    _config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert _config_manager._plugins[plugin_type][name] == defs


# Generated at 2022-06-22 19:37:19.747288
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    '''
    False positive:
        /home/user/cfg
    False negative:
        /home/user/cfg/
    '''
    orig_env = os.environ.get("ANSIBLE_CONFIG", None)
    orig_cwd = os.getcwd()
    orig_home = os.environ.get("HOME", None)

    if orig_env is not None:
        del os.environ["ANSIBLE_CONFIG"]
    if orig_home is not None:
        del os.environ["HOME"]

    # False positive
    expected = "/home/user/cfg"
    os.environ["ANSIBLE_CONFIG"] = expected
    path = find_ini_config_file()
    assert path == expected

    # False positive
    expected = "/home/user/cfg"
    os.ch

# Generated at 2022-06-22 19:37:33.565398
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    def _create_temp_file(parent_dir, filename, content):
        open(_create_temp_filename(parent_dir, filename), "w").write(content)

    def _create_temp_filename(parent_dir, filename):
        return os.path.join(parent_dir, filename)

    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    # We use a function accessible from both modules and classes
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:37:41.672221
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_manager = ConfigManager(['/etc/ansible/ansible.cfg', os.path.expanduser('~/.ansible.cfg')])
    config_manager.DEFAULT_CONFIG = '/etc/ansible/ansible.cfg'
    config_manager.CONFIG_FILE = None
    config_manager.CLIARGS = None
    config_manager.SECTIONS = None
    config_manager.config = None
    config_manager.parsers = None
    config_manager.parser = None
    config_manager.defs = dict()

    config_manager.update_config_data()


# Generated at 2022-06-22 19:37:53.098713
# Unit test for method get_plugin_vars of class ConfigManager

# Generated at 2022-06-22 19:38:01.197835
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config = ConfigManager(parser='ini')
    config.initialize_plugin_configuration_definitions('strategy', 'linear', {'forks': {'default': 5, 'choices': [1,2,3,4,5,6,7,8,9,10], 'type': 'int'}})
    config._parse_config_file('/dev/null')
    config.update_config_data()

    assert config.data._settings['forks'].value == 5
    assert config.data._settings['forks'].value_type == 'int'
    # with pytest.raises(Exception) as excinfo:
    #     config.data.get_setting('forks')
    # assert 'Invalid setting forks' in str(excinfo.value)


# Generated at 2022-06-22 19:38:09.512158
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # class ConfigManager definition
    def __init__(self, config_file=C.CONFIG_FILE):
        pass

import mock


    # Initialize a mock object for class ConfigManager

# Generated at 2022-06-22 19:38:22.377947
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
	from ansible.config.manager import ConfigManager

# Generated at 2022-06-22 19:38:33.790719
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    bdefs = {
        'foo': {'default': 'banana'},
        'bar': {}
    }
    cm = ConfigManager(cfile='foo', config_defs=bdefs)

    assert 'bar' not in cm.get_configuration_definitions(), 'Empty config not defined'
    assert 'foo' in cm.get_configuration_definitions(), 'Config defined'
    assert cm.get_config_value('foo') == 'banana', 'Config defined'
    assert not cm.get_configuration_definitions('bar'), 'Config not defined'
    assert cm.get_config_value('bar') is None, 'Config not defined'
    assert cm.get_config_value('baz') is None, 'Config not defined'


# Generated at 2022-06-22 19:38:38.590378
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    # Setup
    args = dict()
    config_manager = ConfigManager(args)

    # Test
    # AssertionError: 'rsync' is not in list
    assert config_manager.get_plugin_options('strategy', 'rsync') == dict()



# Generated at 2022-06-22 19:38:39.898519
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    assert True

# Generated at 2022-06-22 19:38:48.576211
# Unit test for method get_plugin_options of class ConfigManager

# Generated at 2022-06-22 19:38:53.624205
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    defs = {'a': {'vars': [{'name': 'b'}]}, 'c': {}}

    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('ansible.plugins.test', 'test', defs)

    assert config.get_plugin_vars('test', 'test') == ['b']


# Generated at 2022-06-22 19:38:57.951038
# Unit test for constructor of class Plugin
def test_Plugin():
    ''' test base class Plugin '''
    plugin = Plugin(None)
    assert plugin is not None

# pylint: disable=unused-argument

# Generated at 2022-06-22 19:39:06.319869
# Unit test for function ensure_type

# Generated at 2022-06-22 19:39:11.861319
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    input_args = ['config=foo', '--config=bar']
    config_manager = ConfigManager(args=input_args, env_vars=None)
    config_manager.get_config_value_and_origin('config')
    assert config_manager.get_config_value('config') == 'foo'

if __name__ == '__main__':
    test_ConfigManager_get_config_value_and_origin()

# Generated at 2022-06-22 19:39:17.359586
# Unit test for function get_config_type
def test_get_config_type():
    # No file type specified
    assert get_config_type(None) is None
    # Test with .ini file
    assert get_config_type('test.ini') == 'ini'
    # Test with .cfg file
    assert get_config_type('test.cfg') == 'ini'
    # Test with .yaml file
    assert get_config_type('test.yaml') == 'yaml'
    # Test with .yml file
    assert get_config_type('test.yml') == 'yaml'
    # Test with unsupported file type
    try:
        get_config_type('test.txt')
    except AnsibleOptionsError:
        pass
    else:
        raise AssertionError('Unsupported config file extension did not raise AnsibleOptionsError')



# Generated at 2022-06-22 19:39:27.653043
# Unit test for constructor of class Setting
def test_Setting():
    # Check if constant name is properly formatted
    try:
        Setting('ANSIBLE', '~/.ansible.cfg', None, 'string')
    except:
        print('FAILED: Constants name is not correctly formatted')
        return False
    # Check if the value is of correct type
    try:
        Setting('ANSIBLE_CONFIG', '~/.ansible.cfg', None, 'boolean')
    except:
        print('FAILED: Constants type is not one of the allowed types')
        return False
    # Check if constants value is of correct type
    try:
        Setting('ANSIBLE_CONFIG', 1, None, 'string')
    except:
        print('FAILED: Constants value is not of correct type')
        return False
    print('SUCCESS: Setting constructor is working as expected')
    return True

# Generated at 2022-06-22 19:39:34.020835
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('.') == os.getcwd()
    assert resolve_path('{{CWD}}') == os.getcwd()
    assert resolve_path('./test') == os.path.join(os.getcwd(), 'test')
    assert resolve_path('tmp') == '/tmp'
    assert resolve_path('test', basedir='/') == '/test'



# Generated at 2022-06-22 19:39:45.828053
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    ''' make sure we can find config files in a variety of conditions '''

    # backup the environment
    orig_env = os.environ.copy()

    # set up a function to restore the environment
    # todo: this could probably be cleaned up as we move to using context managers more perpahs
    def restore_env():
        for var in orig_env:
            os.environ[var] = orig_env[var]
        for var in ['ANSIBLE_CONFIG', 'ANSIBLE_CONFIG_SET', 'ANSIBLE_CONFIG_UNSET']:
            if var in os.environ:
                del os.environ[var]

    # make sure restoring works
    restore_env()

    # make sure the sentinel value is not a valid path before we start

# Generated at 2022-06-22 19:39:58.213754
# Unit test for method get_config_value_and_origin of class ConfigManager

# Generated at 2022-06-22 19:40:07.524282
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    cm = ConfigManager()

    # test with only name
    assert(cm.get_configuration_definition('DEFAULT_HOST_LIST'))

    # test with wrong plugin type
    assert(cm.get_configuration_definition('DEFAULT_HOST_LIST', plugin_type='foo') is None)

    # test with wrong plugin name
    assert(cm.get_configuration_definition('HOST_KEY_CHECKING', plugin_type='ssh', plugin_name='foo') is None)

    # test with right plugin name and type
    assert(cm.get_configuration_definition('HOST_KEY_CHECKING', plugin_type='ssh', plugin_name='ssh'))

    # test with wrong name
    assert(cm.get_configuration_definition('foo', plugin_type='ssh', plugin_name='ssh') is None)


# Generated at 2022-06-22 19:40:19.441350
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(3.0, 'float') == 3.0
    assert ensure_type(3, 'int') == 3
    assert ensure_type('3', 'int') == 3
    assert ensure_type(['a', 'b', 'c'], 'list') == ['a', 'b', 'c']
    assert ensure_type('a,b,c', 'list') == ['a', 'b', 'c']
    assert ensure_type(None, 'list') is None
    assert ensure_type(None, 'none') is None
    assert ensure_type('VARNAME', 'path') == resolve_path('VARNAME')
    assert ensure_type('VARNAME', 'pathlist') == resolve_path('VARNAME').split(os.pathsep)

# Generated at 2022-06-22 19:40:20.595279
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    import doctest
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()
    doctest.testmod(config_manager)

# Generated at 2022-06-22 19:40:24.604761
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    func = getattr(config, 'get_configuration_definition')
    assert func


# Generated at 2022-06-22 19:40:28.792932
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('{{CWD}}/test') == '{{CWD}}/test'
    assert resolve_path('/test') == '/test'
    assert resolve_path('{{CWD}}') == os.getcwd()
    assert resolve_path('{{CWD}}/test') == '{{CWD}}/test'
    assert resolve_path('/test/file', basedir='/test') == '/test/file'

