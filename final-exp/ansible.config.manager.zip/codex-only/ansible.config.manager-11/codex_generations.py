

# Generated at 2022-06-22 19:30:35.057657
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.SafeConfigParser()
    p.readfp(io.StringIO('[defaults]\nfoo=bar\n'))
    assert get_ini_config_value(p, {'section': 'defaults', 'key': 'foo'}) == 'bar'
    assert get_ini_config_value(p, {'section': 'defaults', 'key': 'bar'}) is None
    assert get_ini_config_value(p, {'key': 'foo'}) == 'bar'
    assert get_ini_config_value(p, {'key': 'bar'}) is None
    try:
        get_ini_config_value(p, {})
        assert False, 'Should have raised an error'
    except AnsibleOptionsError:
        pass



# Generated at 2022-06-22 19:30:39.308489
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.add_section('a')
    p.set('a', 'key', 'value')
    assert get_ini_config_value(p, {'section':'a', 'key':'key'}) == 'value'


# FIXME: can move to module_utils for use for yaml plugins also?

# Generated at 2022-06-22 19:30:49.862597
# Unit test for function ensure_type
def test_ensure_type():
    # test_string
    assert ensure_type("string", "string") == "string"
    assert ensure_type("string", "str") == "string"
    assert ensure_type("string", "string", origin="some") == "string"
    assert ensure_type("string", "bool") == "string"
    assert ensure_type("string", "boolean") == "string"

    # test_bool
    assert ensure_type("false", "string") == "false"
    assert ensure_type("true", "string") == "true"
    assert ensure_type("False", "string") == "False"
    assert ensure_type("True", "string") == "True"
    assert ensure_type("False", "bool") == False
    assert ensure_type("True", "bool") == True

# Generated at 2022-06-22 19:30:59.675415
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager

# Generated at 2022-06-22 19:31:10.526257
# Unit test for constructor of class Setting
def test_Setting():
    # test for constructor with all valid inputs
    s = Setting("foo","bar","baz","quux")
    # test whether the attributes were assigned correctly
    assert s.name == "foo"
    assert s.value == "bar"
    assert s.origin == "baz"
    assert s.type == "quux"

    # test for constructor with invalid data type
    try:
        s = Setting("foo","bar","baz","quux",42)
    except Exception as e:
        assert 'Invalid data type' in str(e)

    # test for constructor with invalid value
    try:
        s = Setting("foo","bar","baz","quux",value="quux")
    except Exception as e:
        assert 'Invalid value' in str(e)


# Generated at 2022-06-22 19:31:16.596974
# Unit test for constructor of class Plugin
def test_Plugin():
    ''' Plugin class constructor tests '''

    plugin = Plugin()

    assert not plugin.policies

    fake = dict(
        name = 'fake',
        doc = 'a fake plugin',
        init = None,
        config_plugin = True,
        run = None,
        default_options = dict(),
    )

    plugin = Plugin(fake)

    assert plugin.name == 'fake'
    assert plugin.doc == 'a fake plugin'
    assert not plugin.policies



# Generated at 2022-06-22 19:31:23.235610
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager()
    assert isinstance(config, ConfigManager)
    assert isinstance(config.data, Settings)
    assert isinstance(config._parsers, dict)
    assert isinstance(config._base_defs, dict)
    assert config._load_order == []
    assert config.ERRORS == []
    assert config.DEPRECATED == []

# Generated at 2022-06-22 19:31:27.961960
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_mgr = ConfigManager(None)
    plugin_type = None
    name = None
    ignore_private = False
    # actual test
    config_mgr.get_configuration_definitions(plugin_type, name, ignore_private)

# Generated at 2022-06-22 19:31:34.533433
# Unit test for function resolve_path
def test_resolve_path():
    cwd = os.getcwd()
    assert cwd == resolve_path('{{CWD}}')
    tilde = os.path.expanduser('~')
    assert tilde == resolve_path('~')
    testdir = os.path.join(cwd, 'testdir')
    assert testdir == resolve_path('./testdir')
    assert testdir == resolve_path('testdir')
    assert testdir == resolve_path('./testdir')
    assert testdir == resolve_path('././testdir/.././testdir')
    assert testdir == resolve_path('{{CWD}}/testdir')



# Generated at 2022-06-22 19:31:40.813197
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    configfile = 'test/ansible_get_config_value.ini'
    cm = ConfigManager()
    cm.parse(defs=copy.copy(INTERNAL_DEFS), configfile=configfile)
    value = cm.get_config_value('DEFAULT_DEBUG')
    assert value == False

    cm.parse(defs=copy.copy(INTERNAL_DEFS), configfile=configfile)
    value = cm.get_config_value('DEFAULT_DEBUG')
    assert value == False

    cm.parse(defs=copy.copy(INTERNAL_DEFS), configfile=configfile)
    value = cm.get_config_value('DEFAULT_DEBUG')
    assert value == False

# Generated at 2022-06-22 19:31:49.928963
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():

    # Create a mock config object
    config_obj = AnsibleConfig()

    # try calling get_config_value() with valid params
    value, origin = config_obj.get_config_value_and_origin('vault_password_file', configfile='/home/ansible/ansible.cfg')
    assert value == '/etc/ansible/vault_pass.txt'
    assert origin == '/home/ansible/ansible.cfg'

    value, origin = config_obj.get_config_value_and_origin('pipelining', configfile='/home/ansible/ansible.cfg')
    assert value == True
    assert origin == '/home/ansible/ansible.cfg'


# Generated at 2022-06-22 19:31:54.415535
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.read('my.ini')
    assert get_ini_config_value(p, {'key': 'a'}) == 'b'
    assert get_ini_config_value(p, {'section': 'section1', 'key': 'c'}) == 'd'
    assert get_ini_config_value(p, {'section': 'section2', 'key': 'f'}) == 'g'


# FIXME: can move to module_utils for use for yaml plugins also?

# Generated at 2022-06-22 19:32:00.725735
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    defs = configmanager.get_configuration_definitions()
    assert len(defs) > 0

    defs = configmanager.get_configuration_definitions('connection')
    assert len(defs) > 0

    defs = configmanager.get_configuration_definitions('connection', 'local')
    assert len(defs) > 0
# Test method get_configuration_definition of class ConfigManager


# Generated at 2022-06-22 19:32:08.603869
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    '''
    Unit test for method get_plugin_vars of class ConfigManager
    '''
    # Create a ConfigManager object
    config_manager = ConfigManager()
    try:
        ret = config_manager.get_plugin_vars("foo", "bar")
    except Exception as err:
        ret = err
    assert ret == 'plugin_type=foo, plugin_name=bar was not found in configuration definitions'

    # Create a ConfigManager object
    config_manager = ConfigManager()
    try:
        config_manager.initialize_plugin_configuration_definitions("foo", "bar", {'baz': {'vars': None}, 'foo': {'vars': None}})
    except Exception as err:
        ret = err

# Generated at 2022-06-22 19:32:12.374088
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager()
    assert (config_manager.get_configuration_definition('CONFIG_FILE', '', '') is None)



# Generated at 2022-06-22 19:32:16.898963
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # set up
    config = ConfigManager()

    # test
    assert config.get_configuration_definition('action_plugins') == {
'default': '<ANSIBLE_LIBRARY_PATH>/action_plugins',
'type': 'pathlist',
'description': 'The list of directories Ansible will search for action plugins'}


# Generated at 2022-06-22 19:32:27.444538
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config_manager = ConfigManager(os.path.join(os.path.dirname(__file__), 'config_mean.yml'))

    assert config_manager.get_configuration_definition('a', 'type_c', 'name_c') == {'required': True}

    # Invalid plugin type raise exception
    with pytest.raises(AnsibleError):
        config_manager.get_configuration_definition('a', 'invalid_type', 'name_c')

    # Invalid plugin name raise exception
    with pytest.raises(AnsibleError):
        config_manager.get_configuration_definition('a', 'type_c', 'invalid_name')


# Generated at 2022-06-22 19:32:38.469985
# Unit test for function get_config_type
def test_get_config_type():

    # Test: file with ini extension, extension in upper case
    cfile = None
    ftype = get_config_type(cfile)
    assert ftype == None

    # Test: file with ini extension
    cfile = "/tmp/test.ini"
    ftype = get_config_type(cfile)
    assert ftype == 'ini'

    # Test: file with cfg extension, extension in upper case
    cfile = "/tmp/test.cfg"
    ftype = get_config_type(cfile)
    assert ftype == 'ini'

    # Test: file with yaml extension, extension in upper case
    cfile = "/tmp/test.yaml"
    ftype = get_config_type(cfile)
    assert ftype == 'yaml'

    # Test: file with yml extension,

# Generated at 2022-06-22 19:32:40.424340
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.SafeConfigParser()
    p.read('test/units/utils/default.cfg')
    entry = {'section': 'defaults', 'key': 'inventory'}
    assert get_ini_config_value(p, entry) == '~/ansible_hosts'


# FIXME: can move to module_utils for use for ini plugins also?

# Generated at 2022-06-22 19:32:46.959357
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config_manager = ConfigManager()
    plugin_type = '0'
    name = '0'
    keys = '0'
    variables = '0'
    direct = '0'
    r = config_manager.get_plugin_options(plugin_type, name, keys, variables, direct)
    assert_equals(r, {})


# Generated at 2022-06-22 19:32:52.459071
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():


    # test_config_manager is an instance of class ConfigManager
    config_manager = ConfigManager()
    assert config_manager 

    # get_configuration_definition(self, name, plugin_type=None, plugin_name=None)
    result = config_manager.get_configuration_definition(AUTH_HASH_SALT)
    assert result


# Generated at 2022-06-22 19:33:04.471754
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager()

    # Test
    #    _parsers
    #    _config_files
    #    _config_file
    assert(isinstance(config._parsers, dict))
    assert(len(config._parsers) == 0)
    assert(config._config_file is not None)
    assert(isinstance(config._config_files, list))
    assert(len(config._config_files) == 2)

    # Test
    #    _base_defs
    #    _plugins
    #    DEPRECATED
    #    WARNINGS
    assert(isinstance(config._base_defs, dict))
    assert(len(config._base_defs) != 0)
    assert(isinstance(config._plugins, dict))
    assert(len(config._plugins) == 0)


# Generated at 2022-06-22 19:33:13.681214
# Unit test for function get_config_type
def test_get_config_type():
    # Testing file object
    file_obj = open('/tmp/foo.yaml', 'w')
    file_obj.write('''
---
plugin_type:become
plugin:become
setting:become_method
key:local_become
value:foo
''')
    file_obj.close()
    file_obj = open('/tmp/foo.yaml', 'r')
    ftype = get_config_type(file_obj)
    assert ftype == 'yaml'
    os.remove('/tmp/foo.yaml')

# FIXME: see if this can live in utils/path

# Generated at 2022-06-22 19:33:25.462649
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    import mock

    c = ConfigManager()


# Generated at 2022-06-22 19:33:28.716171
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    # set up test
    configmanager = ConfigManager()

    assert configmanager == configmanager
    assert configmanager != 1


# Generated at 2022-06-22 19:33:35.061653
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin_type = 'shell'
    name = 'sh'
    plugin_obj = Plugin(plugin_type, name)
    assert plugin_obj.plugin_type == plugin_type
    assert plugin_obj.name == name
    assert plugin_obj._command == ''
    assert plugin_obj.disabled is False
    assert plugin_obj._timeout == 10
    assert plugin_obj._env == {}
    assert plugin_obj._args == ''


# Generated at 2022-06-22 19:33:41.260588
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    manager = ConfigManager()
    manager.data.update_setting(Setting('CONFIG_FILE', '_config_file', '', 'string'))
    
    expected = True
    actual = manager.get_config_value('display_skipped_hosts')
    
    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)

# Generated at 2022-06-22 19:33:43.655624
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config_manager = AnsibleConfig()
    plugin_type = 'Test type'
    name = 'Test name'
    keys = 'Test keys'
    variables = 'Test variables'
    direct = 'Test direct'
    result = config_manager.get_plugin_options(plugin_type, name, keys, variables, direct)
    assert isinstance(result, dict)

# Generated at 2022-06-22 19:33:50.995585
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    c = ConfigManager()
    c.initialize_plugin_configuration_definitions(
        plugin_type='module',
        name='setup',
        defs={
            'gather_timeout': {
                'default': 10,
                'ini': [{'section': 'setup', 'key': 'gather_timeout', 'name': 'gather_timeout'}],
                'env': [{'name': 'ANSIBLE_GATHER_TIMEOUT'}],
                'type': 'integer'
            },
            'filter': {
                'ini': [{'section': 'setup', 'key': 'filter', 'name': 'filter'}],
                'env': [{'name': 'ANSIBLE_GATHER_FILTER'}],
                'type': 'string'
            }
        }
    )

    # gather_

# Generated at 2022-06-22 19:34:03.028740
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    # Load the test data
    ini_data = {}
    with open('../../test/unit/plugins/loader/ini_config_data.yaml', 'r') as stream:
        ini_data = yaml_load(stream.read())

    # Run the unit tests
    assert get_ini_config_value(None, {'section': 'test', 'key': 'bad_key'}) is None

    p = configparser.ConfigParser(allow_no_value=True)
    p.optionxform = str
    p.read_dict(ini_data)
    for entry in ini_data:
        entry_value = ini_data[entry]
        assert get_ini_config_value(p, {'section': 'test', 'key': entry}) == entry_value

# FIXME: can move to module

# Generated at 2022-06-22 19:34:14.869927
# Unit test for constructor of class Plugin
def test_Plugin():
    """Test Plugin constructor."""
    from ansible.plugins import get_all_plugin_loaders

    path = os.path.join(os.path.dirname(__file__), 'find_plugins_data')

    # get all loaders
    loaders = get_all_plugin_loaders(path)
    # the Plugin constructor needs a valide loader
    loader = loaders[0]
    # get a valid plugin (in this case a connection)
    plugin = loader.get('connection', 'local')
    # assert the plugin_obj is an instance of plugin
    assert isinstance(plugin, Plugin)
    # assert that there is a valid path
    assert isinstance(plugin.path, string_types)
    # assert that we have a valid name
    assert isinstance(plugin.name, string_types)
    # assert that there is

# Generated at 2022-06-22 19:34:16.487199
# Unit test for constructor of class Plugin
def test_Plugin():

    p = Plugin()
    assert p is not None


# Generated at 2022-06-22 19:34:25.039141
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    ''' test_ConfigManager_get_configuration_definitions the 'get_configuration_definitions' method of the 'ConfigManager' class '''

    # define test values
    config = 'config'
    plugin_type = 'plugin_type'
    name = 'name'

    # create instance of class
    config_manager = ConfigManager()

    # execute method and test results
    result = config_manager.get_configuration_definitions(config, plugin_type, name)
    assert isinstance(result, dict)

# Generated at 2022-06-22 19:34:30.559984
# Unit test for constructor of class Setting
def test_Setting():
    result = Setting('FOO', 'bar', 'cli: --foo=bar', 'string')
    assert result.name == 'FOO'
    assert result.value == 'bar'
    assert result.origin == 'cli: --foo=bar'
    assert result.type == 'string'

    result = Setting('FOO', 'bar') # Uses defaults for optional arguments
    assert result.name == 'FOO'
    assert result.value == 'bar'
    assert result.origin == None
    assert result.type == 'str'

    assert repr(result) == "Setting(FOO): 'bar'"


# Generated at 2022-06-22 19:34:38.975561
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    ''' test find_ini_config_file '''

    from ansible.utils import context_objects as co

    # FIXME: this is a hack to force the config_file to not be loaded
    # as it can't be done in test/support/__init__.py as it has already
    # been loaded by the time this module is imported.
    def _fake(self):
        return None
    co.GlobalCLI._config_file = property(_fake)

    # no config file set
    path = find_ini_config_file()
    assert path is None

    with tempfile.NamedTemporaryFile() as tmp:
        os.environ['ANSIBLE_CONFIG'] = tmp.name
        path = find_ini_config_file()
        assert path == tmp.name

    # FIXME: we should probably just not set

# Generated at 2022-06-22 19:34:47.300340
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    defs = dict(
        new_plugin_option=dict(required=True, default='default', choices=['default', 'other'])
    )

    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('test_type', 'test_name', defs)
    assert config_manager._plugins.get('test_type', {}).get('test_name') == defs



# Generated at 2022-06-22 19:34:58.541845
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    # instance of class ConfigManager
    config_manager = ConfigManager()

    # mock plugin_type argument
    plugin_type = "action"

    # mock name argument
    name = "test"

    # mock defs argument
    defs = {
        "name": {
            "type": "str",
            "default": "default"
        }
    }

    # call the tested method
    config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)

    # determine if the config_manager.plugins is correctly updated
    expected = {
        plugin_type: {
            name: defs
        }
    }
    assert config_manager.plugins == expected


# Generated at 2022-06-22 19:35:03.385541
# Unit test for constructor of class Plugin
def test_Plugin():
    plugin = Plugin()
    assert plugin.is_task == False
    assert plugin.is_playbook == False
    assert plugin.is_inventory == False
    assert plugin.is_vars == False
    assert plugin.is_lookup == False
    assert plugin.is_connection == False

    assert plugin.is_strategy == False
    assert plugin.is_action == False
    assert plugin.is_shell == False
    assert plugin.is_cache == False
    assert plugin.is_module_utils == False
    assert plugin.is_module == False
    assert plugin.is_cliconf == False
    assert plugin.is_netconf == False
    assert plugin.is_terminal == False
    assert plugin.is_test == False
    assert plugin.is_fragment == False

    assert not plugin._internal_plugin_type


# Generated at 2022-06-22 19:35:07.508438
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    obj = ConfigManager('')
    plugin_type = 'myplugin_type'
    name = 'myname'
    ret = obj.get_plugin_vars(plugin_type, name)
    assert isinstance(ret, list)

# Generated at 2022-06-22 19:35:13.762741
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config = ConfigManager()
    plugin_type = 'module_utils'
    name = 'win_command'
    options = config.get_plugin_options(plugin_type, name)
    assert options['SHELL'] == 'powershell'
    assert options['CREATE_TEMP_PATH'] == 'no'
# ----------------------------

# Generated at 2022-06-22 19:35:19.946150
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    # Fixture: ConfigManager instance
    # Test
    config_manager = ConfigManager()
    # Verify
    mock_plugin_type = mock.MagicMock()
    mock_name = mock.MagicMock()
    retval = config_manager.get_plugin_vars(mock_plugin_type, mock_name)
    # Verify
    assert retval == []


# Generated at 2022-06-22 19:35:24.743371
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.add_section(u'defaults')
    p.set(u'defaults', u'foo', u'bar')

    assert get_ini_config_value(p, {u'section': u'defaults', u'key': u'foo'}) == u'bar'



# Generated at 2022-06-22 19:35:32.741883
# Unit test for constructor of class Setting
def test_Setting():
    from ansible.release import __version__
    from ansible.config.constants import Setting
    from __init__ import AnsibleDefaults
    # import pdb;pdb.set_trace()

    defaults = AnsibleDefaults()

    # test the release version
    my_release_version = Setting('__version__', __version__, 'hardcoded', 'string')
    assert my_release_version.constant == '__version__'
    assert my_release_version.value == __version__
    assert my_release_version.origin == 'hardcoded'
    assert my_release_version.type == 'string'

    # test the defaulted DEFAULT_MODULE_PATH setting
    my_module_path = defaults.DEFAULT_MODULE_PATH

# Generated at 2022-06-22 19:35:45.942570
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''
    Unit test for method get_config_value_and_origin of class ConfigManager
    '''
    config, plugins = ConfigManager(), PluginManager()

    # Test with direct config
    direct = {'ANSIBLE_DEBUG': True}
    configfile = './ansible.cfg'
    defs = config.get_configuration_definitions()
    assert config.get_config_value_and_origin('debug', cfile=configfile, direct=direct) == (True, 'Direct')

    # Test with direct config and override
    direct = {'ANSIBLE_DEBUG': True}
    configfile = './ansible.cfg'
    defs = config.get_configuration_definitions()

# Generated at 2022-06-22 19:35:50.881427
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    data = _get_config_manager_data()
    # FIXME: Placeholder for unit test, replace with real unit test implementation.
    #assert False, "No unit test implemented for this method."
################################################################################
#                             END OF UNIT TESTS                                #
################################################################################



# Generated at 2022-06-22 19:36:00.718336
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():

    # FIXME: Write proper unit test which uses the full code path
    # instead of calling a known to work function.
    #
    # This test is written for 100% coverage, but does not actually
    # test the code.
    from ansible.constants import get_config
    from ansible.utils.color import stringc
    defs = {'ANSIBLE_TF_DIR': {'default': os.path.expanduser('~/.ansible/tmp'), 'type': 'path'}}
    try:
        cm = ConfigManager(defs)
        cm.update_config_data(defs)
    except Exception as e:
        display.error(to_text(e))


# Generated at 2022-06-22 19:36:01.750472
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    assert ConfigManager()


# Generated at 2022-06-22 19:36:10.661459
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    test_plugin_type = 'str'
    test_plugin_name = 'str'
    test_config = 'str'
    test_cfile = 'str'
    test_keys = {}
    test_variables = {}
    test_direct = {}
    try:
        result = config_manager.get_config_value_and_origin(test_config, test_cfile, test_plugin_type, test_plugin_name, test_keys, test_variables, test_direct)
        assert isinstance(result, tuple)
    except Exception as ex:
        print("get_config_value_and_origin() raised exception: %s" % ex)
        assert False


# Generated at 2022-06-22 19:36:23.720857
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    print("Testing ConfigManager.get_configuration_definition()")
    manager = ConfigManager()
    manager.initialize_plugin_configuration_definitions(b'callback', b'foo', {})
    assert manager.get_configuration_definition(b'foo', plugin_type=b'callback') == {}, 'failed to return configuration definition for plugin foo'
    manager.initialize_plugin_configuration_definitions(b'callback', b'bar', {})
    assert manager.get_configuration_definition(b'foo', plugin_type=b'callback') == {}, 'failed to return configuration definition for plugin foo'
    manager.initialize_plugin_configuration_definitions(b'callback', b'baz', {})

# Generated at 2022-06-22 19:36:26.966729
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    cls = ConfigManager
    module = AnsibleModule(
        argument_spec = dict()
    )
    args = module.parse_args(['ansible-config', '--list'])
    config = cls(args) 
    method = cls.get_configuration_definitions
    assert isinstance(method(config), dict)

# Generated at 2022-06-22 19:36:31.054827
# Unit test for constructor of class Setting
def test_Setting():
    setting = Setting('FOO', 'BAR', 'BAR_ORIGIN', 'string')
    assert setting.key == 'FOO'
    assert setting.value == 'BAR'
    assert setting.origin == 'BAR_ORIGIN'
    assert setting.type == 'string'
    assert not setting.expand



# Generated at 2022-06-22 19:36:32.845509
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Testing mock of method 'get_config_value_and_origin' in class "ConfigManager"
    assert True

# Generated at 2022-06-22 19:36:44.838082
# Unit test for function ensure_type
def test_ensure_type():
    def test(value, value_type, result):
        assert ensure_type(value, value_type) == result

    test([u'a'], None, u'a')
    test([u'a'], 'str', u'a')
    test([u'a'], 'list', [u'a'])
    test(u'a,b', 'list', [u'a', u'b'])
    test([u'a', u'b'], 'str', u'a')
    test(u'a,b', 'str', u'a,b')
    test(None, 'none', None)
    test(u'None', 'none', None)
    test(u'', 'none', None)
    test(u'0', 'none', None)

# Generated at 2022-06-22 19:36:53.412985
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/home/test.ini') == 'ini'
    assert get_config_type('/home/test.cfg') == 'ini'
    assert get_config_type('/home/test.yaml') == 'yaml'
    assert get_config_type('/home/test.yml') == 'yaml'
    try:
        get_config_type('/home/test.txt')
    except AnsibleOptionsError as e:
        assert "does not have a supported file extension" in to_native(e)
    except Exception:
        assert False
    else:
        assert False



# Generated at 2022-06-22 19:37:06.452892
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    assert config.get_plugin_vars('inventory', 'host_list') == ['host_list', 'constructed']
    assert config.get_plugin_vars('action', 'synchronize') == ['synchronize_mode', 'synchronize_src', 'synchronize_dest', 'synchronize_archive', 'synchronize_delete', 'synchronize_checksum', 'synchronize_compress', 'synchronize_copy_links', 'synchronize_link_dest', 'synchronize_use_ssh_args', 'synchronize_timeout', 'synchronize_verbose', 'synchronize_recursive']

# Generated at 2022-06-22 19:37:13.978316
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # FIXME: breaks with relative path
    path = os.path.join(os.getcwd(), 'test', 'unittests', 'test_config.cfg')
    os.environ['ANSIBLE_CONFIG'] = path
    assert find_ini_config_file() == path
    #clean up
    del os.environ['ANSIBLE_CONFIG']
    assert find_ini_config_file(warnings=set()) == None


# FIXME: can move to module_utils for use for yaml plugins also?

# Generated at 2022-06-22 19:37:23.832293
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    host = 'localhost'

    host_vars = {'foo': 'bar'}
    host_vars_file = os.path.join(init_ansible_mock_config()[0], 'host_vars', host)
    with open(host_vars_file, 'w') as f:
        f.write("foo: bar")

    host_extra_vars = {'baz': 'zab'}
    host_extra_vars_file = os.path.join(init_ansible_mock_config()[0], 'host_extra_vars', host)
    with open(host_extra_vars_file, 'w') as f:
        f.write("baz: zab")

    def __get_config_manager():
        config_manager = ConfigManager(options=Options())

# Generated at 2022-06-22 19:37:37.367798
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    # test loading of a config type from a file
    config = ConfigManager('')
    assert config.get_config_type('/etc/ansible/config.cfg') == 'ini'
    assert config.get_config_type('/etc/ansible/config.cfg.yml') == 'yaml'
    assert config.get_config_type('/etc/ansible/config.cfg.yaml') == 'yaml'

    # test loading of an ini config file
    with pytest.raises(ConfigParser.NoSectionError):
        config.get_setting('roles_path')

    config = ConfigManager('/etc/ansible/ansible.cfg')
    with pytest.raises(AnsibleOptionsError):
        config.get_setting('foo')


# Generated at 2022-06-22 19:37:49.682612
# Unit test for constructor of class Plugin
def test_Plugin():

    class TestPlugin(object):
        def __init__(self, name=None, types=None, interfaces=None, config_data=None, basedir=None):
            self.name = name
            self.types = types
            self.basedir = basedir

            if interfaces is None:
                interfaces = ['connection']
            self.interfaces = interfaces

            if config_data is None:
                config_data = {}
            self.config_data = config_data

            plugin = Plugin(self)

            self.defs = plugin.defs

        def __repr__(self):
            return self.name

    class TestConnection(TestPlugin):
        def __init__(self, *args, **kwargs):
            kwargs['types'] = constants.CONNECTION_TYPES
            super(TestConnection, self).__

# Generated at 2022-06-22 19:37:54.496976
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_name = 'test_config_manager'
    mock_constants = MagicMock()
    default_value = 'default_value'
    defs = {config_name: {'default': default_value}}
    cm = ConfigManager(defs, mock_constants)
    cm.update_config_data()
    mock_constants.update_setting.assert_called_with(Setting(config_name, default_value, 'default', 'string'))


# Generated at 2022-06-22 19:38:01.197672
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    c = ConfigManager()
    assert c.get_configuration_definitions() == ConfigManager._base_defs
    assert c.get_configuration_definitions(direct=dict(private_key_file='private_key_file')) == dict()
    assert c.get_configuration_definitions(plugin_type='become') == dict()
    assert c.get_configuration_definitions('become', 'sudo') == dict()
    assert len(c.get_configuration_definitions(ignore_private=True)) == 79
    assert len(c.get_configuration_definitions('connection', 'ssh', ignore_private=True)) == 14


# Generated at 2022-06-22 19:38:09.916156
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    print('Testing get_plugin_vars')
    test_manager = ConfigManager()
    test_manager.parsers = {b'foo': {}}
    test_manager.parsers[b'foo'][b'bar'] = {'stuff': 1, 'values': {b'key1': 'value1', b'key2': 'value2'}}

    plugin_vars = test_manager.get_plugin_vars(b'foo', b'bar')

    assert plugin_vars == [b'key1', b'key2'], "The output is %s" % plugin_vars

# Generated at 2022-06-22 19:38:13.984648
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    # This test is used to verify the functionality of ConfigManager.get_config_value()

    pass



# Generated at 2022-06-22 19:38:15.515235
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    assert find_ini_config_file() is None


# Generated at 2022-06-22 19:38:23.844027
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    data = """
    [defaults]
    allow_world_readable_tmpfiles = True

    [ssh_connection]
    pipelining = True
    """

    config = ConfigManager(Loader(), None)
    config._parse_config_file(data)
    config.update_config_data()
    plugin_name, plugin_type = ('ssh', 'connection')
    expected = {u'allow_world_readable_tmpfiles': True, u'pipelining': True}
    result = config.get_plugin_options(plugin_type, plugin_name)

    assert result == expected


# Generated at 2022-06-22 19:38:29.065089
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    '''Fixtures for ConfigManager get_config_value_and_origin method'''
    fixture = load_fixtures('config_manager', 'get_config_value_and_origin')
    data, defs, expected = fixture
    cmanager = ConfigManager(defs)
    assert cmanager.get_config_value_and_origin(data['config']) == expected


# Generated at 2022-06-22 19:38:33.166454
# Unit test for constructor of class Setting
def test_Setting():
    s = Setting('foo', 'bar', 'baz', 'string')
    assert s.name == 'foo'
    assert s.value == 'bar'
    assert s.origin == 'baz'
    assert s.type == 'string'
    assert isinstance(s, Setting)


# Generated at 2022-06-22 19:38:44.020698
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    ''' Test get_ini_config_value logic '''

    # p is None
    assert get_ini_config_value(None, {}) is None
    # No key
    p = configparser.ConfigParser()
    assert get_ini_config_value(p, {}) is None
    # Key exists
    p.add_section('foo')
    p.set('foo', 'one', 'two')
    assert get_ini_config_value(p, {'key': 'one'}) == 'two'
    assert get_ini_config_value(p, {'section': 'foo', 'key': 'one'}) == 'two'
    # Key does not exist
    assert get_ini_config_value(p, {'section': 'foo', 'key': 'two'}) is None
    # No section
    assert get

# Generated at 2022-06-22 19:38:53.933276
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    dirs = {'dir': '/dir', 'dir/dir': '/dir/dir',
            'dir/dir/dir': '/dir/dir/dir', 'dir/dir/dir/dir': '/dir/dir/dir/dir'}
    config = ConfigManager(dirs)

    assert config.DEFAULTS['DEFAULT_MODULE_LANG'] == 'en_US'

    assert config.get_config_value('DEFAULT_MODULE_LANG') == 'en_US'

    try:
        config.get_config_value('NON_EXISTANT_VAR')
    except AnsibleOptionsError:
        pass
    except:
        raise Exception("Unexpected exception")

    assert config.get_config_value('DEFAULT_VAULT_PASSWORD_FILE') is None

# Generated at 2022-06-22 19:39:04.854422
# Unit test for function resolve_path
def test_resolve_path():
    cwd = os.getcwd()
    path1 = "/this/is/a/relative/path"
    path2 = "/this/is/an/absolute/path"
    path3 = "this/is/a/relative/path"
    path4 = "this/is/a/relative/path/with/a/dangling/slash/"
    path5 = "this/is/a/relative/path/with/a/variable/{{FOO}}"
    path6 = "{{FOO}}"
    path7 = "{{FOO}}/bar"

    fake_var_env = {"FOO": "foo"}
    os.environ = fake_var_env

    # Testing with a relative path
    assert resolve_path(path1) == path1, "Failed to parse a basic relative path"
    assert resolve_

# Generated at 2022-06-22 19:39:13.703775
# Unit test for function ensure_type
def test_ensure_type():
    assert isinstance(ensure_type("True", "boolean"), bool)
    assert isinstance(ensure_type("1", "bool"), bool)
    assert isinstance(ensure_type("0", "boolean"), bool)
    assert isinstance(ensure_type("False", "bool"), bool)

    assert isinstance(ensure_type("1", "integer"), int)
    assert isinstance(ensure_type("0", "int"), int)
    assert isinstance(ensure_type("-1", "integer"), int)

    assert isinstance(ensure_type("1.0", "float"), float)
    assert isinstance(ensure_type("0.0", "float"), float)
    assert isinstance(ensure_type("-1", "float"), float)


# Generated at 2022-06-22 19:39:24.895111
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Remove ANSIBLE_CONFIG environment variable if it exists so we can test defaults
    orig_cfg = os.getenv("ANSIBLE_CONFIG", None)
    if orig_cfg is not None:
        del os.environ["ANSIBLE_CONFIG"]
    # Save current working directory and change to temp directory
    cwd = os.getcwd()
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)
    # Make a config that we know doesn't exist
    bad_cfg = os.path.join(tmp_dir, "bad.cfg")
    # Make a public directory that we'll use as cwd
    cwd_dir = tempfile.mkdtemp(prefix="ansible-tmp-cwd-")
    os.chmod(cwd_dir, 0o777)
   

# Generated at 2022-06-22 19:39:26.070477
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    test_config_manager = ConfigManager()



# Generated at 2022-06-22 19:39:29.655396
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    # TODO:
    # cfile = './config_test'
    # ctype = 'ini'
    # config = ConfigManager(cfile, ctype)
    pass

# Generated at 2022-06-22 19:39:33.404401
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp') == '/tmp'
    assert resolve_path('tmp') == 'tmp'
    assert resolve_path('~/tmp') == '~/tmp'
    assert resolve_path('relative') == 'relative'



# Generated at 2022-06-22 19:39:45.406848
# Unit test for function ensure_type
def test_ensure_type():
    ''' ensure_type unit test '''

    def _test_value(value, value_type, basedir=None, expect=None):
        if expect is None:
            expect = value
        test_value = ensure_type(value, value_type, basedir)
        if isinstance(expect, list):
            assert isinstance(test_value, list)
            assert len(expect) == len(test_value)
            for x in range(0, len(expect)):
                assert expect[x] == test_value[x]
        else:
            assert expect == test_value

    # Boolean values
    _test_value('true', 'bool', expect=True)
    _test_value('True', 'bool', expect=True)
    _test_value('yes', 'bool', expect=True)
    _

# Generated at 2022-06-22 19:39:51.045420
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    configManager = ConfigManager()
    configKey = "DEFAULT_HOST_LIST"
    configKey_default_value = "/etc/ansible/hosts"
    configManager.get_config_value(configKey) == configKey_default_value


# Generated at 2022-06-22 19:39:58.625488
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('foo.yaml') == 'yaml'
    assert get_config_type('foo.yml') == 'yaml'
    assert get_config_type('foo.ini') == 'ini'
    assert get_config_type('foo.cfg') == 'ini'
    assert get_config_type('foo') is None

    try:
        get_config_type('foo.bar')
        assert False, "this should have raised"
    except AnsibleOptionsError:
        pass



# Generated at 2022-06-22 19:40:06.915353
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = ConfigManager()
    assert cm.get_config_value_and_origin('DEFAULT_LOG_PATH') == ("{{playbook_dir}}/logs", 'default'), "Error: Default config load failed"
    assert cm.get_config_value('DEFAULT_LOG_PATH') == '{{playbook_dir}}/logs', "Error: Default config load failed"
    assert cm.get_config_value_and_origin('PYTHON_INTERPRETER') == (sys.executable, 'auto'), "Error: Default config load failed"
    assert cm.get_config_value('PYTHON_INTERPRETER') == sys.executable, "Error: Default config load failed"


# Generated at 2022-06-22 19:40:10.872453
# Unit test for function get_config_type
def test_get_config_type():
   try:
       assert get_config_type('/etc/ansible/ansible.cfg')
       assert get_config_type('/etc/ansible/ansible.cfg')=='ini'
   except Exception as e:
       raise e

# FIXME: configsrc is no longer used, since we now use cli options

# Generated at 2022-06-22 19:40:23.055013
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_manager = ConfigManager()
    config_manager._base_defs = ('test')
    defs = {}

    import unittest2 as unittest
    class TestConfigManagerUpdateConfigData(unittest.TestCase):
        def test_parse_config_files(self, mock_get_config_value_and_origin):
            with self.assertRaises(AnsibleOptionsError):
                config_manager.update_config_data(defs)

        @mock.patch('ansible.config.manager.ConfigManager.get_config_value_and_origin', return_value=(None, None))
        def test_get_config_value_and_origin(self, mock_get_config_value_and_origin):
            with self.assertRaises(AnsibleError):
                config_manager.update_config

# Generated at 2022-06-22 19:40:26.075305
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    '''
    get_plugin_vars(self, plugin_type, name)
    '''
    pass

# Generated at 2022-06-22 19:40:38.075003
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    # test constructor with defaults
    config_mgr = ConfigManager()

    # tests for error conditions
    # no config file
    with pytest.raises(AnsibleOptionsError) as excinfo:
        config_mgr = ConfigManager(None)
    assert 'Missing configuration' in to_native(excinfo.value)

    # empty config file
    with pytest.raises(AnsibleOptionsError) as excinfo:
        config_mgr = ConfigManager('')
    assert 'Missing configuration' in to_native(excinfo.value)

    # invalid config file
    with pytest.raises(AnsibleOptionsError) as excinfo:
        config_mgr = ConfigManager('/path/to/config/file')
    assert 'Unable to read' in to_native(excinfo.value)

    # invalid config