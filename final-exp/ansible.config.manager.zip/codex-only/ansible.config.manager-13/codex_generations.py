

# Generated at 2022-06-22 19:30:35.134733
# Unit test for function resolve_path
def test_resolve_path():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    assert resolve_path('/tmp') == '/tmp'
    assert resolve_path('/tmp', test_dir) == '/tmp'
    assert resolve_path('relative') == os.path.abspath('relative')
    assert resolve_path('relative', test_dir) == os.path.join(test_dir, 'relative')
    assert resolve_path('') == os.path.abspath('')
    assert resolve_path('', test_dir) == os.path.abspath(test_dir)
    assert resolve_path('{{CWD}}') == os.getcwd()
    assert resolve_path('{{CWD}}', test_dir) == os.getcwd()



# Generated at 2022-06-22 19:30:43.079496
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config = ConfigManager()
    assert isinstance(config._base_defs, dict)
    assert isinstance(config.data, Settings)
    assert len(config.data) == 0
    assert config._parsers == {}
    assert config._config_file is None
    assert config._deprecated_settings == []
    assert config._config_files == []
    assert config._plugins == {}
    assert config._display is None
    assert config.internal is False


# Generated at 2022-06-22 19:30:55.926150
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    ''' Test for get_ini_config_value '''
    p = configparser.RawConfigParser()
    p.read('test/test_plugin.cfg')
    assert get_ini_config_value(p, {'section': 'test_section', 'key': 'string1'}) == 'value1'
    assert get_ini_config_value(p, {'section': 'test_section', 'key': 'string2'}) == 'value2'
    assert get_ini_config_value(p, {'section': 'test_section', 'key': 'string3'}) == 'value3'
    assert get_ini_config_value(p, {'section': 'test_section', 'key': 'string4'}) == 'value4'

# Generated at 2022-06-22 19:31:02.908499
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config_manager = ConfigManager()

    assert config_manager.get_configuration_definitions(ignore_private=True)
    assert config_manager.get_configuration_definitions('connection', ignore_private=True)
    assert config_manager.get_configuration_definitions(plugin_type='connection', name='smart', ignore_private=True)

# Generated at 2022-06-22 19:31:04.587128
# Unit test for constructor of class ConfigManager
def test_ConfigManager():

    C = ConfigManager()


# Generated at 2022-06-22 19:31:12.989581
# Unit test for function find_ini_config_file
def test_find_ini_config_file():

    def _test(kwargs, expected_path, expected_warning=False, monkeypatch=None):
        warnings = set()
        if monkeypatch:
            monkeypatch.setattr(os, 'getenv', lambda key, default=None: kwargs.get(key, default))
            monkeypatch.setattr(os, 'getcwd', lambda: kwargs.get('cwd', '/cwd'))
        path = find_ini_config_file(warnings)
        assert expected_path == path
        if expected_warning:
            assert len(warnings) == 1
        else:
            assert len(warnings) == 0

    # No environment variable set
    _test({}, '/etc/ansible/ansible.cfg')

    # No environment variable set, no system config file

# Generated at 2022-06-22 19:31:24.425155
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    plugin_type = 'plugin_type'
    name = 'name'
    defs = dict()

    # Make sure the version is adequate
    (major, minor) = sys.version_info[:2]
    if major < 3:
        return

    assert not os.path.exists(CONFIG_FILE)

    default_config_manager = ConfigManager(CONFIG_FILE)
    default_config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    assert default_config_manager._plugins[plugin_type][name] == defs

    if os.path.exists(CONFIG_FILE):
        os.remove(CONFIG_FILE)



# Generated at 2022-06-22 19:31:28.495497
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    args = dict(
        plugin_type='module',
        name='command',
    )
    obj = ConfigManager()
    res = obj.get_plugin_vars(**args)

    assert res is not None



# Generated at 2022-06-22 19:31:31.251285
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('{{CWD}}/test') == '{{CWD}}/test'
    assert resolve_path('~/test') == os.path.expanduser('~/test')



# Generated at 2022-06-22 19:31:38.825769
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    print("test_get_configuration_definitions")
    config_manager = ConfigManager()
    defs = config_manager.get_configuration_definitions(ignore_private=True)
    assert_not_equal(defs, None)
    assert_true('callback_facts' in defs)
    assert_false(defs['callback_facts'] is None)
    assert_false('foo' in defs)


# Generated at 2022-06-22 19:31:44.753970
# Unit test for constructor of class Setting
def test_Setting():
    test = Setting('CONFIG_FILE', '/etc/ansible/ansible.cfg', '', 'string')

    assert test.name == 'CONFIG_FILE'
    assert test.value == '/etc/ansible/ansible.cfg'
    assert test.origin == ''
    assert test.type == 'string'


# Generated at 2022-06-22 19:31:56.685841
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    def test_get_value(conf_mgr, config, expected_value, expected_origin):
        value, origin = conf_mgr.get_config_value_and_origin(config)
        assert expected_value == value
        assert expected_origin == origin

    # Test case 1
    # This test uses a fake config file that doesn't exist
    # The test checks that even if the config file doesn't exist
    # the method still returns the expected values and doesn't raise an exception
    test_config_file = 'fake_config_file_that_doesnt_exist'

# Generated at 2022-06-22 19:32:02.840406
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    config_data = {
        "_meta": {
            "hostvars": {
                "example": {}
            }
        },

        "all": {
            "vars": {
                "foo": "bar"
            }
        },

        "host_pattern": {
            "hosts": [
                "example",
                "example2"
            ],

            "vars": {
                "example_var": "example_value",
                "example2_var": "example2_value"
            }
        }
    }
    config_manager = ConfigManager(config_data=config_data)

    assert config_manager.get_config_value(config='foo', keys={'foo': 'foovalue'}) == 'foovalue'

# Generated at 2022-06-22 19:32:05.919668
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
  expected = None
  actual = ConfigManager()[0].get_configuration_definition(u'CONFIG_FILE')
  assert expected == actual


# Generated at 2022-06-22 19:32:16.240687
# Unit test for function ensure_type
def test_ensure_type():
    module = AnsibleModule(
        argument_spec=dict(
            value=dict(required=True, type='str'),
            value_type=dict(required=True, type='str'),
            origin=dict(required=False, type='path'),
        )
    )
    value = module.params['value']
    value_type = module.params['value_type']
    origin = module.params['origin']
    result = ensure_type(value, value_type, origin)
    module.exit_json(msg=result)



# Generated at 2022-06-22 19:32:27.865206
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    def check_cm(cm):
        assert cm.get_config_value_and_origin('DEFAULT_MODULE_LANG') == ('python', 'default')
        assert cm.get_config_value_and_origin('DEFAULT_MODULE_LANG', direct={'DEFAULT_MODULE_LANG': None}) == (None, 'Direct')

    # create a config manager
    # base config
    conf_base = {
        'DEFAULT_MODULE_LANG': {'default': 'python'}
    }
    # env config
    conf_env = {
        'DEFAULT_MODULE_LANG': {'default': 'python'}
    }
    # cli config
    conf_cli = {
        'DEFAULT_MODULE_LANG': {'default': 'python'}
    }
   

# Generated at 2022-06-22 19:32:32.669434
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    config_manager = get_config_manager()
    assert config_manager._config_file == b"unittest_ansible.cfg"
    p = config_manager.get_config_file_path()
    assert p == b"unittest_ansible.cfg"

# Generated at 2022-06-22 19:32:42.531840
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    def _mock_getcwd():
        return "/path/to/cwd"
    def _mock_getenv(var):
        if var == "ANSIBLE_CONFIG":
            return "/path/to/ANSIBLE_CONFIG"
    def _mock_isfile(path):
        return path == "/path/to/ANSIBLE_CONFIG" or path == _mock_getcwd() + "/ansible.cfg"
    def _mock_isdir(path):
        return False
    def _mock_osstat(path):
        # Give the path returned by getcwd() a mode indicating it is world writable
        if path == _mock_getcwd():
            return os.stat_result((33204, 0, 0, 0, 0, 0, 0, 0, 0, 0))
        return

# Generated at 2022-06-22 19:32:53.592556
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    myconfig = ConfigManager(None)
    
    if myconfig is None:
        assert False, "Failed to initialize ConfigManager class"
    
    if len(glob.glob('tests/unit/data/config/base_defs_test*')) == 0:
        assert False, "Missing test config data"
    
    for test_file in glob.glob('tests/unit/data/config/base_defs_test*'):
        try: 
            # read test file
            with open(test_file, 'r') as f:
                data = yaml.safe_load(f.read())
        except Exception as e:
            assert False, "Failed to load test data: %s" % (to_native(e))
            
        # read plugin type

# Generated at 2022-06-22 19:32:59.702059
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    assert get_ini_config_value(p, {'key': 'test'}) is None
    assert get_ini_config_value(p, {'key': 'action_plugins'}) == '/path/to/action_plugins'
    # make sure we can still get values from defaults section
    assert get_ini_config_value(p, {'section': 'defaults', 'key': 'action_plugins'}) == '/path/to/action_plugins'
    assert get_ini_config_value(p, {'section': 'defaults', 'key': 'lookup_plugins'}) == '/different/lookup_plugins,/path/to/lookup_plugins'
    # make sure we can still get values from defaults section when no key is specified

# Generated at 2022-06-22 19:33:04.612004
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    config = ConfigManager()
    config_defs = config.get_configuration_definitions()
    assert config_defs
    assert config_defs['DEFAULT_LOG_PATH'] == {'accepted': '/path/to/logs', 'description': 'if specified, log events will be written to this file', 'env': [{'name': 'ANSIBLE_LOG_PATH'}], 'ini': [{'key': 'log_path', 'section': 'defaults'}], 'vars': [{'name': 'ansible_log_path'}], 'type': 'path'}


# Generated at 2022-06-22 19:33:15.723353
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = ConfigManager()
    cfile = 'myconf'
    plugin_type = 'mytype'
    plugin_name = 'myname'
    config = 'x'
    defs = {config: {'default': 1}}
    entries = [{'name': 'x'}]
    keys = {'x': 1}
    variables = {'x': 2}
    direct = {'x': 3}
    # Test the case that get_config_value_and_origin does not raise an exception
    cm.get_configuration_definitions = mock.MagicMock(return_value=defs)

# Generated at 2022-06-22 19:33:20.344567
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config_manager = ConfigManager()
    config_manager.initialize_plugin_configuration_definitions('strategy', 'linear', C.STRATEGY_PLUGIN_CONSTANTS)
    config_manager.update_config_data({'strategy_plugins': 'linear'})
    config_manager.get_plugin_options('strategy', 'linear')

test_ConfigManager_get_plugin_options()


# Generated at 2022-06-22 19:33:31.788554
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    ''' Unit test for ConfigManager.get_config_value_and_origin '''

    from ansible.config.manager import ConfigManager


# Generated at 2022-06-22 19:33:38.215172
# Unit test for function resolve_path
def test_resolve_path():
    def osp(p):
        return p.replace('/', os.sep)

    assert resolve_path('/tmp/{{CWD}}/foo', '/roor') == osp('/roor' + os.sep + 'foo')
    assert resolve_path('/tmp/{{CWD}}/{{CWD}}', '/roor') == osp('/roor/roor')
    assert resolve_path('foo/{{CWD}}/bar', '/roor') == osp('/roor/bar')



# Generated at 2022-06-22 19:33:47.481355
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    #
    # default test
    #
    cm = ConfigManager()
    cm.get_configuration_definitions() # no exception

    #
    # test exceptions
    #

    # test ConfigManager.get_configuration_definitions exception
    cm = ConfigManager()
    with pytest.raises(Exception) as excinfo:
        cm.get_configuration_definitions(plugin_name='faker')
    assert 'plugin_type' in str(excinfo.value)

    # test ConfigManager.get_configuration_definitions exception
    cm = ConfigManager()
    with pytest.raises(Exception) as excinfo:
        cm.get_configuration_definitions(plugin_type='faker')
    assert 'plugin_name' in str(excinfo.value)

    # test ConfigManager.get_configuration_

# Generated at 2022-06-22 19:33:56.262090
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    p = mock.MagicMock(spec_set=ConfigManager)
    defs = {"CONFIG_FILE": {"default": "test"}, "ANSIBLE_PRIVATE_KEY_FILE": {"default": "test", "env": [{"name": "ANSIBLE_PRIVATE_KEY_FILE"}]}}
    configfile = 'test'
    ans = p.update_config_data(defs, configfile)
    assert ans is None



# Generated at 2022-06-22 19:34:02.692668
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type('/etc/ansible/ansible.cfg') == 'ini'
    assert get_config_type('/etc/ansible/ansible.yml') == 'yaml'
    try:
        get_config_type('/etc/ansible/ansible.cfg.not')
    except AnsibleOptionsError:
        pass
    else:
        assert False, "unsupported extension did not error"



# Generated at 2022-06-22 19:34:09.525428
# Unit test for function get_config_type
def test_get_config_type():
    '''
    Test of get_config_type
    '''
    test_data = [
        {'input': 'config/ansible.cfg', 'output': 'ini'},
        {'input': 'config/ansible.yaml', 'output': 'yaml'},
        {'input': 'config/ansible.yml', 'output': 'yaml'},
        {'input': 'config/inventory', 'output': None},
    ]

    for entry in test_data:
        assert get_config_type(entry['input']) == entry['output']



# Generated at 2022-06-22 19:34:18.331315
# Unit test for function get_config_type
def test_get_config_type():
    """
    Verify function get_config_type() returns expected value.
    """
    result = get_config_type('ansible.cfg')
    assert result == 'ini'
    result = get_config_type('ansible.yaml')
    assert result == 'yaml'
    result = get_config_type('ansible.yml')
    assert result == 'yaml'
    try:
        result = get_config_type('ansible.xyz')
        assert False
    except AnsibleOptionsError:
        assert True



# Generated at 2022-06-22 19:34:25.336792
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    try:
        defs = None
        configfile = None
        config = ConfigManager(defs, configfile)
        # No good way to test for this, as it is not used internally, except in the
        # .display config, which is exposed from the Display back to the ConfigManager
    except Exception as exception:
        logging.error("Uncaught exception in test_ConfigManager_update_config_data: '%s'", exception)
        return False

    return True

test_ConfigManager_update_config_data()


# Generated at 2022-06-22 19:34:39.199093
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    config = ConfigManager(None)
    assert config.plugin_names['callback'] == ['default']

# Generated at 2022-06-22 19:34:52.199040
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    cfg = ConfigManager()
    cfg.data = DummyData()
    cfg._config_file = 'ansible.cfg'
    cfg._base_defs = {
        'DEFAULT_HOST' : {
            'type' : 'string',
            'required' : False,
            'default'  : 'localhost',
            'cli': [
                     {'name': 'host', 'type': 'string', 'env': [None], 'ini': [
                            {'section': 'defaults', 'key': 'host'}
                     ]}
                   ],
            'env': [
                        {'name': 'ANSIBLE_HOST'},
                   ],
            'ini': [
                       {'section': 'defaults', 'key': 'host'}
                   ],
        },
    }

    cfg._p

# Generated at 2022-06-22 19:35:03.902799
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    """Test the function find_ini_config_file, which is used to find ansible configuration files.

    Specifically we are testing that the function warns the user if they are running ansible in a
    world writable directory.
    """
    warnings = set()
    # No config file was found
    assert find_ini_config_file(warnings) is None
    # No warning should have been issued
    assert not warnings

    # Create a world writable directory to run ansible in
    with tempfile.TemporaryDirectory() as cwd:
        os.chmod(cwd, stat.S_IROTH | stat.S_IWOTH)

        # Now create an ansible config file in the cwd

# Generated at 2022-06-22 19:35:15.225425
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    """Test the function of get_ini_config_value"""
    # test if config contains the section
    p = configparser.ConfigParser(allow_no_value=True)
    p.readfp(io.BytesIO(b'''
    [test]
    key1 = value1
    key2 = value2
    '''))
    assert get_ini_config_value(p, {'section': 'test', 'key': 'key1'}) == 'value1'
    # test if config does not contain the section
    assert get_ini_config_value(p, {'section': 'unexist_section', 'key': 'key1'}) is None
    # test if config does not contain the key

# Generated at 2022-06-22 19:35:24.120762
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    config_manager = ConfigManager()
    config_manager.DEFAULTS = None
    config_manager._base_defs = {}
    config_manager.get_config_value = mock.Mock()
    config_manager.get_config_value.return_value = None
    config_manager.initialize_plugin_configuration_definitions = mock.Mock()
    config_manager.update_config_data(defs={})
    if not config_manager.get_config_value.called:
        raise AssertionError("Expected call to mock 'get_config_value' was not called")

# Generated at 2022-06-22 19:35:32.327161
# Unit test for method get_config_value of class ConfigManager

# Generated at 2022-06-22 19:35:38.210526
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Test get_config_value_and_origin() works as expected with all possible values
    # of config, cfile, plugin_type, plugin_name, keys, variables, and direct.

    # Test we can retrieve values set through defaults, cli, ini, yaml, and environment
    for config in DIRECT_CONFIG_DEFAULTS:
        obj = ConfigManager(configfile=None)
        assert obj.get_config_value_and_origin(config)[0] == DIRECT_CONFIG_DEFAULTS[config]

    # Test that environment variables get precedence over defaults
    for config in DIRECT_CONFIG_DEFAULTS:
        choice = 'I AM DEFINITELY NOT THE DEFAULT'
        env = os.environ.copy()
        env['ANSIBLE_%s' % config] = choice

# Generated at 2022-06-22 19:35:51.176448
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    import io
    p = configparser.ConfigParser()
    p.readfp(io.StringIO(
        '[defaults]\n'
        'test_a = this is a test\n'
    ))
    # test case 1
    entry = dict(section='defaults', key='test_a')
    result = get_ini_config_value(p, entry)
    assert result == 'this is a test'

    # test case 2
    entry = dict(section='defaults', key='test_b')
    result = get_ini_config_value(p, entry)
    assert result is None

    # test case 3
    entry = dict(section='defaults')
    result = get_ini_config_value(p, entry)
    assert result is None

    # test case 4

# Generated at 2022-06-22 19:35:53.149111
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    tmp1 = ConfigManager()

 

# Generated at 2022-06-22 19:35:55.550472
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config_manager = ConfigManager()
    assert None == config_manager.get_config_value_and_origin('should_be_none')

# Generated at 2022-06-22 19:36:05.633630
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    '''
    Unit tests for function find_ini_config_file
    '''
    # Create a temporary working directory with a tempfile
    # Create ansible.cfg in current working directory
    # Set cwd to temporary path
    # Check for ansible.cfg in current working directory
    # Cleanup
    tmpdir = tempfile.mkdtemp()
    tempfile.mkstemp(dir=tmpdir)
    olddir = os.getcwd()
    os.chdir(tmpdir)
    b_ansible_cfg = to_bytes(os.path.join(tmpdir, "ansible.cfg"))
    with open(b_ansible_cfg, "w") as f:
        f.write("config file")
    found = find_ini_config_file()
    os.remove(b_ansible_cfg)


# Generated at 2022-06-22 19:36:18.520749
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    p = configparser.ConfigParser()
    p.add_section('sectionname')
    p.set('sectionname', 'key1', 'value1')
    p.set('sectionname', 'key2', 'value2')
    assert 'value1' == get_ini_config_value(p, dict(section='sectionname', key='key1'))
    assert 'value1' == get_ini_config_value(p, dict(section='sectionname', key='key1', default='somevalue'))
    assert 'somevalue' == get_ini_config_value(p, dict(section='sectionname', key='key3', default='somevalue'))
    assert 'somevalue' == get_ini_config_value(p, dict(section='sectionname', key='key3', default='somevalue'))


# FIXME:

# Generated at 2022-06-22 19:36:21.145327
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    results = {}
    # placeholder for proper test, requires config manager and plugins
    assert results == {}

# Generated at 2022-06-22 19:36:27.347208
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():
    # Display the test name for this test, as tests can be filtered by test name
    display_test_name("test_ConfigManager_get_configuration_definition")
    # Create the instance to be tested
    config = ConfigManager()
    # Call the function with all possible arguments, expect to get the default values
    result = config.get_configuration_definition(None, None)
    # Perform the tests
    assert result == None


# Generated at 2022-06-22 19:36:40.835312
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    config = ConfigManager(parser=FakeConfigParser())
    config.define_setting('ANSIBLE_CONFIG')
    config.define_setting('ANSIBLE_STDOUT_CALLBACK')
    config._parsers = {'/etc/ansible/ansible.cfg': FakeConfigParser()}
    config._parsers['/etc/ansible/ansible.cfg'].add_section('defaults')
    config._parsers['/etc/ansible/ansible.cfg'].set('defaults', 'log_path', 'test')
    config._parsers['/etc/ansible/ansible.cfg'].set('defaults', 'retry_files_enabled', 'False')
    config._parsers['/etc/ansible/ansible.cfg'].set('defaults', 'roles_path', '/tmp')


# Generated at 2022-06-22 19:36:48.038165
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    """
    Unit test for method get_config_value_and_origin of class ConfigManager
    """
    with pytest.raises(AnsibleError):
        config_manager = ConfigManager(config_data=None, connection_type='')
        config_manager.get_config_value_and_origin(config='config', cfile=None, plugin_type=None, plugin_name=None, keys=None, variables=None, direct=None)



# Generated at 2022-06-22 19:36:58.440313
# Unit test for function ensure_type
def test_ensure_type():
    # This tests the complex setup of nested configuration
    # that is used with the configuration plugin
    assert ensure_type('a string', 'string') == 'a string'
    assert ensure_type('Hello,  world!', 'string') == 'Hello,  world!'
    assert ensure_type(None, 'string') == None

    assert ensure_type('true', 'boolean') is True
    assert ensure_type('true', 'bool') is True
    assert ensure_type(True, 'boolean') is True
    assert ensure_type(True, 'bool') is True
    assert ensure_type('yes', 'boolean') is True
    assert ensure_type('yes', 'bool') is True
    assert ensure_type('on', 'boolean') is True
    assert ensure_type('on', 'bool') is True

# Generated at 2022-06-22 19:37:06.495561
# Unit test for function get_config_type
def test_get_config_type():
    assert get_config_type(cfile='test.yml') == 'yaml'
    assert get_config_type(cfile='test.yaml') == 'yaml'
    assert get_config_type(cfile='test.ini') == 'ini'
    assert get_config_type(cfile='test.cfg') == 'ini'
    try:
        get_config_type(cfile='test.txt')
    except AnsibleOptionsError:
        pass


# FIXME: see if this can be moved to utils.module_docs or some such

# Generated at 2022-06-22 19:37:16.761869
# Unit test for constructor of class Plugin
def test_Plugin():
    test_data = {'src': 'yum'}
    plugin_name = 'foo'
    plugin = Plugin(plugin_name, test_data)
    assert plugin.name == plugin_name
    assert plugin.data == test_data
    assert plugin.status == []

    # test obj is dict-like and 'data' attribute is immutable
    try:
        plugin['foo'] = 'bar'
        assert False, "Shouldn't be able to set value for a key in plugin"
    except NotImplementedError:
        pass
    try:
        plugin.data['foo'] = 'bar'
        assert False, "Shouldn't be able to set value for a key in plugin.data"
    except NotImplementedError:
        pass


# Generated at 2022-06-22 19:37:25.429598
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    # Create ini_config_value
    fd, ini_config_value = tempfile.mkstemp()
    with open(ini_config_value, "w") as config:
        config.write('[defaults]\n')
        config.write('key=value\n')
    # Config parser
    p = configparser.ConfigParser()
    p.read(ini_config_value)
    # Test case of section key
    def test_section_key():
        entry = {'section': 'defaults', 'key': 'key'}
        assert get_ini_config_value(p, entry) == 'value'
    test_section_key()
    # Test case of section
    def test_section():
        entry = {'section': 'defaults', 'key': 'does_not_exist'}
       

# Generated at 2022-06-22 19:37:27.707408
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    config = ConfigManager()
    config.get_plugin_options()


# Generated at 2022-06-22 19:37:40.094139
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    import json
    import os
    import pprint
    import sys

    config_manager = ConfigManager()

    # the following tests assume that the default config file is present

    # test all config values
    defs = config_manager.get_configuration_definitions()
    if not isinstance(defs, dict):
        raise Exception('Unexpected type returned by get_configuration_definitions(): %s' % type(defs))

    # test all values for a specific plugin
    defs = config_manager.get_configuration_definitions('callback')

# Generated at 2022-06-22 19:37:44.363154
# Unit test for function get_config_type
def test_get_config_type():
    assert(get_config_type('/path/to/test.yaml') == 'yaml')
    assert(get_config_type('/path/to/test.yml') == 'yaml')
    assert(get_config_type('/path/to/test.ini') == 'ini')
    assert(get_config_type('/path/to/test.cfg') == 'ini')


# FIXME: generic file type?

# Generated at 2022-06-22 19:37:49.441142
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
  config_manager = ConfigManager()
  config_manager.initialize_plugin_configuration_definitions('test', 'test', ['test'])
  config_manager._plugins['test']['test'] = ['test']


# Generated at 2022-06-22 19:37:53.464301
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
  # testing get_config_value with a string
  config_manager_obj = config.config_manager.ConfigManager()
  try:
    config_manager_obj.get_config_value("ANSIBLE_CONFIG")
  except Exception as e:
    assert False, "Failed to get_config_value with a string"



# Generated at 2022-06-22 19:38:05.644647
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('True', 'bool') == True
    assert ensure_type('False', 'bool') == False
    assert ensure_type(3, 'int') == 3
    assert type(ensure_type(3.0, 'float')) == float
    assert ensure_type('a,b,c', 'list') == ['a', 'b', 'c']
    assert ensure_type('a', 'list') == ['a']
    assert ensure_type('None', 'none') == None
    assert ensure_type('~', 'path') == os.path.expanduser('~')
    assert isinstance(ensure_type('/tmp', 'tmppath'), string_types)

# Generated at 2022-06-22 19:38:10.363261
# Unit test for constructor of class Setting
def test_Setting():
    result = Setting('CONFIG_FILE', '/path/to/anisble.cfg', 'config file', 'string')

    assert result.setting == 'CONFIG_FILE'
    assert result.value == '/path/to/anisble.cfg'
    assert result.origin == 'config file'
    assert result.setting_type == 'string'


# Generated at 2022-06-22 19:38:21.719004
# Unit test for method get_configuration_definition of class ConfigManager
def test_ConfigManager_get_configuration_definition():

    cm = ConfigManager()
    cm._base_defs = copy.deepcopy(CONFIG_DEFAULTS)
    cm._plugins = copy.deepcopy(INTERNAL_DEFS)
    cm._parsers = {}

    # base config
    assert cm.get_configuration_definition('host_key_checking') == CONFIG_DEFAULTS['host_key_checking']
    assert cm.get_configuration_definition('_unknown') == None

    # plugin config
    assert cm.get_configuration_definition('time_tasks', plugin_type='strategy', plugin_name='linear') == INTERNAL_DEFS['strategy']['linear']['time_tasks']


# Generated at 2022-06-22 19:38:33.327205
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    # plain string
    p = configparser.ConfigParser()
    entry = {'section': 'defaults', 'key': 'val1'}
    p.add_section(entry.get('section', 'defaults'))
    p.set(entry.get('section', 'defaults'), entry.get('key', ''), 'value1')
    assert get_ini_config_value(p, entry) == 'value1'

    # has variable
    p = configparser.ConfigParser()
    entry = {'section': 'defaults', 'key': 'val2'}
    p.add_section(entry.get('section', 'defaults'))
    p.set(entry.get('section', 'defaults'), entry.get('key', ''), 'value2${var2}')

# Generated at 2022-06-22 19:38:43.603276
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    config.initialize_plugin_configuration_definitions('plugin_type', 'plugin_name', {
        'foo': {
            'description': 'bar',
            'default': 'baz',
            'vars': [{
                'name': 'AN_ENV_VAR',
                'type': 'str',
                'dest': 'an_env_var'
            }]
        },
        'bob': {
            'description': 'hope',
            'type': 'str',
            'default': 'gilligan'
        }
    })
    assert config.get_plugin_vars('plugin_type', 'plugin_name') == ['AN_ENV_VAR']


# Generated at 2022-06-22 19:38:52.801726
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():
    config = ConfigManager()
    playbook = '''
- hosts: localhost
  tasks:
    - name: "{{ 'a' if cond else 'b' }}"
      debug:
        msg: "{{ 'a' if cond else 'b' }}"
'''
    data = yaml.load(playbook)
    pb = Playbook.load(data, variable_manager=VariableManager(), loader=DataLoader())
    for p in pb.get_plays():
        for t in p.tasks:
            for k in t.vars_prompt:
                err = config.get_plugin_vars('', k)
                print (err)

# Generated at 2022-06-22 19:39:04.229486
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    # case sensitive
    p = configparser.ConfigParser(False)
    p.read_dict({'section': {'Key': 'Value'}})
    assert None is get_ini_config_value(p, {'section': 'section', 'key': 'key1'})
    assert None is get_ini_config_value(p, {'section': 'section1', 'key': 'key'})
    assert 'Value' is get_ini_config_value(p, {'section': 'section', 'key': 'Key'})
    assert 'Value' is get_ini_config_value(p, {'section': 'section', 'key': 'Key', 'section_key': 'section'})
    assert None is get_ini_config_value(p, {'section': 'section', 'section_key': 'section1'})


# Generated at 2022-06-22 19:39:09.913554
# Unit test for method get_plugin_options of class ConfigManager
def test_ConfigManager_get_plugin_options():
    # Parameters passed from test cases
    config, name, plugin_type, keys, variables, direct = mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock()

    # Invoke method
    result = ConfigManager().get_plugin_options(config, name, plugin_type, keys, variables, direct)

    # Check invoke result
    assert result is None


# Generated at 2022-06-22 19:39:21.761895
# Unit test for function ensure_type
def test_ensure_type():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import text_type

    assert ensure_type("10", "int") == 10
    assert ensure_type("10", "integer") == 10
    assert ensure_type("10.0", "float") == 10.0
    assert ensure_type("10.0", "float") != 10
    assert ensure_type("10.0", "float") != 10.1
    try:
        ensure_type("a", "int")
        assert False
    except ValueError:
        pass
    try:
        ensure_type("a", "integer")
        assert False
    except ValueError:
        pass
    try:
        ensure_type("a", "float")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 19:39:30.546123
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('frank', 'boolean')
    assert ensure_type(True, 'boolean')
    assert ensure_type('yes', 'boolean')
    assert ensure_type('false', 'boolean')
    assert not ensure_type('bad', 'boolean')
    assert not ensure_type(None, 'boolean')

    assert ensure_type('1', 'integer')
    assert ensure_type(0, 'integer')
    assert not ensure_type(1.1, 'integer')
    assert not ensure_type('bad', 'integer')
    assert not ensure_type(None, 'integer')

    assert ensure_type('1.1', 'float')
    assert ensure_type(0.0, 'float')
    assert ensure_type(0, 'float')
    assert not ensure_type(1, 'float')


# Generated at 2022-06-22 19:39:38.221677
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    from ansible.config.manager import ConfigManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    configManager = ConfigManager()
    # test with a direct setting
    assert configManager.get_config_value_and_origin('DEFAULT_HOST_LIST','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',['localhost'],'direct')[0] == ['localhost']
    # test with a direct setting for alias

# Generated at 2022-06-22 19:39:49.431064
# Unit test for function resolve_path
def test_resolve_path():
    from ansible.utils.path import makedirs_safe
    basedir = None
    test_path = '/tmp/ansible-testing/resolve_path'
    makedirs_safe(test_path, mode=0o700)
    atexit.register(cleanup_tmp_file, test_path)

    test_path_symlink = '/tmp/ansible-testing/resolve_path_symlink'

    def cleanup():
        for p in (test_path_symlink, test_path):
            if os.path.exists(p):
                cleanup_tmp_file(p)

    atexit.register(cleanup)

    # Test defaults
    try:
        assert test_path == resolve_path('resolve_path')
    except AssertionError:
        traceback.print_exc()

# Generated at 2022-06-22 19:40:01.223072
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    cfg_mgr = ConfigManager()

    cfg_mgr.data.update_setting(Setting('CONFIG_FILE', 'config_file', '', 'string'))
    cfg_mgr.data.update_setting(Setting('config', 'value', 'origin', 'string'))
    cfg_mgr.data.update_setting(Setting('config2', 'value2', 'origin2', 'string'))
    cfg_mgr.data.update_setting(Setting('config3', 'value3', 'origin3', 'string'))

    # assert defaults
    assert cfg_mgr.data.get_setting('CONFIG_FILE') is not None
    assert to_text(cfg_mgr.data.get_setting('CONFIG_FILE').value) == 'config_file'

# Generated at 2022-06-22 19:40:03.644275
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
  g_config: ConfigManager.get_config_value_and_origin()
  assert g_config == '', 'Expected empty string'


# Generated at 2022-06-22 19:40:14.737986
# Unit test for constructor of class ConfigManager
def test_ConfigManager():
    ''' test constructor for ConfigManager '''

    # init config with defaults
    config_obj = ConfigManager()

    # make sure we got an object back
    assert isinstance(config_obj, ConfigManager)

    # make sure we got the defaults
    for entry in config_obj.data:
        assert entry in CONFIG_DEFAULTS

    # make sure we got the constants
    for entry in config_obj.constants:
        assert entry in config_obj.data

    # make sure config_base and config_file are in data
    assert 'CONFIG_BASE' in config_obj.data
    assert 'CONFIG_FILE' in config_obj.data

    # make sure config_base is set properly
    expected = os.path.expanduser('~/.ansible')

# Generated at 2022-06-22 19:40:24.894038
# Unit test for constructor of class Setting
def test_Setting():
    # Testing all the functions in module, except for the 'validate' function
    # validate is tested in test_config, with all the other ansible-config.cfg tests
    s = Setting('A', 'B', 'C', 'D')
    assert isinstance(s, Setting)
    assert s.name == 'A'
    assert s.value == 'B'
    assert s.origin == 'C'
    assert s.desc == ''
    # Changed 'desc' to 'description'
    s = Setting('A', 'B', 'C', 'D', desc='F')
    assert s.desc == 'F'
    # Testing the equality, inequality operators
    # all equal
    s1 = Setting('A', 'B', 'C', 'D')
    s2 = Setting('A', 'B', 'C', 'D')

# Generated at 2022-06-22 19:40:25.825495
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    assert find_ini_config_file()



# Generated at 2022-06-22 19:40:37.621667
# Unit test for function find_ini_config_file
def test_find_ini_config_file():

    # Mock this out
    def getcwd():
        return "/some/random/cwd"

    os.getcwd = getcwd

    assert "/etc/ansible/ansible.cfg" == find_ini_config_file()

    # mock this out
    def getenv(name):
        return "/some/random/path"

    os.getenv = getenv

    assert "/some/random/path/ansible.cfg" == find_ini_config_file()

    def stat(path):
        s = stat_t()
        s.st_mode = 0
        return s

    stat_t = namedtuple('stat_t', 'st_mode')

    os.stat = stat

    assert "~/.ansible.cfg" == find_ini_config_file()

    # mock this out