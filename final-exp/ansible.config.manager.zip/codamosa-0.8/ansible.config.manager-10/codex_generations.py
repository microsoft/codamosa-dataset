

# Generated at 2022-06-10 22:58:02.303879
# Unit test for function ensure_type
def test_ensure_type():
    value = 'bob'
    result = ensure_type(value, 'string')
    assert result == u'bob'

    value = 'True'
    result = ensure_type(value, 'boolean')
    assert isinstance(result, bool)
    assert result is True

    value = '3'
    result = ensure_type(value, 'integer')
    assert isinstance(result, int)
    assert result == 3

    value = '3.3'
    result = ensure_type(value, 'float')
    assert isinstance(result, float)
    assert result == 3.3

    value = 'a,b,c'
    result = ensure_type(value, 'list')
    assert isinstance(result, list)
    assert result == ['a', 'b', 'c']



# Generated at 2022-06-10 22:58:05.345651
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    cm = ConfigManager()
    defs = cm.get_configuration_definitions()
    assert defs is not None

# Generated at 2022-06-10 22:58:10.325879
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(None, 'str') is None
    assert ensure_type("", 'str') == u''
    assert isinstance(ensure_type("", 'float'), float)
    assert isinstance(ensure_type("", 'int'), int)
    assert ensure_type("", 'bool') is False
    assert ensure_type("", 'list') == [u'']
    assert isinstance(ensure_type("", 'tmppath'), string_types)
    assert isinstance(ensure_type("", 'dict'), dict)
    assert isinstance(ensure_type("", 'dictionary'), dict)



# Generated at 2022-06-10 22:58:20.388419
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    import ansible.config.manager
    config_manager = ansible.config.manager.ConfigManager()
    # General test case:
    config = 'ansible_connection'
    plugin_type = 'connection'
    name = 'local'

# Generated at 2022-06-10 22:58:25.002931
# Unit test for function get_config_type
def test_get_config_type():
    assert 'ini' == get_config_type('/etc/ansible/ansible.cfg')
    assert 'yaml' == get_config_type('/etc/ansible/roles/test.yml')
    try:
        get_config_type('/etc/ansible/roles/test.txt')
    except AnsibleOptionsError as e:
        assert "Unsupported configuration file extension for" in to_native(e)


# Generated at 2022-06-10 22:58:35.602306
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    cm = get_config_manager_for_tests()
    assert cm
    # test data
    config = 'become'
    cfile = '/etc/ansible/ansible.cfg'
    plugin_type = 'strategy'
    plugin_name = 'linear'
    keys = {'become': True, 'become_user': 'root', 'become_method': 'sudo'}
    variables = {'ansible_user': 'root'}
    direct = {'become_method': 'doas'}
    defs = cm.get_configuration_definitions(plugin_type, plugin_name)
    assert defs
    value, origin = cm.get_config_value_and_origin(config, cfile, plugin_type, plugin_name, keys, variables, direct)

# Generated at 2022-06-10 22:58:40.355777
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    warnings = []
    assert find_ini_config_file(warnings=warnings) == unfrackpath('~/.ansible.cfg', follow=False)
    assert warnings == []
    os.environ['ANSIBLE_CONFIG'] = unfrackpath('~/.ansible.cfg', follow=False)
    assert find_ini_config_file(warnings=warnings) == os.environ['ANSIBLE_CONFIG']
    assert warnings == []
    os.environ.pop('ANSIBLE_CONFIG')
    assert find_ini_config_file(warnings=warnings) == '/etc/ansible/ansible.cfg'
    assert warnings == []



# Generated at 2022-06-10 22:58:43.431471
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    data = ConfigData()
    cm = ConfigManager(defs=DEFAULT_CONFIG_DATA, data=data)
    cm.get_configuration_definitions()
    pass


# Generated at 2022-06-10 22:58:45.961760
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    ''' Unit test for function find_ini_config_file '''

    # Invalid test, we only know its set above. It's also based on env.
    # assert not find_ini_config_file()

    with py3compat.mock_open() as m:
        # Invalid test we can't set things up in the modue to be able to mock stuff
        # assert not find_ini_config_file()
        pass



# Generated at 2022-06-10 22:58:49.229193
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # pylint: disable=redefined-outer-name
    sys.stderr.write("NOTE: TESTING get_config_value_and_origin of class ConfigManager NOT IMPLEMENTED\n")