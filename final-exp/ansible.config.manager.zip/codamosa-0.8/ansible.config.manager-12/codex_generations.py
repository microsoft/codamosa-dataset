

# Generated at 2022-06-10 22:55:16.413645
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Get the test config file data to use
    test_config = yaml.safe_load(open(C.TEST_CONFIG_FILE, 'r').read())
    for config_type in test_config:
        for test_config_item in test_config[config_type]:
            test_input = test_config_item[0]
            expected_results = test_config_item[1]
            # Run the test
            config_manager = ConfigManager(C.DATA_PATH, C.CONFIG_FILE)
            config_manager._parse_config_file(C.TEST_CONFIG_FILE)

# Generated at 2022-06-10 22:55:22.889941
# Unit test for method get_config_value_and_origin of class ConfigManager

# Generated at 2022-06-10 22:55:30.083846
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    """
    test_ConfigManager_get_config_value_and_origin tests get_config_value_and_origin
    method of ConfigManager class
    """
    cmgr = ConfigManager(config_file=None)

    # Test get_config_value_and_origin with no config file
    plugin_name = 'plugin_name'
    plugin_type = 'plugin_type'
    config = 'config'
    defs = {config: {'type': 'string'}}
    cmgr.initialize_plugin_configuration_definitions(plugin_type, plugin_name, defs)
    expected = ('', None)
    value, origin = cmgr.get_config_value_and_origin(config, plugin_type=plugin_type, plugin_name=plugin_name)

# Generated at 2022-06-10 22:55:39.603549
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # test defaults
    orig_path = os.getcwd()
    path = find_ini_config_file()
    os.chdir(orig_path)
    assert path is not None
    assert os.path.isfile(path)
    assert os.access(path, os.R_OK)

    # test env override
    path = None

# Generated at 2022-06-10 22:55:48.235875
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    from ansible.config.manager import ConfigManager
    from ansible.config.base import BaseConfig
    from ansible.config.data import load_config_definitions
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import sys
    import pytest
    c = ConfigManager(loader=DataLoader(), defs=load_config_definitions())
    kwargs=dict()
    loader=kwargs.pop('loader', DataLoader())
    defs=kwargs.pop('defs', None)
    conf=BaseConfig(loader=loader, defs=defs)
    c._config_file='/root/.ansible.cfg'
    conf._config_file='/root/.ansible.cfg'

# Generated at 2022-06-10 22:55:50.296330
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('{{CWD}}/foo') == os.getcwd() + '/foo'
    assert resolve_path('./foo') == os.getcwd() + '/foo'



# Generated at 2022-06-10 22:55:59.840039
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    """
    test cases for method get_config_value_and_origin
    """
    from ansible.config.manager import ConfigManager, Setting
    from ansible.config.data import ConfigData
    from ansible.plugins.loader import find_plugin_filepaths
    from ansible.errors import AnsibleError
    from ansible.utils.path import unfrackpath
    config_test_dirs = find_plugin_filepaths()
    config_file = "/file/path"
    plugin_type = "connection"
    plugin_name = "mock"
    config = "SUPPORT_CHECK_MODE"

# Generated at 2022-06-10 22:56:07.261470
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():

    from ansible.constants import CONFIG_FILE_NAME

    # set up a test
    config_manager = ConfigManager(config_file=CONFIG_FILE_NAME, plugin_dirs=[])
    config_manager.initialize_plugin_configuration_definitions('asdf', 'asdf', INTERNAL_DEFS)

    # test deprecation of the setting
    defs = {'FOO': {'type': 'string', 'required': True, 'aliases': ['FOO1', 'FOO2'], 'deprecated': 'This setting is deprecated.'}}
    config_manager.initialize_plugin_configuration_definitions('asdf', 'asdf', defs)

# Generated at 2022-06-10 22:56:15.694793
# Unit test for method get_plugin_vars of class ConfigManager
def test_ConfigManager_get_plugin_vars():

    config = ConfigManager([])

    assert config.get_plugin_vars('lookup', 'file') == ['vars']
    assert config.get_plugin_vars('callback', 'default') == ['vars']
    assert config.get_plugin_vars('connection', 'local') == []
    assert config.get_plugin_vars('shell', 'sh') == ['env']
    assert config.get_plugin_vars('action', 'copy') == []
    assert config.get_plugin_vars('shell', 'fish') == []
    assert config.get_plugin_vars('action', 'template') == []
    assert config.get_plugin_vars('shell', 'csh') == ['env']
    assert config.get_plugin_vars('connection', 'network_cli') == []
    assert config.get_

# Generated at 2022-06-10 22:56:24.384714
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(True, value_type='') == 'True'
    assert ensure_type(True, value_type='boolean') is True
    assert ensure_type(True, value_type='bool') is True
    assert ensure_type('42', value_type='integer') == 42
    assert ensure_type('42', value_type='int') == 42
    assert ensure_type('42', value_type='float') == 42.0
    assert ensure_type('42', value_type='list') == ['42']
    assert ensure_type('42', value_type='none') == '42'
    assert ensure_type('42', value_type='path') == '/42'
    assert ensure_type('42', value_type='none', origin='/foo') == '/foo/42'