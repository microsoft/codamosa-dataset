

# Generated at 2022-06-10 23:00:34.067740
# Unit test for function ensure_type

# Generated at 2022-06-10 23:00:42.930995
# Unit test for function resolve_path
def test_resolve_path():
    assert not os.path.join(os.getcwd(), 'foo', 'bar').endswith('/')
    assert os.path.join(os.getcwd(), 'foo', 'bar') == resolve_path('.')
    tmpfile = resolve_path('foo', './bar')
    assert os.path.join(os.getcwd(), 'bar', 'foo') == tmpfile
    tmpfile = resolve_path('foo', '/bar')
    assert os.path.join('/bar', 'foo') == tmpfile
    tmpfile = resolve_path('foo', '/bar/')
    assert os.path.join('/bar', 'foo') == tmpfile



# Generated at 2022-06-10 23:00:55.382058
# Unit test for function resolve_path