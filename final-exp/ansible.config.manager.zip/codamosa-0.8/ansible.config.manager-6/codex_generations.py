

# Generated at 2022-06-10 22:57:12.204631
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
  configmgr = ConfigManager()
  config = ""
  cfile = ""
  plugin_type = ""
  plugin_name = ""
  keys = {}
  variables = {}
  direct = ""
  return configmgr.get_config_value_and_origin(config, cfile, plugin_type, plugin_name, keys, variables, direct)

# Generated at 2022-06-10 22:57:18.318236
# Unit test for function get_config_type
def test_get_config_type():
    ftype = get_config_type('./config/ansible.cfg')
    assert ftype == 'ini'
    ftype = get_config_type('./ansible.cfg')
    assert ftype == 'ini'
    ftype = get_config_type('/etc/ansible/ansible.cfg')
    assert ftype == 'ini'
    ftype = get_config_type('./config/ansible.yml')
    assert ftype == 'yaml'
    ftype = get_config_type('./ansible.yml')
    assert ftype == 'yaml'
    ftype = get_config_type('/etc/ansible/ansible.yml')
    assert ftype == 'yaml'

# Generated at 2022-06-10 22:57:22.372122
# Unit test for function ensure_type
def test_ensure_type():
    class Dummy:
        def __init__(self, value):
            self.value = value
    assert ensure_type(Dummy(1), 'int') == 1
    assert ensure_type(Dummy(1), 'float') == 1.0
    assert ensure_type(Dummy('1'), 'float') == 1.0
    assert ensure_type(Dummy('1'), 'int') == 1
    assert ensure_type(Dummy('1'), 'bool') is True
    assert ensure_type(Dummy('1'), 'bool', strict=False) is True
    assert ensure_type(Dummy('1'), 'boolean', strict=False) is True
    assert ensure_type(Dummy('0'), 'bool', strict=False) is False
    assert ensure_type(Dummy('1'), 'boolean', strict=True) is True


# Generated at 2022-06-10 22:57:26.571534
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    global config_manager

    print_header("Starting test_ConfigManager_get_config_value_and_origin")

    # Set some configs

# Generated at 2022-06-10 22:57:30.625755
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Setup
    path_from_test_env = os.getenv('ANSIBLE_TEST_CONFIG')
    if path_from_test_env is not None:
        del os.environ['ANSIBLE_TEST_CONFIG']
    old_PWD = os.getcwd()
    old_HOME = os.getenv('HOME')

    # Create some temp directories for testing purposes
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)
    homedir = tempfile.mkdtemp()
    os.environ['HOME'] = homedir

    # Create the config files we need
    test_env_cfg = to_bytes(os.path.join(tmpdir, "test_env.cfg"))
    with open(test_env_cfg, "wb") as f:
        f

# Generated at 2022-06-10 22:57:42.384745
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    with tempfile.TemporaryDirectory() as tempdir:
        tempdir = os.path.join(tempdir, "temp_ansible_config")
        temp_ansible_config = tempdir + "/ansible.cfg"
        # No env var, cwd config
        os.mkdir(tempdir)
        with open(temp_ansible_config, 'w'):
            pass

        assert(get_ini_config_value(temp_ansible_config) == temp_ansible_config)

        # With env var, cwd config
        with tempfile.NamedTemporaryFile() as env_config:
            os.putenv("ANSIBLE_CONFIG", env_config.name)

            assert(find_ini_config_file() == env_config.name)

        # No env var, no cwd config

# Generated at 2022-06-10 22:57:46.302579
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    cm = ConfigManager()
    defs = {"foo": "bar"}
    plugin_type = "bar"
    name = "bar"
    cm.initialize_plugin_configuration_definitions(plugin_type, name, defs)


# Generated at 2022-06-10 22:57:53.446899
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    review_status = {'review_status': ['Not Reviewed', 'Reviewed'], 'type': 'list'}
    defs = {'review_status': review_status}
    config = ConfigManager(defs)
    review_status_value = config.get_config_value_and_origin('review_status', plugins=None)
    assert review_status_value[0] == ['Not Reviewed', 'Reviewed'] and review_status_value[1] == 'default'

# Generated at 2022-06-10 22:58:05.784826
# Unit test for function resolve_path
def test_resolve_path():
    '''
    Unit test for function resolve_path
    '''
    def _test_dir(dirname):
        '''returns absolute path if dirname is relative'''
        return os.path.abspath(dirname) if not os.path.isabs(dirname) else dirname

    assert resolve_path('/x/y/z') == '/x/y/z'
    assert resolve_path('./x/y/z') == 'x/y/z'
    assert resolve_path('x/y/z') == _test_dir('x/y/z')
    assert resolve_path('/x/y/../z') == '/x/z'
    assert resolve_path('/x/y/z', basedir='/x/test') == '/x/y/z'

# Generated at 2022-06-10 22:58:10.175825
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    manager = ConfigManager()
    manager.get_config_value_and_origin('my_config', configfile='my_configfile', plugin_type='my_plugin_type', plugin_name='my_plugin_name', keys={}, variables={}, direct={})
    expected = (None, None)
    assert manager.get_config_value_and_origin('my_config', configfile='my_configfile', plugin_type='my_plugin_type', plugin_name='my_plugin_name', keys={}, variables={}, direct={}) == expected