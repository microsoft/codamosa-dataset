

# Generated at 2022-06-10 22:55:40.954878
# Unit test for function get_config_type
def test_get_config_type():
    tmp_path = tempfile.mkdtemp()


# Generated at 2022-06-10 22:55:48.235873
# Unit test for method get_config_value of class ConfigManager
def test_ConfigManager_get_config_value():
    from ansible.config.manager import ConfigManager
    from ansible.parsing.plugin_docs import read_docstring

    # unit test for get_config_value()

    # Create one ConfigManager with one 'config' dictionary
    cm = ConfigManager(
        config_defs={'config': {'foo': {'default': 'bar', 'type': 'string'}}},
        config_file=[],
    )

    # get_config_value() should return 'bar'
    result = cm.get_config_value('foo')
    assert result == 'bar'


# Unit test f.get_config_value() with a text file, without config file in argument

# Generated at 2022-06-10 22:55:57.470219
# Unit test for method get_config_value_and_origin of class ConfigManager

# Generated at 2022-06-10 22:56:04.417727
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    option_parser = OptionParser()
    config_manager = ConfigManager(option_parser, args=['-vvvv'])
    os.environ['ANSIBLE_VERBOSITY'] = '1'
    assert config_manager.get_config_value_and_origin('verbosity') == (1, 'env: ANSIBLE_VERBOSITY')
    config_manager = ConfigManager(option_parser, args=['-vvvv'])
    assert config_manager.get_config_value_and_origin('verbosity') == (4, 'cli: verbose')
    config_manager = ConfigManager(option_parser, args=[])
    assert config_manager.get_config_value_and_origin('verbosity') == (0, 'default')
    config_manager = ConfigManager(option_parser, args=['-vvvv'])

# Generated at 2022-06-10 22:56:08.934014
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    c = ConfigManager()
    c.configfile = 'ansible.cfg'
    c._parsers['ansible.cfg'] = ConfigParser.ConfigParser()
    c.get_configuration_definitions(ignore_private=True)
    if not 1:
        assert False, 'Expected raised error not found for get_configuration_definitions'

# Generated at 2022-06-10 22:56:17.404792
# Unit test for function get_config_type
def test_get_config_type():
    try:
        get_config_type(cfile="test_cfile.ini")
        assert False
    except AnsibleOptionsError:
        pass


# python2 configparser can't handle unicode on py2 by default
if py3compat.PY2:
    class CFParser(configparser.ConfigParser):
        def write(self, fp):
            """Write an .ini-format representation of the configuration state."""
            if self._defaults:
                fp.write("[%s]\n" % configparser.DEFAULTSECT)
                for (key, value) in self._defaults.items():
                    fp.write("%s = %s\n" % (key, str(value).replace('\n', '\n\t')))
                fp.write("\n")

# Generated at 2022-06-10 22:56:25.830406
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    cm = ConfigManager()
    cm._base_defs['ANSIBLE_HOST_KEY_CHECKING'] = {
        'name': 'ANSIBLE_HOST_KEY_CHECKING',
        'default': True,
        'env': [
            {'name': 'ANSIBLE_HOST_KEY_CHECKING'},
            {'name': 'ANSIBLE_HOST_KEY_CHECKING'}
        ],
        'ini': [
            {'key': 'host_key_checking', 'section': 'defaults'},
            {'key': 'host_key_checking', 'section': 'defaults'}
        ],
        'yaml': [
            'host_key_checking',
            'host_key_checking'
        ],
        'type': 'bool'
    }
    cm.update_config_data()

# Generated at 2022-06-10 22:56:35.566301
# Unit test for function get_config_type
def test_get_config_type():
    from ansible.module_utils.common._collections_compat import Mapping
    def _test_good_files(files):
        for f in files:
            assert get_config_type(f) == 'ini'
    def _test_bad_files(files):
        for f in files:
            try:
                assert get_config_type(f) == 'yaml'
            except AnsibleOptionsError as e:
                assert "is unsupported" in str(e)
    good_files = ['/path/to/good_file.cfg', '/path/to/good_file.ini',
                  '/path/to/good_file', 'good_file.cfg', 'good_file.ini',
                  'good_file']

# Generated at 2022-06-10 22:56:37.847054
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    CONF = ConfigManager()
    c = CONF.get_configuration_definitions()
    assert c == {}


# Generated at 2022-06-10 22:56:45.470249
# Unit test for function get_config_type
def test_get_config_type():
    if os.path.exists('/usr/bin/python'):
        os.environ['ANSIBLE_CONFIG_FILE_PATH'] = '/usr/bin/python'
    else:
        os.environ['ANSIBLE_CONFIG_FILE_PATH'] = '/bin/python'
    assert 'python' == get_config_type(os.environ.get('ANSIBLE_CONFIG_FILE_PATH'))

# FIXME: see if this can be moved to utils/module_docs_fragments

# Generated at 2022-06-10 22:59:57.301468
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()

    defs = config.get_configuration_definitions()
    assert defs, 'Expected non-empty dictionary for result.'

    definitions = {
        'DEFAULT_MODULE_NAME': {
            'default': 'command', 'aliases': ['executable', 'action']
        },
        'CONFIG_FILE': {
            'default': os.path.join(os.path.expanduser('~'), '.ansible.cfg'),
            'aliases': [],
        }
    }

    for definition in definitions:
        assert definitions[definition] == defs[definition], 'Definition %s mismatch: expected: %s, actual: %s' % (definition, definitions[definition], defs[definition])


# Generated at 2022-06-10 23:00:02.288773
# Unit test for function resolve_path
def test_resolve_path():
    # Test resolving relative path
    assert resolve_path('./somefile') == os.path.abspath("./somefile")

    # Test resolving path containing environment variable
    assert resolve_path('$HOME/somefile') == os.environ.get('HOME') + '/somefile'

    # Test resolving path containing '{{CWD}}'
    assert resolve_path('{{CWD}}/somefile') == os.getcwd() + '/somefile'

    # Test resolving path containing environment variable and '{{CWD}}'
    assert resolve_path('{{CWD}}/$HOME/somefile') == os.getcwd() + '/' + os.environ.get('HOME') + '/somefile';


# FIXME: see if this can live in utils/path

# Generated at 2022-06-10 23:00:11.742775
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    test = AnsibleModule(
        argument_spec = dict()
    )

    cm = ConfigManager(defs=testconfigdef.config)

    # set up some test data
    env = py3compat.environ.copy()
    env.update(testconfigenv.testcase)
    # testcase keys need to be stringified
    variables = {k:v for k, v in testconfigvar.testcase.iteritems()}
    # testcase keys need to be stringified
    keys = {k:v for k, v in testconfigkey.testcase.iteritems()}


# Generated at 2022-06-10 23:00:15.750914
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    configmgr = ConfigManager()
    configmgr.provides = None
    configmgr._plugins = None
    configmgr._base_defs = None
    configmgr.get_configuration_definitions(plugin_type=None, name=None, ignore_private=False)
    assert True


# Generated at 2022-06-10 23:00:18.212609
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    configmanager = ConfigManager()
    # test with required values 
    configmanager.get_configuration_definitions()


# Generated at 2022-06-10 23:00:20.163675
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    os.chdir("../")
    path = find_ini_config_file()
    assert to_text(path, errors='surrogate_or_strict') == to_text("../ansible.cfg", errors='surrogate_or_strict')
    os.chdir("test/units/cli")


# Generated at 2022-06-10 23:00:25.701065
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    # Ensure that no value is returned if ANSIBLE_CONFIG is set but points to an invalid file
    os.environ["ANSIBLE_CONFIG"] = "/this/file/does/not/exist"
    assert find_ini_config_file() is None
    del os.environ["ANSIBLE_CONFIG"]
    # Ensure that no value is returned if ANSIBLE_CONFIG is set but points to a directory
    os.environ["ANSIBLE_CONFIG"] = os.path.dirname(os.path.realpath(__file__))
    assert find_ini_config_file() is None
    del os.environ["ANSIBLE_CONFIG"]
    # Ensure that ANSIBLE_CONFIG is respected if set to a valid file

# Generated at 2022-06-10 23:00:27.317995
# Unit test for function get_config_type
def test_get_config_type():
    ftype = None
    cfile = "./ansible.cfg"
    getconfigtype = get_config_type(cfile)
    ftype = 'ini'
    assert getconfigtype == ftype
#

# Generated at 2022-06-10 23:00:35.794010
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    config = ConfigManager()

# Generated at 2022-06-10 23:00:36.723210
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    pass

