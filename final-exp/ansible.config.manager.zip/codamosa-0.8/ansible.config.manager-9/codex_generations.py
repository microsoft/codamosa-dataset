

# Generated at 2022-06-10 22:55:59.702547
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/etc/passwd') == '/etc/passwd'
    assert resolve_path('/etc/{{CWD}}', '/etc/passwd') == '/etc/'
    assert resolve_path('{{CWD}}/foo', '/etc/passwd') == '/etc/foo'
    assert resolve_path('{{CWD}}/foo') in ['/foo', '//foo']
    assert resolve_path('{{CWD}}/foo') == resolve_path('{{CWD}}/foo/')
    assert resolve_path('{{CWD}}/foo') == resolve_path('{{CWD}}/foo')
    assert resolve_path('{{CWD}}/foo') in ['/foo', '//foo']
    if os.name == 'posix':
        assert resolve_path('{{CWD}}') == '/'

# Generated at 2022-06-10 22:56:06.551806
# Unit test for function get_ini_config_value
def test_get_ini_config_value():
    ''' perform unit tests for function get_ini_config_value '''

# Generated at 2022-06-10 22:56:14.906519
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager

# Generated at 2022-06-10 22:56:23.646403
# Unit test for function ensure_type

# Generated at 2022-06-10 22:56:32.647779
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    cm = ConfigManager()
    cm.initialize_plugin_configuration_definitions('vars', None, {'ANSIBLE_DEBUG': {'type': 'bool', 'aliases': ['ANSIBLE_VERBOSITY'], 'cli': [{'name': 'verbose'}, {'name': 'vvvv'}, {'name': 'vvvvv'}], 'env': [{'name': 'ANSIBLE_DEBUG'}, {'name': 'ANSIBLE_VERBOSITY'}], 'ini': [{'section': 'defaults', 'key': 'debug'}], 'default': 'False', 'parse_for_tokens': ['ANSIBLE_DEBUG', 'ANSIBLE_VERBOSITY']}})

# Generated at 2022-06-10 22:56:44.788153
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    configmanager = ConfigManager()

# Generated at 2022-06-10 22:56:51.354803
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # TODO: implement better test that doesn't rely on external config file
    import os
    # set env var
    os.environ['ANSIBLE_INVENTORY'] = 'test'
    cm = ConfigManager()
    # test env var with non-default ini override
    value, origin = cm.get_config_value_and_origin('inventory', cfile=os.path.expanduser('~/.ansible.cfg'))
    assert value == '/tmp/ansible_test'
    assert origin == 'ini: inventory = /tmp/ansible_test'

# Generated at 2022-06-10 22:56:57.985561
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(u'123', 'integer', origin='/tmp/test') == 123
    assert ensure_type('123', 'boolean', origin='/tmp/test') is True
    assert ensure_type('123', 'bool', origin='/tmp/test') is True
    assert ensure_type('123', 'float', origin='/tmp/test') == 123.0
    assert ensure_type('/tmp/123,/tmp/234/', 'list', origin='/tmp/test') == [u'/tmp/123', u'/tmp/234/']
    assert ensure_type('/tmp/123,/tmp/234/', 'pathspec', origin='/tmp/test') == [u'/tmp/123', u'/tmp/234']

# Generated at 2022-06-10 22:57:07.423699
# Unit test for method initialize_plugin_configuration_definitions of class ConfigManager
def test_ConfigManager_initialize_plugin_configuration_definitions():
    module = AnsibleModule(
        argument_spec = dict()
    )
    config_manager = ConfigManager(module)
    # Set config_manager._base_defs
    config_manager._base_defs = dict()
    # initialize config_manager._plugins
    config_manager._plugins = dict()

    # Test when defs is None
    defs = None
    plugin_type = None
    name = None
    try:
        config_manager.initialize_plugin_configuration_definitions(plugin_type, name, defs)
    except AnsibleOptionsError as e:
        module.fail_json(msg="Test failed: %s" % to_native(e))
    except Exception as e:
        module.fail_json(msg="Test failed: %s" % to_native(e))

    # Test when def

# Generated at 2022-06-10 22:57:12.632854
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    PYTEST_SKIP_TEST = True
    if PYTEST_SKIP_TEST:
        pytest.skip("No reason")
    # Set up test objects
    cm = ConfigManager()
    defs = CONFIGURATION_DEFS
    config = 'display_skipped_hosts'
    cfile = "/home/charlie/Projects/ansible-base/lib/ansible/config/base.yml"
    plugin_type = None
    plugin_name = None
    keys = None
    variables = None
    direct = None
    cm.load()
    # Execute the code to be tested
    retval = cm.get_config_value_and_origin(config, cfile, plugin_type, plugin_name, keys, variables, direct)
    # Verify the results