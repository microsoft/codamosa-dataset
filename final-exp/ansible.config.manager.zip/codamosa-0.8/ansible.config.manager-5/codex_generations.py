

# Generated at 2022-06-10 22:55:38.058653
# Unit test for method update_config_data of class ConfigManager
def test_ConfigManager_update_config_data():
    module = AnsibleModule(
         argument_spec=dict(),
     )
    cm = ConfigManager()
    config_file = cm.config_file
    assert(config_file is not None)
    def_data = {'name':'configFile','default':config_file,'type':'string','env':[{'name':'ANSIBLE_CONFIG'}],'ini':[{'section':'defaults', 'key':'config_file'}],'yaml':[{'key':'config_file'}]}
    cm.update_config_data(defs = def_data, configfile = config_file)
    
# Test the following methods of class ConfigManager
# def load_config_file(self, file_name=None, loader=None, vault_password=None):
test_ConfigManager_load_config_

# Generated at 2022-06-10 22:55:42.766950
# Unit test for method get_configuration_definitions of class ConfigManager
def test_ConfigManager_get_configuration_definitions():
    defs = ConfigManager().get_configuration_definitions()
    assert isinstance(defs, dict)

    defs = ConfigManager().get_configuration_definitions('foobar')
    assert isinstance(defs, dict)

    defs = ConfigManager().get_configuration_definitions(None, 'foobar')
    assert isinstance(defs, dict)



# Generated at 2022-06-10 22:55:50.326945
# Unit test for function find_ini_config_file
def test_find_ini_config_file():
    file_name = 'ansible.cfg'
    # Current working directory
    cwd = os.getcwd()
    cwd_file = os.path.join(cwd, file_name)
    cwd_stat = os.stat(cwd)
    # Per user location
    user_file = unfrackpath("~/.ansible.cfg", follow=False)
    # System location
    sys_file = "/etc/ansible/ansible.cfg"

    print(cwd)
    # Test environment setting
    if sys_file in os.environ.values():
        del os.environ['ANSIBLE_CONFIG']

    os.environ['ANSIBLE_CONFIG'] = sys_file
    env_path = find_ini_config_file()
    assert env_path == sys_file

    # Test current working

# Generated at 2022-06-10 22:55:56.378044
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Set up mocks
    configmanager = ConfigManager()

    with patch.multiple(
        'ansible.config.manager.ConfigManager',
        get_configuration_definitions=DEFAULT,
        get_config_value=DEFAULT,
    ):
        # Test using default args
        configmanager.get_config_value_and_origin()

        # Test using specific args
        # TODO: add test for plugin_type, plugin_name, keys, variables, direct

# Generated at 2022-06-10 22:56:03.830823
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type(False, 'bool') is False
    assert ensure_type(True, 'bool') is True
    assert ensure_type('false', 'bool') is True
    assert ensure_type('true', 'bool') is True
    assert ensure_type('True', 'bool') is True
    assert ensure_type('False', 'bool') is False
    assert ensure_type('random string', 'bool') is True

    assert ensure_type(1, 'int') == 1
    assert ensure_type('1', 'int') == 1
    assert ensure_type('1.0', 'int') == 1
    assert ensure_type('random string', 'int') == 1

    assert ensure_type(1.0, 'float') == 1.0
    assert ensure_type(1, 'float') == 1.0

# Generated at 2022-06-10 22:56:07.706741
# Unit test for function resolve_path
def test_resolve_path():
    tmpdir = tempfile.mkdtemp()
    try:
        assert os.path.isabs(resolve_path(tmpdir))
        assert resolve_path('{{CWD}}') == os.getcwd()
    finally:
        os.rmdir(tmpdir)


# FIXME: see if this can live in utils/path

# Generated at 2022-06-10 22:56:12.770661
# Unit test for function resolve_path
def test_resolve_path():
    assert resolve_path('/tmp/') == '/tmp'
    assert resolve_path('./path/bar.txt') == os.path.normpath(os.path.join(os.getcwd(), './path/bar.txt'))
    assert resolve_path('foo.txt') == os.path.normpath(os.path.join(os.getcwd(), 'foo.txt'))


# FIXME: see if this can live in utils/path

# Generated at 2022-06-10 22:56:21.527198
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    """
    Test case to check the functionalities of ConfigManager.get_config_value_and_origin()
    :return:
    """
    from ansible.utils import structure_loader
    import ansible
    from ansible import context
    # TODO: Better way to get the root directory of the source code
    yaml_file_path = os.path.join(os.path.dirname(ansible.__file__), "config/base.yml")

    # check for config file path
    cm = ConfigManager(os.path.join(os.path.dirname(__file__), 'test_config.yml'), os.path.join(os.path.dirname(__file__), 'ansible.cfg'))

    with open(yaml_file_path) as yaml_file:
        data = structure_loader

# Generated at 2022-06-10 22:56:30.424414
# Unit test for function ensure_type
def test_ensure_type():
    assert ensure_type('1', 'bool', '127.0.0.1') == True
    assert ensure_type('1', 'string', '127.0.0.1') == '1'
    assert ensure_type('1', 'int', '127.0.0.1') == 1
    assert ensure_type('1', 'float', '127.0.0.1') == 1.0
    assert ensure_type('1,2', 'list', '127.0.0.1') == ['1', '2']
    assert ensure_type(None, 'none', '127.0.0.1') == None
    assert ensure_type('[1,2]', 'list', '127.0.0.1') == [1, 2]

# Generated at 2022-06-10 22:56:40.841661
# Unit test for method get_config_value_and_origin of class ConfigManager
def test_ConfigManager_get_config_value_and_origin():
    # Initialize class instance
    conf = ConfigManager()

    # Test validating types

    config = 'config1'
    cfile = None
    plugin_type = None
    plugin_name = None
    keys = None
    variables = None
    direct = None
    # expected_type = None
    # expected_origin = None
    expected_value, expected_origin = conf.get_config_value_and_origin(config, cfile, plugin_type, plugin_name, keys, variables, direct)

    config = 'config2'
    cfile = None
    plugin_type = None
    plugin_name = None
    keys = None
    variables = None
    direct = None
    # expected_type = None
    # expected_origin = None
    expected_value, expected_origin = conf.get_config_value_and_