

# Generated at 2022-06-21 01:56:04.712640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(ansible_play_context, "ansible.legacy.copy", {})
    arg = {}
    assert None != module.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 01:56:17.595087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test default constructor of ActionModule.
    '''

    # Test with empty task and connection
    task = Task()
    connection = Connection()
    result = ActionModule(task, connection, C.DEFAULT_ANSIBLE_PLUGIN_CONSTANTS, loader=None, templar=None, shared_loader_obj=None)
    assert result._task == task
    assert result._connection == connection

    # Test with Task object that is empty
    task = Task()
    connection = Connection()
    result = ActionModule(task, connection, C.DEFAULT_ANSIBLE_PLUGIN_CONSTANTS, loader=None, templar=None, shared_loader_obj=None)
    assert result._task == task
    assert result._connection == connection


# Generated at 2022-06-21 01:56:26.861835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.__init__ import Ansible
    from ansible.inventory.manager import InventoryManager

    # set up basics
    print('Creating Ansible environment')
    ansible = Ansible()
    print('Creating PlaybookExecutor')
    playbook_executor = PlaybookExecutor()
    print('Setting up inventory')
    playbook_executor._inventory = InventoryManager(loader=ansible._loader, sources=GOOD_INVENTORY_SOURCE)

# Generated at 2022-06-21 01:56:36.023778
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create a task with no remote_user so that we can test the constructor of ActionModule.
    task = Task()

    # Create play object.
    play = Play()

    # Create connection info.
    connection_info = ConnectionInfo('ssh', 'remotehost', '22')

    # Create new ActionModule object.
    action_module = ActionModule(task, play, connection_info, 'path')

    # Check __init__ method of ActionModule class.
    assert hasattr(action_module, "_task")
    assert hasattr(action_module, "_play")
    assert hasattr(action_module, "_connection_info")
    assert hasattr(action_module, "_connection")

    assert hasattr(action_module, "ROOT_PATH")
    assert hasattr(action_module, "NO_TARGET_SYSLOG")
   

# Generated at 2022-06-21 01:56:46.682922
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create the class used for testing
    action_module = ActionModule(task=task, connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=None)

    # Set the source, content, and destination arguments
    action_module._task.args['src'] = 'test_src'
    action_module._task.args['content'] = 'test_content'
    action_module._task.args['dest'] = 'test_dest'
    # Set the expected result
    expected = dict(
        failed = True,
        msg = 'src and content are mutually exclusive'
    )

    # Run the run function
    result = action_module.run(tmp=None, task_vars=None)

    # Verify the result
    assert result == expected

    # Set the source

# Generated at 2022-06-21 01:56:52.545996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Verify the class is instantialized correctly; it will raise an exception if not.
    action_module = ActionModule(load_reader=True, templar=mock.MagicMock(),
                                 connection=mock.MagicMock(), play_context=mock.MagicMock(),
                                 loader=mock.MagicMock(), shared_loader_obj=mock.MagicMock(),
                                 almost_done_callback=mock.MagicMock(),
                                 exit_without_unsafe_args=False,
                                 task_uuid=mock.MagicMock(), task_vars=mock.MagicMock(), tmp=mock.MagicMock(),
                                 task_path=mock.MagicMock())

    assert action_module is not None


# Generated at 2022-06-21 01:56:54.985163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None


# Generated at 2022-06-21 01:56:58.484587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action

    # Instantiate an ActionModule object
    am = ansible.plugins.action.ActionModule(
        task = dict(),
        connection = dict(),
        play_context = play_context,
        loader = dict(),
        tempfile = dict(),
        shared_loader_obj = dict()
    )

    # Make sure object was initialized correctly
    assert isinstance(am, ansible.plugins.action.ActionModule)


# Generated at 2022-06-21 01:57:05.787102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(
        src='/tmp/foo',
        dest='/tmp/bar',
        mode='preserve',
        follow='yes',
        checksum='sha1',
        validate='no',
        remote_src='no',
        unsafe_writes='no',
    )
    task = Task('test_copy', {}, args)
    host = Host(name='testhost')
    host.vars = dict()
    host.vars['ansible_connection'] = 'test'
    play_context = PlayContext()

    connection = Connection(play_context, host)
    am = ActionModule(task, connection, play_context, loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 01:57:08.311868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner = Runner()
    action_module = ActionModule({}, runner)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 01:57:56.116806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure we can use the ActionModule constructor
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 01:58:00.749568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    run(self, tmp, task_vars)
    """
    pass

# conditional import
try:
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.netcommon.utils import (
        _module_params, ArgumentSpec
    )
except ImportError:
    pass


# Generated at 2022-06-21 01:58:13.213849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'testhost'
    task = dict(action=dict(module='copy', args=dict(src='source', dest='dest')))
    connection = DummyConnection()
    task_vars = dict(inventory_hostname='testhost', ansible_host='testhost')
    play_context = PlayContext(remote_addr='testhost', remote_user='testuser',
                               password='testpass')
    new_stdin = FakeModuleStdin()

    def load_task_vars(self, task_vars):
        return {}

    def save_task_vars(self, task_vars):
        return {}

    new_module = ActionModule(task, connection, play_context, new_stdin)

    new_module._execute_module = load_task_vars

# Generated at 2022-06-21 01:58:21.049725
# Unit test for constructor of class ActionModule
def test_ActionModule():

    shell = Shell(prompt=re.compile(re.escape('$')), newline='\n', runner=None)
    task = Task()
    task.args = {'src': 'src'}

    action_module = ActionModule(task, connection=shell, runner=None)

    assert action_module._task.args['src'] == 'src'


# Generated at 2022-06-21 01:58:33.237538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Test if class variable '_uses_shell' of AnsibleModule is False
        assert ActionModule._uses_shell is False
        # Test if class variable '_no_log' of AnsibleModule is False
        assert ActionModule._no_log is False
        # Test if class variable '_supports_check_mode' of AnsibleModule is False
        assert ActionModule._supports_check_mode is False
        # Test if class variable '_supports_generate_diff' of AnsibleModule is False
        assert ActionModule._supports_generate_diff is False
        # Test if class variable '_supports_async' of AnsibleModule is False
        assert ActionModule._supports_async is False
    except AssertionError:
        print("Failed assertion in test_ActionModule")


# Generated at 2022-06-21 01:58:34.186643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:58:37.394167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task_vars={})
    assert module is not None



# Generated at 2022-06-21 01:58:47.146795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = MagicMock()
    _task.args.get.return_value = None
    _connection = MagicMock()
    _connection._shell.side_effect = lambda cmd, *args, **kwargs: (0, cmd, '')
    _connection.module_implementation_preferences = ['action']
    _loader = MagicMock()
    _play_context = MagicMock()
    run = ActionModule(
        _task,
        _connection,
        _loader,
        _play_context
    )

# Generated at 2022-06-21 01:58:48.674479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # TODO
  pass

# Generated at 2022-06-21 01:58:52.593075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(
        src=os.path.join('test','data','testmodule.txt'),
        dest=os.path.join('test','data','testmodule_bak.txt'),
        content='hello world',
    )
    am = ActionModule(None, module_args)
    assert am.module_name == 'copy'
    assert am.module_args == module_args

# Generated at 2022-06-21 01:59:56.069205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock ansible.module_utils.connection.Connection
    class MockConnection(object):
        def __init__(self, module=None, shell=None):
            if shell:
                self._shell = shell
            else:
                self._shell = MockShell()
    # Mock ansible.module_utils.connection.Shell
    class MockShell(object):
        def __init__(self, tmpdir=None):
            self.tmpdir = tmpdir

        def expand_user(self, path):
            return path

        def path_has_trailing_slash(self, path):
            return path

        def fixup_perms2(self, path, mode):
            return path, mode

        def join_path(self, path, *paths):
            return os.path.join(path, *paths)


# Generated at 2022-06-21 02:00:02.886070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Basic unit test to make sure the argument constructor is working
    '''
    from ansible.plugins.action.copy import ActionModule

    task = {'action': {'__ansible_module__': 'fake'}}
    am = ActionModule(None, task, loader=None, connection=None)

    assert (am is not None)
    assert isinstance(am, object)


# Generated at 2022-06-21 02:00:14.705534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup arguments that would be used when constructing class.
    args = {}
    args['connection'] = "connection"
    args['task'] = "task"
    args['loader'] = "loader"
    args['templar'] = "templar"
    args['shared_loader_obj'] = "shared_loader_obj"

    # Create the class with specifed args.
    action_module = ActionModule(**args)

    # Check member variables of class after creation.
    assert action_module._connection == "connection"
    assert action_module._task == "task"
    assert action_module._loader == "loader"
    assert action_module._templar == "templar"


# Generated at 2022-06-21 02:00:26.608585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    mock_task = MagicMock(name="task")
    mock_task.args = dict()
    mock_task.args["src"] = None
    mock_task.args["content"] = None
    mock_task.args["dest"] = None
    mock_task.args["remote_src"] = False
    mock_task.args["local_follow"] = True
    mock_action_module = MagicMock(name="action_module")
    mock_action_module.run.return_value = dict(failed="mocked_failed")
    result = ActionModule(mock_task, mock_action_module).run(tmp, task_vars)
    assert result == dict(failed="mocked_failed")


# Generated at 2022-06-21 02:00:31.848831
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(task=dict(action=dict(module_name='copy', module_args=dict())))
    assert module.action._module_name == 'copy'
    assert module.action.module_name == 'copy'

    module = ActionModule(task=dict(action=dict(module_name='foo.bar.baz', module_args=dict())))
    assert module.action._module_name == 'foo.bar.baz'
    assert module.action.module_name == 'baz'


# Generated at 2022-06-21 02:00:40.207677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Given a task with valid args
    task = Task()
    task.args = {
        'content': None,
        'dest': '/tmp/a.txt',
        'force': False,
        'group': 'root',
        'mode': None,
        'others': '',
        'owner': 'root',
        'regexp': None,
        'remote_src': False,
        'selevel': None,
        'serole': None,
        'setype': None,
        'seuser': None,
        'src': '/tmp/b.txt',
        'unsafe_writes': True,
        'validate': None
    }

    # when we construct an ActionModule
    action = ActionModule(task, {})

    # No exception is raised
    action.run()

# Unit test

# Generated at 2022-06-21 02:00:48.564129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = object()
    action_module = ActionModule(connection, '/fake/path', 10)

    assert action_module._connection == connection
    assert action_module._task_vars == {}
    assert action_module._tmpdir == '/fake/path'
    assert action_module._delete_remote_tmp == True
    assert action_module._non_persistent_connections == ('network_cli', 'local')
    assert action_module._persistent_file_transfer_method == 'copy'
    assert action_module._persistent_file_transfer_handlers == ('unarchive', 'fetch')
    assert action_module._task_uuid == 10
    assert action_module._loader == None


# Generated at 2022-06-21 02:00:49.537107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule.run()
    


# Generated at 2022-06-21 02:00:55.837144
# Unit test for constructor of class ActionModule
def test_ActionModule():

    c = ansible.plugins.connection.Connection('unix')
    args = dict(
        action=dict(module_name='copy', module_args=dict(src='/tmp/test1.txt', dest='/tmp/test2.txt', remote_src=True), _ansible_selinux_special_fs=False),
        connection='unix')
    s = 'module_name: copy, module_args: {"dest": "/tmp/test2.txt", "_ansible_selinux_special_fs": false, "src": "/tmp/test1.txt", "remote_src": true}'

# Generated at 2022-06-21 02:00:58.767257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing the ActionModule.run method")
    a = ActionModule()
    return True

# Generated at 2022-06-21 02:02:54.004718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True
    assert module._supports_async == True
    assert module._task.action == 'copy'
    assert isinstance(module._connection, Connection)
    assert isinstance(module._loader, DataLoader)
    assert isinstance(module._templar, Templar)
    assert isinstance(module._shared_loader_obj, AnsibleLoader)
    assert isinstance(module._task_vars, dict)
    assert isinstance(module._result, dict)


# Generated at 2022-06-21 02:03:00.256212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.DEFAULT_COPY_PATH is not None
    assert am.DEFAULT_COPY_PATH_FACTS is not None
    assert am.DEFAULT_COPY_PATH_FILES is not None


# Generated at 2022-06-21 02:03:08.072133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare first test
    source = 'fake_source'
    content = None
    dest = 'fake_dest'
    remote_src = False
    local_follow = True
    task_vars = {}
    
    module_name = 'ansible.legacy.file'
    module_args = {'path': dest, 'state': 'directory', 'recurse': False, 'mode': None}
    module_return = module_return = {'dest': dest, 'src': source, 'changed': True}
    # Run first test
    am = ActionModule(source, content, dest, remote_src, local_follow)
    result = am.run(None, task_vars)

    # Prepare second test
    source = 'fake_source'
    content = {}
    dest = 'fake_dest'

# Generated at 2022-06-21 02:03:17.356056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dirs = ['./files', 'files', '/files']
    for d in dirs:
        try:
            os.stat(d)
        except Exception:
            os.mkdir(d)

    files = ['files/a.txt', 'files/b.txt', 'files/c.txt', 'files/d.txt']
    for f in files:
        try:
            os.stat(f)
        except Exception:
            open(f, 'wb').write(b'hello world')

    module = ActionModule()
    module.args = {'src': 'files/', 'dest': 'files/files2'}
    result = module.run()
    print(result)

# Generated at 2022-06-21 02:03:18.828598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

__all__ = ['ActionModule']

# Generated at 2022-06-21 02:03:27.883956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = dict(
        ansible_host='host',
        ansible_port=2222,
        ansible_user='ansible',
        ansible_password='ansible',
    )
    connection = dict(
        connection_type='httpapi',
        remote_addr=host['ansible_host'],
        port=host['ansible_port'],
        remote_user=host['ansible_user'],
        private_key_file='/home/ansible/.ssh/id_rsa',
        private_key_file_passphrase='',
        password=host['ansible_password'],
    )

# Generated at 2022-06-21 02:03:36.588823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_bytes

    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector


# Generated at 2022-06-21 02:03:43.768360
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:03:54.850909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = './ansible/test/units/modules/utils/test_utils_module_runner/test_runner.py'
    dest = '/tmp/test_runner.py'
    module_loader = DictDataLoader({
        "ansible/test/units/modules/utils/test_utils_module_runner/test_runner.py": file_loader(source),
        })
    module_deps = AnsibleModuleDeps()
    connection = Connection(None)
    runner = TaskExecutor(connection,
        task_vars={"ansible_module_deps": module_deps},
        module_loader=module_loader)
    module_args = {'src': source, 'dest': dest, '_ansible_no_log': True}

# Generated at 2022-06-21 02:04:05.081893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(action=dict(args=dict(src=None, dest=None))))
    result = module.run()
    assert result['failed']
    assert result['msg'] == 'src (or content) is required'
    assert result['invocation']

    module = ActionModule(task=dict(action=dict(args=dict(src=None, dest=None, content='hello world'))))
    result = module.run()
    assert result['failed']
    assert result['msg'] == 'dest is required'
    assert result['invocation']

    module = ActionModule(task=dict(action=dict(args=dict(src=None, dest=None, content='hello world', src='/tmp/src'))))
    result = module.run()
    assert result['failed']