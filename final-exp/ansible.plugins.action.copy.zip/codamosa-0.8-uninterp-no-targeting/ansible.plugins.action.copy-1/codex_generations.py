

# Generated at 2022-06-21 01:56:04.427331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule), 'Creation of `ActionModule` class failed.'


# Generated at 2022-06-21 01:56:17.867735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    from ansible.module_utils.common.collections import ImmutableDict

    _task = ImmutableDict({u'src': u'file.txt', u'dest': u'file2.txt'})
    _connection = ImmutableDict({u'name': u'ansible'})
    _ansible_version = ImmutableDict({u'version': u'2.8.0'})
    _ansible_module_name = ImmutableDict({u'name': u'test.py'})
    _ansible_module_args = ImmutableDict({u'test': u'data'})
    _ansible_module_kwargs = ImmutableDict({u'test': u'data2'})
    _ansible_job_id = Imm

# Generated at 2022-06-21 01:56:27.046533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors
    import ansible.utils.unsafe_proxy as unsafe_proxy
    import ansible.utils.template as template

    #
    # R2V2
    #

    # Mock
    mock_tmp_path = '/private/tmp/ansible-tmp-1458563574.5-56664387225275'
    mock_task_vars = {
        'ansible_check_mode': True,
        'ansible_file_encoding': 'utf-8',
        'ansible_managed': '1',
        'ansible_module_name': 'copy',
        'ansible_version': '2.0.1.0',
        'ansible_user_id': 'root',
        'ansible_playbook_python': '/usr/bin/python'
    }

   

# Generated at 2022-06-21 01:56:36.098051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for missing id
    with pytest.raises(AnsibleError) as excinfo:
        cls = ActionModule()
        cls._load_name = 'copy'
    assert excinfo.value.message == 'invalid call to module constructor: missing id'

    # Test for missing name
    with pytest.raises(AnsibleError) as excinfo:
        cls = ActionModule(id='foo')
    assert excinfo.value.message == 'invalid call to module constructor: missing name'

    # Test for wrong argument type
    with pytest.raises(AnsibleError) as excinfo:
        cls = ActionModule(id='foo', name='bar', args='xyz')
    assert excinfo.value.message == 'invalid call to module constructor: args must be an iterable'

    # Test

# Generated at 2022-06-21 01:56:46.713548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task via the mock module
    task = mock.MagicMock()

    # Create a mock connection via the mock module
    connection = mock.MagicMock()

    # Create a mock loader via the mock module
    loader = mock.MagicMock()

    # Create a mock templar via the mock module
    templar = mock.MagicMock()

    # Create an instance of the ActionModule
    action_module = ActionModule(task, connection, loader, templar)

    # Create a mock result
    result = mock.MagicMock()

    # Assign value to the result instance's failed attribute.
    result.failed = True

    # Assign value to the result instance's msg attribute.
    result.msg = 'msg'

    # Create a mock invocations
    invocations = mock.MagicMock()

    #

# Generated at 2022-06-21 01:56:48.665676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(connection='connection_type')) is not None


# Generated at 2022-06-21 01:56:54.985147
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    obj = ActionModule()


    assert isinstance(result,dict) is True
    assert result.get('failed', False) is False
    assert result.get('changed', False) is False
    assert result.get('rc', 0) is 0
    assert result.get('dest', '') == '/tmp/foobar'
    assert result.get('start', 0) > 0
    assert result.get('delta', 0) > 0
    assert result.get('end', 0) > 0

# Generated at 2022-06-21 01:56:57.146555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    config.parse()
    fixture = ActionModule(None)
    fixture.run(None,None)

# Generated at 2022-06-21 01:56:58.055955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    assert(action.run == False)

# Generated at 2022-06-21 01:57:10.002144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' returns an action module for use in tests'''

    class MockTask(object):
        ''' minimalistic mock object for a task '''
        def __init__(self, args):
            self.args = args

    class MockPlayContext(object):
        ''' minimalistic mock object for a play context '''
        def __init__(self):
            self.become = False
            self.become_user = None
            self.connection = None
            self.remote_addr = '127.0.0.1'

    class MockLoader(object):
        ''' minimalistic mock object for a loader '''
        def __init__(self):
            pass

    class MockVariableManager(object):
        ''' minimalistic mock object for a variable manager '''
        def __init__(self):
            pass


# Generated at 2022-06-21 01:58:03.303231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.connection as connection

    # Create a fake config file to use
    configfile = StringIO()
    configfile.name = 'ansible.cfg'

    cfg = ConfigParser()
    cfg.add_section(u'privilege_escalation')
    cfg.set(u'privilege_escalation', u'su', u'/bin/su')
    cfg.set(u'privilege_escalation', u'sudo', u'/bin/sudo')

# Generated at 2022-06-21 01:58:10.856590
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert isinstance(am, ActionModule)
  # attr
  assert am._display.__name__ == 'Display'
  assert am._supports_check_mode.__name__ == 'supports_check_mode'
  assert am.shebang.__name__ == 'get_shebang'
  assert am.noop_on_check(None, None) == 'It works'


# Generated at 2022-06-21 01:58:24.566346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = mock.Mock()
    mock_task.args = {
        'one': '1',
        'two': '2',
        'three': '3',
        'four': '4',
        'five': '5'
    }

    am = ActionModule(mock_task, mock.Mock(), mock.Mock(), mock.Mock())

    # Test that the constructor correctly initializes the data members
    assert am._task == mock_task
    assert am._connection == mock.Mock()
    assert am._play_context == mock.Mock()
    assert am._shared_loader_obj == mock.Mock()

    # Test that _task.args is sanitied in _sanitize_args

# Generated at 2022-06-21 01:58:28.906791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Try to construct ActionModule with a bare minimum of requirements

    # Try to construct ActionModule with no actions
    _ = ActionModule(dict(),
                     connection='connection',
                     play_context=None,
                     loader=None,
                     templar=None,
                     shared_loader_obj=None)

# Generated at 2022-06-21 01:58:31.352683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None)
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None

# Generated at 2022-06-21 01:58:38.367511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare the parameters
    self = MagicMock()
    self._task = dict({'args': dict({'ax': [], 'b': 'c'})})
    self._execute_module = MagicMock()
    self._execute_module.return_value = dict({'changed': False})
    self._task.args.update({'ex': ['f'], 'g': 'h'})
    self._remove_tmp_path = MagicMock()
    self._remove_tmp_path.return_value = None
    self._remote_expand_user = MagicMock()
    self._remote_expand_user.return_value = None
    self._loader = MagicMock()

# Generated at 2022-06-21 01:58:43.196925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test setting the abstract class' do_reload_module_implementation to False
    module = ActionModule(None, None, None, False)

    # Test setting the abstract class' do_reload_module_implementation to True
    module = ActionModule(None, None, None, True)


# Generated at 2022-06-21 01:58:55.257757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._create_content_tempfile = Mock(return_value='foo')
    action_module._remove_tempfile_if_content_defined = Mock()
    action_module._find_needle = Mock(return_value='bar')
    action_module._remote_expand_user = Mock(return_value='baz')
    action_module._connection._shell.path_has_trailing_slash = Mock(return_value=True)
    action_module._remove_tmp_path = Mock()
    action_module._execute_module = Mock(return_value='boo')


# Generated at 2022-06-21 01:59:06.044704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import UserDict
    action_module_run = ActionModule.run

# Generated at 2022-06-21 01:59:16.819682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = ConfigParser()
    c.read(["test/ansible.cfg", os.path.expanduser("~/.ansible.cfg")])
    p = Playbook.load(c, "test/playbook.yml")
    t = p.get_task("actionmodule")
    a = t.module_vars.get("action")
    assert isinstance(a, ActionModule)

    # 'dest' is required
    r = a.run(task_vars=dict(ansible_become_password="password"))
    assert r.get("failed") is True
    assert r.get("msg") == "dest is required"

    # 'src' is required
    r = a.run(task_vars=dict(dest="/path/to/dest", ansible_become_password="password"))
    assert r

# Generated at 2022-06-21 02:00:51.426779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:00:57.714869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_request = Request()
    fake_request.method = 'GET'
    fake_request.path_info = '/test/test.py'
    task = Task()
    task.args = dict(
        content='test_file',
        dest='test_destination',
        src='test_source'
    )

    connection = Connection()
    ac = ActionModule(fake_request, task, connection)
    assert type(ac) == ActionModule
    assert ac._task.args == dict(
        content='test_file',
        dest='test_destination',
        src='test_source'
    )


# Generated at 2022-06-21 02:01:08.541453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for the constructor of ActionModule '''

    def create_connection():
        ''' Creates a connection stub '''

        connection = MagicMock()
        connection._shell = MagicMock()
        connection._shell.tmpdir = tempfile.mkdtemp()
        connection._shell.join_path = os.path.join
        connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
        connection._shell.split_path = shlex.split
        connection._shell.quote = lambda x: "'%s'" % x
        connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
        connection._shell.join_path = lambda *args: '/'.join(args)
        connection._shell.glob = glob.glob


# Generated at 2022-06-21 02:01:19.476650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # source is required
    with pytest.raises(AnsibleError) as excinfo:
        ActionModule().run(None, {"src": None, "dest": "foo"})
    assert "src (or content) is required" in to_text(excinfo.value)

    # dest is required
    with pytest.raises(AnsibleError) as excinfo:
        ActionModule().run(None, {"src": "foo", "dest": None})
    assert "dest is required" in to_text(excinfo.value)

    # content and src are mutually exclusive
    with pytest.raises(AnsibleError) as excinfo:
        ActionModule().run(None, {"src": "foo", "content": "test", "dest": "bar"})

# Generated at 2022-06-21 02:01:28.856676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostname = 'test-host'
    port = 1234
    task_uuid = 'test-task-uuid'
    action = 'test-action'
    task_vars = {'test': 'test-task-vars'}
    inject = {'test': 'test-inject'}
    loader = 'test-loader'
    tmpdir = '/tmp'

    assert isinstance(action, string_types)
    assert isinstance(task_uuid, string_types)
    assert isinstance(task_vars, dict)

    connection = Connection(host=hostname,
                            port=port)

# Generated at 2022-06-21 02:01:37.779438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook import Play

    from ansible.utils.vars import combine_vars

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'host_one',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='copy', args='src=/etc/hosts dest=/tmp/hosts'))
            ]
        )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    tqm = None

# Generated at 2022-06-21 02:01:43.722505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test without connection
    a = ActionModule(None, None, None, '/tmp/test/test.yml')
    assert a is not None

    # test with connection
    a = ActionModule(None, None, {'_connection':'test'}, '/tmp/test/test.yml')
    assert a is not None

# Generated at 2022-06-21 02:01:44.594536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:01:46.881570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None


# Generated at 2022-06-21 02:01:49.617651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:04:13.310128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = MockConnection()
    task = MockTask()
    host = MockHost()
    host.get_connection.return_value = connection

    action = ActionModule(task, host)

    assert action._task == task
    assert action._play_context == task._play_context
    assert action._loader == task._loader
    assert action._templar == task._templar
    assert action._connection == connection


# Generated at 2022-06-21 02:04:24.515327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    task = Task()
    task._role = None

    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = '192.0.2.1'
    connection = Connection('http://example.org/', play_context, new_stdin=None)
    loader = DataLoader()


# Generated at 2022-06-21 02:04:35.418205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup a mock object for the task_vars and a mock object for the action module.
    task_vars = {'ansible_check_mode': True}
    action_module = ActionModule()
    # Setup mock objects for the fake file and file content.
    fake_file = mock.MagicMock()
    fake_file.return_value = '/usr/local/fake_file'
    fake_content = mock.MagicMock()
    fake_content.return_value = 'fake_content'

    # Setup a dictionary containing the task arguments appropriate for the file module.
    task_args = {'dest': '/usr/local', 'content': 'fake_content'}
    # Setup mock object to return the appropriate task_args when called.
    action_module.args = mock.MagicMock()

# Generated at 2022-06-21 02:04:37.571678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.common_args == {}

# Generated at 2022-06-21 02:04:39.118215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Real tests needed...
    assert True

# Generated at 2022-06-21 02:04:43.868439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Setup values
    name = "module"
    task = MagicMock()
    ds = MagicMock()
    task_vars = {}

    # Construct the object
    am = ActionModule(name, task, ds, task_vars)

    # assert that constructor worked
    assert(am is not None)


# Generated at 2022-06-21 02:04:55.082788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_tmp_path_removed(mocker):
        connection = mocker.Mock()
        connection.connect = mocker.Mock()
        connection._shell = mocker.Mock()
        host = mocker.Mock()
        host.get_vars.return_value = {}
        task = mocker.Mock()
        task.args = {}
        task.action = mocker.Mock()
        task.action.args = {}
        task.action.deprecate = mocker.Mock()
        task.action.deprecate.return_value = None
        Loader = mocker.Mock()
        loader = mocker.Mock()
        loader.path_dwim = mocker.Mock()
        loader.path_dwim.return_value = None
        loader.is_

# Generated at 2022-06-21 02:04:56.867920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:05:08.002326
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_name = 'copy'
    task_vars = {'a': 1, 'b': 2}
    task_args = {'c': 3, 'd': 4}

# Generated at 2022-06-21 02:05:11.968710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = dict(dest='mydest', src='/my/src', content=None, remote_src=False, local_follow=True)
    task_vars = dict()
    tmp = None

    runner = Runner(
        module_name='copy',
        module_args=module_args,
        task_vars=task_vars,
        connection='local',
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    action = ActionModule(runner)
    result = action.run(tmp,task_vars)