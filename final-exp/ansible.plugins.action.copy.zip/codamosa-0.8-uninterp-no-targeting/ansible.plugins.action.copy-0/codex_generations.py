

# Generated at 2022-06-21 01:56:15.378529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    class MyTask(object):
        def __init__(self):
            self.args = dict()
            self.action = 'copy'
            self.name = 'mytask'

# Generated at 2022-06-21 01:56:23.849648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    if not HAS_LIBRARIAN:
        module.fail_json(msg="python module librarian_ansible is not installed")
    if not HAS_LIBRARIAN_FILTR:
        module.fail_json(msg="python module librarian_filtr is not installed")

    # Create an instance of the local action
    # For convenience we use the same args as the ansible module
    local_action = ActionModule(
        module._socket_path,
        task_vars=dict(),
        connection='local',
        play_context=PlayContext(),
        loader=module._loader,
        templar=module._templar,
        shared_loader_obj=module._shared_loader_obj)

    #

# Generated at 2022-06-21 01:56:34.550583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print('Testing class ActionModule in file %s' % __file__)
  # Create a mock object to work with
  mock_task = mock.MagicMock(name='task')
  mock_task.args.get.side_effect = lambda x, y: None if y is None else y
  mock_task.args = {'follow': False, 'dest': 'dest', 'content': None, 'original_basename': None, 'remote_src': False, 'src': 'src', 'directory_mode': None, 'checksum': False, 'local_follow': False, 'mode': None, 'original_checksum': None, 'recurse': True, 'original_path': None}
  mock_action = mock.MagicMock(name='action', task=mock_task)

# Generated at 2022-06-21 01:56:36.080840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = AnsibleActionModule()
    action_module.run()

# Generated at 2022-06-21 01:56:46.683252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    import ansible.constants as C

    # Test with arbitrary module_name
    module_name = "ansible.legacy.debug"
    p = PlayContext()
    am = ActionModule( {'module_name': module_name, '_ansible_verbosity': 5}, p, 0, "/path/to/ansible.cfg")

    assert type(am.module_name) is string_types and am.module_name == module_name
    assert type(am._ansible_verbosity) is int and am._ansible_verbosity == 5
    assert type(am._play_context) is PlayContext and am._play_context == p


# Generated at 2022-06-21 01:56:51.745097
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create an instance of ActionModule
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # create an instance of ActionModule
    # passing in the created module
    action_module = ActionModule(module)

    # run method
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 01:56:53.462564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 01:57:04.151580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = dict(
            ansible_facts=dict(
                ansible_module_name='copy',
                ansible_module_args=dict(
                    content='Hello Ansible',
                    dest='/home/ansible/test.txt',
                ),
                ansible_version='2.6.1',
                ansible_facts=dict(),
                module_name='copy'
            ),
            ansible_included_var_files=list(),
            changed=True,
            checksum='4be4a4bab82ce11e2a72c56d3518a9b9e884b8d1',
            diff=dict(
                before='',
                after='Hello Ansible'
            ),
            file='/home/ansible/test.txt'
    )
    assert results == copy.run()

# Generated at 2022-06-21 01:57:09.170762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection(ConnectionBase):
        pass

    class MockModule(object):
        pass

    unittest_helper(ActionModule, module_args={'foo': 'bar'}, check_invalid_arguments=False,
                    connection=MockConnection(MockModule()))

# Generated at 2022-06-21 01:57:11.224407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:57:55.103564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit: test class method ActionModule.run"""


# Generated at 2022-06-21 01:57:58.437273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(None, None, None, None)

    if not ac:
        raise AssertionError("ActionModule creation failed")

# Generated at 2022-06-21 01:58:01.736044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict()
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager._fact_cache = {}
    task_vars = {}
    module_args = {}
    tmp = '/tmp'
    result = dict()
    action_module = ActionModule(task, loader, variable_manager, tmp)
    assert action_module.run(tmp, task_vars) == result


# Generated at 2022-06-21 01:58:03.699630
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 01:58:05.780730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = copy()
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 01:58:10.573005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_obj = copy.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    output = my_obj.run(tmp=None, task_vars=None)
    pass

# Generated at 2022-06-21 01:58:15.280787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert module


# Generated at 2022-06-21 01:58:26.832893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for `ActionModule.run`"""
    source = 'test/fake/path/to/source'
    content = 'test/fake/content'
    dest = 'test/fake/path/to/dest'
    remote_src = False
    local_follow = True
    tmp = None
    task_vars = dict()

    action_module = ActionModule()
    action_module._task = Mock(spec=Task(), autospec=True)
    action_module._task.args.get.side_effect = (source, content, dest, remote_src, local_follow)
    action_module._task_vars_inject_path = None

    result = action_module.run(tmp, task_vars)


# Generated at 2022-06-21 01:58:36.151693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    vars = get_data()
    modules = get_data()
    loader = AnsibleLoader(modules, 'json', None)
    templar = Templar(loader=loader, variables=vars)
    args = get_data()
    args = templar.template(args)
    module = get_data()
    task = get_data()
    module = copy.deepcopy(module)
    module.update({'args': args})
    task.update({'args': args, 'action': module})
    task_vars = {}
    action_module = ActionModule(task, {}, loader=loader, templar=templar, shared_loader_obj=loader)
    result = action_module.run(None, task_vars)
    assert result == get_data()


# Generated at 2022-06-21 01:58:41.923129
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Set up
    action_module = ActionModule()
    task_args = dict()
    tmpdir = '/path/to/ansible/tmp'

    # Set the value of the global variable __file__
    import os
    try:
        del os.environ["__file__"]
    except KeyError:
        pass

    os.environ["__file__"] = "/path/to/ansible/ansible/plugins/action/copy.py"

    # Create the mocks
    # Mock the class AnsibleConnection

# Generated at 2022-06-21 02:00:09.352094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, task_vars={'hostvars': {}}, connection=None)
    assert isinstance(m, ActionModule)
    assert m.supports_check_mode is True


# Generated at 2022-06-21 02:00:17.621990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os, os.path
    import tempfile
    import shutil
    import json
    import copy
    import traceback
    import sys
    import platform
    import subprocess
    import time
    import imp
    import random
    import re
    import locale
    import json
    import types
    import pprint
    import collections
    import ansible.utils
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    
    from ansible.plugins.action.copy import ActionModule
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import string_types

# Generated at 2022-06-21 02:00:27.409855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = '/home/david'
    tmp = '/dev/shm/ccqf3xcE'
    source = '/dev/shm/ansible/tmp/ansible-tmp-1492988756.52-255789056341287/source'
    source_rel = 'source'
    dest = '/dev/shm/ansible/tmp/ansible-tmp-1492988756.52-255789056341287/dest'
    remote_src = False

# Generated at 2022-06-21 02:00:34.033478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None)
    module_loader = None
    task_uuid = None
    am._connection = Connection(module_loader=module_loader, task_uuid=task_uuid)
    am._task = Task()
    am._task.args = {}
    am._loader = DataLoader()
    return am


# Generated at 2022-06-21 02:00:43.608009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    task = DummyTask()
    connection = DummyConnection()
    task_vars = DummyTaskVarsModule().vars
    # Test with simple task
    action_module = ActionModule(connection, task, task_vars=task_vars)
    assert action_module.task_vars == task_vars
    assert action_module._task == task
    assert action_module._connection == connection


# Generated at 2022-06-21 02:00:46.472299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    action = ActionModule(module, {})

    assert action.connection is not None


# Generated at 2022-06-21 02:00:54.304658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' unit test for ActionModule.run() '''

    # Testing the class directly without invoking a run
    # command.  This should not fail.
    action_module = ActionModule()

    assert action_module is not None


if __name__ == '__main__':
    # Unit test the module
    module = ActionModule()

    # We are not really testing anything, but we should
    # not fail unit testing.
    test_ActionModule_run()

# Generated at 2022-06-21 02:01:07.022177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    sys.path.append(os.path.abspath(os.path.join(os.getcwd(), '../module_utils/')))
    import module_utils
    from ansible.module_utils import basic

    # Create test object, class ActionModule
    testModule = ActionModule(None, None, None)

    # Create test object, class basic.AnsibleModule
    testAnsibleModule = basic.AnsibleModule()

    # assign vars for test

# Generated at 2022-06-21 02:01:18.300261
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:01:25.102389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import action_loader

    set_module_args(dict(
        src='/foo/bar',
        dest='/bar/baz'
    ))

    module_args = to_bytes(dumps(dict(
        src='/foo/bar',
        dest='/bar/baz'
    )))

    mock_connection = MagicMock()
    mock_connection.__module_name = 'ansible.builtin.connection_plugins.local'

    task_vars = {}

    action = action_loader.get('copy', {}, task_vars, mock_connection)

    action._task = MagicMock()
    action._task.args = {}
    action._task.action = 'copy'

    action._remove_tmp_

# Generated at 2022-06-21 02:05:08.749150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        from ansible.module_utils import basic
        from ansible.module_utils.connection import Connection
        from ansible.module_utils.six import PY3
    except ImportError:
        module.fail_json(msg='Could not import Ansible module utils')

    # Create a mock task object
    task = dict(action=dict(module_name="test", module_args=dict(src="source", dest="destination", raw=dict(follow=False))))
    task_name = "test task name"

    # Create a mock connection object
    class MockConnection(Connection):
        def __init__(self, tmpdir):
            self._shell = Mock()
            self.tmpdir = tmpdir
            self.become_methods_supported = ['sudo', 'su', 'pbrun', 'pfexec']



# Generated at 2022-06-21 02:05:17.828737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(ActionModule.ARGS(
        name='test',
        src='/test/path',
        dest='/test/dest',
        remote_src='true',
        content='test-content',
        force='true',
        validate='test'
    ), task=MockTask())
    
    assert action_module.name == 'test'
    assert action_module.src == '/test/path'
    assert action_module.dest == '/test/dest'
    assert action_module.remote_src == 'true'
    assert action_module.content == 'test-content'
    assert action_module.force == 'true'
    assert action_module.validate == 'test'
    assert action_module.win_path_json is None


# Generated at 2022-06-21 02:05:29.139930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution
    from ansible.module_utils.facts.system.distribution import HP