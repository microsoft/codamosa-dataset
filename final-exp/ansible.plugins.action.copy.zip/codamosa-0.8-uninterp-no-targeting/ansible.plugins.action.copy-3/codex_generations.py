

# Generated at 2022-06-21 01:56:17.855519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import connection_loader
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor import playbook_executor
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook import playbook

    from ansible.module_utils.six import string_types

# Generated at 2022-06-21 01:56:21.263294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(), connection=None, templar=None, shared_loader_obj=None, loader=None)
    module_return = action_module.run(tmp=None, task_vars=None)
    assert module_return is None


# Generated at 2022-06-21 01:56:33.228931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_module_utils_module_loader = MagicMock(name='module_utils_module_loader')
    mock_task_vars = {'foo':'bar'}
    mock_tmp = MagicMock()
    mock_connection = MagicMock()

    mock_connection.run.return_value = (0, '', '')
    mock_connection._shell.join_path.return_value = 'mock_path'
    mock_connection._shell.split_path.return_value = ['mock_path1', 'mock_path2']

    mock_connection._shell.env_prefix.return_value = 'mock_p'
    mock_connection._shell.path_has_trailing_slash.return_value = True

# Generated at 2022-06-21 01:56:39.875225
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:56:47.946987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system.copy as copy
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.basic import AnsibleModule

    module_args = copy.get_module_args()
    module_args.update(
        dict(
            src='',
            dest='',
            follow=True,
            force=True,
            local_follow=True,
            mode='preserve',
            content='',
            remote_src=False,
            recursive=False,
            validate_checksum=False
        )
    )
    module_class = copy.AnsibleModule
    tmp = mock.MagicMock()

    # Mocking arguments and return values.
    task_vars = MagicMock()
    result = {'failed': False}

    # M

# Generated at 2022-06-21 01:56:51.230847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for attr in ('_transfer_strategy', '_connection'):
        tmp_action = ActionModule()
        if not hasattr(tmp_action, attr):
            raise AssertionError("ActionModule missing attr: %s" % attr)

# Generated at 2022-06-21 01:56:56.297429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of ActionModule.
    '''

    # test object creation of ActionModule class
    action_plugin = copy()

    # check object creation using assertIsInstance()
    assertIsInstance(action_plugin, ActionModule)

# Generated at 2022-06-21 01:57:01.970050
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Used to avoid logging calls to ignore them during the test
    def logging_method(message, *args, **kwargs):
        """ Method to ignore logging calls from the library """
        pass

    # Used to avoid log calls to ignore them during the test
    class LoggingClass():  # pylint: disable=too-few-public-methods
        """ Class to ignore logging calls from the library """
        def error(self, message, *args, **kwargs):
            """ The error log method """
            pass

        def debug(self, message, *args, **kwargs):
            """ The debug log method """
            pass

        def info(self, message, *args, **kwargs):
            """ The info log method """
            pass

        def warning(self, message, *args, **kwargs):
            """ The warning log method """


# Generated at 2022-06-21 01:57:07.809071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule()
    test_action_module.set_task(MockTask())
    test_action_module.set_loader(MockLoader())
    test_action_module.set_connection(MockConnection())
    assert test_action_module.run() == 'How to test?'

# Generated at 2022-06-21 01:57:12.877974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Connection(play_context=PlayContext())
    task = dict(name='test', args={'dest': 'a/b/c.txt'})
    action = ActionModule(task, connection, play_context=PlayContext())
    assert isinstance(action._play_context, PlayContext)
    assert 'a/b/c.txt' == action._task.args['dest']
    assert isinstance(action._task, dict)

# Generated at 2022-06-21 01:58:05.726694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        from ansible.plugins.test import test_loader
        from ansible.plugins.test import test_runner
        from ansible.plugins.test import test_connection
    except ImportError:
        return

    print(ActionModule.__doc__)

    task_vars = {}

    class AnsibleModule(object):
        def __init__(self, argspec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False):
            self.argument_spec = argspec
            self.params = {}
            self.check_mode = False
            self.bypass_checks = bypass_checks

# Generated at 2022-06-21 01:58:14.845134
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp = None
    module_args = dict(
        src=str(),
        dest=str(),
        recurse=False,
        mode=str(),
        remote_src=False,
        local_follow=True,
        checksum=str(),
        follow=False,
        force=False,
        backup=str(),
        original_basename=str(),
        content=str(),
        delimiter=str(),
        directory_mode=str(),
        archive=False,
        remote_src=False,
        local_follow=True,
        validate=str(),
        remote_user=str(),
        remote_port=int(),
        remote_pass=str(),
        remote_private_key_file=str(),
        remote_conn=None,
        remote_transport=str()
    )

    # Fail test if module

# Generated at 2022-06-21 01:58:26.564060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule.run()
    """

    # setup
    kwargs = dict()
    kwargs['_ansible_parsed'] = True
    kwargs['_ansible_check_mode'] = False
    kwargs['_ansible_no_log'] = False
    kwargs['_ansible_verbosity'] = 2
    kwargs['_ansible_selinux_special_fs'] = [
        '/sys/fs/selinux',
        '/selinux'
    ]
    kwargs['content_tempfile'] = None
    kwargs['_ansible_diff'] = False
    kwargs['_original_basename'] = None
    kwargs['_ansible_version'] = LooseVersion('2.1.2')

# Generated at 2022-06-21 01:58:35.997611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule.py: Unit test for constructor of class ActionModule '''
    module_name = 'copy'
    task = dict(action=dict(module=module_name))
    task_vars = dict()
    templar = Templar(loader=None, variables=task_vars)
    am = ActionModule(task, templar, task_vars=task_vars)
    assert am.action == module_name, "Newly created ActionModule instance does not have correct action"
    assert am._task == task, "Newly created ActionModule instance does not have correct task"
    assert am._templar == templar, "Newly created ActionModule instance does not have correct templar"

# Generated at 2022-06-21 01:58:46.804160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Setup
    
    module = AnsibleModule(argument_spec=dict())
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._loader.module_loader = DictDataLoader({'ansible.legacy.copy': copy.ActionModule})
    action._loader.module_loader.module_utils_loader = DictDataLoader({'ansible.module_utils.common.copy': copy.module_utils.common})
    action._loader.module_loader.module_utils_loader.module_utils_loader = DictDataLoader({'ansible.module_utils.basic': copy.module_utils.basic})
    action._loader.module_loader.module_utils_loader.module_utils_loader.module_

# Generated at 2022-06-21 01:58:47.248500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 01:58:53.931189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModule(object):
        def run(self, tmp, task_vars=None):
            pass

    module = ActionModule()
    assert isinstance(module, ActionModule)

    class Task(object):
        def __init__(self):
            self.args = dict()

    task = Task()
    module = ActionModule(task, connection=None)
    assert isinstance(module, ActionModule)


# Generated at 2022-06-21 01:59:01.623452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create object of type ActionModule with task and connection
    actionmodule = ActionModule(task=dict(), connection=dict())

    # Test if exception is raised
    with pytest.raises(AnsibleError):
        actionmodule.run(tmp=None, task_vars=None)


# Generated at 2022-06-21 01:59:03.099379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    ActionModule().run()

# Generated at 2022-06-21 01:59:08.628529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup fixture
    self = copy.deepcopy(FIXTURE)
    # execute method
    result = self.run(tmp=None, task_vars=None)
    # Check result
    assert result == FIXTURE_RESULT

# Generated at 2022-06-21 02:00:32.440775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:00:35.027774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict())
    assert action is not None
    assert isinstance(action, ActionBase)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:00:35.864210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:00:39.313772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

##############################################################################

# 
# Code for class ActionModule
#

# Generated at 2022-06-21 02:00:40.788116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._uses_shell is False

# Generated at 2022-06-21 02:00:48.206362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # These parameters are required.
    params = {'dest': 'some/remote/file', 'src': 'some/local/file'}

    # A valid task is required.
    task = Task(name='test_task', action='some.action', args=dict())

    # A valid connection is required.
    connection = Connection(host='localhost', port=12345)

    # This is our test object.
    action = ActionModule(task, connection, play_context=PlayContext())

    # And this is how we test it.
    action._execute_module(module_name='ansible.legacy.copy', module_args=params, task_vars=dict())



# Generated at 2022-06-21 02:00:54.304788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global C
    C = ConfigParser.RawConfigParser()
    C.read('.config_file')
    try:
        action = ActionModule()
    except Exception as e:
        raise Exception("ActionModule constructor Failed %s" % u(e))
    else:
        print("ActionModule constructor is working as expected")


# Generated at 2022-06-21 02:00:56.650874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None


# Generated at 2022-06-21 02:01:08.049837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mocker = Mocker()

    # mock arguments
    args = dict(dest=u'东京', src=u'北京')
    shell = mocker.mock()

    # mock _connection
    ansible_connection = mocker.mock()
    ansible_connection.shell = shell
    ansible_connection._shell = shell
    ansible_connection.tmpdir = '/tmp/mock'

    # mock _task
    ansible_task = mocker.mock()
    ansible_task.args = args

    with mocker:
        # _execute_module needs to be mocked
        mocker.patch(ActionModule.__module__ + '.ActionModule._execute_module')
        copy = ActionModule(ansible_task, ansible_connection, '/tmp/mock')
        assert copy

        #

# Generated at 2022-06-21 02:01:10.547929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test module run method based on an independent scenario.
    pass

# Generated at 2022-06-21 02:04:42.345517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleBaseActionModule()
    host = FakeHttpsConnection()
    assert action_neb.run(module,host,connection)

# Generated at 2022-06-21 02:04:47.677979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    foo = ActionModule(dict())
    bar = foo.run()
    assert isinstance(bar, dict)
    assert 'msg' in bar
    assert 'failed' in bar


# Generated at 2022-06-21 02:04:54.734960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  import nose

  class my_test_class:
    def __init__(self):
      self._task = {}
      self._task.args = {}
      self._task.args['src'] = 'hoge'
      self._task.args['dest'] = 'hoge'


  obj = ActionModule(my_test_class())
  self.assertEqual(obj.run(None), None)


if __name__ == "__main__":
  unittest.main()

# Generated at 2022-06-21 02:05:06.867051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager

    fixture_loader = FixtureLoader()
    action_module = ActionModule()
    action_module.set_loader(fixture_loader)
    action_module._remove_tmp_path = lambda x: None

    # test with deprecated recursive behavior
    action_module._task = Task(dict(action=dict(module_name='copy', recursive=True)))

    action_module._task.args = dict(
        content='test content',
        dest='/path/to/test/dest/'
    )
    action_module._connection = Connection(dict(path_mismatch='mismatch'))
    action_module._display.vvvv = True
    action_module._display.debug = True

# Generated at 2022-06-21 02:05:12.206635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(action=dict(module_name='copy', args=dict())))
    assert isinstance(module, ActionModule)
    assert isinstance(module, ActionBase)
    assert not module.noop_on_check(None)
    assert module.bypass_checks
    assert not module.need_to_run(None, None)
    assert module.get_task_results(None) is None
    assert module.get_task_results(dict()) == dict()
    assert module._execute_module(module_name='ansible.legacy.copy', module_args=dict(), task_vars=dict()) == dict()
    assert module.run(tmp=None, task_vars=dict()) == dict()


# Generated at 2022-06-21 02:05:14.486847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-21 02:05:27.444875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This function tests for the constructor of the ActionModule class.
    """
    test_mock_connection = Connection(None)
    test_task = dict(action=dict(module_name='copy', module_args=dict()))
    test_task_name = ''
    test_inject = None
    test_shared_loader_obj = None
    test_action_loader_obj = None
    test_task_queue = None
