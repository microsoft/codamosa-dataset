

# Generated at 2022-06-21 01:56:11.646495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #print("Running ActionModule_run")
    am = ActionModule()
    am.set_shell(Ssh())
    am.set_task(Task())
    am.set_loader(DataLoader())
    am.set_connection(Ssh())
    am.set_play_context({'password': "test"})

    args = {'content': 'test', 'dest': 'test'}
    # TODO:
        # verify am.run(args)
    #print("Done")

if __name__ == "__main__" :
    test_ActionModule_run()

# Generated at 2022-06-21 01:56:22.664572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil

    basedir = tempfile.mkdtemp()

    try:
        source = os.path.join(basedir, 'tempfile')
        dest = os.path.join(basedir, 'tempfile2')

        with open(source, 'w') as f:
            f.write('cat')

        t = AnsibleTaskVars()
        t.vars = dict()
        t.args = dict()
        t.args['src'] = source
        t.args['dest'] = dest

        action = ActionModule(t, Connection('localhost'))

        result = action.run(None, t.vars)

        shutil.rmtree(basedir)

    finally:
        from os import path

# Generated at 2022-06-21 01:56:23.548393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:56:34.442084
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:56:42.904092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection="connection", runner_queue="runner_queue", task_queue="task_queue",
                          ansible_play=AnsiblePlay(), share_cache="share_cache", action="action", module_name="action_module",
                          module_path="module_path", task=AnsibleTask())
    assert module._connection == "connection"
    assert module._runner_queue == "runner_queue"
    assert module._task_queue == "task_queue"
    assert module._task == AnsibleTask()

    class Runner:
        def __init__(self, host_name="host_name"):
            self._host_name = host_name

    class RunnerQueue:
        def join(self):
            pass


# Generated at 2022-06-21 01:56:53.734043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(connection=Connection())
    action_module._transfer_strategy = 'push'
    action_module._task = dict()
    action_module._task['args'] = dict()
    action_module._task['args']['src'] = 'src'
    action_module._task['args']['dest'] = 'dest'
    action_module._task['args']['content'] = None
    action_module._task['args']['remote_src'] = False
    action_module._task['args']['local_follow'] = True
    _loader = DataLoader()
    _loader.set_basedir(os.getcwd())
    _task_vars = dict()
    _task_vars['vars'] = dict()

# Generated at 2022-06-21 01:57:03.152430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for ActionModule constructor '''
    # (in, out)
    test_cases = [
        ('', {'action': 'asdf'}),
        ('src: "/etc/passwd"', {'action': 'asdf', 'src': '/etc/passwd'}),
        ('src: "/etc/passwd"\ndest: "/tmp/test"', {'action': 'asdf', 'src': '/etc/passwd', 'dest': '/tmp/test'}),
    ]

    for i in test_cases:
        module = ActionModule(i[0])
        assert module._task.args == i[1]


# Generated at 2022-06-21 01:57:13.524810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection_factory = MagicMock()
    mock_connection = mock_connection_factory.return_value
    mock_connection._shell = MagicMock()
    mock_connection._shell.path_has_trailing_slash = MagicMock()
    mock_connection._shell.join_path = MagicMock()
    mock_connection._shell.tmpdir = MagicMock()
    mock_connection._shell.join_path.return_value = MagicMock()
    mock_connection._shell.join_path.return_value.rstrip = MagicMock()
    mock_connection._shell.join_path.return_value.rstrip.return_value = MagicMock()
    mock_connection._shell.join_path.return_value.rstrip.return_value.startswith = MagicMock()
    mock_connection

# Generated at 2022-06-21 01:57:14.620756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = AnsibleActionModule('test')


# Generated at 2022-06-21 01:57:24.855443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for action_plugins/action_module.py run method.
    """
    # Mock module.exit_json
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    builtins.module.exit_json = lambda **kwargs: kwargs
    # Construct the object
    connection = Connection(None)
    task = Task(None, {}, None, None)
    action_module = ActionModule(task, connection, 'test_host', False)

    # Mock _create_content_tempfile
    with patch.object(action_module, '_create_content_tempfile') as content_tempfile:
        content_tempfile.return_value = 'tmpfile'
        # Test for 'src' is required.
        result = action_module.run()

# Generated at 2022-06-21 01:58:15.668173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = MagicMock()
    host.get_name.return_value = "example.com"
    host.get_variable_interpolated.return_value = "/path/to/my/file"
    host.get_variables.return_value = {"ansible_diff_mode":"diff", "ansible_ssh_private_key_file":"ssh_private_key_file"}
    host.get_connection_type.return_value = "ssh"
    host.get_dsn.return_value = "example.com,example.com"
    host.get_bin_path.return_value = "bin_path"
    host.has_pipelining.return_value = True

    task = MagicMock()
    task.get_name.return_value = "task-x"


# Generated at 2022-06-21 01:58:27.021490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test normal case
    module_args = dict(
        content=None,
        dest='/path/to/destination/',
        directory_mode=None,
        follow=False,
        force=False,
        group=None,
        mode=None,
        owner=None,
        remote_src=False,
        selevel=None,
        serole=None,
        setype=None,
        seuser=None,
        src='/path/to/source/',
        validate=None,
    )
    fake_loader = DictDataLoader({'path/to/source/': b"file data"})
    fake_invocation = dict(module_args=module_args)
    # Test with content
    module_args['content'] = 'content'

# Generated at 2022-06-21 01:58:30.879674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test_input_action_module_data')
    assert am is not None

if __name__ == "__main__":

    # Unit Tests
    test_ActionModule()

# Generated at 2022-06-21 01:58:44.909541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    import ansible.executor.task_result as task_result

    # Construct a simple task
    mock_loader, lookup_finder, temp_dir = _create_mock_objects()
    mock_task = Task()
    mock_task._role = None
    mock_block = Block()
    mock_block.vars = dict()
    mock_task._block = mock_block
    mock_play_context = PlayContext()

    mock_task.args = dict(
        dest='/etc/ansible',
        src='/etc/ansible'
    )

    mock_task.action = 'copy'
    mock_task.async_val = 0

   

# Generated at 2022-06-21 01:58:48.509993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(action=dict(module='copy',
                            args=dict(
                                src='/etc/hostname',
                                dest='/etc/ssss')))

    t = ActionModule(task=task, connection=dict(module='local'))
    result = t.run()
    assert result['invocation']['module_name'] == 'copy'
    assert 'failed' in result['invocation']


# Generated at 2022-06-21 01:58:56.138967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a dummy task
    task_args = dict()

    # create the action module object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # check the class members instantiated with empty values
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None


# Generated at 2022-06-21 01:59:00.414573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = mock.Mock()
    mock_task_vars = dict()
    mock_task_vars['ansible_connection'] = 'local'
    mock_action_plugin = ActionModule(mock_task, task_vars=mock_task_vars)
    assert mock_action_plugin._connection.__class__.__name__ == 'LocalConnection'
    assert mock_action_plugin._task_vars == mock_task_vars


# Generated at 2022-06-21 01:59:07.872384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.connection import Connection

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='copy', args=dict(dest='/tmp/test.txt', content='foooooobaaaarrr'))),
            ]
        )

    loader

# Generated at 2022-06-21 01:59:17.384103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=dict(action=dict(module_name='copy', module_args={"a":1, "b":2}), args={"src": "src", "dest": "dest"}), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m._task.action['module_name'] == 'copy'
    assert m._task.action['module_args'] == {"a":1, "b":2}
    assert m._task.args['src'] == "src"
    assert m._task.args['dest'] == "dest"
    assert m.connection == None
    assert m.play_context == None
    assert m.loader == None
    assert m.templar == None
    assert m.shared_loader_obj == None

# Generated at 2022-06-21 01:59:20.314861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    import __main__ as main
    main.DS = None

    tmp = '/tmp'
    task_vars = {'foo': 'bar'}
    ansible_module_instance = ActionModule(dict(), dict(), 'test_id')

    # Call method under test
    result = ansible_module_instance.run(tmp=tmp, task_vars=task_vars)



# Generated at 2022-06-21 02:00:49.664903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def _create_action_mod():
        class DataHolder(object):
            def __init__(self, **kwargs):
                for attr in kwargs:
                    setattr(self, attr, kwargs[attr])

# Generated at 2022-06-21 02:00:52.342274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the class object
    module = ActionModule()
    # Check the run() method
    assert module.run() == None

# Generated at 2022-06-21 02:00:59.084714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.utils.path import unfrackpath
    from .mock import patch, MagicMock
    import pytest
    import os
    import shutil
    import tempfile
    import yaml
    import base64
    import json
    import sys

    global module_return, source_files
    module_return = {}
    source_files = {}

    fake_loader = MagicMock()
    context._init_global_context(loader=fake_loader)

    tmp = tempfile.mkdtemp()
    local_tmp = tempfile.mkdtemp()
    source = unfrackpath(tmp) + '/'
    dest = unfrackpath(local_tmp)

    # Make ansible tmp dir
    os.makedirs(source)

    # Make some fake files for the tests

# Generated at 2022-06-21 02:01:09.092867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # imports
    import os

    # Set some variables
    action_connection = module_connection = os

    # random data
    tmp = data_random_int

    # random data
    task_vars = data_random_int

    # instantiation
    action_instance = ActionModule(
        action_connection,
        "/home/foo", # _load_name
        "/home/foo", # _task_vars
        "/home/foo", # _templar
        "/home/foo", # _shared_loader_obj
        dict(foo='bar'), # data
        tmp,
        task_vars,
        "/home/foo", # play_context
        "/home/foo", # loader
        "/home/foo", # templar
        "/home/foo", # shared_loader_obj
    )

    # class instant

# Generated at 2022-06-21 02:01:16.610995
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:01:21.883587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct an Ansible task, AnsibleOptions and AnsibleTaskVars
    task = Task()
    task.args = dict(
        src = 'src',
        dest = 'dest',
        remote_src = False,
        content = 'content',
        local_follow = None
    )
    ansible_options = AnsibleOptions()
    ansible_task_vars = AnsibleTaskVars()

    # Construct a connection and a transport for this connection
    connection = Connection(ansible_options)
    transport = Connection(ansible_options, connection)

    # Construct a new ActionModule
    action_module = ActionModule(connection, transport, task, ansible_options, ansible_task_vars)
    assert action_module is not None

# Generated at 2022-06-21 02:01:30.737917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = source_dir + "test_action_module/action_plugins/test_copy.py"
    with open(source) as f:
        lines = f.read()
    s = StringIO(lines)
    module_name = 'test_copy'
    module_args = {}
    my_class = ActionModule(s, module_name, {}, **module_args)
    task_vars = {}
    module_paths = {}
    tmp = tempfile.gettempdir()
    tmp = to_bytes(tmp, errors='surrogate_or_strict')
    result = my_class.run(tmp, task_vars)
    assert result.get('failed') is False

    module_name = 'test_copy2'

# Generated at 2022-06-21 02:01:32.246327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=FakeTask())
    assert action_module

# Generated at 2022-06-21 02:01:34.986275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert module.run() == None



# Generated at 2022-06-21 02:01:46.950030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    DICT = {'key': 'value'}

    action = ActionModule()

    # Test failed, not a dictionary
    assert action.run() == {'failed': True, 'msg': 'src (or content) is required'}

    # Test failed, no dest
    assert action.run({'src': 'a'}) == {'failed': True, 'msg': 'dest is required'}

    # Test failed, source and content are mutually exclusive
    assert action.run(
        {
            'src': 'a',
            'content': 'content',
            'dest': 'dest'
        }
    ) == {'failed': True, 'msg': 'src and content are mutually exclusive'}

    # Test failed, content with dir as dest

# Generated at 2022-06-21 02:05:29.245659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test case.
    import ansible.legacy.plugins.action
    import tempfile
    tmp = tempfile.mkdtemp()
    result = dict()
    task_vars = dict()
    tmp_src = tempfile.mkdtemp(dir=tmp)
    tmp_dest = tempfile.mkdtemp(dir=tmp)
    task_args = dict(content=None, src=tmp_src, current_path=tmp, dest=tmp_dest, follow=False, recursive=True, mode='preserve')
    action_module = ansible.legacy.plugins.action.ActionModule(task=dict(action=dict(module_name='copy'), args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test case for