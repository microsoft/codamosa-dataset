

# Generated at 2022-06-21 01:56:18.635417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_connection='local',
        ansible_python_interpreter=sys.executable,
        ansible_shell_type='csh',
        ansible_shell_executable='/bin/csh',
        ansible_ssh_executable='/usr/local/bin/ssh'
    )

    # test string values

# Generated at 2022-06-21 01:56:27.495059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play_context
    play_context_obj = ansible.playbook.play_context.PlayContext()
    import ansible.playbook.task
    task_obj = ansible.playbook.task.Task()
    import ansible.plugins.loader
    pm = ansible.plugins.loader.action_loader.get('copy', play_context_obj, task_obj, loader=ansible.plugins.loader)
    pm._remove_tmp_path('/tmp')
    pm.check_mode = True
    pm.cleanup('test')
    pm.copy('test', 'test')
    pm._copy_file('test', 'test', 'test', 'test', 'test', 'test', 'test')
    pm._create_content_tempfile('test')

# Generated at 2022-06-21 01:56:36.302529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit test for constructor of class ActionModule
    '''
    reload(legacy_file)
    os_path_exists_map = {'EXAMPLE_TEST': True}
    os_path_isdir_map = {'EXAMPLE_TEST': True}
    os_path_exists_map_false = {'EXAMPLE_TEST': False}
    module_loader = DictDataLoader({'ansible.legacy.file': '', 'ansible.legacy.copy': ''})
    task_vars = {}
    test_args = {}
    m_object = MagicMock()
    m_object.__getitem__.side_effect = os_path_exists_map.__getitem__
    m_object.__setitem__.side_effect = os_path_

# Generated at 2022-06-21 01:56:46.715320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ntpath
    import posixpath
    import os
    import tempfile
    import traceback
    import json

    class Shell(object):
        def path_has_trailing_slash(self, path):
            if path.endswith("/") or path.endswith("\\"):
                return True
            else:
                return False

        def join_path(self, path1, path2):
            return path1 + "/" + path2

        def tmpdir(self):
            return tempfile.gettempdir()

    class Task(object):
        def __init__(self):
            self.args = {}

        def __str__(self):
            return ""

    class TaskVars(object):
        def __init__(self):
            self.vars = {}


# Generated at 2022-06-21 01:56:57.351704
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:57:08.850221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    remote_user = None
    a = ActionModule(task=dict(action=dict(module_name='copy', module_args=dict()), args=dict(dest='/home/ansible')))
    a.get_action_args = lambda: dict()
    a._task = CustomObject()

# Generated at 2022-06-21 01:57:16.830464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # user_connection is of class ansible.plugins.connection.local.Connection
    user_connection = ansible.plugins.connection.local.Connection(None)

    # self._task is of class ansible.executor.task_result.TaskResult
    self._task = ansible.executor.task_result.TaskResult(
        ansible.playbook.task.Task(),
        ansible.playbook.play.Play()
    )
    self._task._role = ansible.playbook.role.Role()
    self._task._role.get_role_path = lambda: "test_role_path"
    self._task.action = "copy"
    self._task.args = {
        "content": "test_content",
        "dest": "test_dest"
    }

    # self._connection is of class ansible

# Generated at 2022-06-21 01:57:23.673979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {"hostvars": {"host1": {'foo': 'bar'}}}
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['host1', 'host2']))
    task = Task()
    task.action = 'copy'
   

# Generated at 2022-06-21 01:57:31.768110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test the constructor of class ActionModule
    '''
    class TestTask(object):
        def __init__(self, args):
            self.args = args

    args = dict(
        _uses_shell=False,
        _raw_params="",
        _task_vars={},
        action="copy",
    )

    action_module = ActionModule(task=TestTask(args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-21 01:57:33.218379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:58:32.646877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('foo', 'bar', 'baz')
    assert module._name == 'foo'
    assert module._task == 'bar'
    assert module._connection == 'baz'
    assert module._play_context == 'baz'
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None
    assert module._action_loader is None
    assert module._connection_loader is None
    assert module._task_vars is None
    assert module._task_vars_template is None
    assert module._playbook is None
    assert module._new_stdin is None
    assert module._handler_path == 'ansible.legacy.builtin_action_plugins'
    assert module._name_action is not None
    assert module._name_action == 'foo'

# Generated at 2022-06-21 01:58:45.340636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = AnsibleModule()

    # test_ActionModule_run_empty_source
    with pytest.raises(AnsibleFailure) as excf:
        ActionModule._task = m
        ActionModule._task.args = dict()
        ActionModule.run()
    assert "src (or content) is required" in excf.value.message

    # test_ActionModule_run_empty_dest
    with pytest.raises(AnsibleFailure) as excf:
        ActionModule._task = m
        ActionModule._task.args = dict(src='test')
        ActionModule.run()
    assert "dest is required" in excf.value.message

    # test_ActionModule_run_src_and_content

# Generated at 2022-06-21 01:58:50.756057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    :summary: Check that ActionModule constructor works properly
    '''

    class LocalActionModule(ActionModule):
        def run(self, *args, **kwargs):
            raise NotImplementedError()

    task = MockTask()
    connection = MockConnection()
    play_context = MockPlayContext()
    loader = MockLoader()
    tmp = MockTemporaryDirectory()

    action_module = LocalActionModule(task, connection, play_context, loader, tmp)

    assert isinstance(action_module._task, MockTask)
    assert isinstance(action_module._connection, MockConnection)
    assert isinstance(action_module._play_context, MockPlayContext)
    assert isinstance(action_module._loader, MockLoader)
    assert isinstance(action_module._temppath, MockTemporaryDirectory)

# Generated at 2022-06-21 01:58:58.890043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    use_crypto = None
    module = ActionModule(task=dict(action=dict(), args=dict()), connection=dict(use_persistent_connections=False, become=False, ansible_ssh_user='test_user', ansible_ssh_pass='test_pass'), play_context=dict(become_user='test_become_user', become_pass='test_become_pass', become=False, remote_addr='test_remote_addr', password='test_pass'), loader=dict(basedir='test_basedir'), templar=dict(), shared_loader_obj=None)

    assert use_crypto == True

    use_crypto = None

# Generated at 2022-06-21 01:59:08.067370
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task

    from ansible.plugins.action.copy import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import module_common
    from ansible.utils.display import Display
    display = Display()

    # FIXME: Change the task to be used as parameter in first parameter of ActionModule
    #task = Mock(spec=Task)
    task = Task()

    # FIXME: Change the connection to be used as parameter in second parameter of ActionModule
    #connection = Mock(spec=Connection)
    connection = Connection()

    # FIXME: Change the play_context to be used as parameter in third parameter of ActionModule
    #play_context =

# Generated at 2022-06-21 01:59:17.457301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = ansible.playbook.play_context.PlayContext()
    conn._shell = Mock()
    conn._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    conn._shell.join_path = lambda x, y: x + '/' + y
    conn._shell.tmpdir = C.DEFAULT_REMOTE_TMP
    conn._shell.tmpdir_lockfd = None
    conn._shell.tmpdir_lockfile_path = None
    conn._shell.tmpdir_uses_sudo = True
    conn.remote_addr = 'localhost'
    conn.remote_user = 'root'

    task = ansible.playbook.task_include.TaskInclude()
    task.args = {'foo': 'bar'}
    task_vars = dict()

    #

# Generated at 2022-06-21 01:59:22.794383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # null object to use if no tmp is provided
    null_object = object()
    # set up the actual test
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # temp directory for the source
    test_tmp = os.path.join(tempfile.gettempdir(), 'ansible-unittest')
    # make sure the temp directory isn't there
    if os.path.exists(test_tmp):
        shutil.rmtree(test_tmp)
    # create the temp directory
    os.makedirs(test_tmp)
    # define the source as the temp directory
    source = test_tmp
    # create a remote path for the destination

# Generated at 2022-06-21 01:59:35.189775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create connection to test against
    class MockConnection(Connection):
        def set_options(self, var_options=None):
            pass
        def connect(self, port=None):
            pass
        def exec_command(self, cmd, in_data=None, sudoable=True):
            pass
        def _prefix_login_path(self, remote_path):
            return remote_path
    mock_connection = MockConnection(host=hostname, port=2222)
    mock_shell = ShellModule(connection=mock_connection)
    mock_shell.tmpdir = tempfile.mkdtemp()
    mock_shell.path_has_trailing_slash = MagicMock(return_value=False)

    # Stub out the options dictionary.

# Generated at 2022-06-21 01:59:46.812454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Item tests
    #

    def pytest_generate_tests(metafunc):
        # called once per each test function
        funcarglist = metafunc.cls.params[metafunc.function.__name__]
        argnames = sorted(funcarglist[0])
        metafunc.parametrize(argnames, [[funcargs[name] for name in argnames]
                                        for funcargs in funcarglist])


# Generated at 2022-06-21 01:59:49.096378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)


# Generated at 2022-06-21 02:01:13.419884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.BYPASS_HOST_LOOP == True

# Generated at 2022-06-21 02:01:18.614049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Should pass if no exception
    try:
        am = ActionModule()
    except Exception as e:
        raise Exception('unexpected exception found: {}'.format(str(e)))

# Generated at 2022-06-21 02:01:28.464025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = os.path.realpath(tempfile.mkdtemp())
    filename = os.path.join(tmp, "test_file")
    with open(filename, "w") as f:
        f.write("TEST0\n")
    task = dict(action=dict(module="copy", args=dict(src=filename, dest=filename+"2", content="TEST")))
    tmp_vars = dict(ansible_connection="local")

    action = ActionModule(task, tmp_vars)
    res = action.run(tmp, tmp_vars)
    assert res["changed"], "ActionModule constructor run without arguments should have 'changed'=True: %s" % res
    os.remove(filename)
    os.remove(filename+"2")
    os.removedirs(tmp)

# Generated at 2022-06-21 02:01:35.532149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test execution with "src" provided.
    action_module = ActionModule(
        task=dict(
            args=dict(src="src")
        )
    )

    # Test execution with "content" provided.
    action_module = ActionModule(
        task=dict(
            args=dict(content="content")
        )
    )

    # Test execution with "content" and "dest" provided.
    action_module = ActionModule(
        task=dict(
            args=dict(content="content", dest="dest")
        )
    )



# Generated at 2022-06-21 02:01:47.305127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""

    # Unit test for method run of class ActionModule without parameters
    def test_ActionModule_run_without_parameters(self):

        module_without_parameters = {
        }
        module_parameters = {}

        # Creation of class ActionModule with parameters module_parameters
        action_module = ActionModule(module_parameters)

        # Test the method run of class ActionModule
        result = action_module.run()
        assert result == {'failed': True, 'msg': 'src is required'}

    # Unit test for method run of class ActionModule with parameters

# Generated at 2022-06-21 02:01:51.410305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    assert module.run() == None
    assert module.run(None) == None
    assert module.run(None, None) == None



# Generated at 2022-06-21 02:01:59.053230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    task = AnsibleMock()
    task_args = {
        "src": "some_src",
        "content": "some_content",
        "dest": "some_dest",
        "remote_src": "some_remote_src",
        "local_follow": "some_local_follow"
    }
    task.args = task_args
    connection = AnsibleMock()
    action_module = ActionModule(task, connection)
    assert action_module.run()




# Generated at 2022-06-21 02:02:06.009391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_module_args({
        'src': '/path/to/a',
        'dest': '/path/to/b',
        'content': 'Hello world',
        'state': 'directory',
        'mode': '0755',
        'remote_src': True,
        'backup': 'yes',
        'force': True,
    })
    am = ActionModule(task=dict(action=dict(module_name='copy'), args=dict()), connection='local', play_context=dict(become_user='testuser'), loader=dict(), templar=None, shared_loader_obj=None)
    assert am._task == dict(action=dict(module_name='copy'), args=dict())
    assert am._connection == 'local'
    assert am._play_context == dict(become_user='testuser')

# Generated at 2022-06-21 02:02:15.902491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(
        src='/path/to/file',
        remote_src=True,
        follow=True,
        local_follow=True,
        dest='/path/to/file'
    )
    task = DummyTask(args=args)
    task.register_template_loader('path/to/file', DummyLoader())
    task_vars = dict(
        ansible_connection='local',
        ansible_check_mode=False,
        ansible_module_name='copy'
    )

    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = action.run(tmp='/path/to/file', task_vars=task_vars)

# Generated at 2022-06-21 02:02:25.375524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test function for class ActionModule
    '''
    # Load the class and make an instance.  We have to specify a
    # config and a task.  Config could come from an AnsibleConfig object but we don't
    # have one yet.  An ActionBase object also needs it's task as part of it's constructor.
    # We'll be making up a dummy task to pass in.
    module_mock = MagicMock(name='ActionModule mock')
    config_mock = MagicMock(name='config mock')
    config_mock.ANSIBLE_LIBRARY = '/dev/null'
    config_mock.DEFAULT_KEEP_REMOTE_FILES = True
    config_mock.HASH_BEHAVIOUR = 'merge'
    task = dict()
    task['action'] = dict()