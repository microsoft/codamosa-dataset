

# Generated at 2022-06-11 11:22:01.684634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    shutil.rmtree("test", ignore_errors=True)
    os.makedirs("test")
    os.system("cat /home/gavin/project/source/git/others/ansible-poc/test/test_role/test_data/test_task/test.py > test/test.py")
    os.system("cat /home/gavin/project/source/git/others/ansible-poc/test/test_role/test_data/test_task/test.yml > test/test.yml")
    os.system("cat /home/gavin/project/source/git/others/ansible-poc/test/test_role/test_data/test_task/test2.py > test/test2.py")

# Generated at 2022-06-11 11:22:13.443016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config = {
        'remote_user': 'r.user',
        'hosts': ['remote.host'],
        'host_key_checking': False,
        'ssh_common_args': [],
        'sftp_extra_args': [],
        'scp_extra_args': [],
        'connection': 'smart',
        '_ansible_connection': 'ssh',
        '_ansible_remote_tmp': '~/.ansible/tmp'
    }

    # Test module run for an ssh connection
    class ConnectionSshMock:
        @staticmethod
        def run(self, tmp, task_vars):
            return {'changed': False, 'dest': 'dest'}

# Generated at 2022-06-11 11:22:21.287187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = AnsibleModule()
    task_vars = dict(ansible_connection='', ansible_ssh_user='', ansible_ssh_pass='', ansible_sudo_pass='', ansible_become_pass='', ansible_check_mode=True)
    a._ansible_no_log = set()
    a.run_command('', check_rc=False)
    a._load_name_splitter("AnsibleModule")
    a._execute_module()
    b = ActionModule(a, task_vars=task_vars)
    paramiko.SSHClient = MagicMock()
    b._execute_module()
    b._execute_module("ansible.legacy.file")
    b._execute_module("ansible.legacy.file", find_needle=False)
    b._

# Generated at 2022-06-11 11:22:24.964874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), shared_loader_obj=Mock(),
                          final_q=Mock(), loader_cache=Mock())
    assert(True)

# Generated at 2022-06-11 11:22:27.682597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test ActionModule constructor
    '''
    module = ActionModule()
    assert module._supports_check_mode == False

# Generated at 2022-06-11 11:22:39.961247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    ver = Version('2.9.1')
    # FIXME: depends on a 'python' executable
    task = Task()
    task.args = {'_raw_params': 'echo "hello"', '_uses_shell': False, '_uses_delegate': True, '_raw_params': 'date', '_delegate_to': 'localhost'}
    connection = Connection(play_context=PlayContext())
    module_mock = MagicMock(spec_set=ModuleBase)
    module_mock._load_name = 'ansible.legacy.shell'

# Generated at 2022-06-11 11:22:48.855919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_helper = TestHelper()
    temp_dir = tempfile.mkdtemp()
    test_helper.register_task_plugin(path=temp_dir, name="copy.py", plugin_class="copy",
                                     module_utils="ansible.module_utils.basic")
    test_helper.register_task_plugin(path=temp_dir, name="file.py", plugin_class="file",
                                     module_utils="ansible.module_utils.basic")
    test_helper.register_module_utils(
        {"ansible.module_utils.basic": {"AnsibleModule": test_helper.mock_ansible_module}})
    test_helper.patch_modules(basic=True)
    fake_path = "/usr/bin:/bin:/tmp"


# Generated at 2022-06-11 11:22:52.586430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   # val = ActionModule(mock,mock,mock,mock)
    #assert val is not None
    pass

#################
#ActionModule::run_command
#################


# Generated at 2022-06-11 11:23:03.603433
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:23:13.271292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    in_data = dict(dest=["dir_1/dir_2"],
                   follow=["False"],
                   mode=["preserve"],
                   recurse=["yes"],
                   src=['from_dir/from_file'],
                   original_basename=["from_file"])

    task_vars = dict(
        ansible_check_mode=False,
        ansible_connection='local',
        ansible_network_os=None,
        ansible_play_batch=None,
        ansible_play_hosts=['test_host'],
        ansible_user='test_user')

    loader = DictDataLoader({'test_host': {'vars': {'host_var': 'host_var_value'}}})

    mock_task = MagicMock()

# Generated at 2022-06-11 11:24:23.417129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.setup_task = MagicMock()
    action_module._execute_module = MagicMock()
    action_module._execute_module.return_value = {'dest': 'test', 'src': 'test', 'changed': False}
    action_module._connection = Mock()

    # No source and no content
    action_module._task.args = {'dest': 'test'}
    result = action_module.run(None, {'TEST_VAR': 'test'})
    assert result['failed']

    # source is empty
    action_module._task.args = {'src': '', 'dest': 'test'}
    result = action_module.run(None, {'TEST_VAR': 'test'})
    assert result['failed']

    # dest

# Generated at 2022-06-11 11:24:32.886291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = AnsibleOptions(verbosity=0, connection='ssh', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False, diff=False, listhosts=None, listtasks=None, listtags=None, syntax=False)
    b = Display()
    c = CLI(a)
    d = OptionParser(a, b, c)
    e = AnsibleModule(argument_spec={}, supports_check_mode=False)
    f = ActionModule(e)
    g = Mock()
    g.run.return_value = '{"failed": False}'
    f._execute_module = g
    h = Mock()
    h.return_value = 'None'
    f._copy_file = h

# Generated at 2022-06-11 11:24:35.401525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  action_module.run(tmp=None, task_vars=None)


# Class ActionModule

# Generated at 2022-06-11 11:24:38.358302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for ActionModule constructor'''

    obj = ActionModule(None, {}, {})

    assert obj is not None, 'Expected non-None object'

# Generated at 2022-06-11 11:24:45.671495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Test run() of ActionModule '''

    # Setup test
    set_module_args({
        'remote_src': True
    })

    # Execute test
    with patch.object(ActionModule, 'run') as mock_run:
        mock_run.return_value = {}
        action_module = ActionModule()
        result = action_module.run(tmp=None, task_vars=None)

    assert result == {
        'changed': False
    }


# Generated at 2022-06-11 11:24:47.539078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing, Constructor of class ActionModule")
    obj = ActionModule(None, None)
    return obj


# Generated at 2022-06-11 11:24:56.511080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test of ActionModule class.
    '''
    args = dict(dest='/tmp/foo', src='/tmp/bar')
    task = dict(args=args)
    task_vars = dict()

    def exec_module_mock(*args, **kwargs):
        raise NotImplementedError()

    def execute_module_mock(*args, **kwargs):
        raise NotImplementedError()

    module_mock = MagicMock()
    module_mock.params = dict(src=None, dest=None, content=None)
    module_mock.run_command = exec_module_mock
    module_mock.run = execute_module_mock
    module_mock.fail_json.return_value = dict(failed=True)


# Generated at 2022-06-11 11:25:06.474881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    mock_loader = DictDataLoader({
        'foobar.yml': """
        - hosts: all
          tasks:
            - copy:
                src: '/usr/local/bin/foo'
                dest: '/etc/bin'
        """,
    })
    mock_inventory = InventoryManager(loader=mock_loader, sources=['foobar.yml'])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

# Generated at 2022-06-11 11:25:08.681012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(src="/path/to/src", dest="/path/to/dest")
    obj = ActionModule(dict(), args, False)
    assert obj

# Generated at 2022-06-11 11:25:17.447445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test environment.
    from ansible.plugins.loader import connection_loader, module_loader
    from ansible import context
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
   

# Generated at 2022-06-11 11:27:37.685452
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test with default parameters
    test_actionmodule_obj = ActionModule()

    # Check the type of test_actionmodule_obj.
    assert isinstance(test_actionmodule_obj, ActionModule)
    
    # Test with parameters
    test_task_obj = Task()
    test_connection_obj = Connection()
    test_task_vars_obj = dict()
    test_play_context_obj = PlayContext()
    test_loader_obj = DataLoader()
    test_temppath_obj = None
    test_shared_loader_obj = False

# Generated at 2022-06-11 11:27:47.848155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    import __main__ as main
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    localhost = '127.0.0.1'

    class MockConnection(ConnectionBase):
        '''Connection stub for test'''
        transport = 'mock'
        def __init__(self, *args, **kwargs):
            self.host = localhost
            super(MockConnection, self).__init__(*args, **kwargs)

        def _connect(self):
            return self

        def put_file(self, in_path, out_path):
            '''Base class override stub for test'''
            return True


# Generated at 2022-06-11 11:27:57.949431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import Include
    from ansible.playbook.handler.include import Include as HandlerInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess

    play_context = PlayContext()
    task = Task()
    block = Block()
    role_include = Include()
    handler_include = HandlerInclude()
    tqm = None
    worker_process = WorkerProcess(tqm, play_context, task, block, role_include, handler_include)

# Generated at 2022-06-11 11:28:08.281728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_run_setup(object):
        def __init__(self, module_name, module_args, task_vars, task_vars_with_self, task_vars_with_private_ip_addr, task_vars_without_private_ip_addr, _connection, play_context, loader, _task, _loader_mock, _connection_mock):
            self._task = _task
            self._loader_mock = _loader_mock
            self._connection_mock = _connection_mock
    class ActionModule_run_setup_mock(object):
        def __init__(self):
            self._task = None
            self._loader_mock = MagicMock()
            self._connection_mock = MagicMock()

# Generated at 2022-06-11 11:28:09.646861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('file', dict(), dict(), dict(), dict())

# Generated at 2022-06-11 11:28:16.269870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the module and check if all data
    # are correct initialized.
    am = ActionModule('copy')
    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None
    assert am._diff == None

    # Create an instance of the module and check if all data
    # are correct initialized.
    am = ActionModule('copy', task='task', connection='connection', play_context='play_context',
                      loader='loader', templar='templar', shared_loader_obj='shared_loader_obj', diff='diff')
    assert am._task == 'task'
    assert am._connection == 'connection'

# Generated at 2022-06-11 11:28:20.776239
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:28:22.486062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for ActionModule class constructor """
    module = ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, object)


# Generated at 2022-06-11 11:28:26.840757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {'dest': '/tmp/test'}
    loader = DictDataLoader({
        "path": {"plugin": "ansible.legacy", "name": "copy"},
    })
    module_manager = ModuleManager(loader=loader)
    task_queue_manager = TaskQueueManager(module_manager=module_manager,
                                          inventory=Inventory(loader=loader,
                                                              host_list=['localhost']),
                                          variable_manager=VariableManager())
    play_context = PlayContext()

    task_vars = dict()
    action_module = ActionModule(task=task,
                                 play_context=play_context,
                                 new_stdin='',
                                 loader=loader,
                                 connection=None,
                                 task_queue_manager=task_queue_manager)
    result

# Generated at 2022-06-11 11:28:28.432581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    am = ActionModule(None, {})
    assert am._action_name == 'file'
    assert am._action_path == 'ansible.legacy.file'
    assert am._action is ansible.plugins.action.copy.ActionModule.copy