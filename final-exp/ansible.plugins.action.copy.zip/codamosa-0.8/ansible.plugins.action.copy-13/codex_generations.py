

# Generated at 2022-06-11 11:21:51.623349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 11:21:53.710181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert str(type(am._shell_plugin)) == "<class 'ansible.plugins.shell.ShellModule'>"

# Generated at 2022-06-11 11:22:06.082268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    file = ActionModule(Connection, 'ansible_test_connection', 'bogus', 'testdata/test.yml')
    assert file is not None
    assert file._task.action == 'copy'
    assert file._task.args.get('src') == 'hello'
    assert file._task.args.get('dest') == 'goodbye'

    # Constructor with nonexistent yaml file
    try:
        file = ActionModule(Connection, 'ansible_test_connection', 'bogus', 'dummy.yml')
        assert False
    except AnsibleFileNotFound as e:
        assert to_text(e) == "the playbook: dummy.yml could not be found"

    # Constructor with invalid yaml file

# Generated at 2022-06-11 11:22:16.742041
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def _generate_test_cases():
        # Test case 1
        test_case_1 = (dict(
            source = None,
            content = None,
            dest = None,
            remote_src = False,
            local_follow = True,
            expected_dest = None,
            expected_failed = True,
        ))

        # Test case 2
        test_case_2 = (dict(
            source = None,
            content = "hello world",
            dest = None,
            remote_src = False,
            local_follow = True,
            expected_dest = None,
            expected_failed = True,
        ))

        # Test case 3

# Generated at 2022-06-11 11:22:27.578277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Connection()
    connection._shell = Shell('/Users/jamesob/.ansible/tmp/ansible-tmp-1571226455.774566-157391232111104/', '/bin/sh')
    task = Task()
    task.args.update({'src': 'test.txt', 'dest': '/tmp/test.txt'})


# Generated at 2022-06-11 11:22:39.822215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = MagicMock()
    host.get_vars.return_value = {'inventory_hostname': 'foo'}
    task = MagicMock(action=dict(module_args=dict(content='bar')))
    task.args = {}
    am = ActionModule(task, host)
    am.run()

    # Validate call to copy module
    assert 'ansible.legacy.copy' in am._task.action
    assert '_ansible_tmp_file' in am._task.action['module_args']
    assert 'content' in am._task.action['module_args']
    assert 'checksum' in am._task.action['module_args']
    assert 'dest' in am._task.action['module_args']

    # Validate call to file module

# Generated at 2022-06-11 11:22:48.739582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VarManager

    test_default_args = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}

    test_play_context = PlayContext()
    test_play_context.remote_addr = '127.0.0.1'
    test_play_context._play = dict()
    test_play_context._play.vars = dict()

    test_var_manager = VarManager
    test_var_manager._fact_cache = dict()
    test_var_manager._extra_vars = dict()
    test_var_manager._task_vars = dict()

    test_connection_info = dict()
    test_connection_

# Generated at 2022-06-11 11:22:59.654178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    s = dict(foo='bar')
    task_vars = dict(foo='bar')
    task_vars = dict()
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    action_module = ActionModule(ansible_module, s)
    action_module.run(tmp=None, task_vars=task_vars)
    action_module._connection._connection.play_context = s
    action_module._connection._shell.path_has_trailing_slash = lambda x: True
    action_module._connection._shell.join_path = lambda *args: args
    action_module.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-11 11:23:10.228215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cls = ActionModule
    cls._remove_tmp_path = mock.MagicMock()
    cls._copy_file = mock.MagicMock()
    cls._execute_module = mock.MagicMock()
    cls._remote_expand_user = mock.MagicMock()
    cls._find_needle = mock.MagicMock()
    cls._task = mock.MagicMock()
    cls._task.args.get.return_value = None
    cls._connection = mock.MagicMock()
    cls._connection._shell.path_has_trailing_slash.return_value = 'path'
    
    result = cls.run('tmp', 'task_vars')
    assert cls._remove_tmp_path.called
    assert cls._copy_file.called


# Generated at 2022-06-11 11:23:18.878846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is a simple example of a unit test that would get
    # run automatically.  It should ensure the code does what it
    # claims to.
    am = ActionModule()
    task = {}
    task['args'] = {}
    task['args']['src'] = 'src'
    task['args']['dest'] = 'dest'
    task['args']['content'] = 'content'
    task['args']['checksum'] = 'checksum'
    task['args']['recurse'] = True
    task['args']['mode'] = 'mode'
    task['args']['follow'] = 'follow'
    task['args']['directory_mode'] = 'directory_mode'
    task['args']['original_basename'] = 'original_basename'

# Generated at 2022-06-11 11:24:10.881221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ...


# Generated at 2022-06-11 11:24:15.509858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(DummyConnection(), None, 'test_action', {}).action == 'test_action'
    assert ActionModule(DummyConnection(), None, 'test_action2', {}).action == 'test_action2'
    assert ActionModule(DummyConnection(), None, 'test_action3', {}).action == 'test_action3'


# Generated at 2022-06-11 11:24:16.763346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:24:26.464995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if six.PY2:
        _connection = Connection()
        _task = Task()
        _loader = DataLoader()
        _play_context = PlayContext()
        _play_context._play = _play_context
        _task._play_context = _play_context
        _task._role = _task
        _task._task = _task

# Generated at 2022-06-11 11:24:38.147280
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:24:44.623804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Just construct an instance of ActionModule class, no need to test anything else
    action_module = ActionModule(
        task=dict(action=dict(module_name='copy', args=dict(src='test', dest='test'))),
        connection=object(),
        play_context=PlayContext(),
        loader=object(),
        templar=object(),
        shared_loader_obj=None
    )
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:24:46.548465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task_vars=dict())
    assert isinstance(module, ActionModule)



# Generated at 2022-06-11 11:24:55.689041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = dict(name='testhost', port=22, ipv4='192.168.100.10')
    task = dict(name='file', action=dict(module='copy', args='{"dest":"/tmp/foo"}'))
    playcontext = PlayContext()

    def dummy_load_file_common_arguments(self):
        self._task.args['_original_basename'] = 'foo'
        self._task.args['content'] = '#!/bin/bash\necho Hello world'

    def dummy_load_file_common_arguments_2(self):
        self._task.args['_original_basename'] = 'bar'
        self._task.args['content'] = '#!/bin/bash\necho Hello world'

    tmp_path_stub = TempPath()
    tmp_path_stub

# Generated at 2022-06-11 11:25:00.512824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    utils = AnsibleModuleMock()
    task = AnsibleTaskMock()
    variable_manager = AnsibleVarsMock()
    source = "/home/gy/ansible_module_test/src/"
    dest = "/tmp/dest/"
    task.args = dict(src=source, dest=dest)
    am = ActionModule(utils, task, variable_manager)
    assert am is not None

# Generated at 2022-06-11 11:25:01.378944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:26:54.466969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for ActionModule class '''
    connection = FakeConnection()
    task = FakeTask()
    task.args = dict(src=None, dest=None, content=None)
    action_module = ActionModule(connection=connection, task=task, temper=None)
    action_module.setup = MagicMock()

    action_module.run(task_vars=dict())

# Generated at 2022-06-11 11:27:05.113851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config = dict(
        action_plugins=ActionModule.action_loader._action_plugins,
        connection_plugins=ConnectionModule.connection_loader._plugins,
        aliases={},
    )
    old_config = AnsibleConfig(**config)
    config = dict(
        forks=10,
        module_name="ping",
        module_path=["/Library/Python/2.7/site-packages/ansible/modules/core/"],
        pattern="*",
        remote_user="root",
        module_lang="C",
        become=False,
        become_method="sudo",
        become_user="root",
        check=False,
        diff=False,
        private_key_file="/Users/bob/.ssh/id_rsa",
        timeout=10
    )

# Generated at 2022-06-11 11:27:15.044936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(dict(WORKING_DIR='/home/myuser', ROLE_NAME='myrole'),
                          '/tmp/',
                          DataLoader(),
                          TaskQueueManager(),
                          '/tmp/',
                          'ActionModule'
                         )

    assert module._role_name is 'myrole'
    assert module._working_dir is '/home/myuser'
    assert module._result is None
    assert module._task_vars is None
    assert module._tmp is '/tmp/'
    assert module._tmppath is '/tmp/'
    assert module._templar is not None
    assert module._connection is not None
    assert module._play_context is not None

    assert module.FLAGS == module._templar._available_variables['ansible_module_flags']
    assert module.PARAMS

# Generated at 2022-06-11 11:27:16.444468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert True == False


# Generated at 2022-06-11 11:27:26.218885
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # <COMPONENT>/<CLASS>/<METHOD>
    from ansible.module_utils import basic
    from ansible_collections.ansible.legacy.plugins.modules.copy import ActionModule
    from ansible.utils.vars import combine_vars

    # Unit test for method run of class ActionModule
    # Required params:
    # src: Source path
    # dest: Destination path
    # Follows if a link would be followed
    # local_follow: Local path would be followed
    # Follows if a non-recursive copy were done
    # remote_src: Remote source path would be used
    # Required args:
    # src: Source path
    # dest: Destination path
    # Follows if a link would be followed
    # local_follow: Local path would be followed
    # Follows if a non-

# Generated at 2022-06-11 11:27:36.326071
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert not ActionModule(dict(), 'host', 'path', 'connection').supports_check_mode
    assert not ActionModule(dict(), 'host', 'path', 'connection').supports_async
    assert not ActionModule(dict(), 'host', 'path', 'connection').bypass_checks
    assert not ActionModule(dict(), 'host', 'path', 'connection').no_log
    assert ActionModule(dict(), 'host', 'path', 'connection').supports_async_timeout
    assert not ActionModule(dict(), 'host', 'path', 'connection').trusted_hosts

    assert isinstance(ActionModule(dict(), 'host', 'path', 'connection')._legal_inputs, set)
    assert isinstance(ActionModule(dict(), 'host', 'path', 'connection')._module_args_cache, dict)

# Generated at 2022-06-11 11:27:43.550933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup the module to be executed.
    module = 'copy'
    args = {}
    # Setup the action plugin to be tested.
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Test the constructor.
    assert action_plugin.module_name == module
    assert action_plugin._task.action == module
    assert action_plugin._task.args == args
    assert action_plugin._task.action == module

# Generated at 2022-06-11 11:27:53.670156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    shared_loader_obj = DictDataLoader({})
    tmp_path = "/tmp/ansible_file_payload.XXXXXX"
    ac = ActionModule(task=Task(), connection=Connection(shared_loader_obj), play_context=PlayContext(), loader=shared_loader_obj, templar=Templar(), shared_loader_obj=shared_loader_obj)
    assert ac
    ac = ActionModule(task=Task(), connection=Connection(shared_loader_obj), play_context=PlayContext(), loader=shared_loader_obj, templar=Templar(), shared_loader_obj=shared_loader_obj, SUDO_EXE=None, CACHE_PLUGIN_FILTERED_RESULTS=True, tmp_path=tmp_path)
    assert ac

# Generated at 2022-06-11 11:28:03.934427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   def _ActionBase__execute_module():
      raise Exception("NotImplementedError")
   def _ActionBase__execute_module_with_become():
      raise Exception("NotImplementedError")
   module = 'ActionModule'
   src = '/tmp/src'
   content = 'content'
   dest = '/tmp/dest'
   remote_src = False
   local_follow = True
   tmp = None
   task_vars = {}
   
   am = ActionModule(module, src, content, dest, remote_src, local_follow, task_vars )
   setattr(am, '_ActionBase__execute_module', _ActionBase__execute_module)
   setattr(am, '_ActionBase__execute_module_with_become', _ActionBase__execute_module_with_become)
   res

# Generated at 2022-06-11 11:28:12.876138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given: The ActionModule class with a valid instance of a HttpApi
    module = ActionModule(HttpApi('localhost', None))
    module._remove_tmp_path = lambda x: None
    module._execute_module = lambda x, **y: None
    module._remote_expand_user = lambda x: x
    module._find_needle = lambda x, y: y
    module._execute_remote_stat = lambda x, **y: None
    module._copy_file = lambda *x: None
    module._loader = Mock(path_exists_in_cwd=lambda x: False)
    module._connection = Mock(tmpdir='/tmp',
                              _shell='shell',
                              _shell_plugin='shell_plugin')

    # And: A valid task to use, with a list of paths