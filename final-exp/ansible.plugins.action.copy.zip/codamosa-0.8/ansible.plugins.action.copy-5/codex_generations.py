

# Generated at 2022-06-11 11:21:50.055917
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructor of FileModule
    file_obj = FileModule(runner)

    assert file_obj != None

# Generated at 2022-06-11 11:22:02.096608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    import __main__
    # Ansible v2.9.6 Compat
    # class SetModuleArgs(object):
    #     def __init__(self, dictargs=dict()):
    #         self.args = dictargs
    # task = Task()
    # set_module_args = SetModuleArgs
    task = Task()
    set_module_args = dict()
    task._role = dict()
    task.args = dict()
    task

# Generated at 2022-06-11 11:22:09.597406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init
    a = ActionModule(1, 2, 3)
    # test for default
    a.run()


# Generated at 2022-06-11 11:22:19.029299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize legacys region
    legacys = ActionModule('testhost', dict(action='test-action', module_name='test_module_name'))

    # Initialize module result
    module_result = dict(failed=False, changed=False, task_action='test_action')

    # Initialize module return
    module_return = dict(failed=False, changed=False, task_action='test_action')

    # Initialize task
    task = dict(args=dict(src='test_src', content='test_content', dest='test_dest', remote_src=True, local_follow=True))

    # Initialize task vars
    task_vars = dict()

    # Initialize tmp
    tmp = None

    # Get result
    result = legacys.run(tmp, task_vars)

   

# Generated at 2022-06-11 11:22:30.960337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    unit test method run of class ActionModule
    '''
    ansible.legacy.galaxy.api.ANSIBLE_VERSION = '2.5.7'

# Generated at 2022-06-11 11:22:42.982782
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:22:51.446013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='copy', src='source_path', dest='destination_path',),)
    module_name = 'copy'
    task_vars = dict()
    inject = dict()

    action_module = ActionModule(task, module_name, task_vars, inject)

    assert action_module._task == task
    assert action_module._connection == inject.get('connection')
    assert action_module._play_context.become == inject.get('become')
    assert action_module._play_context.become_method == inject.get('become_method')
    assert action_module._play_context.become_user == inject.get('become_user')


# Generated at 2022-06-11 11:23:02.422360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import os
    import shutil
    from ansible.utils.path import unfrackpath
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    class CallbackModule(object):
        """
        Callbacks for original ansible
        """
        def __init__(self):
            self.events = []

        def v2_runner_on_ok(self, result):
            self.events.append(result)

        def v2_runner_on_failed(self, result, ignore_errors=False):
            self.events.append(result)


# Generated at 2022-06-11 11:23:08.778532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'action'
    source = None
    content = None
    dest = 'Test-Src'
    remote_src = None
    local_follow = None
    tmp = None
    task_vars = None
    temp_action = ActionModule(self._task, self._connection, self._play_context, play_context, loader, templar, shared_loader_obj)
    temp_action.run(tmp, task_vars)


# Generated at 2022-06-11 11:23:09.556393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 11:24:01.646543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Try to create an object and ensure required exceptions are thrown
    try:
        ActionModule()
    except RuntimeError as err:
        assert err.args[0] == "'ActionModule' object has no attribute '_task'"
    # Create an object
    obj = ActionModule(task=Task())
    # Try to add an attribute
    try:
        obj.foo = 1
    except AttributeError as err:
        assert err.args[0] == "'ActionModule' object has no attribute 'foo'"
    # Try to call a method
    try:
        obj.run()
    except TypeError as err:
        assert err.args[0] == "run() missing 2 required positional arguments: 'tmp' and 'task_vars'"
    # Try to call a method without arguments
    # Should fail because of missing tmp argument

# Generated at 2022-06-11 11:24:04.796218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module._connection, Connection)
    assert isinstance(action_module._task, Task)


# Generated at 2022-06-11 11:24:16.213036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a test of ActionModule class constructor.
    """
    # execute_module function is mocked, so it won't run real code.
    # Mocked functions are just passing through all the arguments without
    # any modification.
    # If this test fails, then probably _execute_module function
    # does not properly pass some arguments.

# Generated at 2022-06-11 11:24:17.447796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    raise NotImplementedError

# Generated at 2022-06-11 11:24:21.401667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(
        dest='/tmp/foo.txt',
        src='/tmp/bar.txt'
    )
    set_module_args(task_args)
    my_obj = ActionModule()
    #my_obj.run()



# Generated at 2022-06-11 11:24:29.156087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We setup our task (we can reuse this)
    task_vars = {'ansible_ssh_user': 'vagrant', 'ansible_ssh_pass': 'vagrant', 'ansible_ssh_host': 'localhost'}
    task_vars['ansible_ssh_port'] = 2222
    task_vars['ansible_ssh_private_key_file'] = '.vagrant/machines/default/virtualbox/private_key'

    # We create our module instance

# Generated at 2022-06-11 11:24:40.714279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = "copy"
    category = 'test_category'
    task = Task()

    set_loader(DataLoader())
    set_connection_loader('local', 'ansible.plugins.connection.local.Connection')
    set_inventory(InventoryManager(loader=get_loader(), sources=''))
    get_loader().set_categories({module_name: category})
    get_loader().load_plugin(module_name, category)
    connection = get_connection('local')
    connection.set_task_uuid('task_uuid')

    action = ActionModule(connection=connection, task=task)


# Generated at 2022-06-11 11:24:51.075236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    play_context = PlayContext()
    play_context.check_mode = False
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '1.2.3.4'
    task = Task(name='fetch_test', action='fetch', task_vars=dict(), play_context=play_context)
    action_module = ActionModule(task, dict(src='test_src', dest='test_dest'))
    assert action_module.task_vars == dict()
    assert action_module._task.action == 'fetch'
    assert action_module._connection.become == False
    assert action_module._task.args['src'] == 'test_src'

# Generated at 2022-06-11 11:24:52.184001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 11:25:00.103246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'setup'
    task_args = dict(filter='ansible_distribution*')
    task_vars = {}
    wrap_async = False
    task_path = '/a/b/c'
    runner = object()

    action = ActionModule(module_name, task_args, task_vars, wrap_async, task_path, runner)

    assert action._task.action == 'setup'
    assert action._task.args == task_args
    assert action._task.vars == task_vars
    assert action._task.async_val == wrap_async
    assert action._task.path == task_path
    assert action._task.runner == runner

# Generated at 2022-06-11 11:26:52.266157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {"ansible_user": "jdoe", "ansible_my_var": "my_var_value", "ansible_ssh_pass": "secret",
                 "ansible_connection": "local"}
    module_args = {"state": "directory", "path": "/tmp", "mode": "0755"}
    task = Task(dict(action=dict(module='file', args=module_args)), task_vars)
    task.args = module_args
    action = ActionModule(task, task_vars)
    assert action._task.action == 'file'
    assert action._task.args == {'path': '/tmp', 'state': 'directory', 'mode': '0755'}

# Generated at 2022-06-11 11:27:01.864188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeShell(object):
        def path_has_trailing_slash(self, path):
            return path.endswith('/')

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.args = dict(
                dest='/etc/test.conf',
                src='test/test.conf',
                mode='0644'
            )

    class FakeTask(object):
        def __init__(self, *args, **kwargs):
            self.args = dict(
                dest='/etc/test.conf',
                src='test/test.conf',
                mode='0644'
            )

    class FakeConnection(object):
        def __init__(self, *args, **kwargs):
            self._shell = FakeShell()
            self._shell

# Generated at 2022-06-11 11:27:12.967332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {
        'remote_tmp': '/tmp',
        'src': 'some/src/file',
        'dest': 'some/dest/file',
        'local_follow': False
    }
    task_args = dict(
        _ansible_check_mode=False,
        _ansible_diff=False,
        _ansible_keep_remote_files=False,
        _ansible_remote_tmp='/tmp',
        _ansible_verbosity=0,
        action='some/src/file',
        follow=False,
        local_follow=False,
        original_basename=None,
        original_checksum=None,
        original_path=None,
        src='some/src/file',
        dest='some/dest/file',
        synchronize=None
    )
    connection

# Generated at 2022-06-11 11:27:23.289238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    actionModule_instance = ActionModule()
    # Create an instance of class AnsibleTaskVars for the function _execute_module()
    ansibleTaskVars_instance = AnsibleTaskVars()
    # Set instance attributes of ansibleTaskVars_instance
    ansibleTaskVars_instance.name = 'AnsibleTaskVars'
    # Create an instance of class ShellModule for the function _execute_module()
    shellModule_instance = ShellModule()
    # Set instance attributes of shellModule_instance
    shellModule_instance.name = 'ShellModule'
    # Create an instance of class AnsibleConnection for the function _execute_module()
    ansibleConnection_instance = AnsibleConnection()
    # Set instance attributes of ansibleConnection_instance

# Generated at 2022-06-11 11:27:26.976018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS={'src': 'source', 'dest': 'destination'}))
    assert action_module._task.args['src'] == 'source'
    assert action_module._task.args['dest'] == 'destination'

# Unit tests for _create_remote_copy_args

# Generated at 2022-06-11 11:27:37.035055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule.
    Requires pytest and a running ansible runtime environment.
    """
    from ansible.module_utils._text import to_bytes
    # Initialize a task and a connection.
    connection_info = {'network_os': 'default'}
    module_name = 'file'
    task = dict(action='copy', src=__file__, dest='/tmp/ansible_test')
    task_vars = dict(default_network_os='default',
                     network_os='default')
    # Create a new instance of module ActionModule with the task, connection_infos and task_vars

# Generated at 2022-06-11 11:27:45.075408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = Connection(PseudoConnection())
    conn._shell.path_has_trailing_slash = lambda x: False
    task = Task(action=dict(module=["ansible.legacy.copy"]))
    am = ActionModule(task, conn)
    # TODO: Must mock away stuff in module_utils/basic.py (e.g. AnsibleFileNotFound and AnsibleActionFail)
    # We could use the unittest.mock library if we're comfortable with this, but we're not.
    #am.run(tmp=None, task_vars=None):
    pass


# Generated at 2022-06-11 11:27:55.258624
# Unit test for constructor of class ActionModule
def test_ActionModule():  # pylint: disable=too-many-statements
    ''' Unit test for constructor of class ActionModule '''
    action_base = ActionBase()
    action_base._task_vars = dict(
        foo='foo',
        bar="bar",
        baz="baz",
        remote_tmp='$HOME/.ansible/tmp',
        remote_username='bob',
    )
    action_base._low_level_shell_stdout = 'low_level_shell_stdout'
    action_base._low_level_shell_stderr = 'low_level_shell_stderr'
    action_base._shell = 'shell'

# Generated at 2022-06-11 11:28:00.806353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create temp file.
    fd, dest = tempfile.mkstemp(prefix='test_', dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    f.close()

    # Write the content
    content = 'abcdefg'
    f = open(dest, 'wb')
    f.write(content)
    f.close()

    def _create_task(originator, module, args):
        class Task:
            def __init__(self, originator, module, args):
                self.originator = originator
                self.args = args
                self.module = module
                self.action = module.ActionModule(self)

        return Task(originator, module, args)

    # create the task with module and action_module

# Generated at 2022-06-11 11:28:10.856487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with legacy
    module = ActionModule({'action': 'copy', '_uses_shell': False, '_uses_delegate': False, '_raw_params': 'copy'},
                          connection_info={'network_os': 'linux'})
    assert module.__dict__['_module_class'] == 'copy'

    # Test with ansible.legacy
    module = ActionModule({'action': 'ansible.legacy.copy', '_uses_shell': False, '_uses_delegate': False, '_raw_params': 'ansible.legacy.copy'},
                          connection_info={'network_os': 'linux'})
    assert module.__dict__['_module_class'] == 'copy'

    # Test with ansible.netcommon.network_template