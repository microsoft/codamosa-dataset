

# Generated at 2022-06-11 11:22:01.684581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dflt_cfg = configparser.ConfigParser()
    dflt_cfg.read('test/ansible.cfg')
    dflt_cfg.set('defaults', 'retry_files_enabled', 'False')
    dflt_cfg.set('defaults', 'roles_path', 'test/ansible_test/roles')

    task = Task()
    task.init_from_dict({
        'name': 'test',
        'action': 'test',
        'args': {},
        'delegate_to': 'test',
        'delegate_facts': True,
        'register': 'test',
    })

    conn_info = ConnectionInfo(dflt_cfg.get('defaults', 'remote_user'), 'test', None)


# Generated at 2022-06-11 11:22:13.441623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    When testing ActionModule(), we create a fake connection and a fake loader.
    We also check every error conditions
    to make sure the constructor of ActionModule() return None properly.
    """
    # Create a dummy loader and connection
    module_loader = DictDataLoader({})
    conn = Connection(None)
    # Create test errors
    non_action_task = dict(action='this is not an action module')
    no_action_task = dict()

    # Check with non-action module task
    test_action = ActionModule(task=non_action_task, connection=conn,
                               _play_context=PlayContext(),
                               loader=module_loader, templar=None)
    assert test_action is None

    # Check with no action module

# Generated at 2022-06-11 11:22:22.626269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task(object):
        def __init__(self):
            self.args = dict()
            self.action = 'ActionModule'
            self.async_val = -1
            self.delegate_to = 'localhost'
            self.become_user = 'root'
            self.environment = dict()

    class Host(object):
        def __init__(self):
            self.name = 'localhost'
            self.vars = dict()
            self.port = 22
            self.ansible_connection = 'ssh'
            self.ansible_ssh_common_args = ''
            self.ansible_ssh_common_args_nopty = ''

            self.ansible_ssh_host = '127.0.0.1'
            self.ansible_ssh_user = 'root'

# Generated at 2022-06-11 11:22:34.843039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.dataloader import DataLoader

    # test creating an ActionModule without task or connection
    mock_task = MagicMock()
    mock_ds = MagicMock()
    test_am = ActionModule(mock_task, mock_ds, 'local', 'copy')

    assert_match = assert_regex if PY3 else assert_regexp_matches
    assert_match(to_text(test_am), r"Ansible ActionModule .* invoked by .*")
    assert(test_am.result is not None)

    # test creating an ActionModule with a task and connection

# Generated at 2022-06-11 11:22:36.844986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-11 11:22:47.216566
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:22:58.548468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initialize class object
    actionModule = ActionModule()

    # initialize the parameters of the class object
    actionModule.task = dict()
    actionModule.task['action'] = dict()
    actionModule.task['action']['args'] = dict()
    actionModule.task['args'] = dict()
    actionModule.task['action']['args']['src'] = "test.txt"
    actionModule.task['action']['args']['dest'] = "test.txt"
    actionModule.task['action']['args']['content'] = None
    actionModule.task['action']['args']['remote_src'] = True
    actionModule.task['action']['args']['local_follow'] = True
    actionModule.connection = dict()

# Generated at 2022-06-11 11:23:09.250450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible import constants as C

    ######################################################################
    # Initialize objects for test
    ######################################################################
    C.HOST_KEY_CHECKING = False
    task = Task()
    task._role = Role()

# Generated at 2022-06-11 11:23:18.029027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_connection='local',
        ansible_module_name='copy',
        ansible_module_args=dict(
            src='/src/path',
            dest='/dest/path')
    )
    # "connection" is really non-optional, but we can't resolve the
    # connection plugin without an inventory, so just bypass
    # the param check here
    module_executor = ActionModule(
        PlayContext(runner_ident=''),
        task_vars,
        [],
        "",
        'copy',
        'local',
        {},
        True,
        'debug'
    )
    assert isinstance(module_executor, ActionModule)
    assert module_executor._task.action == 'copy'

# Generated at 2022-06-11 11:23:26.578058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = None
    content = None
    dest = None
    remote_src = False
    local_follow = True
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor import task_queue_manager
    from ansible.executor import playbook_executor
    from ansible.inventory import Inventory
    from ansible import context
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    context._init_global_context(loader=None)
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'testhost': {}}}
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
   

# Generated at 2022-06-11 11:24:21.058989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:24:29.008017
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:24:40.559700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor with valid values
    try:
        # Create a task.
        task_ds = dict()
        task_ds['action'] = dict()
        task_ds['action']['__ansible_module__'] = 'ansible.legacy.copy'
        # Create play context.
        play_context = PlayContext()
        test_action_module = ActionModule(task=Task.load(task_ds), connection=Connection(play_context), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    except:
        test_action_module = None
    assert test_action_module is not None

    # constructor with invalid values

# Generated at 2022-06-11 11:24:50.944073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    stub_source = {'key1': 'value1', 'key2': 'value2'}
    stub_task = dict(action=dict(module_name='test',module_args=dict(src=stub_source)))
    stub_connection = 'ansible.plugins.connection.Connection'
    stub_loader = 'ansible.parsing.dataloader.DataLoader'
    stub_templar = 'ansible.template.Templar'

    action_module = ActionModule(stub_task, stub_connection, stub_loader, stub_templar)

    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module._task, dict)
    assert action_module._task == stub_task
    assert action_module._connection == stub_connection
    assert action_module._loader == stub

# Generated at 2022-06-11 11:24:56.974493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.__dict__['_remove_tmp_path'] = lambda self: None
    action_module.__dict__['_execute_module'] = lambda self, module_name, module_args, task_vars: {}
    action_module.__dict__['_remove_tempfile_if_content_defined'] = lambda self, content, content_tempfile: None
    action_module.__dict__['_create_content_tempfile'] = lambda self, content: 'content_tempfile'
    action_module.__dict__['_task'] = MagicMock(spec=['args'])
    action_module._task.args = {}
    action_module.__dict__['_connection'] = MagicMock(spec=['_shell'])
    action_module._connection._shell = MagicM

# Generated at 2022-06-11 11:25:06.863892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ('ansible.legacy.actions.copy.ActionModule')
    module_args = {'src': ['file1', 'file2'], 'dest': '/tmp/dest'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    kwargs = {'task': None, 'connection': None, 'play_context': None, 'loader': None, 'templar': None, 'shared_loader_obj': None}
    assert action_module.__class__.__name__ == m
    assert action_module.action_loader.action_plugin_loader._prefix == 'ansible.legacy.actions'
    assert action_module.action_loader.action_plugins == {}
    assert action_module.action

# Generated at 2022-06-11 11:25:15.900441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = {
        "hostname": "localhost",
        "port": 22,
        "username": "root",
        "password": "123456"
    }
    con = Connection(host)

    task = {
        "dest": "/root/a.txt",
        "src": "data/a.txt",
        "remote_src": False,
        "local_follow": True,
        "copy": {
            "local_action": {
                "args": {},
                "module": "copy"
            }
        }
    }
    task_vars = {}

    am = ActionModule(con, task, task_vars)

    result = am.run(None, task_vars)
    assert 'changed' in result
    assert result['changed'] == True
    assert 'dest' in result
   

# Generated at 2022-06-11 11:25:20.608964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _task = Mock()
    _task.args = {'src': 'somesrc'}
    _task.action = 'copy'

    action_module = ActionModule(_task, connection=Mock())
    assert action_module._task == _task
    assert action_module.args['src'] == 'somesrc'
    assert action_module.args['action'] == 'copy'



# Generated at 2022-06-11 11:25:24.196063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task to use for the test.
    task = Mock()

    # Create an instance of the module class to test.
    module_instance = ActionModule(task)

    # Check the task was assigned to the instance.
    assert task == module_instance._task


# Generated at 2022-06-11 11:25:26.035299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    action_plugin.ActionModule has no unit tests.
    '''


# Generated at 2022-06-11 11:27:20.051376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(Connection(), 'test', {})
    assert module is not None
    assert module._task.action == 'test'
    assert module._task.args == {}


# Generated at 2022-06-11 11:27:28.306182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Patch the module inside the module_utils/facts/ folder
    # so that it is available for module code execution.
    from ansible.module_utils.facts import system
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import default_collectors
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    import ansible.constants as C

    display = Display()
    Options = basic._Ans

# Generated at 2022-06-11 11:27:33.477945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = MagicMock()
    task = MagicMock()
    connection = MagicMock()
    task_vars = MagicMock()
    loader = MagicMock()
    templar = MagicMock()

    action_module = ActionModule(host, task, connection, task_vars, loader, templar)
    assert action_module._connection is connection

# Generated at 2022-06-11 11:27:34.684229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass #TODO


# Generated at 2022-06-11 11:27:36.061508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)


# Generated at 2022-06-11 11:27:46.209892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup Module Arguments
    module_args = dict(src=dict(type='str', required=True), dest=dict(type='str', required=True), mode=dict(type='raw'), owner=dict(type='raw'), group=dict(type='raw'))
    # build arguments
    arguments = dict(remote_src=dict(type='bool', default=False, aliases=['copy']), local_follow=dict(type='bool', default=True), remote_user=dict(type='str'), checksum=dict(type='str'), backup=dict(type='bool', default=True), original_basename=dict(type='str'), content=dict(type='str'), follow=dict(type='bool', default=False), force=dict(type='bool', default=True), directory_mode=dict(type='raw'))
    # arguments.update

# Generated at 2022-06-11 11:27:56.480700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    # Load fixture for mocking purpose
    module_loader = DictDataLoader()
    module_loader.set_basedir(os.path.join(os.path.dirname(__file__), '..', '..', 'plugins', 'action'))

    collection_loader = MockCollectionLoader()
    collection_loader._legacy_action_plugins = {'copy': module_loader}

    fake_loader = MockLoader(collection_loader)
    fake_connection = MockConnection(fake_loader)

    fake_task = Task()
    fake_task._role = Mock()
    fake_task._role.get_task_deps = lambda x: []

# Generated at 2022-06-11 11:28:06.585156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # pass

    # Mock class for object
    mock_object = MagicMock()
    # Mock class for ActionBase
    mock_ActionBase = MagicMock(spec=ActionBase)
    # Mock class for ActionModule
    mock_ActionModule = MagicMock(spec=ActionModule, _task=mock_object, _play_context=mock_object, loader=mock_object, _connection=mock_object, _environ_suffix=mock_object, _loader_hashes=mock_object, _loader_paths=mock_object, _shell=mock_object)
    # Mock class for AnsibleError
    mock_AnsibleError = MagicMock(spec=AnsibleError)
    # Mock class for Ansible

# Generated at 2022-06-11 11:28:09.524234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_module = AnsibleModule("copy")
    results = ActionModule.run(ansible_module)
    assert results['msg'] == 'A required parameter was not passed in the task or config: src or content'

# Generated at 2022-06-11 11:28:12.966075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    executable   = 'ansible-playbook'
    module_name  = 'copy'
    
    ansible_module = None
    ActionModule(ansible_module, tmp, task_vars)
    return 0
test_ActionModule_run()

#Unit test for execute_module of class ActionModule