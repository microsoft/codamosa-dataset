

# Generated at 2022-06-11 11:21:51.018037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of ActionModule class, no exception should be thrown
    my_action_module = ActionModule(connection=None, task=None, loader=None, templar=None)
    assert my_action_module


# Generated at 2022-06-11 11:21:55.293973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test constructor of class ActionModule
    '''

    # Fire function again to test whether instance is created properly
    action_module = ActionModule(None, None)
    assert action_module is not None, "Unable to create instance of class ActionModule"


# Generated at 2022-06-11 11:22:07.656168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if six.PY3:
        import unittest
        from ansible.playbook.task import Task

        from ansible.playbook.task_include import TaskInclude

        class TestActionModule(unittest.TestCase):

            def setUp(self):
                pass

            def tearDown(self):
                pass

            @patch.object(ActionModule, 'run')
            def test_ActionModule_init_local_action(self, run_mock):
                my_task = Task()
                my_task.action = 'copy'
                my_task.local_action = 'copy'

                my_action = ActionModule(my_task, connection=None)
                assert isinstance(my_action, ActionModule)
                assert my_action._task == my_task
                assert my_action._connection is None

# Generated at 2022-06-11 11:22:14.623127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = './test-data/test_copy_module.py'
    content = None
    dest = 'test_copy_module.py'
    remote_src = False
    local_follow = False

    # Create the task
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    task = Task()
    task._role = None
    task.context = play_context
    task._supports_async = False
    task.action = 'copy'
    task.args = dict(src=source, content=content, dest=dest, remote_src=remote_src, local_follow=local_follow)
    
    # Set up invenotry
    from ansible.inventory import Inventory

# Generated at 2022-06-11 11:22:24.091010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # c.p.m.file_common.ActionModule.run()
    # No source and content is None
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins import filter_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 11:22:36.429817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simple test of module.
    module = ActionModule(task=dict(module_name='copy', args=dict(src='src', dest='dest')),
                          connection=None,
                          _play_context=play_context.PlayContext(),
                          loader=DictDataLoader(),
                          templar=None,
                          shared_loader_obj=None)
    # ActionModule calls _execute_module() with module_name as an argument.
    # _execute_module() only operates on task_vars and does not use module_name.
    module._execute_module = lambda module_name, module_args, task_vars: task_vars
    module._play_context.check_mode = True
    assert module.run(task_vars=dict(a='b')) == dict(a='b')

#

# Generated at 2022-06-11 11:22:42.181657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks
    task_vars = {}
    tmp = None

    # Run test
    t = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = t.run(tmp, task_vars)

    # Verify results
    assert result == {}


# Generated at 2022-06-11 11:22:45.850085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=PlayContext(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None
    )

    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 11:22:47.036039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No longer used by Ansible, so no unit test are required.
    pass

# Generated at 2022-06-11 11:22:58.301934
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:23:50.139213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = random.randint(0, 255)
    dir_path = 'test_ActionModule_run_dir_path'
    dir_path_len = len(dir_path)
    remote_dir = 'test_ActionModule_run_remote_dir'
    result = AnsibleModuleTestResult(remote_dir)

    # Create tmp directory to be used
    os.mkdir(dir_path)
    # Create instance of our class to be tested
    # and do the test
    x = ActionModule(None, random.randint(0, 255), dir_path)
    x.run(tmp, {'remote_dir': remote_dir})
    # Check the result
    assert result.changed == x._result.changed
    assert result.msg == x._result.msg

# Generated at 2022-06-11 11:23:59.857569
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeVarsModule():
        ''' This is only a fake module to test Action Module'''
        def __init__(self):
            self.data = {'_ansible_check_mode': True}

        def vars(self):
            return self.data

    # Check no args supplied
    with pytest.raises(Exception) as exec_info:
        tmp = ActionModule(None, None, None, None, None, None)
    assert 'task or connection or play_context or loader or templar or shared_loader object is undefined' in str(exec_info)

    # Check no connection supplied
    task = AnsibleTask()
    with pytest.raises(Exception) as exec_info:
        tmp = ActionModule(task, None, None, None, None, None)

# Generated at 2022-06-11 11:24:12.167054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options(object):
        def __init__(self, verbosity=None, listhosts=None, module_path=None, forks=None,
                     remote_user=None, private_key_file=None, ssh_common_args=None,
                     ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                     become=None, become_method=None, become_user=None, verbosity_level=None,
                     check=None, start_at_task=None):
            self.verbosity = verbosity
            self.listhosts = listhosts
            self.module_path = module_path
            self.forks = forks
            self.remote_user = remote_user
            self.private_key_file = private_key_file
            self.ssh_

# Generated at 2022-06-11 11:24:22.596848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test constructor of class ActionModule
    """
    import ansible.playbook
    import ansible.inventory
    import ansible.runner
    from ansible.callbacks import DefaultRunnerCallbacks

    class Task(object):
        """ Minimalistic Ansible Task used for ActionModule unit test """
        def __init__(self, play_context, remote_user=None, remote_pass=None, remote_port=None, private_key_file=None, connection='smart', module_name='copy', module_args='', sudo_user=None, sudo=False, forks=5, become_method=None, become_user=None, no_log=False, environment=None,
                     check=False, diff=False, transport='ssh'):
            class TaskVars(object):
                pass
            self.vars = TaskVars()

# Generated at 2022-06-11 11:24:23.211099
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-11 11:24:24.718562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_mod = ActionModule(None, None, None, None)
    assert type(action_mod) == ActionModule

# Generated at 2022-06-11 11:24:26.002481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test needs to be created
    raise Exception("Unit test not implemented")


# Generated at 2022-06-11 11:24:37.549920
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup mocks
    # Using mocks here because we need to test the results of methods
    m_ActionBase_run = MagicMock(return_value='test')
    m_get_task_vars = MagicMock(return_value='test')
    m_b_to_raw = MagicMock(return_value='test')
    m_b_to_text = MagicMock(return_value='test')

    # Setup variables
    task_vars = dict()
    source = dict()
    content = dict()
    dest = dict()
    remote_src = dict()
    local_follow = dict()
    module_return = dict()
    source_full = dict()
    source_rel = dict()
    content_tempfile = dict()
    follow = dict()
    paths = dict()
    dir_path

# Generated at 2022-06-11 11:24:48.649938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    args = dict()
    tmp = tempfile.mkdtemp(suffix='ansible-local')

# Generated at 2022-06-11 11:24:49.678760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-11 11:26:29.782424
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:26:34.355154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """test the ActionModule constructor"""

    task = {"action": {}}
    task_vars = {}

    adhoc = ActionModule(task, task_vars, module_defaults={"ANSIBLE_MODULE_ARGS": {}})

    assert adhoc._task == task
    assert adhoc._task_vars == task_vars
    assert adhoc._templar == task_vars

# Generated at 2022-06-11 11:26:38.948743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test first constructor call to verify that '_uses_shell' is set to True.
    action_module = ActionModule({'shell': True})
    assert action_module._uses_shell is True

    # Test second constructor call to verify that '_uses_shell' is set to False.
    action_module = ActionModule({'shell': False})
    assert action_module._uses_shell is False

# Generated at 2022-06-11 11:26:40.232351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    new_copy = ActionModule()
    assert new_copy is not None

# Generated at 2022-06-11 11:26:50.195556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_python_interpreter='/usr/bin/python',
        remote_user='toto',
        remote_pass='password',
        ansible_connection='winrm',
        ansible_winrm_server_cert_validation='ignore',
        ansible_winrm_transport='basic'
    )
    src = 'AnsiballZ_ActionModule.py'
    dest = 'C:/Windows/Temp/AnsiballZ_ActionModule.py'
    content = dict(
        ansible_module_generated_extras={
            'test': 'extras',
            'ANSIBLE_REMOTE_TEMP': '/tmp',
            'ANSIBLE_MODULE_ARGS': {}
        },
        ansible_module_generated_warnings=[]
    )


# Generated at 2022-06-11 11:26:57.449056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock a connection
    connection = mock.MagicMock()

    # Mock a task
    task = mock.MagicMock()
    task.args = dict()

    # Construct an ActionModule object
    action_module = ActionModule(connection=connection, task=task)

    return action_module

if __name__ == "__main__":
    # Construct an ActionModule object
    action_module = test_ActionModule()
    # Construct the path to the tmp directory
    tmp_path = "/home/dnelson/tmp"
    action_module._remove_tmp_path(tmp_path)

# Generated at 2022-06-11 11:27:02.663968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action

    action_plugin = ansible.plugins.action.ActionModule(
        task=dict(action=dict(module_name='copy', module_args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    action_plugin.run()
    return

# Generated at 2022-06-11 11:27:13.284241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    module_context = {}

    class Mock(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __getitem__(self, name):
            return self.__dict__[name]

        @staticmethod
        def update(key, value):
            module_context.update({key: value})

        @staticmethod
        def setdefault(key, value):
            module_context.setdefault(key, value)

        @staticmethod
        def get(key, value):
            if key in module_context:
                return module_context[key]
            else:
                return value

        @staticmethod
        def keys():
            return module_context.keys()

        @staticmethod
        def items():
            return module_context.items()



# Generated at 2022-06-11 11:27:23.631123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for the file module. '''
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    my_task = Task()
    my_task.name = 'setup'
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = C.DEFAULT_REMOTE_USER
    play_context.password = C.DEFAULT_REMOTE_PASS
    play_context.port = 22
    play_context.become = False
    play_

# Generated at 2022-06-11 11:27:32.787393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock object
    mock_task = Mock()
    mock_task.args = {}
    mock_task.args['content'] = 'foo'
    mock_task.args['dest'] = 'foo'
    mock_task.args['local_follow'] = 'foo'
    mock_task.args['remote_src'] = 'foo'
    mock_task.args['src'] = 'foo'
    mock_task.args['checksum'] = 'foo'
    mock_task.args['mode'] = 'foo'
    mock_task.args['original_basename'] = 'foo'
    mock_task.args['selevel'] = 'foo'
    mock_task.args['serole'] = 'foo'
    mock_task.args['setype'] = 'foo'