

# Generated at 2022-06-11 11:21:51.331147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Test method run of class ActionModule.
    '''
    # Initializing method objects
    module_test = ActionModule(loader=None, templar=None, shared_loader_obj=None)

    # Test case: normal case,
    # Test output: return value for method run with arguments tmp, task_vars,
    # Test result: expected results
    module_test.run(tmp=None, task_vars=None)

    # Test case: raised AnsibleError exception,
    # Test output: ret

# Generated at 2022-06-11 11:21:53.141200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule()

    assert isinstance(test_action_module, ActionModule)


# Generated at 2022-06-11 11:22:05.559935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    sources = [
        "test.txt",
        "subdirectory/test2.txt",
        "subdirectory/subsubdirectory/test3.txt"
    ]

    # Mock a task

# Generated at 2022-06-11 11:22:11.674187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.playbook.play_context as play_context

    connection = FakeConnection()

    task = FakeTask()
    task_ds = dict(dest='/usr/share/myapp', src='myapp.tar.gz')
    task.vars = dict()
    task.args = task_ds

    play_context = play_context.PlayContext()
    play_context.become = False
    play_context._output_callback = cli.CLI.display

# Generated at 2022-06-11 11:22:20.291085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = tempfile.mkdtemp()


# Generated at 2022-06-11 11:22:29.425439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setup a fake task for testing
    class FakeActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass
    task = dict(action=dict(module_name='fake', module_args=dict()))
    is_local = False
    task_vars = dict()

    # Call the constructor
    action = FakeActionModule(task, is_local, task_vars)

    # Test if it's as expected
    assert action.task == task
    assert action._task == task
    assert action._is_local == is_local
    assert action._connection is None

# Generated at 2022-06-11 11:22:33.713446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict(), dict())
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is not None
    assert module._templar is not None

# Generated at 2022-06-11 11:22:45.154315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task(object):
        def __init__(self):
            self.args = dict(src='a', dest='b')

    class Runner(object):
        def __init__(self):
            self.action_plugins_path = None
            self.task_vars = None

    class PlayContext(object):
        def __init__(self):
            self.remote_addr = "192.168.0.1"

    class Options(object):
        def __init__(self):
            self.connection = "ssh"
            self.module_path = None
            self.forks = 10
            self.become = True
            self.become_method = "sudo"
            self.become_user = "root"
            self.check = False
            self.diff = False

    # Create the AnsibleConnection


# Generated at 2022-06-11 11:22:46.957347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'args': {}}, shared_loader_obj={}, connection={})
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:22:57.313790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = dict(
        default_tempfile_path = '~/.ansible/tmp',
        index_full = [{'path': '/home/ansible/f1', 'name': 'f1'}, {'path': '/home/ansible/d1/f2', 'name': 'f2'}],
        index_partial = [{'path': '/home/ansible/f1', 'name': 'f1'}])
    task_vars = dict(
        playbook_basedir = '/home/ansible')
    action_module = ActionModule(None, config, task_vars)
    print("ActionModule: ")

# Generated at 2022-06-11 11:23:48.356521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:23:58.290500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init action module class
    action_module = ActionModule()
    # Init task class
    action_module._task = Task()
    # Init connection class
    action_module._connection = Connection()
    # Init loader module
    action_module._loader = DataLoader()
    # Init play_context module
    action_module._play_context = PlayContext()
    # Init play_context module
    action_module._templar = Templar()

    # Init target src path
    src = '/tmp/dup/action_module_test'
    # Init target dest path
    dest = '/tmp/dup/action_module_test_dest'
    # Init empty task vars variable
    task_vars = {}

    # Create a files and directories
    os.mkdir(src)
    os.mkdir(dest)

# Generated at 2022-06-11 11:24:00.827820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    a = AnsibleActionModule()
    assert_equal(a.__doc__, m.__doc__)



# Generated at 2022-06-11 11:24:12.786182
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    for arg in [
        'src',
        'dest',
        'directory_mode',
        'original_basename',
        'content',
        'copy',
        'mode',
        'recursive',
        'backup',
        'force',
        'setype',
        'selevel',
        'serole',
        'seuser',
        'seuser',
        'serole',
        'selevel',
        'setype',
        'seuser',
        'serole',
        'selevel',
        'setype',
        'unsafe_writes',
        '_backup_name',
        'remote_src',
        'local_follow',
    ]:
        assert arg in action_module._available_arguments

# Generated at 2022-06-11 11:24:13.824304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-11 11:24:14.899525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-11 11:24:25.149167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = module.ModuleExecutor(connection=mock.Mock(),
                              async_jid=None,
                              inject=None,
                              complex_args=None,
                              sudo_user=None,
                              sudoable=None,
                              module_name='ansible.legacy.file',
                              task_uuid='uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu',
                              diff=False,
                              become_method=None,
                              become_user=None,
                              become_password=None,
                              become_flags=None,
                              task_vars={},
                              args={})
    test_action_module = ActionModule(m)


# Generated at 2022-06-11 11:24:26.002849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 11:24:37.447254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of class ActionModule
    my_ActionModule = ActionModule()
    # get a result of _create_remote_dirs
    result = my_ActionModule._create_remote_dirs('/tmp')
    # get a result of _build_needle_search_paths
    result = my_ActionModule._build_needle_search_paths()
    # get a result of _create_remote_copy_args
    result = my_ActionModule._create_remote_copy_args()
    # get a result of _execute_remote_stat
    result = my_ActionModule._execute_remote_stat()
    # get a result of _execute_module
    result = my_ActionModule._execute_module()
    # get a result of _find_needle
    result = my_ActionModule._find_needle()


# Generated at 2022-06-11 11:24:45.878056
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # # run method is our entry point into the plugin.
    #    See the documentation on the module class to see what other methods
    #    are available.
    #

    # AnsibleModule.run is the way an action plugin should execute
    result = ansible_module.run(
        task_vars={'ansible_check_mode': False},
        tmp=tempfile.mkdtemp(),
    )
    # AnsibleModule.exit_json is how you return data back to ansible
    ansible_module.exit_json(**result)


# Generated at 2022-06-11 11:26:27.470552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_name = 'copy'
    path = '/path/to/copy.py'
    path_data = dict()
    my_action_module = action_plugin.ActionModule(action_name, path, path_data)
    assert my_action_module.action == action_name
    assert my_action_module.name == action_name
    assert my_action_module.path == path
    assert my_action_module.path_data == path_data
    assert my_action_module.task == None
    assert my_action_module.task_vars == None
    assert my_action_module.loader == None
    assert my_action_module.connection == None
    assert my_action_module.play_context == None
    assert my_action_module.shared_loader_obj == None
    assert my_action_module

# Generated at 2022-06-11 11:26:36.596417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    import ansible.executor.task_queue_manager
    from ansible.executor.powershell.manager import ActionModule as powershell_action_module
    from ansible.executor.connection_info import ConnectionInformation
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Create a loader
    loader = DataLoader()

    # Create an inventory
    inventory = InventoryManager(loader=loader, sources=[])

    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a task result

# Generated at 2022-06-11 11:26:46.148688
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Set up task, loader and templar to use in the module.
    class Mock_task(object):
        def __init__(self, args=None):
            self.args = args or dict()

        @property
        def environment(self):
            return dict()

    class Mock_loader(object):
        class Constructable(object):
            pass

        def __init__(self, basedir=None):
            self.path_dwim = lambda x, y, z: x

        def get_basedir(self, task):
            return '/Users/mark/ansible/test/'

        def load_from_file(self, path, module_name, is_playbook):
            return self.Constructable()

        def add_directory(self, directory):
            pass


# Generated at 2022-06-11 11:26:48.223293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Connection(None)
    module = ActionModule(connection, {})
    assert isinstance(module, ActionModule)


# Generated at 2022-06-11 11:26:58.137099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_user='shuo',
        ansible_ssh_pass='R@dium8911',
        ansible_become_pass='R@dium8911',
        ansible_become_method='sudo',
        ansible_connection='ssh',
        ansible_ssh_user='root',
        ansible_ssh_private_key_file='/home/shuo/.ssh/id_rsa'
    )
    host_vars = dict(
        ansible_host='192.168.189.172',
        ansible_port=22
    )

    custom_module = "copy"
    module_args = dict(
        src='/home/shuo/test.txt',
        dest='/root/'
    )

# Generated at 2022-06-11 11:26:58.756086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:27:05.310334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_shell = MagicMock()
    am = ActionModule(dict(),
                      connection=fake_shell,
                      task_vars=dict())

    # private fields
    if not hasattr(am, "_connection"):
        raise AssertionError("ActionModule does not have field `_connection`")
    if not hasattr(am, "_task_vars"):
        raise AssertionError("ActionModule does not have field `_task_vars`")

# Generated at 2022-06-11 11:27:15.275398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    plugin = ActionModule(dummy_connection, task=dummy_task)
    assert plugin.run() == {u'exception': None, u'failed': True, 
                            u'invocation': {u'module_args': {u'dest': None, u'src': None}}, 
                            u'msg': u'dest is required'}
    assert plugin.run(task_vars={}) == {u'exception': None, u'failed': True, 
                                        u'invocation': {u'module_args': {u'dest': None, u'src': None}}, 
                                        u'msg': u'dest is required'}

# Generated at 2022-06-11 11:27:19.433137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test the constructor of class ActionModule
    assert not ActionModule(dict(), dict(), '', '')._connection.connected
    assert ActionModule(dict(), dict(), '', '')._connection.connect()
    assert ActionModule(dict(), dict(), '', '')._connection.connected

# Generated at 2022-06-11 11:27:27.940788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    FAKE_TASK = dict(
        args=dict(
            dest='/etc/hello',
            src='/tmp/hello.txt',
            remote_src=True
        )
    )
    obj = ActionModule(FAKE_TASK, {})
    obj._remote_expand_user('~')
    obj._transfer_file('/tmp/hello.txt', '/hello.txt')
    obj._execute_remote_stat(path='/etc/hello', all_vars=dict(), follow=True)
    obj._execute_module(module_name='ansible.legacy.copy', module_args=dict(), task_vars=dict())
    obj._remove_tmp_path(tmpdir='/tmp/ansible-tmp-1474395058.29-57755306798643')
    obj._