

# Generated at 2022-06-25 06:37:32.593914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg0 = True
    arg1 = set()
    list_0 = list()
    arg3 = set()
    arg4 = list()
    dict_0 = {}
    test_case_0()
    action_module_0 = ActionModule(arg0, arg1, list_0, arg3, arg4, dict_0)
    bool_0 = True
    tmp = bool_0
    task_vars = "z"
    result = action_module_0.run(tmp, task_vars)
    assert len(result) == 2


# Generated at 2022-06-25 06:37:36.873833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test parameters.
    tmp = None
    task_vars = dict()

    # Call the run method of the ActionModule class.
    action_module = ActionModule(None, DummyConnection(), None, None, None, None)
    action_module.run(tmp, task_vars)


# Generated at 2022-06-25 06:37:37.884304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:43.898674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0}
    list_0 = [set_0, bool_0, set_0, bool_0]
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, set_0, list_0, set_0, list_0, dict_0)
    if False:
        tmp = set_0
        task_vars = set_0
        action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:37:45.420575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except:
        (f, c, t) = sys.exc_info()
        print(f, c, t)

test_ActionModule_run()

# Generated at 2022-06-25 06:37:50.348263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = setup_test_ActionModule()
    var_0 = None
    var_1 = {}
    action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 06:37:54.690103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    ansible_module = ActionModule(tmp, task_vars)
    ansible_module.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:37:55.793654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:37:57.527358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Testing for class ActionModule

# Generated at 2022-06-25 06:38:00.271590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(False, {True}, [{True}], {True}, [True], {})


# Generated at 2022-06-25 06:38:40.086272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = None
    tmp = None
    task_vars = None
    assert obj.run(tmp, task_vars) == None

# Generated at 2022-06-25 06:38:44.362553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    action_module_obj_0 = ActionModule(var_0, var_1)
    try:
        var_2 = None
        var_3 = {}
        var_4 = action_module_obj_0.run(var_2, var_3)
        assert True
    except:
        assert False


# Generated at 2022-06-25 06:38:46.539281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule('foo')
    assert(action_module_obj is not None), "ctor"

if __name__ == "__main__":
    # run the unit test
    test_ActionModule()

# Generated at 2022-06-25 06:38:52.797560
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:38:54.541471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an object of the class ActionModule
    x = ActionModule()

    global var_0, var_1
    var_0 = None
    var_1 = {}
    x.run()


# Generated at 2022-06-25 06:39:04.274151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = {}
    var_18 = {}
    var_19 = {}
    var_20 = {}
    var_21 = {}
    var_22 = {}
    var_23 = {}
    var_24 = {}
    var_25 = {}
    var_26 = {}
    var_27 = {}
    var_

# Generated at 2022-06-25 06:39:07.373860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # result = None
    # a = ActionModule()
    # result = a.run()
    # assert result == None
    pass



# Generated at 2022-06-25 06:39:08.955702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var = ActionModule()
    assert True


# Generated at 2022-06-25 06:39:19.882965
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:39:29.237182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = None
    var_3 = {}
    var_4 = {}
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = {}
    var_10 = {}
    var_11 = ActionModule(var_0,var_1,var_2,var_3,var_4,var_5,var_6,var_7,var_8,var_9)
    # Call method
    try:
        ret_obj = var_11.run(var_1, var_10)
    except Exception as err:
        ret_obj = err
    assert ret_obj


# Generated at 2022-06-25 06:40:19.234958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

if __name__ == '__main__':
    test_case

# Generated at 2022-06-25 06:40:29.916456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    str_1 = '0'
    dict_0 = {'0': str_0}
    var_0 = action_module_0.run(complex_0, dict_0)
    print("    var_0: ", end="")


# Generated at 2022-06-25 06:40:38.306651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the case with the following input:
    # float_0 = -2002.0
    # bool_0 = True
    # set_0 = {float_0, bool_0}
    # str_0 = '0'
    # bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    # int_0 = 1757
    float_0 = -2002.0
    bool_0 = True
    set_0 = set()
    set_0.add(float_0)
    set_0.add(bool_0)
    str_0 = '0'

# Generated at 2022-06-25 06:40:44.490129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_1 = None
    float_1 = -2002.0
    bool_1 = True
    set_1 = {float_1, bool_1}
    str_1 = '0'
    bytes_1 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_1 = 1757
    action_module_0 = ActionModule(float_1, bool_1, set_1, str_1, bytes_1, int_1)
    assert action_module_0._task._role is float_1
    assert action_module_0._task._task is bool_1
    assert action_module_0._task._block is set_1
    assert action_module_0._task._

# Generated at 2022-06-25 06:40:49.905892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)


# Generated at 2022-06-25 06:40:56.624893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    case_0 = None
    float_0 = 7522.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'\x1b\x1c\xdb\x07\x8b[\x82\x9f\x9e\xa8\xde\xbb\x13\x88\xbf\xd4'
    int_0 = -4661
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    var_0 = action_module_0.run(case_0)


# Generated at 2022-06-25 06:41:03.230466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    var_0 = action_run(complex_0)

# Generated at 2022-06-25 06:41:10.005247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -3.0
    bool_0 = False
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'p\x12\xc0\xef\x9a\xda\x1d\xac\xf0\x84\x8ct\xaf\xc9\x9b\xab\x8e\xd5Y[\xfb\xbc\xc5'
    int_0 = 871
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    tmp_0 = None
    task_vars_0 = dict()

# Generated at 2022-06-25 06:41:11.845661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert True
    except:
        ActionModule_run_TestError()


# Generated at 2022-06-25 06:41:14.540754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '__init__')
    class_0 = ActionModule()
    assert class_0 is not None

test_case_0()

# Generated at 2022-06-25 06:42:45.071380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    complex_1 = None
    var_0 = action_module_0.run(complex_0)


# Generated at 2022-06-25 06:42:49.225420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    var_0 = action_run(complex_0)


# Generated at 2022-06-25 06:42:58.924562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    action_module_0.run(complex_0)
    #assert_equal(action_module_0.get(complex_0, complex_0), complex_0)

if __name__ == "__main__":
    test_case_

# Generated at 2022-06-25 06:43:06.424387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    var_0 = action_run(complex_0)

if __name__ == '__main__':
    try:
        test_case_0()
    except Exception as exc:
        print(exc)
        raise exc

# Generated at 2022-06-25 06:43:12.086838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    module_1 = action_module_0.run()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:43:15.383795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)


# Generated at 2022-06-25 06:43:16.508935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')

    # Setup
    # Put code here
    print('Test Success')


# Generated at 2022-06-25 06:43:21.661425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = 7.491537600254010e-34
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = 'd\x17\xce\x9e\xef\xdc\x8f\xbd\xff'
    bytes_0 = b'\xb4\x9d\xef\xc4'
    int_0 = 1342

    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    str_1 = '@\xfe\xf6\xb3\xfe\x8d\x96\x94"\xcc\xb8\x8f'
    float_1 = -1.0
    result

# Generated at 2022-06-25 06:43:30.027431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    float_0 = -2002.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    str_0 = '0'
    bytes_0 = b'x\xbb\xb6\x83x\t\x1f<\xd9\x8b1\xb0\xa4\xb1\xcdd\xbf'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
    result = {1, -1.013992377353958e-08, '', '\x7f'}

# Generated at 2022-06-25 06:43:36.422027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = 22
    float_0 = -2002.0
    bool_0 = True
    set_0 = {complex_0, float_0}
    str_0 = '0'
    bytes_0 = b'\x1b\x96\x84\x9b\x9c\xdf\x06\x8f\xd4\xa4\x86\x11\xf8\x9e\x9c'
    int_0 = 1757
    action_module_0 = ActionModule(float_0, bool_0, set_0, str_0, bytes_0, int_0)
