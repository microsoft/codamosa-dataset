

# Generated at 2022-06-25 06:37:29.429738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = ""
    dest = ""
    content = ""
    tmp = ""
    task_vars = ""
    obj = ActionModule()
    obj.run(source=source, dest=dest, content=content, tmp=tmp, task_vars=task_vars)

# Stack trace: test_ActionModule_run
#   File "copy.py", line 699, in test_ActionModule_run
#     def test_ActionModule_run():
#   File "copy.py", line 701, in test_ActionModule_run
#     obj.run(source=source, dest=dest, content=content, tmp=tmp, task_vars=task_vars)
#   File "/home/travis/build/ansible/ansible-modules-core/test/units/action_plugins/test_copy.py", line 7

# Generated at 2022-06-25 06:37:36.733975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #action = ActionModule(ActionModule.__name__, ActionModule.__doc__)
    action = ActionModule(ActionBase.__name__, ActionBase.__doc__)
    print(action.async_val)
    print(action.async_seconds)

# This section is called if this script is executed from command line:
if __name__ ==  '__main__':
    print("This script is a module, supposed to be\n"
          "imported by another scripts, not executed directly.")

# Generated at 2022-06-25 06:37:38.469075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Unit test of method remote_expand_user of class ActionModule

# Generated at 2022-06-25 06:37:45.318451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate ActionModule
    # use the implicit subdir specifier "./"
    task_vars = dict()
    tmp = None
    source = "../ansible/modules/cloud/azure/azure_rm_acs.py"
    content = None
    dest = "/home/vagrant/workspace/ansible/azure_rm_acs.py"
    remote_src = False
    local_follow = True
    a_instance_0 = ActionModule(task_vars, tmp, source, content, dest, remote_src, local_follow)
    a_instance_0.run()


# Generated at 2022-06-25 06:37:49.650938
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiate mock class

    # Call method run with parameters
    result = AnsibleModule.run(tmp=None, task_vars=None)



# Generated at 2022-06-25 06:37:50.852917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_obj = ActionModule()


# Generated at 2022-06-25 06:37:51.911258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-25 06:37:56.523175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #prepare and run the task
    actionmodule = ActionModule()
    actionmodule._task = task()
    result = actionmodule.run(None, None)

    # check if the output was expected
    assert result['failed'] == True
    assert result['msg'] == "dest is required"


# Generated at 2022-06-25 06:37:58.672926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(ActionModule(), tmp=None, task_vars={})
    assert result == {}

# Generated at 2022-06-25 06:38:11.106554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = mock.Mock()
    loader_0 = mock.Mock()
    tqm_0 = mock.Mock()
    connection_0 = mock.Mock()
    play_context_0 = mock.Mock()
    result_0 = ActionModule.__new__(ActionModule)
    result_0.runner = mock.Mock()
    result_0.runner_connection = mock.Mock()
    result_0.runner_queue = mock.Mock()
    result_0.task = mock.Mock()
    result_0.loader = mock.Mock()
    result_0.play = mock.Mock()
    result_0.tqm = mock.Mock()
    result_0.set_runner = mock.Mock()
    result_0.set_task = mock.M

# Generated at 2022-06-25 06:38:53.259051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # action_module_1 = ActionModule()
    # assert_equal(action_module_1.run(), None)
    pass


# Generated at 2022-06-25 06:39:01.893365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f\'$'
    bytes_0 = b'\x90\x0e\xe2-\x7f\x99\x93\xba\x91\xc5\xcf\xf8\xe4\x04\xeb\xf4'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    float_0 = -3792.515
    int_0 = 238
    action_module_0 = ActionModule(bytes_0, list_0, float_0, int_0, list_0, list_0)
    str_1 = '\xc1\x1d\xa4'
    action_module_0.run(str_1)

# Main function

# Generated at 2022-06-25 06:39:13.336129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case for the run method
    str_2 = 'f1'
    bytes_2 = b'C\xa6\xaaa\xaf\x92\x93\xa1\x87\x9a\x16\x93\x05\x02y\xc7\x91\xb8-\xcb\x89\xec\xc4\x8d\xb3\x0f\\\xd1'
    float_2 = -72.89
    int_2 = 5
    list_2 = [bytes_2, bytes_2, bytes_2, str_2, str_2, str_2]
    list_3 = [str_2, int_2, str_2, str_2, str_2, int_2]

# Generated at 2022-06-25 06:39:22.881055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Gp'
    bytes_0 = b'\xc8i'
    list_0 = [str_0, bytes_0, str_0, str_0, bytes_0]
    float_0 = 17.52200331495
    int_0 = 333
    action_module_0 = ActionModule(bytes_0, list_0, float_0, int_0, list_0, list_0)
    action_module_0._task.args = dict()
    str_1 = '\x1f\xbe\xf8h\xe7\x18\xe5'
    action_module_0._task.args['content'] = str_1
    str_2 = 'MN'
    action_module_0._task.args['dest'] = str_2

# Generated at 2022-06-25 06:39:24.022626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)


# Generated at 2022-06-25 06:39:34.483686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'JQ6'
    bytes_0 = b"G\xeb\x92\x91\xed_\x19J\xc3'7\xd1\x08\xcd\\9\xb3"
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    float_0 = -3792.515
    int_0 = 238
    action_module_0 = ActionModule(bytes_0, list_0, float_0, int_0, list_0, list_0)
    str_1 = 'p9l'
    str_2 = '8'
    bytes_1 = b'\xfc\x80\x89\xe5\xd0\xe9\x12\xd8'

# Generated at 2022-06-25 06:39:42.068157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test_case = (ActionModule.run, [(0,), {"tmp": 0, "task_vars": 0}])
    test_case = (ActionModule.run, [(0,), {
    }])
    test_case_0(test_case[0], *test_case[1])

if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.DEBUG)
    for case in [test_ActionModule_run]:
        print(case)
        case()

# Generated at 2022-06-25 06:39:52.658438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Ensure correct invocation.
    action_module_0 = ActionModule()
    str_0 = '.'
    list_0 = []
    float_0 = 708.3
    int_0 = 103
    str_1 = '('
    list_1 = []
    str_2 = 'ipv6.af'
    bytes_0 = b'\xe2v\x8d\xc0\x94\x88\x1e\x9b\\\xb0\xd1\xce\x8fW\xa0\xb9\xaa'
    list_2 = [bytes_0, bytes_0]
    action_module_0 = ActionModule(str_0, list_0, float_0, int_0, list_1, list_2)
    str_3 = '!'

# Generated at 2022-06-25 06:40:03.965152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'F2Q'
    bytes_0 = b'\xae\xca\xeb\xfc+\xe9\xed\xd8\xce\xb6\x82\x0b\xba\xaf\x91\xc2'

# Generated at 2022-06-25 06:40:05.651923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Case 0
    test_case_0()
    # Case 1

# Generated at 2022-06-25 06:41:31.965692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert abc.ABCMeta.__subclasshook__(test_ActionModule, action_module_0)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:41:34.550453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # tmp is a string.
    # task_vars is a dict.
    action_module_0 = ActionModule()
    result = action_module_0.run()
    # assert result == expected


# Generated at 2022-06-25 06:41:43.742748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'q'
    bytes_0 = b'\x03\xea\x19\x0e\xbe\x7f!\x93\xbf\x8b\x03\r\xcf\x14\x82\xbd\x0c\x17\x9c\x8f'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0, bytes_0]
    float_0 = -5.2203234
    int_0 = 135
    tuple_0 = (list_0, list_0)
    action_module_0 = ActionModule(bytes_0, list_0, float_0, int_0, list_0, list_0)
    result = action_module_0.run(None, tuple_0)

# Generated at 2022-06-25 06:41:51.278944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        import zlib
        zlib_decompress = zlib.decompress
        zlib.decompress = test_case_0
        ActionModule(None, None, None, None, None, None)
    except Exception:
        print('Expected Exception')
    else:
        assert False
    finally:
        zlib.decompress = zlib_decompress

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:42:02.966135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Test for class method run
    str_1 = '\x7f\x08\xf9\x10\xfd\x0b\xfe\x1a\x14\xf0\xfa\xe9\x0e\x0f\x1c\xec\xfc\x0e\xf0\x1e\x08\x0b\x0b\x13\x08\x1a\x0c\x1f\x0a\x0a\xfc'
    str_0 = '\x14\x1d\x01'
    int_0 = 67
    float_1 = -4248.492

# Generated at 2022-06-25 06:42:14.604277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '7<'
    bytes_0 = b'.'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    float_0 = -1571.85
    int_0 = 522
    action_module_0 = ActionModule(str_0, list_0, float_0, int_0, list_0, list_0)
    str_1 = '~'
    bytes_1 = b';'
    list_1 = [bytes_1, bytes_1, bytes_1, bytes_1]
    float_1 = 5794.8
    int_1 = -231
    bool_0 = bool(str_1, list_1, float_1, int_1, list_1, list_1)
    str_2 = '|'
    bytes_

# Generated at 2022-06-25 06:42:22.760545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'N^'
    bytes_0 = b'\xd5R\x82\xba5\x16\xdd\xda\x17\x8c\x99\x9e\x16\x10\x82\x12\x05\x15\xcb\xbd\xc6\x95\x16\xaf\xa6\x8f\x15\xce\xc0\x8c\x15\x05\x1a\x98\x8d\x03\x14\xdc\xc8\xd0\x12\x1a\x9b\x8d\x10\x1d\xdc\xc8\xd0\x12\x1a\x9b'

# Generated at 2022-06-25 06:42:26.467703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Setup
  arg1 = "test_value"
  arg2 = "test_value"
  arg3 = "test_value"
  arg4 = "test_value"
  arg5 = "test_value"
  arg6 = "test_value"
  action_module_0 = ActionModule(arg1, arg2, arg3, arg4, arg5, arg6)
  tmp = None
  task_vars = dict()
  # Exercise
  result = action_module_0.run(tmp, task_vars)
  # Verify
  assert result == None


# Generated at 2022-06-25 06:42:31.312811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "uA}"
    list_0 = []
    float_0 = 0.02
    int_0 = -2
    list_1 = [str_0, float_0]
    list_2 = [True, -0.01]
    action_module_0 = ActionModule(str_0, list_0, float_0, int_0, list_1, list_2)
    dict_0 = dict()
    dict_1 = dict()
    dict_0 = action_module_0.run(dict_0, dict_1)
    assert (dict_0 == dict_1)
    assert (dict_0 is not dict_1)


# Generated at 2022-06-25 06:42:33.010177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test ActionModule run')
    # TODO: Add test for ActionModule run (as used in test_case_0)


# Generated at 2022-06-25 06:46:10.934545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare parameters
    tmp = None
    task_vars = {}

    # Instantiate class
    action_module = ActionModule(None, None, 0.0, 0, None, None)
    # Run method
    result = action_module.run(tmp, task_vars)
    assert result == {}

# Generated at 2022-06-25 06:46:12.008877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 06:46:16.327321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'D'
    list_0 = []
    float_0 = 1737.58889
    int_0 = 12
    action_module_0 = ActionModule(str_0, list_0, float_0, int_0, list_0, list_0)
    action_module_0.run()



# Generated at 2022-06-25 06:46:23.964765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_W}'
    bytes_0 = b"G\xeb\x92\x91\xed_\x19J\xc3'7\xd1\x08\xcd\\9\xb3"
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    float_0 = -3792.515
    int_0 = 238
    action_module_0 = ActionModule(bytes_0, list_0, float_0, int_0, list_0, list_0)
    action_module_0.run(bytes_0, bytes_0)

# Generated at 2022-06-25 06:46:26.019567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('****** Execution of test method for run() ******')
    test_case_0()
    print('****** Execution of test method for run() ends ******')


# Generated at 2022-06-25 06:46:31.626175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Bb'
    bytes_0 = b"\xd3U\x91\x10\xc6\x80\x0b\xbd\xfc\x8c\x19\x10\x07\xd7\x8f:\xcd\xd6\xf1\xbc\xed"
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    float_0 = -3792.515
    int_0 = 238
    action_module_0 = ActionModule(bytes_0, list_0, float_0, int_0, list_0, list_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 06:46:32.945396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:46:42.062140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f:\xe9\x1f\xe0\xe7\xee\x06\x91\x04\xa0\xc8\x1f\x0c\xe4\x18\xee\x1b\x0f\x12\x1c\xc9\x9b\x0d\x90\x0e\xcc\xb1\x83'