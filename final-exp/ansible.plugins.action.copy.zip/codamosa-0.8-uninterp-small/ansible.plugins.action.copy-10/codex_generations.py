

# Generated at 2022-06-25 06:37:31.913176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case var init
    int_0 = -711
    str_0 = 'y"\x92\xbd\x11\x1e\x9d!\xd2i\xe1\xcf\xfd\x14\x0b>\x84\x00\x1dn\xe1\x82N'
    str_1 = '~\xbe\xe7\x81\x98\x1b\x1d\xcf\xa3\xf5\xfa\xac\x18\xeb\x1e\x9a\xf2\xb2'
    str_2 = '\x13\x15\xf8\x0c\x9e\x17\x7f\xf4\x01\xb4'

# Generated at 2022-06-25 06:37:41.829745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1489
    str_0 = ' 4vx'
    bytes_0 = b'\xf6\xbb\x8bn\xca\xb5\x17\xe5\x1d\xd2 \xecc\r\xf83-[\x8cj'
    action_module_0 = ActionModule(str_0, int_0, str_0, int_0, bytes_0, str_0)

    int_0 = -1133
    int_1 = -1325
    str_0 = '`\x9c\x84\x8b\xa5\xcc\xab\x87\x8b\x91\xa3\x9c\x8b\x82\xa7\x91'

# Generated at 2022-06-25 06:37:43.525336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    test_case_0()


# Generated at 2022-06-25 06:37:44.522671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:47.621310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation of mock class.
    tmp = Mock()
    task_vars = Mock()

    # Setup
    str_0 = 'snbKz'
    int_0 = 4

    # Pass
    assert True is True

    # Failure
    assert True is True


# Generated at 2022-06-25 06:37:49.806197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:38:01.338049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1322
    str_0 = 'g'

# Generated at 2022-06-25 06:38:02.807314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create test cases
    # test_case_0()

    # Run tests
    # test_case_0()

    # display test results
    print('Done')

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 06:38:04.896580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:07.825742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:20.509450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Configure mock
    #
    def side_effect_for_run_0(*args, **kwargs):
        return True

    side_effect_for_run_0.__name__ = 'side_effect_for_run_0'
    side_effect_for_run_0.is_coroutine = False

    def side_effect_for_run_1(*args, **kwargs):
        return True

    side_effect_for_run_1.__name__ = 'side_effect_for_run_1'
    side_effect_for_run_1.is_coroutine = False


# Generated at 2022-06-25 06:39:25.386437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = None
    # Prepare the test environment
    test_case_0()

    # Construct the test class
    obj = ActionModule()

    # Execute the run method
    var_1 = obj.run(var_0)
    assert var_1 != None


# Generated at 2022-06-25 06:39:35.628308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    test_case_0()

# Generated at 2022-06-25 06:39:37.970337
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:39:43.746126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    parm = None
    parm = 'None'
    var_1 = None
    tmp = None
    task_vars = None
    test_obj_0 = ActionModule(parm)
    test_obj_0.run(tmp, task_vars)
    del test_obj_0
    del tmp
    del task_vars
    del parm


# Generated at 2022-06-25 06:39:53.769805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 'tmp'
    var_1 = None
    var_2 = 'dest'
    var_3 = 'src'
    var_4 = 'ansible.legacy.file'
    var_5 = 'content'
    var_6 = '/usr/bin/python'
    var_7 = 'follow'
    var_8 = 'directory_mode'
    var_9 = 'remote_src'
    var_10 = 'local_follow'
    var_11 = 'checksum'
    var_12 = 'backup'
    var_13 = 'force'
    var_14 = 'validate'
    var_15 = 'remote_user'
    var_16 = None
    var_17 = 'mode'
    var_18 = None
    var_19 = 'async'
    var_

# Generated at 2022-06-25 06:40:04.609846
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module_0 = ActionModule('ActionModule', None)

    assert module_0._copy_file() == None
    assert module_0._get_diff() == None
    assert module_0._remote_expand_user() == None
    assert module_0._write_config() == None
    assert module_0._get_remote_user() == None
    assert module_0.cleanup() == None
    assert module_0._execute_module() == None
    assert module_0._remove_tmp_path() == None
    assert module_0._execute_module_with_changed_args() == None
    assert module_0._transfer_str_to_file() == None
    assert module_0._remove_tmp_path() == None
    assert module_0._remove_tmp_path() == None
    assert module_0._execute_module

# Generated at 2022-06-25 06:40:09.554959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_3 = None
    test_case_0()
    try:
        var_0.run(var_1, var_2)
    except Exception as e:
        print("Caught exception: ", str(e))


# Generated at 2022-06-25 06:40:11.145643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_instance = ActionModule()


# Generated at 2022-06-25 06:40:18.941269
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:41:42.587524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule()
    assert (test_ActionModule.run != None)


# Generated at 2022-06-25 06:41:45.026341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("--- test_ActionModule ---")
    test_case_0()
    print("--- End test_ActionModule ---")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:41:54.964270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.runner = MagicMock()
    action_module_0.runner.action = 'copy'
    action_module_0._task = MagicMock()
    action_module_0._task._role = None
    action_module_0._task._role_params = None
    action_module_0._task._ds = None
    action_module_0._task.args = {'dest': '/home/ubuntu/copy_dir/', 'copy': 'copy module', 'mode': 'preserve', 'content': None, 'src': '/home/ubuntu/copy_dir_1_src/', 'original_basename': None, '_ansible_diff': True, '_ansible_parsed': True}
    action_module_0._loader = MagicMock()


# Generated at 2022-06-25 06:41:57.732771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None
    print("Test class ActionModule constructor")


# Generated at 2022-06-25 06:41:59.569552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule()
    assert type(action_module) is ActionModule

# Generated at 2022-06-25 06:42:05.754229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor with no arguments
    action_module_0 = ActionModule()
    # Test constructor with 2 arguments
    action_module_1 = ActionModule(task=None, connection=None)
    # Test constructor with 3 arguments
    action_module_2 = ActionModule(task=None, connection=None, play_context=None)
    # Test constructor with 4 arguments
    action_module_3 = ActionModule(task=None, connection=None, play_context=None, loader=None)
    # Test constructor with 5 arguments
    action_module_4 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None)


# Generated at 2022-06-25 06:42:15.649996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Test for method "run"
    # no argument provided
    try:
        result = action_module_0.run()
    except Exception as e:
        print (e.message)
        print (e.args)
        print (traceback.format_exc())
        print ('Test for method "run" of class ActionModule failed.')

    # two argument provided
    try:
        result = action_module_0.run('tmp', 'task_vars')
    except Exception as e:
        print (e.message)
        print (e.args)
        print (traceback.format_exc())
        print ('Test for method "run" of class ActionModule failed.')


# Generated at 2022-06-25 06:42:17.530518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n*** Unit test of constructor of class ActionModule\n")
    action_module = ActionModule()


# Generated at 2022-06-25 06:42:18.129164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:42:25.346196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_module = Mock()
    test_module.params = dict()
    action_module_0._execute_module = Mock(return_value=test_module)
    action_module_0._transfer_str = "test"
    action_module_0._remove_tmp_path = Mock()
    action_module_0._remove_tempfile_if_content_defined = Mock()
    action_module_0._find_needle = Mock()
    action_module_0._loader = MagicMock()
    action_module_0._connection = MagicMock()
    action_module_0._task = MagicMock()
    action_module_0._remove_tmp_path = Mock()
    action_module_0._check_mode = Mock()

# Generated at 2022-06-25 06:44:13.486581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('5a1KlhNlDf', -1650417451, 'hv+x', -1489, b'\xf6\xbb\x8bn\xca\xb5\x17\xe5\x1d\xd2 \xecc\r\xf83-[\x8cj', 'hv+x')
    assert_equals(action_module_0.run(), None)


# Generated at 2022-06-25 06:44:15.477467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\nRunning test_ActionModule_run')
    test_case_0()
    test_case_1()

# generative method trace path
# test_case_0
# test_case_1
# test_ActionModule_run

# Generated at 2022-06-25 06:44:16.603620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:44:17.527864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:44:23.512641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1489
    str_0 = 'hv+x'
    bytes_0 = b'\xf6\xbb\x8bn\xca\xb5\x17\xe5\x1d\xd2 \xecc\r\xf83-[\x8cj'
    action_module_0 = ActionModule(str_0, int_0, str_0, int_0, bytes_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:44:25.139572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:44:30.651149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -836
    str_0 = 'w'
    bytes_0 = b'\xf3\xbe\xed\x8d\x1c\x1e\xcf\xeb\x11\x9f\x83\xcd\x1e>\x04\xa4\xf7\x91'
    action_module_0 = ActionModule(str_0, int_0, str_0, int_0, bytes_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:44:33.333354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Connection('localhost')
    tmp = None
    task_vars = dict()
    task = dict()
    action_module = ActionModule(task, host, tmp, task_vars)
    result = action_module.run(tmp, task_vars)
    assert( result == dict() )


# Generated at 2022-06-25 06:44:36.035556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_ActionModule.__doc__ == __doc__
    assert len(inspect.getargspec(ActionModule.__init__).args) == 6

# Pattern for validating docstring for class ActionModule
README_CONTENT_CHECK_FOR = re.compile(r"test_constructor_of_class_ActionModule")


# Generated at 2022-06-25 06:44:39.759696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    output_0 = 'test_output'
    setattr(sys.stdout, 'buffer', buffer)
    test_case_0()
    assert attr(sys.stdout, 'buffer').getvalue() == output_0
