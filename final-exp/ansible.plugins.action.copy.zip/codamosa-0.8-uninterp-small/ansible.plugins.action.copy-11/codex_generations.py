

# Generated at 2022-06-25 06:37:28.744506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'NF\x07%cG^b5-=\x7fj\x14\x12', 'NF\x07%cG^b5-=\x7fj\x14\x12', 'NF\x07%cG^b5-=\x7fj\x14\x12'}
    dict_0 = {'NF\x07%cG^b5-=\x7fj\x14\x12': set_0, 'NF\x07%cG^b5-=\x7fj\x14\x12': set_0}
    tuple_0 = ('NF\x07%cG^b5-=\x7fj\x14\x12',)

# Generated at 2022-06-25 06:37:39.559218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\\`\x1b\x19\\T\x06\\\x0c?S\x06\x1f'
    set_0 = {str_0, str_0}
    dict_0 = {str_0: set_0}
    tuple_0 = (str_0,)
    dict_1 = {str_0: dict_0}
    dict_2 = {str_0: dict_0}
    action_module_0 = ActionModule(str_0, set_0, dict_0, tuple_0, dict_1, dict_2)
    dict_3 = {str_0: set_0, str_0: action_module_0, str_0: action_module_0}
    union_0 = dict_3.update(dict_3)

# Generated at 2022-06-25 06:37:41.320674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print('exception caught')


# Generated at 2022-06-25 06:37:42.292925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:37:43.278470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:46.962249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    action_module_0 = ActionModule('tmp', set(), {}, (), {}, {})
    assert action_module_0.run(tmp, task_vars) == {
        u'failed': True,
        u'msg': u'src (or content) is required'
    }


# Generated at 2022-06-25 06:37:59.754641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a module_args dictionary
    module_args = dict()
    # Base module arguments
    module_args['src'] = 'test'
    module_args['dest'] = 'test'
    module_args['state'] = 'test'
    # File module arguments
    module_args['path'] = 'test'
    module_args['follow'] = False
    module_args['regexp'] = None
    module_args['removes'] = None
    module_args['content'] = 'test'
    module_args['backup'] = False
    module_args['force'] = False
    module_args['selinux_ignore_defaults'] = False
    module_args['selevel'] = 'test'
    module_args['serole'] = 'test'
    module_args['setype'] = 'test'


# Generated at 2022-06-25 06:38:05.494897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('6P[CN(k\x0c', set(), dict(), tuple(), dict(), dict())
    exception_0 = None
    try:
        action_module_0.run('zs', dict())
    except Exception as exception_0:
        pass
    assert exception_0 is not None


# Generated at 2022-06-25 06:38:09.626172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('P#Y_QosH&', set(), dict(), tuple(), dict(), dict())

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:38:11.022430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:39:02.524128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_0 = ActionModule()
    class_0 = ActionModule()
    assert ActionModule() is not mod_0
    assert ActionModule()._connection is not mod_0._connection
    assert ActionModule()._task is not mod_0._task
    assert isinstance(ActionModule()._connection.__dict__['_shell'], Shell)
    for attr_0 in ActionModule.__dict__.keys():
        assert not isinstance(getattr(class_0, attr_0), types.MethodType)


# Generated at 2022-06-25 06:39:14.196869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a temp file and write a list to it.
    content = [1,2,3]
    fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    try:
        json.dump(content, f)
    finally:
        f.close()

    my_action = ActionModule()

    # Define a task with content in it.
    my_task = Task()
    my_task.args = dict(dest='./content_tempfile', content=content)

    # Pass the object to the class.
    my_action._task = my_task
    my_action._loader = DictDataLoader({})
    my_action._connection = Connection()

# Generated at 2022-06-25 06:39:23.430256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['dest'] = 'dir_1/dir_2'
    var_0['src'] = 'dir_3/dir_4'
    var_0['local_follow'] = True
    var_0['recursive_mode'] = 'yes'
    var_0['remote_src'] = 'yes'
    var_0['existing'] = "replace"
    var_0['backup'] = "yes"
    var_0['follow'] = "yes"
    var_0['checksum'] = "no"
    var_0['force'] = "yes"
    var_0['content'] = "str_6"
    var_0['directory_mode'] = "yes"
    var_0['flat'] = "yes"
    var_0['group'] = "yes"


# Generated at 2022-06-25 06:39:34.209346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_0['name'] = 'foo'
    var_0['password'] = 'bar'
    var_0['src'] = None
    var_0['content'] = None
    var_0['dest'] = None
    var_0['_ansible_verbosity'] = 3
    var_0['_ansible_no_log'] = False
    var_0['_ansible_diff'] = False
    var_0['_ansible_selinux_special_fs'] = False
    var_0['_ansible_debug'] = False
    var_0['_ansible_keep_remote_files'] = False
    var_0['encoding'] = 'utf-8'
    var_0['errors'] = 'strict'

# Generated at 2022-06-25 06:39:45.737948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = 'ansible.legacy.copy'
    var_2 = 'dest'
    var_3 = 'src'
    var_4 = False
    var_5 = '/etc/ansible/ansible.cfg'
    var_6 = '***'
    var_7 = '---'
    var_8 = 'ansible.legacy.file'
    var_9 = 'changed'
    var_10 = 'mode'
    var_11 = 'rotate'
    var_12 = 'dest'
    var_13 = 'checksum'
    var_14 = 'backup'
    var_15 = 'dest'
    var_16 = 'content'
    var_17 = '-move-'
    var_18 = 'First match wins'

# Generated at 2022-06-25 06:39:50.344449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        arg_0 = dict()
        arg_1 = dict()
        act_mod = ActionModule()
        act_mod.run(arg_0, arg_1)
    except Exception as e:
        print('Exception: %s' % e)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:54.695083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with following params.
    # task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None
    action_module = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    action_module.test_0()


# Generated at 2022-06-25 06:40:04.935934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    var_24 = dict()
    var_25 = dict()

# Generated at 2022-06-25 06:40:06.604363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    param_0 = ContentGenerator()
    var_0 = ActionModule(param_0)


# Generated at 2022-06-25 06:40:10.244490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    tmp_2 = None
    # set up the task and the state
    ActionModule.run(var_2, tmp_2)

test_case_0()

# Generated at 2022-06-25 06:41:44.709964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()

    # test 1:
    action_module = ActionModule(task=var_0)
    assert isinstance(action_module, ActionModule)
    assert hasattr(action_module, '_execute_module')
    assert hasattr(action_module, '_execute_command')
    assert action_module._task == var_0
    assert action_module._connection == var_0['connection']
    assert action_module._shell == 'sh'
    assert action_module._tmpdir == '/tmp'
    assert action_module._tmpdir_update_cache == False
    assert action_module._tmpdir_lockfile == None
    assert action_module._is_pipelining == False
    assert action_module._task_vars == var_0['vars']
    assert action_module._play_context == var

# Generated at 2022-06-25 06:41:45.512512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()


# Generated at 2022-06-25 06:41:48.306317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()

    obj_0 = ActionModule(var_0, var_1)


# Generated at 2022-06-25 06:41:56.287846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = ansible.playbook.play.Play()
    var_3.name = 'my_play'
    var_4 = ansible.playbook.role.Role()
    var_4._role_name = 'my_role'
    var_5 = ansible.playbook.included_file.IncludedFile()
    var_5._filename = 'my_import'
    var_6 = ansible.playbook.task.Task()
    var_6.name = 'my_task'
    var_7 = ansible.playbook.block.Block()
    var_7._parent = var_6
    var_8 = ansible.playbook.handler.Handler()
    var_8.name = 'my_handler'
    var_2 = ansible.modules.source_control.git.Git()


# Generated at 2022-06-25 06:42:02.569872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config = dict()
    task_vars = dict()
    result = dict()
    cls = ActionModule(task=mock.MagicMock(), connection=mock.MagicMock(), play_context=mock.MagicMock(), loader=mock.MagicMock(), templar=mock.MagicMock(), shared_loader_obj=mock.MagicMock())
    res = cls.run(config, task_vars)
    assert res == result

# Generated at 2022-06-25 06:42:14.297561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['_is_async'] = 0
    var_0['_diff'] = 0
    var_0['_ansible_parsed'] = 0
    var_0['action_type'] = 'async'
    var_0['_ansible_no_log'] = False
    var_0['_ansible_check_mode'] = None
    var_0['name'] = None
    var_0['_ansible_verbosity'] = 0
    var_0['_ansible_debug'] = 0
    var_0['_ansible_module_name'] = u'ansible.legacy.copy'
    var_0['_ansible_delegated_vars'] = None
    var_0['src'] = 'src'

# Generated at 2022-06-25 06:42:22.528666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0["content"] = None
    var_0["dest"] = "test"
    var_0["remote_src"] = False
    var_0["local_follow"] = True
    var_0["src"] = "test"
    var_0["follow"] = False
    var_0["recursive"] = True
    var_0["force"] = False
    var_0["backup"] = False
    var_0["checksum"] = True
    var_0["directory_mode"] = None
    var_0["mode"] = None
    var_0["owner"] = None
    var_0["group"] = None
    var_0["selevel"] = None
    var_0["serole"] = None
    var_0["setype"] = None

# Generated at 2022-06-25 06:42:24.555935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule is not None


# Generated at 2022-06-25 06:42:25.694221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = ActionModule(var_0)


# Generated at 2022-06-25 06:42:26.381119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:46:14.150612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    
    # Call method run with arguments
    try:
        action_module_0.run(tmp=None, task_vars=None)
    except:
        pass
    try:
        action_module_1.run(tmp=None, task_vars=None)
    except:
        pass


# Generated at 2022-06-25 06:46:20.661937
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:46:26.414537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_0['task_vars'] = dict()
    var_0['task_vars']['ansible_check_mode'] = False
    var_0['connection'] = dict()
    var_0['connection']['name'] = 'local'
    var_0['connection']['_executor'] = type('MockExecutor', (object,), dict())
    var_0['connection']['_shell'] = type('MockShell', (object,), dict())
    var_0['connection']['_shell']['_terminal_stdout'] = False
    var_0['_task'] = type('MockTask', (object,), dict())
    var_0['_task']['module_name'] = 'copy'

# Generated at 2022-06-25 06:46:28.373533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for i in range(0, 10):
        try:
            test_case_0()
        except:
            print("Constructor test failed.")
            raise



# Generated at 2022-06-25 06:46:37.771130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._display.verbosity = 0
    action_module._display.deprecated_warning = mock.Mock()
    action_module._display.warning = mock.Mock()
    action_module._get_diff_data = mock.Mock()
    action_module._execute_remote_stat = mock.Mock()
    action_module._execute_module = mock.Mock()
    action_module._remove_tmp_path = mock.Mock()
    action_module._remote_expand_user = mock.Mock()
    action_module._find_needle = mock.Mock()
    action_module._copy_file = mock.Mock

# Generated at 2022-06-25 06:46:41.235042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'localhost'
    port = None
    user = 'root'
    password = '*****'
    host = Host(hostname, port=port, user=user, password=password)
    setup_datadir()