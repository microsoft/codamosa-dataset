

# Generated at 2022-06-25 06:37:22.225257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:37:25.740336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 2686.03
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)



# Generated at 2022-06-25 06:37:34.890471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule for unit test
    action_module_0 = ActionModule(True, 0.5, True, 'Ansible', True, 'Ansible')

    result_0 = action_module_0.run(None, None)

    # AssertionError: unexpected invocation result: {'failed': True, 'msg': 'dest is required'}
    assert result_0 == {'failed': True, 'msg': 'dest is required'}

if __name__ == "__main__":
    test_case_0()
    print("Test 1")
    test_ActionModule_run()

# Generated at 2022-06-25 06:37:35.755747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule')
    test_case_0()


# Generated at 2022-06-25 06:37:36.360285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:37.021775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:42.292306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup to test run method
    tmp = None
    task_vars = None
    bool_0 = False
    float_0 = 2686.03
    bool_1 = True
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_1, str_0)
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:37:47.949072
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test for values
    bool_0 = False
    float_0 = 2686.03
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    # Test for key
    bool_0 = False
    float_0 = 1571.51
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)

# Generated at 2022-06-25 06:37:54.387699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 6180.62
    str_0 = 'pub'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    action_module_0.run()
    #assert action_module_0.run() == '1'


# Generated at 2022-06-25 06:38:00.984037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 2478.35
    str_0 = 'parallel'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)

if __name__ == "__main__":
    # Unit test for constructor of class ActionModule
    test_ActionModule()
    # Unit test for constructor of class ActionModule
    test_case_0()

# Generated at 2022-06-25 06:38:49.428685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 2686.03
    str_0 = 'centos'
    dict_0 = {'a': 'b', 'c': 'd'}
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)

    # Now we can test the methods associated with the ActionModule class
    assert action_module_0.action_version == 1
    assert action_module_0.action_name == 'file'



# Generated at 2022-06-25 06:38:52.100617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate the class
    task = dict()
    action = dict()
    connection = dict()
    templar = dict()
    play_context = dict()
    loader = dict()
    action_module_0 = ActionModule(task, connection, templar, play_context, loader)


# Generated at 2022-06-25 06:38:57.581114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    str_0 = '_'
    action_module_0.run(tmp=None, task_vars=None)
    assert (action_module_0.run(_task_fields('task_vars')) == (action_module_0._execute_module(module_name='ansible.legacy.setup', module_args=None, task_vars=None)))
    assert (action_module_0.run(_task_fields('task_vars')) == (action_module_0._execute_module(module_name='ansible.legacy.setup', module_args=_task_fields('task_vars'), task_vars=None)))

# Generated at 2022-06-25 06:39:03.429967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 796.04
    str_0 = 'cloudlinux'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)


if __name__ == '__main__':
    try:
        test_ActionModule()
    finally:
        fp.close()

# Generated at 2022-06-25 06:39:10.446861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 1465.1
    str_0 = 'mail'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    assert action_module_0.run() == None
    assert action_module_0.run(None) == None

# Unit tests for function _walk_dirs

# Generated at 2022-06-25 06:39:12.855374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule(True, -3106.0, False, 'foo', True, 'bar')
    assert var_0 is None


# Generated at 2022-06-25 06:39:21.726683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 3349.0
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    bool_1 = action_module_0.b_0
    assert bool_1 == bool_0
    bool_2 = action_module_0.b_1
    assert bool_2 == bool_0
    float_1 = action_module_0.f_0
    assert float_1 == float_0
    assert action_module_0.s_0 == str_0
    assert action_module_0.s_1 == str_0


# Generated at 2022-06-25 06:39:32.692806
# Unit test for constructor of class ActionModule
def test_ActionModule():

    temp_str_0 = str()
    temp_str_1 = str()
    temp_str_2 = str()
    temp_str_3 = str()
    temp_str_4 = str()
    temp_str_5 = str()
    temp_str_6 = str()
    temp_str_7 = str()
    temp_str_8 = str()
    temp_str_9 = str()
    temp_str_10 = str()
    temp_str_11 = str()
    temp_str_12 = str()
    temp_str_13 = str()
    temp_str_14 = str()
    temp_str_15 = str()
    temp_str_16 = str()
    temp_str_17 = str()
    temp_str_18 = str()
    temp_str_19 = str()

# Generated at 2022-06-25 06:39:36.589291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(boolean=False, float=2686.03, boolean=False, str='virtuozzo', boolean=False, str='virtuozzo')
    var_0 = action_run(tmp=None, task_vars=None)
    print(var_0)


# Generated at 2022-06-25 06:39:39.842600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int(), int(), int(), str(), int(), str())
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:41:13.553541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(args={}))
    result = module.run(tmp='foo/bar', task_vars=dict())
    assert result['invocation'] == dict(module_args={})


# Generated at 2022-06-25 06:41:19.819508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 2762.49
    str_0 = 'abc'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    assert not hasattr(action_module_0, 'task')
    assert equals(action_module_0.CHUNK_SIZE, 65536)
    assert equals(action_module_0.TRANSPORT, 'smart')


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:41:25.633288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 572.46
    str_0 = 'vagrant'
    action_module_0 = ActionModule(True, 33.78, False, 'test', True, 'test')
    action_module_1 = ActionModule(True, 94945.4, True, 'test', False, 'test')
    action_module_2 = ActionModule(True, True, True, 'test', True, False)
    action_module_3 = ActionModule(True, str_0, True, 'test', True, True)
    action_module_4 = ActionModule(True, bool_0, True, 'test', False, True)
    action_module_5 = ActionModule(str_0, True, True, 'test', True, 'test')

# Generated at 2022-06-25 06:41:28.538303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:41:31.577301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 2686.03
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    assert_equal(isinstance(action_module_0, ActionModule), True)
    assert_equal(isinstance(action_module_0, AnsibleModuleBase), True)


# Generated at 2022-06-25 06:41:33.751001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 9772.65
    str_0 = 'container_web_rbd'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:41:34.422495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:41:37.163564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 06:41:41.906770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 2346.933
    str_0 = '  '
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    var_0 = False
    var_1 = None
    action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 06:41:48.964305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 1038.8
    str_0 = 'FVQ'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    action_module_0.run()

# Create an instance of class ActionModule for testing
action_module_0 = ActionModule(False, 6379.5, False, '0J0X', False, ':5')

# Invoke method run of class ActionModule
try:
    test_ActionModule()
except Exception as exception:
    traceback.print_tb(exception.__traceback__)

# Invoke method run of class ActionModule
try:
    var_0 = action_run()
except Exception as exception:
    traceback.print_tb

# Generated at 2022-06-25 06:45:46.121151
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    bool_0 = False
    float_0 = 901.23
    str_0 = '@0*wQM#1T'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    action_module_0.run('@0*wQM#1T')
    float_0 = 36.5125
    str_0 = 'Ek:qX)7<Z'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    action_module_0.run('Ek:qX)7<Z')
    float_0 = 2339.20
    str_0 = '=Pd.054&|'
    action

# Generated at 2022-06-25 06:45:47.225470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run the code here
    test_case_0()

# Generated at 2022-06-25 06:45:51.903080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 4986.92
    str_0 = 'murano'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    return None


# Generated at 2022-06-25 06:45:53.095625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:45:57.718495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = 2686.03
    str_0 = 'virtuozzo'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)
    if action_module_0.verbosity != float_0:
        raise Exception("Failed to initialize ActionModule")

# Generated at 2022-06-25 06:46:01.363615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 6193.49
    str_0 = 'nonexistent'
    action_module_0 = ActionModule(bool_0, float_0, bool_0, str_0, bool_0, str_0)



# Generated at 2022-06-25 06:46:02.670512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #test_case_0()
    pass


# Generated at 2022-06-25 06:46:06.789329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 == None, 'run returns None'

# Generated at 2022-06-25 06:46:08.308538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_0 = ActionModule()
    run_0.run()
    return


# Generated at 2022-06-25 06:46:10.163568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert len(a) == 10
    except:
        assert len(b) == 10
