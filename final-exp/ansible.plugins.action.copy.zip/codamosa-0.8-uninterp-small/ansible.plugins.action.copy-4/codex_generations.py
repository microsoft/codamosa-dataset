

# Generated at 2022-06-25 06:37:26.840837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    test_case_0()

### MAIN ###
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:37.938029
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:37:46.670661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__

    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the command method
    # Test the

# Generated at 2022-06-25 06:37:52.917764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [1, 2, 3]
    list_1 = list_0
    assert len(list_0) == len(list_1)
    for i in range(len(list_0)):
        assert list_0[i] == list_1[i]


# Generated at 2022-06-25 06:37:55.003633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:59.632534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1
    bytes_0 = b'S\x8aZ>\x1b\x83\x95\xc4\xdd\xd9\xa0-0D\x069\x1e'
    list_0 = [bytes_0, bytes_0, bytes_0]
    bytes_1 = b'\xdd\xef\xe1\xa7\x8c\xcc\xb6\x93\xa7\x8e\x18\xeb\xec\x14\x07\x83'
    bool_0 = True
    list_1 = ['\xdd\xef\xe1\xa7\x8c\xcc\xb6\x93\xa7\x8e\x18\xeb\xec\x14\x07\x83']
    set_

# Generated at 2022-06-25 06:38:11.772176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_module_0 = ansible.module_utils.basic.AnsibleModule.__new__(ansible.module_utils.basic.AnsibleModule)
    ansible_module_0.params = dict()
    ansible_module_0.params['dest'] = 'dest'
    ansible_module_0.params['local_follow'] = True
    ansible_module_0.params['recurse'] = True
    ansible_module_0.params['content'] = 'content'
    ansible_module_0.params['original_basename'] = 'original_basename'
    ansible_module_0.params['checksum_dest'] = True
    ansible_module_0.params['mode'] = 'mode'
    ansible_module_0.params['backup'] = True
    ansible_

# Generated at 2022-06-25 06:38:13.830075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init a class instance
    action_module_0 = ActionModule()

    # Test method run
    # No exception should be thrown
    action_module_0.run()


# Generated at 2022-06-25 06:38:25.157044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bytes_0 = b'S\x8aZ>\x1b\x83\x95\xc4\xdd\xd9\xa0-0D\x069\x1e'
    list_0 = [bytes_0, bytes_0, bytes_0]
    bytes_1 = b'\xbe\xad\xed\xbe\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = True
    set_0 = {bool_0}
    action_module_0 = ActionModule(bytes_1, list_0, bytes_0, bool_0, list_0, set_0)

    # Unit test
    action_module_0.run()



# Generated at 2022-06-25 06:38:26.844952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:14.352016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 34
    int_1 = 0
    dict_0 = dict()
    action_module_0 = ActionModule(int_0, int_1, dict_0, int_0, int_1, int_1)
    action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 06:39:15.061750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:39:21.503714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 202.128737
    int_0 = -4098
    list_0 = []
    bytes_0 = b'\xad'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:32.507857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source_0 = 'x/y/z'
    dest_0 = 'x/y/z'
    # Testing the first constructor.
    float_0 = -7.48
    int_0 = -1487
    list_0 = []
    bytes_0 = b'\xed\x82\x89'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)

    # Testing the second constructor.
    action_module_1 = ActionModule(source_0, dest_0)
    assert action_module_1._task.args['src'] == source_0, "Fails if src is not equal."
    assert action_module_1._task.args['dest'] == dest_0, "Fails if dest is not equal."



# Generated at 2022-06-25 06:39:38.150177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -0.1223
    int_0 = 8
    list_0 = []
    bytes_0 = b'-\x0bT\xcf'
    float_1 = 30.5723
    float_2 = 0.1804

    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_1, float_2)
    assert action_module_0 is not None

# Unit tests for the run() method in the class ActionModule

# Generated at 2022-06-25 06:39:45.195524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 491.988777
    int_0 = -4450
    list_0 = [0.232775, 0.403429]
    bytes_0 = b'\x1f\xa2\xb8'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:39:46.671833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_test_case_0()
    test_case_0()

# Generated at 2022-06-25 06:39:47.695825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == var_0


# Generated at 2022-06-25 06:39:55.008016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1301.0
    int_0 = 9820
    list_0 = [bool(0), bool(0), bool(0), bool(0), bool(0), bool(0), bool(0), bool(0), bool(0), bool(0)]
    bytes_0 = b'\x12\x88\x16'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    tmp = None
    task_vars = dict()
    var_0 = action_module_0.run(tmp, task_vars)
    return var_0


# Generated at 2022-06-25 06:40:02.746630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    float_0 = 141.499697
    int_0 = -4594
    list_0 = []
    bytes_0 = b'\xef\x14'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    action_module_0.run()

if __name__ == '__main__':
    print('Testing core/actions/action_module.py')
    test_ActionModule_run()
    print('Testing completed')

# Generated at 2022-06-25 06:41:33.610989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create object of class ActionModule
    float_0 = 141.499697
    int_0 = -4594
    list_0 = []
    bytes_0 = b'\xef\x14'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)

    # Test run with parameters (tmp=None, task_vars=None)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:41:36.992372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -6.5904765845
    int_0 = -4648
    list_0 = []
    bytes_0 = b'\xaf\x89'
    float_1 = -1.3552421034
    float_2 = 5.3
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_1, float_2)


# Generated at 2022-06-25 06:41:41.804517
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:41:43.254800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:41:47.645126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 141.499697
    int_0 = -4594
    list_0 = []
    bytes_0 = b'\xef\x14'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)

# main()
if __name__ == '__main__':
    print('Testing')
    test_ActionModule()
    print('Done.')

# Generated at 2022-06-25 06:41:55.904078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Constructor test')

# Generated at 2022-06-25 06:42:04.899579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2.2927
    int_0 = -24
    list_0 = ['2', '1', '!', '!', '!', '3', '!', '!', '!', '8', '6', '!', '!', '!', 'E', '!']
    bytes_0 = b'\x8f5\x92\x1e\x9b\x8d\xcf\x84\x19J\xab\x841\xeb\xd5\xf6\x9a\x0f\xac\xe2\xcc?\x8f\x0e\xd4\xef\xa9o\xf8\x1c\x91\x1c\x8e'

# Generated at 2022-06-25 06:42:09.158262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as exception:
        print('Line: {}: {}'.format(exception.__traceback__.tb_lineno, exception))
    else:
        print('test success')



# Generated at 2022-06-25 06:42:12.324207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.__class__.__name__ == 'ActionModule'
    assert isinstance(action_module_0._task, Task)


# Generated at 2022-06-25 06:42:14.297366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:45:48.815199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 75.153563
    int_0 = -903
    list_0 = []
    bytes_0 = b'\xef\x14'
    tuple_0 = ('',)
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    action_module_0.run(tuple_0, tuple_0)
    action_module_0.run(tuple_0, tuple_0)
    action_module_0.run(tuple_0, tuple_0)
    action_module_0.run(tuple_0, tuple_0)
    action_module_0.run(tuple_0, tuple_0)
    action_module_0.run(tuple_0, tuple_0)

# Generated at 2022-06-25 06:45:53.998078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -210.0
    int_0 = -1743
    list_0 = []
    bytes_0 = b'\xb1\x9e\xae'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)


# Generated at 2022-06-25 06:45:54.973584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:45:59.896338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 89.7
    int_0 = -4904
    list_0 = []
    bytes_0 = b'\x8e\x1f'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 06:46:03.623036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 141.499697
    int_0 = -4594
    list_0 = []
    bytes_0 = b'\xef\x14'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    
    

# Generated at 2022-06-25 06:46:13.052212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 157.0889
    int_1 = 3863
    list_1 = [int_1, int_1, int_1]
    bytes_1 = b'\xfb\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf\xaf'
    action_module_0 = ActionModule(float_1, int_1, list_1, bytes_1, float_1, float_1)
    action_module_1 = ActionModule(float_1, int_1, list_1, bytes_1, float_1, float_1)


# Generated at 2022-06-25 06:46:17.068931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 141.499697
    int_0 = -4594
    list_0 = []
    bytes_0 = b'\xef\x14'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)


# Generated at 2022-06-25 06:46:18.841039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run(action_module_0.tmp, action_module_0.task_vars) == action_module_0.var_0

# Generated at 2022-06-25 06:46:24.795399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -348.339
    int_0 = 8621
    list_0 = []
    bytes_0 = b'\x0c'
    float_1 = -936.21
    float_2 = 0.439534
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_1, float_2)
    assert_equals(float_0, action_module_0.sleep_time)
    assert_equals(float_1, action_module_0.sleep_time)
    assert_equals(int_0, action_module_0.attempts)
    assert_equals(int_0, action_module_0.attempts)
    assert_equals(list_0, action_module_0.conn)
   

# Generated at 2022-06-25 06:46:31.428076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 141.499697
    int_0 = -4594
    list_0 = []
    bytes_0 = b'\xef\x14'
    action_module_0 = ActionModule(float_0, int_0, list_0, bytes_0, float_0, float_0)
    bool_0 = action_module_0.check_mode()
    bool_1 = action_module_0.no_log()
    bool_2 = action_module_0.always_run()
    bool_3 = action_module_0.supports_check_mode()
    bool_4 = action_module_0.dump_results()
    bool_5 = action_module_0.delete_remote_tmp()
    bool_6 = action_module_0.supports_async()
    bool_7