

# Generated at 2022-06-25 06:37:30.187682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test'
    float_0 = -1169.2
    bool_0 = True
    bytes_0 = b'\xed'
    bool_1 = False
    set_0 = set()
    action_module_0 = ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)
    tmp_0 = None
    task_vars_0 = str_0
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except Exception as exception_0:
        test_0 = exception_0
        del exception_0


if __name__ == '__main__':
    # test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:37:35.538983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assert instance attributes of class ActionModule
    action_module_0 = ActionModule()
    # Assert type of attribute has_target of class ActionModule
    assert hasattr(action_module_0, 'has_target')
    # Assert False for attribute has_target of class ActionModule
    assert not getattr(action_module_0, 'has_target')
    # Assert type of attribute _uses_shell of class ActionModule
    assert hasattr(action_module_0, '_uses_shell')
    # Assert False for attribute _uses_shell of class ActionModule
    assert not getattr(action_module_0, '_uses_shell')
    # Assert type of attribute _task_has_become of class ActionModule
    assert hasattr(action_module_0, '_task_has_become')
    # Ass

# Generated at 2022-06-25 06:37:44.749071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'n=x'
    float_0 = -60.3
    bool_0 = False
    bytes_0 = b'D'
    bool_1 = True
    set_0 = set()
    action_module_0 = ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)
    str_1 = '6??'
    float_1 = 658.6
    bool_2 = False
    bytes_1 = b'V'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['exception'] = str_1
    dict_1['failed'] = bool_2
    dict_1['msg'] = str_1
    dict_0['failed'] = dict_1
    dict_0['msg'] = str

# Generated at 2022-06-25 06:37:56.969938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tt=z'
    str_1 = 'tt=z'
    float_0 = -138.0
    bool_0 = True
    bytes_0 = b'\xa8'
    bool_1 = True
    set_0 = set()
    action_module_0 = ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)
    action_module_0._inject_facts(str_1)
    action_module_0.get_handler(float_0, str_1)
    action_module_0.add_cleanup_file(bytes_0)
    action_module_0.add_cleanup_path(str_1)
    action_module_0.push_cleanup()
    action_module_0.pop_clean

# Generated at 2022-06-25 06:38:05.444282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0.12 , -3.0, True, b'j\x1b', False, set([1.0]))
    str_0 = 'tt=z'
    float_0 = -138.0
    bool_0 = True
    bytes_0 = b'\xa8'
    set_0 = set()
    result = action_module_0.run(str_0, float_0, bool_0, bytes_0, set_0)
    print(result)


# Generated at 2022-06-25 06:38:15.287628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'tt=z'
    float_0 = -138.0
    bool_0 = True
    bytes_0 = b'\xa8'
    bool_1 = False
    set_0 = set()
    action_module_0 = ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)
    action_module_0._ensure_invocation(set_0)
    action_module_0._connection._connection_info.update(set_0)
    action_module_0._execute_module(str_0, set_0)
    action_module_0._execute_module(str_0, set_0, set_0)
    action_module_0._execute_module(str_0, set_0, set_0)
    action_

# Generated at 2022-06-25 06:38:16.458094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('== Test case 0 ==')
    test_case_0()



# Generated at 2022-06-25 06:38:27.604021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{3,0!kv!r#'
    float_0 = +-103.0
    bool_0 = True
    bytes_0 = b'\xb1\\y\xdd\xad'
    bool_1 = True
    set_0 = {'{o~^\x83C\x19\xaa\xb4\xc1\x12H\x02\xcb\x98\x04\x02\t\x1a\x1c\x19\x1b\xca'}
    action_module_0 = ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)
    action_module_0.run()
    print('unit_test: test_ActionModule_run: unit test completed')

# Unit

# Generated at 2022-06-25 06:38:31.341815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tt=z'
    float_0 = -138.0
    bool_0 = True
    bytes_0 = b'\xa8'
    bool_1 = True
    set_0 = set()
    ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)


# Generated at 2022-06-25 06:38:37.426597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'X'
    float_0 = -42.0
    bool_0 = True
    bytes_0 = b'\xcf'
    bool_1 = True
    set_0 = {(0, 77, b'\xa4\x03\x8b\x9a\xa1 K\x10')}
    action_module_0 = ActionModule(str_0, float_0, bool_0, bytes_0, bool_1, set_0)
    str_1 = 'gB\x1c\x8e\x19\x91\x05\x89\xd8\x12\xb6'
    action_module_0.run(str_1)
    str_2 = 'm\x8d\xdd'
    dict_0 = {}
    action_module_0

# Generated at 2022-06-25 06:39:15.597679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:39:16.915421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(str(ActionModule))


# Generated at 2022-06-25 06:39:28.553786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config_data = {'ANSIBLE_NET_CONFIG_DEBUG': 'True'}
    config_data['ANSIBLE_LIBRARY'] = cfg_library_path
    config_data['ANSIBLE_MODULE_UTILS'] = cfg_module_utils_path
    config_data['ANSIBLE_ROLES_PATH'] = cfg_roles_path
    config_data['ANSIBLE_FILTER_PLUGINS'] = cfg_filter_plugins_path
    config_data['ANSIBLE_ACTION_PLUGINS'] = cfg_action_plugins_path
    config_data['ANSIBLE_CALLBACK_PLUGINS'] = cfg_callback_plugins_path
    config_data['DEFAULT_ROLES_PATH'] = cfg_default_roles_path

# Generated at 2022-06-25 06:39:30.026396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    print(var_0)


# Generated at 2022-06-25 06:39:32.134049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('== Test ActionModule ==')
    var_0 = ActionModule()


# Generated at 2022-06-25 06:39:35.068306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '== Test method run of class ActionModule =='
    var_0 = print(str_0)

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 06:39:46.716635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 'ansible.plugins.action.copy'
    # the params are the same like the ActionModule class constructor
    helper_0 = ActionPluginLoader.get(var_0, task=task, connection=connection, play_context=play_context, loader=loader, templar=templar)
    if helper_0 is not None:
        print('ActionModule() constructor works')
    else:
        print('ActionModule() constructor failed')

if __name__ == '__main__':
    from ansible.plugins.action.copy import ActionModule

    task = ansible.playbook.task.Task()
    connection = ansible.plugins.connection.Connection()
    play_context = ansible.playbook.play_context.PlayContext()
    loader = ansible.parsing.dataloader.DataLoader()


# Generated at 2022-06-25 06:39:56.236574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    md0 = dict(
        dest = 'dest',
        src = 'src'
    )
    print('Testing ActionModule.run()')
    print('    md0 = ')
    print(md0)
    #print('    md0 = ', md0)
    md1 = dict(
        content = 'content'
    )
    print('    md1 = ')
    print(md1)
    #print('    md1 = ', md1)
    md2 = dict(
        remote_src = 'remote_src'
    )
    print('    md2 = ')
    print(md2)
    #print('    md2 = ', md2)
    md3 = dict(
        local_follow = 'local_follow'
    )
    print('    md3 = ')

# Generated at 2022-06-25 06:39:59.125957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '== Test ActionModule constructor =='
    var_1 = print(str_1)

    var_2 = ActionModule()


# Generated at 2022-06-25 06:40:00.287465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(str(file_transfer.ActionModule().run))


# Generated at 2022-06-25 06:40:47.348834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\n[Test] test_case_0()')
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:40:51.684821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    action_module = ActionModule()
    args = {'src': 'test_file'}
    action_module._task.args = args

    # Act
    result = action_module.run({}, {})

    # Assert
    assert result['result']['failed'] == True
    assert result['result']['msg'] == 'dest is required'


# Generated at 2022-06-25 06:40:58.104693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test return value of function _create_remote_file_args
    ret_val = _create_remote_file_args({})
    # Check ret_val is type dict
    assert isinstance(ret_val, dict)
    # Check ret_val is equal to {'recurse': 'no', 'mode': '0664', 'owner': 'root', 'group': 'root'}
    assert ret_val == {'recurse': 'no', 'mode': '0664', 'owner': 'root', 'group': 'root'}


# Generated at 2022-06-25 06:40:59.224998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run()

# Generated at 2022-06-25 06:41:00.898856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    action_module_1.run()

if __name__ == "__main__":
    #unittest.main()
    test_ActionModule_run()
    pass

# Generated at 2022-06-25 06:41:08.487458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    action_module_0 = ActionModule()
    action_module_0._task.args['src'] = '/file/source'
    action_module_0._task.args['dest'] = '/file/destination'
    action_module_0._task.args['checksum'] = 'sha1:b1946ac92492d2347c6235b4d2611184'
    action_module_0._task.args['follow'] = False
    action_module_0._task.args['force'] = True
    action_module_0._task.args['backup'] = False
    action_module_0._task.args['local_follow'] = True
    action_module_0._task.args['unsafe_writes'] = True

# Generated at 2022-06-25 06:41:12.355686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if not (isinstance(action_module_0, ActionModule) and action_module_0.__class__ == ActionModule):
        print('Failed to create an instance of ActionModule')
        return 1
    else:
        return 0


# Generated at 2022-06-25 06:41:13.064400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:41:14.706367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule
    assert isinstance(action_module_1, object)



# Generated at 2022-06-25 06:41:22.793592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #print("\n Unit test for method run of class ActionModule")
    action_module_0 = ActionModule()

    # test for src = None and content = None
    #print("\n Test 1: src = None and content = None")
    task = dict(src = None, content = None, dest = "dest_path")
    action_module_0._task = dict(args = task, action = 'action', name = 'name')
    result = action_module_0.run()
    assert (result.get('failed') == True)
    assert (result.get('msg') == "src (or content) is required")
    
    # test for dest = None
    #print("\n Test 2: dest = None")
    task = dict(src = "src_path", content = None, dest = None)
    action_module

# Generated at 2022-06-25 06:42:10.791564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Invoke constructor of class ActionModule
    action_module_0 = ActionModule()
    # if ERROR is thrown, it means constructor invoked failed
    print("test_ActionModule complete")


# Generated at 2022-06-25 06:42:11.763525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:42:20.725371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n===Test case 1: test_ActionModule_run")

    action_module_obj = ActionModule()

    #test_case_0: test run with valid args
    tmp = {"remote_user":"test_user"}

# Generated at 2022-06-25 06:42:25.476143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    action_module_0 = ActionModule()
    action_module_0.set_task_vars(task_vars)
    action_module_0.set_connection_info(host_variable_name='hostvars', transport="ssh")
    action_module_0._display._verbosity=0
    action_module_0.set_loader(DataLoader())
    action_module_0.set_task(MockTask())
    action_module_0._templar = Templar(loader=action_module_0._loader)
    action_module_0._display.verbosity = 4
    action_module_0._task.action = "copy"
    action_module_0._task.args = {'src': 'src', 'dest': "dest", 'local_follow': 'True'}


# Generated at 2022-06-25 06:42:31.180806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    params_dict = {}
    params_dict['content'] = 'test_str'
    params_dict['owner'] = 'test_str'
    params_dict['force'] = True
    params_dict['checksum'] = 'test_str'
    params_dict['follow'] = True
    params_dict['dest'] = 'test_str'
    params_dict['backup'] = 'test_str'
    params_dict['group'] = 'test_str'
    params_dict['divider'] = 'test_str'
    params_dict['src'] = 'test_str'
    params_dict['remote_src'] = True
    params_dict['regexp'] = 'test_str'
    params_dict['directory_mode'] = 'test_str'
    params

# Generated at 2022-06-25 06:42:33.729144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    str_0 = str(action_module_0)
    assert "ActionModule" in str_0
    repr_0 = repr(action_module_0)
    assert "ActionModule" in repr_0


# Generated at 2022-06-25 06:42:36.997828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    # when
    result = action_module_run_0.run()
    # then
    action_module_run_0.assert_dict('result', result, 'ansible_job_id')
    action_module_run_0.assert_dict('result', result, 'ansible_facts')
    action_module_run_0.assert_dict('result', result, 'invocation')


# Generated at 2022-06-25 06:42:38.094427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:42:43.907300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_executed = False
    action_module_run = ActionModule()
    source = "some source"
    source_files = {'files': [('some source 1', 'some source 1')], 'directories': [('some source 2', 'some source 2')], 'symlinks': [('some target path', 'some dest path')]}
    dest = "some destination"
    content = "some content"
    task_vars = {"ansible_module_executed": module_executed}
    result = action_module_run.run(None, task_vars)
    assert result['failed'] is True
    assert "src " in result['msg']
    assert "dest" in result['msg']
    result = action_module_run.run(None, task_vars)
    assert result['failed'] is True

# Generated at 2022-06-25 06:42:48.018263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock_self = mock.MagicMock()
    # mock_self._execute_module = mock.MagicMock()
    # mock_self._execute_module.return_value = {'msg': 'mock_msg'}
    # result = ActionModule.run(mock_self)
    # assert result == {'msg': 'mock_msg'}
    return

# Generated at 2022-06-25 06:43:58.054100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1.0

# Generated at 2022-06-25 06:44:08.262043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -618.3
    bytes_0 = b'\xe0\xf3\xeb\xa6\xff\x1d\xb2\xb7\x12\x87'
    float_1 = -667.81887
    bytes_1 = b'\x1c\x9e\xfb\xf4\x1a\x7f\x90\x00\x86\x80'
    int_0 = 28
    float_2 = -527.3
    bytes_2 = b'\xfd\xca\x9b'
    bytes_3 = b'\x1c\x9e\xfb\xf4\x1a\x7f\x90\x00\x86\x80'

# Generated at 2022-06-25 06:44:14.650735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -742.932
    str_0 = '%\xb8\x00\x95\x91\x89\x92'
    float_1 = -924.83
    bytes_0 = b'!\x97-\x1c\xc2\x8e'
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, bytes_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:44:17.751427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.
    str_0 = 'rM-I\\{\x0cuO'
    float_1 = -953.0
    str_1 = '*'
    float_2 = -993.20
    bytes_0 = b'\xae\x10\x95\x8f\xe6m\x1a}ex\x87BC'
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, bytes_0)
    del action_module_0

# Generated at 2022-06-25 06:44:26.585392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 4.806870995712229E307
    str_0 = '\x1a\x11\x18\x1a\x1c\n\x00\x13\x00\x01\x00\x1b\x00\x1d'
    float_1 = -19016.844
    str_0 = '\x01\x00\x03\x00\x01\x00\r\x00\x0e\x00\x1b\x00\x03'
    float_0 = -1.1149046041540204E308

# Generated at 2022-06-25 06:44:34.628417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1094.99847
    str_0 = '*rM-I\\{\x0cuO'
    float_1 = -916.8
    bytes_0 = b'\xb1\x7f\xae\x10\x95\x8f\xe6m\x1a}ex\x87BC'
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, bytes_0)
    assert (action_module_0.dest == float_0)
    assert (action_module_0.content == str_0)
    assert (action_module_0.backup is None)
    assert (action_module_0.follow is None)
    assert (action_module_0.changed is False)

# Generated at 2022-06-25 06:44:42.698157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1094.99847
    str_0 = '*rM-I\\{\x0cuO'
    float_1 = -916.8
    bytes_0 = b'\xb1\x7f\xae\x10\x95\x8f\xe6m\x1a}ex\x87BC'
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, bytes_0)
    var_0 = action_run(float_0)

# Generated at 2022-06-25 06:44:48.898157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1094.99847
    str_0 = '*rM-I\\{\x0cuO'
    float_1 = -916.8
    bytes_0 = b'\xb1\x7f\xae\x10\x95\x8f\xe6m\x1a}ex\x87BC'
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, bytes_0)
    var_0 = action_run(float_0)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:44:52.843110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1094.99847
    str_0 = '*rM-I\\{\x0cuO'
    float_1 = -916.8
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, str_0)
    test_case_0()


# Generated at 2022-06-25 06:44:58.665378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1094.99847
    str_0 = '*rM-I\\{\x0cuO'
    float_1 = -916.8
    bytes_0 = b'\xb1\x7f\xae\x10\x95\x8f\xe6m\x1a}ex\x87BC'
    action_module_0 = ActionModule(float_0, str_0, float_1, str_0, float_0, bytes_0)
    var_0 = action_module_0.run()
    print(var_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()