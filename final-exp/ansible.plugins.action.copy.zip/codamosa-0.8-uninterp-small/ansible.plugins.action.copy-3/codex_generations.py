

# Generated at 2022-06-25 06:37:22.741288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:23.823299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:26.295456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:31.299211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('\x17', True, True, '\x19', 947, True)
    map_0 = {}
    action_module_0.run(map_0, map_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:37:32.638757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:33.692941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:43.072519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: mock ActionModule._encode_templates, ActionModule._execute_module, ActionModule._copy_file
    # and ActionModule._remote_expand_user
    action_module_0 = ActionModule('', True, True, '', 947, True)
    action_module_0.action_loader = ActionLoader()
    action_module_0.action_loader.add_directory(os.path.expanduser(os.path.join('~', 'ansible', 'test', 'units', 'module_utils', 'netconf')))
    action_module_0.action_loader.add_directory(os.path.join(str(Path(__file__).parent), 'netconf'))

    # TODO: mock ActionModule._get_remote_filename and ActionModule._remote_checksum

# Generated at 2022-06-25 06:37:48.451464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'yO<+%&!@'
    int_0 = 700
    action_module_0 = ActionModule(str_0, bool_0, bool_0, str_0, int_0, bool_0)
    action_module_0.run()



if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    # Uncomment the following line for more information about the execution
    # print(inspect.getsource(inspect.getmodule(ActionModule)))

# Generated at 2022-06-25 06:37:52.329145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare objects and variables
    str_0 = ''
    bool_0 = True
    tmp = str_0
    task_vars = dict()
    action_module_0 = ActionModule(str_0, bool_0, bool_0, str_0, 947, bool_0)

    # Call the method
    result = action_module_0.run(tmp, task_vars)

    # Return the result
    return result

if __name__ == '__main__':
    # Call the unit test
    print(test_ActionModule_run())

# Generated at 2022-06-25 06:37:57.481024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = ''
    int_0 = 878
    action_module_0 = ActionModule(str_0, bool_0, bool_0, str_0, int_0, bool_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:39:07.455752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:13.186787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool()
    str_0 = ''
    int_0 = int()
    action_module_0 = ActionModule(str_0, bool_0, bool_0, str_0, int_0, bool_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:39:22.432284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _loader = DataLoader()
    _connection = Connection(module_name='ansible.legacy.copy')
    _task = Task(action=dict())
    _play_context = PlayContext()
    _action_module = ActionModule(
        _loader,
        _connection,
        _task,
        _play_context,
        make_vars=False,
        ansible_version=2.8)
    arg_0 = dict()
    arg_1 = dict()
    ans_0 = _action_module.run(arg_0, arg_1)

# Generated at 2022-06-25 06:39:24.468739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check if test method is called.
    assert test_case_0() == None

# Generated at 2022-06-25 06:39:25.533782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:39:27.303286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:28.451877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:39:30.347149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:32.784641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test of constructor for class ActionModule")
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:35.290366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('foo', 'foo', 'foo', 'foo', 5, 'foo')
    assert action_module_0.run() == None


# Generated at 2022-06-25 06:41:08.370691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    pass

# Generated at 2022-06-25 06:41:10.396885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test for method run of class ActionModule'
    var_0 = print(str_0)


# Generated at 2022-06-25 06:41:13.421320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test of run for class ActionModule'
    var_0 = print(str_0)

# Main code
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:41:16.735273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test of method run of class ActionModule'
    var_0 = print(str_0)

#
# main
#
if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:41:18.333323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('unit test for constructor of class ActionModule')
    test_case_0()


# Generated at 2022-06-25 06:41:20.172653
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:41:21.539534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    test_class_ActionModule = ActionModule()
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:41:25.201536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = {}
    arg_1 = 'ansible.legacy.copy'
    arg_2 = 'ActionModule'
    arg_3 = ''
    action_module = ActionModule(arg_0, arg_1, arg_2, arg_3)
    test_case_0()

# Generate test case
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:41:26.809184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("Unit tests for constructor of class ActionModule are completed")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:41:28.538557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule() called')
    test_case_0()

# Unit test execution
test_ActionModule()

# Generated at 2022-06-25 06:42:44.370334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # target:
    #     def __init__(self, task=None, connection=None, play_context=None,
    #                  loader=None, templar=None, shared_loader_obj=None):
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:42:45.590637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test of method run of class ActionModule'
    var_0 = print(str_0)


# Generated at 2022-06-25 06:42:50.024824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = var_0._low_level_execute_command('uname', use_unsafe_shell=True, executable='/bin/sh')
    var_2 = print(var_1)


# Generated at 2022-06-25 06:42:51.856610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_object = ActionModule(data=None)
    assert class_object.run()


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 06:42:52.906101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:43:01.556408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_9 = type(u'test_case_0', (object,), {u'__module__': u'test_ActionModule', u'__qualname__': u'test_case_0', u'__doc__': None, u'test_case_0': test_case_0})
    var_10 = type(u'TestActionModule', (unittest.TestCase,), {u'__module__': u'test_ActionModule', u'__qualname__': u'TestActionModule', u'__init__': lambda self: unittest.TestCase.__init__(self, u'test_case_0')})
    var_9.test_case_0 = staticmethod(var_9.test_case_0)
    unittest.main()


# Generated at 2022-06-25 06:43:02.676299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:43:04.057659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test of method run for class ActionModule'
    var_0 = print(str_0)


# Generated at 2022-06-25 06:43:10.789596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# add python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + os.sep + os.pardir)

# add ansible module path
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + os.sep + 'ansible_module/lib/')

if __name__ == '__main__':
    # test_ActionModule()

    # action module object
    action_0 = ActionModule()
    # get task obj
    task_0 = action_0._task
    # print task_0
    # print action_0.__class__.__bases__[0].__dict__
    # print (action_0.__class__.__bases__[0

# Generated at 2022-06-25 06:43:11.942197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("In test_ActionModule")   # Output to stdout
    test_case_0()


# Generated at 2022-06-25 06:44:37.801444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    result = dict(failed=False)
    setattr(self, 'content', None)
    setattr(self, 'version_added', None)
    setattr(self, 'remote_user', None)
    setattr(self, 'remote_src', None)
    setattr(self, 'owner', None)
    setattr(self, 'group', None)
    setattr(self, 'selevel', None)
    setattr(self, 'serole', None)
    setattr(self, 'setype', None)
    setattr(self, 'seuser', None)
    setattr(self, 'content', None)
    setattr(self, 'create', None)
    setattr(self, 'force', None)

# Generated at 2022-06-25 06:44:46.394816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = os.path.join(TEST_DIR_ABS, 'test_case_0.py')
    str_0 = 'module_utils.basic import AnsibleModule'
    str_1 = 'module_utils.basic import AnsibleModule'
    def test_call(self):
        var_1 = MyTask(self, str_0)
        var_2 = var_1.run()
        assert var_2 == var_2.get('msg')
    mock_0 = patch(str_1, side_effect=test_call)
    mock_0.start()
    str_1 = 'module_utils.connection import Connection'
    str_2 = 'module_utils.connection import Connection'
    def test_call(self):
        var_3 = MyTask(self, str_0)
        var_

# Generated at 2022-06-25 06:44:48.865557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Ensure that the class exists and it runs without an Exception
    try:
        slf = ActionModule()
        slf.run()
    except Exception as e:
        assert False, 'ActionModule.run raised Exception: ' + e.message


# Generated at 2022-06-25 06:44:51.749343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = print('test of constructor for class ActionModule')

    var_1 = Task()
    var_2 = ActionModule(var_1)

    var_3 = print(var_2)


# Generated at 2022-06-25 06:44:52.277681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()

# Generated at 2022-06-25 06:44:54.502352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
        )


# Generated at 2022-06-25 06:44:56.241104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test of run method for class ActionModule'
    var_0 = print(str_0)



# Generated at 2022-06-25 06:45:01.423797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '''
- name: test file
  tags:
  - test file
  - test path
  - test run
  - test action
  - test copy
  copy:
    src: /home/student/recursive_copy/
    dest: /tmp/
    remote_src: false
    follow: false
    flat: false
    local_follow: false
    content: null
'''
    var_1 = '''
- name: test file
  tags:
  - test file
  - test path
  - test run
  - test action
  - test copy
  copy:
    src: /home/student/recursive_copy/
    dest: /tmp/
    remote_src: false
    follow: false
    flat: false
    local_follow: false
    content: null
'''

# Generated at 2022-06-25 06:45:02.977121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test for method run of class ActionModule'
    var_0 = print(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:45:04.873421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = isinstance(ActionModule(), ActionModule)
    if (var_0):
        test_case_0()
    var_0 = isinstance(ActionModule(), ActionBase)
    if (var_0):
        test_case_0()
