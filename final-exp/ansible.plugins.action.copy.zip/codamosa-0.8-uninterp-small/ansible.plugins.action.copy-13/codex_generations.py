

# Generated at 2022-06-25 06:37:28.793667
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:37:39.294715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule('src', 'content', 'dest', 'remote_src', 'local_follow')
    assert action_module_0._task.args.get('src') == 'src'
    assert action_module_0._task.args.get('content') == 'content'
    assert action_module_0._task.args.get('dest') == 'dest'
    assert action_module_0._task.args.get('remote_src') == 'remote_src'
    assert action_module_0._task.args.get('local_follow') == 'local_follow'
    assert action_module_0.action_type == 'copy'
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:37:47.591682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf7\xd5\x02\xc9b\xf8\xcd`\xb1\xda\x0f\xf9f\x01\xa1'
    bool_0 = True
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0}
    float_0 = -635.2296
    int_0 = -1086
    action_module_0 = ActionModule(bytes_0, dict_0, float_0, dict_0, int_0, dict_0)
    # Assert instance variables
    assert action_module_0._task == bytes_0
    assert action_module_0._play_context == dict_0
    assert action_module_0._loader == dict_0
    assert action_module_0._templar == float_

# Generated at 2022-06-25 06:37:57.112061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf7\xd5\x02\xc9b\xf8\xcd`\xb1\xda\x0f\xf9f\x01\xa1'
    bool_0 = True
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0}
    float_0 = -635.2296
    int_0 = -1086
    action_module_0 = ActionModule(bytes_0, dict_0, float_0, dict_0, int_0, dict_0)


# Generated at 2022-06-25 06:38:00.529289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:12.403678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {'msg': 'msg_0'}
    task_vars = {'vars_0': 'vals_0'}
    tmp = {'tmp_0': -106.0971}
    action_module_0 = ActionModule('src_0', 'args_0', -633.8323, 'tmp_0', -1061, result)
    dest = 'dest_0'
    remote_src = False
    follow = False
    content = 'content_0'
    local_follow = False
    action_module_0._copy_file = MagicMock(return_value = result)
    action_module_0._gen_tmp_path = MagicMock(return_value = 'tmp_path_0')
    action_module_0._execute_module = MagicMock(return_value = result)
   

# Generated at 2022-06-25 06:38:20.297995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf7\xd5\x02\xc9b\xf8\xcd`\xb1\xda\x0f\xf9f\x01\xa1'
    bool_0 = True
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0}
    float_0 = -635.2296
    int_0 = -1086
    action_module_0 = ActionModule(bytes_0, dict_0, float_0, dict_0, int_0, dict_0)



# Generated at 2022-06-25 06:38:28.022759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf7\xd5\x02\xc9b\xf8\xcd`\xb1\xda\x0f\xf9f\x01\xa1'
    bool_0 = True
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0}
    float_0 = -635.2296
    int_0 = -1086
    action_module_0 = ActionModule(bytes_0, dict_0, float_0, dict_0, int_0, dict_0)
    action_module_0.run(None, {});


# Generated at 2022-06-25 06:38:34.879458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x00\xc2\x00\x00\x08\x00\x01\x00\x00\x00\x00\x00'
    bool_0 = True
    dict_0 = {bool_0: bytes_0, bytes_0: bytes_0}
    float_0 = -635.2296
    int_0 = -1086
    action_module_0 = ActionModule(bytes_0, dict_0, float_0, dict_0, int_0, dict_0)
    str_0 = '~'
    str_1 = 'S'
    str_2 = 'i'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'r'
    str_6 = ':'
    str_7 = ' '

# Generated at 2022-06-25 06:38:44.876366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '@'
    bytes_0 = b'^'
    bytearray_0 = bytearray()

# Generated at 2022-06-25 06:39:26.390262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    assert var_1.run(var_1, var_1)


# Generated at 2022-06-25 06:39:33.692271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.dataloader
    df_ldr = ansible.parsing.dataloader.DataLoader()
    vars = dict()
    play = Play()

    #Create task
    task = Task()
    task.action = 'copy'
    task.register = 'result'

    # Create connection
    connection = Connection(play, task)

    module = copy.ActionModule(df_ldr, connection, play, task)

# Unit test_execute when file name is not found

# Generated at 2022-06-25 06:39:39.671610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'k'
    bytes_1 = b'~'
    var_1 = bytearray()
    var_1 = bytearray()
    var_2 = bytearray()
    var_3 = bytearray()
    var_3 = bytearray()
    var_4 = bytearray()
    var_4 = bytearray()
    var_5 = bytearray()


# Generated at 2022-06-25 06:39:41.907217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Execute constructor of class ActionModule
    test_case_0()


# Generated at 2022-06-25 06:39:52.530310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '20:0,21:2'
    bytes_0 = b'^'
    var_0 = bytearray()
    var_1 = dict()
    str_1 = '~|'
    str = '_'
    list_0 = list()
    var_2 = None
    var_3 = int()
    var_4 = float()
    var_5 = str()
    var_6 = bytes()
    var_7 = bytearray()
    var_8 = dict()
    var_9 = list()
    var_10 = set()
    var_11 = frozenset()
    var_12 = tuple()
    var_13 = None
    str_2 = '+'
    dict_0 = dict()

# Generated at 2022-06-25 06:39:55.215167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert(result == None)

# Generated at 2022-06-25 06:40:01.899816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_0 = AnsibleHost()
    _task_0 = AnsibleTask()
    _task_0.host = host_0
    action_module_0 = ActionModule()
    action_module_0._task = _task_0
    action_module_1 = ActionModule()
    action_module_1._task = _task_0
    action_module_2 = ActionModule()
    action_module_2._task = _task_0


# Generated at 2022-06-25 06:40:04.528894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except ValueError:
        assert False
    except TypeError:
        assert False
    except:
        assert False

# test_ActionModule()

# Generated at 2022-06-25 06:40:05.566238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:40:08.247247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor with argument argspec
    argspec = dict()
    test_obj = ActionModule(argspec)
    assert test_obj._task._ds is None


# Generated at 2022-06-25 06:41:00.730455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 = ActionModule('local', {}, {}, 'local-2')
    var_0 = None
    assert var_0 is not None, 'var_0 construction failed'


# Generated at 2022-06-25 06:41:08.426571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0 = {"remote_user": "couchdb", "delegate_to": "couchdb"}

# Generated at 2022-06-25 06:41:17.707106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    file_1 = dict()
    file_1['src'] = 'abc'
    file_2 = dict()
    file_2['src'] = 'def'

    var_0 = dict()
    var_0['src'] = 'abc'
    var_0['dest'] = 'def'
    var_0['action'] = 'copy'
    var_0['delegate_to'] = 'localhost'
    var_0['_ansible_no_log'] = False
    var_0['_ansible_verbosity'] = 0
    var_0['_ansible_syslog_facility'] = 'LOG_USER'
    var_0['_ansible_selinux_special_fs'] = list()
    var_0['_ansible_diff'] = False

# Generated at 2022-06-25 06:41:18.651127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:41:19.857810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_file = ActionModule()
    assert test_file is not None


# Generated at 2022-06-25 06:41:21.910428
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a new instance of class ActionModule
    var_1 = ActionModule()

    # Call run of class ActionModule
    var_1.run(var_0, var_0)

# Generated at 2022-06-25 06:41:28.182378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    var_0 = dict()
    var_1 = None
    var_2 = dict()
    var_2['dest'] = 'path_to_file'
    var_2['follow'] = 'False'
    var_2['content'] = 'content'
    var_2['remote_src'] = 'False'
    var_2['local_follow'] = 'False'
    var_2['extra_arguments'] = '[]'
    var_2['encoding'] = None
    var_2['backup'] = 'False'
    var_2['force'] = 'False'
    var_2['checksum_algorithm'] = 'sha1'
    var_2['validate_certs'] = 'False'
    var_2['directory_mode'] = None
    # Call method run

# Generated at 2022-06-25 06:41:32.078368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    obj = ActionModule(action_exec_id='test_action_exec_id', task_vars=task_vars)
    tmp = None
    obj.run(tmp=tmp, task_vars=task_vars)

test_case_0()
#test_ActionModule_run()

# Generated at 2022-06-25 06:41:36.710329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    temp_file_name = tempfile.mktemp()

    class Connection:
        def __init__(self, shell):
            self._shell = shell
            self.cmd_count = 0
            self._shell.cmd_count = 0

        def exec_command(self, cmd, tmp_path, sudoable=True):
            self._shell.last_cmd = cmd
            self._shell.cmd_count += 1
            self.cmd_count += 1
            return cmd

        def join_path(self, *paths):
            if len(paths) > 1:
                return self._shell.join_path(*args)
            else:
                return paths[0]

        def split_path(self, path):
            return self._shell.split_path(path)


# Generated at 2022-06-25 06:41:40.347229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var = {}
# Case 0
    var_0 = {}
    try:
        var = ActionModule(var_0)
    except Exception as e:
        print(e)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:42:35.165572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the class ActionModule
    action_module_0 = ActionModule()

    # Create a variable, var_0, as a dict
    var_0 = dict()

    # Call the method run with arguments tmp and task_vars
    # Result of call action_module_0.run(tmp=, task_vars=)
    # Expected value returned by run: None
    result_run = action_module_0.run(var_0, var_0)

    # Check if the result of call method run equals expected value; False
    # assert result_run != None, 'ActionModule::run did not return expected value'


# Generated at 2022-06-25 06:42:36.066162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 06:42:41.711461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule

    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_

# Generated at 2022-06-25 06:42:45.264963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = "the src file to copy.  (aliases: name, dest)"
    var_2 = "the destination file/path.  (aliases: dest)"
    var_3 = None
    obj_4 = ActionModule(var_1, var_2, var_3)
    obj_5 = obj_4.run(tmp=None, task_vars=None)
    assert obj_5 == None


# End of unit test for method run of class ActionModule

# Generated at 2022-06-25 06:42:55.792757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    attr_0 = dict()
    attr_1 = dict()
    attr_1['args'] = 'Test ActionModule args'
    attr_1['_uses_shell'] = False
    attr_1['_task'] = 'Test ActionModule _task'
    attr_1['_connection'] = 'Test ActionModule _connection'
    attr_1['_loader'] = 'Test ActionModule _loader'
    attr_1['_task_vars'] = 'Test ActionModule _task_vars'
    attr_1['_play_context'] = 'Test ActionModule _play_context'
    attr_1['_shared_loader_obj'] = 'Test ActionModule _shared_loader_obj'
   

# Generated at 2022-06-25 06:43:01.183045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = mock.MagicMock()
    var_1.task_args = mock.MagicMock()
    var_1.task_args.get.return_value = var_0
    var_1.args = mock.MagicMock()
    var_1.args.get.return_value = var_0
    var_2 = mock.MagicMock()
    var_2.module_vars = mock.MagicMock()
    var_2.module_vars.get.return_value = var_0
    var_2.inventory = mock.MagicMock()
    var_2.inventory.get_hosts.return_value = [mock.MagicMock()]
    var_3 = mock.MagicMock()
    var_3.get_option.return_value

# Generated at 2022-06-25 06:43:03.184075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(module_name='module_0', task_vars=dict())
    # Unit test for method run
    test_case_0()



# Generated at 2022-06-25 06:43:05.118670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    obj = ActionModule(tmp, task_vars)
    obj.run(tmp, task_vars)


# Generated at 2022-06-25 06:43:07.542286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    assert "ActionModule" in globals()
    a_0 = ActionModule(var_0)
    assert a_0.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 06:43:08.816105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:45:24.948144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()

    # call the test function
    result = test_case_0()


# Generated at 2022-06-25 06:45:34.472708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_4 = dict()
    var_4 = dict()
    var_4 = dict()
    var_3 = ActionModule(var_4)
    var_5 = dict()
    var_6 = None
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = None
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6
    var_6 = var_6

# Generated at 2022-06-25 06:45:44.848271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_1['ansible_user'] = 'vagrant'
    var_1['ansible_connection'] = 'smart'
    var_1['ansible_ssh_user'] = 'vagrant'
    var_1['ansible_ssh_host'] = 'localhost'
    var_1['ansible_ssh_pass'] = 'vagrant'
    var_1['__item_port'] = '22'
    var_1['ansible_host'] = 'localhost'
    var_1['__item_host'] = 'localhost'
    var_2 = dict()
    var_2['_ansible_parsed'] = True
    var_2['ansible_facts'] = dict()

# Generated at 2022-06-25 06:45:53.435626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_var = None
    var_0 = dict()
    var_1 = None
    var_0 = {}
    var_2 = None
    var_0 = {}
    var_3 = None
    var_0 = {}
    var_4 = None
    var_0 = {}
    # main test logic
    # Creation of the class instance
    obj = ActionModule(var_0, var_1, var_2, var_3, var_4)
    # test if exceptions were raised
    assert test_var is None


# Generated at 2022-06-25 06:46:02.621928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    var_24 = dict()

# Generated at 2022-06-25 06:46:05.054018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_run")
    # Declare objects and variables
    var_0 = dict()


    # Call the function
    ret_0 = ActionModule_run(var_0)

    # Output results
    print(ret_0)

# Generated at 2022-06-25 06:46:07.473189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: what are you attempting to test here?
    # test_case_0()
    pass

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:46:08.385714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:46:15.798292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['exception'] = "An unexpected error occurred while checking checksum: %s %s"
    var_0['no_log'] = False
    var_0['follow'] = True
    var_0['dest'] = 'tmp/dest'
    var_0['src'] = 'tmp/src'
    var_0['no_log_lines'] = [re.compile('^BECOME-SUCCESS-.*'), re.compile('^AUTH_FAILED=0.*')]
    var_0['original_basename'] = '/root/tmp/src/converter.py'
    var_0['content'] = dict()
    var_0['original_basename'] = 'tmp/src/converter.py'

# Generated at 2022-06-25 06:46:22.073946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    var_0 = dict()
    var_0['dest'] = 'pa'
    var_0['remote_src'] = False
    var_0['content'] = None
    var_0['follow'] = False
    var_0['src'] = 'pa'
    var_0['checksum'] = None
    var_0['state'] = 'file'
    var_0['mode'] = None
    var_0['local_follow'] = True
    var_0['original_basename'] = True
    var_0['directory_mode'] = None
    var_0['tmp'] = None
    var_0['content'] = None
    var_1 = None
    var_2 = object()
    var_3 = object()
    var_4 = object()
    
   