

# Generated at 2022-06-25 06:37:30.028747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    MOCK_VARS = {
        "inventory_hostname": "test.example.org",
        "ansible_host": "test.example.org",
        "group_names": ["ungrouped"],
        "groups": {"ungrouped": ["test.example.org"]},
    }
    MOCK_OPTIONS = MagicMock(connection="ssh", module_path=None, forks=10, become=None,
                             become_method=None, become_user=None, check=False, diff=False)
    MOCK_LOADER = DictDataLoader({
        "test/tasks/main.yaml": b"",
    })
    MOCK_INVENTORY = MagicMock()

    task = Task()
    task.args = {}
    task.action = "copy"

# Generated at 2022-06-25 06:37:35.390651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    os_module_0 = os(None)
    os_module_0.path.exists(None)
    os_module_0.path.isdir(None)
    os_module_0.path.isfile(None)
    os_module_0.path.islink(None)
    os_module_0 = os(None)
    os_module_0.stat(None)
    os_module_0 = os(None)
    os_module_0.stat(None)
    os_module_0 = os(None)
    os_module_0.chmod(None, None)
    os_module_0 = os(None)
    os_module_0.chown(None, None, None)
    os_module_0 = os(None)

# Generated at 2022-06-25 06:37:36.829189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:37:40.372218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # int -> ActionsAPI.ActionModule
    action_module_1 = action_module_0.run()

    # int -> ActionsAPI.ActionModule
    action_module_2 = action_module_1.run()


# Generated at 2022-06-25 06:37:42.042222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return action_module_0


# Generated at 2022-06-25 06:37:42.987004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:37:44.941448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    int_0 = -1546
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:37:46.678454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    int_0 = -11019
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:37:58.131061
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    for i in range(NUMBER_OF_TESTS):
        action_module = ActionModule()
        int_0 = random.randint(0, 2147483647)
        var_0 = action_module.run()

        if int_0 % 5 == 0:
            assert type(var_0) == dict
        elif int_0 % 5 == 1:
            assert type(var_0) == dict
        elif int_0 % 5 == 2:
            assert type(var_0) == dict
        elif int_0 % 5 == 3:
            assert type(var_0) == dict
        elif int_0 % 5 == 4:
            assert type(var_0) == dict


# Generated at 2022-06-25 06:38:02.734149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module_0.run()


# Generated at 2022-06-25 06:38:52.432009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call the constructor of class ActionModule
    action_module_1 = ActionModule()

    # Print the object's attribute dest
    print(action_module_1.dest)

    # Print the object's attribute remote_checksum
    print(action_module_1.remote_checksum)

    # Print the object's attribute set_remote_checksum
    print(action_module_1.set_remote_checksum)

    # Print the object's attribute set_remote_user
    print(action_module_1.set_remote_user)

    # Print the object's attribute remote_user
    print(action_module_1.remote_user)


# Generated at 2022-06-25 06:38:57.819303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    # test for simple copy
    action_module_1 = ActionModule()
    action_module_1._task.args = dict(content = None, src = 'localhost', dest = 'localhost', recurse = None)
    task_vars_1 = dict(inventory_hostname = 'localhost')
    action_module_1._execute_module = mock.MagicMock(return_value = dict(changed = False, msg = 'test_for_method_run_of_class_ActionModule_1'))
    action_module_1._connection._shell.path_has_trailing_slash = mock.MagicMock(return_value = True)
    action_module_1._find_needle = mock.MagicMock(return_value = 'localhost')

# Generated at 2022-06-25 06:39:09.122145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # For various values of 'changed', check that:
    #   1) copy_file works as expected for non-recursive cases
    #   2) copy_file works as expected for recursive cases
    #   3) file module is called for directory creation
    action_module_1 = ActionModule()
    action_module_1._play_context = Mock()
    action_module_1._play_context.check_mode = True
    action_module_1._connection = Mock()
    action_module_1._connection._shell = Mock()
    action_module_1._connection._shell.path_has_trailing_slash = lambda x: False

    # No trailing slash
    assert(action_module_1._connection._shell.path_has_trailing_slash("/tmp/test") is False)
    # Trailing slash

# Generated at 2022-06-25 06:39:11.277642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 06:39:12.988626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = test_case_0()
    assert(result == 0)

# Unit test function for _find_needle(self, dirname, needle)

# Generated at 2022-06-25 06:39:22.704713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {
        'files': '/etc/passwd'
    }
    tmp_0 = '/tmp'
    args_0 = {
        'dest': '/etc/passwd',
        'src': '/etc/passwd',
        '_ansible_verbosity': 0
    }
    action_module_0 = ActionModule(
        action=None,
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

# Generated at 2022-06-25 06:39:25.076451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None
    print(action_module)


# Generated at 2022-06-25 06:39:27.681502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Wrapper for main method
# Call the main method
if __name__ == '__main__':
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:39:29.651098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert( action_module != None )


# Generated at 2022-06-25 06:39:37.695033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a file.
    test_file_name = "test_action_module.txt"
    fo = open(test_file_name, 'wb')
    fo.write("ActionModule testing...")
    fo.close()
    # Set a variable under self._task.args
    self._task.args = {'action': 'ActionModule', 'test_action_module': test_file_name}
    # Call the constructor of class ActionModule
    action_module_0 = ActionModule(self)
    action_module_0.run(self, None)
    # Delete the test_action_module.txt
    os.remove(test_file_name)


# Generated at 2022-06-25 06:41:15.165862
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:41:16.774173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    i_action_module_0 = ActionModule()
    assert i_action_module_0 != None

# Generated at 2022-06-25 06:41:18.371444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert_true(action_module_1 is not None)


# Generated at 2022-06-25 06:41:19.579775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:41:21.623757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(".... test_ActionModule:  Start of test_ActionModule")

    action_module = ActionModule()
    assert action_module != None


# Generated at 2022-06-25 06:41:27.195021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    dest = '/var/tmp/dir_11'
    tmp_dir = '/var/tmp'
    task_vars = dict()
    task_vars['ansible_user'] = 'user_1'
    action_module_1._task.args = dict()
    action_module_1._task.args['src'] = 'template_file_1'
    action_module_1._task.args['group'] = 'group_1'
    action_module_1._task.args['mode'] = '664'
    action_module_1._task.args['owner'] = 'owner_1'
    action_module_1._task.args['dest'] = dest
    action_module_1._task.args['recursive'] = 'yes'
    action_module_1._

# Generated at 2022-06-25 06:41:35.343005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src_0 = '/etc/issue'
    dest_0 = '/etc/issue.back'
    src_1 = '/usr/bin'
    dest_1 = '/usr/bin.back'
    src_2 = '/usr/local/bin'
    dest_2 = '/usr/local/bin.back'
    src_3 = '/etc/issue'
    dest_3 = '/etc/issue'
    action_module_0 = ActionModule()
    result_0 = action_module_0.run(src=src_0, dest=dest_0)
    print('result_0: ', result_0)
    result_1 = action_module_0.run(src=src_1, dest=dest_1)
    print('result_1: ', result_1)
    result_2 = action_module_0.run

# Generated at 2022-06-25 06:41:43.766117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for constructor of class ActionModule
    action_module_0 = ActionModule()
    # make sure we made both args lists

# Generated at 2022-06-25 06:41:50.616054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    try:
        action_module.run()
    except:
        import sys, traceback
        ex_type, ex, tb = sys.exc_info()
        traceback.print_tb(tb)

if __name__ == '__main__':
    # test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:41:53.924690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("")
    print("------------Testing for action_copy_test.py ------------")

    # Test cases for ActionModule
    test_case_0()

# Test cases for class ActionModule
test_ActionModule_run()

# Generated at 2022-06-25 06:45:47.802991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Using actual ansible invocation module name.
    action_module_0._task.args = dict(backup=True, content='This is a test file.', create=True, dest='/etc/test_file.txt', group='root', mode='0644', owner='root', selevel='s0', serole='staff_r', setype='var_lib_t', seuser='root', src='/home/vagrant')
    # Using actual ansible invocation module name.
    action_module_0.copy = ActionModule()
    action_module_0.copy._execute_module = Mock()
    action_module_0.copy._execute_module.return_value = dict(changed=True)
    # Using actual ansible invocation module name.
    action_module_0.file = ActionModule

# Generated at 2022-06-25 06:45:50.075033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module) is ActionModule


# Generated at 2022-06-25 06:45:52.768652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Params for create class ActionModule
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 06:45:54.420694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 06:45:57.510179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of class ActionModule
    actionModule_test = ActionModule()

    # test if actionModule_test is instance of class ActionModule
    assert isinstance(actionModule_test, ActionModule), "actionModule_test is instance of class ActionModule"

# Generated at 2022-06-25 06:45:59.035683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print()
    action_module = ActionModule()



# Generated at 2022-06-25 06:46:01.091756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    action_module_0 = ActionModule()
    assert action_module_0



# Generated at 2022-06-25 06:46:04.061786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print('type(action_module): %s' % type(action_module))
    print('action_module: %s' % action_module)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:46:05.662003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:46:09.572565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

_test_cases = [
    test_case_0,
    test_ActionModule_run,
]

if __name__ == '__main__':
    for test_case in _test_cases:
        test_case()