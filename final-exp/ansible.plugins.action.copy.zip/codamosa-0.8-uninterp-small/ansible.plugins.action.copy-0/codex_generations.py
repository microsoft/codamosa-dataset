

# Generated at 2022-06-25 06:37:35.404457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2055.7029
    float_1 = 7067.1772
    list_0 = [float_0, float_1]
    float_2 = 5349.6312
    float_3 = 7473.9415
    dict_0 = {float_2: float_3}

# Generated at 2022-06-25 06:37:40.084273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [8214.411, -3.8963]
    set_0 = {-3.473671913, 3.97736}
    bytes_0 = b'ms\x12\x04\x0f3\x02\x98\x00-\x11\x1a\x8e'
    str_0 = 'KEEPCAR.ZIP'
    int_0 = -36
    dict_0 = dict()
    dict_0 = {-2.464: bytes_0, -1.2401: set_0, 'g': -2.03, -4.0: str_0}
    action_module_0 = ActionModule(list_0, set_0, bytes_0, dict_0, str_0, list_0)

# Generated at 2022-06-25 06:37:46.101160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    try:
        action_module_0.run(tmp, task_vars)
    except Exception as exception_0:
        print('Exception caught: ')
        print('')
        print(exception_0)
    else:
        print('No exception caught.')
    finally:
        print('Finished a test')

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:37:49.650929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:38:01.239396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 477.31
    dict_0 = dict()
    int_0 = 4
    dict_0['cache_timeout'] = int_0
    int_1 = 6
    dict_0['changed'] = int_1
    dict_1 = dict()
    int_2 = 7
    dict_1['cache_timeout'] = int_2
    int_3 = 2
    dict_1['changed'] = int_3
    dict_0['invocation'] = dict_1
    int_4 = 3
    dict_0['msg'] = int_4
    dict_0['rc'] = int_4
    dict_2 = dict()
    int_5 = 0
    dict_2['cache_timeout'] = int_5
    int_6 = 2
    dict_2['changed'] = int_6
   

# Generated at 2022-06-25 06:38:04.439106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ####
    # A stress test for the run method of the ActionModule class.
    ####
    test_case_0()


# Generated at 2022-06-25 06:38:08.719854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}
    action = ActionModule(args=args)
    res = action.run("/tmp")
    assert res["failed"] == True
    assert res["msg"] == "src (or content) is required"

# Generated at 2022-06-25 06:38:11.197496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule constructor')
    test_case_0()
# End of unit test for constructor of class ActionModule


# Generated at 2022-06-25 06:38:16.637461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2489.732
    list_0 = [float_0, float_0]
    set_0 = {float_0, float_0}
    bytes_0 = b'\x1b\x9a~XmI\x13'
    str_0 = 'EXEC: %s'
    action_module_0 = ActionModule(list_0, set_0, bytes_0, set_0, str_0, list_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:38:27.680804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    file_0_fd, file_0_path = tempfile.mkstemp()
    file_0 = os.fdopen(file_0_fd, 'w')
    try:
        file_0_content = '~\n'
        try:
            os.write(file_0.fileno(), file_0_content.encode('utf-8'))
        except Exception:
            pass
    finally:
        file_0.close()
    float_0 = 2489.732
    list_0 = [file_0, float_0]
    set_0 = {float_0, float_0}
    bytes_0 = b'\x1b\x9a~XmI\x13'
    str_0 = 'EXEC: %s'

# Generated at 2022-06-25 06:39:18.438807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module = ActionModule()

    source = None
    content = None
    dest = 'dest'
    remote_src = False
    local_follow = True

    action_module._task = MagicMock()
    action_module._task.args = {'src': source, 'content': content, 'dest': dest, 'remote_src': remote_src, 'local_follow': local_follow}
    action_module.run(tmp,task_vars)

# Generated at 2022-06-25 06:39:23.442755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    sys.stdout.write("Testing method run of class ActionModule... ")
    sys.stdout.flush()
    action_module_0 = ActionModule()
    assert(action_module_0.run() == None)
    print("PASSED")

################################################################################


# Generated at 2022-06-25 06:39:29.832717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.set_loader('loader')
    action_module_0.set_connection('connection')
    action_module_0.set_task('task')
    action_module_0.set_task_vars('task_vars')
    action_module_0.set_loader_path('loader_path')
    action_module_0._task.args = None
    action_module_0._task.args = {'content': None, 'follow': False, 'dest': 'dest', 'src': 'src'}
    r = action_module_0.run()
    assert r == None

# Generated at 2022-06-25 06:39:31.945829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:39:33.001639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(action_module_0)


# Generated at 2022-06-25 06:39:34.024549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()


# Generated at 2022-06-25 06:39:35.377607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:39:37.784443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print("Failed to instantiate ActionModule.")

if __name__ == "__main__":
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:39:49.261842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of a MockTaskExecutor
    task_executor_0 = MockTaskExecutor()
    # Set the property tmp of task_executor_0
    task_executor_0.tmp = None
    # Create an instance of a MockPlayContext
    play_context_0 = MockPlayContext()
    # Set the property remote_addr of play_context_0
    play_context_0.remote_addr = None
    # Set the property port of play_context_0
    play_context_0.port = 22

    # Create an instance of a MockConnection
    connection_0 = MockConnection()
    # Set the property in_path of connection_0
    connection_0.in_path = None
    # Set the property failsafe of connection_0
    connection_0.failsafe = []
    # Set the property become

# Generated at 2022-06-25 06:39:56.535926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'vagrant'
    action_module = ActionModule()

    test_args = dict(
        dest = '/home/vagrant/test1',
        src = '/home/vagrant/test1',
        state = 'directory',
        # debug = True
    )
    action_result = action_module._create_remote_file_args(test_args)

    # Testing module parameters
    assert action_result['path'] == '/home/vagrant/test1'
    assert action_result['state'] == 'directory'
    # assert action_result['debug'] == True

    # Testing module parameters
    assert action_result['path'] == '/home/vagrant/test1'
    assert action_result['state'] == 'directory'
    # assert action_result['debug'] == True

    # Testing method _create_remote_

# Generated at 2022-06-25 06:41:28.246819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    print(action_module_1.__dict__)

    action_module_2 = ActionModule()
    print(action_module_2.__dict__)


# Generated at 2022-06-25 06:41:29.505215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == {}

# Generated at 2022-06-25 06:41:31.011619
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:41:32.041185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:41:33.517195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(isinstance(action_module, ActionModule))


# Generated at 2022-06-25 06:41:35.235961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 0
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:41:39.285463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_obj = ActionModule()
    params_data = {}
    # Replace 'nop' to test method run
    action_module_run_obj.run = 'nop'
    result = action_module_run_obj.run(params_data)


# Generated at 2022-06-25 06:41:39.889110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:41:43.070212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('******test for run of class ActionModule******')
    print('test_case_0')
    test_case_0()
    print('test_case_0 is done')


# Generated at 2022-06-25 06:41:49.738252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()


# Generated at 2022-06-25 06:43:42.464736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 512.0
    float_1 = 0.0
    str_0 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_0 = True
    bytes_0 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)


# Generated at 2022-06-25 06:43:53.269007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_1 = None
    list_1 = [tuple_1, tuple_1, tuple_1, tuple_1]
    float_2 = 512.0
    float_3 = 0.0
    str_1 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_1 = True
    bytes_1 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_1 = ActionModule(list_1, float_2, float_3, str_1, bool_1, bytes_1)
    task_vars_0 = {}
    var_1 = action_module_1.run(None, task_vars_0)




# Generated at 2022-06-25 06:43:57.178560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = dict()
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    assert var_0 is None


# Generated at 2022-06-25 06:44:07.917501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 512.0
    float_1 = 0.0
    str_0 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_0 = True
    bytes_0 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)
    assert action_module_0.task == list_0
    assert action_module_0.connection == float_0
    assert action_module_0.play_context == float_1

# Generated at 2022-06-25 06:44:15.269106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 512.0
    float_1 = 0.0
    str_0 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_0 = True
    bytes_0 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 06:44:22.841261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 512.0
    float_1 = 0.0
    str_0 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_0 = True
    bytes_0 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:44:30.620002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 512.0
    float_1 = 0.0
    str_0 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_0 = True
    bytes_0 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)
    str_1 = 'Fo\x80\x9c'
    assert_equal(action_module_0._find_needle(str_1), None)
    str_1 = 'x'
    bytes_

# Generated at 2022-06-25 06:44:35.934523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 512.0
    float_1 = 0.0
    str_0 = 'Z4sSZv\nt|BBCs- U$AM#'
    bool_0 = True
    bytes_0 = b'-\x85 \xbe\xf1\x9e\x1d\x95\xe35'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)
    action_module_0.run()
    var_0 = action_run()


# Generated at 2022-06-25 06:44:45.138421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = None
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]
    float_0 = 20.0
    float_1 = 0.0
    str_0 = 'rzW}9E[u'
    bool_0 = True
    bytes_0 = b'\xf1\xdd\xd9\x9f\x0b\x00\xde\x0f\x1c\xbc\x86\xb3\x9a\x85\xdc\xba\xcb\x14\xbe\xb2'
    action_module_0 = ActionModule(list_0, float_0, float_1, str_0, bool_0, bytes_0)
    list_1 = []
    dict_0 = {}
    action_module

# Generated at 2022-06-25 06:44:46.921517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # get results
    results = run()
    print(results)


if __name__ == '__main__':
    test_ActionModule_run()