

# Generated at 2022-06-25 06:37:34.029059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = '{V~<d-A>G:7b"\x0b|\r>i'
    dict_1 = {'n': '\x1e', '&': '\\=1|i', '\x15': 53.758320774144745}
    action_module_0 = ActionModule(dict_0, dict_1, dict_0, dict_1, str_0, dict_0)
    action_module_0.run(dict_1, dict_0)


# Generated at 2022-06-25 06:37:35.755550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0
    print('\nTest case 0\n')
    test_case_0()

# Invoke test cases
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:37:38.497415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    test_case_0()


current_path = os.path.dirname(os.path.realpath(__file__))
parent_path = os.path.dirname(os.path.dirname(current_path))
yaml_config_path = os.path.join(parent_path, 'config/auto_deploy_config.yml')


# Generated at 2022-06-25 06:37:40.973347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:45.018342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1873.8
    dict_0 = {}
    int_0 = None
    str_0 = '_Dhb<nx\x00=W'
    action_module_0 = ActionModule(float_0, dict_0, int_0, dict_0, str_0, float_0)


# Generated at 2022-06-25 06:37:49.114828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {"src": "test_src",
              "dest": "test_dest",
              "content": "test_content"}
    int_0 = None
    str_0 = 'a^i(U\tjYt/boJlR2!E'

    action_module_0 = ActionModule(0.0, dict_0, int_0, dict_0, str_0, 0.0)
    action_module_0.run()

# Generated at 2022-06-25 06:37:50.335499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:37:51.455715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:37:53.738598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:02.358117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    float_1 = -1456.1
    dict_1 = {}
    int_1 = None
    str_1 = 'a^i(U\tjYt/boJlR2!E'
    action_module_0 = ActionModule(float_1, dict_1, int_1, dict_1, str_1, float_1)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:38:49.166292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # mock tmp
    tmp_1 = Mock()
    task_vars_1 = {}
    result_1 = action_module_1.run(tmp_1, task_vars_1)
    assert type(result_1) == dict


# Generated at 2022-06-25 06:38:55.050306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

    if action_module_0.__dict__.get('_task').args.get('src') == None:
        raise Exception('Fail to get the src parameter')

    content = action_module_0.__dict__.get('_task').args.get('content')
    if content == None:
        raise Exception('Fail to get the content parameter')

    dest = action_module_0.__dict__.get('_task').args.get('dest')
    if dest == None:
        raise Exception('Fail to get the dest parameter')

    # test if the src parameter is set to a directory,
    # it throws an exception
    action_module_1 = ActionModule()
    action_module_1.__dict__['_task'].args['src']

# Generated at 2022-06-25 06:39:06.389445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # Test correct args
    # Test correct args
    tmp = None
    task_vars = {
        "is_windows": False,
        "ansible_user_dir": "/home/ansible/.ansible"
    }
    source = 'test'
    content = 'test'
    dest = '/home/test'
    remote_source = False
    local_follow = 'test'
    result = action_module.run(tmp, task_vars)
    assert result == {}

    # Test missing args
    task_vars = {
        "is_windows": False,
        "ansible_user_dir": "/home/ansible/.ansible"
    }
    source = 'test'
    content = 'test'
    dest = 'test'
    remote_source = False

# Generated at 2022-06-25 06:39:08.514374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac_m0 = ActionModule()
    tmp_0 = ac_m0._execute_module(module_name='ansible.legacy.copy')
    task_vars_0 = dict()
    dest_0 = ac_m0._task.args.get('dest', None)
    ac_m0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:39:11.352419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


if __name__ == '__main__':
    test_ActionModule()
    # test_case_0()

# Generated at 2022-06-25 06:39:17.318896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test function call
    action_module_0 = ActionModule()
    action_module_0.run(None, None)
    # Test call with no param
    action_module_0 = ActionModule()
    action_module_0.run()
    # Test call with one param
    action_module_0 = ActionModule()
    action_module_0.run(None)


# Generated at 2022-06-25 06:39:18.980128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_m = ActionModule()
    is_instance(action_m, ActionModule)


# Generated at 2022-06-25 06:39:22.583351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # No exception raised
    try:
        action_module.run(tmp=None, task_vars=None)
    except:
        assert False


# Generated at 2022-06-25 06:39:26.107471
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test for default execution
    action_module = ActionModule()
    assert not action_module._play_context.become
    assert not action_module._play_context.become_user


# Generated at 2022-06-25 06:39:36.266633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._execute_module = MagicMock()
    action_module_0._execute_module.return_value = {}
    action_module_0._task = MagicMock()
    action_module_0._task.args = {}
    action_module_0._connection = MagicMock()
    action_module_0._connection._shell = MagicMock()
    action_module_0._connection._shell.tmpdir = '/tmp'
    action_module_0._task.args = dict(
        src="src",
        dest="dest"
    )
    action_module_0._connection._shell.join_path = lambda x, y: os.path.join(x, y)
    action_module_0._connection._shell.path_has_trailing_slash

# Generated at 2022-06-25 06:41:08.371854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert 'missing required arguments' in str(action_module_1.run())


# Generated at 2022-06-25 06:41:16.645429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.task = None
    action_module.task_vars = None
    action_module.tmp = None
    assert action_module.run() == dict(changed=False, msg='src (or content) is required')

    action_module.task_vars = {}
    action_module.task = dict(args=dict(src='/test/src'))
    assert action_module.run() == dict(changed=False, msg='dest is required')

if __name__ == '__main__':
    # unit tests
    # test_case_0()

    # unit testing for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 06:41:18.255413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert not action_module_0


# Generated at 2022-06-25 06:41:25.510673
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Defining test_case_0
    action_module_0 = ActionModule()
    tmp_0 = None
    tmp_0 = None
    task_vars = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()
    result = dict()

    # Invoke method run of class ActionModule with parameters tmp, task_vars
    action_module_0.run(tmp_0, task_vars)

    # Invoke method run of class ActionModule with parameters tmp
    action_module_0.run(tmp_0)

    # Invoke method

# Generated at 2022-06-25 06:41:26.513933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:41:27.615154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 06:41:28.509870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:41:36.134222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._task.args = dict(
        content='test',
        dest='test/test/test.sh',
        src='test.sh',
        remote_src=False,
        local_follow=True,
        follow=False,
        checksum=None,
        original_basename='test.sh',
        recurse=False,
        # state='file'
    )
    action_module_1._task.name = "test"
    action_module_1._task.start = datetime.now()
    action_module_1.display = Display()
    action_module_1._loader = DataLoader()
    action_module_1._connection = Connection()

    action_module_1._connection._shell = ShellModule()
    action_module_1._

# Generated at 2022-06-25 06:41:38.682717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()

# Run test cases
test_ActionModule_run()

# Generated at 2022-06-25 06:41:39.587004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module_0
    test_case_0()

    action_module_0.run()

# Generated at 2022-06-25 06:45:38.715556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call the execution of the AnsibleModule and obtain the result.
    result = action_module_0.run()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:45:43.653625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    source = None
    content = None
    dest = None
    remote_src = False
    local_follow = True

    expected = dict(failed=True, msg='src (or content) is required')
    action_module_1.run(source, content, dest, remote_src, local_follow)


# Generated at 2022-06-25 06:45:45.991608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test ActionModule: start')
    action_module = ActionModule()
    assert action_module is not None, "constructor of ActionModule failed"
    print('Test ActionModule: end')


# Generated at 2022-06-25 06:45:50.124462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = "tmp"
    task_vars = {"a": "b"}
    result = action_module_0.run(tmp, task_vars)

# Unit tests for action module

# Generated at 2022-06-25 06:46:00.201380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module_0 = ActionModule()

    # Create a dummy task
    task_0 = Task()
    task_0.args = dict()
    task_0.args['follow'] = 'False'
    task_0.args['local_follow'] = 'False'
    task_0.args['owner'] = ''
    task_0.args['content'] = ''
    task_0.args['dest'] = '~/srcc/test.txt'
    task_0.args['content_tempfile'] = '/tmp/ansible_test.txt_Q2ZwW8'
    task_0.args['copy_pass'] = ''
    task_0.args['dest_port'] = '22'

    # Run the run method of the ActionModule class
    ret_value = action

# Generated at 2022-06-25 06:46:01.831910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 06:46:02.734562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return


# Generated at 2022-06-25 06:46:08.616165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    result = {}
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=task_vars)
    #assert result == {}

if __name__ == "__main__":
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 06:46:14.678399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # source has no trailing slash and source is directory, dest has trailing slash and dest is directory
    action_module_0._task.args = {'dest': '/root/tmp/', 'content': 'Test content for testing', 'src': '/root/tmp'}
    action_module_0._task.args['content'] = encode_multipart_formdata(action_module_0._task.args)
    action_module_0._shell = Shell('bash', '/usr/bin/bash')
    try:
        action_module_0._connection.host = shell('hostname')
    except Exception as e:
        raise Exception(e)
        return False
    # source has no trailing slash and source is file, dest has trailing slash and dest is directory

# Generated at 2022-06-25 06:46:21.081826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Configuration
    config = createConfigObject()

    #Test data
    test_case_data_0 = '''
    #!/usr/bin/python

    #-*- coding: utf-8 -*-

    config = '''
    action_module_0 = ActionModule(config)

    #Test 1 - Invalid arguments
    try:
        raise Exception("Unit test not implemented!")
    except Exception as e:
        print("Test 1 FAILED: " + str(e))
    else:
        print("Test 1 PASS")

    #Test 2 - Normal arguments
    try:
        raise Exception("Unit test not implemented!")
    except Exception as e:
        print("Test 2 FAILED: " + str(e))
    else:
        print("Test 2 PASS")
