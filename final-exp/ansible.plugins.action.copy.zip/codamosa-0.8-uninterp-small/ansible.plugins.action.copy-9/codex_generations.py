

# Generated at 2022-06-25 06:37:27.862069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    int_0 = -1093
    list_0 = None
    bool_0 = None
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

if __name__ == '__main__':
    # Begin unit test
    unittest.main()

# Generated at 2022-06-25 06:37:35.438518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    bytes_0 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    int_0 = -1093
    list_0 = None
    bool_0 = None
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:41.957487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    int_0 = -1093
    list_0 = None
    bool_0 = None
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:37:43.606808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:37:53.970359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    int_0 = -1093
    int_1 = -1957
    list_0 = None
    bytes_1 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    bool_0 = None
    action_module_0 = ActionModule(bytes_0, int_0, int_1, list_0, bytes_1, bool_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:37:58.857783
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    # test with a positive scenario
    result = module.run(tmp=None, task_vars=None)
    print(result)
    assert result.get('changed') == True

# ---------------------------
# test_case_0 (ActionModule)
# ---------------------------

# Generated at 2022-06-25 06:38:00.201723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:38:12.212330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    int_0 = -1093
    list_0 = None
    bool_0 = None
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)
    assert isinstance(action_module_0, ActionModule)
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)
    assert isinstance(action_module_0, ActionModule)
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)

# Generated at 2022-06-25 06:38:21.911530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x8b|n\x8a\xa7\x00by\xad\xf7\x8a'
    int_0 = -1093
    list_0 = None
    bool_0 = None
    action_module_0 = ActionModule(bytes_0, int_0, int_0, list_0, bytes_0, bool_0)
    # TODO: Add additional test cases for the method run of class ActionModule
    # Uncomment the code below and add your test cases here
    # action_module_0.run()


if __name__ == "__main__":
    # Test for method run of class ActionModule
    test_ActionModule_run()
    # test_case_0()

# Generated at 2022-06-25 06:38:24.969033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Running test for constructor of class ActionModule")
    test_case_0()
    print("Passed test for constructor of class ActionModule")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:10.886961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    a = ActionModule()
    # test_case 0
    # this test case tests the constructor of ActionModule
    test_case_0()


# Generated at 2022-06-25 06:39:11.815778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    check_0 = ActionModule()


# Generated at 2022-06-25 06:39:15.123414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    if var_0 is not None:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:39:16.749587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert True


# Generated at 2022-06-25 06:39:25.387758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("#############################################")
    print("### Testing ActionModule.run ###")
    print("#############################################")
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(tmp='/tmp/test_ansible/var_0', task_vars='var_0')
    print("var_0")
    print(var_0)
    print("#############################################")
    print("### End of Testing ActionModule.run ###")
    print("#############################################")
    print("")

# Generated at 2022-06-25 06:39:27.202466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None


# Generated at 2022-06-25 06:39:29.182362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run()


# Generated at 2022-06-25 06:39:38.362358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    task_vars_1 = dict()
    tmp_1 = None
    tmp_1 = action_module_1.run(tmp_1, task_vars_1)
    assert_equal(action_module_1._task, None)
    assert_equal(action_module_1._connection, None)
    assert_equal(action_module_1._play_context, None)
    assert_equal(action_module_1._loader, None)
    assert_equal(action_module_1._templar, None)
    assert_equal(action_module_1._shared_loader_obj, None)
    assert_equal(action_module_1._connection_loader, None)
    assert_equal(action_module_1._task_vars, None)
    assert_equal

# Generated at 2022-06-25 06:39:47.430750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    var_2 = tempfile.mkdtemp()
    var_3 = var_2.run(var_2, var_2)
    assert var_3 is not None
    assert var_3 is False or var_3
    var_2.run(var_2, var_2)
    assert var_3 is not None
    assert var_3 is False or var_3
    var_2.run(var_2, var_2)
    assert var_3 is not None
    assert var_3 is False or var_3
    


# Generated at 2022-06-25 06:39:49.450243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test variables
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:40:40.909837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(Exception) as exc:
        action_module = ActionModule()
    assert str(exc.value) == 'This class should not be instantiated directly'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-25 06:40:42.160515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()
    assert True


# Generated at 2022-06-25 06:40:43.196072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test function
    assert(True)


# Generated at 2022-06-25 06:40:44.119425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None



# Generated at 2022-06-25 06:40:45.443450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:40:50.050439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # source file
    source_file_0 = '/home/karthik/.ssh/id_rsa.pub'
    # tmp directory
    tmp_0 = 'tmp'
    # variables
    task_vars_0 = {}
    ret_val_0 = action_module_0.run(tmp_0, task_vars_0)
    # assert if the return value is ok
    assert ret_val_0


# Generated at 2022-06-25 06:40:57.414114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    params_0 = dict(
        #dest="/foo/bar",
        content="content",
        dest="/foo/bar"
    )

    params_1 = dict(
        src="../data/test_module.py",
        dest="/foo/bar"
    )

    params_2 = dict(
        src="../data/test_module.py",
        dest="/foo/bar",
        remote_src=True
    )


# Generated at 2022-06-25 06:41:02.172413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print('action_module_0 = %s' % action_module_0)
    action_module_0 = ActionModule(connection=None)
    print('action_module_0 = %s' % action_module_0)
    action_module_0 = ActionModule(task=None)
    print('action_module_0 = %s' % action_module_0)
    action_module_0 = ActionModule(task=None, connection=None)
    print('action_module_0 = %s' % action_module_0)
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-25 06:41:03.609021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 06:41:06.510920
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:42:04.747306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ';k|m]@\nm4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_2 = '|F^&IPGKo,5R(:'
    str_3 = "h_'#Gewlri"
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:42:15.781080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ';k|m]@\nm4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_2 = '|F^&IPGKo,5R(:'
    str_3 = "h_'#Gewlri"
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)
    str_4 = ']yU6Iy)_/;_$9P'
    str_5 = 'lk-2'
    str_6 = 'y`C#~'


# Generated at 2022-06-25 06:42:18.938954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: unless it is specified, the type of the returned variable is
    # *wildcard*.  We need to explicitly cast it to the type of variable
    # in the return value.
    ret = ActionModule.run()
    assert type(ret) == str


# Generated at 2022-06-25 06:42:19.883349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:42:25.233089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')zP2`/\X>Y'
    dict_0 = {str_0: int, str_0: float, str_0: str}
    int_0 = -862
    str_1 = 'v{:B%V7^#CZx@'
    str_2 = 'Y^eKq'
    str_3 = '<oR+G-2w@'
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)
    del action_module_0


# Generated at 2022-06-25 06:42:26.409317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return action_module_0


# Generated at 2022-06-25 06:42:31.233774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = '=3'
    var_2 = {var_1: var_1, var_1: var_1, var_1: var_1}
    var_3 = -66
    var_4 = 'BbK"+N'
    var_5 = 'rCZG/KpJ5'
    var_6 = "^fI'e}R"
    action_module_1 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)
    var_7 = action_run()
# END

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:42:37.178223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.module_name == 'debug'
    assert action_module_0.module_args == {'msg': 'Hello from the debug module!'}
    assert action_module_0.tmp == '/tmp/ansible-tmp-1423796390.97-147729857856000/debug'
    assert action_module_0.task_vars == {'verbosity': 0, 'inventory_hostname': 'webserver01', 'ansible_ssh_pass': 'Vp!HmDdyQ<}^-\rjWc{',
                                         'group_names': ['ungrouped'], 'grouped_vars': {}, 'groups': {'ungrouped': ['webserver01']},
                                         '_ansible_no_log': False, 'parsed': True}

# Generated at 2022-06-25 06:42:42.486553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'OixHe.b:O'
    str_1 = '8!L\x0b'
    str_2 = 'l8Yv<&:4Q2,6A'
    int_0 = -17
    str_3 = '`K?_?:pYn#5'
    str_4 = 'l8Yv<&:4Q2,6A'
    str_5 = '0~0'
    action_module_0 = ActionModule(str_0, str_1, str_2, int_0, str_3, str_4, str_5)
    action_module_0.run()
    var_0 = action_run()


# Generated at 2022-06-25 06:42:48.545990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3g`[bh=XH&o6Ha#I6+'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = '0YH/_<f^JSC2[hE@*nH'
    str_2 = 'Qg*$R}_B<!,Tp1:y'
    str_3 = ';{zC\r>\\ci7Vu'
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)


# Generated at 2022-06-25 06:44:56.295695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ';k|m]@\nm4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_2 = '|F^&IPGKo,5R(:'
    str_3 = "h_'#Gewlri"
    action_module_1 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)
    str_4 = 'n'
    dict_1 = {"s": str_4, str_4: str_4, str_4: str_4}
    dict_2 = action_module_

# Generated at 2022-06-25 06:45:02.106229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ';k|m]@\nm4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_2 = '|F^&IPGKo,5R(:'
    str_3 = "h_'#Gewlri"
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)
    temp_0 = 'z4f\nO[ 9!\x0c"lj?'

# Generated at 2022-06-25 06:45:02.783696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Function run executed successfully')


# Generated at 2022-06-25 06:45:08.433329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ';k|m]@\nm4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_2 = '|F^&IPGKo,5R(:'
    str_3 = "h_'#Gewlri"
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)
    dict_1 = dict(dict_0)
    dict_2 = dict(dict_1)
    dict_2.update(dict_0)
    assert dict_2 == dict_1



# Generated at 2022-06-25 06:45:15.443013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'h_'
    str_1 = 'ewlri'
    str_2 = str_0 + str_1
    str_3 = ';k|m]@\nm4'
    dict_0 = {str_3: str_3, str_3: str_3, str_3: str_3}
    int_0 = -162
    str_4 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_5 = '|F^&IPGKo,5R(:'
    str_6 = "h_'#Gewlri"
    action_module_0 = ActionModule(str_2, dict_0, int_0, str_4, str_5, str_6)
    action_module_0.run()

# Unit

# Generated at 2022-06-25 06:45:18.453696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print ('test ActionModule run')
    uut = ActionModule('name', {}, 3, 'remote_user', 'remote_pass', 'transport')
    uut.run()

test_ActionModule_run()

# Generated at 2022-06-25 06:45:20.037446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Stub test.
    '''
    pass


# Generated at 2022-06-25 06:45:22.046338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run method of class ActionModule")
    # Run the run method
    test_case_0()


# Generated at 2022-06-25 06:45:28.616606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ';k|m]@\nm4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = -162
    str_1 = 'Vp!HmDdyQ<}^-\rjWc{'
    str_2 = '|F^&IPGKo,5R(:'
    str_3 = "h_'#Gewlri"
    action_module_0 = ActionModule(str_0, dict_0, int_0, str_1, str_2, str_3)


# Generated at 2022-06-25 06:45:33.470558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule('_task', '_connection', '_play_context', '_loader', '_templar', '_shared_loader_obj')
    res_0 = action_module_0.run(tmp, task_vars)
    assert res_0 is None