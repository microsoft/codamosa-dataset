

# Generated at 2022-06-25 06:37:22.698888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:30.512931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    str_0 = 'b\x17\xb2\xe5\xbe\xfc\x9ff'
    bytes_0 = b'\xcf8\x05\xfc\x175\x05\x80'
    bytes_1 = b'\xe7\x98v\xbf\xd0H\xfc\x9c\xb9\xa9'
    bytes_2 = b'\x0f\x81\x90\x0e\xa1\x9e'
    float_0 = -96.82924
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, bytes_1, bytes_2, float_0)
    bytes_3 = b'/C'

# Generated at 2022-06-25 06:37:31.198650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:37:33.867236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 06:37:43.239518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'd}-H?NK1KQ\xde\xe3\x06\x80\xb6'
    str_1 = 'qh\xfa\xc4Z\x1e\x12\x1f\x85\x87\x84'
    str_2 = '\x13\xc5\x0e\x89\xdd\xf8\x10\x84\x9e\x81\x0e\x85\x01\xf2\x04\x1d\x9b\x0b\x98\xc4'

# Generated at 2022-06-25 06:37:50.064725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '}g\x863\xce\x1d\x9c\xc3\x8c\x13\xfcJ\x1c'

# Generated at 2022-06-25 06:37:56.131752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(None, None)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    # Run the below test manually if you want to see how long it takes for a copy module to run
    #test_ActionModule_run_on_folder()

# Generated at 2022-06-25 06:37:58.268382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:00.304920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result_false_0 = action_module_0
    assert result_false_0 is False
    assert result_false_0 is False


# Generated at 2022-06-25 06:38:12.250641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    str_0 = '\x1b\xba\xeb\x8f\x13\xbcA\xa3\xa9\\'
    bytes_0 = b'\xea\x0c\x8b\xfe\xe1\xda\xf9'
    bytes_1 = b'kD\x1e\x8b\x1c\x94\xaa\xaf'
    float_0 = -4.306635E+11
    action_module_0 = ActionModule(bool_0, str_0, bytes_0, bytes_1, bytes_1, float_0)
    tmp = '\xfc\x1a\x9d\xdd5\xab(I\x08\x8bk\x83*'
    task_v

# Generated at 2022-06-25 06:39:07.746541
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # This is using the importer plugin to get the action plugin
    action_plugin = ActionModule()

    # Needed for testing
    setattr(action_plugin._connection, '_shell', Shell())
    setattr(action_plugin, '_task', Dict())

    # Populate the task info with data
    action_plugin._task.args = get_test_data()

    task_vars = {"ansible_ssh_user": "test", "ansible_ssh_host": "host.example.com"}
    action_plugin._play_context = PlayContext(play=Dict())
    action_plugin._play_context.play.options = Dict()
    action_plugin._play_context.play.options['remote_user'] = "test"

# Generated at 2022-06-25 06:39:18.871114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    src = 'src'
    content = 'content'
    _path_items = ['path_items']
    task_uuid = 'task_uuid'
    wrap_async = 'wrap_async'

# Generated at 2022-06-25 06:39:29.494940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    tmp = None
    task_vars = None
    try:
        print("test_ActionModule_run 1")
        try:
            print("test_ActionModule_run 2")
            try:
                print("test_ActionModule_run 3")
                try:
                    print("test_ActionModule_run 4")
                    try:
                        actionModule.run(tmp, task_vars)
                    except Error:
                        raise Error('ExpectedError')
                except Error:
                    raise Error('ExpectedError')
            except Error:
                raise Error('ExpectedError')
        except Error:
            raise Error('ExpectedError')
    except Error:
        raise Error('ExpectedError')



# Generated at 2022-06-25 06:39:33.170621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # See if the string defined in method test_case_0() was decoded correctly.
    assert test_case_0() == '}g\x863Î\x1d\x9cÃ\x8c\x13üJ\x1c'

# Generated at 2022-06-25 06:39:36.305228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()
    # TODO add test for run of class ActionModule

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:47.920839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '?\xa2\x90G\xe2\xda|\x9a'
    str_1 = '\xed\x0e\xf7\xb8'
    str_2 = '\x9a\x8c[\x02c\xad\x87\xb7-\xdc\x1e\xc1'
    str_3 = '\xed\x0e\xf7\xb8'
    str_4 = '\xb9&\x0c\xac\x86\x10'
    str_5 = '\x95\x0c\xd0/íÊ'
    str_6 = '\x97\x16\x1b\xa5'

# Generated at 2022-06-25 06:39:58.901390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '[\x0f\x0e\x9fÞÕò{z\x1aà\x1b\x12\\\x19\x9cÈ\x16\xdf\x1d\x86\x13\x82\x1f\x1dò\x1e\x05\x0fÝ\x0e'
    str_2 = 'Z\x93\x90\x16\x9dÔ\x0f\x12\x13Ä\x1c\x05\x19ù\x1b\xdf'
    int_3 = 53

# Generated at 2022-06-25 06:40:06.308490
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:40:16.698697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class DummyModule(object):
        class DummyTask(object):
            def __init__(self):
                self.args = dict()

        def __init__(self):
            self.task = self.DummyTask()
            self.connection = 'local'
            self.run_command = lambda args: 'ansible_shell_executable'

    class DummyConnection(object):
        class DummyShell(object):
            def __init__(self):
                self.tmpdir = 'test_tmpdir'

            def join_path(self, arg_0, arg_1):
                return arg_0 + arg_1

            def path_has_trailing_slash(self, arg):
                if arg[-1] == os.path.sep:
                    return True
                return False


# Generated at 2022-06-25 06:40:27.274870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    retval_0 = ActionModule('ansible.legacy.copy')
    assert retval_0.task == 'ansible.legacy.copy'
    assert retval_0._loader == 'CachingFileLoader'
    assert retval_0._templar == 'AnsibleTemplar'
    assert retval_0._shared_loader_obj == 'CachingFileLoader'
    assert retval_0._task.action == 'ansible.legacy.copy'
    assert retval_0._task.args == '{}'

# Generated at 2022-06-25 06:41:21.910692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare objects and variables
    var_0 = None

    # Create an object of the class ActionModule
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

    # Method run of class ActionModule
    action_module_0.run(var_0, var_0)


# Generated at 2022-06-25 06:41:24.705079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:41:29.465385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 06:41:33.316393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:41:38.564743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create ActionModule
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    assert (isinstance(action_module_0, ActionModule))
    # Create ActionModule
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_1 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    assert (isinstance(action_module_1, ActionModule))
    # Create ActionModule
    bool_0 = True
    float_0 = 0.0001
   

# Generated at 2022-06-25 06:41:42.317182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    assert action_module_0.run() is None


# Generated at 2022-06-25 06:41:44.500529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(b'mock', True, 0.01, True, b'mock', ())
    assert 'mock' == a.run()


# Generated at 2022-06-25 06:41:47.994583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module_0 = ActionModule(None)
    # Init value for tmp
    tmp_1 = None
    # Init value for task_vars
    task_vars_1 = None

    # Invoke method
    result = action_module_0.run(tmp_1, task_vars_1)
    assert result is None


# Generated at 2022-06-25 06:41:56.129906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)

    assert action_module_0._supports_check_mode is False
    assert action_module_0._supports_async is False

    assert action_module_0._connection is None
    assert action_module_0._play_context is None
    assert action_module_0._loader is None
    assert action_module_0._templar is None
    assert action_module_0._shared_loader_obj is None
    assert action_module_0._task is None
    assert action_module_0._task_vars is None
    assert action_module

# Generated at 2022-06-25 06:42:01.869818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    bool_0 = True
    float_0 = 0.0001
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, ())
    var_0 = True
    task_vars_0 = dict()
    action_module_0.run(var_0, task_vars_0)


# Generated at 2022-06-25 06:43:58.376829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = Task()
    connection_0 = Connection()
    action_module_0 = ActionModule(task_0, True, 0.0001, True, b'', (),
                                   connection_0)
    print(action_module_0.copy_file)
    print(action_module_0.upload_file)
    print(action_module_0.check_mode)
    print(action_module_0.no_log)
    print(action_module_0._task)
    print(action_module_0._connection)
    print(action_module_0.task_vars)
    print(action_module_0.default_vars)
    print(action_module_0.play_context)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule

# Generated at 2022-06-25 06:44:01.931021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = dict()
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:44:05.678346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    var_0 = action_run()

test_ActionModule()
test_case_0()
action_run()

# Generated at 2022-06-25 06:44:06.712261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 06:44:07.620673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test0 = ActionModule()


# Generated at 2022-06-25 06:44:09.041060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:44:17.593517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    assert action_module_0.name == 'local'
    assert action_module_0.original_name == 'copy'
    assert action_module_0.directive == 'file'
    assert action_module_0.noop_dumps == '{"foo": "bar"}'
    assert action_module_0.noop_has_triggered == False
    assert action_module_0.bypass_cache == False
    assert action_module_0.action == 'file'
    assert action_module_0.job_id == 0
    assert action

# Generated at 2022-06-25 06:44:26.481818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cwd_0 = os.getcwd()
    content_0 = """xxxx"""

    # test method run of class ActionModule
    # tmp no longer has any effect
    # test if the remote cache is enabled
    # test if the destination is a directory or a regular file
    # test if the destination directory exists
    # test if the destination is writeable
    # src is required
    # dest is required
    # src and content are mutually exclusive
    # can not use content with a dir as dest
    # src is required
    # dest is required
    # src and content are mutually exclusive
    # can not use content with a dir as dest
    # src is required
    # dest is required
    # src and content are mutually exclusive
    # can not use content with a dir as dest
    # src is required
    # dest is required
    # src and

# Generated at 2022-06-25 06:44:29.749924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    float_0 = 0.0001
    bytes_0 = b''
    tuple_0 = ()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, tuple_0)
    action_module_0.action_run()

# Generated at 2022-06-25 06:44:36.621620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    bool_0 = True
    float_0 = 0.0001
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, bool_0, bytes_0, bytes_0, bytes_0)
    var_2 = action_module_0._execute_module(bytes_0, bytes_0, bytes_0)
    var_5 = action_module_0._execute_module(bytes_0, bytes_0, bytes_0)
    var_9 = action_module_0._execute_module(bytes_0, bytes_0, bytes_0)
    var_12 = action_module_0._execute_module(bytes_0, bytes_0, bytes_0)