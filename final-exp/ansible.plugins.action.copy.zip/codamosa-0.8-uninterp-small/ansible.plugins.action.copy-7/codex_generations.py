

# Generated at 2022-06-25 06:37:29.459762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    list_0 = [set_0, set_0]
    str_0 = 'LHpc4GDw1m>>m^hYqp#'
    action_module_0 = ActionModule(str_0, set_0, set_0, list_0, str_0, str_0)
    assert_equal(str_0, action_module_0._connection._shell.tmpdir)
    assert_is_none(action_module_0._loader)
    assert_is_none(action_module_0._task)
    assert_is_none(action_module_0._connection)
    assert_is_none(action_module_0._play_context)
    assert_equal(set_0, action_module_0._templar)

# Generated at 2022-06-25 06:37:40.076637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = ['WEX?=^v', 'S5I5.5"jW!9X3[', '~o/Go|%t_W|pA\u0007', '/<NA(u/^n2}X\u000b', '"t%_|Bw']

# Generated at 2022-06-25 06:37:48.093821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A,ty;8%rJ*>Bf6:5U6'
    set_0 = 'path'
    # NOTE: The callable test_case_0 is mapped to run(), so it will be invoked
    # when run() is called.
    # test_case_0 is a function which has input parameters. The value of
    # parameters of test_case_0 is determined by the mocker.patch and
    # mocker.Mock classes.
    # mocker.patch is used to replace the input parameters of the called
    # function (run) with mock objects.
    # Since mocker.patch is used to replace the input parameters, the input
    # parameters of the test_case_0 can be any value.
    # Mocker.Mock class is used create a mock object.
    # Mocker.mock

# Generated at 2022-06-25 06:38:00.297298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'hosts',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)

    runner_run_0 = MockRunnerRun(play=play)

# Generated at 2022-06-25 06:38:07.792232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    list_0 = [set_0, set_0]
    str_0 = '/lbjmwsp'
    action_module_0 = ActionModule(str_0, set_0, set_0, list_0, str_0, str_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:38:16.421735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    list_0 = [set_0, set_0]
    str_0 = 'LHpc4GDw1m>>m^hYqp#'
    action_module_0 = ActionModule(str_0, set_0, set_0, list_0, str_0, str_0)
    print("\nTask: " + str(action_module_0.task))
    # TODO: Validate the task
    assert type(action_module_0.task) is Task
    assert type(action_module_0.connection) is Connection
    assert type(action_module_0.play_context) is PlayContext
    assert type(action_module_0._task.args) is dict

# Generated at 2022-06-25 06:38:22.566238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    list_0 = [set_0, set_0]
    str_0 = 'LHpc4GDw1m>>m^hYqp#'
    action_module_0 = ActionModule(str_0, set_0, set_0, list_0, str_0, str_0)



# Generated at 2022-06-25 06:38:27.804421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_1 = None
    list_1 = [set_1, set_1]
    str_1 = '0}4Y4&4El_waf<Dx)b{'
    action_module_1 = ActionModule(str_1, set_1, set_1, list_1, str_1, str_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:38:29.805546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Test cases for dictionary _copy_file_action_module

# Test case for file _copy_file_action_module

# Generated at 2022-06-25 06:38:36.264174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('pV.a', 'zUiD', 817, '2Yw(n', '^vV8W', 'Z9uV')
    action_module_1 = ActionModule('yP(wA', 'o', 895, '*b"N', '4M[4', 'c%_8h')
    action_module_2 = ActionModule(';a', '<a>X', 879, 'o:dI', 't', '&qMp')
    action_module_3 = ActionModule('AV(2', '?_M}', 852, 'z', 's', ']p=')
    action_module_4 = ActionModule(')E', 'HQ1m', 872, ',*', 'c%', 'e>Zb')
    action_module_

# Generated at 2022-06-25 06:39:19.642034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 1 - constructor")
    # Test the constructor with a module_name and task
    mod = {'module_name': 'ansible.legacy.copy', 'task': None}
    action_mod = ActionModule(mod)
    if action_mod is None:
        print("ActionModule constructor failed: unable to create an instance")
        return 1
    else:
        print("Test 1 - Success")
        return 0

test_case_1()
test_case_0()
test_ActionModule()

# Generated at 2022-06-25 06:39:23.493595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_class = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-25 06:39:27.688527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert True

if __name__ == '__main__':
    # test constructor
    test_ActionModule()
    # test case 0
    test_case_0()

# Generated at 2022-06-25 06:39:36.632638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_dict = {
        'content': '',
        'dest': 'A,ty;8%rJ*>Bf6:5U6',
        'follow': '',
        'mode': '',
        'owner': '',
        'repo_path': '',
        'selevel': '',
        'serole': '',
        'setype': '',
        'seuser': '',
        'src': '',
        'state': 'present',
        'unsafe_writes': '',
        'validate': '',
        'version': '',
    }
    return_value_0 = ActionModule.run(args_dict)

test_case_0()

# Generated at 2022-06-25 06:39:47.969353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loader = Mock()
    shell = FakeShellModule()
    OptionsModule = collections.namedtuple('OptionsModule', ['no_log'])
    options = OptionsModule(no_log=False)
    tmp = '/tmp/'
    task_vars = {'_ansible_no_log': False}
    source = 'src'
    content = 'content'
    dest = 'dest'
    remote_src = False
    local_follow = False
    data_path = 'data_path'
    _task_action = 'file'
    _task_args = {'dest': 'dest', 'src': 'src'}
    _task_dep_file = 'path'
    _task_async = 'async'
    _task_async_val = 'val'
    _task_notify = 'notify'

# Generated at 2022-06-25 06:39:58.899846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _remote_expand_user_path_0 = (random.randint(0, 1000) - 437) + 798
    _remote_expand_user_path_1 = (random.randint(0, 1000) - 579) + -469
    _remove_tmp_path_sep = ''.join([str(random.randint(0, 10)) for _ in range(random.randint(1, 9))])
    _remove_tmp_path_sep_0 = random.choice([(random.randint(-184, -7) - -982), 'rV=CvJG_X;p[xD.sE@B'])
    _remove_tmp_path_sep_1 = (random.randint(0, 1000) + -931) + 240
    _remove_tmp_path_

# Generated at 2022-06-25 06:40:03.498846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(0, 0, 0)
    str_0 = 'A,ty;8%rJ*>Bf6:5U6'
    str_1 = 'path'
    str_2 = 'dest'
    dict_0 = dict()
    dict_0['path'] = 'path'
    dict_0['dest'] = 'dest'

    action_module_0._handle_aliases(dict_0)


# Generated at 2022-06-25 06:40:04.419009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:40:06.558458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0, param_1 = param_1()
    assert param_0.run(param_1) == None



# Generated at 2022-06-25 06:40:16.884045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = 'c-1.tmp'
    content = 'A,ty;8%rJ*>Bf6:5U6'
    source = 'c-1.tmp'
    task_vars = dict()
    task_vars['content'] = 'A,ty;8%rJ*>Bf6:5U6'
    task_vars['_ansible_no_log'] = False
    task_vars['dest'] = 'c-1.tmp'
    task_vars['_ansible_verbosity'] = 0
    task_vars['_ansible_syslog_facility'] = 'LOG_USER'
    task_vars['_ansible_selinux_special_fs'] = ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p']
    task

# Generated at 2022-06-25 06:41:07.380828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(str_0, list_0, list_0, list_0, dict_0, list_0, list_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:41:09.230238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:41:14.163066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 9.346603837975615
    list_0 = [float_0, float_0, float_0]
    dict_0 = {"it": "dummy", "it2": "dummy2"}
    action_module_0 = ActionModule(float_0, list_0, list_0, list_0, dict_0, list_0)


# Generated at 2022-06-25 06:41:16.774500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(float_0, list_0, list_0, list_0, dict_0, list_0)
    assert action_module_0._result == dict_0


# Generated at 2022-06-25 06:41:18.079827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule.run(ActionModule())
    assert x == None

# Generated at 2022-06-25 06:41:25.410965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1604.959148
    list_0 = [float_0, float_0, float_0, float_0]
    int_0 = -1604
    dict_0 = {float_0: list_0, float_0: int_0, int_0: float_0}
    action_module_0 = ActionModule(float_0, list_0, list_0, list_0, dict_0, list_0)
    result = action_module_0.run(float_0, dict_0)

# Generated at 2022-06-25 06:41:31.176419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1604.959148
    list_0 = [float_0, float_0, float_0, float_0]
    int_0 = -1604
    dict_0 = {float_0: list_0, float_0: int_0, int_0: float_0}
    action_module_0 = ActionModule(float_0, list_0, list_0, list_0, dict_0, list_0)

# Generated at 2022-06-25 06:41:35.811575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 28232.0
    list_0 = [float_0, float_0, float_0, float_0]
    list_1 = ["7o", float_0, float_0, float_0]
    list_2 = [float_0, float_0, float_0, float_0]
    dict_0 = {float_0: list_0, float_0: float_0, float_0: float_0}
    list_3 = [float_0, float_0, float_0, float_0]
    action_module_0 = ActionModule(float_0, list_0, list_1, list_2, dict_0, list_3)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:41:39.111368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    action_module_0 = ActionModule(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)

# Generated at 2022-06-25 06:41:46.773070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3030.381064
    list_0 = [float_0, float_0, float_0, float_0]
    list_1 = [float_0, float_0, float_0, float_0]
    list_2 = [float_0, float_0, float_0, float_0]
    int_0 = -3030
    dict_0 = {float_0: list_0, float_0: int_0, int_0: float_0}
    action_module_0 = ActionModule(float_0, list_0, list_1, list_2, dict_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 06:43:33.183350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1604.959148
    list_0 = [float_0, float_0, float_0, float_0]
    int_0 = -1604
    dict_0 = {float_0: list_0, float_0: int_0, int_0: float_0}
    action_module_0 = ActionModule(float_0, list_0, list_0, list_0, dict_0, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:43:38.021329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(NotImplementedError):
        float_0 = float()
        list_0 = [float_0]
        list_1 = [float_0]
        list_2 = [float_0]
        dict_0 = {}
        list_3 = [float_0]
        action_module_0 = ActionModule(float_0, list_0, list_1, list_2, dict_0, list_3)
        action_module_0.run(list_1, dict_0)

# Generated at 2022-06-25 06:43:46.661122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1604.959148
    list_0 = [float_0, float_0, float_0, float_0]
    int_0 = -1604
    dict_0 = {float_0: list_0, float_0: int_0, int_0: float_0}
    action_module_0 = ActionModule(float_0, list_0, list_0, list_0, dict_0, list_0)
    dict_0 = action_run(list_0, dict_0)
    assert dict_0 == dict_0
    assert dict_0.get("changed") == dict_0.get("changed")


# Generated at 2022-06-25 06:43:48.937427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 06:43:57.297442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variables for testcase 0
    float_0 = 1537.9771769
    list_0 = [float_0, float_0, float_0, float_0]
    list_1 = [float_0, float_0, float_0, float_0]
    list_2 = [float_0, float_0, float_0, float_0]
    dict_0 = {float_0: list_0, float_0: float_0, float_0: float_0}
    list_3 = [float_0, float_0, float_0, float_0, float_0]
    float_1 = 1523.5944573
    list_4 = [float_1, float_1, float_1, float_1]

# Generated at 2022-06-25 06:44:06.790253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = -1872
  list_0 = [int_0, int_0, int_0]
  list_1 = [1872, 1872, 1872]
  list_2 = [1872, 1872, 1872]
  list_3 = [1872, 1872, 1872]
  dict_0 = {int_0: list_0, int_0: list_1, int_0: list_2}
  action_module_0 = ActionModule(int_0, list_1, list_2, list_3, dict_0, list_0)
  var_0 = action_module_0.run()

# Generated at 2022-06-25 06:44:08.869745
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:44:17.120389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -121.9796
    list_0 = [float_0, float_0, float_0, float_0]
    list_1 = [float_0, float_0, float_0, float_0]
    list_2 = [float_0, float_0, float_0, float_0]
    dict_0 = {float_0: list_0, float_0: float_0, float_0: float_0}
    list_3 = [float_0, float_0, float_0, float_0]
    action_module_0 = ActionModule(float_0, list_0, list_1, list_2, dict_0, list_3)
    action_module_0.run()


# Generated at 2022-06-25 06:44:18.675154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Builtin test cases:
# test_ActionModule()

# Generated at 2022-06-25 06:44:20.836853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0.argspec() == None)
