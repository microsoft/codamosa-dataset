

# Generated at 2022-06-25 06:37:29.552729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 119
    float_0 = -0.3
    int_1 = 253
    str_0 = '/X@MkC()rtdU< 7\\]g=pP'
    bytes_0 = b'mb|I\x1a\x19\xa5\xd7\x1d\xac\xa2'
    str_1 = 'N?~g$h\x19\x18\xea\x0e\x1a'
    action_module_0 = ActionModule(int_0, float_0, int_1, str_0, bytes_0, str_1)
    arguments_0 = dict()
    arguments_0['dest'] = 'V`(x@uw7nJ'
    arguments_0['follow'] = False

# Generated at 2022-06-25 06:37:40.118923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1525
    float_0 = 8.851
    int_1 = -1535
    str_0 = 's.w'
    bytes_0 = b'\x03\x15\x15\x12\x0a\x1c\x1d\x0c\x07\x13\x1f\x07\x0f\x1e\x11\x07'
    str_1 = '\x0f\x19\x1e\x19\x08\x0a\x1a\x1d\x1e\x04\x0d\x08\x0a\x1f\x08\x1e\x0a\x0f\x00\x15\x0d\x0f'
    action_module_0 = ActionModule

# Generated at 2022-06-25 06:37:48.185852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1554
    float_0 = -243.948
    str_0 = 'B(>c6h'
    action_module_0 = ActionModule(int_0, float_0, int_0, str_0, str_0, str_0)

# Generated at 2022-06-25 06:38:00.344772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    init_param_0 = b'm4\tQs'
    init_param_1 = 1.1944444444444444
    init_param_2 = -2

# Generated at 2022-06-25 06:38:10.600157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Old style class created instance of class ActionModule
    int_0 = 1194
    float_0 = -448.4643
    str_0 = 'd!FmjmE<? ((KG.\\|e'
    bytes_0 = b'\x1b\x10'
    action_module_0 = ActionModule(int_0, float_0, int_0, str_0, bytes_0, str_0)
    tmp_0 = None
    task_vars_0 = {}

    result = action_module_0.run(tmp_0, task_vars_0)
    print(result)


# Generated at 2022-06-25 06:38:17.844839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    func_labels = {}
    function_name = 'test_case_0'
    if function_name in func_labels:
        label = func_labels[function_name]
    else:
        label = function_name
    print('in %s' % (label,))
    int_0 = 1194
    float_0 = -448.4643
    int_1 = 1194
    str_0 = 'd!FmjmE<? ((KG.\\|e'
    bytes_0 = b'\x1b\x10'
    str_1 = 'd!FmjmE<? ((KG.\\|e'
    action_module_0 = ActionModule(int_0, float_0, int_1, str_0, bytes_0, str_1)
    return


# Generated at 2022-06-25 06:38:24.708885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1194
    float_0 = -448.4643
    str_0 = 'd!FmjmE<? ((KG.\\|e'
    bytes_0 = b'\x1b\x10'
    action_module_0 = ActionModule(int_0, float_0, int_0, str_0, bytes_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 06:38:32.477775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 64193
    float_0 = 163.5
    int_1 = 1445
    str_0 = 'x{  t_m>'
    bytes_0 = b'\x0c\x0b'
    str_1 = "BRgAm[0@z2  ^_"
    action_module_0 = ActionModule(int_0, float_0, int_1, str_0, bytes_0, str_1)
    assert(action_module_0._task == int_0)
    assert(action_module_0._connection == float_0)
    assert(action_module_0._play_context == int_1)
    assert(action_module_0._loader == str_0)
    assert(action_module_0._templar == bytes_0)

# Generated at 2022-06-25 06:38:34.675353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception as e:
        print('[ERROR]: %s' % str(e))
        assert 0
    else:
        assert 1

# Define unit test function

# Generated at 2022-06-25 06:38:39.126334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mock args
    task_vars = {}
    # Perform the call
    result = ActionModule.run(task_vars)
    # Check the results
    assert False == result["failed"]
    assert False == result["changed"]

# Generated at 2022-06-25 06:39:24.983879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_0 = {}
    test_case_1_ActionModule = ActionModule(None, var_0)


# Generated at 2022-06-25 06:39:35.290400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if not os.path.isfile("/tmp/ansible_semaphore_TZ1m_Dd"):
        os.mkfifo("/tmp/ansible_semaphore_TZ1m_Dd")

    if not os.path.isfile("action_plugins/modules/copy.py"):
        os.mkfifo("action_plugins/modules/copy.py")

    if not os.path.isfile("/tmp/ansible_semaphore_ZzU6Vl"):
        os.mkfifo("/tmp/ansible_semaphore_ZzU6Vl")


# Generated at 2022-06-25 06:39:37.717915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define arguments
    tmp = undefined
    task_vars = undefined

    # Call method
    try:
        ActionModule.run(tmp, task_vars)
    except SystemExit:
        pass

# Generated at 2022-06-25 06:39:39.758059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var = ActionModule()
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:43.746475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    test_case = ActionModule(var_1, var_0)
    assert test_case.set_options(var_0) == None


# Generated at 2022-06-25 06:39:45.245807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    var_0 = None
    var_1 = {}
    action_module.run(var_0, var_1)


# Generated at 2022-06-25 06:39:46.357644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}


# Generated at 2022-06-25 06:39:55.119902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = {}
    var_1['checksum'] = '25101ab66786f6f3d049a7e9a9b14e7bdc51d6d8'
    var_1['owner'] = None
    var_1['uid'] = None
    var_1['attributes'] = {}
    var_1['path'] = '/tmp/ansible_file_payload_uMp7Vc'
    var_1['secontext'] = 'system_u:object_r:user_tmp_t:s0'
    var_1['_original_basename'] = 'hello.txt'
    var_1['gid'] = None
    var_1['mime_type'] = ''
    var_1['access_time'] = 1585196250

# Generated at 2022-06-25 06:39:56.389260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:40:04.666821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    var_2 = {}

    class ActionModule_test(ActionModule):
        def __init__(self, var_0, var_1, var_2):
            self.task = var_0
            self.connection = var_1
            self.play_context = var_2

    var_0 = {}
    var_1 = {}
    var_2 = {}
    acm = ActionModule_test(var_0, var_1, var_2)
    acm.task = var_0
    acm.connection = var_1
    acm.play_context = var_2
    return acm


# Generated at 2022-06-25 06:40:56.482329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 is expected to be dict
    var_0 = {}
    # var_1 is expected to be dict
    var_1 = {}
    tm = ActionModule(var_0, var_1)
    # check if object tm is an instance of class ActionModule
    assert isinstance(tm, ActionModule)


# Generated at 2022-06-25 06:41:02.380308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # init an empty dict to pass to module
    var_0 = {}

    # create a dummy module for module_args to pass in
    class DummyModule():
        def __init__(self, params):
            self.params = params
        def fail_json(self, msg, **kwargs):
            return 'fail_json'
    var_1 = DummyModule(var_0)

    # create a dummy args for ActionModule to pass in
    var_2 = {}

    # test case 1
    test_case_1(var_1, var_2)


# Generated at 2022-06-25 06:41:03.567996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
# Main function
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 06:41:10.252357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_0 = var_0["task_vars"] = {}
    var_0 = var_0["tmp"] = {}
    var_0 = var_0["_task"] = {}
    var_0 = var_0["_task"] = var_0["_task"]
    var_0 = var_0["args"] = {}
    var_0 = var_0["dest"] = {}
    var_0 = var_0["_task"] = var_0["_task"]
    var_0 = var_0["args"] = var_0["args"]
    var_0 = var_0["remote_checksum"] = {}
    var_0 = var_0["_task"] = var_0["_task"]
    var_0 = var_0["args"] = var_0["args"]


# Generated at 2022-06-25 06:41:12.393119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_0 = {}
    action_module = ActionModule(data_0)

    result_0 = action_module.run()

# Generated at 2022-06-25 06:41:15.704857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    var_1['task'] = 'task'

    # Instantiation of ActionModule
    class_ActionModule_module = ActionModule(var_1)

    # Assertion to check the id of class_ActionModule_module
    #
    # We cannot use assertEqual() here, because the task is a class, not a
    # simple int
    assert class_ActionModule_module.task == var_1['task']


# Generated at 2022-06-25 06:41:23.611597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dump_task_args(task_args)
    ansible_facts = {}
    var_0 = {}
    loader = _load()
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
    )
    tqm._stdout_callback = ResultCallback()
    ac = ActionModule(
        task=task,
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=None
    )

    # test method get_version
    ac.get_version()

    # test method run
    result = ac.run(tmp=None, task_vars=task_vars)
    dump_result(result)


# Generated at 2022-06-25 06:41:25.138027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:41:26.438267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}


# Generated at 2022-06-25 06:41:34.935634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}

    var_3 = {}
    var_3['msg'] = ('src (or content) is required')
    var_3['failed'] = True
    var_5 = {}
    var_5['src'] = None
    var_5['dest'] = 'What'
    var_4 = {}
    var_4['args'] = var_5
    var_6 = {}

    var_2 = ActionModule(var_4,var_6)
    var_2.run(var_1)
    var_7 = {}
    var_7['msg'] = ('dest is required')
    var_7['failed'] = True
    var_9 = {}
    var_9['src'] = 'What'
    var_9['dest'] = None
    var_8 = {}

# Generated at 2022-06-25 06:43:23.296469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    vt = ValueTester.ValueTester(var_0)
    vt.test(test_case_0, 'ActionModule')
    return

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:43:31.398986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {'ansible_connection': 'local', 'ansible_version': {'complete_sha': '8bbf7d59201543e1e7b38cbb8c44a4b65f20c701', 'full': '2.9.1.tar.gz', 'ansible_module_utils': '2.7.2', 'version': '2.9.1'}, 'ansible_play_hosts': [''], 'ansible_play_batch_size': 1, 'ansible_play_hosts_all': {'hosts': {'': {'ansible_check_mode': False, 'ansible_no_log': False}}}, 'ansible_python_version': '3.8.3'}
    # var_1 = {'ansible_facts': {'thisfile': '/home

# Generated at 2022-06-25 06:43:39.114772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    var_24 = dict()

# Generated at 2022-06-25 06:43:50.101236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # try:
    #     raise AnsibleError('some error')
    # except AnsibleError as e:
    #     var_2 = e
    action._task.args={u"content": u"some content", "dest": "/tmp/test"}
    action._task.args={u"src": u"/tmp/somefile", "dest": "/tmp/test"}
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
   

# Generated at 2022-06-25 06:43:55.115960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Does this work?
    var_0 = ActionModule(task=Task(), connection=Connection, play_context=PlayContext(), loader=DataLoader(), templar=Templar, shared_loader_obj=None)
    var_0 = ActionModule(task=Task(), connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 06:44:05.845253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate an instance of ActionModule
    action_module_instance_0 = ActionModule(var_0)
    # test whether the instance is constructed as expected
    assert type(action_module_instance_0) is ActionModule
    print("Test 0: instantiation of ActionModule class successful")
    # test the return value of method run of the instance action_module_instance_0
    print("Test 1: test the return value of method run")
    action_module_instance_0.run()
    print("Test 2: test the return value of method run")
    print("Test 3: test the return value of method run")
    print("Test 4: test the return value of method run")
    print("Test 5: test the return value of method run")
    print("Test 6: test the return value of method run")

# Generated at 2022-06-25 06:44:09.687187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}

    var_1 = {}

    var_0['test'] = var_1
    var_2 = ActionModule(var_0)
    var_3 = {}
    var_3['test'] = var_1
    var_3['test1'] = var_1

    var_4 = ActionModule(var_3)


# Generated at 2022-06-25 06:44:11.760574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit tests for ActionModule
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:44:17.120976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an object of the class
    obj = ActionModule()

    # Create an object of the AnsibleModule Fake class
    module = object()

    # Create an object of the AnsibleModule Fake class
    task = object()

    # Create an object of the AnsibleModule Fake class
    tmp = object()

    # Create an object of the AnsibleModule Fake class
    task_vars = {}

    # Call the method being tested
    obj.run(tmp, task_vars)


# Generated at 2022-06-25 06:44:20.500288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Declarations
    tmp = None
    task_vars = None
    #End of test setup

    #Calling the method under test
    t0 = ActionModule()
    t0.run(tmp, task_vars)



# Generated at 2022-06-25 06:46:40.311308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:46:43.658585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    test_case_0()

if __name__ == "__main__":
    print("=== begin ===")
    test_ActionModule_run()
    print("=== end ===")