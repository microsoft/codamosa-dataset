

# Generated at 2022-06-23 07:37:12.338832
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Set up parameters for ActionModule
    mock_task = mock.Mock()
    mock_connection = mock.Mock()
    mock_templar = mock.Mock()
    mock_loader = mock.Mock()

    # Create instance of ActionModule
    am = ActionModule(
        task=mock_task,
        connection=mock_connection,
        templar=mock_templar,
        loader=mock_loader)

    # Check attributes of instance
    assert am._task == mock_task
    assert am._connection == mock_connection
    assert am._templar == mock_templar
    assert am._loader == mock_loader
    assert not hasattr(am, '_shell')


# Generated at 2022-06-23 07:37:24.384430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ansible.modules.copy.ActionModule(runner=play_context.PlayContext(),
                                               task=dict(
                                                   base_path='/tmp/ansible_test',
                                                   action='ansible.legacy.copy',
                                                   args=dict(
                                                       follow=True,
                                                       original_basename='somefile',
                                                       checksum='md5:b673a8a3a3dc3f0a6d0e8f8b9f9b112a',
                                                       src='/path/to/somefile',
                                                       dest='/tmp/ansible_test'
                                                   )
                                               )
                                               )
    assert module._play_context == play_context.PlayContext()

# Generated at 2022-06-23 07:37:39.076383
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:37:41.469621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule()
    print(test_action_module.run())



# Generated at 2022-06-23 07:37:43.036462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({})
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 07:37:50.627086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection_args = {}
    connection_args['host'] = 'localhost'
    connection_args['port'] = 22
    connection_args['user'] = 'user'
    connection_args['pass'] = 'pass'
    connection_args['timeout'] = 4
    connection_args['remote_user'] = 'remote_user'


# Generated at 2022-06-23 07:37:53.199326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    #
    # @TODO: Probably not the right check here
    #assert not ActionModule.run().failed
    pass

# Generated at 2022-06-23 07:37:59.585124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.executor.task_result
    result = ansible.executor.task_result.TaskResult(None, dict(action='copy'))
    result.set_task_result(None, None)
    assert isinstance(ActionModule(None, None, result), ansible.executor.task_result.TaskResult)


# Generated at 2022-06-23 07:38:05.901499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner = ActionModule(Connection('ssh', 'localhost', 'ansible'),
                          'ansible.legacy.copy',
                          '/usr/local/bin/ansible',
                          '/usr/local/bin',
                          'ansible',
                          {'src': '/usr/local/bin/ansible'},
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    return runner


# Generated at 2022-06-23 07:38:15.144043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import shutil
    import tempfile


# Generated at 2022-06-23 07:38:18.253580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method run
    """
    module = ActionModule()
    assert False == module.run()


# Generated at 2022-06-23 07:38:25.647986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task_vars = {'a': '1', 'b': '2'}
  module_return = {'a': '1'}
  instance = {'hostname': 'host', 'ipv4': ['10.10.10.10']}
  tmp = '/path/to/tempdir'

  action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  action_module._set_connection(connection_name='local')
  action_module._connection._shell.tmpdir = '/tmp'
  action_module._loader.path_exists.return_value = True
  action_module._find_needle.return_value = instance
  action_module._execute_module.return_value = module_return
 

# Generated at 2022-06-23 07:38:34.516103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = Mock()
    host.get_vars.return_value = {'ansible_version': '2.8'}

    task = Mock()
    task.args = dict()

    shell = Shell()
    am = ActionModule(task, shell, host)
    assert am.CONTENT_REGEX is None
    assert am.CONTENT_META is None

    class Meta:
        content_regex = 'some_content_regex'
        content_meta = 'some_content_meta'

    host.get_vars.return_value = {'ansible_version': '2.9'}

# Generated at 2022-06-23 07:38:44.833294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock a task
    task = mock.Mock()
    task._role = mock.Mock()
    task._role.get_path.return_value = C.DEFAULT_ROLES_PATH
    task._role._role_path = "/home/test/ansible_roles/common"
    task._role._role_name = "common"
    task._role.name = "common"
    task._role.path = "/home/test/ansible_roles/common"
    task._ds = mock.Mock()
    task._ds.get_failed_hosts.return_value = []
    task._ds.get_host_failed.return_value = None

    # task.args is a dictionary
    get_task_args = mock.Mock()

# Generated at 2022-06-23 07:38:47.932531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert isinstance(m, ActionModule)
    print(m)

# Generated at 2022-06-23 07:38:58.236266
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1: When source is a directory and content is not defined.
    # Test 2: When source is a directory and content is also defined.
    # Test 3: When source is a file and content is also defined.
    # Test 4: When src and content is defined.

    # Test 1: When source is a directory and content is not defined
    from ansible.module_utils._text import to_text

    def _ensure_invocation(self, result):
        return result

    def _find_needle(self, dirname, needle):
        return 'test/files/' + needle

    def _remote_expand_user(self, path):
        return path

    def _remove_tmp_path(self, tmp):
        self._shell.tmpdir = None


# Generated at 2022-06-23 07:39:07.294006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    
    mock_TaskQueueManager_run = mocker.patch('ansible.executor.task_queue_manager.TaskQueueManager.run').start()
    mock_TaskQueueManager_run.return_value = ['0']
    mock_TaskResult_exception = mocker.patch('ansible.executor.task_result.TaskResult.exception').start()
    mock_TaskResult_exception.return_value = 'false'
    mock_TaskResult_exception = mocker.patch('ansible.executor.task_result.TaskResult.stdout').start()

# Generated at 2022-06-23 07:39:16.893878
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock task and task_result named task_variable
    task_var = Mock()
    task_result = Mock()
    task_var.result = task_result
    task_var.args = dict()

    # Create the object under test
    action_module = ActionModule(task_var, connection=Mock())

    # Create a mock result dictionary
    result = dict()

    # Create a mock tmp named as tmp_var
    tmp_var = Mock()

    # Define return value for method run
    # Test case 1 does not contain return value for method run
    # Test case 2 contains a dummy return value for method run

    # Call method run
    return_val = action_module.run(tmp=tmp_var)



# Generated at 2022-06-23 07:39:22.837483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test constructor of class ActionModule.
    '''

    module = AnsibleModule(
        argument_spec = dict(
            src = dict(),
            dest = dict()
        ),
        supports_check_mode = True
    )

    action_plugin = ActionModule(module.task, module.connection, module._shared_loader_obj, module._play_context)

    return action_plugin

# Generated at 2022-06-23 07:39:24.463971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run()

# Generated at 2022-06-23 07:39:33.197431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule
    """
    assert ActionModule._uses_shell is False
    assert ActionModule._uses_templating is True
    assert ActionModule._uses_unsafe_shell is False

if __name__ == '__main__':
    # Unit test for module_args_parser function
    action = ActionModule(None)
    assert action.module_args_parser(None) == (None, dict())
    assert action.module_args_parser('') == ('', dict())
    assert action.module_args_parser('dest=/tmp') == ('/tmp', dict(dest='/tmp'))
    assert action.module_args_parser('dest=/tmp/a.txt') == ('/tmp/a.txt', dict(dest='/tmp/a.txt'))
    assert action.module_args_parser

# Generated at 2022-06-23 07:39:37.240137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    first_available_file = []
    file_args = {}
    file_vars = {}
    follow = False
    force = False
    if_missing = None
    if_different = False
    local_follow = True
    recursive = False
    remote_src = False
    src = []
    src1 = []
    state = []
    update = False


# Generated at 2022-06-23 07:39:48.438412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make a module instance.
    module = ActionModule(
        task=Task(),
        connection=Connection(),
        play_context=PlayContext(
            remote_addr="10.0.0.2",
            port=22,
            remote_user="bobby"
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Make a set of properties for the task.args
    # Ugly.  TODO: Refactor.
    #
    # These are the args that are tested.

# Generated at 2022-06-23 07:39:53.449755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Return the number of keys of an AnsibleTask object."""
    task_fields = ['action', 'loop', 'notify', 'tags', 'until', 'when',
                   'async_val', 'async_jid', 'async_seconds', 'become',
                   'become_user', 'connection', 'delegate_to', 'environment',
                   'first_available_file', 'ignore_errors', 'local_action',
                   'poll', 'remote_user', 'su', 'su_user', 'sudo', 'sudo_user',
                   'transport', 'vars', 'no_log', '_role_name']

# Generated at 2022-06-23 07:39:58.750945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 07:39:59.645342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:40:04.054622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module

    # Create fake ActionModule object
    action_module = ActionModule('', {'module_name': 'file'})
    assert action_module is not None
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 07:40:13.673597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.unsafe_proxy as unsafe
    from ansible.plugins import module_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    import ansible.playbook.play_context
    play_context = ansible.playbook.play_context.PlayContext()

    import ansible.playbook.task
    task = ansible.playbook.task.Task()

    # create the module
    class TestModule(object):
        def __init__(self):
            self.argument_spec = dict()
            self.CHECKMODE = False
            self.params

# Generated at 2022-06-23 07:40:26.065136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    call_result = ''
    def _handle_warnings(message, category, filename, lineno, file=None, line=None):
        ''' mock warning handler, we expect this to be called and not fail '''
        return

    def _execute_module(module_name, module_args, task_vars=dict()):
        ''' mock module, returns a call result for the transfer module '''
        global call_result
        return call_result

    source = "/tmp/source"
    content = "string"
    dest = "/tmp/dest"
    src = "src"
    tmp = "/tmp/tmp"
    content = "content"
    task_vars = dict()
    def _find_needle(dir, needle):
        return source
    def _remote_expand_user(dest):
        return dest


# Generated at 2022-06-23 07:40:31.543241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.connection import Connection

    # Create a mock of the Connection plugin
    mock_connection = Connection()

    # We pass a mock of the display object in order to silence any output to
    # stdout.
    mock_display = Display(verbosity=0)

    # Create mock of the AnsibleOptions

# Generated at 2022-06-23 07:40:32.203772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:40:41.112830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # rsync transfer
    action = ActionModule(connection=MagicMock())
    action.connection.run.return_value = 123
    action.connection._shell.join_path.return_value = "mocky"

    # rsync transfers not enabled, should create temp file
    assert action.transfer_strategy == 'temp'

    # rsync transfers enabled, should create temp file
    action.connection.rsyncing = True
    assert action.transfer_strategy == 'rsync'

    # Temp file supported, should create temp file
    action.connection.rsyncing = False
    action.connection._shell.supports_rsync_flags.return_value = False
    assert action.transfer_strategy == 'temp'
    assert action.transfer_tempfile == "mocky"

    # Rsync transfers not enabled and temp file not available

# Generated at 2022-06-23 07:40:50.250018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'testHost'
    task = dict(name='testTask')
    task_vars = dict()
    connection = 'testConnection'
    play_context = 'testPlayContext'
    loader = 'testLoader'
    templar = 'testTemplar'
    shared_loader_obj = 'shared_loader_obj'

    test_action_module = \
        ActionModule(
            host=host,
            task=task,
            task_vars=task_vars,
            connection=connection,
            play_context=play_context,
            loader=loader,
            templar=templar,
            shared_loader_obj=shared_loader_obj)

    assert test_action_module.host == host
    assert test_action_module.task == task
    assert test_action_module.task

# Generated at 2022-06-23 07:41:03.470368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    def _task_run(task):
        connection = task.args.get('delegate_to', None)
        if connection:
            return task.run(connection=connection, play_context=play_context, task_vars=non_local_vars)
        else:
            return task.run(play_context=play_context, task_vars=non_local_vars)

    class TestCallback(object):
        def __init__(self):
            self.events = []
            self.fail = False
            self.result = {}


# Generated at 2022-06-23 07:41:07.747900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# Invoke the constructor of the ActionModule class
	actionModule =  ActionModule()
	result = actionModule.run()
	# Verify that the expected result has been obtained; return a result indicating that all tests were successful
	assert result

# Generated at 2022-06-23 07:41:22.154187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test ActionModule constructor """

    # Test ActionModule constructor with no arguments
    action_module = ActionModule()

    # Test ActionModule constructor with just the path to a file.
    path_to_file = os.path.abspath("test/ansible/modules/network/eos/eos_template.py")
    action_module = ActionModule(path_to_file=path_to_file)

    # Test ActionModule constructor with a ActionModule object as the action_plugins_path
    action_module = ActionModule(action_plugins_path=action_module)

    # Test module_loader. Could not figure out how to mock this.
    # module_loader = ActionModule(module_loader=module_loader)


# Generated at 2022-06-23 07:41:33.919297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.copy import ActionModule
    
    # Set up mock
    mock_find_needle = MagicMock()
    mock_find_needle.find_needle = MagicMock(side_effect=[
        '/etc/foo',
        '/etc/bar',
        Exception,
        '/etc/foo',
        '/etc/bar',
        Exception,
        '/etc/foo',
        '/etc/bar'])

    mock_remote_expand_user = MagicMock()
    mock_remote_expand_user.remote_expand_user = MagicMock(return_value='/etc/ansible')

    mock_execute_module = MagicMock()
    mock_execute_module.execute_module = MagicMock(return_value={'changed': True})

    mock_ensure_inv

# Generated at 2022-06-23 07:41:39.826705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = dict(
        content=None,
        dest=None,
        follow=None,
        local_follow=None,
        remote_src=None,
        src=None,
    )

    # constructor is not supported on python2.6
    # action_module = ActionModule(task_args)
    # print(action_module)


# Generated at 2022-06-23 07:41:47.117514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.supports_check_mode == True

    action_module = ActionModule(task=None)
    assert action_module.supports_check_mode == True

    action_module = ActionModule(task=None, connection=None, runner=None, shared_loader_obj=None)
    assert action_module.supports_check_mode == True


# Generated at 2022-06-23 07:41:52.014425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This is just a wrapper.  We test the underlying task.
    class Wrapper(object):
        def __init__(self, args):
            self.args = args

    args = dict(src='./', dest='./')
    wrapper = Wrapper(args)
    action = ActionModule(wrapper, dict(), False)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 07:42:03.743918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    test ActionModule constructor
    '''
    connection = DummyConnection(None, None)

    constructor_args = dict(
            task=object(), # Should be Task object
            connection=connection,
            templar=None, # Should be Templar object
            shared_loader_obj=None, # Should be DataLoader object
            loader=None # Should be DataLoader object
        )

    action_module = ActionModule(**constructor_args)

    assert action_module._task is constructor_args['task']
    assert action_module._connection is connection
    assert action_module._templar is constructor_args['templar']
    assert action_module._loader is constructor_args['loader']
    assert action_module._shared_loader_obj is constructor_args['shared_loader_obj']



# Generated at 2022-06-23 07:42:15.934427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check default attribute values
    action_module = ActionModule()
    assert action_module.argument_spec == {}
    assert action_module.default_vars == {}
    assert action_module.bypass_checks == False
    assert action_module.no_log == False
    assert action_module.connection is None
    assert action_module.task is None
    assert action_module.loader is None
    assert action_module.result is None
    assert action_module.delegate_to is None
    assert action_module.redirected_stdout is False

    # Set the attribute values to something custom
    action_module._task = 'test_task'
    connection = dict(hello='world')
    action_module._connection = connection
    loader = dict(foo='bar')
    action_module._loader = loader
    action_module

# Generated at 2022-06-23 07:42:27.416396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    :return: test passed or failed bool
    :rtype: bool
    '''
    # Test a copy action
    copy_action = dict(action=dict(module='copy',
                                   args=dict(src='/tmp/a',
                                             dest='/tmp/b')))
    action_module = ActionModule(copy_action, raise_exception=False)
    # Test the callable object
    callable_obj = action_module.run('/tmp/a', dict())
    assert callable_obj.module_args == dict(src='/tmp/a', dest='/tmp/b')
    assert callable_obj.module_name == 'ansible.legacy.copy'

    # Test a file action

# Generated at 2022-06-23 07:42:41.742165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create the task queue manager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None
    )

    # Create a play to work with
    play = Play().load("test.yml", variable_manager=None, loader=None)

    # Create the play context to work with
    play_context = PlayContext()

    # Create the task to work with
    task = Task()

# Generated at 2022-06-23 07:42:50.693510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    fake_task = Task()
    fake_task.args = dict(foo='bar')
    fake_task.action = 'copy'
    fake_task.delegate_to = 'localhost'
    fake_task.delegate_facts = None
    fake_action = ActionModule(fake_task, fake_connection, fake_loader)
    assert fake_action is not None
    assert fake_action._task == fake_task
    assert fake_action._connection == fake_connection
    assert fake_action._loader == fake_loader
    assert not fake_action._supports_async


# Generated at 2022-06-23 07:43:01.975795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = ActionModule().run()
    assert res['msg'] == 'src (or content) is required'

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 07:43:04.668831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.module_name = "copy"
    # TODO: build out test suite for this
    assert False


# Generated at 2022-06-23 07:43:13.210314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    import ansible.executor.task_result
    import tempfile
    import json
    import traceback
    import os

    # Define virtual objects
    class LookupError(Exception):
        pass
    class AnsibleError(Exception):
        pass
    class TaskResult(ansible.executor.task_result.TaskResult):
        def __init__(self, host, task, task_result):
            super(TaskResult,self).__init__(host, task, task_result)

# Generated at 2022-06-23 07:43:24.138344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input params
    task_vars = {'ansible_python_interpreter': 'python'}
    dest = 'dest'
    dest_status_nofollow = {'lnk_source': 'link source'}
    dest_status_nofollow['islnk'] = True
    dest_status_nofollow['isdir'] = True
    dest_status_nofollow['inerrno'] = None
    dest_status_nofollow['st_mode'] = 16877
    dest_status_nofollow['bytes'] = '1234'
    dest_status_nofollow['checksum_type'] = 'checksum_type'
    dest_status_nofollow['checksum_salt'] = 'checksum_salt'

    # Setup mocks
    tmp = None
    task_vars

# Generated at 2022-06-23 07:43:28.085151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({'foo': 'bar'}, 'file', False, module_vars={'foo': 'bar'})
    assert hasattr(module, '_task')
    assert hasattr(module, '_connection')
    assert hasattr(module, '_loader')
    assert hasattr(module, '_templar')
    assert hasattr(module, '_shared_loader_obj')


# Generated at 2022-06-23 07:43:30.851062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is a unit test for testing constructor of class ActionModule
    """
    from ansible.plugins import ActionModule
    action_module = ActionModule(None, None, None, None, None)

    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 07:43:40.856420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run method of class ActionModule
    """
    # define args
    args = {
        'content': 'content_data',
        'dest': 'dest_path',
        'follow': False
    }

    ansible_module_instance = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(), loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=MockSharedLoaderObj())

    ansible_module_instance._remove_tempfile_if_content_defined = Mock()

    # define attributes
    ansible_module_instance._task.args = args
    ansible_module_instance._connection._shell.path_has_trailing_slash = Mock()

    # stubs

# Generated at 2022-06-23 07:43:50.427848
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleError
    from ansible.utils import context_objects as co
    from ansible.utils.boolean import boolean
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collections_compat import MutableMapping

    import pytest
    import tempfile
    import shutil
    import os

    # Mock classes to help with the unit test
    class MockConnection(BaseConnection):
        def __init__(self, *args, **kwargs):
            super(MockConnection, self).__init__(*args, **kwargs)

        def set_shell_support(self, shell_support):
            self._shell = shell_support

    # Mock

# Generated at 2022-06-23 07:43:59.761774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    from ansible.plugins.loader import connection_loader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    import ansible.compat.six as six

    tmpdir = tempfile.mkdtemp()
    source = os.path.join(tmpdir, 'source.txt')
    dest = os.path.join(tmpdir, 'dest.txt')


# Generated at 2022-06-23 07:44:09.407060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_connection_type='ssh',
        ansible_ssh_host='dummy',
        ansible_ssh_user='fred'
    )

    # Create a test 'connection'.
    connection = Connection('dummy', 'fred')
    itask = Task.load('foo', {}, connection, task_vars=task_vars)

    module = ActionModule(itask, task_vars=dict())
    assert module._task == itask
    assert module._task.args == {}
    assert module._task_vars == task_vars


# Generated at 2022-06-23 07:44:22.466807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    myvar = {'foo': 'bar',
         'baz': 'qux'}
    action = dict(foo='bar')

    myargs = dict(foo='bar', baz='qux')
    task = dict(action=action, args=myargs)
    result = dict(foo='bar', baz='qux')
    host = Host('127.0.0.1')
    task_vars = dict(foo='bar', baz='qux')
    play_context = dict(foo='bar', baz='qux')

    myobj = ActionModule(task, host, task_vars, play_context)
    myobj.run

# Generated at 2022-06-23 07:44:26.571735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(a=1, b=2, c=3))
    assert am._task.args['a'] == 1
    assert am._task.args['b'] == 2
    assert am._task.args['c'] == 3

    am = ActionModule(dict(a=1, b=2, c=3), task_vars=dict(d=4))
    assert am._task.args['a'] == 1
    assert am._task.args['b'] == 2
    assert am._task.args['c'] == 3
    assert am._task_vars['d'] == 4


# Generated at 2022-06-23 07:44:38.667501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase

    action_base = ActionBase()
    # Check that object inherits from ActionBase
    assert isinstance(action_base, ActionBase)

    # Check that object can be instantiated
    assert isinstance(action_base, ActionBase)

    # Check that instance has connection object
    assert isinstance(action_base._connection, Connection)

    # Check that instance has loader object
    assert isinstance(action_base._loader, DataLoader)

    # Check that instance has templar object
    assert isinstance(action_base._templar, Templar)

    # Check that instance has variable manager
    assert isinstance(action_base._variable_manager, VariableManager)

    # Check that instance has connection_loader object

# Generated at 2022-06-23 07:44:47.804631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = {'args': {
        'src': '/etc/hosts',
        'dest': '/etc/hosts',
        'follow': False,
    }}
    mock_play_context = PlayContext()
    mock_connection = Connection()

    action_module = ActionModule(mock_task, mock_play_context, mock_connection)

    assert action_module._task == mock_task
    assert action_module._play_context == mock_play_context
    assert action_module._connection == mock_connection



# Generated at 2022-06-23 07:44:53.282860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock `Runner` object that can be used to execute modules.
    # It relies on `_execute_module` doing its job.
    class MockRunner(object):
        def __init__(self):
            self._connection = MockConnection()

        def on_any(self, *args, **kwargs):
            pass

        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None):
            return dict(changed=False)

    # Create a mock `Connection` object that can be used to evaluate
    # file operations. It relies on `_search_path` and `_create_tmp_path`
    # doing their job.
    class MockConnection(object):
        def __init__(self):
            self._shell = MockShell()
            self

# Generated at 2022-06-23 07:44:58.767424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup test environment
    global ANSIBLE_PRIVATE_MODULE_UTILS
    old_path = copy.copy(sys.path)
    sys.path.append('lib/ansible/module_utils')
    import module_utils
    import module_utils.facts
    ANSIBLE_PRIVATE_MODULE_UTILS = module_utils.__dict__
    task_vars = dict()
    task_executor = _TaskExecutor()
    task_executor._task = _Task()
    task_executor._task.args = dict()
    task_executor._task.action = 'copy'
    task_executor._task.action_loader = DictDataLoader({})
    task_executor._host = _Host()
    task_executor._host.name = 'testhost'
    task_

# Generated at 2022-06-23 07:45:05.194637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    action = ActionModule(task=dict(action='copy', src='src.txt', dest='dest.txt'), task_vars=task_vars, connection=None, tmp=tmp, loader=DictDataLoader(), templar=Templar(loader=DictDataLoader()))

    action.run()
    assert action._task.args == {'action': 'copy', 'dest': 'dest.txt', 'src': 'src.txt'}


# Generated at 2022-06-23 07:45:14.251584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Reset the default connection plugin to 'local'
    C.DEFAULT_CONNECTION = 'local'
    # Default ansible.cfg to not use any config file
    C.CONFIG_FILE = Unset

    # Create a basic task and set the action to file.
    task = Task()
    task.action = 'file'

    # Create a basic task result
    result = TaskResult(host=None, task=task)

    # Create a basic task and set the action to copy.
    task = Task()
    task.action = 'copy'

    # Create a basic task result
    result = TaskResult(host=None, task=task)

    # Create a basic task and set the action to fetch.
    task = Task()
    task.action = 'fetch'

    # Create a basic task result

# Generated at 2022-06-23 07:45:25.720629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import shutil

    # Create a mock task to run the method against.
    module_args = dict(
        dest='/usr/local',
        src='/home/dude/scripts',
    )

    action_module_instance = ActionModule(ActionModule.Task(dict()), module_args)
    action_module_instance._connection = mock.Mock()

    # Execute method
    try:
        result = action_module_instance.run(tmp='', task_vars=None)
        assert result['failed'] == True
        assert result['msg'] == 'dest is required'
    except Exception as err:
        print('Failed to execute method `run`.')
        raise err

# Generated at 2022-06-23 07:45:37.065834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Run tests for the ActionModule class.
    '''
    # Since we're testing protected members, we must create a subclass of
    # ActionModule.
    class TestActionModule(ActionModule):
        '''
        Subclass of ActionModule used to test protected members.
        '''

        def _execute_module(self, result, module_name, module_args, task_vars, tmp=None):
            '''
            Overridden to just return the result.
            '''
            return result

    # Without module_path, the module fails to initialize as it cannot
    # find the argspec
    module_path = os.path.join(os.getcwd(), 'ansible', 'modules', 'files')
    os.environ['ANSIBLE_LIBRARY'] = module_path

    # Setup mocks to test the

# Generated at 2022-06-23 07:45:47.999424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # unit test for constructor of class ActionModule
    module = 'copy'
    task = dict(action=dict(module=module, args=dict(src='src', dest='dest', remote_src=False, follow=False,
                                                     local_follow=True, directory_mode=None, state='state', delimiter='delimiter',
                                                     backup='backup', force='force', content='content')))
    task_vars = dict(ansible_ssh_pass='ssh_pass', ansible_ssh_user='ssh_user', ansible_ssh_host='ssh_host',
                     ansible_module_name='module_name', ansible_playbook_python='playbook_python')

    shared_loader_obj = DictDataLoader({})
    shared_action_obj = SharedPluginLoaderObj()
    shared_action_

# Generated at 2022-06-23 07:45:54.644129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    tmp = 'fake-tmp'
    source = 'fake-source'
    content = 'fake-content'
    dest = 'fake-dest'
    remote_src = False
    local_follow = True

    action_module = ActionModule(tmp, task_vars, source, content, dest, remote_src, local_follow)
    assert action_module.tmp is tmp
    assert action_module.task_vars is task_vars
    assert action_module.source is source
    assert action_module.content is content
    assert action_module.dest is dest
    assert action_module.remote_src is remote_src
    assert action_module.local_follow is local_follow

# Generated at 2022-06-23 07:46:06.153172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def _execute_module(self, **kwargs):
            pass


# Generated at 2022-06-23 07:46:11.876473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test ActionModule constructor'''
    import ansible.executor.task_queue_manager
    # TEST: create new ActionModule object
    action_module = ActionModule(ansible.executor.task_queue_manager.TaskQueueManager('test_host')._final_q,
                                 '/some/path/to/ansible/', 'test_host', {}, 'test_task')
    assert action_module

# Generated at 2022-06-23 07:46:21.696373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_name_map = {
        'content': 'content',
        'dest': 'dest',
        'recurse': 'recursive',
        'remote_src': 'remote_src',
        'force': 'force',
        'local_follow': 'local_follow',
        'mode': 'mode',
        'follow': 'follow',
        'owner': 'owner',
        'group': 'group',
        'selevel': 'selevel',
        'serole': 'serole',
        'setype': 'setype',
        'seuser': 'seuser',
        'unsafe_writes': 'unsafe_writes',
        'validate': 'validate'
    }

# Generated at 2022-06-23 07:46:30.830049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # parametrize
    param_names = ['tmp', 'task_vars']
    param_values = [
        ['fixtures.file', 'fixtures.tmp'],
        ['fixtures.task_vars']
    ]

    # mock
    mock_task = Mock()
    mock_task._ds = {}
    mock_task._ds['ansible_connection'] = 'local'
    mock_task._ds['ansible_python_interpreter'] = '/usr/bin/python'
    mock_task._ds['ansible_shell_executable'] = '/bin/sh'
    mock_task._ds['ansible_shell_type'] = 'posix'
    mock_task._ds['ansible_user_id'] = 'ansible'

    mock_task.args = {}

# Generated at 2022-06-23 07:46:38.337581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.legacy.files as files
    __loader__ = None; # Used so pyflakes doesn't complain that this isn't used.
    import ansible.modules.legacy.file as file
    import ansible.module_utils.basic as basic_module_utils
    import ansible.module_utils.basic as basic_module_utils
    import ansible.module_utils.basic as basic_module_utils
    import ansible.module_utils.basic as basic_module_utils
    import ansible.module_utils.basic as basic_module_utils
    import ansible.module_utils.connection as connection_module_utils
    import ansible.module_utils.facts.system as system_module_utils
    import ansible.module_utils.facts as facts_module_utils
    import ansible.module_utils.facts

# Generated at 2022-06-23 07:46:50.075253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a connection to simulate the Ansible engine running task
    connection = Connection('192.168.56.1', 'ssh', 'foo', 'bar')
    connection.connect()

    # Create a tmp path for the module for CVE-2019-14846
    tmp = connection._shell.tmpdir
    if os.path.exists(tmp):
        shutil.rmtree(tmp)
    os.mkdir(tmp)

    # Create a action module to run task
    action = ActionModule(connection, 'file', 'foo.yml', dict(), dict())    

    # Create a test file_utils to return mock stat results

# Generated at 2022-06-23 07:46:59.850424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = '/home/test/test.txt'
    dest = '/root/test.txt'
    remote_src = False
    local_follow = True
    task_vars = dict(ansible_check_mode=False)
    source = '/home/test/test.txt'
    content = None

    A = AnsibleActionModule(task=dict(action='copy', args=dict(src=src, dest=dest, remote_src=remote_src, local_follow=local_follow)))
    result = A.run(task_vars=task_vars)

    assert result['failed'] == False
    assert result['invocation']['module_complex_args']['_original_basename'] == 'test.txt'

# Generated at 2022-06-23 07:47:03.666877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up a fake interface to mock out ActionModule.run_command.
    class IncompleteInterface(object):
        pass

    setattr(IncompleteInterface, '_run_command', lambda self, cmd, tmp_path, sudoable=False, executable=None: '')

    # Mock the _loader attribute to avoid errors in a clean unit test.
    ActionModule._loader = DictDataLoader({})
    ActionModule.__dict__['_connection'] = IncompleteInterface()

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
