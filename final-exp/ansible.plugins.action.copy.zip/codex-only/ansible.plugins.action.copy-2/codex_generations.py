

# Generated at 2022-06-23 07:37:15.652852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create and destroy singleton
    SharedPluginLoaderObj()
    SharedPluginLoaderObj.global_instance = None

    # Create an empty task object

# Generated at 2022-06-23 07:37:25.794386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic
    obj = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    obj.exit_json = lambda **kwargs: None
    obj.update_changed_flag = lambda **kwargs: None
    obj.exit_json.return_value = None
    obj.update_changed_flag.return_value = None
    task_vars = dict()
    action_module = ActionModule(
        task=obj,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    rc = action_module.run(None, task_vars)
    assert rc is None



# Generated at 2022-06-23 07:37:33.241866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check the return value of method execute_module is not None
    task_vars = dict()
    tmp = None
    am = ActionModule(task=dict(args=dict(dest="/home/ansible/file", content="content", remote_src=False,
                                          state="present", mode=None, original_basename=None, follow="no", local_follow="yes",
                                          checksum=None)), tmp=tmp, task_vars=task_vars)
    assert am.run(tmp, task_vars) is not None
    # Check the return value of method _execute_module is not None
    task_vars = dict()
    tmp = None

# Generated at 2022-06-23 07:37:43.596297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a loader object and then serialize it to a dict
    my_loader = DataLoader()
    tmp = my_loader.serialize()
    # Get the module_name
    module_name = 'copy'
    # Create a TaskExecutor object and then serialize the dict to retreive the module_name
    my_task = TaskExecutor('TaskExecutor', dict(), tmp)
    my_task.serialize = lambda: {'name': module_name}
    # Get the arguments for this module
    args = dict(src='/foo/bar/baz', dest='/baz/blah/foo')
    # Create the ActionModule object
    action_module = ActionModule(my_task, args, tmp)
    # Create the Connection object and then serialize the dict to retreive the connection attributes
    my_conn = Connection

# Generated at 2022-06-23 07:37:45.387323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTest(ActionModule):
        pass

    return ActionModuleTest

# Generated at 2022-06-23 07:37:51.582100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule with tmp set to default
    action_module = ActionModule({"src": "src"})
    res = action_module.run()

    assert isinstance(res, dict)
    assert "failed" in res["invocation"]
    assert res["invocation"]["failed"]
    assert "msg" in res["invocation"]
    assert res["invocation"]["msg"] == "dest is required"



# Generated at 2022-06-23 07:37:53.987357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' action_plugins/copy.py:TestActionModule() '''
    assert ActionModule is not None

# Generated at 2022-06-23 07:38:06.204894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    setup_loader()
    my_task = dict(action=dict(module='copy', args=dict(src='/etc/hosts', dest='/tmp/test')))
    my_task_ds = dict(action=dict(module='copy', args=dict(src='/etc/hosts', dest='/tmp/test', delegate_to='localhost')))
    my_task_delegate = dict(action=dict(module='copy', args=dict(src='/etc/hosts', dest='/tmp/test', delegate_to='localhost', delegate_facts=True)))
    my_task_ds_list = dict(action=dict(module='copy', args=dict(src='/etc/hosts', dest='/tmp/test', delegate_to=['localhost', 'otherhost'])))
    my_task_ds_list_bad = dict

# Generated at 2022-06-23 07:38:11.491786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Connection(1)
    module_loader = DictDataLoader({})
    task = Task()
    task.args = {'content': """some test content""", 'dest': '/test/content'}
    action = ActionModule(connection=connection, task=task, templar=task.templar, data=task.args, shared_loader_obj=module_loader)
    assert action.action_loader is not None
    assert action._task == task


# Generated at 2022-06-23 07:38:21.866130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if os.getenv('ANSIBLE_TEST_FILE_MODULE', False) != 'unit':
        raise SkipTest('Skipping')

    from ansible.executor.task_result import TaskResult

    from ansible.plugins.action.copy import ActionModule
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()
    module_name = 'ansible.legacy.copy'

    task_name = 'test_task'
    args = {'src': 'src', 'dest': 'dest'}
    action_args = {'task': task_name, 'args': args}
    action_args_with_defaults = action_args.copy()
    action_args_with_defaults['args']['remote_src'] = False
    action_args

# Generated at 2022-06-23 07:38:29.319492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # default constructor
    try:
        am = ActionModule()
    except Exception as e:
        assert False, "ActionModule() raised Exception: %s" % to_native(e)

    # explicit constructor
    try:
        am = ActionModule(task=dict(), connection=paramiko.SSHClient(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    except Exception as e:
        assert False, "ActionModule() raised Exception: %s" % to_native(e)


# Generated at 2022-06-23 07:38:41.630545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.files.synchronize import ActionModule as am
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleVarsUnsafeProxy
    import json
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import platform
    import textwrap

    # Initialize a AnsibleVarsUnsafeProxy instance
    task_vars = dict()
    task_vars['ansible_all_ipv4_addresses'] = [u'172.17.0.2', u'172.17.0.3']

# Generated at 2022-06-23 07:38:55.293294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    inject = {}
    action_module = ActionModule({'name': 'name', 'args': {'src': 'src', 'dest': 'dest'}}, inject)
    action_module._connection = Connection({})
    action_module._loader = DataLoader()
    action_module._task_vars = {'ansible_check_mode': False}

    def remote_expand_user(ass):
        return ass

    action_module._remote_expand_user = remote_expand_user

    def _remove_tmp_path(ass):
        pass

    action_module._remove_tmp_path = _remove_tmp_path
    # Test
    assert action_module.run() == {'result': 'result'}

    # Setup test
    inject = {}

# Generated at 2022-06-23 07:39:05.639554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import time, tempfile, shutil, os
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.action.copy import ActionModule


# Generated at 2022-06-23 07:39:15.490043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Purpose: test run of ActionModule
    Steps:
    1. create a ActionModule object
    2. execute the run method of ActionModule.
    """
    from ansible.plugins.action import ActionModule
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ansible_collections_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '../test/test_collections')
    inventory_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '../test/test_inventory')

   

# Generated at 2022-06-23 07:39:18.745778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with all parms provided, no user, no password
    module = ActionModule({})
    assert module != None



# Generated at 2022-06-23 07:39:24.464511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' action_plugins.copy.Test (constructor) '''

    # Make an instance of ActionModule without args
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None
    )

    # Verify action_module was created
    assert action_module is not None

# Generated at 2022-06-23 07:39:25.160736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 07:39:29.683019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class DummyConnection(object):
        transport = 'local'

        def _shell_quote(self, s):
            return u"'%s'" % s.replace("'", "\\'")

        def _shell_rewrite_args(self, s):
            return s.replace("'", "\\'")

        def join_path(self, *parts):
            return '/'.join(parts)

        def getcwd(self):
            return b'.'

        def expand_user(self, path):
            # skip expansion if it already looks like an absolute path
            if path.startswith("/") or path.startswith("~"):
                return path
            return '~/' + path

        def path_has_trailing_slash(self, path):
            return path.rstrip().endswith('/')

# Generated at 2022-06-23 07:39:33.362338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = AnsibleActionModule(object, object, task_vars=dict(), loader=AnsibleLoader())
    assert isinstance(action_module.run(), dict)


# Generated at 2022-06-23 07:39:41.398676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    acm = AnsibleCoreMeta()
    p = module_common.ModuleCommon()

    return_data = dict(
        failed=False,
        changed=False,
        msg='',
        dest='/opt/test'
    )
    action_module = ActionModule(acm, p)
    result = action_module.run()
    assert result.keys() == return_data.keys()

    return_data = dict(
        failed=True,
        changed=False,
        msg='src (or content) is required'
    )
    action_module = ActionModule(acm, p)
    task_args = dict(
        dest='/opt/test'
    )
    action_module._task.args = task_args
    result = action_module.run()

# Generated at 2022-06-23 07:39:51.306174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_server = None
    test_module = None
    test_task = None
    test_loader = None
    test_variable_manager = None
    test_connection = None
    test_play_context = None

    test_connection = MagicMock(name="fake_connection")
    test_loader = MagicMock(name="fake_loader")
    test_variable_manager = MagicMock(name="fake_variable_manager")
    test_play_context = MagicMock(name="fake_play_context")
    test_play_context.check_mode = False
    test_play_context.become = False
    test_play_context.become_method = False
    test_play_context.become_user = False
    test_play_context.no_log = False
    test_play_context.password

# Generated at 2022-06-23 07:40:00.951691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a host with a fake connection
    host = MagicMock(name='host', spec=('connection',))
    host.name = 'localhost'
    host.connection = MagicMock()
    host.connection.path_has_trailing_slash.return_value = False

    # create a task with a fake TaskExecutor
    task = MagicMock(name='task', spec=('args', 'executor'))
    task.args = dict()
    task.executor = MagicMock(name='executor', spec=('hostvars', 'get_vars', 'get_variables', 'get_low_level_connection', 'get_loader'))
    task.executor.get_loader.return_value.load_from_file.return_value = dict(lookup_plugin='test')
    task.executor

# Generated at 2022-06-23 07:40:02.122471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 07:40:04.011522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict(task_uuid='uuid', task_vars={}), None)

# Generated at 2022-06-23 07:40:11.904939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        Action(
            {
                'operation': 'PUT',
                'src': '/tmp/src.txt',
                'dest': '/tmp/dest.txt',
                'content': '',
                'flat': True,
                'mode': None,
                'original_basename': None,
                'remote_src': None,
                'remote_user': None,
                'validate': None,
                'unsafe_writes': False
            }
        ),
        None,
        None,
        None,
        None
    )

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:40:12.636797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:40:16.377640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Allocate arbitrary values for all arguments.
    tmp = 'TestString'
    task_vars = {'a': 'TestString', 'b': 'TestString'}
    # Invoke method
    result = ActionModule.run(tmp, task_vars)
    # Tests
    assert(result == '')

# Generated at 2022-06-23 07:40:26.668748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='copy', args=dict(src='/path/to/src', dest='/path/to/dest',
                                                     follow=False, recurse=False)),
                registered=dict(files='/path/to/files'))
    task_vars = dict()
    connection = FakeConnection(shell=FakeShell(os='posix'))
    connection._shell.tmpdir = '/tmp'

    action = ActionModule(task, connection, task_vars=task_vars, loader=DictDataLoader())
    assert action.connection is connection

    # test the constructor got shell and tmpdir right
    assert action._tmp_path == '/tmp'

    # test the constructor loaded the files dict
    assert action._task_vars['files'] == '/path/to/files'

    # test correct module

# Generated at 2022-06-23 07:40:35.744219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.plugins import connection_loader
  from ansible.plugins import module_loader
  from ansible.plugins.loader import module_loader
  from ansible.utils import context_objects as co
  c_shell = connection_loader.get('local', class_only=True)()
  m_shell = module_loader.get('command', class_only=True)
  # This is wrong because it totally skips action_plugins.py
  #from ansible.playbook.task_include import TaskInclude
  #from ansible.playbook.task import Task
  #from ansible.playbook.play_context import PlayContext
  #from ansible.playbook.role.include import RoleInclude
  #from ansible.playbook.handler_task_include import HandlerTaskInclude
  #from ansible.vars import VariableManager

# Generated at 2022-06-23 07:40:46.560450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define and setup module
    module = AnsibleActionModule('action_type', 'default', {'src': 'file.txt', 'dest': 'file.txt'},
    AnsibleConnection('test_host'), AnsibleTask('test_task'), AnsibleTaskVars())
    module.supports_check_mode = True

    # Add tb_fixture return value to AnsibleActionModule class

# Generated at 2022-06-23 07:40:51.884010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    constructor test
    '''
    # Create an instance of ActionModule
    module = ActionModule()
    # If a string is passed we just assign it to _task.name
    assert module._task.name == 'copy'
    # If a dict is passed we assign _task.name and task_vars
    task_vars = dict()
    module = ActionModule(task_vars=task_vars)
    assert module._task.name == 'copy'



# Generated at 2022-06-23 07:41:00.841467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None, '127.0.0.1', {}), ActionModule)
    assert isinstance(ActionModule(None, None, '127.0.0.1', {'connection': 'smart'}), ActionModule)
    assert isinstance(ActionModule(None, None, '127.0.0.1', {'connection': 'paramiko'}), ActionModule)
    assert isinstance(ActionModule(None, None, '127.0.0.1', {'connection': 'ssh'}), ActionModule)

# Generated at 2022-06-23 07:41:11.418359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(remote_src='yes',
                src='/tmp/foo',
                dest='/tmp/bar',
                original_basename='foo',
                module_name='file')
    action_module = ActionModule(dict(action='copy'), args, load_callback_module=None, connection_info=dict())
    assert action_module._connection.connection._shell.tmpdir == os.path.expanduser('~/.ansible/tmp')

    args = dict(remote_src='yes',
                src='/tmp/foo',
                dest='/tmp/bar',
                original_basename='foo',
                module_name='file',
                _ansible_tmpdir='/tmp/something')

# Generated at 2022-06-23 07:41:12.881039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._uses_shell is False


# Generated at 2022-06-23 07:41:17.259204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert am is not None


# Generated at 2022-06-23 07:41:20.897519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-23 07:41:25.602355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = "~/downloads/test.txt"
    content = "Hi"
    dest = "~/downloads/test2.txt"
    result = None
    result = ActionModule.run(source, content, dest)
    assert result is not None


# Generated at 2022-06-23 07:41:35.115032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    # Test __init__
    assert module is not None

    # Test _validate_tmp_path
    module._validate_tmp_path('/tmp')

    # Test _trailing_slash_or_backslash
    assert module._trailing_slash_or_backslash('a/b/c')
    assert not module._trailing_slash_or_backslash('a/b/c/')
    # Test with backslash
    assert module._trailing_slash_or_backslash('a\\b\\c')
    assert not module._trailing_slash_or_backslash('a\\b\\c\\')


# Generated at 2022-06-23 07:41:48.236604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_class = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(src='src', 
            dest='dest', 
            content='content', 
            tmp='tmp', 
            task_vars=dict(a='a', 
                b='b'))))

    my_class._task_vars = dict(c='c', 
            d='d')
    my_class._loader = Mock(**{'get_basedir.return_value': 'basedir', 
            'path_dwim.return_value': 'path_dwim', 
            'cleanup_tmp_file.side_effect': lambda x: x})
    my_class._remove_tmp_path = Mock(name='_remove_tmp_path')

# Generated at 2022-06-23 07:41:49.640718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    pass




# Generated at 2022-06-23 07:42:02.177841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager as InventoryManager_module
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.executor.task_queue_manager import TaskQueueManager
    # context and task are not used, but these are set to build an instance of ActionModule
    context = dict()
    task = Task()
    # Setting this action_module as a module of type FIle
    task.args = dict(dest = "/home/ahmed/Desktop/file.yml")
    # Set the connection to local

# Generated at 2022-06-23 07:42:07.719955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure constructor works with no arguments.
    action = ActionModule()
    assert action is not None

    # Make sure constructor works with an argument.
    action = ActionModule(None)
    assert action is not None

# Unit test walk_dirs()

# Generated at 2022-06-23 07:42:17.986482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    chmod_mock = MagicMock()
    def ut_check_executing_module(module_name, module_args, task_vars):
        module_return = {}
        if 'content' in module_args:
            module_return['changed'] = True
        else:
            module_return['changed'] = False
        if 'ansible.legacy.copy' in module_name:
            module_args['src'] = module_args['dest']
        elif 'ansible.legacy.file' in module_name:
            module_return['path'] = module_args['dest']
        return module_return
    def ut_remote_expand_user(path):
        return path
    def ut_find_needle(dirname, filename):
        if dirname == 'files': return filename
        raise AnsibleError

# Generated at 2022-06-23 07:42:26.661472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_module_args(dict(
            src='/etc/passwd',
            dest='/tmp',
            checksum='sha1:a3491e8bca4502b5d09f5aacd8b835e7a72d9a3e',
            follow=True,
            content="foo"))

    # BUG: `args` and `set_module_args` will try to access `_task`, which
    # is not set up yet.
    saved_task = copy.deepcopy(ActionModule._task)
    ActionModule._task = None

    module = ActionModule()
    module.run()
    module._remove_tmp_path()

    ActionModule._task = saved_task

# Generated at 2022-06-23 07:42:35.013974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Use a mock class to test the method
    class Connection:
        def __init__(self):
            pass
        def _shell_expand_user(self, path):
            return path
        def _shell_expand_path(self, path):
            return path
    class ShellParser:
        def __init__(self):
            pass
        def get_remote_filename(self, path):
            return path
        def path_has_trailing_slash(self, path):
            return path.endswith("/")
        def join_path(self, path1, path2):
            return path1 + path2
    class Task:
        def __init__(self):
            pass

# Generated at 2022-06-23 07:42:39.880900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Connection()
    module_loader = DictDataLoader({'test': { 'test.py': """
- hosts: localhost
  tasks:
    - name: action module test
      copy: src=test dest=test
    """}})
    mock_inventory = create_mock_inventory(
        [
            Host(name='localhost',
                    port=22,
                    variables=dict(ansible_connection='ssh', ansible_user='user'))
        ],
        loader=DictDataLoader({}))

    def get_hosts(pattern):
        return mock_inventory.get_hosts(pattern)

    task = Task(
        name='test',
        get_hosts=get_hosts,
        loader=module_loader,
        connection=connection
    )

# Generated at 2022-06-23 07:42:50.951005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test environment
    self = ansible.utils.unsafe_proxy.AnsibleUnsafeProxy({})
    tmp = None
    task_vars = dict()

    # Test call - no dest
    result = self.run(tmp, task_vars)
    assert result.keys() == ['failed', 'exception', 'msg']
    assert result['failed'] == True
    assert result['msg'] == 'dest is required'

    # Test call - no src or content
    self._task.args = {'dest': 'dest'}
    result = self.run(tmp, task_vars)
    assert result.keys() == ['failed', 'exception', 'msg']
    assert result['failed'] == True
    assert result['msg'] == 'src (or content) is required'

    # Test call - content and src


# Generated at 2022-06-23 07:43:02.161138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    # initialize needed objects
    context = PlayContext()
    inventory = InventoryManager(loader=None, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    variable_manager._extra_vars = combine_vars(variable_manager._extra_vars, loader=loader)

    # create a task, which will be used to test execution of copy module
    task = Task()
    task.action = 'copy'

# Generated at 2022-06-23 07:43:11.896523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase, ActionModule
    from ansible.plugins.action.copy import ActionModule as ActionModule_copy
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.process import AnsibleProcess
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.text.converters import to_

# Generated at 2022-06-23 07:43:14.588279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod = ActionModule()
    task_vars = {}
    action_mod.run(task_vars)
    pass

# Generated at 2022-06-23 07:43:24.765040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This seems to be the only way to pass in module_utils from the outside.
    setattr(action.ActionModule, '_module_utils', module_utils)

    # Stub the connection class
    class Connection():
        ''' connection stub class '''
        def __init__(self):
            ''' init for connection class '''
            self._shell = 'posix'
            self._shell_type = 'posix'

    # Create a dummy task to pass in.
    task = dict(
        action=dict(
            module_utils='ansible.module_utils.basic'
        )
    )

    # Create the action module.

# Generated at 2022-06-23 07:43:35.558429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_task_run_copy_module_action_module = {u'action': u'ansible.actions.copy', u'_ansible_no_log': False, u'_raw_params': u'content=\'{\'aaa\': \'bbb\'}\' dest=/home/test', u'_ansible_module_name': u'copy', u'dest': u'/home/test/test.json', u'_ansible_module_post_mortem': False, u'_ansible_verbose_always': True, u'_ansible_version': u'2.1.1.0', u'_ansible_module_name': u'copy', u'content': u'{\'aaa\': \'bbb\'}'}
    ansible_task_run_copy_module_action_module_return_dict = {}


# Generated at 2022-06-23 07:43:40.461550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' constructor for class ActionModule '''

    # Create a mock connection and module
    connection = Connection(None)
    m_module = MagicMock(spec=ActionModule, connection=connection)

    # Construct and return
    res = ActionModule.__new__(ActionModule)
    res.__dict__ = m_module.__dict__
    return res

# Generated at 2022-06-23 07:43:46.227284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # AnsibleModule = Ansible.module_utils.ansible_module_get
    # AnsibleModule = AnsibleModule(argument_spec={'a':{'type':'int','required':True,'default':42},'b':{'type':'str','default':'twenty-three'}})
    # ModuleReturn = AnsibleModule.exit_json(changed=True,meta={'c':'hello'})
    # ModuleReturn = AnsibleModule.fail_json(msg='something went wrong')
    return NotImplementedError()


# Generated at 2022-06-23 07:43:58.154999
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialize the test environment
    test_spec = dict(
        dest="/home/ansible/test.txt",
        src="/home/ansible/sample.txt")

# Generated at 2022-06-23 07:43:59.155431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-23 07:44:07.442286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_module = ActionModule()
    assert hasattr(fake_module, '_execute_module')
    assert hasattr(fake_module, '_remove_tmp_path')
    assert hasattr(fake_module, '_remote_expand_user')
    assert hasattr(fake_module, 'run')


# Generated at 2022-06-23 07:44:11.855181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(str(action_module))
    assert action_module is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-23 07:44:18.574468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import playbook
    from ansible import inventory

    host = inventory.Host(name="test")
    task = playbook.Task()
    task.args = {}
    conn = connection_loader.get('local', task, None)
    am = ActionModule(task, conn, '/tmp')
    assert am.task_vars == {}
    assert am._task.args == {}
    assert am._listen_to_stdin == False
    assert am._task_vars == {}
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None
    assert am._connection == conn
    assert am._play_context == None
    assert am._loaded_fragments == {}
    assert am._task._role == None
    assert am._task._block == None

# Generated at 2022-06-23 07:44:29.405508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    action_plugins/copy.py ActionModule Unit Test
    """
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory_manager)
    localhost = inventory_manager.get_host('localhost')

    task = Task()
    task.set_loader(loader)
    task._variable_manager = variable_manager

    play_context = PlayContext()
    play_context.network_os = 'Default'


# Generated at 2022-06-23 07:44:30.607718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create new ActionModule object
    am = ActionModule()

# Generated at 2022-06-23 07:44:41.732205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source = 'test/fixtures/ansible_test_file'
    fake_task = dict(
        action=dict(
            module_args=dict(
                src=source,
                dest='/home/foo'
            ),
            module_name='copy'
        )
    )
    mock_connection = MockConnection()
    action_module = ActionModule(mock_connection, fake_task, 'home/foo')
    assert action_module._connection.name == 'mock'
    # test _bz2_read_into_data
    source2 = 'test/fixtures/ansible_test_file_bz2'
    action_module._task.args.update(dict(src=source2))
    data = action_module._bz2_read_into_data()

# Generated at 2022-06-23 07:44:43.557875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = AnsibleActionModule()
    print(a.run())



# Generated at 2022-06-23 07:44:44.794659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    myModule = ActionModule()
    myModule.ActionBase()


# Generated at 2022-06-23 07:45:01.120034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the class instance
    action_module_instance = AnsibleActionModule()
    action_module_instance.action = 'copy'
    action_module_instance.action_loader = ActionModuleLoader()
    action_module_instance._task = Task()
    action_module_instance._task.args['src'] = 'test'
    action_module_instance._task.args['dest'] = 'test'
    action_module_instance._task.args['content'] = 'test'
    action_module_instance._connection = ConnectionBase()
    action_module_instance._loader = DataLoader()
    action_module_instance._templar = Templar(loader=action_module_instance._loader)
    action_module_instance.set_action_options(action_options='test')
    action_module_instance.set_action_vars

# Generated at 2022-06-23 07:45:05.905679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(LoadedTask(Task(), connection=None), DataLoader(), None, None)
    assert action_module._templar is not None
    assert action_module._loader is not None

# Generated at 2022-06-23 07:45:10.722972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({})
    assert isinstance(action, ActionModule)
    assert isinstance(action, base.ActionBase)
    # assert action.module == 'copy'


# Generated at 2022-06-23 07:45:14.791426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        {'src': 'src', 'dest': 'dest', 'action': 'action', 'content': 'content'},
        {'path': {'backend': 'local'}, 'inventory_hostname': 'inventory_hostname'}
    )
    module.run()

# Generated at 2022-06-23 07:45:17.446280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict())
    assert isinstance(action_module, object)


# Generated at 2022-06-23 07:45:19.776363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert type(action) == ActionModule

# Generated at 2022-06-23 07:45:29.673760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate test object
    am = ActionModule()
    # instantiate mock for class AnsibleConnection
    ac = MockAnsibleConnection()
    # instantiate mock for class ShellModule
    sm = MockShellModule()
    # instantiate mock for class Task
    t = MockTask()
    # set attribute _shell for class ActionModule
    am._shell = sm
    # set attribute host for class AnsibleConnection
    ac.host = t.host
    # set attribute _connection for class ActionModule
    am._connection = ac
    # set attribute _task for class ActionModule
    am._task = t
    # set variable tmp
    tmp = None
    # set variable task_vars
    task_vars = {}
    # call method run of class ActionModule with args tmp and task_vars

# Generated at 2022-06-23 07:45:32.893197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._connection = MockConnection()
    action_module._task = MockTask()
    action_module._task.args = {}
    # Execute
    result = action_module.run()
    # Verify
    # FIXME: Any way to avoid these nested list comprehensions below?
    assert_equal(result,
        {'failed': True,
         'msg': 'src and dest are required'})

# Generated at 2022-06-23 07:45:38.373029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.text.text import to_text
    from ansible.utils.path import unfrackpath
    # RemovedInAnsible25Warning:
    import ansible.plugins.action.copy as action_copy
    import tempfile
    try:
        import collections.abc as collections_abc
    except ImportError:
        import collections as collections_abc
    import distutils
    import distutils.errors
    import distutils.spawn
    import errno
    import functools
    import json
    import multiprocessing
    import os
    import pyclbr
    import shutil
    import subprocess
    import sys
    import threading

# Generated at 2022-06-23 07:45:49.493789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible = Ansible()
    ansible.get_module_class = MagicMock(return_value=MyModule)
    ansible._module_loaders = [AnsibleLoader(os.path.join(os.path.dirname(__file__), 'fixtures', 'test_module_utils/legacy_modules/'))]
    ansible._is_task_module = True
    ansible._is_role_module = True
    ansible._is_action_module = True
    ansible.recursively_find_files = MagicMock(return_value=['/tmp/foo.txt'])
    ansible._connection_plugin_paths = [os.path.join(os.path.dirname(__file__), 'fixtures', 'plugins')]
    ansible._task = Task()
    ansible._

# Generated at 2022-06-23 07:46:00.779530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """test ActionModule.run"""
    task = mock.MagicMock(spec=Task)
    action_module = ActionModule(task, {})

    # Test copy with src = None, content = None
    task.args = {"src": None, "dest": "dest", "content": None}
    result = action_module.run({}, {})
    assert result is not None
    assert result.get("failed") == True

    # Test copy with src = None
    task.args = {"src": None, "dest": "dest"}
    result = action_module.run({}, {})
    assert result is not None
    assert result.get("failed") == True

    # Test copy with src = valid file
    task.args = {"src": "/tmp/file/src", "dest": "dest"}

# Generated at 2022-06-23 07:46:11.876589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = "test"
    follow = False
    source = "test"
    task_vars = dict(
        ansible_check_mode=True
    )
    content_tempfile = None

    # create an instance of the class
    action = ActionModule()
    action._task.args = {
        'dest': dest,
        'src': source,
        'follow': follow,
        'ansible_check_mode': True
    }

    # test the run method
    result = action.run(action, task_vars=task_vars)

    # check if the expected result is present in the returned result
    assert result['changed'] == True


# Generated at 2022-06-23 07:46:14.755780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For now, just hardcode input and expected output
    # TODO: enable unit tests for copy module
    pass

# Generated at 2022-06-23 07:46:19.217488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Unit tests for class ActionModule



# Generated at 2022-06-23 07:46:25.123809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = MagicMock()
    host.get_name.return_value = '127.0.0.1'
    task = MagicMock()
    task.args = dict()
    task.no_log = False
    connection = MagicMock()
    tmp = MagicMock()

    c = ActionModule(task, connection, tmp)
    c.run(tmp, {'hostvars':{}})

# Generated at 2022-06-23 07:46:35.100929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test requires a working copy of ansible-python2.7 and 2.6 in the same directory as this file.
    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager
    except ImportError:
        print(str(sys.exc_info()[1]))
        print("Unable to import ansible.  This test is skipped")
        return
    # Arrange
    loader = DataLoader()
    inv_obj = InventoryManager(loader=loader,
                             sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inv_obj)

   

# Generated at 2022-06-23 07:46:46.537223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    module_name = "ansible.legacy.copy"
    action_plugin = copy.ActionModule(action=module_name, task=None)
    action_plugin._display.verbosity = 2

    # Mock
    mock_play_context = MagicMock()
    action_plugin._play_context = mock_play_context

    mock_task = MagicMock()
    action_plugin._task = mock_task

    mock_copy_file = MagicMock(return_value=dict(changed=False))
    action_plugin._copy_file = mock_copy_file

    mock_execute_module = MagicMock(return_value=dict(changed=False))
    action_plugin._execute_module = mock_execute_module

    mock_remote_expand_user = MagicMock(return_value='ads')


# Generated at 2022-06-23 07:46:53.254751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='test', module_args=dict(test_arg=3))),
        connection=dict(module_name='test', module_args=dict(test_conn=4)),
        play_context=dict(become=False, diff=False, become_method='test')
    )


# Generated at 2022-06-23 07:46:59.038690
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:47:09.207533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create testing environment
    import ansible.plugins.action
    m = ansible.plugins.action.ActionModule(
        task=dict(action=dict(module_name='copy', module_args=dict(src='src', dest='dest'))),
        connection='connection',
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    # Check values
    assert (m._task_vars == dict())
    assert (m._loader is None)
    assert (m._connection is None)
    assert (m._play_context is None)
    assert (m._templar is None)
    assert (m._templar_args is None)
    assert (m._shared_loader_obj is None)