

# Generated at 2022-06-23 07:37:08.239728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a class instance
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-23 07:37:15.198414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a class object
    action_module = ActionModule()
    # Create a local var
    tmp = ""
    # Create a local var
    task_vars = dict()
    # Create a local var
    result = dict()
    # Create a local var
    assert action_module is not None
    # Call method run of class ActionModule
    assert result == action_module.run(tmp=tmp, task_vars=task_vars)


# Generated at 2022-06-23 07:37:17.788752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test class constructor to ensure that it sets up the object properly '''

    action_module = ActionModule(dict(action='test', dest='test'))



# Generated at 2022-06-23 07:37:27.248507
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    m = mock.mock_open()

    # The mocked object returned by mock_open
    handle = m()

    # The value returned by read()
    handle.read.return_value = 'value read'

    # The value returned by write()
    handle.write.return_value = 'value written'

    # The value returned by seek()
    handle.seek.return_value = 'value seek'

    # The value returned by truncate()
    handle.truncate.return_value = 'value truncate'

    # The action to test
    action = ActionModule(mock.Mock())

    # Mock the connection
    connection = mock.MagicMock()
    connection.get_option.return_value = True
    connection.host = 'localhost'
    action._connection = connection

    # Mock the loader


# Generated at 2022-06-23 07:37:30.295668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 07:37:41.750783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test requires a mocked environment to work in

    # Setup test environment
    import tempfile as tempfile_mod
    tempfile_mod.mkdtemp = lambda *args, **kwargs: "test-tempdir"
    import ansible.plugins.action.copy as copy_mod
    orig_run_command = copy_mod.ActionModule.run_command
    copy_mod.ActionModule.run_command = lambda *args, **kwargs: "test_command_result"
    orig_glob = copy_mod.glob
    copy_mod.glob = lambda *args, **kwargs: "test_glob"
    orig_ActionModule___init__ = copy_mod.ActionModule.__init__
    copy_mod.ActionModule.__init__ = lambda self, *args, **kwargs: None

# Generated at 2022-06-23 07:37:53.969834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'copy'
    fake_loader = DictDataLoader({'template/foo.j2': '{%s}' % C.DEFAULT_JINJA2_SYNTAX})
    task_vars = dict(
        inventory=dict(
            hostvars=dict(
                fake_host=dict(),
            )
        ),
    )
    templar = Templar(loader=fake_loader, variables=task_vars)
    connection = Connection(None)
    tmp = connection._shell.tmpdir
    am = ActionModule(connection=connection, task_vars=task_vars,
                      loader=fake_loader, templar=templar, shared_loader_obj=None)
    assert am.task_vars == task_vars
    assert am.connection == connection
    assert am

# Generated at 2022-06-23 07:37:56.716818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._copy_cached_file_if_exists() == None
    assert action_module._execute_remote_stat() == None
    assert action_module._execute_module() == None
    assert action_module._remove_tempfile_if_content_defined() == None
    assert action_module.run() == None

# Generated at 2022-06-23 07:38:01.801952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = Task(True, load_subset='test')
    task._ds = {'test_var': 'test_value'}
    module_args = dict(content='test', dest='test')
    set_module_args(module_args)

    assert isinstance(ansible_module, ActionModule)
    assert ansible_module._task == task
    assert ansible_module._connection is None
    assert ansible_module._shell is None
    assert ansible_module._loader is None
    assert ansible_module._templar is None
    assert ansible_module._needs_tmp_path is True
    assert ansible_module._task.vars is not None
    assert ansible_module._task.args == dict(content='test', dest='test')
    assert ansible_module._tmp is not None
    assert ans

# Generated at 2022-06-23 07:38:08.204566
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule({'test_key': {'test_arg1': 'test_value1'}})
    assert action._task.action == 'test_key'
    assert action._task.args == {'test_arg1': 'test_value1'}

    # Make sure that no error is thrown for `undefined` when argument is mandatory
    assert action._task.args.get('private', 'undefined') == 'undefined'
    assert action._task.args.get('private', None) == None



# Generated at 2022-06-23 07:38:16.985534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors, utils
    from ansible.plugins.action import ActionBase
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import to_unicode as to_unicode_unsafe
    from ansible.utils.unsafe_proxy import to_bytes
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # Unit test for method run of class ActionModule

    # Check if attribute _remove_tmp_path of object_ActionModule is callable
    assert callable(getattr(ActionModule, "_remove_tmp_path", None))

    # Check if attribute _find_needle of object_ActionModule is callable
    assert callable(getattr(ActionModule, "_find_needle", None))

    # Check if attribute _copy_file

# Generated at 2022-06-23 07:38:17.674389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:38:25.364795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init mocks
    config._connection_cache = dict()
    config._variable_manager = VariableManager()
    config._variable_manager._fact_cache = dict()
    config._variable_manager._fact_cache_time = 0
    config._variable_manager.set_inventory(Inventory(host_list=['localhost']))
    config.loader = DictDataLoader({
        "localhost": {
            "vars": {}
        }
    })

    action = ActionModule(task={'args': {'foo': 'bar'}}, connection=dict(host='localhost'), play_context=dict(), loader=DictDataLoader({}), templar=Templar(), shared_loader_obj=None)
    action._loader.set_basedir('/')
    action._remove_tmp_path = Mock()
    action._execute_

# Generated at 2022-06-23 07:38:33.571707
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create a task object to run
    task = Task()
    task.args = dict(src='/etc/passwd', dest='/tmp/passwd')
    task.action = 'file'

    # Create a play context object to run
    play_context = PlayContext()

    # Create a connection object to run
    connection = Connection(play_context)

    # Create our action module instance to test
    action_module = ActionModule(task, connection, play_context)

    # Assert constructor of class
    assert hasattr(action_module, '_task')
    assert hasattr(action_module, '_connection')
    assert hasattr(action_module, '_play_context')


# Generated at 2022-06-23 07:38:41.723744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    module_name = 'testmod'
    task = Task()
    task._role = None
    task._ds = None
    task.args = dict()

    play_context = PlayContext()
    play_context.check_mode = False
    task._play_context = play_context

    am = ActionModule(task, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)
    assert am

# Generated at 2022-06-23 07:38:43.454161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_class = ActionModule()
    assert(type(my_class) == ActionModule)


# Generated at 2022-06-23 07:38:50.182496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = DummyTask()
    _connection = DummyConnection()

    _connection._shell = DummyShell()
    _task.args = dict(
        content='{"test": "test"}',
        dest='/tmp/dest',
        follow=True,
        remote_src=True,
        src='/tmp/src',
    )
    _task.action = 'copy'
    _task.name = 'copy test'

    _action = ActionModule(_task, _connection)
    assert _action.run() == dict(
        dest='/tmp/dest',
        src='/tmp/src',
        changed=False,
    )

    _connection._shell.command_successful = False

# Generated at 2022-06-23 07:38:50.888901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   pass

# Generated at 2022-06-23 07:39:01.372555
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:39:04.504045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO:  Do we really need a test for this?
    ActionModule(create_task('dummy', dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 07:39:13.091677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This method is for unit testing run method of ActionModule class
    """
    # Dummy variables
    protocol = "ssh"
    ansible_host = "ansible_host"
    ansible_port = "ansible_port"
    connection_host = "connection_host"
    connection_port = "connection_port"
    ansible_user = "ansible_user"
    ansible_password = "ansible_password"
    ansible_ssh_private_key_file = "ansible_ssh_private_key_file"
    ansible_become = "ansible_become"
    ansible_become_method = "ansible_become_method"
    ansible_become_user = "ansible_become_user"

# Generated at 2022-06-23 07:39:18.652550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mocker = Mocker()
    mock_task = create_ansible_mock(mocker)
    mock_task._role = create_ansible_mock(mocker)
    mock_task._role.get_role_path = lambda:None
    ActionModule(mock_task)

# Generated at 2022-06-23 07:39:29.110740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test copied from former test_action_copy.py
    # Example action context (few things populated)
    # FIXME: try to use actual ActionContext instead of dict
    action_ctx = dict()
    action_ctx['task_vars'] = dict(
        ansible_check_mode=False,
        _original_file=dict(name='original_filename.txt')
    )

    # Example module args
    module_args = dict(
        content='hello, world!',
        dest='new_filename.txt',
        checksum='sha1:61a7b37044635fe9cd9d6e8d55562a3a4a277e67'
    )

    # Example task context
    task_ctx = dict()
    task_ctx['register'] = 'f1_result'

    # Inherit from Action

# Generated at 2022-06-23 07:39:37.560505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import types
    import tempfile
    import os
    import shutil

    from ansible.plugins.action.copy import ActionModule as CopyModule
    from ansible.plugins.action.template import ActionModule as TemplateModule
    from ansible.plugins.loader import find_plugin
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.playbook.task import Task

# Generated at 2022-06-23 07:39:48.156476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task(object):
        args = dict()

    class Connection(object):
        pass

    connection = Connection
    task = Task

    test_mod = ActionModule(connection, task, "/this/is/a/path")

    assert test_mod.connection is connection
    assert test_mod._task.args == task.args
    assert test_mod._task.args is task.args
    assert test_mod._loader is None
    assert test_mod._templar is None
    assert test_mod._shared_loader_obj is None
    assert test_mod._connection is connection
    assert test_mod._diff is True
    assert test_mod._task is task
    assert test_mod._shell is None

# Unit tests for constructor of ActionModule

# Generated at 2022-06-23 07:39:58.946088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.utils.path import unfrackpath
    import traceback


    module_args = dict(
        content=json.dumps({'key1': 'value1', 'key2': 2}),
        dest='/home/test',
        follow=False,
        mode='preserve',
        original_basename='test_file',
        remote_src=False,
        src='/home/test/test_file'
    )
    connection = Connection()
    module_execute_call_count = 0
    module_return = dict(ansible_facts=dict())

# Generated at 2022-06-23 07:40:03.930993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({'foo':'bar'}, pid=1234)
    assert action_module._connection is None
    assert action_module._task.args['foo'] == 'bar'
    assert(action_module._low_level_pid == 1234)

# Generated at 2022-06-23 07:40:09.473517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(),
            dest=dict(),
            recurse=dict(default=False, type='bool'),
            remote_copy=dict(default='scp', choices=['scp', 'rsync', 'sftp', 'boto']),
            validate_checksum=dict(default=False, type='bool'),
            follow=dict(default=False, type='bool'),
            directory_mode=dict(),
            remote_src=dict(default=False, type='bool'),
            local_follow=dict(default=True, type='bool'),
            mode=dict(default=None, choices=['preserve', 'restrict', 'absent']),
            content=dict(),
        ),
        supports_check_mode=True
    )

    assert module.argument_

# Generated at 2022-06-23 07:40:12.610979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.copy
    am = ansible.plugins.action.copy.ActionModule(dict(ANSIBLE_MODULE_ARGS={}), dict())
    assert am is not None


# Unit tests for private functions in this file

# Generated at 2022-06-23 07:40:19.051868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Note: This tests the run method of the ActionModule class.
    loader = DictDataLoader({
        'test/foo.j2': 'content {{ a }}',
        'test/foo.txt': 'content {{ b }}',
        'test/foo.sh': 'content {{ c }}',
        'test/bar.j2': 'content {{ d }}',
        'test/bar.txt': 'content {{ e }}',
        'test/bar.sh': 'content {{ f }}'
    })
    mock_vars = dict(
        a='a',
        b='b',
        c='c',
        d='d',
        e='e',
        f='f'
    )
    mock_loader = DictDataLoader({})

# Generated at 2022-06-23 07:40:24.104994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize object
    am = ActionModule()

    # Check that we are running on linux
    if not am.system == 'Linux':
        print("Test not running on Linux")
        return

    # Run main program
    main(am)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:40:32.238523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner = SpyRunner(run_as_root=False)
    runner._shell = SpyShell()
    connection = SpyConnection('testhost')
    connection._shell = runner._shell
    module = ActionModule(runner, connection, '/path/to/playbook', 'action', dict())
    assert module.action == 'action'
    assert module.runner == runner
    assert module._task.action == 'action'
    assert module._task.args == {}
    assert module._connection == connection
    assert module._loader.path_exists('/path/to/playbook')

# Generated at 2022-06-23 07:40:41.137691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    # Should not cause exception
    my_task = dict(
        action = dict(
            module = 'copy',
        ),
    )
    my_connection = ConnectionBase(play_context=PlayContext())
    my_action_mod = ActionModule(my_task, my_connection)
    my_action_mod = ActionModule(my_task, my_connection, become_methods=['sudo'])
    my_action_mod = ActionModule(my_task, my_connection, become_methods=None)

    # Constructor of class ActionModule
    # Raise exception, because 'become_methods' is empty and is not None
    try:
        my_action_mod = ActionModule(my_task, my_connection, become_methods=[])
    except Exception:
        pass
   

# Generated at 2022-06-23 07:40:44.181825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_module_spec=False, **DEFAULT_FIXTURE_ARGS)
    assert module

# Generated at 2022-06-23 07:40:53.370739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from __main__ import display
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.vars_plugin import AnsibleVarsPlugin
    import os
    import tempfile
    import traceback
    import types

    not_a_real_collection = 'not_a_real_collection'
    not_a_real_name = 'not_a_real_name'


# Generated at 2022-06-23 07:41:00.842689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize class object
    action_module = ActionModule(connection='connection', task='task', templar='templar', shared_loader_obj='shared_loader_obj', loader='loader', path_info='path_info')
    # Set valid values for 'result' which is a dictionary
    result = {}
    # Invoke method with valid values for parameters source, result, dest
    action_module.run(source='source', result='result', dest='dest')

# Generated at 2022-06-23 07:41:01.560756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:41:11.874256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equal(ActionModule.BYPASS_HOST_LOOP, True)
    assert_equal(ActionModule.NO_TARGET_SYSLOG, True)
    assert_equal(ActionModule.BYPASS_HASH, True)
    assert_equal(ActionModule._static_args, set(['path', 'dest', 'src', 'content', 'remote_src', 'recurse', 'mode', 'directory_mode',
                                                 'remote_src', 'local_follow', 'follow', 'checksum']))
    assert_equal(ActionModule._no_log, set(['content']))

    # test initialization of object
    a = ActionModule()
    assert_equal(a._task, None)
    assert_equal(a._connection, None)
    assert_equal(a._play_context, None)

# Generated at 2022-06-23 07:41:20.827324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with patch("os.path.isfile", return_value=False):
        with patch("os.path.isdir", return_value=True):
            tmp = None
            task_vars = dict()
            action_module = ActionModule(load_name="", task=None)
            result = action_module.run(tmp, task_vars)
            assert result["failed"] == True


# Generated at 2022-06-23 07:41:26.511972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy task for testing
    class DummyTask(object):
        def __init__(self):
            self.args = {}

    module = ActionModule(DummyTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, object)

# Generated at 2022-06-23 07:41:36.492270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import BytesIO

    class MockConnection:
        class _shell:
            class _cleanup_commands:
                def __init__(self):
                    self.commands = []

                def __setitem__(self, key, value):
                    self.commands.append(value)

                def __delitem__(self, key):
                    self.commands.remove(key)

            def __init__(self, has_trailing_slash):
                self.path_has_trailing_slash = has_trailing_slash
                self.tmpdir = "/fake/tmp/path"
                self._cleanup_commands = self._shell._cleanup_commands()


# Generated at 2022-06-23 07:41:37.636422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #unittest.main()
    assert True

# Generated at 2022-06-23 07:41:49.953511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tmp = tempfile.mkdtemp(prefix='ansible-tmp')
    collection_loader = collections.CollectionLoader()
    loader = DataLoader()

# Generated at 2022-06-23 07:42:02.366315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-23 07:42:14.858350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule()
    t.set_connection()
    t._task = Task()
    t._task.args.update(dict(src='mock_src', dest='mock_dest'))
    t._remove_tmp_path = Mock()
    t._replace_with_kv_expansion = Mock()
    t._remote_expand_user = Mock()
    t._transfer_data = Mock()
    t._execute_module = Mock(side_effect=dict(changed=False, failed=True, msg='what'))
    t._execute_command_with_send_mode = Mock()
    t._execute_command_with_sudo = Mock()
    t._execute_command_with_su = Mock()
    t._execute_command_with_shell = Mock()
    t._execute_command_with_prompt

# Generated at 2022-06-23 07:42:24.508384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.stups.zign.tests.unit.compat import unittest
    from ansible_collections.stups.zign.tests.unit.compat.mock import patch, Mock, MagicMock
    from ansible_collections.stups.zign.plugins.modules import zign_copy

    action_module = zign_copy.ActionModule("the_name","the_path")
    action_module.tmp = "the_tmp"
    action_module.task_vars = "the_task_vars"

    with patch("ansible.modules.zign.copy.ActionModule.run") as _m_run:
        m_run = Mock()
        _m_run.return_value = m_run
        action_module.run()
        _m_run.assert_called

# Generated at 2022-06-23 07:42:25.087838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == False

# Generated at 2022-06-23 07:42:34.143097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize some variables for testing
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    task_vars = dict()
    result = dict()

    # Create a instance of class ActionModule
    am = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=loader,
        variable_manager=variable_manager,
        all_vars=dict()
    )

    # Unit test for method run when result['failed'] == True
    result['failed'] = True
    assert am.run(tmp=None, task_vars=task_vars) == result

    # Unit test for method run when source and content is required
    result['failed'] = False
    result['msg'] = 'src (or content) is required'

# Generated at 2022-06-23 07:42:36.312266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    module = None
    task = Task()
    task._role = dict()

    from ansible.plugins.action import ActionBase

    module = ActionModule(task, Connection())

    assert module is not None


# Generated at 2022-06-23 07:42:44.360088
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create a dummy class as an ActionModule
    class MyAM(ActionModule):
        TRANSFERS_FILES = True
        def __init__(self, *args, **kwargs):
            super(MyAM, self).__init__(*args, **kwargs)
            self._task = kwargs['task']
            self._task_vars = kwargs['task_vars']
            self._tmp = '/tmp/'
            self._connection = kwargs['connection']

        def _execute_module(self, module_name, module_args, task_vars):
            return dict()

    # Create data to populate the ActionModule
    task = dict()
    task_vars = dict()


# Generated at 2022-06-23 07:42:45.460539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test class method run
    pass

# Generated at 2022-06-23 07:42:54.322402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case test data
    module_args = dict(dest='/var/log/',
                       follow=False,
                       local_follow=True,
                       mode=None,
                       src='/foo/bar/')
    task_vars = dict(ansible_connection='winrm')
    # Patching setup
    patcher_action_base = patch('ansible.plugins.action.copy.ActionModule._execute_module', return_value=dict(failed=False))
    patcher_action_base_exc = patch('ansible.plugins.action.copy.ActionModule._execute_module', side_effect=Exception)
    patcher_action_copy = patch('ansible.plugins.action.copy.ActionModule.run', side_effect=AnsibleError)

# Generated at 2022-06-23 07:43:06.365021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run()
    assert result == dict(failed=True, msg='src (or content) is required')

    module = ActionModule(task=dict(args=dict(dest=None)), connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run()
    assert result == dict(failed=True, msg='dest is required')

    source = '/path/to/src'
    dest = '/path/to/dest'


# Generated at 2022-06-23 07:43:18.727262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests assume utils/module_utils/cloud/azure/azure_rm_common.py is a vendorized copy of ansible.module_utils.cloud.azure.azure_rm_common
    # All of the actual methods are mocked in this file.
    import sys
    sys.path.insert(0, '../../utils/module_utils/cloud/azure')
    from azure_rm_common import AzureRMModuleBase

    class MockAnsibleModule():
        def __init__(self):
            self.params = dict()

    class MockAnsibleBase():
        def __init__(self):
            self.params = dict()

    class MockAnsible():
        def __init__(self):
            self.params = dict()

# Generated at 2022-06-23 07:43:28.981952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check that a basic object can be created
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host = Host('blackbird.ansible.com')
    group = Group('ungrouped')
    group.add_host(host)
    task_vars = dict()
    variables = VariableManager(loader=loader, hosts=group, task_vars=task_vars)
    task = dict(action=dict(module='command', args=dict(echo='hi')))

    action = ActionModule(task, variables)
    assert action is not None

# Generated at 2022-06-23 07:43:38.037219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.network.sros.sros import sros_argument_spec
    
    module = AnsibleModule(sros_argument_spec, 'sros')
    module.run_command = MagicMock()
    module.run_command.return_value = (0,"")
    module.check_mode = False
    module.params = { 'provider':{ 'password':'admin',
                                   'host':'localhost',
                                   'username':'admin'},
                      'interface':'test1',
                      'description':'test description'
                      }
    
    
    am = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    

# Generated at 2022-06-23 07:43:46.303580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Params is a list of tuples that contain the above arguments to the ActionModule instance.
    params = [
    ]
    # Return is a list of tuples that contain (param, expect, result)
    return_ = [
    ]

    # Run run_module() against the param set
    for param, expect, result in run_module(ActionModule, params):
        # Verify the result matches the expected value
        assert result == expect, 'Result does not match expected: %s' % param

    # This method will fail with an exception if the method doesn't exist
    ActionModule.run()

    # Verify that we can access the attributes defined in the class
    obj = ActionModule()
    obj.transfer_files()
    obj.fail_json()
    obj.run_command()
    obj.async_poll()
    obj.poll_

# Generated at 2022-06-23 07:43:58.180967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    yaml_data = """
    tasks:
    - name: copy test
      copy:
        src: /tmp/source
        dest: /tmp/dest
        mode: 0644
        follow: yes
      register: result
    - debug: var=result"""

    yaml_data2 = """
    tasks:
    - name: copy test
      copy:
        src: /tmp/source
        dest: /tmp/dest
        mode: 0644
        follow: yes
        recurse: yes
      register: result
    - debug: var=result"""


# Generated at 2022-06-23 07:44:05.931884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys, os
    import pytest
    import pytest_tk  # noqa
    import ansible.module_utils.six as six

    from mock import MagicMock, patch
    from ansible.errors import AnsibleFileNotFound
    from ansible.module_utils.six.moves import builtins

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts.system.distribution import DistributionFactRetriever

    from ansible.plugins.action import ActionModule


    mock_task = MagicMock()
    mock_task.action.split.return_value = [None, None, None]

    results = dict(skipped=False)
    results['changed'] = True

    mock_play_context = MagicMock

# Generated at 2022-06-23 07:44:07.395685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test _ActionModule class constructor '''

    # test without args
    module = ActionModule()
    assert module

# Generated at 2022-06-23 07:44:15.706254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    con = Mock()
    con.run_command = Mock()
    con.run_command.return_value = (0, "", "")

    play_context = Mock()
    play_context.prompt = Mock()

    task = Mock()
    task.args = json.loads('''{"src": "/root/file1", "dest": "/root/file2", "state": "absent"}''')

    am = ActionModule(task, con, play_context, loader=None, templar=None, shared_loader_obj=None)

    assert am.task == task
    assert am.connection == con
    assert am.play_context == play_context


# Generated at 2022-06-23 07:44:24.229252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    #
    # Test to make sure ActionModule is a subclass of ansible.plugins.ActionBase
    #
    assert issubclass(ActionModule, ActionBase)

    #
    # Test ActionModule instantiation
    #
    module = ActionModule()
    assert isinstance(module, ActionBase)
    assert hasattr(module, '_task')
    assert hasattr(module, 'run')
    assert hasattr(module, '_execute_module')
    assert hasattr(module, '_copy_file')
    assert hasattr(module, '_create_content_tempfile')
    assert hasattr(module, '_remove_tempfile_if_content_defined')

    # Test instantiation involving all arguments

# Generated at 2022-06-23 07:44:25.423629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-23 07:44:32.017580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # First create the class
    action = ActionModule(None, None)
    # Check some members
    assert action.uses_shell is False
    assert action.no_log is False
    # We're done with this for now

# Test if ActionModule._find_needle() works as expected.
# Also test if the return value from this method is escaped properly.

# Generated at 2022-06-23 07:44:43.363688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock = MagicMock()
    mock.connection = MagicMock()
    mock.connection.run = MagicMock()
    mock.connection.generate_command_line = MagicMock()

    mock.vars = dict()
    mock.noop_on_check = False
    mock.args = dict()
    module = ActionModule(mock)
    assert module._play_context == mock
    assert module._connection == mock.connection
    assert module._task == mock
    assert module._loader is None
    assert module._shared_loader_obj is None
    assert module._action == 'Ansible Action Module'
    assert module._loaded_name == 'Ansible Action Module'
    assert module._task_vars == {}
    assert module._templar is None
    assert module._loader is None
    assert module._shared_

# Generated at 2022-06-23 07:44:59.515409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Python 2.6 doesn't have the `assertRaisesRegexp` so we need to use `assertRaisesRegex`
    if sys.version_info < (2, 7):
        assertRaisesRegex = getattr(unittest, 'assertRaisesRegexp')
    else:
        assertRaisesRegex = getattr(unittest, 'assertRaisesRegex')


# Generated at 2022-06-23 07:45:01.950418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_helper = ActionModule()
    assert isinstance(action_helper, ActionModule) is True


# Generated at 2022-06-23 07:45:05.061731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 07:45:13.019763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    my_task = Task()
    my_task.action = 'copy'
    my_task.args = {}
    my_connection = Connection()
    action_module = ActionModule(my_task, my_connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.name == 'copy'
    assert action_module._shared_loader_obj == None
    assert action_module._loader._shared_loader_obj == None
    assert action_module._task == my_task
    assert action_module._connection == my_connection


# Generated at 2022-06-23 07:45:19.301560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(src='/tmp/test/test1.txt', dest='/tmp/test/test2.txt')

    module = ActionModule(task=dict(action=dict(_uses_shell=False, args=module_args)))
    assert module._uses_shell == False

# Generated at 2022-06-23 07:45:20.661227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:45:30.264501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize an instance of class ActionModule
    a = AnsibleActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Initialize a dict to pass as the value for task_vars, as that is one of the arguemnts of method run
    task_vars = dict()

    # Set default value for content of task_vars dict
    task_vars['content'] = None

    # Initialize a dict to pass as the value for inject, as that is one of the arguemnts of method run
    inject = dict()

    # Set default value for content of inject dict
    inject['content'] = None

    # Initialize a dict to pass as the value for ans

# Generated at 2022-06-23 07:45:35.822085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = module_common.DummyModule()
    m.params =  dict(
        content="test content string",
        dest="/usr/bin/test_file",
        src=None
    )

    am = ActionModule(m, connection=None)

    assert am._connection is None, "ActionModule.connection should be None."

    assert am._task.args == m.params, 'ActionModule.task.args should be set to module.params.'

# Generated at 2022-06-23 07:45:47.817362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is the unit test for the ActionModule in the basic.py
    """
    import ansible.plugins.connection.ssh
    mock_connection = ansible.plugins.connection.ssh.Connection()
    mock_loader = DictDataLoader({'file': '', 'directory': ''})
    mock_task = DictObj()
    mock_task.action = 'file'
    mock_task.async_val = 0
    mock_task.sudo = True
    mock_task.sudo_user = 'fake_user'

# Generated at 2022-06-23 07:45:49.406181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: write tests
    pass


# Generated at 2022-06-23 07:45:57.813820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the ActionModule class
    x = ActionModule()

    # Return the result of a method call
    test_dir_path = os.path.dirname(__file__)
    test_data_path = os.path.join(test_dir_path, "test_data")
    test_file_path = os.path.join(test_data_path, "test_str.yaml")
    result = x.run(tmp=test_file_path, task_vars=test_data_path)

    print(result)


# Generated at 2022-06-23 07:46:04.189423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    action_module = ActionModule()
    # define the task object
    action_module._task = Task()
    # define the connection object
    action_module._connection = Base()
    action_module._task.args = dict(src='', dest='')
    # assert the result
    assert action_module.run() == dict(failed=True, msg='dest is required')

# Generated at 2022-06-23 07:46:06.877069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''ActionModule class constructor'''

    module = ActionModule({'action': 'copy'})
    assert isinstance(module, ActionModule)

# Generated at 2022-06-23 07:46:09.065700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' return_data should be a dict '''
    action_module_instance = ActionModule()
    _, return_data = action_module_instance._execute_module()
    assert isinstance(return_data, dict)

# Generated at 2022-06-23 07:46:15.444920
# Unit test for constructor of class ActionModule
def test_ActionModule():
        """
        Tests ActionModule.__init__() and ActionModule.run() methods.
        """
        mock_task = mock.Mock()
        mock_connection = mock.Mock()
        mock_task.args = {'dest': 'dest', 'src': 'src'}
        test_action = ActionModule(mock_task, mock_connection)
        assert test_action

# Generated at 2022-06-23 07:46:17.543272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 07:46:28.642409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    task = TaskResult(host=dict(name='localhost'), task=dict(action=dict(module='copy', args=dict(src='s', dest='d'))))
    play_context = PlayContext()
    action = ActionModule(task, play_context, '/tmp/', connection=None, shell=None, loader=None, templar=None, shared_loader_obj=None)

    res = action.run(None, task_vars={})
    assert res['dest'] == 'd'
    assert res['src'] == 's'


# Generated at 2022-06-23 07:46:37.064915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    import shutil
    import random
    import string

    # src/dest directory configuration
    SRC_DIR_NAME = 'test_action_module_src'
    DST_DIR_NAME = 'test_action_module_dest'

    # length of src/dest directory name
    SRC_DIR_NAME_LEN = len(SRC_DIR_NAME)
    DST_DIR_NAME_LEN = len(DST_DIR_NAME)

    temp_dir = tempfile.mkdtemp()
    src_dir_path = os.path.join(temp_dir, SRC_DIR_NAME)
    dst_dir_path = os.path.join(temp_dir, DST_DIR_NAME)


# Generated at 2022-06-23 07:46:47.338268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_path = 'my_path'
    my_task = 'my_task'
    my_connection = 'my_connection'
    my_play_context = 'my_play_context'
    my_loader = 'my_loader'
    my_templar = 'my_templar'
    my_shared_loader_obj = 'my_shared_loader_obj'
    my_action_base = 'my_action_base'

    my_action_module = ActionModule(my_path, my_task, my_connection, my_play_context, my_loader, my_templar, my_shared_loader_obj, my_action_base)

    # The following tests are for the constructor of ActionModule
    assert my_play_context == my_action_module.play_context

    assert my_task.action

# Generated at 2022-06-23 07:46:58.857153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner_path = 'ansible_runner'
    runner_interfaces = 'interface'
    runner_module = 'file'
    runner_action = 'copy'
    runner_task = dict(name='name')
    runner_task_args = dict()
    runner_task_args['dest'] = 'dest'
    runner_task_args['src'] = 'src'
    runner_task_args['content'] = 'content'
    runner_set_noop = False
    runner_connection = 'connection'
    runner_loader = 'loader'
    runner_play_context = 'play_context'
    runner_variable_manager = 'variable_manager'
    runner_shared_loader_obj = 'shared_loader_obj'


# Generated at 2022-06-23 07:47:09.097280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Example of a structure of task.args
    """
    args = {
        'content': '',
        'dest': '/home/test/test.txt',
        'recursive': True,
        'group': 'test',
        'src': '/test/test.txt',
        'force': True,
        'state': 'file',
        'owner': 'test',
        'mode': '777'
    }
    """
    # Action Module, which is under test.
    am = ActionModule()
    # Fake task, which is passed to __init__.
    task = object()
    # Fake connection, which is passed to __init__.
    conn = object()
    # Fake play_context, which is passed to __init__.
    pc = object()
    # Fake loader, which is passed to __init__.
