

# Generated at 2022-06-23 07:37:08.082639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''action_plugins/copy.py: ActionModule()'''
    # FIXME: Not implemented test
    temp_obj = ActionModule()
    assert temp_obj is not None


# Generated at 2022-06-23 07:37:18.243113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(
        _ansible_loop_items=[]
    )
    task = Task(dict(
        action=dict(
            args=args,
            module_name='ansible.legacy.copy',
            name='Ansible Copy'
        )
    ))

    # Create a magic mock to store task in
    task_mock = MagicMock()
    task_mock.configure_mock(**{'as_dict.return_value': task.as_dict()})

    # Create a fake Ansible TaskResult
    task_result_mock = MagicMock(spec=TaskResult)

    # Create a fake Ansible TaskExecutor
    executor_obj = MagicMock()

    # Create a magic mock to store our Result in
    result_mock = MagicMock()

    # Create a

# Generated at 2022-06-23 07:37:20.052582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test that we can create an instance of ActionModule.
    '''
    action_module = ActionModule()
    assert action_module


# Generated at 2022-06-23 07:37:22.903179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-23 07:37:25.240948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.copy as copy
    am = copy.ActionModule({'src': 'files/hello.txt'})
    assert am is not None

# Generated at 2022-06-23 07:37:25.767992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:37:39.276752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = sys.modules[__name__]
    class_ = getattr(module, 'ActionModule')
    setattr(class_, '_execute_module', _execute_module_mock)
    setattr(class_, '_execute_remote_stat', _execute_remote_stat_mock)
    setattr(class_, '_remove_tmp_path', _remove_tmp_path_mock)
    setattr(class_, '_check_invalid_arguments', _check_invalid_arguments_mock)
    setattr(class_, '_transfer_str', _transfer_str_mock)
    setattr(class_, '_connection_transfer_data', _connection_transfer_data_mock)

# Generated at 2022-06-23 07:37:47.776614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    j = _json.loads
    action = _action.ActionModule
    module_utils = _module_utils.ModuleUtils
    shell = _shell.Shell
    mock_config = _mock_config.MockConfig
    config = mock_config()
    task_vars = {}
    tmp = None
    play_context = _play_context.PlayContext
    connection = _connection.Connection
    loader = _loader.ActionLoader
    display = _display.Display
    templar = _templar.Templar
    ansible_module_utils = _ansible_module_utils.AnsibleModuleUtils
    utils = _utils.Utils
    task = _task.Task
    mock_args = _mock_args.MockArgs
    mock_shell = _mock_shell.MockShell
   

# Generated at 2022-06-23 07:37:56.533702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    ansible_host = Mock()
    ansible_host.run = Mock(return_value=None)
    register_ansible_module = Mock()
    register_ansible_module.copy = Mock(return_value=ansible_host)
    register_ansible_module.file = Mock(return_value=ansible_host)
    ansible_fact = Mock()
    ansible_fact.get_ansible_host = Mock(return_value=ansible_host)
    ansible_fact.get_register_ansible_module = Mock(return_value=register_ansible_module)
    ansible_fact.get_ansible_module_path = Mock()
    tmp = Mock()
    tmp.get_tmp_path = Mock(return_value="test_path")
    task_vars=M

# Generated at 2022-06-23 07:38:03.524630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Test that files are found if they are in one of the expected directories.

# Generated at 2022-06-23 07:38:07.332049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module is not None


# Generated at 2022-06-23 07:38:10.911225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode is True
    assert module._connection is None
    assert module.runner is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None
    assert module._task is None


# Generated at 2022-06-23 07:38:19.096679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import to_bytes
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.errors import AnsibleUndefinedVariable

    global ABS_PATH_TO_TEST_FILES
    ABS_PATH_TO_TEST_FILES = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'test_data')

    global ABS_PATH_TO_TEST_TMP_FILES
    ABS_PATH_TO_TEST_TMP_FILES = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'test_tmp')

    global ABS_PATH_

# Generated at 2022-06-23 07:38:23.136157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor with ActionBase
    action_base = ActionBase()
    try:
        action_module = ActionModule(action_base)
        fail("Test constructor with ActionBase fail")
    except Exception as e:
        pass

    # Test constructor with Task
    task = Task()
    action_module = ActionModule(task)
    assert action_module.action_base == task.action_base

# Generated at 2022-06-23 07:38:32.218083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Fix Constants
    C.DEFAULT_LOCAL_TMP = '/tmp/'
    C.DEFAULT_REMOTE_TMP = '/tmp/'
    connection = ansible.plugins.connection.ConnectionBase(PlayContext())
    play_context = PlayContext()
    play_context._connection = connection
    task = Task()
    task._role = None
    task._role_context = None
    task.args = {'mode': 'preserve'}
    task._play = None
    task._play_context = play_context
    action_module = ActionModule(task, connection, templar=None)
    assert action_module


# Generated at 2022-06-23 07:38:32.992462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:38:44.024722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for ActionModule can only be called with valid arguments.
    # First argument has to be task object.
    from ansible.playbook.task import Task
    task_object = Task()

    # Second argument has to be connection object.
    from ansible.plugins.connections.local import Connection
    connection_object = Connection()

    # Third argument has to be 'tmp' of type string.
    tmp_str = '/tmp/'

    # Fourth argument has to be 'task_vars' of type map.
    task_vars_map = {}

    # Fifth argument has to be 'loader' of type object.
    from ansible.parsing.dataloader import DataLoader
    loader_object = DataLoader()

    # Sixth argument has to be 'play_context' of type object.

# Generated at 2022-06-23 07:38:55.026640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, action_plugin=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._templar.__class__.__name__ == 'Template'
    assert am._loader.__class__.__name__ == 'DataLoader'
    assert am._connection.__class__.__name__ == 'Connection'
    assert am._play_context.__class__.__name__ == 'PlayContext'
    assert am._action.__class__.__name__ == 'ActionBase'
    assert am._shared_loader_obj.__class__.__name__ == 'TaskVars'
    assert am._task.__class__.__name__ == 'Task'

# Generated at 2022-06-23 07:39:05.399443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_ActionModule_run')
    def _find_needle_mock(self, dirname, needle):
        return os.path.join(fixture_path,dirname,needle)

    class AnsibleModule_mock():
        _ansible_module_name = 'ansible.legacy.file'
        _ansible_module_args = 'dest=/tmp/dest'
        def __init__(self):
            pass

        def get_bin_path(self, arg):
            return arg
        def _execute_module(self):
            return None

        def _execute_module(self):
            return None
        def _remove_tmp_path(self):
            return None

# Generated at 2022-06-23 07:39:07.263788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule('test')
    assert not action_module.run()


# Generated at 2022-06-23 07:39:16.333876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test AnsibleAction.run
    """
    # Module to test
    # import sys
    # sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    # import ansible_collections.ansible.community.plugins.action.synchronize as synchronize

    # Setup test
    synchronize.ActionModule.__bases__ = (object,)
    synchronize.ActionModule.__subclasses__ = ()

    synchronize.AnsibleAction.__bases__ = (object,)
    synchronize.AnsibleAction.__subclasses__ = ()

    synchronize.Synchronize.__bases__ = (object,)
    synchronize.Synchronize.__subclasses__ = ()

    synchronize.SFTPAction

# Generated at 2022-06-23 07:39:27.687525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock connection
    test_conn = Connection()

    # Create a mock task
    test_task = Task()

    # Create a mock AnsibleOptions
    test_options = AnsibleOptions()

    # Create a mock AnsibleLoader
    test_loader = AnsibleLoader()

    # Create a mock display
    test_display = Display()

    # Create a mock variables
    test_variables = dict()

    # Create an action module
    action_module = ActionModule(test_task, test_connection, test_loader, test_options, test_display, test_variables)

    # Create a mock remote_user and remote_pass
    remote_user = "test"
    remote_pass = "test"

    # Create a mock delete
    test_delete = True

    # Create a mock sudo
    test_sudo = True



# Generated at 2022-06-23 07:39:29.829866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(10, 10)
    assert isinstance(mod, ActionModule)
    assert mod._task.action == 'copy'
    assert mod._task.args == {}

# Generated at 2022-06-23 07:39:34.606421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {'src': 'test', 'dest': 'test'})
    assert action._connection is None
    assert action._task is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None
    assert action._task_vars is None
    assert action._loader_cache is None
    assert action._connection_info is None

# Generated at 2022-06-23 07:39:47.515035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None, None, None, None)
    am._task = Mock()
    am._task.args = {}

    # empty src/dest is not acceptable
    assert am.run()['failed']
    am._task.args = {'dest':'/tmp/ansible-tmp-1448132722.94-126579735742318/test'}
    assert am.run()['failed']
    am._task.args = {'src':'/tmp/ansible-tmp-1448132722.94-126579735742318/test',
                     'dest':'/tmp/ansible-tmp-1448132722.94-126579735742318/test'}
    assert not am.run()['failed']

    # content and src are exclusive

# Generated at 2022-06-23 07:39:57.258312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    # ActionModule is a class
    # Assign values as needed for test
    mock_task = MagicMock(spec=Task)
    mock_connection = MagicMock(spec=Connection)
    mock_play_context = MagicMock(spec=PlayContext)

    action_module = ActionModule(mock_task, mock_connection, mock_play_context, loader=None, templar=None, shared_loader_obj=None)

    # Act
    # Call run method
    with pytest.raises(NotImplementedError):
        action_module.run()

# ---------------------------------------------------------
# 'copy' action plugin
# ---------------------------------------------------------

# Generated at 2022-06-23 07:40:05.379848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.inventory.manager import InventoryManager

    module_utils = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'module_utils')
    action = ActionModule({'action': 'copy'},
                          {'action': 'copy', 'src': 'file', 'dest': '/tmp/dest'},
                          'inventory', 'host',
                          '/path/to/playbook', '', 'remote',
                          datetime.datetime(1, 1, 1, 1, 1, 1),
                          '/path/to/playbook/module_utils',
                          True)
    assert action._task.module_vars == {}
    assert action._action == 'copy'
    assert action._connection == 'remote'
    assert action._play_context is None
    assert action._

# Generated at 2022-06-23 07:40:14.887626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Sample task_vars dict
    task_vars = {u'nested': {u'foo': {u'bar': u'baz'}}}
    
    # Sample module_args dict

# Generated at 2022-06-23 07:40:26.115108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
      This unit test will test the constructor of `ansible_collections.ansible.community.plugins.module_utils.legacy.action.ActionModule`.
    """
    def _task_mock_instance(self, task_vars):
        return None

    def _loader_mock_instance():
        return None

    module = ActionModule({},
                          {'playbook_dir': '/playbook/path/'},
                          _task_mock_instance,
                          'ansible.legacy.copy',
                          _loader_mock_instance)
    assert isinstance(module, ActionModule)
    assert module._task is None
    assert module._loader is None
    assert module._shared_loader_obj is None
    assert module._connection is None
    assert module._play_context is None
    assert module

# Generated at 2022-06-23 07:40:27.470589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test to check the ActionModule is working as expected.
  m = ActionModule({},{})


#####################################################################################


# Generated at 2022-06-23 07:40:32.680732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader()
    host = Mock(name='host')

    def get_option(k):
        return None

    host.get_option.side_effect = get_option

    task = Mock(name='task')
    task._role = None
    task.args = dict()
    task.action = 'copy'
    task.loop = 'copy'
    task.noop_task = False

    play_context = Mock(name='play_context')
    play_context.network_os = 'default'
    play_context.remote_addr = None
    play_context.remote_user = None
    play_context.password = None
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None

# Generated at 2022-06-23 07:40:41.424385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from copy import deepcopy
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI
    from ansible.plugins.loader import module_loader
    import pytest

    context._init_global_context(AdHocCLI())

    # Create a manager for runtime context
    context.CLIARGS._manager = getattr(context._GLOBAL_CONTEXT, "CLIARGS")

    module = module_loader.get('copy', class_only=True)
    if module is None:
        raise Exception("Could not get copy module")

    # mock file
    mock_action_module = mock.Mock(spec=ActionModule)

# Generated at 2022-06-23 07:40:50.513856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._task.action == 'copy'
    assert action._task.args == {}
    assert action._shared_loader_obj.module_loader is None
    assert action._connection.transport == 'local'
    assert action._task.delegate_to is None
    assert action._task._role is None
    assert action._task.async_val == 0
    assert action._task.async_seconds == 0
    assert action._task.async_poll_interval == 10

    # See https://github.com/ansible/ansible-modules-core/issues/1809
    assert action._task.async_seconds == 0
    assert action._task.async_poll_interval == 10
    assert action._task.async_timeout == 0

    assert action._loader.get_basedir

# Generated at 2022-06-23 07:41:03.524488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_inventory(inventory=None)

    variable_manager.extra_vars = dict(
        ansible_connection='local',
        ansible_python_interpreter='/usr/bin/python'
    )

    context = PlayContext()
    context._variable_manager = variable_manager

    task_vars = dict()
    task_vars['ansible_python_interpreter'] = sys.executable
    task_vars['ansible_connection'] = 'local'


# Generated at 2022-06-23 07:41:05.454759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-23 07:41:07.304155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test init
    # Init the action module
    action_module = ActionModule()


# Generated at 2022-06-23 07:41:15.064760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule = action_plugins.ActionModule
    ansible_connection = mock.MagicMock()
    ansible_connection.tmpdir.return_value = '/var/folders/5g/c5y5p5z12vb0gplx_f4ks5300000gn/T/'
    ansible_connection.join_path.side_effect = lambda *args: '/'.join(args)
    action_module = ActionModule(ansible_connection, dict(src='test', dest='test'))
    ansible_connection.run.side_effect = lambda *args: args[0]
    assert action_module.run() == ['chdir', '/var/folders/5g/c5y5p5z12vb0gplx_f4ks5300000gn/T/']



# Generated at 2022-06-23 07:41:17.859823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    # test that the action plugin is loaded ok and the correct type
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:41:29.016867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict()),
            task=dict(args=dict(src="test_src", dest="test_dest"), vars=dict(dest="nope", foobar="foobar", ansible_host="host")))
    assert not mod.run()['failed']
    # test _load_params()
    mod = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict()),
            task=dict(args=dict(src="test_src", dest="test_dest"), vars=dict(dest="nope", foobar="foobar", ansible_host="host")))
    assert not mod._load_params()

# Generated at 2022-06-23 07:41:34.151911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit tests for ActionModule constructor
    """
    mock_task = MagicMock()
    mock_connection = MagicMock()
    mock_play_context = MagicMock()

    mock_task.args = {}
    mock_connection._shell.tmpdir = "tmp"
    mock_task.action = "file"

    assert isinstance(ActionModule(mock_task, mock_connection, mock_play_context), ActionModule)
    # Test if values were assigned properly
    assert ActionModule(mock_task, mock_connection, mock_play_context)._task == mock_task
    assert ActionModule(mock_task, mock_connection, mock_play_context)._connection == mock_connection
    assert ActionModule(mock_task, mock_connection, mock_play_context)._play_context == mock_play_context


# Generated at 2022-06-23 07:41:47.015115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    global_loader = DictDataLoader({})
    global_vars_plugin = ansible.plugins.action.VarsModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=global_loader, templar=Mock(), shared_loader_obj=None)
    global_shell_plugin = ansible.plugins.action.ShellModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=global_loader, templar=Mock(), shared_loader_obj=None)
    global_template_plugin = ansible.plugins.action.TemplateModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=global_loader, templar=Mock(), shared_loader_obj=None)

# Generated at 2022-06-23 07:41:51.352637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = DummyConnection()
    action_module = ActionModule(DummyTask(), connection, '/tmp/ansible_action_module')
    assert action_module.action_loader is not None
    assert action_module.connection is not None
    assert action_module.tmp_path is not None


# Generated at 2022-06-23 07:41:52.655352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-23 07:42:04.117152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = "path/to/sample/file"
    dest = "/some/dest"
    remote_src = False
    local_follow = True
    remote_follow = False
    checksum = '3a816101f3d7e233655a3e3dcd3e6edf'
    local_checksum = 'e8a4bef4d761d4e2ec7f8a2c962e6af9'

    # test with empty src
    module_args = {"src": ''}
    temp_task_vars = {"a": "b"}
    temp_loader = DictDataLoader({})
    temp_task = Task()
    temp_task.args = module_args
    temp_result = dict()


# Generated at 2022-06-23 07:42:16.145771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection plugin
    conn = Connection()

    # Create a mock ActionModule instance
    action_module = ActionModule(conn)

    # Create a mock task
    task = Task()

    # Set connection plugin
    task.set_connection(conn)

    # Assert test
    #assert action_module.run(task.args, task.vars) == {'failed': True, 'msg': 'src (or content) is required'}

    # Create a mock task
    task = Task()

    # Set connection plugin
    task.set_connection(conn)

    # Set task args
    task.args["dest"] = "data"

    # Assert test
    assert action_module.run(task.args, task.vars) == {'failed': True, 'msg': 'src (or content) is required'}



# Generated at 2022-06-23 07:42:22.637872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule with parameters task, connection, play_context, loader, templar, shared_loader_obj
    with pytest.raises(Exception):
        obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-23 07:42:32.517732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import ansible.modules.file
    import ansible.modules.copy
    import ansible.modules.shell
    import ansible.modules.command
    import ansible.modules.stat
    import ansible.utils
    import ansible.errors
    import ansible.callbacks
    import ansible.executor
    import ansible.utils.unsafe_proxy
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.errors import AnsibleError
    import ansible.vars
    import ansible.utils.vars
    import ansible.utils.module_docs
    from ansible.module_utils.basic import get_platform, AnsibleModule
    from ansible.module_utils.six import iteritems, string_types

# Generated at 2022-06-23 07:42:41.510002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = MagicMock()
    task = MagicMock()
    connection = MagicMock()
    task_vars = dict()
    result = dict()
    setattr(task, 'args', dict())
    setattr(connection, '_shell', None)
    src = 'src'
    content = 'content'
    dest = 'dest'
    remote_src = 'remote_src'
    local_follow = 'local_follow'
    action = ActionModule(task, connection, task_vars, result)
    action.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 07:42:51.949314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(__ansible_module__='copy', __ansible_arguments__=[]))
    am = ActionModule(task, dict(connection='local'))
    assert 'local' == am._task.args.get('connection')

    task = dict(action=dict(__ansible_module__='copy', __ansible_arguments__=[]))
    am = ActionModule(task, dict(connection='chroot'))
    assert 'sftp' == am._task.args.get('connection')

    task = dict(action=dict(__ansible_module__='copy', __ansible_arguments__=[]))
    am = ActionModule(task, dict(connection='jail'))
    assert 'sftp' == am._task.args.get('connection')


# Generated at 2022-06-23 07:43:02.678694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_transfer_file():
        (parsed_args, parsed_kwargs) = transfer_file.call_args
        assert parsed_args[1] == 'foo'
        assert parsed_args[2] == 'bar'
        assert parsed_args[3] == 'dest'

    results = dict(
        changed=False,
        md5sum='abc',
        sha1sum='abc',
        failed=False,
        rc=None
    )

    task_vars = dict()


# Generated at 2022-06-23 07:43:05.381311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate ActionModule and check instance
    action = ActionModule(None, None, None)
    assert isinstance(action, ActionModule)


# Generated at 2022-06-23 07:43:13.560644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Test for creating instance of ActionModule class
    action_module = ActionModule()

    #Test repr method
    assert action_module.__repr__() == "<ansible.legacy.ActionModule>"

    #Test _execute_module method
    assert action_module._execute_module(module_name='ansible.legacy.copy', task_vars=dict()) == dict(failed=True)

    #Test _copy_file method
    assert 'msg' in action_module._copy_file(source_full='/var/log', source_rel='/var/log', content=None, content_tempfile=None, dest='abc', task_vars=dict(), follow=False)

# Generated at 2022-06-23 07:43:21.267044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import mock_open, patch, MagicMock
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader

    class TestActionModule(unittest.TestCase):

        def test_constructor(self):
            task = dict(action=dict(module='copy', args=dict(src='/tmp/foo', dest='/tmp/bar', mode='444')))
            connection = MagicMock()
            ca = action_loader.get('copy', class_only=True)
            c = ca(task, connection)
            self.assertEqual(c._task.action['args']['src'], '/tmp/foo')

# Generated at 2022-06-23 07:43:29.464079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(
        src='src',
        dest='dest',
        remote_src=False,
        local_follow=True
    )

    action_module = ActionModule(
        task=dict(action=dict(module_args), args=module_args),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None
    )

    # Verify action_module is not None
    assert action_module is not None


# Generated at 2022-06-23 07:43:38.952910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor ActionModule
    # Create a MockConnection object to store Connection object
    mock_conn = MockConnection()
    # Create a MockTask object to store Task object
    mock_task = MockTask()
    # Create a MockPlayContext object to store PlayContext object
    mock_play_context = MockPlayContext()
    # Create a MockLoader object to store Loader object
    mock_loader = MockLoader()
    # Create a MockTemplar object to store Templar object
    mock_templar = MockTemplar()

    action_module = ActionModule(mock_conn, mock_task, mock_play_context, mock_loader, mock_templar)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-23 07:43:41.407206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(
        module_name = 'copy',
        module_args = {},
        task_args = {},
        runner_args = {},
    ))
    ok_(am is not None)

# Generated at 2022-06-23 07:43:43.531354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mocker = Mocker()
    task = mocker.mock()
    task.args = dict()
    ActionModule(task)
    mocker.verify()


# Generated at 2022-06-23 07:43:44.671913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unimplemented testcase, return dummy result
    return (ActionModule.run(), True)


# Generated at 2022-06-23 07:43:55.206938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class MockCallback(CallbackBase):
        """A helper class for testing."""
        def __init__(self):
            self.results = []
            super(MockCallback, self).__init__()

        def v2_runner_on_ok(self, result, **kwargs):
            self.results.append(result)

        def v2_playbook_on_task_start(self, task, is_conditional):
            return

    # Create loader, inventory, variable

# Generated at 2022-06-23 07:43:57.354120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:44:11.412889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar

# Generated at 2022-06-23 07:44:14.262137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_action_module = ActionModule()

    # TODO: implement unit test for method run of class ActionModule
    pass


# Generated at 2022-06-23 07:44:15.276018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    raise ValueError

# Generated at 2022-06-23 07:44:24.060532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #host  /etc/ansible/hosts
    ansible.utils.plugin_docs.prepare(sys.modules[__name__])
    action_module = ActionModule('chdir=/home/vagrant/virtualenv/ansible-2.4.0.0/lib/python2.7/site-packages/ansible/modules/files')
    #action_module.run(tmp=None, task_vars={})
    #action_module.run('/home/vagrant/virtualenv/ansible-2.4.0.0/lib/python2.7/site-packages/ansible/modules/files', task_vars={})
    #action_module.run('/home/vagrant/virtualenv/ansible-2.4.0.0/lib/python2.7/site-packages/ansible/modules

# Generated at 2022-06-23 07:44:36.243961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    playbook_loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 07:44:45.842514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = {"hostname": "127.0.0.1",
            "port": 22,
            "username": "root",
            "password": "******",
            "private_key_file": "/home/work/.ssh/id_rsa",
            "become": True,
            "become_method": "sudo",
            "become_user": "root",
            "become_pass": "******"}

    task = {"action": {"__ansible_module__": "copy",
                       "__ansible_arguments__": {"src": "/home/work/test",
                                                 "dest": "/home/work"}}}

    action_module = ActionModule(host, task)
    action_module._connection = ssh.Ssh(host=host)

# Generated at 2022-06-23 07:45:02.141125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[C.DEFAULT_HOST_LIST])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = "default"
    play_context.remote

# Generated at 2022-06-23 07:45:12.558997
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:45:17.438446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = mock.MagicMock()
    task.args = dict()
    mock_connection = mock.MagicMock()
    mock_loader = mock.MagicMock()
    mock_play_context = mock.MagicMock()
    test_action_module = ActionModule(task,
                                      mock_connection,
                                      mock_loader,
                                      mock_play_context)
    assert test_action_module


# Generated at 2022-06-23 07:45:20.327389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    name = am._supports_check_mode
    assert name == True

# Generated at 2022-06-23 07:45:30.058979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up arguments.
    action = ActionModule()
    action.__dict__['_task'] = {}
    action.__dict__['_task']["args"] = {}
    action.__dict__['_task']['args']["src"] = "test"
    action.__dict__['_task']['args']["dest"] = "test"
    action.__dict__['_task']['args']["content"] = "test"
    action.__dict__['_task']['args']["remote_src"] = True
    action.__dict__['_task']['args']["local_follow"] = True
    action.__dict__['_connection'] = {} 
    action.__dict__['_connection']['_shell'] = {}

# Generated at 2022-06-23 07:45:33.494089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.copy as copy_action
    mod = copy_action.ActionModule(None, None, None)
    assert(mod is not None)
    assert(isinstance(mod, copy_action.ActionModule))

# Generated at 2022-06-23 07:45:46.150591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(
        remote_src=False,
        local_follow=True,
        content=None,
        src=None,
        dest=None,
    )
    ptr = ActionModule(dict(args=args))
    ptr._loader = DictDataLoader()
    ptr._templar = Templar(loader=ptr._loader)
    ptr._connection = MagicMock()
    ptr._connection._shell.expand_user.side_effect = lambda x: x
    ptr._connection._shell.path_has_trailing_slash.side_effect = lambda x: False
    ptr._connection._shell.join_path.side_effect = lambda *x: '/'.join(x)

# Generated at 2022-06-23 07:45:58.043423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_connection = Mock()
    mock_loader = Mock()
    mock_task = Mock()
    mock_task.args = dict()
    mock_templar = Mock()

    mock_shared_loader_obj = Mock()
    mock_shared_loader_obj.module_loader = 'ansible.legacy.plugins.action.copy'
    mock_loader.action_loader = {'copy': mock_shared_loader_obj}

    # Call constructor
    try:
        copy_action_plugin = ActionModule(mock_connection, mock_loader, mock_templar, mock_task)
    except Exception as e:
        assert False, "Failed to create 'action.copy' plugin object: " + str(e)

    # Make sure member variables are initialized properly
    assert copy_action_plugin._connection == mock_connection


# Generated at 2022-06-23 07:46:07.907432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup config
    config = dict(DEFAULT_REMOTE_TMP='', DEFAULT_LOCAL_TMP='')

    # Setup args
    args = dict()

    # Setup task
    task = dict(action=dict(module='copy', args=args))

    # Setup connection
    class _connection:
        def __init__(self):
            self.shell = dict(tmpdir='/tmp')
        def _shell_quote(self, args):
            return '"' + args + '"'
    connection = _connection()

    # Setup play context
    play_context = dict(remote_addr='remote_addr', password='password', port='port')

    # Create action module and run it

# Generated at 2022-06-23 07:46:09.225147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert 'ActionBase' in str(type(module))

test_ActionModule()

# Generated at 2022-06-23 07:46:15.253817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_module_spec(None, '/path/to/copy.py', ANSIBLE_LIBRARY), dict(), False, '/path/to/action', 'copy', task_uuid='dummy_uuid')
    assert module is not None
    module = ActionModule(load_module_spec(None, '/path/to/copy.py', ANSIBLE_LIBRARY), dict(), False, '/path/to/action', 'copy', task_uuid='dummy_uuid')
    assert module is not None


# Generated at 2022-06-23 07:46:18.850393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(DEFAULT_LOCAL_TMP='/tmp'), 'copy')


# Generated at 2022-06-23 07:46:29.202171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a test of the constructor of class ActionModule."""
    # Setup the task that is being worked on
    task_ds = dict()
    task_ds['action'] = 'copy'
    task_ds['args'] = dict()
    task_ds['delegate_to'] = 'all'
    task_ds['delegate_facts'] = False
    task_ds['delegate_whom'] = None
    task_ds['register'] = 'ansible'
    task_ds['retries'] = 3
    task_ds['until'] = None

    # Initialize the action module
    action_module = NewActionModule(task_ds, None, task_vars=None, connection=None)
    assert action_module._task.action == 'copy'
    assert type(action_module._task.args) == dict
   

# Generated at 2022-06-23 07:46:34.042667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}

    task = DummyTask()
    task.args = args

    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.task_vars = {}
    action.action_vars = {}
    action._task = task

    action.run(None, None)

# Generated at 2022-06-23 07:46:45.794093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialization
    # Set module_loader to None
    module_loader_mock = MagicMock(name='module_loader_mock')
    module_loader_mock.get_basedir.return_value = '/basedir'
    task_vars = dict({'var': 'value'})
    task_vars_mock = MagicMock(name='task_vars_mock')
    task_vars_mock.copy.return_value = task_vars.copy()
    # Return value of function _create_tmp_path
    tmp_path_mock = MagicMock(name='tmp_path_mock')
    tmp_path_mock.dirname = 'dirname'

    # Create objects for testing.
    # Mock AnsibleTask object and its member variables (that will be used in constructor)

# Generated at 2022-06-23 07:46:57.693313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.copy import ActionModule
    import ansible.plugins.loader as plugin_loader
    import ansible.utils.vars as vars
    import ansible.inventory as inventory

    class Args(object):
        def __init__(self, args):
            self.args = args

        def __getitem__(self, key):
            return self.args[key]

    v = vars.VariableManager()
    i = inventory.Inventory(v)

    p = plugin_loader.find_plugin(None, 'copy')
    p = p.action_class(p._shared_loader_obj, '/tmp/foo', Args({'dest': '/tmp/bar'}), 'file_copy')

    assert type(p) == ActionModule

# Generated at 2022-06-23 07:47:08.483462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test of ActionModule'''
    # Create a mock 'connection' object
    conn_obj = mock.Mock()
    conn_obj.port = 22

    # Create a mock 'task' object
    mock_task = mock.Mock()
    mock_task.args = {'transport': 'ssh', '_ansible_diff': True, 'mode': '0600', 'path': '/etc/newfile', '_ansible_parsed': True, 'src': '/etc/newfile', 'content': 'Hello World'}

    # Create a mock 'loader' object
    loader_obj = mock.Mock()

    # Create a mock 'play context' object
    play_context = mock.Mock()
    play_context.check_mode = False

    # Create an object of ActionModule