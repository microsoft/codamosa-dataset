

# Generated at 2022-06-23 07:37:14.639330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    play_context = PlayContext()
    play_context.connection = 'local'

    # Instantiate an ActionModule
    t = action_loader.get('copy', play_context=play_context, loader=loader)
    assert t is not None

    # Test the method _create_tmp_path()
    t._create_tmp_path()
    assert t._connection._shell.tmpdir != ''

    # Test the method _remove_tmp_path()
    t._remove_tmp_path(t._connection._shell.tmpdir)
    assert t._connection._shell.tmpdir == ''

# Generated at 2022-06-23 07:37:24.966272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3

    # Pass fake connection to AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(required=True),
            content=dict(),
            dest=dict(required=True),
            remote_src=dict(type='bool', default=False),
            local_follow=dict(type='bool', default=True),
        ),
        add_file_common_args=True,
        supports_check_mode=True,
        mutually_exclusive=[['src', 'content']],
    )

    # Prepare arguments
    args = dict(
        src=u'/home/user/.bashrc',
        dest=u'/home/user/.bashrc',
    )

    # Initialize AnsibleModule

# Generated at 2022-06-23 07:37:29.558814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test class variables
    test_obj = ActionModule()
    test_obj._role = None
    test_obj._playbooks = []
    test_obj._task_name = 'test_task'
    test_obj._loader = DataLoader()
    test_obj._templar = Templar(loader=test_obj._loader)
    test_obj._task = Task(name='test',play_context={})
    test_obj._task.action = 'copy'

# Generated at 2022-06-23 07:37:41.489815
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.module_utils.basic
    import ansible.module_utils.connection
    import ansible.module_utils.network


    if not hasattr(ansible.module_utils.basic, 'AnsibleModule'):
        ansible.module_utils.basic.AnsibleModule = lambda: None

    if not hasattr(ansible.module_utils.connection, 'Connection'):
        ansible.module_utils.connection.Connection = lambda: None

    if not hasattr(ansible.module_utils.network, 'NetworkModule'):
        ansible.module_utils.network.NetworkModule = lambda: None


# Generated at 2022-06-23 07:37:47.492271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config.cfg.initialize()
    config.load_config_file()

    am = ActionModule(task=dict(action=dict(copy=dict()), args=dict(follow=True)))
    assert am.follow == True, "ActionModule follow is not True."

# Generated at 2022-06-23 07:37:56.424011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define local test function

    def test_inner(mocker, tmp_path_factory, module_implementation_pre_connection, connection_mock, tmpdir):
        # Create a test module
        module_data = to_bytes('{hostvars}')
        module_path = tmp_path_factory.mktemp('arg_test').joinpath('test_module.py')
        module_path.write_bytes(module_data)

        # Create a test task vars
        task_vars = dict(
            ansible_connection='local',
            ansible_inventory=dict(
                test_host=dict(
                    ansible_inventory_tmpdir=tmpdir,
                    ansible_inventory_tmpdir_used=False,
                )
            )
        )

        # Patch module_implementation.module_loader

# Generated at 2022-06-23 07:38:00.626992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    test_instance_of_ActionModule = ActionModule()

    assert (isinstance(test_instance_of_ActionModule, ActionModule))



# Generated at 2022-06-23 07:38:10.315575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.ext.legacy.plugin.action.copy import ActionModule
    from ansible.action.copy import ActionModule as LegacyActionModule
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    class MockConnection(object):
        def __init__(self, path_has_trailing_slash):
            self._path_has_trailing_slash = path_has_trailing_slash

        @property
        def shell(self):
            return MockShell(self._path_has_trailing_slash)


# Generated at 2022-06-23 07:38:21.589176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.from_user = False
    a.noop = False
    task_vars = { 'ansible_user': 'ansible_user'}
    result = {}
    content_tempfile = 'content_tempfile'
    source = 'source'
    dest = 'dest'
    module_executed = True
    source_files = {'files': [], 'directories': [], 'symlinks': []}
    a._task.args = {'dest': dest}
    assert result == a.run(task_vars=task_vars)
    a._task.args = {'content': 'content',
                    'dest': dest}
    result = a.run(task_vars=task_vars)
    assert 'failed' in result

# Generated at 2022-06-23 07:38:31.587007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.facts import ansible_local

    # Arrange
    _task = Mock()
    _task.args = {'src': None, 'content': None, 'dest': None, 'remote_src': False, 'local_follow': True}
    _loader = Mock()
    _connection = Mock()
    _shell = Mock()
    _connection._shell = _shell
    _task.args = {'src': None, 'content': None, 'dest': None, 'remote_src': False, 'local_follow': True}
    _task.args['content'] = None
    _task.args['src'] = None
    _task.args['dest'] = None
    _task.args['remote_src'] = False
    _task.args['local_follow']

# Generated at 2022-06-23 07:38:43.101594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = DummyConnection(None)
    action = ActionModule(connection=connection, play_context=None, new_stdin=None)

    assert action._task.action == 'copy'
    assert action._task._ds is None
    assert action._task.args is None
    assert action._task.dep_chain is None
    assert action._task.loop is None
    assert action._task.name == 'copy'
    assert action._task.notified_by is None
    assert action._task.post_validate is None
    assert action._task.uuid == 'copy'
    assert action._task.vars is None
    assert action._task.when is None
    assert action._task.cleanup is None
    assert action._task.always is None
    assert action._task.register is None
    assert action._task.first_

# Generated at 2022-06-23 07:38:44.422359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert(isinstance(module, ActionModule))
    assert(isinstance(module, ActionBase))


# Generated at 2022-06-23 07:38:51.571505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {})
    assert am.module_name == "copy"
    assert am.module_args is None
    assert am._connection is None
    assert am._task is None
    assert am._loader is None
    assert am.is_task is False
    assert am.task_vars is None
    assert am.tmp is None
    assert am.runner is None
    assert am.module_name == "copy"


# Generated at 2022-06-23 07:39:02.598085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = tempfile.mkdtemp()

    task_vars = dict(
        ansible_connection='fake_connection',
        ansible_play_hosts='fake_play_hosts',
        ansible_version='fake_version',
        ansible_ssh_user='fake_ssh_user'
    )

    # dict to hold fake connection info
    fake_connection_info = dict(
        host=dict(
            ipv4=dict(
                address='fake_ip'
            )
        ),
        port=22
    )

    file_module_instance = FakeFileModule(
        connection=dict(),
        module_name='fake_file_module',
        module_args=dict(),
        task_vars=task_vars,
        tmp=tmp
    )


# Generated at 2022-06-23 07:39:11.438631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if it works with undefined action.
    try:
        module = ActionModule(dict(action='dummy'))
        print(module.fail_json(msg='Dummy action test'))
    except Exception as e:
        print('Test exception: %s' % e)

    # Test if it works with undefined connection.
    try:
        module = ActionModule(dict(action='get_url', connection='dummy'))
        print(module.fail_json(msg='Dummy connection test'))
    except Exception as e:
        print('Test exception: %s' % e)

    # Test if it works with undefined environment.

# Generated at 2022-06-23 07:39:18.081643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def __init__(self):
            pass
    try:
        am = ActionModule()
        assert False
    except TypeError as e:
        assert str(e).find("Can't instantiate abstract class") != -1
    else:
        assert False
    am = TestActionModule()
    assert am

# Generated at 2022-06-23 07:39:28.640976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Mock()

    # We need a mock of connection._shell
    connection._shell = Mock()
    connection._shell.tmpdir = "tmpdir"
    connection._shell.join_path = lambda *args: os.path.join(*args)
    connection._shell.path_has_trailing_slash = lambda path: path.endswith("/")
    connection._shell.split_path_canonical = lambda path: (os.path.dirname(path), os.path.basename(path))

    # We need a mock of connection._shell.join_path
    connection._shell.join_path = os.path.join

    # We need a mock of connection._shell.split_path
    connection._shell.split_path = os.path.split

    # We need a mock of connection._shell.run
    connection._shell

# Generated at 2022-06-23 07:39:37.169338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_task(self):
        return dict(action=dict(module_name="copy", module_args=dict()))
    option_names = ['_original_file', '_original_basename', '_uses_shell', '_raw_params', '_binary_file']
    # TODO: Do we still need this?
    #loader_mock.get_real_file.return_value = 'lookup_file'
    display = Display()
    shell = Shell(in_data=b'', store_pid=False, err_data=b'')
    connection = Connection(shell)
    my_task = Task()
    my_task.action = 'my_action'
    my_task.args = dict()
    my_task._role = None
    my_task._task = dict()

# Generated at 2022-06-23 07:39:48.338475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct valid url's
    url_1 = 'https://example.com/src'
    url_2 = 'https://example.com/dir/'
    # Construct valid dictionary
    dest_dir = '/etc/dir/'
    dest_file = '/etc/dir/file'
    src = '/src'
    dest = '/dest'
    task = {'src': src, 'dest': dest}
    args = {'src': url_1, 'dest': dest_dir}
    result = {'content': 'content', 'content_tempfile': 'content_tempfile'}
    # Construct class
    action = ActionModule(task, args)
    # Construct private methods
    #_remove_tempfile_if_content_defined
    result['content'] = None

# Generated at 2022-06-23 07:39:50.647099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: add tests for the constructor
    # This is a test stub.
    pass

# Generated at 2022-06-23 07:39:54.641502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    acm = ActionModule(
        task=MagicMock(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert acm


# Generated at 2022-06-23 07:40:02.888933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.connection.paramiko_ssh as paramiko_ssh
    import ansible.plugins.action.copy as copy
    connection = paramiko_ssh.Connection()
    action = copy.ActionModule(connection=connection)
    assert action is not None


# Generated at 2022-06-23 07:40:12.700796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test old dict constructor
    module_args_dict = dict()
    action_module_dict = ActionModule(module_args_dict)
    assert action_module_dict.modules_for_shell.keys() == ['command']
    assert action_module_dict.modules_for_shell['command'] == 'sh'
    assert action_module_dict.action._connection_plugin.name == 'local'
    assert action_module_dict.action._connection_plugin._shell_type == 'command'

    # Test old dict constructor
    module_args_dict = dict(ANSIBLE_MODULE_ARGS={})
    action_module_dict = ActionModule(module_args_dict)
    assert action_module_dict.modules_for_shell.keys() == ['command']
    assert action_module_dict.modules_for_shell['command']

# Generated at 2022-06-23 07:40:19.071221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Mock()
    connection = Mock()
    connection.shell = Mock()
    connection.shell.path_has_trailing_slash = Mock()
    connection.shell.join_path = Mock()
    host.get_connection = Mock()
    host.get_connection.return_value = connection
    task = Mock()
    task._ds = Mock()
    task._ds.get = Mock()
    task.args = {'content': 'test_content', 'dest': 'test_dest'}
    self = ActionModule(task, connection, 'ansible.legacy.copy')
    assert self._execute_remote_stat(dest='test_dest', all_vars={}) == False

# Generated at 2022-06-23 07:40:30.253966
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:40:33.811072
# Unit test for constructor of class ActionModule
def test_ActionModule():

    shell_module = ShellModule()
    connection = Connection(shell_module)
    task = Task()
    action_module = ActionModule(task, connection, shell_module)
    assert action_module is not None

# Generated at 2022-06-23 07:40:40.946801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_file_name = '/tmp/file.txt'
    with open(tmp_file_name, 'w') as f:
        f.write("Hello World")

    try:
        task = AnsibleTask()
        connection = AnsibleConnection()
        result = ActionModule(task, connection).run({}, {'file_name': tmp_file_name})
        assert result['dest'] == '/tmp/file.txt'
        assert result['failed'] == False
        assert result['changed'] == False
    finally:
        os.remove(tmp_file_name)

ActionModule_run.__doc__ = ActionModule.run.__doc__
ActionModule_run()

# Generated at 2022-06-23 07:40:50.104839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #import os.path
    import os
    import tempfile
    from units.compat.mock import MagicMock, patch
    from units.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible.modules.copy import ActionModule as _ActionModule

    # Fixture object
    module_obj = _ActionModule()
    path = os.path.sep.join(["a", "b", "foo"])
    path_with_trailing_slash = os.path.join(path, '')
    partial_path = os.path.join("a", "b")

    # Create side_effect for use in mock patch
    tuple_to_dict = lambda x: [dict(src=y) for y in x]

    # Create side_effect for mock

# Generated at 2022-06-23 07:40:56.953968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('test')

    # _load_params() takes module_args as dict
    module._load_params({'dest': '/home/testuser/'})

    # Result should be changed
    assert module.run()['changed']


# Generated at 2022-06-23 07:40:58.202253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'foo' == 'foo'


# Generated at 2022-06-23 07:40:59.646166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 07:41:05.608864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    unit test for method run of class ActionModule
    '''
    action_module = ActionModule()
    # TODO: What is tmp ?
    tmp = "/tmp"
    task_vars = dict()

# Generated at 2022-06-23 07:41:21.327342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY2

    mock_shell = MagicMock()
    mock_shell.path_has_trailing_slash.__name__ = "_shell_path_has_trailing_slash"
    mock_shell.join_path.__name__ = "_shell_join_path"

    mock_task = MagicMock()
    mock_task.args = dict(dest="/home/test/testfile.txt", src="testfile.txt", content="testfile")
    mock_task.run_once = True

    mock_loader = MagicMock()

    mock_connection = MagicMock()
    mock_connection._shell = mock

# Generated at 2022-06-23 07:41:29.355578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the test.
    owner = 'owner'
    group = 'group'
    mode = '0755'
    file = '/path/to/file'
    dest = '/dest/path/to/file'

    # Create a mock action.

# Generated at 2022-06-23 07:41:38.544726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No args
    test_action_module = ActionModule()
    assert isinstance(test_action_module, ActionModule) is True
    # Arg: task and connection
    test_task = TestTask()
    test_connection = TestConnection()
    test_action_module_with_task = ActionModule(task=test_task, connection=test_connection)
    assert isinstance(test_action_module_with_task, ActionModule) is True


# Generated at 2022-06-23 07:41:47.723803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = Connection()
    load = TaskLoader(None)
    loader = DataLoader()

    host = MagicMock()
    task = Task()
    task._role = None
    task._role_name = None

    action = ActionModule(conn, task, load, loader, host)
    assert action._connection == conn
    assert action._task == task
    assert action._loader == load
    assert action._templar == loader
    assert action._shared_loader_obj == loader
    assert action._connection._shell.tmpdir == '/tmp'


# Generated at 2022-06-23 07:41:49.595074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_module_spec('ansible.legacy.copy', None))
    assert module is not None

# Generated at 2022-06-23 07:42:02.131788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor has no arguments, which is the general case.
    obj = ActionModule(1, 2, 3, None)
    assert obj.transport == 'local'
    obj = ActionModule(1, 2, '/usr/local', None)
    assert obj.transport == 'local'
    obj = ActionModule(1, 2, 'ssh:', None)
    assert obj.transport == 'ssh'
    obj = ActionModule(1, 2, '/usr/local', None)
    assert obj.transport == 'local'
    obj = ActionModule(1, 2, 'ssh:192.168.1.1', None)
    assert obj.transport == 'ssh'
    obj = ActionModule(1, 2, None, None)
    assert obj.transport == 'local'
    pass


# Generated at 2022-06-23 07:42:09.448634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = "/tmp/test_file"
    dest = "/tmp/test_file2"
    with open(source, "w") as f:
        f.write("Testing file module")
    task_vars = dict(
        transfer_method = "copy"
    )
    task = ActionModule(source, task_vars)
    res = task.run(task_vars=task_vars)
    if os.path.exists(dest):
        os.remove(source)
        os.remove(dest)
        assert res.get('dest') == dest
        assert res.get('src') == source
        assert res.get('changed') == True
    else:
        os.remove(source)
        assert res.get('dest') == dest
        assert res.get('src') == source
        assert res.get

# Generated at 2022-06-23 07:42:18.733844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a Mock task
    task = MockTask()
    task.args = {'src': 'src', 'dest': 'dest', 'recursive': True}

    # Create a Mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp/ansible-tmp-1482624378.32-197992100788667/'
    connection._shell.path_has_trailing_slash.return_value = False
    connection._shell.join_path.return_value = 'dest'

    # Create a Mock module
    module = MockModule()

    # Create a Mock os
    os = MockOs()
    os.path.join.return_value = 'dest'
    os.path.isdir.return_value = False
    os.path.basename.return_value = 'dest'

    # Create

# Generated at 2022-06-23 07:42:29.033563
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:42:39.050518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    module = ansible.legacy.modules.source_control.git.ActionModule(
        {'src': 'test.file1', 'dest': '/tmp/test.file2'},
        {}
    )

    # Test
    result = module.run()

    # Assertions
    assert result == {
        'changed': True,
        'dest': '/tmp/test.file2',
        'src': 'test.file1'
    }

    # Cleanup


# Generated at 2022-06-23 07:42:48.572027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert AC_ANSIBLE_MODULE_RUN_OBJ.run() == {'_ansible_parsed': True, '_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_version': 2.7, '_ansible_no_log_values': ['Redacted', 'Encrypted'], '_ansible_module_name': 'copy', '_ansible_module_setup': True, '_ansible_diff': False, '_ansible_module_cache': True, 'invocation': {'module_name': 'copy'}, 'ansible_loop_var': 'item'}


# Generated at 2022-06-23 07:42:55.420720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    host = '127.0.0.1'

    class MockTask:
        def __init__(self):
            self.args = dict(
                src='newfile.txt',
                dest='/tmp/newfile.txt',
            )

    class MockModule:
        def __init__(self):
            self._connection = None

    mock_task = MockTask()
    mock_module = MockModule()
    am = ActionModule(mock_task, mock_module._connection, 'loader', 'templar')

    am._make_tmp_path = lambda x: ''

    assert am.run(host, task_vars) == dict(
        failed=True,
        msg='dest is required',
    )


# Generated at 2022-06-23 07:42:56.553020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-23 07:42:59.802260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' _transfer_file.ActionModule() # Constructor Test '''

    action_module = ActionModule('task', 'play_context', 'loader', 'templar', 'shared_loader_obj')
    assert action_module is not None

# Generated at 2022-06-23 07:43:10.651994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.community.crypto.tests.unit.compat.mock import patch
    from ansible_collections.community.crypto.plugins.modules.crypto.file import ActionModule as crypto_file

    remote_user = os.environ['USER']
    remote_pass = None
    remote_port = None
    convert_data = b'\x80\x00'
    remote_port = None
    remote_conn = mock.Mock()
    remote_conn._shell.tmpdir = tempfile.gettempdir()
    class DummyTask(object):
        def __init__(self, args):
            self._args = args
    class DummyPlay(object):
        def __init__(self):
            self.connection = remote_conn

# Generated at 2022-06-23 07:43:12.290606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(None, None, None, None, None)
    assert isinstance(action_mod, ActionModule)


# Generated at 2022-06-23 07:43:23.275925
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:43:33.538722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a task UUID so we can use this for fetching the task from the ResultCallback and ResultCallback is invoked.
    task_uuid = uuid.uuid4()

    # Create a connection to use for the fetch of plugin_load_info
    connection = Connection('localhost')
    print('created connection')

    # Create a task
    task = Task()
    print('created task')

    # Create a container for the result of the action plugin
    result = dict(counter=0)
    print('created result container')

    # Create an argument container

# Generated at 2022-06-23 07:43:41.732945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(action=dict(module_name='test_module_name')), 'test_play', 'test_task')

    # Assert _task.
    assert action_module._task.action.module_name == 'test_module_name'
    # Assert _play.
    assert action_module._play.name == 'test_play'
    # Assert _task.
    assert action_module._task.name == 'test_task'
    # Assert _loaded_name.
    assert action_module._loaded_name == 'test_module_name'


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:43:56.807967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get a connection object
    conn = connection_loader.get('local', loader=None, basedir='/tmp/ansible_file_payload_test')
    # Get a module object
    am = ActionModule(connection=conn,
                      task_vars=dict(ansible_connection='local', ansible_user='root', ansible_port='22'),
                      loader=None, templar=None, shared_loader_obj=None)

    # Create our temp directory
    tmpdir = tempfile.mkdtemp()
    source_dir = os.path.join(tmpdir, 'source')
    makedirs(source_dir)
    source_file = os.path.join(source_dir, 'source_file.txt')
    touch(source_file)

    # Create the expected results

# Generated at 2022-06-23 07:44:04.721624
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeTask:
        def __init__(self):
            self.args = dict(
                src="src",
                dest="dest",
                content="content",
                raw="raw",
                checksum="checksum"
            )

        def __str__(self):
            return "FakeTask"

    class FakePlayContext:
        def __init__(self):
            self.become = "become"

        def __str__(self):
            return "FakePlayContext"

    class FakeLoader:
        def __init__(self):
            self.paths = "paths"

        def __str__(self):
            return "FakeLoader"

    class FakeDatastore:
        def __init__(self):
            self.hostvars = dict(hostvars="hostvars")


# Generated at 2022-06-23 07:44:06.407037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test for method run of class ActionModule
    assert True


# Generated at 2022-06-23 07:44:07.533021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

# Generated at 2022-06-23 07:44:15.820424
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:44:24.272627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("test_ActionModule")
    task = Mock()
    task.args = {'src': 'test_src', 'dest': 'test_dest'}
    connection = Mock()

    action_module = ActionModule(task, connection)

    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._task.args == {'src': 'test_src', 'dest': 'test_dest'}

# Generated at 2022-06-23 07:44:25.423133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 07:44:37.836470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    import ansible.module_utils.network.f5.f5_module_utils as f5_utils


    # Mock module
    module = AnsibleModule('dummy')

# Generated at 2022-06-23 07:44:51.137812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = DummyConnection()  # DummyConnection or TaskModule(DummyConnection, 'copy')?
    connection = host.mock_connection
    connection._shell.get_file_stat = lambda path: {'exists': True}
    connection._shell.join_path = lambda path1, path2: path1 + '/' + path2

    task_vars = {'ansible_check_mode': False}
    source = '/path/to/source'
    dest = '/path/to/dest'
    module_args = {
        'src': source,
        'dest': dest,
    }

    action_module = ActionModule(task=TaskModule(connection, 'copy'), connection=connection, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    #action_module

# Generated at 2022-06-23 07:45:05.436290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  src = None
  dest = None

# Generated at 2022-06-23 07:45:14.349009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    model = AnsibleCoreCI(
        # No AnsibleCore, but we are not testing that here
        connection=Connection(
            # No Transport, but we are not testing that here
            shell=Shell()
        )
    )

# Generated at 2022-06-23 07:45:25.040707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=DictDataLoader())
    action_module._connection = Mock()
    action_module._remove_tmp_path = Mock()
    action_module._ensure_invocation = Mock()
    action_module._execute_module = Mock()
    action_module._execute_module.return_value = dict()
    action_module._task = Mock()
    action_module._task.args = dict()

    # test default values
    expected = dict()

    # method run
    result = action_module.run(tmp=None, task_vars=None)

    assert result == expected

# Generated at 2022-06-23 07:45:27.930167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' action_plugins/copy.py:ActionModule() constructor test'''
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj

# Generated at 2022-06-23 07:45:37.710674
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:45:48.877525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import StringIO
    import ansible.legacy.file
    import ansible.legacy.copy
    import ansible.plugins.action
    #import ansible.plugins.action.copy
    import ansible.plugins.connection
    from ansible.vars.hostvars import HostVars
    import ansible.vars.manager
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.errors
    import ansible.utils.json
    #import ansible.utils.template
    #import time
    #import ansible.utils.loader
    #import ansible.utils.display
    #import ansible.utils.path
    import ansible.plugins
    #import ansible.playbook.role

# Generated at 2022-06-23 07:46:00.518317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a connection to a local dummy terminal and
    # connect it to a mock transport
    conn = Connection(None)
    conn._shell = mock.MagicMock()
    # create a dummy task to be sent to the connection
    task = Task(action=dict())
    task._role = mock.MagicMock()
    task.args = dict()
    # create a test ActionModule using the dummy connection and task
    action = ActionModule(conn, task, connection=conn, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    # use a mock for the subprocess_check_output function
    action._execute_module = mock.MagicMock()
    with pytest.raises(AnsibleActionFail):
        action.run(tmp=None, task_vars=None)


# Generated at 2022-06-23 07:46:05.365647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    # Test ArgSpec creation
    action = ActionModule(None, None)
    assert action._task.args.get('mode') is None


# Generated at 2022-06-23 07:46:08.122793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None)
    with pytest.raises(NotImplementedError):
        am.run()

# Generated at 2022-06-23 07:46:16.690570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    load_path = ['/path/to/ansible/lib/ansible/modules/core']

    def create_task(args):
        return dict(
            action=dict(
                module_stdout_callback="json",
            ),
            
            args=args,
        )


# Generated at 2022-06-23 07:46:27.258454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    from ansible.playbook.play_context import PlayContext

    conn = Connection(module_path='./mymodules')
    task = Task()
    context = PlayContext()
    context.connection = 'local'
    task.action = 'copy'
    task.args = {'src': 'myfile.txt'}
    task._connection = conn
    conn.task = task
    conn._shell.tmpdir = tempfile.mkdtemp()
    conn._shell.chdir()
    task.args = {'src': 'myfile.txt'}
    ansible_module = ActionModule(task=task, connection=conn, play_context=context)

    ansible_module.run(task_vars=dict())

# Generated at 2022-06-23 07:46:35.971024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict()
    args['args'] = dict()
    args['args']['src'] = 'foo'
    args['args']['dest'] = 'bar'
    args['args']['recursive'] = False
    args['task'] = dict()
    args['task']['hosts'] = 'host'
    args['task']['args'] = args['args']
    action_module = ActionModule(**args)
    assert action_module.action
    assert action_module._recursive
    assert action_module._task.args == args['task']['args']
    assert action_module.result
    assert action_module._dest
    assert action_module._src
    assert action_module._recursive
    assert action_module._action

# Generated at 2022-06-23 07:46:36.919440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return True

# Generated at 2022-06-23 07:46:47.283704
# Unit test for constructor of class ActionModule
def test_ActionModule(): # pylint: disable=too-many-locals
    ''' test ActionModule constructor '''

    # Simple fake ansible module parameters
    mock_ansible_params = dict(
        async_jid='1234567890',
        async_limit='testinventory',
        async_seconds='600',
        delegate_to=None,
        content=None,
        dest='/dev/null',
        directory_mode=None,
        follow=False,
        force=True,
        group='root',
        local_follow=True,
        mode='0600',
        owner='root',
        remote_src=False,
        src='/bin/testfile',
        selevel=None,
        serole=None,
        setype=None,
        seuser=None
    )

    # Set up mock module
    mock

# Generated at 2022-06-23 07:46:58.819230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    from ansible.playbook.task import Task

    import ansible.constants as C

    mytask = Task()
    mytask.name = 'mytest'
    mytask.args = {}
    mytask.action = 'test'
    setattr(mytask, '_role', C.DEFAULT_LOAD_CALLBACK_PLUGINS)

    connection = Dict()

    stdout = []
    cmd = (C.DEFAULT_MODULE_PATH, '', '')
    stdout.append(cmd)
    cmd = (u'bin/python', u'modules/test/test.py', '{"myarg":"myval"}')
    stdout.append(cmd)

    connection._shell.exec_command(cmd)

    connection._shell.join_

# Generated at 2022-06-23 07:47:01.308478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None,None)
    assert type(module).__name__ == 'ActionModule'

# Generated at 2022-06-23 07:47:09.920391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    callback = CallbackBase()
    loader = DataLoader()