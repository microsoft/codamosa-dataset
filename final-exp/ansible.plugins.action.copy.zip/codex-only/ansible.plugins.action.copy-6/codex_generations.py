

# Generated at 2022-06-23 07:37:04.070291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=None)

# Generated at 2022-06-23 07:37:05.257458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None)

# Generated at 2022-06-23 07:37:17.252079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_case_1():
        with patch('ansible.playbook.play_context.PlayContext') as play_context_mock:
            play_context_mock.return_value = 'test_play_context'

            transport = 'test_transport'
            connection = 'test_connection'
            tmp = 'test_tmp'
            module_name = 'test_module_name'
            module_args = 'test_module_args'
            task_vars = dict()

            # Non-recursive copy
            task_args = dict(recursive=False)
            action_module = ActionModule(play_context_mock, transport, connection, tmp, module_name, module_args, task_vars, task_args)
            assert action_module.connection == connection
            assert action_module.module_name == module

# Generated at 2022-06-23 07:37:26.879213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test run of class ActionModule'''
    import ansible.plugins.action as action
    inpt = {}
    am = action.ActionModule(inpt, {})

# Generated at 2022-06-23 07:37:40.180830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    from ansible_collections.ansible.community.tests.unit.compat.mock import DEFAULT, MagicMock, create_autospec, patch
    from io import BytesIO
    import tempfile

    tmp_path = tempfile.mkdtemp()
    filename = "sample.txt"
    file_abs_path = os.path.join(tmp_path, filename)
    file_txt = "test text"

    def _setup_mock_config(mock_config):
        mock_config.shell = 'test_shell'
        mock_config.executable = None

    _mock_connection = create_autospec(Connection)
    _mock_task = create_autospec(Task)
    _mock_task

# Generated at 2022-06-23 07:37:48.634838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ActionModule()
    action_module = ActionModule()
    assert action_module.DEFAULT_NEWLINE_SEQUENCE == '\n'
    assert action_module.DEFAULT_ERROR_ON_UNKNOWN_NODES == False

    # ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    # For now, just check that args are stored

# Generated at 2022-06-23 07:37:50.123728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None)
    assert mod is not None

# Generated at 2022-06-23 07:37:50.829057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:37:58.407947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_shell = type('FakeShell', (), {
        'path_has_trailing_slash': None,
        'join_path': None,
    })

    fake_task = type('FakeTask', (), {
        'args': {
            'src': None,
            'dest': None,
            'remote_src': False,
            'local_follow': True,
            'recurse': False,
            'regexp': None,
        },
    })()

    fake_connection = type('FakeConnection', (), {
        '_shell': fake_shell,
        '_shell.path_has_trailing_slash': None,
        '_shell.join_path': None,
        '_shell.tmpdir': None,
        'remove_tmp_path': None,
    })

    action_module = Action

# Generated at 2022-06-23 07:38:05.746092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    module_args = dict(
        src='/path/to/source',
        dest='/path/to/destination'
    )
    task = Task()
    task._role = None
    task._role_name = None
    task.args = module_args
    am = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(am, ActionModule)


# Generated at 2022-06-23 07:38:08.784191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule.
    action_module = ActionModule()

    # Test the class __init__ method.
    assert_equal(action_module._shared_loader_obj._basedir, '/')

if __name__ == '__main__':
    # Run the above unittest.
    from ansible.module_utils.basic import *
    run_tests(ActionModule)

# Generated at 2022-06-23 07:38:14.171533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {'src':'src_path', 'dest':'dest_path'}
    src_path, dest_path = task_args['src'], task_args['dest']
    task_vars = {'first_available_file':['file1', 'file2']}
    module_return={'changed':False, 'failed':False}
    module_args={'dest':'dest_path', 'copy':'copy', 'path':'dest_path', 'state':'directory', '_original_basename':'', 'follow':True, 'recurse':False, 'checksum':'checksum', 'mode':'mode'}
    source = 'source'
    content = 'test'
    source_rel = 'source_rel'
    task_vars = {}

# Generated at 2022-06-23 07:38:19.842917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.copy
    copy_module = ansible.plugins.action.copy.ActionModule('tmp', {}, False, 'some_prefix', 'some_body')
    setattr(copy_module, '_connection', MockConnection())
    setattr(copy_module, '_task', MockTask())
    setattr(copy_module, '_shared_loader_obj', MockLoader())
    setattr(copy_module, '_loader', MockLoader())
    setattr(copy_module, '_display', MockDisplay())
    setattr(copy_module, '_success_result', {})
    copy_module.run()

# Generated at 2022-06-23 07:38:24.896827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create dummy instance of module class.
    action_module = ActionModule(None, None)
    # Check ActionModule.run method.
    fake_result = action_module.run(tmp = None, task_vars = None)
    assert isinstance(fake_result, dict)

# Generated at 2022-06-23 07:38:34.042121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Cases:
    # source = dest = None
    # source = None, dest = "foo"
    # source = "bar" dest = None
    # source = dest != None
    # 1. content is None and remote_src is True
    # 2. content is not None and remote_src is False
    # 3. content is None and remote_src is False and dest is None
    # 4. content is not None and remote_src is False and dest is None
    # 5. content is None and remote_src is False and dest is not None
    # 6. content is not None and remote_src is False and dest is not None
    tmp = None
    task_vars = dict()

    source = None
    content = None
    dest = None
    module_return = dict(changed=False)
    remote_src = False
    a

# Generated at 2022-06-23 07:38:44.501440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialising mock values
    tmp=None
    task_vars={
        'key':'value',
        'key1':'value1',
    }

    # Initialising mock object
    mock_object=ActionModule(loader=None, task=None, connection=None, play_context=None, loader_class=None, templar=None, shared_loader_obj=None)

    # Calling run() to test the method
    mock_object.run(tmp=tmp, task_vars=task_vars, )

    # Asserting values
    assert mock_object.templar.template.call_count == 2
    assert mock_object.templar.template.call_args_list[0] == mock.call(content=None)
    assert mock_object.templar.template.call_args_list

# Generated at 2022-06-23 07:38:45.768097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert isinstance(m, ActionModule)


# Generated at 2022-06-23 07:38:56.489072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    data_file = os.path.join(os.path.dirname(__file__), 'data', 'file_action')
    filename = 'foo'
    filedir = os.path.join(data_file, 'files')
    srcfile = os.path.join(filedir, filename)
    dest = os.path.join(data_file, filename)

    module_task = dict(
        action='file',
        src=srcfile,
        dest=dest,
        follow=True,
        checksum=True,
        state='touch',
    )
    loader = DictDataLoader(dict())

    t = Task()
    t.args = module_task

    ti = TaskExecution(None)
    a = ActionModule(ti, loader=loader)


# Generated at 2022-06-23 07:39:05.177821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    
    #
    # Create test object.
    #
    module = ActionModule('test', '/home/username/ansible_test/ansible/modules/core', 'test_modules')

    #
    # Run test and verify results.
    #
    result = module.run(None, None)
    assert False

    #
    # We should never get here, because one of the preceding asserts will have
    # thrown an exception.
    #
    raise RuntimeError("Reached unreachable code")

# Generated at 2022-06-23 07:39:15.032391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmppath'
    remote_src = False
    local_follow = False
    source = None
    content = None
    dest = 'tmppath'
    module_executed = False
    implicit_directories = set()
    source_files = {'files': [], 'directories': [], 'symlinks': []}
    changed = False
    target_path = None
    dest_path = 'tmppath'
    module_return = dict(changed=False)
    paths = None
    dir_path = ''
    new_module_args = dict()
    trailing_slash = False
    follow = False
    module_return = None
    dest_path = 'tmppath'
    src = None
    local_follow = False
    content_tempfile = None
    source = 'tmppath'

# Generated at 2022-06-23 07:39:26.935397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import inspect
    import mock
    import os
    import shutil
    import tempfile

    import ansible.plugins.action
    import ansible.plugins.action.copy
    import ansible.utils
    import ansible.modules.files
    import ansible.modules.files.file

    assert hasattr(ansible.modules.files, 'file')
    assert inspect.isclass(ansible.modules.files.file.ActionModule)

    assert hasattr(ansible.plugins.action, 'copy')
    assert inspect.isclass(ansible.plugins.action.copy.ActionModule)

    with tempfile.NamedTemporaryFile(mode='wb') as f:
        temporary_file = f.name
        assert temporary_file.endswith('.tmp')
        assert os.path.exists(temporary_file)

       

# Generated at 2022-06-23 07:39:41.634684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader

    module_loader = DictDataLoader(dict())
    play_context = PlayContext()
    templar = Templar(loader=module_loader)

# Generated at 2022-06-23 07:39:51.346354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' unit test for ActionModule class '''
    import ansible.plugins.action.copy_legacy
    import ansible.executor.task_result
    import ansible.module_utils.basic
    import ansible.plugins.loader

    base = ansible.plugins.action.copy_legacy.ActionModule(
        task=dict(args=dict(dest='/tmp/test_dest', src='/tmp/test_src')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-23 07:39:52.383973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:40:05.526940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test_new_task')
    assert am._task is not None
    assert am._loader is not None
    assert am._templar is not None
    assert am._shared_loader_obj is not None
    assert am._connection is not None
    assert am._play_context is not None
    assert am._loader.get_basedir() == 'test_new_task'


from ansible.module_utils.six.moves import cStringIO as StringIO

from ansible.plugins.action.copy import ActionModule as CopyActionModule
from ansible.plugins.action.file import ActionModule as FileActionModule



# Generated at 2022-06-23 07:40:15.003563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case: Constructor without a task
    try:
        action = ActionModule(None)
    except ansible.errors.AnsibleError:
        pass
    except Exception as err:
        raise AssertionError('Unexpected exception raised: %s' % repr(err))
    else:
        raise AssertionError('AnsibleError not raised')

    # Test case: Constructor with a task
    task = dict(action=dict(module_name='copy'))
    action = ActionModule(task)
    assert action is not None

    # Test case: Constructor with a task and play_context
    task = dict(action=dict(module_name='copy'))
    action = ActionModule(task, play_context=ansible.playbook.PlayContext())
    assert action is not None

# Generated at 2022-06-23 07:40:26.143873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    class MockTaskExecutor(object):
        def __init__(self, dummy_task):
            self._task = dummy_task

    class MockTask(object):
        def __init__(self, dummy_task_args):
            self._task_executor = MockTaskExecutor(self)
            self.args = dummy_task_args
            self._role = None
            self._role_path = None

        def __getattr__(self, name):
            if name == '_role':
                return None
            if name == '_role_path':
                return None
            raise AttributeError(name)

    class MockPlay(Play):
        def __init__(self):
            self.name = None

# Generated at 2022-06-23 07:40:31.637314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    copy_task = dict(
        action=dict(
            module='copy',
            src='/source',
            dest='/dest',
            recurse=True
        )
    )

    task_vars = dict()

    def execute_module_mock(self, module_name, module_args, task_vars):
        if module_name == 'ansible.legacy.copy':
            return dict(changed=False, failed=False, dest='/dest')
        elif module_name == 'ansible.legacy.file':
            return dict(changed=False, failed=False, path='/dest')

    class LoaderMock(object):
        pass

    loader_mock = LoaderMock()


# Generated at 2022-06-23 07:40:38.733892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play_context
    import ansible.utils.plugin_docs
    import ansible.utils.template

    c = ansible.playbook.play_context.PlayContext()
    ds = ansible.utils.plugin_docs.get_docstring(ActionModule, verbose=False)
    t = ansible.utils.template.AnsibleTemplate()
    am = ActionModule(c, t, ds, 'testhost', None)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:40:39.959067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict())
# End of unit test

# Generated at 2022-06-23 07:40:44.770341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    shell = Shell()
    connection = Connection(shell)
    task = Task('copy', dict(dest=None, src=None))
    assert isinstance(ActionModule(task, connection), ActionModule)

# Generated at 2022-06-23 07:40:53.059602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = ActionModule(dict(dest='/tmp'))
    # We change the method _find_needle so it always returns a file.
    ac._find_needle = lambda x, y: '/tmp/test_file'
    res = ac.run()
    assert res.get('failed')
    assert 'src' in res.get('msg')
    assert res.get('exception') is None

    ac = ActionModule(dict(dest='/tmp', src='test_file'))
    # We change the method _find_needle so it always returns a file.
    ac._find_needle = lambda x, y: '/tmp/test_file'
    res = ac.run()
    assert not res.get('failed')
    assert 'path' in res
    assert res.get('exception') is None


# Generated at 2022-06-23 07:41:04.387366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_stub_for_ActionModule = AnsibleModuleStub()

    action_module = ActionModule(
        connection=ansible_stub_for_ActionModule,
        task=(),
        task_vars=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # running run with no arguments should be ok
    result = action_module.run()
    assert result.get('failed') == False

    # check the case of no src or content args
    result = action_module.run(
        tmp='/tmp',
        task_vars={'foo': 'bar'}
    )
    assert result.get('failed') == True
    assert result.get('msg') == 'src (or content) is required'

    # check the case of no dest

# Generated at 2022-06-23 07:41:07.248479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")

    # FIXME: Need to mock things to get this working
    action_module = None
    tmp = None
    task_vars = None
    action_module.run(tmp, task_vars)

# Generated at 2022-06-23 07:41:22.837226
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    task_vars = dict()
    tmp_path = _prepare_tmp_path(self._connection, self._task.args)
    from ansible import constants as C
    source = './tests/unicode_string'
    content = None
    dest = '/tmp/unicode_string'
    remote_src = False
    local_follow = True
    if task_vars is None: task_vars = dict()
    result = super(ActionModule, self).run(tmp, task_vars)
    del tmp  # tmp no longer has any effect

    # Exercise
    result['failed'] = True
    if not source and content is None:
        result['msg'] = 'src (or content) is required'
    elif not dest:
        result['msg'] = 'dest is required'

# Generated at 2022-06-23 07:41:33.627035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test the overridden constructor
    task_vars = dict(
        ansible_ssh_user='test',
        ansible_ssh_pass='test',
    )
    action = ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.update_task_vars(task_vars)
    assert action._play_context.become
    assert action._play_context.become_method == 'sudo'
    assert action._play_context.become_user == 'root'
    assert action._play_context.remote_addr == 'test'


# Generated at 2022-06-23 07:41:46.690313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    task_vars = dict()
    source = None
    content = None
    dest = None
    remote_src = False
    local_follow = True
    action_module = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=MagicMock(),
                                 templar=MagicMock(), shared_loader_obj=None)
    action_module._loader = DictDataLoader({})
    action_module._shared_loader_obj = MagicMock()
    tmp = None
    # Set up for magic mock to return the value
    values_to_return = dict()
    values_to_return['run'] = dict(failed=True, msg='src (or content) is required')

# Generated at 2022-06-23 07:41:48.236437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False, "Test not implemented"


# Generated at 2022-06-23 07:42:00.150655
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    remote_user = 'root'
    remote_pass = ''
    remote_port = 2200
    remote_host = '192.168.0.56'

    src = '/tmp/test_ActionModule_run/src'
    dest = '/tmp/test_ActionModule_run/dest'
    file_content = 'a' * 1024

    # create the local src files and directories
    create_local_dir(src)
    create_local_dir(src + '/foo')
    create_local_dir(src + '/foo/bar')
    create_local_dir(src + '/bar')
    create_local_dir(src + '/bar/foo')

    create_local_file(src + '/test1', content='a' * 1024)
    #create_local_file(src + '/test1', content=file_content)

# Generated at 2022-06-23 07:42:06.968774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'testhost'
    task = dict(action=dict(module_name='copy', module_args={}))

# Generated at 2022-06-23 07:42:08.470264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-23 07:42:18.300758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Should execute the action of the module'''
    module_args = dict(
        remote_src=False,
        local_follow=True,
        dest='',
        src='',
    )

# Generated at 2022-06-23 07:42:26.528477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = dict(msg=None)
    args = dict(src='src', dest='dest')
    task_vars = dict()
    action_plugins_dir = 'action_plugins_dir'
    connection = 'connection'
    executor = 'executor'
    tmp = 'tmp'
    result_updater = 'result_updater'
    dataset = dict(
        action_plugins_dir=action_plugins_dir,
        connection=connection,
        executor=executor,
        tmp=tmp,
        result_updater=result_updater,
        results=results
        )

    action = ActionModule(task=object(), connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=None)

# Generated at 2022-06-23 07:42:27.140984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:42:35.180631
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = dict()
    fake_loader = DictDataLoader({})
    tasks = [dict(action=dict(module='copy'))]

    play_context = PlayContext()
    play = Play().load(tasks, variable_manager=VariableManager(), loader=fake_loader, play_context=play_context)

    tqm = None
    connection = Connection('ssh')

    plugin = ActionModule(task=play.tasks[0], connection=connection, play_context=play_context, loader=fake_loader, templar=None, shared_loader_obj=None)

    # test _execute_module
    res = plugin._execute_module(module_name='ansible.legacy.copy', module_args=dict(), task_vars=task_vars)

# Generated at 2022-06-23 07:42:46.794451
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(load_plugins=False,
                          runner_queue=None,
                          host=None,
                          new_stdin='null',
                          connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None,
                          # initial values for testing
                          task=dict(args=dict(src='/tmp/source', dest='/tmp/dest'))
                         )
    assert isinstance(module, ActionModule)
    assert module._copy is not None
    assert module._transfer_files == []
    assert module._templar is not None
    assert module._task_vars is None
    assert module._loader is not None
    assert module._connection is not None
    assert module._play_context is not None

# Generated at 2022-06-23 07:42:51.778007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(required=True),
            dest=dict(required=True),
            original_basename=dict(),
            directory_mode=dict(),
            checksum=dict(),
        ),
        supports_check_mode=True
    )
    am = ActionModule(None, module)
    assert am is not None

# Generated at 2022-06-23 07:42:54.137877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-23 07:43:00.166565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        action=dict(module='copy')
    )
    connection = DummyConnection()
    play_context = PlayContext()
    taskvars = dict()
    temppath = 'testpath'
    connection.tmpdir = temppath
    runner = ActionModule(task, connection, temppath, play_context, taskvars)
    assert runner.transfers == 'smart'

## Unit test for _create_remote_file_args of class ActionModule

# Generated at 2022-06-23 07:43:06.181095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_shell_obj = FakeShellModule()
    test_action_module = ActionModule(shell=test_shell_obj, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_action_module._display.verbosity == 3

test_ActionModule()


# Generated at 2022-06-23 07:43:18.738479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test method run of class ActionModule
    (ansible.plugins.action.copy.ActionModule).

    Tests with no exception raised.
    '''
    test_obj = action_plugin.ActionModule(
        task=Task(), connection=Connection(), play_context=PlayContext(),
        loader=DictDataLoader(), templar=Templar(), shared_loader_obj=None)

    _task = MagicMock()
    test_obj._task = _task

    _connection = MagicMock()
    test_obj._connection = _connection

    _loader = MagicMock()
    test_obj._loader = _loader

    _execute_module = MagicMock(return_value=dict(changed=True))
    test_obj._execute_module = _execute_module

    tmp = None
    task_vars = dict()


# Generated at 2022-06-23 07:43:29.723881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._display.verbosity = 2
    action_module._options = {'connection': 'ssh',
                              'module_path': '/dummy',
                              'forks': 5,
                              'become': False,
                              'become_method': 'sudo',
                              'become_user': None,
                              'check': False,
                              'remote_user': 'ansible',
                              'private_key_file': None,
                              'ssh_common_args': '',
                              'ssh_extra_args': '',
                              'sftp_extra_args': '',
                              'scp_extra_args': '',
                              'become_flags': '-H',
                              'diff': False}
    action_module._task

# Generated at 2022-06-23 07:43:36.059882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test set up

    # Initialise TestActionModule instance
    action_module = TestActionModule()

    # Test execution

    # On exception, test fails
    # with error message and stack trace
    try:
        action_module.run()
    except Exception as err:
        print(err)
        print(traceback.format_exc())
        assert False

# Unit test run
test_ActionModule_run()
 

# Generated at 2022-06-23 07:43:40.461642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    out = action.run(task_vars=None)
    assert out == {u'msg': u'dest is required'}


# Generated at 2022-06-23 07:43:47.431620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test case for constructor of ActionModule class
    """
    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockConnection(object):
      def __init__(self, _shell):
          self._shell = _shell

      class Shell(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

    config = { }
    action_mod = ActionModule(MockTask(dict()), MockConnection(MockConnection.Shell(tempfile.gettempdir())), config)
    assert action_mod.tmp == tempfile.gettempdir()

# Generated at 2022-06-23 07:43:58.862722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create the config file
    if os.path.exists('/tmp/test-cfg'):
        shutil.rmtree('/tmp/test-cfg')
    config = ConfigParser.SafeConfigParser()
    config.add_section('defaults')
    config.set('defaults', '_ansible_verbosity', '3')
    config.add_section('privilege_escalation')
    config.set('privilege_escalation', 'become', 'False')
    config.set('privilege_escalation', 'become_method', 'sudo')
    config.set('privilege_escalation', 'become_user', 'root')
    config.set('privilege_escalation', 'become_ask_pass', '')
    config.add_section('ssh_connection')

# Generated at 2022-06-23 07:44:12.893812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    valid_args = dict()
    valid_args['src'] = 'source'
    valid_args['dest'] = 'destination'
    valid_args['recurse'] = False
    valid_args['backup'] = False
    valid_args['force'] = False
    valid_args['validate'] = 'md5'
    valid_args['directory_mode'] = None
    valid_args['follow'] = False
    valid_args['original_basename'] = 'source'
    valid_args['copy_remote_src'] = False
    valid_args['local_follow'] = True
    valid_args['content'] = 'content'
    valid_args['remote_src'] = False
    valid_args['checksum'] = None
    valid_args['mode'] = None



# Generated at 2022-06-23 07:44:23.275147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test checks the constructor and the prepare method
    # of class ActionModule

    # Create a mock to replace the connection plugin
    # This test does not check the connection plugin
    mock_connection = MagicMock()

    # Create a mock to replace the loader plugin
    # This test does not check the loader plugin
    mock_loader = MagicMock()

    # Create a mock to replace the templar plugin
    # This test does not check the templar plugin
    mock_templar = MagicMock()

    mock_task = MagicMock()

# Generated at 2022-06-23 07:44:26.108626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)

    assert isinstance(module, ActionModule)


# Generated at 2022-06-23 07:44:38.513055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_cfg = dict(defaults=dict(remote_tmp='/var/lib/awx_${USER}/tmp', remote_user='remote_user_value'))
    connection_cfg = dict(connection_type='local')
    task_args = dict(dest='/var/lib/awx_remote_user_value/tmp/tmpjKvDhM/test.txt', content='0'*1024, follow=True, src='/var/lib/awx_remote_user_value/tmp/tmpjKvDhM/test.txt', remote_src=False, directory_mode=None, _original_basename='test.txt')
    # Arguments used to create an instance of ActionModule

# Generated at 2022-06-23 07:44:41.156099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({}, {}, 'file', 'file', 'file', 'file', True, False)
    assert action_module.connection.connection_info == {}

# Generated at 2022-06-23 07:44:54.522321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_file_module_utils_module_1 = Mock()
    ansible_file_module_utils_module_1.__name__ = 'ansible.module_utils.file'
    ansible_file_module_utils_module_2 = Mock()
    ansible_file_module_utils_module_2.__name__ = 'ansible.module_utils.file'
    ansible_file_module_utils_module_2.configuration.rcpath = '/Users/u.kakava/ansible_collections/ansible/builtin/modules/file/ansiballz_file/data/ansible/file/.ansible_module_generated'

    ansible_module_utils_module_1 = Mock()
    ansible_module_utils_module_1.__name__ = 'ansible.module_utils'


# Generated at 2022-06-23 07:45:06.797837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import tempfile

# Generated at 2022-06-23 07:45:12.354172
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeModule:
        pass

    class FakeTask:
        def __init__(self, args):
            self.args = args

    class FakePlayContext:
        def __init__(self, check=False, diff=False):
            self.check_mode = check
            self.diff = diff

    class FakeLoader:
        def load_from_file(self, path, **kwargs):
            return path

        def get_basedir(self, **kwargs):
            return os.path.dirname(__file__)

    def fake_execute_module(**kwargs):
        module_args = kwargs['module_args']
        module_name = kwargs['module_name']


# Generated at 2022-06-23 07:45:25.898809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    step = {
        "module_name": "ansible.legacy.copy",
        "module_args": {
            "mode": None,
            "checksum": None,
            "content": None,
            "recursive": True,
            "remote_src": True,
            "local_follow": True,
            "dest": "",
            "src": ""
        },
        "loop": None,
        "name": "Copy Ansible inventories to working dir",
        "when": True
    }

# Generated at 2022-06-23 07:45:33.300878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = AnsibleModule(
        argument_spec = dict(
            src = dict(type='path', required=False),
            content = dict(),
            dest = dict(type='path', required=True),
        ),
        add_file_common_args = True,
    )
    action_module.check_mode = True
    action_module.no_log = True
    action_module.run()

# Generated at 2022-06-23 07:45:35.372371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the TaskExecutor.
    task_executor = ActionModule()

    assert isinstance(task_executor, ActionModule)

# Generated at 2022-06-23 07:45:43.268352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that we create an ActionModule with a task
    action = ActionModule(Task())

    # Check for module name
    try:
        import ansible.plugins
        name = 'ansible.plugins.action.copy'
    except ImportError:
        from ansible.runner import action_plugins
        name = 'ansible.runner.action_plugins.copy'

    assert action._module_name == name, 'ActionModule.__init__() did not set `_module_name`'

# Generated at 2022-06-23 07:45:52.688357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test ActionModule class'''

    import errno
    import os
    import shutil
    import tempfile

    import ansible.plugins.action

    # Store the original values of AnsibleModule
    original_AnsibleModule = ansible.plugins.action.AnsibleModule
    original_display = Display()

    # Setup some fake environment variables
    temp_dir = tempfile.mkdtemp()
    os.environ['HOME'] = temp_dir
    os.environ['USER'] = 'user'
    os.environ['ANSIBLE_CONFIG'] = os.devnull
    os.environ['ANSIBLE_CALLBACK_PLUGINS'] = os.devnull
    os.environ['ANSIBLE_CALLBACK_WHITELIST'] = os.devnull

# Generated at 2022-06-23 07:46:02.036308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # use a connection from playbook1 to simulate playbook2
    playbook1_class = AnsiblePlaybook()
    playbook1_class._load_playbook_from_file('./test/playbook1.yml')
    connection = playbook1_class._tasks[0].action._connection
    task = AnsibleTask(playbook1_class._tasks[0].action._task)
    task._task_fields['connection'] = connection
    task._task_fields['_role_path'] = '/test/test_data/test_roles/role1'
    task_vars = dict()

# Generated at 2022-06-23 07:46:05.150423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module.transfer_files, transfer_files)

# Generated at 2022-06-23 07:46:06.631501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 07:46:13.948758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test method run of class ActionModule"""
    task_args = {'src': '/path/to/source', 'dest': '/path/to/dest'}
    task_vars = {'temp_path': '/temp/path', 'remote_user': 'user'}
    action = ActionModule(task=MockTask(args=task_args), connection=MockConnection(shell=MockShell()), loader=MockLoader())
    result = action.run(task_vars=task_vars)
    assert result['failed'] == True


# Generated at 2022-06-23 07:46:27.021164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_loader = DictDataLoader({})
    fake_stdout = StringIO()
    fake_display = Display()

    def fake_get_task_vars(x, y):
        return {}

    real_get_task_vars = TaskExecutor._get_task_vars
    TaskExecutor._get_task_vars = fake_get_task_vars


# Generated at 2022-06-23 07:46:36.077528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockConnection:
        def __init__(self):
            self.tmpdir = 'tmpdir'
            self._shell = MockShell()

        def _shell_quote(self, s):
            return s

        def _shell_quote_paths(self, paths):
            return paths

        def _shell_escape_paths(self, paths):
            return paths

        def _get_file_stat(self, path):
            class TempFileStat:
                def __init__(self, do_local=False):
                    self.st_size = 0
                    self.st_mtime = 0
                    self.st_mode = 0
                    self.st_uid = 0
                    self.st_gid = 0
                    self.ex_mode = 0

            if path.endswith('/not_here'):
                raise Ans

# Generated at 2022-06-23 07:46:46.956667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for ActionModule class
    """
    action_plugin_class = ActionModule
    action_plugin_class.append_plugin_dir(dest=os.path.join(os.path.dirname(__file__), '../test/test_action_plugins'))
    action_plugin_class.append_plugin_dir(dest='/home/np/test_action_plugins')
    task = dict(
        action=dict(
            module='test_action',
            args=dict(
                test_val=1
            )
        )
    )

    display = dict()
    tmp = tempfile.mkdtemp()

# Generated at 2022-06-23 07:46:58.590614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the module object
    ActionModule = copy.ActionModule(
        MockTask(),
        MockConnection(),
        '/path/to/tmp',
        'remote',
        False
    )

    # Create the arguments to be passed to the module
    valid_args = {
        'src': '/path/to/src'
    }

    # Mock the Python built-in module os
    mock_os = MagicMock()

    # Mock the Python built-in module tempfile
    mock_tempfile = MagicMock()

    # Mock the Python built-in module traceback
    mock_traceback = MagicMock()

    # Mock the Python built-in module json
    mock_json = MagicMock()

    # Mock the Python built-in module os.path

# Generated at 2022-06-23 07:47:08.482190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor test for class ActionModule.
    '''

    # Initialize class object
    action_module = ActionModule()

    # Mock class test variables
    action_module._task_vars = dict()
    action_module._tmp_path = 'test_tmp_path'
    action_module._loader = 'test_loader'
    action_module._shared_loader_obj = 'test_shared_loader_obj'

    # Constructor test assertion(s)
    assert action_module._task_vars == dict()
    assert action_module._tmp_path == 'test_tmp_path'
    assert action_module._loader == 'test_loader'
    assert action_module._shared_loader_obj == 'test_shared_loader_obj'