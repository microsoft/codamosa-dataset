

# Generated at 2022-06-23 07:37:14.597646
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test action
    action = ActionModule(None, None, {})

    # Test function
    @mock.patch.multiple(action, _execute_module=mock.DEFAULT, _find_needle=mock.DEFAULT, _copy_file=mock.DEFAULT, _remove_tmp_path=mock.DEFAULT)
    def test(mocks, tmp=None, task_vars=None):

        # Create mocks
        if not task_vars:
            task_vars = {}
        content_tempfile = None

        # Call function
        result = action.run(tmp, task_vars)

        # Assertion
        assert not result.get('failed')


    test()


# Generated at 2022-06-23 07:37:24.925838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors

    from mock import patch, Mock, MagicMock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.executor.task_result import TaskResult

    am = ActionModule(Mock(), dict(dest='dest'), Mock())
    am._loader.get_basedir = Mock(return_value='/tmp')
    am._ansible_tmpdir = Mock(return_value='/tmp/ansible')
    am._remove_tmp_path = Mock()
    am._make_tmp_path = Mock()
    am._execute_module = Mock(return_value={})
    am._find_needle = Mock(return_value='src')
    am._rel_symlink = Mock()
    am._cleanup = Mock()

# Generated at 2022-06-23 07:37:31.365765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # FIXME: assert something
    my_am = ActionModule()
    my_am.setup_copy_module()
    my_am.setup_file_module()
    my_am.run({'tmp': '/tmp'}, {})

# Generated at 2022-06-23 07:37:40.278092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(a=1), is_playbook=False)
    assert action.boolean is not None, 'boolean object init failed'
    assert action.boolean(True) is True, 'boolean object translate True failed'
    assert action.boolean(False) is False, 'boolean object translate False failed'
    assert action.boolean('True') is True, 'boolean object translate True failed'
    assert action.boolean('False') is False, 'boolean object translate False failed'
    assert action.boolean('foo') is None, 'boolean object translate None failed'


# Generated at 2022-06-23 07:37:44.498290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' return_value, exception = test_ActionModule()
    '''
    return_value = None
    exception = None

    try:
        # Run the constructor of class ActionModule
        action = ActionModule('', '', {})
    except Exception as err:
        exception = err

    return return_value, exception


# Generated at 2022-06-23 07:37:54.659142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# ===== END action_plugins/copy.py =====
# ===== BEGIN action_plugins/template.py =====

# Copyright (c) 2012, Walter Dolce <walterdolce@gmail.com>
# Copyright (c) 2012, Seth Vidal <skvidal@fedoraproject.org>
# Copyright (c) 2014, Jeroen Hoekx <jeroen@hoekx.be>
# Copyright (c) 2018 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible import constants as C
from ansible.errors import AnsibleError

# Generated at 2022-06-23 07:38:07.019129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor 'ActionModule' of class ActionModule is tested here
    # a sample 'task' is defined here
    task = dict(
        args = dict(
            content = None,
            dest = '/home/user/abc.txt',
            remote_src = True,
            local_follow = True,
            src = '/home/user/abc.txt'
        )
    )

    # a sample 'connection' is defined here
    connection = object()

    # a sample 'tmp' is defined here
    tmp = '/home/user/sample'

    # a sample 'task_vars' is defined here

# Generated at 2022-06-23 07:38:09.361903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(dict(ANSIBLE_MODULE_ARGS={}), {}, False, False)
    assert hasattr(module, '_tmp_path')

# Generated at 2022-06-23 07:38:14.728604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Tests ActionModule (constructor)
    '''

# Generated at 2022-06-23 07:38:21.254084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 07:38:31.494369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config.load_config_file()
    config.initialize_legacy_templating()
    task_args = dict(dest="/tmp/test_file", content="foo", remote_src=False)
    # TODO: paramiko_connection.Connection
    connection = paramiko_connection.Connection(None)
    connection.transport = paramiko.Transport(None)
    task_action = ActionModule(task_args, connection)
    tmp_file = tempfile.mkstemp()

# Generated at 2022-06-23 07:38:32.428543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("")

# Generated at 2022-06-23 07:38:43.642941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    play_context = PlayContext()
    play_context.connection = 'ssh'
    play_context.network_os = 'junos'
    play_context.remote_addr = 'unittest'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'root'

    def get_task_vars(task_vars):
        return task_vars
    # Create task for test
    task = Task()
    task.args = {'remote_src': 'true'}
    task.action = 'copy'
    task.async_val = 15
    task.delegate_to = 'other'
    task.environment = {'UNITTEST': 'TEST'}
    task.first_available_file = 'test1'

# Generated at 2022-06-23 07:38:54.704209
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:39:05.068397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    ActionModule class is used by the controller and should not interact
    with the execution environment.
    """
    class MockExecutor:
        def get_module_args(self, *args, **kwargs):
            return dict()

        def run_command(self, *args, **kwargs):
            return dict(
                stdout='',
                stderr='',
                rc=0,
                cmd='',
                stdout_lines='',
                stderr_lines='',
                started=0,
                ended=0,
                delta=0
            )

        def _transfer_data(self, *args, **kwargs):
            pass

        def transfer_file(self, *args, **kwargs):
            pass

    class MockTask:
        def __init__(self):
            self.args = dict

# Generated at 2022-06-23 07:39:12.983398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test whether the class constructor works properly.
    '''
    unittest.TestCase()
    task = Mock()
    task.args = {}
    inject = dict(ansible_connection="winrm",
                  ansible_connection_user='Administrator',
                  ansible_connection_password='secret',
                  ansible_winrm_server_cert_validation='ignore',
                  __salt__={
                        'config.get': lambda x: 'C:\\salt'
                  })

    am = ActionModule(task, inject)
    assert am._shell.SHELL_FAMILY == "powershell"

# Generated at 2022-06-23 07:39:18.467467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection_terms = dict(
        host='some.example.com',
        port=1234,
        user='user name',
        password='password',
        ssh_key_file='/path/to/ssh/key',
    )
    role_kwargs = dict(
        _tmp_path=tempfile.mkdtemp(),
        _connection=Connection(**connection_terms),
        _task=dict(
            action='my_action',
            args=dict(
                src='/foo/bar',
                dest='/baz',
                recurse=True,
                follow=True,
                remote_src=True,
            )
        ),
    )
    result = ActionModule(**role_kwargs)
    assert result is not None

# Generated at 2022-06-23 07:39:28.970982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Patch Ansible options
    options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff', 'remote_user'])
    options.connection = 'ssh'
    options.module_path = '/path/to/mymodules'
    options.forks = 10
    options.become = False
    options.become_method = ''
    options.become_user = ''
    options.check = False
    options.diff = False
    options.remote_user = ''
    set_module_args(dict(
        src='/path/to/source',
        dest='/path/to/dest/',
        remote_src=True
    ))

# Generated at 2022-06-23 07:39:29.565964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-23 07:39:42.583288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(DictObj({'action': 'copy', 'ansible_loop_var': 'item'}), 'local', 'copy', '/tmp/ansible-test')
    assert action.task_vars == dict()
    assert action._task.args == dict()
    assert action.task_includes == dict()
    assert action.play_context == DictObj({})

    action = ActionModule(DictObj({'action': 'copy', 'ansible_loop_var': 'item'}), 'local', 'copy', '/tmp/ansible-test', DictObj({'delegate_to': 'localhost'}))
    assert action.play_context == DictObj({'delegate_to': 'localhost'})


# Generated at 2022-06-23 07:39:43.965229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:39:50.201718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initializing an instance of ActionModule.
    mod = ActionModule()

    # Initializing a Task object
    task = Task()

    # Assigning task to mod's _task variable
    mod._task = task

    # Initializing a Connection object.
    conn = Connection()

    # Assigning conn to mod's _connection variable.
    mod._connection = conn

    # Assigning connection to mod's _loader variable.
    mod._loader = conn

    # Test for the __init__ method by trying to invoke the run method.
    mod.run()

# Generated at 2022-06-23 07:39:56.113100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test case for unit test "test_ActionModule_run" of class ActionModule
    """
    # Test case

# Generated at 2022-06-23 07:40:04.461944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # assert_raises_regexp() is deprecated, use assertRaisesRegex() instead
    # assert_in() is deprecated, use assertIn() instead
    # assert_not_in() is deprecated, use assertNotIn() instead
    # assert_false() is deprecated, use assertFalse() instead
    # assert_true() is deprecated, use assertTrue() instead
    # assert_equal() is deprecated, use assertEqual() instead
    # assert_not_equal() is deprecated, use assertNotEqual() instead


    #
    # Configure stubs
    #

    # Stub of _find_needle.
    _find_needle_expected_result = "find_needle"

    def _create_remote_file_args(self):
        return self

    def _execute_module(self):
        return self


# Generated at 2022-06-23 07:40:07.163085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = AnsibleModule(
        argument_spec = dict(
            dest=dict(default=None),
            src=dict(default=None),
            copy=dict(required=True),
        )
    )
    assert a.copy == True
    assert a.src == None
    assert a.dest == None

# Generated at 2022-06-23 07:40:11.203512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test if method correctly goes through the three cases:
    # src and content are mutually exclusive
    # can not use content with a dir as dest
    # if we have first_available_file in our vars look up the files and use the first one we find as src
    pass


# Generated at 2022-06-23 07:40:12.875512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule({})
    action_module.run()

# For unit test

# Generated at 2022-06-23 07:40:20.356950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_loader = DictDataLoader({})
    fake_play_context = PlayContext()
    fake_play_context.connection = 'local'
    fake_play_context.network_os = 'Default'
    fake_play_context.remote_addr = '192.168.0.1'
    fake_play_context.port = 22
    fake_play_context._remote_passwords = {}
    fake_play_context.become = False
    fake_play_context.become_method = None
    fake_play_context.become_user = None
    fake_play_context.check_mode = False
    fake_task = Task()
    fake_task._role = None
    fake_task._role_path = None
    fake_task._task_deps = None
    fake_task._block = None


# Generated at 2022-06-23 07:40:31.211949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ModuleStub(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    class ConnectionStub(object):
        def __init__(self, **kwargs):
            self.base_prompt = kwargs['base_prompt']
            self.shell = kwargs['shell']

    class ShellStub(object):
        def __init__(self, **kwargs):
            self.DEFAULT_MODULE_NAME = kwargs['DEFAULT_MODULE_NAME']
            self.DEFAULT_MODULE_ARGS = kwargs['DEFAULT_MODULE_ARGS']
            self.tmpdir = kwargs['tmpdir']
            self.path_has_trailing_slash = kwargs['path_has_trailing_slash']
            self

# Generated at 2022-06-23 07:40:40.541763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # patch 'src' and set to a valid path
    src = '/home/jdoe/ansible/copy/test.yml'
    with patch.object(ActionModule, '_find_needle') as mocked_find_needle:
        mocked_find_needle.return_value = src
        # patch 'dest' and set to a valid path
        dest = '/tmp/myproject/test.yml'
        # patch '_load_params' for action plugin

# Generated at 2022-06-23 07:40:51.727764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host, port = socket.gethostbyname(socket.gethostname()), 12345
    path = os.path.join(tempfile.gettempdir(), 'ansible-test-run')
    try:
        os.mkdir(path)
    except:
        pass
    remote = '%s:%s' % (host, path)
    module = ActionModule(
        dict(
            src=os.path.join(path, 'normal-file'),
            dest=remote,
            remote_src=False,
            local_follow=False
        ),
        dict(
            ANSIBLE_SSH_CONTROL_PATH='/tmp/ansible-ssh-%h-%p-%r',
            ANSIBLE_SSH_PIPELINING=False
        )
    )

# Generated at 2022-06-23 07:40:57.274868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    os.environ['ANSIBLE_REMOTE_TEMP'] = '/tmp'

    class MockConfig(object):
        pass

    C.config = MockConfig()
    C.config.shell = None

    class MockTask(object):
        def __init__(self):
            self.args = {'mode': None, 'path': None}

    class MockTaskVars(object):
        def __init__(self):
            self.VARIABLE = 'test'

    class MockInventory(object):
        def __init__(self):
            self.basedir = "/test"
            self.get_vars = Mock(return_value='test')

    class MockPlayContext(object):
        def __init__(self):
            self.remote_addr = 'remote_addr'
            self.connection = 'connection'



# Generated at 2022-06-23 07:41:06.824740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_connection = MagicMock()
    action_module = ActionModule(mock_connection)
    # ActionModule.run() depends on the following methods of ActionModule
    # _execute_module_class
    # _ensure_invocation
    # _execute_module
    # _remove_tmp_path
    # _remote_expand_user
    # _find_needle
    # _copy_file
    # _create_content_tempfile
    # _remove_tempfile_if_content_defined
    # ActionModule.run() depends on the following methods of ActionBase
    # run
    # _low_level_execute_command

    # The following are the tests for ActionModule.run()

    # test for execution of module when src and dest are not specified

# Generated at 2022-06-23 07:41:15.857363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run: cmd = 'echo hello'")
    action_mod = ActionModule()
    action_mod._task = Task(action='command', args={'cmd': 'echo hello'})
    action_mod.__dict__['_connection'] = FakeConnection()
    ret = action_mod.run(tmp=None, task_vars=None)
    print("  " + str(ret))
    assert ret == {'stdout': 'hello', 'changed': False, 'stdout_lines': 'hello'}

# Generated at 2022-06-23 07:41:19.180876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(src='/path/to.py', dest='/var/www/html/')
    task = Task()
    task.args = args
    action_module = ActionModule(task)
    assert action_module._task.args == args



# Generated at 2022-06-23 07:41:28.545474
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:41:32.898580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule

    ActionModule is just a subclass of module_common.ActionBase.
    This test is just a sanity check.
    """

    action = ActionModule()
    assert isinstance(action, module_common.ActionBase)

# Generated at 2022-06-23 07:41:46.282655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock environment
    self = get_mock_interface(ActionModule)
    self._task = get_mock_interface(Task)
    self._task.args = {'src': 'some/source/path', 'dest': 'some/destination/path'}
    self._connection = get_mock_interface(Connection)
    self._loader = get_mock_interface(Loader)
    self._loader.exists = {'an/existant/path': True, 'a/non/existant/path': False}
    self._loader.get_basedir = {'an/existant/path': 'a/basedir', 'a/non/existant/path': 'a/basedir'}

# Generated at 2022-06-23 07:41:56.260287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    import os
    c = Connection()
    path = "/tmp/test"

# Generated at 2022-06-23 07:41:57.746164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod is not None


# Generated at 2022-06-23 07:41:58.459220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:42:07.425769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_connection = Connection()
    ansible_task = dict(action=dict(module_name='copy', module_args=dict(dest='/var/tmp/')))
    ansible_task_vars = dict(content='hello')
    ansible_task_vars['hostvars'] = {'localhost': {'ansible_connection': 'ssh', 'ansible_user': 'vagrant', 'ansible_ssh_pass': 'vagrant'}}
    ansible_task_vars['ansible_connection'] = 'ssh'
    ansible_task_vars['ansible_user'] = 'vagrant'
    ansible_task_vars['ansible_ssh_pass'] = 'vagrant'

# Generated at 2022-06-23 07:42:17.106105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.legacy.copy as ansible_copy
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict(
        src=ansible_copy.__file__, 
        dest='/tmp/copy'
    )
    am = ActionModule(AnsibleModule(argument_spec=dict(src=dict(), dest=dict()), supports_check_mode=False),
                      dict(ANSIBLE_MODULE_ARGS=module_args, ANSIBLE_REMOTE_TMP="/tmp", ANSIBLE_CHECKPOINT_DIR="/tmp/.ansible/cp"))

# Generated at 2022-06-23 07:42:18.718263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:42:28.967546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import argparse
    from ansible.module_utils import basic
    from ansible.module_utils import basic
    from ansible.module_utils import common_argparser
    from ansible.module_utils import common_environment
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    parser = common_argparser.create(
        conn_pass=[
            dict(
                name='connection',
                option_strings=[],
                dest='connection',
                default='local',
                choices=['local', 'smart', 'ssh', 'paramiko', 'docker', 'winrm', 'netconf', 'telnet']
            )
        ]
    )


# Generated at 2022-06-23 07:42:38.274429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Disable pylint message: Access to a protected member _of a client class
    # pylint: disable=E1101
    conn = Connection()
    conn.init_for_tests()
    conn._shell = ShellModule()
    conn._shell.tmpdir = '~/ansible_test/tmp'
    am = ActionModule(conn)
    assert am._conn == conn
    assert am._connection == conn



# Generated at 2022-06-23 07:42:50.463449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_loader, lookup_plugin_loader, path_loader = C.MODULE_UTILS_PATH, C.DELEGATE_TO_LOADERS, C.ACTION_PLUGIN_PATH

    class Task(object):
        def __init__(self):
            self.args = dict()

    class Connection(object):
        def __init__(self):
            self.become_method = None
            self.become_user = 'root'
            self.become = False

        def connect(self, params, _task):
            return self

        def exec_command(self, cmd, in_data=None, sudoable=False):
            res = command(cmd, in_data)
            return (0, res, None)

        def _shell_escape(self, arg):
            return arg


# Generated at 2022-06-23 07:43:01.750596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor for class ActionModule.
    """
    from ansible.plugins.action import ActionBase
    from ansible.plugins import module_loader

    mock_task = MagicMock()
    mock_connection = MagicMock()
    mock_play_context = MagicMock()
    mock_loader = MagicMock()
    mock_templar = MagicMock()
    mock_shared_loader_obj = MagicMock()
    mock_action_base = MagicMock()
    mock_action_base.get_shared_loader_obj.return_value = mock_shared_loader_obj

    action_module = ActionModule(mock_task, mock_connection, mock_play_context, mock_loader, mock_templar, mock_action_base)

    assert action_module._shared_loader_obj == mock_

# Generated at 2022-06-23 07:43:08.576837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test no dest argument
    actionmodule = ActionModule()
    actionmodule._task = dict(args=dict(src="foo"))
    assert actionmodule.run()['msg'] == "dest is required"
    actionmodule._task = dict()
    actionmodule._task['args'] = dict(src="foo")
    assert actionmodule.run()['msg'] == "dest is required"
    actionmodule._task = dict(args=None)
    assert actionmodule.run()['msg'] == "dest is required"

# Generated at 2022-06-23 07:43:09.799600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-23 07:43:11.074322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, task=dict(action=dict(args=dict())))
    assert isinstance(module, ActionModule)

# Generated at 2022-06-23 07:43:14.272356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # call method with args
    ActionModule().run(tmp=None, task_vars=None)
    


# Generated at 2022-06-23 07:43:24.648963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Verify the constructor of ActionModule.
    """
    class MyActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            super(MyActionModule, self).__init__(*args, **kwargs)

    # Test passing MyActionModule as action_plugin_class
    task = Task()
    task.action = 'mymodule'
    task.args = dict(myarg='myargvalue')
    connection = Connection()
    display = Display()
    mymodule = MyActionModule(task, connection, display)
    assert mymodule is not None
    assert isinstance(mymodule, ActionModule)
    assert mymodule._task.action == 'mymodule'
    assert mymodule._task.args['myarg'] == 'myargvalue'
    assert mymodule._connection is connection
    assert mymodule

# Generated at 2022-06-23 07:43:35.421506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'test_host'
    connection = Connection(play_context=PlayContext())
    task = Task()
    loader = DataLoader()
    templar = Templar(loader=loader)
    connection._shell.tmpdir = '/tmp/ansible-tmp-1234567890.23-1337'
    copy = copy_module.ActionModule(host=host, connection=connection, task=task, loader=loader, templar=templar)

    assert(copy._task == task)
    assert(copy._loader == loader)
    assert(copy._templar == templar)
    assert(copy._connection == connection)
    assert(copy._play_context == connection._play_context)
    assert(copy._shell == connection._shell)
    assert(copy._tmpdir == connection._shell.tmpdir)

# Generated at 2022-06-23 07:43:43.737835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    target = 'test_target'
    tmpdir = 'test_tmpdir'
    task_vars = {'test_task_vars': 'test_task_vars'}
    args_copy = {
        'test_args_copy': 'test_args_copy'
    }
    task = dict(args=args_copy)

# Generated at 2022-06-23 07:43:52.122642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a module that doesn't exist so it raises an exception
    mod = ActionModule({"action": "fake"})
    assert isinstance(mod, ActionModule)

    # Test with a real module
    mod = ActionModule({"action": "copy"})
    assert isinstance(mod, ActionModule)

# Generated at 2022-06-23 07:43:55.315586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = FakeConnection()
    task = FakeTask()
    task.args = {'src': '/path/to/src', 'dest': '/path/to/dest'}
    action_module = ActionModule(connection, task, tmpdir='')

# Generated at 2022-06-23 07:44:10.663705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Successfully create an instance of ActionModule
    '''
    from ansible.executor.task_executor import TaskExecutor
    import ansible.executor.task_executor
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader))
    play_context = PlayContext()

    # These keys/values are required for the __init__ method
    # of the ansible.executor.task_executor.TaskExecutor class.

# Generated at 2022-06-23 07:44:15.877459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleError):
        action = ActionModule(None, {}, {}, False)
        action.setup()


# Generated at 2022-06-23 07:44:32.025421
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.legacy.plugins.action
    import ansible.constants as C


# Generated at 2022-06-23 07:44:33.365208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:44:44.157558
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock defaults
    action_module = ActionModule()
    action_module._task.args = {}
    action_module._connection = Mock()
    action_module._loader = Mock()
    action_module._remove_tmp_path = Mock()

    # Run the method.
    result = action_module.run(task_vars={})

    # Assert that the result is as we expect.
    assert result == {
        'failed': True,
        'msg': 'src (or content) is required'
    }

    # Mock defaults
    action_module = ActionModule()
    action_module._task.args = {}
    action_module._connection = Mock()
    action_module._loader = Mock()
    action_module._remove_tmp_path = Mock()

    # Set the arguments

# Generated at 2022-06-23 07:44:54.370757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if not HAS_PARAMIKO:
        raise SkipTest("paramiko is not installed")

    set_module_args(dict(
        content='test file content',
        dest='/dummy/path'
    ))
    action = ActionModule(load_fixture('command_success.json'))
    assert action.content == 'test file content'
    assert action.dest == '/dummy/path'
    assert 'content' in action.nonce_keys
    assert 'dest' in action.nonce_keys
    assert 'remote_checksum' in action.nonce_keys, action.nonce_keys


# Generated at 2022-06-23 07:45:06.740091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders

    class MockRoleRequirement(RoleRequirement):
        def __init__(self, role_name, role_path=None):
            super(MockRoleRequirement, self).__init__()
            self.role_name = role_name
            self.role_path = role_path
            self.actions = []
            self.name = os.path.basename(role_path) if role_path else None
            self._role_data = {}
            self

# Generated at 2022-06-23 07:45:17.504571
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:45:23.449331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    p = AnsibleLegacyAtomicCopy()

    assert p._supports_check_mode is True
    assert p._supports_async is False
    assert p._supports_pipe_fileno is True
    assert p._keep_remote_files is True
    assert p._use_unsafe_shell is False

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources='')

    host = Host()

# Generated at 2022-06-23 07:45:28.252491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_mock = Mock(spec=ActionModule, name='ActionModule')
    test_mock.run.return_value = {'ansible_facts': {}}
    from ansible.module_utils.facts import Facts
    test_facts = Facts(dict())
    results = ActionModule._execute_module(test_mock, test_facts, {})
    assert results['ansible_facts'] == {}

# Generated at 2022-06-23 07:45:37.852039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The module_utils/urls.py file is not automatically imported because
    # it is not in the default import location for modules.
    # TODO: move module_utils/http.py to a location that is automatically imported
    module_utils_urls_path = os.path.join(os.path.dirname(__file__), 'module_utils/urls.py')
    module_utils_urls_path = os.path.normpath(module_utils_urls_path)
    module_utils_urls_path = os.path.abspath(module_utils_urls_path)
    module_utils_urls_path = os.path.realpath(module_utils_urls_path)

# Generated at 2022-06-23 07:45:49.011884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture_loader = FixtureLoader()
    mock_plugin_loader = PluginLoader(class_name='CacheModule')
    src_path = '/home/foo/bar'
    dest_path = '/home/foo/bar'

    # Setup task that has src and dest arguments
    task = Task()
    task.args = dict(src=src_path, dest=dest_path)

    # Setup the base connection class
    conn = Connection(None)

    # Setup the cache
    stdout = BytesIO(b'{"ansible_facts": {}, "changed": false, "_ansible_no_log": false}')
    cache = BaseCacheModule(mock_plugin_loader, 'memory', {}, stdout)

    action_module = ActionModule(task, conn, cache, fixture_loader)

    assert action_module is not None


# Generated at 2022-06-23 07:45:50.631673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()


# Generated at 2022-06-23 07:45:53.282947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for class constructor
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)



# Generated at 2022-06-23 07:46:02.282165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.unsafe_proxy as unsafe_proxy

    if not hasattr(C, 'DEFAULT_DEBUG'):
        setattr(C, 'DEFAULT_DEBUG', False)

    source = {"a": {"b": 1}, "ansible": {"c": "ansible"}, "ansible_facts": {"d": "ansible_facts"}, "ansible_forks": {"e": "ansible_forks"}}
    task_vars = TaskVars(unsafe_proxy.AnsibleUnsafeText(source))
    source = copy.deepcopy(source)
    task_vars.set_nonpersistent_facts(source)

    tmp = AnsibleUnsafeBytes(C.DEFAULT_LOCAL_TMP)

# Generated at 2022-06-23 07:46:10.062065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing creating an ActionModule instance
    my_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(my_action_module, ActionModule)

# We don't do this when we're running tests.
if __name__ == '__main__':
    # Fire up the test harness
    pytest.main([__file__, "-v"])

# Generated at 2022-06-23 07:46:21.130813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins import module_loader
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import data
    try:
        from ansible.parsing.dataloader import DataLoader
    except ImportError:
        from ansible.vars.manager import VariableManager
    from ansible.vars.manager import VariableManager

    conn_args = {
        'host': '127.0.0.1',
        'port': 9921,
        'username': 'admin',
        'password': 'admin',
    }

# Generated at 2022-06-23 07:46:30.503591
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:46:42.794653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_ds = dict(
        action=dict(module='copy', src='source', dest='dest')
    )
    play_context = PlayContext()

    # Create a TaskExecutor and inject it into a TaskInclude
    task_include = TaskInclude()
    task_include._task = Task().load(task_ds)
    task_include._task._role = None
    task_include._play_context = play_context

    # Create an ActionModule through TaskExecutor
    action_module = ActionModule(task_include, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-23 07:46:48.172527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock = MagicMock()
    action = ActionModule(mock)

    # Check initial values
    assert action._task == mock
    assert action._shared_loader_obj == None
    assert isinstance(action._loader, DataLoader)
    assert action._connection == None
    assert action._play_context == None
    assert isinstance(action._templar, Templar)
    assert action._cleanup_remote_tmp is False

# Generated at 2022-06-23 07:46:59.213868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import ast
    import os
    import ansible.plugins.loader
    sys.modules["ansible"] = ansible
    # Create a task, a play, and a loader
    task_ds = dict(
        action=dict(
            __ansible_module__="copy",
        ),
        register="foo",
    )
    play_context = PlayContext()
    new_stdin = FakeSTDIN(u'{"foo": "bar"}')
    connection = Connection(new_stdin)
    loader.add_directory(os.path.join(os.path.dirname(__file__), '../test_utils/test_plugins'))
    tasks = [task_ds]
    play = Play().load(tasks, variable_manager=VariableManager(), loader=loader)
    tqm._stdout_callback

# Generated at 2022-06-23 07:47:09.287180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test for method run of class ActionModule')
    print('---')
    # Defines the needed input variables
    # Declare objects of class ActionModule
    aModule = ActionModule(1,2,3,4,5,6,7,8)

    print('Test for aModule.run() with source as a dir')
    print('---')
    tmp = 1