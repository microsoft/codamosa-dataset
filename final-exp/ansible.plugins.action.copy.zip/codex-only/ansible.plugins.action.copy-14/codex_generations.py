

# Generated at 2022-06-23 07:37:17.401887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Mocking
    mock_ansible_module = MagicMock()
    mock_ansible_module.check_mode = False
    mock_ansible_module.no_log = False
    mock_ansible_module._diff = False
    mock_ansible_module.params = dict()
    mock_ansible_module.params['src'] = ""
    mock_ansible_module.params['dest'] = ""
    mock_ansible_module.params['backup'] = 0
    mock_ansible_module.params['mode'] = "0644"
    mock_ansible_module.params['owner'] = ""
    mock_ansible_module.params['group'] = ""

# Generated at 2022-06-23 07:37:26.976664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    # Create a task and an action module to test.
    task = dict(action=dict(module_name='copy'))
    action_module = ActionModule(task=task)

    # Test existence of the loader, templar, connection, etc.
    assert hasattr(action_module, '_loader')
    assert hasattr(action_module, '_templar')
    assert hasattr(action_module, '_shared_loader_obj')
    assert hasattr(action_module, '_connection')

    # Test validate method of the action_module.
    assert action_module._validate_self() == None

    # Test execute method when there is no src and content.
    task['action']['module_args'] = dict()
    task_vars = dict()

# Generated at 2022-06-23 07:37:28.124654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(True, None, None, None, None, None)
    assert m != None


# Generated at 2022-06-23 07:37:40.531045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=connection_loader.get('local', None))
    assert action_module.__class__.__name__ == 'ActionModule'

    action_module = ActionModule(task=dict(), connection=connection_loader.get('smart', None))
    assert action_module.__class__.__name__ == 'ActionModule'

    action_module = ActionModule(task=dict(), connection=connection_loader.get('network_cli', None))
    assert action_module.__class__.__name__ == 'ActionModule'

    action_module = ActionModule(task=dict(), connection=connection_loader.get('local_docker', None))
    assert action_module.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 07:37:48.667821
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:37:57.002076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = Mock(spec=Task())
    mock_task.args = {'dest': '/fake/dest/dir', 'src': '/fake/src/dir', 'original_basename': '/fake/src/dir'}

    mock_task.action = 'file'

    mock_connection = Mock(spec=Connection())
    mock_connection._shell = Mock(spec=ShellModule())

    mock_loader = Mock(spec=DataLoader())
    mock_undefined = Mock(spec=Undefined())

    mock_task_vars = dict()

    mock_connection._shell.path_has_trailing_slash.return_value = False
    mock_connection._shell.join_path.return_value = '/fake/dest/dir/'

    # Test action is file

# Generated at 2022-06-23 07:37:58.984014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    A = ActionModule(dict(ANSIBLE_MODULE_ARGS=CHAINS), complex_args=dict(ANSIBLE_MODULE_ARGS=CHAINS))
    assert isinstance(A, ActionModule)


# Generated at 2022-06-23 07:38:09.065089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 07:38:09.486778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:38:14.873225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection(object):
        def __init__(self):
            self._shell = Shell(string_conversion=to_bytes)
    class MockModule(object):
        def __init__(self):
            self.params = dict(
                src="/tmp/src",
                dest="tmp/dest",
                recursive=False
            )
    module = ActionModule(
        task=dict(
            args=dict(
                src="/tmp/src",
                dest="tmp/dest",
                recursive=False
            ),
            name="copy",
            action="copy"
        ),
        load_path="/path/to/load",
        connection=MockConnection(),
        task_vars=dict(),
        templar=MockModule()
    )
    assert module._task.args['src'] == "/tmp/src"

# Generated at 2022-06-23 07:38:21.866124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creates an action module for testing.
    #
    # Returns:
    #   An instance of ActionModule.
    m = ansible.utils.module_docs.get_action_module('copy')
    connection = Connection()
    task = Task()
    action = ActionModule(connection=connection, task=task, tmp_path=tempfile.mkdtemp())
    action._shared_loader_obj = None
    action._loader = None
    action._templar = None
    return action


# Generated at 2022-06-23 07:38:24.566446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Case 1: set self._task as None
    assert ActionModule(task=None) == None

    # Case 2: set self._task as not None
    assert ActionModule(task=dict()) != None

# Generated at 2022-06-23 07:38:33.832649
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:38:44.349875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """
    # Make sure all paths and variables are set correctly
    tests_dir = os.path.dirname(os.path.realpath(__file__))
    src_file = os.path.join(tests_dir, 'fixtures/test_file_src.txt')
    dest_file = os.path.join(tests_dir, 'fixtures/test_file_dest.txt')
    expected_file_dest_content = b'This is a test file\n'
    content = 'blah blah'
    temp_src_file = tempfile.NamedTemporaryFile()
    temp_src_file.write(content)
    temp_src_file.flush()
    task_args = {'src': temp_src_file.name, 'dest': dest_file}

# Generated at 2022-06-23 07:38:55.375067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    server_list = list()
    test_obj = ActionModule(server_list)

    class MockConnectionPlugin(object):
        def __init__(self):
            pass

        def _shell_wrap(self, cmd):
            return cmd

    class MockModule(object):
        def __init__(self):
            self.params = dict()

    class MockTask(object):
        def __init__(self):
            self.args = dict(
                src=None, 
                content=None, 
                dest=None, 
                remote_src=False, 
                local_follow=True,
            )
            self.tmp = None

    test_obj._task = MockTask()
    test_obj._connection = MockConnectionPlugin()
    test_obj._loader = MockModule()
    test_obj

# Generated at 2022-06-23 07:38:59.983515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(Task())
    assert isinstance(module, ActionModule)
    # The below test fails, but it should not.  The ActionModule is
    # currently not fully constructed at this point, so things like
    # _connection are not available.
    #assert module._connection is None

# Generated at 2022-06-23 07:39:08.383428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = '127.0.0.1'
    port = 20001
    user = 'testuser'
    password = 'testpassword'
    connection = Connection(host=host, port=port, user=user, password=password, become=True)

    args = dict(
        content=None,
        dest='/tmp/testfile',
        follow=True,
        mode='preserve',
        original_basename='testfile',
        path='testfile',
        recursive=True,
        selevel=None,
        serole=None,
        setype=None,
        seuser=None,
        src='/tmp/testfile',
        state='file',
        unsafe_writes=False,
        validate='md5',
        remote_src=True
    )

# Generated at 2022-06-23 07:39:14.553224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict(
        dest='/path/to/dest',
        content='content of test file'
    )

    module = ActionModule(params=params)
    module.run(task_vars=dict())

if __name__ == '__main__':
    params = dict(
        dest='/tmp/test',
        src='test2.txt'
    )

    module = ActionModule(params=params)
    module.run(task_vars=dict())

# Generated at 2022-06-23 07:39:23.765333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for class ActionModule '''

    # Test init with 'connection' and 'play_context'
    connection = MockConnection()
    loader = DataLoader()

    play_context = PlayContext()
    play_context.become = False
    play_context.become_user = None

    task = Task()
    task.args = {}
    display = Display()
    action_module = ActionModule(connection, play_context, task, loader, display)

    # Test init without 'connection' and 'play_context'
    action_module = ActionModule(None, None, None, None, None)

# Generated at 2022-06-23 07:39:32.215366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    task = dict(
        action=dict(
            module_args=dict(
                src='src',
                checksum=True,
                other_args='other_args',
            )
        )
    )
    task_vars = dict(
        ansible_connection='local',
        ansible_check_mode=True,
    )
    task_vars_no_connection = dict(
        ansible_check_mode=True,
    )

    play_context = dict(
        remote_addr='127.0.0.1',
        password='pass',
        port=22,
        other_var='other_var',
    )

    # Happy path, required args present

# Generated at 2022-06-23 07:39:42.098285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    This is a unit test for ActionModule class constructor.
    '''
    # mock task object
    mock_task = mock.MagicMock()
    # mock constructor of ActionModule class
    mock_action_module = mock.MagicMock(spec=ActionModule)

    # test constructor
    action_module = ActionModule(mock_task, mock_action_module)

    # verify constructor
    assert action_module._task == mock_task
    assert action_module._connection == mock_action_module


# Generated at 2022-06-23 07:39:51.579667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to test
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    source = 'test'
    content = None
    dest = None
    remote_src = False
    local_follow = True
    # call method run with parameters
    result = action_module.run(tmp=None, task_vars=None)
    # assert the return of method run
    assert result['failed'] == True
    assert result['msg'] == 'src (or content) is required'
    # call method run with parameters
    result = action_module.run(tmp=None, task_vars=None)
    # assert the return of method run
    assert result['failed'] == True

# Generated at 2022-06-23 07:39:56.292989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(load_module_spec=False)

    assert am.DEFAULT_SYMLINK_FOLLOW == True
    assert am.NO_TRAILING_SLASH == False
    assert am._use_persistent_connection == True
    assert am._display.verbosity == 3
    assert isinstance(am, ActionModule)



# Generated at 2022-06-23 07:40:04.608236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = 'source_server'
    content = 'content_server'
    dest = 'dest_server'
    remote_src = 'remote_src_server'
    local_follow = 'local_follow_server'

    file_copy = ActionModule()
    file_copy.exists = MagicMock()
    file_copy.exists.return_value = False
    file_copy.remove = MagicMock()
    file_copy.remove.return_value = False
    file_copy._remove_tmp_path = MagicMock()
    file_copy._remove_tmp_path.return_value = False
    file_copy._execute_module = MagicMock()
    file_copy._execute_module.return_value = {}
    file_copy._remove_tempfile_if_content_defined = MagicMock()
    file

# Generated at 2022-06-23 07:40:16.071360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {
        'src': '/home/test/foo.txt',
        'dest': '/tmp/foo.txt',
        'content': '',
        'dest_port': 22,
        'dest_host': 'host',
        'dest_user': 'user',
        'dest_password': 'password',
        'dest_private_key': 'private_key',
        'content_tempfile': '/tmp/tmp.txt'
    }
    # Create ActionModule object
    am = ActionModule(args)
    # Test contents of object
    assert am._task.action == 'copy'
    assert am._task.args == args
    assert am._load_name == 'copy'
    assert am.supports_check_mode

# Generated at 2022-06-23 07:40:19.777468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner = Runner()
    result = ActionModule(runner)
    assert result._task == runner._task
    assert result._connection == runner._connection
    assert result._play_context == runner._play_context
    assert result._loader == runner._loader
    assert result._templar == runner._templar
    assert result._shared_loader_obj == runner._shared_loader_obj


# Generated at 2022-06-23 07:40:26.642994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Get the implementation of ActionModule from the
  # module which is loaded into the Ansible runtime
  a = ActionModule()

  # Run the method we are testing with the test data that was
  # produced by the stub method _get_remote_user
  # run(self, tmp=None, task_vars=None)
  ret = a.run(tmp=None, task_vars=None)

  # Ensure that the return value of run is expected
  assert isinstance(ret, dict) and ret == 'test ret'

# Generated at 2022-06-23 07:40:38.365484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test  begin for method run of class ActionModule')
    tmp = None
    task_vars = dict()
    action = ActionModule()
    action.set_task(Task())
    action.set_loader(DataLoader())
    action.set_connection(Connection())
    action.set_play_context(PlayContext())
    ansible_vars = dict(ansible_ssh_user='ansible',
                        ansible_ssh_pass='changeme',
                        ansible_ssh_host='192.168.1.1',
                        ansible_ssh_port='22',
                        ansible_connection='ssh')

# Generated at 2022-06-23 07:40:39.748074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


# Generated at 2022-06-23 07:40:43.845895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = None
    content = None
    dest = None
    remote_src = False
    local_follow = True
    result = dict(failed=None)
    # result is not None, so no side effect
    assert(ActionModule._ActionModule__run(source, content, dest, remote_src, local_follow, result) == result)


# Generated at 2022-06-23 07:40:53.056272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Build the task for the test module.
    task = Task()
    task.args = {
        'src': 'test/files/test_file',
        'dest': 'test/files/new_test_file',
        'content': 'test_content',
        'remote_src': False,
    }

    # Build the play context for the test module.
    play_context = PlayContext()
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.check_mode = True
    play_context.remote_addr = 'localhost'

    # Build the connection object for the test module.
    connection = Connection(play_context)

    # Test the result of constructor.

# Generated at 2022-06-23 07:41:04.385741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an ActionModule object
    _task = Task()
    _connection = Connection()
    _play_context = PlayContext()
    _loader = DataLoader()
    _templar = Templar()
    _task.args = dict()
    _task.action = 'copy'
    am = ActionModule(_task, _connection, _play_context, _loader, _templar)
    # Get results from _ensure_safe_args
    am._ensure_safe_args()
    # Get results from _get_shebang
    am._get_shebang()
    # Get results from _executable_exists
    am._executable_exists()
    # Get results from _transfer_str
    am._transfer_str()
    # Get results from _transfer_data
    am._transfer_data()
    # Get results

# Generated at 2022-06-23 07:41:05.883247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule('')
    assert mod is not None

# Generated at 2022-06-23 07:41:06.562381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:41:22.258241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible = AnsibleModule(
        argument_spec = dict(
            src=dict(),
            content=dict(),
            dest=dict(),
            remote_src=dict(),
            local_follow=dict(),
            source_checksum=dict(),
            force=dict(),
            remote_src=dict(),
            validate_checksum=dict(),
            mode=dict()
        )
    )
    action_module = ActionModule(ansible)
    ansible.params = dict(
        src = 'src',
        dest = 'dest'
    )
    result = action_module.run()

# Generated at 2022-06-23 07:41:34.012760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # required for testing
    module_loader = DictDataLoader({})

    # Set up our module parameters
    module_args = DictObj()
    module_args.update(dict(
        src='/src/path',
        dest='/dest/path',
        follow=False,
        checksum=False,
        content=None,
        raw=False
    ))

    # Construct our action module
    am = ActionModule(module_loader=module_loader, task=DictObj(), connection=DictObj(), play_context=DictObj(), loader=DictObj(), templar=DictObj(), shared_loader_obj=DictObj())

    module_return = am.run(tmp='', task_vars=dict())

    assert module_return.get('failed') == True

# Generated at 2022-06-23 07:41:34.750296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:41:39.729183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure we get an exception if we don't have a task set
    with pytest.raises(AssertionError):
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-23 07:41:51.766270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method "run" of class "ActionModule"
    '''

    # -----
    # Setup
    # -----

    # Setup for test _find_needle.
    _find_needle_test_data = [
        ('test_data/test_dir', 'test_dir'),
        ('test_data/test_dir', 'test_dir/test_file'),
        ('test_data/test_dir', 'test_dir/test_dir2/test_file2'),
        ]

# Generated at 2022-06-23 07:42:03.593030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import shutil
    import tempfile
    tmp_dir = tempfile.gettempdir()
    tmp_path = os.path.join(tmp_dir, 'ansible_test_mock_connection')
    os.mkdir(tmp_path)
    with open(os.path.join(tmp_path, 'content.txt'), 'w') as content_file:
        content_file.write('test content')

# Generated at 2022-06-23 07:42:05.450427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res =  ActionModule().run(tmp=None)
    assert res["failed"] == True
    assert "dest is required" in res["msg"]


# Generated at 2022-06-23 07:42:16.679639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b_vars = dict(
        ansible_user='vagrant',
        ansible_ssh_host='default',
        ansible_connection='ssh',
        ansible_ssh_pass='vagrant',
        ansible_ssh_port=2222,
        ansible_ssh_private_key_file='/home/honglou/.vagrant.d/insecure_private_key',
        ansible_ssh_common_args='-o StrictHostKeyChecking=no',
        ansible_ssh_extra_args='',
        ansible_shell_type='bash',
        ansible_shell_executable='/bin/bash',
        ansible_python_interpreter='/usr/bin/python'
    )

    am = ActionModule(b_vars, host=Host(name='default'))
   

# Generated at 2022-06-23 07:42:18.982958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1


# Generated at 2022-06-23 07:42:29.261486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = AnsibleTask()
    task.action = 'copy'
    task.args = dict(
        src='/path/to/src.txt'
    )

    # Mock AnsibleOptions
    m_opts = mock.MagicMock()
    m_opts.connection = 'chroot'
    m_opts.module_path = '/path/to/modules'

    # Mock AnsibleShell
    m_shell = mock.MagicMock()
    m_shell.join_path.return_value = '/mock/path'
    m_shell.path_has_trailing_slash.return_value = False

    # Mock AnsibleConnection
    m_conn = mock.MagicMock()
    m_conn.shell = m_shell

# Generated at 2022-06-23 07:42:41.965091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit tests for ActionModule constructor
    """
    mock_task = mock.Mock()
    mock_task.args = dict()
    action = ActionModule(mock_task, mock.Mock())
    assert isinstance(action, ActionModule)
    action.connection = mock.Mock()
    action.connection.transport = 'mock'
    action.connection._shell.tmpdir = '/tmp/ansible_file_test_dir'
    mock_task.args = dict(
        src='test_src',
        dest='test_dest',
        content='test_content',
        remote_src=True,
        local_follow=True,
        follow=True,
    )
    action = ActionModule(mock_task, mock.Mock())

# Generated at 2022-06-23 07:42:45.997441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test ActionModule constructor"""
    # Test valid args
    ActionModule(dict(action=dict(foo=1)), dict(bar=2))

    # Test missing action key
    args = {
        'action_args': dict(foo=1),
        'action_name': 'test_module',
        'action_wrapper': 'test_module',
    }
    action = ActionModule(args, dict(bar=2))
    assert action.name == 'test_module', "Name for action should have been 'test_module', found '%s' instead" % action.name

# Generated at 2022-06-23 07:42:54.711973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task_include
    from ansible.playbook.task import Task

    r = RemoteMachine('localhost')
    t = Task()
    t.args = dict(dest='/tmp', src='/etc/hosts')
    tqm = None
    loader = None
    variable_manager = None
    shared_loader_obj = ansible.playbook.task_include.TaskInclude(loader=loader, variable_manager=variable_manager, use_handlers=True)

    am = ActionModule(task=t, connection=r, play_context=None, shared_loader_obj=shared_loader_obj, loader=loader, templar=None, shared_module_utils=None)
    assert am.task is not None
    assert am.connection is not None
    assert am._loader is not None
   

# Generated at 2022-06-23 07:42:58.622370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock up a MyClass to test.
    mock_self = MagicMock()
    mock_tmp = None
    mock_task_vars = None
    # Make the call.
    result = ActionModule.run(mock_self, mock_tmp, mock_task_vars)
# Test class ActionModule.

# Generated at 2022-06-23 07:43:03.851210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert_equals(action_module.DEFAULT_NEW_FILE_MODE, 0o600)
    assert_equals(action_module.DEFAULT_NEW_DIR_MODE, 0o700)


# Generated at 2022-06-23 07:43:09.078424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule({'one': 1, 'two': 2}, task_vars=dict())

    assert mod._task_vars == {'one': 1, 'two': 2}, 'Expected _task_vars to be equal to the expected result'
    assert mod._templar is None, 'Expected _templar to be None'
    assert mod._loader is None, 'Expected _loader to be None'

# Generated at 2022-06-23 07:43:20.497119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    import random

    module_args = dict(src='Modules/copy.py', dest='/tmp')
    module_res = dict(src='Modules/copy.py', dest='/tmp')
    # TODO: module_res.update({'md5sum': '<module_md5sum>'})
    tmp = '/tmp'
    task_vars = dict(module_name='module_name', module_args=module_args)
    task_vars.update({'__CHROOT_NEW__': '/tmp'})
    task_vars.update({'__CHROOT_OLD__': '/tmpfoo'})
    task_vars.update({'__DEFAULT_SYSTEM_CHARSET': 'utf-8'})
    task_vars.update

# Generated at 2022-06-23 07:43:31.705437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test for ActionModule constructor '''
    action_module = ActionModule(None, None, None, None, None)
    assert isinstance(action_module, ModuleBase)
    assert action_module.task is None
    assert action_module.connection is None
    assert action_module.play_context is None
    assert action_module.loader is None
    assert action_module.templar is None
    assert action_module.shared_loader_obj is None
    assert action_module.argument_spec is None
    assert action_module.supports_check_mode is None
    assert action_module.no_log is False
    action_module.no_log = True
    assert action_module.no_log is True
    assert action_module.connection_info is None
    assert action_module._task is None
    assert action_

# Generated at 2022-06-23 07:43:32.786595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule()
    x.run()

# Generated at 2022-06-23 07:43:42.354739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # Setup argument values for create_task.
    # Task definition
    task_definition = TaskDefinition(
        action={},
        task_vars=[],
        check_mode=False,
        loader=None,
        templar=None,
        task_uuid=None,
        third_pass=False,
        ignore_errors=False,
    )

    # Task internal configuration
    play = Play(
        play_uuid=uuid.uuid4(),
        name='A fake play',
        vars_prompt=[],
        vars_files=[],
        roles=[],
        tasks=[],
        handlers=[],
    )

    # Stub task_vars

# Generated at 2022-06-23 07:43:56.833097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule.
    # Instance of ActionModule is created.
    #
    connection_info = mock.Mock()
    action_base = mock.Mock()
    action_base._task.action = 'copy'
    action_base._task.args.get.return_value = 'test'
    tmp = '/tmp'
    task_vars = dict()
    a = ActionModule(connection_info, action_base, task_vars, tmp)
    if a._shell is not None:
        assert True
    else:
        assert False
    if a._connection is not None:
        assert True
    else:
        assert False
    if a._task.action == 'copy':
        assert True
    else:
        assert False

# Generated at 2022-06-23 07:44:04.747171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule run()")

    # input parameter
    task_vars = dict()
    tmp = None
    content_tempfile = None
    content = "test content"
    content_tempfile = "/tmp/content_tempfile"
    dest = "/tmp/dest"
    remote_src = False
    local_follow = True

    # expected result
    result = dict()
    result['checksum'] = None
    result['failed'] = True
    result['msg'] = 'dest is required'

    # execute and validate test
    m = ActionModule()
    actual = m.run(tmp, task_vars)
    assert actual == result

    # reset expected result
    result = dict()
    result['checksum'] = None
    result['failed'] = True

# Generated at 2022-06-23 07:44:08.175880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ConnectionMock(object):
        _shell = None

    conn = ConnectionMock()
    conn._shell = ShellModuleMock()

    task = TaskModuleMock()
    task.args = dict(src=1, dest=1)

    action = ActionModule(task, conn, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action

# Generated at 2022-06-23 07:44:16.065526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task = DummyTask())
    action_module._remove_tmp_path = MagicMock()
    action_module._create_content_tempfile = MagicMock()
    action_module._copy_file = MagicMock()
    action_module._execute_module = MagicMock()
    action_module._find_needle = MagicMock()
    action_module.transfer_strategy = "ansible.legacy"
    action_module.transfer_module = "ansible.legacy.copy"
    action_module._execute_remote_stat = MagicMock()
    action_module._remote_expand_user = MagicMock()
    action_module._task.args = dict(src = r"", dest = r"")
    action_module._task.diff = dict()
    action_module

# Generated at 2022-06-23 07:44:29.529384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Note that we use get_action_module to ensure that the curl module is skipped,
    # since that class is tested below.
    actmod = get_action_module(None, action='copy')
    task = create_task('copy', src='default_tests/unit/fixtures/src_path', dest='/tmp/dest_path')
    action_result = actmod.run(task_vars={}, tmp=None, task_vars=None)
    print(action_result)
    assert action_result is not None


# Generated at 2022-06-23 07:44:37.348948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # __init__
    # test_update_path()
    test_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # run
    # test_check_argument_types()
    result = test_ActionModule.run(tmp=None, task_vars=None)
    assert(isinstance(result, dict))



# Generated at 2022-06-23 07:44:46.550875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import MagicMock
    from ansible.plugins.action import ActionBase
    result = dict(failed=False, msg="", rc=1)
    task_vars = dict(ansible_default_remote_tmp="/abc/tmp/")
    args = dict(src="/abc/src/file1", dest="/abc/dest/file1")
    tmp = MagicMock()
    tmp.__str__ = lambda x: "/abc/tmp"
    ActionModule.run(self=ActionModule, tmp=tmp, task_vars=task_vars)
    file = MagicMock(return_value=result)
    ActionBase._execute_module = file
    ActionModule.run(self=ActionModule, tmp=tmp, task_vars=task_vars)
    args_a = args.copy()

# Generated at 2022-06-23 07:45:02.500179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Constructor of class ActionModule
    """

    # test1: "ActionModule (task, connection, play_context, loader, templar, shared_loader_obj)" is called.
    #        "task" is not instance of ansible.runner.task.Task.
    #        It returns ValueError.
    t = AnsibleAsyncResult()
    c = MockConnection()
    pc = MockPlayContext()
    l = MockLoader()
    tmplr = ansible.template.Templar(loader=l)
    shared_loader_obj = ansible.loader._AnsibleLoader(None, l._basedir, l._module_paths, l.get_basedir())
    assert_raises(ValueError, ActionModule, "action", t, c, pc, l, tmplr, shared_loader_obj)



# Generated at 2022-06-23 07:45:04.271755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:45:13.645772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = str(random.randint(1,9999)) # noqa: F841
    task_vars = dict()

# Generated at 2022-06-23 07:45:24.795489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a task object
    task = Task(None, {"remote_user": "testuser", "remote_pass": "password", "remote_port": "22"})
    action_module = ActionModule()
    results = action_module.run(task_vars={"remote_user": "testuser", "remote_pass": "password", "remote_port": "22"})
    assert results.get('failed') == True
    assert results.get('msg') == 'dest is required'
    assert results.get('invocation') == "invocation"
    del results["invocation"]
    assert results == {"failed": True, "msg": "dest is required"}

# Generated at 2022-06-23 07:45:34.615578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection, ConnectionError

    module = AnsibleModule(
        argument_spec=dict(),
    )
    try:
        am = ActionModule(module, 'copy')
    except Exception as e:
        assert False, repr(e)

    try:
        Connection.create(None, 'paramiko')
    except ConnectionError as e:
        assert False, repr(e)

    try:
        am2 = ActionModule(module, 'command')
    except Exception as e:
        assert False, repr(e)

# Generated at 2022-06-23 07:45:38.795764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create ActionModule object with the required arguments
    action_module = ActionModule('TODO', 'TODO', 'TODO')
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 07:45:39.840246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Construct action module and verify if all the options are assigned correctly
    '''
    import ans

# Generated at 2022-06-23 07:45:50.027055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    assert m._file_module is not None
    assert m._remote_checksum is not None
    assert m._remove_tmp_path is not None
    assert m._execute_module is not None
    assert m._transfer_str is not None
    assert m._get_diff_data_for_file is not None
    assert m._connection is not None
    assert m._task is not None
    assert m._loader is not None
    assert m._play_context is not None
    assert m._templar is not None
    assert m._shared_loader_obj is not None


# Generated at 2022-06-23 07:46:00.908121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.action import ActionBase

    module_loader, lookup_loader, inventory_loader, test_loader = setup_loader()

    def _create_module_return(*args, **kwargs):
        return {'changed': False, '_ansible_verbose_always': True, '_ansible_no_log': False, 'rc': 0}

    class TestActionModule(ActionBase):
        TRANSFERS_FILES = True

# Generated at 2022-06-23 07:46:09.374505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import os

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'ActionModule_run.yml')
    fixture_data = load_fixture(fixture_path)
    my_vars = fixture_data.get('my_vars')
    my_task_vars = fixture_data.get('my_task_vars')
    my_task = Task.load(fixture_data.get('my_task'))
    my_task_env = ImmutableDict(my_task.environment)
    my_task._

# Generated at 2022-06-23 07:46:17.424542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    my_ActionModule = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    my_task = {
               'args': {
                        'dest': 'x',
                        'content': None,
                        'remote_src': False,
                        'local_follow': True,
                        'src': 'x'
                       },
               'action': 'copy',
               'name': 'copy'
              }

    my_task_vars = {}

    my_tmp = None

    expected_result = {
                       'dest': 'x',
                       'src': 'x',
                       'failed': False,
                       'changed': False
                      }

# Generated at 2022-06-23 07:46:19.013153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:46:29.325744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(action=dict(module='copy', args=dict(dest='destination'))),
        connection=dict(host='host'),
        play_context=PlayContext()
    )

    module._remove_tmp_path = MagicMock()
    # _ensure_invocation returns its argument.
    module._ensure_invocation = lambda arg: arg
    module._remote_expand_user = MagicMock()
    module._find_needle = MagicMock()

    with patch.object(ActionModule, '_copy_file') as mock_copy_file:
        task_vars = dict()
        result = dict()

        # If source or dest is unset, returns result with failed=True
        result['failed'] = True
        result['msg'] = 'src is required'
       

# Generated at 2022-06-23 07:46:30.659977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.copy import ActionModule

    assert True

# Generated at 2022-06-23 07:46:35.496251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization for unit test
    # Init one of the abstract object for class ActionModule
    # What does this code do?
    #
    # Why is skip_conditions like this?
    #
    #
    conn = Connection(param=None)
    disp = Display()
    tqm = None
    loader = None
    variable_manager = VariableManager()
    action = ActionModule(
        disp=disp,
        conn=conn,
        tqm=tqm,
        loader=loader,
        variable_manager=variable_manager
    )

    # The following code is a unit test for method run of class ActionModule
    # What are the inputs to this method?
    #
    # tmp:             None
    # task_vars:       dict
    #
    # dependent?
    #
    # What are

# Generated at 2022-06-23 07:46:46.734299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {
        'src': '/etc/hosts',
        'dest': '/tmp',
    }
    source = '/etc/hosts'
    dest = '/tmp'
    follow = False

    # Create ActionModule object.
    action_module = None
    try:
        action_module = ActionModule(task_args=task_args, templar=None)
    except Exception as err:
        assert False, 'Unable to create ActionModule object: {0}'.format(err)

    # Test with error.
    result = {'failed': True}
    try:
        result = action_module.run(tmp=None, task_vars=None)
    except Exception as err:
        assert False, err
    if result.get('failed', False) == True:
        assert True

# Generated at 2022-06-23 07:46:49.798034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(task=dict(task_name='task name')), ActionModule)


# Generated at 2022-06-23 07:46:59.734627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test no src or dest
    task = dict()
    task['args'] = dict()
    connection = MagicMock()
    task_vars = dict()
    am = ActionModule(connection, task, task_vars=task_vars)
    result = am.run('/tmp', task_vars=task_vars)
    assert 'failed' in result
    assert 'src (or content) is required' in result['msg']

    # test no dest
    task = dict()
    task['args'] = dict()
    task['args']['src'] = '/tmp/src'
    connection = MagicMock()
    task_vars = dict()
    am = ActionModule(connection, task, task_vars=task_vars)

# Generated at 2022-06-23 07:47:09.431091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case: basic 
    # Case specification:
    #       ActionModule(self, task, connection, play_context, loader, templar, shared_loader_obj)
    #       method run(tmp = None, task_vars = None)
    #       params:
    #           tmp = None
    #           task_vars = None
    #       result:
    #           result
    #       expected:
    #           result should have key failed with value True
    #           result should have key msg with value 'src (or content) is required'
    task = dict()
    play_context = dict()
    shared_loader_obj = dict()
    connection = dict()
    templar = dict()
    loader = dict()