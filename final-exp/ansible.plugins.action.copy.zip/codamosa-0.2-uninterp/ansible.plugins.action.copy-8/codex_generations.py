

# Generated at 2022-06-17 08:39:05.653363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid source and destination
    source = 'test/test_file.txt'
    dest = '/tmp/test_file.txt'
    task_vars = dict()
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    task_vars['ansible_shell_type'] = 'sh'
    task_vars['ansible_shell_executable'] = '/bin/sh'
    task_vars['ansible_user_id'] = 'root'
    task_vars['ansible_host'] = 'localhost'
    task_vars['ansible_hostname'] = 'localhost'

# Generated at 2022-06-17 08:39:13.026968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(action=dict(module_name='copy', module_args=dict(src='/tmp/src', dest='/tmp/dest'))))
    assert action_module._task.action['module_name'] == 'copy'
    assert action_module._task.action['module_args']['src'] == '/tmp/src'
    assert action_module._task.action['module_args']['dest'] == '/tmp/dest'


# Generated at 2022-06-17 08:39:22.629734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.args = dict()
    action_module._task.args['src'] = 'src'
    action_module._task.args['dest'] = 'dest'
    action_module._task.args['content'] = 'content'
    action_module._task.args['remote_src'] = False
    action_module._task.args['local_follow'] = True
    action_module._connection = Mock()
    action_module._connection._shell = Mock()
    action_module._connection._shell.tmpdir = 'tmpdir'
    action_module._remove_tmp_path = Mock()
    action_module._remove_tmp_path.return_value = None
    action_module._ensure_invocation = Mock()


# Generated at 2022-06-17 08:39:32.397151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None

    # Test with an invalid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src')))

# Generated at 2022-06-17 08:39:45.789326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = None
    task.args['content'] = None
    task.args['dest'] = None
    task.args['remote_src'] = False
    task.args['local_follow'] = True

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value='/tmp/test')
    connection._shell.expand_user = Mock(return_value='/tmp/test')
    connection._shell.exists = Mock(return_value=False)
    connection._shell.isdir = Mock

# Generated at 2022-06-17 08:39:59.945462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = mock.Mock()

# Generated at 2022-06-17 08:40:05.130570
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:40:14.597480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:40:21.301623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection
    connection = Connection()
    # Create a mock task
    task = Task()
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock module_return
    module_return = dict(changed=False)
    # Create a mock result
    result = dict(failed=True)
    # Create a mock source
    source = None
    # Create a mock content
    content = None
    # Create a mock dest
    dest = None
    # Create a mock remote_src
    remote_src = False
    # Create a mock local_follow
    local_follow = True
    # Create a mock trailing_slash
    trailing_slash = False
    # Create a mock source_full
    source_full = None
    #

# Generated at 2022-06-17 08:40:32.305626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test environment
    # Create a mock connection plugin
    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = '/tmp/ansible-tmp-1468671472.52-140587815765038'
    mock_connection._shell.join_path = Mock(return_value='/tmp/ansible-tmp-1468671472.52-140587815765038/test_file')
    mock_connection._shell.path_has_trailing_slash = Mock(return_value=False)
    mock_connection._shell.expand_user = Mock(return_value='/home/test_user')
    mock_connection._shell.join_path = Mock(return_value='/home/test_user/test_file')
    mock_

# Generated at 2022-06-17 08:41:28.681336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src='/path/to/src',
        dest='/path/to/dest',
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/path/to/tmpdir'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith(os.path.sep)
    connection._shell.split_path = lambda x: (x, '')
    connection._shell.expand_user = lambda x: x
    connection._shell.quote = lambda x: x

    # Create a mock

# Generated at 2022-06-17 08:41:35.064848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task == task
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    # Test with an invalid task
    task = dict(action=dict(module='copy', args=dict()))

# Generated at 2022-06-17 08:41:43.780949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    am = ActionModule(task, connection=dict(module='local'))
    assert am._task == task
    assert am._connection == dict(module='local')

    # Test with an invalid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src')))
    try:
        am = ActionModule(task, connection=dict(module='local'))
        assert False
    except AnsibleError as e:
        assert 'missing required arguments: dest' in to_native(e)


# Generated at 2022-06-17 08:41:55.285316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src='/etc/hosts',
        dest='/tmp/hosts',
        content=None,
        remote_src=False,
        local_follow=True,
    )
    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.expand_user = lambda x: x
    connection._shell.split_path = lambda x: x.split('/')

# Generated at 2022-06-17 08:41:55.939859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:42:06.339101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()

# Generated at 2022-06-17 08:42:17.846532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None

    # Test with a task that is not a dict
    task = 'not a dict'

# Generated at 2022-06-17 08:42:30.473484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = Task()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['content'] = 'content'
    task.args['remote_src'] = False
    task.args['local_follow'] = True

    # Create a mock connection.
    connection = Connection()
    connection._shell = Shell()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.path_has_trailing_slash = lambda x: False

    # Create a mock loader.
    loader = DictDataLoader({})

    # Create a mock variable manager.
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()



# Generated at 2022-06-17 08:42:43.615716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True
    )
    # Create a mock connection object
    connection = Mock()
    # Create a mock shell object
    shell = Mock()
    shell.path_has_trailing_slash.return_value = False
    shell.join_path.return_value = '/tmp/ansible_file_payload_test_file'
    connection._shell = shell
    # Create a mock tmp object
    tmp = Mock()
    # Create a mock task_vars object
    task_vars = dict()
    # Create a mock loader object
    loader = Mock()
    # Create a mock module_loader object
    module

# Generated at 2022-06-17 08:42:52.797626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['remote_src'] = False
    task.args['local_follow'] = True

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value='path')
    connection._shell.join_path.side_effect = lambda x, y: x + y
    connection._shell.join_path.side_effect = lambda x, y: x + y
    connection._shell.join_path

# Generated at 2022-06-17 08:44:32.897040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:44:46.331837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()
    task.args = dict(
        src='/home/user/test.txt',
        dest='/home/user/test.txt',
        content=None,
        remote_src=False,
        local_follow=True,
        follow=False,
        checksum=None,
        mode=None,
        owner=None,
        group=None,
        selevel=None,
        serole=None,
        setype=None,
        seuser=None,
        backup=False,
        force=False,
        validate=None,
        directory_mode=None,
        remote_src=False,
        local_follow=True,
    )
    task.action = 'copy'
    task.async_val = None
    task.async_seconds

# Generated at 2022-06-17 08:44:53.233355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    # Create a mock task
    mock_task = Mock()
    mock_task.args = {'src': 'src', 'dest': 'dest'}
    mock_task.action = 'action'
    mock_task.async_val = 15
    mock_task.notify = ['notify']
    mock_task.run_once = True
    mock_task.delegate_to = 'delegate_to'
    mock_task.delegate_facts = True
    mock_task.register = 'register'
    mock_task.environment = {'environment': 'environment'}
    mock_task.sudo = True
    mock_task.sudo_user = 'sudo_user'
    mock_task.when = ['when']
    mock_task.tags = ['tags']
    mock_task.any_errors_

# Generated at 2022-06-17 08:45:04.632422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    am = ActionModule(task, connection=dict(module='local'))
    assert am._task == task
    assert am._connection == dict(module='local')

    # Test with an invalid task
    task = dict(action=dict(module='copy'))
    try:
        am = ActionModule(task, connection=dict(module='local'))
        assert False
    except AnsibleError as e:
        assert 'missing required arguments' in to_text(e)

    # Test with an invalid connection
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))

# Generated at 2022-06-17 08:45:16.159873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    # Create a fake play context
    play_context = dict(remote_addr='127.0.0.1', password='password')
    # Create a fake loader
    loader = DictDataLoader({})
    # Create a fake variable manager
    variable_manager = VariableManager()
    # Create a fake connection
    connection = Connection(play_context, new_stdin=None)
    # Create a ActionModule object
    am = ActionModule(task, connection, play_context, loader, variable_manager)
    # Assert that the object is an instance of ActionModule
    assert isinstance(am, ActionModule)


# Generated at 2022-06-17 08:45:18.528364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:45:31.532342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = {'src': 'src', 'dest': 'dest', 'content': 'content', 'remote_src': False, 'local_follow': True}
    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.path_has_trailing_slash = Mock(return_value=True)
    connection._shell.join_path = Mock(return_value='path')
    connection._shell.join_path.side_effect = lambda *args: '/'.join(args)
    connection._shell.split_path = Mock(return_value=['path'])
    connection._shell.split_path.side_effect = lambda path: path.split('/')
    connection

# Generated at 2022-06-17 08:45:41.024903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am._task.action == 'copy'
    assert am._task.args == {}

    # Test with args
    am = ActionModule(dict(action='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    assert am._task.action == 'copy'
    assert am._task.args == dict(src='/tmp/src', dest='/tmp/dest')


# Generated at 2022-06-17 08:45:48.360916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    mock_task = Mock()

# Generated at 2022-06-17 08:45:59.307330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = Mock()
    task.args = dict()

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.split_path = lambda x: x.split('/')
    connection._shell.expand_user = lambda x: x
    connection._shell.quote = lambda x: x

    # Create a mock loader.
    loader = Mock()

    # Create a mock templar.
    templar = Mock()

    # Create a mock module_common.
    module_common = Mock()

    # Create a mock