

# Generated at 2022-06-17 08:39:16.237715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = mock.Mock()
    mock_module.params = {'src': 'test_src', 'dest': 'test_dest'}
    mock_module.run.return_value = {'failed': False}

    # Create a mock object for the connection class
    mock_connection = mock.Mock()
    mock_connection.shell.path_has_trailing_slash.return_value = False
    mock_connection.tmpdir = 'test_tmpdir'
    mock_connection.remote_expand_user.return_value = 'test_remote_expand_user'

    # Create a mock object for the task class
    mock_task = mock.Mock()

# Generated at 2022-06-17 08:39:24.745784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = Task()

# Generated at 2022-06-17 08:39:36.875773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Task()

    # Create a mock connection.
    connection = Connection()

    # Create a mock loader.
    loader = Loader()

    # Create a mock variable manager.
    variable_manager = VariableManager()

    # Create a mock templar.
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a mock action module.
    action_module = ActionModule(task=task, connection=connection, templar=templar, loader=loader, variable_manager=variable_manager)

    # Create a mock task args.
    task_args = dict()

    # Create a mock task vars.
    task_vars = dict()

    # Create a mock tmp.
    tmp = None

    # Run the method under test.
    result = action_module

# Generated at 2022-06-17 08:39:45.789776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/source', dest='/tmp/dest')))
    am = ActionModule(task, connection=dict(module='local'))
    assert am._task == task
    assert am._connection == dict(module='local')

    # Test with a invalid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/source')))
    try:
        am = ActionModule(task, connection=dict(module='local'))
        assert False
    except AnsibleError as e:
        assert 'dest is required' in to_text(e)


# Generated at 2022-06-17 08:39:59.944024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value='/tmp/foo')
    connection._shell.split_path = Mock(return_value=('/', 'tmp', 'foo'))
    connection._shell.expand_user = Mock(return_value='/tmp/foo')
    connection._shell.exists = Mock(return_value=False)


# Generated at 2022-06-17 08:40:10.932587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['content'] = 'content'
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    task.args['follow'] = False
    task.args['directory_mode'] = None
    task.args['mode'] = None
    task.args['checksum'] = None
    task.args['checksum_algorithm'] = None
    task.args['checksum_salt'] = None
    task.args['original_basename'] = None
    task.args['copy_remote_src'] = False
    task.args['set_remote_user'] = False

# Generated at 2022-06-17 08:40:19.220070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict()
    task.args['src'] = None
    task.args['content'] = None
    task.args['dest'] = None
    task.args['remote_src'] = False
    task.args['local_follow'] = True

    # Create a mock loader.
    loader = Mock()
    loader.path_dwim = Mock(return_value=None)
    loader.get_basedir = Mock(return_value=None)

    # Create a mock templar.
    templar = Mock()

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.join_path = Mock(return_value=None)
    connection._shell.path

# Generated at 2022-06-17 08:40:22.646035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule(None, None, None, None)
    assert module is not None


# Generated at 2022-06-17 08:40:34.509102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['content'] = 'content'
    task.args['remote_src'] = False
    task.args['local_follow'] = True

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value='path')
    connection._shell.join_path.side_effect = lambda x, y: x + y

# Generated at 2022-06-17 08:40:38.632827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule(None, None, None, None, None, None)
    assert module is not None

    # Test with args
    module = ActionModule(None, None, None, None, None, None, None)
    assert module is not None

# Generated at 2022-06-17 08:41:36.076838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()

# Generated at 2022-06-17 08:41:48.260555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['follow'] = False
    task.args['recurse'] = False
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    task.args['checksum'] = 'md5'
    task.args['mode'] = 'preserve'
    task.args['directory_mode'] = 'preserve'
    task.args['content'] = None
    task.args['original_basename'] = None
    task.args['content_tempfile'] = None

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()

# Generated at 2022-06-17 08:41:57.234367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock task object
    task = MockTask()
    # Create a mock action module object
    action_module = ActionModule(connection, task)
    # Create a mock task_vars object
    task_vars = dict()
    # Create a mock tmp object
    tmp = dict()
    # Create a mock result object
    result = dict()
    # Create a mock source object
    source = dict()
    # Create a mock content object
    content = dict()
    # Create a mock dest object
    dest = dict()
    # Create a mock remote_src object
    remote_src = dict()
    # Create a mock local_follow object
    local_follow = dict()
    # Create a mock module_return object
    module_return = dict()
    # Create

# Generated at 2022-06-17 08:42:03.383344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()

# Generated at 2022-06-17 08:42:17.298202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    # Create a mock action module
    action_module = ActionModule()
    # Create a mock task
    task = Task()
    # Create a mock task args
    task_args = dict()
    # Create a mock task vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock result
    result = dict()
    # Create a mock source
    source = None
    # Create a mock content
    content = None
    # Create a mock dest
    dest = None
    # Create a mock remote_src
    remote_src = False
    # Create a mock local_follow
    local_follow = True
    # Create a mock content_tempfile
    content_tempfile = None
    # Create a mock module_return
    module_return = dict()
    # Create

# Generated at 2022-06-17 08:42:18.170762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass


# Generated at 2022-06-17 08:42:29.073762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor for class ActionModule
    '''
    # Create a task
    task = Task()

    # Create a connection
    connection = Connection()

    # Create a loader
    loader = DataLoader()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create an action module
    action_module = ActionModule(task, connection, loader, variable_manager)

    # Check the action module
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._loader == loader
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None
    assert action_module._task_vars == {}
    assert action_module._tmp is None
    assert action_module._play_context == None
    assert action_module._

# Generated at 2022-06-17 08:42:40.188114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    task.args['follow'] = False
    task.args['checksum'] = False
    task.args['mode'] = None
    task.args['directory_mode'] = None
    task.args['content'] = None
    task.args['recurse'] = True
    task.args['backup'] = False
    task.args['force'] = False
    task.args['validate'] = None
    task.args['original_basename'] = None
    task.args['copy_remote_src'] = False

# Generated at 2022-06-17 08:42:51.206740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True,
    )
    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value=None)
    connection._shell.tmpdir = None
    connection._shell.join_path = Mock(return_value=None)
    connection._shell.join_path = Mock(return_value=None)
    connection._shell.join_path = Mock(return_value=None)

# Generated at 2022-06-17 08:42:55.061133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Create a task
    task = Task()
    # Create a task result
    task_result = TaskResult(host=None, task=task)
    # Create a connection
    connection = Connection(None)
    # Create an action module
    action_module = ActionModule(task, connection, task_result, None)
    # Check the action module
    assert action_module is not None


# Generated at 2022-06-17 08:44:03.655954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid source and dest
    source = 'test_source'
    dest = 'test_dest'
    task_vars = dict()
    task_vars['ansible_check_mode'] = False
    task_vars['ansible_ssh_executable'] = 'ssh'
    task_vars['ansible_ssh_common_args'] = '-o ControlMaster=auto -o ControlPersist=60s'
    task_vars['ansible_ssh_extra_args'] = ''
    task_vars['ansible_sftp_extra_args'] = ''
    task_vars['ansible_scp_extra_args'] = ''
    task_vars['ansible_ssh_pipelining'] = False
    task_vars['ansible_ssh_private_key_file'] = None

# Generated at 2022-06-17 08:44:08.544603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Test with no task
    action_module = ActionModule(None)
    assert action_module._task is None

    # Test with a task
    task = Task()
    action_module = ActionModule(task)
    assert action_module._task == task


# Generated at 2022-06-17 08:44:16.299394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid source and dest
    source = '/tmp/test_source'
    dest = '/tmp/test_dest'
    task_vars = dict()
    module_return = dict(changed=False)
    module_return_copy_file = dict(changed=False)
    module_return_execute_module = dict(changed=False)
    module_return_execute_remote_stat = dict(changed=False)
    module_return_execute_module_file = dict(changed=False)
    module_return_execute_module_copy = dict(changed=False)
    module_return_execute_module_file_module = dict(changed=False)
    module_return_execute_module_copy_module = dict(changed=False)