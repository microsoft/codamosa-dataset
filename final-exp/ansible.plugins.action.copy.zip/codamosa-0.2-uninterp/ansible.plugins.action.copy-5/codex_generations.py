

# Generated at 2022-06-17 08:39:10.167207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule(None, None, None, None, None)
    assert module._task.args == dict()

    # Test with args
    module = ActionModule(None, None, None, None, dict(src='/tmp/src', dest='/tmp/dest'))
    assert module._task.args == dict(src='/tmp/src', dest='/tmp/dest')

# Generated at 2022-06-17 08:39:21.048514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    action_module = ActionModule(task, connection=dict(module='local'))
    assert action_module._task == task
    assert action_module._connection == dict(module='local')

    # Test with an invalid task
    task = dict(action=dict(module='copy'))
    with pytest.raises(AnsibleError) as exc:
        ActionModule(task, connection=dict(module='local'))
    assert to_text(exc.value) == "invalid task, missing required arguments: ['args']"

    # Test with an invalid connection

# Generated at 2022-06-17 08:39:31.373248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task.
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    task.args['follow'] = False
    task.args['checksum'] = False
    task.args['mode'] = None
    task.args['directory_mode'] = None
    task.args['content'] = None
    task.args['recurse'] = False
    task.args['original_basename'] = None
    task.args['copy_remote_src'] = False
    task.args['copy_local_src'] = False
    task.args['copy_unsafe_writes'] = False

# Generated at 2022-06-17 08:39:44.808306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock action module object
    action_module = ActionModule(connection=connection)
    # Create a mock task object
    task = MockTask()
    # Create a mock task object
    task_vars = MockTaskVars()
    # Create a mock tmp object
    tmp = MockTmp()
    # Create a mock result object
    result = MockResult()
    # Create a mock module_return object
    module_return = MockModuleReturn()
    # Create a mock source_files object
    source_files = MockSourceFiles()
    # Create a mock module_executed object
    module_executed = MockModuleExecuted()
    # Create a mock changed object
    changed = MockChanged()
    # Create a mock implicit_directories object
    implicit_directories = Mock

# Generated at 2022-06-17 08:39:58.910051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = dict(
        src='/path/to/src',
        dest='/path/to/dest',
        remote_src=False,
        local_follow=True,
    )
    mock_task.action = 'copy'

    # Create a mock connection
    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = '/path/to/tmp'
    mock_connection._shell.join_path = os.path.join
    mock_connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    mock_connection._shell.path_has_trailing_slash.__name__ = 'path_has_trailing_slash'


# Generated at 2022-06-17 08:40:10.888887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True,
    )
    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith(os.path.sep)
    connection._shell.split_path = lambda x: x.split(os.path.sep)
    connection._shell.expand_user = lambda x: x
    connection._shell.quote = lambda x: x
    connection._shell.path_has_trailing_

# Generated at 2022-06-17 08:40:19.148643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    task.args['follow'] = False
    task.args['directory_mode'] = None
    task.args['mode'] = None
    task.args['content'] = None
    task.args['checksum'] = None
    task.args['recurse'] = True
    task.args['original_basename'] = None
    task.args['copy_remote_src'] = True
    task.args['set_remote_user'] = True
    task.args['remote_user'] = None
    task.args['validate_certs'] = True

# Generated at 2022-06-17 08:40:31.447378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src='/path/to/src',
        dest='/path/to/dest',
        remote_src=False,
        local_follow=True,
        checksum='sha1',
        content=None,
        backup=False,
        force=False,
        validate='md5',
        directory_mode=None,
        follow=False,
        mode='preserve',
        original_basename=None,
        recurse=True,
        remote_user=None,
        selevel=None,
        serole=None,
        setype=None,
        seuser=None,
        unsafe_writes=False,
    )
    task.async_val = None
    task.notify = []

# Generated at 2022-06-17 08:40:42.734121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task.
    task = Task()
    task.args = dict(
        src='/path/to/src',
        dest='/path/to/dest',
        content='test content',
        remote_src=False,
        local_follow=True,
    )

    # Create a fake connection.
    connection = Connection()

    # Create a fake loader.
    loader = DictDataLoader({})

    # Create a fake templar.
    templar = Templar(loader=loader)

    # Create a fake shared plugin loader obj.
    shared_plugin_loader = SharedPluginLoaderObj()

    # Create a fake variable manager.
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()

    # Create a fake action module.

# Generated at 2022-06-17 08:40:52.541953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = Mock()
    connection = Mock()
    # Create a mock ansible module
    module = Mock()
    # Create a mock ansible module args
    module_args = dict()
    # Create a mock ansible module result
    module_result = dict()
    # Create a mock ansible module return value
    module_return_value = dict()
    # Create a mock ansible module invocation
    module_invocation = dict()
    # Create a mock ansible module invocation
    module_invocation_result = dict()
    # Create a mock ansible module invocation
    module_invocation_result_result = dict()
    # Create a mock ansible module invocation
    module_invocation_result_result_result = dict()
    # Create a mock ansible module invocation
    module_invocation_result_

# Generated at 2022-06-17 08:41:42.041360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src='/path/to/src',
        dest='/path/to/dest',
        remote_src=False,
        local_follow=True
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/path/to/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith(os.path.sep)
    connection._shell.split_path = lambda x: (os.path.dirname(x), os.path.basename(x))
    connection._shell.expand_user = lambda x: x

# Generated at 2022-06-17 08:41:45.629142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:41:48.741540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-17 08:41:57.704173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    # Create a mock task with a mock connection
    task = mock.Mock()
    task.args = dict(
        src='/path/to/src',
        dest='/path/to/dest',
        remote_src=False,
        local_follow=True,
    )
    task.action = 'copy'
    task.async_val = 42
    task.notify = ['test_handler']
    task.run_once = False
    task.no_log = False
    task.rerun = []
    task.role_name = None
    task.loop = None
    task.when = None
    task.changed_when = None
    task.failed_when = None
    task.always_run = False
    task.register = 'test_register'
    task.until = None
   

# Generated at 2022-06-17 08:42:03.684825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a module that returns a dict
    module = ActionModule(dict(action=dict(module_name='test_module', module_args=dict(arg1='arg1', arg2='arg2'))))
    module._execute_module = lambda module_name, module_args, task_vars: dict(changed=True, rc=0, stdout='stdout', stderr='stderr')
    result = module.run(task_vars=dict())
    assert result == dict(changed=True, rc=0, stdout='stdout', stderr='stderr')

    # Test with a module that returns a string
    module = ActionModule(dict(action=dict(module_name='test_module', module_args=dict(arg1='arg1', arg2='arg2'))))

# Generated at 2022-06-17 08:42:15.572838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    am = ActionModule(task, connection=dict(module='local'))
    assert am._task == task
    assert am._connection == dict(module='local')

    # Test with an invalid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src')))
    try:
        am = ActionModule(task, connection=dict(module='local'))
        assert False
    except AnsibleError as e:
        assert 'dest is required' in to_text(e)


# Generated at 2022-06-17 08:42:21.287101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    module = ActionModule(task=dict(action=dict(module_name='copy', module_args=dict(src='/tmp/src', dest='/tmp/dest'))))
    assert module._task.action['module_name'] == 'copy'
    assert module._task.action['module_args'] == {'src': '/tmp/src', 'dest': '/tmp/dest'}


# Generated at 2022-06-17 08:42:32.099093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    task.args['follow'] = False
    task.args['directory_mode'] = None
    task.args['mode'] = None
    task.args['content'] = None
    task.args['checksum'] = None
    task.args['recurse'] = False
    task.args['original_basename'] = None

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None

# Generated at 2022-06-17 08:42:43.773145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
    task = mock.Mock()
    connection = mock.Mock()
    # Create a mock task and connection
   

# Generated at 2022-06-17 08:42:51.840085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no source, no content, no dest
    task_vars = dict()
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    task_vars['ansible_check_mode'] = False
    task_vars['ansible_verbosity'] = 0
    task_vars['ansible_version'] = '2.9.9'
    task_vars['ansible_version_full'] = '2.9.9'
    task_vars['ansible_version_major'] = '2'
    task_vars['ansible_version_minor'] = '9'
    task_vars['ansible_version_revision'] = '9'

# Generated at 2022-06-17 08:44:02.649041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Create a task
    task = Task()

# Generated at 2022-06-17 08:44:13.366765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src='/home/test/test.txt',
        dest='/home/test/test.txt',
        content=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value='/home/test/test.txt')
    connection._shell.join_path.side_effect = lambda *args: '/'.join(args)

# Generated at 2022-06-17 08:44:24.069955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection
    connection = Connection()
    # Create a mock task
    task = Task()
    # Create a mock action module
    action_module = ActionModule(connection, task)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict()

    # Create a mock source
    source = None

    # Create a mock content
    content = None

    # Create a mock dest
    dest = None

    # Create a mock remote_src
    remote_src = False

    # Create a mock local_follow
    local_follow = True

    # Create a mock module_return
    module_return = dict(changed=False)

    # Create a mock module_executed
    module_executed = False

   

# Generated at 2022-06-17 08:44:29.661905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    raise NotImplementedError()


# Generated at 2022-06-17 08:44:40.236678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src='/home/user/test.txt',
        dest='/home/user/test.txt',
        remote_src=False,
        local_follow=True
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.join_path = os.path.join
    connection._shell.split_path = lambda x: x.split('/')
    connection._shell.expand_user = lambda x: x.replace('~', '/home/user')

    # Create a mock loader
    loader = Mock()
    loader

# Generated at 2022-06-17 08:44:41.682481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:44:51.214151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict()

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = os.path.path_has_trailing_slash
    connection._shell.split_path = os.path.split
    connection._shell.expand_user = os.path.expanduser
    connection._shell.quote = shlex_quote
    connection._shell.path_has_trailing_slash = os.path.path_has_trailing_slash
    connection._shell.join_path = os.path.join
    connection._shell.split_path = os.path

# Generated at 2022-06-17 08:45:04.133396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task to test with
    task = Task()
    task.args = dict(
        src='/home/user/test.txt',
        dest='/home/user/test2.txt',
        remote_src=False,
        local_follow=True
    )

    # Create a mock connection to test with
    connection = Connection()
    connection._shell = Shell()
    connection._shell.tmpdir = '/tmp'
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.join_path = lambda x, y: x + '/' + y

    # Create a mock loader to test with

# Generated at 2022-06-17 08:45:16.159865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    # Create a mock task
    mock_task = MagicMock()
    mock_task.args = dict()

    # Create a mock connection
    mock_connection = MagicMock()

    # Create a mock loader
    mock_loader = MagicMock()

    # Create a mock templar
    mock_templar = MagicMock()

    # Create a mock display
    mock_display = MagicMock()

    # Create a mock action plugin
    mock_action_plugin = MagicMock()

    # Create a mock shared loader plugin
    mock_shared_loader_plugin = MagicMock()

    # Create a mock shell
    mock_shell = MagicMock()

    # Create a mock connection plugin
    mock_connection_plugin = MagicMock()

    # Create a

# Generated at 2022-06-17 08:45:30.582315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a task that has a 'src' argument
    task = dict(action=dict(module='copy', args=dict(src='/path/to/src')))
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task.args['src'] == '/path/to/src'

    # Test with a task that has a 'content' argument
    task = dict(action=dict(module='copy', args=dict(content='some content')))
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task.args['content'] == 'some content'

    # Test with a task that has both a

# Generated at 2022-06-17 08:46:28.945500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module = ActionModule()

    # Create a mock object of class Task
    task = Task()

    # Create a mock object of class Connection
    connection = Connection()

    # Create a mock object of class Shell
    shell = Shell()

    # Set the attributes of the mock object of class Connection
    connection._shell = shell

    # Set the attributes of the mock object of class Task
    task.args = {'src': 'src', 'dest': 'dest'}
    task._connection = connection

    # Set the attributes of the mock object of class ActionModule
    action_module._task = task

    # Call the method run of class ActionModule
    result = action_module.run()

    # Check the result
    assert result['failed'] == True

# Generated at 2022-06-17 08:46:39.027802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='src', dest='dest')))
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

    # Test with an invalid task
    task = dict(action=dict(module='copy', args=dict(src='src')))
    try:
        action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        assert False
    except AnsibleActionFail:
        pass

# Generated at 2022-06-17 08:46:50.430731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True
    )

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith(os.path.sep)
    connection._shell.expand_user = lambda x: x
    connection._shell.quote = lambda x: x

    # Create a mock loader.
    loader = Mock()
    loader.path_dwim = lambda x: x

    # Create a mock templ

# Generated at 2022-06-17 08:46:56.046424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(action=dict(module_name='copy', module_args=dict(src='src', dest='dest'))))
    assert module._task.action['module_name'] == 'copy'
    assert module._task.action['module_args'] == {'src': 'src', 'dest': 'dest'}
    assert module._task.args == {'src': 'src', 'dest': 'dest'}


# Generated at 2022-06-17 08:47:04.088007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='src', dest='dest')))
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._task == task
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

    # Test with a task without action
    task = dict()

# Generated at 2022-06-17 08:47:15.086294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src='/home/test/test.txt',
        dest='/home/test/test.txt',
        content=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.expand_user = lambda x: x
    connection._shell.split_path = lambda x: x.split('/')
    connection._shell.quote = lambda x: x
    connection._shell.path

# Generated at 2022-06-17 08:47:16.189757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    raise NotImplementedError()


# Generated at 2022-06-17 08:47:27.731920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()
    task.args = dict(
        content=None,
        dest='/home/test/test_file',
        follow=False,
        mode=None,
        owner=None,
        group=None,
        remote_src=False,
        selevel=None,
        serole=None,
        setype=None,
        seuser=None,
        src='/home/test/test_file',
        validate=None
    )
    # Create a mock connection
    connection = Connection()
    connection._shell = Shell()
    connection._shell.tmpdir = '/tmp'
    connection._shell.path_has_trailing_slash = lambda x: False
    connection._shell.join_path = lambda x, y: x + y
    connection._shell.split_

# Generated at 2022-06-17 08:47:33.966324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection
    connection = mock.Mock()
    connection._shell = mock.Mock()
    connection._shell.tmpdir = None
    connection._shell.path_has_trailing_slash = mock.Mock(return_value=False)
    connection._shell.join_path = mock.Mock(return_value='')
    connection._shell.join_path.side_effect = lambda *args: '/'.join(args)
    connection._shell.join_path.return_value = ''

# Generated at 2022-06-17 08:47:42.661884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task with a mock connection
    mock_task = Mock()
    mock_task.args = {'src': 'test_src', 'dest': 'test_dest'}
    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = 'test_tmpdir'
    mock_connection._shell.join_path = Mock(return_value='test_path')
    mock_connection._shell.path_has_trailing_slash = Mock(return_value=False)
    mock_connection._shell.exists = Mock(return_value=True)
    mock_connection._shell.isdir = Mock(return_value=True)
    mock_connection._shell.isfile = Mock(return_value=True)