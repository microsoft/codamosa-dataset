

# Generated at 2022-06-17 08:38:58.371305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action = ActionModule()
    assert action._task.args == dict()

    # Test with args
    action = ActionModule(dict(foo='bar'))
    assert action._task.args == dict(foo='bar')

# Generated at 2022-06-17 08:39:11.660505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task.action == 'copy'
    assert action._task.args['src'] == '/tmp/src'
    assert action._task.args['dest'] == '/tmp/dest'

    # Test with an invalid task
    task = dict(action=dict(module='copy', args=dict()))

# Generated at 2022-06-17 08:39:13.300343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:39:22.770600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        content=None,
        dest='/home/user/test_file',
        follow=False,
        local_follow=True,
        mode=None,
        original_basename=None,
        path='/home/user/test_file',
        remote_src=False,
        src='/home/user/test_file',
        state='file',
        unsafe_writes=False
    )
    task.action = 'copy'
    task.async_val = None
    task.async_jid = None
    task.delegate_to = None
    task.delegate_facts = None
    task.environment = None
    task.first_available_file = None
    task.loop = None

# Generated at 2022-06-17 08:39:28.113559
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(dict(action='copy'))
    assert action is not None
    assert action._task.action == 'copy'

    # Test with an invalid action
    action = ActionModule(dict(action='invalid'))
    assert action is not None
    assert action._task.action == 'invalid'


# Generated at 2022-06-17 08:39:41.127179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()

# Generated at 2022-06-17 08:39:53.726998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        content=None,
        dest='/home/ansible/test.txt',
        follow=False,
        local_follow=True,
        mode='preserve',
        remote_src=False,
        src='/home/ansible/test.txt'
    )

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.expand_user = lambda x: x
    connection._shell.split_path = lambda x: x.split('/')
   

# Generated at 2022-06-17 08:40:03.783569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        src='/tmp/src',
        dest='/tmp/dest',
        remote_src=False,
        local_follow=True,
        content=None,
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.path_has_trailing_slash.return_value = False
    connection._shell.join_path.return_value = '/tmp/dest'
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path

# Generated at 2022-06-17 08:40:13.272526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src='/tmp/src',
        dest='/tmp/dest',
        content=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.expand_user = lambda x: x
    connection._shell.split_path = lambda x: x.split(os.path.sep)
    connection._shell.quote = lambda x: x
    connection._shell.unquote

# Generated at 2022-06-17 08:40:20.456156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()

# Generated at 2022-06-17 08:41:09.275428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

    # Test with args
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action_module is not None


# Generated at 2022-06-17 08:41:17.061451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule()
    assert module._task.action == 'copy'
    assert module._task.args == {}
    assert module._connection.host == 'localhost'
    assert module._connection.port == 22
    assert module._connection.user == 'root'
    assert module._connection.password == ''
    assert module._connection.private_key_file == ''
    assert module._connection.timeout == 10
    assert module._connection.shell is not None
    assert module._loader.get_basedir() == '~/.ansible/tmp/ansible-tmp-1460757972.94-147729857856000/'
    assert module._templar is not None
    assert module._shared_loader_obj.module_loader is not None

# Generated at 2022-06-17 08:41:30.765803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Task()
    # Create a mock connection
    connection = Connection()
    # Create a mock module
    module = ActionModule(task, connection)
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock result
    result = dict()
    # Create a mock source
    source = None
    # Create a mock content
    content = None
    # Create a mock dest
    dest = None
    # Create a mock remote_src
    remote_src = False
    # Create a mock local_follow
    local_follow = True
    # Create a mock trailing_slash
    trailing_slash = False
    # Create a mock source_full
    source_full = None
    # Create a mock source_rel


# Generated at 2022-06-17 08:41:36.690310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule()
    assert module._task.action == 'copy'
    assert module._task.args == {}

    # Test with args
    module = ActionModule(dict(action='copy', args=dict(src='/tmp/src', dest='/tmp/dest')))
    assert module._task.action == 'copy'
    assert module._task.args == dict(src='/tmp/src', dest='/tmp/dest')


# Generated at 2022-06-17 08:41:43.358403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = dict()

    # Create a mock connection
    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = '/tmp/ansible-tmp-1423961596.97-147729857856000'
    mock_connection._shell.path_has_trailing_slash = Mock(return_value=False)
    mock_connection._shell.join_path = Mock(return_value='/tmp/ansible-tmp-1423961596.97-147729857856000/source')
    mock_connection._shell.join_path.side_effect = lambda x, y: '/'.join([x, y])

# Generated at 2022-06-17 08:41:50.143303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(action=dict(module_name='copy', module_args=dict(src='src', dest='dest'))))
    assert module._task.action == 'copy'
    assert module._task.args == dict(src='src', dest='dest')
    assert module._task.action == 'copy'
    assert module._task.args == dict(src='src', dest='dest')


# Generated at 2022-06-17 08:41:59.059560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict()
    task.args['src'] = None
    task.args['content'] = None
    task.args['dest'] = None
    task.args['remote_src'] = False
    task.args['local_follow'] = True
    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value='/tmp/foo')
    connection._shell.split_path = Mock(return_value=['/', 'tmp', 'foo'])
    connection._shell.expand_user = Mock(return_value='/tmp/foo')


# Generated at 2022-06-17 08:42:10.912888
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:42:20.263699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = dict(
        content=None,
        dest='/home/user/test_file',
        follow=False,
        local_follow=True,
        mode='preserve',
        remote_src=False,
        src='/home/user/test_file'
    )

    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.path_has_trailing_slash.__name__ = 'path_has_trailing_slash'
    connection._shell.join_path

# Generated at 2022-06-17 08:42:22.978814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 08:44:11.597436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Create a task object
    task = Task()

    # Create a task result object
    task_result = TaskResult(host=None, task=task)

    # Create a connection object
    connection = Connection(play_context=PlayContext())

    # Create a action module object
    action_module = ActionModule(task=task, connection=connection, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    # Check if the object is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-17 08:44:23.320431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = None
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.join_path = Mock(return_value=None)
    connection._shell.join_path.side_effect = lambda *args: '/'.join(args)
    connection._shell.join_path.return_value = None
    connection._shell.join_path.side_effect = lambda *args: '/'.join(args)
    connection._

# Generated at 2022-06-17 08:44:40.017907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = Task()
    task.args = {'src': 'test_src', 'dest': 'test_dest'}
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None

    # Test with an invalid task
    task = Task()
    task.args = {}

# Generated at 2022-06-17 08:44:44.752963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()
    task.args = {'src': 'src', 'dest': 'dest'}
    # Create a mock connection
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.split_path = os.path.split
    connection._shell.expand_user = os.path.expanduser
    connection._shell.exists = lambda x: True
    connection._shell.isdir = lambda x: False
    connection._shell.isfile = lambda x: True

# Generated at 2022-06-17 08:44:52.084294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = Mock()

# Generated at 2022-06-17 08:45:04.238859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src=None,
        content=None,
        dest=None,
        remote_src=False,
        local_follow=True,
    )
    # Create a mock connection.
    connection = Mock()
    # Create a mock loader.
    loader = Mock()
    # Create a mock templar.
    templar = Mock()
    # Create a mock play context.
    play_context = Mock()
    # Create a mock AnsibleModule.
    ansible_module = Mock()
    # Create a mock AnsibleModule.
    ansible_module_return = Mock()
    ansible_module_return.get.return_value = None
    ansible_module.return_value = ansible_module_return
    # Create a

# Generated at 2022-06-17 08:45:09.872319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    module = ActionModule(task=dict(action=dict(module='copy', args=dict(src='/tmp/src', dest='/tmp/dest'))))
    assert module._task.action == 'copy'
    assert module._task.args['src'] == '/tmp/src'
    assert module._task.args['dest'] == '/tmp/dest'


# Generated at 2022-06-17 08:45:19.053702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict()
    task.args['src'] = 'src'
    task.args['dest'] = 'dest'
    task.args['content'] = 'content'
    task.args['remote_src'] = False
    task.args['local_follow'] = True

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.join_path = Mock(return_value='path')
    connection._shell.path_has_trailing_slash = Mock(return_value=False)
    connection._shell.exists = Mock(return_value=True)
    connection._shell.isdir = Mock(return_value=True)
    connection._shell.isf

# Generated at 2022-06-17 08:45:31.716012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = dict(
        src='/home/user/test.txt',
        dest='/home/user/test.txt',
        content=None,
        remote_src=False,
        local_follow=True,
    )

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = '/tmp'
    connection._shell.path_has_trailing_slash = lambda x: x.endswith('/')
    connection._shell.join_path = lambda x, y: x + '/' + y
    connection._shell.split_path = lambda x: x.split('/')
    connection._shell.expand_user = lambda x: x

# Generated at 2022-06-17 08:45:41.588977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task.
    task = Mock()
    task.args = {'src': 'src', 'dest': 'dest', 'remote_src': False, 'local_follow': True}

    # Create a mock connection.
    connection = Mock()
    connection._shell = Mock()
    connection._shell.tmpdir = 'tmpdir'
    connection._shell.join_path = os.path.join
    connection._shell.path_has_trailing_slash = os.path.has_trailin