

# Generated at 2022-06-17 14:12:19.519595
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    import shutil
    from ansible.plugins.loader import vars_loader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create subdirectory 'group_vars'
    os.mkdir(os.path.join(tmpdir, 'group_vars'))

    # Create file 'group_vars/all'
    path = os.path.join(tmpdir, 'group_vars', 'all')
    with open(path, 'w') as f:
        f.write('---\n')
        f.write('foo: bar\n')

    # Create subdirectory 'host_vars'
    os.mkdir(os.path.join(tmpdir, 'host_vars'))

    # Create file 'host_vars/localhost'

# Generated at 2022-06-17 14:12:30.444504
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.vars import BaseVarsPlugin
    import os
    import shutil
    import tempfile
    import json
    import yaml


# Generated at 2022-06-17 14:12:43.781556
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/tmp/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_module = VarsModule()
    vars_module.get_vars(loader=vars_loader, path='/tmp/hosts', entities=inventory.get_hosts())
    vars_module.get_vars(loader=vars_loader, path='/tmp/hosts', entities=inventory.get_groups())

# Generated at 2022-06-17 14:12:48.844949
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    import json
    import os
    import shutil
    import tempfile
    import pytest


# Generated at 2022-06-17 14:12:59.953462
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test with Host
    host = Host('localhost')
    vars_module = VarsModule()
    vars_module._basedir = '.'
    vars_module._display = None
    vars_module._get_file_loader = None
    vars_module._get_vault_secrets = None
    vars_module._get_vault_secrets_files = None
    vars_module._get_vault_password = None
    vars_module._get_vault_password_files = None
    vars_module._get_vault_identity_list = None
    vars_module._get_vault_identity_list_files = None
    vars_module._get_vault_identity = None
    vars_module._get_vault_identity_files = None


# Generated at 2022-06-17 14:13:12.321683
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test with a group
    group = Group('test_group')
    group.vars = {'test_var': 'test_value'}
    group.source = 'test_source'
    group.set_variable('test_var2', 'test_value2')
    group.set_variable('test_var3', 'test_value3')

    # Test with a host
    host = Host('test_host')
    host.vars = {'test_var': 'test_value'}
    host.source = 'test_source'
    host.set_variable('test_var2', 'test_value2')
    host.set_variable('test_var3', 'test_value3')

    # Test with a list of entities
    entities = [group, host]

    # Test with a loader
    loader = None

# Generated at 2022-06-17 14:13:25.278257
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a fake inventory
    fake_inventory = Host(name='fake_host')
    fake_inventory.vars = {}
    # Create a fake loader
    class FakeLoader():
        def find_vars_files(self, path, entity_name):
            return ['/fake/path/to/file']
        def load_from_file(self, path, cache=True, unsafe=True):
            return {'fake_key': 'fake_value'}
    fake_loader = FakeLoader()
    # Create a fake basedir
    fake_basedir = '/fake/basedir'
    # Create a fake cache
    fake_cache = True
    # Create a fake entities
    fake_entities = [fake_inventory]
    # Create a fake path
    fake_path = '/fake/path'
    # Create a fake stage


# Generated at 2022-06-17 14:13:37.357653
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a host object
    host = Host(name='test_host')
    # Create a group object
    group = Group(name='test_group')
    # Create a variable manager object
    variable_manager = VariableManager()
    # Create a data loader object
    loader = DataLoader()

    # Create a VarsModule object
    vars_module = VarsModule()
    # Set the basedir
    vars_module._basedir = '/tmp'
    # Set the display
    vars_module._display = None

    # Test get_vars

# Generated at 2022-06-17 14:13:47.870362
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    group = Group('group1')
    host = Host('host1')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    # Create a fake loader
    loader = DataLoader()

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Create a fake

# Generated at 2022-06-17 14:13:58.257227
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a loader
    loader = DataLoader()
    # Create an inventory
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name='localhost')
    # Create a group
    group = Group(name='group1')

    # Create a VarsModule object
    vars_module = VarsModule()

    # Test get_v

# Generated at 2022-06-17 14:14:16.071967
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    inventory.add_host(host=Host(name='localhost'))
    inventory.add_group(group=Group(name='group1'))
    inventory.add_host(host=Host(name='localhost'), group='group1')

    # Create a fake loader
    loader = vars_loader
    loader.set_basedir('/tmp')

    # Create a fake path
    path = '/tmp/host_vars/localhost'

    # Create a fake entity
    entity = inventory.get_host(name='localhost')

    # Create a fake cache

# Generated at 2022-06-17 14:14:26.872585
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary playbook

# Generated at 2022-06-17 14:14:34.410110
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a fake inventory
    class FakeInventory(object):
        def __init__(self):
            self.hosts = {}
            self.groups = {}
            self.patterns = {}
            self.hosts['test_host'] = Host(name='test_host')
            self.groups['test_group'] = Group(name='test_group')
            self.patterns['test_pattern'] = Group(name='test_pattern')

    # Create a fake loader
    class FakeLoader(object):
        def __init__(self):
            self.base_path = './'
            self.path_cache = {}
            self.path_cache['./host_vars/test_host'] = ['./host_vars/test_host/test_file']

# Generated at 2022-06-17 14:14:46.340968
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name="test_host")
    group = Group(name="test_group")
    plugin = VarsModule()
    plugin.get_vars(loader, "", host)
    plugin.get_vars(loader, "", group)

# Generated at 2022-06-17 14:14:54.012351
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a host
    host = Host(name='test_host')

    # Create a group
    group = Group(name='test_group')

    # Create a loader
    loader = DataLoader()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a VarsModule object
    vars_module = VarsModule()

    # Create a vars_loader object
    vars_loader = vars_loader()

    # Set the basedir

# Generated at 2022-06-17 14:15:04.648675
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Unit test for method get_vars of class VarsModule
    '''
    # Create a mock loader object
    class MockLoader:
        def find_vars_files(self, path, entity_name):
            return [path + '/' + entity_name]
        def load_from_file(self, path, cache=True, unsafe=True):
            return {'foo': 'bar'}

    # Create a mock entity object
    class MockEntity:
        def __init__(self, name):
            self.name = name

    # Create a mock display object
    class MockDisplay:
        def __init__(self):
            self.verbosity = 0
        def debug(self, msg):
            pass
        def warning(self, msg):
            pass

    # Create a mock config object

# Generated at 2022-06-17 14:15:14.710458
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/host_group_vars/hosts'])
    host = inventory.get_host("test_host")
    group = inventory.get_group("test_group")

    vars_module = VarsModule()
    vars_module._basedir = 'tests/inventory/host_group_vars'
    vars_module._display = None
    vars_module._loader = vars_loader

    # Test with host
    host_vars = vars_module.get_vars(vars_module._loader, '', host)

# Generated at 2022-06-17 14:15:26.600573
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a loader
    loader = DataLoader()

    # Create an inventory
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name='localhost')

    # Create a group
    group = Group(name='test_group')

    # Create a VarsModule object
    vars_module = VarsModule()

    # Test get_

# Generated at 2022-06-17 14:15:36.868371
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import json
    import os


# Generated at 2022-06-17 14:15:46.361003
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    # Create inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create VarsModule object
    vars_module = VarsModule()

    # Create entities
    host = Host(name="localhost")
    group = Group(name="all")

    # Test get_vars method
    vars_module.get_vars(loader, "/etc/ansible", host, cache=True)

# Generated at 2022-06-17 14:16:01.777228
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a loader
    loader = DataLoader()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a group
    group = Group('test_group')

    # Create a host
    host = Host('test_host')

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a variable manager

# Generated at 2022-06-17 14:16:11.246650
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    import shutil
    from ansible.plugins.loader import vars_loader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary inventory file
    inv_file = os.path.join(tmpdir, 'hosts')
    with open(inv_file, 'w') as f:
        f.write("""
[group1]
host1
host2

[group2]
host3
host4
""")

    # Create a temporary group_vars directory
    group_vars_dir = os.path.join(tmpdir, 'group_vars')
    os.mkdir(group_vars_dir)
    # Create a temporary host_vars directory

# Generated at 2022-06-17 14:16:22.767897
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vars_plugin = VarsModule()
    vars_plugin.set_options({'_valid_extensions': ['.yml', '.yaml', '.json']})
    vars_plugin._basedir = 'test/unit/plugins/vars/host_group_vars'
    vars_plugin._display = None
    vars_plugin._loader = loader
    vars_plugin._inventory = None

    # Test for host
    host = Host('test_host')
    host.vars = vars_plugin.get_vars(loader, 'test/unit/plugins/vars/host_group_vars', host)

# Generated at 2022-06-17 14:16:34.933119
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a fake inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Create a fake host
    host = Host(name="localhost")
    inv_manager.add_host(host)

    # Create a fake group
    group = Group(name="test_group")
    inv_manager.add_group(group)
    inv_manager.add_child(group, host)

    # Create a fake group_vars

# Generated at 2022-06-17 14:16:44.807176
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.plugins.vars.host_group_vars import VarsModule

# Generated at 2022-06-17 14:16:55.111037
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import os
    import sys


# Generated at 2022-06-17 14:17:06.474659
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = InventoryManager(loader=DataLoader(), sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=vars_loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='all')
    vars_module = VarsModule()
    vars_module.get_vars(loader=vars_loader, path='/etc/ansible/', entities=[host, group])

# Generated at 2022-06-17 14:17:13.431261
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    import shutil
    import json
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a host_vars directory
    host_vars = os.path.join(tmpdir, 'host_vars')
    os.mkdir(host_vars)

    # Create a group_vars directory
    group_vars = os.path.join(tmpdir, 'group_vars')
    os.mkdir(group_vars)

    # Create a host_vars file
    host_vars_file = os.path.join(host_vars, 'test_host')

# Generated at 2022-06-17 14:17:25.375232
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write(
            "[defaults]\n"
            "roles_path = %s\n" % tmpdir
        )
    os.environ['ANSIBLE_CONFIG'] = path

   

# Generated at 2022-06-17 14:17:34.456962
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader

    # Create a fake host
    host = Host(name='fake_host')

    # Create a fake group
    group = Group(name='fake_group')

    # Create a fake loader
    loader = vars_loader

    # Create a fake path
    path = 'fake_path'

    # Create a fake list of entities
    entities = [host, group]

    # Create a fake cache
    cache = True

    # Create a fake basedir
    basedir = 'fake_basedir'

    # Create a fake list of found files
    found_files = ['/fake_path/fake_host.yml', '/fake_path/fake_group.yml']

    # Create a fake list of new data
    new_data = ['fake_data']

    # Create a fake

# Generated at 2022-06-17 14:18:00.911330
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes, to_native, to_text
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary inventory file
    inv_file = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    inv_

# Generated at 2022-06-17 14:18:10.163879
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Unit test for method get_vars of class VarsModule
    '''
    # Create a VarsModule object
    vars_module = VarsModule()

    # Create a Host object
    host = Host(name="host1")

    # Create a Group object
    group = Group(name="group1")

    # Create a list of entities
    entities = [host, group]

    # Create a loader object
    loader = None

    # Create a path
    path = "/home/user/ansible/inventory"

    # Call method get_vars
    vars_module.get_vars(loader, path, entities)

# Generated at 2022-06-17 14:18:19.209052
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a fake loader
    class FakeLoader(object):
        def __init__(self):
            self.vars_files = []

        def find_vars_files(self, path, entity_name):
            return self.vars_files

        def load_from_file(self, path, cache=True, unsafe=True):
            return {'test_key': 'test_value'}

    # Create a fake host
    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    # Create a fake group
    class FakeGroup(object):
        def __init__(self, name):
            self.name = name

    # Create a fake display
    class FakeDisplay(object):
        def __init__(self):
            self.debug_messages = []


# Generated at 2022-06-17 14:18:28.752782
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader

    # Create a fake inventory

# Generated at 2022-06-17 14:18:36.120561
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 14:18:47.274422
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a mock loader object
    class MockLoader(object):
        def __init__(self):
            self.vars_files = []
            self.vars_files_cache = {}

        def find_vars_files(self, path, entity_name):
            return self.vars_files

        def load_from_file(self, path, cache=True, unsafe=True):
            if path in self.vars_files_cache:
                return self.vars_files_cache[path]
            else:
                return {}

    # Create a mock display object
    class MockDisplay(object):
        def __init__(self):
            self.warnings = []
            self.debug_messages = []

        def warning(self, msg):
            self.warnings.append(msg)


# Generated at 2022-06-17 14:18:52.459095
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 14:18:59.937968
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/tmp/hosts'])
    host = inventory.get_host('localhost')
    path = '/tmp/host_vars'
    entities = [host]
    vars_module = VarsModule()
    vars_module.get_vars(vars_loader, path, entities)

# Generated at 2022-06-17 14:19:10.552787
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a fake loader
    class FakeLoader:
        def find_vars_files(self, path, entity_name):
            return [path]
        def load_from_file(self, path, cache=True, unsafe=True):
            return {'a': 'b'}
    loader = FakeLoader()

    # Create a fake host
    class FakeHost:
        def __init__(self, name):
            self.name = name
    host = FakeHost('test')

    # Create a fake group
    class FakeGroup:
        def __init__(self, name):
            self.name = name
    group = FakeGroup('test')

    # Create a fake display
    class FakeDisplay:
        def debug(self, msg):
            pass
        def warning(self, msg):
            pass
    display = FakeDisplay()

# Generated at 2022-06-17 14:19:17.487427
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a VarsModule object
    vars_module = VarsModule()

    # Create a Host object
    host = Host(name='host')

    # Create a Group object
    group = Group(name='group')

    # Create a list of entities
    entities = [host, group]

    # Create a loader object
    loader = None

    # Create a path
    path = None

    # Call method get_vars of class VarsModule
    vars_module.get_vars(loader, path, entities)

# Generated at 2022-06-17 14:19:59.607885
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a VarsModule object
    vm = VarsModule()

    # Create a Host object
    h = Host('host1')

    # Create a Group object
    g = Group('group1')

    # Create a loader object
    loader = DummyLoader()

    # Create a path
    path = '/path/to/file'

    # Create a list of entities
    entities = [h, g]

    # Test get_vars
    vm.get_vars(loader, path, entities)



# Generated at 2022-06-17 14:20:06.760023
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a VarsModule object
    vars_module = VarsModule()

    # Create a Host object
    host = Host(name='test_host')

    # Create a Group object
    group = Group(name='test_group')

    # Create a list of entities
    entities = [host, group]

    # Create a loader object
    loader = None

    # Create a path object
    path = None

    # Call method get_vars of class VarsModule
    vars_module.get_vars(loader, path, entities)

# Generated at 2022-06-17 14:20:13.831038
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import json
    import os
    import shutil
    import sys
    import tempfile


# Generated at 2022-06-17 14:20:26.826529
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a fake inventory
    inventory = InventoryManager(loader=DataLoader())
    inventory.add_group('test_group')
    inventory.add_host(Host(name='test_host', groups=['test_group']))

    # Create a fake loader
    loader = vars_loader

    # Create a fake basedir
    basedir = os.path.join(os.path.dirname(__file__), 'fixtures', 'vars_plugin')

    # Create a fake path
    path = os.path.join(basedir, 'host_vars', 'test_host')

    # Create a fake entities

# Generated at 2022-06-17 14:20:32.621553
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name="testhost")
    group = Group(name="testgroup")

    vars_module = VarsModule()
    vars_module.get_vars(loader, '', host)
    vars_module.get_vars(loader, '', group)
    vars_

# Generated at 2022-06-17 14:20:46.283122
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a fake host
    host = Host('fake_host')

    # Create a fake group
    group = Group('fake_group')

    # Create a fake loader
    loader = vars_loader

    # Create a fake path
    path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'test', 'units', 'lib', 'ansible_test_data', 'vars_plugins'))

    # Create a fake entities
    entities = [host, group]

    # Create a fake cache
    cache = True

    # Create a fake basedir


# Generated at 2022-06-17 14:20:54.611866
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='testhost')
    group = Group(name='testgroup')
    vars_module = VarsModule()
    vars_module.get_vars(loader, 'tests/inventory', host)
    vars_module.get_vars(loader, 'tests/inventory', group)
    assert v

# Generated at 2022-06-17 14:21:04.281803
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # create a dummy inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a dummy group
    group = Group('group1')
    inventory.add_group(group)

    # create a dummy host
    host = Host('host1')
    inventory.add_host(host)
    group.add_host(host)

    # create a dummy vars plugin
    v

# Generated at 2022-06-17 14:21:15.752832
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class DummyVarsModule(VarsModule):
        def __init__(self):
            self._basedir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'units', 'vars_plugins', 'host_group_vars')

    # Create a dummy inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group

# Generated at 2022-06-17 14:21:22.397702
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a dummy inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='group')
    inventory.add_host(host)
    inventory.add_group(group)
    inventory.add_child('group', host)

    # Create a dummy variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Create a dummy loader
    loader