

# Generated at 2022-06-25 12:19:13.387857
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert vars_module_0.get_vars

# Generated at 2022-06-25 12:19:14.766861
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # global vars_module_0
    assert vars_module_0.get_vars()

# Generated at 2022-06-25 12:19:25.991999
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.module_utils.plugins import module_extend
    from ansible.module_utils.ansible_release import __version__
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Add parameters passed in to the class
    ansible_options = dict(
        ansible_managed='Ansible managed: {file} modified on %s by %s' % (
            '{{ ansible_date_time.date }}', '{{ ansible_ssh_user }}'),
        ansible_version=dict(
            full='%s' % __version__,
            major=__version__.split('.')[0],
            minor=__version__.split('.')[1],
        ),
    )

# Generated at 2022-06-25 12:19:36.202183
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """
    get_vars() of VarsModule return data parsed from inventory files
    """
    from ansible.parsing.dataloader import DataLoader

    data_loader = DataLoader()
    vars_module_1 = VarsModule()

    # test case 1: No path, entities and cache
    if vars_module_1.get_vars(data_loader, '', '', False):
        assert True
    else:
        assert False

    # test case 2: test_data_2, entities and cache
    test_data_2 = {'/etc/ansible/host_vars/test_host': ['test.yml']}

# Generated at 2022-06-25 12:19:38.120803
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    assert vars_module_1.get_vars() == False


# Generated at 2022-06-25 12:19:47.519579
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    plugin = VarsModule()
    basedir = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", ".."))
    groups_file = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", "..", "inventory", "test_groups"))
    plugin._basedir = basedir
    plugin._display = C.display
    plugin._valid_extensions = C.YAML_FILENAME_EXT
    plugin._get_vars_files = VarsModule.get_vars
    loader = plugin._loader

    # test for Host entities
    groups = loader.load_from_file(groups_file, cache=True)
    if isinstance(groups, Group):
        groups = [groups]

# Generated at 2022-06-25 12:19:52.129325
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    with pytest.raises(AnsibleParserError, match=r"Supplied entity must be Host or Group, got {0} instead".format(type(VarsModule()))):
        test_VarsModule = VarsModule()
        test_VarsModule.get_vars(None, None, [VarsModule()])

# Generated at 2022-06-25 12:20:00.350009
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = FakeDataLoader()
    path_0 = 'host_vars'
    entities_0 = []
    cache_0 = True
    assert vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0) == {}

import mock
import os
import tempfile
import pytest

from ansible.module_utils.common.text.converters import to_bytes, to_text
from ansible.module_utils.six import PY3

from ansible.module_utils.six.moves.urllib.error import HTTPError

from ansible.parsing.dataloader import DataLoader
from ansible.plugins.loader import vars_loader
from ansible.vars.manager import Variable

# Generated at 2022-06-25 12:20:06.118912
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    inventory_0 = {
        'inventory_hostname': 'c972aa88-d821-4e64-b3d7-fd3b2efe2d84'
    }
    path_0 = 'group_vars'
    vars_module_0.get_vars(loader=None, path=path_0, entities=inventory_0)

# Generated at 2022-06-25 12:20:11.197984
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    try:
        vars_module_1.get_vars(loader, path, entities)
    except Exception as err:
        # check if exception raised is an instance of the right exception
        assert type(err) is AnsibleParserError

# Generated at 2022-06-25 12:20:18.208544
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

# Generated at 2022-06-25 12:20:22.215119
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    if isinstance(var_0, dict):
        print("Success")
    else:
        print("AnsibleParserError")

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:20:25.276365
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars = MagicMock(return_value = {})
    var_0 = vars_module_0.get_vars()
    assert var_0 == {}


# Generated at 2022-06-25 12:20:29.736481
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars()
    # Test consumer with different input
    vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    vars_get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:20:39.465219
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Here is the test input
    vars_module_0 = VarsModule()
    loader_0 = """one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty"""
    path_0 = """one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty"""
    entities_0 = """one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty"""

    # Run the code to be tested
    var_0 = vars_get_vars(vars_module_0, loader_0, path_0, entities_0)

    # Check the expected vs actual result
    assert expected == actual

# Generated at 2022-06-25 12:20:46.084286
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    get_vars_args = [
        {
            'inventory': '''test_host1 ansible_host=10.10.10.10''',
            'subdir': '''host_vars''',
            'output': '''{
    "bar": "baz"
}''',
        },
    ]

    for test_case in get_vars_args:
        inventory_file = inventory_loader(test_case['inventory'])
        result = inventory_file.get_hosts('test_host1')

        vars_plugin = VarsModule()

        vars_plugin.basedir = 'tests/units/vars_plugins'

        vars_plugin.get_vars(vars_plugin, vars_plugin, result)


# Generated at 2022-06-25 12:20:47.845753
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars(vars_module, vars_module, vars_module)
    pass

# Generated at 2022-06-25 12:20:51.555979
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    assert vars_module_1 == var_1

if __name__ == "__main__":
    doctest.testmod()

# Generated at 2022-06-25 12:20:54.631301
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module._basedir = None
    vars_module._display = None
    vars_module._loader = None
    vars_module.C = None
    vars_module.get_vars(vars_module, vars_module, vars_module)

# Generated at 2022-06-25 12:20:56.236430
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:21:08.921005
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_loader_1 = vars_module_0
    var_0 = vars_get_vars(vars_module_0, vars_loader_1, vars_module_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:21:13.237691
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        test_case_0()
    except:
        print("Failed test case 0")


if __name__ == "__main__":

    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:14.396382
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 12:21:15.205185
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass



# Generated at 2022-06-25 12:21:18.718228
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # get vars of class VarsModule
    var_0 = VarsModule()
    # get vars of class BaseVarsPlugin
    var_1 = BaseVarsPlugin()
    # get vars of class BaseVarsPlugin
    var_2 = BaseVarsPlugin()
    # call method get_vars of class VarsModule
    var_0.get_vars(var_1, var_2)

# Generated at 2022-06-25 12:21:21.339567
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_1 = {}
    var_2 = [var_1]
    obj = VarsModule()
    found = obj.get_vars(var_1, var_1, var_2)

# Generated at 2022-06-25 12:21:24.479531
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)


# Generated at 2022-06-25 12:21:30.818920
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars("/home/dana/ansible/lib/ansible/plugins/vars/host_group_vars.py", "/home/dana/ansible/lib/ansible/plugins/vars/host_group_vars.py", "/home/dana/ansible/lib/ansible/plugins/vars/host_group_vars.py", True)

# Generated at 2022-06-25 12:21:31.668283
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert True == False



# Generated at 2022-06-25 12:21:34.035253
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_loader, 'path', vars_entities, False)


# Generated at 2022-06-25 12:22:01.460631
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_0 = ''
    test_1 = ''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    test_0 += str(var_0)
    var_1 = vars_get_vars(vars_module_0, vars_module_0)
    test_1 += str(var_1)
    if test_0 == test_1:
        print('unit_test_case_0:pass')
    else:
        print('unit_test_case_0:fail')


# Generated at 2022-06-25 12:22:05.910214
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0._basedir = '/etc/ansible'
    vars_module_0._display = Display()
    vars_get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:22:14.447102
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    #
    # AnsibleModule test case #0
    #
    var_0 = None
    test_case_0_entities = [Host, Group]
    test_case_0_loader = None
    test_case_0_path = None
    test_case_0_cache = True
    test_case_0_try_name = None
    test_case_0_fallback_name = None
    test_case_0_try_file = None
    test_case_0_fallback_file = None
    test_case_0_vars_module = VarsModule()

# Generated at 2022-06-25 12:22:14.943727
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:22:17.341026
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:22:18.631592
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Add your test logic here
    raise NotImplementedError()

# Generated at 2022-06-25 12:22:21.452467
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

if __name__ == "__main__":
    if test_VarsModule_get_vars():
        print(True)

# Generated at 2022-06-25 12:22:24.226058
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:22:33.623946
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    if var_0:
        print("Get value of variable var_0: " + str(var_0))
    else:
        print("Variable var_0 is None")

if __name__ == "__main__":
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:41.331071
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_1 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    var_2 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    var_3 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert var_1 != None and var_2 != None and var_3 != None


# Generated at 2022-06-25 12:23:18.973475
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:23:27.716714
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # get_vars module
    var_0 = VarsModule()
    # loader = AnsibleFileLoader(loader)
    var_1 = AnsibleFileLoader(loader)
    # path = ""
    var_2 = ""
    # entities = () # TypeError: 'tuple' object is not callable
    # var_3 = ()
    # cache = True # TypeError: 'bool' object is not callable
    # var_4 = True
    # call callable
    try:
        var_0.get_vars(var_1, var_2, var_3, var_4)
    except TypeError as exc:
        assert str(exc) == "'tuple' object is not callable"
    except Exception as exc:
        print('Exception from tested code:', exc)
        raise



# Generated at 2022-06-25 12:23:29.269375
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    if FOUND[key] == found_files:
        print(ok)
    else:
        print(fail)

test_case_0()

# Generated at 2022-06-25 12:23:31.821655
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:23:40.693112
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Example usage of the method 'get_vars' of the class 'VarsModule'
    '''
    # Example:
    vars_module = VarsModule()
    var = vars_get_vars(vars_module, vars_module, vars_module)
    '''

    # Test 1:
    vars_module = VarsModule()
    var = get_vars(vars_module, vars_module, vars_module)
    # Test 2:
    vars_module = VarsModule()
    var = get_vars(vars_module, vars_module, vars_module, vars_module)

# Generated at 2022-06-25 12:23:44.454663
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module_data = VarsModule()
    vars_module_entities = VarsModule()
    var_data = vars_module.get_vars(vars_module_data, vars_module_data, vars_module_entities)
    assert isinstance(var_data, dict)


# Generated at 2022-06-25 12:23:55.317840
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    file_handler= open("VarsModule_get_vars.txt","w")
    # file_handler.write("")

    vars_module_0 = VarsModule()

    group_0 = Group()
    group_0.name = "group_0_name"
    group_0.port = 1
    group_0.vars = {}
    group_0.groups = []
    group_0.hosts = []
    group_0.children = []

    host_0 = Host()
    host_0.name = "host_0_name"
    host_0.port = 1
    host_0.groups = []
    host_0.vars = {}
    host_0.host_vars = {}


# Generated at 2022-06-25 12:23:57.679320
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

# Generated at 2022-06-25 12:24:08.680544
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # AnsibleModule
    ansible_module = AnsibleModule()
    # defined by AnsibleModule
    args = {
        'param': 'value',
    }
    # defined by AnsibleModule
    # FIXME: Currently, in AnsibleModule, this is constant value
    # of 'changed'. But, actually, this value should be changed.
    changed = True
    # defined by AnsibleModule
    check_mode = False
    ansible_module._ansible_debug = True
    # FIXME: Currently, this is not really supported, yet.
    #ansible_module._ansible_check_mode = True
    # defined by AnsibleModule
    diff = {'before': {'key': 'value'}, 'after': {'key': 'value'}}
    ansible_module._ansible_diff = diff
    # defined

# Generated at 2022-06-25 12:24:17.840943
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' Test case for method get_vars of class VarsModule '''

    # First test case
    # Test data
    vars_module_0 = VarsModule()

    # Expected output
    var_0 = {}

    # Unit test
    var_1 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert var_0 == var_1

    # Second test case
    # Test data
    vars_module_0 = VarsModule()

    # Expected output
    var_0 = {}

    # Unit test
    var_1 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert var_0 == var_1

    # Third test case


# Generated at 2022-06-25 12:25:29.854716
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:25:35.758587
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    var_1 = vars_module_0
    var_2 = vars_module_0
    var_3 = "default"
    try:
        var_0.get_vars(var_1, var_2, var_3)
    except Exception as exception:
        print('An exception happened: ' + str(exception))


# Generated at 2022-06-25 12:25:37.548038
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:25:43.385187
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    cur_dir = os.getcwd()
    vars_module = VarsModule()
    entities = Group("example")
    # call method get_vars of class VarsModule
    var = vars_module.get_vars(vars_module, cur_dir, entities)
    print("Response from method get_vars of class VarsModule:", var)
    return


if __name__ == "__main__":
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:47.048645
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # This is just a sanity check to make sure that we are actually testing a function, and not a variable.
    # Do not remove it
    assert callable(VarsModule.get_vars)

    # Input variables initialization
    vars_module_0 = VarsModule()

    # This is where the actual test starts
    assert True

# Generated at 2022-06-25 12:25:51.243869
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    test_file_path_1 = C.DEFAULT_HOST_LIST
    test_entities_1 = [Host('test_host_0')]
    test_cache_1 = True
    test_result_1 = vars_module_1.get_vars(test_file_path_1, test_entities_1, test_cache_1)
    assert test_result_1 is None

# Generated at 2022-06-25 12:25:51.886197
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass


# Generated at 2022-06-25 12:26:03.382555
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = TestLoader()
    path_0 = TestOSFilePath()
    entities_0 = [1]
    # It should return a python object that is an empty dictionary
    assert vars_module_0.get_vars(loader_0, path_0, entities_0) == {}

    entity_0 = TestHost()
    # It should raise an AnsibleParserError with this message
    msg = "Supplied entity must be Host or Group, got <class 'test_vars_plugins.TestHost'> instead"
    with pytest.raises(AnsibleParserError, message=msg):
        vars_module_0.get_vars(loader_0, path_0, entity_0)

    entity_1 = TestGroup()

# Generated at 2022-06-25 12:26:06.754707
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path = 'path'
    loader = 'loader'
    entities = 'entities'
    cache = True

    vars_module_0 = VarsModule()

    assert compare_vars(vars_module_0.get_vars(loader, path, entities, cache), vars_get_vars(vars_module_0, loader, entities, cache))


# Generated at 2022-06-25 12:26:15.746052
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_p = VarsModule()
    path_p = os.path.realpath(to_bytes(os.path.join(vars_module_p._basedir, var_p)))

# Generated at 2022-06-25 12:28:10.817517
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    b_opath = '/home/user/ansible/roles/test/host_vars/'
    a_cwd = '/home/user/ansible/roles/test/'
    basedir = '/home/user/ansible/roles/test/'
    vars_module_0 = VarsModule()

    def mock_os_path_realpath(arg_0):
        return '/home/user/ansible/roles/test/host_vars/'

    def mock_os_path_exists(arg_0):
        return 'true'

    def mock_os_path_isdir(arg_0):
        return 'true'

    def mock_find_vars_files(file_name, new_data):
        return ['nodes.yaml']


# Generated at 2022-06-25 12:28:13.919541
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

# Generated at 2022-06-25 12:28:16.520728
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:28:25.038328
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    arg0 = load_fixture('recursive_dirs_and_files/dir1/dir2/dir3/file1')
    arg1 = load_fixture('recursive_dirs_and_files/dir1/dir2/dir3/file2')
    arg2 = load_fixture('recursive_dirs_and_files/dir1/dir2/dir3/file3')
    arg3 = load_fixture('recursive_dirs_and_files/dir1/dir2/dir3/file4')
    arg4 = load_fixture('recursive_dirs_and_files/dir1/dir2/dir3/file5')
    arg5 = load_fixture('recursive_dirs_and_files/dir1/dir2/dir3/file6')
    arg6 = load_f

# Generated at 2022-06-25 12:28:34.085582
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entity_0 = Host()
    entity_1 = Host()
    entity_2 = Host()
    entity_2.name = '.'
    entity_3 = Host()
    entity_3.name = './repos/codebase'
    loader_0 = AnsibleLoader()
    path_0 = './repos/codebase'
    data_0 = vars_get_vars(loader_0, path_0, entity_0)
    data_1 = vars_get_vars(loader_0, path_0, entity_1)
    data_2 = vars_get_vars(loader_0, path_0, entity_2)
    data_3 = vars_get_vars(loader_0, path_0, entity_3)

# Generated at 2022-06-25 12:28:37.634393
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    arg_0 = VarsModule()
    arg_1 = None
    arg_2 = None
    var_0 = vars_module_0.get_vars(vars_module_0, arg_0, arg_1, arg_2)

# Generated at 2022-06-25 12:28:40.701272
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Instantiation
    vars_module = VarsModule()

    # Call method get_vars of VarsModule
    get_vars(vars_module, vars_module, vars_module)

if __name__ == '__main__':
    test_case_0()

    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:28:42.569149
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    if False:
        # This section needs the following variables initialized:
        # vars_module_0: Instance of class VarsModule
        # var_0: Instance of class VarsModule
        pass


# Generated at 2022-06-25 12:28:54.294805
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host_0 = Host(name='host_0')
    vars_module_1 = VarsModule()
    var_0 = vars_get_vars(vars_module_1, vars_module_1, host_0)
    assert len(var_0) == 1
    assert var_0['0']['hostname'] == 'host_0'
    assert var_0['0'][''] == 'host_0'
    group_0 = Group(name='group_0')
    var_1 = vars_get_vars(vars_module_1, vars_module_1, group_0)
    assert len(var_1) == 1
    assert var_1['0']['group_name'] == 'group_0'

# Generated at 2022-06-25 12:28:59.982922
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_1 = VarsModule()
    var_2 = VarsModule()
    var_3 = vars_module_0.get_vars(var_1, var_2, var_1, var_1)
    assert (len(var_3) == 0)
