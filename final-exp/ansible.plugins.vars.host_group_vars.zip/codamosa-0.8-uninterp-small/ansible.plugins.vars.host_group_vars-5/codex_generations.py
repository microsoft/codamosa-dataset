

# Generated at 2022-06-25 12:19:25.548555
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class VarsModule_get_vars_parsed_host(Host):
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    vars_module = VarsModule()
    vars_module._loader = VarsModuleLoader()

# Generated at 2022-06-25 12:19:31.733841
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    # VarsModule.get_vars(loader, path, entities, cache=True)

    # Required argument `entities` (pos 3) not found
    try:
        vars_module_0.get_vars()
    except TypeError as exc:
        assert exc.args[0] == "get_vars() missing 3 required positional arguments: 'loader', 'path', and 'entities'"
    else:
        assert False, "Expected Exception"

# Generated at 2022-06-25 12:19:35.255475
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    cmd_test_data = {'test_case': 1, 'cmd': 'test_data'}
    path = 'test_path'
    entities = ['test_entities']
    cache = True

    # Make the function under test
    vars_module_1 = VarsModule()
    vars_module_1.get_vars(cmd_test_data, path, entities, cache)

# Generated at 2022-06-25 12:19:36.131146
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_get_vars = VarsModule()

# Generated at 2022-06-25 12:19:45.884175
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test Case 1
    # Execute test_case_1.py with an argument
    f = open('my_file.txt','w')
    f.write('some random text') # python will convert \n to os.linesep
    f.close() # you can omit in most cases as the destructor will call it

    # Load vars from files in a given dir without any extension
    def load_vars_from_files_in_dir(path, filenames):
        ret = []
        if not os.path.isdir(path):
            raise AnsibleParserError("Found %s that is not a directory" % (path))
        for filename in filenames:
            fpath = os.path.join(path, filename)
            if os.path.isfile(fpath):
                ret.append(fpath)
       

# Generated at 2022-06-25 12:19:56.311858
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    # construct arguments that are normally passed in by Ansible during runtime
    loader_0 = DataLoader()
    play_context_0 = PlayContext()
    inventory_0 = None
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)
    entities = []
    result = vars_module_0.get_vars(loader=loader_0, path='group_vars/all', entities=entities)
    assert type(result) == dict

### end of tests ###

# print out our test results

# Generated at 2022-06-25 12:19:58.045356
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars("loader", "path", ["entities"], True)

# Generated at 2022-06-25 12:20:01.040812
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = None
    entities_0 = []
    cache_0 = None
    assert vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0) == None

# Generated at 2022-06-25 12:20:03.035000
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars = VarsModule()
    class HostMock():
        name = 'hostMock'
    host = HostMock()
    vars.get_vars('mock_loader', '/etc/ansible/host_vars', host)

# Generated at 2022-06-25 12:20:04.037532
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vm = VarsModule()
    assert vm.get_vars(vm, 0, vm)


# Generated at 2022-06-25 12:20:15.904214
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    vars_module_1 = VarsModule()
    vars_module_1._basedir = 'test/unit/plugins/vars/vars_plugins/test'
    path = 'test/unit/plugins/vars/vars_plugins/test/hosts'
    host = Host(name='test')
    result = vars_module_1.get_vars(loader, path, host)
    assert result == {'test': 'value'}

# Generated at 2022-06-25 12:20:23.863459
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    class Myclass():
        pass

    class Myloader():
        def __init__(self):
            self.path = os.path.dirname(os.path.realpath(__file__))
            self.basedir = os.path.realpath(os.path.join(self.path, '../../../'))
            self.path_ = os.path.realpath(os.path.join(self.basedir, './tests/units/modules/extras/test_vars_plugin/get_vars/data'))

        def find_vars_files(self, dirname, hostname):
            self.filename = os.path.realpath(os.path.join(self.path_, './' + dirname + '/' + hostname))
            return [self.filename]


# Generated at 2022-06-25 12:20:26.457526
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    g = Group("my-group")
    h = Host("my-host")
    vars_module = VarsModule()
    assert vars_module.get_vars(loader, b"/path/to/ansible/", g) == {}

# Generated at 2022-06-25 12:20:30.479935
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    x_vars_module_1 = vars_module_1.get_vars()
    assert x_vars_module_1 == {}
    assert vars_module_1.get_vars() == {}
    loader = AnsibleLoader()
    assert vars_module_1.get_vars(loader, path, entities) == {}
    assert vars_module_1.get_vars(loader, path, entities, cache) == {}

# Generated at 2022-06-25 12:20:41.334755
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_get_vars_1 = VarsModule()
    test_loader_get_vars_1 = "/home/runner/work/ansible/ansible/test/test_data/test_vars_plugins/loader_get_vars_1"
    test_path_get_vars_1 = "/home/runner/work/ansible/ansible/test/test_data/test_vars_plugins/path_get_vars_1"
    test_entities_get_vars_1 = "/home/runner/work/ansible/ansible/test/test_data/test_vars_plugins/entities_get_vars_1"
    test_cache_get_vars_1 = True

# Generated at 2022-06-25 12:20:48.189084
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = None
    #entities_0 = ['host_vars', 'group_vars']
    entities_0 = None
    cache_0 = True
    #result = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    #assert result == {"global":{"a":10}, "d":{"e":12}}


if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:20:52.557257
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader = ...  # provide correct value
    path = ...  # provide correct value
    entities = ...  # provide correct value
    cache = ...  # provide correct value
    data = vars_module_0.get_vars(loader=loader, path=path, entities=entities, cache=cache)
    # assertions
    assert data is not None

# Generated at 2022-06-25 12:20:56.629511
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_0 = vars_module_1.loader
    path_0 = None
    entities_0 = Host('192.168.1.10')
    cache_0 = True
    try:
        vars_module_1.get_vars(loader_0, path_0, entities_0, cache_0)
    except AnsibleParserError:
        pass
    else:
        raise Exception("Expected exception: AnsibleParserError")


# Generated at 2022-06-25 12:20:58.901749
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    result = vars_module_1.get_vars(loader=None, path=None, entities=[])
    assert result == {}

# Generated at 2022-06-25 12:21:03.623563
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader = 'loader'
    path = 'path'
    entities = [{'entity': 'entity'}]
    cache = True
    assert vars_module.get_vars(loader, path, entities, cache=True) is None

# Generated at 2022-06-25 12:21:14.872845
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    assert type(var_0) == dict

test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:21.628497
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host_0 = Host(name='host_0', port=22)
    host_1 = Host(name='host_1', port=22)
    host_2 = Host(name='host_2', port=22)
    group_0 = Group(name='group_0')
    group_1 = Group(name='group_1')
    group_2 = Group(name='group_2')
    vars_module_0 = VarsModule()
    vars_module_0._display = Display()
    vars_module_0._basedir = '.'
    vars_module_0.get_vars(vars_module_0, '.', vars_module_0)
    vars_module_0._basedir = '/tmp'

# Generated at 2022-06-25 12:21:32.185589
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Initial test variables
    b_path_0 = b'/home/user/workspace/ansible/test/inventory/test_inventory'
    path_0 = to_text(b_path_0)
    b_entity_name_0 = b'192.168.1.2'
    entity_name_0 = to_text(b_entity_name_0)
    entity_0 = Host(entity_name_0)
    loader_0 = DataLoader()
    # Expectations
    class_loader_find_vars_files = ['%s/host_vars/%s' % (path_0, entity_name_0)]

# Generated at 2022-06-25 12:21:35.153753
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        o_vars_module_0 = VarsModule()
        o_int_0 = 0
        o_var_0 = vars_get_vars(o_vars_module_0, o_int_0, o_vars_module_0)
        if not (o_var_0):
            raise error
    except Exception as e:
        print(e)

test_case_0()

# Generated at 2022-06-25 12:21:35.978468
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:21:38.616635
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    os_path_sep = os.path.sep
    try:
        os.path.sep = 'm6lR!m'
        int_0 = 0
        var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    except Exception as e:
        var_0 = str(e)
    os.path.sep = os_path_sep
    assert 'Invalid path' in var_0

# Generated at 2022-06-25 12:21:44.760419
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entities = []
    loader = []
    # Path the the files
    path = os.getcwd() + "/Ansible_vars_test/test_case_0"
    b_path = to_bytes(path)
    vars_module_0 = VarsModule()
    assert(vars_module_0.get_vars(loader, b_path, entities, False) == {})

test_case_0()

# Generated at 2022-06-25 12:21:47.352067
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    global vars_get_vars
    vars_get_vars = VarsModule.get_vars
    test_case_0()

# Entry point of this plugin

# Generated at 2022-06-25 12:21:48.245527
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:21:54.298745
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    entities_0 = list()
    loader_0 = """<ansible.parsing.dataloader.DataLoader object at 0x7ff5a8a2b9d0>"""
    path_0 = """/home/zombie/workspace/ansible/ansible/inventory/yaml.py"""
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, loader_0, path_0, entities_0)

# Generated at 2022-06-25 12:22:04.824390
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

# Generated at 2022-06-25 12:22:13.648276
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    stage = 'any'
    plugin_vars = {'_ansible_base_directory': '/root', '_ansible_cache': {}, '_ansible_no_log': False, 'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost', 'group_names': [], 'groups': {'all': Group(name='all')}, '_ansible_inventory_sources': []}
    entity_0 = Host(name='localhost', port=22)
    loader_0 = DataLoader()
    path ='/root'
    entities = entity_0
    cache = True
    # Test of vars_module_0 of class VarsModule
    vars_module_0 = VarsModule()


# Generated at 2022-06-25 12:22:15.774272
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    int_0 = 0
    var_0.get_vars(int_0, int_0, int_0)


# Generated at 2022-06-25 12:22:19.494163
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # TEST CASE 0: <without params>
    test_case_0()


if __name__ == '__main__':

    # TEST CASE 0: <without params>
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:24.000331
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    path_0 = '.'
    inventory_0 = Host()
    inventory_0.group_vars = VarsModule()
    cache_0 = False
    vars_get_vars(vars_module_0, path_0, inventory_0, cache_0)

# Generated at 2022-06-25 12:22:30.905134
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    host_0 = Host(name='host_0')
    group_0 = Group(name='group_0')
    host_0_vars = vars_get_vars(vars_module_0, host_0, vars_module_0)
    group_0_vars = vars_get_vars(vars_module_0, group_0, vars_module_0)
    assert (host_0_vars == {'test0': 'test0'})
    assert (group_0_vars == {'test2': 'tests2'})

# Generated at 2022-06-25 12:22:33.590202
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    xunit_str_1 = "vars_module_1"
    var_1 = vars_get_vars(vars_module_1, xunit_str_1)

# Generated at 2022-06-25 12:22:43.369168
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    opath = os.path.realpath(to_bytes(os.path.join(self._basedir, subdir)))
    # opath = to_text(b_opath)
    if os.path.exists(b_opath) and os.path.isdir(b_opath):
        self._display.debug("\tprocessing dir %s" % opath)
        found_files = loader.find_vars_files(opath, entity.name)
        FOUND[key] = found_files
        for found in found_files:
            new_data = loader.load_from_file(found, cache=True, unsafe=True)
            if new_data:  # ignore empty files
                data = combine_vars(data, new_data)
    return data


# Generated at 2022-06-25 12:22:53.688038
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    path_0 = 'E\\8\x96\\'

# Generated at 2022-06-25 12:22:56.458175
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    # assert funcReturn[0][0]['host_name'] == 'host1'
    # assert funcReturn[0][0]['a'] == '1'



# Generated at 2022-06-25 12:23:14.158936
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = ''
    entities_0 = None
    cache_0 = True
    var_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert var_0 == {}

# Generated at 2022-06-25 12:23:22.706969
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    params = [
                "Entity must be Host or Group",
                "Found vars_host_group_vars that is not a directory, skipping: /tmp/vars_host_group_vars",
                "Found vars_host_group_vars",
                "Entity must be Host or Group",
                "Found vars_host_group_vars that is not a directory, skipping: /tmp/vars_host_group_vars",
                "Found vars_host_group_vars that is not a directory, skipping: /tmp/vars_host_group_vars"
            ]


    # Check if the path "vars_host_group_vars" exists.
    # Test case 1

# Generated at 2022-06-25 12:23:26.028086
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    int_0 = 0
    int_1 = 0
    var_0 = vars_get_vars(vars_module_1, int_0, int_1)
    assert var_0 is not None

# Generated at 2022-06-25 12:23:29.233384
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    assert_equal(var_0, 0)


# Generated at 2022-06-25 12:23:31.118717
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)


# Generated at 2022-06-25 12:23:34.041527
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    assert vars_module_0.get_vars(vars_module_0, int_0, vars_module_0) == None

# Generated at 2022-06-25 12:23:40.479789
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    
    # Initialisation
    int_0 = 0

    # Call of tested method
    var_0 = vars_module_0.get_vars(int_0, vars_module_0, vars_module_0)


if __name__ == '__main__':
    
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:23:43.183150
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = AnsibleLoader()
    int_0 = 0
    vars_module_0.get_vars(loader_0, int_0, vars_module_0)

# Generated at 2022-06-25 12:23:48.895969
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = 0
    vars_module_0 = VarsModule()
    result = vars_module_0.get_vars(int_0, int_0, int_0, bool_0)
    assert result is None


if __name__ == '__main__':
    # Unit test
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:23:54.178593
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import StringIO
    out = StringIO.StringIO()
    vars_module_0 = VarsModule()
    int_0 = 0
    vars_module_1 = VarsModule()
    vars_module_2 = VarsModule()
    vars_module_0.get_vars(vars_module_1, int_0, vars_module_2)


# Generated at 2022-06-25 12:24:22.643188
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars('loader', 'path')


# Generated at 2022-06-25 12:24:25.348746
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_1, int_0, vars_module_1)


# Generated at 2022-06-25 12:24:27.956751
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

test_case_0()

# Generated at 2022-06-25 12:24:30.227908
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module, int_0, vars_module)
    assert True
    assert var_0 is None

# Generated at 2022-06-25 12:24:34.752010
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # create vars module class
    vars_Module_0 = VarsModule()
    # create dummy path
    path_0 = "dummy_path"
    # create dummy entities
    entities_0 = ['dummy_entity_0', ]
    # check
    vars_get_vars(vars_Module_0, path_0, entities_0)


# Generated at 2022-06-25 12:24:36.026773
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  vars_module_0 = VarsModule()
  int_0 = 0
  var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

# Generated at 2022-06-25 12:24:41.301584
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # given
    vars_module_0 = VarsModule()
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    vars_module_0._valid_extensions.append('.py')
    vars_module_0.get_vars(int_0, int_1, int_2, int_3)
    # when
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    # then
    while True:
        if True: raise Exception('Not implemented')

# Generated at 2022-06-25 12:24:43.981657
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = 0
    vars_module_0 = VarsModule()

    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    assert var_0 == None


# Generated at 2022-06-25 12:24:47.368575
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("test_VarsModule_get_vars")

    # Setup fixture
    vars_module_1 = VarsModule()

    # Test case 0:
    int_0 = 0
    var_0 = vars_get_vars(vars_module_1, int_0, vars_module_1)

    print("test_VarsModule_get_vars done")

test_VarsModule_get_vars()

# Generated at 2022-06-25 12:24:50.661662
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    if not to_native(C.ANSIBLE_YAML_FILENAME_EXT):
        C.ANSIBLE_YAML_FILENAME_EXT = ['.yaml', '.yml', '.json']
    test_case_0()

# Convenience methods to make testing easier

# Generated at 2022-06-25 12:25:49.700198
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
	vars_module_0 = VarsModule()
	vars_module_0.set_options({'forks': [
		{'value': '0'},
		{'value': '0'}
	]})

	# get_vars(self, loader, path, entities, cache=True)
	assert vars_module_0.get_vars(vars_module_0, 0, vars_module_0) is None

# Generated at 2022-06-25 12:25:52.724942
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Init class
    vars_module_0 = VarsModule()
    int_0 = 0
    # Invoke method
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 12:25:55.797602
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    int_1 = 1
    var_1 = vars_get_vars(vars_module_1, int_1, vars_module_1)

# Generated at 2022-06-25 12:26:06.006046
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    # set up parameters
    
    inventory_source = '/etc/ansible/hosts'
    inventory_dir = '/etc/ansible'
    loader = DataLoader(None)
    inventory = InventoryManager(loader=loader, sources=inventory_source)
    group = inventory.groups_dict.values()[0]
    host = group.hosts_dict.values()[0]
    hostvars = get_host_variables(host)
    groupvars = get_group_variables(group)
    entities = host
    cache = True
    # get_vars(loader, path, entities, cache=True)
    path = vars_module_0.get_vars(loader, inventory_dir, entities, cache)
    # validate return value
    assert path


# Generated at 2022-06-25 12:26:12.108530
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    int_0 = 0
    # Call the method
    obj = var_get_vars(var_0, int_0, var_0)
    # Tests if the method returns a list
    if not isinstance(obj, list):
        raise Exception("Vars get_vars does not return a list")
    # Tests if the list returned is empty
    if obj != []:
        raise Exception("Vars get_vars does not return an empty list")

# Generated at 2022-06-25 12:26:15.139903
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Input Parameters
    entities = ["foo", "bar"]

    # Output Parameters
    output_0 = 0

    # Execution of the tested method
    var_0 = VarsModule.get_vars(entities)

    # Verification
    assert (var_0 is output_0)

# Generated at 2022-06-25 12:26:18.958991
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_1 = MockAnsibleLoader()
    path_1 = 'ansible.builtin.get_url'
    entities_1 = [Host()]
    var_1 = vars_module_1.get_vars(loader_1, path_1, entities_1)


# Generated at 2022-06-25 12:26:20.399904
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert test_case_0()


# Generated at 2022-06-25 12:26:22.913835
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

# Generated at 2022-06-25 12:26:27.946899
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0_0 = 0
    int_0_1 = 0
    var_1 = vars_get_vars(vars_module_0, (int_0_0, int_0_1), vars_module_0)



test_case_0()

# Generated at 2022-06-25 12:28:28.288637
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = DataLoader()
    int_0 = 0
    path_0 = '_pdir'
    list_0 = []
    entity_0 = Host()
    list_1 = []
    list_1.append(entity_0)
    entities_0 = list_1
    ansible_vars_plugin_stage_0 = '1'
    ansible_vars_plugin_stage_1 = '2'
    ansible_vars_plugin_stage_2 = '3'
    ansible_vars_plugin_stage_3 = '4'
    ansible_vars_plugin_stage_4 = '5'
    ansible_vars_plugin_stage_5 = '6'

# Generated at 2022-06-25 12:28:30.311768
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Setup data
    vars_module = VarsModule()
    vars_module.get_vars(vars_module)


# Generated at 2022-06-25 12:28:33.872364
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    path_0 = None
    entities_0 = None
    cache_0 = None
    var_0 = vars_module_0.get_vars(path_0, entities_0, cache_0)

# Generated at 2022-06-25 12:28:36.522574
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

# Generated at 2022-06-25 12:28:38.799012
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

# Generated at 2022-06-25 12:28:42.183079
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    path_0 = ''
    entities_0 = []
    cache_0 = True
    assert vars_module_0.get_vars(path_0, entities_0, cache_0) == {}, "assertion error"

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:28:49.364079
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    # IN: var_0 = vars_module_0.get_vars(int_0, vars_module_0)
    print(var_0)

# Generated at 2022-06-25 12:28:52.834828
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)

    # Test failure of method get_vars of class VarsModule
    try:
        vars_get_vars(vars_module_0, int_0, vars_module_0)
    except AnsibleParserError:
        print("AnsibleParserError caught")


# Generated at 2022-06-25 12:29:00.971203
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # instance creation
    vars_module_0 = VarsModule()

    # test case
    int_0 = 0
    var_0 = vars_get_vars(vars_module_0, int_0, vars_module_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 12:29:09.482273
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Instantiate a file plugin for the test
    test_file_plugin = VarsModule()

    # Test default behavior
    assert test_file_plugin.get_vars() == ""

    # Test function with multiple args
    assert test_file_plugin.get_vars(test_file_plugin) == ""

    # Test function with multiple args
    assert test_file_plugin.get_vars(test_file_plugin, "inventory") == ""

    # Test function with multiple args
    assert test_file_plugin.get_vars(test_file_plugin, "inventory", ) == ""

    # Test function with multiple args
    assert test_file_plugin.get_vars(test_file_plugin, "inventory", "Host/Group") == ""

    # Test function with multiple args
    assert test_file_plugin.get_v