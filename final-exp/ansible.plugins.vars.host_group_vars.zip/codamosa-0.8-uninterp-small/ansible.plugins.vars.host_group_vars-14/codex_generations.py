

# Generated at 2022-06-25 12:19:15.197103
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert False


# Just for coverage

# Generated at 2022-06-25 12:19:21.254911
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
        vars_module_0 = VarsModule()
        # just run get_vars without any host/group
        # TODO: add better host/group objects
        hosts_0 = [Host()]
        vars_module_0.get_vars('loader', 'path', hosts_0)

# Test cases for the module

# Generated at 2022-06-25 12:19:31.286036
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Assume that the current working directory is the tests directory
    vars_module_0 = VarsModule()
    vars_module_0._basedir = "../tests/inventory"
    loader_0 = DictDataLoader()
    path_0 = "../tests/inventory"
    entities_0 = ["localhost"]
    cache_0 = True
    result_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert result_0 == ["localhost"]


# Generated at 2022-06-25 12:19:37.551340
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create an instace of VarsModule
    vars_module_0 = VarsModule()
    # Create a variable for argument 'loader' with a default value
    loader_0 = None
    # Create a variable for argument 'path' with a default value
    path_0 = None
    # Create a variable for argument 'data' with a default value
    data_0 = None
    # Create a variable for argument 'cache' with a default value
    cache_0 = True

    # Call method get_vars with arguments values
    ret = vars_module_0.get_vars(loader_0, path_0, data_0, cache_0)
    assert ret == {}, "Return value of get_vars is not as expected."


if __name__ == "__main__":
    test_case_0()
    # test

# Generated at 2022-06-25 12:19:44.418349
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    path_0 = '/home/khertan/Khertan/Packages/ansible/lib/ansible/plugins/inventory/'
    entities_0 = []
    entities_0.append("Host(name=None)")
    entities_0.append("Group(name='all')")

    cache_0 = True
    assert vars_module_0.get_vars("loader", path_0, entities_0, cache=cache_0)

# Generated at 2022-06-25 12:19:50.738536
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_get_vars = VarsModule()
    host1 = Host("name1", "group1", {"port": "1234"})
    groups = [Group("group1", hosts=[host1])]

    result = vars_module_get_vars.get_vars("loader", "host_vars", entities=groups, cache=False)
    assert result == {}

# Generated at 2022-06-25 12:19:57.135587
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    fake_loader = FakeLoader()
    vars_module_0 = VarsModule()
    fake_entities  = [FakeHost()]
    vars_module_0.get_vars(fake_loader, fake_entities)
    assert os.path.isdir(fake_loader.path_0)
    for fake_path in fake_loader.file_dict.keys():
        assert fake_path in (os.path.join(fake_loader.path_0, i) for i in fake_loader.file_dict.keys())


# Generated at 2022-06-25 12:20:00.219382
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        vars_module_0 = VarsModule()
        vars_module_0._display = None
        vars_module_0._stage = 'setup'
        vars_module_0.get_vars(loader='loader_0', path='path_0', entities=None, cache=False)
    except Exception as e:
        print(e)
        raise e



# Generated at 2022-06-25 12:20:05.251991
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # arrange
    vars_module = VarsModule()
    loader = None
    path = None
    entities = [Group(name='test_group')]
    cache = True

    # act
    result = vars_module.get_vars(loader, path, entities, cache)

    # assert
    assert not result


# Generated at 2022-06-25 12:20:10.266412
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    try:
        vars_module_1.get_vars(loader="loader", path="path", entities="entities", cache="cache")
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 12:20:17.261427
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(vars_module_0, tuple_0, tuple_0, int_0)


# Generated at 2022-06-25 12:20:22.683412
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_dict = {"test_case_0":test_case_0}
    res = True
    for test_func in test_dict:
        res = res and test_dict[test_func]()
    return res

# ############ main ############
if __name__ == '__main__':
    test_Vars_Module_get_vars()

# Generated at 2022-06-25 12:20:29.253285
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    b_opath = to_bytes(os.path.join(os.path.curdir(), "test", "test_file_0.txt"))
    opath = to_text(b_opath)
    group_0 = Group(name=opath)
    entities_0 = [group_0]
    tuple_0 = ()
    int_0 = -1037
    vars_module_0 = VarsModule(tuple_0, tuple_0, entities_0, int_0)
    var_0 = vars_get_vars(vars_module_0, opath, entities_0)


vars_get_vars = VarsModule.get_vars

# Generated at 2022-06-25 12:20:34.290157
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:20:37.714348
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:20:42.515128
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 0
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    vars_module_0.get_vars = get_vars_0
    var_0 = vars_module_0.get_vars(tuple_0, tuple_1, tuple_2, int_0)


# Generated at 2022-06-25 12:20:46.870545
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    print(var_0)


# Generated at 2022-06-25 12:20:54.559331
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_1 = VarsModule()
    tuple_1 = ()
    str_1 = 'c3BlY2lhbF9yZXF1ZXN0'
    bytearray_0 = bytearray(str_1, 'utf-8')
    str_2 = 'c3BlY2lhbF9yZXF1ZXN0'
    bytearray_1 = bytearray(str_2, 'utf-8')
    str_3 = 'c3BlY2lhbF9yZXF1ZXN0'
    bytearray_2 = bytearray(str_3, 'utf-8')
    int_0 = -1037
    int_1 = -1037
    int_2 = -1037

# Generated at 2022-06-25 12:21:05.884049
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    data_0 = {}
    bool_0 = False
    int_2 = 3
    int_1 = 0
    bool_1 = True
    data_0["int_0"] = bool_0
    data_0["int_1"] = int_2
    data_0["int_2"] = int_1
    data_0["bool_0"] = bool_1
    data_0["bool_1"] = bool_0
    data_0["data_0"] = data_0
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

if __name__ == "__main__":
    test_case_

# Generated at 2022-06-25 12:21:08.749529
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    assert type(vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)) == dict


# Generated at 2022-06-25 12:21:21.755309
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:21:28.639143
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """
    :return: A tuple containing:
            0: TODO
            1: TODO
    """
    loader_0 = Loader()
    list_0 = []
    path_0 = ''
    entities_0 = []
    cache_0 = True
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(loader_0, list_0, path_0, entities_0, cache_0)

# Generated at 2022-06-25 12:21:31.546903
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        test_case_0()
    except Exception:
        print('FAIL')
    else:
        print('PASS')

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:34.522400
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    print (var_0)

# Generated at 2022-06-25 12:21:38.250513
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    tuple_1 = ()
    int_0 = 269127
    var_0 = vars_get_vars(tuple_0, tuple_1, vars_module_0, int_0)


# Generated at 2022-06-25 12:21:41.203639
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:21:43.108260
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Can any additional arguments be added to the method get_vars of class VarsModule
    try:
        test_case_0()
    except:
        assert False
    assert True


# Generated at 2022-06-25 12:21:47.661787
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
 
  # Unit test for method get_vars of class VarsModule
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
 

# Generated at 2022-06-25 12:21:49.122534
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    test_case_0()



# Generated at 2022-06-25 12:21:59.802210
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  
    # Create an instance of the class VarsModule
    #TODO
    vars_module_0 = VarsModule()
    
    # Create an instance of the class tuple
    #TODO
    tuple_0 = ()

    # Create an instance of the class tuple
    #TODO
    tuple_1 = ()
    # Create an instance of the class int
    #TODO
    int_0 = -1037

    # Assign var_0 with the method get_vars
    # of vars_module_0 with tuple_0, tuple_1 and int_0 as arguments
    var_0 = vars_module_0.get_vars(tuple_0, tuple_1, int_0)
    

if __name__ == '__main__':
    test_VarsModule_get_

# Generated at 2022-06-25 12:22:22.099537
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ("/Users/sgr/Code/OpenSource/ansible/lib/ansible/plugins/vars",)
    tuple_1 = ("/Users/sgr/Code/OpenSource/ansible/lib/ansible/plugins/vars",)
    class_1 = Host("VarsModule")
    int_0 = -1037
    tuple_2 = ("/Users/sgr/Code/OpenSource/ansible/lib/ansible/plugins/vars")
    tuple_3 = ("/Users/sgr/Code/OpenSource/ansible/lib/ansible/plugins/vars")
    class_2 = Group("VarsModule")
    tuple_4 = (class_1, class_2)

# Generated at 2022-06-25 12:22:25.550735
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)



# Generated at 2022-06-25 12:22:28.882437
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    tuple_1 = ()
    int_1 = -1037
    tuple_2 = ()
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(tuple_1, tuple_2, vars_module_1, int_1)

# Generated at 2022-06-25 12:22:38.445233
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)


if __name__ == "__main__":
    test_VarsModule_get_vars()
    test_case_0()

# Generated at 2022-06-25 12:22:39.842919
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    first_test = VarsModule()
    first_test.get_vars(loader=None, path='path', entities=None, cache=True)


# Generated at 2022-06-25 12:22:41.406226
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert get_vars(self, 'Pip3.install') == 'Pip3.install'



# Generated at 2022-06-25 12:22:42.035682
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:22:44.204406
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_module_0.get_vars(tuple_0, tuple_0, int_0)


# Generated at 2022-06-25 12:22:48.140742
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print(" test_VarsModule_get_vars not yet implemented")

# unit tests end here

if __name__ == '__main__':
    print(" testing starts here :")
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:51.906768
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:23:15.554836
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)


# Generated at 2022-06-25 12:23:18.761737
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)


# Generated at 2022-06-25 12:23:20.968510
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    tuple = ()
    int = -1037
    var = vars_get_vars(tuple, tuple, vars_module, int)

# Generated at 2022-06-25 12:23:26.019001
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create instance of class with params
    vars_module_0 = VarsModule()
    # Read params
    tuple_0 = ()
    int_0 = -1037
    # Call method
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    # Check result is as expected
    assert var_0 is not None
    # Free memory



# Generated at 2022-06-25 12:23:28.925240
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    assert var_0 is None
    print("Test case 0 passed")


# Generated at 2022-06-25 12:23:31.452191
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    tuple_0 = ()
    vars_module_0 = VarsModule()
    int_0 = 1
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    assert var_0 is not None


# Generated at 2022-06-25 12:23:34.128295
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        vars_module_1 = VarsModule()
        tuple_1 = tuple()
        tuple_2 = tuple()
        int_1 = -1
        vars_get_vars(tuple_1, tuple_2, vars_module_1, int_1)
    except TypeError as e:
        print(e)


# Generated at 2022-06-25 12:23:38.925610
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsPlugin()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_module_0.get_vars(tuple_0, tuple_0, tuple_0, int_0)

# Generated at 2022-06-25 12:23:42.653156
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Setup
    vars_module_1 = VarsModule()
    tuple_1 = ()
    int_1 = -1037
    
    # Assert
    # Assert
    vars_get_vars(tuple_1, tuple_1, vars_module_1, int_1)


# Generated at 2022-06-25 12:23:45.602525
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)


# Generated at 2022-06-25 12:24:59.214810
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    print("Method get_vars of class VarsModule returned:", var_0)



# Generated at 2022-06-25 12:25:04.252861
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = 12
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
    var_1 = vars_get_vars(tuple_0, tuple_0, tuple_0, int_0)

# Generated at 2022-06-25 12:25:07.606909
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Testing case 0 (normal test case):')
    test_case_0()

# Main execution
if __name__ == '__main__':
    print('Testing')
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:12.040259
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:25:15.282055
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    tuple_0 = ()
    tuple_1 = ()
    int_0 = 1024
    var_1 = vars_get_vars(tuple_1, tuple_0, var_0, int_0)


if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:18.615764
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  vars_module_0 = VarsModule()
  tuple_0 = ()
  tuple_1 = ()
  int_0 = -1037
  var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:25:27.452226
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("==> Now testing class VarsModule, method get_vars")
    subdir_0 = "/etc/ansible/host_vars"
    b_subdir_0 = to_bytes(subdir_0)
    var_0 = os.path.isdir(b_subdir_0)
    vars_module_0 = VarsModule()
    int_0 = -1037
    tuple_0 = ()
    tuple_1 = ()
    var_1 = vars_get_vars(tuple_0, tuple_1, vars_module_0, int_0)
    if (subdir_0 == "/etc/ansible/host_vars"):
        print("\tFAILED: class VarsModule, method get_vars")
        return

# Generated at 2022-06-25 12:25:30.373666
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)


# Generated at 2022-06-25 12:25:41.546372
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    int_0 = -1037

    var_0 = vars_get_vars(tuple_0, tuple_1, vars_module_0, int_0)
    var_1 = vars_get_vars(tuple_1, tuple_1, vars_module_0, int_0)
    var_2 = vars_get_vars(tuple_2, tuple_1, vars_module_0, int_0)

    var_3 = vars_get_vars(tuple_0, tuple_2, vars_module_0, int_0)

# Generated at 2022-06-25 12:25:45.732021
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_get_vars_0 = VarsModule()
    tuple_0 = ()
    tuple_1 = ()
    int_0 = 4366
    var_2 = vars_get_vars(tuple_0, tuple_1, vars_module_get_vars_0, int_0)
    print(var_2)


# Generated at 2022-06-25 12:28:09.966556
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    tuple_0 = ()
    vars_module_0 = VarsModule()
    int_0 = -1037
    vars_module_0.get_vars(tuple_0, tuple_0, tuple_0, int_0)

# Generated at 2022-06-25 12:28:10.804353
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO: This test is incomplete
    assert(False)



# Generated at 2022-06-25 12:28:14.771392
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    args = (tuple, tuple, VarsModule)
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)

# Generated at 2022-06-25 12:28:16.132025
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  # Should not raise an error
  test_case_0()



# Generated at 2022-06-25 12:28:24.704008
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
	#make inputs
	tuple_0 = ()
	tuple_1 = ()
	vars_module_0 = VarsModule()
	int_0 = -1037

	#call method
	for found in FOUND:
		if found == '%s.%s' % (entity.name, opath):
			var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)
			assert var_0 == FOUND[found]
			print("Passed")
		else:
			if found == '%s.%s' % (entity.name, os.path.realpath(to_bytes(os.path.join(self._basedir, subdir)))):
				var_0 = vars_

# Generated at 2022-06-25 12:28:25.527343
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:28:27.122862
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    varsModule = VarsModule()
    varsModule.get_vars()


# Generated at 2022-06-25 12:28:31.957195
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create the mock object
    vars_module_1 = VarsModule()
    tuple_1 = ()
    int_1 = -1037

    # Call the method with simple arguments
    var_1 = vars_module_1.get_vars(tuple_1, tuple_1, tuple_1, int_1)

    # Verify the result
    assert var_1 == {}



# Generated at 2022-06-25 12:28:36.116042
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-25 12:28:40.106394
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    tuple_0 = ()
    int_0 = -1037
    var_0 = vars_get_vars(tuple_0, tuple_0, vars_module_0, int_0)