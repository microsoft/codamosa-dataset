

# Generated at 2022-06-25 12:19:24.143407
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # noinspection PyUnusedLocal
    def _VarsModule_get_vars(self, loader, path, entities, cache=True):
        # noinspection PyUnresolvedReferences
        return self._get_vars(loader, path, entities, cache)

    # noinspection PyUnusedLocal
    def _get_vars(self, loader, path, entities, cache=True):
        return self._get_vars(loader, path, entities, cache)

    def _set_VarsModule_get_vars(self, get_vars):
        self._get_vars = get_vars

    vars_module_0 = VarsModule()
    vars_module_0._set_VarsModule_get_vars(_VarsModule_get_vars)
    entities_0 = []
    v

# Generated at 2022-06-25 12:19:26.064179
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    # TODO
    vars_module_1.get_vars()

# Generated at 2022-06-25 12:19:36.280062
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars

    vars_module_0 = VarsModule()
    x = to_bytes('this')
    y = to_text('this')
    cur_entity = Host()
    path_0 = to_bytes(os.path.realpath(to_bytes(os.path.join(to_bytes('.'), to_bytes('vars_plugins')))))
    data_0 = {}
    loader = vars_loader
    cache = True
    found_files = []
    # load vars

# Generated at 2022-06-25 12:19:38.167623
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars = vars_module_1.get_vars()


# Generated at 2022-06-25 12:19:47.558749
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check','diff'])

# Generated at 2022-06-25 12:19:57.291614
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    vars_module_1 = VarsModule()

    loader = DataLoader()
    collection_loader = AnsibleCollectionLoader()

    script_path = os.path.realpath(os.path.join(os.getcwd(), __file__))
    test_case_path = os.path.realpath(os.path.join(script_path, '..'))

    basedir = os.path.realpath(os.path.join(test_case_path, 'includes', 'vars_host_group_vars'))
    host_name = 'test'


# Generated at 2022-06-25 12:19:59.459066
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a host object to pass to the get_vars method
    h = Host(name="test_name")
    vars_module = VarsModule()
    assert vars_module.get_vars('test_loader', 'test_path', h) == {}

# Generated at 2022-06-25 12:20:05.216961
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a group
    group = Group(loader=None, inventory="", name="group_name")
    # Create a host
    host = Host(loader=None, inventory="", name="host_name")
    # Set the base dir
    vars_module = VarsModule()
    vars_module._basedir = "./"
    # Call method get_vars
    result = vars_module.get_vars(None, "./", [group, host], False)
    # Check if result is equal to the expected value

# Generated at 2022-06-25 12:20:16.640516
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    try:
        vars_module_1.get_vars(None, None, None, False)
    except Exception as e:
        assert getattr(e, 'message', None) == 'Supplied entity must be Host or Group, got NoneType instead'
    group_1 = Group()
    group_1.name = 'ansible_fax'
    try:
        vars_module_1.get_vars(None, None, group_1, False)
    except Exception as e:
        assert getattr(e, 'message', None) == "The variable named 'ansible_fax' is not defined in '<class 'ansible.vars.host_group_vars.VarsModule'>'"
    host_1 = Host()

# Generated at 2022-06-25 12:20:26.596995
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    # Setup test
    #
    # @return text
    # Constructor for MockClass
    def MockClass(self, *args, **kwargs):
        test_class = args[0]
        test_class._loader = MockClass_obj._loader
        test_class._basedir = MockClass_obj._basedir
        return test_class
    def MockClass_obj(*args, **kwargs):
        pass
    MockClass_obj._loader = MockClass_obj
    MockClass_obj._basedir = 'MOCK_DATA'
    vars_module_1.__class__ = MockClass
    entities = MockClass_obj
    MockClass_obj.name = 'MOCK_DATA'
    path = 'MOCK_DATA'

    # Run test
    res = v

# Generated at 2022-06-25 12:20:40.717215
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_name_path

    # Setup
    vars_module_0 = VarsModule()
    loader_0 = vars_loader._create_loader(playbook_basedir='/home/user/Documents/ansible/playbooks', inventory=[], variable_manager=None)
    path_0 = None
    entities_0 = [Host('myhost')]
    cache_0 = True

    # Testing
    vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)

    # Verify
    b_path = to_bytes(os.path.realpath(os.path.join('/home/user/Documents/ansible/playbooks', 'group_vars')))
   

# Generated at 2022-06-25 12:20:49.866024
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    # Calling get_vars(loader, path, entities, cache=True)
    # group_vars/all.yml
    # group_vars/all.yml
    # group_vars/all.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml
    # host_vars/localhost.yml

# Generated at 2022-06-25 12:20:51.113923
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule().get_vars()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:20:52.379486
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert VarsModule().get_vars(loader, path, entities, cache) == None


# Generated at 2022-06-25 12:20:57.282762
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = MockLoader()
    path_0 = '/Users/mihai/Documents/GitHub/ansible-modules-core/hacking'
    entities_0 = MockHost()
    result = vars_module_0.get_vars(loader_0, path_0, entities_0)

# Generated at 2022-06-25 12:21:07.460068
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    entities_0=[Host()]
    cache_0 = True
    path_0 = "testing"

    # Code to be replaced below
    opath = os.path.realpath(to_bytes(os.path.join(vars_module_0._basedir, "host_vars")))
    b_opath = to_bytes(opath)
    if os.path.exists(b_opath):
        plugin_vars_0  = os.listdir(b_opath)
    else:
        plugin_vars_0 = []

    for plugin_var_0 in plugin_vars_0:
        if plugin_var_0.startswith(b'.'):
            continue
        elif plugin_var_0.endswith('~'):
            continue

# Generated at 2022-06-25 12:21:08.554948
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("Testing get_vars method of VarsModule")
    pass


# Generated at 2022-06-25 12:21:18.467493
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Unit test for method get_vars of class VarsModule')
    vars_module_0 = VarsModule()
    group = Group('group_name')
    vars_module_0.get_vars('loader', 'path', group)
    vars_module_0 = VarsModule()
    host = Host('host_name')
    vars_module_0.get_vars('loader', 'path', host)
    vars_module_0 = VarsModule()
    vars_module_0.get_vars('loader', 'path', ['path_0', 'path_1'])
    return


if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:19.360722
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()

# Generated at 2022-06-25 12:21:30.069107
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Get an instance of the class
    vars_module_1 = VarsModule()

    # Invoke get_vars of VarsModule w/args:
    # loader=<ansible.parsing.dataloader.DataLoader object at 0x7f6a4ea9bd68>
    # path=None
    # entities=[]
    # cache=True
    result = vars_module_1.get_vars(loader=None, path=None, entities=[], cache=True)
    assert isinstance(result, dict)
    assert result == {}

    # Invoke get_vars of VarsModule w/args:
    # loader=<ansible.parsing.dataloader.DataLoader object at 0x7f6a4ea9bd68>
    # path=None
    # entities=

# Generated at 2022-06-25 12:21:39.985705
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()

    vars_module.get_vars(loader=None, path=None, entities=['host_vars.yml'])
    vars_module.get_vars(loader=None, path=None, entities=['group_vars.yml'])



# Generated at 2022-06-25 12:21:50.353206
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path = os.getcwd()
    from ansible.plugins import loader
    from ansible.inventory.manager import InventoryManager
    #create an inventory
    inventory = InventoryManager(loader=loader, sources=path + '/test_cases/test_case_0/hosts')
    #create an array of entities
    entities = ['group1', 'group2', 'host1', 'host2', 'host3', 'host4']
    #create an instance of class VarsModule
    vars_module_0 = VarsModule()
    #test get_vars method of class VarsModule
    value = vars_module_0.get_vars(loader, path, entities)

# Generated at 2022-06-25 12:21:51.877416
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()  # VarsModule.__init__

# Generated at 2022-06-25 12:21:59.525710
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    correct_result = {'ansible_ssh_private_key_file': '~/.ssh/id_rsa',
                      'ansible_ssh_user': 'root',
                      'ansible_ssh_host': 'localhost',
                      'ansible_ssh_port': '22'}
    entities = [Group(name='servers')]

    vars_module_0 = VarsModule()
    test_0_result = vars_module_0.get_vars(loader=None, path='', entities=entities, cache=True)
    assert test_0_result == correct_result

# Generated at 2022-06-25 12:22:04.339188
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader = loader_test_0()
    path = "path"
    entities = ["test_host"]
    cache = True
    get_vars = vars_module.get_vars(loader, path, entities, cache)
    assert get_vars is not None


# Generated at 2022-06-25 12:22:13.237972
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    class MockHost(Host):
        def __init__(self, name):
            self.name = name

    class MockGroup(Group):
        def __init__(self, name):
            self.name = name

    # Testing with a Host object
    host_obj = MockHost("localhost")
    vars_module_0.get_vars(loader=object, path=None, entities=host_obj, cache=True)

    # Testing with a Group object
    group_obj = MockGroup("localhost")
    vars_module_0.get_vars(loader=object, path=None, entities=group_obj, cache=True)

    # Testing with an invalid object

# Generated at 2022-06-25 12:22:24.136547
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_host_name = 'test_host'
    test_group_name = 'test_group'
    mock_path = 'test_path'
    mock_cache = True
    mock_loader = 'test_loader'
    mock_entities = []

    # test to get vars for host
    host = Host(test_host_name)
    mock_entities.append(host)
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(mock_loader, mock_path, mock_entities, cache=mock_cache)

    # test to get vars for group
    mock_entities = []
    group = Group(test_group_name)
    mock_entities.append(group)
    vars_module_0 = VarsModule()
   

# Generated at 2022-06-25 12:22:27.550358
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("testing VarsModule_get_vars")
    vars_module = VarsModule()


if __name__ == "__main__":
    print("running test cases")

    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:30.894391
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_1 = None
    path_1 = None
    entity_1 = None
    result_1 = vars_module_1.get_vars(loader_1, path_1, entity_1)
    assert result_1 is None



# Generated at 2022-06-25 12:22:42.501256
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class MockLoader:
        def find_vars_files(self, path, entity):
            return ['test1', 'test2']

        def load_from_file(self, found, unsafe=False):
            return {'variable': 'test'}

    class MockHost:
        def __init__(self, name):
            self.name = name

    class MockGroup:
        def __init__(self, name):
            self.name = name

    vars_module = VarsModule()
    host = MockHost(name='host_name')
    group = MockGroup(name='group_name')
    result = vars_module.get_vars(MockLoader(), '/', host)
    assert result == {'variable': 'test'}, result

# Generated at 2022-06-25 12:23:03.113181
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path = "/path/to/ansible/playbooks"
    entities = [Host("test_host")]
    loader = None

    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars(loader, path, entities) is not None


# Generated at 2022-06-25 12:23:07.645547
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    entities = [Host(name='abc')]
    path = '/opt/myproj'
    data = vars_module.get_vars(path, entities)
    assert data == {}, "VarsModule.get_vars() method returns incorrect value"


# Generated at 2022-06-25 12:23:12.069917
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = DummyVarsModuleLoader()
    path_0 = "/"
    entities_0 = []
    cache_0 = True
    vars_module_0.get_vars(loader=loader_0, path=path_0, entities=entities_0, cache=cache_0)



# Generated at 2022-06-25 12:23:14.625724
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    a = VarsModule()
    group = Group(name = "test")
    my_loader = DummyLoader()
    result = a.get_vars(loader=my_loader, path="", entities=group)
    assert result["group"] == "vars_2"

# Generated at 2022-06-25 12:23:17.627039
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # By default, all test cases are run
    test_cases = range(0, 1)

    # TODO: Need to provide an inventory file and host and group
    #       names to run this test case
    if 0 in test_cases:
        test_case_0()

# Generated at 2022-06-25 12:23:26.532201
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host1 = Host('host1')
    host2 = Host('host2')
    group1 = Group('group1')
    group2 = Group('group2')
    group3 = Group('group3')
    group4 = Group('group4')
    group5 = Group('group5')
    group6 = Group('group6')
    group7 = Group('group7')

    loader = None
    path = None
    cache = True

    # Case 0.1 test
    entities1 = host1
    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars(loader, path, entities1) == {}

    # Case 0.2 test
    entities2 = host2
    vars_module_1 = VarsModule()

# Generated at 2022-06-25 12:23:31.067874
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    data = {}

    host_1 = Host(name='test_host')
    group_1 = Group(name='test_group')
    list_1 = [host_1, group_1]
    loader = None
    path = ''

    ret = vars_module_0.get_vars(loader, path, list_1)
    assert ret == {}
    assert FOUND == {}


# Generated at 2022-06-25 12:23:33.678900
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create instance of class VarsModule
    vars_module_1 = VarsModule()
    # Get values of variables
    vars_module_1.get_vars()

# Generated at 2022-06-25 12:23:41.673411
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    host_0 = Host()
    loader_0 = vars_module_0.get_loader('/opt/ansible/', 'filesystem')
    path_0 = 'host_vars'
    entities_0 = host_0
    cache_0 = True

    try:
        data_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    except Exception as e:
        raise Exception ("test_VarsModule_get_vars test case failed: %s" % (e))


# Generated at 2022-06-25 12:23:43.966564
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """
    Test of method get_vars
    :return:
    """
    vars_module_0 = VarsModule()
    vars_module_0.get_vars("")

# Generated at 2022-06-25 12:24:12.043462
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(loader, path, entities, cache)

# Generated at 2022-06-25 12:24:16.750188
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = object()
    path_0 = object()
    entities_0 = object()
    cache_0 = object()
    try:
        vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0=cache_0)
    except:
        pass


# Generated at 2022-06-25 12:24:26.044626
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # instantiate a VarsModule object
    vars_module = VarsModule()

    # create a mock loader object
    loader = lambda: None
    loader.find_vars_files = lambda dir, entity: ['file1', 'file2', 'file3']
    loader.load_from_file = lambda file, cache, unsafe: {file: 'variable value'}

    entities = [Host('host1'), Host('host2'), Group('group1'), Group('group2')]

    path = 'path_to_host'

    cache = True

    # call the get_vars method of vars_module using above fixtures
    result = vars_module.get_vars(loader, path, entities, cache)

    # assert that the result is what you expected

# Generated at 2022-06-25 12:24:27.301891
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  vars_module_1 = VarsModule()


# Generated at 2022-06-25 12:24:30.857028
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Test usage of VarsModule.get_vars
    '''
    # Setup test environment

    # Get instance of VarsModule
    vars_module_0 = VarsModule()
    # Test function call
    # get_vars(loader, path, entities, cache=True):
    # Test no. 1:
    # Test no. 2:
    # Test no. 3:

# Generated at 2022-06-25 12:24:32.983613
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var1 = Host()
    var2 = Group()
    var3 = False
    vars_module_0.get_vars(vars_module_0, var1, var2, var3)


# Generated at 2022-06-25 12:24:34.715740
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars(loader={}, path={}, entities={})

# Generated at 2022-06-25 12:24:37.503245
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    data = vars_module_0.get_vars(loader, path, entities, cache)
    assert data

# Generated at 2022-06-25 12:24:39.149112
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # Test 1
    vars_module.get_vars(loader, path, entities, cache=True)


# Generated at 2022-06-25 12:24:40.556786
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Case 0
    # live test
    vars_module_0 = VarsModule()


# Generated at 2022-06-25 12:25:44.821553
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # set up test environment
    os.environ['ANSIBLE_VARS_PLUGIN_STAGE'] = 'vars_files'
    os.environ['ANSIBLE_YAML_FILENAME_EXT'] = '["json", "yml"]'

    test_data_0 = {}

    # Test for entities as list
    for entity in ['a', 'b', 'c']:
        test_data_0[entity] = VarsModule().get_vars(None, None, [entity])

    # Test for entities as string
    entity = 'd'
    test_data_0[entity] = VarsModule().get_vars(None, None, entity)

    return test_data_0

# Generated at 2022-06-25 12:25:47.833523
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    mock_loader = MockLoader()
    mock_entities = []
    path = '/path/to/something'
    vars_module_1.get_vars(mock_loader, path, mock_entities)

# Generated at 2022-06-25 12:25:51.975858
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_vars_module_0 = VarsModule()
    #   VarsModule_vars_module_0._valid_extensions = [".yml", ".yaml", ".json"]
    #   VarsModule_vars_module_0._display = AnsibleDisplay()
    #   VarsModule_vars_module_0._subdirs = ["group_vars", "host_vars"]
    #   VarsModule_vars_module_0.get_vars(loader, path, entities, cache=True)

# Generated at 2022-06-25 12:25:58.470768
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = 'C:\\Users\\Administrator\\Documents\\GitHub\\ansible\\lib'
    entities_0 = []
    cache_0 = True
    vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)

# Generated at 2022-06-25 12:25:58.799839
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    assert True

# Generated at 2022-06-25 12:26:06.214413
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader

    vars = VarsModule()
    path = "/tmp/test_VarsModule_get_vars.yaml"
    with open(path, "w") as myfile:
        myfile.write("---\n")
    entities = "test_VarsModule_get_vars"
    result_expected = {u'test_VarsModule_get_vars': {}}
    result = vars.get_vars(vars_loader, path, entities)
    assert result == result_expected
    os.remove(path)

# Basic unit tests for class Host

# Generated at 2022-06-25 12:26:15.296777
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    assert vars_module_0

    # Path as a string
    path_0_0 = '/etc/ansible/hosts'

    # Entity as a list
    entities_0_0 = ['boston']

    assert vars_module_0.get_vars(loader=None, path=path_0_0, entities=entities_0_0, cache=True)

    # Entity as a string
    entities_0_1 = 'boston'

    assert vars_module_0.get_vars(loader=None, path=path_0_0, entities=entities_0_1, cache=True)

    # Path as a list
    path_0_1 = ['/etc/ansible/hosts']

    assert vars_module_0.get

# Generated at 2022-06-25 12:26:16.789524
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    # vars_module_0.get_vars(loader, path, entities, cache=True)

# Generated at 2022-06-25 12:26:17.744999
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars()

# Generated at 2022-06-25 12:26:23.393859
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    try:
        loader = None
        path = None
        entities = None

        # calling get_vars method
        vars_module_1.get_vars(loader, path, entities)

    except Exception as e:
        print("Exception when calling get_vars method")
        print(str(e))


# Generated at 2022-06-25 12:27:27.838429
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    data_0 = None
    loader_0 = BaseVarsPlugin()
    path_0 = 'fv'
    entities_0 = Group()
    cache_0 = True
    var_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert type(var_0) == dict



# Generated at 2022-06-25 12:27:31.554134
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = Loader()
    path = '/./'
    entities = ['vars_host_group_vars_var_0', 'vars_host_group_vars_var_0']
    cache = True

    ansible_0 = VarsModule()
    ansible_get_vars = ansible_0.get_vars(loader, path, entities, cache)

# Generated at 2022-06-25 12:27:33.837887
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = False
    float_0 = 579.0
    var_0 = vars_get_vars(vars_module_0, bool_0, float_0)
    print(var_0)


# Generated at 2022-06-25 12:27:35.646849
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Params
    vars_module = VarsModule()
    bool_0 = False
    float_0 = 579.0
    # Var
    var_0 = vars_get_vars(vars_module, bool_0, float_0)


# Generated at 2022-06-25 12:27:44.090443
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = True
    bool_1 = True
    float_0 = 579.0
    float_1 = 579.0
    var_0 = vars_get_vars(vars_module_0, bool_0, float_0)
    var_1 = vars_get_vars(vars_module_0, bool_1, float_1)
    var_2 = vars_get_vars(vars_module_0, bool_1, float_0)
    var_3 = vars_get_vars(vars_module_0, bool_0, float_1)


# Generated at 2022-06-25 12:27:47.362770
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = False
    float_0 = 758.0
    var_0 = vars_get_vars(vars_module_0, bool_0, float_0)

# Test cases for get_vars of method of class VarsModule

# Generated at 2022-06-25 12:27:52.496744
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    bool_1 = False
    float_1 = 607.0
    entities_1 = 'entities'
    cache_1 = False
    var_1 = vars_get_vars(vars_module_1, bool_1, float_1, entities_1, cache_1)


# Generated at 2022-06-25 12:27:55.766859
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = False
    float_0 = 579.0
    var_0 = vars_get_vars(vars_module_0, bool_0, float_0)



# Generated at 2022-06-25 12:27:58.041494
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader = None
    path = to_text(u'.', encoding='utf-8')
    hosts = []
    cache = None

    result = vars_module.get_vars(loader, path, hosts, cache)

    assert result is None


# Generated at 2022-06-25 12:28:00.192830
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = False
    float_0 = 61.0
    var_0 = vars_get_vars(vars_module_0, bool_0, float_0)
    assert (var_0 == True)