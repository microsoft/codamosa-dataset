

# Generated at 2022-06-25 12:19:28.315407
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    f = open('test/test_VarsModule_get_vars_01.out', 'w')

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='test/inventory')
    variable_manager.set_inventory(inventory)
    add_group = Group('add')
    inventory.add_group(add_group)
    host = Host(name="localhost")
    add_group.add_host(host)
    variable_manager.set_host_variable(host, 'foo', 'bar')

    f.write('\nget_vars()\n')

    variable

# Generated at 2022-06-25 12:19:34.193862
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Creating objecy of class VarsModule
    vars_module_test = VarsModule()
    # Call to the method get_var, passing the  values for arguments loader, path, cache, entities
    vars_module_test.get_vars(loader="loader", entities="entities", path="path")


# Generated at 2022-06-25 12:19:36.160056
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass


if __name__ == "__main__":

    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:19:45.934253
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Fix for issue #31778
    # Test for successful loading of host_vars and group_vars
    entity = Host("black.example.org")
    base_dir = '/home/ansible/ansible'
    vars_module_0 = VarsModule()
    loader = ansible.parsing.dataloader.DataLoader()
    test_vars = vars_module_0.get_vars(loader, base_dir, entity)
    assert 'ansible_ssh_host' in test_vars
    assert 'ansible_python_interpreter' in test_vars
    assert test_vars['ansible_ssh_host'] == '10.0.0.1'
    assert test_vars['ansible_python_interpreter'] == '/usr/bin/python3'

# Generated at 2022-06-25 12:19:56.361383
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test for the presence of file
    with open("host_vars/test-host-0.yml", "w") as f:
        f.write("---\n")
        f.write("ansible_host: \"127.0.0.1\"\n")
        f.write("test_variable_0: \"{{ test_variable_0 | default(1) }}\"\n")
        f.write("test_variable_1: \"{{ test_variable_1 | default(2) }}\"\n")
        f.write("test_variable_2: \"{{ test_variable_2 | default(3) }}\"\n")
        f.write("...\n")

    # Test for the presence of file

# Generated at 2022-06-25 12:19:57.654450
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test based on Ansible Vars Plugin
    vars_module = VarsModule()
    vars_module.get_vars(loader=None, path=None, entities=None, cache=True)
    assert True

# Generated at 2022-06-25 12:20:01.613940
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1._basedir = './test/unit/plugins/vars/host_group_vars/test_case_0/data/'
    entities = []
    host = Host('host1')
    group = Group('group1')
    entities.extend([host, group])
    assert vars_module_1.get_vars(None, None, entities, False)['foobar'] == 'junk'


# Generated at 2022-06-25 12:20:03.562859
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_1 = AnsibleLoader()
    entities = None
    vars_module_1.get_vars(loader_1, 'test_path', entities)


# Generated at 2022-06-25 12:20:05.388720
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars(loader, path, entities)


# Generated at 2022-06-25 12:20:11.772572
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()

    vars_module.get_vars("test_loader", "test_path", [])
    vars_module.get_vars("test_loader", "test_path", Host("test_host"))
    vars_module.get_vars("test_loader", "test_path", Group("test_group"))

# Generated at 2022-06-25 12:20:20.848808
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    assert var_0 == {}

# Generated at 2022-06-25 12:20:29.010282
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # test case 0
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    # test case 1
    str_1 = '5xLg~0Z*FNc%'
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(str_1, vars_module_1, vars_module_1, str_1)
    # test case 2
    str_2 = 'z`;g`XN&'
    vars_module_2 = VarsModule()

# Generated at 2022-06-25 12:20:32.769011
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        test_case_0()
        assert True
    except Exception as exc:
        print(exc)
        assert False



# Generated at 2022-06-25 12:20:37.146059
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)


# Generated at 2022-06-25 12:20:40.965490
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '*#nJ]Vl~3q+^A'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)


# Generated at 2022-06-25 12:20:46.950108
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print(' Testing method get_vars of class VarsModule')
    print(' Testing case 0')
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    print(' Test if the method get_vars returns the value true')
    assert var_0 == True

# Generated at 2022-06-25 12:20:53.059009
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Setting up test case
    path = './testcases/unit_test_files/get_vars_test_file'
    entities = [Host()]
    cache = True
    vars_module = VarsModule()
    expected_return_value = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    # Run the method to be tested
    returned_value = vars_module.get_vars(vars_module, path, entities, cache)

    # Check test results
    assert expected_return_value == returned_value


# Generated at 2022-06-25 12:20:58.147806
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'R|-k:E1XA/M~'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(vars_module_0, vars_module_0, str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:21:04.818374
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Purpose: test a known value
    # Pre conditions:
    #     Known value, vars_module_0 = VarsModule()
    # Test:
    #     Call method get_vars of vars_module_0 with known value str_0, vars_module_0, str_0
    # Post conditions:
    #     Check method returns var_0
    assert method_returns == expected_value


# Generated at 2022-06-25 12:21:08.119692
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)


# Generated at 2022-06-25 12:21:22.169670
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

test_VarsModule_get_vars.weak = False


# Generated at 2022-06-25 12:21:29.029368
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Check that AnsibleParserError is being raised
    try:
        str_0 = 'd}Fwf2U:Z6U'
        vars_module_0 = VarsModule()
        var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

    #Check if there is an exception
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 12:21:32.224087
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Generated at 2022-06-25 12:21:37.731519
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    str_1 = 'eVu"r@B(7Vu9'
    str_2 = '&RJ<~Fc%=A$'
    vars_module_0 = VarsModule()
    dict_0 = dict()
    dict_1 = dict()
    dict_1['key'] = str_0
    dict_0[str_0] = dict_1
    dict_1 = dict()
    dict_1['key'] = str_1
    dict_0[str_1] = dict_1
    dict_1 = dict()
    dict_1['key'] = str_2
    dict_0[str_2] = dict_1
    dict_2 = dict()

# Generated at 2022-06-25 12:21:39.386560
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # assert vars_module_0.get_vars(str_0, var_0) == str_0
    assert True


# Generated at 2022-06-25 12:21:41.852349
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(None, vars_module_0, vars_module_0, None)

# Generated at 2022-06-25 12:21:44.803400
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:50.618649
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_1 = 'q$xh,V|~0'
    str_2 = '!d,7TC'
    vars_module_1 = VarsModule()
    vars_module_2 = VarsModule()
    var_1 = vars_get_vars(str_1, vars_module_1, vars_module_2, str_2)

test_case_0()
test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:54.208477
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '=>Uy'
    str_1 = '|dG*'
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(str_0, str_1, str_0, str_0)


# Generated at 2022-06-25 12:21:59.308561
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    [(['', [], True], [{}]), (['', None, True], []), (['', '', True], []), (['', 0, True], []), (['', [], False], [{}]), (['', None, False], []), (['', '', False], []), (['', 0, False], [])]


# Generated at 2022-06-25 12:22:15.678241
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Generated at 2022-06-25 12:22:22.427440
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0, True)
    print('result: ', var_0)
    assert var_0 == None


test_case_0()
test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:23.364888
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:22:27.507929
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '!@Y/{M>a/N@N;'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    assert (var_0 == 0)


# Generated at 2022-06-25 12:22:32.780695
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader_0 = Loader()
    path_0 = ']J9C7Vu'
    entities_0 = Host()
    vars_module_0 = VarsModule()
    vars_module_1 = vars_module_0
    
    # Case 0
    test_case_0()



# Generated at 2022-06-25 12:22:43.176722
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    str_0 = '&'
    str_1 = 'B6|++_'
    str_2 = 'oG'
    str_3 = '.+^L/'
    str_4 = 'xN'
    str_5 = '|,a'
    str_6 = '/'
    str_7 = 'aK^'
    str_8 = '+y5r'
    str_9 = '%'
    str_10 = 'H/Fw)*'
    str_11 = 'f&'
    str_12 = 'vb'
    str_13 = '|C_kz'
    str_14 = '2A'
    loader_0 = AnsibleLoader()
    dict_0 = Dict()
    dict_1 = D

# Generated at 2022-06-25 12:22:47.263843
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '/home/travis/build/'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Generated at 2022-06-25 12:22:56.485930
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path_0 = 'U6,dmMtw}$REK'
    vars_module_0 = VarsModule()
    stage_0 = 'U6,dmMtw}$REK'
    entities_0 = list([])
    opath_0 = '/'
    found_files_0 = ''
    found_0 = ''
    new_data_0 = ''
    str_0 = 'pHgVY*D$#_'
    var_0 = vars_get_vars(str_0, vars_module_0, stage_0, entities_0)
    assert var_0 == dict(), 'Expected dict(), but it returned: ' + str(var_0)

# Generated at 2022-06-25 12:22:59.168928
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  try:
    #pass
    test_case_0()
  except Exception as e:
    print("Exception: " + str(e))
    raise Exception("Failed test case: test_VarsModule_get_vars")

# Test prop: stage_name

# Generated at 2022-06-25 12:23:01.979207
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    test_case_0(vars_module_0, vars_module_0, str)

# Generated at 2022-06-25 12:23:37.681619
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-25 12:23:41.716868
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()

    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

    var_0 += 1

# Generated at 2022-06-25 12:23:51.912434
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'v'
    str_1 = { 'R_?#' : '6', 'W8' : 'nMG3EI3%M5', 'W8' : 'R_?#' }
    str_2 = 'W8'
    str_3 = 'y'
    str_4 = 'EI3%M5'
    str_5 = 'r'
    str_6 = 42
    str_7 = 'o'
    str_8 = 'a'
    str_9 = 'R_?#'
    str_10 = 'g'
    str_11 = 'u'
    str_12 = 'c'
    str_13 = 'e'
    str_14 = 'G'
    str_15 = 'G'
    str_16 = 'E'
    str_

# Generated at 2022-06-25 12:23:55.124490
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Generated at 2022-06-25 12:23:57.775741
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '4UA/'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    assert (var_0 == {})

# Generated at 2022-06-25 12:24:06.079754
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'r5yrxK_=H'
    str_1 = 'm:uV7Wb$6'
    str_2 = '!KD8W@{zBJ7R'
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(str_0, str_1, list_0, bool_0)

if __name__ == "__main__":
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:24:12.875484
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    str_1 = 'Ce1w'
    str_2 = 'ax&>[JCTgE^'
    vars_module_0 = VarsModule()
    path_0 = '+j>'
    host_0 = Host(str_0, str_1)
    entities_0 = [host_0]
    cache_0 = False
    data_0 = vars_module_get_vars(path_0, vars_module_0, entities_0, cache_0)
    assert data_0 is not None


# Generated at 2022-06-25 12:24:14.849197
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'HQ{:sU|LZ'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)


# Generated at 2022-06-25 12:24:24.997790
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    list_0 = ['e', 'L']
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    var_1 = vars_get_vars(str_0, vars_module_0, vars_module_0, list_0)
    var_2 = vars_get_vars(str_0, vars_module_0, vars_module_0, list_0)
    var_3 = vars_get_vars(str_0, vars_module_0, vars_module_0, list_0)
    var_4 = vars_get

# Generated at 2022-06-25 12:24:28.167990
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'P/AiU6(YLDj^S'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)


# Generated at 2022-06-25 12:25:23.937486
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:25:27.304537
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  str_0 = 'Qm/cB$9Ow{Fc$'
  vars_module_0 = VarsModule()
  var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
  assert True


# Generated at 2022-06-25 12:25:28.667770
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  test_case_0()

# Tests for vars_get_vars of VarsModule


# Generated at 2022-06-25 12:25:32.071307
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    b_path_0 = to_bytes(C.DEFAULT_HOST_LIST)
    var_0 = vars_get_vars(b_path_0, VarsModule(), VarsModule(), b_path_0)

vars_get_vars = VarsModule.get_vars  # get_vars defined in the class VarsModule


if __name__ == "__main__":
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:32.715222
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert 1 == 1

# Generated at 2022-06-25 12:25:36.282581
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'test_path'
    vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Unit test main function

# Generated at 2022-06-25 12:25:42.304218
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    arg_0 = 'V(,u'
    arg_1 = VarsModule()
    arg_2 = VarsModule()
    arg_3 = '&%A@'
    arg_4 = '#/xkK'
    obj = VarsModule()
    result = obj.get_vars(arg_0, arg_1, arg_2, arg_3, arg_4)
    assert(result is None)

# Generated at 2022-06-25 12:25:43.818255
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("\nTest get_vars method of VarsModule")
    test_case_0()


# Generated at 2022-06-25 12:25:47.125335
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)


# Generated at 2022-06-25 12:25:50.497028
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Generated at 2022-06-25 12:27:46.917736
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = ''
    str_1 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    var_1 = vars_get_vars(str_1, vars_module_0, vars_module_0, str_1)


# Generated at 2022-06-25 12:27:55.727076
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path_0 = '!b.'
    vars_module_0 = VarsModule()
    str_0 = '-X[gF0h*j6&'
    entities_0 = Host(str_0)
    var_0 = vars_get_vars(entities_0, vars_module_0, path_0, vars_module_0)
    path_1 = '-X[gF0h*j6&'
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars('-X[gF0h*j6&', vars_module_1, path_1, 'X9O[DdRt%c7')

# Generated at 2022-06-25 12:28:00.027853
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = BaseVarsPlugin()
    path_0 = ')m=p-L{_hnJ'
    entities_0 = [Host()]
    # Call the method
    get_vars(loader_0, path_0, entities_0, vars_module_0)

test_case_0()

# Generated at 2022-06-25 12:28:09.199655
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Qm/cB$9Ow{Fc$'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    var_1 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    var_2 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)
    var_3 = vars_get_vars(str_0, vars_module_0, vars_module_0, str_0)

# Generated at 2022-06-25 12:28:12.715357
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Z^tA7P*i,A{D'
    str_1 = 'B$k#0,i#p_0Y'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(str_0, str_1, vars_module_0, str_0)


# Generated at 2022-06-25 12:28:14.857005
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    # var_0.get_vars()
    pass

# Generated at 2022-06-25 12:28:19.400806
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        ansible_vars_plugin_stage= '######'
        ansible_vars_plugin_stage= '>>>>>'
        ansible_vars_plugin_stage= '*****'
    except Exception as e:
        print(e)
        raise e

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:28:21.708728
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    source_text = "Qm/cB$9Ow{Fc$"
    # Test cases
    if test_case_0():
        pass
    
    

# Generated at 2022-06-25 12:28:23.753171
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        VarsModule_get_vars()
        assert False
    except Exception as e:
        print(e)
        assert True
        

# Generated at 2022-06-25 12:28:32.519986
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '{S9R/!|&@>NZ/Fw=l'
    vars_module_0 = VarsModule()
    vars_module_1 = VarsModule()
    str_1 = '@1i$%c&oW=mp$7><u'
    vars_get_vars(str_0, vars_module_0, vars_module_1, str_1)
    str_2 = '{S9R/!|&@>NZ/Fw=l'
    str_3 = '@1i$%c&oW=mp$7><u'
    var_0 = vars_get_vars(str_2, vars_module_0, vars_module_1, str_3)
    assert None is not var_0

#