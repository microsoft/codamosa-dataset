

# Generated at 2022-06-25 12:19:19.164067
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = {'_file_cache': {}}
    path_0 = 'test/path'
    entities_0 = []
    cache_0 = True
    data_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)


# Generated at 2022-06-25 12:19:21.086937
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert hasattr(vars_module, 'get_vars'), 'get_vars method is not defined'

# Generated at 2022-06-25 12:19:25.547613
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    test_loader = object()
    test_path = "/path"
    test_entities = [Host(), Group()]
    output = vars_module.get_vars(test_loader, test_path, test_entities)
    assert output is not None


# Generated at 2022-06-25 12:19:35.840973
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case 0
    ansible_vars_plugin_stage = os.getenv('ANSIBLE_VARS_PLUGIN_STAGE', 'default')
    b_basedir = to_bytes(os.path.realpath('./'))
    basedir = to_text(b_basedir)
    loader = None
    path = './'
    entities = [{'name': 'test'}]

    # Test case 1
    ansible_vars_plugin_stage = os.getenv('ANSIBLE_VARS_PLUGIN_STAGE', 'default')
    b_basedir = to_bytes(os.path.realpath('./'))
    basedir = to_text(b_basedir)
    loader = None
    path = './'

# Generated at 2022-06-25 12:19:45.614096
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case for the entities type Host
    host = Host('127.0.0.1', port=22)
    host.vars['host_name'] = 'host_127.0.0.1'
    host.vars['connection'] = 'local'
    vars_module_1 = VarsModule()
    vars_result = vars_module_1.get_vars(loader=None, path=None, entities=host, cache=None)
    assert 'host_127.0.0.1' in vars_result
    assert 'connection'in vars_result
    assert vars_result['connection'] == 'local'
    assert vars_result['host_name'] == 'host_127.0.0.1'
    # Test case for the entities type Group
    group = Group('test_group')

# Generated at 2022-06-25 12:19:47.276426
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
   vars_module = VarsModule()
   vars_module.get_vars()

# Generated at 2022-06-25 12:19:54.106898
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    fake_loader = FakeLoader('/some/fake/base/dir')
    fake_entities = [FakeEntity('an/inventory/host'), FakeEntity('a_group')]
    vars_module = VarsModule()
    data = vars_module.get_vars(fake_loader, '/some/fake/base/dir', fake_entities)
    assert isinstance(data, dict)
    assert data == {'vars1': 'value1', 'vars2': 'value2'}


# Generated at 2022-06-25 12:19:58.578271
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()

    class loader():
        def find_vars_files(self, path, name):
            path = os.path.join(path, name)
            return [path]

        def load_from_file(self, path, cache=True, unsafe=True):
            return {path: "foo"}

    class host():
        def __init__(self, name):
            self.name = name
            self.groups = [group(name)]

    class group():
        def __init__(self, name):
            self.name = name

    from ansible.utils.vars import AnsibleVars
    assert isinstance(vars_module.get_vars(loader(), '/tmp', host('foo')), AnsibleVars)

# Generated at 2022-06-25 12:20:02.063665
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    inventory_data_0 = [['abc']]
    entities_0 = [Host(name='abc')]
    try:
        vars_module_0.get_vars(loader=None, path=inventory_data_0, entities=entities_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 12:20:05.145830
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    try:
        vars_module_1.get_vars("test_path","test_entities")
    except Exception as exception:
        print("Exception: ", exception)

# Generated at 2022-06-25 12:20:09.344310
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert False

test_case_0()

# Generated at 2022-06-25 12:20:10.014370
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:20:18.176183
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_test = VarsModule()
    test_host = Host('test_host')
    test_host.name = "test_host"
    test_host.port = '''22'''
    test_host.vars = dict()
    test_loader = None
    test_path = '/home/user'
    test_entities = [test_host]
    vars_module_test.get_vars(test_loader, test_path, test_entities)
    assert test_host.name == "test_host"
    assert test_host.port == '''22'''
    assert test_host.vars == dict()


# Generated at 2022-06-25 12:20:18.768036
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:20:23.414975
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = object()
    path_0 = 'path_0'
    entities_0 = []

    # Call method
    result = vars_module_0.get_vars(loader_0, path_0, entities_0)
    assert result == {}

# Generated at 2022-06-25 12:20:26.338800
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader_0 = None
    path_0 = "./"
    entities_0 = []
    cache_0 = True
    var_0 = VarsModule.get_vars(loader_0, path_0, entities_0, cache_0)

test_case_0()

# Generated at 2022-06-25 12:20:31.711007
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import unittest
    import ansible
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    class Host0(Host):
        def __init__(self, name):
            self.hostname = name
            self.name = name

    class TestGetVars(unittest.TestCase):
        def test_get_vars(self):
            config = ansible.config.loader.ConfigLoader()
            config.set_config_value('host_group_vars', 'stage', 'non-existent')
            self.assertEquals(config.get_config_value('host_group_vars', 'stage'), 'non-existent')

            host_0 = Host0('test_host')
            host_

# Generated at 2022-06-25 12:20:33.742898
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars is not None

# Generated at 2022-06-25 12:20:38.237632
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    path = '/etc/ansible/'
    entities = [Host(name = 'test-host-name')]
    loader = None
    cache = True
    result = vars_module_0.get_vars(loader, path, entities, cache)
    assert (isinstance(result, dict))

# Generated at 2022-06-25 12:20:40.313657
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    data = vars_module.get_vars(None, None, None, True)
    assert data is not None

# Generated at 2022-06-25 12:20:51.568395
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = None
    bytes_0 = b''
    entity_0 = Host()
    # Testing here requires a monkey patch to ansible.utils.display.Display._display
    # to store data from the 'debug' call.  This is because there is no reliable
    # way to mock the output of os.path.exists() in this case.  The _display()
    # call is made before the os.path.exists() call, so it can be used as a
    # signal to clean up after the test.
    vars_get_vars(vars_module_0, bool_0, bytes_0, entity_0, False)

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars

# Generated at 2022-06-25 12:20:54.273994
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = None
    str_0 = str()
    list_0 = []
    var_0 = vars_get_vars(vars_module_0, bool_0, str_0, list_0)

# Generated at 2022-06-25 12:20:58.148171
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_get_vars(vars_module_0, bytes_0, bytes_0, bool_0)
    assert False, "Cannot yet implement"


# Generated at 2022-06-25 12:21:08.229150
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = b''
    dict_0 = dict()
    obj_0 = Group()
    list_0 = list()
    bytes_1 = b''
    vars_module_0 = VarsModule()

    def obj_to_obj_0(obj_0_arg):
        return obj_0_arg

    setattr(vars_module_0, '_AnsibleBaseVarsPlugin__basedir', bytes_0)
    setattr(vars_module_0, '_AnsibleBaseVarsPlugin__display', dict_0)
    setattr(vars_module_0, '_valid_extensions', list_0)
    # Missing the following call to self._validate_extensions()

# Generated at 2022-06-25 12:21:14.080527
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    try:
        var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    except:
        assert False

# Generated at 2022-06-25 12:21:17.482417
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

# Generated at 2022-06-25 12:21:21.380696
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:21:27.300568
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

if __name__ == "__main__":
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:30.871247
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)



# Generated at 2022-06-25 12:21:33.175691
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars(loader=None, path=None, entities=None, cache=True) is None
    assert vars_module.get_vars(loader=None, path=None, entities=None, cache=False) is None

# Unit tests for class VarsModule

# Generated at 2022-06-25 12:21:46.744278
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_2 = None
    bytes_1 = b''
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, bool_2, bytes_1, bool_2)



# Generated at 2022-06-25 12:21:51.448462
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Input parameters for function get_vars
    bool_0 = None
    bytes_0 = b''
    bool_1 = None

    # Call function get_vars with appropriate arguments
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(bool_0, bytes_0, bool_1)
    assert type(var_0) == dict

# Generated at 2022-06-25 12:21:55.026234
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    # vars_module_0.get_vars() test:
    #   Returns: Dict
    #   Raises: AssertionError, ValueError, IOError, SyntaxError, Exception
    assert True



# Generated at 2022-06-25 12:22:01.145712
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

    # Test get_vars method on instance VarsModule
    assert_not_equal(var_0, None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:22:04.824805
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    boolean_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, boolean_0, bytes_0, boolean_0)

# Generated at 2022-06-25 12:22:08.449777
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_1 = None
    bytes_1 = b''
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, bool_1, bytes_1, bool_1)


# Generated at 2022-06-25 12:22:12.011748
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    var_1 = None
    var_2 = b''
    var_3 = None
    method_result_0 = var_0.get_vars(var_1, var_2, var_3)
    assert(method_result_0 == None)

# Generated at 2022-06-25 12:22:17.280381
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:22:21.175023
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_1 = None
    vars_module_0 = VarsModule()
    vars_module_0.get_vars()
    _vars_2 = vars_module_0.get_vars(bool_1, bool_1, bool_1)

# Generated at 2022-06-25 12:22:24.314011
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

# Generated at 2022-06-25 12:22:39.445723
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

# Generated at 2022-06-25 12:22:41.652435
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    #assert isinstance(actual, expected), 'Test failed because expected raised exception but actual did not'
    #assert expected == actual, 'Test has failed because expected and actual do not match'
    #assert True == False, 'Test has failed because expected and actual do not match'
    pass

# Generated at 2022-06-25 12:22:44.044345
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    # AssertionError: None
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 12:22:47.145427
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bytes_0, bytes_0, True)

# Generated at 2022-06-25 12:22:51.350310
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)


# Generated at 2022-06-25 12:22:56.871518
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    module = AnsibleModule(
        argument_spec=dict(
            stage=dict(type='str'),
        ),
        supports_check_mode=False
    )

    args = dict(
        stage='resolve_vars',
    )

    from ansible.plugins.loader import vars_loader

    vars_plugin = vars_loader.get('host_group_vars', class_only=True)
    result = vars_plugin(**args)

    assert result == vars_module_0



# Generated at 2022-06-25 12:23:00.610306
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test 0
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)


# Generated at 2022-06-25 12:23:04.471138
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Tests get_vars method of class VarsModule using mock object
    vars_module = VarsModule()
    vars_module_get_vars(vars_module)


# Generated at 2022-06-25 12:23:07.605204
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

# Generated at 2022-06-25 12:23:10.527280
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_1 = vars_module_get_vars(bool_0, bytes_0, bool_0, bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:23:45.134642
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  # No subdir test
  vars_module_0 = VarsModule()
  bytes_0 = b''
  entities_0 = []
  cache_0 = True
  vars_get_vars(vars_module_0, bytes_0, entities_0, cache_0)

  # Host test
  vars_module_1 = VarsModule()
  bytes_1 = b''
  entities_1 = []
  cache_1 = True
  vars_get_vars(vars_module_1, bytes_1, entities_1, cache_1)

  # Group test
  vars_module_2 = VarsModule()
  bytes_2 = b''
  entities_2 = []
  cache_2 = True

# Generated at 2022-06-25 12:23:51.020849
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_0 = VarsModule()
    loader_0 = None
    path_0 = b''
    entities_0 = []
    cache_0 = True
    assert_equals(VarsModule_0.get_vars(loader_0, path_0, entities_0, cache_0), {})


# Generated at 2022-06-25 12:23:52.907104
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    var_0.get_vars(None, None, None)

# Generated at 2022-06-25 12:23:55.357353
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Set up mock
    vars_module_0 = MockVarsModule()
    vars_module_0.get_vars(loader, path, entities, cache=True)


# Generated at 2022-06-25 12:23:58.561649
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)


# Test of class VarsModule

# Generated at 2022-06-25 12:23:59.561255
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test case 0
    yield test_case_0


# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 12:24:10.568614
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # unit test for method get_vars of class VarsModule
    print(__name__)
    print(test_VarsModule_get_vars.__name__)

    vars_module_0 = VarsModule()
    vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert vars_module_0.REQUIRES_WHITELIST == True
    assert vars_module_0.get_vars(vars_module_0,vars_module_0,vars_module_0) == vars_module_0.get_vars(vars_module_0,vars_module_0,vars_module_0)

# Generated at 2022-06-25 12:24:12.995907
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-25 12:24:15.000050
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)



# Generated at 2022-06-25 12:24:22.219626
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entity = Host()
    entity.name = 'host'
    entities = [entity]
    vars_module_1 = VarsModule()
    vars_module_1._basedir = 'tests/integration/data'
    var_1 = vars_module_1.get_vars(vars_module_1, vars_module_1, entities, bool(1))
    assert var_1 == {'host': {'var': 'test'}, 'all': {'var': 'test'}}

# Generated at 2022-06-25 12:25:21.116963
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    # No parameters
    vars_get_vars(vars_module_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:25:26.814578
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    print('Unit test for method get_vars of class VarsModule')
    try:
        assert var_0 == None
    except AssertionError as e:
        print('Test Failed')

test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:33.710735
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = True
    bytes_0 = b'/tmp/'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

# Generated at 2022-06-25 12:25:38.233077
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    assert len(var_0.keys()) == 0

# Generated at 2022-06-25 12:25:43.621863
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = None
    bytes_0 = b''
    vars_module_0_get_vars_2 = vars_module_0.get_vars(bool_0, bytes_0, bool_0)
    print(vars_module_0_get_vars_2)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:25:44.782021
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case 0. None -> None
    test_case_0()

# Generated at 2022-06-25 12:25:51.430857
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    try:
        var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    except AnsibleParserError as e:
        var_0 = e.message
        var_0 = e.__class__
    finally:
        var_0 = os.path.join(C.DEFAULT_VARS_PLUGIN_PATH, 'vars_plugins')
        var_0 = os.path.join(C.DEFAULT_VARS_PLUGIN_PATH, 'vars_plugins')


# Generated at 2022-06-25 12:25:53.824253
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)



# Generated at 2022-06-25 12:25:59.133428
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test 1:
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:26:03.851393
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:28:00.628642
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    # Use 'assert' to ensure that tests pass



# Generated at 2022-06-25 12:28:04.581975
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    pass




# Generated at 2022-06-25 12:28:09.394764
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    if var_0:
        print('test_VarsModule_get_vars passed')
    else:
        print('test_VarsModule_get_vars failed')


# Generated at 2022-06-25 12:28:11.723940
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # set up test data
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = VarsModule()
    var_0.get_vars(bool_0, bytes_0, bool_0)

# Generated at 2022-06-25 12:28:21.181297
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)


# Assigning a Call to a Name (line 41):

# Assigning a Call to a Name (line 58):

# Call to VarsModule(...): (line 58)
# Processing the call keyword arguments (line 58)
kwargs_0 = {}
# Getting the type of 'VarsModule' (line 58)
VarsModule_1 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 58, 10), 'VarsModule', False)
# Calling VarsModule(args, kwargs) (line 58)

# Generated at 2022-06-25 12:28:26.662674
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b'\xFF\x00'
    bytes_1 = b'\x01\x00'
    bytes_2 = b'\xFF\x00'
    bytes_3 = b'\x0B\x00'
    bytes_4 = b'\x03\x00'
    bytes_5 = b''
    bytes_6 = b'\x10\x00'
    bytes_7 = b'\x00\x00'
    bytes_8 = b'\x0C\x00'
    bytes_9 = b'\x00\x00'
    bytes_10 = b'\x0C\x00'
    bytes_11 = b'\x00\x00'
    bytes_12 = b'\x0C\x00'


# Generated at 2022-06-25 12:28:29.871384
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_1 = None
    bytes_1 = b''
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, bool_1, bytes_1, bool_1)
    assert var_0 == var_1

# Generated at 2022-06-25 12:28:31.259575
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO: Implement this test case
    raise Exception("Not implemented")

# Generated at 2022-06-25 12:28:34.837702
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)



# Generated at 2022-06-25 12:28:36.592819
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = None
    bytes_0 = b''
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bool_0, bytes_0, bool_0)
    print(var_0)
