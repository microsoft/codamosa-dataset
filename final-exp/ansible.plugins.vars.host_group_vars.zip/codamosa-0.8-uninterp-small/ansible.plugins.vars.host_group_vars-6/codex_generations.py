

# Generated at 2022-06-25 12:19:14.914678
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass


# Generated at 2022-06-25 12:19:15.670328
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert True

# Generated at 2022-06-25 12:19:18.661704
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars()

# Generated at 2022-06-25 12:19:23.504874
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader = VarsModule()
    path = ''
    host0 = Host(name='3.3.3.3')
    host1 = Host(name='4.4.4.4')

    entities_1 = [host0, host1]
    vars_module.get_vars(loader, path, entities_1)

# Generated at 2022-06-25 12:19:29.903378
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    host_0 = Host()
    path_0 = os.path.join('test', 'files', 'host_vars')
    entities_0 = [host_0]
    cache_0 = True
    vars_module_0.get_vars('loader', path_0, entities_0, cache_0=cache_0)

# Generated at 2022-06-25 12:19:31.176734
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars("loader","path","entities")


# Generated at 2022-06-25 12:19:37.552064
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    # This is a unit test, so we're not actually going to call
    # get_vars() as it has a lot of requirements.  This is only testing the
    # argument processing.  No need to initialize any objects, we'll
    # just mock the class methods.

    # Create a mock loader object.
    mock_loader = type('MockLoader', (object,), {})()
    mock_loader.find_vars_files = lambda *args, **kwargs: None
    mock_loader.load_from_file = lambda *args, **kwargs: None
    mock_loader.path_exists = lambda *args, **kwargs: True

    # Create a mock host object.
    #mock_host = type('mock_host', (object,), {})()


# Generated at 2022-06-25 12:19:42.414016
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_VarsModule_get_vars = VarsModule()
    test_VarsModule_get_vars._basedir = "/etc/ansible"
    try:
        test_VarsModule_get_vars.get_vars(loader=None, path=None, entities=None, cache=True)
    except Exception:
        assert False

# Generated at 2022-06-25 12:19:47.021275
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = "./test/test_host_vars_plugin.yml"
    entities_0 = [None, None]
    cache_0 = True
    assert vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0) == {u'foo': u'bar'}

# Generated at 2022-06-25 12:19:52.511564
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_1 = VarsModule()

    file_loader_0 = vars_module_0.file_loader
    entities_0 = [vars_module_0]
    vars_module_0.get_vars(file_loader_0, 'test/inventory', entities_0, True)


# Generated at 2022-06-25 12:19:57.897732
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)


# Generated at 2022-06-25 12:20:00.650134
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test with the following values for the arguements of method:
    # - loader: None
    # - path: None
    # - entities: None
    # - cache: None
    # Expected outcome:
    # - loader, path, entities and cache are all None
    pass


# Generated at 2022-06-25 12:20:02.610803
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)



# Generated at 2022-06-25 12:20:08.896923
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    pos_0 = Host("hostname")
    str_0 = "hostname"
    test_var = vars_module_0.get_vars(pos_0, str_0, pos_0)
    print(test_var)

    # vars_get_vars(self, loader, path, entities, cache=True)
    # test_case_0(self)

# Generated at 2022-06-25 12:20:11.240434
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  var_0 = 'entities'
  VarsModule.get_vars(var_0, var_0, var_0)


# Generated at 2022-06-25 12:20:12.502957
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO: implement this test
    pass

# Generated at 2022-06-25 12:20:16.128145
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # You need to set the below field manually, according to the actual situation
    vars_module = VarsModule()
    loader = None
    path = None
    entities = None

    vars_module.get_vars(loader, path, entities)


# Generated at 2022-06-25 12:20:19.550956
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)

# Generated at 2022-06-25 12:20:28.172776
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    key_0 = 'a.b'
    list_0 = [key_0]

    class Host_0():
        inventory_name = key_0
        name = None

    host_0 = Host_0()

    class VarsModule_0():
        def get_vars(self, loader, path, entities, cache=True):
            self.basedir = 'c'
            os.path.exists = lambda path: True
            os.path.isfile = lambda path: True
            os.path.isdir = lambda path: True
            os.path.join = lambda *args: 'd'
            os.path.realpath = lambda path: 'e'
            loader.find_vars_files = lambda path, name: list_0

            # Initialize data with an empty dict.
            data = {}

# Generated at 2022-06-25 12:20:29.508854
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars()


# Generated at 2022-06-25 12:20:44.960391
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    pytest.test_case_0()
    str_0 = 'entities'
    var_0 = vars_get_vars(to_text(str_0), to_text(str_0), to_text(str_0))


# Generated at 2022-06-25 12:20:47.944535
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    str_1 = 'entities'
    str_2 = 'entities'
    int_0 = vars_module_0.get_vars(str_0, str_1 , str_2)
    assert int_0 == None
    pass

# Generated at 2022-06-25 12:20:52.634217
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    entities = None
    # Assume vars_module_0.get_vars(entities) raise NoneType exception then call test_case_0()
    try:
        vars_module_0.get_vars(entities)
    except:
        test_case_0()


############################################################
# function vars_get_vars
############################################################

# Generated at 2022-06-25 12:21:03.542005
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = "entities"
    str_1 = ""
    str_2 = to_text(str_1)
    str_3 = "loader"
    str_4 = "path"
    str_5 = "cache"
    str_6 = "FOUND"
    str_7 = "found_files"
    str_8 = "key"
    str_9 = "opath"
    str_10 = "b_opath"
    str_11 = "os.path.sep"
    str_12 = to_text(str_11)
    str_13 = "os.pardir"
    str_14 = to_text(str_13)
    str_15 = "os.path"
    str_16 = "entity.name"
    str

# Generated at 2022-06-25 12:21:06.314600
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)

# Generated at 2022-06-25 12:21:07.421970
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Set up mock objects
    # Run the test
    test_case_0()

# Generated at 2022-06-25 12:21:09.606738
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'entities'
    # vars_module was created with vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(str_0, str_0, str_0)
    # var_0 is not None
    assert var_0 is not None

# Generated at 2022-06-25 12:21:18.935079
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_mock = VarsModule()
    # Test the first path ...
    test1 = "entities"
    test2 = "entities"
    test3 = "entities"
    var1 = VarsModule_mock.get_vars(test1, test2, test3)
    # Test the second path ...
    test1 = "entities"
    test2 = "entities"
    test3 = "entities"
    var1 = VarsModule_mock.get_vars(test1, test2, test3)
    # Test the third path
    test1 = "entities"
    test2 = "entities"
    test3 = "entities"
    var1 = VarsModule_mock.get_vars(test1, test2, test3)

# Unit test

# Generated at 2022-06-25 12:21:22.295401
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entities = '__main__.Host'
    loader = '__main__.DataLoader'
    path = '__main__.str'
    vars_module_get_vars = VarsModule.get_vars(entities, loader, path)

# Generated at 2022-06-25 12:21:27.124725
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # Test verifies the class successfully initialized and method get_vars is implemented.
    assert vars_module


if __name__ == "__main__":
    vars_module = VarsModule()
    print(vars_module)

# Generated at 2022-06-25 12:21:41.633722
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("\nPerforming unit test for get_vars of class VarsModule")

    test_case_0()

    print("\nUnit test success")

test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:44.842208
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars(1, 1, 1) == {}, 'Failed test_VarsModule_get_vars'

# Generated at 2022-06-25 12:21:46.332236
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)

# Generated at 2022-06-25 12:21:50.819954
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    str_0 = 'entities'
    var_1 = Group()
    var_2 = vars_module_get_vars(var_0, str_0, var_1)
    assert var_2 == 'entities'

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:58.315003
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entity1 = Host(name='localhost')
    entity2 = Group(name='foogroup')

    vars_module_1 = VarsModule()
    str_1 = 'entities'
    var_1 = vars_module_1.get_vars(str_1, str_1, [entity1, entity2])

    vars_module_2 = VarsModule()
    str_2 = 'entities'
    var_2 = vars_module_2.get_vars(str_2, str_2, entity2)



# Generated at 2022-06-25 12:22:01.813436
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'entities'
    str_1 = 'entities'
    str_2 = 'entities'
    var_0 = VarsModule()
    result = var_0.get_vars(str_0, str_1, str_2)
    assert result == None

# Generated at 2022-06-25 12:22:05.139139
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)

# Generated at 2022-06-25 12:22:06.092259
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:22:08.626698
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Unittest is not supported by ansible
    # print 'Starting VarsModule::get_vars'
    # test_case_0()

    print('done test')

# Generated at 2022-06-25 12:22:14.989543
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)
    str_1 = 'loader'
    str_2 = 'path'
    str_3 = 'entities'
    str_4 = 'cache'
    str_5 = 'True'
    vars_get_vars(str_1, str_2, str_3, str_4, str_5)
    vars_get_vars(str_4, str_4, str_4, str_4, str_4)


# Generated at 2022-06-25 12:22:30.406466
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_module_0.get_vars(str_0, str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 12:22:35.321234
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Call method get_vars of class VarsModule
    t_VarsModule_0 = VarsModule()
    t_loader_0 = {"entities": "entities"}
    t_path_0 = "entities"
    entities_0 = BaseVarsPlugin()
    t_cache_0 = {"entities": "entities"}
    test_case_0(t_VarsModule_0, t_loader_0, t_path_0, entities_0, t_cache_0)

# Generated at 2022-06-25 12:22:40.564915
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'path'
    str_1 = 'loader'
    str_2 = 'entities'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(str_0, str_1, str_2)

test_case_0()
test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:45.061800
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = 'loader'
    str_0 = 'path'
    entities_0 = 'entities'
    assert vars_module_0.get_vars(loader_0, str_0, entities_0) == ('entities', 'entities', 'entities')


# Generated at 2022-06-25 12:22:47.821079
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)


# Generated at 2022-06-25 12:22:57.026523
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # instantiate class VarsModule
    vars_module_0 = VarsModule()
    # instantiate class Host
    host_0 = Host()
    # assign a. name to host_0.name
    host_0.name = 'a. name'
    # assign vars_module_0.loader to host_0.loader
    host_0.loader.module_loader = vars_module_0.loader.module_loader
    # assign vars_module_0.path to host_0.path
    host_0.path = vars_module_0.path
    # assign vars_module_0.inventory to host_0.inventory
    host_0.inventory = vars_module_0.inventory
    # instantiate class Group
    group_0 = Group()
    # assign b. name to group_0.

# Generated at 2022-06-25 12:23:07.728926
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    str_1 = 'subdir'
    str_2 = 'entity'
    str_3 = 'entity.name'
    str_4 = 'os.path.sep'
    str_5 = 'subdir'
    str_6 = 'subdir'
    str_7 = 'found'
    str_8 = 'found'
    str_9 = 'subdir'
    str_10 = 'subdir'
    str_11 = 'subdir'
    str_12 = 'subdir'
    str_13 = 'subdir'
    str_14 = 'subdir'
    str_15 = 'subdir'
    str_16 = 'subdir'
    str_17 = 'subdir'
    str_18 = 'subdir'
    str_19

# Generated at 2022-06-25 12:23:10.655281
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)

# Generated at 2022-06-25 12:23:13.296000
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = 0
    int_1 = 0
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)


# Generated at 2022-06-25 12:23:17.072146
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # test case 0
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_module_0.get_vars(loader=loader, path=path, entities=entities)
    result_0 = str_0
    assert var_0 == result_0



# Generated at 2022-06-25 12:24:00.274162
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    group_0 = Group('group_0')
    host_0 = Host('host_0')
    dict_0 = {'a': 'b', 'c': 'd'}
    data_0 = {}
    data_0['group_0'] = {'c': 'd', 'a': 'b'}
    data_0['host_0'] = {'c': 'd', 'a': 'b'}
    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars('./path', group_0, dict_0) == data_0['group_0']
    assert vars_module_0.get_vars('./path', host_0, dict_0) == data_0['host_0']

# Generated at 2022-06-25 12:24:06.377480
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    entities = 'entities'
    loader = 'ldr_0'
    path = 'path'
    cache = 1
    # entity is an instance of Host or Group
    entity_0 = Host()
    entity_1 = Group()

    # test with entity_0
    var_0 = vars_module_0.get_vars(loader, path, entity_0, cache)
    # test with entity_1
    var_1 = vars_module_0.get_vars(loader, path, entity_1, cache)
    # test with entities as list and cache enabled
    var_2 = vars_module_0.get_vars(loader, path, [entity_0, entity_1], True)
    # test with entities as list and cache disabled
    var

# Generated at 2022-06-25 12:24:09.901808
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    str_1 = 'loader'
    str_2 = 'path'
    str_3 = 'entities'
    vars_get_vars(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 12:24:13.332179
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader = loader()
    path = path()
    entities = entities()
    cache = cache()
    assert vars_module.get_vars(loader, path, entities, cache) == 'data'
# END Unit tests for VarsModule.get_vars


# Generated at 2022-06-25 12:24:17.001897
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Save value of global variable FOUND
    FOUND_old = FOUND.copy()
    data = {}

    instance_0 = VarsModule()
    str_0 = 'loader'
    str_1 = 'path'
    str_2 = 'entities'
    # Call method get_vars of VarsModule with arguments str_0, str_1, str_2
    result = instance_0.get_vars(str_0, str_1, str_2)

    # Check if result is equal to data
    assert result == data
    # Restore global variable FOUND
    FOUND = FOUND_old


# Generated at 2022-06-25 12:24:17.760990
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:24:26.762783
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)

# unit test
if __name__ == '__main__':
    import os
    import inspect
    import pprint

    # build some test entities

    test_host = Host(name='testhost')
    test_host.set_variable('not', 'a real variable')
    test_host.set_variable('group1', 'host')
    test_host.set_variable('group2', 'host')

    test_group = Group(name='testgroup')
    test_group.set_variable('group1', 'group')
    test_group.set_variable('group2', 'group')

    test_group2 = Group

# Generated at 2022-06-25 12:24:28.784795
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(vars_module_0, str_0,str_0, str_0)

# Generated at 2022-06-25 12:24:37.993994
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    dict_0 = dict()
    dict_0['base_dir'] = 'entities'
    dict_0['entities'] = 'entities'
    dict_0['is_playbook'] = True
    dict_0['vault_password'] = 'entities'
    dict_0['_ansible_vault_password_file'] = 'entities'
    dict_0['_ansible_vault_password'] = 'entities'
    dict_0['cache'] = True
    dict_0['forks'] = 'entities'
    dict_0['no_log'] = False
    dict_0['force_handlers'] = 'entities'
    dict_0['flush_cache'] = 'entities'
   

# Generated at 2022-06-25 12:24:43.722832
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.vars.host_group_vars import VarsModule

    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_module_0.get_vars(str_0, str_0, str_0)

    # On failure, print out the error and the expected and actual data
    try:
        assert var_0 == data_0
    except AssertionError as e:
        print(e)
        print("\n%s" % var_0)
        print("Expected:\n%s" % data_0)


# Generated at 2022-06-25 12:25:42.909539
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("\nRunning test_VarsModule_get_vars ...")
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)
    print("\nExiting test_VarsModule_get_vars ...")


# Generated at 2022-06-25 12:25:46.318026
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Testing method get_vars of class VarsModule')
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_module_0.get_vars(vars_module_0, str_0, str_0)


# Generated at 2022-06-25 12:25:50.068617
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    # Test case where entities is not a list

    # Test case where entities is a list, path is not a string, entities is a list, entities is a list, entities is a list


if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:50.804477
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass


# Generated at 2022-06-25 12:25:51.522875
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert True


# Generated at 2022-06-25 12:25:55.275275
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)


# Generated at 2022-06-25 12:26:02.396354
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_loader_0 = VarsLoader(vars_data={}, vars_dirs=[])
    str_0 = 'path'
    str_1 = 'entities'
    bool_0 = True
    try:
        vars_module_0.get_vars(vars_loader_0, str_0, str_1, bool_0)
        assert False
    except Exception as e:
        pass


# Generated at 2022-06-25 12:26:04.680433
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # entity is not a valid host or group.
    assert raise_exception(VarsModule, 'entities', 'entities', 'entities')


# Generated at 2022-06-25 12:26:10.656962
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    stage_arg = 'entities'
    loader_arg = 'entities'
    path_arg = 'entities'
    entities_arg = 'entities'
    cache_arg = 'entities'
    stage = 'entities'
    vars_module = VarsModule()
    data = vars_module.get_vars(stage_arg, loader_arg, path_arg, entities_arg, cache_arg)
    test_assert_equal(data, stage)


# Generated at 2022-06-25 12:26:15.297004
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Testing Code
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_module_0.get_vars(str_0, str_0, str_0)
    # Unit Test Assertions
    assert var_0 == ''
    assert False
    assert True
    assert True
    assert var_0 == ''
    assert var_0 == ''
    assert False


# Generated at 2022-06-25 12:28:11.921826
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entities =  ['a', 'b']
    loader = 'loader'
    path = os.path.realpath(to_bytes(os.path.join(C._BASEDIR_, 'host_vars')))
    key = 'host_vars.path'
    FOUND[key] = ['host_vars_1', 'host_vars_2']
    vars_get_vars(entities, loader, path)

# Generated at 2022-06-25 12:28:21.425758
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-25 12:28:23.374955
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    s0 = 'entities'

    v1 = vars_module_0.get_vars(s0, s0, s0)

    assert (v1 == None)


# Generated at 2022-06-25 12:28:27.400395
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    global FOUND
    entities_0 = []
    loader_0 = ''
    path_0 = ''
    cache_0 = True
    try:
        vars_module_0 = VarsModule()
        vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    except:
        pass


# Generated at 2022-06-25 12:28:36.521584
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_1 = os.path.sep
    var_2 = None
    var_3 = None
    var_4 = False
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    vars_module_1 = VarsModule()
    str_1 = 'entities'
    str_2 = 'path'
    str_3 = 'entities'
    str_4 = 'cache'
    str_5 = 'True'
    str_6 = 'entities'
    str_7 = 'Host'
    str_

# Generated at 2022-06-25 12:28:41.367077
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('==== test_VarsModule get_vars ====')
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_module_0.get_vars(str_0, str_0, str_0)
    print('==== test_VarsModule get_vars DONE ====')
    print(var_0)


# Generated at 2022-06-25 12:28:46.685213
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.vars import combine_vars
    TEST_VALUES_0 = {}
    TEST_VALUES_0[0] = 'entities'
    TEST_VALUES_0[1] = 'entities'
    TEST_VALUES_0[2] = 'entities'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(TEST_VALUES_0[0], TEST_VALUES_0[1], TEST_VALUES_0[2])
    assert var_0 != None


# Generated at 2022-06-25 12:28:49.890745
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    try:
        vars_module.get_vars(loader, path, entities)
    except Exception as e:
        assert str(e) == 'Supplied entity must be Host or Group, got <type \'str\'> instead'


# Generated at 2022-06-25 12:28:51.525969
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'entities'
    var_0 = vars_get_vars(str_0, str_0, str_0)



# Generated at 2022-06-25 12:28:55.913938
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_plugin_0 = VarsModule()
    str_0 = 'entities'
    str_1 = 'entities'
    str_2 = 'entities'
    var_0 = vars_plugin_0.get_vars(str_0, str_1, str_2)