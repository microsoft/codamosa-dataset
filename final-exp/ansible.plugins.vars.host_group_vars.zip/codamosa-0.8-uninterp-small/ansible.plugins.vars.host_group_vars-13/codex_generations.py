

# Generated at 2022-06-25 12:19:19.113334
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test for case 0
    vars_module_0 = VarsModule()
    entities_0 = []
    path_0 = None
    loader_0 = None
    cache_0 = True
    result_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)

# Generated at 2022-06-25 12:19:22.252742
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        vars_module = VarsModule()
        vars_module.get_vars(loader, path, entities, cache=True)
    except Exception:
        pass


# Generated at 2022-06-25 12:19:33.733849
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    global FOUND
    FOUND = {}
    opath = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_VarsModule_get_vars')
    if not os.path.exists(opath):
        os.makedirs(opath)
    with open(os.path.join(opath, 'test_case_0.yml'), 'w') as f:
        f.write('foo: foo')

    vars_module_0 = VarsModule()
    args = {'loader': None, 'path': opath, 'entities': [Host(name='test_case_0')], 'cache': True}
    result = vars_module_0.get_vars(**args)

    assert result == {'foo': 'foo'}

# Generated at 2022-06-25 12:19:37.761915
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_vars_module = VarsModule()
    assert(test_vars_module != None)

    test_host = Host('localhost')
    assert(test_host != None)

    test_vars_module.get_vars(None, None, test_host)

# Generated at 2022-06-25 12:19:44.244871
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = GlobalsModule()
    entities_0 = ["foo", "bar"]
    path_0 = "host_vars"
    cache_0 = True
    result_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert result_0 == {}, 'Expected {}, but got {}'.format(result_0, {})


# Generated at 2022-06-25 12:19:46.376203
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()


# Generated at 2022-06-25 12:19:56.746499
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test with no list of entities
    try:
        vars_module = VarsModule()
        vars_module.get_vars(['host', 'group'])
    except AnsibleParserError as e:
        assert(e.args[0] == 'Supplied entity must be Host or Group, got <class \'str\'> instead')
    
    # Test with no list of entities
    vars_module = VarsModule()
    vars_module.get_vars([])

    # Test with group
    group = Group('group')
    vars_module = VarsModule()
    vars_module.get_vars([group])

    # Test with host
    host = Host('host')
    vars_module = VarsModule()
    vars_module.get_vars([host])

# Generated at 2022-06-25 12:19:57.270928
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:20:03.155709
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create instance of VarsModule() class
    vars_module_0 = VarsModule()
    # Create instance of AnsibleLoader() class
    ansible_loader_0 = AnsibleLoader()
    # Create instance of Group() class
    group_0 = Group()
    # Create instance of Host() class
    host_0 = Host()
    # Create instance of BaseDisplay() class
    ansible_base_display_0 = BaseDisplay()
    # Assign a value to variable # Add to inventory: localhost becomes the child of ungrouped
    group_0.name = 'localhost'
    # Assign default value to variable
    FOUND = {}
    # Assign default value to variable
    entities = []
    # Add to list
    entities.append(host_0)
    # Call function get_vars of class VarsModule and

# Generated at 2022-06-25 12:20:05.971847
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    with patch('ansible_collections.misc.not_a_real_collection.plugins.modules.vars.group_vars.Group') as MockGroup:
        MockGroup.name = "localhost"
        grouphost = MockGroup()
        vars_module = VarsModule()
        # Invalid entities
        assert vars_module.get_vars(grouphost, "/path", "test_entities") == None

# Generated at 2022-06-25 12:20:20.545084
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Format the password and salt for saving\n    :arg password: the plaintext password to save\n    :arg salt: the salt to use when encrypting a password\n    :arg encrypt: Which method the user requests that this password is encrypted.\n        Note that the password is saved in clear.  Encrypt just tells us if we\n        must save the salt value for idempotence.  Defaults to None.\n    :arg ident: Which version of BCrypt algorithm to be used.\n        Valid only if value of encrypt is bcrypt.\n        Defaults to None.\n    :returns: a text string containing the formatted information\n\n    .. warning:: Passwords are saved in clear.  This is because the playbooks\n        expect to get cleartext passwords from this lookup.\n    '

# Generated at 2022-06-25 12:20:28.916329
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:20:40.380439
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:20:49.637529
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = random.randint(0,1000)
    int_1 = random.randint(0,1000)
    int_2 = random.randint(0,1000)
    int_3 = random.randint(0,1000)
    int_4 = random.randint(0,1000)
    int_5 = random.randint(0,1000)
    int_6 = random.randint(0,1000)
    int_7 = random.randint(0,1000)
    int_8 = random.randint(0,1000)
    int_9 = random.randint(0,1000)
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = 'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-25 12:20:54.818850
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()

# Generated at 2022-06-25 12:21:05.882037
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:21:09.515467
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  vars_0 = VarsModule()

# Generated at 2022-06-25 12:21:14.358938
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'test'
    str_1 = 'test'
    bool_0 = None
    var_0 = vars_module_0.get_vars(str_0, str_1, bool_0)
    assert var_0 == None

# Generated at 2022-06-25 12:21:21.259068
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'Variable managment plugin in charge of loading group_vars and host_vars.\n    '
    bool_0 = None
    var_0 = vars_get_vars(str_0, str_0, bool_0)
    bool_1 = bool_0
    var_1 = vars_get_vars(str_0, str_0, bool_1)
    str_1 = '\n    Variable managment plugin in charge of loading group_vars and host_vars.\n    '
    # Check that the class VarsModule raises an error when the input value for parameter entities is of the invalid type 'str'.

# Generated at 2022-06-25 12:21:27.134698
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'hahahahahahahaha'
    str_1 = 'hahahahahahahaha'
    bool_0 = None
    var_0 = vars_get_vars(str_0, str_1, bool_0)
    assert var_0 == False, 'Assertion failed.'

# Generated at 2022-06-25 12:21:41.621433
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:21:48.246809
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost'])
    vars_manager = VariableManager(loader=loader, inventory=inv)
    VarsModule.get_vars(VarsModule(), loader, path='', entities=[], cache=True)



# Generated at 2022-06-25 12:21:55.224797
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:22:00.298596
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = {}
    dict_1 = {}
    dict_1['method'] = 'dict'
    dict_0['type'] = dict_1
    var_0 = vars_module_0.get_vars(dict_0, dict_0, dict_0)

# Generated at 2022-06-25 12:22:10.189953
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    # Copy from the test case

# Generated at 2022-06-25 12:22:18.979953
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    str_1 = "vars_module.py"
    str_2 = "data"
    bool_1 = None
    var_1 = vars_module_1.get_vars(str_1, str_2, bool_1)
    bool_2 = bool_1
    return var_1 is None and bool_2 is None


if __name__ == '__main__':
    result = test_VarsModule_get_vars()
    print(result)
    test_case_0()

# Generated at 2022-06-25 12:22:22.189293
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        VarsModule.get_vars()
    except NameError as err:
        assert True
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 12:22:30.893102
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = '1=1'
    str_1 = 'GROUPING'
    str_2 = '1=2'
    str_3 = '2=2'
    str_4 = '3=3'
    str_5 = '3=3'
    str_6 = '3=3'
    str_7 = '3=3'
    str_8 = '3=3'
    str_9 = '3=3'
    str_10 = '3=3'
    str_11 = '3=3'
    str_12 = '3=3'
    str_13 = '3=3'
    str_14 = '3=3'
    str_15 = '3=3'
    str_16 = '3=3'
    str_17 = '3=3'
    str

# Generated at 2022-06-25 12:22:37.333162
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = 1
    int_1 = 1
    str_0 = 'PASSWORD_HASH'
    str_1 = 'C(password_hash)'
    str_2 = 'Complex password hash format'
    str_3 = 'Complex password hash format which can be used to create a crypt hash while passing parameters to it'
    str_4 = 'none'
    int_2 = 4
    str_5 = 'complex'
    int_3 = 1
    str_6 = 'complex'
    int_4 = None
    str_7 = 'devices'
    str_8 = 'True'
    int_5 = 0
    str_9 = 'absent'
    int_6 = None
    str_10 = 'error'
    int_7 = None

# Generated at 2022-06-25 12:22:46.866675
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader_0 = VarsLoader()

# Generated at 2022-06-25 12:23:03.651363
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create an object of the class VarsModule
    vars_module_0 = VarsModule()

    # Test the method get_vars of class VarsModule
    test_case_0()

# Generated at 2022-06-25 12:23:11.107456
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = dict()
    dict_0.update({"path": "/Users/satishm/github/ansible2.4/lib/ansible/plugins/dynamic_inventory/vagrant.py", "entities": "hashlib"})
    path = dict_0["path"]
    entities = dict_0["entities"]
    cache = None
    var_0 = vars_module_0.get_vars(str_0, path, entities, cache)
    return var_0


# Generated at 2022-06-25 12:23:18.144173
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:23:26.999983
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:23:34.011380
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = Loader()

# Generated at 2022-06-25 12:23:43.836467
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:23:54.651430
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:24:05.627292
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    str_0 = 'Format the password and salt for saving\n    :arg password: the plaintext password to save\n    :arg salt: the salt to use when encrypting a password\n    :arg encrypt: Which method the user requests that this password is encrypted.\n        Note that the password is saved in clear.  Encrypt just tells us if we\n        must save the salt value for idempotence.  Defaults to None.\n    :arg ident: Which version of BCrypt algorithm to be used.\n        Valid only if value of encrypt is bcrypt.\n        Defaults to None.\n    :returns: a text string containing the formatted information\n\n    .. warning:: Passwords are saved in clear.  This is because the playbooks\n        expect to get cleartext passwords from this lookup.\n    '
    str_1 = None

# Generated at 2022-06-25 12:24:14.004924
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()

# Generated at 2022-06-25 12:24:18.453065
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
	vars_module_0 = VarsModule()
	str_0 = 'vars/'
	str_1 = 'vars/'
	bool_0 = False
	var_0 = vars_module_0.get_vars(str_0, str_1, bool_0)

# Generated at 2022-06-25 12:25:15.440115
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_test_case_0 = VarsModule()
    b_test_0 = os.path.realpath(to_bytes(os.path.join(self._basedir, subdir)))

# Generated at 2022-06-25 12:25:20.254435
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()

    # Test: get_vars is not implemented in VarsModule
    try:
        vars_module_1.get_vars(str_0, str_0, bool_0)
    except NotImplementedError:
        pass
    else:
        raise AssertionError("Failed to raise NotImplementedError for unimplemented function get_vars")

# Generated at 2022-06-25 12:25:28.776498
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:25:30.846705
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    is_true = vars_module_0.get_vars('inventory_config_1', str_0, str_1)
    assert is_true

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:25:41.757015
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:25:49.817810
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_0 = VarsModule()
    str_0 = 'Include a file with variables\nThis is essentially a bulk version of the var lookup.\nYou can put a list of files (or globs) in there, they will get loaded and merged together.\nThis could lead to unexpected results if files share variable names with different values.\nFiles are loaded in the order given and later files will overwrite variables from previous ones.\n\n:param files: list of paths or globs of paths\n:param name: unused\n:param depth: depth to nest the resulting dictionary\n:param dig: if C(name) is not specified, prepend a "dig" to the key at the specified depth\n'

# Generated at 2022-06-25 12:25:55.898910
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    data = {
        '_target_host': None,
        'ansible_inventory_hostname': 'testhost.example.com',
        'ansible_hostname': 'testhost',
        'ansible_path_plugins': './my_plugins',
        'ansible_path_plugins_extended': './my_plugins/plugins:./my_plugins/extended_plugins'
    }

# Generated at 2022-06-25 12:26:06.131797
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins

    test_case_0()

    # From Ansible 2.5
    module = AnsibleModule({}, '', False)
    vars_module = VarsModule()
    vars_module.get_vars(AnsibleModule, '', '')

    # From Ansible 2.7
    module = AnsibleModule({}, '', False)
    vars_module = VarsModule()
    vars_module.get_vars(AnsibleModule, '', '')
    vars_module.get_vars(module, '', '')

    # From Ansible 2.8
    module = AnsibleModule({}, '', False)
    vars_module = VarsModule()


# Generated at 2022-06-25 12:26:11.106150
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  host_0 = Host(name='host_0', port=22, variables={})
  path_0 = 'path/to/some/file'
  #vars_module_0 = VarsModule()
  data = {}
  data = VarsModule.get_vars(VarsModule(), path_0, host_0, cache=True)
  assert data == {}

# Generated at 2022-06-25 12:26:13.888301
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  vars_module_0 = VarsModule()
  str_0 = ''
  str_1 = ''
  bool_0 = None
  var_0 = vars_get_vars(str_0, str_1, bool_0)

# Generated at 2022-06-25 12:27:19.949182
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()


# Generated at 2022-06-25 12:27:29.174721
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:27:35.210991
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:27:39.692281
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    str_0 = 'n/a'
    str_1 = 'n/a'
    bool_0 = None
    var_0 = vars_module_0.get_vars(str_0, str_1, bool_0)


# Generated at 2022-06-25 12:27:48.045852
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:27:57.229872
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Get a variable of an object
    obj_0 = VarsModule()
    var_0 = obj_0

# Generated at 2022-06-25 12:28:02.551336
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:28:11.186777
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

# Generated at 2022-06-25 12:28:14.855186
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    var_0 = str()
    var_1 = str()
    var_2 = bool()

    vars_get_vars(vars_module_0, var_0, var_1, var_2)



# Generated at 2022-06-25 12:28:18.984872
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = 'dev'
    str_1 = 'dev'
    bool_0 = None
    var_0 = vars_get_vars(str_0, str_1, bool_0)


if __name__ == '__main__':
    pass
# End of Test Cases.