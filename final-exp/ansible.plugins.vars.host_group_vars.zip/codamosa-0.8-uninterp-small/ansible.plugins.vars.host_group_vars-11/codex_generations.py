

# Generated at 2022-06-25 12:19:24.191268
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    # Generated from package ansible
    # Original definition of method get_vars for class VarsModule
    # in file lib/ansible/plugins/vars/host_group_vars.py
    loader_0 = MockAnsibleLoader()
    path_0 = 0
    entities_0 = [0]
    cache_0 = 0
    vars_module_0.get_vars(loader = loader_0, path = path_0, entities = entities_0, cache = cache_0)


# Generated at 2022-06-25 12:19:24.977932
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

test_case_0()

# Generated at 2022-06-25 12:19:29.201574
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import VarsModule
    from ansible.utils.display import Display
    vars_module_0 = VarsModule()



# Generated at 2022-06-25 12:19:31.832172
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    path = '/root/ansible/lib/ansible/plugins/vars'
    entities = []
    loader = object()
    cache = True
    expected = {}
    actual = vars_module.get_vars(loader, path, entities, cache)
    assert actual == expected



# Generated at 2022-06-25 12:19:36.397508
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    vars_module = VarsModule()

    results = vars_module.get_vars(loader=loader, path=C.DEFAULT_HOST_VARS_PATH, entities=inventory.get_groups_dict()['all'].get_hosts())

    assert results == {}

# Generated at 2022-06-25 12:19:42.591700
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = BaseVarsPlugin()
    path_0 = "inventory.txt"
    entities_0 = [Host()]
    cache_0 = True
    get_vars_0 = vars_module_0.get_vars(loader_0,path_0,entities_0,cache_0)
    assert get_vars_0 == None

test_case_0()

# Generated at 2022-06-25 12:19:45.728167
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars()


if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:19:56.152651
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    try:
        vars_module_0.get_vars(None, None, None)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    try:
        vars_module_0.get_vars(None, None, None,True)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    try:
        vars_module_0.get_vars(None, None, [None])
    except Exception as e:
        assert isinstance(e, AnsibleParserError)

    try:
        vars_module_0.get_vars(None, None, [Host(name='localhost2')])
    except Exception as e:
        assert isinstance(e, AnsibleParserError)



# Generated at 2022-06-25 12:20:00.211969
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = BaseVarsPlugin()
    path = 'test'
    entities = [Host()]
    cache = True
    vars_module_0.get_vars(loader_0, path, entities, cache)

#Unit test for method get_vars of class VarsModule for one of the two possible scenarios when this method is called

# Generated at 2022-06-25 12:20:05.809542
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    basedir = os.path.join(C.DEFAULT_LOCAL_TMP, 'test_case_0')
    os.makedirs(basedir)
    # Test for the case where path is a relative path.
    path = os.path.join(basedir, 'relative_path')
    os.makedirs(path)
    # Test for the case where k is not in entities.
    entities = 'test'
    # Test for the case where entities is not a list.
    entities = [entities]
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(loader, path, basedir, entities)
    # Test for the case where entity is not an instance of Host or Group.
    entity = os.path.join(entities, 'test_entity')
    v

# Generated at 2022-06-25 12:20:18.384721
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    dict_1 = vars_module_0.get_vars(dict_0, dict_0, set_0)


if __name__ == "__main__":
    import sys
    import os
    import nose2
    nose2.main()

# Generated at 2022-06-25 12:20:27.507316
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = BaseVarsPlugin()
    path = BaseVarsPlugin()
    entities = BaseVarsPlugin()
    cache = True
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    var_0 = vars_get_vars(dict_0, dict_0, set_0)

    vars_module_0.get_vars(loader, path, entities, cache)
    return var_0

# Generated at 2022-06-25 12:20:38.593348
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print()
    print("# Unit test for method get_vars of class VarsModule")

    # Test #0
    print("## Test #0")
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    var_0 = vars_get_vars(dict_0, dict_0, set_0)

# Generated at 2022-06-25 12:20:40.413258
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars() == None


# Generated at 2022-06-25 12:20:47.525518
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    var_0 = vars_get_vars(dict_0, dict_0, set_0)


# Generated at 2022-06-25 12:20:53.327168
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    vars_get_vars(dict_0, dict_0, set_0)


# Generated at 2022-06-25 12:21:01.560948
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    var_0 = vars_get_vars(dict_0, dict_0, set_0)

# Generated at 2022-06-25 12:21:08.089587
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = {vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0, vars_module_0: vars_module_0}
    set_0 = {vars_module_0, vars_module_0, vars_module_0, vars_module_0}
    var_0 = vars_get_vars(dict_0, dict_0, set_0)


# Generated at 2022-06-25 12:21:12.636433
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    test_case_0()


if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:18.654871
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    # Extract original args
    args_0 = ("loader", "path", "entities")
    vars_get_vars(*args_0)

    # Check type of method result for VarsModule class
    assert isinstance(vars_get_vars(*args_0), object)

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:30.068680
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host()
    host.name = 'chroot'
    groups = Group()
    groups.name = 'chroot'
    entities = [host, groups]
    path = 'path'
    variables = {'host':host, 'groups':groups, 'entities':entities, 'path':path}
    test_case_0(**variables)


# Generated at 2022-06-25 12:21:38.496451
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Group
    class MockGroup:
        def _init__(self):
            self.name = 'MockGroup'
    mock_group = MockGroup()
    # Host
    class MockHost:
        def _init__(self):
            self.name = 'MockHost'
    mock_host = MockHost()

    # VarsModule
    class MockVarsModule:
        def get_vars(entities):
            if not isinstance(entities, list):
                entities = [entities]
            data = {}
            for entity in entities:
                if isinstance(entity, Host):
                    subdir = 'host_vars'
                elif isinstance(entity, Group):
                    subdir = 'group_vars'

# Generated at 2022-06-25 12:21:47.694452
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    test_data = []
    for test_data_entry in test_data:
        vars_module_0 = VarsModule()
        if test_data_entry[0] == 'loader':
            loader = test_data_entry[1]
        elif test_data_entry[0] == 'path':
            path = test_data_entry[1]
        elif test_data_entry[0] == 'entities':
            entities = test_data_entry[1]
        elif test_data_entry[0] == 'cache':
            cache = test_data_entry[1]
        var_0 = vars_get_vars(vars_module_0, loader, path, entities, cache)

# Generated at 2022-06-25 12:21:54.948265
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path = '/etc/ansible/hosts'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, (vars, vars))
    var_0 = vars_get_vars(vars_module_0, vars_module_0, path)
    var_0 = vars_get_vars(vars_module_0, vars_module_0, (vars, vars, vars, vars))
    var_0 = vars_get_vars(vars_module_0, vars_module_0, path, True)

# Generated at 2022-06-25 12:21:58.015507
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(loader, opath, entity)


# Generated at 2022-06-25 12:22:05.831781
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create an instance of VarsModule
    vars_module_0 = VarsModule()

    # Create an instance of BaseVarsPlugin
    base_vars_plugin_0 = BaseVarsPlugin()

    str_0 = vars_module_0.get_vars(vars_module_0, str_0, str_0)
    str_1 = vars_module_0.get_vars(str_1, str_1, str_1)
    str_2 = base_vars_plugin_0.get_vars(str_2, str_2, str_2)

# Generated at 2022-06-25 12:22:12.051689
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # noinspection PyDictCreation
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert var_0 == {}
    #noinspection PyUnresolvedReferences
    assert isinstance(vars_module_0, VarsModule)
    #noinspection PyUnresolvedReferences
    assert isinstance(vars_module_0, BaseVarsPlugin)


# Generated at 2022-06-25 12:22:21.779746
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Get method from class 'VarsModule'
    cls = getattr(VarsModule, 'get_vars')
    assert callable(cls)
    # 1st param should be of type 'VarsModule'
    assert isinstance(cls, MethodType)

    # Create object 'VarsModule'
    obj = VarsModule()

    # Call method 'get_vars' with required param values
    result = obj.get_vars(vars_module_0, vars_module_0, vars_module_0)

    if result is False:
        test_case_0()
    else:
        # No error and result is true, so test passed
        test_case_1()


# Generated at 2022-06-25 12:22:22.731919
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass


# Generated at 2022-06-25 12:22:25.118779
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0)
    assert var_0


# Generated at 2022-06-25 12:22:33.089073
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  VarsModule_0_obj = VarsModule()
  VarsModule_0_obj.get_vars(loader, path, entities)

# Generated at 2022-06-25 12:22:34.288955
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert True == True



# Generated at 2022-06-25 12:22:44.627285
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars(get_loader_mock(), "/some/path", [Host(name='foo')]) == {'foo': {'ansible_host': 'foo_host', 'ansible_port': 42}}
    assert vars_module.get_vars(get_loader_mock(), "/some/path", Group(name='grp')) == {'grp': {'ansible_host': 'grp_host', 'ansible_port': 42}}
    #assert vars_module.get_vars(get_loader_mock(), "/some/path", Group(name='grp')) == {'grp': {'ansible_host': 'grp_host', 'ansible_port': 42}}
    #assert vars_module.get

# Generated at 2022-06-25 12:22:50.558865
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Get a VarsModule object
    vars_module = VarsModule()

    # Get the argparse.Namespace object
    opt = argparse.Namespace()

    # Create a list for storing the entities
    entities = []

    # Initialize an empty directory
    dummy_dir = ""

    # Call get_vars
    get_vars(vars_module, opt, entities, dummy_dir)

# Generated at 2022-06-25 12:22:53.043382
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert var_0

# Generated at 2022-06-25 12:22:57.586807
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None # TODO: initialise it correctly
    path_0 = None # TODO: initialise it correctly
    entities_0 = None # TODO: initialise it correctly
    cache_0 = bool()
    var_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)


# docstring

# Generated at 2022-06-25 12:23:07.845524
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    stage_value = 'after_sources'
    option_value = {'stage': stage_value}
    loader_value = ['loader']
    path_value = ['path']
    entities_value = ['entities']
    cache_value = True

    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(loader_value, path_value, entities_value, cache=cache_value)
    print('Expect var_0 to be None: ' + repr(var_0))
    print('Expect var_0 to be None: ' + repr(var_0))
    print('Expect var_0 to be None: ' + repr(var_0))


# Generated at 2022-06-25 12:23:12.216637
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    os.environ["ANSIBLE_YAML_FILENAME_EXT"] = "Host"
    vars_module_0 = VarsModule()
    entities = Group
    loader = VarsModule
    path = VarsModule
    var_0 = vars_module_0.get_vars(loader, path, entities)
    assert(var_0 == None)

# Generated at 2022-06-25 12:23:14.263270
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0)



# Generated at 2022-06-25 12:23:16.685449
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    var = vars_module.get_vars(vars_loader=vars_module, path=vars_module, entities=vars_module)


# Generated at 2022-06-25 12:23:34.312623
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case with an existing path
    assert VarsModule.get_vars(path_not_found, loader, path, entities) == {}
    assert VarsModule.get_vars(path_found, loader, path, entities) != {}

# Generated at 2022-06-25 12:23:37.893156
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars(vars_module, vars_module, vars_module)


# Generated at 2022-06-25 12:23:39.009581
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:23:41.475105
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-25 12:23:51.541766
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test with correct parameters
    entity_0 = Host(name='item_0')
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(vars_module_0, '/tmp', entity_0)
    entity_1 = Group(name='item_1')
    vars_module_1 = VarsModule()
    vars_module_1.get_vars(vars_module_1, '', entity_1)
    # Test with wrong parameters
    entity_2 = Host(name='item_2')
    vars_module_2 = VarsModule()

# Generated at 2022-06-25 12:23:59.012617
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # first argument must be of type
    try:
        test_case_0()
    except AssertionError as e:
        assert True
    # last argument must be of type
    try:
        test_case_0()
    except AssertionError as e:
        assert True
    # last argument must be of type
    try:
        test_case_0()
    except AssertionError as e:
        assert True
    # last argument must be of type
    try:
        test_case_0()
    except AssertionError as e:
        assert True
    # last argument must be of type
    try:
        test_case_0()
    except AssertionError as e:
        assert True
    # last argument must be of type

# Generated at 2022-06-25 12:24:06.493592
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    var_1 = vars_get_vars(vars_module_0, vars_module_0)
    var_2 = vars_get_vars(vars_module_0, vars_module_0)

# Generated at 2022-06-25 12:24:14.764985
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    var_1 = vars_get_v

# Generated at 2022-06-25 12:24:22.965473
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1._basedir = os.path.join('path', 'to', 'basedir')
    vars_module_1._display = Display()
    vars_module_1._options = {'vault_password': 'secret', '_ansible_vault_password_file': 'path/to/file'}
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)
    assert type(var_1) is ansible_vars


# Generated at 2022-06-25 12:24:30.345037
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_loader_0 = vars_module_0
    # Pass a non-string value to the path parameter
    var_0 = vars_get_vars(vars_module_0, vars_loader_0, vars_module_0)
    # Pass a non-string value to the path parameter
    var_1 = vars_get_vars(vars_module_0, vars_loader_0, vars_module_0)
    # Pass a non-string value to the path parameter
    var_2 = vars_get_vars(vars_module_0, vars_loader_0, vars_module_0)
    # Pass a non-string value to the path parameter

# Generated at 2022-06-25 12:25:00.775022
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# vim: expandtab filetype=python

# Generated at 2022-06-25 12:25:03.224191
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:25:10.427846
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Load data
    data = yaml.load(_get_data_from_file("./data/VarsModule_1.yml"))

    # Create instance of class VarsModule with unsafe parameters
    varsModule_instance = VarsModule(**data["args"]["get_vars"]["unsafe_args"])

    # Get the test function reference
    func_ref = varsModule_instance.get_vars

    # Get the function parameters arguments
    args = data["args"]["get_vars"]["args"]

    # Execute the test function
    result = func_ref(**args)

    # Verify the result
    assert(result == data["result"])

# Generated at 2022-06-25 12:25:16.005358
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # test_VarsModule_get_vars_0
    vars_module_0 = VarsModule()
    assert(vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0) == {})
    assert(vars_module_0.get_vars(vars_module_0, vars_module_0, to_text(vars_module_0)) == {})
    assert(vars_module_0.get_vars(vars_module_0, vars_module_0, to_text(vars_module_0)) == {})

# Generated at 2022-06-25 12:25:20.554904
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()

    # Case 0 - if groups
    var = vars_module.get_vars(vars_module, vars_module, [Group])
    assert var is None

    # Case 1 - if Host
    var = vars_module.get_vars(vars_module, vars_module, [Host])
    assert var is None

# Generated at 2022-06-25 12:25:22.294008
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var = VarsModule(None)
    var.get_vars(None, None, None)

# Generated at 2022-06-25 12:25:24.948745
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

# Generated at 2022-06-25 12:25:30.118923
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars(vars_module, vars_module, vars_module)
    vars_module.get_vars(vars_module, 'test_function_1', vars_module)
    vars_module.get_vars(vars_module, vars_module, 'test_function_2')
    vars_module.get_vars(vars_module, 'test_function_3', 'test_function_4')

# Generated at 2022-06-25 12:25:41.361949
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    # 'host_vars' test
    # Testing with a valid entity type
    host_0 = Host()
    var_0 = vars_module_0.get_vars(vars_module_0, vars_module_0, host_0)

    # 'group_vars' test
    # Testing with a valid entity type
    group_0 = Group()
    var_1 = vars_module_0.get_vars(vars_module_0, vars_module_0, group_0)
    # Testing with an invalid entity type

# Generated at 2022-06-25 12:25:43.028592
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # No test written in the unit test file as the method is defined in the BaseVarsPlugin class
    pass

# Generated at 2022-06-25 12:26:44.535400
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(self, loader, path, entities, cache=True)

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:26:48.329914
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    print(var_0)
    print('Test for method get_vars of class VarsModule is completed')

# Generated at 2022-06-25 12:26:56.128624
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # First test case
    vars_module_0 = VarsModule()
    vars_loader_0 = mock_ansible_loader(vars_module_0)
    vars_path_0 = '/home/vagrant/school/ansible-playbooks/ansible/inventory/'
    vars_entities_0 = [ Host() ]
    var_0 = vars_module_0.get_vars(vars_loader_0, vars_path_0, vars_entities_0)
    assert var_0 == {'host_vars': {'local': 'localhost', 'ansible_python_interpreter': ''}}



# Generated at 2022-06-25 12:26:58.820267
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var = VarsModule()
    path = os.getcwd()
    entities = ['host_vars']
    cache = False
    assert var.get_vars(var, path, entities, cache) == 'host_vars'

# Generated at 2022-06-25 12:27:08.297692
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    for key in C.YAML_FILENAME_EXT:
        assert (key == '.yaml')
        assert (key == '.json')
        assert (key == '.yml')

    assert (vars_module_0.get_vars(vars_module_0, path) == var_0.get_vars(var_0, path, entities))
    assert (vars_module_0.get_vars(vars_module_0, path) == var_0.get_vars(var_0, path, entities, cache))
    assert (vars_module_0.get_vars(vars_module_0, path) == FOUND)
    assert (var_0.get_vars(var_0, path, entities) == FOUND)

# Generated at 2022-06-25 12:27:09.633273
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # Check method returns not None
    assert vars_module.get_vars(vars_module, vars_module, vars_module) is not None


# Generated at 2022-06-25 12:27:19.118653
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    os_sep_parent = os.path.split(os.path.dirname(os.path.realpath(__file__)))
    ansible_test_path = os.path.join(os_sep_parent[0], 'test', 'units', 'module_utils', 'ansible_test_setup')
    if os.getenv(to_bytes('ANSIBLE_LIBRARY')) is None:
        os.environ[to_bytes('ANSIBLE_LIBRARY')] = to_bytes(ansible_test_path)

    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()

    os_sep_

# Generated at 2022-06-25 12:27:20.846164
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars()


# Generated at 2022-06-25 12:27:29.742581
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import unittest

    # Unit test for get_vars with following parameters
    # vars_module_0 = VarsModule()
    # var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

    class TestVarsModule_get_vars(unittest.TestCase):

        def test_get_vars(self):
            print("\nIn test_get_vars")
            vars_module_0 = VarsModule()
            var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

    return unittest.TestLoader().loadTestsFromTestCase(TestVarsModule_get_vars)

# Generated at 2022-06-25 12:27:31.826204
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)