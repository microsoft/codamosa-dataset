

# Generated at 2022-06-25 12:19:13.999799
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars('loader','path','entities', True)


# Generated at 2022-06-25 12:19:19.966160
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = "ASIp"
    host_0 = Host()
    entities_0 = [host_0]
    cache_0 = True
    vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)

# Generated at 2022-06-25 12:19:24.071405
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    entities = [Group("test")]
    assert 'host_vars' in vars_module.get_vars(entities=entities)
    assert 'group_vars' in vars_module.get_vars(entities=entities)



# Generated at 2022-06-25 12:19:30.049571
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()

    entities_0 = []

    result = vars_module_0.get_vars(loader=None, path="host_vars/", entities=entities_0)
    if result is not None:
        print(result)
        print(type(result))


# Generated at 2022-06-25 12:19:32.271914
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_get_vars = VarsModule()
    assert len(vars_module_get_vars.get_vars(loader, path, entities, cache=True)) == 0

# Generated at 2022-06-25 12:19:43.311606
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_host = Host('test_host_get_vars')
    test_group = Group('test_group_get_vars')
    test_vars_module = VarsModule()
    vars_module_0 = VarsModule()
    is_error = False
    filename = os.path.join(C.TEST_DIR, 'test_vars_plugin.yaml')
    test_vars = test_vars_module.get_vars(vars_module_0._loader, filename, test_host)
    assert test_vars['var_host'] == 'host_vars'
    assert test_vars['var_group'] == 'group_vars'

# Generated at 2022-06-25 12:19:43.898623
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:19:46.073565
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    data = vars_module.get_vars('loader', 'path', ['entities'])
    assert data == {}


# Generated at 2022-06-25 12:19:46.650455
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:19:55.666210
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("Testing method host_group_vars.VarsModule.get_vars()")
    vars_module_0 = VarsModule()
    loader_obj_0 = AnsibleLoader()
    path_0 = "/home/ansible/test_folder"
    entities_0 = ["host_0", "host_1"]
    cache_0 = True
    # Calls the method
    result_0 = vars_module_0.get_vars(loader_obj_0, path_0, entities_0, cache_0)
    # Evaluates the result
    # print(result_0)
    print("Test case 0 passed!")


# Generated at 2022-06-25 12:20:07.258674
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Setup
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()

    # Execution
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)

    # Verification
    assert var_0 == None

    # Cleanup
    clean_up(vars_module_0)
    clean_up(var_0)


# Generated at 2022-06-25 12:20:08.421654
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
#    assert vars_module_0.get_vars(loader, path, entities) ==


# Generated at 2022-06-25 12:20:13.390682
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Init vars_module_0
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    # Invoke get_vars with arguments (dict, str, dict)
    test_case_0()


# Generated at 2022-06-25 12:20:21.812068
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ploader_0 = MockLoader()
    str_0 = 'h:IBV@#Z[5}esk)%n'
    list_0 = []
    dict_0 = {'host': str_0}
    dict_1 = {}
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(ploader_0, '', list_0)
    var_0 = vars_module_0.get_vars(ploader_0, str_0, dict_0)
    vars_module_0.get_vars(ploader_0, str_0, dict_1)
    vars_module_0.get_vars(ploader_0, '', dict_0)

# Generated at 2022-06-25 12:20:28.519565
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_test_VarsModule_get_vars.yaml')
    fp = open(str_0, 'w')
    fp.write("""
- hosts: all
  vars:
    cloud_provider: I will be overridden
    toaster: true
""")
    fp.close()
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)
    assert var_0["toaster"] == True


# Generated at 2022-06-25 12:20:34.101106
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  REQUIRES_WHITELIST = True
  entities = [entities]
  loader = "subdir"
  path = "subdir"
  vars_module_0 = VarsModule()
  vars_module_0.get_vars(loader, path, entities)

# Generated at 2022-06-25 12:20:36.449961
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:20:40.497941
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_1 = vars_module_0.get_vars(dict_0, str_0, dict_0)
    assert var_1 == to_text(str_0)

# Generated at 2022-06-25 12:20:41.220463
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:20:47.828604
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)
    C._load_name_resolution_vars({})
    var_1 = C._get_vars_from_inventory(dict_0, str_0, {})
    assert var_0 == var_1


# Generated at 2022-06-25 12:20:58.524368
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)


# Generated at 2022-06-25 12:21:04.105640
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)
    assert_equals(var_0, '')


# Generated at 2022-06-25 12:21:08.440248
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)
    var_0 = vars_module_0.get_vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:21:18.709040
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    dict_1 = {}

# Generated at 2022-06-25 12:21:26.953687
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    opath = '0.yml'
    found_files = ['0.yml']
    b_opath = '0.yml'
    new_data = 'zzz'
    data = 'zzz'
    cache = True
    entity = {'name': 'zzz'}
    subdir = 'zzz'
    loader = 'zzz'
    path = 'zzz'
    entities = {'name': 'zzz'}
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(loader, path, entities, cache)

# Generated at 2022-06-25 12:21:30.569487
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:21:38.973783
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    from ansible.parsing.dataloader import DataLoader
    dataloader_0 = DataLoader()
    list_0 = vars_module_0.get_vars(dataloader_0, str_0, dict_0)
    str_1 = '!/Z]08,7+9X-E'
    list_1 = vars_module_0.get_vars(dataloader_0, str_1, dict_0)
    str_2 = 'o*7BxjKz#G0;9r^'

# Generated at 2022-06-25 12:21:49.405356
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'BpSzGWCwCn"Dz2(UL4!4'
    dict_1 = {}
    dict_1['h:IBV@#Z[5}esk)%n'] = C.LOCALHOST
    dict_1['Cd:D{]o_8Ww\\u>v3^\\`0!?y'] = os.path.normcase(dict_0)
    dict_1['VarsModule'] = VarsModule
    dict_1['C.DEFAULT_VAULT_ID_MATCH'] = C.DEFAULT_VAULT_ID_MATCH
    dict_1['os.path'] = os.path

# Generated at 2022-06-25 12:22:00.345271
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    dict_1 = {}
    dict_1['host_vars'] = 'host_vars'
    dict_2 = {}
    dict_2['group_vars'] = vars_module_0.get_vars(vars_module_0, dict_0, str_0, dict_0)
    dict_2['host_vars'] = vars_module_0.get_vars(vars_module_0, dict_0, str_0, dict_0)
    dict_3 = {}
    dict_3['h:IBV@#Z[5}esk)%n'] = dict_2
    dict_3['group_vars'] = 'group_vars'
    dict

# Generated at 2022-06-25 12:22:05.822949
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    int_0 = random.randint(0, 0x7fffffff)
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

import random
from math import sqrt


# Generated at 2022-06-25 12:22:23.557769
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Initialize vars
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    # Call method get_vars of class VarsModule
    vars_get_vars(vars_module_0, dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:22:30.587943
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # prepare the test data
    data = {}
    loader = "loader"
    path = "path"
    entities = "entities"
    cache = False

    # get the instance
    vars_module_instance = VarsModule()
    # call the method
    result = vars_module_instance.get_vars(loader, path, entities, cache)
    # check the result
    assert result

if __name__ == '__main__':
    data = {}
    loader = "loader"
    path = "path"
    entities = "entities"
    cache = False

    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:32.937244
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)


# Generated at 2022-06-25 12:22:37.952433
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:22:41.103117
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {
    }
    str_0 = '/etc'
    list_0 = ['inventory']
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, list_0)

# Generated at 2022-06-25 12:22:46.904706
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("Test get_vars")
    host_0 = Host(name='llvs@14.27.87.117')
    group_0 = Group(name='tsilc@N2qt;[{N')
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, group_0)


test_case_0()

# Generated at 2022-06-25 12:22:51.761698
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    dict_0 = {}
    str_0 = '['
    dict_1 = {}
    str_1 = ':e}J*Xz$su^N/O'
    var_1 = var_0.get_vars(dict_0, str_0, dict_1)



# Generated at 2022-06-25 12:22:55.089463
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # test case 0
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)



# Generated at 2022-06-25 12:22:58.079806
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:23:09.041896
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    files_0 = [{'+d(5nP.o': 'h:IBV@#Z[5}esk)%n'}, {'+d(5nP.o': 'h:IBV@#Z[5}esk)%n'}, {'+d(5nP.o': 'h:IBV@#Z[5}esk)%n'}]
    entities_0 = {'+d(5nP.o': 'h:IBV@#Z[5}esk)%n'}
    with patch('ansible.plugins.vars.host_group_vars.VarsModule._find_vars_files') as mock_find_vars_files:
        mock_find_vars_files.return_value = files_0
        vars_module_0 = VarsModule()
       

# Generated at 2022-06-25 12:23:39.143525
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    # Testing if exceptions are raised
    try:
        vars_module_0.get_vars(None, None, None)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 12:23:43.144124
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  dict_0 = {}
  str_0 = 'h:IBV@#Z[5}esk)%n'
  vars_module_0 = VarsModule()
  var_0 = vars_get_vars(dict_0, str_0, dict_0)
  # This code asserts that the result of the method is what it is expected to be
  assert var_0 == None

# Generated at 2022-06-25 12:23:53.857873
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'k=x,y,z'
    vars_module_0 = VarsModule()
    str_1 = 'K&\x16y\x0fM#5\x1f'
    var_0 = vars_get_vars(dict_0, str_0, str_1)
    str_2 = 'host_vars'
    var_1 = os.path.join(str_1, str_2)
    str_3 = 'group_vars'
    var_2 = os.path.join(str_1, str_3)

# Generated at 2022-06-25 12:24:00.270187
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    entity_1 = Host()
    entity_1.name = 'z1'
    entity_1.path = 'host_vars/z1'
    #
    vars_module_1.get_vars(loader, 'host_vars/z1', [entity_1])
    #
    entity_2 = Host()
    entity_2.name = 'z3'
    entity_2.path = 'host_vars/z3'
    #
    vars_module_1.get_vars(loader, 'host_vars/z3', [entity_2])
    #
    entity_3 = Host()
    entity_3.name = 'z4'
    entity_3.path = 'host_vars/z4'
    #


# Generated at 2022-06-25 12:24:06.377106
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    b_str_0 = to_bytes('m@iHTsXsO{`]/0%c')
    str_0 = '##h7N8|vMIu#N_R#h'
    str_1 = 'h:IBV@#Z[5}esk)%n'
    str_2 = 'Host'
    b_var_0 = to_bytes('[w?BgUX2F4JR4%d}')
    b_var_1 = to_bytes('rV8r.6U1D}U.zd|n')
    vars_module_0 = VarsModule()
    subdir = str_0
    b_var_2 = to_bytes('8pocC}hD?{x%c>Zk')
    var_0 = vars_module_get_

# Generated at 2022-06-25 12:24:08.967582
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        vars_module_0 = VarsModule()
        vars_module_0.get_vars()
    except Exception as err:
        print(err)
        assert False



# Generated at 2022-06-25 12:24:13.031357
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 12:24:16.334554
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)


if __name__ == "__main__":
    import sys
    import traceback
    try:
        test_case_0()
    except Exception as e:
        print(traceback._some_str(), e)
        exit(1)

    sys.exit(0)

# Generated at 2022-06-25 12:24:21.901354
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

# ==========================================================
# Test for method get_vars of class VarsModule
# ==========================================================

# Generated at 2022-06-25 12:24:24.297771
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:25:22.390338
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)


# Generated at 2022-06-25 12:25:24.017075
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert callable(getattr(VarsModule, 'get_vars', None))



# Generated at 2022-06-25 12:25:27.379802
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:25:30.532184
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)



# Generated at 2022-06-25 12:25:32.761574
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO implementation
    print("Test method VarsModule.get_vars()")

# Generated at 2022-06-25 12:25:41.798455
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    list_0 = []
    str_0 = 'r{z^:$`IbHj*fl'
    host_0 = Host()
    group_0 = Group()
    vars_module_0 = VarsModule()
    try:
        vars_get_vars(dict_0, str_0, list_0)
    except:
        pass
    try:
        vars_get_vars(dict_0, str_0, host_0)
    except:
        pass
    try:
        vars_get_vars(dict_0, str_0, group_0)
    except:
        pass


# Generated at 2022-06-25 12:25:45.343160
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)


# Generated at 2022-06-25 12:25:51.608568
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    str_1 = 'v@h<dD/0.,0`}5:5'
    vars_module_0 = VarsModule()
    path_0 = os.path.realpath(to_bytes(os.path.join(dict_0, str_1)))
    os.path.exists(path_0)
    os.path.isdir(path_0)
    dict_1 = vars_module_get_vars(dict_0, str_0, dict_0)
    assert dict_1 == dict_0


# Generated at 2022-06-25 12:25:58.878228
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:26:03.937751
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    group_0 = Group()
    host_0 = Host()
    var_0 = vars_module_0.get_vars()
    var_1 = vars_module_0.get_vars(host_0, group_0, host_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:28:00.330860
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {'url_prefix': 'http://dummy-env/', 'public_key': 'ssh-rsa dummykey'}
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, dict_0, 'stage0')
    dict_1 = {}
    dict_1['staging_dir'] = 'var/tmp/stage0'
    dict_1['final_dir'] = 'var/tmp/final'
    var_1 = vars_get_vars(vars_module_0, dict_1, 'stage0')
    dict_2 = {}
    dict_2['url_prefix'] = 'http://dummy-env/'

# Generated at 2022-06-25 12:28:09.512349
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    os_path_sep = os.path.sep
    str_0 = '\x00\x03'
    os_path_join = os.path.join
    str_1 = '#Pb%I^]3,1\x07'
    bytes_0 = b'\x00\x03'
    os_path_realpath = os.path.realpath
    os_path_exists = os.path.exists
    os_path_isdir = os.path.isdir
    str_2 = '*'
    str_3 = '\x1b'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}

# Generated at 2022-06-25 12:28:12.999588
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:28:17.520375
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        vars_module_0 = VarsModule()
        dict_0 = {}
        str_0 = 'h:IBV@#Z[5}esk)%n'
        vars_module_0.get_vars(dict_0, str_0, dict_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 12:28:21.181383
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:28:23.589708
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # test_case_0
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:28:29.082832
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'N)X;,eB;'
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    vars_module_0 = VarsModule()
    result = vars_module_0.get_vars(vars_loader_0, vars_path_0, dict_0, dict_1, dict_2, dict_3)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:28:32.605937
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(dict_0, str_0, dict_0)

# Generated at 2022-06-25 12:28:33.551671
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:28:41.150442
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dict_0 = {}
    str_0 = 'h:IBV@#Z[5}esk)%n'

    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(dict_0, str_0, dict_0)

    dict_1 = {}
    str_1 = 'h:IBV@#Z[5}esk)%n'
    dict_2 = {}
    dict_3 = {}
    dict_3['a'] = 'a'
    dict_3['b'] = 'b'
    dict_2['a'] = dict_3
    dict_2['b'] = dict_3
    dict_4 = {}
    dict_4['a'] = dict_3
    dict_4['b'] = dict_3