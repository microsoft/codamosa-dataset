

# Generated at 2022-06-25 12:19:25.435452
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='test/test_playbook/inventory')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    vars_module = VarsModule()
    var1 = vars_module.get_vars(loader, 'test/test_playbook/inventory', inventory.get_host("localhost"), cache=True)
    var2 = vars_module.get_vars(loader, 'test/test_playbook/inventory', inventory.get_host("localhost"), cache=False)

# Generated at 2022-06-25 12:19:35.763014
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Call get_vars(loader, path, entities, cache=True)
    # Test expected exceptions
    # Path/entities must be a string/list respectively
    try:
        vars_module_1 = VarsModule()
        vars_module_1.get_vars(vars_module_1, '', 'test_case_1')
    except Exception as e:
        assert type(e) == AnsibleParserError
        assert to_native(e) == "Supplied entity must be Host or Group, got %s instead" % (type('test_case_1'))

    # Call get_vars(loader, path, entities, cache=True)
    # Test expected return value(s)
    vars_module_2 = VarsModule()

# Generated at 2022-06-25 12:19:45.613258
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    inventory_file = os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_test_vars")
    data_path = os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_vars_dir")

    for directory in [inventory_file, data_path]:
        if not os.path.exists(directory):
            os.makedirs(directory)

    def entity_to_ini(entity_type, inventory_file_path, entity_name, delete=False):

        entity_name = os.path.basename(entity_name)

        if entity_type == "host":
            config_file_name = "host_vars"
        elif entity_type == "group":
            config_file_name = "group_vars"

# Generated at 2022-06-25 12:19:48.223238
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    assert vars_module_1.get_vars('loader','path','entities','cache') == None

# Generated at 2022-06-25 12:19:57.748504
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=['test/integration/inventory_hosts_file_groups'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = inventory.get_host(hostname='testhost')
    path = '/test/path'
    entities = [host]
    cache = False

# Generated at 2022-06-25 12:19:58.606753
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    assert True

# Generated at 2022-06-25 12:19:59.107310
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert VarsModule().get_vars() is None

# Generated at 2022-06-25 12:20:01.238966
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader = 'loader'
    path = 'path'
    entities = 'entities'
    cache = True
    vars_module_0.get_vars( loader, path, entities, cache)

# Generated at 2022-06-25 12:20:13.274439
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0._basedir = '/home/ansible/ansible/test/units/plugins/inventory/vars_plugins/host_group_vars'
    vars_loader_0 = VarsModule._get_loader(vars_module_0)
    vars_module_0.get_vars(vars_loader_0, 'test/units/plugins/inventory/vars_plugins/host_group_vars', None)
    # assert failed because actual is None, expected is not None: Assertion failed
    # assert vars_module_0._basedir == '/home/ansible/ansible/test/units/plugins/inventory/vars_plugins/host_group_vars'
    # assert failed because actual is None, expected is not None: Ass

# Generated at 2022-06-25 12:20:19.507674
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = vars_module_0._loader
    # Loader.find_vars_files() returns a list of files
    vars_module_0._basedir = './'
    path_0 = 'path'
    entities_0 = []
    entities_0.append('group_vars')
    entities_0.append('host_vars')

    r = vars_module_0.get_vars(loader_0, path_0, entities_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:20:34.199392
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = None
    entities_0 = None
    cache_0 = True
    data_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert data_0 is None


test_case_0()
test_VarsModule_get_vars()

# Generated at 2022-06-25 12:20:39.464351
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars(loader=BaseVarsPlugin(), path=C.DEFAULT_DEBUG, entities=["test_var"]) == None
    assert vars_module.get_vars(loader=BaseVarsPlugin(), path=C.DEFAULT_DEBUG, entities=["test_var1", "test_var2"]) == None

# Generated at 2022-06-25 12:20:45.269553
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    inventory_file = 'test/test_playbook/hosts'
    inventory = Inventory(inventory_file)
    inventory._set_basedir(inventory_file)
    loader = DataLoader()
    inventory.parse_inventory(loader)
    host = inventory.get_host(b'test_host')
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(loader, inventory_file, host)

# Generated at 2022-06-25 12:20:52.815827
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test case 1
    #
    # Tested entity is a Host
    # Tested basedir is not an empty string
    # Tested basedir is a valid path
    # Tested entity name is on the path
    #
    
    host_entity = Host()
    host_entity.name = "test_host"

    vars_module_1 = VarsModule()

    loader_module_1 = DummyLoader()
    loader_module_1.set_basedir("test_host_vars")

# Generated at 2022-06-25 12:20:56.057425
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    instance = VarsModule()
    entities = [Group()]
    vars_module = VarsModule().get_vars(loader=1, path="path", entities=entities, cache=True)

# Generated at 2022-06-25 12:20:59.144677
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    host_2 = Host()
    group_2 = Group()

    vars_module_1.get_vars(None, '/path/to/inventory', group_2, False)



# Generated at 2022-06-25 12:21:04.312361
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = None
    entities_0 = [Group()]
    cache_0 = False
    assert vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0) is None

# Generated at 2022-06-25 12:21:10.198786
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('\n')
    vars_module = VarsModule()
    loader = vars_module._loader
    path = 'path'
    entities = []
    hosts = Group()
    hosts.name = "hosts"
    entity = Host()
    entity.name = "localhost"
    hosts.add_host(entity)
    entities.append(hosts)
    cache = True
    assert isinstance(vars_module.get_vars(loader, path, entities, cache=True), dict)
    assert isinstance(vars_module.get_vars(loader, path, entity, cache=True), dict)


# Generated at 2022-06-25 12:21:13.168297
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(loader, path, entities, cache=True)

# Generated at 2022-06-25 12:21:16.906322
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_get_vars_0 = VarsModule()
    VarsModule_get_vars_0.get_vars()

# Generated at 2022-06-25 12:21:29.776802
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars()

# Generated at 2022-06-25 12:21:34.756504
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    data = {}
    entities = []
    for entity in entities:
        if isinstance(entity, Host):
            subdir = 'host_vars'
        elif isinstance(entity, Group):
            subdir = 'group_vars'
        else:
            raise AnsibleParserError("Supplied entity must be Host or Group, got %s instead" % (type(entity)))
        # avoid 'chroot' type inventory hostnames /path/to/chroot

# Generated at 2022-06-25 12:21:38.495343
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    result1 = vars_module.get_vars(loader=None, path="", entities=None)
    assert result1 == {}
    result2 = vars_module.get_vars(loader=None, path="", entities="")
    assert result2 == {}

# Generated at 2022-06-25 12:21:44.778691
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test 'entities' is not list
    vars_module_1 = VarsModule()
    host = Host()
    try:
        vars_module_1.get_vars(None, None, host)
    except AnsibleParserError:
        pass

    # Test 'entities' is empty
    vars_module_2 = VarsModule()
    list = []
    vars_module_2.get_vars(None, None, list)

    # Test 'entities' has invalid length
    vars_module_3 = VarsModule()
    list = []
    host = Host()
    group = Group()
    list.append(host)
    list.append(group)

# Generated at 2022-06-25 12:21:53.187365
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    host_0 = Host(name='host_0', port=None, variables={})
    group_0 = Group(name='group_0')
    path_0 = 'i'
    print('*** create inventory ***')
    inventory = InventoryManager(loader=None, sources=path_0)
    print(inventory)
    inventory_data = inventory.get_group_variables('group_0')
    print('*** get_vars ***')
    print(vars_module_0.get_vars(loader=None, path=path_0, entities=[host_0], cache=False))
    print('*** inventory get_group_variables ***')
    print(inventory_data)

# check host_group_vars exist

# Generated at 2022-06-25 12:21:58.609857
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    from ansible.parsing.dataloader import DataLoader
    loader_1 = DataLoader()
    path_1 = None
    entities_1 = []
    cache_1 = True
    vars_module_1.get_vars(loader_1, path_1, entities_1, cache_1)

# Generated at 2022-06-25 12:22:00.698844
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    #TODO: Implement the test
    assert False


# Generated at 2022-06-25 12:22:09.200065
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("test_VarsModule_get_vars")
    vars_module_0 = VarsModule()
    loader_0 = None
    path_0 = None
    entities_0 = [Host(), Group()]
    cache_0 = True
    try:
        data = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
        print("data: %s" % (data))
    except Exception as e:
        print("exception: %s" % (str(e)))

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:10.429960
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    file_name_list = []
    vars_module_1 = VarsModule()
    vars_module_1.get_vars()

# Generated at 2022-06-25 12:22:22.053639
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    try:
        vars_module.get_vars(None, None, None, None)
    except Exception as e:
        pass

if __name__ == '__main__':
    import sys
    import os
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'library'))
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.vars.manager import VariableManager

    c = configparser.ConfigParser()

# Generated at 2022-06-25 12:22:33.618321
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()


# Generated at 2022-06-25 12:22:34.282260
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:22:44.626884
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os, tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Make temp dir to save test data
    temp_dir = tempfile.mkdtemp()
    test_data_path = os.path.join(temp_dir,'test_data')
    os.mkdir(test_data_path)
    os.mkdir(os.path.join(test_data_path, 'group_vars'))
    os.mkdir(os.path.join(test_data_path, 'host_vars'))

    # Save host vars

# Generated at 2022-06-25 12:22:50.908784
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # TODO: simulate loader
    loader = None
    path = "/tmp/test_site.yml"
    # TODO: simulate entities
    entities = None
    cache = True
    expected_result = {}
    actual_result = vars_module.get_vars(loader, path, entities, cache)
    assert(actual_result == expected_result)
    assert(FOUND == {})

# Generated at 2022-06-25 12:22:52.720741
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars(2, 3, 4)


# Generated at 2022-06-25 12:22:56.639312
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(loader, path, entities, cache=False)

if __name__ == '__main__':
    print('[*] test_VarsModule.py')
    test_case_0()
    test_VarsModule_get_vars()
    print('[*] DONE')

# Generated at 2022-06-25 12:22:57.342591
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()



# Generated at 2022-06-25 12:23:06.187156
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    vars_module_0._display = type('MockDisplay', (), {'debug': lambda s, m: print('display.debug(%s)' % m)})()

    #host = type('MockHost', (), {'name': 'host', 'port': None})()
    #host_0 = host()
    #entities = [host_0]
    #entities = [host]
    #vars_module_0.get_vars(loader=None, path=None, entities=entities, cache=True)
    #assert True is True  # TODO

# Generated at 2022-06-25 12:23:12.938459
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case 1
    vars_module_0 = VarsModule()
    loader_0 = FakeLoader({'plugin_staging_path': '/playbooks/test/plugins/vars'})
    path_0 = '/playbooks'
    entities_0 = Host('instance-00000252', '10.1.0.1')
    result_0 = vars_module_0.get_vars(loader_0, path_0, entities_0)
    assert result_0 == {'test_var': 'var'}
    assert FOUND['instance-00000252.0'] == ['/playbooks/host_vars/instance-00000252']

# Generated at 2022-06-25 12:23:15.544949
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars('test_loader_1', 'test_path_1', 'test_entities_1')


# Generated at 2022-06-25 12:23:32.080846
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_0 = VarsModule()
    loader_0 = Mock(loader_get_basedir=Mock(return_value=str_0), loader_find_vars_files=Mock(return_value=str_0), loader_load_from_file=Mock(return_value=var_0))
    path_0 = '\x04nQP\x0fUg+\t[\x0f2Z\x0e\x1c'
    entities_0 = str_0
    cache_0 = 'F\x06\x1b\x1b8W\x13\x1f\x1b\x0bG\x1a\r'
    VarsModule_0.get_vars(loader_0, path_0, entities_0, cache_0)

#

# Generated at 2022-06-25 12:23:38.372314
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = '3'
    list_0 = [vars_module_0, str_0, str_0]
    str_1 = '%c\x0c>;T@'
    str_2 = '\x0c&U6'
    var_0 = vars_get_vars(list_0, str_1, str_2)



# Generated at 2022-06-25 12:23:41.712205
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    t = VarsModule()
    list_0 = [t, t, t]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    assert t.get_vars(list_0, str_0, str_0) == None

# Generated at 2022-06-25 12:23:51.913287
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  module_0 = AnsibleModule(
    argument_spec = dict(),
    supports_check_mode = False
  )
  if module_0.params['supports_check_mode'] == 'False':
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    var_0 = vars_get_vars(list_0, str_0, str_0)

# Generated at 2022-06-25 12:23:54.649208
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    data = None
    entities = None
    loader = None
    path = None
    stage = None

    vars_module_1 = VarsModule()
    try:
        var_1 = vars_module_1.get_vars(loader, path, entities)
    except Exception as exception:
        print(exception)



# Generated at 2022-06-25 12:23:58.566439
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    var_0 = vars_get_vars(list_0, str_0, str_0)
    assert var_0 == 0, "Did you fail the test ?"

# Generated at 2022-06-25 12:24:04.868278
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    parser_0 = varsModule()
    parser_0.get_vars('2a[_f=,\x0bpcP=@CP|t_', '2a[_f=,\x0bpcP=@CP|t_', '2a[_f=,\x0bpcP=@CP|t_')


# Generated at 2022-06-25 12:24:09.245066
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    var_0 = vars_get_vars(list_0, str_0, str_0)

# Generated at 2022-06-25 12:24:18.453246
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  var_0 = '2a[_f=,\x0bpcP=@CP|t_'
  var_1 = 'hostname'
  var_2 = '2a[_f=,\x0bpcP=@CP|t_'
  vars_module_0 = VarsModule()
  group_0 = Group(var_0)
  host_0 = Host(var_1)
  list_0 = [group_0, host_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0]

# Generated at 2022-06-25 12:24:27.347997
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_instance = VarsModule()
    str_0 = 'kv'
    str_1 = 'znK'
    str_2 = 'N^'
    str_3 = '3q'
    str_4 = 'jKM'
    str_5 = '$R'
    str_6 = '&Q'
    str_7 = 'C'
    str_8 = 'K'
    str_9 = 'u'
    str_10 = 'g'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_6]
    list_1 = [str_7, str_8, str_9, str_10]
    tuple_0 = (list_0, list_1)
    dict_0 = Vars

# Generated at 2022-06-25 12:24:51.699812
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:24:52.254855
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:25:01.694199
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Example for using assertRaisesRegexp
    # assertRaisesRegexp does not have a long message <https://bugs.python.org/issue27720>
    with pytest.raises(AnsibleParserError, match='Supplied entity must be Host or Group, got xxx instead'):
        vars_module_0 = VarsModule()
        str_0 = '\x0bpcP=@CP|t_'
        str_1 = '_'
        str_2 = '_'
        class_0 = [str_0, str_1, str_2]
        vars_get_vars(vars_module_0, str_0, class_0)

    # Example for using assertRaisesRegexp
    # assertRaisesRegexp does not have a long message <https://bugs.python

# Generated at 2022-06-25 12:25:05.344536
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_1 = VarsModule()
    var_2 = "./test_data/test_vars_dir"
    var_3 = []
    var_4 = False
    var_5 = var_1.get_vars(var_3, var_2, var_2, cache=var_4)


# Generated at 2022-06-25 12:25:10.579502
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dummy_loader = VarsModule()
    path = 'path'
    entities = [1, 2, 3]
    cache = True
    dummy_VarsModule = VarsModule()
    str_0 = 'group_vars'
    var_0 = dummy_VarsModule._basedir
    dummy_VarsModule._basedir = str_0
    dummy_VarsModule.get_vars(dummy_loader, path, entities, cache)
    dummy_VarsModule._basedir = var_0

# Generated at 2022-06-25 12:25:16.066160
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Instance of class VarsModule
    vars_module_0 = VarsModule()
    # List with elements of class VarsModule
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    # List with elements of type 'str'
    str_list_0 = ['FA+c', 'Jh<#{bSc;', 'vV8W', 'o)uJ7', '&$(+', 'W', 'VW]dQ7-*']
    # Any type
    any_type_0 = C.INTERNAL_ERROR_RETRIES
    # Any type
    any_type_1 = True
    # List with elements of type 'str'

# Generated at 2022-06-25 12:25:20.976269
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module = VarsModule()

    class Entity :
        name = None
        def __init__(self, name):
            self.name = name

    entities = [Entity("first"), Entity("second")]

    # Unit test with parameters: (loader, path, entities, cache=True)

    # Unit test with parameters: (loader, path, entities, cache=False)



# Generated at 2022-06-25 12:25:29.576370
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()

# Generated at 2022-06-25 12:25:32.672495
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    var_0 = vars_module_0.get_vars(list_0, str_0, str_0)


# Testcases for Testname = status of a feature or functionality

# Generated at 2022-06-25 12:25:42.828154
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0
    class Host_1:
        pass
    host_0 = Host_1()
    class Group_1:
        pass
    group_0 = Group_1()
    list_0 = [host_0, group_0]

    try:
        vars_module_0.get_vars(vars_module_0, str_1, list_0)
    except AnsibleParserError:
        pass
    else:
        raise Exception(Error.get_error())

    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    class Host_0:
        def __init__(self):
            self.name = str_0
    host_0 = Host_0()

# Generated at 2022-06-25 12:26:52.062321
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    list_1 = [vars_module_1, vars_module_1, vars_module_1]
    str_1 = '2a[_f=,\x0bpcP=@CP|t_'
    var_1 = vars_get_vars(list_1, str_1, str_1)
    assert var_1 == None


# Generated at 2022-06-25 12:26:57.508846
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    list_0 = [Host(name='test_host_0')]

    # inventory is a string pointing to a file
    str_inventory = os.path.join(C.DEFAULT_LOCALHOST_CHROOT, '.ansible_test/test_inventory_0')
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(list_0, str_inventory)

# Generated at 2022-06-25 12:26:59.783191
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("Testing VarsModule.get_vars()")
    test_case_0()


# Generated at 2022-06-25 12:27:09.284932
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Initialization
    vars_module_0 = VarsModule()
    path_0 = 'S#0'
    dict_0 = dict()
    path_1 = '\x1a\x0b\x10\x1cn\\\x13'
    dict_1 = dict()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    dict_2 = dict()
    dict_3 = dict()
    str_0 = 'F\x1f\x01\x7fO\x01\x7fz\xd1\x7f'
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()

# Generated at 2022-06-25 12:27:18.748403
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule(None, 'rsK\x0b0\x0b\x0c\x0c', 'E6\x0ezP\x0c')
    str_0 = 'A:N\x0b\x0b\x0c'
    str_1 = '4\x0b\x0c[_nE\x0e\x0c\x0b'
    list_0 = [vars_module_0, str_1, str_0]
    str_2 = '\x0c\x0e[3\x0b\x0cO\x0c'
    var_0 = vars_module_0.get_vars(str_1, str_2, list_0)
    assert len(var_0) == 0



# Generated at 2022-06-25 12:27:24.031053
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    assert isinstance(vars_module_0.get_vars(list_0, str_0, str_0), dict) == True


# Generated at 2022-06-25 12:27:28.748547
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    dict_0 = dict()
    list_0 = [-7, 0, -5, -7]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    var_0 = vars_get_vars(vars_module_0, str_0, list_0, dict_0)

# Generated at 2022-06-25 12:27:32.547066
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    var_0 = vars_get_vars(list_0, str_0, str_0)

# Generated at 2022-06-25 12:27:38.225416
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    list_0 = [vars_module_0, vars_module_0, vars_module_0]
    str_0 = '2a[_f=,\x0bpcP=@CP|t_'
    vars_module_0.get_vars(list_0, str_0, str_0)


# Generated at 2022-06-25 12:27:40.259841
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert isinstance(VarsModule.get_vars, classmethod)
