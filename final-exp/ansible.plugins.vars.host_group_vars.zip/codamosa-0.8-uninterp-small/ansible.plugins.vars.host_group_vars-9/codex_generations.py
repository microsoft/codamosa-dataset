

# Generated at 2022-06-25 12:19:23.619126
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()

    ansible_loader = None
    path_0 = 'path_0'
    entities_0 = []
    cache_0 = True

    #call method get_vars
    try:
        result_0 = vars_module_0.get_vars(ansible_loader, path_0, entities_0, cache_0)
    except Exception as e:
        pass

    ansible_loader = None
    path_0 = 'path_0'
    entities_0 = None
    cache_0 = None
    #call method get_vars
    try:
        result_0 = vars_module_0.get_vars(ansible_loader, path_0, entities_0, cache_0)
    except Exception as e:
        pass


# test case

# Generated at 2022-06-25 12:19:26.387699
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 12:19:35.636825
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Setup
    vars_module = VarsModule()
    vars_module.basedir = 'test/integration/test_host_vars_plugins/host/host_vars'
    vars_module.get_extensions = lambda: ['.json']
    entity = Host('test_entity')

    # Perform unit test with cache=True
    vars_module.get_vars('loader', 'path', [entity], cache=True)

    # Perform unit test with cache=False
    vars_module.get_vars('loader', 'path', [entity], cache=False)

# Generated at 2022-06-25 12:19:37.454120
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    #loader = None
    vars_module_0.get_vars(None, None, None)

# Generated at 2022-06-25 12:19:39.807785
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    print(vars_module_1.get_vars(path='', entities=[]))



# Generated at 2022-06-25 12:19:45.998321
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_data = dict(
        entities=["localhost", "host2", "host3"],
        path="host_vars/localhost:group_vars/ansible"
    )

    setattr(test_data, "loader", object())
    setattr(test_data, "_basedir", object())
    setattr(test_data, "_display", object())

    vars_module_1 = VarsModule()
    vars_module_1.get_vars(**test_data)

# Generated at 2022-06-25 12:19:48.897728
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Group entity

    # Host entity

    pass

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:19:52.074970
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_get_vars_0 = VarsModule()

    vars_module_get_vars_0.get_vars('loader', 'path', 'entities', True)

# Generated at 2022-06-25 12:20:00.316446
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import vars_loader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    host = Host('test_case_0')
    group = host.get_group()
    group.name = 'test_case_0'
    entities = [host, group]

    vars_module_0 = VarsModule()
    os.environ['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'

    add_all_plugin_dirs()
    loader = DataLoader()
    vars_loader.add_directory(os.getcwd())
    vars_module_0._display = ImmutableDict

# Generated at 2022-06-25 12:20:03.903830
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Valid case
    vars_module_0 = VarsModule()
    print("Test vars plugin")
    vars_module_0.get_vars(None, None, [])


# Generated at 2022-06-25 12:20:08.359012
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:20:11.543064
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()
    loader = AnsibleLoader()
    entities = []
    path = None
    var = v.get_vars(loader, path, entities)
    assert var == {}

# Generated at 2022-06-25 12:20:20.781111
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    path_0 = 'C'

# Generated at 2022-06-25 12:20:28.998700
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Check when vars_loader is None
    try:
        vars_get_vars(vars_loader=None, cache=True, entities=Host())
        # Should not get here
        assert False
    except TypeError:
        assert True

    # Check when entities is None
    try:
        vars_get_vars(vars_loader=VarsModule(), cache=True, entities=None)
        # Should not get here
        assert False
    except TypeError:
        assert True

    # Check when entities is a list
    try:
        vars_get_vars(vars_loader=VarsModule(), cache=True, entities=[Host()])
        # Should not get here
        assert False
    except TypeError:
        assert True

    # Check when entities is a tuple

# Generated at 2022-06-25 12:20:30.677482
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule.get_vars()

# Generated at 2022-06-25 12:20:34.199222
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars("loader", "path", ["entities"])


# Generated at 2022-06-25 12:20:36.552779
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    error = False
    try:
        test_case_0()
    except Exception:
        error = True
    assert error


# Generated at 2022-06-25 12:20:40.301613
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("\n>>>>>> {{method}} <<<<<<\n")
    vars_module_0 = VarsModule()
    vars_get_vars(vars_module_0, vars_module_0, vars_module_0)

# Unit test helper method for get_vars

# Generated at 2022-06-25 12:20:44.784993
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = vars_module_0
    path_0 = vars_module_0
    entities_0 = vars_module_0
    var_0 = vars_get_vars(vars_module_0, path_0, entities_0)

# Generated at 2022-06-25 12:20:52.143095
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Load a default configuration
    import os
    import sys
    import yaml

    filepath = os.path.dirname(__file__)
    config_file = filepath + "/test_vars.yaml"
    # The 'config.yaml' file must be present in the same directory as this source file
    f = open(config_file)
    config = yaml.load(f)
    f.close()

    # Define the attributes of the object
    var_obj = VarsModule()

    # Input data
    data = config["data"]

    # Actual test of the method

# Generated at 2022-06-25 12:20:58.775325
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass


# Generated at 2022-06-25 12:21:02.964254
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:21:03.628968
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:21:04.790702
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    var = vars_get_vars(vars_module, vars_module, vars_module)

# Generated at 2022-06-25 12:21:06.628164
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # One or more of the following asserts are correct
    try:
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-25 12:21:09.571888
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    mock_vars_0 = [mock_Host(), mock_Group()]
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(vars_module_0, vars_module_0, mock_vars_0)



# Generated at 2022-06-25 12:21:12.714207
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var_0 = VarsModule()
    get_vars(var_0)
    return var_0


# Generated at 2022-06-25 12:21:15.802653
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Test of method get_vars of class VarsModule')
    print('This test requires full code coverage, including execution of all conditional branches and loops')

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:21:20.462517
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host()
    group = Group()
    entities = [host, group]
    loader_test = arbitrary_value
    cache_test = arbitrary_value
    # Check if Argument error is raised when not enough arguments are passed
    assert_equal(VarsModule.get_vars(), TypeError)
    # Check if Argument error is raised when too many arguments are passed
    assert_equal(VarsModule.get_vars(loader_test, loader_test, entities, cache_test, cache_test), TypeError)
    # Check if AnsibleParserError is raised when 'entities' is not of type list
    assert_equal(VarsModule.get_vars(loader_test, loader_test, host), AnsibleParserError)

    # Creating a Host object for testing
    host_test = Host()
    host_test.name = arbitrary

# Generated at 2022-06-25 12:21:31.066707
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    group_0 = Group()

    if (isinstance(group_0, Host)):
        subdir_0 = 'host_vars'
    elif (isinstance(group_0, Group)):
        subdir_0 = 'group_vars'
    else:
        raise AnsibleParserError('Supplied entity must be Host or Group, got' +  str(type(group_0))) + ' instead'

# Generated at 2022-06-25 12:21:56.112784
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert callable(VarsModule().get_vars)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:22:06.451999
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    entity_0 = Host()
    loader = vars_module_0
    path = vars_module_0
    entities = [entity_0]
    var_0 = vars_get_vars(vars_module_0, loader, path, entities, True)
    cache = True

    # Test branches for an if statement (line 79)
    if os.path.exists(b_opath):
        pass
    else:
        assert False

    # Test branches for an if statement (line 85)
    if not os.path.isdir(b_opath):
        assert False
    else:
        assert False

    # Test branches for an if statement (line 96)
    if new_data:
        pass
    else:
        assert True


# Generated at 2022-06-25 12:22:10.023761
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert vars_module_0 == var_0


# Generated at 2022-06-25 12:22:12.834807
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_obj = VarsModule()
    vars_module_obj.get_vars('', '', '')
    vars_module_obj.get_vars('', '', '', '')

test_case_0()

# Generated at 2022-06-25 12:22:13.997351
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    #test_case_0()
    print("test get_vars")

# Generated at 2022-06-25 12:22:17.822275
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Replace method get_vars of class VarsModule with a mock.
    vars_module_0 = VarsModule()
    vars_module_0.get_vars = Mock(return_value=({'var_name': 'var_value'}))
    # Call method get_vars of class VarsModule with a mock object and test its return value.
    assert vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0) == {'var_name': 'var_value'}

# Generated at 2022-06-25 12:22:18.789428
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass



# Generated at 2022-06-25 12:22:28.394337
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars = lambda self, loader, path, entities, cache=True: 'get_vars'
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    assert var_0 == 'get_vars'
    assert FOUND.get(('chroot.host_vars', 'group_vars')) is None
    assert FOUND.get(('chroot.host_vars', 'host_vars')) is None
    assert FOUND.get(('chroot.group_vars', 'host_vars')) is None
    assert FOUND.get(('chroot.group_vars', 'group_vars')) is None

# Generated at 2022-06-25 12:22:32.814695
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:22:39.489572
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)

    vars_module_2 = VarsModule()
    var_2 = vars_get_vars(vars_module_2, vars_module_2, vars_module_2)

    assert var_1 == var_2


# Generated at 2022-06-25 12:23:13.618712
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_loader_2 = vars_module_1.get_loader('/test/path', '/test/basedir', None)
    vars_loader_2.vars_plugins = []
    vars_loader_2.vars_plugins.append(vars_module_1)
    var_3 = C.DEFAULT_VAULT_IDENTITY_LIST
    vars_loader_2.set_vault_secrets(var_3)
    var_4 = C.DEFAULT_VAULT_IDENTITY_LIST
    vars_loader_2.set_vault_identities(var_4)
    var_5 = C.DEFAULT_VAULT_PASSWORD_FILE

# Generated at 2022-06-25 12:23:16.156884
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:23:20.350686
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    vars_module_0 = VarsModule()
    var_0 = var_get_vars_return_value = vars_module_0.get_vars(loader, path, entities, cache=True)

    assert var_0 == var_get_vars_return_value



if __name__ == "__main__":

    test_case_0()

# Generated at 2022-06-25 12:23:29.066408
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create an empty config
    config = {}

    # Create an empty context
    context = {}

    # Stub
    configstub = {}
    configstub['constants'] = C
    configstub['DEFAULT_VAULT_ID_MATCH'] = '^[A-Za-z0-9]{8}$'
    configstub['DEFAULT_VAULT_PASSWORD_FILE'] = '/root/.vault_pass.txt'
    configstub['DEFAULT_VAULT_IDENTITY_LIST'] = ['/root/.ssh/id_rsa', '/root/.ssh/id_dsa']
    configstub['DEFAULT_BECOME_METHOD'] = 'sudo'
    configstub['DEFAULT_BECOME_FLAGS'] = ''

# Generated at 2022-06-25 12:23:34.657202
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    loader = BaseVarsPlugin()
    path = VarsModule()
    entities = ['entity_1', 'entity_2']

    # get_vars with all arguments provided
    assert isinstance(vars_module.get_vars(loader, path, entities), dict)

    # get_vars with all required arguments provided and optional arguments skipped
    assert isinstance(vars_module.get_vars(loader, path, entities), dict)

    # get_vars with all required arguments not provided
    with pytest.raises(Exception) as exception_info:
        vars_module.get_vars()
    assert "Supplied entity must be Host or Group, got NoneType instead" in str(exception_info.value)
    assert exception_info.type == AnsibleParserError


# Generated at 2022-06-25 12:23:44.308116
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Temp vars
    var_1 = 0
    var_2 = 0
    VarsModule_get_vars = VarsModule.get_vars
    VarsModule_get_vars(VarsModule_get_vars, var_1, var_2)
    # Unit test setup
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    var_1 = 0
    var_2 = 0
    # Testing
    VarsModule_get_vars(VarsModule_get_vars, var_1, var_2)
    # Unit test tear down
    vars = VarsModule()

# Generated at 2022-06-25 12:23:55.163669
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Create an instance of VarsModule
    vars_module_0 = VarsModule()

    # Create an instance of Play
    play_0 = Play()

    # Create an instance of InventoryManager
    inventory_manager_0 = InventoryManager(loader=None, sources=['ansible-hosts'])

    # Create an instance of Host
    host_0 = Host(name='localhost', port=22)

    # Create an instance of Group
    group_0 = Group(name='localhost', hosts=[host_0])

    vars_module_0.set_options(var_options={})

    # Call method get

# Generated at 2022-06-25 12:23:58.233699
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Testing get_vars of class VarsModule')
    vars_module_1 = VarsModule()
    assert vars_module_1.get_vars(vars_module_1, vars_module_1, vars_module_1)
    

# Generated at 2022-06-25 12:24:03.777288
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    var = vars_module.get_vars(vars_module, vars_module, vars_module)
    var = vars_module.get_vars(vars_module, vars_module, vars_module)

# Generated at 2022-06-25 12:24:05.735959
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Get the path of the current file
    cur = os.path.dirname(os.path.realpath(__file__))
    # Assert for the path of all the directories and files
    assert(cur == '/home/travis/build/ansible/ansible/test/units/modules/vars_plugins')
    assert(FOUND=={})


# Generated at 2022-06-25 12:25:00.939841
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()

# Generated at 2022-06-25 12:25:03.711288
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # vars_module_0 = VarsModule()
    # var_0 = vars_get_vars(vars_module_0, vars_module_0, vars_module_0)
    print('Not yet implemented')

# Generated at 2022-06-25 12:25:08.409358
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Setup
    vars_module = VarsModule()
    loader = vars_module
    path = vars_module
    entities = vars_module
    cache = True
    # Exercise
    var = vars_module.get_vars(loader, path, entities, cache)
    # Verify
    assert var == {}
    # Cleanup - none necessary



# Generated at 2022-06-25 12:25:11.871711
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0)


# Generated at 2022-06-25 12:25:15.956217
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Variable var initialized
    var = to_native(VarsModule)
    var_get_vars = var.get_vars()

    # Test if method get_vars of class VarsModule returns an instance of its class
    assert isinstance(vars_module_0, VarsModule)
    # Test if method get_vars of class VarsModule returns the expected value
    assert vars_get_vars == var_get_vars

# Generated at 2022-06-25 12:25:22.014612
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    arg_0 = VarsModule()
    arg_1 = VarsModule()
    arg_2 = VarsModule()
    arg_3 = VarsModule()
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(arg_0, arg_1, arg_2, arg_3)

if __name__ == "__main__":
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:25:23.733709
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    var = VarsModule()
    assert isinstance(var.get_vars(1, 1, 1), dict)

# Generated at 2022-06-25 12:25:29.357431
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    assert isinstance(vars_module_0, VarsModule)
    var_0 = vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0, False)
    assert var_0 == {}
    var_0 = vars_module_0.get_vars(vars_module_0, vars_module_0, vars_module_0, True)
    assert var_0 == {}


# Generated at 2022-06-25 12:25:31.255153
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Input Parameters
    loader = VarsModule()
    path = './hosts'
    entities = Group('hosts')

    var_0 = vars_module_0.get_vars(loader, path, entities)
    assert var_0 == None

# Generated at 2022-06-25 12:25:34.075560
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    var = vars_get_vars(vars_module, vars_module, vars_module)



# Generated at 2022-06-25 12:27:27.593409
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entity = Host()

    vars_module_1 = VarsModule(loader=vars_module_1, path=vars_module_1, entities=entity)
    var_1 = vars_get_vars(vars_module_1, vars_module_1, vars_module_1)

# Generated at 2022-06-25 12:27:31.790483
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        assert test_case_0() == "Pass"
    except AssertionError:
        print("Testcase Assertion Error")
    except Exception:
        print("Testcase Exception Error")
    else:
        print("Testcase Success")

test_VarsModule_get_vars()

# Generated at 2022-06-25 12:27:42.225308
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    o0 = FOUND
    o1 = o0
    o2 = o1
    o3 = VarsModule()
    o4 = o3
    o5 = o4
    o6 = o5
    o7 = False
    o8 = type(o7)
    o9 = o8
    o10 = isinstance(o9, str)
    o11 = to_bytes(o10)
    o12 = to_native(o11)
    o13 = o12
    o14 = loader.find_vars_files(o13, o13)
    o15 = o14
    o16 = o15
    o17 = o16
    o18 = o17
    o19 = o18
    o20 = o19
    o21 = o20
    o22 = o21
    o23 = o

# Generated at 2022-06-25 12:27:44.050238
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars(None, None, None)


# Generated at 2022-06-25 12:27:46.717506
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.name = "VarsModule"
    var_0 = vars_get_vars(vars_module_0, None, None)


# Generated at 2022-06-25 12:27:54.515226
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = vars_module_0._loader
    path_0 = ''
    host_0 = Host(vars_module_0, vars_module_0, vars_module_0, vars_module_0, vars_module_0)
    entity_0 = [host_0]
    cache_0 = True
    var_0 = vars_module_0.get_vars(loader_0, path_0, entity_0, cache_0)
    assert var_0 == {}, "Expected %s, got %s" % (var_0, {})

# Generated at 2022-06-25 12:27:56.243966
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0._loader = data_loader()
    vars_module_0._display = Display()
    vars_module_0._basedir = 'base'
    assert vars_module_0.get_vars() == {}

# Generated at 2022-06-25 12:27:57.931739
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_data = VarsModule()
    var_data = vars_get_vars(vars_module_data, vars_module_data, vars_module_data)



# Generated at 2022-06-25 12:28:03.008181
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case 1
    vars_module_0 = VarsModule()
    vars_module_0.get_vars()

    # Test case 2
    vars_module_1 = VarsModule()
    vars_module_1.get_vars()

    # Test case 3
    vars_module_2 = VarsModule()
    vars_module_2.get_vars()

    # Test case 4
    vars_module_3 = VarsModule()
    vars_module_3.get_vars()

    # Test case 5
    vars_module_4 = VarsModule()
    vars_module_4.get_vars()

    # Test case 6
    vars_module_5 = VarsModule()
    vars_module_5.get_vars()

   

# Generated at 2022-06-25 12:28:06.789533
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()

    # Input params for methods get_vars of class VarsModule
    path_1 = None
    entities_1 = [Host]
    cache_1 = False

    var_1 = vars_get_vars(vars_module_1, path_1, entities_1, cache_1)