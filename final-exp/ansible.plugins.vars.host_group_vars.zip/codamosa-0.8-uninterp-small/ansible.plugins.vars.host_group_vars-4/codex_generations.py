

# Generated at 2022-06-25 12:19:20.081360
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_1 = object()
    path_1 = 'd'
    entities_1 = []
    cache_1 = True

    returned_value_1 = vars_module_0.get_vars(loader_1, path_1, entities_1, cache_1)
    result_1 = isinstance(returned_value_1, dict)
    assert result_1

# Generated at 2022-06-25 12:19:23.882479
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    entities_0 = ['foo', 'bar']
    assert vars_module_0.get_vars(loader=None, path=None, entities=entities_0, cache=True) == {}


# Generated at 2022-06-25 12:19:29.421788
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entities = [Host(name = 'test.example.com')]
    path = '/etc/ansible/hosts'
    loader = None
    cache = True
    data = VarsModule.get_vars(VarsModule, loader, path, entities, cache)
    assert len(data) == 0



# Generated at 2022-06-25 12:19:30.918355
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars({}, {}, [])


# Generated at 2022-06-25 12:19:31.798389
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-25 12:19:32.597828
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()

# Generated at 2022-06-25 12:19:35.527463
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test case with good empty list
    assert vars_module_0.get_vars() == []


# Generated at 2022-06-25 12:19:37.658811
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(opts, vault_opts, args)
    assert True

# Generated at 2022-06-25 12:19:42.181254
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_entity = Host("srv1", "myhost", "myhost_name")
    vars_module_0 = VarsModule()
    print (vars_module_0.get_vars)
    print (vars_module_0.get_vars(None, None, test_entity))

# Generated at 2022-06-25 12:19:44.031685
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars() is None

# Generated at 2022-06-25 12:19:52.924413
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)

# Generated at 2022-06-25 12:19:55.932253
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)



# Generated at 2022-06-25 12:19:58.600373
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)


# Generated at 2022-06-25 12:20:00.788592
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)

# Generated at 2022-06-25 12:20:05.291811
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = -1210
    bool_0 = False
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    assert var_0 == 0


# Generated at 2022-06-25 12:20:13.392526
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -599436780589281809
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)


# Generated at 2022-06-25 12:20:20.842871
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
        Unit test for method get_vars of class VarsModule
    '''
    int_0 = -1210
    bool_0 = False
    ipath_0 = "-"
    entity_0 = Group()
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    var_1 = vars_get_vars(ipath_0, bool_0, vars_module_0)
    var_2 = vars_get_vars(ipath_0, entity_0, vars_module_0)


# Generated at 2022-06-25 12:20:25.013263
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(int_0, bool_0)
    #assert (var_0 == )
    return "ok"


# Generated at 2022-06-25 12:20:28.893743
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)


if __name__ == "__main__":
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:20:38.640160
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Load ansible.cfg to get default values
    C._get_config_dir()
    C._get_parsable_extensions()
    C._get_safe_bytes()
    C._get_safe_text()
    C._get_unsafe_bytes()
    C._get_unsafe_text()
    C._get_yaml_extensions()
    ansible_cfg_0 = C.config.get_config_data(parser=None, filename=None)
    # Test with params
    test_case_0()

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:20:46.112794
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)

# Generated at 2022-06-25 12:20:49.496310
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = True
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    print(var_0)
    assert isinstance(var_0, dict)
    assert False


# Generated at 2022-06-25 12:20:52.518260
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    assert var_0 is None

# Generated at 2022-06-25 12:20:53.261822
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert True


# Generated at 2022-06-25 12:20:56.955528
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)

# Generated at 2022-06-25 12:21:00.897779
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    str_0 = '.'
    # vars_module_0.get_vars(str_0)
    # vars_module_0.get_vars(str_0)

# Generated at 2022-06-25 12:21:04.783939
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Testing arguments
    path = 'key1_value1'
    entities = 'key1_value1'

    # Invocation of method
    result = VarsModule.get_vars(path, entities)

    # Assert
    assert result is None



# Generated at 2022-06-25 12:21:10.249508
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    yaml_filename_ext = '.yml'
    bool_output = False
    vars_module_0 = VarsModule()
    arguments = {}
    arguments['loader'] = AnsibleLoader()
    arguments['path'] = '/root/.ansible/tmp/ansible-tmp-1541488223.07-92546375395080/yum'
    arguments['entities'] = ['']
    arguments['cache'] = bool_output
    try:
        vars_module_0.get_vars(**arguments)
    except SystemExit as e:
        pass


# Generated at 2022-06-25 12:21:18.959546
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path = "y/m"
    host_0 = Host()
    host_1 = Host()
    group_0 = Group()
    group_1 = Group()
    group_2 = Group()
    group_3 = Group()
    entity_arr = [host_0, host_1, group_0, group_1, group_2, group_3]
    cache = True
    var_1 = lambda: 0
    setattr(var_1, "name", "x")
    setattr(var_1, "name", "x")
    setattr(var_1, "name", "x")
    setattr(var_1, "name", "x")
    setattr(var_1, "name", "x")
    setattr(var_1, "name", "x")

# Generated at 2022-06-25 12:21:21.629774
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = 0
    bool_0 = False
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(int_0, bool_0)


# Generated at 2022-06-25 12:21:47.398235
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test file path
    file_path = C.ANSIBLE_TEST_DATA_ROOT / 'inventory.yml'
    # Test group
    group = Group('group1')
    # Test host
    host = Host('192.168.1.1')
    # Test vars module
    vars_module = VarsModule()
    # Test vars
    vars_get_vars(file_path, group, vars_module)
    vars_get_vars(file_path, host, vars_module)

# Generated at 2022-06-25 12:21:50.500109
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)


# Generated at 2022-06-25 12:21:59.023391
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ansible_0 = 'x_x'
    loader_0 = AnsibleLoader(ansible_0)
    group_0 = Group('x_x')
    group_1 = Group('x_x')
    host_0 = Host(group_0, group_1)
    path_0 = 'x_x'
    entities_0 = [host_0]
    cache_0 = True
    vars_module_1 = VarsModule()
    vars_get_vars(loader_0, path_0, entities_0, cache_0, vars_module_1)

# Function to test host_group_vars plugin

# Generated at 2022-06-25 12:22:02.268644
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = 0
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)

# Generated at 2022-06-25 12:22:11.852719
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0._basedir = 'plugins/vars/host_group_vars/tests/data/inventory/playbooks'
    vars_module_0._display = 'vars_module_0._display'
    vars_module_0._valid_extensions = ['.yaml', '.json', '.yml']
    entities_0 = [Host()]
    entities_1 = entities_0
    loader_0 = 'fake loader'
    cache_0 = False

# Generated at 2022-06-25 12:22:22.643099
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    int_0 = -5791
    bool_0 = False
    int_1 = -14238
    bool_1 = True
    int_2 = -364
    bool_2 = False
    groups_0 = Group()
    groups_0.name = "group0"
    groups_0._groups = [groups_0]
    groups_0._vars = {}
    groups_0.vars = {}
    vars_0 = {}
    vars_0["0"] = "0"
    groups_0._vars = vars_0
    groups_0.vars = vars_0
    group_1 = Group()
    group_1.name = "group1"
    group_1._groups = [group_1]
    group_1._v

# Generated at 2022-06-25 12:22:26.063295
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
        vars_module_0 = VarsModule()
        int_0 = -1210
        bool_0 = False
        result = vars_module_0.get_vars(int_0, bool_0)
        print(result)
        assert result == None


# Generated at 2022-06-25 12:22:31.736865
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)


# Generated at 2022-06-25 12:22:37.708363
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1598
    bool_0 = True
    vars_module_0 = VarsModule()
    with patch('ansible.plugins.vars.BaseVarsPlugin.get_vars') as mocked_BaseVarsPlugin_get_vars:
        BaseVarsPlugin.get_vars(int_0, bool_0, vars_module_0)
        mocked_BaseVarsPlugin_get_vars.assert_called_with(int_0, bool_0, vars_module_0)
        mocked_BaseVarsPlugin_get_vars.reset_mock()
        mocked_BaseVarsPlugin_get_vars.return_value = None

        # Call the method

# Generated at 2022-06-25 12:22:40.912476
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars(int_0, bool_0, vars_module_0) == 0


# Generated at 2022-06-25 12:23:08.142319
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path_0 = 'D-{.1X:|<Vh%5QrO1aLU=z'
    entities_0 = '$'
    cache_0 = True
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(path_0, entities_0, cache_0, vars_module_0)

if __name__ == '__main__':
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:23:14.269507
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_0 = VarsModule()
    VarsModule_0.get_vars(loader = None, path = None, entities = None, cache = True)

# Generated at 2022-06-25 12:23:18.303981
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('test_VarsModule_get_vars')

    # test_case_0 setUp
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)



# Generated at 2022-06-25 12:23:27.127274
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    module_dir_0 = './library/ansible/plugins/vars/case_0'
    basedir_0 = './library/ansible/plugins/vars/case_0'
    entity_0 = Host(module_dir_0, basedir_0)
    entities_0 = [entity_0]
    vars_module_0 = VarsModule()
    path_0 = './library/ansible/plugins/vars/case_0/host_vars'

# Generated at 2022-06-25 12:23:30.500937
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # setup
    path_0 = "group_vars"
    entities_0 = ["g1", "g2", "g3", "host1", "host2", "host3"]
    vars_module_0 = VarsModule()
    var_0 = get_vars(path_0, entities_0, cache=False)
    # verify
    assert var_0 is not None


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 12:23:33.132672
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_1 = 793
    bool_1 = True
    vars_module_1 = VarsModule()
    int_0 = 0
    # if the method doesn't raise an error, it is sufficient to verify that the function was called
    vars_module_1.get_vars(int_0, int_0, int_0, bool_1)

# Generated at 2022-06-25 12:23:37.724727
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    return var_0



# Generated at 2022-06-25 12:23:41.599327
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = 0
    bool_0 = True
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    assert var_0 is not None

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:23:44.184962
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)

# Generated at 2022-06-25 12:23:48.671654
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1190
    bool_0 = True
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)


# Generated at 2022-06-25 12:24:33.941557
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test Arguments
    int_0 = 0
    bool_0 = False
    vars_module_0 = VarsModule()

    # Invoke Method
    result = vars_module_0.get_vars(int_0, bool_0)

    # Assertions
    assert result == vars_module_0


# Generated at 2022-06-25 12:24:38.198685
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    path_0 = ''
    loader_0 = FakeLoader(path_0)
    entities_list_0 = []
    entities_0 = Host(entities_list_0)
    cache_0 = False
    var_0 = VarsModule_get_vars(path_0, loader_0, entities_0, cache_0)


# Generated at 2022-06-25 12:24:38.903447
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # testcase0
    test_case_0()

# Generated at 2022-06-25 12:24:41.367322
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_1 = 0
    bool_1 = True
    vars_module_1 = VarsModule()
    var_1 = vars_get_vars(int_1, bool_1, vars_module_1)

# Generated at 2022-06-25 12:24:44.550065
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bool_0 = False
    int_0 = -1210
    get_vars(int_0, bool_0, vars_module_0)
    return


if __name__ == "__main__":
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:24:46.066257
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bool_0 = True
    vars_module_0 = VarsModule()
    vars_module_0.get_vars(bool_0)


# Generated at 2022-06-25 12:24:48.346789
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
   int_0 = -1210
   bool_0 = False
   vars_module_0 = VarsModule()
   var_0 = vars_module_0.get_vars(int_0, bool_0)

test_case_0()
test_VarsModule_get_vars()

# Generated at 2022-06-25 12:24:50.141329
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    print(var_0)



# Generated at 2022-06-25 12:24:52.057489
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """
    Test method get_vars of class VarsModule
    """
    current_dir = os.path.dirname(__file__)
    localhost = os.path.join(current_dir, '../../../../../lib/ansible/inventory/hosts/hosts')


# Generated at 2022-06-25 12:24:58.180668
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    if var_0 is not None:
        raise AssertionError("get_vars returned unexpected value: %s" % var_0)


if __name__ == "__main__":
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:26:31.436242
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    if os.path.isdir("/etc/ansible/inventory/"):
        pass
    else:
        try:
            vars_module_0 = VarsModule()
            vars_module_0.subdir = "group_vars"
        except:
            pass
        else:
            try:
                vars_module_0 = VarsModule()
                vars_module_0.subdir = "host_vars"
            except:
                pass
            else:
                vars_module_0 = VarsModule()
                vars_module_0.subdir = "host_vars"
        vars_module_0 = VarsModule()
        vars_module_0.subdir = "group_vars"
    vars_module_0 = VarsModule()
    vars_module_

# Generated at 2022-06-25 12:26:37.459289
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(int_0, bool_0)

if __name__ == "__main__":
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None

'''
You can read or edit the value of a variable with the syntax $var or ${var}.
 Recall that variable names are made up of letters, digits, and underscores.
  The first character should not be a digit.
'''

# Generated at 2022-06-25 12:26:41.803512
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    try:
        test_case_1()
        test_case_2()
        test_case_3()
    except AssertionError as error:
        print(error)
    else:
        print("Path Testing successful")

# Function vars_get_vars executes the vars_module.get_vars method

# Generated at 2022-06-25 12:26:47.471717
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = VarsModule()
    bool_0 = VarsModule()
    vars_module_0 = VarsModule()
    # var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    raise NotImplementedError

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:26:48.657069
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Case 0
    test_case_0()


# Generated at 2022-06-25 12:26:51.865012
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    assert var_0 == None

# Generated at 2022-06-25 12:26:55.690741
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    assert len(var_0) == 0

# Generated at 2022-06-25 12:26:59.322996
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # from ansible.plugins.vars import VarsModule
    # int_0 = -1210
    # bool_0 = False
    # vars_module_0 = VarsModule()
    # var_0 = vars_module_0.get_vars(int_0, bool_0)
    assert True  # No real testing yet



# Generated at 2022-06-25 12:27:01.286454
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


if __name__ == "__main__":
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:27:05.875761
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    int_0 = -1210
    bool_0 = False
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(int_0, bool_0, vars_module_0)
    assert var_0 is None


# Test that the deprecation warning is triggered when importing