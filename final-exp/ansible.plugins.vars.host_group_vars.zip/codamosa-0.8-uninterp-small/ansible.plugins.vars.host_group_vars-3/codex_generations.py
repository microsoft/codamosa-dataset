

# Generated at 2022-06-25 12:19:19.163630
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    var_key = 'some/dummy/key'
    var_value = 'path/some/dummy/key'
    FOUND[var_key] = var_value
    data = {}
    loader = None
    path = var_key
    entities = [Group("some_group")]
    return_data = vars_module_0.get_vars(loader, path, entities)
    if (data and return_data):
        assert data == return_data

# Generated at 2022-06-25 12:19:26.520428
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_1 = None
    path_1 = b'C:\\Users\gdiaz\\Code\\ansible-2.9.7\\lib\\ansible\\plugins\\vars\\host_group_vars.py'
    entities_1 = Host(name='/Users/gdiaz/Code/ansible-2.9.7/inventory/hosts')
    cache_1 = True
    
    test_vars_1 = vars_module_1.get_vars(loader_1, path_1, entities_1, cache_1)
    assert test_vars_1 == {}

# Generated at 2022-06-25 12:19:31.322126
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("\nTESTING VarsModule.get_vars")
    vars_module = VarsModule()
    loader = None
    path = None
    host = Host("localhost")
    group = Group("all")
    entities = [host, group]
    data = vars_module.get_vars(loader, path, entities)



# Generated at 2022-06-25 12:19:33.511301
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    for entity in [Host()]:
        vars_module_1.get_vars(entity)


# Generated at 2022-06-25 12:19:36.717415
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    assert vars_module_1.get_vars(object(), object(), object(), True) == {}

# Generated at 2022-06-25 12:19:46.434094
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # Write your own test cases for get_vars method of class VarsModule
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/unit/modules/z_group_vars.yml'])
    inv_manager.parse_sources()

    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    vars_module = VarsModule()
    result = vars_module.get_vars(loader=loader, path='tests/unit/modules',
                        entities=inv_manager.groups['all'], cache=False)
    #

# Generated at 2022-06-25 12:19:56.825692
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    VarsModule_get_vars_env = os.environ.copy()
    VarsModule_get_vars_env["ANSIBLE_VARS_PLUGIN_STAGE"] = "setup"
    VarsModule_get_vars_env["ANSIBLE_YAML_FILENAME_EXT"] = ".yaml"
    VarsModule_get_vars_env["ANSIBLE_INVENTORY_ENABLED"] = "freeform,ini,yaml,auto,toml"
    VarsModule_get_vars_env["ANSIBLE_INLINE_INVENTORY_ENABLED"] = "yaml,auto,toml"

# Generated at 2022-06-25 12:20:02.538285
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.utils.vars import combine_vars

    # setup
    vars_module_0 = VarsModule()

    loader_0 = vars_module_0.get_loader()
    path_0 = "/path/to/inventory"

    # test with empty list
    entities_0 = []
    cache_0 = True
    vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)

    # test with Host object
    # - successful
    test_host = Host("test_host")
    entities_1 = test_host
    cache_1 = True
    vars_module_0.get_vars(loader_0, path_0, entities_1, cache_1)

    # - vars file is empty

# Generated at 2022-06-25 12:20:03.163153
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    pass

# Generated at 2022-06-25 12:20:14.201120
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print("\n--- Testing get_vars() ---")

    vars_module_0 = VarsModule()
    vars_module_1 = VarsModule()

    # Arrange
    path_string = "~/ansible/test_module_inventory"
    path_string_1 = "~/ansible/test_module_inventory/group_vars"
    path_string_2 = "~/ansible/test_module_inventory/host_vars"
    path = os.path.expanduser(path_string)
    path_1 = os.path.expanduser(path_string_1)
    path_2 = os.path.expanduser(path_string_2)

    # Cretae inventory for test
    test_host0 = Host(name="test_host0", port=22)


# Generated at 2022-06-25 12:20:19.501684
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars() == None

# Generated at 2022-06-25 12:20:25.941490
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # create object of class VarsModule
    vars_module_object = VarsModule()

    # create object of class BaseVarsPlugin
    base_vars_plugin_object = BaseVarsPlugin()

    # store the return value of function get_vars of class BaseVarsPlugin
    get_vars_return_value = base_vars_plugin_object.get_vars()

    # store the return value of function get_vars of class VarsModule
    get_vars_return_value = vars_module_object.get_vars()

# Generated at 2022-06-25 12:20:33.586407
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test for:
    #   get_vars(self, loader, path, entities, cache=True):
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Path to dataloader, which contains the class to be instantiated
    loader = DataLoader()
    path = "/home/ansible/ansible/test/integration/inventory/static/"
    cache = True

    # Test of happy path, where entitites are properly defined
    # entities can be type host or type group
    entities = [Host(name="localhost", port=22)]

# Generated at 2022-06-25 12:20:42.996731
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host_object = Host(name='hostname')
    group_object = Group(name='group_name')
    entities = [host_object, group_object]

# Checks whether function get_vars throws exception when argument entities is not of type 'list'
    try:
        test_case_0().get_vars('loader_object', 'path', host_object)
    except AnsibleParserError:
        pass

# Checks whether function get_vars throws exception when entity in entities is not of type 'Host' or 'Group'
    try:
        test_case_0().get_vars('loader_object', 'path', 'entity')
    except AnsibleParserError:
        pass

# Checks whether function get_vars throws exception when entity in entities is not of type 'Host' or 'Group'

# Generated at 2022-06-25 12:20:47.641679
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # check that get_vars raises AnsibleParserError when wrong type of entity is passed
    try:
        vars_module.get_vars(loader, path, 'entity')
    except Exception as e:
        assert 'Supplied entity must be Host or Group' in to_native(e)
    pass

# Generated at 2022-06-25 12:20:55.207432
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # test case # 0
    test_case_0()
    # test case # 1
    basedir = os.path.realpath('test/units/vars_plugins/test_host_group_vars/inventory/')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[basedir])
    # todo: make sure host_1 and host_2 are in the inventory
    host_1 = Host('host_1')
    host_2 = Host('host_2')
    group = Group('group_1')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vars_module

# Generated at 2022-06-25 12:21:05.920102
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_mock = class_mock.create_autospec(MockLoader())
    path_mock = class_mock.create_autospec(MockPath())
    entities_mock = class_mock.create_autospec(MockEntities())


# Generated at 2022-06-25 12:21:11.887272
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # This is dummy value for the load_from_file mock.
    DUMMY_LOADER_OUTPUT = { 'a': { 'b': 'c' } }

    # This is dummy yaml file to read.
    DUMMY_YAML_FILE_1 = """
---
meta:
  foo: 'bar'
    """

    # This is dummy yaml file to read.
    DUMMY_YAML_FILE_2 = """
---
path:
  /etc: test
    """

    # This is dummy JSON file to read
    DUMMY_JSON_FILE = """
{
"meta": {
"foo": "bar"
}
}
    """

    # This is a placeholder class to be used to mock an object of class InventoryFile.

# Generated at 2022-06-25 12:21:19.721766
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create the object of class VarsModule
    vars_module = VarsModule()
    # Set a fake inventory

# Generated at 2022-06-25 12:21:28.726243
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a class "Host" instance and a class "Group" instance with different values and assign these to different variables
    host_instance = Host('127.0.0.1', port=22)
    group_instance = Group('dummy', port=22)

    # Call method "get_vars" of class VarsModule with the different values and assert an exception value
    vars_module_1 = VarsModule()
    assert_exception_message(vars_module_1.get_vars, entities=host_instance)
    assert_exception_message(vars_module_1.get_vars, entities=group_instance)



# Generated at 2022-06-25 12:21:36.796171
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    from ansible.parsing.dataloader import DataLoader
    loader_0 = DataLoader()
    path_0 = ''
    entities_0 = [Host()]
    cache_0 = True
    data_0 = vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert data_0 == {}


# Generated at 2022-06-25 12:21:38.973909
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert(sorted(VarsModule.get_vars(VarsModule(),loader=None,path=None,entities=None,cache=True).keys()) == sorted([]))

# Generated at 2022-06-25 12:21:41.830069
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Testing get_vars')
    vars_module_0 = VarsModule()
    vars_module_0.get_vars('loader', 'path', 'entities', True)



# Generated at 2022-06-25 12:21:45.302800
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars('a', 'b', 'c')


# Generated at 2022-06-25 12:21:53.619487
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # test entity is a Host
    entity = Host(name="localhost", port=22)
    loader = AnsibleFileLoader('/', '', '', ['yml'])
    vars_module = VarsModule()
    real_path = os.path.realpath('/tmp')
    vars_module.get_vars(loader, real_path, entity)
    assert FOUND['localhost.%s'%real_path] == []

    # test entity is a Group
    group = Group(name="test")
    vars_module.get_vars(loader, real_path, group)
    assert FOUND['test.%s'%real_path] == []

    # test entity is a list
    entities = [entity, group]
    vars_module.get_vars(loader, real_path, entities)

# Generated at 2022-06-25 12:22:04.375407
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    data = {'a': 1, 'b': 2, 'c': 3}
    found_files = ['file1.txt', 'file2.txt']
    FOUND['key.value'] = found_files
    loader = Mock_object_loader()
    entities = ['entity1', 'entity2']
    vars_module_0.get_vars(loader, 'path', entities)
    assert(loader.load_from_file.call_count == 2)
    loader.load_from_file.assert_any_call('file1.txt', cache=True, unsafe=True)
    loader.load_from_file.assert_any_call('file2.txt', cache=True, unsafe=True)

# Using mock library, mock loader class

# Generated at 2022-06-25 12:22:07.508544
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    assert vars_module_0.get_vars is not None

if __name__ == "__main__":
    test_case_0()
    test_VarsModule_get_vars()

# Generated at 2022-06-25 12:22:08.937992
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars()

# Generated at 2022-06-25 12:22:11.286520
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    subdir = 'host_vars'
    host_name = 'localhost'
    vars_module_0 = VarsModule()
    data = vars_module_0.get_vars(C.loader, C.basedir, [host_name, subdir])
    assert type(data) == dict


# Generated at 2022-06-25 12:22:17.870665
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_vars = {}
    test_path = 'path/to/file'

    test_base_class = BaseVarsPlugin()
    assert test_base_class is not None

    test_entities = [
        ('host1', Host, 'host1', 'host_vars/host1.yml'),
        ('group1', Group, 'group1', 'group_vars/group1.yml'),
        ('group2', Group, 'group2', 'group_vars/group2.yml'),
        ('supergroup1', Group, 'group2:group1', 'group_vars/group2.yml'),
        ('supergroup1', Group, 'group2:group1', 'group_vars/group1.yml'),
    ]

    for test_entity in test_entities:
        test_

# Generated at 2022-06-25 12:22:37.307935
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create an instance of VarsModule class
    vars_module = VarsModule()

    # Create an instance of Host class
    host = Host('test_host')

    # Create an instance of Group class
    group = Group('test_group')

    # Create an instance of AnsibleLoader class
    class TestLoader:
        def find_vars_files(self, path, name):
            return []

        def load_from_file(self, path, cache=True, unsafe=True):
            return {}

    loader = TestLoader()

    # Test the get_vars method when entity is Host
    vars_module.get_vars(loader, '/path/to/inventory/file', host)

    # Test the get_vars method when entity is Group

# Generated at 2022-06-25 12:22:38.460710
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    vars_module.get_vars('', '', '')


# Generated at 2022-06-25 12:22:39.628507
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars(None,'path',[]) == {}

# Generated at 2022-06-25 12:22:41.822458
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
	vars_module_0 = VarsModule()
	assert isinstance(vars_module_0, VarsModule)
	vars_module_0.get_vars(loader=None, path=None, entities=None, cache=None)


# Generated at 2022-06-25 12:22:43.692931
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Initialize the VarsModule object
    vars_module_0 = VarsModule()

    # Test get_vars method
    vars_module_0.get_vars(loader, path, entities, cache=True)

# Generated at 2022-06-25 12:22:46.040703
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars()

# Generated at 2022-06-25 12:22:52.318334
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = DictDataLoader({})
    entity_0 = DictDataLoader({})
    path_0 = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_host_group_vars_payload')
    actual = vars_module_0.get_vars(loader_0, path_0, entity_0)
    print(actual)


# Generated at 2022-06-25 12:22:57.477412
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

  # Test Setup
  # Test Execution
  vars_module_0 = VarsModule()

  path_0 = None
  entities_0 = None
  cache_0 = None
  data_0 = vars_module_0.get_vars(path_0, entities_0, cache_0)

  # Test Verification
  assert data_0 ==  None
  assert vars_module_0.REQUIRES_WHITELIST ==  1

  # Test Teardown




# Generated at 2022-06-25 12:22:58.503990
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule_0 = VarsModule()


# Generated at 2022-06-25 12:23:08.575288
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    current_path = os.path.dirname(os.path.realpath(__file__))
    vars_module = VarsModule(path=current_path, stage="early")
    loader = _Loader()
    input_entities = [Host(name='foo', port=None, variables={})]
    output_vars = vars_module.get_vars(loader=loader, path=current_path, entities=input_entities, cache=True)
    assert "host_key1" in output_vars
    assert "host_key2" in output_vars
    assert "host_key3" in output_vars
    assert "host_key4" in output_vars


# Generated at 2022-06-25 12:23:43.868345
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    #dir1 = os.path.dirname(__file__)
    #dir2 = os.path.dirname(dir1)
    #dir3 = os.path.dirname(dir2)
    #dir4 = os.path.dirname(dir3)
    #dir5 = os.path.dirname(dir4)
    #dir6 = os.path.dirname(dir5)
    #dir7 = os.path.dirname(dir6)
    #dir8 = os.path.dirname(dir7)
    print("dir path")
    #print(dir1,dir2,dir3,dir4,dir5,dir6,dir7,dir8)
    #print(dir1,dir2,dir3)
    #print(dir5,dir6,dir7)
    #print(dir8

# Generated at 2022-06-25 12:23:46.568671
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    vars_module_1.get_vars(None, None, None, None)

# Generated at 2022-06-25 12:23:56.254895
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    loader_2 = loader()
    path_3 = "test"
    host_4 = Host(name="test")
    host_4.vars["ansible_connection"] = "local"
    host_4.vars["foo"] = "bar"
    host_5 = Host(name="another-test")
    host_5.vars["ansible_connection"] = "local"
    host_5.vars["foo"] = "bar"
    host_6 = Host(name="group")
    host_6.vars["ansible_connection"] = "local"
    host_6.groups = [Group(name="group")]
    host_6.groups[0].vars["foo"] = "bar"
    result = vars_module_1.get_

# Generated at 2022-06-25 12:24:02.545441
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    loader_0 = ''
    path_0 = ''
    entities_0 = ''
    cache_0 = ''
    data_0 = ''
    # Note: no __init__ for entity/entity_0
    assert not vars_module_0.get_vars(loader_0, path_0, entities_0, cache_0)
    assert data_0 == ''

# Generated at 2022-06-25 12:24:07.057684
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    class C:
        def __init__(self, a):
            self.name = a
    groups = [C("child1"), C("child2"), C("child3")]
    subdir = "group_vars"
    vars_module_0.get_vars(None, None, groups, subdir)

# Generated at 2022-06-25 12:24:16.005933
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import vars_loader
    from ansible.module_utils.six import PY3
    import inspect
    import sys

    PY3 = sys.version_info[0] >= 3

    if PY3:
        f_args = inspect.getfullargspec(VarsModule.get_vars).args
    else:
        f_args = inspect.getargspec(VarsModule.get_vars).args

    assert len(f_args) > 0, 'Argument list for get_vars not defined'
    assert 'self' in f_args, 'Argument list for get_vars self not defined'
    assert 'loader' in f_args, 'Argument list for get_vars loader not defined'


# Generated at 2022-06-25 12:24:16.557407
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert 0 == 1

# Generated at 2022-06-25 12:24:25.848426
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_1 = VarsModule()
    host_0_name = 'host_0_name'
    host_0 = Host(host_0_name)
    #host_0._set_variable('host_0_var_0', 'host_0_var_0_value')
    host_0._variable_manager = {'host_0_var_0': 'host_0_var_0_value'}
    group_0_name = 'group_0_name'
    group_0 = Group(group_0_name)
    #group_0._set_variable('group_0_var_0', 'group_0_var_0_value')
    group_0._variable_manager = {'group_0_var_0': 'group_0_var_0_value'}

    assert vars

# Generated at 2022-06-25 12:24:28.956403
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    #Arguments for the method
    loader = None
    path = None
    entities = None
    cache = True
    
    x = VarsModule()
    out = x.get_vars(loader,path,entities,cache)
    assert True == True

case_0 = True

# Generated at 2022-06-25 12:24:34.381580
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    subdir = './test/integration/vars_plugins/host_group_vars/group_vars_test_group1'
    path = './test/integration/vars_plugins/host_group_vars/inventory'
    data = '{:}{:}{:}'.format(C.DEFAULT_LOCAL_TMP, os.sep, 'ansible_data')
    entities = [Group('test_group1'), Group('test_group2')]
    vars_module_1 = VarsModule()

    result = vars_module_1.get_vars(path, entities, data)
    assert result == {'group_var_file_name': 'group_vars_test_group1'}

if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-25 12:25:03.299251
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_case_0()


# Generated at 2022-06-25 12:25:06.453057
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entity_0 = Group()
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(vars_module_0, bytes_0, entity_0)
    assert var_0 is None


# Generated at 2022-06-25 12:25:09.151199
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)

# Generated at 2022-06-25 12:25:15.773804
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 468
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)
    assert (var_0 is None)

    vars_module_0 = VarsModule()
    bytes_4 = 20
    int_0 = 243
    int_1 = 194
    int_2 = 628
    int_3 = 687
    file_0 = vars_module_0.get_vars(bytes_4, int_0, int_1, int_2, int_3)
    assert (file_0 is None)

    bytes_1 = None
    int_0 = 679
    int_1 = 593

# Generated at 2022-06-25 12:25:16.825171
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass



# Generated at 2022-06-25 12:25:19.868931
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 66
    vars_module_0 = VarsModule()
    var_0 = vars_module_0.get_vars(bytes_0, bytes_0, int_0)

# Generated at 2022-06-25 12:25:23.080041
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)


# Generated at 2022-06-25 12:25:27.158783
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
   # Add your own unit tests here.

    bytes_0 = None
    vars_module_0 = VarsModule()
    data = vars_get_vars(bytes_0, bytes_0, Host(name="localhost"))

    print("unit test for Ansible vars plugin:")
    print("host_vars: ")
    print(data)


# Generated at 2022-06-25 12:25:29.659514
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)

# Generated at 2022-06-25 12:25:41.114040
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.vars import VarsModule
    vars_module_0 = VarsModule()
    bytes_0 = to_bytes('epoch')
    bytes_2 = to_bytes('test_ansible_vars_plugins')
    str_0 = to_text('epoch')
    int_0 = 962
    vars_module_0.get_vars(bytes_0, bytes_2, int_0)
    bytes_1 = to_bytes('var')
    vars_module_1 = VarsModule()
    vars_module_1.get_vars(bytes_1, bytes_2, int_0)


# Generated at 2022-06-25 12:26:40.345681
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)


# Generated at 2022-06-25 12:26:45.140829
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    bytes_0 = None
    bytes_1 = None
    int_0 = 82035
    var_0 = vars_module_0.get_vars(bytes_0, bytes_1, int_0)
    assert var_0 == None


# Generated at 2022-06-25 12:26:53.683703
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """VarsModule TestCase"""
    from ansible.module_utils.common.collections import ImmutableDict

    # Test a dict return type
    vars_module_1 = VarsModule()
    vars_module_1.get_vars = lambda *args, **kwargs: {'example': 'test'}
    assert isinstance(vars_module_1.get_vars(), dict)

    # Test an ImmutableDict return type
    vars_module_2 = VarsModule()
    vars_module_2.get_vars = lambda *args, **kwargs: ImmutableDict()
    assert isinstance(vars_module_2.get_vars(), dict)

# Generated at 2022-06-25 12:26:55.172075
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module_0 = VarsModule()
    vars_module_0.get_parser()

# Generated at 2022-06-25 12:26:57.273402
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # given
    instance = VarsModule()

    # when
    result = instance.get_vars()

    # then
    assert result is None


# Generated at 2022-06-25 12:27:01.574450
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        test_case_0()
    else:
        test_VarsModule_get_vars()

# Generated at 2022-06-25 12:27:04.724021
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # create the instance of VarsModule
    e = vars_module_0.get_vars(vars_module_0, vars_get_vars, None)
    print(e)

# Generated at 2022-06-25 12:27:07.561925
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)


# Generated at 2022-06-25 12:27:13.133870
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    
    # Set up test data
    bytes_0 = None
    int_0 = 1895
    vars_module_0 = VarsModule()

    # Call the get_vars method of class VarsModule
    var_0 = vars_module_0.get_vars(bytes_0, bytes_0, int_0)

    # Assert the results



# Generated at 2022-06-25 12:27:15.896241
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    bytes_0 = None
    int_0 = 1283
    vars_module_0 = VarsModule()
    var_0 = vars_get_vars(bytes_0, bytes_0, int_0)

