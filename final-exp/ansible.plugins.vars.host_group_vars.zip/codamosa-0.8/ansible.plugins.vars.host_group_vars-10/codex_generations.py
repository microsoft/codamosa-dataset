

# Generated at 2022-06-11 17:03:11.941770
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
  module = VarsModule()
  class MockLoader:
    def find_vars_files(self, opath, entity_name):
      return ['group_vars/default', 'host_vars/localhost']
    def load_from_file(self, found, cache=True, unsafe=True):
      return {'name': found}
  class MockDisplay:
    def debug(self, msg):
      print(msg)
    def warning(self, msg):
      print(msg)
  loader = MockLoader()
  display = MockDisplay()
  module._display = display
  host = Host(name='localhost')
  module._basedir = '.'
  groups = module.get_vars(loader, '', host, cache=True)
  print(groups)

# Generated at 2022-06-11 17:03:22.094039
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    res = VarsModule.get_vars('', '', [])
    assert res == {}
    VarsModule.FOUND = {}

    res = VarsModule.get_vars('', '', [Host(name='aHost')])
    assert res == {}
    assert VarsModule.FOUND == {}

    res = VarsModule.get_vars('', '', [Group(name='aGroup')])
    assert res == {}
    assert VarsModule.FOUND == {}

    VarsModule.FOUND = {'aGroup.group_vars': ['aDir', 'aFile.yml']}
    res = VarsModule.get_vars('', '', [Group(name='aGroup')])
    assert res == {}

# Generated at 2022-06-11 17:03:25.833361
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' UnitTest for get_vars method of class VarsModule '''
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins import vars_loader

    loader, inventory, variable_manager, all_vars = setUp(None,
            ['host_vars/testhost', 'group_vars/all', 'group_vars/testgroup',
            'host_vars/testhost/subdir', 'host_vars/testhost/subdir_test.json',
            'group_vars/testgroup/subdir', 'group_vars/testgroup/subdir_test.json'])

    all_vars.clear()

# Generated at 2022-06-11 17:03:33.745867
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.vars import PluginLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible_collections.ansible.common.tests.unit.test_vars import TestVarsPluginStaging as VarsModuleStaging
    plugin_loader = PluginLoader(
        'ansible.plugins.vars',
        'VarsModule',
        C.DEFAULT_INVENTORY_VARS_PLUGINS,
        'vars_plugins',
        required_base_class=VarsModule,
        staging_namespace='ANSTEST',
    )
    plugin = plugin_loader.get(namespace=VarsModuleStaging.staging_namespace)
    loader = DataLoader()
    path = None
    host = Host("test")
    group = Group("test")
   

# Generated at 2022-06-11 17:03:39.686325
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    basedir = os.path.realpath(".")
    loader = None
    path = None
    host_name = 'localhost'

    host = Host(loader=loader, variable_manager=None, hostname=host_name, port=22)
    plugin_staging = VarsModule()

    data = plugin_staging.get_vars(loader, path, host)
    assert data

# Generated at 2022-06-11 17:03:48.986620
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host('127.0.0.1')
    host.name = "127.0.0.1"
    obj = VarsModule()
    # set plugin_basedir attribute
    obj._basedir = "/home/ubuntu/ansible/plugins/vars"
    
    # set loader attribute
    loader = AnsibleLoader()
    # set _display attribute
    class _display:
        def __init__(self):
            self.logger = logging.getLogger('ansible.runner.connection')
        def debug(self, s):
            print(s)
        def warning(self, s):
            print(s)
    obj._display = _display()
    obj.get_vars(loader, "/home/ubuntu/ansible/plugins/vars", [host], cache=True)
    assert obj._based

# Generated at 2022-06-11 17:03:49.823336
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-11 17:03:55.872906
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_plugin = VarsModule()
    vars_plugin._basedir = '/'
    vars_plugin._display = C.display.Display()
    vars_plugin._valid_extensions = [".yml", ".yaml", ".json"]
    vars_plugin._loader = C.get_loader(C.config.get_config_value('DEFAULTs', 'hostfile', 'hosts'))
    assert vars_plugin.get_vars(vars_plugin._loader, '/', []) == {}

# Generated at 2022-06-11 17:04:03.008831
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    # The following is a valid path, but a directory.
    # We don't expect any file to be found.
    assert vars_module.get_vars(None, '/usr/local/whatever', [Host('h1')]) == {}

    # The following is a valid file path.
    # We don't expect any file to be found.
    assert vars_module.get_vars(None, '/usr/local/whatever/file.txt', [Host('h1')]) == {}

# Generated at 2022-06-11 17:04:12.545448
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    VarsModule._basedir = "/tmp"
    FOUND = {}
    assert VarsModule().get_vars(vars_loader, "/tmp", "myhost.mydomain.com") == {
        'ansible_python_interpreter': '/usr/bin/python'
    }
    FOUND = {}
    assert VarsModule().get_vars(vars_loader, "/tmp", "myhost2.mydomain.com") == {
        'ansible_python_interpreter': '/usr/bin/python'
    }

# Generated at 2022-06-11 17:04:26.150860
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Test that the get_vars method of the VarsModule class is not totally broken.
    '''
    import os
    import tempfile
    import shutil
    import pytest

    # Disable host key checking
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = "False"

    # Disable callback fact gathering
    os.environ['ANSIBLE_CALLBACK_WHITELIST'] = "profile_tasks"

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary inventory file
    temp_inventory = tempfile.mkstemp()
    inventory_file, inventory_filename = temp_inventory
    os.write(inventory_file, b'localhost ansible_connection=local')
    os.close(inventory_file)


# Generated at 2022-06-11 17:04:36.418316
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes, to_text
    import os
    import tempfile
    import json
    import yaml
    import shutil

    vars_module = None
    paramiko_mock = None
    vault_mock = None
    vars_loader_mock = None
    temp_directory = None


# Generated at 2022-06-11 17:04:47.535270
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible_collections.notmintest.not_a_real_collection.plugins.inventory.group_vars_mapping import InventoryGroupVarsMapping, _get_filename_for_host
    from ansible_collections.notmintest.not_a_real_collection.plugins.inventory.host_vars_mapping import InventoryHostVarsMapping, _get_filename_for_host

    #################################################################

# Generated at 2022-06-11 17:05:00.135031
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host("test_name", "test_port")
    group = Group("test_name")
    entity = [host, group]
    data = {}
    FOUND_test = {}

    class fake_loader():
        def find_vars_files(self, opath, entity_name):
            found_files = [entity_name + ".yml"]
            return found_files

        def load_from_file(self, found, cache=True, unsafe=True):
            new_data = { "key": "value" }
            return new_data

    class fake_display():
        def debug(self, debug_message):
            return

        def warning(self, warning_message):
            return

    test_VarsModule = VarsModule()

# Generated at 2022-06-11 17:05:06.653045
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host

    basedir = "/home/aaron/ansible/inventory"
    b_opath = os.path.realpath(to_bytes(os.path.join(basedir, 'group_vars')))
    opath = to_text(b_opath)
    loader = {}
    entities = [Host("h1")]
    entities[0].vars = {"opt1": "val1"}

    # Load vars
    data = VarsModule.get_vars(VarsModule(), loader, basedir, entities, cache=True)

    assert data == entities[0].vars

# Generated at 2022-06-11 17:05:19.016503
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager

    class FakeLoader:
        def find_vars_files(self, path, name):
            found_files = []
            if path.endswith('/group_vars'):
                found_files = ['/home/ansible/group_vars/group1']
            elif path.endswith('/host_vars'):
                found_files = ['/home/ansible/host_vars/host1']
            return found_files


# Generated at 2022-06-11 17:05:27.726734
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    C.DEFAULT_VAULT_ID_MATCH = 0
    C.DEFAULT_VAULT_SECRET_MATCH = 0
    C.DEFAULT_VAULT_IDENTITY_LIST = []

    class Collection:
        """ Fake collection of files. """
        def __init__(self):
            self.collection = {}
        def __contains__(self, path):
            return path in self.collection
        def __getitem__(self, path):
            return self.collection[path]

    class FakeVarsLoader:
        def __init__(self, vault_secrets=None):
            self.vault_secrets = vault_secrets
            self.file_collection = Collection()

        def set_basedir(self, basedir):
            self.basedir = basedir


# Generated at 2022-06-11 17:05:38.549191
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # setup
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    class MockAnsibleModule(AnsibleModule):
        ''' mock class that fakes AnsibleModule methods '''
        def __init__(self, *args, **kwargs):
            super(MockAnsibleModule, self).__init__(*args, **kwargs)
            self.params = dict()

    class FakeArgs(object):
        ''' class to fake argparse parser class '''
        def __init__(self):
            self.connection = 'local'
            self.module_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../library')
            self.forks = 1


# Generated at 2022-06-11 17:05:48.876489
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.plugins.loader import vars_loader

    b_base_dir = os.path.dirname(to_bytes(__file__))
    base_dir = to_text(b_base_dir)
    host_name = "test"
    module_test = VarsModule()
    # Create test_vars_loader
    test_loader = vars_loader.VarsModule()
    # Create test_inventory_manager
    test_inventory_manager = VarsModule()
    # Test if get_vars() returns expected result
    assert module_test.get_vars(test_loader, base_dir, entities=[], cache=True) == {}
    assert module_test.get_vars(test_loader, base_dir, entities=Host(name=host_name), cache=True) == {}
    assert module

# Generated at 2022-06-11 17:05:53.653458
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()

    def test_file_loader(str1,str2):
        assert str1 == str2
        return True

    vars_module.get_vars(test_file_loader, 'base_dir', '', cache=True)

# Generated at 2022-06-11 17:06:11.076928
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    testfile = os.path.join('lib/ansible/plugins/vars', 'host_group_vars.py')

    lines, remainder = inspect.getblock(inspect.getdoc(VarsModule))
    docstring = '\n'.join(lines)
    options = yaml.safe_load(docstring)['options']

    # Use 2.10 options and defaults if not specified in the docstring
    if 'stage' not in options:
        options['stage'] = dict(ini=dict(key='stage', section='vars_host_group_vars'),
                                env='ANSIBLE_VARS_PLUGIN_STAGE')

    VarsModule.setup(options)
    plugin = VarsModule()


# Generated at 2022-06-11 17:06:19.426790
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class TestInventory():
        def __init__(self):
            self.groups = {}
            self.groups[None] = Group(name='all')

        def get_groups(self):
            return [self.groups[None]]

    import os
    import shutil
    import tempfile

    plugin = VarsModule()
    tmppath = tempfile.mkdtemp()
    cwd = os.getcwd()
    os.chdir(tmppath)
    os.mkdir('group_vars')
    os.mkdir('host_vars')
    os.chdir(cwd)

    inventory = TestInventory()
    inventory.groups[None].name = 'all'
    plugin.set_options(direct=dict(basedir=[tmppath]))

# Generated at 2022-06-11 17:06:29.477313
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import sys
    import tempfile
    from ansible.plugins.loader import vars_loader

    #################################################
    # create a custom vars plugin for testing purpose
    #################################################
    class MyVarsModule(VarsModule):

        def get_vars(self, loader, path, entities, cache=True):
            """
            An overloaded get_vars method for testing purpose
            """
            return super(MyVarsModule, self).get_vars(loader, path, entities)

    #################################################
    # create a temp dir with some dirs
    #################################################
    tmp_dir = tempfile.mkdtemp()
    group_vars = os.path.join(tmp_dir, 'group_vars')

# Generated at 2022-06-11 17:06:41.531979
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    print('Hint: If you update this test, please also update the documentation above.')

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import vars_loader

    test_host_name = 'foo'
    test_group_name = 'bar'
    test_hostvars_path = os.path.join('host_vars', test_host_name)
    test_groupvars_path = os.path.join('group_vars', test_group_name)

    # Note: The 'result' dictionaries below are constructed for readability. During normal
    # operation, the results would be in the form of a "data" key.

    result_groupvars = dict(a=1, b=2, c=3)

    result_groupvars_group

# Generated at 2022-06-11 17:06:52.781422
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # TEST METHOD 1: Test method when host_name is not a path
    #                and inventory file is in a different directory

    # Set up the variables for the test
    # To ensure that the vars plugin method get_vars(..) is well tested,
    # we will use the following scenario:
    #   - The inventory files are in a different directory than the playbook
    dynamic_inventory_path = "./tests/vars_plugin/"
    inventory_file = "hosts_test"
    playbook_name = "dummy_test.yml"
    host_name = "test_host"

    # Since we want to test the method get_vars(..), we need to create an
    # object of type VarsModule. However, we cannot create the object directly,
    # since the constructor of the class VarsModule needs the inventory


# Generated at 2022-06-11 17:06:53.393438
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-11 17:06:54.680127
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # TODO
    assert False

# Generated at 2022-06-11 17:06:56.367359
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-11 17:07:05.755467
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv_file_name = "hosts"
    inv_basedir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_vars_plugin')
    inv_file = os.path.join(inv_basedir, inv_file_name)
    inv_content = [
        '[ubuntu]',
        'localhost',
        '[all:vars]',
        'foo = bar',
        '[windows]',
        '192.168.56.111',
    ]
    inventory = InventoryManager(loader=DataLoader(), sources=inv_content)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-11 17:07:11.025393
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    module = VarsModule()
    module.get_vars(loader, '/etc/ansible/host_vars', Host(name='test_host_vars'))
    module.get_vars(loader, '/etc/ansible/group_vars', Group(name='test_group_vars'))



# Generated at 2022-06-11 17:07:29.077167
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_module = VarsModule()

    host = Host(name="test_host")
    group = Group(name="test_group")

    entities = [host, group]

    for entity in entities:
        assert test_module.get_vars(None, None, entity) == {}

# Generated at 2022-06-11 17:07:31.003516
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vm = VarsModule()
    vm.get_vars(loader, path, entities, cache)

# Generated at 2022-06-11 17:07:39.286603
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    import ansible.constants as C

    # create a fake inventory with a fake host and a fake group
    class FakeInventory(object):
        def __init__(self):
            self.hosts = dict()
            self.groups = dict()

    class FakeHost(object):
        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

        def get_vars(self):
            return self.vars

    class FakeGroup(object):
        def __init__(self, name, vars):
            self.name = name
            self.vars = vars

        def get_vars(self):
            return self.vars

    inventory = FakeInventory()
    inventory.hosts = dict

# Generated at 2022-06-11 17:07:49.331025
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.vars.manager import create_vars_files
    from ansible.vars.manager import create_vars_plugins
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import create_inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    import os

    # create a DataLoader that will find yaml files
    loader = DataLoader()

    # create the inventory, use path to host config file as source or hosts in a comma separated string
    inventory = create_inventory(loader, 'test_hosts_in_subdir')
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    vars_manager.set_inventory(inventory)
    # Create a list of vars plugins, with the host

# Generated at 2022-06-11 17:07:59.270556
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import vars_loader

    _vars_module = VarsModule()

    test_entities = [
        Host(name='inventory_1'),
        Host(name='inventory_2'),
        Group(name='inventory_1'),
        Group(name='inventory_2'),
    ]

    # Create some encrypted vault files.
    vault_password = 'ansible'

# Generated at 2022-06-11 17:08:11.299943
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import os
    import sys
    import tempfile
    import pytest

    # We need to plug in _actual_ tempfile.TemporaryDirectory
    # because we want to read the files into memory while they
    # are open.
    tmpdir = tempfile.TemporaryDirectory()

    # We also need to make sure to use the right directory separator
    # for the tmpdir.
    tmpdir_realpath = to_text(os.path.realpath(to_bytes(tmpdir.name)))

    # We'll create a tempfile for the host_vars dir
    host_vars_fd, host_vars_path = tempfile.mkstemp(dir=tmpdir_realpath)

    # We'll create a tempfile for the group_vars dir
    group_vars_fd, group_vars_path = tempfile

# Generated at 2022-06-11 17:08:15.886366
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    mm = VarsModule()
    import ansible.plugins.loader
    new_loader = ansible.plugins.loader.PluginLoader(
        'vars',
        '',
        'host_group_vars',
        '',
        'foo')
    new_loader._get_paths = lambda x: ['/dev/null']
    mm.get_vars(new_loader, '/dev/null', 'bar')

# Generated at 2022-06-11 17:08:25.175697
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Check if method get_vars returns the correct result
    '''

    # Create a test object
    test_obj = VarsModule()

    # Create a test inventory object
    test_inventory_obj = type("inventory", (object,), {})()
    test_inventory_obj.hostnames = ["host1", "host2"]
    test_inventory_obj.groups = {"host_group1": ["host1"], "host_group2": ["host2"]}

    # Create a test loader object
    test_loader_obj = type("loader", (object,), {})()

    # Test for method get_vars with entities = host1
    entities = "host1"
    test_result = test_obj.get_vars(test_loader_obj, "", entities, cache = True)
    assert test_result

# Generated at 2022-06-11 17:08:35.273674
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    f = os.path.join(C.DEFAULT_LOCAL_TMP, u'ansible_host_group_vars_test.yml')
    d = os.path.dirname(f)

    if os.path.isfile(f):
        os.unlink(f)

    if not os.path.isdir(d):
        os.makedirs(d)


# Generated at 2022-06-11 17:08:44.106106
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.plugins import vars_loader
    from ansible.utils.vars import combine_vars

    class Mock_Host(object):
        def __init__(self, name):
            self.name = name

    class Mock_Group(object):
        def __init__(self, name):
            self.name = name

    # TODO: Improve this test in order to handle the "chroot" type inventory hostnames /path/to/chroot

# Generated at 2022-06-11 17:09:31.817630
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()
    loader = DictDataLoader({})
    path = b'/path/to/fake/inventory'
    entities = [FakeEntity('groupA'), FakeEntity('groupB'), FakeEntity('groupC')]
    expected = [{'varA': 'A', 'varB': 'B', 'varC': 'C'}]
    actual = v.get_vars(loader, path, entities)
    assert actual == expected


# Generated at 2022-06-11 17:09:43.872714
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host('test')
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    test_dir = os.path.join(basedir, 'test/unit/vars_plugins/host_group_vars/test_dir')
    varsm = VariableManager(loader=vars_loader, inventory=None)
    vars_module = VarsModule()
    vars_module.set_options({'_basedir': test_dir})
    varsm._fact_cache[host] = {}
    # Test case for  Host

# Generated at 2022-06-11 17:09:54.933463
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import tempfile
    import shutil
    import os.path
    import os
    import errno

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    os.chmod(tmpdir, 0o700)
    os.chdir(tmpdir)
    plugin_basedir = os.path.join(tmpdir, 'test_plugin')

# Generated at 2022-06-11 17:10:01.776966
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert not(VarsModule.get_vars(None,
                         '/path/to/inventory',
                         Group(inventory=None, name='group_name')))
    assert not(VarsModule.get_vars(None,
                         '/path/to/inventory',
                         Host(inventory=None, name='host_name')))
    assert not(VarsModule.get_vars(None,
                         '/path/to/inventory',
                         Group(inventory=None, name='/path/to/chroot')))
    assert not(VarsModule.get_vars(None,
                         '/path/to/inventory',
                         Host(inventory=None, name='/path/to/chroot')))

# Generated at 2022-06-11 17:10:11.738202
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    loader = DummyVarsFileLoader()
    basedir = '/opt/inventory'

    # entity is a Host
    entity = Host("test_host")
    entities = [entity]
    path = basedir
    varsModule = VarsModule()
    varsModule._basedir = basedir
    varsModule.get_vars(loader, path, entities)
    assert(loader.file_name == "test_host.yml")

    # entity is a Group
    entity = Group("test_group", "")
    entities = [entity]
    varsModule = VarsModule()
    varsModule._basedir = basedir
    varsModule.get_vars(loader, path, entities)
    assert(loader.file_name == "test_group.yml")

# Dummy Loader class for unit test

# Generated at 2022-06-11 17:10:22.578945
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_data_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test_data')
    class Mock_loader(object):
        def __init__(self, datadir):
            self.datadir = datadir

        def find_vars_files(self, path, name):
            self.path = path
            self.name = name
            # return files found that are not ignored
            return [os.path.join(self.datadir, 'test_get_vars/group_vars/test/test.yaml')]

        def load_from_file(self, found, cache=True, unsafe=True):
            return {'v': '1'}

    class Mock_display():
        def __init__(self):
            self

# Generated at 2022-06-11 17:10:32.764147
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import copy
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.plugins.vars.host_group_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class TestVarsModule(unittest.TestCase):

        def setUp(self):
            self.variable_manager = VariableManager()
            self.loader = DataLoader()

# Generated at 2022-06-11 17:10:34.678337
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert VarsModule(None, {}, '/tmp/foo').get_vars(None, None, ['foo']) == {}

# Generated at 2022-06-11 17:10:43.154662
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Empty dict as data in test to collect vars
    data = {}

    # Create a Group object to be used in test
    group = Group('group_name')

    # Create a VarsModule object to be used in test
    vars = VarsModule()

    # Create a DummyLoader object to be used in test
    loader = DummyLoader()

    # Get vars from group_vars
    vars.get_vars(loader, 'path', group, data)


# Generated at 2022-06-11 17:10:54.219394
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    import os
    import shutil
 
    # Create a dummy vault secret
    vault_password = "ansible"

# Generated at 2022-06-11 17:12:21.211718
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class VarsModuleMock(VarsModule):
        def __init__(self):
            self._basedir = 'test_VarsModule_get_vars_basedir'

        def _load_plugin_vars(self, loader):
            pass

        def _load_vars(self, loader):
            pass

        def _load_file_vars(self, loader):
            pass

        @property
        def plugin_vars_cache(self):
            return self._plugin_vars_cache

    class Host:
        def __init__(self, name):
            self.name = name

    class Group:
        def __init__(self, name):
            self.name = name

    class DataLoader:
        def __init__(self, path):
            self.path = path


# Generated at 2022-06-11 17:12:27.294951
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    module = VarsModule()
    import ansible.plugins.loader as plugin_loader
    loader = plugin_loader.VarsModule.all()[0]

    # Get variable in group_vars/all
    entities = [Group('all')]
    variables = module.get_vars(loader, '/home/ansible/playbook', entities)
    assert variables == {'foo': 'bar'}

    # Get variable in group_vars/group
    entities = [Group('group')]
    variables = module.get_vars(loader, '/home/ansible/playbook', entities)
    assert variables == {'foo': 'bar'}

    # Get variable in host_vars/host
    entities = [Host('host')]

# Generated at 2022-06-11 17:12:38.708330
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class Entity(object):
        def __init__(self, name):
            self.name = name

    class Loader(object):
        def __init__(self, vars_files, unsafe=False):
            self.vars_files = vars_files
            self.unsafe = unsafe

        def find_vars_files(self, dir_name, entity_name):
            return [self.vars_files[k] for k in self.vars_files if dir_name + "/" + entity_name + "." in k]

        def load_from_file(self, file_name, cache=True, unsafe=False):
            return self.vars_files[file_name] if file_name in self.vars_files else None

    class Display(object):
        def debug(self, msg):
            print

# Generated at 2022-06-11 17:12:48.118922
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.plugins.loader import lookup_loader
    loader = lookup_loader.get('vars')
    plugin = loader.get('host_group_vars')

    # get_vars can be applied on a Host instance or a Group instance
    # Test case : Host
    host_obj = Host('test_get_vars_host_obj')

    if plugin.get_vars(loader, '', host_obj):
        print('Host entity processed successfully')
    else:
        print('Unable to process host entity')

    # Test case : Group
    group_obj = Group('test_get_vars_group_obj')
    
    if plugin.get_vars(loader, '', group_obj):
        print('Group entity processed successfully')
    else:
        print('Unable to process group entity')

# Generated at 2022-06-11 17:12:59.020892
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' Unit test for VarsModule.get_vars() '''
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    import tempfile
    import shutil

    def var_get_vars(loader, path, entities, cache=True):
        vmp = VarsModule()
        vmp._loader = loader
        vmp._basedir = path
        return vmp.get_vars(loader, path, entities, cache=cache)

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()