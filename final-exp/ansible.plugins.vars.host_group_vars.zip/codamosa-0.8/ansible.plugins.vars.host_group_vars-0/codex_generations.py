

# Generated at 2022-06-11 17:03:14.210412
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-11 17:03:24.726054
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()
    import ansible.constants as C
    import tempfile
    d = tempfile.mkdtemp()
    C.DEFAULT_HOST_LIST = '%s/hosts' % d
    C.DEFAULT_GROUP_LIST = '%s/groups' % d
    os.mkdir('%s/host_vars' % d)
    os.mkdir('%s/group_vars' % d)
    with open('%s/host_vars/host1' % d, 'w') as f:
        f.write('key1: value1\nkey2: value2')
    with open('%s/group_vars/group1' % d, 'w') as f:
        f.write('key3: value3\nkey4: value4')
   

# Generated at 2022-06-11 17:03:33.119318
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    import json

    test_host_1 = Host(name="test_host_1")
    test_host_2 = Host(name="test_host_2")
    test_group_1 = Group(name="test_group_1")

    test_data_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_data_loader, sources='localhost,',
            display=Display())
    test_inventory.clear_pattern_cache()
    test_inventory.add_host(test_host_1)
    test_inventory.add_

# Generated at 2022-06-11 17:03:33.882392
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-11 17:03:39.789097
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Create a VarsModule object
    varsModule = VarsModule()

    # Create a loader object
    loader = None

    # Create a path
    path = "/tmp"

    # Create a entities
    entities = None

    # Create a cache
    cache = True

    # Call the method get_vars with the parameters
    varsModule.get_vars(loader, path, entities, cache)

# Generated at 2022-06-11 17:03:48.118100
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    host = inventory.get_host(name='foobar')
    path = '/etc/ansible'
    # The results are cached, so to get a new result, we need to reload vars_module
    vars_module = VarsModule()
    data = vars_module.get_vars(loader, path, host)
    assert type(data) == dict

# Generated at 2022-06-11 17:03:58.485564
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    host = inventory.get_host('localhost')
    assert isinstance(host, Host)
    group = inventory.get_group('ungrouped')
    assert isinstance(group, Group)

    assert host.name == 'localhost'
    assert group.name == 'ungrouped'

    plugin_obj = VarsModule()
    vars = plugin_obj.get_vars(DataLoader(), '/etc/ansible/host_vars', host)
    assert isinstance(vars, dict)
    assert host.name in vars
    assert 'ansible_connection' in vars

# Generated at 2022-06-11 17:04:06.715049
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    plugin_instance = VarsModule()
    entities = [Host(), Group()]
    basedir = '/fake/path'
    plugin_instance._basedir = basedir
    for entity in entities:
        if isinstance(entity, Host):
            subdir = 'host_vars'
        elif isinstance(entity, Group):
            subdir = 'group_vars'
        else:
            raise AnsibleParserError("Supplied entity must be Host or Group, got %s instead" % (type(entity)))

        # avoid 'chroot' type inventory hostnames /path/to/chroot

# Generated at 2022-06-11 17:04:16.787015
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # 'entities' & 'basedir' are required inputs for get_vars()
    entities = [Host('example.com'), Group('my_group')]
    basedir = "/path/to/{0}"
    vars = VarsModule()

    # Test for "Host" object
    for obj in entities:
        if isinstance(obj, Host):
            vars._basedir = basedir.format('host_vars')
            ret = vars.get_vars(vars_loader, obj.name, obj)
    # Test for "Group" object
    for obj in entities:
        if isinstance(obj, Group):
            vars._basedir = basedir

# Generated at 2022-06-11 17:04:27.005012
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import unittest

    class FakeHost(Host):
        def __init__(self):
            pass

    class FakeGroup(Group):
        def __init__(self):
            pass

    from ansible.plugins.vars import BaseVarsPlugin

    class FakeBaseVarsPlugin(BaseVarsPlugin):
        REQUIRES_WHITELIST = True

    class FakeLoader():

        def find_vars_files(self, opath, name):
            return [dname for dname in os.listdir(opath) if
                    os.path.splitext(dname)[-1] in C.YAML_FILENAME_EXT]

        def load_from_file(self, found, cache=True, unsafe=True):
            return {}


# Generated at 2022-06-11 17:04:48.365276
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import pytest
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=demo_inv_path)
    host = inventory.get_host('test')
    vars_module = VarsModule()
    vars_module.set_options({'_basedir': demo_inv_path})
    vars = vars_module.get_vars(loader, demo_inv_path, host)
    assert 'host_var1' in vars
    assert 'host_var2' in vars
    with pytest.raises(AnsibleParserError):
        vars_module.get_vars(loader, demo_inv_path, 'invalid_entity')



# Generated at 2022-06-11 17:05:00.889090
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import os
    import sys
    import shutil
    import tempfile
    from collections import namedtuple

    Path = namedtuple('Path', ['name', 'path', 'file'])

    def create_file(b_basedir, path, body, executable=False):
        b_opath = os.path.join(b_basedir, path)
        opath = to_text(b_opath)
        dname = os.path.dirname(b_opath)
        if not os.path.exists(dname):
            os.makedirs(dname)
        with open(b_opath, 'wb') as f:
            if isinstance(body, text_type):
                body = to_bytes(body)
            f.write(body)

# Generated at 2022-06-11 17:05:08.126063
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create test class
    varsModule = VarsModule()
    # Create test objects
    loader = AnsibleLoader()
    path = os.path.realpath(__file__)
    groups = [Group('g1', loader), Group('g2', loader)]
    hosts = [Host('h1', loader), Host('h2', loader)]

    # Check empty variables in group vars directories
    for group in groups:
        # Create empty group_vars directory
        os.makedirs('group_vars')
        # Create group_vars/group directory
        os.makedirs('group_vars/' + group.name)
        data = varsModule.get_vars(loader, path, group)
        assert data == None

    # Check empty variables in host vars directories

# Generated at 2022-06-11 17:05:21.067966
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import collections
    import sys
    import ansible.plugins.loader
    import ansible.plugins.vars

    basedir = 'test/units/plugins/vars/data/host_group_vars'
    entity = ansible.inventory.host.Host('127.0.0.1')
    entity.vars = collections.defaultdict()
    entity.vars['ansible_python_interpreter'] = sys.executable
    loader = ansible.plugins.loader.VarsPluginLoader()
    VarsModule.register_plugin(loader)
    plugin = loader.get('host_group_vars', basedir=basedir)
    result = plugin.get_vars(loader, basedir, entity, cache=True)

# Generated at 2022-06-11 17:05:33.168371
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_host = 'testhost'
    test_group = 'testgroup'
    test_entities = [test_host, test_group]
    test_subdirs = ['host_vars', 'group_vars']
    test_vars = {'var1': 'val1', 'var2': 'val2'}

    class TestLoader:
        def find_vars_files(self, opath, host_name):
            found_files = []

            if not opath.endswith('vars'):
                return found_files

            if opath.endswith('group_vars'):
                for entity in test_entities:
                    if entity == 'testgroup':
                        found_files.append('test_file_group')

# Generated at 2022-06-11 17:05:41.323185
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    data = {
        "fruit": "apple"
    }

    class MyVarsModule(VarsModule):
        def __init__(self, *args, **kwargs):
            super(MyVarsModule, self).__init__(*args, **kwargs)
            self.data = data

    host = Host(name="test")
    group = Group(name="test")
    inventory_dir = 'inventory'
    host_vars_dir = os.path.join(inventory_dir, 'host_vars')
    group_vars_dir = os.path.join(inventory_dir, 'group_vars')

    if not os.path.exists(inventory_dir):
        os.makedirs(inventory_dir)

# Generated at 2022-06-11 17:05:42.660988
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert False, "Test cases not implemented"


# Generated at 2022-06-11 17:05:51.482039
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    subdirs = ['host_vars', 'group_vars']
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    loader = vars_loader
    vm = VarsModule()
    vm._load_name = 'vm_test'
    vm._basedir = C.DEFAULT_MODULE_PATH[0]
    vm._display = type('', (), {})()
    vm._display.debug = lambda x: x
    vm._display.warning = lambda x: x
    vm._display.vvvv = lambda x: x
    vm._display.vvvvv = lambda x: x
    vm._display.v = lambda x: x
    vm._display.vv = lambda x: x
    from ansible import context
    context._init_global_context(None)


# Generated at 2022-06-11 17:05:58.218418
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # create instance of Host class
    host = Host('host_name')
    # create instance of Group class
    group = Group('group_name')

    # create instance of VarsModule class
    vars_module = VarsModule()
    # call method get_vars
    assert vars_module.get_vars('loader', 'path', [host]) == {}

# Generated at 2022-06-11 17:06:07.117747
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader

    vars_module = VarsModule()

    Results = namedtuple('Results', ['hosts'])
    Options = namedtuple('Options', ['inventory'])
    FakeHost = namedtuple('Host', ['name'])
    opts = Options('/path/to/folder/')
    inv_manager = InventoryManager(loader=DataLoader(), sources='/etc/ansible/hosts')
    inv_manager._inventory.add_group('test')
    inv_manager._inventory.add_host(FakeHost('1.1.1.1'), 'test')


# Generated at 2022-06-11 17:06:13.009756
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-11 17:06:23.125728
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    module = VarsModule()
    path = "path/to/inventory"
    loader = None
    entity = Host(name="myhost", port=22)
    entities = [entity]
    cache = True

    vars = module.get_vars(loader, path, entities, cache)
    assert isinstance(vars, dict)

    entity = Group(name="mygroup")
    vars = module.get_vars(loader, path, [entity], cache)
    assert isinstance(vars, dict)

# Generated at 2022-06-11 17:06:31.510910
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins import vars_loader

    v = VarsModule()
    v._load_name = 'VarsModule'
    v._display = lambda x: x

    # NOTE: controlled environment for running one test case

# Generated at 2022-06-11 17:06:43.006686
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader

    # clear out FOUND cache
    global FOUND
    FOUND = {}

    if not os.path.exists('test'):
        os.mkdir('test')
    # create test files.
    with open(os.path.join('test', 'host_vars', 'test_host'), 'w') as f:
        f.write('---\nhost_var: test_host_var\n')
    with open(os.path.join('test', 'group_vars', 'test_group'), 'w') as f:
        f.write('---\ngroup_var: test_group_var\n')

    # create objects
    a = Host(name='test_host')
    b = Group(name='test_group')
    # create vars

# Generated at 2022-06-11 17:06:48.825311
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.errors import AnsibleParserError

    display = Display()
    loader = DataLoader()
    vars_dir = '{0}/../../../../examples/host_vars_group_vars'.format(os.path.dirname(__file__))
    inventory = InventoryManager(loader, vars_dir, display)

    hostvars = inventory.get_host("host1").get_vars()
    assert(len(hostvars) > 0)


# Generated at 2022-06-11 17:06:59.014192
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import json
    import sys
    import os
    import tempfile
    import shutil

    prev_cwd = os.getcwd()
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)
    sys.path.insert(0, '%s/../../..' % os.path.dirname(os.path.abspath(__file__)))

    # Setup fake ansible config
    os.makedirs("%s/.test_ansible" % tempdir)
    os.makedirs("%s/.test_ansible/host_vars" % tempdir)
    os.makedirs("%s/.test_ansible/group_vars" % tempdir)


# Generated at 2022-06-11 17:07:07.311426
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    test_dir = tempfile.TemporaryDirectory(prefix='ansible_host_group_vars_unit_test.')
    test_hosts = ['host1', 'host2']
    # test_hosts = ['host1', 'host2', '/chroot-host3']
    test_groups = {'group1': ['host1'], 'group2': ['host2'], 'groupall': ['host1', 'host2']}

# Generated at 2022-06-11 17:07:13.664482
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp(dir='/tmp')
    basedir = os.path.join(tmpdir, 'vars_dir')
    os.mkdir(basedir)

    # Create inventory host file
    inv_path = os.path.join(basedir, 'inventory')
    with open(inv_path, 'w') as inv:
        inv.write('localhost ansible_connection=local\n')

    # Create vars files
    os.mkdir(os.path.join(basedir, 'group_vars'))
    os.mkdir(os.path.join(basedir, 'host_vars'))
    with open(os.path.join(basedir, 'group_vars', 'group1'), 'w') as g:
        g.write

# Generated at 2022-06-11 17:07:14.559955
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    result = VarsModule.get_vars()
    assert result is not None

# Generated at 2022-06-11 17:07:22.264199
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from units.mock import Mock
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    vm._vault_password = '$ANSIBLE_VAULT;1.1;AES256;notarealpassword'
    vm._vault = Mock(return_value='secrets')
    vm._vault_ids = DEFAULT_VAULT_ID_MATCH
    plugin = VarsModule()

# Generated at 2022-06-11 17:07:38.435061
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host('127.0.0.1')
    group = Group('database')
    loader = DictDataLoader({})
    file_loader = DictDataLoader({'host_vars/127.0.0.1':"name=host_vars_host", 'group_vars/database':"name=group_vars_database"})
    vm = VarsModule(loader=file_loader)
    vars = vm.get_vars(loader, '.', [host, group])
    assert vars['name'] == 'group_vars_database'



# Generated at 2022-06-11 17:07:48.752963
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # test cases
    # TODO: test cases run, but they may fail the assert (not necessarily the get_vars returned false)
    #       still need to find a way to test them properly
    # TODO: load_file method is not tested, because it's not used in this code snippet

    #VarsModule_get_vars
    module = VarsModule(path='.')
    loader = MockLoader(path='/tmp')
    entities = ['localhost']
    data = module.get_vars(loader, '/tmp', entities, cache=True)
    assert data != False

    #VarsModule_get_vars2
    module = VarsModule(path='.')
    loader = MockLoader(path='/tmp')
    entities = ['localhost']

# Generated at 2022-06-11 17:07:58.486682
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' Unit test for method get_vars of class VarsModule '''
    import copy
    # Create a simple Inventory
    inven = Host(name="dummy", port=22)
    # Create a simple AnsibleOptions
    opts = copy.deepcopy(C.CLIARGS)
    opts["connection"] = "ssh"
    # Create a MockDataLoader
    m_loader = MockDataLoader()
    # Create an instance of class VarsModule
    v_module = VarsModule()
    # Get the variables for host 'dummy'
    vars = v_module.get_vars(m_loader, "", inven, False)
    assert vars['ansible_connection'] == opts["connection"]



# Generated at 2022-06-11 17:08:00.640565
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule.get_vars(VarsModule, loader='loader', path='', entities='entities', cache=True)

# Generated at 2022-06-11 17:08:12.983090
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_host_vars = {}

    # get vars for host
    test_host = {}
    test_host['name'] = 'test_host'
    test_plugin = VarsModule('/test_directory', test_host)
    test_plugin.get_vars(test_plugin, '/test_directory', test_host)
    test_host_vars[test_host['name']] = test_plugin._templar._available_variables[test_host['name']]

    # get vars for group
    test_group = {}
    test_group['name'] = 'test_group'
    test_plugin = VarsModule('/test_directory', test_group)
    test_plugin.get_vars(test_plugin, '/test_directory', test_group)

# Generated at 2022-06-11 17:08:19.037275
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = MockLoader()
    mod = VarsModule()
    mod.set_options()

    mod._basedir = 'tests/unit/plugins/vars'
    data = mod.get_vars(loader, 'host_group_vars', 'host')
    assert data['var_host'] == 'var_host'

    mod._basedir = 'tests/unit/plugins/vars'
    data = mod.get_vars(loader, 'host_group_vars', 'group')
    assert data['var_group'] == 'var_group'

    # key should be cached
    mod._basedir = 'tests/unit/plugins/vars'
    data = mod.get_vars(loader, 'host_group_vars', 'host')
    assert data['var_host'] == 'var_host'




# Generated at 2022-06-11 17:08:30.460920
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # The variables used in this test
    attributes = {
        '_basedir': './',
        '_display': {'debug': lambda msg: print(msg)},
        '_valid_extensions': ['.json', '.yml', '.yaml']
    }

    # Building the object
    obj = VarsModule()
    for attr in attributes.keys():
        setattr(obj, attr, attributes[attr])

    # Writing data to test
    obj._valid_extensions = ['.json', '.yml', '.yaml']

    # Unit test for get_vars
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import find_plugin


# Generated at 2022-06-11 17:08:37.626882
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    module = VarsModule()
    group = Group('groupname')
    group.vars = {'a' : 'aa', 'b' : {'b1' : 'bb1'}}
    host = Host('hostname')
    host.vars = {'a': 'aaa', 'b' : {'b2': 'bb2'}}
    entities = [group, host]
    for entity in entities:
        data = module.get_vars(loader=None, path=None, entities=entity, cache=False)
        expected_data = {'a':'aaa', 'b':{'b2':'bb2'}}
        assert(data == expected_data)


# Generated at 2022-06-11 17:08:45.285038
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    import shutil
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create inventory
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    # Create vars directory for host localhost
    os.makedirs(tmpdir + '/host_vars')

    # Create inventory file in tmpdir
    with open(tmpdir + '/hosts', 'w') as f:
        f.write('localhost')

    # Create var file for host localhost

# Generated at 2022-06-11 17:08:56.200400
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import ansible.plugins.vars.host_group_vars as host_group_vars
    test_dir = os.path.dirname(__file__)
    sample_inventory = os.path.join(test_dir, 'samples')
    loader = VarsModule._get_loader(
        [sample_inventory],
        False,
    )

    host_group_vars.FOUND = {}

    #
    # Test host variables
    #
    data = host_group_vars.get_vars(loader, sample_inventory, [Host("test")])
    assert data['test'] == "test"
    assert data['test1'] == "test1"

    #
    # Test group variables
    #

# Generated at 2022-06-11 17:09:57.666211
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import sys
    import pytest
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Prepare data for test
    basedir = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'host_group_vars')
    class_obj = VarsModule(vars_loader)
    class_obj._basedir = basedir
    entities = [Group('group1', basedir='.'),
                Group('group2', basedir='.'),
                Group('group3', basedir='.'),
                Host('example.com', basedir='.')]



# Generated at 2022-06-11 17:10:08.067870
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class FakeHost():
        def __init__(self, name):
            self.name = name

    class FakeGroup():
        def __init__(self, name):
            self.name = name

    class FakeLoader():
        def find_vars_files(self, opath, base_path):
            return self._variables

        def load_from_file(self, filename, cache=True, unsafe=True):
            return self._loaded_variables

    class FakeVariableManager():
        def __init__(self, inventory):
            self.inventory = inventory

    class FakeInventory():
        def __init__(self):
            self.hosts = {}

        def register_host(self, host):
            self.hosts[host.name] = host


# Generated at 2022-06-11 17:10:15.108078
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.vars.unsafe_proxy import UnsafeVariable


# Generated at 2022-06-11 17:10:23.760537
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager

    class MockVarsModule(VarsModule):
        REQUIRES_WHITELIST = False

    config = {
        'ANSIBLE_VARS_PLUGINS': 'host_group_vars',
        'ANSIBLE_INVENTORY': './test/units/vars/host_group_vars/',
        'ANSIBLE_VARS_PLUGIN_STAGE': 'playbook'
    }
    inv_manager = InventoryManager(config, vars_loader)

    vars_mod = MockVarsModule(inv_manager)

    hosts = inv_manager.get_hosts()


# Generated at 2022-06-11 17:10:34.089236
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = DummyVarsLoader()
    host = DummyHost()
    path = "path_to"
    group = DummyGroup()
    cache = False
    stage = "any"
    host.name = "host1"
    group.name = "group1"
    b_opath = os.path.realpath(to_bytes(os.path.join(path, "group_vars")))
    opath = to_text(b_opath)
    key = '%s.%s' % (group.name, opath)
    assert VarsModule.get_vars(loader, path, group, cache) == {"group1": {"var1": "value1", "var2": "value2"}}

# Generated at 2022-06-11 17:10:35.401144
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule.get_vars(None, None, None)

# Generated at 2022-06-11 17:10:43.650250
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    plugin = VarsModule()
    basedir = '/etc/ansible'
    fake_host = Host(name=C.DEFAULT_HOST_LIST)
    fake_host.vars = {'inventory_dir': '/etc/ansible', 'inventory_file': '/etc/ansible/hosts'}
    fake_host.set_variable('inventory_file', '/etc/ansible/hosts')
    plugin.set_options(basedir=basedir, entities=[fake_host])
    assert plugin.get_vars(loader=None, path=None, entities=fake_host) == {"test_var": True}
    # group
    fake_group = Group(name=C.DEFAULT_HOST_LIST)

# Generated at 2022-06-11 17:10:48.405416
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Parameters
    loader = None
    path = None
    entities = []
    cache = True
    VarsModule_obj = VarsModule()
    
    # VarsModule_obj.get_vars(loader, path, entities, cache)
    assert True == True



# Generated at 2022-06-11 17:10:58.427699
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.vars.host_group_vars import VarsModule
    from test.units.vars.test_host_group_vars import CustomYamlDumper
    old_dumper = AnsibleDumper
    AnsibleDumper = CustomYamlDumper
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars'))
    vm = VarsModule()

# Generated at 2022-06-11 17:11:06.277148
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    basedir = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../../../lib/ansible/plugins/vars'))
    inputs = [
            (basedir, 'host_vars', 'localhost'),
            (basedir, 'group_vars', 'all'),
            (basedir, 'host_vars', 'localhost'),
        ]
    expected_results = [
            {u'foo': u'bar'},
            {u'group_var': u'single_var'},
            {u'foo': u'bar'},
        ]

    vars_module = VarsModule()
    loader = C.get_config_loader()
    for idx, (basedir, subdir, entity) in enumerate(inputs):
        data = vars_

# Generated at 2022-06-11 17:12:13.978989
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Test that the get_vars method of the VarsModule class will successfuly return
    a variable or YAML or JSON variable files.
    '''

    class TestVarsModule(VarsModule):
        pass

    class TestHost(Host):
        def __init__(self, name):
            super(TestHost, self).__init__(name, None)

    class TestGroup(Group):
        def __init__(self, name):
            super(TestGroup, self).__init__(name, None)


    vars_module = TestVarsModule()

    assert vars_module.get_vars(vars_module, '', TestHost("test_host")) == {}

    assert vars_module.get_vars(vars_module, '', TestGroup("test_group")) == {}

# Generated at 2022-06-11 17:12:24.149797
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    global FOUND

    # ---
    test_name = "setUp"
    calling_class = 'VarsModule'
    calling_method = 'get_vars'
    test_desc = 'FOUND must be an empty dict'
    test_result = str(FOUND)
    #
    print('{0} - {1}, calling {2} - {3}'.format(calling_class, calling_method, test_name, test_desc))
    assert test_result == '{}', test_result
    # ---

    class FakeLoader(object):
        def __init__(self):
            self.cache = False

        def find_vars_files(self, path, entity_name):
            found_files = []

# Generated at 2022-06-11 17:12:25.323009
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO
    pass


# Generated at 2022-06-11 17:12:26.070598
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-11 17:12:37.462526
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Unit test for method get_vars of class VarsModule
    '''
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    variable_manager = vars_loader.VariableManager()
    variable_manager.extra_vars = {'a': 1}

    basedir = './test/test_data/test_host_group_vars_plugin/'
    loader = vars_loader.VarsModule()
    data = loader.get_vars(variable_manager, basedir, Host('host1'), False)
    assert isinstance(data, MutableMapping)
    assert data['a'] == 1

# Generated at 2022-06-11 17:12:39.327031
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO: Create unit test of method get_vars of class VarsModule
    pass

# Generated at 2022-06-11 17:12:48.548858
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    basedir = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, 'plugins', 'inventory', 'test_data')
    loader = None
    path = ''
    cache = True
    # return value
    expected = {'host_specific_var': 1, 'host_specific_var_2': 2}

    # create entity
    entity = Host(name="localhost")
    entities = [entity]

    # create object, init and call get_vars method
    vars_module = VarsModule()
    vars_module._basedir = basedir
    vars_module.get_vars(loader, path, entities, cache)

    # get vars files

# Generated at 2022-06-11 17:12:59.273577
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.vault import VaultLib
    import collections
    import os
    import tempfile
    import shutil
    import ansible.plugins.vars.host_group_vars
    import ansible.plugins.vars.vault

    def create_and_write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def create_vaulted_vars_file(path, vault_password, host_vars):
        host_vars = '---\n' + host_vars
        vault = VaultLib(vault_password)
        host_vars = vault.encrypt(host_vars)
        create_and_write_file(path, host_vars)
