

# Generated at 2022-06-21 07:40:41.296315
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # prepare some test environment
    # set env
    os.environ['ANSIBLE_VARS_PLUGIN_STAGE'] = 'default'

    # init vars module
    vars_module = VarsModule()
    # set base dir
    vars_module._basedir = """../../tests/integration/inventory/dir_layout/group_vars_host_vars"""
    # init data
    data = dict()
    # set host name
    host_name = "some_host"

    # init mock host object
    host = Host()
    host.name = host_name

    # init mock loader object
    loader = VarsModule()

    # expected result
    expected_data = dict()
    expected_data["test_var"] = 42
    expected_data["test_var2"] = "foo"


# Generated at 2022-06-21 07:40:45.289280
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Create an instance of class VarsModule
    plugin = VarsModule()

    # Verify that the class has the needed attributes
    assert hasattr(plugin, 'get_vars')

# Generated at 2022-06-21 07:40:53.591038
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import json
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from units.mock.loader import DictDataLoader

    # Test the content of group_vars/all
    group_vars_all_content = {"group_vars_all_key1": "group_vars_all_value1",
                              "group_vars_all_key2": "group_vars_all_value2",
                              "group_vars_all_key3": "group_vars_all_value3"}
    # Test the content of group_vars/group_all
   

# Generated at 2022-06-21 07:41:04.342852
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.vars import get_vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import shutil
    import tempfile

    _loader = DataLoader()
    _inventory = InventoryManager(loader=_loader, sources='')
    class DummyGroup(object):
        pass

    class DummyHost(object):
        pass

    plugin = VarsModule()
    # create a temp directory to store group_vars and host_vars
    tmp_path = tempfile.mkdtemp()
    group_vars_path = os.path.join(tmp_path, 'group_vars')
    os.mkdir(group_vars_path)

# Generated at 2022-06-21 07:41:14.298589
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import combine_vars

    class FakeLoader(object):
        def __init__(self):
            self.data = {}
            self.basedir = './'
            #self.vault_password = vault_password
            #self.stream = stream

        def load(self, path, cache=False):
            return self.data[path]

        def load_from_file(self, path, cache=True, accept_alternate=False, unsafe=False):
            return self.load(path, cache)


# Generated at 2022-06-21 07:41:24.455755
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import json
    import yaml
    fake_dir = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", "..", "test", "units", "vars_plugins"))
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["{0}/hosts".format(fake_dir)])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # The "hostvars" variable is of type ansible.v

# Generated at 2022-06-21 07:41:27.667290
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' constructor for vars_plugins/host_group_vars.py '''
    obj = VarsModule()
    assert obj


# Generated at 2022-06-21 07:41:35.446493
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    class TestUnsafeLoader(object):
        def __init__(self):
            self.files = []

        def add_file(self, filename):
            self.files.append(filename)

        def find_vars_files(self, d, name):
            return self.files

        def load_from_file(self, fp, cache=True, unsafe=True):
            return {'loaded_file': fp}

    entity = Host('myhost')
    entities = [entity]
    loader = TestUnsafeLoader()
    loader.add_file('/some/basedir/host_vars/myhost')
    vm = VarsModule()

    # test empty directories
    vm._basedir = '/dir/does/not/exist'

# Generated at 2022-06-21 07:41:44.510928
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host('test')
    group = Group('test')
    path = '/tmp/ansible/sample_playbooks'
    entities = [host, group]
    cache = True
    basedir = '/tmp/ansible/sample_playbooks'
    valid_extensions = ['.yml', '.yaml', '.json']
    loader = {}
    loader['paths'] = {}
    loader['paths'] = ['/tmp/ansible/sample_playbooks']
    loader['_basedir'] = '/tmp/ansible/sample_playbooks'
    loader['_ext_fragment_loader'] = None
    loader['_get_file_contents'] = {}

# Generated at 2022-06-21 07:41:53.595599
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class_loader=[]
    class_entities=[]
    class_cache=[]
    class_path=[]
    class_loader.append('VarsModule')
    class_entities.append('Host')
    class_entities.append('Group')
    class_FOUND=[]
    class_cache.append(True)
    class_cache.append(False)
    class_path.append('test_data/test_host_vars')
    class_path.append('test_data/host_var_dir/host_vars/test_host_vars/generic/generic.yaml')
    class_path.append('test_data/test_group_vars')

# Generated at 2022-06-21 07:42:05.481706
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class FakeVarsModule(VarsModule):
        def __init__(self):
            super(FakeVarsModule, self).__init__()
        def get_option(self, k):
            return C.DEFAULT_HOST_LIST

    fakeVarsModule = FakeVarsModule()
    fakeVarsModule._basedir = "/tmp/vars"
    os.mkdir(fakeVarsModule._basedir)
    fd = os.open(os.path.join(fakeVarsModule._basedir, 'test_hostname_vars_test.yaml'), os.O_CREAT | os.O_TRUNC | os.O_WRONLY)
    os.write(fd, b"test_hostname:\n  foo: bar")
    os.close(fd)

# Generated at 2022-06-21 07:42:16.300000
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''In charge of testing correct functionality of class VarsModule method get_vars'''
    ###########################
    # Setup fixtures
    ###########################
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    entities = ['atest', 'btest']

    loader = DataLoader()

    variable_manager = InventoryManager(loader=loader, sources=['/tmp/test_inventory'])

    ###########################
    # Setup mock objects
    ###########################
    class MockHost(object):
        '''Mock object representing class Host'''
        def __init__(self, name):
            self.name = name

    mock_host = MockHost('test')
    vm = VarsModule()

# Generated at 2022-06-21 07:42:17.660170
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module

# Generated at 2022-06-21 07:42:18.525809
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:42:25.617983
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """Unit test for method get_vars of class VarsModule
    """
    varsplugin = VarsModule()

    # Test case 1: entity is not a Host or a Group, should fail
    loader = None
    path = "host_vars"
    entity = 123
    try:
        varsplugin.get_vars(loader, path, entity, cache=True)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("Should have raised an AnsibleParserError")


    # Test case 2: entity is a Host, check if the dictionary returned is
    # correctly parsed
    loader = VarsModule()
    path = "host_vars"

# Generated at 2022-06-21 07:42:29.789347
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars = VarsModule()
    assert isinstance(vars, BaseVarsPlugin)
    assert vars._valid_extensions == [".yml", ".yaml", ".json"]

# Generated at 2022-06-21 07:42:40.816000
# Unit test for constructor of class VarsModule
def test_VarsModule():
    class Fake_Host():
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name
    h = Fake_Host(name = "host1")
    g = Fake_Host(name = "group1")
    from ansible.plugins.loader import vars_loader
    v = VarsModule()
    v.get_vars(vars_loader, "", h)
    v.get_vars(vars_loader, "", g)

if __name__ == '__main__':
    test_VarsModule()

# Generated at 2022-06-21 07:42:45.444917
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert isinstance(vm, VarsModule)


# Generated at 2022-06-21 07:42:55.842137
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class FakeLoader(object):
        def find_vars_files(self, path, entity_name):
            if entity_name == "vagrant" and path == "/etc/ansible/group_vars":
                return [
                    "/etc/ansible/group_vars/vagrant.yaml",
                    "/etc/ansible/group_vars/vagrant.yml",
                    "/etc/ansible/group_vars/vagrant.json"
                ]
            return []

        def load_from_file(self, fname, cache=True, unsafe=True):
            return {}

    loader = FakeLoader()

    host = Host("vagrant")
    group = Group("vagrant")

    v = VarsModule()
    v._display = object()

# Generated at 2022-06-21 07:43:00.477382
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert_msg = 'Invalid value for "get_vars" method'
    host = Host('localhost')
    group = Group('example_group')
    subdirs = ['group_vars', 'host_vars']
    vm = VarsModule()
    for item in [host, group]:
        for subdir in subdirs:
            vm.get_vars(None, None, item)

# Generated at 2022-06-21 07:43:19.308061
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import sys
    import imp

    # Needs to be done in order to get the correct directory where the modules are
    ansible_path = 'questions'
    path = imp.find_module(ansible_path)
    file, pathname, description = imp.find_module('test_modules_extra_vars')
    sys.path.append(os.path.dirname(pathname)+'/..')

    # Import the Ansible class
    from ansible.plugins.vars.base import BaseVarsPlugin
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Import the object TestVarsModule
    from test_modules_extra_vars import TestVarsModule

    # Create a TestVarsModule object
    tvm = TestVarsModule()

    # Create a Host

# Generated at 2022-06-21 07:43:20.183708
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule(None, '', None, None)

# Generated at 2022-06-21 07:43:27.944131
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    try:
        import __builtin__ as builtins  # Python 2
    except ImportError:
        import builtins  # Python 3

    import collections
    import mock
    import os

    class MockHost():
        def __init__(self, name):
            self.name = name

    class MockGroup():
        def __init__(self, name):
            self.name = name

    class MockBasedirLoader():

        def __init__(self):
            self.basedir = os.path.dirname(os.path.dirname(__file__))
            self.vars_folders = set()

        def find_vars_files(self, path, entity_name):

            self.vars_folders.add(os.path.join(self.basedir, path))

# Generated at 2022-06-21 07:43:33.907092
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins import vars_loader
    vars_loader.add_directory(C.DEFAULT_VARS_PLUGIN_PATH)

    for plugin in vars_loader.all():
        if plugin.startswith('host_group_vars'):
            pl = vars_loader.get(plugin)()
            assert(pl.__class__.__name__ == 'VarsModule')


if __name__ == '__main__':
    test_VarsModule()

# Generated at 2022-06-21 07:43:38.447985
# Unit test for constructor of class VarsModule
def test_VarsModule():
    module = VarsModule()

# Unit test (missing docstring for method) for get_vars(loader, path, entities, cache)

# Generated at 2022-06-21 07:43:39.955159
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert v is not None

# Generated at 2022-06-21 07:43:41.700931
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm is not None

# Generated at 2022-06-21 07:43:47.847095
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Create a tree with group_vars and host_vars directories
    os.makedirs('group_vars')
    os.makedirs('host_vars')

    # Create a file in host_vars
    filepath = os.path.abspath('host_vars/my_group')
    open(filepath, 'a').close()

    # Create the plugin
    C.INVENTORY_ENABLED = True
    C.VARS_PLUGIN_WHITELIST = ['*']
    VarsModule.REQUIRES_WHITELIST = False
    vars_module = VarsModule()

    # Create the paramaters needed for get_vars

# Generated at 2022-06-21 07:43:49.703434
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule is not None, 'VarsModule class is None'

# Generated at 2022-06-21 07:43:53.633116
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    assert vars_module.get_vars(None, None, None) == {}

# Generated at 2022-06-21 07:44:07.124504
# Unit test for constructor of class VarsModule
def test_VarsModule():
    pass

# Generated at 2022-06-21 07:44:08.484800
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO: how to test this kind of plugin?
    pass

# Generated at 2022-06-21 07:44:13.775579
# Unit test for constructor of class VarsModule
def test_VarsModule():
    """
    Basic constructor test
    """
    assert isinstance(
        VarsModule(
            loader=None,
            host=None,
            task=None,
            task_vars=dict(
                _variable_manager=None,
                _loader=None
            ),
            shared_plugin_path=None,
            namespace=None
        ),
        VarsModule
    )

# Generated at 2022-06-21 07:44:15.379675
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule.get_vars(loader, path, entities, cache=True)

# Generated at 2022-06-21 07:44:17.954586
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # can't import unit test everything here until get_vars is updated to not be static
    return True

# Generated at 2022-06-21 07:44:19.548532
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsModule = VarsModule()
    assert varsModule is not None

# Generated at 2022-06-21 07:44:28.142801
# Unit test for constructor of class VarsModule
def test_VarsModule():
    module = VarsModule()
    ansible = Ansible()
    ansible.inventory = InventoryManager(loader=DataLoader())
    ansible.vars = VarsManager()
    group = Group('test_group')
    group.vars = {'gvar': 'gvalue'}
    ansible.inventory.add_group(group)
    host = Host('test_host')
    host.vars = {'hvar': 'hvalue'}
    ansible.inventory.add_host(host)
    # check that the constructor does not fail
    module.get_vars(ansible.vars._loader, None, ansible.inventory.get_host(host.name), cache=False)

# Generated at 2022-06-21 07:44:39.600093
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()

# Generated at 2022-06-21 07:44:42.245783
# Unit test for constructor of class VarsModule
def test_VarsModule():
    import ansible.plugins.vars.host_group_vars.VarsModule
    assert isinstance(VarsModule(), BaseVarsPlugin)

# Generated at 2022-06-21 07:44:43.480860
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule() is not None

# Generated at 2022-06-21 07:45:20.220966
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class MockLoader():
        called = set()
        def find_vars_files(self, opath, entity_name):
            MockLoader.called.add('find_vars_files')
            if entity_name == "5":
                return ['group_vars/all/main.yaml', 'group_vars/5/main.yaml']
            if entity_name == "6":
                return ['group_vars/all/main.yaml', 'group_vars/6/main.yaml']
            return ['group_vars/all/main.yaml', 'group_vars/other/main.yaml']
        def load_from_file(self, found, cache=True, unsafe=False):
            MockLoader.called.add('load_from_file')
            data = {}

# Generated at 2022-06-21 07:45:31.915006
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a sample entity to use as argument in method get_vars
    class Host_test:
        def __init__(self, name):
            self.name = name
            self.vars = {}

    # Test when entity is a instance of Host
    obj_VarsModule = VarsModule()
    host = Host_test('test1')
    path = 'path/to/subdir/'
    entities = host
    result = obj_VarsModule.get_vars(None, path, entities)
    # Expected result is empty dict {}
    assert result == {}

    # Test when entity is a list containing an instance of group
    class Group_test:
        def __init__(self, name):
            self.name = name
            self.vars = {}
            self.groups = []

# Generated at 2022-06-21 07:45:34.586976
# Unit test for constructor of class VarsModule
def test_VarsModule():
    '''
    unit testing for class VarsModule
    '''
    vsm = VarsModule()
    assert vsm.get_vars(None, None, None) == {}

# Generated at 2022-06-21 07:45:35.322505
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:45:40.776886
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Creating fake ansible.inventory.host.Host object
    __fakeEntity = type('Host', (object,), {'name': 'foo'})
    __instance = VarsModule()
    # Calling get_vars method
    __instance.get_vars(loader=None, path=None, entities=__fakeEntity, cache=True)

# Generated at 2022-06-21 07:45:42.905584
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert isinstance(VarsModule(), BaseVarsPlugin)
    assert VarsModule.REQUIRES_WHITELIST


# Generated at 2022-06-21 07:45:48.507266
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.parsing.splitter import parse_kv

    results = VarsModule()

    assert isinstance(results, VarsModule)
    assert isinstance(results.vars, dict)
    assert results.vars == {}

    results = VarsModule()
    results.vars = parse_kv("TEST_VAR=TEST_VALUE")

    assert isinstance(results.vars, dict)
    assert results.vars == {"TEST_VAR": "TEST_VALUE"}

# Generated at 2022-06-21 07:46:00.346457
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    #test basic functionality for host vars
    msg = "`get_vars` should return data loaded from host vars file"
    loader = DictDataLoader({'/etc/ansible/host_vars/test': """
      first_var: "first var value"
    """})
    host = Host('test')
    result = VarsModule().get_vars(loader, '.', host)
    assert result['first_var'] == 'first var value', msg

    #test basic functionality for group vars
    msg = "`get_vars` should return data loaded from group vars file"
    loader = DictDataLoader({'/etc/ansible/group_vars/test': """
      second_var: "second var value"
    """})
    group = Group('test')

# Generated at 2022-06-21 07:46:13.028794
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Test that the method VarsModule.get_vars() returns the expected data.
    '''
    # When we test this plugin, any files with a YAML extension in the inventory
    # will be parsed. We don't want to see any warnings about the file not
    # being parsed so we are going to set an environment variable that tells
    # the code to parse YAML files.
    os.environ['ANSIBLE_YAML_FILENAME_EXT'] = 'yaml'

    # For this test we are going to create a few dummy files and directories
    # that we can use to test the get_vars() method.
    #
    # The first file will be a YAML file that we expect to be parsed.

# Generated at 2022-06-21 07:46:15.123239
# Unit test for constructor of class VarsModule
def test_VarsModule():
    c = C()
    v = VarsModule(c)
    assert v._valid_extensions == [".yml", ".yaml", ".json"]

# Generated at 2022-06-21 07:47:08.143267
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsModule = VarsModule()
    assert varsModule is not None


# Generated at 2022-06-21 07:47:10.237968
# Unit test for constructor of class VarsModule
def test_VarsModule():
    plugin = VarsModule()
    assert plugin

# Generated at 2022-06-21 07:47:12.126285
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert isinstance(vm, VarsModule)
    return vm


# Generated at 2022-06-21 07:47:14.535736
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert(v.REQUIRES_WHITELIST)

# Generated at 2022-06-21 07:47:25.555705
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Create a mock loader object.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-21 07:47:26.813039
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert v

# Generated at 2022-06-21 07:47:27.487126
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:47:29.923075
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsModule = VarsModule()
    assert varsModule.get_vars(None, None, None) is None

# Generated at 2022-06-21 07:47:32.830226
# Unit test for constructor of class VarsModule
def test_VarsModule():
    args = ['/path/to/base_dir']
    obj = VarsModule(*args)
    assert obj._basedir == '/path/to/base_dir'


# Generated at 2022-06-21 07:47:33.408848
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule

# Generated at 2022-06-21 07:49:17.565742
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = DictDataLoader({})
    vars_module = VarsModule()
    vars_module._basedir = "./test_VarsModule_get_vars_base"

    os.makedirs("./test_VarsModule_get_vars_base/group_vars")
    os.makedirs("./test_VarsModule_get_vars_base/host_vars")
    os.makedirs("./test_VarsModule_get_vars_base/group_vars/group1")
    os.makedirs("./test_VarsModule_get_vars_base/group_vars/group2")
    os.makedirs("./test_VarsModule_get_vars_base/host_vars/host1")
    os.m

# Generated at 2022-06-21 07:49:30.264456
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import ansible.plugins.loader as plugin_loader
    import ansible.vars.manager

    # Mock AnsibleVars object to return the values for the merged vars
    class MockVars(ansible.vars.manager.AnsibleVars):
        def get_vars(self, loader, path, entities, cache=True):
            return dict()

    # Mock AnsibleLoader to return an instance of MockVars
    class Loader(plugin_loader.PluginLoader):
        def __init__(self, class_name):
            try:
                self._plugin_class = plugin_loader.find_plugin(class_name, plugins=C.VARS_PLUGIN_CLASSES)
            except ansible.errors.AnsibleError as e:
                raise ansible.utils.plugin_docs.DocCLI.parse_error

# Generated at 2022-06-21 07:49:37.403614
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os.path
    import sys
    import unittest
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from collections import namedtuple
    from ansible.plugins.vars import BaseVarsPlugin

    SubMock = namedtuple('SubMock', ['name'])
    BaseMock = namedtuple('BaseMock', ['basedir'])
    HostMock = namedtuple('HostMock', ['name'])
    GroupMock = namedtuple('GroupMock', ['name'])
    LoaderMock = namedtuple('LoaderMock', ['find_vars_files', 'load_from_file'])

    #########################################################
    # Mock

    class VarsModuleMock(VarsModule):
        def __init__(self):
            self

# Generated at 2022-06-21 07:49:48.195544
# Unit test for constructor of class VarsModule
def test_VarsModule():
    b_cwd = os.getcwd()
    b_path = os.path.join(b_cwd, b'host_vars')
    b_correct_path = os.path.join('/', b_path[1:])

    host = Host(name='test')
    vars_module = VarsModule(b_cwd)
    # test get_vars with path exists
    a = vars_module.get_vars(vars_module, path=b_path, entities=host)
    assert vars_module.get_vars(vars_module, path=b_correct_path, entities=host) == a
    # test get_vars with path doesn't exist
    assert vars_module.get_vars(vars_module, path='/test', entities=host) == {}

# Generated at 2022-06-21 07:49:53.233348
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins.vars import _get_var_loader
    from ansible.parsing.dataloader import DataLoader
    plugin = VarsModule()
    loader = DataLoader()
    vars_loader = _get_var_loader(loader)
    plugin._basedir = os.path.realpath('../')
    host = Host(name='localhost')
    plugin.get_vars(vars_loader, '../', host)

if __name__ == '__main__':
    test_VarsModule()

# Generated at 2022-06-21 07:49:54.138863
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:49:55.989318
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    if not isinstance(v, VarsModule):
            raise Exception("Failed")

# Generated at 2022-06-21 07:49:57.535167
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, VarsModule)

# Generated at 2022-06-21 07:49:59.729447
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm is not None, "VarsModule is not instantiated"

# Generated at 2022-06-21 07:50:10.171880
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # set up a mock inventory
    class MockHost:
        def __init__(self, name, variables):
            self.name = name
            self.variables = variables

    class MockGroup:
        def __init__(self, name, variables):
            self.name = name
            self.variables = variables

    class MockInventory:
        def __init__(self, groups, host_list):
            self.hosts = host_list
            self.groups = groups
            self.get_host = lambda name: host_list[name]