

# Generated at 2022-06-21 07:40:31.793539
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # test defaults
    v = VarsModule()
    assert v.stage == 'vars'
    assert v.REQUIRES_WHITELIST is True
    assert v.priority == 128
    assert v._options == {'_valid_extensions': ['.yml', '.yaml', '.json']}


# Generated at 2022-06-21 07:40:39.499140
# Unit test for constructor of class VarsModule
def test_VarsModule():
    """
    Unit test for the constructor
    :return:
    """
    print("Constructor:")
    # because of the decorator, we need a dummy class to be able to instantiate the class
    class DummyModule(VarsModule):
        pass
    instance = DummyModule()
    print(instance)
    print()

if __name__ == '__main__':
    test_VarsModule()
    sys.exit(0)

# Generated at 2022-06-21 07:40:42.521065
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars = VarsModule()
    vars._basedir = '/home'
    vars.get_vars()

# Generated at 2022-06-21 07:40:43.043914
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule

# Generated at 2022-06-21 07:40:46.443811
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vsm = VarsModule()
    print(vsm.get_vars(None, None, None))


# Generated at 2022-06-21 07:40:48.124083
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsModule = VarsModule()
    assert varsModule

# Generated at 2022-06-21 07:40:59.435253
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    assert FOUND == {}

    entities = ['myhost', 'mygroup']
    loader = 'myobject'
    path = 'myinventory'
    cache = 'mycache'

    # Create instance of class
    testobj = VarsModule()
    assert testobj
    assert isinstance(testobj, VarsModule)

    # Call method
    rval = testobj.get_vars(loader, path, entities, cache)
    assert rval == {}

    # Call method
    rval = testobj.get_vars(loader, path, 'mygroup', cache)
    assert rval == {}

# Generated at 2022-06-21 07:41:12.218990
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    # Testing host_vars plugin
    host_vars_plugin = VarsModule()
    host_vars_plugin.get_vars(loader, '', [])
    # Testing group_vars plugin
    group_vars_plugin = VarsModule()
    group_vars_plugin.get_vars(loader, '', [])
    # Testing if the method get_vars of group_vars plugin is working properly
    group_vars_plugin = VarsModule()
    groups = InventoryManager(loader=loader, sources=['test/group_vars_plugin/hosts']).groups
    group_vars

# Generated at 2022-06-21 07:41:13.652210
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule(None)

# Generated at 2022-06-21 07:41:14.894678
# Unit test for constructor of class VarsModule
def test_VarsModule():
    VarsModule()

# Generated at 2022-06-21 07:41:19.942848
# Unit test for constructor of class VarsModule
def test_VarsModule():
    VarsModule()

# Generated at 2022-06-21 07:41:28.584092
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Instantiate a Host named 'host1'
    entity = Host('host1')

    # Create a VarsModule object
    vm = VarsModule()

    # There should be no errors
    try:
        # Call the get_vars method of VarsModule object
        vm.get_vars(None, None, entity)
    except Exception as e:
        print(to_native(e))
        return False
    return True



# Generated at 2022-06-21 07:41:41.948385
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.tests.unit.vars.snippets.vars_module import test_VarsModule_get_vars_data

    # load test data
    data = test_VarsModule_get_vars_data()
    # prepare group instance
    group = Group()
    group.name = "test_group"
    group.vars = {"var_group": "value_group"}
    # prepare host instance
    host = Host(name="test_host")
    host.vars = {"var_host": "value_host"}

    # create vars module instance
    vars_module = VarsModule()
    # set basedir
    basedir = "./test_VarsModule_get_vars_files"
    vars_module._basedir = basedir

    # load vars from vars module


# Generated at 2022-06-21 07:41:43.611138
# Unit test for constructor of class VarsModule
def test_VarsModule():
    myvars = VarsModule()
    assert myvars



# Generated at 2022-06-21 07:41:47.132592
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsModule = VarsModule()
    data = varsModule.get_vars()
    assert len(data) == 0, data

# Generated at 2022-06-21 07:41:57.194022
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    entities = ['test_host', 'test_group']
    loader = {}
    cache = True

    class AnsibleParserError:
        pass
    
    class BaseVarsPlugin:
        pass

    class VarsModule(BaseVarsPlugin):
        REQUIRES_WHITELIST = True

        def __init__(self):
            self._basedir = './test'

        def get_vars(self, loader, path, entities, cache=True):
            data = {}
            for entity in entities:
                if entity == 'test_host':
                    subdir = 'host_vars'
                else:
                    subdir = 'group_vars'

# Generated at 2022-06-21 07:41:59.268674
# Unit test for constructor of class VarsModule
def test_VarsModule():
    tmp = VarsModule()
    assert tmp


# Generated at 2022-06-21 07:41:59.975085
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:42:11.702290
# Unit test for constructor of class VarsModule
def test_VarsModule():

    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader

    class TestVarsModule(VarsModule):
        """Test class to make constructor visible"""

        def __init__(self):
            super(TestVarsModule, self).__init__()

    class TestLoader(DataLoader):

        def __init__(self):
            super(TestLoader, self).__init__()
            self.collection_loader = AnsibleCollectionLoader()

    module = TestVarsModule()
    loader = TestLoader()
    module.get_vars(loader, "", Host("test"), cache=True)

# Generated at 2022-06-21 07:42:13.670915
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm


# Generated at 2022-06-21 07:42:24.474017
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class Entity():
        def __init__(self, name):
            self.name = name

    # no.1: test case
    def find_vars_files(opath, entity_name):
        if opath == './group_vars':
            return ['./group_vars/all', './group_vars/abc']
        else:
            return ['./host_vars/xyz']

    class Loader_mock():
        def load_from_file(self, var_file, cache=True, unsafe=True):
            with open(var_file, 'r') as fp:
                return fp.read()

        def find_vars_files(self, opath, entity_name):
            return find_vars_files(opath, entity_name)


# Generated at 2022-06-21 07:42:31.920588
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = DummyLoader()
    path = './'
    host = Host(name='localhost')
    group = Group(name='web')
    entities = [host, group]
    vars_module = VarsModule()
    vars_module._loader = loader
    vars_module._basedir = path
    vars_module.get_vars(loader, path, entities)


# Generated at 2022-06-21 07:42:34.539427
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' test the constructor, basically to make sure it doesn't throw exceptions '''
    VarsModule()

# Generated at 2022-06-21 07:42:44.009461
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
       vars_module = VarsModule()
       loader = C.DEFAULT_LOADER_CLASS()

       b_opath = os.path.realpath(to_bytes(os.path.join(os.getcwd(), 'host_vars')))
       opath = to_text(b_opath)
       key = 'host_vars.%s' % opath
       found_files = []

       # load vars
       if os.path.exists(b_opath):
           if os.path.isdir(b_opath):
               found_files = loader.find_vars_files(opath, 'host_vars')
           # else:
           #     self._display.warning("Found %s that is not a directory, skipping: %s" % (subdir, opath))


# Generated at 2022-06-21 07:42:50.643562
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ansible_vars_plugin_stage = 'setup'

    ansible_yaml_filename_ext = [
        ".yml",
        ".yaml",
        ".json"]

    # Testing for the case when path is a file
    loader = 'load_vars'
    path = 'tests/test_group_vars/group_vars/test_group'

    # Testing for the case when path is a directory
    #path = 'tests/test_group_vars/group_vars/'

    # Testing for the case when path is an invalid path
    #path = 'tests/test_group_vars/group_vars/test_group/'

    # Initializing an instance of class Host

# Generated at 2022-06-21 07:43:03.471989
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader, find_vars_files

    from ansible.plugins.vars.host_group_vars import VarsModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = vars_loader
    path = 'test/unit/vars_plugin/group_vars/test_inventory_path'
    host = Host(name='test_inventory_path')
    entities = [host]
    # create group_vars and host_vars directory in group_vars/test_inventory_path
    if not os.path.exists(path):
        os.makedirs(path)
    os.makedirs(os.path.join(path, 'group_vars'))

# Generated at 2022-06-21 07:43:16.866781
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    import yaml
    from ansible.module_utils.six import PY3

    if not PY3:
        from ansible.inventory.data import InventoryData
        from ansible.parsing.vault import VaultLib
        from ansible.plugins.vars import BaseVarsPlugin
        from ansible.module_utils.six import StringIO
    else:
        from ansible.inventory.data import InventoryData
        from ansible.parsing.vault import VaultLib
        from ansible.plugins.vars import BaseVarsPlugin
        from io import StringIO


# Generated at 2022-06-21 07:43:18.024010
# Unit test for constructor of class VarsModule
def test_VarsModule():
    a = VarsModule()
    assert(a)



# Generated at 2022-06-21 07:43:27.776277
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    test_VarsModule_get_vars: Test if vars are correctly loaded from file.
    '''
    # Test with a host, the vars should be loaded from host_vars/ directory
    plugin = VarsModule()
    host = Host('localhost')
    data = plugin.get_vars(None, None, host)
    assert data == {u'answer': 42}

    # Test with a group, the vars should be loaded from group_vars/ directory
    plugin = VarsModule()
    host = Group('testgroup')
    data = plugin.get_vars(None, None, host)
    assert data == {u'answer': 42}

# Generated at 2022-06-21 07:43:28.640792
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vmodule = VarsModule()


# Generated at 2022-06-21 07:43:49.198606
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Run VarsModule constructor
    v = VarsModule()

    # Check if the object v is created successfully
    assert v is not None

    # Check the attributes of class VarsModule
    assert hasattr(v, 'vars')
    assert hasattr(v, '_valid_extensions')
    assert hasattr(v, '__doc__')
    assert hasattr(v, 'cache_key')
    assert hasattr(v, 'REQUIRES_WHITELIST')
    assert hasattr(v, 'get_vars')
    assert hasattr(v, 'get_host_vars')
    assert hasattr(v, 'get_group_vars')
    assert hasattr(v, '_load_list_of_blocks')

# Generated at 2022-06-21 07:43:54.697093
# Unit test for constructor of class VarsModule
def test_VarsModule():
    host = Host()

    plugin = VarsModule()
    plugin.get_vars(loader=None, path=None, entities=host)
    assert(plugin.get_vars(loader=None, path=None, entities=[host, host]).get('_ansible_is_chroot'))

# Generated at 2022-06-21 07:44:00.190107
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # first get the basetest functionality
    obj = BaseVarsPlugin()
    # get a new copy of VarsModule
    obj1 = VarsModule()

    # test all the attributes of VarsModule
    assert obj1._basedir is None
    assert obj1._display is obj._display
    assert obj1.get_vars is not None

# Generated at 2022-06-21 07:44:01.162382
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert issubclass(VarsModule, BaseVarsPlugin)

# Generated at 2022-06-21 07:44:04.459614
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Create a VarsModule object without an argument for path.
    vars_module = VarsModule()

    # Verify that the path is not set.
    assert vars_module._basedir is None

    # Create a VarsModule object with a path argument.
    vars_module = VarsModule(path='/some/path')

    # Verify that the path is now set to the value passed in.
    assert vars_module._basedir == '/some/path'

# Generated at 2022-06-21 07:44:15.768665
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.dataloader import DataLoader

    class FakeEntity:
        def __init__(self, name):
            self.name = name

    class FakeModule:
        def __init__(self, basedir):
            self._basedir = basedir
            self.vars_loader = vars_loader

        def get_basedir(self):
            return self._basedir

    basedir = "/tmp/host_group_vars_test"
    if os.path.isdir(basedir):
        os.removedirs(basedir)
    os.makedirs(basedir)

    os.makedirs(os.path.join(basedir, "host_vars"))

# Generated at 2022-06-21 07:44:26.436915
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """Test VarsModule._get_vars() for simple case"""
    vars1_dict = {'test1': 'test1'}
    vars2_dict = {'test2': 'test2'}
    vars3_dict = {'test3': 'test3'}
    vars4_dict = {'test4': 'test4'}
    vars5_dict = {'test5': 'test5'}
    vars6_dict = {'test6': 'test6'}
    vars7_dict = {'test7': 'test7'}

    vars_module = VarsModule()
    vars_module._display = Display()

    # Instantiate a dummy test file finder, setting base dir to '.' and finding
    # fake files in the hierarchy below

# Generated at 2022-06-21 07:44:29.319220
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' constructor test '''
    v = VarsModule()
    assert v.get_vars(None, C.DEFAULT_HOST_LIST, None) == {}

# Generated at 2022-06-21 07:44:40.461519
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    real_path = "inventory/plugins/host_group_vars/test_data"
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["%s/hosts" % (real_path)])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # get vars for host: test2.example.com
    vars_obj = VarsModule(variable_manager=variable_manager)
    vars_obj.vars_plugins = []
    vars_obj._basedir = real_path
    hostname = "test2.example.com"

# Generated at 2022-06-21 07:44:44.125094
# Unit test for constructor of class VarsModule
def test_VarsModule():
    """Unit test for constructor of class VarsModule"""
    # test if correct object is created
    assert isinstance(VarsModule(), VarsModule)


# Generated at 2022-06-21 07:45:15.508185
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # setup
    test_subject = VarsModule()
    entities = [Host('host_1'), Group('group_1')]
    path = '/path/to/hosts'
    loader = {}

    # when
    result = test_subject.get_vars(loader, path, entities)

    # then
    assert result == {}

# Generated at 2022-06-21 07:45:16.087125
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert True

# Generated at 2022-06-21 07:45:19.026123
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # pylint: disable=missing-docstring
    # pylint: disable=too-many-arguments
    module = VarsModule()

    assert module.get_vars(None, None, None) == {}

# Generated at 2022-06-21 07:45:23.445137
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()

    # Test 1: Test get_vars for Host
    host = Host('testhost')
    test_vars = v.get_vars(loader=None, path="/path", entities=host)
    assert test_vars == {}

    # Test 2:  Test get_vars for Group
    group = Group('testgroup')
    test_vars = v.get_vars(loader=None, path="/path", entities=group)
    assert test_vars == {}

# Generated at 2022-06-21 07:45:35.474279
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible import context
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import AnsibleVars

    import pytest
    import os

    # Create toy inventory
    current_directory = os.path.dirname(os.path.realpath(__file__))
    toy_inventory_path = os.path.join(current_directory, 'toy_inventory')

# Generated at 2022-06-21 07:45:40.928564
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()
    assert v._valid_extensions == ['', '.yml', '.yaml', '.json'], '_valid_extensions should be [".yml", ".yaml", ".json"]'
    assert v.get_vars(None, None, [Host(name='localhost'), Group(name='group_name')]) == {}

# Generated at 2022-06-21 07:45:41.898360
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsmodobj = VarsModule()

# Generated at 2022-06-21 07:45:50.197236
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import json
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    class TestVarsModule(VarsModule):
        pass

    cwd = os.path.dirname(os.path.abspath(__file__))
    group_vars_dir = os.path.join(cwd, "group_vars")
    host_vars_dir = os.path.join(cwd, "host_vars")
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=cwd)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    v = TestVarsModule()
    v.enable_extensions = True


# Generated at 2022-06-21 07:46:01.431194
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.host import Host
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars

    host1 = Host('host1', True)
    host2 = Host('host2', True)
    host3 = Host('host3', True)

    varsModule = VarsModule()
    varsModule.set_options({'vars_host_group_vars.stage': 'tasks'})
    varsModule.set_runner(None)

    # Test with cached data
    test_data = varsModule.get_vars(vars_loader, '/base/dir/', host1, True)
    assert test_data == {
        'aa': '1',
        'bb': '2'
    }

    test_data = varsModule

# Generated at 2022-06-21 07:46:13.699664
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import unittest
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    VarsModule.requires_whitelist = False

    class TestVarsModule(unittest.TestCase):

        def setUp(self):
            self.test_vars_module = VarsModule()

        def tearDown(self):
            pass


# Generated at 2022-06-21 07:46:44.212949
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = C.plugin_loader
    path = './'
    host = Host('localhost', None, None, None)
    vars = VarsModule(loader)
    vars.get_vars(loader, path, host, cache=True)

# Generated at 2022-06-21 07:46:45.986706
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module is not None, "VarsModule object was not created"

# Generated at 2022-06-21 07:46:52.392348
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module.REQUIRES_WHITELIST is True
    assert vars_module.get_vars(loader=None, path=None, entities=None) is None
    assert vars_module.get_vars(loader=None, path=None, entities=None, cache=False) is None

# Generated at 2022-06-21 07:46:54.912034
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert isinstance(vars_module, VarsModule)
    assert not isinstance(vars_module, Group)
    assert not isinstance(vars_module, Host)

# Generated at 2022-06-21 07:47:07.117617
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    basedir = "/Users/michael/dev/ansible/playbooks/files/host_group_vars_test"
    os.makedirs(basedir + "/host_vars/foo")
    os.makedirs(basedir + "/group_vars/foo_group")
    open(basedir + "/host_vars/foo/foo.yaml", "w").close()
    open(basedir + "/group_vars/foo_group/foo_group.yaml", "w").close()
        
    plugin = VarsModule()
    plugin._basedir = basedir
    vars = plugin.get_vars(None, None, [Host(name="foo")])
    assert vars["foo"] == { "ansible_facts": {} }

# Generated at 2022-06-21 07:47:11.730020
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    loader = None  # needs to be defined
    path = None  # needs to be defined
    entities = []
    cache = True
    chdir = C.DEFAULT_LOCAL_TMP
    ansible_config = None
    vars = VarsModule(loader, path, entities, cache, chdir, ansible_config)
    assert vars.get_vars(loader, path, entities, cache) == {}

# Generated at 2022-06-21 07:47:23.569073
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    test_loader = DataLoader()

    test_group = Group()
    test_group.name = 'foo'
    test_group.inventory = InventoryManager(loader=test_loader)

    test_host = Host()
    test_host.name = 'bar'
    test_host.inventory = InventoryManager(loader=test_loader)

    test_VarsModule = VarsModule()

    test_VarsModule._basedir = '.'
    test_VarsModule._display = 'none'
    test_VarsModule._loader = test_loader

    test_VarsModule.get_vars('', '', test_group)

# Generated at 2022-06-21 07:47:34.701579
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule.REQUIRES_WHITELIST = False
    # Test start_at_task flag
    C.DEFAULT_UNSAFE_LEVEL = 2
    VarsModule.stage = "vars_host_group_vars"
    assert VarsModule.get_vars(1, './test/',
                               [Group('ansible')]) == {'group_name': 'ansible'}
    assert VarsModule.get_vars(1, './test/',
                               [Host('host1')]) == {'host_name': 'host1'}

    # Test start_at_task flag
    C.DEFAULT_UNSAFE_LEVEL = 2
    VarsModule.stage = "vars_host_group_vars"

# Generated at 2022-06-21 07:47:41.558132
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import yaml
    import time

    # Make a temp directory
    tmpdir = tempfile.mkdtemp()

    # Write group_vars/all
    group_vars_all_path = os.path.join(tmpdir, 'group_vars', 'all')
    os.makedirs(group_vars_all_path)
    group_vars_all_file = os.path.join(group_vars_all_path, 'file.yaml')
    with open(group_vars_all_file, 'w') as f:
        yaml.safe_dump(yaml.safe_load("""
all:
  var1: value1
  var3: value3
"""), f)

    #

# Generated at 2022-06-21 07:47:48.754486
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    obj = VarsModule()

    # Unit test when `entities` is a list
    entities = ['test_entities']
    get_vars = obj.get_vars('test_loader', 'test_path', entities)

    # Unit test when `entities` is not a list
    entities = 'test_entities'
    get_vars = obj.get_vars('test_loader', 'test_path', entities)

# Generated at 2022-06-21 07:48:53.888991
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Arrange
    basedir = '/path/to/basedir'
    entities = [Host('fqdn1'), Host('fqdn2')]

    # create fake loader object
    class FakeLoader:
        class FakeFileReader:
            def __init__(self):
                self.filename_with_empty_data = None
            def get_basedir(self):
                return basedir
            def all_vars(self, path, wrap_as_vars=False, filename_with_empty_data=None):
                # Assert
                # Check if the name of the file is being passed as an argument to method all_vars
                # of class FakeFileReader
                assert filename_with_empty_data == '/path/to/basedir/group_vars/fqdn2.yml'
                return {}


# Generated at 2022-06-21 07:48:59.742837
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Test trying to create VarsModule with bogus basedir
    try:
        varsModule = VarsModule('/bogus/basedir')
        assert False
    except:
        assert True

    # Test trying to create VarsModule with valid basedir
    varsModule = VarsModule('/home/testuser')
    assert True

# Generated at 2022-06-21 07:49:01.800347
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, VarsModule)

# Generated at 2022-06-21 07:49:12.211478
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    def mock_display_warning(msg):
        # This is not an asert, as display.warning really prints a warning,
        # this is only to get rid of a print while testing
        assert msg == "Found group_vars that is not a directory, skipping: /path/to/group_vars"

    def mock_find_vars_files(path, entity_name):
        if path == '/path/to/group_vars/group1':
            return ['file_g_group1']
        elif path == '/path/to/host_vars/server1':
            return ['file_h_server1']
        else:
            raise Exception("Unexpected find_vars_files arguments path: {}, entity_name: {}".format(path, entity_name))


# Generated at 2022-06-21 07:49:21.336059
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    source = '''
        [all:vars]
        ansible_connection=local

        [all]
        localhost
        '''

    # Initialize needed objects
    loader = DataLoader()
    inv_data = InventoryManager(loader=loader, sources=source)
    variable_manager = VariableManager(loader=loader, inventory=inv_data)

    # Initialize vars instance
    vars_module = VarsModule()
    vars_module.get_vars(loader, to_text(b'/tmp'), inv_data.groups.get('all').hosts[0])

    # Confirm that 'test_host_vars.yaml'

# Generated at 2022-06-21 07:49:28.921775
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins.loader import vars_loader

    vl = vars_loader.get('host_group_vars')
    vars_plugin = vl.get('host_group_vars', {}).get('class')
    vars_plugin = vars_plugin()

    assert_type = type(vars_plugin)
    assert assert_type == VarsModule, "parsed type is %s, should be VarsModule" % assert_type

# Generated at 2022-06-21 07:49:32.495329
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' Test cases for VarsModule constructor'''
    path = 'C:\\Users\\User1\\Desktop\\vars_host_group_vars.py'
    assert path == VarsModule.__module__


# Generated at 2022-06-21 07:49:33.705163
# Unit test for constructor of class VarsModule
def test_VarsModule():
    '''Unit test for constructor of class VarsModule'''
    VarsModule()

# Generated at 2022-06-21 07:49:34.489034
# Unit test for constructor of class VarsModule
def test_VarsModule():
    VarsModule()

# Generated at 2022-06-21 07:49:37.185907
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_obj = VarsModule()
    assert isinstance(vars_obj, VarsModule)
    assert isinstance(vars_obj, BaseVarsPlugin)