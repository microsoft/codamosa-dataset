

# Generated at 2022-06-21 07:40:41.346248
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a host
    host = Host(name='host')

    # Create a group
    group = Group(name='group')

    # Create a VarsModule object
    vars_module = VarsModule()

    # Create a loader
    loader = None

    # Test when the entity is a 'Host'
    path = "some/path"
    entities = host
    result = vars_module.get_vars(loader, path, entities)
    assert result == {}

    # Test when the entity is a 'Group'
    path = "some/path"
    entities = group
    result = vars_module.get_vars(loader, path, entities)
    assert result == {}

    # Test when the entity is not a 'Host' or a 'Group'
    path = "some/path"
    entities = 42


# Generated at 2022-06-21 07:40:52.160754
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader

    # Setup the class
    import tempfile
    dir = tempfile.mkdtemp()

    b_dir = to_bytes(dir)
    os.mkdir(os.path.join(b_dir, b'group_vars'))
    os.mkdir(os.path.join(b_dir, b'host_vars'))

    test_dirs = [dir]

    vars_m = VarsModule(test_dirs)

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(loader=vars_loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=vars_loader, inventory=inventory)

    group = Group('test')
    host

# Generated at 2022-06-21 07:40:53.280757
# Unit test for constructor of class VarsModule
def test_VarsModule():
    obj = VarsModule()
    assert isinstance(obj, VarsModule)
    assert isinstance(obj._basedir, basestring)

# Generated at 2022-06-21 07:41:04.206706
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Define paths for test
    basedir = "/tmp/ansible/unittest/"
    host_vars = basedir + "host_vars/"
    group_vars = basedir + "group_vars/"
    host_file_name = "host_vars.yml"
    group_file_name = "group_vars.yml"

    # Create tmp directory
    os.system("rm -rf " + basedir)
    os.makedirs(host_vars)
    os.makedirs(group_vars)

    # Create tmp file in the host_vars directory
    fh = open(host_vars + host_file_name, "w")
    fh.write("host_vars:\n")
    fh.write("  host_variables: foo\n")

# Generated at 2022-06-21 07:41:10.852599
# Unit test for constructor of class VarsModule
def test_VarsModule():
    class Obj(object):
        def __init__(self):
            self.extra_vars = dict()
            self.inventory = dict()
            self.basedir = dict()

    obj = Obj()
    obj.extra_vars = dict()
    obj.inventory = dict()
    obj.basedir = dict()
    obj.display = dict()

    val = VarsModule()
    val.get_vars(obj)

# Generated at 2022-06-21 07:41:14.425704
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module.__class__.__name__ == 'VarsModule'

# Generated at 2022-06-21 07:41:15.404938
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:41:24.316053
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Assumptions: test_ansible_path, basedir, groupname, hostname, subdir, an entity_type, a path exist
    # and a vars file is located in the path (with the extension .yaml or .json).

    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    newVarsModule = VarsModule()
    newVarsModule._basedir = 'test_ansible_path'
    newVarsModule._display.verbosity = 3
    newVarsModule.get_vars(loader, vars_loader, [entity_type(newVarsModule._basedir, groupname, hostname)])

# Generated at 2022-06-21 07:41:25.306016
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()

# Generated at 2022-06-21 07:41:34.259708
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    current_path = os.path.dirname(os.path.realpath(__file__))
    arguments = {'subdir': 'group_vars', 'basedir': current_path}
    assert VarsModule.get_vars(DataLoader(), os.path.join(current_path, 'group_vars/test.yml'), 'test', cache=True) == {}

    inventory_manager = InventoryManager(loader=DataLoader())
    inventory_manager.subset('test')
    inventory_manager.set_variable('all', 'plugin_dir', current_path)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)

# Generated at 2022-06-21 07:41:42.833015
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm

# Generated at 2022-06-21 07:41:49.774412
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    subdir = 'group_vars'
    cache = True
    entities = ["prod", "webservers", "foo:bar:baz"]

    class Host_():
        def __init__(self, name):
            self.name = name

    class Group_():
        def __init__(self, name):
            self.name = name

    objects_ = []
    for entity in entities:
        if entity.startswith('prod'):
            objects_.append(Host_(entity))
        else:
            objects_.append(Group_(entity))

    def find_vars_files(self, opath, entity):
        return ['host_vars/foo.yml', 'host_vars/bar', 'group_vars/baz.yml', 'group_vars/foo.yml']

   

# Generated at 2022-06-21 07:41:56.434643
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    hostname = "testhost"
    file_loader = VarsModule()
    assert file_loader.get_vars(file_loader, 'test_dir', hostname) == {}
    assert file_loader.get_vars(file_loader, 'test_dir', hostname, cache=False) == {}

# Generated at 2022-06-21 07:42:05.671893
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    this_dir, this_filename = os.path.split(__file__)
    path = os.path.join(this_dir, "vars_dir")

    loader = AnsibleLoader(path)
    vars_dir_module = VarsModule()

    entities = [ Host('dummy1') ]
    expected_data = {'vars': {'foo': 'bar'}}
    data = vars_dir_module.get_vars(loader, path, entities)
    assert data == expected_data, "Data returned by vars_dir_module.get_vars(loader, %s, %s) should equal %s, but got %s" % (to_text(path), to_text(entities), to_text(expected_data), to_text(data))


# Generated at 2022-06-21 07:42:16.807759
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class FakeInventory():
        def __init__(self):
           pass

        def search_groups(self):
            return [FakeGroup()]

        def search_hosts(self):
            return [FakeHost()]

    MockAvailableHost = MagicMock()
    MockAvailabaleGroup = MagicMock()
    MockAvailableGroup._variable_manager = Mock()
    MockAvailableHost._variable_manager = Mock()
    MockAvailableGroup._variable_manager._fact_cache = {}
    MockAvailableHost._variable_manager._fact_cache = {}

    FakeInventory.get_group = MockAvailabaleGroup
    FakeInventory.get_host = MockAvailableHost

    class FakeLoader():
        def __init__(self):
           pass


# Generated at 2022-06-21 07:42:25.086241
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-21 07:42:26.731952
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule.__doc__

# Generated at 2022-06-21 07:42:27.566042
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:42:35.917586
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    """Unit test for the VarsModule class and its method, get_vars."""

    # required
    loader = None
    path = '/root'
    entities = [Group('group1')]
    # optional, defaults to True
    cache = True
    # create instance
    vars_module_instance = VarsModule()
    vars_dict = vars_module_instance.get_vars(loader, path, entities, cache)
    # validate
    assert(type(vars_dict) is dict)
    assert('plugin_staging' in vars_dict)
    assert('group1' in vars_dict['plugin_staging'])

# Generated at 2022-06-21 07:42:36.705552
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()


# Generated at 2022-06-21 07:42:52.436959
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' host_group_vars.py:VarsModule.__init__() '''

    # No valid extensions
    x = VarsModule(None, [], [], [])
    assert x._valid_extensions == ['.yml', '.yaml', '.json']

    # With valid extensions
    x = VarsModule(None, [], [], ['.txt', '.yml'])
    assert x._valid_extensions == ['.yml', '.yaml', '.json', 'txt']

# Generated at 2022-06-21 07:43:04.756703
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # test 'host' entity - host_vars/ directory

    # create variant of Host class w/o realpath
    class Host_NoPath(Host):
        def _get_path(self, basedir):
            return basedir + '/host_vars'

    # create loader fixture
    class loader_fixture():
        def find_vars_files(self, path, entity_name):
            return [os.path.join(path, entity_name)]

        def load_from_file(self, path, cache=True, unsafe=True):
            with open(path, 'r') as f:
                return f.read()

    # create instance of VarsModule plugin
    test_plugin = VarsModule()

    # create instances of Host and Group
    test_host = Host_NoPath("example.com")

    # create

# Generated at 2022-06-21 07:43:06.215686
# Unit test for constructor of class VarsModule
def test_VarsModule():
    module = VarsModule()

    assert module is not None

# Generated at 2022-06-21 07:43:18.452442
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.parsing.dataloader import DataLoader
    class TestOption(object):
        def __init__(self):
            self.connection = 'ssh'
            self.module_path = ''
            self.forks = 30
            self.become = False
            self.become_method = 'sudo'
            self.become_user = None
            self.check = False
            self.diff = False
    class TestDisplay(object):
        def __init__(self):
            self._verbosity = 0
        def debug(self, msg):
            print(msg)
    c = TestOption()
    d = TestDisplay()
    data = DataLoader()
    vars = VarsModule(c,d)
    vars.get_vars(data, './', './', './')


# Generated at 2022-06-21 07:43:27.503670
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import vars_loader, get_all_plugin_loaders

    # load all the vars plugins
    loaders = get_all_plugin_loaders('vars')
    loader = vars_loader.VarsModuleLoader(loaders)

    # Create a vault password file
    vault_password = VaultLib([])
    vault_password.write_file('ansible')
    vault_password_file = os.path.abspath(os.path.join('test', 'unit', 'ansible_vault'))

    # Instanciate the plugin
    # For its unit test, the plugin

# Generated at 2022-06-21 07:43:28.845890
# Unit test for constructor of class VarsModule
def test_VarsModule():
    var = VarsModule()
    assert var

# Generated at 2022-06-21 07:43:38.192631
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # mock data
    test_vars_data = "{'test_var': 'test_val'}"
    test_entities = [Host('test'), Group('test_group')]

    from ansible.plugins.loader import vars_loader
    _loader = vars_loader
    _loader.get_vars_files = MagicMock(return_value=test_vars_data)

    # object creation
    test_vars_mod = VarsModule()
    test_vars_mod.get_vars(_loader, '', test_entities)

    # test if get_vars_files is called with the right params
    _loader.get_vars_files.assert_called_once()
    _loader.get_vars_files.assert_called_with('', 'test')

# Generated at 2022-06-21 07:43:43.842214
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars.host_group_vars import VarsModule
    assert isinstance(vars_loader.get('host_group_vars', None), VarsModule)

# Generated at 2022-06-21 07:43:47.479228
# Unit test for constructor of class VarsModule
def test_VarsModule():
    """
    Unit test for constructor of class VarsModule
    """
    os.environ['ANSIBLE_VARS_PLUGIN_STAGE'] = 'start'
    assert VarsModule(playbook=None, inventory=None, loader=None).stage == 'start'

# Generated at 2022-06-21 07:44:00.296969
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = ''
            self.forks = 5
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = ''
            self.ssh_extra_args = ''
            self.sftp_extra_args = ''
            self.scp_extra_args = ''
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'

# Generated at 2022-06-21 07:44:15.546450
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module is not None

# Generated at 2022-06-21 07:44:18.518784
# Unit test for constructor of class VarsModule
def test_VarsModule():
    config = {}
    inventory = []
    namespace = {}
    vm = VarsModule()
    vm.get_vars(config, inventory, namespace)

# Generated at 2022-06-21 07:44:22.463325
# Unit test for constructor of class VarsModule
def test_VarsModule():
    plugin_class = VarsModule

    # Test the constructor
    plugin_instance = plugin_class()

    assert plugin_instance._valid_extensions == [".yml", ".yaml", ".json"], "Unexpected valid_extensions value"

# Generated at 2022-06-21 07:44:26.327284
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Create test object
    obj = VarsModule()
    # Test get_vars
    # TODO: create a unittest as we do on test_vars.py
    return obj

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 07:44:28.387070
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host()
    VarsModule.get_vars(None, None, None, None)

# Generated at 2022-06-21 07:44:39.791995
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' unit test for VarsModule class constructor '''
    from ansible.plugins.loader import var_loader

    options = dict(
        inventory=C.DEFAULT_HOST_LIST,
        module_path=C.DEFAULT_MODULE_PATH,
        forks=C.DEFAULT_FORKS,
        become=False,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None,
        module_paths=C.DEFAULT_MODULE_PATH,
        verbosity=C.DEFAULT_VERBOSITY).copy()

    # NO ARGUMENTS

# Generated at 2022-06-21 07:44:44.921536
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # Test use cases for Host and Group classes
    host = Host("example", "example")
    group = Group("example")
    # with valid extension
    path = "/path/to/my/host_vars/example.yml"
    #host.
    # get_vars
    # without valid extension

# Generated at 2022-06-21 07:44:49.036046
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule.REQUIRES_WHITELIST == True
    assert VarsModule.REQUIRES_TMPPATH == False
    assert VarsModule.REQUIRES_CACHE == False



# Generated at 2022-06-21 07:44:50.216755
# Unit test for constructor of class VarsModule
def test_VarsModule():
  v = VarsModule()


# Generated at 2022-06-21 07:44:55.133328
# Unit test for constructor of class VarsModule
def test_VarsModule():
    #Test 'get_vars' method
    print('Testing VarsModule.get_vars')
    vars_module = VarsModule()
    vars_module.get_vars()

#test_VarsModule()



# Generated at 2022-06-21 07:45:34.169684
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 07:45:44.979970
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.inventory.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins import vars_plugins
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    inventory = Inventory(loader=None, host_list=[])
    play_context = Play().set_loader(None)
    templar = Templar(loader=None, variables=VariableManager())
    vars_plugins.add_directory("/home/mats/src/ansible/lib/ansible/plugins/vars")

    mod = VarsModule(play_context=play_context, new_stdin=None)
    assert mod.__class__


# Generated at 2022-06-21 07:45:46.205213
# Unit test for constructor of class VarsModule
def test_VarsModule():
    test_vars = VarsModule()
    assert isinstance(test_vars, VarsModule)


# Generated at 2022-06-21 07:45:49.254742
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' constructor '''
    obj = VarsModule()
    assert obj
    assert obj.get_vars

# Generated at 2022-06-21 07:45:53.063624
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()
    result = v.get_vars('loader.py', 'path', 'entities')
    assert result is None


# Generated at 2022-06-21 07:45:55.389461
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, VarsModule)
    assert isinstance(v, BaseVarsPlugin)


# Generated at 2022-06-21 07:46:04.108396
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # get_vars method is only intended for loading group_vars and host_vars
    # This simple test only checks loading of host_vars
    # I'm not aware of any way for a plugin to access data from the ansible inventory
    # so I'm not able to test loading group_vars

    # setting up test environment variables
    os.environ['ANSIBLE_VARS_PLUGIN_STAGE'] = ''
    os.environ['ANSIBLE_YAML_FILENAME_EXT'] = ''
    ansible_vars_plugin_stage = ''
    ansible_yaml_filename_ext = ''
    basedir = '/tmp/ansible_vars_plugin_basedir'
    entity_name = 'localhost.localdomain'
    entities = []

# Generated at 2022-06-21 07:46:08.408553
# Unit test for constructor of class VarsModule
def test_VarsModule():

    path = 'tests/'
    entities = ['test_group1', 'test_group2', 'test_host1']
    loader = 'test_loader'
    plugin = VarsModule()
    plugin.get_vars(loader, path, entities)

# Generated at 2022-06-21 07:46:11.044888
# Unit test for constructor of class VarsModule
def test_VarsModule():
    try:
        varsmodule = VarsModule()
        assert(varsmodule is not None)
    except:
        assert(False)
    else:
        assert(True)


# Generated at 2022-06-21 07:46:13.972747
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()

# Generated at 2022-06-21 07:47:15.082716
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    VarsModule.REQUIRES_WHITELIST = False
    class FakeLoader:
        def __init__(self):
            self.basedir = '/path/to/basedir'
        def find_vars_files(self, path, entities):
            return ['/path/to/basedir/group_vars/test_grp1/test_grp1_file.yml',
                    '/path/to/basedir/group_vars/test_grp1/test_grp1_file.yaml',
                    '/path/to/basedir/group_vars/test_grp1/test_grp1_file.json']
        def load_from_file(self, path, cache):
            return {'test_var': 'test_value'}
    fake_loader = FakeLoader()


# Generated at 2022-06-21 07:47:16.989977
# Unit test for constructor of class VarsModule
def test_VarsModule():
  plugin = VarsModule()
  assert isinstance(plugin, VarsModule)

# Generated at 2022-06-21 07:47:20.037370
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # The following two lines are needed for pytest mocking to work.
    plugin = VarsModule()
    plugin.get_vars(loader, path, entities, cache=True)

# Generated at 2022-06-21 07:47:28.427559
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars = VarsModule()
    import ansible.inventory.manager
    loader = ansible.inventory.manager.InventoryDirectory(c.config.base_vars_path())

    # Should throw exception with group that is not a group
    try:
        vars.get_vars(loader, 'path', ansible.inventory.host.Host('host_test'))
        raise Exception('Should have a thrown an exception')
    except AnsibleParserError:
        pass

    # Should throw exception with host that is not a host
    try:
        vars.get_vars(loader, 'path', ansible.inventory.group.Group('group_test'))
        raise Exception('Should have a thrown an exception')
    except AnsibleParserError:
        pass

    # Should get vars for host
    data = vars.get_

# Generated at 2022-06-21 07:47:36.189679
# Unit test for constructor of class VarsModule
def test_VarsModule():
    b_cwd = os.path.realpath(to_bytes(os.getcwd()))
    b_path = os.path.join(os.path.sep, b'dev', b'null')
    vars_module = VarsModule()

    entities = [
        Host(name='/dev/null', port=None),
        Group(name='/dev/null')
    ]
    _ = vars_module.get_vars(loader=None, path=b_path, entities=entities)

    os.chdir(to_text(b_cwd))

# Generated at 2022-06-21 07:47:42.140522
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    context.CLIARGS = {'syntax': False, 'connection': 'local', 'module_path': '', 'forks': 10, 'become': False,
                       'become_method': '', 'become_user': None, 'check': False, 'listhosts': None, 'listtasks': None,
                       'listtags': None, 'verbosity': 0, 'extra_vars': [], 'inventory': ['./test/integration/inventory']}

    basedir = "./test/integration/inventory"
    loader = DataLoader()

# Generated at 2022-06-21 07:47:48.737077
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()
    basedir = './'
    vars_module._basedir = basedir
    entity = Host('test_host')
    path = './test_host_vars/test_host'
    vars = vars_module.get_vars(None, path, entity, cache=False)
    assert vars['test_key'] == 'test_value'

# Generated at 2022-06-21 07:47:56.499013
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    from ansible.plugins.loader import VarsModule
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_path_exists

    def access_side_effect(self, path, mode):
        return os.access(path, mode)

    def get_file_loader(data, basedir):
        d = DictDataLoader(data)
        d._basedir = basedir
        return d

    def get_group(name, hostnames):
        g = Group(name)
        for hostname in hostnames:
            g.add_host(Host(hostname))

        return g

    test_

# Generated at 2022-06-21 07:47:59.557504
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' unit testing for VarsModule() constructor '''

    vm = VarsModule()
    assert type(vm) == VarsModule, "VarsModule() constructor is broken."

# Generated at 2022-06-21 07:48:00.221832
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:49:55.037229
# Unit test for constructor of class VarsModule
def test_VarsModule():
    module = VarsModule()
    assert module != None

# Generated at 2022-06-21 07:49:55.646091
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:49:56.289810
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:50:06.879140
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    current_dir = os.path.dirname(os.path.realpath(__file__))
    group_vars_dir = os.path.join(current_dir, 'test_host_group_vars', 'group_vars')
    host_vars_dir = os.path.join(current_dir, 'test_host_group_vars', 'host_vars')

    loader = DataLoader()
    inventory = InventoryManager(loader, [group_vars_dir, host_vars_dir])
    all = inventory.groups['all']
    g1 = inventory.groups['g1']

    v = VarsModule()

    all_vars = v.get_v

# Generated at 2022-06-21 07:50:16.856196
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import shutil
    import tempfile
    import yaml
    from ansible.inventory import Inventory

    plugin = VarsModule()
    host = Host('test_hostname_1')

    def cleanup():
        shutil.rmtree(base_dir)
        Inventory._clear_host_vars_from_memory()


# Generated at 2022-06-21 07:50:18.893277
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module is not None
    assert vars_module.priority == 99

# Generated at 2022-06-21 07:50:20.695440
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert False, "Tests not implemented yet"


# Generated at 2022-06-21 07:50:23.940362
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert isinstance(vm, VarsModule)
    assert isinstance(vm, BaseVarsPlugin)
    assert vm._basedir == C.DEFAULT_VARS_PLUGIN_PATH