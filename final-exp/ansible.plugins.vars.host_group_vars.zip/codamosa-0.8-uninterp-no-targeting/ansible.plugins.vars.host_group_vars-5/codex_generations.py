

# Generated at 2022-06-21 07:40:33.357030
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Create an instance of VarsModule
    vars_module = VarsModule()


if __name__ == '__main__':
    # Unit test for constructor of class VarsModule
    test_VarsModule()

# Generated at 2022-06-21 07:40:42.113702
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    module = VarsModule()
    loader = DictDataLoader({})
    # We can't use the ansible.utils.vars.combine_vars here because we want to test in a specific order
    def combine_vars(a, b):
        return dict(list(a.items()) + list(b.items()))
    module.set_vars_loader(loader)
    module.set_combine_vars(combine_vars)
    module.set_basedir(os.path.join('tests', 'support', 'vars_plugins'))
    data = module.get_vars(loader, os.path.join('tests', 'support', 'vars_plugins', 'host_group_vars'), [Host('host'), Group('group')])

# Generated at 2022-06-21 07:40:50.293276
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' test_VarsModule_get_vars
    '''
    import os
    import shutil
    #import sys
    import tempfile
    #import textwrap
    #from ansible.inventory import Inventory
    import ansible.plugins.loader as plugin_loader

    #from ansible.plugins.vars import BaseVarsPlugin
    import pytest
    from ansible.plugins.vars.host_group_vars import VarsModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Define a file in the temp

# Generated at 2022-06-21 07:40:51.801658
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule({},{})

# Generated at 2022-06-21 07:41:03.525247
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.module_utils._text import to_text
    from ansible.vars.manager import VariableManager

    # make a fake loader...
    ldr = vars_loader.VarsModule()
    ldr.path = C.DEFAULT_VARS_PLUGIN_PATH
    ldr._basedir = to_text('test/test_data/plugins/vars_plugins')

    # make a fake entity...
    h = Host(name="foo", port=99)

    # make a fake variable manager to check the overwriting...
    v = VariableManager()

    # check that we can find a file in a directory and load it's contents

# Generated at 2022-06-21 07:41:05.030860
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    b = BaseVarsPlugin()
    assert v.__class__.__bases__[0] == b.__class__

# Generated at 2022-06-21 07:41:14.592693
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """ Unit tests for method get_vars of class VarsModule """

    stage_dir = "/test"
    basedir = "/test/base"
    vars_dir = "/test/base/host_vars/"

    os.makedirs(vars_dir)
    os.chdir(stage_dir)

    with open(vars_dir + '/file1.yml', 'w') as f:
        f.write("test_key: 'test_value'")
    with open(vars_dir + '/.file2.yml', 'w') as f:
        f.write("test_key: 'test_value'")
    with open(vars_dir + '/~file3.yml', 'w') as f:
        f.write("test_key: 'test_value'")

# Generated at 2022-06-21 07:41:16.147106
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule() is not None

# Generated at 2022-06-21 07:41:25.479612
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.vars.host_group_vars import VarsModule

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()
    # Create a temp file in the temp directory
    temp_file = tempfile.NamedTemporaryFile(mode='w', dir=temp_dir, delete=False)
    # Write a test inventory file to the temp file
    temp_file.write("""
all:
  hosts:
    host1:
    host2:
    host3:
    """)
    # Close the temp file to avoid an error when loading it
    temp_file.close

# Generated at 2022-06-21 07:41:34.317558
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' testing method VarsModule.get_vars '''

    # create test inventory
    # test inventory is composed of one group "g1" with two hosts "h1" and "h2"
    # and one host "h3" not associated to any group
    test_path = os.path.join(os.path.dirname(__file__), "hosts")
    test_loader = BaseVarsPlugin()
    test_loader.set_basedir(test_path)
    h1 = Host("h1")
    h2 = Host("h2")
    h3 = Host("h3")
    g1 = Group("g1")
    g1.add_host(h1)
    g1.add_host(h2)
    # create test object
    test_object = VarsModule(test_loader)

# Generated at 2022-06-21 07:41:41.235388
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    assert False, 'Not Implemented Yet!'


# Generated at 2022-06-21 07:41:50.732792
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    b_cwd = to_bytes(os.getcwd(), errors='surrogate_or_strict')
    b_opath = to_bytes(os.path.join(b_cwd, b'group_vars'))
    mock_entity = {'name': 'h1', 'port': 22}
    ansible_vars = VarsModule()
    ansible_vars.get_vars({}, b_opath, mock_entity)
    assert isinstance(FOUND['h1.%s' % b_opath][0], bytes)

# Generated at 2022-06-21 07:42:02.887280
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Setup
    from ansible.plugins.loader import vars_loader
    import ansible.parsing.dataloader
    host_obj = Host(name='app1')
    path = '/tmp'
    var_files = ['group_vars/app.yml','host_vars/app1.yml','app1.yml']
    vars_loader._get_files_for_path = lambda x,y,z: var_files

    #Test
    vars_mod = VarsModule()
    vars_mod.get_vars(ansible.parsing.dataloader.DataLoader(), path, host_obj, cache=False)

    #Assert
    assert vars_loader._load_from_file.call_count==3

# Generated at 2022-06-21 07:42:06.595865
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' unit test for VarsModule() class constructor
    '''
    data = VarsModule()
    assert isinstance(data, VarsModule), 'class constructor test failed'

# Generated at 2022-06-21 07:42:15.470406
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import sys
    import yaml

    from ansible.plugins.loader import vars_loader

    # If path of the files being loaded contain '\' Windows-style characters,
    # we need to use '\\' to hold the directory, or we need to use os.path.join
    # to combine the directory strings.
    # We need to do this in order to match the path found in the variable `found`
    b_opath = to_bytes(os.path.join('dir', 'dir_sub'))

    # The variable `found` is a String, and we need to encode it to bytes in order to
    # open it for reading.
    found = to_bytes(os.path.join('dir', 'dir_sub', 'file.yml'))

    # Create the data file under test.

# Generated at 2022-06-21 07:42:16.303209
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:42:16.658324
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:42:25.130323
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = MagicMock()
    path = "host_vars/test_host"
    host1 = Host("test_host")
    host2 = Host("test_host2")
    host3 = Host("test_host3")
    host4 = Host("test_host4")
    host5 = Host("test_host5")
    host6 = Host("test_host6")
    host7 = Host("test_host7")
    host8 = Host("test_host8")
    host9 = Host("test_host9")
    host10 = Host("test_host10")
    group1 = Group("test_group")
    group2 = Group("test_group2")
    group3 = Group("test_group3")
    group4 = Group("test_group4")
    group5 = Group("test_group5")

# Generated at 2022-06-21 07:42:30.652954
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins.loader import vars_loader
    # create an instance of class VarsModule by passing path and main_settings to its constructor
    obj = VarsModule("/home/", "/home/ansible/ansible/ansible/plugins/vars/host_group_vars.py")

    # Test get_vars() method
    # create sample inventory object and return it
    class Inventory(object):
        inventory = "/home/ansible/ansible/ansible/inventory/simple_hosts"
        basedir = "/home/ansible/ansible/ansible/inventory"
        vault_password = None

# Generated at 2022-06-21 07:42:42.779753
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import sys
    import os
    import tempfile
    import __builtin__

    # python 2.6 hack
    stdout = sys.stdout
    stderr = sys.stderr
    tmpfd, tname = tempfile.mkstemp()
    os.close(tmpfd)
    setattr(__builtin__, 'open', lambda fname, mode: open(tname, mode) if fname == tname else open(fname, mode))
    sys.stdout = open(tname, 'w')
    sys.stderr = open(tname, 'w')

    # create temp inventory file
    fd, inv_path = tempfile.mkstemp()

# Generated at 2022-06-21 07:42:47.521334
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm is not None
    assert vm.get_vars(None, None, None) == {}
    assert vm._valid_extensions == [".yml", ".yaml", ".json"]

# Generated at 2022-06-21 07:42:48.511700
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module is not None

# Generated at 2022-06-21 07:42:50.355345
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert isinstance(vm,VarsModule)
    assert isinstance(vm,BaseVarsPlugin)


# Generated at 2022-06-21 07:42:55.560023
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = DictDataLoader({})
    basedir = '/tmp'
    entities = [Group(loader=loader, name='groupname'), Host(loader=loader, name='hostname')]

    for entity in entities:
        vm = VarsModule()
        vm.get_vars(loader, basedir, entity)

# Generated at 2022-06-21 07:42:59.358887
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' Test instantiation of class VarsModule '''
    vars_mod = VarsModule()
    assert vars_mod.REQUIRES_WHITELIST == True

# Generated at 2022-06-21 07:43:00.882749
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule == type(VarsModule())

# Generated at 2022-06-21 07:43:03.088716
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ans = VarsModule()
    assert ans.get_vars('loader', '/path/to/file', 'entities', cache=True) == {}

# Generated at 2022-06-21 07:43:06.588131
# Unit test for constructor of class VarsModule
def test_VarsModule():
    mod = VarsModule()
    assert mod is not None
    assert mod.__class__.__name__ == 'VarsModule'

# Generated at 2022-06-21 07:43:18.594524
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    #import os.path
    # basedir = os.path.join(os.path.dirname(__file__), '../../../', 'test/hosts')
    #
    # b_basedir = to_bytes(basedir, errors='surrogate_or_strict')
    # def find_files(path, name):
    #     if name != 'host1':
    #         return []
    #     else:
    #         return [os.path.join(b_basedir, 'host_vars/host1/hostvars.yml')]
    #
    # loader = DataLoader()


# Generated at 2022-06-21 07:43:22.185004
# Unit test for constructor of class VarsModule
def test_VarsModule():
    host = Host("hostname")
    path = "path"
    entities = [host]
    assert VarsModule().get_vars(None, path, entities)

# Generated at 2022-06-21 07:43:36.887707
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # additional setup for test
    import sys
    import tempfile
    import shutil
    basedir = tempfile.mkdtemp()
    loader = None

    # create hostvars and groupvars directories
    os.mkdir(os.path.join(basedir, 'host_vars'))
    os.mkdir(os.path.join(basedir, 'group_vars'))

    # create valid variable files in host_vars and group_vars
    with open(os.path.join(basedir, 'host_vars', 'host1'), 'w') as f:
        f.write('var_host1_1: value_host1_1\n')
        f.write('var_host1_2: value_host1_2\n')

# Generated at 2022-06-21 07:43:49.066581
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import unittest

    class MockLoader(object):
        def __init__(self):
            self.path = "mock_path"
            self.all_vars = {}

        def get_basedir(self):
            return "mock_basedir"

        def find_vars_files(self, path, files):
            return [os.path.join(path, "mock_file" + ext) for ext in ['.yaml', '.yml', '.json']]

        def load_from_file(self, path, cache=True, unsafe=True):
            return {path: 'mock_value'}

    mock_loader = MockLoader()

    import os
    import tempfile
    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the directory we want to read from

# Generated at 2022-06-21 07:43:51.078327
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm

# Generated at 2022-06-21 07:44:02.468281
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import shutil
    import tempfile
    import unittest

    import ansible
    from ansible.plugins.loader import vars_loader

    class TestVarsModule(unittest.TestCase):

        def setUp(self):
            self.vars_dir = tempfile.mkdtemp(prefix='VarsModuleTest')
            self.host_vars_dir = os.path.join(self.vars_dir, 'host_vars')
            self.group_vars_dir = os.path.join(self.vars_dir, 'group_vars')

            for d in (self.vars_dir, self.host_vars_dir, self.group_vars_dir):
                os.mkdir(d)


# Generated at 2022-06-21 07:44:08.820951
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    test_dir = os.path.dirname(__file__)

    # Create a fake inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    groups = ['ungrouped', 'all', 'somegroup']
    hosts = ['somehost']
    manager = InventoryManager(loader=loader, groups=groups, hosts=hosts)

    # Create a fake task to mimick an actual task
    from ansible.playbook.task import Task
    task_vars = dict(
        ansible_inventory=manager,
        ansible_basedir=test_dir
    )
    fake_task = Task()
    fake_task.set_loader(loader)
    fake_task.vars = task_vars

   

# Generated at 2022-06-21 07:44:20.759926
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import PluginLoader

    def test_load_from_file(filename, cache=False, unsafe=False):
        return {}

    def test_find_vars_files(path, filenames):
        return ['file1', 'file2']

    test_host = Host('test_host')
    test_group = Group('test_group')
    test_loader = PluginLoader(Display(), config=dict(constants=C))

    test_get_vars_instance = VarsModule(loader=test_loader._loader, inventory=None)


# Generated at 2022-06-21 07:44:28.584977
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    plugin = VarsModule()
    ansible_fact = dict()
    ansible_fact['plugin_stage'] = 'vars_host_group_vars'
    ansible_fact['yaml_valid_extensions'] = ['.yml', '.yaml', '.json']
    ansible_fact['ansible_path_plugins'] = '/root/.ansible/plugins'
    ansible_fact['ANSIBLE_PATH_PLUGINS'] = '/root/.ansible/plugins'

    def mock_get_option(opt):
        return ansible_fact[opt]

    plugin._get_option = mock_get_option

    host1 = Host("1.1.1.1")
    plugin.get_vars(None, '.', host1)


# Generated at 2022-06-21 07:44:30.317891
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm.__class__.__name__ == 'VarsModule'



# Generated at 2022-06-21 07:44:33.718576
# Unit test for constructor of class VarsModule
def test_VarsModule():
    test_vars_module = VarsModule()
    assert isinstance(test_vars_module, VarsModule)


# Generated at 2022-06-21 07:44:34.875762
# Unit test for constructor of class VarsModule
def test_VarsModule():
    plugin = VarsModule()
    assert plugin is not None

# Generated at 2022-06-21 07:44:55.088213
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    plugin = VarsModule()
    plugin._display = DummyDisplay()

    # data loader
    mock_loader = DictDataLoader({
        u'/etc/ansible/host_vars/foo': "foo: bar",
        u'/etc/ansible/host_vars/foo.yaml': "foo: bar",
        u'/etc/ansible/host_vars/foo.json': "{\"foo\": \"bar\"}",
        u'/e/x': "foo: bar",     # no access - ignored
        u'/etc/ansible/host_vars/y': "foo: bar",  # no access - ignored
    })

    # setup args
    mock_loader.set

# Generated at 2022-06-21 07:44:56.712157
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, VarsModule)
    assert v.priority == 128

# Generated at 2022-06-21 07:44:58.462723
# Unit test for constructor of class VarsModule
def test_VarsModule():
    my_class = VarsModule()

# Generated at 2022-06-21 07:45:04.131304
# Unit test for constructor of class VarsModule
def test_VarsModule():
    """
        Return class object with initialized variables
    """
    vars_module = VarsModule()
    assert isinstance(vars_module, VarsModule)
    assert isinstance(vars_module._basedir, str)
    assert isinstance(vars_module._display, object)
    assert isinstance(vars_module._options, dict)

# Generated at 2022-06-21 07:45:04.770472
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:45:12.357766
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    t_vars = VarsModule()
    ansible_vars = {
        'host_vars': {
            'host1.example.com': {},
            'host2.example.com': {},
            'host3.example.com': {}
        },
        'group_vars': {
            'testgroup': {},
            'testgroup2': {},
        }
    }

    host = Host('group1.example.com', ansible_vars=ansible_vars)
    assert t_vars.get_vars(None, '', host) == {}

    host = Host('host1.example.com', ansible_vars=ansible_vars)
    assert t_vars.get_vars(None, '', host) == {}

    group = Group('group1')

# Generated at 2022-06-21 07:45:22.284704
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host as AnsibleHost
    from ansible.inventory.group import Group as AnsibleGroup
    vars_path = './test/unit/vars_plugins'
    host_group_vars = VarsModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['./test/unit/inventory/inventory_file'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._extra_vars = variable_manager.get_vars(play=None)

# Generated at 2022-06-21 07:45:34.588267
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # load vars
    class Entity:
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class Loader:
        def __init__(self):
            self.basedir = os.path.expanduser("~")
            self.subdirs = ['host_vars', 'group_vars']

        def find_vars_files(self, path, *args):
            files = ['host_vars/host01.yaml', 'host_vars/host01.json', 'host_vars/host01', 'host_vars/host01.yml']
            return [os.path.join(path, file) for file in files if os.path.exists(os.path.join(path, file))]


# Generated at 2022-06-21 07:45:36.690883
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert hasattr(vm, "get_vars")

# Generated at 2022-06-21 07:45:41.127568
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # A function for basic unit testing of class VarsModule
    # not using assertEquals because multiple checks are done
    # in one function.
    vars_module_instance = VarsModule()
    vars_module_instance.vars_plugin_staging()

# Generated at 2022-06-21 07:46:03.469115
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars = VarsModule()
    assert vars is not None

# Generated at 2022-06-21 07:46:06.344317
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsmod = VarsModule()
    data = varsmod.get_vars(loader, path, entities)
    assert data == {}

# Generated at 2022-06-21 07:46:08.406842
# Unit test for constructor of class VarsModule
def test_VarsModule():
    path = 'test_path'
    entities = 'test'
    VarsModule(path, entities)

# Generated at 2022-06-21 07:46:09.689228
# Unit test for constructor of class VarsModule
def test_VarsModule():
    myobj = VarsModule()


# Generated at 2022-06-21 07:46:21.287284
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import ansible.plugins.vars.host_group_vars

    inventory = '''
[all]
localhost

[localhost:vars]
ansible_host = localhost

[web_servers]
web01
web02

[web_servers:vars]
ansible_host = localhost

[web_servers:children]
lb_servers
'''
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import vars_loader

    inventory_manager = InventoryManager(loader=None, sources=inventory)
    host = inventory_manager.get_host("localhost")
    plugin = ansible.plugins.vars.host_group_vars.VarsModule()

# Generated at 2022-06-21 07:46:32.069117
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    v = VarsModule()

    class TestEntity(object):
        def __init__(self, name):
            self.name = name

    class TestLoader(object):
        def __init__(self):
            self.vars_files = []

        def find_vars_files(self, path, entity_name):
            return [path + '/' + entity_name]

        def load_from_file(self, path, cache=True, unsafe=True):
            return {'value': path}

    class TestDisplay(object):
        def __init__(self):
            self.display = []

        def debug(self, msg):
            self.display.append(msg)

        def warning(self, msg):
            self.display.append(msg)

    # Test with Host entity
    loader = TestLoader()
   

# Generated at 2022-06-21 07:46:42.626209
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from .mock import mock_open, patch, Mock
    import collections
    import json
    from ansible.vars.plugins.host_group_vars import VarsModule

    test_cases = collections.namedtuple('test_cases', ['inv_path', 'group', 'group_name', 'entity', 'expected'])
    tc_list = []

    group = collections.namedtuple('group', ['name'])
    group.name = 'localhost'

    group2 = collections.namedtuple('group2', ['name'])
    group2.name = 'hosts'

    host = collections.namedtuple('host', ['name'])
    host.name = 'localhost'

    host2 = collections.namedtuple('host2', ['name'])
    host2.name = 'hosts'


# Generated at 2022-06-21 07:46:54.149960
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # pylint: disable=redefined-outer-name
    class AnsibleOptions(object):
        verbosity = 0
    options = AnsibleOptions()
    basedir = '/tmp'
    display = to_text(None)
    inventory = None
    vars_cache = to_text(None)
    loader = to_text(None)
    inventory_basedir = '/tmp'
    data_context = to_text(None)
    connection_info = to_text(None)
    options.roles_path = None
    vars_module = VarsModule(inventory=inventory, loader=loader, basedir=basedir, inventory_basedir=inventory_basedir, data_context=data_context,
                             display=display, vars_cache=vars_cache, options=options, connection_info=connection_info)

# Generated at 2022-06-21 07:46:56.724291
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert isinstance(vars_module, VarsModule)

# Generated at 2022-06-21 07:47:04.581823
# Unit test for constructor of class VarsModule
def test_VarsModule():
    current_dir = os.path.dirname(__file__)
    inventory_file_path = os.path.join(current_dir, "test_inventory", "test_inventory")
    inventory_file_path_b_type = to_bytes(inventory_file_path)
    display = Mock()
    vm = VarsModule(inventory_file_path_b_type, display=display)
    assert vm._basedir == os.path.join(current_dir, "test_inventory")



# Generated at 2022-06-21 07:47:51.329644
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsmodule = VarsModule()
    assert varsmodule._valid_extensions == [".yml", ".yaml", ".json"]
    b_opath = os.path.realpath(to_bytes(os.path.join('/tmp', 'host_vars')))
    opath = to_text(b_opath)
    key = 'group.%s' % (opath)
    assert key not in FOUND

# Generated at 2022-06-21 07:47:58.106078
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create some objects
    basedir = '/a/b/c'
    b_basedir = to_bytes(basedir)
    host = Host('test-host')
    group = Group('test-group')
    entities = [host, group]
    # Test all entities
    data = {}

# Generated at 2022-06-21 07:47:58.747164
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:48:09.218832
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' Unit test for VarsModule.get_vars() '''

    # prepare module inputs
    loader = DummyLoader()
    basedir = '.'
    path = ''
    entities = [DummyHost('a')]

    # set env vars
    os.environ[str('ANSIBLE_YAML_VALID_EXTENSIONS')] = str('yml,yaml')

    # invoke method being tested
    module = VarsModule(loader, basedir, path)
    result = module.get_vars(loader, path, entities, cache=False)

    # assert the result
    assert result == {'k1': 'v1'}



# Generated at 2022-06-21 07:48:15.712161
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    group = Group('webservers')
    group.vars = {}
    group.vars['x'] = 'x'
    group.vars['y'] = 'y'
    group.vars['z'] = 'z'
    
    host = Host('test')
    host.vars = {}
    host.vars['a'] = 'a'
    host.vars['b'] = 'b'
    host.vars['c'] = 'c'
    host.groups.append(group)
    host.groups.append(group)
    host.groups.append(group)

    vars_module = VarsModule()

    f = vars_module.get_vars(None, None, None)
    assert not f


# Generated at 2022-06-21 07:48:16.748912
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule({}) != None


# Generated at 2022-06-21 07:48:21.128753
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' test for constructor for VarsModule '''
    vars_obj = VarsModule()
    assert vars_obj._valid_extensions == [".yml", ".yaml", ".json"]
    assert vars_obj._stage == 'vars'

# Generated at 2022-06-21 07:48:22.604327
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Since we initialize the class, we don't need to test much more
    v = VarsModule()
    assert(v)

# Generated at 2022-06-21 07:48:28.350819
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    module = VarsModule()
    fake_loader = None
    fake_path = None
    fake_entities = [
        Host(name='host1'),
        Host(name='host2'),
        Group(name='group1'),
        Group(name='group2'),
    ]
    module.get_vars(fake_loader, fake_path, fake_entities)

# Generated at 2022-06-21 07:48:38.852399
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    Test get_vars of class VarsModule
    '''
    mock_vars_file = './test_data/host_vars/inventory_hostname.yaml'
    mock_host_variable = {'host_var': 'host_var_value'}
    mock_group_variable = {'group_var': 'group_var_value'}
    mock_groups = [
        {'name': 'group_name', 'vars': mock_group_variable},
    ]
    mock_host = {'name': 'inventory_hostname', 'groups': mock_groups, 'vars': mock_host_variable}
    vars_module = VarsModule()


# Generated at 2022-06-21 07:50:16.101188
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert(vars_module)


# Generated at 2022-06-21 07:50:19.022683
# Unit test for constructor of class VarsModule
def test_VarsModule():
    host = Host('test.example.org')
    group = Group('test_group')
    vm = VarsModule()
    vm.get_vars(None, None, host)
    vm.get_vars(None, None, group)

# Generated at 2022-06-21 07:50:31.189596
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    yaml_file = '''
---
name: test_VarsModule_get_vars_yaml
var_1:
  - yaml
  - file
'''
    json_file = '''
{
  "name": "test_VarsModule_get_vars_json",
  "var_1": [
    "json",
    "file"
  ]
}
'''

    try:
        import yaml
    except ImportError:
        raise AssertionError('VarsModule requires PyYAML')
    try:
        import json
    except ImportError:
        raise AssertionError('VarsModule requires json')

    vm = VarsModule()