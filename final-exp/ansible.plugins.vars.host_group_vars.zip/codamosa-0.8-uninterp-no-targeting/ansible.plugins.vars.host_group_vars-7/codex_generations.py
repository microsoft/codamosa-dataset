

# Generated at 2022-06-21 07:40:36.951218
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test call of method get_vars()
    f_res = VarsModule.get_vars("loader", "path", [Host()])
    assert f_res == {}



# Generated at 2022-06-21 07:40:41.031961
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, VarsModule)
    assert isinstance(v, BaseVarsPlugin)

# Generated at 2022-06-21 07:40:45.652198
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """This is a dummy test for method get_vars of class VarsModule"""

    varsMod = VarsModule()
    varsMod.get_vars(None, None, None, True)

# Generated at 2022-06-21 07:40:48.368991
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_vars_plugin = VarsModule()
    assert vars_vars_plugin.get_vars(None, None, None) is None

# Generated at 2022-06-21 07:41:01.432713
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Create a FakeModuleLoader
    class FakeModuleLoader(object):
        def _load_from_file(self, path, file_name, inject_name=None,
                            cache=True, unsafe=False):
            #file_name in FOUND[path] and
            if path == u'/home/stale/work/ansible/ansible/test/units/plugins/vars/test_data/group_vars' and file_name == 'test_group':
                return {'var1': 'value1', 'var2': 'value2'}

# Generated at 2022-06-21 07:41:03.661480
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars = VarsModule()
    assert isinstance(vars, VarsModule)

# Generated at 2022-06-21 07:41:07.955084
# Unit test for constructor of class VarsModule
def test_VarsModule():
    config = { 'ANSIBLE_VARS_PLUGIN_STAGE': 'test' }
    plugin = VarsModule(None, config, None, None)
    assert plugin._stage == 'test'

# Generated at 2022-06-21 07:41:15.780077
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible import context
    from ansible.cli import CLI
    from ansible.plugins import vars_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import json

    cli = CLI(args=[])
    cli.parse()
    context.CLIARGS = cli.args

    loader = DataLoader()
    context.CLIARGS = cli.args

    # Create a dummy group "test" and add a dummy host "testh1" to it
    inventory = InventoryManager(loader=loader, sources="./host_group_vars_test/inventory")
    host = inventory.get_host("testh1")


# Generated at 2022-06-21 07:41:28.583113
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # FIXME: the unit test is not working
    import unittest
    from unittest.mock import MagicMock
    from ansible.inventory.manager import InventoryManager

    plugin = VarsModule()
    plugin._display = MagicMock()
    loader = MagicMock()
    loader.find_vars_files = MagicMock()
    loader.load_from_file = MagicMock()
    loader.load_from_file.return_value = {
        'a': 1,
        'b': 2,
    }
    loader.curr_file = MagicMock()
    loader.curr_file.split.return_value = ['/c/d/e', 'f']
    plugin.basedir = '/c/d/e'
    path = '/c/d/e/f'
    host_

# Generated at 2022-06-21 07:41:30.435210
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert v is not None


# Generated at 2022-06-21 07:41:38.504491
# Unit test for constructor of class VarsModule
def test_VarsModule():
    mod = VarsModule()
    assert mod.get_vars(None,None,None,None)

# Generated at 2022-06-21 07:41:45.284478
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # host and group object
    host = Host('testhost')
    group = Group('testgroup')
    group.hosts.append(host)
    # create vars object
    vars_manager = VariableManager()
    vars_manager.add_group(group)
    # create loader object
    loader = DataLoader()
    inventory_basedir = os.path.dirname(loader.get_basedir())
    # create vars object
    vars_obj = VarsModule(play=None, inventory=vars_manager)
    # set option

# Generated at 2022-06-21 07:41:54.628901
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins.loader import vars_loader, filter_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost,127.0.0.1"])
    host = inventory.get_host("localhost")
    assert host is not None
    vars_m = VarsModule(loader=vars_loader, filter_loader=filter_loader, host=host)
    assert vars_m is not None


# Generated at 2022-06-21 07:42:03.634991
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.plugins.loader import vars_loader

    test_host_obj = Host('test_host', groups=['test_group'], vars={'fake_var': 'fake_var_value'})
    test_group_obj = Group('test_group', groups=['test_group2'], vars={'fake_var': 'fake_var_value'})
    test_group2_obj = Group('test_group2', vars={'fake_var': 'fake_var_value'})

    # Test host group
    vars_module = VarsModule()
    vars_module._basedir = os.path.join(C.DEFAULT_LOCAL_TMP, 'vars_plugin_test_dir')
    vars_module._inventory = vars_loader

# Generated at 2022-06-21 07:42:14.450766
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.inventory.host import Host
    from ansible.plugins.loader import load_plugin_paths, VarsModule
    from ansible.parsing.utils.addresses import parse_address
    info = load_plugin_paths('./', 'vars')

    v = VarsModule()
    host = Host(name="test_host", port=22)
    ansible_group1 = {'group1': {'age': 1, 'run': 1}}
    ansible_group2 = {'group2': {'age': 2, 'run': 2}}
    ansible_group3 = {'group3': {'age': 3, 'run': 3}}
    ansible_group4 = {'group4': {'age': 4, 'run': 4}}

# Generated at 2022-06-21 07:42:25.086569
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.plugins.loader import vars_loader
    import ansible.constants as C
    import os

    # Setting all required variables
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_MODULE_PATH = os.path.dirname(__file__) + os.sep + 'modules'
    C.LOCALHOST_WARNING = False
    C.DEFAULT_HOST_LIST = os.path.dirname(__file__) + os.sep + 'inventory'
    C.INVENTORY_ENABLED = 'host_group_vars'
    C.DEFAULT_MODULE_NAME = 'copy'

    # Initializing plugin with vars_loader
    v = VarsModule()
    vars_loader.add("host_group_vars", v)

    #

# Generated at 2022-06-21 07:42:27.337037
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert(v is not None)

# Generated at 2022-06-21 07:42:29.731507
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' test constructor of class VarsModule '''
    v = VarsModule()
    assert v.REQUIRES_WHITELIST is True
    assert v._valid_extensions == ['.yml', '.yaml', '.json']
    assert v._loader is None
    assert v._basedir is None


# Generated at 2022-06-21 07:42:42.181210
# Unit test for constructor of class VarsModule

# Generated at 2022-06-21 07:42:49.537302
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import sys
    import shutil
    from ansible.vars.manager import VariableManager
    basedir = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                           'test_data', 'test_host_vars_plugin')
    host_path = os.path.join(basedir, 'host_vars')
    group_path = os.path.join(basedir, 'group_vars')
    inventory_path = os.path.join(basedir, 'hosts')
    global FOUND
    FOUND = {}
    for path in [basedir, host_path, group_path]:
        if os.path.exists(path):
            shutil.rmtree(path)
        os.makedirs(path)

# Generated at 2022-06-21 07:43:05.842624
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ''' Unit test for method get_vars of class VarsModule '''

    from ansible import context
    from ansible.cli import CLI
    from ansible.plugins.vars import VarsModule

    # Create current object
    current = VarsModule()

    # Create loader object
    parser = CLI.base_parser(
        usage='',
        epilog=''
    )
    (options, args) = parser.parse_args()
    attach_args = vars(options)
    context._init_global_context(attach_args)
    loader = context.CLIARGS['loader']
    loader.plugin_filters = []

    # Create path object
    path = '/home/user/project/ansible_project/group_vars/'

    # Create entities object
    host = Host('localhost')

   

# Generated at 2022-06-21 07:43:18.017170
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # host_vars
    h = Host("host1")
    d = VarsModule()
    host_vars = d.get_vars(None, None, [h])
    assert host_vars["host_var"] == "host_var_value"
    # group_vars
    h = Host("host1")
    h.groups = ["grp1"]
    d = VarsModule()
    group_vars = d.get_vars(None, None, [h])
    assert group_vars["group_var"] == "group_var_value"
    # host_vars & group_vars
    h = Host("host1")
    h.groups = ["grp1"]
    d = VarsModule()

# Generated at 2022-06-21 07:43:22.712322
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """ Unit test for method get_vars of class VarsModule """
    loader_args = {'paths': [b'/path'], '_basedir': b'/basedir'}
    vars_module = VarsModule()
    vars_module.set_options(direct=loader_args)


if __name__ == '__main__':
    test_VarsModule_get_vars()

# Generated at 2022-06-21 07:43:34.173206
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Define some inventory hosts
    test_inventory_path = 'test/unit/plugins/inventory/test_host_group_vars.yml'
    test_hosts = ['host0', 'host1', 'host2', 'host3', 'host4', 'host5', 'host6', 'host7', 'host8', 'host9', 'host10', 'host11']

    # Create groups
    group_all = Group('all')
    group_ungrouped = Group('ungrouped')
    group_group0 = Group('group0')
    group_group1 = Group('group1')
    group_group2 = Group('group2')
    group_group3 = Group('group3')
    group_group4 = Group('group4')
    group_group5 = Group('group5')

    # Create hosts and assign

# Generated at 2022-06-21 07:43:36.557111
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsplugin = VarsModule()
    print(varsplugin)

# Generated at 2022-06-21 07:43:41.916562
# Unit test for constructor of class VarsModule
def test_VarsModule():
    loader = None
    path = None
    entity = None
    vm = VarsModule()
    # TODO: Replace with assertRaises
    # vm.get_vars(loader, path, entity)
    assert 0


# Generated at 2022-06-21 07:43:44.080482
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule.REQUIRES_WHITELIST == True



# Generated at 2022-06-21 07:43:44.851223
# Unit test for constructor of class VarsModule
def test_VarsModule():
    x = VarsModule()
    assert x

# Generated at 2022-06-21 07:43:55.775796
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # import json
    # import os
    # import shutil
    # import sys
    # import tempfile
    # import unittest
    # from unittest.mock import patch, MagicMock

    # from ansible.errors import AnsibleParserError
    # from ansible.inventory.host import Host
    # from ansible.inventory.group import Group
    # from ansible.module_utils._text import to_bytes
    from ansible.vars.manager import VariableManager
    # from ansible.vars.vars_plugin import VarsModule
    # from ansible.vars.vars_plugins.host_group_vars_plugin import VarsModule
    # from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # # create a fake inventory
    # groups = dict

# Generated at 2022-06-21 07:44:05.297906
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    m_inivars=dict()
    m_inventory=dict()
    m_display=dict()
    m_option=dict()
    m_variable_manager=dict()

    vars_module = VarsModule(m_inivars, m_inventory, m_display, m_option, m_variable_manager)
    loader = dict()
    path = "/test/test_group_host_vars.yml"
    entities = [Host(name="test_host", port=None, variables={'list1': ['a', 'b'], 'list2': ['c', 'd'], 'list3': ['e', 'f', 'g']})]


# Generated at 2022-06-21 07:44:18.668897
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module is not None


# Generated at 2022-06-21 07:44:20.969908
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert isinstance(vm, VarsModule)


# Generated at 2022-06-21 07:44:23.677502
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module_obj = VarsModule()
    name = vars_module_obj.get_name()
    assert name is not None
    assert name == VarsModule.name

# Generated at 2022-06-21 07:44:29.222505
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    loader = None
    path = None
    host = Host('host_in_file')
    group = Group('group_in_file')
    wrong_entity = Group('wrong_entity')
    entities = [host, group, wrong_entity]

    vars_plugin = VarsModule()

    vars_plugin.get_vars(loader, path, entities)

# Generated at 2022-06-21 07:44:39.203958
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # initialization of unit test
    loader = DummyVarsFileLoader()
    plugin = VarsModule()

    # test for case Host object
    host = Host('example')
    data = plugin.get_vars(loader, '', [host])
    assert len(data) == 2
    assert data.get('example') == True
    assert data.get('example2') == True

    # test for case Group object
    group = Group('example')
    data = plugin.get_vars(loader, '', [group])
    assert len(data) == 2
    assert data.get('example') == True
    assert data.get('example2') == True

# Unit test helper class

# Generated at 2022-06-21 07:44:46.900701
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Construct the input arguments for the VarsModule constructor
    path = "/etc/ansible/host_vars/test"
    entities = [Host(name="test", port=22)]
    basedir = "/etc/ansible"

    global FOUND
    FOUND = []

    # Create instance of class VarsModule
    v = VarsModule(loader=None, path=path, entities=entities, basedir=basedir)

    assert v.get_vars(loader=None, path=path, entities=entities)

# Generated at 2022-06-21 07:44:57.380072
# Unit test for constructor of class VarsModule
def test_VarsModule():
    class Entity(object):
        def __init__(self, name):
            self.name = name

    class Loader(object):
        def find_vars_files(self, opath, entity_name):
            return ['/etc/ansible/{0}/{1}'.format(opath, entity_name)]

        def load_from_file(self, opath, cache=True, unsafe=True):
            return {entity_name: {'name': entity_name, 'var': 'value'}}

    entity_name = 'localhost'
    entity = Entity(entity_name)

    basedir = '/etc/ansible'
    loader = Loader()
    vars_plugin = VarsModule({}, basedir=basedir)
    vars_plugin.get_vars(loader, basedir, [entity])
   

# Generated at 2022-06-21 07:44:59.015008
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert v, "Failed to instantiate VarsModule"

# Generated at 2022-06-21 07:45:05.508680
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    args = (os.path.join(os.path.dirname(__file__), 'test_host_group_vars.yaml'), [{'key1': 'value1'}, {'key2': 'value2'}])
    v = VarsModule()
    assert v.get_vars(args) == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 07:45:12.690481
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import os
    import tempfile
    from ansible.utils.vars import combine_vars

    test_dir = tempfile.mkdtemp(prefix="test_VarsModule_get_vars-")


# Generated at 2022-06-21 07:45:32.043428
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_m = VarsModule()
    assert vars_m.priority == 128

    vars_m = VarsModule(priority=128)
    assert vars_m.priority == 128

    vars_m = VarsModule(True, 128)
    assert vars_m.priority == 128

    vars_m = VarsModule(True, 128, False)
    assert vars_m.priority == 128
    assert not vars_m.REQUIRES_WHITELIST


# Generated at 2022-06-21 07:45:35.502053
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    host = Host("abc", '192.168.0.2', port=22)
    path = 'group_vars'
    if not isinstance(host, list):
        entities = [host]
    else:
        entities = host
    vars_module = VarsModule()

    data = vars_module.get_vars(None, path, entities, cache=False)
    assert data == {}

    data = vars_module.get_vars(None, path, host, cache=False)
    assert data == {}

# Generated at 2022-06-21 07:45:46.189511
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Arrange
    class fake_Host:
        def __init__(self, _name):
            self.name = _name

    class fake_Group:
        def __init__(self, _name):
            self.name = _name

    class fake_loader:
        def __init__(self):
            self.cache_key = "fake_cache_key"

        def get_basedir(self, path):
            return os.path.dirname(path)

        def find_vars_files(self, basedir, entity_name):
            return ["fake_file1.yml", "fake_file2.yml"]

        def load_from_file(self, path, cache=True, unsafe=True):
            return "fake_return_data"

    loader = fake_loader()
    plugin = VarsModule

# Generated at 2022-06-21 07:45:51.249099
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, BaseVarsPlugin)
    assert v.REQUIRES_WHITELIST is True
    assert v._valid_extensions == [".yml", ".yaml", ".json"]

# Generated at 2022-06-21 07:46:02.050359
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class fake_object(object):
        pass
    fake_loader = fake_object()
    fake_host = fake_object()
    fake_group = fake_object()

    # execute hostname
    vm = VarsModule()
    fake_loader.find_vars_files = lambda a, b: [True]
    fake_loader.load_from_file = lambda a, b: {"hello": "world"}
    fake_loader.path_exists = lambda a: True
    fake_host.name = "test_host"
    ret = vm.get_vars(fake_loader, "fake/path", fake_host)
    assert ret == {"hello": "world"}

    # execute groupname
    vm = VarsModule()
    fake_loader.find_vars_files = lambda a, b: [True]
   

# Generated at 2022-06-21 07:46:13.889182
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    def mock_loader_find_vars_files(vars_dir, entity_name):
        assert vars_dir == '/playbooks/group_vars'
        assert entity_name == 'test'
        return ['/playbooks/group_vars/test']

    def mock_loader_load_from_file(vars_filename, cache=True, unsafe=True):
        assert vars_filename == '/playbooks/group_vars/test'
        assert cache
        assert unsafe
        return {'a': '1'}

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class VarsModule(object):
        def __init__(self):
            self._display = object()
            self._basedir

# Generated at 2022-06-21 07:46:15.948037
# Unit test for constructor of class VarsModule
def test_VarsModule():
    varsModule = VarsModule()
    assert isinstance(varsModule, VarsModule)

# Generated at 2022-06-21 07:46:19.783423
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # TODO: This is not a unit test and it is not testing anything.
    #       It looks like it was inserted into docstring by accident.
    #       This should be removed.
    vars_module = VarsModule()
    assert vars_module.get_vars(path='/path/to/inventory', entities='all')



# Generated at 2022-06-21 07:46:21.421562
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:46:32.187700
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' unit test for class VarsModule as a standalone '''
    varsmodule = VarsModule()
    base_dir = "/tmp/test_dir"
    varsmodule._basedir = base_dir
    varsmodule._loader = None
    varsmodule._ds = None
    varsmodule._play = None
    varsmodule._play_ds = None
    varsmodule._playbook_dir = None
    varsmodule._inventory = None
    varsmodule._strict = True
    varsmodule._display = None

    # test for get_vars
    # for host
    hosts_list = ["host1", "host2"]
    for host in hosts_list:
        entities = Host(name=host)
        host_vars_path = base_dir + "/host_vars"
        host_v

# Generated at 2022-06-21 07:47:06.565966
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # import libs
    from ansible.plugins.loader import vars_loader
    from ansible.inventory.manager import InventoryManager
    import tempfile
    import pytest
    import shutil

    def get_vars(path, entity):

        inventory_path = path
        # create inventory
        inventory_manager = InventoryManager(loader=vars_loader, sources=['%s' % inventory_path])
        # get entity from inventory
        entity_object = inventory_manager.get_entity(to_text(entity))
        # get vars
        var_manager = VarsModule()
        vars = var_manager.get_vars(loader=vars_loader, path=inventory_path, entities=entity_object)

        return vars


    # create temporary directory with group_vars and host_vars
    temp_

# Generated at 2022-06-21 07:47:14.442545
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import shutil
    import tempfile
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # prepare temp directory
    tmp_dir = tempfile.mkdtemp()
    os.mkdir(tmp_dir + "/host_vars")
    os.mkdir(tmp_dir + "/group_vars")
    os.mkdir(tmp_dir + "/custom")

    # prepare files
    with open(tmp_dir + "/host_vars/test_host", "w+") as f:
        f.write("var1_host: test1\nvar2: test2")

# Generated at 2022-06-21 07:47:25.518514
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    vars = VarsModule()
    vars._display = DictDataLoader()
    vars._display.verbosity = 3
    vars._get_file_vars = mock_unfrackpath_noop
    vars._loader = DictDataLoader()
    vars._loader._basedir = '/'
    vars._host_name = 'host_name'
    vars._host_name_key = 'host_name_key'
    vars._host_name_files = ['/etc/ansible/host_vars/host_name', '/etc/ansible/group_vars/all']
    vars._host_name_data = dict()
    vars._

# Generated at 2022-06-21 07:47:30.720477
# Unit test for constructor of class VarsModule
def test_VarsModule():
    config = dict()
    config['DEFAULT_HOST_LIST'] = '/root/DEFAULT_HOST_LIST'
    config['DEFAULT_GROUP_LIST'] = '/root/DEFAULT_GROUP_LIST'
    config['DEFAULT_HOST_PATTERN'] = None
    config['DEFAULT_MODULE_NAME'] = None
    config['DEFAULT_MODULE_PATH'] = None
    config['DEFAULT_FORKS'] = None
    config['DEFAULT_MODULE_ARGS'] = None
    config['DEFAULT_MODULE_LANG'] = None
    config['DEFAULT_TIMEOUT'] = None
    config['DEFAULT_POLL_INTERVAL'] = None
    config['DEFAULT_REMOTE_USER'] = None
    config['DEFAULT_ASK_PASS'] = None

# Generated at 2022-06-21 07:47:31.916052
# Unit test for constructor of class VarsModule
def test_VarsModule():
	assert VarsModule is not None

# Generated at 2022-06-21 07:47:37.181986
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Test empty entities
    entities = []
    plugin = VarsModule()
    result = plugin.get_vars(None, None, entities)
    assert (result=={})
    # Test list with 1 entity
    entities = [Host(name='host1')]
    result = plugin.get_vars(None, None, entities)
    assert (result=={Host: {'host1': {}}})

# Generated at 2022-06-21 07:47:39.826451
# Unit test for constructor of class VarsModule
def test_VarsModule():
    module = VarsModule()
    assert module.get_vars("loader", "path", "entities", cache=True) == {}

# Generated at 2022-06-21 07:47:51.495131
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    global FOUND

    FOUND = {}
    fake_loader = FakeLoader()
    vars_module = VarsModule()

    #test with path that don't exist
    data = vars_module.get_vars(fake_loader, "", "host1", cache=True)
    assert data == {}
    data = vars_module.get_vars(fake_loader, "", "group1", cache=True)
    assert data == {}

    #test with path that exist
    data = vars_module.get_vars(fake_loader, "path/to/basedir", "host1", cache=True)

# Generated at 2022-06-21 07:47:53.613078
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, BaseVarsPlugin)
    assert v.REQUIRES_WHITELIST is True


# Generated at 2022-06-21 07:48:06.371474
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''Check the get_vars method of class VarsModule'''
    # pylint: disable=unused-argument
    loader = None
    path = None
    entities = None

    print("\nChecking get_vars method of class VarsModule")

    # Test the case when entities is not a list
    print("\nTesting the case when entities is not a list")
    print(
        "Checking the exception when entities is not a list",
        end="", flush=True
    )
    try:
        vars_module = VarsModule()
        vars_module.get_vars(loader, path, entities)
        print(" .... failed")
    except AnsibleParserError as e:
        print(" ... passed")
        print("\tException message: %s" % e)

    # Test the case

# Generated at 2022-06-21 07:48:53.308560
# Unit test for constructor of class VarsModule
def test_VarsModule():
    V = VarsModule()
    assert isinstance(V, BaseVarsPlugin)
    assert hasattr(V, 'get_vars')
    assert hasattr(V, '_valid_extensions')
    assert V._valid_extensions == [".yml", ".yaml", ".json"]

# Generated at 2022-06-21 07:48:58.394635
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert isinstance(v, VarsModule)

# Generated at 2022-06-21 07:49:00.842532
# Unit test for constructor of class VarsModule
def test_VarsModule():
    ''' unit testing for VarsModule() constructor '''
    m = VarsModule()
    assert isinstance(m, VarsModule)


# Generated at 2022-06-21 07:49:02.081550
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:49:12.335898
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    dir_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..'))
    loader = DictDataLoader({'loader_dir_path': dir_path})
    c = VarsModule()
    c._basedir = os.path.realpath(os.path.join(os.path.dirname(__file__), 'examples', 'host_group_vars'))
    host = Host('host1')
    host._vars_cache = {}
    # Test file in host_vars
    assert c.get_vars(loader, os.path.realpath(os.path.join(os.path.dirname(__file__), 'examples', 'host_group_vars')), host) == {}
    assert host._vars_cache

# Generated at 2022-06-21 07:49:13.623689
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module_test = VarsModule()
    assert vars_module_test



# Generated at 2022-06-21 07:49:15.007677
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    assert vm.__class__.__name__ == 'VarsModule'

# Generated at 2022-06-21 07:49:15.794812
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()


# Generated at 2022-06-21 07:49:21.020995
# Unit test for constructor of class VarsModule
def test_VarsModule():
    import os
    from ansible.constants import DEFAULT_VAULTS_ENCRYPT_METHOD
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    class AnsibleOptions(object):
        def __init__(self):
            self.__dict__ = dict(
                vault_password='secret',
                vault_identity='key.pem',
                _vault_secrets=[],
                vault_encrypt_key=DEFAULT_VAULTS_ENCRYPT_METHOD,
            )
    class AnsibleVaultEncryptedFile(object):
        def __init__(self):
            self._vault = dict(
                password='secret',
                secret='xyz',
            )

# Generated at 2022-06-21 07:49:22.215389
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert v