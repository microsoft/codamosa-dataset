

# Generated at 2022-06-21 07:40:30.401873
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    raise NotImplementedError

# Generated at 2022-06-21 07:40:41.214371
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    plugin = VarsModule()

    # overrides required to bypass file-related calls
    plugin._get_basedir = lambda x: '/home/vagrant/test_VarsModule'
    plugin.get_file_loader = lambda x: FakeFileLoader()

    host = Host(name='host1', port=22)

    result = plugin.get_vars(path='/home/vagrant/test_VarsModule/host_vars', entities=[host])
    assert result == {'host_1': 'foo', 'host_2': 'bar'}


fake_content = {
    'host_vars/host1.yml': 'host_1: foo',
    'host_vars/host2.yml': 'host_2: bar'
}

# faked class to run unit test

# Generated at 2022-06-21 07:40:52.111426
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-21 07:40:53.710037
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule(None, None, None)

# Generated at 2022-06-21 07:40:56.504770
# Unit test for constructor of class VarsModule
def test_VarsModule():
    b_wanted = "VarsModule(priority=50, basedir=None, staged=False)"
    wanted = to_native(b_wanted)
    result = to_native(VarsModule(None, '', False))
    assert result == wanted, "%r != %r" % (result, wanted)

# Generated at 2022-06-21 07:41:05.479963
# Unit test for constructor of class VarsModule
def test_VarsModule():
    class ModuleTest(VarsModule):

        # default StageableObjects
        stage = None
        vars_files = None
        play_context = None
        new_stdin = None

    vars_module = ModuleTest()
    assert vars_module.stage.vars_plugin_name == 'host_group_vars'
    assert vars_module.stage.plugin_name == 'host_group_vars'
    assert vars_module.stage.vars_plugins.vars_plugins == [vars_module]
    assert vars_module.stage.name == 'host_group_vars'
    assert vars_module.stage.plugin_vars == []
    assert vars_module.stage.config_vars == []
    assert vars_module.stage.plugin_vars == []

# Generated at 2022-06-21 07:41:07.453904
# Unit test for constructor of class VarsModule
def test_VarsModule():

    vm = VarsModule()
    assert vm.get_option("stage") is None

# Generated at 2022-06-21 07:41:15.599126
# Unit test for constructor of class VarsModule
def test_VarsModule():
    class FakeLoader(object):
        class FakeVaultLib(object):
            class FakeVaultEditor(object):
                def __init__(self):
                    pass

            def __init__(self):
                self.vault = VarsModule.VaultEditor()

        def find_vars_files(self, directory, filename):
            pass

        def load_from_file(self, filename, cache=True, unsafe=False):
            pass

    class FakeDisplay(object):
        def __init__(self, verbosity):
            pass

        def debug(self, msg):
            pass

        def verbose(self, msg):
            pass

        def warning(self, msg):
            pass

        def deprecate(self, msg, version, removed=False):
            pass

        def banner(self, msg):
            pass



# Generated at 2022-06-21 07:41:25.203258
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    # We are testing the path load feature specific to the host_group_vars plugin
    # Hence we will be loading an inventory with a group and a host and then loading
    # group_vars/ host_vars/ as required.
    data_loader = DataLoader()
    add_all_plugin_dirs()

# Generated at 2022-06-21 07:41:27.112375
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # ToDo - implement test
    pass


# Generated at 2022-06-21 07:41:43.749985
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    '''
    test cases for the VarsModule class
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    #Create the loader object so that we can mock data
    loader = DataLoader()

    # Create the PlayContext object so that we can mock data
    context = PlayContext()

    # Create the inventory to pass to the variable manager
    hosts = ['testhost', 'testhost2']
    groups = {'all': {'hosts': ['testhost', 'testhost2']}}
    inventory = InventoryManager(loader=loader, sources=None)
    inventory.add_group('all')

# Generated at 2022-06-21 07:41:45.887606
# Unit test for constructor of class VarsModule
def test_VarsModule():
    myplugin = VarsModule()
    print(myplugin.__str__())

# Generated at 2022-06-21 07:41:48.753471
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # TODO: find a way to test the method get_vars of class VarsModule
    pass

# Generated at 2022-06-21 07:41:49.659833
# Unit test for constructor of class VarsModule
def test_VarsModule():
    v = VarsModule()
    assert v is not None

# Generated at 2022-06-21 07:41:59.269265
# Unit test for constructor of class VarsModule
def test_VarsModule():
    paths_to_mock = {
        'host_vars': '/host_vars/',
        'group_vars': '/group_vars/',
        '_basedir': '/'
    }
    mock_class = type('MockVarsModule', (VarsModule,), paths_to_mock)
    vm = mock_class()
    assert vm.get_vars(None, None, None) == {}, "Host or Group entity is required to load vars"

# Generated at 2022-06-21 07:42:06.093761
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # construct an inventory source path for testing
    inventory_source_path = '/etc/ansible/hosts'

    # construct a class for testing
    vars_module_instance = VarsModule()

    # attempt to extract the "stage" property of the class
    stage_property = vars_module_instance.get_option('stage')

    # assert expected outcome - the stage value should be 'default'
    assert stage_property == 'default'

    # attempt to extract the "valid extensions" property of the class
    valid_extensions_property = vars_module_instance.get_option('_valid_extensions')

    # assert expected outcome - the stage value should be '.yml', '.yaml', and '.json'
    assert valid_extensions_property == ['.yml', '.yaml', '.json']

    # call get_v

# Generated at 2022-06-21 07:42:15.285793
# Unit test for method get_vars of class VarsModule

# Generated at 2022-06-21 07:42:24.687410
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    import os
    import sys
    import unittest

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    from ansible.plugins.vars import BaseVarsPlugin

    class TestVarsModule(unittest.TestCase):

        def setUp(self):
            # Prepare the test environment:
            os.environ = {'ANSIBLE_CONFIG': '/tmp/ansible.cfg'}
            sys.path.append(os.path.abspath('../vars'))
            # Instantiate the test class:
            self.varsModule = VarsModule()
            # Prepare a few test variables:

# Generated at 2022-06-21 07:42:36.058822
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # ensure that the variable files are being read correctly
    # and combined correctly when multiple are found

    # load a Hoat, Group, and a Host without a subdir dir
    hosts = [Host(name='test1', port=22, vars={}, groups=[],
                            default_vars={}, inventory=None,
                realname='test1', address='127.0.0.1'),
            Group(name='test2', vars={}, hosts=[],
                    children=[], inventory=None),
            Host(name='/path/to/chroot', port=22, vars={}, groups=[],
                default_vars={}, inventory=None,
                realname='/path/to/chroot', address='127.0.0.1')]

    # create an instance of the class
    loader = VarsModule()

    #

# Generated at 2022-06-21 07:42:37.411868
# Unit test for constructor of class VarsModule
def test_VarsModule():
    tester = VarsModule()
    assert tester.REQUIRES_WHITELIST == True



# Generated at 2022-06-21 07:42:45.872323
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars = VarsModule()
    assert vars._valid_extensions == ["", ".yml", ".yaml", ".json"]


# Generated at 2022-06-21 07:42:47.918371
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert isinstance(vars_module, BaseVarsPlugin)
    assert vars_module._valid_extensions == [".yml", ".yaml", ".json"]

# Generated at 2022-06-21 07:42:48.877578
# Unit test for constructor of class VarsModule
def test_VarsModule():
    plugin = VarsModule()
    assert plugin == plugin

# Generated at 2022-06-21 07:42:50.566936
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_plugin = VarsModule()
    assert vars_plugin.get_vars(None, "", "") == {}

# Generated at 2022-06-21 07:42:51.409307
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule()

# Generated at 2022-06-21 07:42:57.681530
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # Initialization and setup
    entity = Host(name='test_name')
    entities = [entity]
    loader = None
    path = C.DEFAULT_HOST_LIST
    cache = True
    FOUND.clear()

    # Get instance of VarsModule
    vars_module_instance = VarsModule()

    # Variables to check if are set to default values
    assert vars_module_instance._basedir == '.'

    # Get_vars method returns False for default values
    vars_dict = vars_module_instance.get_vars(loader, path, entities, cache)
    assert not vars_dict

# Generated at 2022-06-21 07:43:04.956013
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """
    Test method get_vars()
    """
    test_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../testing'))
    loader = DictDataLoader({'hosts': {'test': {'hosts': ['test1', 'test2']},
                                       'test1': {'hosts': [], 'vars': {'test1var': 'test1value'}},
                                       'test2': {'hosts': [], 'vars': {'test2var': 'test2value'}}}})
    plugin = VarsModule({})
    data = plugin.get_vars(loader, test_path, [Group('test'), Group('test1'), Group('test2')])
    assert 'test1var' in data

# Generated at 2022-06-21 07:43:05.831603
# Unit test for constructor of class VarsModule
def test_VarsModule():
    pass

# Generated at 2022-06-21 07:43:08.102874
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule.REQUIRES_WHITELIST == True

# Generated at 2022-06-21 07:43:17.616378
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    # basic test to ensure that method get_vars of class VarsModule is working as expected
    #
    # here we are testing that the return types are correct

    host = Host("test1")
    host.vars = {}

    vars_module = VarsModule()
    host_vars = vars_module.get_vars({}, "", host)

    assert isinstance(host_vars, dict)

    group = Group("test_group", "test1")
    group.vars = {}

    group_vars = vars_module.get_vars({}, "", group)

    assert isinstance(group_vars, dict)

# Generated at 2022-06-21 07:43:30.560939
# Unit test for constructor of class VarsModule
def test_VarsModule():
    module = VarsModule()
    assert module

# Generated at 2022-06-21 07:43:36.784463
# Unit test for constructor of class VarsModule
def test_VarsModule():

    #Create an object of Class VarsModule
    class_obj = VarsModule()
    assert isinstance(class_obj, VarsModule)
    assert isinstance(class_obj, BaseVarsPlugin)
    assert hasattr(class_obj, 'get_vars')
    assert callable(getattr(class_obj, "get_vars"))
    assert hasattr(class_obj, 'REQUIRES_WHITELIST')
    assert isinstance(class_obj.REQUIRES_WHITELIST, bool)

# Generated at 2022-06-21 07:43:48.999982
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # class Group definition has changed. We need to mock it
    class Group:
        def __init__(self, name):
            self.name = name

    # class Host definition has changed. We need to mock it
    class Host:
        def __init__(self, name):
            self.name = name

    # class VarsModule definition has changed. We need to mock it
    class VarsModule(BaseVarsPlugin):
        _basedir = os.path.dirname(os.path.realpath(__file__))
        _display = None


        def get_vars(self, loader, path, entities, cache=True):
            return super(VarsModule, self).get_vars(loader, path, entities, cache)


    # Mocking object loader

# Generated at 2022-06-21 07:43:55.715228
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    test_loader = {}
    test_path = 'test_path'
    test_entities = ['test_entity']
    test_cache = True
    test_varsmodule = VarsModule()
    result = test_varsmodule.get_vars(loader=test_loader, path=test_path, entities=test_entities, cache=test_cache)
    assert result == {}

# Generated at 2022-06-21 07:43:56.663846
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    pass

# Generated at 2022-06-21 07:43:57.451819
# Unit test for constructor of class VarsModule
def test_VarsModule():
    assert VarsModule

# Generated at 2022-06-21 07:44:06.046226
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    """ Unit tests for class VarsModule and method get_vars """

    class fake_host:
        def __init__(self, name, address=None):
            self.name = name
            self.address = address
        def get_name(self):
            return self.name
        def get_address(self):
            return self.address

    class fake_loader:
        def find_vars_files(self, opath, entity_name):
            return [entity_name, 'host_vars/all']

        def load_from_file(self, found, cache=True, unsafe=True):
            return {found: 'test'}

    class fake_display:
        def warning(self, msg):
            pass

        def debug(self, msg):
            pass

    loader = fake_loader()
    display = fake

# Generated at 2022-06-21 07:44:17.189703
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    class Object(object):
        pass

    class VarsPluginModule(VarsModule):
        def __init__(self):
            self.AnsibleParserError = AnsibleParserError
            self.AnsibleUndefinedVariable = AnsibleUndefinedVariable
            self.AnsibleFallbackNotFound = AnsibleFallbackNotFound
            self.to_text = to_text

    class MockModuleLoader(object):
        def __init__(self, arg):
            self.name = arg

        def load_from_file(self, file_name, cache, unsafe):
            return file_name

        def find_vars_files(self, path, entity_name):
            return path

    obj = Object()
    obj.AnsibleUndefinedVariable = AnsibleUndefinedVariable

    loader = MockModuleLoader('mock_loader')


# Generated at 2022-06-21 07:44:27.079776
# Unit test for constructor of class VarsModule
def test_VarsModule():
    path = "."
    entities = []
    basedir = "."
    vm = VarsModule(path, entities)
    vm._vars_plugins_so_far = []
    vm._vars_per_host = {}
    vm._hosts_cache = []
    vm._hosts_cache_extra_vals = {}
    vm._hosts_cache_all_group_names = []
    vm._hosts_cache_unmatched_patterns = []
    vm._hosts_cache_all_group_names = []
    vm._play = None

# Generated at 2022-06-21 07:44:38.957960
# Unit test for constructor of class VarsModule
def test_VarsModule():
    
    # use a fake inventory to work with
    class FakeInventory():
        path='path'  # required by _get_base_vars method
        base_cache={}

    # create the instance and test its values
    instance = VarsModule(FakeInventory())
    assert instance._valid_extensions == [".yml", ".yaml", ".json"]
    assert instance._cache == {}
    assert instance._base_cache == {}
    assert instance._basedir == 'path'
    assert instance._stage == 'gather_vars'
    assert instance._stages == ['gather_vars', 'all', 'post_validate']

    # create a fake loader and run get_vars method - this will process a directory
    # of group_vars in the 'gather_vars' stage

# Generated at 2022-06-21 07:45:30.611184
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    # For module 'host_group_vars', the class is VarsModule,
    # and the method to test is get_vars()
    module = 'host_group_vars'
    module_class = VarsModule.__name__
    module_function = 'get_vars'

    _showobj = ShowObj(showerror=False)

    # Set up a parent object to pass to the method being tested
    # Its name is ParentClass, and the module is 'parent_module'
    parent_class = VarsModule.__name__
    parent_module = module
    parent_obj = ShowObj(showerror=False)

    # Dictionary entry for the parent_class
    showobj_dict = { parent_class: parent_obj }

    # Set up a display_callback_method to pass to the method being tested
   

# Generated at 2022-06-21 07:45:33.053405
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module, 'VarsModule() returned nothing'


# Generated at 2022-06-21 07:45:36.002983
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    ret = VarsModule().get_vars(
       loader,
       path,
       [
          mock_obj_Host(name='host1' ),
          mock_obj_Group(name='group2')
       ]
    )
    assert ret == {
        'host1': 'host1_Vars',
        'group2': 'group2_Vars'
    }


# Mock object for Ansible class Host

# Generated at 2022-06-21 07:45:44.047200
# Unit test for constructor of class VarsModule
def test_VarsModule():
    global FOUND

    FOUND = {}
    for entity in (Host('h1.example.com'), Group('ungrouped')):
        s = VarsModule()
        s._basedir = './'
        vars = s.get_vars(loader='', path='', entities=entity, cache=True)
        assert vars == {}
        assert FOUND != {}
        FOUND = {}
        vars = s.get_vars(loader='', path='', entities=entity, cache=False)
        assert vars == {}
        assert FOUND != {}



# Generated at 2022-06-21 07:45:51.295683
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    vars_module = VarsModule()

    # setup data for test
    def load_from_file(filename, cache=False, unsafe=False, follow_symlinks=False):
        vars_ = {
            'group_vars/all': {'gvar1': 'gvarvalue1'},
            'host_vars/hostname1': {'hvar1': 'hvarvalue1'},
            'host_vars/hostname2': {'hvar2': 'hvarvalue2'},
        }
        return vars_.get(filename)

    class Loader():
        def find_vars_files(self, include_path, host=None):
            basedir = './candidate_vars'

# Generated at 2022-06-21 07:45:53.827670
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_plugin = VarsModule()
    assert isinstance(vars_plugin, VarsModule)



# Generated at 2022-06-21 07:45:56.067714
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module.REQUIRES_WHITELIST is True


# Generated at 2022-06-21 07:45:57.100436
# Unit test for constructor of class VarsModule
def test_VarsModule():
    mod = VarsModule()

# Generated at 2022-06-21 07:46:05.024812
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import ansible.plugins.loader as plugin_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # set up class variables and instance variables
    basedir = os.getcwd()
    entities = Host(name='localhost')

    # set up mock inventory and return data
    class MockInventory:
        basedir = '/some_inventory/'
        vars = {'some_var': 'some_value'}

    # set up mock loader and return data
    class MockLoader:
        class MockData:
            def __init__(self, basedir):
                self.basedir = basedir

            def get_basedir(self):
                return self.basedir


# Generated at 2022-06-21 07:46:16.420568
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():

    def fake_get_vars(a, b, c, d=True):
        return "fake_get_vars"

    # 1. test get_vars() with os.path.isdir=lambda path: True, os.path.exists=lambda path: True, loader.find_vars_files=lambda opath, entity_name: ['/path/to/directory/'+entity_name+'-group.yml', '/path/to/directory/'+entity_name+'-host.yml']
    group = Group('testgroup')
    path = '/path/to/directory'
    entities = [group]
    fake_config = {'yaml_valid_extensions': ['.yaml', '.yml'], 'vars_plugins': ['host_group_vars']}

# Generated at 2022-06-21 07:47:21.600571
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import os
    import shutil
    import tempfile
    import yaml
    from ansible.plugins.loader import vars_loader

    # create a temporary directory to work in
    tmp_dir = tempfile.mkdtemp()
    # create the directory structure to test with
    dirs = ['group_vars', 'host_vars', 'inventory']
    for d in dirs:
        os.mkdir(os.path.join(tmp_dir, d))
    # create the vars files used in tests

# Generated at 2022-06-21 07:47:23.627985
# Unit test for constructor of class VarsModule
def test_VarsModule():
    VarsModule()

# Generated at 2022-06-21 07:47:24.167041
# Unit test for constructor of class VarsModule
def test_VarsModule():

    assert VarsModule()

# Generated at 2022-06-21 07:47:35.410693
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_mod = VarsModule()
    vars_mod._load_name = 'host_group_vars'
    vars_mod._basedir = '/home/user/ansible'
    vars_mod._vault_password = 'password'
    vars_mod._display = C.DISPLAY
    vars_mod._zipped_mod_path = '/home/user/ansible/zipped_path'

    assert vars_mod._load_name == 'host_group_vars'
    assert vars_mod._basedir == '/home/user/ansible'
    assert vars_mod._vault_password == 'password'
    assert vars_mod._display == C.DISPLAY
    assert vars_mod._zipped_mod_path == '/home/user/ansible/zipped_path'

# Generated at 2022-06-21 07:47:46.586789
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import shutil

    v = VarsModule()
    v._basedir = "/tmp/vars_plugin_test"
    shutil.rmtree(v._basedir, True)
    os.makedirs(v._basedir)
    os.makedirs(v._basedir + "/host_vars")
    os.makedirs(v._basedir + "/group_vars")

    #
    # Initialize test inventory
    #
    v._inventory = C.DEFAULT_HOST_LIST

    def _create_file(path, content):
        f = open(path, 'w')
        f.write(content)
        f.close()
    #
    # Create host_vars file
    #
    host_vars = v._basedir + "/host_vars/test.yml"

# Generated at 2022-06-21 07:47:54.896407
# Unit test for constructor of class VarsModule
def test_VarsModule():
    # Following lines are required so that the plugin code
    # can be tested independently of a real Ansible run.
    import ansible.plugins
    import ansible.plugins.loader
    valid_exts = VarsModule.doc_fragments['options'][
        '_valid_extensions']['default']
    ansible.plugins.loader.add_all_plugin_dirs()
    ansible.plugins.__init__()
    ansible.plugins.vars._load_plugins(valid_exts)
    # Instantiate the plugin
    plugin = VarsModule()
    return plugin

# Generated at 2022-06-21 07:48:07.558542
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    import tempfile, shutil

# Generated at 2022-06-21 07:48:11.278487
# Unit test for constructor of class VarsModule
def test_VarsModule():
    """Create object for VarsModule and test for parameters"""

    arg = {'plugin_name': 'host_group_vars', 'stage': 'any'}
    obj = VarsModule(**arg)
    obj.get_vars(None, None, None)

    assert(obj._valid_extensions == [".yml", ".yaml", ".json"])

# Generated at 2022-06-21 07:48:15.760666
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vm = VarsModule()
    data = vm.get_vars(None, path=C.DEFAULT_HOST_LIST, entities=['localhost'])
    assert isinstance(data, dict)

# Generated at 2022-06-21 07:48:18.151408
# Unit test for constructor of class VarsModule
def test_VarsModule():
    vars_module = VarsModule()
    assert vars_module.__class__.__name__ == 'VarsModule'

# Generated at 2022-06-21 07:50:18.913602
# Unit test for constructor of class VarsModule
def test_VarsModule():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultEditor
    from ansible.plugins.loader import vars_loader

    datadir = 'test/unit/plugins/vars/data'
    basedir = 'test/unit/plugins/vars/host_group_vars'

    host = Host(name='fake_host')

    # This is a host that has a group that is named after it in group_vars/
    vars_plugin = VarsModule()
    vars_plugin.set_options(direct=dict(basedir=os.path.join(datadir, basedir)))

    # Test YAML Vars
    entity = host

# Generated at 2022-06-21 07:50:22.964929
# Unit test for method get_vars of class VarsModule
def test_VarsModule_get_vars():
    m = VarsModule()
    loader = None
    path = "data/extravars.yml"
    entities = "test"
    cache = False
    assert m.get_vars(loader, path, entities, cache) != {}