

# Generated at 2022-06-21 21:23:29.090416
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:23:34.307789
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("~/.bashrc") == os.path.expanduser("~/.bashrc")
    assert expand("/tmp/test") == "/tmp/test"
    assert expand("${HOME}/test") == os.path.expanduser("${HOME}/test")



# Generated at 2022-06-21 21:23:43.682892
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for the function load_env_file.

    """

    # A list with lines to test
    lines_to_test = ["LANG=C.UTF-8",
                     "PATH=/home/user1/bin:/home/user1/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin",
                     "HOME=/home/user1"]

    # Test results
    test_results = load_env_file(lines_to_test)

    # Check that the results are what we expect

# Generated at 2022-06-21 21:23:48.712606
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:23:51.219322
# Unit test for function expand
def test_expand():
    assert expand(os.environ["HOME"] + "/yeee") == os.path.expanduser(os.environ["HOME"]) + "/yeee"



# Generated at 2022-06-21 21:24:00.722372
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ("TEST", expand("${HOME}/yeee")),
        ("THISIS", expand("~/a/test")),
        ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))
    ]



# Generated at 2022-06-21 21:24:05.961382
# Unit test for function expand
def test_expand():
    assert expand('~/foo') == os.path.expanduser('~/foo')
    assert expand('~/foo') == expand('${HOME}/foo')
    assert expand(os.environ['HOME']) == expand('$HOME')

    os.environ['TEST'] = 'foo'
    assert expand('$TEST') == os.environ['TEST']



# Generated at 2022-06-21 21:24:15.615272
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['HOME=foo', 'TEST=bar'], write_environ=dict()) == collections.OrderedDict([('HOME', 'foo'), ('TEST', 'bar')])
    assert load_env_file(['HOME=foo', 'TEST=bar'], write_environ=dict()) == collections.OrderedDict([('HOME', 'foo'), ('TEST', 'bar')])
    assert load_env_file(['HOME="foo"', 'TEST="bar"'], write_environ=dict()) == collections.OrderedDict([('HOME', 'foo'), ('TEST', 'bar')])

# Generated at 2022-06-21 21:24:19.977235
# Unit test for function expand
def test_expand():
    for i in ['$HOME', '~', '~/../$HOME']:
        assert expand(i) == os.path.expanduser(os.path.expandvars(i))


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:24:25.421484
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:24:30.428060
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "mytest"
    assert expand("$TEST") == "mytest"
    assert expand("~/.config") == os.path.expanduser("~/.config")



# Generated at 2022-06-21 21:24:32.593298
# Unit test for function expand
def test_expand():
    assert expand("${PATH}") == os.environ["PATH"]

# Generated at 2022-06-21 21:24:33.879923
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ.get('HOME')



# Generated at 2022-06-21 21:24:41.478223
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    <generator object parse_env_file_contents at ...>
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(parse_env_file_contents(lines))



# Generated at 2022-06-21 21:24:49.208685
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Using the same values as in the example above
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_values = parse_env_file_contents(lines=lines)

    assert list(parsed_values) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-21 21:24:51.270358
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == os.path.expanduser('~/test')

# Generated at 2022-06-21 21:24:54.020976
# Unit test for function expand
def test_expand():
    # Test that we can expand a path
    assert expand('$HOME') == expand(os.path.expanduser('~'))



# Generated at 2022-06-21 21:24:58.981820
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, dict())



# Generated at 2022-06-21 21:25:05.264641
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            load_env_file(lines, write_environ=dict())

    unittest.main()

# Generated at 2022-06-21 21:25:16.545614
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import textwrap
    import unittest

    import os
    import shutil

    from nose.tools import eq_

    class TestLoadEnvFile(unittest.TestCase):
        def setUp(self):
            self.env = {}
            self.content = textwrap.dedent("""\
                TEST=${HOME}/yeee-$PATH
                THISIS=~/a/test
                YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
                FOO=u$USER

                # A comment on its own line
                BAZ=another\
                variable
            """)
            self.tmp = tempfile.mkdtemp()
            self.env_file = os.path.join(self.tmp, 'env_file')
           

# Generated at 2022-06-21 21:25:27.881372
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function load_env_file
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', os.environ['HOME'] + '/yeee-' + os.environ['PATH']), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

# Generated at 2022-06-21 21:25:37.084754
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = '/some/path/with/values'
    os.environ['TEST2'] = 'abcdef'

    assert expand('~/my/path') == os.path.expandvars(os.path.expanduser('~/my/path'))
    assert expand('${TEST}/folder') == os.path.expandvars(os.path.expanduser('${TEST}/folder'))
    assert expand('${TEST2}/$PATH') == os.path.expandvars(os.path.expanduser('${TEST2}/$PATH'))

# Generated at 2022-06-21 21:25:38.782134
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:25:42.696829
# Unit test for function expand
def test_expand():
    # Home directory
    assert expand('~') == os.path.expanduser('~')

    # Environment variable
    assert expand('$HOME') == os.environ['HOME']


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-21 21:25:46.327509
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME/test') == os.path.expandvars('$HOME/test')



# Generated at 2022-06-21 21:25:52.429569
# Unit test for function expand
def test_expand():
    # https://stackoverflow.com/a/15089844/4976758
    import os

    os.environ["HOME"] = "/home/user"
    assert os.path.expanduser("~/test") == "/home/user/test"

    assert os.path.expandvars("$HOME/test") == "/home/user/test"
    assert os.path.expandvars("${HOME}/${HOME}/test") == "/home/user/home/user/test"

# Generated at 2022-06-21 21:25:56.884253
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-21 21:26:06.454439
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)
    assert next(output) == ('TEST', '.../yeee')
    assert next(output) == ('THISIS', '.../a/test')
    assert next(output) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:26:18.651538
# Unit test for function expand
def test_expand():
    test_path = '~/test/path'
    test_path_expanded = expand(test_path)
    assert test_path_expanded[0] == '/'

    test_var = '$HOME/test/path'
    test_var_expanded = expand(test_var)
    assert test_var_expanded[0] == '/'

    test_var2 = '${HOME}/test/path'
    test_var2_expanded = expand(test_var2)
    assert test_var2_expanded[0] == '/'

    test_var3 = '${HOMEEE}/test/path'
    test_var3_expanded = expand(test_var3)
    assert test_var3_expanded == '${HOMEEE}/test/path'



# Generated at 2022-06-21 21:26:28.337922
# Unit test for function load_env_file
def test_load_env_file():
    # Provided example
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    environ = dict()

    changes = load_env_file(lines, write_environ=environ)

    assert changes
    assert changes['TEST'] == f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'
    assert environ['TEST'] == f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'
    assert changes['THISIS'] == f'{os.environ["HOME"]}/a/test'


# Generated at 2022-06-21 21:26:37.531377
# Unit test for function expand
def test_expand():
    # os.environ["TEST_VAR"] = "/test/path"
    # print("TEST_VAR: ", expand("$TEST_VAR"))
    # print("TEST_VAR with : ", expand("$TEST_VAR:"))
    # os.environ["TEST_VAR"] = "test"
    # print("TEST_VAR: ", expand("${TEST_VAR}"))
    # print("TEST_VAR: ", expand("$TEST_VAR"))
    pass


if __name__ == "__main__":
    test_expand()

# Generated at 2022-06-21 21:26:42.889787
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    output = parse_env_file_contents(lines=(
        'TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

    assert list(output) == [('TEST', '.../.../yeee'), ('THISIS', '.../a/test'),
                            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:26:47.943168
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:26:49.002172
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert tuple(parse_env_file_contents([])) == ()



# Generated at 2022-06-21 21:26:52.906694
# Unit test for function expand
def test_expand():
    assert expand("~/a/b/c") == "/home/travis/a/b/c"
    assert expand("~/a/b/$PATH") == "/home/travis/a/b/:/home/travis/.local/bin/:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin"



# Generated at 2022-06-21 21:27:03.720202
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests parsing env file contents.
    """
    lines = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.split("\n")

    result = dict(parse_env_file_contents(lines))
    assert result['TEST'] == "${HOME}/yeee"
    assert result['THISIS'] == "~/a/test"
    assert result['YOLO'] == "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-21 21:27:07.578872
# Unit test for function expand
def test_expand():
    # Use ${HOME}/{tmp}
    home = os.environ['HOME']
    val = '{}/{}'.format(home, 'tmp')

    # Check that expand() returns the correct value
    assert expand('$HOME/tmp') == val



# Generated at 2022-06-21 21:27:15.324509
# Unit test for function expand
def test_expand():
    line = '$PWD/test'
    assert os.path.exists(expand(line))

    line = '~/test'
    assert os.path.exists(expand(line))

    line = '~/notathingnotathingnotathing'
    assert not os.path.exists(expand(line))

    line = '${PWD}/test'
    assert os.path.exists(expand(line))



# Generated at 2022-06-21 21:27:26.277697
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'TEST=$COLDPLAY')
        f.write(b'THISIS=  "$HOME"')
        f.write(b'YOLO=\'$HOME\'')
        f.write(b'RAW="$HOME"')
        f.flush()
        with open(f.name) as fh:
            values = parse_env_file_contents(fh)
            expected = [('TEST', '$COLDPLAY'), ('THISIS', '  "$HOME"'), ('YOLO', '\'$HOME\''), ('RAW', '"$HOME"')]
            for key, val in values:
                assert (key, val) in expected, 'env variable {} not found in output'.format(val)

# Generated at 2022-06-21 21:27:38.132604
# Unit test for function expand
def test_expand():
    import re
    import os

    os.environ['TEST_VAR'] = 'it_works!'
    assert expand('$TEST_VAR') == 'it_works!'

    os.environ['NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'] = ''
    assert expand('${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}') == ''

    os.environ['TEST_VAR'] = 'it_works!'
    assert expand('${TEST_VAR}yeee') == 'it_works!yeee'

    assert expand('~/a/test') == os.path.expanduser('~/a/test')

    os.environ['TEST_VAR'] = 'it_works!'

# Generated at 2022-06-21 21:27:46.263608
# Unit test for function expand
def test_expand():
    """
    >>> expand('~/.local/share/')
    '.../.local/share/'
    >>> expand('$HOME/.local/share/')
    '.../.local/share/'
    """
    pass



# Generated at 2022-06-21 21:27:54.621879
# Unit test for function expand
def test_expand():
    os.environ["TESTVAR"] = "testval"
    os.environ["HOME"] = "/home/foobar"
    os.environ["USER"] = "foobar"

    assert expand("~/test") == "/home/foobar/test"
    assert expand("${HOME}/test") == "/home/foobar/test"
    assert expand("$HOME/test") == "/home/foobar/test"
    assert expand("${TESTVAR}/test") == "testval/test"
    assert expand("~${USER}/test") == "/home/foobar/test"



# Generated at 2022-06-21 21:27:57.023847
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


# Run the unit tests, if called on its own.
if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:28:03.143933
# Unit test for function load_env_file
def test_load_env_file():
    print('Testing env_loader.load_env_file')

    env_file_lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    env_file_result = load_env_file(env_file_lines)

    assert 'TEST' in env_file_result
    assert 'THISIS' in env_file_result
    assert 'YOLO' in env_file_result


# Generated at 2022-06-21 21:28:06.405217
# Unit test for function expand
def test_expand():
    assert expand(expand('$HOME/test/$HOME')) == os.path.expandvars(expand('$HOME/test/$HOME'))



# Generated at 2022-06-21 21:28:13.457118
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import os

    test_settings_1 = r"""
    export TEST=${HOME}/yeee-$PATH
    export THISIS=~/a/test
    export YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """


    def test_load_env_file():
        assert isinstance(load_env_file(io.StringIO(test_settings_1)), dict)  # This should check if the function returns an OrderedDict.



# Generated at 2022-06-21 21:28:18.139478
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.getenv('HOME')
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-21 21:28:20.224367
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-21 21:28:26.355530
# Unit test for function load_env_file
def test_load_env_file():
    env_path = os.path.join(os.path.dirname(__file__), 'sample.env')
    with open(env_path) as f:
        lines = f.readlines()

    env = load_env_file(lines, write_environ=dict())
    assert env == {
        'TEST1': 'test1',
        'TEST2': 'test2',
    }


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:28:28.251862
# Unit test for function expand
def test_expand():
    assert expand('$PATH') == os.getenv('PATH')
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-21 21:28:45.285614
# Unit test for function expand
def test_expand():
    # Test path expansion
    assert expand("./test.txt") == os.path.abspath("./test.txt")

    # Test environment variable expansion
    assert expand("$HOME") == os.environ["HOME"]

    # Test environment variable expansion with custom environment
    env = {}
    env["HOME"] = "/home/bla"
    assert expand("$HOME", env) == "/home/bla"

    # Test home expansion
    assert expand("~") == os.environ["HOME"]

    # Test home expansion with custom environment
    env = {}
    env["HOME"] = "/home/bla"
    assert expand("~", env) == "/home/bla"

    # Test home expansion with custom environment with no HOME variable
    env = {}
    assert expand("~", env) == "~"

# Generated at 2022-06-21 21:28:49.714428
# Unit test for function expand
def test_expand():
    assert expand('~/a') == os.path.expanduser('~/a')
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand('~/$HOME') == os.path.expandvars(os.path.expanduser('~/$HOME'))



# Generated at 2022-06-21 21:28:59.158141
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = load_env_file(lines, write_environ=dict())
    assert d['TEST'] != '${HOME}/yeee'
    assert d['THISIS'] != '~/a/test'
    assert d['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-21 21:29:06.392097
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    assert True



# Generated at 2022-06-21 21:29:10.032787
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ['HOME']

    home_path = expand('$HOME')

    assert expand(f'{home_path}/test') == os.path.join(home_path, 'test')



# Generated at 2022-06-21 21:29:12.398266
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:29:21.015096
# Unit test for function load_env_file
def test_load_env_file():
    for lines, output in [([], collections.OrderedDict()),
                          (['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
                           collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                                    ('THISIS', '.../a/test'),
                                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]))]:
        assert load_env_file(lines) == output
        assert load_env_file(lines, write_environ=None) == output



# Generated at 2022-06-21 21:29:28.201575
# Unit test for function expand
def test_expand():
    """
    Test function expand. This function is important because it is used in the function load_env_file.
    """

    assert expand("${HOME}") != "${HOME}"
    assert expand("${HOME}") == os.environ["HOME"]

    assert expand("~") == os.environ["HOME"]

    if os.name == "nt":
        assert expand("C:/Documents and Settings") == "C:/Documents and Settings"


if __name__ == "__main__":
    import pytest
    pytest.main(["test_env_parser.py"])

# Generated at 2022-06-21 21:29:37.021795
# Unit test for function load_env_file
def test_load_env_file():  # noqa: D103
    filename = os.path.join(os.path.dirname(__file__), "test.env")

    with open(filename, "r") as f:
        expected = load_env_file(["TEST=1"], write_environ=None)
        assert list(expected.values()) == ["1"]
        expected = load_env_file(f, write_environ=None)
        assert expected["TEST"] == "~/a/test"
        assert expected["TEST2"] == "~/a/test"
        assert expected["TEST3"] == "~/a/test"


if __name__ == "__main__":  # pragma: no cover
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:29:48.075971
# Unit test for function expand
def test_expand():
    assert expand("~/a/path/that/should/be/expanded") == os.path.expanduser("~/a/path/that/should/be/expanded")
    assert expand("$HOME/a/path/that/should/be/expanded") == os.path.expandvars("$HOME/a/path/that/should/be/expanded")
    assert expand("~/a/path/$PATH/and/then/some") == os.path.expanduser("~/a/path/$PATH/and/then/some")
    assert expand("$HOME/a/path/${PATH}/and/then/some") == os.path.expandvars("$HOME/a/path/${PATH}/and/then/some")

# Generated at 2022-06-21 21:30:05.375974
# Unit test for function load_env_file
def test_load_env_file():
    test_lines = ['TEST=VALUE']

    md = load_env_file(test_lines)

    assert isinstance(md, collections.OrderedDict)
    assert isinstance(md['TEST'], str)
    assert md['TEST'] == 'VALUE'

# Generated at 2022-06-21 21:30:12.989783
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(lines)

    expected = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert list(data) == expected



# Generated at 2022-06-21 21:30:23.046603
# Unit test for function load_env_file
def test_load_env_file():
    # save current environment variables
    env_before = {}
    for k, v in os.environ.items():
        env_before[k] = v
    # Test variable expansion without writing to os.environ
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=None)
    for k, v in changes.items():
        if k == 'TEST':
            assert os.path.expanduser('~') in v and '..' not in v and os.environ['PATH'] in v

# Generated at 2022-06-21 21:30:25.010454
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:30:31.429183
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ['HOME']
    assert expand('~/') == os.environ['HOME']
    assert expand('${HOME}/') == os.environ['HOME']+'/'
    assert expand('${FOO}/bar') == os.environ['FOO']+'/bar'



# Generated at 2022-06-21 21:30:36.894871
# Unit test for function expand
def test_expand():
    os.environ['TEST1'] = '$HOME/ENV'
    os.environ['TEST2'] = '~/ENV'
    assert expand('$TEST1') == os.path.expanduser('$HOME/ENV')
    assert expand('$TEST2') == os.path.expanduser('~/ENV')
    assert expand('${TEST2}') == os.path.expanduser('~/ENV')


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-21 21:30:48.963041
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import textwrap
    import unittest

    class LoadEnvFileTest(unittest.TestCase):
        def test_load_env_file(self):
            lines = textwrap.dedent('''
                TEST="$HOME/yeee-$PATH"
                THISIS=~/a/test
                YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
            ''').strip().splitlines()
            values = load_env_file(lines, write_environ=dict())

            for k, v in values.items():
                v = expand(v)
            self.assertEqual(values['TEST'], v)
            self.assertEqual(values['THISIS'], expand('~/a/test'))

# Generated at 2022-06-21 21:30:58.969428
# Unit test for function load_env_file
def test_load_env_file():
    env_file = """[[:alpha:]]+=(.*)
    '.*'
    \".*\""""

    import re

    env_file = re.sub("\n", "", env_file)
    match = re.findall(env_file, """TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST""")

    assert match == [
        '${HOME}/yeee',
        '~/a/test',
        '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]


# Generated at 2022-06-21 21:31:04.601168
# Unit test for function load_env_file
def test_load_env_file():
    from . import base

    env = base.load_env_file(None)
    assert isinstance(env, collections.OrderedDict)
    assert len(env) == 0


if __name__ == '__main__':
    import pytest

    pytest.main(['-s', __file__])

# Generated at 2022-06-21 21:31:15.350112
# Unit test for function load_env_file
def test_load_env_file():
    # Generate test data
    import tempfile
    from pathlib import Path

    with tempfile.NamedTemporaryFile("w", delete=False) as tmp:
        tmp.write("""TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """)

    # Test env file parsing
    with Path(tmp.name).open() as tmp:
        parsed = load_env_file(tmp)
    assert parsed["TEST"] == os.environ["HOME"] / "yeee-" / os.environ["PATH"]
    assert parsed["THISIS"] == Path.home() / "a" / "test"
    assert parsed["YOLO"] == Path.home()

# Generated at 2022-06-21 21:31:47.011374
# Unit test for function expand
def test_expand():
    assert os.path.exists(expand('~/'))
    assert os.path.exists(expand('$HOME/'))
    assert os.path.exists(expand('${HOME}/'))


if __name__ == '__main__':
    test_expand()

# Generated at 2022-06-21 21:31:51.969156
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ={})


if __name__ == '__main__':
    # unit test for function test_load_env_file
    test_load_env_file()

# Generated at 2022-06-21 21:31:56.773661
# Unit test for function expand
def test_expand():
    var = '${HOME}/yeee'
    var2 = '~/yeee'
    val = expand(var)
    val2 = expand(var2)
    assert val == val2, "vals are not equal"



# Generated at 2022-06-21 21:31:59.349543
# Unit test for function expand
def test_expand():
    unittest.main(module=__name__, argv=[sys.argv[0] + ' -v'], exit=False)



# Generated at 2022-06-21 21:32:07.565137
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ={}) == \
        collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                 ('THISIS', '.../a/test'),
                                 ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:32:18.843258
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = os.environ.copy()
    result = load_env_file(lines, write_environ=environ)

    assert environ == os.environ

    result = load_env_file(lines)

    assert result == {'TEST': '.../.../yeee-...:...',
                      'THISIS': '.../a/test',
                      'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}


# Generated at 2022-06-21 21:32:28.278364
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_full_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__), 'test_data'))
    test_env_file = os.path.join(test_full_path, 'test_env_file.txt')

    with open(test_env_file, 'r') as f:
        lines = f.readlines()

    env_dict = dict(parse_env_file_contents(lines))

    assert(env_dict['KEY_WITH_NO_FANCY_SYNTAX'] == 'VALUE_WITH_NO_FANCY_SYNTAX')
    asser

# Generated at 2022-06-21 21:32:38.448263
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    e = load_env_file(lines)


# Generated at 2022-06-21 21:32:47.949116
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines1 = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d1 = loads(dumps(parse_env_file_contents(lines1)))
    d1 = dict(d1)

    assert d1 == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-21 21:32:56.806125
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert changes['TEST'] == '.../.../yeee-...:...'
    assert changes['THISIS'] == '.../a/test'
    assert changes['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    return True

