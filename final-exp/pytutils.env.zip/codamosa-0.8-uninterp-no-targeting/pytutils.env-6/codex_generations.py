

# Generated at 2022-06-21 21:23:32.306560
# Unit test for function expand
def test_expand():
    HOME = expand('~')
    TEST = expand('$HOME/test')

    if HOME not in TEST:
        raise Exception()

# Generated at 2022-06-21 21:23:40.553192
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['HELLO=WORLD', 'YO=${HELLO}']
    write_environ = dict()
    d = load_env_file(lines, write_environ=write_environ)
    # print(d)
    # print(write_environ)
    assert d['HELLO'] == 'WORLD'
    assert d['YO'] == 'WORLD'
    assert write_environ['HELLO'] == 'WORLD'
    assert write_environ['YO'] == 'WORLD'
    assert len(d) == len(write_environ)


_LOADED_LIBS = set()



# Generated at 2022-06-21 21:23:44.783956
# Unit test for function expand
def test_expand():
    input = "${PATH}/yeee-$PATH"
    expected_output = '.../.../yeee-...:...'
    assert expand(input) == expected_output



# Generated at 2022-06-21 21:23:47.246925
# Unit test for function expand
def test_expand():
    assert expand("~/foo") == os.path.join(os.environ["HOME"], "foo")
    assert expand("$HOME/foo") == os.path.join(os.environ["HOME"], "foo")

# Generated at 2022-06-21 21:23:58.085721
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test function parse_env_file_contents
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    assert isinstance(result, collections.OrderedDict), "result is not an ordered dictionary"
    assert isinstance(result['TEST'], str), "result['TEST'] is not a string"
    assert isinstance(result['THISIS'], str), "result['THISIS'] is not a string"
    assert isinstance(result['YOLO'], str), "result['YOLO'] is not a string"



# Generated at 2022-06-21 21:23:59.625347
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:24:05.150525
# Unit test for function expand
def test_expand():
    os.environ['HOME'] = '/some/path/'

    assert expand('$HOME') == '/some/path/'
    assert expand('~') == '/some/path/'
    assert expand('${HOME}') == '/some/path/'
    assert expand('~/') == '/some/path/'
    assert expand('~/a/test') == '/some/path/a/test'



# Generated at 2022-06-21 21:24:07.912726
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/a/b.txt') == os.path.expandvars('${HOME}/a/b.txt')
    assert expand('~/a/b.txt') == os.path.expanduser('~/a/b.txt')

# Generated at 2022-06-21 21:24:19.131949
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())
    assert changes['TEST'] == os.path.expanduser('~/yeee')
    assert changes['THISIS'] == os.path.expanduser('~/a/test')
    assert changes['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-21 21:24:25.717465
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    parsed = load_env_file(lines, write_environ=dict())

    assert values == parsed.items()



# Generated at 2022-06-21 21:24:29.955998
# Unit test for function expand
def test_expand():
    assert expand("~/home/file.py") == os.path.expanduser("~/home/file.py")



# Generated at 2022-06-21 21:24:38.170130
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', expand('${HOME}/yeee-${PATH}')),
             ('THISIS', expand('~/a/test')),
             ('YOLO',
              expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-21 21:24:49.030520
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO

    lines = StringIO(
            'TEST=${HOME}/yeee-$PATH\n'
            'THISIS=~/a/test\n'
            'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n'
    )

    with mock.patch.dict('os.environ', {'HOME': 'home', 'PATH': 'path'}):
        result = load_env_file(lines)
        assert isinstance(result, collections.OrderedDict)

# Generated at 2022-06-21 21:25:01.422255
# Unit test for function load_env_file
def test_load_env_file():
    # If a var isn't defined, it should keep the $VAR syntax
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = load_env_file(lines, write_environ=dict())
    assert values['TEST'] == os.path.join(os.environ['HOME'], 'yeee')
    assert values['THISIS'] ==  os.path.join(os.environ['HOME'], 'a', 'test')

# Generated at 2022-06-21 21:25:08.887253
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-21 21:25:20.741795
# Unit test for function expand
def test_expand():
    orig_home = os.environ['HOME']
    orig_path = os.environ['PATH']
    os.environ['HOME'] = '$HOME'
    os.environ['A'] = 'b'
    os.environ['PATH'] = '/my/path'

    os.environ['HOME'] = '$HOME'

    assert expand('$HOME') == orig_home
    assert expand('~') == orig_home
    assert expand('/$HOME') == '/' + orig_home
    assert expand('//$HOME') == '//' + orig_home
    assert expand('/$HOME/') == '/' + orig_home + '/'
    assert expand('/$A') == '/b'
    assert expand('$PATH') == '/my/path'

    del os.environ['HOME']

# Generated at 2022-06-21 21:25:22.079041
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:25:33.971567
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    write_environ = dict()
    changes = load_env_file(lines, write_environ=write_environ)

    assert changes is not None
    assert len(changes) == len(lines)

    assert changes['TEST'].startswith(expand('${HOME}/yeee-'))
    assert changes['THISIS'].startswith(expand('~/a/test'))

    assert changes['TEST'].endswith(expand('$PATH'))

# Generated at 2022-06-21 21:25:39.591399
# Unit test for function expand
def test_expand():
    assert expand('~/test.txt') == os.path.expanduser('~/test.txt')
    assert expand('${HOME}/test.txt') == os.path.expandvars('${HOME}/test.txt')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:25:50.738207
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert tuple(parse_env_file_contents(['A=B'])) == (('A', 'B'),)
    assert tuple(parse_env_file_contents(['A=B', 'self=important'])) == (('A', 'B'), ('self', 'important'))
    assert tuple(parse_env_file_contents(['A=B', 'self=important', 'C=D'])) == (('A', 'B'), ('self', 'important'), ('C', 'D'))
    assert tuple(parse_env_file_contents(['A="testing"'])) == (('A', 'testing'),)
    assert tuple(parse_env_file_contents(['A="testing\\\\"'])) == (('A', 'testing\\'),)

# Generated at 2022-06-21 21:25:53.797817
# Unit test for function expand
def test_expand():
    assert expand('~') == os.environ['HOME']

# Generated at 2022-06-21 21:26:04.723339
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    env = load_env_file(lines)

    assert 'TEST' in env
    assert env['TEST'] != '${HOME}/yeee'
    assert env['TEST'] == expand('${HOME}/yeee')
    assert env['THISIS'] != '~/a/test'
    assert env['THISIS'] == expand('~/a/test')
    assert env['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-21 21:26:14.719286
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_ = load_env_file(lines, write_environ=dict())
    assert dict_ == {
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }

# Generated at 2022-06-21 21:26:22.395780
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ={})
    assert results == {'TEST': '.../yeee',
                       'THISIS': '.../a/test',
                       'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:26:34.318077
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'LOL=quoted$HOME\'\'/test',
        'LOLOL="a/b/$USER_WITH_SLASHES"',
        'LE=C',
        'SPECIAL_VAR=\\',
    ]


# Generated at 2022-06-21 21:26:44.058877
# Unit test for function load_env_file
def test_load_env_file():
    from py.test import raises

    from pydocstyle.utils import assert_equal_input_output

    with raises(ValueError) as excinfo:
        # keys must be str
        load_env_file(["TEST 1=no", "THISIS=yes"])
    assert str(excinfo.value) == "key must be str, not '1'"

    with raises(ValueError) as excinfo:
        # keys must be str
        load_env_file(["TEST 1=no"])
    assert str(excinfo.value) == "key must be str, not '1'"

    with raises(ValueError) as excinfo:
        # keys must be str
        load_env_file([1])
    assert str(excinfo.value) == "line must be str, not '1'"


# Generated at 2022-06-21 21:26:51.183724
# Unit test for function expand
def test_expand():
    os.environ["BLAH"] = "True"
    os.environ["PATH"] = "/usr/bin"
    assert os.path.join(os.environ["BLAH"], os.environ["PATH"]) == expand("${BLAH}/${PATH}")
    assert os.path.expanduser("~") == expand("~")
    assert os.path.expandvars("${BLAH}/${PATH}") == expand("${BLAH}/${PATH}")



# Generated at 2022-06-21 21:26:56.943275
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:27:05.472701
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert (
        list(parse_env_file_contents(lines)) == [
            ('TEST', '${HOME}/yeee'),
            ('THISIS', '~/a/test'),
            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:27:12.892433
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = collections.OrderedDict(parse_env_file_contents(lines))
    assert result.popitem() == (
        'YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    assert result.popitem() == (
        'THISIS', '~/a/test')
    assert result.popitem() == (
        'TEST', '${HOME}/yeee')



# Generated at 2022-06-21 21:27:26.673695
# Unit test for function expand
def test_expand():
    import os

    os.environ['VAR1'] = 'meow'
    os.environ['VAR2'] = ''
    os.environ['VAR3'] = 'foooooooo'


# Generated at 2022-06-21 21:27:30.377787
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from testfixtures import compare
    from testfixtures import ShouldRaise

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    compare(
        parse_env_file_contents(lines),
        [
            ("TEST", "~/yeee"),
            ("THISIS", "~/a/test"),
            ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
        ]
    )


# Generated at 2022-06-21 21:27:31.286999
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    from . import envfile
    doctest.testmod(envfile)

# Generated at 2022-06-21 21:27:38.694688
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-21 21:27:47.995588
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    changes = load_env_file(lines, write_environ=dict())

    i = 0
    for k, v in values:
        assert changes[k] == v

        i += 1

    assert i == 3



# Generated at 2022-06-21 21:27:58.914257
# Unit test for function expand
def test_expand():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'YOLOBEAN=YOLO',
        'YOLOBEANBEAN=YOLO',
    ]

    changes = load_env_file(lines, write_environ=None)

    assert changes['TEST'] == os.environ['HOME'] + '/yeee-' + os.environ['PATH']
    assert changes['THISIS'] == os.path.expanduser('~/a/test')

# Generated at 2022-06-21 21:28:04.357201
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    from pprint import pprint
    pprint(list(parse_env_file_contents(lines)))



# Generated at 2022-06-21 21:28:05.452977
# Unit test for function load_env_file
def test_load_env_file():
    pass



# Generated at 2022-06-21 21:28:15.516538
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # Test basic function
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Test that variable expansion works
    lines = ['TEST=$HOME/yeee', 'THISIS~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-21 21:28:21.996761
# Unit test for function load_env_file
def test_load_env_file():
    os.environ["HOME"] = "/home/user"
    os.environ["PATH"] = "/home/user/first:/home/user/second"

    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)

# Generated at 2022-06-21 21:28:25.813615
# Unit test for function expand
def test_expand():
    import os

    with os.popen("echo $HOME") as pipe:
        value = pipe.read()

    assert expand("$HOME") == value



# Generated at 2022-06-21 21:28:32.805596
# Unit test for function load_env_file
def test_load_env_file():
    # Unit test for function load_env_file
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    import unittest

    class LoadEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            with mock.patch('os.environ', {}):
                load_env_file(lines, write_environ=os.environ)

# Generated at 2022-06-21 21:28:41.597867
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test with a basic env file
    lines = ['TEST=${HOME}', 'TEST2=${HOME}']
    for key, val in parse_env_file_contents(lines):
        assert key in ['TEST', 'TEST2']
        assert val == os.environ['HOME']

    # test with a multiline file
    lines = ['TEST=${HOME}', '', '', '', '', 'TEST2=${HOME}']
    for key, val in parse_env_file_contents(lines):
        assert key in ['TEST', 'TEST2']
        assert val == os.environ['HOME']

    # test with a multiline file that has comments in it
    lines = ['TEST=${HOME}', '', '', '# COMMENTS']

# Generated at 2022-06-21 21:28:51.201198
# Unit test for function load_env_file
def test_load_env_file():  # pylint: disable=R0914,W0613
    environment = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert environment['TEST'] == os.path.expanduser('~/yeee-' + os.environ['PATH']), environment['TEST']
    assert environment['THISIS'] == os.path.expanduser('~/a/test'), environment['THISIS']
    assert environment['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'), environment['YOLO']

    environment = load_

# Generated at 2022-06-21 21:29:01.760116
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_dict = {
        'TEST': '.../.../yeee-...:...',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }
    for key, value in parse_env_file_contents(lines=lines):
        assert key in expected_dict
        assert value == expected_dict[key]

# Generated at 2022-06-21 21:29:05.418819
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:29:13.727836
# Unit test for function expand
def test_expand():
    """
    Tests the function expand.

    >>> expand('${HOME}/a') == os.path.expandvars('${HOME}/a')
    True
    >>> expand('~/a') == os.path.expandvars('~/a')
    True
    """
    assert expand('${HOME}/a') == os.path.expandvars('${HOME}/a')
    assert expand('~/a') == os.path.expandvars('~/a')



# Generated at 2022-06-21 21:29:15.101434
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-21 21:29:21.296682
# Unit test for function expand
def test_expand():
    """
    >>> test_expand()
    """
    EXPECTED = os.path.abspath(os.path.realpath(os.path.expanduser("~/test")))

    assert expand("${HOME}/test") == EXPECTED
    assert expand("~/test") == EXPECTED


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:29:26.623877
# Unit test for function expand
def test_expand():
    test_inputs = [
        '$HOME/$PATH',
        os.path.expanduser('~/$PATH'),
        os.path.expandvars('$HOME/$PATH'),
        os.path.expandvars(os.path.expanduser('~/$PATH'))
    ]

    for ti in test_inputs:
        assert expand(ti) == ti



# Generated at 2022-06-21 21:29:33.287871
# Unit test for function expand
def test_expand():
    assert expand(r'$HOME/pouet') == os.path.expanduser(r'$HOME/pouet')
    assert expand(r'~/pouet') == os.path.expanduser(r'~/pouet')

# Generated at 2022-06-21 21:29:34.544606
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:29:40.450391
# Unit test for function load_env_file
def test_load_env_file():
    test_env = {
        'HOME': '/home/me',
        'PATH': '/usr/bin',
    }

    with mock.patch.dict(os.environ, test_env, clear=True):
        lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        result = load_env_file(lines)
        print(result)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:29:49.319975
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = list(load_env_file(lines, write_environ=dict()).items())
    assert result == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-21 21:29:59.293304
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    new_dict = {k: v for k, v in parse_env_file_contents(lines)}
    print(new_dict)

    assert new_dict['TEST'].endswith('/yeee')
    assert new_dict['THISIS'].endswith('/a/test')
    assert new_dict['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:30:02.303247
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.join(os.path.expanduser("~"), "test")
    assert expand("${HOME}/test") == os.path.join(os.path.expanduser("~"), "test")



# Generated at 2022-06-21 21:30:06.641441
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    dict_values = dict(parse_env_file_contents(['TEST=test', 'PATH="$PATH:/test"']))
    assert dict_values['TEST'] == 'test'
    assert dict_values['PATH'].endswith('/test')

# Generated at 2022-06-21 21:30:09.736948
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:30:13.045596
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([
        'TEST=$PATH',
        'ABC=123',
    ]) == collections.OrderedDict([
        ('TEST', os.environ['PATH']),
        ('ABC', '123'),
    ])



# Generated at 2022-06-21 21:30:17.798690
# Unit test for function expand
def test_expand():
    values = [
        ('~/yeee', '.../yeee'),
        ('${HOME}/yeee', '.../yeee'),
        ('$PATH', '...:...'),
    ]

    for input, expected_output in values:
        assert expand(input) == expected_output

# Generated at 2022-06-21 21:30:36.602383
# Unit test for function expand
def test_expand():
    from poucave.typings import Environ

    test: Environ = dict()
    test["home"] = "~/test"
    test["path"] = "$HOME/test"
    test["yolo"] = "~$swag"
    test["sport"] = "$PATH/test"
    test["yay"] = "~/test/$HOME/$PAT/H/test"
    test["song"] = "~/test/$HOME/$PAT/H/test/test"

    # https://github.com/python/mypy/issues/6064
    # test["unknown"] = "$UNKNOWN"

    for k, v in test.items():
        new_val = expand(v)

        if new_val == v:
            raise Exception(f"{k}")

# Generated at 2022-06-21 21:30:37.584136
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    pass



# Generated at 2022-06-21 21:30:38.569862
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:30:50.979312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    res = []
    for k, v in parse_env_file_contents(
        ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ):
        res.append((k, v))


# Generated at 2022-06-21 21:31:00.228944
# Unit test for function load_env_file
def test_load_env_file():
    # Given
    varfile = """
    # A comment
    SECRET=hush
    TOKEN=j6i1z6hf55bhw4d4s4s4s4s4s4s4s4s4s4s4s4s4s4s4s4s4s4s4s4s4
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    # When
    changes = load_env_file(varfile.splitlines())

    # Then
    assert changes['SECRET'] == 'hush'

# Generated at 2022-06-21 21:31:01.941509
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expanduser('$HOME')



# Generated at 2022-06-21 21:31:13.952879
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert parse_env_file_contents(lines) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    changes = load_env_file(lines, write_environ=dict())


# Generated at 2022-06-21 21:31:24.110169
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    env_contents = io.StringIO("""
TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
FOO=test""")

    expected_result = [('TEST', '{HOME}/yeee'),
                       ('THISIS', '~/a/test'),
                       ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
                       ('FOO', 'test')]

    assert list(parse_env_file_contents(env_contents)) == expected_result



# Generated at 2022-06-21 21:31:30.691812
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())

    assert len(environ) == 3
    assert 'TEST' in environ
    assert 'THISIS' in environ
    assert 'YOLO' in environ

    assert 'YOLO' in environ

    my_home = os.environ.get('HOME', 'FAILED')
    my_path = os.environ.get('PATH', 'FAILED')

    assert environ['TEST'].startswith(my_home)

# Generated at 2022-06-21 21:31:37.151283
# Unit test for function expand
def test_expand():
    get_home = lambda: os.path.expanduser('~')
    get_env = lambda x: os.environ.get(x, '-nope-')

    get_home.__dict__['x'] = 'x'
    get_env.__dict__['x'] = 'x'

    assert expand(r'\~') == '~'
    assert expand('~') == get_home()
    assert expand('${HOME}') == get_home()

    assert expand('${PATH}') == get_env('PATH')
    assert expand('$UNDEFINED_VAR') == '$UNDEFINED_VAR'



# Generated at 2022-06-21 21:31:59.046068
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-21 21:32:10.324702
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        '# This is a comment',
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        '# This is another comment',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    d = load_env_file(lines, write_environ=None)

    assert 'TEST' in d
    assert 'THISIS' in d
    assert 'YOLO' in d

    assert 'HOME' in d['TEST']
    assert 'PATH' in d['TEST']
    assert 'NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in d['YOLO']

    # Now, let's read the file and check whether

# Generated at 2022-06-21 21:32:18.763932
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == {
        'TEST': os.path.expanduser('~/yeee'),
        'THISIS': os.path.expanduser('~/a/test'),
        'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

# Generated at 2022-06-21 21:32:27.402419
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [('TEST', '.../yeee'),
         ('THISIS', '.../a/test'),
         ('YOLO',
          '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-21 21:32:35.160240
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    testenv = os.environ.copy()
    load_env_file(lines)
    assert 'TEST' in os.environ
    assert testenv == os.environ
    load_env_file(lines, write_environ=None)
    assert testenv == os.environ



# Generated at 2022-06-21 21:32:40.638701
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == \
           [("TEST", "${HOME}/yeee"),
            ("THISIS", "~/a/test"),
            ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
            ]

# Generated at 2022-06-21 21:32:42.788795
# Unit test for function expand
def test_expand():
    assert expand("/home/user/${SHELL}") == "/home/user/bin/bash"



# Generated at 2022-06-21 21:32:53.974924
# Unit test for function load_env_file

# Generated at 2022-06-21 21:32:56.503067
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    failures, _ = doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)
    assert failures == 0

# Generated at 2022-06-21 21:33:05.488300
# Unit test for function expand
def test_expand():
    if os.path.exists("_TEST_EXPAND_TMP"):
        os.remove("_TEST_EXPAND_TMP")

    assert not os.path.exists("_TEST_EXPAND_TMP")

    assert os.path.expanduser("~/asd") != "~/asd"
    env_temp = load_env_file(["_TEST_EXPAND_TMP=~/_TEST_EXPAND_TMP"])
    assert os.path.exists("_TEST_EXPAND_TMP")
    assert os.path.exists(env_temp["_TEST_EXPAND_TMP"])
    os.remove("_TEST_EXPAND_TMP")

    assert os.path.expandvars("${HOME}") != "${HOME}"
    env