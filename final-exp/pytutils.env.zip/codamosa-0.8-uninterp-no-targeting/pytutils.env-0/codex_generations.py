

# Generated at 2022-06-21 21:23:29.636632
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:23:31.999077
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:23:38.703760
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())

    assert len(d) == 3
    assert d['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-21 21:23:48.690836
# Unit test for function load_env_file
def test_load_env_file():
    os.environ["HOME"] = "/home/owenoclee"
    os.environ["PATH"] = "/home/owenoclee/swag/bin:/usr/local/bin"

    fd, name = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-21 21:23:56.126326
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = collections.OrderedDict(parse_env_file_contents(lines))

    assert environ['TEST'] == expand('${HOME}/yeee')
    assert environ['THISIS'] == expand('~/a/test')
    assert environ['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-21 21:24:02.336345
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """YOLO=YEAH
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    """

    assert sorted(list(parse_env_file_contents(lines.splitlines()))) == [
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', 'YEAH')
    ]

# Generated at 2022-06-21 21:24:14.520646
# Unit test for function load_env_file
def test_load_env_file():
    # Test with an empty file
    env_file = ['']
    d = load_env_file(env_file, write_environ=dict())
    assert isinstance(d, collections.OrderedDict)
    assert len(d) == 0

    # Test with empty values
    env_file = ['FOO=', 'BAR=']
    d = load_env_file(env_file, write_environ=dict())
    assert d['FOO'] == ''
    assert d['BAR'] == ''

    # Test with single-quoted values
    env_file = ['FOO=\'a b c\'']
    os.environ['FOO'] = 'x y z'
    d = load_env_file(env_file, write_environ=dict())

# Generated at 2022-06-21 21:24:20.022075
# Unit test for function expand
def test_expand():
    os.environ['TEST_VAR'] = 'test'
    os.environ['HOME'] = 'test'
    assert expand('$TEST_VAR') == 'test'
    assert expand('${TEST_VAR}') == 'test'
    assert expand('~/$TEST_VAR') == 'test/test'
    assert expand('~') == 'test'

# Generated at 2022-06-21 21:24:22.993240
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-21 21:24:24.734263
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:24:27.690565
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:24:31.037197
# Unit test for function expand
def test_expand():
    assert expand('~/foo') == os.path.join(os.environ['HOME'], 'foo')
    assert expand('$XDG_CONFIG_HOME/foo') == os.path.join(os.environ['XDG_CONFIG_HOME'], 'foo')



# Generated at 2022-06-21 21:24:32.861616
# Unit test for function expand
def test_expand():
    assert expand('~/a/test') == expand('${HOME}/a/test')

# Generated at 2022-06-21 21:24:41.240672
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

    assert len(changes) == 3

    # Check that environment path expansion works
    assert 'yeee-' in changes['TEST']
    assert ':' in changes['TEST']

    # Check that tilde expansion works
    assert os.path.basename(changes['THISIS']) == 'test'

    # Check that variables are not expanded
    assert '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in changes['YOLO']

# Generated at 2022-06-21 21:24:50.318499
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test-${HOME}", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST", "YEAH=true"]
    env = dict()

    changes = load_env_file(lines, write_environ=env)

    assert changes == {"TEST": os.path.expanduser(r"~/yeee-$PATH"),
                       "THISIS": os.path.expanduser(r"~/a/test-${HOME}"),
                       "YOLO": r"~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
                       "YEAH": r"true"}


# Generated at 2022-06-21 21:24:55.110447
# Unit test for function expand
def test_expand():
    assert expand(None) == ''
    assert expand('~') == os.environ['HOME']
    assert expand('~/') == os.environ['HOME'] + '/'
    assert expand('$NON_EXISTING_VARIABLE') == ''



# Generated at 2022-06-21 21:25:05.095606
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_environ = dict()

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, test_environ) == {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

# Generated at 2022-06-21 21:25:12.998962
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
            ('TEST', '.../yeee'),
            ('THISIS', '.../a/test'),
            ('YOLO',
             '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        ]

    lines = ['GUNICORN_BIND=0.0.0.0:8080', 'CONFIG_FILE_PATH=config/config.yml', 'PORT=80']

# Generated at 2022-06-21 21:25:23.357730
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    os.environ.get.return_value = "..."

    assert load_env_file(lines, write_environ=dict()) == OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-21 21:25:26.641765
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")



# Generated at 2022-06-21 21:25:39.690444
# Unit test for function load_env_file
def test_load_env_file():
    values = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(values, write_environ=dict())

    assert changes == collections.OrderedDict(
        [
            ('TEST', f'.../.../yeee-{os.environ["PATH"]}'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ]
    )



# Generated at 2022-06-21 21:25:45.136443
# Unit test for function expand
def test_expand():
    """
    >>> expand('$HOME/test/')
    '/home/test/test/'

    >>> expand('~/test/')
    '/home/test/test/'
    """
    HOME = os.path.expanduser("~")
    assert expand("~/test/") == os.path.join(HOME, "test")



# Generated at 2022-06-21 21:25:56.328052
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class Test_parse_env_file_contents(unittest.TestCase):
        def test_parse_env_file_contents(self):
            contents = "\n".join([
                "TEST=${HOME}/yeee",
                "THISIS=~/a/test",
                "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
            ]).strip()

            expected = [
                ("TEST", expand("${HOME}/yeee")),
                ("THISIS", expand("~/a/test")),
                ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
            ]


# Generated at 2022-06-21 21:26:07.850020
# Unit test for function load_env_file
def test_load_env_file():
    def test_lines_to_env(lines: typing.List[str], expected: str) -> None:
        environ = dict()
        values = load_env_file(lines, write_environ=environ)
        assert environ == {"TEST": expected}
        assert values == {"TEST": expected}

    test_lines_to_env(["TEST=${HOME}/yeee"], "{}/yeee".format(os.environ["HOME"]))
    test_lines_to_env(["TEST=~/yeee"], "{}/yeee".format(os.environ["HOME"]))
    test_lines_to_env(["TEST=${PATH}"], "{}".format(os.environ["PATH"]))

# Generated at 2022-06-21 21:26:13.306190
# Unit test for function expand
def test_expand():
    assert expand('file.txt') == expand('file.txt')
    assert expand('${HOME}/file.txt') != '${HOME}/file.txt'
    assert expand('~/file.txt') != '~/file.txt'



# Generated at 2022-06-21 21:26:22.748886
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # type: () -> None
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-21 21:26:34.014055
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function parse_env_file_contents.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:26:40.702148
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == \
        collections.OrderedDict([('TEST', '.../.../yeee-...:/...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-21 21:26:42.309714
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:26:52.980999
# Unit test for function load_env_file
def test_load_env_file():
    from argparse import Namespace
    from loguru import logger

    import sys
    import tempfile

    # Definition of logger
    logger = logger.bind(widgets=[
        {'text': '{name}', 'style': 'class:name'},
        {'text': ' {level} ', 'style': 'class:level'},
        {'text': '{message}', 'style': 'class:message'},
    ])

    args = Namespace()

    # Test creating a new environment variable
    logger.info('Testing load_env_file()')

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-21 21:27:03.804919
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result['TEST'] == '.../yeee'
    assert result['THISIS'] == '.../a/test'
    assert result['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:27:11.109635
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines)
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-21 21:27:14.221187
# Unit test for function load_env_file
def test_load_env_file():
    if __name__ == '__main__':
        import doctest
        doctest.testmod()



# Generated at 2022-06-21 21:27:25.413318
# Unit test for function expand
def test_expand():
    from os.path import expanduser as eu, expandvars as ev

    source = [
        ('a', 'a'),
        ('a/b', 'a/b'),
        ('"a/b"', '"a/b"'),
        ('~/a/b', '~/a/b'),
        ('$PATH', '$PATH'),
        ('$PATH/a', '$PATH/a'),
    ]

    for s, res in source:
        print(s, res)
        print(expand(s))
        assert expand(s) == res, str(s)


# Generated at 2022-06-21 21:27:30.329526
# Unit test for function expand
def test_expand():
    assert expand('$PATH') == os.environ['PATH']
    assert expand('~') == os.environ['HOME']
    assert expand('$HOME') == os.environ['HOME']



# Generated at 2022-06-21 21:27:35.685452
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:27:41.847751
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'BLAH=~/a/test', 'THISIS=$HOME/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = list(parse_env_file_contents(lines))

    assert result == [
        ('TEST', '.../.../yeee-...:...'),
        ('BLAH', '.../a/test'),
        ('THISIS', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-21 21:27:46.238199
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    foo = parse_env_file_contents(lines)

    # FIXME: This is ugly code.
    #  I should make a class or something to test the generator.
    i = 0
    for key, value in foo:
        i += 1

        if i == 1:
            assert key == 'TEST'
            assert value.endswith('/yeee')

        if i == 2:
            assert key == 'THISIS'
            assert value.endswith('/a/test')

        if i == 3:
            assert key == 'YOLO'
            assert value.endsw

# Generated at 2022-06-21 21:27:52.044838
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.expanduser("~/test")
    assert expand("${HOME}") == os.path.expanduser("~")


# todo: expand with '.' in home
# todo: expand with '.' not in home

# Generated at 2022-06-21 21:27:58.445894
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-21 21:28:10.346806
# Unit test for function expand
def test_expand():
    home_var = os.path.expanduser("~")
    working_dir = os.getcwd()

    # Expand shell variables
    assert expand("test-$HOME") == "test-" + home_var
    # Expand user variables
    assert expand("~") == home_var
    # Expand current directory
    assert expand(".") == working_dir
    # Expand variables with other variables inside
    assert expand("TEST-$HOME-$PATH-$PWD") == "TEST-" + home_var + f"-{os.environ['PATH']}-{os.environ['PWD']}"


# Unit tests for function load_env_file

# Generated at 2022-06-21 21:28:18.923009
# Unit test for function load_env_file
def test_load_env_file():
    import shlex


# Generated at 2022-06-21 21:28:21.154111
# Unit test for function load_env_file
def test_load_env_file():
    """
    Tests load_env_file()
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:28:25.134960
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pprint
    pprint.pprint(dict(parse_env_file_contents(
        ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])))



# Generated at 2022-06-21 21:28:26.277192
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-21 21:28:31.277720
# Unit test for function expand
def test_expand():
    os.environ['HOME'] = "testing"
    os.environ['TEST_EXPAND_ENV'] = "testing_environment_variables"
    assert "testing" in expand("~")
    assert "testing/testing_environment_variables" in expand("${TEST_EXPAND_ENV}")
    del os.environ['HOME']
    del os.environ['TEST_EXPAND_ENV']

# Generated at 2022-06-21 21:28:35.963349
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:28:39.744347
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:28:44.836443
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-21 21:28:48.997173
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:28:54.097917
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest_results = doctest.testmod(optionflags=doctest.ELLIPSIS)

    assert doctest_results.failed == 0



# Generated at 2022-06-21 21:29:04.844867
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestLoadEnvFile(unittest.TestCase):
        def setUp(self):
            self.env = dict()

        def test_can_parse_basic_vars(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            changes = load_env_file(lines, write_environ=self.env)
            self.assertEqual(changes['TEST'], os.path.expanduser(os.path.expandvars(lines[0].split('=', 1)[-1])))

# Generated at 2022-06-21 21:29:07.529310
# Unit test for function expand
def test_expand():
    assert expand("~/hello") != "~/hello"
    assert expand("${PATH}") != "${PATH}"

# Generated at 2022-06-21 21:29:18.412022
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'HAHA=${HOME}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines_list = list(parse_env_file_contents(lines))
    home = os.environ['HOME']

    assert lines_list[0] == ('TEST', f'{home}/yeee-{os.environ["PATH"]}')  # This one is tricky since it depends on the user's PATH
    assert lines_list[1] == ('HAHA', home)
    assert lines_list[2] == ('THISIS', os.path.expanduser('~/a/test'))

# Generated at 2022-06-21 21:29:28.387108
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # No real env file, no need for dict(...)
    changes = load_env_file(lines, write_environ=None)


# Generated at 2022-06-21 21:29:33.592033
# Unit test for function expand
def test_expand():
    assert expand('~/a/path') == os.path.expanduser('~/a/path')
    assert expand('$HOME/a/path') == os.path.expandvars('$HOME/a/path')
    assert expand('${HOME}/a/path') == os.path.expandvars('${HOME}/a/path')



# Generated at 2022-06-21 21:29:40.475095
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert [('TEST', os.path.expanduser('~/yeee-') + os.getenv('PATH')),
            ('THISIS', os.path.expanduser('~/a/test')),
            ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))] == changes.items()

# Generated at 2022-06-21 21:29:48.303593
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:29:53.779501
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-21 21:29:58.618638
# Unit test for function expand
def test_expand():
    assert expand('~') == expand('$HOME')
    assert expand('~/') == expand('$HOME/')
    assert expand('~/test/test') == expand('$HOME/test/test')
    assert expand('${HOME}') == expand('$HOME')
    assert expand('${HOME}/') == expand('$HOME/')
    assert expand('${HOME}/test/test') == expand('$HOME/test/test')



# Generated at 2022-06-21 21:30:09.201447
# Unit test for function load_env_file
def test_load_env_file():
    input_list = [
        "export MYVAR=VA-LUE",
        "MYVAR2=V-ALUE2",
        "MYVAR3=$MYVAR2/TAILS $MYVAR",
        "FOO=bar",
    ]

    output_dict = load_env_file(input_list)

    assert output_dict["MYVAR"] == "VA-LUE"
    assert output_dict["MYVAR2"] == "V-ALUE2"
    assert output_dict["MYVAR3"] == "V-ALUE2/TAILS VA-LUE"
    assert output_dict["FOO"] == "bar"



# Generated at 2022-06-21 21:30:10.624805
# Unit test for function load_env_file
def test_load_env_file():
    # TODO
    ...

# Generated at 2022-06-21 21:30:16.621285
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    assert load_env_file(lines, write_environ={}) == collections.OrderedDict(
        [
            ('TEST', '.../yeee'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ]
    )



# Generated at 2022-06-21 21:30:25.016316
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Load .env file')
    parser.add_argument('infile', type=str, help='Input file to read data from')
    parser.add_argument('-o', '--outfile', type=str, help='Output file to write data to')

    args = parser.parse_args()

    changes = load_env_file(open(args.infile))

    if args.outfile is None:
        for k, v in changes.items():
            print("{}={}".format(k, v))
    else:
        with open(args.outfile, "w") as f:
            for k, v in changes.items():
                f.write

# Generated at 2022-06-21 21:30:37.342409
# Unit test for function expand
def test_expand():
    # Create a test string
    s = "~/some/path/with/${variables}/${and}/~other/tilde/${variables}"

    # Save the current home directory
    home = os.environ["HOME"]

    # Set the HOME environment variable
    os.environ["HOME"] = "/home/testuser"

    # Set the variables environment variable
    os.environ["variables"] = "variables"

    # Set the variables environment variable
    os.environ["and"] = "and"

    # Expand the string
    expanded = expand(s)

    # Check if expansion was successful
    assert expanded == "/home/testuser/some/path/with/variables/and/~other/tilde/variables"

    # Restore the home directory
    os.environ["HOME"] = home



# Generated at 2022-06-21 21:30:39.716898
# Unit test for function expand
def test_expand():
    assert(expand('${HOME}') == os.environ['HOME'])


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:30:42.352295
# Unit test for function expand
def test_expand():
    assert expand('~/asd/') == os.path.expanduser('~/asd/')



# Generated at 2022-06-21 21:30:46.486360
# Unit test for function expand
def test_expand():
    assert os.path.expandvars('~/testing/$HOME') == expand('~/testing/$HOME')
    assert os.path.expanduser('~/testing/') == expand('~/testing/')


# Generated at 2022-06-21 21:30:51.072700
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test')]



# Generated at 2022-06-21 21:31:00.299142
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import tempfile

    # Generate simple env file contents
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Write it to temp file, and read it back in.
    with tempfile.NamedTemporaryFile() as f:
        f.write('\n'.join(lines).encode('utf8'))
        f.flush()
        f.seek(0)
        loaded_lines = f.readlines()
        loaded_lines = [l.decode('utf8').strip() for l in loaded_lines]

    # E.g. a temp directory
    temp_dir = tempfile.mkdtemp()
    home = os

# Generated at 2022-06-21 21:31:14.660514
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    d = collections.OrderedDict()

    for k, val in parse_env_file_contents(lines):
        d[k] = val

    assert d == collections.OrderedDict([
        ('TEST', '.../.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])



# Generated at 2022-06-21 21:31:24.400763
# Unit test for function load_env_file
def test_load_env_file():

    # Basic
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', os.environ.get('HOME') + '/yeee'),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])

# Generated at 2022-06-21 21:31:34.378645
# Unit test for function load_env_file
def test_load_env_file():
    # Test output
    import csv
    import io
    import tempfile

    # Get the lines to test
    with io.StringIO('TEST=${HOME}/yeee-$PATH,${HOME}\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n') as f:
        r = csv.reader(f)
        lines = list(r)[0]

    # Create a temporary file for the contents
    fd, filename = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('\n'.join(lines))

    # parse
    output = load_env_file(lines, dict())

    # Test value
    assert output['TEST']

# Generated at 2022-06-21 21:31:46.674168
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    file_txt = """
TEST=$HOME/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    file_stream = io.StringIO(file_txt)
    actual_dictionary = {k: v for k, v in parse_env_file_contents(file_stream.readlines())}

# Generated at 2022-06-21 21:31:51.398016
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:31:59.297216
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    file = io.StringIO('\n'.join(lines))

    def test():
        load_env_file(lines, write_environ=dict())

    assert test() == collections.OrderedDict()



# Generated at 2022-06-21 21:32:05.525122
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    from StringIO import StringIO

    class LoadEnvFileCase(unittest.TestCase):
        def test_load_env_file(self):
            lines = StringIO("""
            TEST=${HOME}/yeee
            THISIS=~/a/test
            YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
            """)

            load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:32:15.824420
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    actual = parse_env_file_contents(lines)
    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    for actual, expected in zip(actual, expected):
        assert actual == expected

# Generated at 2022-06-21 21:32:18.491600
# Unit test for function expand
def test_expand():
    assert expand('~/.env') == os.path.expanduser('~/.env')
    assert expand('${HOME}/.env') == os.environ['HOME'] + '/.env'



# Generated at 2022-06-21 21:32:27.793558
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    out = parse_env_file_contents(lines)
    assert out == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:32:41.690467
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestLoadEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            load_env_file(lines, write_environ=dict())

            # with self.assertRaises(ValueError):
            #     load_env_file('NONEXISTENT_FILE_THAT_DOES_NOT_EXIST')

    unittest.main()



# Generated at 2022-06-21 21:32:47.532235
# Unit test for function expand
def test_expand():
    assert expand('a test') == os.path.expandvars('a test') == os.path.expandvars(os.path.expanduser('a test'))
    assert expand('~/test') == os.path.expandvars('~/test') == os.path.expandvars(os.path.expanduser('~/test'))



# Generated at 2022-06-21 21:32:57.755035
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', '${HOME}/yeee-$PATH')

    write_environ = dict()
    changes = load_env_file(lines, write_environ=write_environ)

    assert changes['TEST'].count('/') == '/'.count(write_environ['TEST'])
    assert changes['THISIS'].count('/') == '/'.count(write_environ['THISIS'])

# Generated at 2022-06-21 21:33:02.344193
# Unit test for function expand
def test_expand():
    # This test is brittle because it relies on the user's environment variables
    assert expand('${USER}') == os.environ['USER']
    assert expand('${USER}/testing') == os.environ['USER'] + '/testing'
    assert expand('${USER}${USER}') == os.environ['USER'] + os.environ['USER']
    assert expand('~') == os.path.expanduser('~')

# Generated at 2022-06-21 21:33:06.416345
# Unit test for function expand
def test_expand():
    assert expand('~/yeeee') == os.path.expanduser('~/yeeee')
    assert expand('$HOME/yeeee') == os.path.expandvars('$HOME/yeeee')



# Generated at 2022-06-21 21:33:16.691700
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO="~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"']
    result = parse_env_file_contents(lines)

    assert result.__next__() == ('TEST', '${HOME}/yeee')
    assert result.__next__() == ('THISIS', '~/a/test')
    assert result.__next__() == ('YOLO', '"~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"')



# Generated at 2022-06-21 21:33:20.287883
# Unit test for function expand
def test_expand():
    import subprocess

    output = subprocess.check_output("echo $HOME", shell=True).decode("utf-8").strip()
    home = output

    assert expand("~/yeee") == home + "/yeee"



# Generated at 2022-06-21 21:33:29.167200
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = parse_env_file_contents(lines)
    expected = [
        ('TEST', os.path.expanduser('~/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]
    assert changes == expected

