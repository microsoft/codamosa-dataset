

# Generated at 2022-06-21 21:23:33.982121
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-21 21:23:35.342211
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    
    doctest.testmod()



# Generated at 2022-06-21 21:23:42.455163
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines) == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

# Generated at 2022-06-21 21:23:49.228631
# Unit test for function expand
def test_expand():
    # Expand variables
    os.environ['TESTVAR'] = 'value'
    assert expand('$TESTVAR') == 'value'

    # Expand home
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~') + '/'
    assert expand('~/test') == os.path.expanduser('~/test')

    # Expand nothing
    assert expand('/') == '/'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:23:56.178048
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import filecmp

    test_str = """
    # comment
    TEST=${HOME}/yeee
    THISIS=~/a/test

    # Another comment
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    test_lines = load_env_file(test_str.splitlines(), write_environ=None)

    test_result_str = """OrderedDict([('TEST', '.../.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])"""

# Generated at 2022-06-21 21:23:58.447470
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(verbose=True)


# A small CLI for testing this

# Generated at 2022-06-21 21:24:02.632212
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    from . import get_test_directory_path

    # Test with a non-existent file actually being passed in
    with pytest.raises(FileNotFoundError):
        load_env_file(get_test_directory_path("config/non-existent-env-file.env"))

# Generated at 2022-06-21 21:24:14.556266
# Unit test for function expand
def test_expand():
    # Test for unexpanded values
    assert expand("test") == "test"
    assert expand("${PATH}") == os.environ.get("PATH")
    assert expand("~/test") == os.path.expanduser("~/test")

    # Test for expanded values
    assert expand(os.environ.get("PATH")) == os.environ.get("PATH")
    assert expand(os.path.expanduser("~/test")) == os.path.expanduser("~/test")

    # Test all together
    assert expand("${PATH}/${PATH}~/test") == os.environ.get(
        "PATH") + os.path.expanduser("/" + os.environ.get("PATH") + "~/test")


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-21 21:24:23.630746
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines)
    assert os.environ['TEST'] == '.../yeee'
    assert os.environ['THISIS'] == '.../a/test'
    assert os.environ['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:24:30.382382
# Unit test for function expand
def test_expand():
    # Set up the test environment
    path = r"/home/vjrantal/servers/yolo/project/source/file.txt"
    os.environ['HOME'] = "/home/vjrantal"
    os.environ['PROJECT_ROOT'] = "/home/vjrantal/servers/yolo/project"

    assert expand("$HOME/servers/yolo/project/source/file.txt") == path



# Generated at 2022-06-21 21:24:34.849272
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeet') == os.path.expandvars('$HOME')+'/yeet'
    assert expand('~/a/yeet') == os.path.expanduser('~/a/yeet')



# Generated at 2022-06-21 21:24:45.532847
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    assert load_env_file(lines, write_environ=write_environ) == collections.OrderedDict([
        ('TEST', os.environ['HOME'] + '/yeee-' + os.environ['PATH']),
        ('THISIS', os.environ['HOME'] + '/a/test'),
        ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

# Generated at 2022-06-21 21:24:52.893612
# Unit test for function expand
def test_expand():
    def assert_equal(a, b):
        assert a == b, ("assertion failed: got %r, expected %r" % (a, b))

    assert_equal(expand("~/file.txt"), os.path.expanduser("~/file.txt"))

    os.environ["TEST"] = "test"
    assert_equal(expand("$TEST"), "test")
    os.environ["TEST_DIR"] = "test/"
    assert_equal(expand("${TEST_DIR}file.txt"), "test/file.txt")
    assert_equal(expand("${TEST_DIR}/${TEST}"), "test/test")
    assert_equal(expand("$TEST/$TEST_DIR"), "test/test/")



# Generated at 2022-06-21 21:25:02.342359
# Unit test for function expand
def test_expand():

    # Test 1
    val = "$HOME/this"
    expected = expand(val)
    actual = "/home/david/this"
    assert actual == expected

    # Test 2
    val = "/home/$USER/this"
    expected = expand(val)
    actual = "/home/david/this"
    assert actual == expected

    # Test 3
    val = "~/this"
    expected = expand(val)
    actual = "/home/david/this"
    assert actual == expected


if __name__ == '__main__':
    import doctest

    # Test 1
    doctest.testmod()

    # Test 2
    test_expand()

# Generated at 2022-06-21 21:25:10.064540
# Unit test for function expand
def test_expand():
    assert expand('~/test/') == os.path.expanduser('~/test/')
    assert expand('$HOME/test/') == os.path.expandvars('$HOME/test/')
    assert expand('${HOME}\\test\\') == os.path.expandvars('${HOME}\\test\\')
    assert expand('${HOME}/test/') == os.path.expandvars('${HOME}/test/')



# Generated at 2022-06-21 21:25:12.904593
# Unit test for function expand
def test_expand():
    assert expand("~/test.txt") == os.environ['HOME'] + "/test.txt"
    assert expand("${HOME}/test.txt") == os.environ['HOME'] + "/test.txt"



# Generated at 2022-06-21 21:25:22.478344
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        (
            'TEST', '.../yeee'),
        (
            'THISIS', '.../a/test'),
        (
            'YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-21 21:25:25.070586
# Unit test for function expand
def test_expand():
    test = expand("$HOME/dir")
    test2 = expand("~/dir")
    assert test == test2, "The function expand is not working properly"



# Generated at 2022-06-21 21:25:26.301646
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:25:39.034831
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test string vars
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert tuple(parse_env_file_contents(lines)) == (('TEST', '${HOME}/yeee-${PATH}'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    # test single quoted vars
    lines = ["SINGLEQUOTE='single \' quote'"]
    assert tuple(parse_env_file_contents(lines)) == (('SINGLEQUOTE', 'single \' quote'),)
   

# Generated at 2022-06-21 21:25:48.171468
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-21 21:25:58.399026
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_string = """
REACT_APP_SECRET_CODE=abcd1234
REACT_APP_NAME=Bokeh
    """
    lines = env_string.split("\n")

    env = load_env_file(lines, write_environ=dict())

    assert env == collections.OrderedDict([
        ('REACT_APP_SECRET_CODE', 'abcd1234'),
        ('REACT_APP_NAME', 'Bokeh'),
    ])


SKIP_JUPYTER = False
SKIP_DJANGO = False
SKIP_FLASK = False
SKIP_STARLET = False
SKIP_BOTH = False
SKIP_BOTH_ALL = False
SKIP_BOTH_ONE = False



# Generated at 2022-06-21 21:26:05.625790
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST="$HOME"/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    values = parse_env_file_contents(lines)
    assert len(list(values)) == 3


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:26:17.946006
# Unit test for function load_env_file
def test_load_env_file():
    env = load_env_file(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])

    assert isinstance(env, collections.OrderedDict)
    assert len(env) == 3
    assert 'TEST' in env
    assert 'THISIS' in env
    assert 'YOLO' in env

    assert env['TEST'].startswith('.../yeee')
    assert env['THISIS'].startswith('.../a/test')
    assert env['YOLO'].startswith('.../swaggins')

# Generated at 2022-06-21 21:26:21.944210
# Unit test for function expand
def test_expand():
    with mock.patch("os.environ", {"HOME": "/home/user", "PATH": "/usr/bin"}):
        assert expand("$HOME/yeee-$PATH") == "/home/user/yeee-/usr/bin"



# Generated at 2022-06-21 21:26:32.664796
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    res = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        res[k] = v

    assert '$PATH' in res['TEST']
    assert res['THISIS'] == '~/a/test'
    assert res['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:26:41.795730
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = dict(parse_env_file_contents(lines))

    assert result['TEST'] == os.environ['HOME'] + '/yeee'
    assert result['THISIS'] == os.environ['HOME'] + '/a/test'
    assert result['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-21 21:26:52.649545
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([]) == collections.OrderedDict()
    assert load_env_file(['TEST=yeee']) == collections.OrderedDict([('TEST', 'yeee')])
    assert load_env_file(['TEST=yeee']) == collections.OrderedDict([('TEST', 'yeee')])
    assert load_env_file(['TEST=\'yeee\'']) == collections.OrderedDict([('TEST', 'yeee')])
    assert load_env_file(['TEST="yeee"']) == collections.OrderedDict([('TEST', 'yeee')])

# Generated at 2022-06-21 21:27:04.696711
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:27:13.184569
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import sys

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    cwd = str(os.getcwd())
    home = str(Path.home())
    path = ':'.join(sys.path)
    changes = load_env_file(lines, write_environ=None)
