

# Generated at 2022-06-21 21:23:30.493385
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    reference = collections.OrderedDict([('TEST', '.../yeee'),
                                         ('THISIS', '.../a/test'),
                                         ('YOLO',
                                          '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert result == reference


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:23:39.973195
# Unit test for function expand
def test_expand():
    # not testing os.path.expandvars or os.path.expanduser, as both are too hard to test with unittest
    assert expand('foo/bar') == 'foo/bar'
    assert expand('foo/$y') == 'foo/$y'
    assert expand('foo/${y}') == 'foo/${y}'
    assert expand('foo/${y}') == 'foo/${y}'
    assert expand('foo/${y}') == 'foo/${y}'
    assert expand('foo/${y') == 'foo/${y'
    assert expand('foo/${y ') == 'foo/${y '
    assert expand('foo/${y') == 'foo/${y'



# Generated at 2022-06-21 21:23:50.609039
# Unit test for function expand
def test_expand():
    # Test expansion of environment variables
    os.environ['TESTVAR1'] = 'VALUE1'
    assert expand('$TESTVAR1') == 'VALUE1'
    assert expand('$TESTVAR2') == '$TESTVAR2'
    assert expand('${TESTVAR1}') == 'VALUE1'
    assert expand('${TESTVAR3}') == '${TESTVAR3}'
    assert expand('$$TESTVAR1') == '$VALUE1'
    assert expand('$$TESTVAR2') == '$$TESTVAR2'

    # Test expansion of ~
    os.environ['HOME'] = '/home/myself'
    assert expand('~') == '/home/myself'
    assert expand('~/tmp') == '/home/myself/tmp'



# Generated at 2022-06-21 21:24:02.249514
# Unit test for function expand

# Generated at 2022-06-21 21:24:14.186654
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Expand all")
    print(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))

    print("Single quote")
    print(parse_env_file_contents(['TEST=\'${HOME}/yeee\'']))

    print("Double quote")
    print(parse_env_file_contents(['TEST="${HOME}/yeee"']))

    print("Quotes and used in quotes")
    print(parse_env_file_contents(['TEST="~/a/test"', 'THISIS=\'~/a/test\'']))

# Generated at 2022-06-21 21:24:26.042502
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    expected = [('TEST', '.../.../yeee-...:...'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    count = 0
    for result, expect in zip(results, expected):
        count += 1

# Generated at 2022-06-21 21:24:28.179530
# Unit test for function expand
def test_expand():
    assert expand("~/foo") == os.path.expanduser("~/foo")



# Generated at 2022-06-21 21:24:32.387722
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    load_env_file(lines, write_environ=dict())
    assert True



# Generated at 2022-06-21 21:24:42.685539
# Unit test for function load_env_file
def test_load_env_file():
    os.environ["PYTHONPATH"] = "/path/to/root/dir"
    os.environ["HOME"] = "/path/to/home/dir"
    os.environ["NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"] = "NONE"

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    res = load_env_file(lines)


# Generated at 2022-06-21 21:24:51.024054
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import tempfile

    new_environ = dict()

    test_content = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(test_content, write_environ=new_environ)


# Generated at 2022-06-21 21:25:01.511825
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.run_docstring_examples(parse_env_file_contents, globals(), optionflags=doctest.ELLIPSIS)


if __name__ == "__main__":
    # Executing this file will show the parsed env variables
    lines = None

    with open(".env") as env_file:
        lines = env_file.readlines()

    # os.environ.clear()

    print("\nParsed variables:")
    if lines:
        print(load_env_file(lines))

    else:
        print("No lines to parse")

# Generated at 2022-06-21 21:25:11.294200
# Unit test for function load_env_file
def test_load_env_file():
    print()
    print(collections.OrderedDict(load_env_file(['TEST=$HOME/yeee', 'THISIS=~/a/test'])))
    print(collections.OrderedDict(load_env_file(['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])))


# Test for function load_env_file
if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:25:22.954499
# Unit test for function load_env_file
def test_load_env_file():
    """
    Parses env file content.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """

# Generated at 2022-06-21 21:25:29.888952
# Unit test for function expand
def test_expand():
    import pathlib

    assert expand('./test.txt') == pathlib.Path('./test.txt').resolve()
    assert expand('$HOME/test.txt') == pathlib.Path(f'{pathlib.Path.home()}/test.txt').resolve()

    os.environ['TEST_PATH'] = '.'
    assert expand('$TEST_PATH/test.txt') == pathlib.Path('./test.txt').resolve()



# Generated at 2022-06-21 21:25:39.640784
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass

# Generated at 2022-06-21 21:25:49.725769
# Unit test for function expand
def test_expand():
    home = os.path.expanduser("~")
    username = os.environ["USER"]
    os.environ["YOLO"] = "123"
    assert home == expand("~")
    assert "$YOLO" == expand("$YOLO")
    assert "123" == expand("${YOLO}")
    assert "%s/%s" % (home, username) == expand("~/$USER")
    assert "%s/%s/123" % (home, username) == expand("~/$USER/${YOLO}")
    assert "%s/%s/123" % (home, username) == expand("~/$USER/$${YOLO}")



# Generated at 2022-06-21 21:25:54.231784
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["ENV1=val1", "# empty comment", "ENV2=val2", "ENV3=a\\nb", "ENV4=\"a\\nb\"", "ENV5='a\\nb'"]
    expected = [("ENV1", "val1"), ("ENV2", "val2"), ("ENV3", "a\\nb"), ("ENV4", "a\\nb"), ("ENV5", "a\\nb")]

    actual = list(parse_env_file_contents(lines))

    assert actual == expected

# Generated at 2022-06-21 21:26:02.902238
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    _check_parse_env_file_contents(
        lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
        expect_success=True,
        env_dict={},
    )

    # Check with non-string values (which is invalid, but allow it anyway)
    _check_parse_env_file_contents(
        lines=[str(2), 3, 4],
        expect_success=True,
        env_dict={},
    )



# Generated at 2022-06-21 21:26:08.487230
# Unit test for function expand
def test_expand():
    test_values = ['~/yeee', '$HOME/yeee', '${HOME}/yeee', '~/a/test', "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    expected = [os.path.expanduser(val) for val in test_values]
    assert list(map(expand, test_values)) == expected



# Generated at 2022-06-21 21:26:14.929924
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())