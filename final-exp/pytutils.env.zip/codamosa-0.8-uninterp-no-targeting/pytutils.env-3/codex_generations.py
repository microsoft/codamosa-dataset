

# Generated at 2022-06-21 21:23:35.999302
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['', '# This is a comment line', 'TEST=${HOME}/yeee',
             'THISIS=~/a/test', 'YOLO="~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"', 'FOO=BAR']

    od = collections.OrderedDict(parse_env_file_contents(lines))
    assert od['TEST'] == expand('${HOME}/yeee')
    assert od['THISIS'] == expand('~/a/test')
    assert od['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:23:37.259665
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:23:44.648586
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Setup:
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Test:
    result = load_env_file(lines)

    # Verify:
    assert result == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-21 21:23:49.070262
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:23:56.057218
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/yeee-$PATH') == '.../.../yeee-...:...'
    assert expand('~/a/test') == '.../a/test'
    assert expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:24:03.970183
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/yeee-$PATH') == os.path.expandvars('${HOME}/yeee-$PATH')
    assert expand('~/a/test') == os.path.expandvars('~/a/test')
    assert expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-21 21:24:11.972202
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-21 21:24:19.325672
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'TEST'
    os.environ['HOME'] = 'HOME'
    assert os.path.expandvars('$TEST') == 'TEST'
    assert os.path.expandvars('${TEST}') == 'TEST'
    assert expand('${TEST}') == 'TEST'
    assert expand('${HOME}') == 'HOME'

    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-21 21:24:21.299623
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(lines=None) is not None

# Generated at 2022-06-21 21:24:25.717706
# Unit test for function expand
def test_expand():
    assert expand('~/hello') == os.path.expanduser('~/hello')
    assert expand('${HOME}/hello') == os.environ['HOME'] + '/hello'
    assert expand('') == ''
    assert expand('hello') == 'hello'



# Generated at 2022-06-21 21:24:29.820429
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()
    print('Doctests passed')


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:24:39.583667
# Unit test for function load_env_file
def test_load_env_file():
    import os
    os.environ['HOME'] = '...'
    os.environ['PATH'] = '...:...'

    test_lines = ['TEST=${HOME}/yeee-$PATH',
                  'THISIS=~/a/test',
                  'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                        ('THISIS', '.../a/test'),
                                        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    result = load_env_file(test_lines)
    assert(expected == result)


# Unit test

# Generated at 2022-06-21 21:24:49.315496
# Unit test for function expand
def test_expand():
    # Tests with environmental variables
    assert expand('$HOME') == os.environ['HOME']
    assert expand('$PATH') == os.environ['PATH']
    assert expand('${HOME}') == os.environ['HOME']

    # Tests with tildes
    assert expand('~') == os.environ['HOME']
    assert expand('~/') == os.environ['HOME'] + '/'
    assert expand('~/a') == os.environ['HOME'] + '/a'

    # Tests combining both
    assert expand('${HOME}/a') == os.environ['HOME'] + '/a'
    assert expand('${HOME}/a/b') == os.environ['HOME'] + '/a/b'

# Generated at 2022-06-21 21:24:59.509351
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    parsed = list(parse_env_file_contents(lines))

    assert parsed == [
        ("TEST", "${HOME}/yeee"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]



# Generated at 2022-06-21 21:25:09.866120
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> parse_env_file_contents()
    <generator object parse_env_file_contents at 0x7fa8d79b2400>

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> list(parse_env_file_contents(lines))
    [('TEST', '.../yeee'),
     ('THISIS', '.../a/test'),
     ('YOLO',
      '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """
    pass



# Generated at 2022-06-21 21:25:12.122432
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee') == os.path.join(os.path.expanduser('~'), 'yeee')



# Generated at 2022-06-21 21:25:15.028177
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/test',
        'HOME=/home/user'
    ]
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', expand('') + 'test'),
        ('HOME', '/home/user')
    ])

# Generated at 2022-06-21 21:25:16.523312
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:25:23.215637
# Unit test for function load_env_file
def test_load_env_file():
    # Ensure that the function load_env_file works correctly
    test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(test_lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:25:28.297956
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = collections.OrderedDict(parse_env_file_contents(lines))
    assert changes['TEST'] == '.../yeee'
    assert changes['THISIS'] == '.../a/test'
    assert changes['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:25:41.630368
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_content = """
    TEST1=${HOME}/asdf
    TEST2="${PATH}"
    TEST3="${PATH}/test"
    TEST4='${PATH}'
    """
    env_lines = env_content.split('\n')
    env_lines = [x.strip() for x in env_lines]
    env_lines = [x for x in env_lines if len(x) > 0]
    env_values = parse_env_file_contents(env_lines)
    env_dict = dict(env_values)
    assert env_dict['TEST1'] == '${HOME}/asdf'
    assert env_dict['TEST2'] == '${PATH}'
    assert env_dict['TEST3'] == '${PATH}/test'

# Generated at 2022-06-21 21:25:45.673274
# Unit test for function expand
def test_expand():
    assert expand('/home') == '/home'
    assert expand('~') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expandvars('${HOME}')



# Generated at 2022-06-21 21:25:52.993355
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "abccc"
    assert os.environ["TEST"] == "abccc"

    assert expand("$TEST") == "abccc"
    assert expand("${TEST}") == "abccc"
    assert expand("$TEST/ddd") == "abccc/ddd"
    assert expand("${TEST}/ddd") == "abccc/ddd"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

    test_expand()

    print("done")

# Generated at 2022-06-21 21:26:04.347170
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Valid lines
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = load_env_file(lines, write_environ=None)
    expected = {'TEST': os.path.expanduser(os.path.join('~', 'yeee-' + os.environ['PATH'])),
                'THISIS': os.path.expanduser('~/a/test'),
                'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}
    assert actual == expected

    # Invalid lines

# Generated at 2022-06-21 21:26:12.463684
# Unit test for function expand
def test_expand():
    ret = expand('~/hello')
    assert re.match(r'\A' + os.getenv('HOME') + '/hello\Z', ret), ret

    ret = expand('${HOME}/hello/${HOME}')
    assert re.match(r'\A' + os.getenv('HOME') + '/hello/' + os.getenv('HOME') + '\Z', ret), ret


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-21 21:26:22.151686
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = test_env_file_contents()
    results = parse_env_file_contents(contents)

    results = list(results)

# Generated at 2022-06-21 21:26:23.798367
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    failure_count, test_count = doctest.testmod()
    assert failure_count == 0

# Generated at 2022-06-21 21:26:35.650051
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())

    for k in ('HOME', 'PATH'):
        assert environ[k] != '$' + k

    assert environ['TEST'] == '.../.../yeee-...:...'
    assert environ['THISIS'] == '.../a/test'
    assert environ['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == '__main__':
    import doctest

   

# Generated at 2022-06-21 21:26:46.328126
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Must fail because it has blank lines
    lines = ['', '', '', '']
    ret = parse_env_file_contents(lines)
    assert not ret

    # Must fail because it has a comment line
    lines = ['# Comment line']
    ret = parse_env_file_contents(lines)
    assert not ret

    # Must fail because it has a malformed line
    lines = ['malformed=line']
    ret = parse_env_file_contents(lines)
    assert not ret

    # Must pass
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = parse_env_file_contents(lines)


# Generated at 2022-06-21 21:26:51.102438
# Unit test for function expand
def test_expand():
    # Given a variable that gets expanded to an absolute path
    os.environ['LOOT_PATH'] = '~/loot'
    # When I expand it (using expand)
    val = expand('$LOOT_PATH')
    # Then the expanded path is the full path
    assert val == os.path.abspath('~/loot')



# Generated at 2022-06-21 21:27:00.249490
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content1 = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    for k, v in parse_env_file_contents(content1):
        assert "~" in v or "$" in v
        if "~" in v:
            assert "$" not in v



# Generated at 2022-06-21 21:27:07.482959
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

    assert changes['TEST'] == os.environ.get('HOME') + '/yeee-' + os.environ.get('PATH')
    assert changes['THISIS'] == os.environ.get('HOME') + '/a/test'
    assert changes['YOLO'] == os.environ.get('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == '__main__':
    test_load_env_file

# Generated at 2022-06-21 21:27:15.736309
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = load_env_file(lines, write_environ=dict())

    for k, v in d.items():
        print(k, '=', v)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:27:26.595815
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w+t') as f:
        f.writelines(['TEST=1\n', 'TEST2=2\n', 'TEST3=$TEST2\n'])

        f.flush()

        load_env_file([f.name])

        assert os.environ['TEST'] == '1'
        assert os.environ['TEST2'] == '2'
        assert os.environ['TEST3'] == '2'

    with tempfile.NamedTemporaryFile(mode='w+t') as f:
        f.writelines(['TEST="1"\n'])

        f.flush()

        load_env_file([f.name])


# Generated at 2022-06-21 21:27:32.003312
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "test_value"
    assert expand("~/a/$TEST") == os.path.join(os.path.expanduser("~"), "a", "test_value")



# Generated at 2022-06-21 21:27:40.188471
# Unit test for function load_env_file
def test_load_env_file():
    # Test for invalid input
    with pytest.raises(ValueError):
        load_env_file([''])
    with pytest.raises(ValueError):
        load_env_file([''])
    with pytest.raises(ValueError):
        load_env_file(['TEST=a/b/c'])
    with pytest.raises(ValueError):
        load_env_file(['=a/b/c'])
    # Test for valid input
    assert load_env_file(['TEST=1']) == {'TEST': '1'}
    assert load_env_file(['TEST2=a/b/c']) == {'TEST2': 'a/b/c'}

# Generated at 2022-06-21 21:27:50.287482
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO
    import os

    lines = """
    # comment line
    TEST1=${HOME}/yeee
    TEST2=~/yeee
    TEST3="yeee"
    TEST4='yeee'
    TEST5="singl'quote"
    TEST6='singl"quote'
    TEST7=singlequote
    FOO=foo
    """

    environ = dict(os.environ)

    changes = load_env_file(StringIO(lines), write_environ=environ)

    assert environ['TEST1'] == os.path.join(os.environ['HOME'], 'yeee')
    assert environ['TEST1'] == changes['TEST1']


# Generated at 2022-06-21 21:27:57.243148
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ={})

    assert result == collections.OrderedDict([('TEST', '.../yeee'),
                                              ('THISIS', '.../a/test'),
                                              ('YOLO',
                                               '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:28:02.274775
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(["a=b"], write_environ=dict()) == collections.OrderedDict([('a', 'b')])
    assert load_env_file(["a=b", "c=d"], write_environ=dict()) == collections.OrderedDict([('a', 'b'), ('c', 'd')])
    assert load_env_file(["a=b", "c=d", "e=f"], write_environ=dict()) == collections.OrderedDict([('a', 'b'), ('c', 'd'), ('e', 'f')])



# Generated at 2022-06-21 21:28:03.892360
# Unit test for function load_env_file
def test_load_env_file():
    pass



# Generated at 2022-06-21 21:28:07.769792
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-21 21:28:08.605550
# Unit test for function expand
def test_expand():
    assert expand('__EYES__') == '__EYES__'
    assert os.path.isdir(expand('~'))



# Generated at 2022-06-21 21:28:17.546617
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = parse_env_file_contents(lines)
    real_result = collections.OrderedDict()
    for key, value in contents:
        real_result[key] = value

    assert 'TEST' in real_result
    assert 'THISIS' in real_result
    assert 'YOLO' in real_result
    assert real_result['TEST'] == os.path.expanduser('~/yeee-') + os.pathsep.join(os.getenv('PATH').split(os.pathsep)[::-1])[::-1]

# Generated at 2022-06-21 21:28:21.943784
# Unit test for function expand
def test_expand():
    userdir = os.path.expanduser("~")
    homedir = os.environ["HOME"]
    assert expand("~") == userdir
    assert expand("${HOME}") == homedir
    assert expand("${HOME}/folder") == os.path.join(homedir, "folder")

# Generated at 2022-06-21 21:28:29.322824
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST") == os.environ.get("YOLO")
    assert expand("~/a/test") == os.environ.get("THISIS")
    assert os.environ.get("TEST") == os.path.expanduser("${HOME}/yeee")



# Generated at 2022-06-21 21:28:37.960950
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-21 21:28:49.422982
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Env file without expansion
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert len(list(parse_env_file_contents(lines))) == 3
    assert list(parse_env_file_contents(lines))[0] == ('TEST', '${HOME}/yeee')
    assert list(parse_env_file_contents(lines))[1] == ('THISIS', '~/a/test')
    assert list(parse_env_file_contents(lines))[2] == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:28:57.966891
# Unit test for function load_env_file
def test_load_env_file():
    # suppress warnings from 'pytest'
    from unittest import mock
    import warnings
    warnings.filterwarnings('ignore')
    mock.patch('os.environ.update').start()

    sample_file_path = os.path.join(os.getcwd(), 'tests', 'data', 'sample_env.txt')

    with open(sample_file_path) as f:
        load_env_file(f.readlines())

    assert os.environ['TEST'] == '~/yeee-~:~/bin'

# Generated at 2022-06-21 21:29:06.237487
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import textwrap
    lines = textwrap.dedent("""
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """).strip().split("\n")

    result = dict(parse_env_file_contents(lines))

    assert result == {
        "TEST": "~/yeee",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    }



# Generated at 2022-06-21 21:29:17.408834
# Unit test for function load_env_file
def test_load_env_file():
    environ = {}
    env_file = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results_d = load_env_file(env_file, write_environ=environ)

    from pprint import pformat
    print(pformat(results_d, indent=4))

    assert results_d
    assert 'TEST' in results_d and results_d['TEST']
    assert 'THISIS' in results_d and results_d['THISIS']
    assert 'YOLO' in results_d and results_d['YOLO']


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-21 21:29:28.716562
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert list(result) == expected


# Generated at 2022-06-21 21:29:34.025537
# Unit test for function expand
def test_expand():
    assert expand("/non/existing/path/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}/yolo") == \
           "/non/existing/path/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}/yolo"

    assert os.path.isdir(expand("~/"))

# Generated at 2022-06-21 21:29:40.120132
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-21 21:29:50.489509
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents([])) == dict()

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = dict(parse_env_file_contents(lines))

    assert result['TEST'].startswith('/home/')
    assert result['TEST'].endswith('/yeee')
    assert result['THISIS'].endswith('/a/test')
    assert result['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:29:59.138322
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # parse_env_file_contents
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-21 21:30:04.490970
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = tuple(parse_env_file_contents(lines))
    assert values == (('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

# Generated at 2022-06-21 21:30:13.769181
# Unit test for function expand
def test_expand():
    test_dict = {
        "DIR1": "~",
        "DIR2": "$HOME",
        "DIR3": "/test/$HOME",
        "DIR4": "/test/$HOME/yeah",
        "TEST": "~/test",
        "EMPTY": ""
    }

    expanded_test_dict = {
        "DIR1": os.environ.get('HOME'),
        "DIR2": os.environ.get('HOME'),
        "DIR3": "/test/" + os.environ.get('HOME'),
        "DIR4": "/test/" + os.environ.get('HOME') + "/yeah",
        "TEST": os.environ.get('HOME') + "/test",
        "EMPTY": ""
    }


# Generated at 2022-06-21 21:30:21.418347
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines)
    assert env == {'TEST': expand('${HOME}/yeee'), 'THISIS': expand('~/a/test'), 'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}



# Generated at 2022-06-21 21:30:34.421185
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '{}/yeee'.format(os.environ['HOME'])),
        ('THISIS', '{}/a/test'.format(os.environ['HOME'])),
        ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ['HOME']))
    ]


# Generated at 2022-06-21 21:30:45.932519
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing function: parse_env_file_contents")

    # Testing quotes
    test_case = (
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        "TEST = 'blablabla'",
        'TEST = "blablabla"'
    )

    test_output = dict(parse_env_file_contents(lines=test_case))

    # Testing if home dir is expanded
    assert '${HOME}' not in test_output['TEST']
    assert '${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}' in test_output['YOLO']

# Generated at 2022-06-21 21:30:54.996834
# Unit test for function expand
def test_expand():
    assert expand('~/linux') == expand('$HOME/linux')

# Generated at 2022-06-21 21:30:58.782473
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open(os.path.join(os.path.dirname(__file__), '../tests/.env'), 'r') as f:
        for key, val in parse_env_file_contents(lines=f):
            print(f"key={key}, val={val}")



# Generated at 2022-06-21 21:31:09.620686
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': os.path.expandvars('${HOME}/yeee'),
                                                    'THISIS': os.path.expanduser('~/a/test'),
                                                    'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}



# Generated at 2022-06-21 21:31:17.726130
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    load_env_file(lines)

    assert 'TEST' in os.environ
    assert 'HOME' in os.environ['TEST']

    assert 'THISIS' in os.environ
    assert 'a' in os.environ['THISIS']

    assert 'YOLO' in os.environ
    assert 'swaggins' in os.environ['YOLO']
    assert 'NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in os.environ['YOLO']



# Generated at 2022-06-21 21:31:27.158151
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=a'])) == [('TEST', 'a')]
    assert list(parse_env_file_contents(['TEST=a ', ' TEST2=b'])) == [('TEST', 'a'), ('TEST2', 'b')]
    assert list(parse_env_file_contents(['TEST=a', 'TEST2="b"'])) == [('TEST', 'a'), ('TEST2', 'b')]
    assert list(parse_env_file_contents(['TEST=a', "TEST2='b'"])) == [('TEST', 'a'), ('TEST2', 'b')]
    assert list(parse_env_file_contents(['TEST=a', "TEST2='b b'"]))

# Generated at 2022-06-21 21:31:31.596061
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:31:35.340883
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines)



# Generated at 2022-06-21 21:31:47.223923
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    )


# Generated at 2022-06-21 21:31:54.268417
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())
    assert environ == collections.OrderedDict([('TEST', '.../yeee'),
                                               ('THISIS', '.../a/test'),
                                               ('YOLO',
                                                '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-21 21:31:59.499284
# Unit test for function expand
def test_expand():
    os.environ['HOME'] = '/home/user'
    os.environ['PATH'] = '/bin:/usr/bin'

    assert expand('$HOME/test') == '/home/user/test'
    assert expand('~/test/$PATH') == '/home/user/test/bin:/usr/bin'

