

# Generated at 2022-06-21 21:23:30.670941
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())
    assert environ['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-') + os.pathsep.join(os.environ['PATH'].split(os.pathsep))
    assert environ['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-21 21:23:35.104786
# Unit test for function load_env_file
def test_load_env_file():
    """ """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:23:44.270757
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test 1

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.join(os.getenv('HOME'), 'yeee')),
        ('THISIS', os.path.join(os.path.expanduser('~'), 'a', 'test')),
        ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]

    # Test 2


# Generated at 2022-06-21 21:23:54.535282
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test that env var expansion works
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert env['TEST'] == os.path.expanduser('~') + '/yeee'
    assert env['THISIS'] == os.path.expanduser('~') + '/a/test'
    assert env['YOLO'] == os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    # Test that single quotes are honoured

# Generated at 2022-06-21 21:23:57.674511
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:23:59.741441
# Unit test for function expand
def test_expand():
    assert expand('~/a/b') == os.path.expanduser('~/a/b')
    assert expand('$HOME/a/b') == os.path.join(os.environ['HOME'], 'a', 'b')



# Generated at 2022-06-21 21:24:05.267468
# Unit test for function expand
def test_expand():
    assert expand("hoi") == "hoi"
    assert expand("~/hoi") == os.path.expanduser("~/hoi")
    assert expand("$HOME/hoi") == os.path.expandvars("$HOME/hoi")



# Generated at 2022-06-21 21:24:15.273084
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    expected = collections.OrderedDict()
    expected['TEST'] = os.path.join(os.environ.get('HOME', ''), 'yeee-',
                                    os.path.pathsep.join(os.environ.get('PATH', '').split(os.path.pathsep)))
    expected['THISIS'] = os.path.join(os.environ.get('HOME', ''), 'a', 'test')

# Generated at 2022-06-21 21:24:27.442066
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    
    def test_parse_env_file_contents():
        for k, v in parse_env_file_contents(lines):
            if k not in {'TEST', 'THISIS', 'YOLO'}:
                raise AssertionError

    def test_load_env_file():
        ret = load_env_file(lines, write_environ={})

        if all(isinstance(ret, dict) and 
               not isinstance(ret, collections.OrderedDict)):
            raise AssertionError

        if not isinstance(os.environ, dict):
            raise

# Generated at 2022-06-21 21:24:29.149894
# Unit test for function expand
def test_expand():
    val = "~/a/b"
    assert val == expand(expand(val))

# Generated at 2022-06-21 21:24:39.015564
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = {k: v for k, v in parse_env_file_contents(lines)}

    assert data['TEST'] == '.../yeee'
    assert data['THISIS'] == '.../a/test'
    assert data['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:24:49.101700
# Unit test for function expand
def test_expand():
    """Tests that the environment variables are expanded correctly."""
    with tempfile.TemporaryDirectory() as td:
        # Write a temporary file
        (h, fn) = tempfile.mkstemp(dir=td)
        with os.fdopen(h, "w") as f:
            f.write("TEST=$HOME/yeee\n")
            f.write("THISIS=~/a/test\n")

        # The temporary file should exist
        assert os.path.exists(fn)

        # The temporary file does not have any environment variables expanded
        with open(fn) as f:
            for line in f:
                assert not line.startswith(os.path.expanduser("~"))

        # Expand the environment variables in the temporary file
        os.environ["HOME"] = os.path.expanduser

# Generated at 2022-06-21 21:24:52.925741
# Unit test for function expand
def test_expand():
    assert expand("~/test") == "/home/a/test"
    assert expand("${HOME}/test") == "/home/a/test"



# Generated at 2022-06-21 21:25:03.010013
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert changes == {
        'TEST': os.path.expandvars('${HOME}/yeee-$PATH'),
        'THISIS': os.path.expandvars('~/a/test'),
        'YOLO': os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }



# Generated at 2022-06-21 21:25:12.221940
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """



# Generated at 2022-06-21 21:25:13.712956
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.join(os.environ['HOME'], 'test')



# Generated at 2022-06-21 21:25:24.934112
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "1"
    assert expand("test") == "test"
    assert expand("$TEST") == "1"
    assert expand("${TEST}") == "1"

    os.environ["TEST"] = "1"
    os.environ["TEST2"] = "2"
    os.environ["TEST3"] = "3"

    assert expand("${TEST}") == "1"
    assert expand("${TEST}${TEST2}") == "12"
    assert expand("${TEST}${TEST2}${TEST3}") == "123"
    assert expand("${TEST}${TEST2}${TEST3}") == "123"

    assert expand("abcd$TEST") == "abcd1"

# Generated at 2022-06-21 21:25:30.361262
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['$PATH', '${HOME}/yeee', '~/a/test', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for line in lines:
        for k, v in parse_env_file_contents([line]):
            assert expand(line) == v

# Generated at 2022-06-21 21:25:35.644635
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:25:47.595302
# Unit test for function expand
def test_expand():
    sample = [
        r"""\home\test.txt""",
        r"home\test.txt",
        r"\home\test.txt",
        r"C:\home\test.txt",
        r"~\test.txt"
    ]

    # Using static path
    expected = [
        r"C:\home\test.txt",
        r"C:\home\test.txt",
        r"\home\test.txt",
        r"C:\home\test.txt",
        r"C:\Users\evgeny\test.txt"
    ]

    for i, s in enumerate(sample):
        res = expand(s)
        print(res)
        assert res == expected[i]

    print("OK")


if __name__ == "__main__":
    test_expand()

# Generated at 2022-06-21 21:25:51.435359
# Unit test for function expand
def test_expand():
    assert expand("./stuff/bar/${HOME}") == os.path.expanduser("./stuff/bar/~")



# Generated at 2022-06-21 21:25:55.441007
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-21 21:25:58.676549
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-21 21:26:08.540476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import textwrap

    lines = """\
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    lines = textwrap.dedent(lines).split('\n')

    # Output should be:
    # OrderedDict([('TEST', '.../yeee'),
    #              ('THISIS', '.../a/test'),
    #              ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    load_env_file(lines)


# Generated at 2022-06-21 21:26:20.719015
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []

    val = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == val


# Generated at 2022-06-21 21:26:25.722330
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    <generator object parse_env_file_contents at 0x...>
    """



# Generated at 2022-06-21 21:26:36.396641
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    t1 = """TEST=yeee
            THISIS=a/test
            YOLO="$HOME/swaggins"
            YOLO_AGAIN=$HOME/swaggins
            YEAH="$FOO/swaggins"
            HEY=${HOME}/asdf
            OKAY='I am a single quoted string'
            """.split('\n')
    t2 = """TEST=yeee
            THISIS=a/test
            YOLO="$HOME/swaggins"
            YOLO_AGAIN=$HOME/swaggins
            YEAH="$FOO/swaggins"
            HEY=${HOME}/asdf
            OKAY='I am a single quoted string'
            """.split('\n')


# Generated at 2022-06-21 21:26:40.962386
# Unit test for function expand
def test_expand():
    if os.path.exists("/temp"):
        assert expand("/temp") == "/temp"
    assert expand("$HOME") == expand("~")
    assert expand("/tmp/folder/$HOME") == "/tmp/folder/" + expand("~")


if __name__ == "__main__":
    test_expand()
    # TODO: write unit tests for load_env_file

# Generated at 2022-06-21 21:26:51.186358
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = io.StringIO(r'''TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST''')
    d = load_env_file(lines, write_environ=dict())
    assert isinstance(d, collections.OrderedDict)
    assert d == {'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

# Generated at 2022-06-21 21:27:01.210712
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(lines=(
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    )) == collections.OrderedDict([
        # Key
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-21 21:27:08.760741
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ["TEST=yeee", "TEST2=yeee2"]
    assert list(parse_env_file_contents(contents)) == [("TEST", "yeee"), ("TEST2", "yeee2")]



# Generated at 2022-06-21 21:27:15.121668
# Unit test for function expand
def test_expand():
    assert expand('~/Downloads') != '~/Downloads'
    assert expand('~/Downloads') == os.path.expanduser('~/Downloads')
    assert expand('$HOME/Downloads') != '$HOME/Downloads'
    assert expand('$HOME/Downloads') == os.path.expandvars('$HOME/Downloads')



# Generated at 2022-06-21 21:27:18.195739
# Unit test for function load_env_file
def test_load_env_file():
    import inspect
    import doctest
    doctest.run_docstring_examples(load_env_file, globals(), verbose=True, name="test_load_env_file")



# Generated at 2022-06-21 21:27:25.669902
# Unit test for function expand
def test_expand():
    d = {"HOME": os.path.expanduser("~")}
    os.environ.update(d)

    assert expand("$HOME/tmp") == os.path.expanduser("~") + "/tmp"
    assert expand("~/tmp") == os.path.expanduser("~") + "/tmp"
    assert expand("~/tmp") == os.path.expanduser("~") + "/tmp"
    assert expand("~") == os.path.expanduser("~")



# Generated at 2022-06-21 21:27:28.994887
# Unit test for function expand
def test_expand():
    assert expand("$HOME/test") == "..."



# Generated at 2022-06-21 21:27:33.289603
# Unit test for function expand
def test_expand():
    assert expand("./test") == os.path.expanduser("./test")
    assert expand("$HOME/test") == os.path.expanduser("$HOME/test")
    assert expand("~/test") == os.path.expanduser("~/test")



# Generated at 2022-06-21 21:27:39.432429
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:27:43.188607
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pprint

    res = parse_env_file_contents(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    res = dict(res)

    pprint.pprint(res)

# Generated at 2022-06-21 21:27:52.989795
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from xt.tests import tty_capture

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = parse_env_file_contents(lines)

    with tty_capture() as cap:
        for line in lines:
            print(line)

    assert cap.out == """\
('TEST', '.../yeee')
('THISIS', '.../a/test')
('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
"""

# Generated at 2022-06-21 21:28:00.770744
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    result = list(parse_env_file_contents(lines))
    reference = [
        ("TEST", os.path.expandvars("${HOME}/yeee-$PATH")),
        ("THISIS", os.path.expanduser("~/a/test")),
        ("YOLO", os.path.expanduser("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
    ]
    assert result == reference



# Generated at 2022-06-21 21:28:12.947502
# Unit test for function expand
def test_expand():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    assert type(load_env_file) == collections.OrderedDict

# Generated at 2022-06-21 21:28:14.825767
# Unit test for function expand
def test_expand():
    assert expand("./test") == os.path.normpath(os.path.join(os.getcwd(), 'test'))



# Generated at 2022-06-21 21:28:19.136898
# Unit test for function expand
def test_expand():
    assert expand("/tmp") == "/tmp"
    assert expand("~/tmp") == os.path.expanduser("~/tmp")
    assert expand("$HOME") == os.environ["HOME"]



# Generated at 2022-06-21 21:28:23.482359
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:28:25.017093
# Unit test for function expand
def test_expand():
    assert expand('~/a') == os.path.expanduser('~/a')



# Generated at 2022-06-21 21:28:35.829356
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        "",
        "# This is a comment",
        "YEEY=${HOME}/${SOMETHING/that/does/not/exist}",
    ]

    actual = collections.OrderedDict(parse_env_file_contents(lines))


# Generated at 2022-06-21 21:28:40.914229
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for key, value in parse_env_file_contents(lines):
        print('{0}={1}'.format(key, value))



# Generated at 2022-06-21 21:28:50.982676
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = list(parse_env_file_contents(lines))
    assert ret[0][0] == 'TEST'
    assert ret[0][1] == '${HOME}/yeee'
    assert ret[1][0] == 'THISIS'
    assert ret[1][1] == '~/a/test'
    assert ret[2][0] == 'YOLO'
    assert ret[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:28:52.992821
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:29:03.915401
# Unit test for function load_env_file
def test_load_env_file():
    from pprint import pprint
    from io import StringIO, TextIOWrapper
    import io
    import sys


    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    pprint(load_env_file(lines, write_environ=dict()))

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = dict()

# Generated at 2022-06-21 21:29:22.145870
# Unit test for function expand
def test_expand():
    old_env = os.environ.copy()
    os.environ['TEST'] = '1'
    assert expand('$TEST') == '1'
    os.environ = old_env

# Generated at 2022-06-21 21:29:34.404560
# Unit test for function load_env_file
def test_load_env_file():
    # Setup
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    # Exercise

# Generated at 2022-06-21 21:29:41.263884
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:29:48.215937
# Unit test for function expand
def test_expand():
    # Test that environment variable is expanded
    os.environ["THAT"] = "test"
    assert expand("$THAT") == "test"

    # Test that user directory is expanded
    assert expand("~") == os.path.expanduser("~")

    # Test that both environment variable and user directory get expanded
    os.environ["THAT"] = "~"
    assert expand("$THAT") == os.path.expanduser("~")



# Generated at 2022-06-21 21:29:52.513781
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import copy
    import doctest

    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL, m=copy)



# Generated at 2022-06-21 21:29:54.845105
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(__doc__.splitlines())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:29:57.438402
# Unit test for function expand
def test_expand():
    assert '.../a/test' == expand('~/a/test')
    assert '.../a/test' == expand('${HOME}/a/test')

# Generated at 2022-06-21 21:29:58.709750
# Unit test for function expand
def test_expand():
    assert os.path.isabs(expand('~/yolo'))

# Generated at 2022-06-21 21:30:05.711538
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict()
    expected['TEST'] = f'{os.getenv("HOME")}/yeee-' \
                       f'{os.pathsep.join(os.getenv("PATH").split(os.pathsep))}'  # FIXME: {os.getenv('PATH')}
    expected['THISIS'] = os.getenv('HOME') + '/a/test'
    expected['YOLO'] = os.getenv('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-21 21:30:09.376892
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.environ["HOME"]
    assert expand("~/") == os.environ["HOME"] + "/"
    assert expand("$HOME/") == os.environ["HOME"] + "/"
    assert expand("~") == os.environ["HOME"]

# Generated at 2022-06-21 21:30:52.129731
# Unit test for function load_env_file

# Generated at 2022-06-21 21:30:55.791514
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    This uses doctest

    https://docs.python.org/3/library/doctest.html
    """
    import doctest
    import sys
    
    doctest.testmod(sys.modules[__name__])



# Generated at 2022-06-21 21:30:58.783374
# Unit test for function load_env_file
def test_load_env_file():
    from tests.test_env_file_helper import load_env_file_contents_test, load_env_file_test

    load_env_file_contents_test()
    load_env_file_test()



# Generated at 2022-06-21 21:31:04.376753
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    _ = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:31:15.219969
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    f = tempfile.NamedTemporaryFile()

# Generated at 2022-06-21 21:31:19.605128
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])

# Generated at 2022-06-21 21:31:23.750992
# Unit test for function expand
def test_expand():
    val = '~/a/b/c'
    assert expand(val) == os.path.expanduser(val)

    val = '/a/b/c'
    assert expand(val) == val

    val = 'a/b/c'
    assert expand(val) == val



# Generated at 2022-06-21 21:31:30.460825
# Unit test for function load_env_file
def test_load_env_file():
    def check_env(filename):
        with open(filename, "rt") as f:
            lines = f.readlines()
            lines = [line.strip() for line in lines]

        env = load_env_file(lines)

        for k, v in env.items():
            env[k] = expand(v)

        os.environ.update(env)

    check_env("env_files/env_file_1")

    assert os.environ["YO_TEST_PATH"] == "~/hello/this/is/a/test"
    assert os.environ["YO_TEST_PATH_2"] == "~/hello/this/is/a/test/a/thing"


# Generated at 2022-06-21 21:31:33.310637
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    os.environ['HOME'] = '/home/user'
    os.environ['PATH'] = '/bin:/usr/bin'
    doctest.testmod()



# Generated at 2022-06-21 21:31:46.301069
# Unit test for function load_env_file
def test_load_env_file():
    # Given
    lines = [
        'TEST=${HOME}/yeee-${PATH}',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    # When
    actual = load_env_file(lines, write_environ=dict())

    # Then
    expected = collections.OrderedDict([
        ('TEST', f'{expand("~")}/yeee-{expand("$PATH")}'),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])
    assert actual == expected

# Generated at 2022-06-21 21:32:56.459683
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = dict(parse_env_file_contents(lines))
    assert results
    assert set(results.keys()) == {'TEST', 'THISIS', 'YOLO'}
    assert '$PATH' in results['TEST']
    assert '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in results['YOLO']

# Generated at 2022-06-21 21:32:58.361391
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:33:04.115415
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    vals = parse_env_file_contents(lines)

    for k, v in vals:
        print(f"Key: {k}; val: {v}")

    # for key in vals.keys():
    #     print(f"Key: {key}; val: {vals[key]}")

# Generated at 2022-06-21 21:33:10.278165
# Unit test for function expand
def test_expand():
    test_env_file_values(
        [
            ("a", "b", "b"),
            ("ab", "d", "d"),
            ("b${C}d", "e", "e"),
            ("f${G}h", "i", "i"),
            ("j${K}l", "m", "m"),
        ]
    )



# Generated at 2022-06-21 21:33:14.285792
# Unit test for function expand
def test_expand():
    # pylint: disable=E1101
    v = '~/.config'
    assert expand(v) == os.path.expandvars(v)
    assert expand(v) == os.path.expanduser(v)



# Generated at 2022-06-21 21:33:19.687626
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.expanduser("~/test")
    assert expand(os.path.expanduser("~/test")) == os.path.expanduser("~/test")

