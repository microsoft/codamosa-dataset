

# Generated at 2022-06-21 21:23:39.189582
# Unit test for function load_env_file
def test_load_env_file():
    # Test basic env file
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    # Test env file that includes a path with a tilde
    lines = ['TEST=~/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    # Test env file with a string that includes both types of quotes

# Generated at 2022-06-21 21:23:45.421606
# Unit test for function expand
def test_expand():
    home = os.path.expanduser('~')
    os.environ['TEST_VAR'] = home

    # these should return the exact same string
    assert expand('~/env_file') == os.path.join(home, 'env_file')
    assert expand('$TEST_VAR/env_file') == os.path.join(home, 'env_file')

    os.environ['TEST_VAR'] = ''
    assert expand('$TEST_VAR/env_file') == 'env_file'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:23:55.621515
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:24:05.113686
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    text_file = open("../../tests/env_file_contents", "r")
    lines = text_file.read().splitlines()
    test_envs = dict(parse_env_file_contents(lines))
    assert len(test_envs) == 3
    assert test_envs['TEST'] == '$HOME/yeee-$PATH'
    assert test_envs['THISIS'] == '~/a/test'
    assert test_envs['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:24:14.792733
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines=lines)
    assert isinstance(res, typing.Generator)

    res = load_env_file(lines=lines, write_environ=dict())
    assert 'TEST' in res
    assert res['TEST'] != '${HOME}/yeee'
    assert res['TEST'] == os.path.expandvars('${HOME}/yeee')

    assert 'THISIS' in res
    assert res['THISIS'] != '~/a/test'
    assert res['THISIS'] == os.path.expanduser

# Generated at 2022-06-21 21:24:17.941463
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('${HOME}/') == os.path.expanduser('~/')



# Generated at 2022-06-21 21:24:28.512685
# Unit test for function expand
def test_expand():
    assert expand(
        r'~/a/test/') == os.path.expanduser(r'~/a/test/')

    assert expand('${HOME}/yeee') == os.path.expanduser(
        '~/yeee')

    assert expand('~/a/test') == os.path.expanduser(
        '~/a/test')

    assert expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == os.path.expanduser(
        '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:24:36.051586
# Unit test for function expand
def test_expand():
    # test expandvars
    os.environ["TEST_EXPAND_VARS"] = "test"
    assert expand("${TEST_EXPAND_VARS}") == "test"

    # test expanduser
    assert expand("~/") == os.path.expanduser("~/")

    # test all together
    assert expand("${HOME}/testing") == os.path.expanduser("~/testing")



# Generated at 2022-06-21 21:24:43.424185
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=None) == collections.OrderedDict(
        TEST=f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}',
        THISIS=f'{os.environ["HOME"]}/a/test',
        YOLO=f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )



# Generated at 2022-06-21 21:24:44.946151
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')

# Generated at 2022-06-21 21:24:58.975385
# Unit test for function load_env_file
def test_load_env_file():
    import os

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    filename = 'test.env'
    with open(filename, 'w') as f:
        f.write('\n'.join(lines))

    environ = os.environ.copy()
    changes = load_env_file(lines, write_environ=environ)

    assert changes is not None
    assert len(changes) == 3
    assert changes['TEST'] == os.path.expanduser(os.path.expandvars(lines[0].split('=')[1]))

# Generated at 2022-06-21 21:25:01.187360
# Unit test for function expand
def test_expand():
    os.environ['TESTVAR'] = 'test'
    assert expand('$TESTVAR/yeee') == 'test/yeee'
    assert expand('~/yeee') == os.path.expanduser('~/yeee')

# Generated at 2022-06-21 21:25:13.277924
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:25:21.341112
# Unit test for function expand
def test_expand():
    assert expand('hi') == 'hi'
    assert expand('$TEST') == '${TEST}'
    assert expand('$HOME/$HOME') == '$HOME/$HOME'
    assert expand('~')[:2] in ('/h', '/U')
    assert expand('~/')[:2] in ('/h', '/U')
    assert expand('~/test')[-5:] == '/test'
    assert expand('~/test/folder')[-10:] == '/test/folder'

# Generated at 2022-06-21 21:25:25.606436
# Unit test for function expand
def test_expand():
    """
    Expands variables and user name.

    >>> expand('$HOME/tmp')
    '.../tmp'
    >>> expand('~/tmp')
    '.../tmp'
    >>> expand('${HOME}/tmp')
    '.../tmp'
    """
    pass



# Generated at 2022-06-21 21:25:30.480782
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    env_vars = set()

    for key, val in parse_env_file_contents():
        env_vars.add(key)

    assert "TEST" in env_vars
    assert "THISIS" in env_vars
    assert "YOLO" in env_vars



# Generated at 2022-06-21 21:25:40.232089
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert load_env_file(lines, {}) == collections.OrderedDict(
        TEST='.../yeee-...:...',
        THISIS='.../a/test',
        YOLO='.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

# Generated at 2022-06-21 21:25:51.230850
# Unit test for function load_env_file
def test_load_env_file():
    output = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=dict())

    # This could be fragile
    assert output['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-', os.path.pathsep.join(os.getenv('PATH').split(':')))
    assert output['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-21 21:25:53.299870
# Unit test for function expand
def test_expand():
    expansion = expand("~/yo")

    assert expansion != "~/yo", "test_expand: test expand() failed, expansion is:\n" + expansion



# Generated at 2022-06-21 21:26:04.252631
# Unit test for function load_env_file
def test_load_env_file():
    # pylint: disable=no-member
    assert load_env_file(['HOME=${HOME}/yeee-$PATH', 'PATH=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == collections.OrderedDict([('HOME', os.path.join(os.environ['HOME'], 'yeee-', os.environ['PATH'])), ('PATH', os.path.join(os.environ['HOME'], 'a', 'test')), ('YOLO', os.path.join(os.environ['HOME'], 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-21 21:26:16.556865
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    with_expanded_variables = {
        'TEST': expand('${HOME}/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }

    assert {k: v for k, v in parse_env_file_contents(lines)} == with_expanded_variables



# Generated at 2022-06-21 21:26:20.258168
# Unit test for function expand
def test_expand():
    env = dict()
    env["HOME"] = "."
    env["PATH"] = "."
    with mock.patch('os.environ', env):
        assert expand("${HOME}") == "."



# Generated at 2022-06-21 21:26:23.795997
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee') == (os.path.expanduser(os.path.expandvars('$HOME/yeee')))
    assert expand('~/yeee') == (os.path.expanduser(os.path.expandvars('~/yeee')))



# Generated at 2022-06-21 21:26:35.649408
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_name = tmp_dir.name

    # Create a temporary env file
    tmp_file = tempfile.NamedTemporaryFile(prefix="tmp_env_file", mode="w", dir=tmp_dir_name, delete=False)
    tmp_file.write('TEST=${HOME}/yeee-$PATH\n')
    tmp_file.write('THISIS=~/a/test\n')
    tmp_file.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
    tmp_file.close()

    lines = open(tmp_file.name, 'r').readlines()

    # Test function
    changes = load_env_file

# Generated at 2022-06-21 21:26:38.807512
# Unit test for function expand
def test_expand():
    # Test that expand works on simple variables
    assert expand("${HOME}/test") == os.path.join(os.getenv("HOME"), "test")
    # And that it works on user variables
    assert expand("~/test") == os.path.join(os.getenv("HOME"), "test")



# Generated at 2022-06-21 21:26:40.448594
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.run_docstring_examples(load_env_file, globals())

# Generated at 2022-06-21 21:26:46.026882
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:26:49.790081
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    _test_parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])



# Generated at 2022-06-21 21:26:51.076833
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:26:53.433407
# Unit test for function expand
def test_expand():
    assert os.path.expanduser('~') == expand('~')



# Generated at 2022-06-21 21:27:00.053981
# Unit test for function expand
def test_expand():
    env = os.environ
    env['EXPAND_TEST_VAR'] = 'yeees'
    assert 'yeees' == expand(env['EXPAND_TEST_VAR'])
    assert ('/root/yeees' == expand(os.path.join('$HOME', '$EXPAND_TEST_VAR')))

# Generated at 2022-06-21 21:27:09.993649
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = parse_env_file_contents(lines)
    for k, v in lines:
        print('{} = {}'.format(k, v))

    # Test that dict() is also OK
    lines = dict([('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    lines = parse_env_file_contents(lines.items())

# Generated at 2022-06-21 21:27:17.591534
# Unit test for function expand
def test_expand():
    cases = [
        ("~/test", "test", "this should not be expanded"),
        ("/somepath", "/somepath", "this should not be expanded"),
        ("/somepath/${HOME}/test", "/somepath/test", "this should be expanded"),
        ("${HOME}/test", "test", "this should be expanded"),
    ]

    for case in cases:
        input, expected, message = case
        assert expand(input) == expected, message

# Generated at 2022-06-21 21:27:27.953652
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))

# Generated at 2022-06-21 21:27:31.287164
# Unit test for function expand
def test_expand():
    commands = [
        ("$HOME", os.environ['HOME']),
        ("~", os.environ['HOME']),
        ("$HOME/a/b/c.log", os.environ['HOME'] + "/a/b/c.log"),
    ]
    for cmd, expected in commands:
        assert expected == expand(cmd)



# Generated at 2022-06-21 21:27:39.955193
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for a scalar env value
    lines = ['TEST=${HOME}/yeee']
    test_result = {k: v for k, v in parse_env_file_contents(lines)}
    assert os.environ['HOME'] + '/yeee' == test_result['TEST']

    # Test for a scalar env value, with weird quoting
    lines = ['TEST="${HOME}/yeee"']
    test_result = {k: v for k, v in parse_env_file_contents(lines)}
    assert os.environ['HOME'] + '/yeee' == test_result['TEST']

    # Test for a scalar env value, with weird quoting
    lines = ["TEST='${HOME}/yeee'"]

# Generated at 2022-06-21 21:27:52.325289
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=a/test'])) == [('TEST', 'a/test')]
    assert list(parse_env_file_contents(['TEST=$PATH'])) == [('TEST', '$PATH')]
    assert list(parse_env_file_contents(['TEST="$PATH"'])) == [('TEST', '$PATH')]
    assert list(parse_env_file_contents(['TEST="a\\\\b"'])) == [('TEST', 'a\\b')]
    assert list(parse_env_file_contents(['TEST="a\\"b"'])) == [('TEST', 'a"b')]

# Generated at 2022-06-21 21:27:53.858022
# Unit test for function expand
def test_expand():
    import sys

    if sys.platform == "win32":
        raise RuntimeError("Path expansion on Windows not supported")



# Generated at 2022-06-21 21:28:01.402625
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict([('TEST', '%s/yeee-%s' % (os.environ.get('HOME'), os.environ.get('PATH'))),
                                        ('THISIS', os.path.expanduser('~/a/test')),
                                        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    assert result == expected



# Generated at 2022-06-21 21:28:09.368330
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_input = ["TEST=${TEST}/yeee", "HOGE=$PWD"]

    expected_output = [("TEST", "./yeee"), ("HOGE", "$PWD")]
    actual_output = parse_env_file_contents(test_input)
    assert list(actual_output) == expected_output


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:28:19.116612
# Unit test for function load_env_file
def test_load_env_file():
    # Reversed because the side effect of `load_env_file` is to modify the environment
    # and the test methods may depend on it.
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = collections.OrderedDict(load_env_file(lines, write_environ=None))

    # os.environ['TEST'] is expected to be similar to '.../.../yeee-...:...'
    values['TEST'] = re.sub(r'^(.*/yeee-).*/(.*)', r'\1...\2', values['TEST'])

    assert values == collections.OrderedDict

# Generated at 2022-06-21 21:28:28.440077
# Unit test for function expand
def test_expand():
    single_dollar = "foo$bar"
    double_dollar = "foo$$bar"
    home_folder = "~"
    home_folder_with_user = "~/batata"
    home_folder_with_user_and_dollar = "~/batata$"
    home_folder_with_dollar = "~$batata"

    assert expand(single_dollar) == "foo$bar"
    assert expand(double_dollar) == "foo$bar"
    assert expand(home_folder) == os.path.expanduser(home_folder)
    assert expand(home_folder_with_user) == os.path.expanduser(home_folder_with_user)

# Generated at 2022-06-21 21:28:33.997244
# Unit test for function load_env_file
def test_load_env_file():
    # Testing all importable variables
    my_home = os.getenv('HOME')
    my_path = os.getenv('PATH')
    my_swag = os.getenv('SWAG')

    if my_home is None or my_path is None or my_swag is None:
        raise RuntimeError('Unable to get env variables')

    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = collections.OrderedDict()
    expected['TEST'] = my_home + '/yeee-' + my_path
    expected['THISIS'] = my_home + '/a/test'

# Generated at 2022-06-21 21:28:38.030904
# Unit test for function expand
def test_expand():
    os.environ['TEST_VAR'] = 'test_var'
    os.environ['HOME'] = os.path.expanduser('~')

    assert expand('${TEST_VAR}') == 'test_var'

    return True

# Generated at 2022-06-21 21:28:48.446576
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=None)
    assert result == collections.OrderedDict([
        ('TEST', os.path.expanduser('${HOME}/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])

# Generated at 2022-06-21 21:28:51.697092
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == expand("${HOME}")
    assert expand("$HOMER") == expand("${HOMER}")
    assert expand("~") == os.path.expanduser("~")



# Generated at 2022-06-21 21:28:59.213092
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    tempdir = tempfile.TemporaryDirectory()

    filename = os.path.join(tempdir.name, 'test.txt')
    with open(filename, 'w') as f:
        f.write('TEST=${HOME}/yeee')

    load_env_file(lines=[filename])


if __name__ == "__main__":
    print("testing load_env_file")
    test_load_env_file()

# Generated at 2022-06-21 21:29:07.592280
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import re
    import unittest

    class LoadEnvFileTest(unittest.TestCase):
        TEST_ENV_VARS = '''TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'''

        def test_load_env_file(self):
            expected_dict = collections.OrderedDict()
            expected_dict['TEST'] = os.path.expanduser(self.TEST_ENV_VARS.splitlines()[0].split('=')[1])

# Generated at 2022-06-21 21:29:10.011233
# Unit test for function expand
def test_expand():
    os.environ['FOO'] = 'bar'

    assert expand('${FOO}') == 'bar'



# Generated at 2022-06-21 21:29:15.223534
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=os.environ)

# Generated at 2022-06-21 21:29:27.257866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert len(list(parse_env_file_contents())) == 0

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../.../yeee'),
                                                                                  ('THISIS', '.../a/test'),
                                                                                  ('YOLO',
                                                                                   '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-21 21:29:32.841141
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    import pprint
    pprint.pprint(load_env_file(lines, write_environ=dict()))


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:29:35.085497
# Unit test for function expand
def test_expand():
    assert expand(None) is None
    assert expand('${FOO}') == '${FOO}'
    assert expand('${HOME}') == '/home/user'

# Generated at 2022-06-21 21:29:36.815783
# Unit test for function expand
def test_expand():
    test_var_key = "TEST_VAR"
    test_var = expand("$HOME")
    assert test_var == "/home/travis"

# Generated at 2022-06-21 21:29:39.114990
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(["TEST=foo", "YEE=bar"]) == collections.OrderedDict([("TEST", "foo"), ("YEE", "bar")])

# Generated at 2022-06-21 21:29:49.156246
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed = parse_env_file_contents(lines)
    res = collections.OrderedDict(parsed)
    assert res == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-21 21:29:53.956122
# Unit test for function expand
def test_expand():
    # Test expansion of the single variables $HOME and $USER
    # and the combination of variables
    assert expand('/$USER/$HOME') == '/{}/{}'.format(os.environ['USER'], os.environ['HOME'])



# Generated at 2022-06-21 21:30:02.392063
# Unit test for function expand
def test_expand():
    assert expand("") == ""
    assert expand("$HOME/tmp") == os.path.expanduser("$HOME/tmp")
    assert expand("~/tmp") == os.path.expanduser("~/tmp")
    assert expand("${HOME}/tmp") == os.path.expanduser("${HOME}/tmp")
    assert expand("~/tmp") == os.path.expanduser("~/tmp")
    assert expand("$HOME") == os.path.expanduser("$HOME")
    assert expand("~") == os.path.expanduser("~")
    assert expand("${HOME}") == os.path.expanduser("${HOME}")
    assert expand("~") == os.path.expanduser("~")

# Generated at 2022-06-21 21:30:10.070998
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    suite = unittest.TestSuite()

    suite.addTest(TestLoadEnvFile('test_load_env_file', lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']))
    suite.addTest(TestLoadEnvFile('test_load_env_file_no_expansion', lines=['TEST=$A/${B}/yeee']))

    return suite


# Generated at 2022-06-21 21:30:16.924018
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    results = load_env_file(lines, write_environ=environ)
    assert results == {
        'TEST': os.path.expanduser('~/yeee-') + os.path.expandvars('${PATH}'),
        'THISIS': os.path.expanduser('~/a/test'),
        'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

# Generated at 2022-06-21 21:30:33.670936
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    assert load_env_file(lines, write_environ=dict()) == {
        "TEST": expand(f"{os.getenv('HOME')}/yeee-{os.getenv('PATH')}"),
        "THISIS": expand(f"{os.getenv('HOME')}/a/test"),
        "YOLO": expand(f"{os.getenv('HOME')}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    }



# Generated at 2022-06-21 21:30:38.970927
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:30:50.689900
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    s = '''    export VAR="$HOME/yee"
    export TEST='$VAR');
    export TEST2="$VAR"

    export TEST3="$VAR");
    export TEST4='$VAR')
    export TEST5=$VAR
    '''
    lines = s.split("\n")

# Generated at 2022-06-21 21:30:52.882154
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH']

    env_changes = load_env_file(lines, write_environ=dict())

    assert env_changes
    assert 'TEST' in env_changes



# Generated at 2022-06-21 21:30:55.250539
# Unit test for function expand
def test_expand():
    val = os.environ["HOME"]
    assert expand('~') == val
    assert expand(f'${{"HOME"}}') == val



# Generated at 2022-06-21 21:31:01.371496
# Unit test for function expand
def test_expand():
    def check(val, expected):
        assert expand(val) == expected
    check('$HOME', os.getenv('HOME'))
    check('${HOME}', os.getenv('HOME'))
    check('~', os.path.expanduser('~'))
    check('~/', os.path.expanduser('~/'))
    check('~/xyz', os.path.expanduser('~/xyz'))
    check(os.path.expanduser('~/xyz'), os.path.expanduser('~/xyz'))



# Generated at 2022-06-21 21:31:13.191386
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected_lines = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    test_lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    assert list(parse_env_file_contents(test_lines)) == expected_lines
    assert list(parse_env_file_contents(test_lines)) == expected_lines



# Generated at 2022-06-21 21:31:20.073889
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = []

    for k, v in parse_env_file_contents(lines):
        assert k == v

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for k, v in parse_env_file_contents(lines):
        assert k == v



# Generated at 2022-06-21 21:31:27.899115
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/yeee') == f'{os.getenv("HOME")}/yeee'
    assert expand('~/a/test') == f'{os.getenv("HOME")}/a/test'
    assert expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == f'{os.getenv("HOME")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:31:36.251100
# Unit test for function expand
def test_expand():
    # Test that the user's home directory is expanded correctly
    assert expand("~") == os.environ["HOME"]
    assert expand("~/") == os.environ["HOME"] + "/"
    assert expand("~/foo") == os.environ["HOME"] + "/foo"

    # Test that variables are expanded correctly
    assert expand("$HOME") == os.environ["HOME"]
    assert expand("${HOME}") == os.environ["HOME"]
    assert expand("${HOME}/foo") == os.environ["HOME"] + "/foo"
    assert expand("$HOME/foo") == os.environ["HOME"] + "/foo"

    # Test that tildes are not expanded if there is no following
    # filename separator
    assert expand("~foo") == "~foo"

# Generated at 2022-06-21 21:31:48.078655
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    lines = ['TEST=${HOME}/yeee-$PATH', 'TEST1=$TEST']
    load_env_file(lines, write_environ=dict())

    with tempfile.NamedTemporaryFile(mode='w') as tf:
        tf.write('\n'.join(lines))
        tf.flush()
        load_env_file(tf.name)

# Generated at 2022-06-21 21:31:50.911600
# Unit test for function expand
def test_expand():
    """
    >>> expand('~/yeee') == expand('$HOME/yeee')
    True
    """


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:32:01.231509
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_ = load_env_file(lines, write_environ=dict())
    assert dict_ == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])



# Generated at 2022-06-21 21:32:12.418421
# Unit test for function expand
def test_expand():
    # No user input should mean no change
    assert os.path.expandvars("") == os.path.expanduser("") == expand("")

    assert expand("~") == os.path.expanduser("~")

    # Home should still be there since no environmental variables
    cwd = os.getcwd()
    home = os.environ["HOME"]
    assert expand(f"{cwd}") == cwd
    assert expand(f"~{home}") == home

    os.environ["YO"] = "MAN"
    assert expand("${YO}") == "MAN"
    assert expand("${YO}-${YO}") == "MAN-MAN"
    assert expand("${YO}-${YO}") == "MAN-MAN"

# Generated at 2022-06-21 21:32:21.586597
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    import tempfile

    class TestLoadEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            with tempfile.NamedTemporaryFile() as test_file:
                # Write contents to file
                test_file.write(b"TEST=foo\n")
                test_file.write(b"TEST1=foobar\n")

                # Force writing to file
                test_file.flush()

                # Load env file
                changes = load_env_file(open(test_file.name))

                self.assertDictEqual(changes, {
                    "TEST": "foo",
                    "TEST1": "foobar"
                })

                # Load env file again
                changes = load_env_file(open(test_file.name))

# Generated at 2022-06-21 21:32:30.255796
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())

    assert env['TEST'] == os.path.join(os.environ['HOME'], 'yeee-', os.environ['PATH'])
    assert env['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')

# Generated at 2022-06-21 21:32:40.522165
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()

    assert load_env_file(lines, write_environ=environ) == {
        'TEST': os.path.expanduser('~/yeee-' + os.environ['PATH']),
        'THISIS': os.path.expanduser('~/a/test'),
        'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

# Generated at 2022-06-21 21:32:43.633415
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:32:54.726531
# Unit test for function expand
def test_expand():
    import os

    test_env = dict(
        key1=os.sep.join(["", "home", "user1"]),
        key2=os.sep.join(["", "home", "user2"]),
    )


# Generated at 2022-06-21 21:33:02.856926
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = load_env_file(lines, write_environ=dict())

    assert results == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-21 21:33:13.276181
# Unit test for function expand
def test_expand():
    os.environ['TEST_VAR'] = '42'
    assert expand('$TEST_VAR') == '42'
    assert expand('~') == os.getenv('HOME')

# Generated at 2022-06-21 21:33:23.434526
# Unit test for function expand
def test_expand():
    old_home = os.getenv('HOME')
    path = os.environ['PATH']
    old_path = os.environ['PATH']
    os.environ['HOME'] = os.getenv('HOME')
    os.environ['PATH'] = os.getenv('PATH')
    os.environ['TEST_VAR'] = 'whatever'

    assert expand('~/test') == os.path.join(old_home, 'test')
    assert expand('${HOME}/test') == os.path.join(old_home, 'test')
    assert expand('${HOME}/${PATH}/test') == os.path.join(old_home, path, 'test')
    assert expand('${HOME}/$TEST_VAR') == os.path.join(old_home, 'whatever')