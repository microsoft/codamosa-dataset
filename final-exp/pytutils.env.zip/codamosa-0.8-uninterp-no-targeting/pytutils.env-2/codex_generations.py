

# Generated at 2022-06-21 21:23:35.389029
# Unit test for function load_env_file
def test_load_env_file():
    import pprint
    import sys


# Generated at 2022-06-21 21:23:44.200890
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    changes = collections.OrderedDict()

    for k, v in values:
        changes[k] = v

    assert changes['TEST'] == os.environ['HOME'] + '/yeee'
    assert changes['THISIS'] == os.environ['HOME'] + '/a/test'
    assert changes['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:23:52.412405
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    load_env_file(lines, environ)
    assert environ['TEST'] == os.path.expanduser(os.path.expandvars('${HOME}/yeee-$PATH'))
    assert environ['THISIS'] == os.path.expanduser(os.path.expandvars('~/a/test'))

# Generated at 2022-06-21 21:23:58.399419
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO

    lines = StringIO(
        """
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """
    )

    environ_updates = load_env_file(lines)



# Generated at 2022-06-21 21:24:07.757963
# Unit test for function load_env_file
def test_load_env_file():
    import ttbl
    import tempfile
    import os

    tempd = tempfile.mkdtemp()

    fn = os.path.join(tempd, "env")
    f = open(fn, "w")
    f.write("""\
FOO=BAR
"""
            )
    f.close()
    os.environ.pop('FOO', None)

    ttbl.env_file.load_env_file(open(fn))
    assert os.environ['FOO'] == 'BAR'

    f = open(fn, "w")
    f.write("""\
FOO=BAR
FOO_A=BAR_A
FOO_B=BAR_B
"""
            )
    f.close()

# Generated at 2022-06-21 21:24:14.226573
# Unit test for function expand
def test_expand():
    from os import environ, getcwd

    environ["TEST_ENV_FILE"] = f"{getcwd()}/tests/test_env_file.env"

    env_file_lines = []
    with open(expand("${TEST_ENV_FILE}")) as f:
        for line in f:
            env_file_lines.append(line.strip())

    print(load_env_file(env_file_lines, os.environ))
    return



# Generated at 2022-06-21 21:24:26.091174
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    if __package__ is None or __package__ == "":
        import sys
        from os.path import dirname, abspath

        sys.path.insert(0, dirname(dirname(abspath(__file__))))

    print("Test for function parse_env_file_contents")

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-21 21:24:34.699781
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    test_dir = os.path.dirname(__file__)

    handle = open(os.path.join(test_dir, "test.env"))
    lines = handle.readlines()
    handle.close()

    result = load_env_file(lines)

    assert result["DJANGO_SETTINGS_MODULE"] == "Test.env"
    assert int(result["TEST_INT"]) == 123

    result = load_env_file(["DJANGO_SETTINGS_MODULE=Test.env", "TEST_INT=123"])

    assert result["DJANGO_SETTINGS_MODULE"] == "Test.env"
    assert int(result["TEST_INT"]) == 123

# Generated at 2022-06-21 21:24:41.849429
# Unit test for function expand
def test_expand():
    home = os.path.expanduser('~')
    path = os.environ['PATH']

    assert expand('~') == home
    assert expand('$PATH') == path
    assert expand('${PATH}') == path

    os.environ['TEST'] = '$PATH'
    assert expand('${TEST}') == path
    assert expand('${TEST}') == path
    assert expand('${TEST}') == path

    del os.environ['TEST']



# Generated at 2022-06-21 21:24:46.128866
# Unit test for function expand
def test_expand():
    # test variable expansion
    os.environ['HOME'] = "/home/user"
    assert expand('${HOME}/files') == '/home/user/files'
    os.environ['TZ'] = "America/Los_Angeles"
    assert expand('${TZ}') == 'America/Los_Angeles'
    del os.environ['TZ']

    # test tilde expansion
    assert expand('~/files') == os.path.join(os.getenv('HOME'), 'files')
    assert expand('~') == os.getenv('HOME')

    # test tilde expansion with multiple values

# Generated at 2022-06-21 21:24:58.724301
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO
    out = StringIO()

    var_file = StringIO("""
export A=a
export B=${A}b
export C=${B}c
export D="Quote ' included"
export E="A backslash \\"
export F="Back to ${A}
""")

    result = load_env_file(var_file, write_environ=out)
    assert result == {
        'A': 'a',
        'B': 'ab',
        'C': 'abc',
        'D': "Quote ' included",
        'E': 'A backslash \\',
        'F': 'Back to ${A}'
    }



# Generated at 2022-06-21 21:25:06.947091
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    write_environ = dict()
    changes = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=write_environ)
    assert len(changes) == 3
    assert changes['TEST'].startswith(os.path.expanduser('~') + '/yeee-')
    assert changes['TEST'].endswith(':' + os.path.expandvars('$PATH'))
    assert changes['THISIS'] == os.path.expandvars('~/a/test')

# Generated at 2022-06-21 21:25:16.924803
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_data = '''
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        '''

    test_output = dict(parse_env_file_contents(test_data.splitlines()))

    assert 'TEST' in test_output
    assert 'THISIS' in test_output
    assert 'YOLO' in test_output

    assert '$' not in test_output['TEST']
    assert '$' not in test_output['THISIS']
    assert '$' not in test_output['YOLO']



# Generated at 2022-06-21 21:25:28.137578
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["# Test", "TEST1=1", "TEST2=2 # Test", "TEST3=3\" # Test", "TEST4=\"1 # Test", "TEST5='1 # Test",
             "TEST6='2 # Test", "TEST7=3' # Test", "TEST8=3\\ # Test", "TEST9='3\\ # Test", "TEST10='# Test",
             "TEST11=\"# Test\"", 'TEST12=\\"# Test\\"', "TEST13=\\ # Test", "TEST14 = 1"]


# Generated at 2022-06-21 21:25:40.533795
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function load_env_file
    """
    from os import environ

    lines = [
        'VAR1="some-value"',
        'VAR2="some-value\\"',
        'VAR3=\'some-value"',
        'VAR4=\'some-value\\\'',
        'VAR5=some-value',
        'VAR6=some-value\\',
    ]

    d = load_env_file(lines)


# Generated at 2022-06-21 21:25:43.473716
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ['HOME']
    assert expand('~/') == os.environ['HOME'] + '/'



# Generated at 2022-06-21 21:25:49.577512
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # The actual test
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines)

    print('result')
    print(results)
    for v in results:
        print(v)

    return


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:25:57.504255
# Unit test for function load_env_file
def test_load_env_file():
    # Get relative path of this file
    base_dir = os.path.dirname(__file__)
    # Get the path of the load_env_file.py file
    env_file_path = os.path.join(base_dir, "load_env_file.py")
    # Open the load_env_file.py file
    env_file = open(env_file_path, "r")
    # Get the contents of the file
    lines = env_file.readlines()
    # Close the file
    env_file.close()

    # Create a reference for the expected output
    expected = collections.OrderedDict()
    expected["TEST"] = os.path.expanduser("~") + "/" + "yeee" + "-" + os.path.expandvars("$PATH")
    expected

# Generated at 2022-06-21 21:26:08.121681
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_keys = ['TEST', 'THISIS', 'YOLO']
    actual_keys = []

    for key, value in parse_env_file_contents(lines):
        actual_keys.append(key)
        if key == 'TEST':
            re.search('..../..../yeee', value)
        elif key == 'THISIS':
            re.search('..../a/test', value)

# Generated at 2022-06-21 21:26:20.428963
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Returns key-value pairs of parsed env file content
    for line in [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]:
        assert len(list(parse_env_file_contents([line]))) == 1  # pragma: no cover

    # Expand variables
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee"])) == [("TEST", f"{os.environ['HOME']}/yeee")]

    # Expand ~