

# Generated at 2022-06-21 21:23:32.020558
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    assert isinstance(result, collections.OrderedDict)
    assert len(result) == 3
    assert result['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee')
    assert result['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-21 21:23:41.912707
# Unit test for function expand
def test_expand():
    test_cases = [
        (r'$HOME', os.environ['HOME']),
        (r'${HOME}', os.environ['HOME']),
        (r'$PATH+:', os.environ['PATH'] + '+:'),
        (r'${PATH}+:', os.environ['PATH'] + '+:'),
        (r'~/path_relative_to_home', os.environ['HOME'] + '/path_relative_to_home'),
        (r'~/path~relative_to_home', os.environ['HOME'] + '/path~relative_to_home'),
        (r'~/path_relative_to_home', os.environ['HOME'] + '/path_relative_to_home'),

    ]


# Generated at 2022-06-21 21:23:48.751219
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)

    # Use index to compare key + value to each list item
    for i, line in enumerate(output):
        assert line[0] == lines[i].split('=')[0]
        assert line[1] == lines[i].split('=')[1]



# Generated at 2022-06-21 21:23:52.574027
# Unit test for function expand
def test_expand():
    """
    Test running expand function.

    >>> os.environ['TEST_ENV_VAR'] = 'test'
    >>> expand('${TEST_ENV_VAR}/$HOME')
    'test/...'
    """
    return expand('${TEST_ENV_VAR}/$HOME')



# Generated at 2022-06-21 21:23:57.125844
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test"]
    actual = list(parse_env_file_contents(lines))
    print(actual)
    assert len(actual) == len(lines)



# Generated at 2022-06-21 21:24:07.029762
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests that parse_env_file_contents works properly, i.e. read values correctly.
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    for key, val in values:
        if key == 'TEST':
            assert expand(val) in ['.../yeee', '.../Documents/yeee', '.../.../yeee']
        elif key == 'THISIS':
            assert expand(val) in ['.../a/test', '.../.../.../a/test', '.../Documents/a/test']

# Generated at 2022-06-21 21:24:15.843402
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    results = parse_env_file_contents(lines)

    assert results.__next__() == ('TEST', os.path.expandvars('${HOME}/yeee-$PATH'))
    assert results.__next__() == ('THISIS', os.path.expanduser('~/a/test'))
    assert results.__next__() == ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-21 21:24:17.287189
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:24:19.132307
# Unit test for function expand
def test_expand():
    v = expand("$HOME/test")
    assert v == os.path.expanduser("~/test")



# Generated at 2022-06-21 21:24:30.660634
# Unit test for function expand
def test_expand():
    """
    $HOME, $PWD and $NONEXISTENT_VAR_THAT_DOES_NOT_EXIST are defined by default on most posix systems.

    >>> import os
    >>> expand('$HOME')
    '/home/...'
    >>> expand('${HOME}/yeee')
    '/home/.../yeee'
    >>> expand('$PWD/test')
    '/.../test'
    >>> expand('NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    'NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    >>> expand('~/test')
    '/home/.../test'
    >>> expand('~root/test')
    '/root/test'
    """
    pass



# Generated at 2022-06-21 21:24:37.771099
# Unit test for function expand
def test_expand():
    """
    Tests the expand method with different environment variables.

    >>> expand('$HOME') == os.path.expanduser('~')
    True

    >>> expand('${HOME}/testing') == os.path.expanduser('~') + '/testing'
    True

    >>> expand('${HOME}/testing-$PATH') == os.path.expanduser('~') + '/testing-...:...'
    True
    """
    pass



# Generated at 2022-06-21 21:24:48.235778
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    kvg = parse_env_file_contents(lines)

    values = collections.OrderedDict()

    for k, v in kvg:
        values[k] = v

    assert values == collections.OrderedDict([
        ('TEST', '$HOME/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])



# Generated at 2022-06-21 21:24:55.902915
# Unit test for function expand
def test_expand():
    assert expand("~/a/b") == os.path.expanduser("~/a/b")

    current_path = os.getcwd()
    os.environ["TEST"] = "test"
    assert expand("$HOME/../test/test/$TEST/file.txt") == current_path + "/../test/test/test/file.txt"
    os.environ.pop("TEST")


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-21 21:25:03.592309
# Unit test for function expand
def test_expand():
    testdata = {
        'teststring': 'teststring',
        'teststring with spaces': 'teststring with spaces',
        '~/hello': os.path.expanduser('~/hello'),
        '${HOME}/hello': os.path.expandvars('${HOME}/hello'),
        "~/hello": os.path.expanduser('~/hello'),
        '$HOME/hello': os.path.expandvars('$HOME/hello')
    }
    for k, v in testdata.items():
        assert expand(k) == v



# Generated at 2022-06-21 21:25:05.518792
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    import doctest
    doctest.testmod()

    class TestLoadEnvFile(unittest.TestCase):
        pass

    unittest.main()

# Generated at 2022-06-21 21:25:08.168950
# Unit test for function expand
def test_expand():
    assert expand(os.path.join('~', 'ye')) == os.path.join(os.path.expanduser('~'), 'ye')



# Generated at 2022-06-21 21:25:18.328586
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee-$PATH')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])



# Generated at 2022-06-21 21:25:29.191090
# Unit test for function load_env_file
def test_load_env_file():
    # Some tests for the load_env_file function
    import doctest
    doctest.testmod()

    # Ensure that load_env_file works with files, not just iterables

    test_file = 'test_load_env_file.txt'
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    with open(test_file, 'w') as handle:
        handle.writelines([f"{line}\n" for line in lines])

    env_dict = load_env_file(test_file)
    assert len(env_dict) == 2, "Expected two keys in loaded environment"
    assert 'TEST' in env_dict and 'THISIS' in env_dict, "Expected TEST and THISIS keys in loaded environment"

    # Clean up
    os.remove

# Generated at 2022-06-21 21:25:33.478996
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'hello'
    os.environ['PATH'] = '${TEST}'
    assert expand('${TEST}') == 'hello'
    assert expand('${PATH}') == 'hello'

# Generated at 2022-06-21 21:25:38.117101
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import unittest

    class TestLoadEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            lines = io.StringIO(
                'TEST=${HOME}/yeee-$PATH\n'
                'THISIS=~/a/test\n'
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
            )

            results = load_env_file(lines)


# Generated at 2022-06-21 21:25:50.481623
# Unit test for function expand
def test_expand():
    assert (
        expand('$HOME/..') == os.path.expanduser('~') + '/..'
    ), 'Function expand failed to expand relative path'

    assert (
        expand('~/..') == os.path.expanduser('~') + '/..'
    ), 'Function expand failed to expand relative path'

    assert (
        expand('$HOME') == os.path.expanduser('~')
    ), 'Function expand failed to expand variable'

    assert (
        expand('~') == os.path.expanduser('~')
    ), 'Function expand failed to expand variable'

    # No such variable
    assert (
        expand('$NONEXISTENT_VAR') == '$NONEXISTENT_VAR'
    ), 'Function expand failed to expand variable'

# Generated at 2022-06-21 21:25:51.622762
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("~") == os.path.expanduser("~")



# Generated at 2022-06-21 21:25:56.142689
# Unit test for function load_env_file
def test_load_env_file():
    from pprint import pprint

    env = {
        'HOME': '/home/user123',
        'PATH': '/usr/bin/:/usr/local/bin:/bin/'
    }

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    pprint(load_env_file(lines, write_environ=env))


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:26:07.818890
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    with open('.env') as fp:
        file_contents = fp.read()

    content_lines = file_contents.splitlines()

    loaded_vars = load_env_file(content_lines)

    assert len(loaded_vars) == 3
    assert loaded_vars['TEST'] == os.path.join(os.environ['HOME'], 'yeee-', ':'.join(os.environ['PATH'].split(':')))
    assert loaded_vars['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')

# Generated at 2022-06-21 21:26:15.931091
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open(os.path.join(os.path.dirname(__file__), 'test.env'), 'r') as f:
        assert load_env_file(f.readlines()) == load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])

# Generated at 2022-06-21 21:26:23.228606
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = dict(parse_env_file_contents(lines))
    assert result == {
        "TEST": "${HOME}/yeee",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }

# Generated at 2022-06-21 21:26:35.233088
# Unit test for function load_env_file
def test_load_env_file():
    _lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    _environ = {
        'HOME': '/home/user',
        'PATH': '/usr/bin:/bin/:/home/user/bin/',
    }


# Generated at 2022-06-21 21:26:43.894303
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    assert [(key, val) for key, val in parse_env_file_contents()] == []

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert [(key, val) for key, val in parse_env_file_contents(lines)] == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:26:48.756927
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:26:56.391862
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    assert dict(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == {
        'TEST': os.getenv('HOME') + '/yeee-' + os.getenv('PATH'),
        'THISIS': os.getenv('HOME') + '/a/test',
        'YOLO': os.getenv('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

# Generated at 2022-06-21 21:27:01.854806
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("$HOME") == os.environ.get("HOME")



# Generated at 2022-06-21 21:27:11.326291
# Unit test for function expand
def test_expand():
    import tempfile
    tmpdir = tempfile.mkdtemp()

    os.mkdir(os.path.join(tmpdir, "subdir"))
    os.environ["HOME"] = tmpdir
    os.environ["SUBDIR"] = "subdir"
    os.environ["FILENAME"] = "file.txt"

    assert "subdir" == expand("$SUBDIR")
    assert "subdir" == expand("${SUBDIR}")
    assert "subdir" == expand("${SUBDIR}")
    assert os.path.join(tmpdir, "subdir") == expand("${HOME}/${SUBDIR}")
    assert os.path.join(tmpdir, "subdir", "file.txt") == expand("${HOME}/${SUBDIR}/${FILENAME}")

# Generated at 2022-06-21 21:27:22.026630
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)

    real = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict((('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))

    assert real == expected



# Generated at 2022-06-21 21:27:30.267474
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = parse_env_file_contents(lines)

    result = collections.OrderedDict(
        (
            ('TEST', '${HOME}/yeee-$PATH'),
            ('THISIS', '~/a/test'),
            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        )
    )

    for k in result:
        assert next(contents) == (k, result[k])



# Generated at 2022-06-21 21:27:39.084973
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

    assert changes == collections.OrderedDict([
        ('TEST', os.path.join(os.path.expandvars('$HOME'), 'yeee-', os.path.expandvars('$PATH'))),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-21 21:27:50.750572
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        (
            ('TEST', os.path.expanduser(f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}')),
            ('THISIS', os.path.expanduser('~/a/test')),
            ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
        )
    )

# Generated at 2022-06-21 21:27:56.785823
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    load_env_file(lines)


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-21 21:28:03.063596
# Unit test for function expand
def test_expand():
    # $HOME and $PATH
    assert expand('$HOME/$PATH') == os.path.join(os.environ['HOME'], expand('$PATH'))
    assert expand('~/$PATH') == os.path.join(os.environ['HOME'], expand('$PATH'))

    # $PATH and $HOME
    assert expand('$PATH/$HOME') == os.path.join(expand('$PATH'), os.environ['HOME'])
    assert expand('$PATH/~') == os.path.join(expand('$PATH'), os.environ['HOME'])

    # ~/ and $HOME
    assert expand('~/test.txt') == os.path.join(os.environ['HOME'], 'test.txt')

# Generated at 2022-06-21 21:28:11.370475
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())
    print(environ)
    environ = load_env_file(lines, write_environ=dict())
    print(environ)


if __name__ == '__main__':
    # test_load_env_file()
    pass

# Generated at 2022-06-21 21:28:19.602259
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    e = load_env_file(lines)

    assert 'TEST' in e
    assert 'THISIS' in e
    assert 'YOLO' in e

    assert e['TEST'] == os.path.expanduser('~/yeee-{PATH}'.format(PATH=os.environ['PATH']))
    assert e['THISIS'] == os.path.expanduser('~/a/test')

# Generated at 2022-06-21 21:28:29.643875
# Unit test for function expand
def test_expand():
    assert expand("~/swag") == os.path.expanduser("~/swag")
    assert expand("$HOME/swag") == os.path.expandvars("$HOME/swag")
    assert expand("${HOME}/swag") == os.path.expandvars("${HOME}/swag")



# Generated at 2022-06-21 21:28:39.744625
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=$HOME/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    changes = load_env_file(lines, write_environ=dict())

    bash_cmd = r'bash -c "echo ${TEST} && echo ${THISIS} && echo ${YOLO}"'

    expected = """
.../.../yeee-...:...
.../a/test
.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
""".strip().split("\n")

    data = subprocess.check_output(bash_cmd, shell=True).decode("utf8").strip

# Generated at 2022-06-21 21:28:49.752860
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), '../test.env')
    with open(filename) as f:
        lines = f.readlines()

    result = load_env_file(lines)
    assert result['TEST'] == '~/yeee-~/a/b/c:/yeee/a/b/c'
    assert result['THISIS'] == '~/a/test'
    assert result['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:29:00.096324
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    # Grab our current path, to verify it gets injected
    savepath = os.environ.get('PATH')
    assert savepath is not None

    changes = load_env_file(lines, write_environ=os.environ)
    assert changes

    # Test that our path got injected.
    assert changes['PATH'] == savepath
    assert os.environ['PATH'] == savepath



# Generated at 2022-06-21 21:29:08.031453
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)
    result = list(result)

    assert result == [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]
    assert result[0][0] == 'TEST'
    assert result[0][1] == '.../yeee'
    assert result[1][0] == 'THISIS'

# Generated at 2022-06-21 21:29:10.821699
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.environ["HOME"]
    assert expand("~") == os.environ["HOME"]



# Generated at 2022-06-21 21:29:15.262995
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-21 21:29:21.560253
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert env['TEST'].endswith('/yeee-')
    assert env['THISIS'].endswith('/a/test')
    assert env['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-21 21:29:33.476864
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines, write_environ=dict())
    assert isinstance(res, collections.OrderedDict)
    assert 'TEST' in res
    assert 'THISIS' in res
    assert 'YOLO' in res
    assert res['TEST'] == os.path.expandvars('${HOME}/yeee')
    assert res['THISIS'] == os.path.expandvars('~/a/test')

# Generated at 2022-06-21 21:29:40.719248
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    res = load_env_file(lines)

    assert isinstance(res, collections.OrderedDict)
    assert len(res) == 3
    assert "TEST" in res
    assert "THISIS" in res
    assert "YOLO" in res

# Generated at 2022-06-21 21:29:48.772902
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('$HOME') == os.path.expanduser('$HOME')



# Generated at 2022-06-21 21:29:59.756774
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'yeee'
    os.environ['HOME'] = 'test_home'
    assert expand('$TEST') == 'yeee'
    assert expand('${TEST}') == 'yeee'
    assert expand('${TEST}/yeee') == 'yeee/yeee'
    assert expand('${TEST}/yeee-$TEST') == 'yeee/yeee-yeee'
    assert expand('~') == expand(os.environ['HOME'])

    assert expand('yeee') == 'yeee'
    assert expand('$NOTHING') == '$NOTHING'
    assert expand('${NOTHING}') == '${NOTHING}'



# Generated at 2022-06-21 21:30:07.692430
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = load_env_file(lines, write_environ=os.environ)
    assert ret == {'TEST': '${HOME}/yeee',
                   'THISIS': '~/a/test',
                   'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-21 21:30:09.376472
# Unit test for function load_env_file
def test_load_env_file():
    # type: () -> None
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:30:11.638194
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("~/a") == os.path.expandvars("~/a")

# Generated at 2022-06-21 21:30:12.979693
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


__all__ = ['load_env_file']

# Generated at 2022-06-21 21:30:16.072878
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ.get('HOME')
    assert expand('~') == os.environ.get('HOME')



# Generated at 2022-06-21 21:30:18.296929
# Unit test for function load_env_file
def test_load_env_file():
    command = ['python', '-m', 'pytest', '-k', 'test_load_env_file']
    subprocess.run(command)

# Generated at 2022-06-21 21:30:25.442578
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    parsed = load_env_file(lines)
    assert len(parsed) == 3
    assert parsed['TEST'] == os.path.expandvars('${HOME}/yeee')
    assert parsed['THISIS'] == os.path.expandvars('~/a/test')
    assert parsed['YOLO'] == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:30:37.392257
# Unit test for function load_env_file
def test_load_env_file():
    import os

    lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    assert load_env_file(lines, write_environ=None) == {
        "TEST": os.path.expanduser(os.getenv("HOME", "")) + "/yeee-" + os.getenv("PATH", ""),
        "THISIS": os.path.expanduser('~') + "/a/test",
        "YOLO": os.path.expanduser('~') + "/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }



# Generated at 2022-06-21 21:30:58.667937
# Unit test for function expand
def test_expand():
    current_path = os.path.dirname(os.path.abspath(__file__))
    home_dir = os.path.expanduser('~')

    assert expand('') == ''
    assert expand('__FILE__') == __file__
    assert expand('~') == home_dir
    assert expand('$HOME') == home_dir
    assert expand('./test') == os.path.join(current_path, 'test')
    assert expand('./test/') == os.path.join(current_path, 'test')
    assert expand('./test/../test') == os.path.join(current_path, 'test')
    assert expand('./test/../test/') == os.path.join(current_path, 'test')

# Generated at 2022-06-21 21:31:09.511403
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    os.environ["TEST"] = "yo"
    os.environ["TEST_PATH"] = "~/yo"
    os.environ["TEST_PATH_REL"] = "yo"
    to_write = dict()
    lines = ['TEST_NEW=${TEST_PATH}', 'TEST_OTHER=${TEST_PATH_REL}-${PATH}']
    load_env_file(lines, to_write)
    assert to_write["TEST_NEW"] == "~/yo"
    assert to_write["TEST_OTHER"] == "yo-" + os.pathsep.join(sys.path)



# Generated at 2022-06-21 21:31:12.569190
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expanduser('~')
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-21 21:31:24.067569
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=None)

    # Returns a list of tuples
    assert isinstance(list(results.items()), list)

    # Returns a list of tuples with the correct keys
    assert isinstance(list(results.keys()), list)
    assert list(results.keys()) == ['TEST', 'THISIS', 'YOLO']

    # Returns a list of tuples with the correct values
    assert isinstance(list(results.values()), list)

# Generated at 2022-06-21 21:31:28.976232
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '$HOME/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:31:36.200694
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:31:42.057871
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(dict(parse_env_file_contents(lines)))



# Generated at 2022-06-21 21:31:45.420674
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import shutil
    import tempfile
    import unittest

    def load_env_file_contents_from_filename(filename):
        with open(filename) as f:
            lines = f.readlines()
            lines = [x.replace('\n', '') for x in lines]
            return list(parse_env_file_contents(lines))

    def load_env_file_contents_from_string(string):
        return list(parse_env_file_contents(string.splitlines()))

    class TestLoadEnvFile(unittest.TestCase):
        def setUp(self):
            self.dir_name = tempfile.mkdtemp()

            self.env_file_name = os.path.join(self.dir_name, 'docker.env')

# Generated at 2022-06-21 21:31:56.269040
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Success cases
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    lines = ['TEST="${HOME}/yeee"', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-21 21:32:04.772419
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee',
                                         'THISIS=~/a/test',
                                         'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('TEST', '${HOME}/yeee'),
                                                                                                     ('THISIS', '~/a/test'),
                                                                                                     ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-21 21:32:23.564229
# Unit test for function load_env_file
def test_load_env_file():
    '''
    Test load_env_file function with test example from the docstring.

    Returns:
        int: 0 on success, 1 otherwise
    '''

    test_environ = dict()

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=test_environ)

    assert test_environ['TEST'] == expand('${HOME}/yeee-{}'.format(os.getenv('PATH')))
    assert test_environ['THISIS'] == expand('~/a/test')

# Generated at 2022-06-21 21:32:35.199779
# Unit test for function load_env_file
def test_load_env_file():
    environ = collections.OrderedDict()

    changes = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], environ)

    # Test changes
    for key, val in [('TEST', '.../yeee-...:...'), ('THISIS', '.../a/test'),
                     ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]:
        assert changes[key] == val

    # Test `environ`

# Generated at 2022-06-21 21:32:43.758689
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    This test parses an env file, and returns a list of tuples of the form (key, value).
    Note that there is no interpolation of variables at this point.
    """

# Generated at 2022-06-21 21:32:52.279483
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == '/home/johannes'
    assert expand('~/tmp') == '/home/johannes/tmp'
    assert expand('${HOME}/tmp') == '/home/johannes/tmp'
    assert expand('${HOME}$HOME/tmp') == '/home/johannes/home/johannes/tmp'
    assert expand('${HOME}${HOME}/tmp') == '/home/johannes/home/johannes/tmp'
    assert expand('/tmp') == '/tmp'


# Unit tests for parse_env_file_contents function

# Generated at 2022-06-21 21:32:55.457336
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == f'{os.environ["HOME"]}/test'
    assert expand('~/test') == f'{os.environ["HOME"]}/test'



# Generated at 2022-06-21 21:33:02.109211
# Unit test for function expand
def test_expand():
    assert expand("$HOME/hi") == os.path.expandvars("$HOME/hi")
    assert expand("~/hi") == os.path.expanduser("~/hi")
    assert expand("${HOME}/hi") == os.path.expandvars("${HOME}/hi")
    assert expand("~/$HOME") == os.path.expanduser("~/$HOME")


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-21 21:33:14.147926
# Unit test for function load_env_file
def test_load_env_file():
    import textwrap

    lines = textwrap.dedent("""\
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST""").split('\n')

    environ = dict()

    d = load_env_file(lines, environ)

    assert len(d) == 3
    assert environ['TEST'].endswith('yeee-/usr/bin:/usr/local/bin')
    assert environ['THISIS'].endswith('/a/test')
    assert environ['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:33:20.333047
# Unit test for function expand
def test_expand():
    # Arrange
    test_cases = [
        ('~/abc/def', '.../abc/def'),
        ('$HOME/abc/def', '.../abc/def'),
        ('$PATH:/opt/bin', '...:/opt/bin')
    ]

    # Act and Assert
    for t in test_cases:
        assert expand(t[0]) == t[1]

