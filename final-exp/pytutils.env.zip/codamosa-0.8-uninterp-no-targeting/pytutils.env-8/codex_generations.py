

# Generated at 2022-06-21 21:23:31.624361
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:23:35.609588
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:23:44.618505
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert tuple(parse_env_file_contents(['key="value"'])).pop() == ('key', 'value')
    assert tuple(parse_env_file_contents(['key="white space"'])).pop() == ('key', 'white space')
    assert tuple(parse_env_file_contents(['key="white space"'])).pop() == ('key', 'white space')
    assert tuple(parse_env_file_contents(['key=\'value\''])).pop() == ('key', 'value')
    assert tuple(parse_env_file_contents(['key=value'])).pop() == ('key', 'value')
    assert tuple(parse_env_file_contents(['key=value#comment'])).pop() == ('key', 'value')

# Generated at 2022-06-21 21:23:54.321309
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env = dict()
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=env)

    assert env['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee')
    assert env['THISIS'] == os.path.join(os.path.expanduser('~'), 'a/test')
    assert env['YOLO'] == os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-21 21:23:56.367247
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test'), \
        "Unit test for function expand failed."



# Generated at 2022-06-21 21:24:06.710557
# Unit test for function load_env_file
def test_load_env_file():
    try:
        import pytest
    except ImportError:
        print("No pytest available")
        return 1

    with pytest.raises(FileNotFoundError):
        load_env_file(lines=[], write_environ=os.environ)

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=None)

    assert isinstance(changes, collections.OrderedDict)
    assert "TEST" in changes
    assert "/yeee-" in changes["TEST"]
    assert ":" in changes["TEST"]

    assert "THISIS" in changes

# Generated at 2022-06-21 21:24:15.902638
# Unit test for function expand

# Generated at 2022-06-21 21:24:27.633740
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class Tester(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            rv = load_env_file(lines, write_environ=None)

# Generated at 2022-06-21 21:24:31.132648
# Unit test for function expand
def test_expand():
    assert expand("~") == expand("$HOME") == os.environ["HOME"]
    assert expand("$PATH") == os.environ["PATH"]
    assert expand("${PATH}") == os.environ["PATH"]



# Generated at 2022-06-21 21:24:40.239744
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    # Initialize dictionary
    env = dict()

    # Define (and load) a temporary environment file
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w+') as env_file:
        env_file.write("TEST=${HOME}/yeee-$PATH")
        env_file.write("\n")
        env_file.write("THISIS=~/a/test")
        env_file.write("\n")
        env_file.write("YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
        env_file.write("\n")
        env_file.flush()
