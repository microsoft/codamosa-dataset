

# Generated at 2022-06-21 21:23:30.724816
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import tempfile
    import unittest

    cwd = os.getcwd()
    home = os.environ.get('HOME', '')
    path = os.environ.get('PATH', '')

    class LoadEnvFileTestCase(unittest.TestCase):
        def test_env_vars_are_expanded(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-21 21:23:37.642543
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    try:
        filename = os.path.join(tempdir, 'test.env')
        with open(filename, 'w') as f:
            f.write('TEST=${HOME}/test\n')

        load_env_file([open(filename)])

        assert os.environ['TEST'] == os.path.expanduser('~/test')

    finally:
        shutil.rmtree(tempdir)



# Generated at 2022-06-21 21:23:40.120562
# Unit test for function expand
def test_expand():
    assert expand("~/.local/share/Steam/SteamApps/common/Game/Game") == os.path.expanduser("~/.local/share/Steam/SteamApps/common/Game/Game")



# Generated at 2022-06-21 21:23:43.477656
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:23:54.106083
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:24:02.832549
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests parse_env_file_contents().

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass

# Generated at 2022-06-21 21:24:06.743168
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:24:13.701687
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = load_env_file(lines, write_environ=dict())
    assert len(out) == 3
    assert '~/a/test' in out.values()
    assert '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in out.values()

# Generated at 2022-06-21 21:24:23.252650
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-21 21:24:34.646861
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    sep = '\\' if sys.platform.startswith('win') else '/'

    lines = ['TEST={}{}{}yeee'.format(sep, sep, sep),
             'THISIS=~{}a{}test'.format(sep, sep),
             'YOLO=~{}swaggins${}NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(sep, sep)]

    res = parse_env_file_contents(lines)

    assert res[0][0] == 'TEST'
    assert res[0][1].endswith(sep + 'yeee')

    assert res[1][0] == 'THISIS'
    assert res[1][1].endswith(sep + 'a' + sep + 'test')



# Generated at 2022-06-21 21:24:38.785094
# Unit test for function expand
def test_expand():
    assert expand("test") == "test"
    assert expand("~test") == expand("~test")
    assert expand("$test") == expand("$test")
    assert expand("${test}") == expand("${test}")



# Generated at 2022-06-21 21:24:49.066923
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~') + '/'
    assert expand('$HOME') == os.environ['HOME']
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('${HOME}/') == os.environ['HOME'] + '/'
    assert expand('~/$HOME') == os.path.expanduser('~') + '/' + os.environ['HOME']
    assert expand('~/${HOME}') == os.path.expanduser('~') + '/' + os.environ['HOME']
    assert expand('~/${HOME}/') == os.path.expanduser('~') + '/' + os.environ['HOME'] + '/'

# Generated at 2022-06-21 21:24:52.488622
# Unit test for function expand
def test_expand():
    assert expand('~/a/b/c') == os.path.expanduser('~/a/b/c')



# Generated at 2022-06-21 21:24:54.075000
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:25:04.109531
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([('TEST', os.path.join(os.environ["HOME"], 'yeee')),
                                        ('THISIS', os.path.join(os.environ["HOME"], 'a/test')),
                                        ('YOLO', "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")])

    actual = collections.OrderedDict(parse_env_file_contents(lines))

    assert expected == actual



# Generated at 2022-06-21 21:25:05.757402
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:25:09.253906
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(["TEST=${HOME}"])["TEST"] == os.environ["HOME"]
    assert load_env_file(["TEST=~"])["TEST"] == os.environ["HOME"]

# Generated at 2022-06-21 21:25:19.349306
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_result = [('TEST', os.environ['HOME'] + '/yeee'), ('THISIS', os.path.expanduser('~/a/test')),
                       ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]
    result = parse_env_file_contents(lines)
    assert result



# Generated at 2022-06-21 21:25:27.037933
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert len(changes) == 3

    assert changes['TEST'] == os.path.abspath(os.path.join(os.path.expanduser('~'), 'yeee-') + os.pathsep + os.path.getenv('PATH'))
    assert changes['THISIS'] == os.path.abspath(os.path.join(os.path.expanduser('~'), 'a', 'test'))

# Generated at 2022-06-21 21:25:39.640508
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # From honcho
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = collections.OrderedDict(parse_env_file_contents(contents))

    # Make sure that the environ is what we expect it to be
    assert len(env) == 3
    assert env['TEST'] == '~/yeee'
    assert env['THISIS'] == '~/a/test'
    assert env['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    # Parse a file containing pairs of key=value settings
    # Just to make sure that

# Generated at 2022-06-21 21:25:50.736957
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-21 21:25:56.018909
# Unit test for function load_env_file
def test_load_env_file():
    import io

    env_contents = """TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"""

    lines = io.StringIO(env_contents)
    od = load_env_file(lines, write_environ=None)

    assert od == collections.OrderedDict([
        ('TEST', '{}/yeee-{}'.format(expand('$HOME'), expand('$PATH'))),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])



# Generated at 2022-06-21 21:26:07.823562
# Unit test for function expand
def test_expand():

    os.environ['YOLO'] = '/yeee'
    os.environ['SWEAG'] = 'swaggins'

    # env variable expansion
    assert expand('${YOLO}/swag') == '/yeee/swag'
    assert expand('${YOLO}/swag/${SWEAG}') == '/yeee/swag/swaggins'

    # user home dir expansion
    assert expand('~/yeee') == os.path.expanduser('~/yeee')

    # no expansion
    assert expand('/yeee/s/w/a/g') == '/yeee/s/w/a/g'

    assert expand('~/') == expand('~/')
    assert expand('/tmp/') == expand('/tmp/')

    del os

# Generated at 2022-06-21 21:26:19.050201
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict(
        [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert result == expected, 'parse_env_file_contents(lines) returned {}, not {}'.format(result, expected)



# Generated at 2022-06-21 21:26:22.552496
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == os.environ['HOME'] + '/test'
    assert expand('~/test') == os.environ['HOME'] + '/test'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:26:23.933924
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-21 21:26:29.899712
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:26:36.076004
# Unit test for function expand
def test_expand():
    old_cwd = os.getcwd()
    os.chdir('/tmp')

    assert expand('~') == os.path.expanduser('~')
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('~/abc') == os.path.expanduser('~') + '/abc'
    assert expand('${HOME}/abc') == os.environ['HOME'] + '/abc'

    os.chdir(old_cwd)

# Generated at 2022-06-21 21:26:37.259929
# Unit test for function expand
def test_expand():
    assert(expand('.') == os.path.abspath('.'))



# Generated at 2022-06-21 21:26:44.657054
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_dict = dict(parse_env_file_contents(lines))

    assert 'TEST' in env_dict
    assert 'THISIS' in env_dict
    assert 'YOLO' in env_dict

    assert env_dict['TEST'] == os.environ['HOME'] + '/yeee'
    assert env_dict['THISIS'] == os.environ['HOME'] + '/a/test'

# Generated at 2022-06-21 21:26:50.636801
# Unit test for function expand
def test_expand():
    os.environ["HOME"] = '/home/user'
    os.environ["PATH"] = '/usr/bin'
    os.environ["USER"] = 'user'

    assert expand('${HOME}/test') == '/home/user/test'
    assert expand('~/test') == '/home/user/test'

# Generated at 2022-06-21 21:26:57.510278
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    class TestCase(unittest.TestCase):
        def test_env_file(self):
            lines = ["TEST=/home/daniel/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST", ""]
            expected = collections.OrderedDict([("TEST", "/home/daniel/yeee-:..."), ("THISIS", "/home/daniel/a/test"), ("YOLO", "/home/daniel/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")])
            self.assertEqual(load_env_file(lines), expected)
    unittest.main()

# Generated at 2022-06-21 21:26:59.366253
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['test=test', 'spaces="a a"']
    result = list(parse_env_file_contents(lines))
    assert result == [('test', 'test'), ('spaces', 'a a')]



# Generated at 2022-06-21 21:27:03.162998
# Unit test for function expand
def test_expand():
    os.environ["TEST_ENV"] = "some_value"
    assert expand("$TEST_ENV") == "some_value"
    assert expand("${TEST_ENV}") == "some_value"



# Generated at 2022-06-21 21:27:10.554958
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ] == [(k, v) for k, v in values]

# Generated at 2022-06-21 21:27:14.025859
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:27:25.186009
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function load_env_file
    """
    test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = dict()

    result = load_env_file(test_lines, write_environ=environ)

    print(result)

    # assert result == {'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}


if __name__ == '__main__':
    test_load_env_file

# Generated at 2022-06-21 21:27:37.080584
# Unit test for function expand
def test_expand():
    tmp_home = "/home/john/myhome"
    tmp_env = os.getenv("HOME", tmp_home)
    os.environ["HOME"] = tmp_home
    tmp_varname = "DUMMYVAR"
    tmp_var = "test"
    os.environ[tmp_varname] = tmp_var

    assert expand("~") == os.getenv("HOME")
    assert expand("${HOME}") == os.getenv("HOME")
    assert expand("$HOME") == os.getenv("HOME")
    assert expand("~/${HOME}") == os.getenv("HOME") + "/" + os.getenv("HOME")
    assert expand("~/~/${HOME}") == os.getenv("HOME") + "/~/" + os.getenv("HOME")
    assert expand

# Generated at 2022-06-21 21:27:40.717416
# Unit test for function expand
def test_expand():
    assert expand("~/foo") == os.path.expanduser("~") + "/foo"
    assert expand("${HOME}/foo") == os.path.expandvars("${HOME}") + "/foo"
    assert expand("${HOME}/foo") == os.path.expanduser("~") + "/foo"



# Generated at 2022-06-21 21:27:46.501221
# Unit test for function expand
def test_expand():
    os.environ['test_var'] = 'test_value'
    assert expand('${test_var}') == expand('$test_var') == 'test_value'
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-21 21:27:51.803099
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee", "THISIS=~/a/test"])) == [
        ("TEST", "..."), ("THISIS", "...")]



# Generated at 2022-06-21 21:27:53.352428
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(raise_on_error=True)



# Generated at 2022-06-21 21:28:01.037762
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:28:13.034691
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest
    import tempfile

    class TestParseEnvFileContents(unittest.TestCase):
        def test_output(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            d = collections.OrderedDict(parse_env_file_contents(lines))

            for k in ['TEST', 'THISIS', 'YOLO']:
                with self.subTest(k=k):
                    self.assertIn(k, d)

            self.assertTrue(d['TEST'].startswith(os.environ['HOME']))

# Generated at 2022-06-21 21:28:16.716003
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:28:24.940776
# Unit test for function expand
def test_expand():
    assert expand("~/blah") == os.path.expanduser("~/blah")
    assert expand('~foo/blah') == '~foo/blah'
    assert expand('${HOME}/blah') == os.path.expandvars('${HOME}/blah')
    assert expand('${NOTSET}/blah') == '${NOTSET}/blah'
    assert expand('$NOTSET/blah') == '$NOTSET/blah'
    assert expand('$$/blah') == os.path.expandvars('$$/blah')


if __name__ == '__main__':
    test_expand()

# Generated at 2022-06-21 21:28:27.550325
# Unit test for function expand
def test_expand():
    assert expand('~/test/file') == os.path.expanduser('~/test/file')
    assert expand('${TEST}/file') == os.path.expandvars('${TEST}/file')

# Generated at 2022-06-21 21:28:30.086820
# Unit test for function expand
def test_expand():
    assert expand('~/user/folder') == expand(os.path.expanduser('~/user/folder'))
    assert expand('${HOME}/user/folder') == expand(os.path.expandvars('${HOME}/user/folder'))

# Generated at 2022-06-21 21:28:38.031029
# Unit test for function expand
def test_expand():
    assert (expand('~/a') == os.path.expanduser('~/a'))
    assert (expand('${HOME}/a') == os.path.expanduser(os.path.join(os.path.expanduser('~'), 'a')))


if __name__ == '__main__':
    env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')

    with open(env_file, 'r') as f:
        load_env_file(f)

# Generated at 2022-06-21 21:28:47.751803
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    """
    assert True



# Generated at 2022-06-21 21:29:01.410125
# Unit test for function load_env_file
def test_load_env_file():
    if __name__ == '__main__':
        write_environ = collections.OrderedDict()
        load_env_file(lines=['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
                      write_environ=write_environ)

        assert write_environ == collections.OrderedDict(
            [('TEST', '/home/users/user/yeee'), ('THISIS', '/home/users/user/a/test'),
             ('YOLO', '/home/users/user/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


#
# Main
#


# Generated at 2022-06-21 21:29:02.235928
# Unit test for function expand
def test_expand():
    assert expand('~/test') == '/home/user/test'



# Generated at 2022-06-21 21:29:04.918522
# Unit test for function expand
def test_expand():
    res = expand('$HOME/test')
    assert os.path.isdir(res)
    res = expand('~/test')
    assert os.path.isdir(res)



# Generated at 2022-06-21 21:29:07.171186
# Unit test for function expand
def test_expand():
    assert expand('~/test') == '.../test'



# Generated at 2022-06-21 21:29:16.076672
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert list(values) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

# Generated at 2022-06-21 21:29:26.009515
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["FOO=BAR"])) == [("FOO", "BAR")]
    assert list(parse_env_file_contents(["FOO=BAR"])) == [("FOO", "BAR")]
    assert list(parse_env_file_contents(["FOO=BAR", "BAR=FOO"])) == [("FOO", "BAR"), ("BAR", "FOO")]
    assert list(parse_env_file_contents(["FOO=BAR=BAR"])) == [("FOO", "BAR=BAR")]

    assert list(parse_env_file_contents(["FOO='BAR'"])) == [("FOO", "BAR")]

# Generated at 2022-06-21 21:29:27.280058
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:29:31.343681
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:29:38.310573
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../yeee'),
                                                                                  ('THISIS', '.../a/test'),
                                                                                  ('YOLO',
                                                                                   '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:29:42.006708
# Unit test for function load_env_file
def test_load_env_file():
    with io.StringIO() as fd:
        writer = csv.DictWriter(fd, fieldnames=['k', 'v'])

        changes = load_env_file(['TEST=ha', 'TEST2=hue', 'TEST3=hee'])
        writer.writeheader()
        writer.writerows([{'k': k, 'v': v} for k, v in changes.items()])
        # print(fd.getvalue())


if __name__ == '__main__':
    test_load_env_file()