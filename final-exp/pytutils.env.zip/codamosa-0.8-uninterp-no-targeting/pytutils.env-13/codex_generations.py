

# Generated at 2022-06-21 21:23:31.104452
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:23:35.521545
# Unit test for function expand
def test_expand():
    assert expand('~/test_example') == os.path.expanduser('~/test_example')
    assert expand('$HOME/test_example') == os.path.expanduser('~/test_example')
    assert expand('${HOME}/test_example') == os.path.expanduser('~/test_example')



# Generated at 2022-06-21 21:23:42.916428
# Unit test for function load_env_file
def test_load_env_file():
    f = open(
        os.path.join(
            os.path.dirname(__file__),
            "files",
            "dotenv_file"
        )
    )
    content = f.readlines()
    f.close()
    content = [x.strip() for x in content]
    expected = {
        'TEST': 'hello-world',
        'NUMBER': '100',
        'SOME': 'value',
        'PATH': '${HOME}'
    }
    result = load_env_file(content, write_environ=None)
    assert expected == result



# Generated at 2022-06-21 21:23:50.973048
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    values = parse_env_file_contents(lines)

    for k, v in values:
        if k == 'TEST':
            assert 'yeee' in expand(v)
        elif k == 'THISIS':
            assert os.path.expanduser(v) == expand(v)
        elif k == 'YOLO':
            assert os.path.expanduser(v) != expand(v)



# Generated at 2022-06-21 21:24:01.567190
# Unit test for function expand
def test_expand():
    assert expand("$HOME/hi") == os.path.expanduser("$HOME/hi")
    assert expand("~/hi") == os.path.expanduser("~/hi")
    assert expand("${HOME}/hi") == os.path.expanduser("${HOME}/hi")
    assert expand("\"~/hi\"") == os.path.expanduser("~/hi")
    assert expand("'~/hi'") == os.path.expanduser("~/hi")
    assert expand("\"$HOME/hi\"") == os.path.expanduser("$HOME/hi")
    assert expand("'$HOME/hi'") == os.path.expanduser("$HOME/hi")

# Generated at 2022-06-21 21:24:06.652585
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.environ["HOME"]
    assert expand("${HOME}") == os.environ["HOME"]
    assert expand("~/test") == os.path.join(os.environ["HOME"], "test")
    assert expand("~") == os.environ["HOME"]
    assert expand("~/") == os.environ["HOME"] + '/'



# Generated at 2022-06-21 21:24:08.234581
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:24:16.614185
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import textwrap

    lines = textwrap.dedent('''
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        MORE=~/"foo/${HOME}""
    ''').strip().splitlines()

    env = parse_env_file_contents(lines)
    expected = [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'), ('MORE', '~/"foo/${HOME}""')]
    assert list(env) == expected



# Generated at 2022-06-21 21:24:18.428602
# Unit test for function expand
def test_expand():
    # Verify that relative paths get expanded properly
    # Verify that user home gets expanded properly
    pass



# Generated at 2022-06-21 21:24:25.869944
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "test_value"
    assert expand("${TEST}") == "test_value"

    os.environ["TEST"] = "test_value"
    assert expand("$TEST") == "test_value"

    assert expand("/home/") == "/home/"

    assert expand("/home/${TEST}") == "/home/test_value"
    assert expand("/home/$TEST") == "/home/test_value"



# Generated at 2022-06-21 21:24:38.092116
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # pylint: disable=redefined-outer-name
    import os
    import tempfile

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [('TEST', os.path.join(os.path.expanduser('~'), 'yeee')),
                ('THISIS', os.path.join(os.path.expanduser('~'), 'a/test')),
                ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]


# Generated at 2022-06-21 21:24:48.990652
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()

    load_env_file(lines, write_environ)

    assert write_environ['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-') + os.environ['PATH']
    assert write_environ['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-21 21:24:58.871468
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {
        'TEST': expand('${HOME}/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-21 21:25:02.635090
# Unit test for function expand
def test_expand():
    expected = os.path.expanduser("~")
    actual = expand("~")
    assert actual == expected


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 21:25:12.123094
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    import sys

    print(load_env_file(lines, write_environ=sys.modules['__main__'].__dict__))
    assert 'TEST' in sys.modules['__main__'].__dict__
    assert 'THISIS' in sys.modules['__main__'].__dict__
    assert 'YOLO' in sys.modules['__main__'].__dict__



# Generated at 2022-06-21 21:25:17.004851
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=dict()) == collections.OrderedDict([('TEST', os.environ['HOME'] + '/yeee-' + os.environ['PATH']), ('THISIS', os.environ['HOME'] + '/a/test'), ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-21 21:25:21.379677
# Unit test for function expand
def test_expand():
    assert expand('~/a/test') == os.path.expanduser('~/a/test')
    assert expand('$HOME/a/test') == os.path.expanduser(os.path.expandvars('$HOME/a/test'))



# Generated at 2022-06-21 21:25:33.143636
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee','THISIS=~/a/test','YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert env == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    lines = ['TEST=${HOME}/yeee-$PATH','THISIS=~/a/test','YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_

# Generated at 2022-06-21 21:25:37.533006
# Unit test for function load_env_file
def test_load_env_file():
    """Unit test for function load_env_file."""
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == collections.OrderedDict([('TEST', expand('${HOME}/yeee-$PATH')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

# Generated at 2022-06-21 21:25:45.680263
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                                     ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:25:53.262540
# Unit test for function expand
def test_expand():
    tests = [
        ('foo', 'foo'),
        ('/a/b/c', '/a/b/c'),
        ('${HOME}/x', expand('${HOME}/x')),
        ('~/x', expand('~/x')),
        ]

    for val, expected_result in tests:
        result = expand(val)
        if result != expected_result:
            print('Failed to expand {} to {}. Result was {} instead.'.format(val, expected_result, result))



# Generated at 2022-06-21 21:25:58.184999
# Unit test for function load_env_file
def test_load_env_file():
    env_file_path = os.path.join(os.path.dirname(__file__), "test.env")
    with open(env_file_path) as env_file:
        load_env_file(env_file, write_environ=dict())

# Generated at 2022-06-21 21:26:04.061333
# Unit test for function expand
def test_expand():
    assert expand("") == ""

    assert expand("$HOME") == expand("${HOME}") == os.environ["HOME"]
    assert expand("$PATH") == expand("${PATH}") == os.environ["PATH"]
    assert expand("$USER") == expand("${USER}") == os.environ["USER"]



# Generated at 2022-06-21 21:26:14.382609
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
                 ('THISIS', '.../a/test'),
                 ('YOLO',
                 '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-21 21:26:23.096692
# Unit test for function expand
def test_expand():
    assert expand('foo') == 'foo'
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/foo') == os.path.expanduser('~/foo')
    assert expand('~foo/') == os.path.expanduser('~foo/')
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('${HOME}/foo') == os.path.join(os.environ['HOME'], 'foo')
    assert expand('$HOME/foo') == os.path.join(os.environ['HOME'], 'foo')



# Generated at 2022-06-21 21:26:35.122421
# Unit test for function expand
def test_expand():
    d = '/home/vagrant/Desktop'

    t1 = '$HOME/Desktop'
    t2 = '$/home/vagrant/Desktop'
    t3 = '~/Desktop'
    t4 = '~/test'
    t5 = '~/test/test'
    t6 = '~/test/test/test'
    t7 = '~/test/test/test/test'
    t8 = '~/test/test/test/test/test'

    assert expand(t1) == os.path.join(d, 'Desktop')
    assert expand(t2) == os.path.join(d, 'Desktop')
    assert expand(t3) == os.path.join(d, 'Desktop')
    assert expand(t4) == os.path.join(d, 'test')
   

# Generated at 2022-06-21 21:26:45.717445
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    load_env_file(lines, write_environ=os.environ)

    assert os.environ['TEST'] == f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'
    assert os.environ['THISIS'] == f'{os.environ["HOME"]}/a/test'

# Generated at 2022-06-21 21:26:51.610656
# Unit test for function expand
def test_expand():
    env = {'HOME': '/home/nico'}
    assert expand(r'$HOME/toto') == r'/home/nico/toto'
    assert expand(r'~/toto') == r'/home/nico/toto'

    with pytest.raises(ValueError):
        os.environ['HOME'] = None  # type: ignore
        expand(r'~')


# Unit test of function load_env_file

# Generated at 2022-06-21 21:26:52.426160
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:27:01.538016
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = ('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    actual = parse_env_file_contents(lines)

    assert actual == expected



# Generated at 2022-06-21 21:27:06.254239
# Unit test for function expand
def test_expand():
    assert expand("$HOME/test") == os.path.join(os.path.expanduser("~"), "test")



# Generated at 2022-06-21 21:27:14.372804
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('$HOME/') == os.path.expandvars('$HOME/')
    assert expand('$ONE/foo/..') == os.path.expandvars('$ONE/foo/..')
    assert expand('~/foo/bar') == os.path.expanduser('~/foo/bar')
    assert expand('$HOME/.zshrc') == os.path.expandvars('$HOME/.zshrc')
    assert expand('${PWD}') == os.path.expandvars('${PWD}')

    assert expand('~/foo/bar') == os.path.expanduser('~/foo/bar')

# Generated at 2022-06-21 21:27:16.666902
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-21 21:27:25.010184
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test/bla') == os.path.join(os.environ['HOME'], 'test/bla')
    assert expand('~/test/bla') == os.path.join(os.environ['HOME'], 'test/bla')
    assert expand('${HOME}/test/bla') == os.path.join(os.environ['HOME'], 'test/bla')
    assert expand('~username/test/bla') == os.path.join('~username', 'test/bla')



# Generated at 2022-06-21 21:27:29.504469
# Unit test for function load_env_file
def test_load_env_file():  # noqa
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = load_env_file(lines)
    print('Out =', out)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:27:38.096693
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    keys, values = list(zip(*parse_env_file_contents(lines)))

    assert list(keys) == ["TEST", "THISIS", "YOLO"]
    assert list(values) == [
        "${HOME}/yeee",
        "~/a/test",
        "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]



# Generated at 2022-06-21 21:27:45.123970
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert set(values) == {('TEST', os.path.expanduser('~/yeee-{}'.format(os.environ['PATH']))), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))}

# Generated at 2022-06-21 21:27:53.896337
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("~") == os.path.expanduser("~")
    assert expand("$HOME/a") == os.path.expanduser("~") + "/a"
    assert expand("~/a") == os.path.expanduser("~") + "/a"
    assert expand("${HOME}") == os.path.expanduser("~")
    assert expand("~/a/b") == os.path.expanduser("~") + "/a/b"
    assert expand("${HOME}/a") == os.path.expanduser("~") + "/a"

# Generated at 2022-06-21 21:28:00.034699
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([])) == []
    assert list(parse_env_file_contents([
        'YOLO=swag',
        'YOLO=swag2',
    ])) == [
        ('YOLO', 'swag2'),
    ]
    assert list(parse_env_file_contents([
        'YOLO=swag',
    ])) == [
        ('YOLO', 'swag'),
    ]

# Generated at 2022-06-21 21:28:12.051399
# Unit test for function parse_env_file_contents

# Generated at 2022-06-21 21:28:26.008767
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert '~' not in changes['TEST']
    assert '~' not in changes['THISIS']
    assert changes['TEST'].endswith('yeee-')
    assert changes['TEST'].startswith(changes['HOME'])
    assert changes['THISIS'] == os.path.expanduser('~/a/test')

# Generated at 2022-06-21 21:28:35.512699
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    # Test windows
    if os.name == 'nt':
        lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        load_env_file(lines, write_environ=dict())

    # Test linux
    else:
        lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:28:36.315375
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:28:46.571192
# Unit test for function expand
def test_expand():
    """
    >>> env = os.environ
    >>> env['TEST'] = 'test'
    >>> env['HOME'] = os.path.expanduser("~")
    >>> tmp_dir = tempfile.mkdtemp()
    >>> os.chdir(tmp_dir)
    >>> assert expand("~/tmp/test") == "{}/tmp/test".format(env['HOME'])
    >>> assert expand("${HOME}/tmp/test") == "{}/tmp/test".format(env['HOME'])
    >>> assert expand("${TEST}") == "test"
    >>> assert expand("abc/abc") == "abc/abc"
    >>> assert expand("abc/abc/") == "abc/abc/"
    """

# Generated at 2022-06-21 21:28:53.788727
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    if 'TEST' in result:
        home_path = result['TEST'].split('/yeee-')[0]
        path = result['TEST'].split('/yeee-')[1]

    assert home_path[:-1] == os.path.expanduser('~')
    assert home_path[-1] == '.' or home_path[-1] == '/'

    test_paths = os.environ['PATH'].split(':')
    assert path in test

# Generated at 2022-06-21 21:29:03.874147
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=$HOME/yeee',  # Value from environment variable
        'THISIS=~/a/test',  # Value from tilde-expansion
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'  # Value with non-existent environment variable
    ]
    expected = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-21 21:29:15.539926
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=1)

# Generated at 2022-06-21 21:29:21.316541
# Unit test for function expand
def test_expand():
    os.environ["yolo"] = "swag"
    assert expand("$yolo") == "swag"


if __name__ == '__main__':

    test_expand()

    if len(sys.argv) < 2:
        print("Usage: %s <env_file>" % sys.argv[0])
        sys.exit(-1)

    env_filename = sys.argv[1]

    with open(env_filename) as f:
        lines = f.read().strip().split('\n')

    load_env_file(lines)

# Generated at 2022-06-21 21:29:33.148889
# Unit test for function expand
def test_expand():
    # Test case 1
    # This test case will try to test if the expand function
    # can correctly expand a PATH variable
    # We have to make sure the variable is correctly expanded
    # because we will use it to check if our function
    # can correctly expand a variable with another variable's
    # key inside its value
    try:
        assert '.' == expand('$PWD')
    except:
        raise AssertionError(
            'The expand function cannot correctly expand a PATH variable.')

    # Test case 2
    # This test case will try to test if the expand function
    # can correctly expand a HOME variable
    # We have to make sure the variable is correctly expanded
    # because we will use it to check if our function
    # can correctly expand a variable with another variable's
    # key inside its value

# Generated at 2022-06-21 21:29:35.162561
# Unit test for function expand
def test_expand():
    assert expand(r"$HOME") == os.path.expanduser(os.environ['HOME'])



# Generated at 2022-06-21 21:29:46.463132
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:29:49.275471
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(['TEST=$PATH', 'TEST2=$TEST'])

# Generated at 2022-06-21 21:29:54.717372
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:30:02.260439
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:30:12.395900
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    lines = list(parse_env_file_contents(lines))

    home = os.environ.get("HOME")
    path = os.environ.get("PATH")

    assert lines[0][0] == "TEST"
    assert lines[0][1] == "%s/yeee-%s" % (home, path)

    assert lines[1][0] == "THISIS"
    assert lines[1][1] == "%s/a/test" % (home,)

    assert lines[2][0] == "YOLO"

# Generated at 2022-06-21 21:30:14.270784
# Unit test for function expand
def test_expand():
    assert expand('~/a/b') == os.path.expandvars(os.path.expanduser('~/a/b'))



# Generated at 2022-06-21 21:30:16.972332
# Unit test for function expand
def test_expand():
    assert expand("./test") == os.path.abspath("./test")
    assert expand("~") == os.environ["HOME"]



# Generated at 2022-06-21 21:30:22.281940
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


file_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))



# Generated at 2022-06-21 21:30:34.895986
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_file_lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    result = parse_env_file_contents(lines=test_file_lines)

    results_map = dict(result)

    assert results_map['TEST'] == expand(test_file_lines[0].split('=')[1])
    assert results_map['THISIS'] == expand(test_file_lines[1].split('=')[1])
    assert results_map['YOLO'] == expand(test_file_lines[2].split('=')[1])



# Generated at 2022-06-21 21:30:46.392595
# Unit test for function load_env_file
def test_load_env_file():
    s = '''
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''

    d = load_env_file(s.split())

    assert d['TEST'] == os.path.expanduser(os.path.expandvars('${HOME}/yeee-$PATH'))
    assert d['THISIS'] == os.path.expanduser(os.path.expandvars('~/a/test'))
    assert d['YOLO'] == os.path.expanduser(os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

# Generated at 2022-06-21 21:31:11.810496
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())
    assert changes['TEST'].find("yeee") >= 0
    assert changes['TEST'].find("yeee") >= 0
    assert changes['THISIS'].find("test") >= 0
    assert changes['YOLO'].find("swaggins") >= 0
    assert '${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}' in changes['YOLO']



# Generated at 2022-06-21 21:31:14.994165
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee') == os.path.expandvars('$HOME/yeee')
    assert expand('~/yeee') == os.path.expandvars('~/yeee')



# Generated at 2022-06-21 21:31:25.607278
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import unittest
    import unittest.mock
    from pprint import pprint

    class TestLoadEnvFile(unittest.TestCase):
        @unittest.mock.patch.dict(os.environ, clear=True)
        def test_load_env_file(self):
            os.environ["HOME"] = "home"
            os.environ["PATH"] = "path"

            lines = io.StringIO("""
            TEST=${HOME}/yeee-$PATH
            THISIS=~/a/test
            YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
            """)

            changes = load_env_file(lines)

            pprint(list(changes.items()))


# Generated at 2022-06-21 21:31:34.414612
# Unit test for function expand
def test_expand():
    """
    Unit test for function expand.
    """
    assert expand('~/test/test') == os.path.expanduser('~/test/test')
    assert expand('~') == os.path.expanduser('~')
    assert expand('$/test/test') == os.path.expandvars('$/test/test')
    assert expand('$/test/test') == os.path.expandvars('$/test/test')
    assert expand('~/test/${HOME}') == os.path.expanduser('~/test/') + os.path.expanduser(' ${HOME}')


if __name__ == '__main__':
    test_expand()

# Generated at 2022-06-21 21:31:45.201187
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.expanduser(os.path.expandvars('$HOME/.vig.test.env'))
    if os.path.isfile(filename):
        os.remove(filename)
    file = open(filename, "w+")
    file.write("TEST=$HOME/yeee")
    file.write("\n")
    file.close()

    environ = dict()
    assert load_env_file(filename, write_environ=environ) == {'TEST': '.../yeee'}
    assert environ == {'TEST': '.../yeee'}

    os.remove(filename)



# Generated at 2022-06-21 21:31:46.178009
# Unit test for function load_env_file
def test_load_env_file():
    pass



# Generated at 2022-06-21 21:31:51.194896
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    with open(__file__) as fp:
        lines = [line for line in fp.readlines() if line[0] != '#']

    with open(__file__) as fp:
        lines_ = parse_env_file_contents(fp)

        for line, line_ in zip(lines, lines_):
            assert line.strip() == "=".join(line_)



# Generated at 2022-06-21 21:32:02.299674
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == {'TEST': f'{os.environ["HOME"]}/yeee',
                                                           'THISIS': f'{os.environ["HOME"]}/a/test',
                                                           'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:32:13.302832
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [
            ('TEST', f'{os.path.expanduser("~")}/yeee-{os.environ["PATH"]}'),
            ('THISIS', f'{os.path.expanduser("~")}/a/test'),
            ('YOLO', f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ]
    )




# Generated at 2022-06-21 21:32:18.015762
# Unit test for function expand
def test_expand():
    assert expand("~/a") == os.path.expanduser("~/a")
    assert expand("$HOME/a") == os.path.expanduser("~/a")
    assert expand("$HOME/$HOME") == os.path.expanduser("~/~")



# Generated at 2022-06-21 21:32:58.498132
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """ Tests parse_env_file_contents """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', expand('${HOME}/yeee')),
                                                    ('THISIS', expand('~/a/test')),
                                                    ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]



# Generated at 2022-06-21 21:33:01.074490
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:33:09.872824
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    inh = io.StringIO(
        'THIS=./that\n'
        'THAT=~/the/other\n'
        'OTHER=the/other/$PATH\n'
        'PATH=/this/that'
    )

    results = list(parse_env_file_contents(inh.readlines()))

    expected = [('THIS', './that'),
                ('THAT', '~/the/other'),
                ('OTHER', 'the/other/$PATH'),
                ('PATH', '/this/that')]

    assert results == expected



# Generated at 2022-06-21 21:33:17.305209
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "foo"
    assert expand("$TEST") == "foo"
    im = os.path.expanduser("~")
    assert expand("~") == im
    os.environ["TEST"] = "foo"
    assert expand("$TEST") == "foo"
    os.environ["TEST"] = "foo"
    assert expand("~/$TEST") == im + "/foo"



# Generated at 2022-06-21 21:33:22.765747
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=dict())
    print(results)


if __name__ == '__main__':
    test_load_env_file()