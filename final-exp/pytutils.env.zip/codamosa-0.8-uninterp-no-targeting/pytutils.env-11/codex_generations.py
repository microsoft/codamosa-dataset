

# Generated at 2022-06-21 21:23:35.342118
# Unit test for function load_env_file
def test_load_env_file():
    my_environ = collections.OrderedDict()

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = load_env_file(lines, write_environ=my_environ)

    assert isinstance(values, collections.OrderedDict)

    assert isinstance(values, collections.OrderedDict)
    assert len(values) == 3

    assert 'TEST' in values
    assert values['TEST'] == os.path.expandvars('${HOME}/yeee-$PATH')

    assert 'THISIS' in values

# Generated at 2022-06-21 21:23:44.479756
# Unit test for function expand
def test_expand():
    assert expand('/home/user/.bashrc') == '/home/user/.bashrc'
    assert expand('/home/$USER/.bashrc') == '/home/user/.bashrc'
    assert expand('/home/$USER/.bashrc') == '/home/user/.bashrc'
    assert expand('/home/$USER/.$USER') == '/home/user/.user'
    assert expand('/home/$USER/.${USER}') == '/home/user/.user'
    assert expand('/home/$USER/.bashrc') == '/home/user/.bashrc'
    assert expand('/home/$USER/.$USER') == '/home/user/.user'
    assert expand('/home/$USER/.${USER}') == '/home/user/.user'

# Generated at 2022-06-21 21:23:52.448615
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines)
    print(environ)
    assert environ == {'TEST': '.../.../yeee-...:...',
                       'THISIS': '.../a/test',
                       'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    # Test that env is populated too
    assert os.environ['TEST'] == '.../.../yeee-...:...'



# Generated at 2022-06-21 21:23:58.116867
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    from pprint import pformat

    print(pformat(changes))

    assert not (os.getenv('TEST') is None)
    assert not (os.getenv('THISIS') is None)
    assert not (os.getenv('YOLO') is None)

    assert changes['TEST'] == os.path.join(os.getenv('HOME'), 'yeee-', os.getenv('PATH'))
    assert changes['THISIS'] == '~/a/test'

# Generated at 2022-06-21 21:24:01.769999
# Unit test for function load_env_file
def test_load_env_file():
    lines = ('TEST=$HOME/yeee-$PATH\n', 'THISIS=~/a/test\n', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')

    # Parse, but don't write to os.environ
    environ = load_env_file(lines)

    assert os.environ['HOME'] in environ['TEST']
    assert environ['THISIS'].startswith('~/a/test')
    assert '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in environ['YOLO']



# Generated at 2022-06-21 21:24:14.148198
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', '{}/yeee'.format(os.environ.get('HOME'))),
        ('THISIS', '{}/a/test'.format(os.environ.get('HOME'))),
        ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ.get('HOME')))
    ])

# Generated at 2022-06-21 21:24:22.686866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'),
                                                    ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:24:23.732797
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:24:31.514376
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write(
            "TEST=$HOME/yeee-$PATH\n"
            "THISIS=~/a/test\n"
            "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n"
        )
        f.flush()

        content = f.read()
        load_env_file(content)



# Generated at 2022-06-21 21:24:34.056402
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')
    assert expand('$$') == os.path.expandvars('$$')



# Generated at 2022-06-21 21:24:42.680573
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input_data = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output_data = parse_env_file_contents(input_data)

    output_list = list(output_data)

    assert output_list == [('TEST', '~/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:24:47.141624
# Unit test for function expand
def test_expand():
    import os

    print(os.environ)

    # This seems to refer to Python's root dir
    print(os.getenv('PYTHON_PREFIX'))

    # This is ./__main__.py's dir
    print(os.getenv('__file__'))

    print(os.path.dirname(__file__))

# Generated at 2022-06-21 21:24:48.357999
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([]) is not None



# Generated at 2022-06-21 21:25:00.812207
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    # Write out a file
    with tempfile.NamedTemporaryFile(mode='w') as f:
        print("In a hole in the ground there lived a hobbit.", file=f)
        print("Not a nasty, dirty, wet hole, filled with the ends of worms and an oozy smell, nor yet a dry, bare, sandy hole with nothing in it to sit down on or to eat: it was a hobbit-hole, and that means comfort.", file=f)
        print("\n")
        print("It had a perfectly round door like a porthole, painted green, with a shiny yellow brass knob in the exact middle.", file=f)

# Generated at 2022-06-21 21:25:09.817239
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    contents = list(parse_env_file_contents(lines))

    assert contents == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:25:21.480885
# Unit test for function load_env_file

# Generated at 2022-06-21 21:25:33.247030
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def parse(lines):
        return load_env_file(lines, dict())

    assert parse(['A=B', '']) == {'A': 'B'}
    assert parse(['A=B', 'B=C']) == {'A': 'B', 'B': 'C'}

    assert parse(['A=', 'B=C']) == {'A': '', 'B': 'C'}
    assert parse(['A=B', 'B=C', '   ']) == {'A': 'B', 'B': 'C'}
    assert parse(['A=B', 'B=C', '   ']) == {'A': 'B', 'B': 'C'}


# Generated at 2022-06-21 21:25:45.374394
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_result = collections.OrderedDict(
        [
            ('TEST', os.path.expanduser('~/yeee-') + os.path.pathsep.join(os.environ['PATH'].split(os.path.pathsep))),
            ('THISIS', os.path.expanduser('~/a/test')),
            ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
        ]
    )
    assert load_env_

# Generated at 2022-06-21 21:25:47.290911
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


__all__ = ['load_env_file']

# Generated at 2022-06-21 21:25:51.395183
# Unit test for function expand
def test_expand():
    assert expand('') == ''
    assert expand('a') == 'a'
    assert expand('a/b') == 'a/b'
    assert expand('/tmp') == '/tmp'
    assert expand('${HOME}') == expand('~')
    assert expand('${PATH}') == expand('~')

# Generated at 2022-06-21 21:26:07.819806
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    actual = parse_env_file_contents(lines)

    expected = [('TEST', f'{os.path.expanduser("~")}/yeee'),
                ('THISIS', f'{os.path.expanduser("~")}/a/test'),
                ('YOLO', f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
                ]

    pytest.helpers.assert_generator_equals(actual, expected)


#

# Generated at 2022-06-21 21:26:10.993283
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:26:21.294100
# Unit test for function load_env_file
def test_load_env_file():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        f.close()

        changes = load_env_file(lines=[], write_environ=dict())
        assert not changes

        changes = load_env_file(lines=None, write_environ=dict())
        assert not changes

        lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
        changes = load_env

# Generated at 2022-06-21 21:26:27.517927
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins']) == \
        collections.OrderedDict([('TEST', '.../yeee-...:...'),
                                 ('THISIS', '.../a/test'),
                                 ('YOLO', '.../swaggins')])


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:26:33.021013
# Unit test for function expand
def test_expand():
    val = expand("~/")
    assert val == expand("$HOME/")

    val = expand("$HOME/")
    assert val == expand("~/")

    val = expand("$HOME/")
    assert val == expand("${HOME}/")

    val = expand("${HOME}/")
    assert val == expand("$HOME/")

    val = expand("${HOME}/")
    assert val == expand("~/")

    val = expand("$PWD/")
    assert val == expand("${PWD}/")

    val = expand("$PWD/")
    assert val == expand("$PWD/$PWD/")



# Generated at 2022-06-21 21:26:41.237665
# Unit test for function expand
def test_expand():
    os.environ["PATH"] = "/bin/:/usr/bin/"
    os.environ["WORK"] = "~/work"
    assert expand("$PATH/grep") == "/bin/:/usr/bin//grep"
    assert expand("${PATH}/grep") == "/bin/:/usr/bin//grep"
    assert expand("$WORK/grep") == "~/work/grep"
    assert expand("${WORK}/grep") == "~/work/grep"
    assert expand("~$USER/work/grep") == "~/work/grep"
    assert expand("~/work/grep") == os.path.expanduser("~/work/grep")



# Generated at 2022-06-21 21:26:52.312864
# Unit test for function expand
def test_expand():
    env = dict(
        HOME='~',
        TEST='${HOME}/yeee-$PATH',
        THISIS='~/a/test',
        YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        PATH=':..'
    )

    path_was = os.environ.get('PATH')

    os.environ.update(env)


# Generated at 2022-06-21 21:26:54.914649
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 21:27:06.038830
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = list(parse_env_file_contents(lines))
    assert contents == [('TEST', f'{os.environ["HOME"]}/yeee'), ('THISIS', f'{os.environ["HOME"]}/a/test'), ('YOLO', f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')], 'parse_env_file_contents() failed to parse all environment variables'


# Generated at 2022-06-21 21:27:11.422336
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.join(os.path.expanduser('~'), 'test')

    if 'test_os_environ_key' in os.environ:
        assert expand('${test_os_environ_key}') == os.environ['test_os_environ_key']
        assert expand('$test_os_environ_key') == os.environ['test_os_environ_key']



# Generated at 2022-06-21 21:27:17.278441
# Unit test for function expand
def test_expand():
    assert expand('$HOME') != '$HOME'
    assert expand('~/test') != '~/test'



# Generated at 2022-06-21 21:27:27.738076
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())
    assert changes['TEST'] == os.environ['HOME'] + '/yeee'
    assert changes['THISIS'] == os.environ['HOME'] + '/a/test'
    assert changes['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Generated at 2022-06-21 21:27:31.777178
# Unit test for function expand
def test_expand():
    home = os.environ["HOME"]

    # It's necessary to use full env variable paths for the test
    # because we're expanding relative to the current environment

    def test_expand(val, expected):
        actual = expand(val)
        assert actual == expected, "%s != %s" % (actual, expected)

    test_expand("~", home)
    test_expand("${HOME}", home)
    test_expand("${bar}", "${bar}")

# Generated at 2022-06-21 21:27:34.304294
# Unit test for function expand
def test_expand():
    assert expand('./$HOME/a') == os.path.abspath(os.path.expanduser('./$HOME/a'))



# Generated at 2022-06-21 21:27:42.865808
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import tempfile

    # Test that we can load into an ordered dict
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert isinstance(result, collections.OrderedDict)

    # Test that we can load into an environment
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-21 21:27:46.101334
# Unit test for function expand
def test_expand():
    v1 = '/home/aaa'
    v2 = '~' + v1[1:]

    assert (expand(v2) == v1)



# Generated at 2022-06-21 21:27:51.918765
# Unit test for function expand
def test_expand():
    os.environ["test"] = "test"
    assert expand("$test") == "test"
    assert expand("$test/test") == "test/test"
    assert expand("~/test") == os.path.expanduser("~/test")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:27:59.217893
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import itertools

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = collections.OrderedDict()
    for k, v in itertools.islice(parse_env_file_contents(lines), None):
        result[k] = v

    assert result['TEST'] == f'{os.environ["HOME"]}/yeee' and result['THISIS'] == f'{os.environ["HOME"]}/a/test' and result['YOLO'] is not None



# Generated at 2022-06-21 21:28:11.070282
# Unit test for function expand
def test_expand():
    from pathlib import Path
    from os import pathsep

    os.environ["PYTHONPATH"] = ":".join([str(Path(__file__).parent.absolute()), "/home/vagrant/Python/PythonSurvey"])

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()
    load_env_file(lines, write_environ)

    assert "TEST" in write_environ
    assert write_environ["TEST"] == f"{os.environ['HOME']}/yeee-{os.environ['PYTHONPATH']}"


# Generated at 2022-06-21 21:28:15.688982
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "testing"
    assert expand("$TEST'123") == os.path.expandvars("$TEST'123")
    assert expand('"$TEST"123') == os.path.expandvars('"$TEST"123')
    assert expand('"$TEST"123') == os.path.expandvars('"$TEST"123')



# Generated at 2022-06-21 21:28:28.611592
# Unit test for function expand
def test_expand():
    assert '~' in expand("~/")
    assert '~' not in expand("$HOME/")
    assert '~' in expand("${HOME}")
    assert '~' not in expand("$HOME")
    assert os.path.expandvars("$HOME") in expand("${HOME}")
    assert os.path.expandvars("$HOME") not in expand("$HOME")
    assert '$HOME' in expand("$HOME")



# Generated at 2022-06-21 21:28:30.203451
# Unit test for function expand
def test_expand():
    assert expand('~/.local/bin') == expand('${HOME}/.local/bin')



# Generated at 2022-06-21 21:28:33.991130
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    result = ["TEST", "HOME"]

    lines = ['TEST=${HOME}/yeee']

    for k, v in parse_env_file_contents(lines):
        assert k in result



# Generated at 2022-06-21 21:28:40.368628
# Unit test for function expand
def test_expand():
    # Check if user's home directory is correctly expanded
    assert expand("~") == os.path.expanduser("~")

    # Check if environment variables are correctly expanded
    assert expand("${HOME}") == os.environ["HOME"]

    # Check if environment variables and user's home directory are correctly
    # expanded
    assert (
        expand("${HOME}/test1 ~ /test2")
        == os.environ["HOME"] + "/test1" + os.path.expanduser("~") + "/test2"
    )



# Generated at 2022-06-21 21:28:50.700019
# Unit test for function load_env_file
def test_load_env_file():
    writes = dict()

    assert load_env_file([]).keys() == tuple()
    assert load_env_file([], write_environ=writes).keys() == tuple()
    assert len(writes) == 0

    assert load_env_file(['A=b', 'C=d']).items() == (('A', 'b'), ('C', 'd'))
    assert load_env_file(['A=b', 'C=d'], write_environ=writes).items() == (('A', 'b'), ('C', 'd'))
    assert len(writes) == 2

    assert load_env_file(['A=b', 'C=d', 'E=f']).items() == (('A', 'b'), ('C', 'd'), ('E', 'f'))
    assert load_

# Generated at 2022-06-21 21:29:02.530858
# Unit test for function load_env_file
def test_load_env_file():
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(contents, write_environ=dict())
    assert environ['TEST'] == os.path.expanduser('~') + '/yeee'
    assert environ['THISIS'] == os.path.expanduser('~') + '/a/test'
    assert environ['YOLO'] == os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    # print(environ)


if __name__ == '__main__':
    test_load

# Generated at 2022-06-21 21:29:09.504516
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pprint import pprint

    lines = '''
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''.splitlines()

    results = list(parse_env_file_contents(lines))
    pprint(results)
    assert len(results) == 3



# Generated at 2022-06-21 21:29:19.851372
# Unit test for function load_env_file
def test_load_env_file():
    import unittest.mock as mock

    with mock.patch.object(os.path, "expandvars", lambda path: path.replace("$", "...")):
        with mock.patch.object(os.path, "expanduser", lambda path: path.replace("~", "...")):
            test_environ = {"HOME": "/home/test", "PATH": "..."}
            test_input = ["FOO=bar", "BAR=baz", "TEST=$HOME/yeee-$PATH", "THISIS=~/a/test",
                          "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

            changes = load_env_file(test_input, test_environ)


# Generated at 2022-06-21 21:29:23.842842
# Unit test for function expand
def test_expand():
    assert os.path.abspath(os.path.join(os.getcwd(), '../')) == expand('$PWD/../')
    assert os.path.abspath(os.path.join(os.path.expanduser('~'), '../')) == expand('~/..')

# Generated at 2022-06-21 21:29:30.853740
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', os.path.join(os.path.expanduser('~'), 'yeee'))



# Generated at 2022-06-21 21:29:44.151757
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for load_env_file function.
    """
    filename = os.path.join(os.path.dirname(__file__), '.env')
    lines = open(filename)
    load_env_file(lines)

# Generated at 2022-06-21 21:29:51.194730
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${PATH}', 'THISIS=~/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', os.path.expandvars('${PATH}')), ('THISIS', os.path.expanduser('~/test')),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    actual = list(parse_env_file_contents(lines))
    assert expected == actual



# Generated at 2022-06-21 21:30:01.282886
# Unit test for function load_env_file
def test_load_env_file():
    import pathlib
    import tempfile

    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    with tempfile.TemporaryDirectory() as d:
        f = d + '/docker.env'
        open(f, 'w').write('\n'.join(lines))
        load_env_file([f], write_environ=os.environ)

        assert os.getenv('TEST') == pathlib.Path.home() / 'yeee-' + os.getenv('PATH')
        assert os.getenv('THISIS') == pathlib.Path.home() / 'a/test'
        assert os.getenv('YOLO') == pathlib

# Generated at 2022-06-21 21:30:09.419796
# Unit test for function expand
def test_expand():
    # Test function expand
    os.environ['MY_VAR'] = 'yeeeaaahh'
    assert expand(r'${MY_VAR}') == 'yeeeaaahh'
    assert expand(r'$HOME/test') == os.path.join(os.path.expanduser("~"), 'test')
    assert expand(r'~/test') == os.path.join(os.path.expanduser("~"), 'test')
    assert expand("~/test") == os.path.join(os.path.expanduser("~"), 'test')



# Generated at 2022-06-21 21:30:16.733493
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = load_env_file(lines, write_environ=dict())
    assert ret == collections.OrderedDict(
        [('TEST', '...' + os.sep + os.sep + 'yeee'),
         ('THISIS', '...' + os.sep + 'a' + os.sep + 'test'),
         ('YOLO', '...' + os.sep + 'swaggins' + os.sep + '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:30:25.088442
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines)

    assert 'TEST' in res
    assert 'THISIS' in res
    assert 'YOLO' in res
    assert res['TEST'].endswith('yeee')
    assert res['THISIS'].endswith('a/test')
    assert '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in res['YOLO']
    assert 'HOME' in res['YOLO']


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:30:36.956848
# Unit test for function expand
def test_expand():
    clear = os.environ.clear
    clear()
    os.environ["TEST"] = "1"
    os.environ["TEST2"] = "2"
    value = expand("$TEST")
    assert value == "1"

    value = expand("${TEST}")
    assert value == "1"

    value = expand("$TEST2")
    assert value == "2"

    value = expand("${TEST2}")
    assert value == "2"

    value = expand("${TEST2}-${TEST}")
    assert value == "2-1"

    value = expand("~")
    assert value.startswith("/")

    value = expand("~/")
    assert value.startswith("/")



# Generated at 2022-06-21 21:30:44.754056
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '$HOME/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-21 21:30:56.239579
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values1 = parse_env_file_contents(lines)

    values2 = parse_env_file_contents(lines)

    assert values1 == values2

    changes1 = load_env_file(lines, write_environ=dict())

    assert changes1['TEST'] == os.path.join(os.path.expanduser("~"), "yeee")

    assert changes1['THISIS'] == os.path.join(os.path.expanduser("~"), "a", "test")


# Generated at 2022-06-21 21:30:59.636788
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 21:31:17.914899
# Unit test for function expand
def test_expand():
    assert expand(r'$HOME') == os.environ['HOME']
    assert expand(r'~/') == os.environ['HOME']

# Generated at 2022-06-21 21:31:20.175372
# Unit test for function expand
def test_expand():
    print(expand('$HOME'))
    print(expand('~'))
    print(expand('$$'))



# Generated at 2022-06-21 21:31:24.317925
# Unit test for function expand
def test_expand():
    os.environ["TEST_VAR"] = "test"
    assert os.path.realpath(expand("~")) == os.path.realpath(os.path.expanduser("~"))
    assert expand("$TEST_VAR") == "test"



# Generated at 2022-06-21 21:31:26.612933
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:31:32.124709
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines)

    # The following must be manually checked
    print(changes)



# Generated at 2022-06-21 21:31:34.362247
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.environ.get('HOME', None)
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-21 21:31:40.674768
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("$HOME/test") == expand(os.path.expandvars("$HOME/test"))


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:31:50.160730
# Unit test for function load_env_file
def test_load_env_file():
    import subprocess

    try:

        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    def subprocess_output_test(test_input, expected_output, env=None):
        output = subprocess.check_output(
            [sys.executable, "-c", test_input],
            bufsize=1,
            env=env,
        )
        assert output == expected_output

    with tempfile.NamedTemporaryFile("w") as temp:
        temp.write("YOLO=this-is-a-test\n")
        temp.flush()

        subprocess_output_test("import os; print(os.environ[\"YOLO\"])", "this-is-a-test")


# Generated at 2022-06-21 21:31:51.657230
# Unit test for function expand
def test_expand():
    assert expand('$HOME') != '$HOME'



# Generated at 2022-06-21 21:31:55.044415
# Unit test for function expand
def test_expand():
    filepath = expand('~/test')
    filepath = expand('$HOME/test')
    assert True



# Generated at 2022-06-21 21:32:32.808874
# Unit test for function load_env_file
def test_load_env_file():
    # Load env file content

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    # Run tests
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:32:40.707476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # File with a single, simple value.
    assert parse_env_file_contents(['YOLO=SWAGGINS']) == [('YOLO', 'SWAGGINS')]

    # File with two values.
    lines = iter(['EXAMPLE1=VALUE1', 'EXAMPLE2=VALUE2'])
    assert parse_env_file_contents(lines) == [('EXAMPLE1', 'VALUE1'), ('EXAMPLE2', 'VALUE2')]

    # Value is a numeric, followed by a word.
    lines = iter(['EXAMPLE1=123foo'])
    assert parse_env_file_contents(lines) == [('EXAMPLE1', '123foo')]

    # Value is a numeric, followed by a word, separated by underscore.

# Generated at 2022-06-21 21:32:52.021058
# Unit test for function load_env_file
def test_load_env_file():
    environ = os.environ
    home = os.path.expanduser("~")
    path = environ["PATH"]

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=None)

    assert (home + "/yeee-" + path) == changes["TEST"]
    assert (home + "/a/test") == changes["THISIS"]
    assert (home + "/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST") == changes["YOLO"]


if __name__ == '__main__':
    test_load

# Generated at 2022-06-21 21:33:03.809534
# Unit test for function load_env_file
def test_load_env_file():
    test_string = """TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"""

    write_environ = dict()
    lines = test_string.split("\n")
    load_env_file(lines, write_environ)

    assert write_environ["HOME"]
    assert write_environ["PATH"]

    if "NONEXISTENT_VAR_THAT_DOES_NOT_EXIST" in os.environ:
        del os.environ["NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-21 21:33:09.969612
# Unit test for function expand
def test_expand():
    assert '.../.../test' == expand('~/../$USER/test')

    assert '~/swaggins/...' == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-21 21:33:21.434575
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    e = dict()
    load_env_file(lines, write_environ=e)

    # Check loaded env variables