

# Generated at 2022-06-21 21:23:29.951194
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    result = tuple(parse_env_file_contents(lines))
    assert result == (
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    )



# Generated at 2022-06-21 21:23:38.846098
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=None) == collections.OrderedDict(
        [('TEST', '.../.../yeee-...:...'),
         ('THISIS', '.../a/test'),
         ('YOLO',
          '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:23:48.528874
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    assert d['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee')
    assert d['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')
    assert d['YOLO'] == os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-21 21:23:58.085723
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():  # type: ignore
    """
    Unit test for function parse_env_file_contents
    """
    assert list(parse_env_file_contents(lines=('TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-21 21:24:00.965655
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('$HOME') == os.path.expandvars('$HOME')



# Generated at 2022-06-21 21:24:08.639288
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])

# Generated at 2022-06-21 21:24:16.848514
# Unit test for function expand
def test_expand():
    file_dir = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-21 21:24:28.653205
# Unit test for function expand
def test_expand():
    assert expand('/usr/share') == '/usr/share'
    assert expand('${HOME}/yeee-${PATH}') == os.path.expanduser('~/yeee-%s' % os.environ['PATH'])

    # Variable references (for now)
    assert expand('${HOME}/yeee-$PATH') == os.path.expanduser('~/yeee-%s' % os.environ['PATH'])

    # Tilde expansion
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('~/yeee') == os.path.expanduser('~/yeee')
    assert expand('~/yeee/') == os.path.expand

# Generated at 2022-06-21 21:24:36.141880
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-"$PATH"', 'THIS=IS~/a/test', 'yOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=None)
    assert changes == collections.OrderedDict(
        [("TEST", ".../yeee-..."), ("THIS", "IS~/a/test"), ("yOLO", ".../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")])

    # Test that changes are stored in write_environ
    environ_copy = {'HOME': '~', 'PATH': '...'}

# Generated at 2022-06-21 21:24:47.901677
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = """
# comment
TEST=$HOME/yeee
# another comment
THISIS=~/a/test
# yet another comment
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""

    lines = contents.splitlines()
    lines = filter(bool, lines)
    lines = (line.strip() for line in lines)
    result = list(parse_env_file_contents(lines))

    assert len(result) == 3
    assert result[0][0] == 'TEST'
    assert result[0][1] == os.path.expanduser('~/yeee')
    assert result[1][0] == 'THISIS'
    assert result[1][1] == os.path.expanduser('~/a/test')

# Generated at 2022-06-21 21:24:58.178834
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert {
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    } == load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:25:06.855184
# Unit test for function expand
def test_expand():
    # expands ~ -> /home/<user>
    assert expand('~') == os.path.expanduser('~')

    # expands environment variables -> /home/<user>
    assert expand('$XDG_DATA_HOME') == os.path.expandvars('$XDG_DATA_HOME')

    # expands ~ and environment variables -> /home/<user>
    assert expand('~$XDG_DATA_HOME') == os.path.expandvars(os.path.expanduser('~$XDG_DATA_HOME'))

    # '~' followed by character that is not '/' is not treated as user home
    assert expand('~a/test') == '~a/test'
    assert expand('~a') == '~a'

    # do not remove leading zeros

# Generated at 2022-06-21 21:25:18.630636
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)
    output = list(output)
    assert len(output) == 3, "Output has length 3"
    assert output[0][0] == "TEST", "Output key is TEST"
    assert re.search(r'\A[a-z]+[^\/]+/yeee\Z', output[0][1]), "Output value is in valid path format"
    assert output[1][0] == "THISIS", "Output key is THISIS"

# Generated at 2022-06-21 21:25:29.488831
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # pylint: disable=duplicate-code

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    expected = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    assert list(result) == expected


# Generated at 2022-06-21 21:25:30.537580
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:25:33.585051
# Unit test for function expand
def test_expand():
    assert expand('$PATH') == os.environ['PATH']
    assert expand('~/') == os.environ['HOME'] + '/'



# Generated at 2022-06-21 21:25:43.263659
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    out = dict(parse_env_file_contents(lines=contents))

    assert out['TEST'] == expand('${HOME}/yeee')
    assert out['THISIS'] == expand('~/a/test')
    assert out['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-21 21:25:45.546499
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 21:25:56.683324
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import os
    from unittest import mock

    lines = [
        'HOME=/home/travis',
        'PATH=/home/travis/.local/bin:/home/travis/miniconda3/bin:...',
    ]
    write_environ = dict()

    retval = load_env_file(lines, write_environ=write_environ)
    assert 'HOME' in retval
    assert 'PATH' in retval
    assert 'HOME' in write_environ
    assert 'PATH' in write_environ

    # Verify that environ is not written to if write_environ is None
    write_environ = None
    retval = load_env_file(lines, write_environ=write_environ)
    assert 'HOME' in retval
    assert 'PATH' in ret

# Generated at 2022-06-21 21:26:05.459893
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = load_env_file(lines)
    assert 'TEST' in output
    assert 'THISIS' in output
    assert 'YOLO' in output
    assert output['TEST'].endswith('/yeee')
    assert output['THISIS'].endswith('/a/test')

# Generated at 2022-06-21 21:26:14.611907
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'test'
    assert expand('$TEST') == 'test'
    assert expand('${TEST}') == 'test'

    # Check for potential regression for issue #54
    os.environ['TEST2'] = 'Hello:World'
    assert expand('$TEST2') == 'Hello:World'
    assert expand('${TEST2}') == 'Hello:World'



# Generated at 2022-06-21 21:26:16.358827
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    return doctest.testmod(verbose=True)[0] == 0

# Generated at 2022-06-21 21:26:26.712466
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(lines=['TEST=${HOME}/yeee']) == [('TEST', '.../yeee')]
    assert parse_env_file_contents(lines=['TEST=${HOME}/yeee-$PATH']) == [('TEST', "...")]
    assert parse_env_file_contents(lines=['TEST=\n']) == []

    assert parse_env_file_contents(lines=['TEST="${HOME}/yeee"']) == [('TEST', "...")]
    assert parse_env_file_contents(lines=['TEST=\'${HOME}/yeee\'']) == [('TEST', '.../yeee')]

# Generated at 2022-06-21 21:26:36.936853
# Unit test for function expand
def test_expand():
    def test_value(original_value, expected):
        assert expand(original_value) == expected

    test_value('$TEST_VAR/blah', '$TEST_VAR/blah')
    os.environ['TEST_VAR'] = '/tmp'
    test_value('$TEST_VAR/blah', '/tmp/blah')
    test_value('${TEST_VAR}/blah', '/tmp/blah')
    test_value('~/blah', '{}/blah'.format(os.path.expanduser('~')))
    test_value('~/blah', '{}/blah'.format(os.path.expanduser('~')))
    test_value('~bob/blah', '~bob/blah')


# Unit

# Generated at 2022-06-21 21:26:42.538206
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    # OrderedDict([('TEST', '.../yeee'),
    # ('THISIS', '.../a/test'),
    # ('YOLO',
    # '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:26:52.154239
# Unit test for function expand
def test_expand():
    # http://stackoverflow.com/questions/13019611/python-expanduser-and-expandvars-not-working-in-the-expected-way
    HOME = os.path.expanduser('~')
    assert expand('~/dir') == HOME + '/dir'
    assert expand('${HOME}/dir') == HOME + '/dir'
    assert expand('~/dir') == expand('${HOME}/dir')
    assert expand('~foobar/dir') == '~foobar/dir'
    assert expand('~/foo~bar/dir') == HOME + '/foo~bar/dir'
    assert expand('${HOME}/foo~bar/dir') == HOME + '/foo~bar/dir'

# Generated at 2022-06-21 21:27:04.224604
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ_old = dict(os.environ)
    load_env_file(lines, write_environ=None)
    environ_new = dict(os.environ)
    assert environ_old == environ_new
    environ = load_env_file(lines)

    assert isinstance(environ, collections.OrderedDict)
    assert 'TEST' in environ
    assert environ['TEST'].startswith(os.path.expanduser('~') + '/yeee-')
    assert environ['TEST'].endswith(':')

# Generated at 2022-06-21 21:27:08.759937
# Unit test for function load_env_file
def test_load_env_file():
    lines = """
    # Comment
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.splitlines()

    print(load_env_file(lines, os.environ))

# Generated at 2022-06-21 21:27:10.267458
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:27:13.672031
# Unit test for function expand
def test_expand():
    assert "~/a/b/c/d" == expand('~/a/b/${HOME}/c/d')



# Generated at 2022-06-21 21:27:23.602523
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ={})
    assert changes == {'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test',
                       'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-21 21:27:27.214179
# Unit test for function expand
def test_expand():
    # os.environ["HOME"] = "/tmp"
    # os.environ["PATH"] = ":/usr/bin/:/usr/local/bin/"
    assert expand(r'${HOME}/yeee-$PATH') == r'/tmp/yeee-:/usr/bin/:/usr/local/bin/'

# Generated at 2022-06-21 21:27:38.313306
# Unit test for function load_env_file

# Generated at 2022-06-21 21:27:39.763216
# Unit test for function expand
def test_expand():
    assert expand("$HOME/a") == os.path.expanduser("~/a")



# Generated at 2022-06-21 21:27:42.392440
# Unit test for function expand
def test_expand():

    assert expand('/home/user/') == '/home/user/'
    assert expand('~/swaggins') == '.../swaggins'
    assert expand('${HOME}/yeee') == '.../yeee'



# Generated at 2022-06-21 21:27:51.666841
# Unit test for function expand
def test_expand():
    # Variables
    val = "~"
    val_expanded = os.path.expanduser(val)
    assert (expand(val)) == val_expanded

    val = "$HOME"
    val_expanded = os.path.expanduser(val)
    assert (expand(val)) == val_expanded

    val = "$PATH"
    val_expanded = os.path.expandvars(val)
    assert (expand(val)) == val_expanded

    val = "$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    val_expanded = os.path.expandvars(val)
    assert (expand(val)) == val_expanded



# Generated at 2022-06-21 21:27:53.542461
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:27:58.578799
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents
    assert test_parse_env_file_contents.__doc__

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    assert d['TEST']



# Generated at 2022-06-21 21:28:00.725488
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    print(load_env_file(['TEST=$HOME/swag']))

# Generated at 2022-06-21 21:28:12.365829
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    tests = [
        dict(
            input=['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], output=[
                ('TEST', '.../.../yeee-...:...'),
                ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
        ),
    ]

    for test in tests:
        output = list(parse_env_file_contents(test['input']))
        assert output == test['output']


test_parse_env_file_contents()

# Generated at 2022-06-21 21:28:24.291363
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = dict(parse_env_file_contents(lines))

    assert d['TEST'] == expand(expand('${HOME}/yeee'))
    assert d['THISIS'] == expand(expand('~/a/test'))
    assert d['YOLO'] == expand(expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-21 21:28:31.821501
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    # test result
    assert isinstance(result, typing.Generator)

    # test generator
    result = list(result)

    assert len(result) == 3

    assert result[0] == ('TEST', '{}/yeee'.format(os.environ.get('HOME')))
    assert result[1] == ('THISIS', '{}/a/test'.format(os.environ.get('HOME')))

# Generated at 2022-06-21 21:28:39.419708
# Unit test for function expand
def test_expand():
    # Test variables
    os.environ["HOME"] = "/home/USER"
    os.environ["PATH"] = "/PATH/TO/SOMEWHERE"

    # Test cases
    test_cases = {
        "HOME": "/home/USER",
        "HOME/file.txt": "/home/USER/file.txt",
        "$HOME": "/home/USER",
        "~": "/home/USER"
    }

    for test_input in test_cases:
        expected_output = test_cases[test_input]
        actual_output = expand(test_input)

        assert expected_output == actual_output

# Generated at 2022-06-21 21:28:47.572946
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins']
    >>> d = dict(parse_env_file_contents(lines))
    >>> d == {
    ...     'TEST': '.../yeee',
    ...     'THISIS': '.../a/test',
    ...     'YOLO': '.../swaggins'
    ... }
    True
    """
    pass



# Generated at 2022-06-21 21:28:50.543620
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(['test=test'])
    assert os.environ.get('test') == 'test'



# Generated at 2022-06-21 21:28:59.883014
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert list(values) == [
        ('TEST', '${HOME}/yeee-${PATH}'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}')]

# Generated at 2022-06-21 21:29:04.911835
# Unit test for function load_env_file
def test_load_env_file():
    from os.path import expanduser
    from os import environ
    from pprint import pformat

    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
        "TEMP=${HOME}/test",
    ]

# Generated at 2022-06-21 21:29:16.968085
# Unit test for function load_env_file
def test_load_env_file():
    import pytest
    from . import helpers

    test_env = os.environ.copy()

    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    result = load_env_file(lines, write_environ=test_env)

    helpers.assert_dicts(result, {
        'TEST': "$HOME/yeee-$PATH",
        'THISIS': "~/a/test",
        'YOLO': "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    })


# Generated at 2022-06-21 21:29:26.817256
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    got = parse_env_file_contents(lines)
    expected = {
        "TEST": "~/yeee",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }
    for k, v in got:
        assert expected[k] == v



# Generated at 2022-06-21 21:29:29.962346
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(verbose=True)
    print('Tests successful')


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:29:39.415347
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # From honcho.
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [(k, expand(v)) for k, v in parse_env_file_contents(lines)]

# Generated at 2022-06-21 21:29:50.453612
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected_dict = {'TEST': '.../.../yeee-...:...',
                     'THISIS': '.../a/test',
                     'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    values = parse_env_file_contents(lines)

    loaded = collections.OrderedDict()

    for k, v in values:
        loaded[k] = v

    assert loaded == expected_dict



# Generated at 2022-06-21 21:29:54.968013
# Unit test for function expand
def test_expand():
    """
    >>> expand('~/test')
    '/home/tom/test'
    >>> expand('$HOME/test')
    '/home/tom/test'
    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:30:04.803753
# Unit test for function expand
def test_expand():
    assert expand(r"~/thistest") == expand(r"${HOME}/thistest")
    assert expand(r"~/file") == expand(r"${HOME}/file")
    assert expand(r"~/~/thistest") == expand(r"${HOME}/~/thistest")
    assert expand(r"~/~/file") == expand(r"${HOME}/~/file")
    assert expand(r"~/root/file") == expand(r"${HOME}/root/file")
    assert expand(r"~/.hidden/file") == expand(r"${HOME}/.hidden/file")
    assert expand(r"/var/www/public_html") == expand(r"${HOME}/../../../var/www/public_html")

# Generated at 2022-06-21 21:30:08.325554
# Unit test for function expand
def test_expand():
    # Expand user
    assert os.path.expanduser('~/test') == expand('~/test')
    # Expand variables
    assert os.path.expandvars('$HOME/test') == expand('$HOME/test')

# Generated at 2022-06-21 21:30:13.030122
# Unit test for function expand
def test_expand():
    # No expansion
    assert expand('value') == 'value'
    assert expand('~/value') == expand('value')

    # Variable expansion
    assert os.path.exists(expand('$HOME/value'))

    # User expansion
    assert os.path.exists(expand('~/value'))

    # Double expansion
    assert os.path.exists(expand('$HOME/~/value'))

# Generated at 2022-06-21 21:30:20.884252
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=$TEST_DIR/test',
        'TEST_DIR=$HOME/test',
        'YOLO=yooooooooo'
    ]

    changes = load_env_file(lines, write_environ={'HOME': '/home/user/'})

    assert changes['HOME'] == '/home/user/'
    assert changes['TEST_DIR'] == '/home/user/test'
    assert changes['TEST'] == '/home/user/test/test'
    assert changes['YOLO'] == 'yooooooooo'

# Generated at 2022-06-21 21:30:33.832558
# Unit test for function expand
def test_expand():
    val = r"~/test $PATH \/some\/more\$go/here"
    val = os.path.expanduser(val)
    val = os.path.expandvars(val)
    assert val == os.path.expanduser("PROJECT_HOME/test PROJECT_HOME/bin PROJECT_HOME/deps/go/bin/here")

    val = "/usr/bin:/bin"
    val = os.path.expanduser(val)
    val = os.path.expandvars(val)
    assert val == "/usr/bin:/bin"

    val = "$PATH"
    val = os.path.expanduser(val)
    val = os.path.expandvars(val)

# Generated at 2022-06-21 21:30:45.176816
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    expected = ('TEST', os.path.join(os.path.expanduser('~'), 'yeee'))
    actual = next(values)
    assert expected == actual, actual

    expected = ('THISIS', os.path.join(os.path.expanduser('~'), 'a', 'test'))
    actual = next(values)
    assert expected == actual, actual


# Generated at 2022-06-21 21:30:54.293723
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(lines=["TEST=${HOME}/yeee-$PATH",
                                "THISIS=~/a/test",
                                "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]) \
           == collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                       ('THISIS', '.../a/test'),
                                       ('YOLO',
                                        '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:31:09.896184
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    expected = collections.OrderedDict([
        ('TEST', f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'),
        ('THISIS', f'{os.environ["HOME"]}/a/test'),
        ('YOLO', f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])


# Generated at 2022-06-21 21:31:18.995461
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST1=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    assert result['TEST1'] == os.getenv('HOME') + '/yeee-' + os.getenv('PATH')
    assert result['THISIS'] == os.getenv('HOME') + '/a/test'
    assert result['YOLO'] == os.getenv('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:31:29.621745
# Unit test for function load_env_file
def test_load_env_file():
    env_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = {'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    env_test_dict = load_env_file(env_lines)
    assert all(k in env_test_dict.keys() for k in result.keys())

    for k, v in env_test_dict.items():
        assert v == result[k]



# Generated at 2022-06-21 21:31:32.480545
# Unit test for function expand
def test_expand():
  assert expand("~/develop/env_tools/env_tools") == os.path.expanduser(os.path.expandvars("~/develop/env_tools/env_tools"))
  assert expand("${HOME}/develop/env_tools/env_tools") == os.path.expanduser(os.path.expandvars("${HOME}/develop/env_tools/env_tools"))



# Generated at 2022-06-21 21:31:38.661316
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())

    p = os.path.expanduser('~')
    q = os.path.expanduser('~') + '/yeee-' + os.getenv('PATH')
    r = os.path.expanduser('~') + '/a/test'
    s = os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    assert env['TEST'] == q
    assert env['THISIS'] == r
   

# Generated at 2022-06-21 21:31:48.640993
# Unit test for function expand
def test_expand():
    test_vars = {
        'HOME': '~'
    }

    os.environ['HOME'] = '~'

    lines = [
        'TEST=$HOME/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    file_contents = load_env_file(lines)

    assert file_contents['TEST'] == '~/yeee-%s' % os.environ['PATH']
    assert file_contents['THISIS'] == '~/a/test'

# Generated at 2022-06-21 21:32:00.354176
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test empty
    lines = []
    res = list(parse_env_file_contents(lines))
    assert len(res) == 0

    # test simple line
    lines = ["TEST=hello"]
    res = list(parse_env_file_contents(lines))
    assert res[0] == ("TEST", "hello")

    # test complex line
    lines = ["TEST=hello/world $VAR"]
    res = list(parse_env_file_contents(lines))
    assert res[0] == ("TEST", "hello/world $VAR")

    # test lines with spaces
    lines = [
        "TEST=hello/world $VAR",
        "TEST2=this 'is a string' with spaces"
    ]

# Generated at 2022-06-21 21:32:11.470196
# Unit test for function load_env_file
def test_load_env_file():
    import pytest
    import os

    # given
    test_env = {'HOME': '/home/daniel', 'PATH': '...'}
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # when
    with pytest.raises(KeyError) as ex:
        load_env_file(lines, {**os.environ, **test_env})

    assert "NONEXISTENT_VAR_THAT_DOES_NOT_EXIST" in str(ex.value)

    # and when
    changes = load_env_file(lines, {**os.environ, **test_env})

    # then
    assert changes

# Generated at 2022-06-21 21:32:20.972633
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest.mock

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = list(parse_env_file_contents(lines))

    assert values == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    with unittest.mock.patch('os.path.expandvars', return_value='EXPANDED'):
        values = list(parse_env_file_contents(lines))



# Generated at 2022-06-21 21:32:32.932862
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    results = load_env_file(lines, write_environ=environ)
    assert results

    assert environ['HOME'] is not None

# Generated at 2022-06-21 21:32:48.595691
# Unit test for function expand
def test_expand():
    import os
    import pathlib

    assert expand('$HOME') == os.path.expanduser('~')
    assert expand('~/test') == os.path.join(os.path.expanduser('~'), 'test')
    assert expand('~/test') == os.path.expanduser('~/test')

    assert expand('${HOME}/test') == pathlib.Path(expand('~')) / 'test'
    assert expand('${HOME}/test') == expand('${HOME}/test')


if __name__ == '__main__':
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 21:33:00.442607
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import os

    def get_home():
        import os
        return os.path.expanduser("~")

    def get_path():
        import os
        return os.environ["PATH"]

    def get_version():
        import sys
        return sys.version

    data = {'HOME': get_home(), 'PATH': get_path(), 'VERSION': get_version()}

    lines = [
        'HOME={home}'.format(**data),
        'PATH={path}'.format(**data),
        'VERSION={version}'.format(**data),
        'FULL_PATH=${HOME}/${PATH}',
        'UNDEFINED_VARIABLE=${UNDEFINED_VARIABLE}'
    ]

    kv_generator = parse_env_file_contents(lines)

# Generated at 2022-06-21 21:33:10.981976
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = list(parse_env_file_contents(lines))
    assert len(results) == 3
    assert results[0] == ('TEST', expand('${HOME}/yeee'))
    assert results[1] == ('THISIS', expand('~/a/test'))
    assert results[2] == ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-21 21:33:22.065773
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    import subprocess

    env_file = tempfile.NamedTemporaryFile()
    env_file.file.write(TEST_ENV_FILE)
    env_file.file.flush()

    args = ['bash', '-c', 'cat {env_file} | env'.format(**locals())]
    result_env = subprocess.Popen(args, stdout=subprocess.PIPE, env=dict()).stdout.read().decode()

    values = parse_env_file_contents(TEST_ENV_FILE.splitlines())

    for k, v in values:
        result_env = re.sub(r'\b{k}={v}\b'.format(**locals()), '', result_env)

    assert result_env == ''


TEST_EN