

# Generated at 2022-06-21 21:23:37.184165
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test escaping of quotes
    lines = ['TEST="a\\\\b"      # comment']
    parsed = parse_env_file_contents(lines)
    assert ('TEST', 'a\\b') in parsed

    lines = ["TEST='ape'"]
    parsed = parse_env_file_contents(lines)
    assert ('TEST', 'ape') in parsed

    lines = ["TEST='a_pe'", 'TEST2="a\\pe"']
    parsed = parse_env_file_contents(lines)
    assert ('TEST', 'a_pe') in parsed
    assert ('TEST2', 'ape') in parsed

    # Test quoted values
    lines = ['TEST="ape"']
    parsed = parse_env_file_contents(lines)
    assert ('TEST', 'ape') in parsed



# Generated at 2022-06-21 21:23:46.816487
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    changes = dict()

    for k, v in values:
        v = expand(v)

        changes[k] = v


# Generated at 2022-06-21 21:23:57.538468
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    x = load_env_file(lines, write_environ=dict())

    x = collections.OrderedDict([('TEST', '/.../.../yeee-...:...'),
                                 ('THISIS', '/.../a/test'),
                                 ('YOLO',
                                  '/.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
                                )

    assert x == load_env_file(lines, write_environ=dict())



# Generated at 2022-06-21 21:24:03.083807
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)

    assert 'TEST' in result
    assert 'THISIS' in result
    assert 'YOLO' in result



# Generated at 2022-06-21 21:24:12.924363
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import re

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    print(list(parse_env_file_contents(lines)))
    assert list(parse_env_file_contents(lines)) == [("TEST", "${HOME}/yeee"), ("THISIS", "~/a/test"), ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]


# Generated at 2022-06-21 21:24:15.817184
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('~') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expanduser('~')



# Generated at 2022-06-21 21:24:18.011520
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=None)

# Generated at 2022-06-21 21:24:29.650612
# Unit test for function load_env_file
def test_load_env_file():
    import shutil
    import tempfile
    import textwrap

    lines = textwrap.dedent('''
        TEST=${HOME}/yeee-${PATH}
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    ''').strip().split('\n')

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-21 21:24:36.893447
# Unit test for function expand
def test_expand():
    """
    Tests the expand function

    >>> os.environ["TEST1"] = "wopwop"
    >>> expand("$TEST1/yea")
    'wopwop/yea'

    >>> expand("~/yea")
    '.../yea'

    >>> expand("~sfsdfsd/yea")
    '~sfsdfsd/yea'

    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-21 21:24:44.376619
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content = """
        TEST=${HOME}/yeee-PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        PATH='/honey'
        NESTED="\$HOME/honey"
        """
    result = parse_env_file_contents(content.splitlines())
    assert isinstance(result, collections.Iterable)
    parsed = list(result)

# Generated at 2022-06-21 21:24:49.711748
# Unit test for function expand
def test_expand():
    assert expand('~/temp') == os.path.join(os.path.expanduser('~'), 'temp')
    assert expand('${HOME}/temp') == os.path.join(os.environ['HOME'], 'temp')
    assert expand('~/temp') != os.path.join(os.environ['HOME'], 'temp')



# Generated at 2022-06-21 21:25:01.690228
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', os.path.expandvars(
        '${HOME}/yeee-$PATH')), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:25:06.475416
# Unit test for function expand
def test_expand():
    assert expand('~/yoyo') == os.environ['HOME'] + '/yoyo'
    assert expand('${HOME}/yoyo') == os.environ['HOME'] + '/yoyo'

# Generated at 2022-06-21 21:25:12.022088
# Unit test for function expand
def test_expand():
    assert expand(r'~') == '/home/vagrant'
    assert expand('~') == '/home/vagrant'
    assert expand('${HOME}') != '${HOME}'
    assert expand(r'${HOME}') != r'${HOME}'

    assert expand('${HOME}') == '/home/vagrant'
    assert expand(r'${HOME}') == '/home/vagrant'



# Generated at 2022-06-21 21:25:17.070309
# Unit test for function expand
def test_expand():
    assert expand('~/foo') == '/Users/tom/foo'
    assert expand('$HOME/foo') == '/Users/tom/foo'
    assert expand('$HOME/foo') == os.environ['HOME'] + '/foo'
    assert expand('~/') == '/Users/tom/'



# Generated at 2022-06-21 21:25:28.288277
# Unit test for function load_env_file
def test_load_env_file():
    import copy
    import unittest

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result_to_compare = collections.OrderedDict()
    result_to_compare['TEST'] = '{}/yeee-{}'.format(os.path.expanduser('~'), os.environ['PATH'])
    result_to_compare['THISIS'] = '{}/a/test'.format(os.path.expanduser('~'))

# Generated at 2022-06-21 21:25:40.682716
# Unit test for function expand
def test_expand():
    old_path = os.environ['PATH']
    old_home = os.environ['HOME']
    os.environ['PATH'] = '/bin:/usr/bin'
    os.environ['HOME'] = '/home/user'

    assert expand('/tmp') == '/tmp'
    assert expand('$PATH') == '/bin:/usr/bin'
    assert expand('${PATH}') == '/bin:/usr/bin'
    assert expand('~') == '/home/user'
    assert expand('~user') == '/home/user'
    assert expand('~/logs') == '/home/user/logs'
    assert expand('~user/logs') == '/home/user/logs'
    assert expand('${HOME}/logs') == '/home/user/logs'


# Generated at 2022-06-21 21:25:49.061103
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = [('TEST', '{}/yeee'.format(os.path.expanduser('~'))),
                ('THISIS', '{}/a/test'.format(os.path.expanduser('~'))),
                ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.path.expanduser('~')))]

    r = list(parse_env_file_contents(contents))
    assert r == expected



# Generated at 2022-06-21 21:25:58.288012
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert collections.OrderedDict(parse_env_file_contents(lines)) == {
        'TEST': os.path.expanduser('~') + '/yeee',
        'THISIS': os.path.expanduser('~') + '/a/test',
        'YOLO': os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-21 21:26:08.407077
# Unit test for function expand
def test_expand():
    """
    Test function expand works as expected.

    The results here are system dependent, but the general idea does not change.
    """
    os.environ['TEST'] = 'this'
    assert expand('$TEST') == 'this'
    assert expand('${TEST}') == 'this'
    assert expand('~') == os.path.expanduser('~')

    # We should not expand things like
    assert expand('${DOESNOTEXIST}') == '${DOESNOTEXIST}'
    assert expand('${DOESNOTEXIST:-default}') == 'default'
    assert expand('${DOESNOTEXIST-default}') == 'default'
    assert expand('${DOESNOTEXIST:=default}') == 'default'
    assert expand('${DOESNOTEXIST=default}') == 'default'

# Generated at 2022-06-21 21:26:14.877094
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test')]



# Generated at 2022-06-21 21:26:19.906143
# Unit test for function expand
def test_expand():
    assert expand('~/yeee') == os.path.expanduser('~/yeee')
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')
    assert expand('/home/~/yeee') == expand('/home/~/yeee')



# Generated at 2022-06-21 21:26:28.898658
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-' + os.environ.get('PATH'))
    assert result['THISIS'] == os.path.join(os.path.expanduser('~'), 'a/test')
    assert result['YOLO'] == os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')




# Generated at 2022-06-21 21:26:33.253642
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


# Generated at 2022-06-21 21:26:39.725753
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import unittest

    # noinspection PyUnresolvedReferences
    class LoadEnvFileTests(unittest.TestCase):
        def setUp(self):
            self.environ = dict()

        def test_reading_a_file(self):
            file = io.StringIO('FOO=BAR\nSPAM=EGGS\n')
            load_env_file(file, self.environ)
            self._assert_equal(self.environ, {'FOO': 'BAR', 'SPAM': 'EGGS'})

        def _assert_equal(self, env, expected):
            self.assertEqual(len(env), len(expected))

            for key, value in env.items():
                self.assertTrue(key in expected)

# Generated at 2022-06-21 21:26:43.744524
# Unit test for function load_env_file
def test_load_env_file():
    with open(os.path.join(os.path.dirname(__file__), '../.env'), mode='r', encoding='utf-8') as f:
        loaded = load_env_file(f)
        print(loaded)



# Generated at 2022-06-21 21:26:49.856924
# Unit test for function expand
def test_expand():
    # Test without anything
    assert expand('test') == 'test'

    # Test with %HOME%
    assert expand('%HOME%') == os.environ['HOME']

    # Test with ~
    assert expand('~') == os.environ['HOME']

    # Test with ~ and / (should append / to the path)
    assert expand('~/') == os.environ['HOME'] + '/'

# Generated at 2022-06-21 21:26:53.131552
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:27:04.781297
# Unit test for function load_env_file

# Generated at 2022-06-21 21:27:13.217334
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Loads env files and checks if they are loaded correctly.
    """
    # Load an env file with simple keys and values
    base_test_env_file_name = os.path.join(os.path.dirname(os.path.realpath(__file__)), "tests/test.env")
    with open(base_test_env_file_name, 'r') as base_test_env_file:
        base_test_env_file_lines = base_test_env_file.readlines()

    # Create a test dict from that file
    test_dict = load_env_file(base_test_env_file_lines, write_environ=None)

    # Check if the list of key-value pairs matches with the list obtained from parse_env_file_contents()

# Generated at 2022-06-21 21:27:20.694300
# Unit test for function expand
def test_expand():
    assert expand('$HOMEPATH/test') == os.path.expanduser('~/test')
    assert expand('~/test') == os.path.expanduser('~/test')

# Generated at 2022-06-21 21:27:29.667668
# Unit test for function load_env_file

# Generated at 2022-06-21 21:27:38.966779
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    import sys

    class Test(unittest.TestCase):
        lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

        def test_loads(self):
            load_env_file(self.lines, write_environ=sys.environ)

            self.assertIn('THISIS', sys.environ)
            self.assertIn('TEST', sys.environ)
            self.assertIn('YOLO', sys.environ)

            self.assertEqual(sys.environ['THISIS'], os.path.expanduser('~') + '/a/test')

# Generated at 2022-06-21 21:27:41.848949
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-21 21:27:43.979542
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-21 21:27:52.454215
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                                                                  ('THISIS', '.../a/test'),
                                                                                  ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:28:00.394286
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    # lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    # ret = load_env_file(lines, write_environ=dict())

    # data = [('TEST', '.../yeee'),
    #         ('THISIS', '.../a/test'),
    #         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # # print(ret.items())
    # # print(data)
    # # print(list(ret.items()))
    # # print(list(data))

    # assert(list(ret.

# Generated at 2022-06-21 21:28:12.366597
# Unit test for function expand
def test_expand():
    # Try curr directory
    if os.getcwd() == os.path.expanduser('.'):
        curr_dir_abs = os.getcwd()
    else:
        curr_dir_abs = os.path.expanduser('.')

    assert expand('.') == curr_dir_abs
    assert expand('./xyz') == os.path.join(curr_dir_abs, 'xyz')
    assert expand('./xyz/') == os.path.join(curr_dir_abs, 'xyz') + os.sep

    # If the directory is invalid, we expect to get the original
    assert expand('..') == '..'
    assert expand('../xyz') == '../xyz'

# Generated at 2022-06-21 21:28:20.034133
# Unit test for function load_env_file
def test_load_env_file():
    # write_environ is set to None because we want to test the raw return from the function
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=None) == collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                                                                ('THISIS', '.../a/test'),
                                                                                ('YOLO',
                                                                                 '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:28:23.602609
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    do_test = doctest.testmod(verbose=False, optionflags=doctest.IGNORE_EXCEPTION_DETAIL)
    assert do_test[0] == 0



# Generated at 2022-06-21 21:28:32.627256
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict())
    # OrderedDict([('TEST', '/Users/test/yeee'),
    #              ('THISIS', '/Users/test/a/test'),
    #              ('YOLO',
    #               '/Users/test/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-21 21:28:36.493768
# Unit test for function expand
def test_expand():
    result = expand('~')
    assert result is not None

    result = expand('${HOME}')
    assert result is not None

    result = expand('~/yeee/yeee/${HOME}')
    assert result is not None

# Generated at 2022-06-21 21:28:45.844319
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines)
    OrderedDict([('TEST', '.../.../yeee-...:...'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-21 21:28:49.120538
# Unit test for function expand
def test_expand():
    expanded = expand('$HOME/test')
    assert expanded.startswith(os.path.expanduser('~'))


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:29:01.108820
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as temp:
        temp.write("""\
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST""")

    m = None


# Generated at 2022-06-21 21:29:03.546490
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('${PATH}') == os.getenv('PATH')



# Generated at 2022-06-21 21:29:07.679077
# Unit test for function expand
def test_expand():
    assert expand('./test') == os.path.expanduser('./test')
    assert expand('$HOME') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expanduser('~')

# Generated at 2022-06-21 21:29:17.206823
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = list(parse_env_file_contents(lines))

    assert result == [('TEST', os.path.expanduser('~') + '/yeee'), ('THISIS', os.path.expanduser('~/a/test')),
                      ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]

# Generated at 2022-06-21 21:29:26.818411
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    expected = collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    actual = collections.OrderedDict(parse_env_file_contents(lines))

    assert expected == actual


# Generated at 2022-06-21 21:29:33.763690
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert parse_env_file_contents(lines) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-21 21:29:51.143865
# Unit test for function expand
def test_expand():
    # Full environment
    env = os.environ.copy()

    # Full load first
    load_env_file(env.items(), write_environ=None)

    # Expand
    expanded = {}
    for key, value in env.items():
        expanded[key] = expand(value)
    assert str(env) == str(expanded)


if __name__ == '__main__':
    import shlex

    import argparse

    parser = argparse.ArgumentParser()
    parser.description = "Prints parsed environment variables"
    parser.add_argument('files', nargs='*', default=['-'])
    args = parser.parse_args()

    if '-' in args.files:
        lines = sys.stdin
    else:
        infiles = [open(f) for f in args.files]

# Generated at 2022-06-21 21:29:57.155093
# Unit test for function load_env_file
def test_load_env_file():
    import textwrap
    lines = textwrap.dedent("""
    FIRST=first
    SECOND=second
    THIRD=three
    REPEATED=first
    REPEATED=second
    """).strip().split("\n")

    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-21 21:30:04.647361
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("~") == os.path.expanduser("~")
    assert expand("~/") == os.path.expanduser("~/")
    assert expand("${HOME}/") == os.path.expanduser("~/")
    assert expand("~/hoge") == os.path.expanduser("~/hoge")

    # Should not work
    assert expand("~hoge") != os.path.expanduser("~hoge")
    assert expand("~hoge") == "~hoge"



# Generated at 2022-06-21 21:30:06.640635
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.run_docstring_examples(load_env_file, globals())



# Generated at 2022-06-21 21:30:07.990876
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 21:30:15.817218
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=~/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output = [x for x in parse_env_file_contents(lines)]

    assert len(output) == 3
    assert output[0][0] == 'TEST'
    assert output[0][1] == '~/yeee'
    assert output[1][0] == 'THISIS'
    assert output[1][1] == '~/a/test'
    assert output[2][0] == 'YOLO'
    assert output[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-21 21:30:20.795193
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = parse_env_file_contents(['TEST=1', 'TEST2=2', 'TEST3=\'3\'', 'TEST4="4"'])
    assert list(contents) == [('TEST', '1'), ('TEST2', '2'), ('TEST3', '3'), ('TEST4', '4')]



# Generated at 2022-06-21 21:30:33.784004
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = collections.OrderedDict()
    changes = load_env_file(lines, write_environ=environ)


# Generated at 2022-06-21 21:30:43.074196
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert tuple(parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == (('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))


if __name__ == '__main__':
    import doctest
    import sys
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-21 21:30:54.749693
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from testfixtures import compare