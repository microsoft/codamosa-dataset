

# Generated at 2022-06-24 02:19:45.522711
# Unit test for function expand
def test_expand():
    # Test expandvars and expanduser
    assert expand('$HOME/a') == os.path.expanduser('~/a')
    assert expand('${HOME}/a') == os.path.expanduser('~/a')
    # Test that expand does nothing if there are no values.
    assert expand('$PATH/a') == '$PATH/a'
    assert expand('~/a/b') == os.path.expanduser('~/a/b')

# Generated at 2022-06-24 02:19:49.103588
# Unit test for function expand
def test_expand():
    with pytest.raises(TypeError):
        expand(42)

    assert expand('~/yeee') == os.path.expanduser('~/yeee')
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')

# Generated at 2022-06-24 02:19:49.701055
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:19:59.058340
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    changes = load_env_file(lines, write_environ=environ)
    assert ("TEST", environ["TEST"]) in changes.items()
    assert ("THISIS", environ["THISIS"]) in changes.items()
    assert ("YOLO", environ["YOLO"]) in changes.items()



# Generated at 2022-06-24 02:20:02.541639
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("${HOME}") == os.path.expandvars("${HOME}")



# Generated at 2022-06-24 02:20:06.620180
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:20:14.797498
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test"]
    res = load_env_file(lines, write_environ=dict())
    assert res['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee')
    assert res['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

    lines = ['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines, write_environ=dict())
    assert res['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:20:23.183497
# Unit test for function load_env_file
def test_load_env_file():
    assert len(load_env_file([], write_environ=None)) == 0

    assert load_env_file([
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ], write_environ=None) == collections.OrderedDict([
        ("TEST", "..."),
        ("THISIS", "..."),
        ("YOLO", "...")
    ])



# Generated at 2022-06-24 02:20:25.837383
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:20:34.896181
# Unit test for function expand
def test_expand():
    cwd = os.getcwd()
    assert expand('~/a/b') != '~/a/b'
    assert expand('~/a/b') == os.path.expanduser('~/a/b')
    os.environ['TEST_VAR'] = cwd
    assert expand('$TEST_VAR/a') != '$TEST_VAR/a'
    assert expand('$TEST_VAR/a') == os.path.join(cwd, 'a')


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-24 02:20:39.604330
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    if sys.version_info < (3, 5):
        import mock
        import unittest.mock as newmock

        mock.patch("builtins.open", newmock.mock_open(read_data="TEST=${HOME}/yeee-$PATH")).start()

        assert load_env_file("notafile") == {
            "TEST": os.path.expanduser("~") + "/yeee-" + os.environ["PATH"]
        }



# Generated at 2022-06-24 02:20:44.475488
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:20:48.895783
# Unit test for function expand
def test_expand():
    assert expand('~/swaggins') == os.path.expanduser('~/swaggins')
    assert expand('${HOME}/swaggins') == '{}/swaggins'.format(os.environ['HOME'])



# Generated at 2022-06-24 02:20:59.420306
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(lines=[])) == []
    assert list(parse_env_file_contents(lines=[''])) == []

    assert list(parse_env_file_contents(lines=['TEST=TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'])) == [
        ('TEST', 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST')
    ]

    assert list(parse_env_file_contents(lines=['TEST=TEST', 'YEAH=YEAH'])) == [
        ('TEST', 'TEST'),
        ('YEAH', 'YEAH')
    ]


# Generated at 2022-06-24 02:21:08.527084
# Unit test for function expand
def test_expand():
    BACKUP_ENV = os.environ.copy()

    os.environ['HOME'] = '/path/to/home'
    os.environ['PATH'] = '/path/to/path'
    os.environ['ENV_VAR_UNITTEST'] = 'unittest'

    assert os.path.expanduser('~/unittest') == expand('~/unittest')
    assert os.path.expandvars('$HOME/unittest') == expand('$HOME/unittest')
    assert os.path.expandvars('${HOME}/unittest') == expand('${HOME}/unittest')

# Generated at 2022-06-24 02:21:12.733340
# Unit test for function expand
def test_expand():
    assert expand('/home/yolo/') == '/home/yolo/'


# Unit tests for function load_env_file

# Generated at 2022-06-24 02:21:17.833489
# Unit test for function expand
def test_expand():
    assert expand(r"~") == os.path.expanduser(r"~")
    assert expand(r"$HOME") == os.path.expanduser(r"$HOME")
    assert expand(r"$HOME/test") == os.path.expanduser(r"$HOME/test")
    assert expand(r"${HOME}") == os.path.expanduser(r"${HOME}")
    assert expand(r"${HOME}/test") == os.path.expanduser(r"${HOME}/test")



# Generated at 2022-06-24 02:21:24.517245
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == \
        collections.OrderedDict([('TEST', os.path.expanduser(os.path.expandvars('${HOME}/yeee'))),
                     ('THISIS', os.path.expanduser(os.path.expandvars('~/a/test'))),
                     ('YOLO', os.path.expanduser(os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')))])



# Generated at 2022-06-24 02:21:34.232224
# Unit test for function expand
def test_expand():
    env_file = [
        'HOME=/home/user',
        'MY_VAR=/home/user/my_env_file',
        'PATH=/usr/bin:/bin'
    ]

    env = os.environ.copy()  # copy the environment to restore it after testing
    new_env = load_env_file(env_file)

    print(new_env)

    # test the expand user method
    assert new_env['HOME'] == expand(new_env['HOME'])
    assert new_env['MY_VAR'] == expand(new_env['MY_VAR'])
    assert new_env['PATH'] == expand(new_env['PATH'])

    # restore env
    os.environ = env



# Generated at 2022-06-24 02:21:41.788965
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    lines = ["TEST=${HOME}/yeee-${PATH}", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    lines = [line.replace("~", os.environ["HOME"]) for line in lines]
    lines = [line.replace("${HOME}", os.environ["HOME"]) for line in lines]
    lines = [line.replace("${PATH}", os.environ["PATH"]) for line in lines]
    lines = [line.replace("${PYTHONPATH}", os.environ["PYTHONPATH"]) for line in lines]

    # Cannot get this working for some reason
    # lines = [line.replace("${PYTHONPATH}

# Generated at 2022-06-24 02:21:47.095547
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['thing=one', 'yolo=swag'], write_environ=dict()) == collections.OrderedDict([('thing', 'one'), ('yolo', 'swag')])



# Generated at 2022-06-24 02:21:53.240971
# Unit test for function expand
def test_expand():
    assert expand(r'$HOME') == os.environ['HOME']
    assert expand('~') == os.environ['HOME']

    assert expand(r'${HOME}/yeee') == os.environ['HOME'] + '/yeee'
    assert expand(r'~/yeee') == os.environ['HOME'] + '/yeee'
    assert expand(r'${PATH}') == os.environ['PATH']
    assert expand(r'${HOME}/${PATH}') == os.environ['HOME'] + '/' + os.environ['PATH']



# Generated at 2022-06-24 02:21:58.700633
# Unit test for function load_env_file
def test_load_env_file():
    # empty file
    assert dict(load_env_file([])) == {}

    # only comments
    assert dict(load_env_file(['# comment1', '# comment2'])) == {}

    # couple variables
    assert dict(load_env_file(['ENV1=my_env1', 'ENV2=my_env2'])) == {
        'ENV1': 'my_env1',
        'ENV2': 'my_env2',
    }

    # couple variables with quotes
    assert dict(load_env_file(['ENV1="my env1"', "ENV2='my env2'"])) == {
        'ENV1': 'my env1',
        'ENV2': 'my env2',
    }

    # couple variables with quotes

# Generated at 2022-06-24 02:22:07.028442
# Unit test for function expand
def test_expand():
    def test(env: typing.Mapping[str, str], expected: str):
        with mock.patch("os.getenv", env.get):
            with mock.patch("os.path.expandvars", os.path.expandvars):
                with mock.patch("os.path.expanduser", os.path.expanduser):
                    assert expected == expand("$TEST")

    def test2(env: typing.Mapping[str, str], expected: str):
        with mock.patch("os.getenv", env.get):
            with mock.patch("os.path.expandvars", os.path.expandvars):
                with mock.patch("os.path.expanduser", os.path.expanduser):
                    assert expected == expand("~/test")


# Generated at 2022-06-24 02:22:12.077376
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:22:21.332838
# Unit test for function expand
def test_expand():
    """
    Test function expand.

    >>> os.environ["TEST"] = "TestVal"
    >>> #os.path.exists(os.environ["HOME"])
    >>> expand("$TEST")
    'TestVal'
    >>> expand("${TEST}")
    'TestVal'
    >>> expand("$HOME")
    '...'
    >>> os.environ["TEST"] = "TestVal2"
    >>> expand("${TEST}")
    'TestVal2'
    >>> del os.environ["TEST"]
    >>> os.environ["TEST"]
    Traceback (most recent call last):
    ...
    KeyError: 'TEST'
    >>> expand("${TEST}")
    ''
    """
    import doctest


# Generated at 2022-06-24 02:22:24.297695
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    from pprint import pprint

    pprint(os.environ)



# Generated at 2022-06-24 02:22:29.405646
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests the function parse_env_file_contents
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-24 02:22:35.779488
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:22:40.502427
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/a') == os.path.expanduser('~/a')
    assert expand('~/a') == os.path.expanduser('~/a')
    assert expand('a') == 'a'


if __name__ == '__main__':
    test_expand()

# Generated at 2022-06-24 02:22:43.234912
# Unit test for function expand
def test_expand():
    assert expand('~') == os.environ['HOME']  # assume that $HOME is set
    assert expand('$HOME') == os.environ['HOME']  # assume that $HOME is set



# Generated at 2022-06-24 02:22:47.583237
# Unit test for function expand
def test_expand():
    input_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(input_dir)
    home = expand("~")
    assert os.path.realpath(os.getcwd()) == os.path.realpath(home)


if __name__ == "__main__":
    test_expand()

# Generated at 2022-06-24 02:22:53.458451
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # type: () -> None
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = parse_env_file_contents(lines)
    assert env == [('TEST', '{{HOME}}/yeee'), ('THISIS', '{{HOME}}/a/test'), ('YOLO', '{{HOME}}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:22:56.251590
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:22:58.268472
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=a'])) == [('TEST', 'a')]



# Generated at 2022-06-24 02:23:02.953640
# Unit test for function expand
def test_expand():
    assert expand("$HOME/test") == os.path.expandvars("$HOME/test")

    # Asserting that ~ works as well
    assert expand("~/test") == os.path.expanduser("~/test")



# Generated at 2022-06-24 02:23:10.347843
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Expected behavior and outcomes
    expected_outputs = collections.OrderedDict()
    expected_outputs['TEST'] = '.../yeee'
    expected_outputs['THISIS'] = '.../a/test'
    expected_outputs['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    # Real arguments
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Running the test
    actual_output = parse_env_file_contents(lines)

    # Failure message

# Generated at 2022-06-24 02:23:16.765444
# Unit test for function expand
def test_expand():
    # Test cases
    a = "~/foo/bar"
    b = "~/foo/bar/"
    c = "~/foo/bar/~"
    d = "$HOME/foo/bar"
    e = "$HOME/foo/bar/"
    f = "$HOME/foo/bar/~"
    g = "$HOME"
    h = "$HOME/"
    i = "$HOME/~"
    j = "~"
    k = "~/"
    l = "~/~"

    # Source of expected results
    e_a = os.path.expanduser(os.path.expandvars(a))
    e_b = os.path.expanduser(os.path.expandvars(b))

# Generated at 2022-06-24 02:23:27.035215
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    environ = dict()
    changes = load_env_file(lines, write_environ=environ)

    assert environ['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-', os.environ['PATH'])
    assert changes['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-', os.environ['PATH'])

# Generated at 2022-06-24 02:23:31.093183
# Unit test for function expand
def test_expand():
    # Test home directory
    assert os.path.expanduser("~/testpath") == expand("~/testpath")

    # Test environment variables
    assert os.path.expandvars("$PWD/testpath") == expand("$PWD/testpath")

    # Test path expansion
    assert os.path.abspath("testpath") == expand("./testpath")


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:23:42.181789
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(None) == []

    lines = [
        '# This is a comment',
        ' # Comment only line',
        '',
        'VARNAME=value',
        'VARNAME="value"',
        "VARNAME='value'",
        'VARNAME=\'value\'',
        'VARNAME="""value"""',
        "VARNAME='''value'''",
        'VARNAME=\'\'\'value\'\'\'',
        'VARNAME=""""value"""\'"\'\'\'',
    ]

# Generated at 2022-06-24 02:23:49.017273
# Unit test for function expand
def test_expand():
    """
    Test expand.
    """
    from sys import version_info

    if version_info[0] < 3:
        return

    assert expand('abc') == 'abc'
    assert expand('$PATH') == os.environ['PATH']
    assert expand('${PATH}') == os.environ['PATH']
    assert expand('~') == os.path.expanduser('~')


if __name__ == "__main__":
    import sys
    import traceback


# Generated at 2022-06-24 02:23:50.986248
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:23:58.905023
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=dict()) == \
           collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                    ('THISIS', os.path.join(os.path.expanduser('~'), 'a', 'test')),
                                    ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-24 02:24:02.813573
# Unit test for function expand
def test_expand():
    assert os.path.expandvars("${HOME}") == expand("${HOME}")
    assert os.path.expanduser("~") == expand("~")
    assert os.path.expanduser("~") == expand("${HOME}")



# Generated at 2022-06-24 02:24:10.921224
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:24:12.882078
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee') == os.path.join(os.environ['HOME'], 'yeee')



# Generated at 2022-06-24 02:24:21.564071
# Unit test for function expand
def test_expand():
    env = {}
    env['HOME'] = os.getenv('HOME')
    env['PATH'] = os.getenv('PATH')

    assert expand("$HOME/yeee") == os.path.expanduser("~/yeee")
    assert expand("${PATH}/yeee") == os.path.expandvars("${PATH}/yeee")
    assert expand("$HOME/yeee-$PATH") == os.path.expanduser("~/yeee-") + os.path.expandvars("${PATH}")



# Generated at 2022-06-24 02:24:30.926744
# Unit test for function expand
def test_expand():
    import sys
    import random

    write_environ = dict()

    # Test that variable expansion works
    test_vars = [
        'TEST', 'TEST_VAR', 'TEST-VAR', 'TEST_VAR_123', 'TEST_VAR_with_a_long_string_and_underscores',
        'TEST_VAR_WITH_CAPS', 'TEST_VAR_WITH_CAPS_AND_UNDERSCORES', 'TEST_VAR_that_is_longer_than_32_chars'
    ]

    for var in test_vars:
        write_environ[var] = '{}_VAR_VALUE'.format(var)

    # Test that variable expansion works with other characters in the variable

# Generated at 2022-06-24 02:24:42.013992
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:24:49.810930
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Typical case
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)
    assert len(result) == 3
    assert result['TEST'] == expand('${HOME}/yeee')
    assert result['THISIS'] == expand('~/a/test')
    assert result['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:24:51.698282
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser(os.path.expandvars('~/test'))

# Generated at 2022-06-24 02:24:59.536291
# Unit test for function expand
def test_expand():
    import unittest
    import os
    import os.path

    # We need to write a file to the home dir to test this
    class TestExpand(unittest.TestCase):
        def setUp(self):
            open(os.path.join(os.path.expanduser('~'), 'my.txt'), 'w').write('test')

        def tearDown(self):
            os.remove(os.path.join(os.path.expanduser('~'), 'my.txt'))

        def test_expand(self):
            # We need to write a file to the home dir to test this
            path = os.path.join(expand('~'), 'my.txt')
            self.assertTrue(os.path.exists(path))

    unittest.main()


# Generated at 2022-06-24 02:25:04.740556
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    print(load_env_file(['PATH=$HOME/foo', 'YOLO=yeee']))

# EOF

# Generated at 2022-06-24 02:25:07.598512
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)


# This is used if called as a script

# Generated at 2022-06-24 02:25:15.879995
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.expanduser('${HOME}/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]



# Generated at 2022-06-24 02:25:16.730357
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:25:22.427534
# Unit test for function load_env_file
def test_load_env_file():
    from pathlib import Path

    # Load the current environment file
    env_file = Path(__file__).parent / 'environment'
    with open(env_file, 'r') as f:
        f_lines = [line for line in f]

    environ_dict = load_env_file(f_lines)

    # Check that the values are correct
    assert environ_dict['TEST'] == 'Hello World'
    assert environ_dict['TEST_EXTENDED'] == 'Hello World Extended'



# Generated at 2022-06-24 02:25:29.621438
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Define input values
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Define expected values
    expected_values = [('TEST', os.environ['HOME'] + '/yeee-' + os.environ['PATH']),
                       ('THISIS', os.environ['HOME'] + '/a/test'),
                       ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    # Test the function
    for key, value in parse_env_file_contents(lines):
        assert (key, value) in expected_values

# Generated at 2022-06-24 02:25:39.603722
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_result = collections.OrderedDict([
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    assert list(parse_env_file_contents(lines)) == list(expected_result.items())



# Generated at 2022-06-24 02:25:49.744652
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def assert_env(lines, expected):
        assert list(parse_env_file_contents(lines.strip().splitlines())) == expected

    assert_env('', [])
    assert_env('TEST=yeee', [('TEST', 'yeee')])
    assert_env('TEST = yeee', [('TEST', 'yeee')])
    assert_env('TEST= yeee', [('TEST', 'yeee')])
    assert_env('TEST =yeee', [('TEST', 'yeee')])
    assert_env('TEST = yeee', [('TEST', 'yeee')])
    assert_env('TEST=yeee ', [('TEST', 'yeee')])

# Generated at 2022-06-24 02:25:54.055186
# Unit test for function expand
def test_expand():
    """
    >>> expand('${CWD}/test')
    '.../test'
    >>> expand('~/test')
    '.../test'
    >>> expand('${HOME}/test')
    '.../test'
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:26:03.590387
# Unit test for function expand
def test_expand():
    path_file_home = '${PATH}/${HOME}'
    path_file_home_va = expand(path_file_home)

    assert path_file_home_va != path_file_home
    assert path_file_home_va != '${PATH}/${HOME}'



# Generated at 2022-06-24 02:26:09.348538
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    x = load_env_file(lines, write_environ=dict())
    assert x.keys() == lines



# Generated at 2022-06-24 02:26:16.685602
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    vals = load_env_file(lines, write_environ=dict())
    assert vals == collections.OrderedDict([('TEST', '.../yeee'),
                                            ('THISIS', '.../a/test'),
                                            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-24 02:26:17.874174
# Unit test for function expand
def test_expand():
    home = os.environ["HOME"]
    assert expand("$HOME") == home
    assert expand("~") == home

# Generated at 2022-06-24 02:26:22.012614
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    l = """
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """
    assert dict(parse_env_file_contents(l.splitlines())) == dict(TEST='${HOME}/yeee',
                                                                 THISIS='~/a/test',
                                                                 YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:26:30.744344
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
             'MULTILINE="a\\nb\\nc"', "QUOTED='a'"]
    os.environ.clear()

    filename = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'fixtures', '.env')

    results = load_env_file(lines, write_environ=dict())
    from copy import deepcopy
    import json

    print(json.dumps(results, indent=4))


# Generated at 2022-06-24 02:26:37.480022
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    ret = parse_env_file_contents(lines)

    expected = {"TEST", "THISIS", "YOLO"}
    assert {pair[0] for pair in ret} == expected


if __name__ == "__main__":
    import pytest

    pytest.main(["-v", __file__])

# Generated at 2022-06-24 02:26:46.173473
# Unit test for function load_env_file

# Generated at 2022-06-24 02:26:54.338500
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from nose.tools import assert_equal

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed_env_file_contents = list(parse_env_file_contents(lines))
    expected_parsed_env_file_contents = [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert_equal(parsed_env_file_contents, expected_parsed_env_file_contents)

    # Unit test for function load

# Generated at 2022-06-24 02:26:58.663157
# Unit test for function expand
def test_expand():
    values = [
        ('${HOME}', os.environ['HOME']),
        ('~', os.environ['HOME']),
        ('~/test', os.environ['HOME'] + '/test'),
        ('${TEST}', '${TEST}'),
        ('"~/test"', os.environ['HOME'] + '/test'),
    ]

    for given, expected in values:
        assert expand(given) == expected



# Generated at 2022-06-24 02:27:01.174504
# Unit test for function expand
def test_expand():
    test_str = '${HOME}${PATH}'
    res = expand(test_str)
    assert res == "%s%s" % (os.environ["HOME"].replace("\\", "/"), os.environ["PATH"].replace("\\", "/"))

# Generated at 2022-06-24 02:27:11.059344
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert next(parse_env_file_contents(['TEST=$HOME/yeee'])) == ('TEST', '.../yeee')
    assert next(parse_env_file_contents(['TEST=$HOME/yeee-$PATH'])) == ('TEST', '.../yeee-...:...')
    assert next(parse_env_file_contents(['TEST=~/yeee-$PATH'])) == ('TEST', '.../yeee-...:...')
    assert next(parse_env_file_contents(['TEST~/yeee-$PATH'])) == ('TEST', '.../yeee-...:...')


# Generated at 2022-06-24 02:27:15.353672
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("$TEST") == os.path.expandvars("$TEST")
    assert expand("~/test") == os.path.expanduser("~/test")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:27:26.499573
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]

    result = load_env_file(lines)

    assert isinstance(result, collections.OrderedDict)
    assert result.keys() == [
        'TEST',
        'THISIS',
        'YOLO'
    ]

    assert result.values() == [
        expand('${HOME}/yeee'),
        expand('~/a/test'),
        expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    ]

# Generated at 2022-06-24 02:27:30.693925
# Unit test for function expand
def test_expand():

    with pytest.raises(FileNotFoundError):
        os.environ['TEST_ENV_NOT_SET'] = '~/tmp/does_not_exist'

    assert expand('~/tmp/does_not_exist') == '~/tmp/does_not_exist'

    assert 'TEST_ENV_NOT_SET' not in os.environ



# Generated at 2022-06-24 02:27:36.975565
# Unit test for function expand
def test_expand():
    # Test that function expand expands ~ and $ variables
    os.environ['TEST'] = 'True'
    os.environ['TEST2'] = 'False'
    os.environ['HOME'] = os.path.expanduser('~')
    os.environ['PATH'] = '{}:'.format(os.path.abspath(os.getcwd()))
    res1 = expand('~')
    res2 = expand('$TEST')
    res3 = expand('${TEST2}')
    res4 = expand('$PATH')
    assert res1 == os.path.expanduser('~')
    assert res2 == 'True'
    assert res3 == 'False'
    assert res4 == os.environ['PATH']



# Generated at 2022-06-24 02:27:43.010498
# Unit test for function expand
def test_expand():
    this_file_dir = os.path.dirname(os.path.abspath(__file__))

    assert expand('~') == os.path.expanduser('~')
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand(os.path.join(this_file_dir, '~')) == os.path.join(this_file_dir, '~')



# Generated at 2022-06-24 02:27:49.126837
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:27:53.837223
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:27:58.684308
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('~/swaggins') == os.path.expanduser('~/swaggins')
    assert expand('~/swaggins/') == os.path.expanduser('~/swaggins/')

    assert expand('/var/log') == expand('/var/log')



# Generated at 2022-06-24 02:27:59.887096
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:28:11.432690
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_dict = load_env_file(lines, write_environ=dict())

    assert 'TEST' in env_dict
    assert 'THISIS' in env_dict
    assert 'YOLO' in env_dict

    assert env_dict['TEST'].endswith('/yeee')
    assert env_dict['THISIS'].endswith('/a/test')
    assert env_dict['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:28:19.022484
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    d = collections.OrderedDict(parse_env_file_contents(lines))
    assert len(d) == 3



# Generated at 2022-06-24 02:28:27.137417
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    first = parse_env_file_contents(lines)
    assert next(first) == ('TEST', '.../yeee')
    assert next(first) == ('THISIS', '.../a/test')
    assert next(first) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:28:35.082481
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import shutil
    import os

    fd, filename = tempfile.mkstemp(suffix='.txt')
    os.close(fd)

    with open(filename, 'w') as fp:
        fp.write('TEST=${HOME}/yeee-$PATH\n')
        fp.write('THISIS=~/a/test\n')
        fp.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')


# Generated at 2022-06-24 02:28:38.916414
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.run_docstring_examples(load_env_file, globals(), verbose=True)



# Generated at 2022-06-24 02:28:45.948165
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand('${HOME}/test') == os.path.expandvars('${HOME}/test')
    assert expand('~/test/${HOME}') == os.path.expandvars(os.path.expanduser('~/test/${HOME}'))



# Generated at 2022-06-24 02:28:54.437371
# Unit test for function load_env_file
def test_load_env_file():
    from unittest.mock import patch
    from unittest import TestCase

    class TestLoad(TestCase):
        def test_reads_env_file(self):
            test_text = '''
            TEST=${HOME}/yeee-$PATH
            THISIS=~/a/test
            YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
            '''


# Generated at 2022-06-24 02:28:57.698566
# Unit test for function expand
def test_expand():
    assert expand("") == ""
    assert expand("${PATH}") == expand("${PATH}")
    assert expand("~") == expand("~")



# Generated at 2022-06-24 02:29:05.533794
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Unit test for function parse_env_file_contents."""
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee-${PATH}", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [("TEST", "{}/yeee-{}".format(expand("~"), expand("$PATH"))), ("THISIS", expand("~/a/test")), ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))]



# Generated at 2022-06-24 02:29:08.163405
# Unit test for function expand
def test_expand():
    assert expand('$FOO') == ''
    assert expand('~') == os.path.expanduser('~')

# Generated at 2022-06-24 02:29:14.680528
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        "TEST=/var/www/$PORT",
        "YOLO=/var/www/blabla",
        "PORT=1234",
    ]
    environ = load_env_file(lines, write_environ=dict())

    assert environ == collections.OrderedDict([
        ("TEST", "/var/www/1234"),
        ("YOLO", "/var/www/blabla"),
        ("PORT", "1234"),
    ])

# Generated at 2022-06-24 02:29:18.146456
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:29:29.632878
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([]) == collections.OrderedDict()

    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == \
        collections.OrderedDict([('TEST', os.environ['HOME'] + '/yeee-' + os.environ['PATH']),
                                 ('THISIS', os.environ['HOME'] + '/a/test'),
                                 ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-24 02:29:31.753225
# Unit test for function expand
def test_expand():
    assert expand("~/a/b/c") == os.path.expanduser("~/a/b/c")
    assert expand("${HOME}/a/b/c") == os.path.expandvars("${HOME}/a/b/c")



# Generated at 2022-06-24 02:29:41.987504
# Unit test for function load_env_file
def test_load_env_file():
    from .constants import TEST_ENVIRONMENT_FILE_PATH

    with open(TEST_ENVIRONMENT_FILE_PATH) as file_:
        lines = file_.readlines()

    environ = load_env_file(lines, write_environ=dict())

    assert 'TEST_VARIABLE' in environ

    # Test that line comments are ignored
    assert '#' not in environ
    assert 'COMMENT' not in environ
    assert 'COMMENT_2' not in environ

    # Make sure raw strings are interpreted correctly
    assert 'RAW_STRING' in environ
    assert '\\' not in environ['RAW_STRING']
    assert '"' not in environ['RAW_STRING']
    assert ' ' in environ['RAW_STRING']
    assert 'Y'

# Generated at 2022-06-24 02:29:46.235284
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("~") == os.path.expanduser("~")

