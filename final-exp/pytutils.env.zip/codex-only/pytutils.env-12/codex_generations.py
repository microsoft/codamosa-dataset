

# Generated at 2022-06-24 02:19:53.330781
# Unit test for function expand
def test_expand():
    environ = {
        'HOME': '/home/me',
        'PATH': '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/snap/bin'
    }

    cases = [
        ('~/yeee-$PATH', '/home/me/yeee-{path}'.format(**environ)),
        ('${HOME}/yeee-$PATH', '/home/me/yeee-{path}'.format(**environ)),
        ('~/a/test', '/home/me/a/test'),
        ('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', '/home/me/swaggins/')
    ]


# Generated at 2022-06-24 02:19:57.911344
# Unit test for function expand
def test_expand():
    tests = {
        '~': os.environ["HOME"],
        '$HOME/a': os.environ["HOME"] + '/a',
    }

    for (key, value) in tests.items():
        assert expand(key) == value

# Generated at 2022-06-24 02:20:05.748913
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    for file, env in [('tests/.env_test.env', {
        'TEST': '/tmp/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    })]:
        with open(file) as fp:
            lines = fp.readlines()

        res = parse_env_file_contents(lines)

        entries = collections.OrderedDict(res)

        assert entries == env

# Generated at 2022-06-24 02:20:16.182125
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import builtins

    if not hasattr(builtins, 'FileNotFoundError'):  # Python 2
        builtins.FileNotFoundError = IOError


# Generated at 2022-06-24 02:20:24.768603
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=None)
    assert changes == collections.OrderedDict([('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-24 02:20:35.772905
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_contents = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    el = parse_env_file_contents(env_contents)

    assert next(el) == ('TEST', os.path.expanduser('~/yeee'))
    assert next(el) == ('THISIS', os.path.expanduser('~/a/test'))
    assert next(el) == ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    with pytest.raises(StopIteration) as e:
        next(el)



# Generated at 2022-06-24 02:20:47.602516
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([], write_environ=None) == collections.OrderedDict()
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ=None) == collections.OrderedDict([('TEST', os.path.expanduser('~/') + '/yeee-') + os.environ.get('PATH', ''), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

# Generated at 2022-06-24 02:20:56.104935
# Unit test for function expand
def test_expand():
    os.environ["YO"] = "my_thing"
    os.environ["HOME"] = "my_home"
    assert (expand("$YO") == "my_thing")
    assert (expand("${HOME}") == "my_home")
    assert (expand("~/test") == "my_home/test")
    assert (expand("${HOME}/test") == "my_home/test")

# Generated at 2022-06-24 02:21:01.953711
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')

    os.environ['PATH'] = '/path1/path2'
    assert expand('${PATH}') == '/path1/path2'



# Generated at 2022-06-24 02:21:10.857714
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    s = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """

    values = parse_env_file_contents((line.strip() for line in s.splitlines()))

    assert next(values) == ('TEST', '.../yeee')
    assert next(values) == ('THISIS', '.../a/test')
    assert next(values) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:21:18.109531
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file_result = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    load_env_file_expected = collections.OrderedDict([('TEST', expand('${HOME}/yeee-$PATH')), ('THISIS', expand('~/a/test')), ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])
    assert load_env_file_result == load_env_file_expected

# Generated at 2022-06-24 02:21:19.503748
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:28.068775
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    actual = parse_env_file_contents(lines)
    expected = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert list(actual) == expected



# Generated at 2022-06-24 02:21:30.855092
# Unit test for function expand
def test_expand():
    # Create a str with Unix-like path
    val = '~/yeee'
    assert expand(val) == os.path.expanduser('~/yeee')

    # Create a str with Windows-like path
    val = '%USERPROFILE%/yeee'
    assert expand(val) == os.path.expandvars('%USERPROFILE%/yeee')



# Generated at 2022-06-24 02:21:35.043214
# Unit test for function expand
def test_expand():
    assert expand("$HOME/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.expanduser("~/test")



# Generated at 2022-06-24 02:21:41.450638
# Unit test for function expand
def test_expand():

    # exapnds a single variable
    assert expand('$HOME') == os.environ['HOME']

    # expands mulitple variables
    test = '${HOME}/yeee-$PATH'
    result = expand(test)
    assert result == test.replace('$HOME', os.environ['HOME']).replace('$PATH', os.environ['PATH'])

    # expands variables and tildes
    test = '~/test/${HOME}'
    result = expand(test)
    assert result == test.replace('$HOME', os.environ['HOME']).replace('~', os.environ['HOME'])


# Unit tests for function load_env_file

# Generated at 2022-06-24 02:21:49.976022
# Unit test for function expand
def test_expand():
    home = os.path.expanduser('~')
    assert expand(f'~/foo') == os.path.join(home, 'foo')
    assert expand(f'/foo/$HOME/bar') == os.path.join('/foo', home, 'bar')


"""
    env_file_content = """

# Generated at 2022-06-24 02:21:54.612980
# Unit test for function expand
def test_expand():
    assert expand('$TEST/aa') == os.path.expandvars('$TEST/aa')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:22:00.408350
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


# If module is run stand-alone, run unit tests
if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:22:08.191396
# Unit test for function expand
def test_expand():
    e = os.environ
    empty: typing.Mapping[str, str]
    empty = {}

    # Basic
    assert expand("~") == os.path.expanduser("~")
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("${HOME}") == os.path.expandvars("${HOME}")
    assert expand("~/$HOME") == os.path.expandvars("${HOME}")
    assert expand("~/$HOME") == os.path.expanduser("~") + os.path.expandvars("${HOME}")

    # Both
    assert expand("~/$HOME") == os.path.expanduser("~") + os.path.expandvars("${HOME}")

    # Nonexistent variable

# Generated at 2022-06-24 02:22:19.163099
# Unit test for function load_env_file
def test_load_env_file():
    import sys

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    result = load_env_file(lines, environ)
    assert environ == result
    assert len(result) == 3
    assert result['TEST'] == '{}/yeee-{}'.format(os.path.expanduser('~'), os.getenv('PATH'))
    assert result['THISIS'] == os.path.expanduser('~/a/test')

# Generated at 2022-06-24 02:22:25.950614
# Unit test for function load_env_file
def test_load_env_file():
    test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    load_env_file(test_lines, environ)

    expected = ['TEST', 'THISIS', 'YOLO']

    assert all(k in expected for k in environ.keys())



# Generated at 2022-06-24 02:22:35.158901
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [
        ("TEST", "${HOME}/yeee-$PATH"),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    ]


# Generated at 2022-06-24 02:22:44.628893
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Parse the sample lines
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    # Check the returned values
    assert list(values) == [('TEST', '${HOME}/yeee'),
                            ('THISIS', '~/a/test'),
                            ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:22:49.044220
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:22:53.987930
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.run_docstring_examples(load_env_file, globals(), True)

# Generated at 2022-06-24 02:23:01.141938
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        with open(os.path.join(temp_dir, '.bashrc'), 'w') as f:
            f.write('export TEST="${HOME}/yeee-$PATH"')
            f.write('export THISIS=~/a/test')
            f.write('export YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

        load_env_file(open(os.path.join(temp_dir, '.bashrc')), write_environ=dict())

    finally:
        shutil.rmtree(temp_dir)


if __name__ == '__main__':
    import doctest
    doctest.testmod

# Generated at 2022-06-24 02:23:08.407271
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        "THISIS='~/a/test'",
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    values = parse_env_file_contents(lines)

    assert list(values) == [
        ('TEST', '.../.../yeee-$PATH'),
        ("THISIS", "~/a/test"),
        ("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]



# Generated at 2022-06-24 02:23:11.060711
# Unit test for function load_env_file
def test_load_env_file():
    print(load_env_file(["YOLO=${HOME}/yeee"]))
    print('\nDone\n')



# Generated at 2022-06-24 02:23:19.402921
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('~') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('${HOME}/test') == os.path.expanduser('~/test')
    assert expand('${PWD}') == os.path.expanduser(os.getcwd())
    assert expand('${PWD}/test') == os.path.expanduser(os.getcwd() + '/test')


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-24 02:23:28.463773
# Unit test for function load_env_file
def test_load_env_file():
    import sys

    test_lines = [
        'HOME=/home/user',
        'PATH=/bin:/usr/bin:/usr/local/bin',
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'UNSETTEST=${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}/yeee',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'STRIPTEST=a/b/c/',
    ]

    python_bin = os.path.abspath(sys.executable)


# Generated at 2022-06-24 02:23:38.713999
# Unit test for function load_env_file
def test_load_env_file():
    import inspect as _inspect
    frame = _inspect.currentframe()

    if frame is not None:
        frame = frame.f_back
    if frame is not None:
        ns = frame.f_globals

    f = open(__file__, 'r')
    f.seek(0)

    lines = f.readlines()
    lines = lines[lines.index('    # Unit test for function load_env_file\n') + 1:]
    assert list(lines) == test_load_env_file.__doc__.splitlines()[3:]

    load_env_file(lines)
    assert ns['load_env_file'].__doc__ == load_env_file.__doc__
    assert ns['parse_env_file_contents'].__doc__ == parse_env_file_contents

# Generated at 2022-06-24 02:23:45.943958
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines, write_environ=dict())

    assert environ['TEST'] == os.environ.get('HOME') + '/yeee'
    assert environ['THISIS'] == os.environ.get('HOME') + '/a/test'
    assert environ['YOLO'] == os.environ.get('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:23:50.725357
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:24:00.671240
# Unit test for function expand
def test_expand():
    # Test expand
    os.environ['TESTENV'] = 'test'
    curdir = os.getcwd()

    os.chdir('/tmp')

    os.environ['HOME'] = os.path.expanduser('~')

    assert expand('$TESTENV') == 'test'

    assert expand('${HOME}/test') == os.environ['HOME'] + '/test'

    assert expand('~/test') == os.environ['HOME'] + '/test'

    assert expand('~') == os.environ['HOME']

    os.chdir(curdir)

    # Cleanup
    del os.environ['TESTENV']



# Generated at 2022-06-24 02:24:10.920557
# Unit test for function load_env_file
def test_load_env_file():
    # Arrange
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    # Act
    changes = load_env_file(lines, write_environ=dict())

    # Assert

# Generated at 2022-06-24 02:24:22.051000
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile

    env_file_path = tempfile.mkstemp()[1]

    with open(env_file_path, "w") as f:
        f.write("""
HOME=${HOME}/yeee-$PATH
EXPORT=$PATH
# This is a comment
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
YOLO2='$PATH'
YOLO3="$HOME"
""")

    with open(env_file_path) as f:
        lines = f.readlines()

    # Dictionary without variable expansion or variable replacement.
    d1 = dict(parse_env_file_contents(lines))

    # Dictionary with variable expansion.

# Generated at 2022-06-24 02:24:30.015422
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_str = """\
# This is a comment.
TEST=${HOME}/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    assert parse_env_file_contents(env_str.splitlines()) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-24 02:24:33.323846
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('${HOME}/test') == os.path.expandvars('${HOME}/test')



# Generated at 2022-06-24 02:24:39.452798
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'foo'
    home = expand('~')

    assert expand('$TEST') == 'foo'
    assert expand('${TEST}') == 'foo'
    assert expand('~/test') == os.path.join(home, 'test')
    assert expand('~/$TEST') == os.path.join(home, 'foo')



# Generated at 2022-06-24 02:24:49.990667
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': f'{os.path.expandvars("$HOME")}/yeee-{os.path.expandvars("$PATH")}', 'THISIS': os.path.expandvars('~/a/test'), 'YOLO': os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}



# Generated at 2022-06-24 02:24:59.774025
# Unit test for function load_env_file
def test_load_env_file():
    # noinspection PyTypeChecker
    assert load_env_file(lines=None) is None
    # noinspection PyTypeChecker
    assert load_env_file(lines=[]) is None
    assert load_env_file(lines=['TEST=${HOME}/yeee']) == {'TEST': '~/yeee'}
    assert load_env_file(lines=['THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == {
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }

# Generated at 2022-06-24 02:25:00.697340
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:25:07.254747
# Unit test for function load_env_file

# Generated at 2022-06-24 02:25:13.245018
# Unit test for function expand
def test_expand():
    assert expand('~/yolo') == os.environ['HOME'] + '/yolo'
    assert expand('~') == os.environ['HOME']
    assert expand('${HOME}/yolo') == os.environ['HOME'] + '/yolo'
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('~/swa') == os.environ['HOME'] + '/swa'

# Generated at 2022-06-24 02:25:21.596060
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "yolo"

    os.environ["HOME"] = "/home/user"
    os.environ["PATH"] = "/bin:/usr/bin"
    os.environ["LD_LIBRARY_PATH"] = "/usr/lib:/usr/local/lib"

    assert expand("$TEST") == "yolo"

    assert expand("$PATH") == "/bin:/usr/bin"
    assert expand("$PATH:$HOME") == "/bin:/usr/bin:/home/user"

    assert expand("$HOME") == "/home/user"
    assert expand("$HOME/test") == "/home/user/test"

    assert expand("~/test") == "/home/user/test"

# Generated at 2022-06-24 02:25:29.047744
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # With all valid lines
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    # With a non-valid line
    lines = ['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST', 'ThisIsNotValid']

# Generated at 2022-06-24 02:25:40.117454
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import os
    import os.path

    # Now, within the test case, do as though we are using this file as a program.
    print(os.path.expanduser('~'))
    sys.path.insert(0, os.path.abspath('.'))

    from hark.entries import env_file

    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = env_file.load_env_file(lines, write_environ=dict())

    import collections

    assert isinstance(result, collections.OrderedDict)
    assert len(result) == 3

# Generated at 2022-06-24 02:25:42.821415
# Unit test for function expand
def test_expand():
    expected = "/etc/orange/something"
    input_val = "$ORANGE_CONF/something"
    os.environ["ORANGE_CONF"] = "/etc/orange"
    assert expected == expand(input_val)



# Generated at 2022-06-24 02:25:52.267910
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:25:54.845960
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'value'
    assert expand('$TEST') == 'value'
    assert expand('${TEST}') == 'value'
    assert expand('$TEST') == 'value'



# Generated at 2022-06-24 02:26:09.076966
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    line = "TEST=${HOME}/yeee"
    assert list(parse_env_file_contents([line])) == [("TEST", "~/yeee")]

    line = "THISIS=~/a/test"
    assert list(parse_env_file_contents([line])) == [("THISIS", "~/a/test")]

    line = "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    assert list(parse_env_file_contents([line])) == [("YOLO", "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]

    line1 = "TEST=${HOME}/yeee-$PATH"
    line2

# Generated at 2022-06-24 02:26:13.017117
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('${HOME}/test') == os.path.expandvars('${HOME}/test')
    assert expand('${HOME}/test') != os.path.expanduser('${HOME}/test')



# Generated at 2022-06-24 02:26:21.406753
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

# Generated at 2022-06-24 02:26:30.685184
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    inputs = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    outputs = parse_env_file_contents(inputs)
    for key, value in outputs:
        if key == 'TEST':
            assert value == os.path.expandvars('${HOME}/yeee-$PATH')
        if key == 'THISIS':
            assert value == os.path.expandvars('~/a/test')
        if key == 'YOLO':
            assert value == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:26:38.769182
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 02:26:46.624967
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert list(values) == [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:26:53.301661
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Using a list so we can test order
    result = list(parse_env_file_contents(lines))

    assert result == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-24 02:27:06.609158
# Unit test for function load_env_file
def test_load_env_file():
    # Test code
    import sys

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected_output = collections.OrderedDict(
        [
            ("TEST", expand("${HOME}/yeee-$PATH")),
            ("THISIS", expand("~/a/test")),
            ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
        ]
    )
    actual_output = load_env_file(lines, write_environ=dict())

    assert expected_output == actual_output



# Generated at 2022-06-24 02:27:14.567754
# Unit test for function expand
def test_expand():
    os.environ["TEST1"] = "test1"
    os.environ["TEST2"] = "test2_${TEST1}_test2"

    assert expand("${TEST2}") == "test2_test1_test2"
    assert expand("~/test") == os.path.expanduser("~") + "/test"
    assert expand("$TEST1") == "test1"
    assert expand("$TEST_NOEXPR") == "$TEST_NOEXPR"



# Generated at 2022-06-24 02:27:18.398571
# Unit test for function expand
def test_expand():
    HOME = os.environ['HOME']
    cwd = os.getcwd()
    assert expand(f'~/test') == os.path.join(HOME, 'test')
    assert expand(cwd) == os.path.abspath(cwd)
    assert expand(f'${HOME}/test') == os.path.join(HOME, 'test')



# Generated at 2022-06-24 02:27:21.842889
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    import sys

    return doctest.testmod(sys.modules[__name__])


if __name__ == '__main__':
    import sys

    sys.exit(test_load_env_file()[0])

# Generated at 2022-06-24 02:27:32.272369
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert load_env_file(lines, write_environ=dict()) == \
        collections.OrderedDict([('TEST', os.path.join(os.environ['HOME'], 'yeee')),
                                 ('THISIS', os.path.join(os.environ['HOME'], 'a/test')),
                                 ('YOLO', os.path.join(os.environ['HOME'], 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])



# Generated at 2022-06-24 02:27:44.000677
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # create temp file
    with tempfile.NamedTemporaryFile('w+t') as env_file:
        env_file.write('TEST=${HOME}/yeee-$PATH\n')
        env_file.write('THISIS=~/a/test\n')
        env_file.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
        env_file.flush()

        with open(env_file.name) as f:
            lines = f.readlines()

        keys, values = zip(*parse_env_file_contents(lines))

        assert keys == ('TEST', 'THISIS', 'YOLO')

# Generated at 2022-06-24 02:27:48.668104
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expandvars('$HOME')
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-24 02:27:57.220305
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test']) == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
    ])


# Generated at 2022-06-24 02:28:06.991564
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = {}

    assert load_env_file(lines, environ) == collections.OrderedDict(
        [
            ('TEST', '%s/yeee' % os.path.expanduser("~")),
            ('THISIS', os.path.expanduser("~") + "/a/test"),
            ('YOLO', '%s/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' % os.path.expanduser("~"))
        ]
    )

    assert 'TEST' in environ

# Generated at 2022-06-24 02:28:14.982797
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import shutil
    import os

    d = tempfile.mkdtemp()


# Generated at 2022-06-24 02:28:25.259388
# Unit test for function expand
def test_expand():
    os.environ["test"] = "testvar"
    os.environ["test2"] = "testvar2"

    assert expand("test") == "test"

    assert expand("$test") == "testvar"
    assert expand("${test}") == "testvar"

    assert expand("$test $test2") == "testvar testvar2"
    assert expand("${test}${test2}") == "testvar2"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:28:37.409240
# Unit test for function expand

# Generated at 2022-06-24 02:28:39.915719
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:28:50.932233
# Unit test for function expand
def test_expand():
    assert expand('/some/file') == os.path.expanduser(os.path.expandvars('/some/file'))
    assert expand('./some/file') == os.path.expanduser(os.path.expandvars('./some/file'))
    assert expand('${HOME}/some/file') == os.path.expanduser(os.path.expandvars('${HOME}/some/file'))
    assert expand('~/some/file') == os.path.expanduser(os.path.expandvars('~/some/file'))
    assert expand('${HOME}') == os.path.expanduser(os.path.expandvars('${HOME}'))

# Generated at 2022-06-24 02:28:52.015863
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:29:03.627550
# Unit test for function expand
def test_expand():
    class mock_os_path:
        def __init__(self) -> None:
            self.calls = 0

        def expanduser(self, p: str) -> str:
            self.calls += 1
            return "expanduser({})".format(p)

        def expandvars(self, p: str) -> str:
            self.calls += 1
            return "expandvars({})".format(p)

    class mock_os:
        def __init__(self) -> None:
            self.path = mock_os_path()

    test_os = mock_os()
    os.environ["TEST1"] = "test1"
    os.environ["TEST2"] = "test2"

    # Test that variables are expanded

# Generated at 2022-06-24 02:29:12.357417
# Unit test for function expand
def test_expand():
    # test start with $ sign
    path = '~/'
    res = expand(path)
    assert res == '.../'

    path = '$HOME'
    res = expand(path)
    assert res == '.../'

    path = '/bin/'
    res = expand(path)
    assert res == '/bin/'

    path = '~/'
    res = expand(path)
    assert res == '.../'

    return


test_expand()


# Generated at 2022-06-24 02:29:16.549536
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(extraglobs={'HOME': os.path.join('/', 'home', 'ralph')})


if __name__ == '__main__':
    import doctest

    doctest.testmod(extraglobs={'HOME': os.path.join('/', 'home', 'ralph')})

# Generated at 2022-06-24 02:29:28.152505
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"],
                         write_environ=dict()) == collections.OrderedDict([('TEST',
                                                                            '.../.../yeee-...:...'),
                                                                           ('THISIS',
                                                                            '.../a/test'),
                                                                           ('YOLO',
                                                                            '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert load_env_file([], write_environ=dict()) == collections.OrderedDict()



# Generated at 2022-06-24 02:29:38.833541
# Unit test for function expand
def test_expand():
    os.environ['FOO'] = 'BAR'
    os.environ['PATH'] = '1:2'
    os.environ['HOME'] = '3'
    home_dir = os.path.expanduser('~')
    assert expand('$FOO:$PATH:$HOME') == 'BAR:1:2:3'
    assert expand('${FOO}:${PATH}:${HOME}') == 'BAR:1:2:3'
    assert expand(home_dir) == home_dir



# Generated at 2022-06-24 02:29:42.400800
# Unit test for function expand
def test_expand():
    v = '$HOME/test'
    assert expand(v) == os.path.join(os.environ['HOME'], 'test')

    v = '~/test'
    assert expand(v) == os.path.join(os.environ['HOME'], 'test')



# Generated at 2022-06-24 02:29:44.358476
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()