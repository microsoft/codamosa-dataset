

# Generated at 2022-06-24 02:19:49.319927
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")

    os.environ['test_expand'] = 'abc'
    assert expand("$test_expand") == 'abc'


if __name__ == '__main__':
    import warnings
    warnings.simplefilter("ignore")
    import doctest
    doctest.testmod()

    test_expand()

# Generated at 2022-06-24 02:20:00.354077
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Create a temporary environment file (in a temporary directory)
    with tempfile.TemporaryDirectory() as tmp_dir:
        filename = os.path.join(tmp_dir, "env_file")

        with open(filename, "w") as f:
            f.write('TEST=${HOME}/yeee-$PATH\n')
            f.write('THISIS=~/a/test\n')
            f.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

        # Read the environment file to be parsed
        with open(filename, "r") as f:
            data = f.read()

        # Parse the environment file
        with patch.dict('os.environ', {"HOME": "...", "PATH": "..."}):
            env

# Generated at 2022-06-24 02:20:08.291298
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_file_content = '''
    # comment
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    #OTHER=${TEST}/a
    '''
    env_file_content = env_file_content.splitlines()
    env_file_content = [line.strip() for line in env_file_content]
    env_file_content = [line for line in env_file_content if line and not line.startswith('#')]
    actual = parse_env_file_contents(env_file_content)
    actual = list(actual)

# Generated at 2022-06-24 02:20:15.379377
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())

    expected = collections.OrderedDict()
    expected['TEST'] = os.path.expanduser(os.path.expandvars('${HOME}/yeee-$PATH'))
    expected['THISIS'] = os.path.expanduser(os.path.expandvars('~/a/test'))

# Generated at 2022-06-24 02:20:22.235579
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_env')
    with open(filename) as fd:
        envs = load_env_file(fd)

    assert envs == {'TEST': '1', 'HOME': '/home/arbiter', 'PATH': 'local:/bin:/usr/bin'}

# Generated at 2022-06-24 02:20:29.842309
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee-{PATH}',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    f = parse_env_file_contents(lines)
    for k, v in f:
        assert isinstance(k, str)
        assert isinstance(v, str)



# Generated at 2022-06-24 02:20:37.782804
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir_path:
        tmp_file_path = Path(tmp_dir_path) / "a_file.env"
        tmp_file_path.write_text("""
# this is a comment
A=B
C=D
export E=F
        """)
        assert set(parse_env_file_contents(open(tmp_file_path))) == {("A", "B"), ("C", "D"), ("E", "F")}

# Generated at 2022-06-24 02:20:44.312824
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:20:48.895754
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.environ.get("HOME")
    assert expand("${HOME}") == os.environ.get("HOME")
    assert expand("${HOME}/") == os.environ.get("HOME") + "/"

# Generated at 2022-06-24 02:20:54.883357
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = "test"
    os.environ['TEST2'] = "$TEST"

    assert expand('$TEST2') == "test" # os.path.expanduser works
    assert expand('~/test') == os.path.expanduser('~/test') # os.path.expanduser works
    assert expand('~/test') == os.path.expanduser('~/test') # os.path.expanduser works

    # os.path.expandvars works
    assert expand('${TEST2}') == "test"
    assert expand('${TEST3}') == "${TEST3}"
    assert expand('${TEST3}') == "${TEST3}"

    # Recursive expansion works
    assert expand('$TEST2') == "test"


# Generated at 2022-06-24 02:21:00.314392
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO

    # Load env file from file object
    file_object_lines = """
    TEST=$PATH
    THISIS=$FOO/bar
    """
    file_object = StringIO(file_object_lines)
    env = load_env_file(file_object, write_environ=dict())

    assert isinstance(env, collections.OrderedDict)
    assert len(env) == 3

    assert "TEST" in env
    assert "THISIS" in env
    assert "FOO" in env

    assert env["TEST"] == ":".join([os.getcwd(), os.getcwd()])
    assert env["THISIS"] == "$FOO/bar"



# Generated at 2022-06-24 02:21:08.141327
# Unit test for function expand
def test_expand():
    try:
        assert os.environ['TEST'] == 'abcd'
    except KeyError:
        os.environ['TEST'] = 'abcd'

    test_str_1 = '$TEST'
    test_str_2 = '$TEST/efgh'
    test_str_3 = '$NOT_PRESENT'
    test_str_4 = '$NOT_PRESENT/efgh'

    assert expand(test_str_1) == 'abcd'
    assert expand(test_str_2) == 'abcd/efgh'
    assert expand(test_str_3) == '$NOT_PRESENT'
    assert expand(test_str_4) == '$NOT_PRESENT/efgh'

# Generated at 2022-06-24 02:21:18.553882
# Unit test for function load_env_file
def test_load_env_file():
    import sys

    path = [sys.prefix]
    if sys.real_prefix != sys.prefix:
        path.insert(0, sys.real_prefix)

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ={})


# Generated at 2022-06-24 02:21:26.582448
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import sys
    from contextlib import contextmanager

    @contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, io.StringIO()
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out

    with capture(load_env_file,
                 ['HELLO=its_a_me_mario', 'MAXN=1']) as out:
        print(f'os.environ: {dict(os.environ)}')
        assert 'HELLO=its_a_me_mario' in out
        assert 'MAXN=1' in out


# Generated at 2022-06-24 02:21:31.255392
# Unit test for function expand
def test_expand():
    assert os.path.exists(expand('~/'))

    val = '$HOME/.bashrc'
    val_expanded = expand(val)
    assert os.path.exists(val_expanded)



# Generated at 2022-06-24 02:21:34.138959
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["A=1", "B=2", "C=3", "D=4", 'F="5\n"']

    parsed = parse_env_file_contents(lines)

    assert dict(parsed) == {"A": "1", "B": "2", "C": "3", "D": "4", "F": "5\n"}



# Generated at 2022-06-24 02:21:39.066856
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    print(result)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:21:51.194050
# Unit test for function expand

# Generated at 2022-06-24 02:21:58.917339
# Unit test for function expand
def test_expand():
    # Just test the expand function, we can trust the expanduser and expandvars functions
    home = expand('~/')
    assert home.startswith('/home') or home.startswith('/Users')
    assert expand('$HOME') == home

    # TEST for ~ username
    if home.startswith('/home'):
        username = 'root'
    else:
        username = os.getlogin()

    assert expand(f'~{username}') == home



# Generated at 2022-06-24 02:22:07.206492
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins",
        'TEST2="hello"',
        "TEST3=''",
        "TEST4=\"a$b\"",
        'TEST5="a$b\\\\c"',
        "TEST6='should not raise error'",
    ]
    f = io.StringIO("\n".join(lines))

    lines.append("TEST7=${HOME}/test7")
    lines.append("TEST8='this should be a single quote'")

    env_file_contents = lines
    output = parse_env_file_contents(env_file_contents)

# Generated at 2022-06-24 02:22:11.234308
# Unit test for function expand
def test_expand():
    if 'HOME' in os.environ:
        assert(expand('$HOME') == os.environ['HOME'])

    assert(expand('~') == os.environ['HOME'])

# Generated at 2022-06-24 02:22:16.258830
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:22:28.031757
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import sys

    test_data = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    expected_output = [
        ('TEST', expand(
            '${HOME}/yeee-$PATH')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ]

    # Unit test for function parse_env_file_contents
    parse_env_file_contents_got = parse_env_file_contents(test_data)

    #

# Generated at 2022-06-24 02:22:40.073548
# Unit test for function load_env_file
def test_load_env_file():
    assert list(load_env_file(['PATH=', 'FOO=bar']).keys()) == ['PATH', 'FOO']
    assert list(load_env_file(['FOO=']).keys()) == ['FOO']
    assert load_env_file(['FOO=bar'])['FOO'] == 'bar'
    assert load_env_file(['FOO="bar"'])['FOO'] == 'bar'
    assert load_env_file(['FOO="bar baz"'])['FOO'] == 'bar baz'
    assert load_env_file(['FOO="bar\" baz"'])['FOO'] == 'bar" baz'
    assert load_env_file(["FOO='bar\" baz'"])['FOO'] == 'bar" baz'
    assert load_env_file

# Generated at 2022-06-24 02:22:47.528774
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-24 02:22:53.672330
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path

    import pytest
    # NOTE: if this test fails, the env var '$HOME' may be set to a value not found on your system
    # get the value of env var '$HOME' or '/home/user' if not set
    home = os.getenv("HOME") or "/home/user"

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    variables = ["TEST", "THISIS", "YOLO"]

# Generated at 2022-06-24 02:22:57.263589
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['A=one', 'B=two']  # type: typing.List[str]
    environ = {}

    load_env_file(lines, write_environ=environ)

    if environ['A'] != 'one':
        raise AssertionError
    if environ['B'] != 'two':
        raise AssertionError

# Generated at 2022-06-24 02:23:03.383175
# Unit test for function expand
def test_expand():
    # Arrange
    x = "${HOME}/yeee"
    os.environ["HOME"] = "/test/test"
    expected = "/test/test/yeee"

    # Act
    actual = expand(x)

    # Assert
    assert expected == actual



# Generated at 2022-06-24 02:23:10.662181
# Unit test for function load_env_file
def test_load_env_file():

    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()

    changes = load_env_file(lines, write_environ=write_environ)

    assert len(changes) == 3
    assert len(write_environ) == 3
    assert changes['TEST'] == write_environ['TEST']
    assert changes['TEST'].startswith(os.path.expanduser('~'))
    assert changes['TEST'].endswith(':' + os.path.pathsep.join(os.environ['PATH'].split(os.path.pathsep)))
    assert changes['TEST']

# Generated at 2022-06-24 02:23:20.282131
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.splitlines()

    changes = parse_env_file_contents(lines)

    expected = """
        TEST=.../.../yeee-...:...
        THISIS=.../a/test
        YOLO=.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.splitlines()

    changes = [l.strip() for l in changes if l.strip()]
    expected = [l.strip() for l in expected if l.strip()]

    assert changes == expected



# Generated at 2022-06-24 02:23:22.787618
# Unit test for function expand
def test_expand():
    print("Testing expand")
    test_lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test"]
    test_changes = [
        ("TEST", os.path.expandvars(test_lines[0])),
        ("THISIS", os.path.expanduser(test_lines[1]))
    ]
    changes = parse_env_file_contents(test_lines)
    assert changes == test_changes



# Generated at 2022-06-24 02:23:31.915086
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content = """apples=123

YOLO=swag

# comment

LOL=foo

FOO=bar # this is a comment

# comment to skip

export SWAG=123

# comment to skip

DOG=cat

# comment to skip
"""
    lines = content.split("\n")
    res = parse_env_file_contents(lines)

    expected = [
        ("apples", "123"),
        ("YOLO", "swag"),
        ("LOL", "foo"),
        ("FOO", "bar"),
        ("SWAG", "123"),
        ("DOG", "cat"),
    ]

    assert expected == list(res)



# Generated at 2022-06-24 02:23:39.941258
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import unittest

    from . import test_parse_env_file_contents as test_parse_env_file_contents_ref

    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'NEED_TRAILING_NEWLINE=',
    ]

    class TestCase(unittest.TestCase):
        def test_parse_env_file_contents(self):
            lines_iter = io.StringIO('\n'.join(lines))


# Generated at 2022-06-24 02:23:44.673195
# Unit test for function expand
def test_expand():
    assert expand(r'\$HOME') == '$HOME'
    assert expand(r'\~/') == '~/'
    assert expand(r'\\~/') == '\\~/'
    assert expand(r'\$PATH') == '$PATH'
    assert expand(r'\$PATH$') == '$PATH$'
    assert expand(r'\~/bin') == '~/bin'

# Generated at 2022-06-24 02:23:57.041309
# Unit test for function expand
def test_expand():
    """
    Tests that all the env variables are properly expanded.

    >>> load_env_file(['TEST=$HOME/yeee-$PATH'])
    OrderedDict([('TEST', '.../yeee-...')])
    """
    vals = {
        'HOME': os.path.expanduser('~'),
        'PATH': os.environ['PATH'],
        'TEST': '/a/b/${PATH}:${HOME}/yeee-${PATH}',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }
    changes = load_env_file(vals.items())

# Generated at 2022-06-24 02:24:08.038590
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    filename = os.path.join(os.path.dirname(__file__), 'test_env')
    with open(filename) as fh:
        lines = fh.readlines()
    values = parse_env_file_contents(lines)
    result = collections.OrderedDict(values)
    expected = collections.OrderedDict(
        (('a', '1'),
         ('b', '2'),
         ('c', '3:{a-2}'),
         ('d', '4:{a-1}'),
         ('e', '5'),
         ('f', '6:{a-1}'),
         ('g', '7:{a-2}'),
         ('h', '8:{a-1}'),
         ('i', '9:{a-2}')))
    assert result == expected

# Generated at 2022-06-24 02:24:17.908226
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestCase(unittest.TestCase):
        lines: typing.List[str]
        changes: collections.OrderedDict

        def test_changes(self) -> None:
            for name, value in self.changes.items():
                self.assertIn(name, os.environ)
                self.assertRegex(value, "^.*/")
                if name == "USER":
                    self.assertEqual(os.environ[name], value)

    class TestCase_Pwd_CurrenUsername(TestCase):
        lines = ["USER=$(whoami)"]
        changes = load_env_file(lines)

    unittest.main()

# Generated at 2022-06-24 02:24:20.795498
# Unit test for function expand
def test_expand():
    """
    >>> expand('~/yeee')
    '/home/.../yeee'
    """



# Generated at 2022-06-24 02:24:28.715837
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-24 02:24:39.145182
# Unit test for function expand
def test_expand():
    assert expand('~/asdf') == "~/asdf"

    # assert expand('~/asdf') == os.path.expanduser('~/asdf')
    # assert expand('${HOME}') == os.path.expanduser('${HOME}')

    # assert expand('~/asdf') == os.path.expanduser('~/asdf')
    # assert expand('${HOME}') == os.path.expanduser('${HOME}')
    # assert expand('~/asdf') == os.path.expanduser('~/asdf')
    # assert expand('${HOME}') == os.path.expanduser('${HOME}')



# Generated at 2022-06-24 02:24:50.427528
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import sys

    from pathlib import Path

    from .config import config

    env_file_contents = io.StringIO()
    env_file_contents.write(
        """
#The assignment for the variable named `TEST` is just an example.

TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    )
    env_file_contents.seek(0)

    load_env_file(env_file_contents.readlines(), write_environ=dict())

    home = Path(os.environ['HOME'])
    path = Path(os.environ['PATH'])


# Generated at 2022-06-24 02:24:59.527799
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    target = collections.OrderedDict()
    target['TEST'] = '.../.../yeee-...:...'
    target['THISIS'] = '.../a/test'
    target['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    assert load_env_file(lines, write_environ=None) == target

# Generated at 2022-06-24 02:25:00.834376
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:25:02.604104
# Unit test for function expand
def test_expand():
    for val in ['${HOME}/path/file.txt']:
        print(expand(val))



# Generated at 2022-06-24 02:25:08.631856
# Unit test for function expand
def test_expand():
    assert expand("./test.txt") == os.path.join(os.getcwd(), "test.txt")
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("~/test.txt") == os.path.join(os.path.expanduser("~"), "test.txt")



# Generated at 2022-06-24 02:25:13.366040
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == expand('~')
    assert expand('$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:25:21.404793
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                        ('THISIS', '.../a/test'),
                                        ('YOLO',
                                         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    result = load_env_file(lines, write_environ=None)

    assert (expected == result)



# Generated at 2022-06-24 02:25:23.329926
# Unit test for function expand
def test_expand():
    assert expand("${HOME}") == expand("~")



# Generated at 2022-06-24 02:25:32.770936
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == [ ('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') ]

# Generated at 2022-06-24 02:25:38.740497
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['FOO=BAR', 'SPAM="EGGS"', "A='B'", 'C="D"', 'PATH=$HOME:$PATH']
    changes = parse_env_file_contents(lines)

    assert isinstance(changes, collections.Iterator)

    changes = list(changes)

    assert changes == [
        ("FOO", "BAR"),
        ("SPAM", "EGGS"),
        ("A", "B"),
        ("C", "D"),
        ("PATH", "...:..."),
    ]



# Generated at 2022-06-24 02:25:49.073038
# Unit test for function expand
def test_expand():
    # environment variables
    os.environ["wyatt"] = "python"
    assert expand("$wyatt") == os.environ["wyatt"]
    os.environ["wyatt"] = ""

    # ~
    assert expand("~") == expand(os.path.expanduser("~"))
    assert expand("~/") == expand(os.path.expanduser("~/"))
    assert expand("~/folder") == expand(os.path.expanduser("~/folder"))
    assert expand("~/folder/") == expand(os.path.expanduser("~/folder/"))
    assert expand("~/wyatt/folder") == expand(os.path.expanduser("~/wyatt/folder"))

# Generated at 2022-06-24 02:25:54.019054
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    for k, v in values:
        print("{}: {}".format(k, v))



# Generated at 2022-06-24 02:25:58.784205
# Unit test for function expand
def test_expand():
    tests = {
        'foo': 'foo',
        '$HOME/foo': '.../foo',
        '${HOME}/foo': '.../foo',
        '~/foo': '.../foo',
        '"foo"': 'foo',
        '"$HOME"': '...',
        "'foo'": 'foo',
        "foo':'bar": 'foo:bar',
        'foo\\:bar': 'foo:bar',
    }

    for val, expected in tests.items():
        result = expand(val)

        assert result == expected



# Generated at 2022-06-24 02:26:09.268777
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test invalid/unsupported format
    with pytest.raises(ValueError):
        list(parse_env_file_contents(['FOO']))

    # Test invalid/unsupported format
    with pytest.raises(ValueError):
        list(parse_env_file_contents(['FOO=']))

    # Test single quotes
    assert list(parse_env_file_contents(['FOO=bar'])) == [('FOO', 'bar')]

    # Test double quotes
    assert list(parse_env_file_contents(['F00="bar"'])) == [('F00', 'bar')]

    # Test single quotes
    assert list(parse_env_file_contents(['F00=\'bar\''])) == [('F00', 'bar')]

    # Test escaping double

# Generated at 2022-06-24 02:26:13.365611
# Unit test for function expand
def test_expand():
    val = "~"
    assert expand(val) == os.path.expanduser(val)



# Generated at 2022-06-24 02:26:21.197648
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:26:29.375103
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) \
        == collections.OrderedDict([('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-24 02:26:39.229966
# Unit test for function expand
def test_expand():
    print("expand('~/file')=" + expand('~/file'))  # on linux and mac, this will return the full path to user's home dir
    print("expand('$HOME/file')=" + expand('$HOME/file'))  # on linux and mac, this will return the full path to user's home dir
    # on windows, the variables %USERPROFILE% and %HOMEPATH% represent the user's home directory.
    # as you can see in the above example, variables are not expanded across lines.



# Generated at 2022-06-24 02:26:46.939561
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = list(parse_env_file_contents(lines))
    assert res == [('TEST', '${HOME}/yeee-PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:26:49.857741
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-24 02:26:58.237998
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # verify expected test result
    # result is the same as in honcho
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines)['TEST'] != "$HOME/yeee"
    assert load_env_file(lines)['TEST'] != '~/yeee'
    assert load_env_file(lines)['THISIS'] != '~/a/test'
    assert load_env_file(lines)['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    # The \$ prefix does not escape the variable
   

# Generated at 2022-06-24 02:27:09.463122
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    assert {k: v for k, v in parse_env_file_contents(lines)} == expected

    lines = ['TEST=\'${HOME}/yeee\'', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-24 02:27:16.097094
# Unit test for function expand
def test_expand():
    # Test expand
    val1 = "~/.path"
    val2 = "$HOME/.path"
    val3 = "${HOME}/.path"

    assert val1 == expand(val1)
    assert expand(val2) == expand(val1)
    assert expand(val3) == expand(val1)



# Generated at 2022-06-24 02:27:19.446816
# Unit test for function expand
def test_expand():
    import unittest

    class TestExpandFunctions(unittest.TestCase):
        def test_expand_var(self):
            self.assertEqual('...', expand('${HOME}'))

        def test_expand_user(self):
            self.assertEqual('...', expand('~/'))

    unittest.main()

# Generated at 2022-06-24 02:27:28.110357
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import pytest

    def parse_lines(lines: typing.Sequence[str]) -> typing.Generator[str, None, None]:
        for line in lines:
            line = line.strip()
            if not line.startswith('#'):
                yield line

    def check_lines(lines: typing.Sequence[str], expected: typing.Mapping[str, str]) -> None:
        lines = '\n'.join(lines)
        f = io.StringIO(lines)
        actual = load_env_file(parse_lines(lines.splitlines()))

        assert expected == actual

    # Matches

# Generated at 2022-06-24 02:27:32.005140
# Unit test for function expand
def test_expand():
    tests = [
        ('$HOME/test', os.environ['HOME'] + '/test'),
        ('~/test', os.environ['HOME'] + '/test'),
        ('$HOME/$PATH', os.environ['HOME'] + '/' + os.environ['PATH'])
    ]
    for test in tests:
        assert expand(test[0]) == test[1]

# Generated at 2022-06-24 02:27:43.700282
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    res = load_env_file(lines, write_environ=dict())

    assert res == collections.OrderedDict([
        ('TEST', os.path.expanduser('~/yeee')),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
    ])


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:27:55.353036
# Unit test for function expand
def test_expand():
    """
    Unit test for function expand.
    """
    os.environ["HOME"] = "/home/user"
    os.environ["PATH"] = "/usr/sbin:/usr/bin:/sbin:/bin"

    tests = [
        ("$HOME/yeee-$PATH", "/home/user/yeee-/usr/sbin:/usr/bin:/sbin:/bin"),
        ("~/a/test", "/home/user/a/test"),
        ("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST", "/home/user/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    ]

    for old, new in tests:
        assert expand(old) == new



# Generated at 2022-06-24 02:28:06.702104
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines, write_environ=dict())

    assert res == collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])


# Run the test
if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:28:14.760057
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == \
           collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                    ('THISIS', '.../a/test'),
                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


# Generated at 2022-06-24 02:28:27.165661
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class ParseEnvFileContentsTest(unittest.TestCase):
        def test(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            result = load_env_file(lines, write_environ=dict())
            self.assertEqual(result['TEST'], expand("${HOME}/yeee"))
            self.assertEqual(result['THISIS'], expand("~/a/test"))
            self.assertEqual(result['YOLO'], expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))


# Generated at 2022-06-24 02:28:32.183088
# Unit test for function expand
def test_expand():
    assert expand('$HOME/hello/') == os.path.expanduser('~/hello/')
    assert expand('~/hello/') == os.path.expanduser('~/hello/')
    assert expand('${HOME}/hello/') == os.path.expanduser('~/hello/')
    assert expand('${HOME}/hello/${HOME}') == os.path.expanduser('~/hello/~')
    assert expand('${HOME}/hello/~') == os.path.expanduser('~/hello/~')



# Generated at 2022-06-24 02:28:38.826421
# Unit test for function expand
def test_expand():
    assert expand("${HOME}/yeee") == os.path.expandvars("${HOME}/yeee")
    assert expand("~/yeee") == os.path.expanduser("~/yeee")
    assert expand("~/yeee/${HOME}") == os.path.expandvars(os.path.expanduser("~/yeee/${HOME}"))
    assert expand("~/yeee/${HOME}/yeet") == os.path.expandvars(os.path.expanduser("~/yeee/${HOME}/yeet"))
    assert expand("~/yeee") == os.path.expanduser(os.path.expandvars("~/yeee"))



# Generated at 2022-06-24 02:28:44.375991
# Unit test for function expand
def test_expand():
    home_dir = os.environ.get('HOME')

    assert expand('~/test') == os.path.join(home_dir, 'test')

    assert expand('$HOME/test') == os.path.join(home_dir, 'test')

    # Not interested in testing the exact path here
    assert expand('${HOME}/test') == os.path.join(home_dir, 'test')



# Generated at 2022-06-24 02:28:53.647297
# Unit test for function load_env_file

# Generated at 2022-06-24 02:29:02.327674
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']

    for k, v in parse_env_file_contents(lines):
        if k == 'TEST':
            assert v == os.path.expanduser(os.path.expandvars('${HOME}/yeee'))
        elif k == 'THISIS':
            assert v == os.path.expanduser(os.path.expandvars('~/a/test'))
        else:
            raise ValueError(k)



# Generated at 2022-06-24 02:29:06.449242
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:29:15.158185
# Unit test for function expand
def test_expand():
    assert expand("~/") == os.path.expanduser("~/")
    assert expand("$HOME/") == os.path.expandvars("$HOME/")
    assert expand("$HOME/") == os.path.expandvars("$HOME/")

    newenv = os.environ.copy()
    newenv["TEST"] = "{HOME}"
    assert expand("${TEST}") == os.path.expandvars("${TEST}", newenv)

    newenv["TEST2"] = "~"
    assert expand("${TEST2}") == os.path.expanduser("${TEST2}", newenv)

# Generated at 2022-06-24 02:29:20.196640
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:29:30.745887
# Unit test for function load_env_file
def test_load_env_file():
    # pytest.skip()
    from io import StringIO
    from pprint import pprint

    stream = StringIO('TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    write_environ = dict()
    load_env_file(stream, write_environ)

    value = write_environ

    pprint(value)


# Generated at 2022-06-24 02:29:39.947286
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    assert (('TEST', '${HOME}/yeee') == values.__next__())
    assert (('THISIS', '~/a/test') == values.__next__())
    assert (('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == values.__next__())



# Generated at 2022-06-24 02:29:42.330521
# Unit test for function expand
def test_expand():
    assert expand("$HOME/file") == os.path.expandvars("$HOME/file")
    assert expand("~/file") == os.path.expanduser("~/file")



# Generated at 2022-06-24 02:29:48.841822
# Unit test for function load_env_file
def test_load_env_file():
    filename = 'tests/env_file'
    lines = open(filename).read().splitlines()

    test_env = load_env_file(lines, write_environ=dict())

    assert len(test_env) == 3
    assert test_env == {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

