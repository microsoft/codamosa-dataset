

# Generated at 2022-06-24 02:19:42.183870
# Unit test for function load_env_file
def test_load_env_file():
    env = load_env_file(lines=['TEST=test', 'TEST2=test'], write_environ=None)

    assert env['TEST'] == 'test'
    assert env['TEST2'] == 'test'



# Generated at 2022-06-24 02:19:51.778038
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    ret: typing.Mapping = dict(parse_env_file_contents(lines))
    assert ret == {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}



# Generated at 2022-06-24 02:19:57.737420
# Unit test for function expand
def test_expand():
    val = '~/some_path/some_file'
    val = expand(val)
    assert val == os.path.expanduser(val)
    val2 = '$HOME/some_path/some_file'
    val2 = expand(val2)
    assert val == val2

# Generated at 2022-06-24 02:20:08.154671
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = ['A=B', 'B=C', '###', '# sdfdsf', '# dfdfds # sdfdds', '', 'C=D']

    assert list(parse_env_file_contents(lines)) == [('A', 'B'), ('B', 'C'), ('C', 'D')]

    contents = """\
A=B
B=C
###
# sdfdsf
# dfdfds # sdfdds

C=D
"""

    assert list(parse_env_file_contents(io.StringIO(contents))) == [('A', 'B'), ('B', 'C'), ('C', 'D')]


# Generated at 2022-06-24 02:20:15.334192
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test data
    t_lines = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test",
               "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    # Execute function
    t_result = next(parse_env_file_contents(t_lines))
    assert t_result == ("TEST", "${HOME}/yeee-$PATH")

    t_result = next(parse_env_file_contents(t_lines))
    assert t_result == ("THISIS", "~/a/test")

    t_result = next(parse_env_file_contents(t_lines))

# Generated at 2022-06-24 02:20:24.993801
# Unit test for function expand
def test_expand():
    before_after = (
        ("", ""),
        ("~", os.path.expanduser("~")),
        ("~/a/b", os.path.expanduser("~/a/b")),
        ("$HOME", os.path.expandvars("$HOME")),
        ("${HOME}", os.path.expandvars("${HOME}")),
        ("${HOME}/a/b", os.path.expandvars("${HOME}/a/b")),
        ("${HOME}a/b", os.path.expandvars("${HOME}a/b")),
    )

    for b, a in before_after:
        assert expand(b) == a

# Generated at 2022-06-24 02:20:32.374899
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = collections.OrderedDict()

    changes = load_env_file(lines, write_environ=write_environ)

    test1 = expand('${HOME}/yeee')
    test2 = expand('~/a/test')
    test3 = expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    assert changes['TEST'] == test1
    assert changes['THISIS'] == test2
    assert changes['YOLO'] == test3

    assert write_environ['TEST'] == test1

# Generated at 2022-06-24 02:20:41.712853
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Setup Test
    with open('tests/fixtures/test.env', 'r') as f:
        lines = f.readlines()

    # Test
    res = parse_env_file_contents(lines)

    # Assert
    assert 'DOE_CLIENT_ID=xyz123' in res
    assert 'DOE_CLIENT_SECRET=abc1234' in res
    assert 'JWT_SECRET=super_secret_key' in res
    assert 'CLINICAL_API_KEY=clinical_api_key' in res
    assert 'CBIOPORTAL_API_KEY=cbio_api_key' in res



# Generated at 2022-06-24 02:20:50.757091
# Unit test for function expand
def test_expand():
    assert expand('~/../tmp/../home/') == os.path.expanduser('~/../tmp/../home/')
    assert expand('$HOME/../tmp/../home/') == os.environ['HOME'] + '/../tmp/../home/'
    assert expand('${HOME}/../tmp/../home/') == os.environ['HOME'] + '/../tmp/../home/'
    assert expand('${HOME}/../tmp/../home/${HOME}') == os.environ['HOME'] + '/../tmp/../home/' + os.environ['HOME']
    assert expand('${HOME}/../tmp/../home/$$') == os.environ['HOME'] + '/../tmp/../home/' + str(os.getpid())
    assert expand('${HOME}/../tmp/../home/$?')

# Generated at 2022-06-24 02:20:57.296627
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    assert len(list(results)) == 3


# Generated at 2022-06-24 02:21:01.116627
# Unit test for function expand
def test_expand():
    assert expand("./test") == os.path.abspath(os.path.expanduser("./test"))
    assert expand("~/test") == os.path.abspath(os.path.expanduser("~/test"))
    assert expand("$HOME/test") == os.path.abspath(os.path.expanduser("$HOME/test"))


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:06.706411
# Unit test for function expand
def test_expand():
    assert expand('~/yeee') == os.path.expanduser('~/yeee')
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')
    assert expand('~/yeee-${PATH}') == os.path.expanduser('~/yeee-${PATH}')



# Generated at 2022-06-24 02:21:17.756786
# Unit test for function load_env_file
def test_load_env_file():
    write_environ = dict()
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    result = load_env_file(lines, write_environ)
    assert result[
        'TEST'] == write_environ['TEST'] == os.path.join(
            os.path.expanduser('~'), 'yeee-' + os.getenv('PATH'))
    assert result[
        'THISIS'] == write_environ['THISIS'] == os.path.join(
            os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-24 02:21:24.793860
# Unit test for function expand
def test_expand():
    assert expand('~/yolo') == os.path.expanduser('~/yolo')
    assert expand('$HOME/yolo') == os.path.expandvars('$HOME/yolo')
    assert expand('$HOME/yolo') == expand('~/yolo')

    if 'TEST_VAR' in os.environ:
        del os.environ['TEST_VAR']

    os.environ['TEST_VAR'] = 'THIS IS A TEST'

    assert expand('$TEST_VAR') == 'THIS IS A TEST'



# Generated at 2022-06-24 02:21:33.774187
# Unit test for function expand
def test_expand():
    val = '~/'
    os.environ['HOME'] = 'HOME'
    assert expand(val) == os.path.join(os.environ['HOME'], '')

    val = '$HOME'
    os.environ['HOME'] = 'HOME'
    assert expand(val) == os.environ['HOME']

    val = '$HOME/$NAME'
    os.environ['HOME'] = 'HOME'
    os.environ['NAME'] = 'NAME'
    assert expand(val) == os.path.join(os.environ['HOME'], os.environ['NAME'])



# Generated at 2022-06-24 02:21:38.156335
# Unit test for function expand
def test_expand():
    """
    >>> load_env_file(['TEST=$HOME', 'FOO=/A/${TEST}/B'])
    """
    _, new_env = capfd.readouterr()
    assert new_env.strip() == "FOO=/A/~/B"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:43.617629
# Unit test for function expand
def test_expand():
    assert expand('$HOME/hi') == os.path.expandvars('$HOME/hi')
    assert expand('~/hi') == os.path.expanduser('~/hi')



# Generated at 2022-06-24 02:21:45.310785
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-24 02:21:53.178626
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', os.path.join(os.path.expanduser("~"), "yeee")),
        ('THISIS', os.path.join(os.path.expanduser("~"), "a/test")),
        ('YOLO', os.path.join(os.path.expanduser("~"), "swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")),
    ]

# Generated at 2022-06-24 02:22:02.830047
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import difflib
    import textwrap
    import pprint

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    correct = """\
    ('TEST', '.../yeee')
    ('THISIS', '.../a/test')
    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')"""

    correct = textwrap.dedent(correct).splitlines()

    actual = pprint.pformat(
        tuple(parse_env_file_contents(lines)),
        width=200,
        compact=True
    ).splitlines()

   

# Generated at 2022-06-24 02:22:10.184753
# Unit test for function load_env_file
def test_load_env_file():
    from copy import copy
    from sys import version_info

    from importlib import reload
    from yaml import safe_load

    from test_utils import __dir__

    # Can't use nose for this test because that would modify sys.path, so we use yaml
    yaml_file = os.path.join(__dir__, '..', '..', 'test_utils', 'sys_path.yaml')

    with open(yaml_file, 'r') as f:
        sys_path = safe_load(f.read())

    # Create new environment
    old_environ = copy(os.environ)
    old_sys_path = copy(sys.path)

    new_environ = dict()
    os.environ = new_environ

    new_sys_path = sys_path

# Generated at 2022-06-24 02:22:20.188886
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert changes['TEST'].startswith(os.environ['HOME'])
    assert changes['THISIS'].startswith(os.environ['HOME'])
    assert changes['YOLO'].endswith('$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:22:30.050169
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = parse_env_file_contents(lines)
    assert contents == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines = ['TEST=\${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents

# Generated at 2022-06-24 02:22:40.546256
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == {
        'TEST': os.path.expanduser(os.path.join('~', 'yeee')),
        'THISIS': os.path.expanduser(os.path.join('~', 'a', 'test')),
        'YOLO': os.path.expanduser(os.path.join('~', 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    }

# Generated at 2022-06-24 02:22:42.605224
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


__all__ = [
    'expand',
    'load_env_file',
]

# Generated at 2022-06-24 02:22:45.452927
# Unit test for function expand
def test_expand():
    test_str = '~/this/should/be/expanded'
    result = expand(test_str)
    assert result == os.getenv('HOME') + '/this/should/be/expanded'

# Generated at 2022-06-24 02:22:47.842177
# Unit test for function expand
def test_expand():
    assert expand('~/a/b') == os.path.expanduser('~/a/b')
    assert expand('$USER/a/b') == os.path.expandvars('$USER/a/b')

# Generated at 2022-06-24 02:22:51.140858
# Unit test for function expand
def test_expand():
    os.environ["FOO"] = "bar"
    assert expand("$FOO") == "bar"
    assert expand("$FOO/baz") == "bar/baz"
    assert expand("~/quux") == os.path.expanduser("~/quux")
    assert os.path.isdir(expand("~/quux"))



# Generated at 2022-06-24 02:23:00.177341
# Unit test for function expand
def test_expand():
    """
    Test for function expand.

    >>> expand('$HELLO/world') == os.path.expandvars('$HELLO/world')
    True
    >>> expand('$HELLO/world') == os.path.expandvars(expand('$HELLO/world'))
    True
    >>> expand('~/hello/world') == os.path.expanduser(expand('~/hello/world'))
    True
    >>> expand('~/hello/world') == os.path.expanduser('~/hello/world')
    True
    """



# Generated at 2022-06-24 02:23:04.405488
# Unit test for function load_env_file
def test_load_env_file():
    # pylint: disable=redefined-outer-name
    with open(__file__) as f:
        lines = f.readlines()
        load_env_file(lines, write_environ=None)


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:23:07.576987
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))

# Generated at 2022-06-24 02:23:13.806415
# Unit test for function load_env_file
def test_load_env_file():
    lines = """TEST=test
    THISIS=test
    YOLO=test
    TEST=$HOME/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    TEST="test"
    THISIS="test"
    YOLO="test"
    TEST="\"test\""
    THISIS="\t"
    YOLO="\\\\test"
    TEST='test'
    THISIS='test'
    YOLO='test'
    TEST='\'test\''
    THISIS='\t'
    YOLO='\\'
    """
    lines = lines.split('\n')
    result = load_env_file(lines)

# Generated at 2022-06-24 02:23:25.118513
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert changes == {'TEST': os.path.join(os.path.expanduser('~'), 'yeee'),
                       'THISIS': os.path.join(os.path.expanduser('~'), 'a', 'test'),
                       'YOLO': os.path.join(os.path.expanduser('~'),
                                            'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}



# Generated at 2022-06-24 02:23:33.095773
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee') == os.path.expandvars('$HOME/yeee')
    assert expand('~/yeee') == os.path.expanduser('~/yeee')
    assert expand('~/') == os.path.expanduser('~/')

    # Test whether some exceptions are caught
    with pytest.raises(TypeError):
        expand(4)



# Generated at 2022-06-24 02:23:39.741611
# Unit test for function expand
def test_expand():
    sample = "$HOME/.local/share"
    improvements = [("$HOME", os.environ["HOME"]),
                    ("$HOME", r"~")]

    for rep, sub in improvements:
        sample = sample.replace(rep, sub)

    original = sample

    assert (sample == original)
    sample = expand(sample)
    assert (sample != original)



# Generated at 2022-06-24 02:23:47.273695
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = os.environ
    values = parse_env_file_contents(lines)

    assert env['HOME'] == next(values)[1]
    assert env['PATH'] in next(values)[1]
    assert next(values)[1] == os.path.expanduser('~') + '/a/test'
    assert next(values)[1] == os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:23:58.776698
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH'])) == [('TEST', os.path.expanduser('~/yeee-$PATH'))]
    assert list(parse_env_file_contents(['THISIS=~/a/test'])) == [('THISIS', os.path.expanduser('~/a/test'))]
    assert list(parse_env_file_contents(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]

# Generated at 2022-06-24 02:24:02.715515
# Unit test for function load_env_file
def test_load_env_file():
    import os,sys
    os.environ['HOME'] = os.path.abspath('.')
    os.environ['PATH'] = ':'.join(sys.path)
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-24 02:24:11.681296
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines) == collections.OrderedDict(
        [
            ("TEST", "{}/yeee-{}".format(expand("$HOME"), expand("$PATH"))),
            ("THISIS", expand("~/a/test")),
            (
                "YOLO",
                expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
            ),
        ]
    )



# Generated at 2022-06-24 02:24:22.786005
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import sys

    if sys.version_info.major >= 3:
        lines = io.StringIO('TEST=${HOME}/${PATH}\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST').readlines()
    else:
        lines = io.BytesIO(b'TEST=${HOME}/${PATH}\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST').readlines()

    changes = load_env_file(lines)

    assert changes['TEST'].startswith(os.path.expanduser('~') + '/')

# Generated at 2022-06-24 02:24:29.128157
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME/test') == os.path.expandvars('$HOME/test')
    assert expand('~/test') != os.path.expandvars('~/test')
    assert expand('${HOME}/test') == os.path.expandvars('${HOME}/test')
    assert expand('${HOME}/test') != '${HOME}/test'

# Generated at 2022-06-24 02:24:40.590417
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-24 02:24:43.480684
# Unit test for function expand
def test_expand():
    assert expand("TEST") == "TEST"
    assert expand("$TEST") == "$TEST"
    assert expand("$TEST/test") == "$TEST/test"
    assert expand("${TEST}") == "${TEST}"



# Generated at 2022-06-24 02:24:55.064780
# Unit test for function expand
def test_expand():
    from pprint import pprint

    values = [
        '~',
        '~/',
        '~/test/123.txt',
        '$HOME',
        '$HOME/test/123.txt',
        '/home/user/$USER/test/123.txt',
        r'/home/user/$USER/test/123.txt',
        "~/test \"quotes\" 'quotes' $PATH",
        r'~/test \"quotes\" \'quotes\' $PATH',
    ]

    for v in values:
        pprint((v, expand(v)))



# Generated at 2022-06-24 02:24:59.526677
# Unit test for function expand
def test_expand():
    assert os.path.expandvars("") == expand("")
    assert os.path.expandvars("test") == expand("test")
    assert os.path.expandvars("${HOME}") == expand("${HOME}")
    assert os.path.expandvars("${HOME}/bla") == expand("${HOME}/bla")



# Generated at 2022-06-24 02:25:06.444190
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = {
        'TEST': '{}/yeee-{}'.format(os.environ['HOME'], os.environ['PATH']),
        'THISIS': '{}/a/test'.format(os.environ['HOME']),
        'YOLO': '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.environ['HOME']),
    }

    actual = load_env_file(lines, write_environ=None)

    assert len(actual) == len(expected)

# Generated at 2022-06-24 02:25:17.860011
# Unit test for function load_env_file
def test_load_env_file():
    import collections

    assert isinstance(load_env_file(''), collections.OrderedDict)
    assert load_env_file('') == collections.OrderedDict()

    assert load_env_file('export test={{home}}/yeee') == collections.OrderedDict([('test', '.../yeee')])
    assert load_env_file('export test={{home}}/yeee', write_environ=dict()) == collections.OrderedDict([('test', '.../yeee')])

    assert load_env_file('test={{home}}/yeee') == collections.OrderedDict([('test', '.../yeee')])
    assert load_env_file('test={{home}}/yeee', write_environ=dict()) == collections.OrderedDict

# Generated at 2022-06-24 02:25:28.857790
# Unit test for function load_env_file
def test_load_env_file():
    original_environ = os.environ.copy()
    original_environ['TEST_VAR'] = 'TEST_VALUE'


# Generated at 2022-06-24 02:25:35.411611
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:25:45.986470
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    def to_dict(values):
        return collections.OrderedDict(tuple(values))

    assert to_dict(parse_env_file_contents(lines)) == collections.OrderedDict((
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ))



# Generated at 2022-06-24 02:25:56.144812
# Unit test for function load_env_file
def test_load_env_file():
    test_env_file_string_list = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_result = load_env_file(test_env_file_string_list)

    assert isinstance(test_result, collections.OrderedDict)
    assert test_result['TEST'] == '.../.../yeee-...:...'
    assert test_result['THISIS'] == '.../a/test'
    assert test_result['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:25:57.993365
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expanduser('~')

    assert expand('${PWD}') == os.getcwd()



# Generated at 2022-06-24 02:26:00.821457
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:26:10.692352
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    input_data = """
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """.splitlines()

    output_data = """
        ('TEST', '.../.../yeee-...:...')
        ('THISIS', '.../a/test')
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
        """.strip().splitlines()

    assert list(parse_env_file_contents(input_data)) == [tuple(entry.split(', ')) for entry in output_data]



# Generated at 2022-06-24 02:26:13.308723
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.join(os.environ['HOME'], 'test')
    assert expand('${HOME}/test') == os.path.join(os.environ['HOME'], 'test')



# Generated at 2022-06-24 02:26:23.148308
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.writelines(['TEST=${HOME}/yeee-$PATH\n', 'THISIS=~/a/test\n', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n'])
        f.flush()

        environ = {}
        load_env_file([f.name], write_environ=environ)

# Generated at 2022-06-24 02:26:31.650621
# Unit test for function load_env_file
def test_load_env_file():
    from hypothesis import given
    from hypothesis.strategies import text

    def _test_loading_file(file_contents_str: str):
        return load_env_file(file_contents_str.splitlines(), write_environ=None)

    @given(text())
    def test_loading_file(file_contents: str):
        _test_loading_file(file_contents)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:26:43.514234
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> test_load_env_file()
    OrderedDict([(...), (...), (...), (...), (...)])
    """
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'DEL=',
        'FOO=\\\"bar\\\"'
    ]


# Generated at 2022-06-24 02:26:45.891960
# Unit test for function expand
def test_expand():
    orig_env = dict(os.environ)
    os.environ['YOLO'] = 'yeee'
    assert expand('$YOLO') == 'yeee'
    assert expand('${YOLO}') == 'yeee'
    os.environ = orig_env



# Generated at 2022-06-24 02:26:54.086100
# Unit test for function load_env_file

# Generated at 2022-06-24 02:26:56.415518
# Unit test for function expand
def test_expand():
    assert expand('$HOME') != '$HOME'
    assert expand('~') != '~'
    assert expand('~/yoloswag') != '~/yoloswag'



# Generated at 2022-06-24 02:27:02.670961
# Unit test for function expand
def test_expand():
    def check(env: dict, val: str, expected: str, **kwargs) -> bool:
        old_env, os.environ = os.environ, dict(env)

        try:
            result = expand(val, **kwargs)
        except Exception as e:
            print(e)
            return False
        finally:
            os.environ = old_env

        success = result == expected

        if not success:
            print("For env={!r}, val={!r}, expected={!r}, got={!r}".format(env, val, expected, result))

        return success

    check({"A": "1"}, "$A", "1")
    check({}, "$NOTHING", "$NOTHING")
    check({"A": "1"}, "${A}", "1")

# Generated at 2022-06-24 02:27:11.145370
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines = [
        'TEST=${HOME}/yeee-foo',
        'YOLO="~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"'
    ]
    assert parse_env_

# Generated at 2022-06-24 02:27:14.694399
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), "fixtures", "test.env")
    with open(filename) as f:
        lines = f.readlines()

    load_env_file(lines=lines)


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.REPORT_ONLY_FIRST_FAILURE)

# Generated at 2022-06-24 02:27:26.435225
# Unit test for function load_env_file
def test_load_env_file():
    # Unit test for function expand
    def test_expand():
        assert expand('foo') == 'foo'
        assert expand('~/foo') == os.path.expanduser('~/foo')
        assert expand('${HOME}/foo') == os.path.join(os.environ['HOME'], 'foo')
        assert expand('${HOME}/foo-${PWD}') == os.path.join(os.environ['HOME'], 'foo-', os.environ['PWD'])

    # Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:27:34.702175
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pathlib
    import collections
    import io

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-24 02:27:37.162842
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

    assert True

# Generated at 2022-06-24 02:27:42.381709
# Unit test for function expand
def test_expand():
    # Test variable expansion
    v = "TEST_VAR"
    os.environ[v] = "/my/test/var"
    assert expand(f"${v}") == "/my/test/var"

    # Test user expansion
    assert expand("~/test") == os.path.expanduser("~/test")



# Generated at 2022-06-24 02:27:50.746723
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # copy os.environ
    environ = dict(os.environ)

    output = load_env_file(lines, write_environ=environ)

    assert output == collections.OrderedDict([('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    assert 'TEST' in environ
    assert 'THISIS' in environ
    assert 'YOLO' in en

# Generated at 2022-06-24 02:27:53.524658
# Unit test for function expand
def test_expand():
    assert expand("$HOME/yeee") == expand("~/yeee")


if __name__ == "__main__":
    test_expand()

# Generated at 2022-06-24 02:28:00.256690
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Runs the unit tests for `parse_env_file_contents`.

    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 02:28:11.784521
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_file = load_env_file(lines, write_environ=dict())

    assert env_file['TEST'] == '~/yeee-~/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    assert env_file['THISIS'] == '~/a/test'
    assert env_file['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == '__main__':
    import doctest

    doctest.test

# Generated at 2022-06-24 02:28:22.454886
# Unit test for function expand
def test_expand():
    assert(expand('$HOME') == os.environ['HOME'])
    assert(expand('~') == os.environ['HOME'])
    assert(expand('~/') == os.path.join(os.environ['HOME'], ''))
    assert(expand('~/tmp') == os.path.join(os.environ['HOME'], 'tmp'))
    assert(expand('~/../tmp') == os.path.join(os.environ['HOME'], '..', 'tmp'))
    assert(expand('$HOME/..') == os.path.join(os.environ['HOME'], '..'))
    assert(expand('$HOME/..//') == os.path.join(os.environ['HOME'], '..', ''))



# Generated at 2022-06-24 02:28:33.303518
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    def parse_and_compare(lines, results):
        assert list(parse_env_file_contents(lines)) == results

    parse_and_compare(
        ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'],
        [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    )


# Generated at 2022-06-24 02:28:38.205328
# Unit test for function expand
def test_expand():
    """
    >>> test_expand()
    True
    """
    assert expand('~/.sometest/') == '/home/<username>/.sometest/'
    assert expand('$HOME/.sometest/') == '/home/<username>/.sometest/'
    return True

# Generated at 2022-06-24 02:28:41.479639
# Unit test for function expand
def test_expand():
    # check if expandvars works
    assert expand('${HOME}') == os.environ['HOME']
    # check if expanduser works
    assert expand('~') == os.environ['HOME']

# Generated at 2022-06-24 02:28:50.400556
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['X=xx']
    os.environ.pop('X', None)
    load_env_file(lines)
    assert os.getenv('X') == 'xx'

    lines = ['X=xx', 'Y=yy']
    os.environ.pop('X', None)
    os.environ.pop('Y', None)
    load_env_file(lines)
    assert os.getenv('X') == 'xx'
    assert os.getenv('Y') == 'yy'



# Generated at 2022-06-24 02:28:51.690226
# Unit test for function expand
def test_expand():
    assert expand('$HOME/a') == '.../a'



# Generated at 2022-06-24 02:29:02.529998
# Unit test for function load_env_file
def test_load_env_file():
    o = load_env_file(["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])
    assert o == collections.OrderedDict([("TEST", os.path.expanduser("~/yeee-") + os.getenv("PATH")), ("THISIS", os.path.expanduser("~/a/test")), ("YOLO", os.path.expanduser("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))])



# Generated at 2022-06-24 02:29:07.934569
# Unit test for function expand
def test_expand():
    test_val = "~/a/b"
    assert expand(test_val) == os.path.expanduser(test_val)



# Generated at 2022-06-24 02:29:17.384546
# Unit test for function load_env_file
def test_load_env_file():
    import io

    header = b"""
export TEMPDIR=${HOME}/tmp
export TEMP=${TEMPDIR}
export TMP=${TEMPDIR}
export HOST=localhost
"""

    for add_quotes in (True, False):
        for shell in ('sh', 'bash'):
            for i, param in enumerate((
                    (header + b'python3 -m http.server', "python3 -m http.server"),
                    (header + b'python3 -m http.server -p $PORT', 'python3 -m http.server -p $PORT'),
            )):
                env_file, cmd_line = param

                if add_quotes:
                    # Add quotes
                    cmd_line = "'" + cmd_line + "'"

                # Parse the command to a list
                parsed_

# Generated at 2022-06-24 02:29:29.063971
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    value_dict = dict(values)

    assert os.path.expandvars(value_dict['TEST']) == os.path.expandvars('${HOME}/yeee')
    assert os.path.expanduser(value_dict['THISIS']) == os.path.expanduser('~/a/test')
    assert value_dict['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:29:35.939373
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parsed = parse_env_file_contents(lines)

    assert dict(parsed) == {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-24 02:29:45.929001
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == \
        collections.OrderedDict([('TEST', '.../yeee'),
                                ('THISIS', '.../a/test'),
                                ('YOLO',
                                 '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])