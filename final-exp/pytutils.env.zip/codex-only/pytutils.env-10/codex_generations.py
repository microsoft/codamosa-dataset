

# Generated at 2022-06-24 02:19:43.123906
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:19:53.312125
# Unit test for function expand
def test_expand():
    full_path = os.path.abspath(os.path.join(__file__, os.pardir))

    # Test expanding environment variables
    os.environ["HOME"] = full_path
    assert expand('~/test') == os.path.join(full_path, 'test')

    # Test expanding variables with multiple paths separated by colons
    os.environ["PATH"] = full_path + ':' + os.path.join(full_path, 'bin')
    assert expand('${PATH}/test') == full_path + '/test:' + os.path.join(full_path, 'bin') + '/test'

    # Test expanding variables that contain other variables
    os.environ["TEST_VARIABLE"] = "/foo/bar"

# Generated at 2022-06-24 02:19:59.266292
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:20:09.149583
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest
    from io import StringIO

    test_data = StringIO('''\
# This is a comment
TEST=$HOME/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
''')

    rv = parse_env_file_contents(test_data)
    rv = dict(rv)

    assert isinstance(rv, dict)

    assert rv['TEST'].startswith(os.environ['HOME'])
    assert rv['TEST'].endswith('/yeee')

    assert rv['THISIS'].startswith(os.environ['HOME'])
    assert rv['THISIS'].endswith('/a/test')

# Generated at 2022-06-24 02:20:15.214896
# Unit test for function expand
def test_expand():
    assert expand("/dev/$USER") == expand(os.path.expandvars("/dev/$USER"))
    assert expand("~/test") == expand(os.path.expandvars("~/test"))



# Generated at 2022-06-24 02:20:24.737157
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> actual = parse_env_file_contents(lines)
    >>> actual = list(actual)
    >>> expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    >>> actual == expected
    True
    """
    pass



# Generated at 2022-06-24 02:20:35.771881
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = '.'
    os.environ['TEST2'] = '..'
    os.environ['TEST3'] = '../..'
    os.environ['TEST4'] = '../../..'
    os.environ['TEST5'] = 'test'
    os.environ['TEST6'] = 'test/test'
    os.environ['TEST7'] = 'test/test/test'
    os.environ['TEST8'] = 'test/test/test/test'

    assert expand('$TEST') == '.'
    assert expand('${TEST}') == '.'
    assert expand('$TEST/test') == './test'
    assert expand('${TEST}/test') == './test'

# Generated at 2022-06-24 02:20:38.622247
# Unit test for function expand
def test_expand():
    v = expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    print(v)
    assert '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST' in v



# Generated at 2022-06-24 02:20:50.416618
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test with one of each type of line
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', os.path.join(expand('$HOME'), 'yeee-') + os.pathsep + expand('$PATH'))
    assert next(values) == ('THISIS', expand('~/a/test'))
    assert next(values) == ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

    # Test with bare values

# Generated at 2022-06-24 02:20:52.721505
# Unit test for function expand
def test_expand():
    assert expand('~/hi') == os.path.expanduser('~/hi')
    assert expand('$PATH/hi') == os.path.expandvars('$PATH/hi')



# Generated at 2022-06-24 02:21:00.138240
# Unit test for function load_env_file
def test_load_env_file():
    import os

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    assert os.environ['TEST'] == os.path.join(os.environ['HOME'], 'yeee-') + os.pathsep + os.environ['PATH']
    assert os.environ['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')

# Generated at 2022-06-24 02:21:08.843246
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-24 02:21:18.609000
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    From honcho - tests from https://github.com/nickstenning/honcho/blob/master/tests/test_environ.py
    """
    assert list(parse_env_file_contents(["foo=bar"])) == [("foo", "bar")]
    assert list(parse_env_file_contents(["foo=bar\n"])) == [("foo", "bar")]

    assert list(parse_env_file_contents(["foo=bar", "baz=quux"])) == [
        ("foo", "bar"),
        ("baz", "quux"),
    ]

    assert list(parse_env_file_contents([" foo=bar "])) == [("foo", "bar")]

    assert list(parse_env_file_contents(["foo = bar"]))

# Generated at 2022-06-24 02:21:27.067599
# Unit test for function expand
def test_expand():
    import os

    os.environ["HOME"] = "/home/eivind"
    os.environ["MLFLOW_HOME"] = "/home/.mlflow"
    os.environ["PATH"] = "/home/eivind/.conda/bin"
    os.environ["NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"] = "/home/eivind/git/mlflow/mlflow/bin"


# Generated at 2022-06-24 02:21:31.893948
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    return load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:21:33.525094
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:21:34.446638
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:37.532864
# Unit test for function expand
def test_expand():
    assert expand("~/.bashrc") == os.path.expanduser("~/.bashrc")
    assert expand("$HOME/.bashrc") == os.path.expandvars("$HOME/.bashrc")



# Generated at 2022-06-24 02:21:50.513644
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        env[k] = v

    assert env.keys() == ['TEST', 'THISIS', 'YOLO']

    assert env['TEST'] == os.path.expanduser("~/yeee-") + os.pathsep.join(os.environ.get('PATH', '').split(os.pathsep))

    assert env['THISIS'] == os.path.expanduser("~/a/test")


# Generated at 2022-06-24 02:21:57.385193
# Unit test for function expand
def test_expand():
    os.environ['TEST_ENV_VAR'] = 'This is the test value'
    test_val = '$TEST_ENV_VAR'
    expanded_val = expand(test_val)
    assert expanded_val == os.environ['TEST_ENV_VAR']
    del os.environ['TEST_ENV_VAR']



# Generated at 2022-06-24 02:22:01.414269
# Unit test for function expand
def test_expand():
    os.environ['TEST'] = 'TEST_VALUE'
    assert expand('$TEST') == 'TEST_VALUE'
    assert expand('${TEST}') == 'TEST_VALUE'
    assert expand('~/test/') == os.path.expanduser('~') + '/test/'



# Generated at 2022-06-24 02:22:04.198029
# Unit test for function expand
def test_expand():
    key = "PATH"
    value = os.environ[key]

    changes = load_env_file(["PATH=${PATH}"], write_environ=os.environ)
    assert changes[key] == value


# Generated at 2022-06-24 02:22:10.982611
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'DB_HOST=${DB_HOST:-localhost}',
        'DB_NAME=${DB_NAME:-test}',
        'DB_USER=${DB_USER:-root}',
        'DB_PASSWORD=${DB_PASSWORD:-}',
        'DB_PORT=${DB_PORT:-3306}',
    ]
    values = list(parse_env_file_contents(lines))

    print(values)

    assert len(values) == 5

# Generated at 2022-06-24 02:22:21.309782
# Unit test for function load_env_file
def test_load_env_file():
    import pytest

    filename = os.path.join(os.path.dirname(__file__), "data", ".env_test_file")

    with open(filename) as f:
        f_contents = f.readlines()

    e_out = load_env_file(f_contents)

    assert e_out["TEST_1"] == "~/a/test"
    assert e_out["TEST_2"] == "~/a/test/b"

    assert e_out["PATH"] == os.path.expanduser(os.path.join("~/a/test")) + ":" + os.path.expandvars("$PATH")

    # Test for unknown variables
    with pytest.raises(KeyError):
        e_out["NONEXISTINGVAR"]

    # Test

# Generated at 2022-06-24 02:22:29.383227
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    for i, (k, v) in enumerate(parse_env_file_contents(lines)):
        if i == 0:
            assert k in ('TEST', 'THISIS', 'YOLO')
            assert not v.endswith('$PATH')
        elif i == 1:
            assert k in ('TEST', 'THISIS', 'YOLO')
            assert not v.startswith('/home')
        elif i == 2:
            assert k in ('TEST', 'THISIS', 'YOLO')
            assert v.startswith('/home')



# Generated at 2022-06-24 02:22:37.142970
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/yeee-$PATH') == os.path.expandvars(os.path.expanduser('${HOME}/yeee-$PATH'))
    assert expand('~/swaggins/yolo') == os.path.expandvars(os.path.expanduser('~/swaggins/yolo'))



# Generated at 2022-06-24 02:22:38.962790
# Unit test for function expand
def test_expand():
    os.environ["MY_ENV_VAR"] = "test"
    assert expand("$MY_ENV_VAR") == "test"
    assert expand("${MY_ENV_VAR}") == "test"



# Generated at 2022-06-24 02:22:46.934539
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'], write_environ={}) == {
        'TEST': os.path.join(expand('${HOME}'), 'yeee-', expand('${PATH}')),
        'THISIS': os.path.join(expand('~'), 'a', 'test'),
        'YOLO': os.path.join(expand('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }

# Generated at 2022-06-24 02:22:53.102897
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines_singlequote = ["'TEST'='${HOME}/yeee'", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]



# Generated at 2022-06-24 02:22:56.416128
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    print(f"Test results: {test_load_env_file()}")

# Generated at 2022-06-24 02:23:04.599906
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)
    assert result['TEST'] == '{}/yeee'.format(os.environ['HOME'])
    assert result['THISIS'] == '{}/a/test'.format(os.environ['HOME'])
    assert result['YOLO'] == "{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST".format(os.environ['HOME'])



# Generated at 2022-06-24 02:23:08.336152
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    text = """
# Comment
TEST=/home/user/app
NAME=Me
FOOBAR=
    """.strip()
    assert tuple(parse_env_file_contents(text.splitlines())) == (
        ('TEST', '/home/user/app'),
        ('NAME', 'Me'),
        ('FOOBAR', ''),
    )



# Generated at 2022-06-24 02:23:12.886819
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test: Basic
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert parse_env_file_contents(lines) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                              ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:23:24.309305
# Unit test for function expand
def test_expand():
    env = dict(
        A='a',
        HOME='/home/user',
        B='${A}',
        C='${HOME}/file.txt',
        D='"${B}"',
        E='"${HOME}"',
        F='"${HOME}/file.txt"',
        G='~/file.txt'
    )

    with patch.object(os.path, 'expandvars', new=lambda x: x) as mock_expandvars:
        mock_expandvars.side_effect = lambda x: x

        # Supposed to work like os.path.expandvars
        assert 'a' == expand('$A')
        assert '/home/user/file.txt' == expand('$HOME/file.txt')


# Generated at 2022-06-24 02:23:30.729939
# Unit test for function load_env_file
def test_load_env_file():
    """
    Tests load_env_file
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=None)



# Generated at 2022-06-24 02:23:38.585800
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests `parse_env_file_contents` with the provided input data.
    """
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-24 02:23:44.418427
# Unit test for function expand
def test_expand():
    home = os.path.expanduser("~")
    assert expand("~") == home, "the function should replace ~ with the home dir"

    assert expand("${HOME}") == home, "the function should replace ${HOME} with the home dir"

    assert expand("~/.local/bin/foo.bar") == os.path.expanduser("~/.local/bin/foo.bar"), "the function should expand both ~ and $HOME"

# Generated at 2022-06-24 02:23:51.088579
# Unit test for function expand
def test_expand():
    assert expand("~/test/test") == os.path.expanduser("~") + '/test/test'
    assert expand("${HOME}/test/test") == os.path.expandvars("${HOME}") + '/test/test'
    assert expand("${HOME}/test/test") == os.path.expandvars("${HOME}") + '/test/test'



# Generated at 2022-06-24 02:24:01.010771
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    # --

    assert (changes['TEST'] == os.path.join(expand('${HOME}'), 'yeee'))
    assert (changes['THISIS'] == expand('~/a/test'))
    assert (changes['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-24 02:24:11.133496
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    import doctest
    failure_count, test_count = doctest.testmod()
    assert test_count > 0
    assert failure_count == 0


# For testing, if executed as script

# Generated at 2022-06-24 02:24:22.260372
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # This test file contain the following values
    """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    with open(os.path.join('.', 'tests', 'test.env'), 'r') as test_file:
        lines = test_file.readlines()
        expected_values = dict(
            TEST='/home/user/yeee',
            THISIS='/home/user/a/test',
            YOLO='/home/user/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
        )


# Generated at 2022-06-24 02:24:30.198794
# Unit test for function load_env_file
def test_load_env_file():
    import os

    lines = ["TEST=${HOME}/yeee-$PATH"]

    env = os.environ.copy()
    env["PATH"] = "/usr/bin"
    env["HOME"] = "/home/yee"

    values = load_env_file(lines, write_environ=env)

    assert values == collections.OrderedDict([("TEST", "/home/yee/yeee-/usr/bin")])
    assert env["TEST"] == "/home/yee/yeee-/usr/bin"


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:24:40.466479
# Unit test for function expand
def test_expand():
    values = [
        ("$HOME", os.path.expanduser("~")),
        ("${HOME}", os.path.expanduser("~")),
        ("~", os.path.expanduser("~")),
        ("~/.", os.path.expanduser("~")),
        ("~/", os.path.expanduser("~")),
        ("~/a/b/c", os.path.expanduser("~") + "/a/b/c"),
        ("~/a/b/c", os.path.expanduser("~") + "/a/b/c"),
    ]

    for inp, outp in values:
        assert expand(inp) == outp



# Generated at 2022-06-24 02:24:45.382494
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = '''
        # Comment
        TEST=${HOME}/yeee
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''.split()
    parsed_vals = parse_env_file_contents(contents)
    for k, v in parsed_vals:
        if k in ('TEST', 'THISIS', 'YOLO'):
            assert k == k
        else:
            raise AssertionError('Invalid parsed value')



# Generated at 2022-06-24 02:24:46.174795
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.path.expanduser('~')

# Generated at 2022-06-24 02:24:47.040957
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:24:53.325578
# Unit test for function expand
def test_expand():
    # Test expansion of environment variables
    os.environ["ENV_TEST_VAR"] = "1"

    assert expand("$ENV_TEST_VAR") == "1"
    assert expand("$ENV_TEST_VAR/yolo") == "1/yolo"

    # Test expansion of tildes
    assert expand("~") == os.path.expanduser("~")
    assert expand("~/yolo") == os.path.expanduser("~") + "/yolo"



# Generated at 2022-06-24 02:25:05.310423
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile
    import unittest


# Generated at 2022-06-24 02:25:16.146897
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import pytest
    from os.path import dirname, join, pardir
    from pathlib import Path
    from kiss_headers.python import env_file_path
    from kiss_headers.python import env_file_path_strict
    from kiss_headers.python import env_file_path_dev
    from kiss_headers.python import env_file_path_dev_strict

    # relative path must exist
    assert load_env_file(env_file_path.parts)
    assert load_env_file(env_file_path_strict.parts)
    assert load_env_file(env_file_path_dev.parts)
    assert load_env_file(env_file_path_dev_strict.parts)

    # Load is not strict

# Generated at 2022-06-24 02:25:24.990475
# Unit test for function load_env_file
def test_load_env_file():
    import sys

    if sys.version_info[:2] <= (2, 7) or (3, 0) <= sys.version_info[:2] < (3, 3):
        import unittest2 as unittest
    else:
        import unittest

    class Test_load_env_file(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            changes = load_env_file(lines, write_environ=dict())


# Generated at 2022-06-24 02:25:31.898502
# Unit test for function expand
def test_expand():

    assert expand("~") == os.path.expanduser("~")

    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("${HOME}") == os.path.expandvars("${HOME}")

    assert expand("${DOTENV_UNIT_TEST_VAR}") == "TEST"



# Generated at 2022-06-24 02:25:41.664060
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

# Generated at 2022-06-24 02:25:43.900395
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == os.path.expanduser('~/test')
    assert expand('~/test') == os.path.expanduser('~/test')



# Generated at 2022-06-24 02:25:49.429619
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    string = """
LEVEL=INFO

# This is a comment

# Blank lines are OK

SOMEVAR=hi there
DYNAMIC=${SOMEVAR}
NESTED=${THAT_${ONE}_${ONE}}
"""

    expected = [
        ('LEVEL', 'INFO'),
        ('SOMEVAR', 'hi there'),
        ('DYNAMIC', 'hi there'),
        ('NESTED', '${THAT_${ONE}_${ONE}}'),
    ]

    actual = list(parse_env_file_contents(string.split('\n')))

    assert expected == actual, actual



# Generated at 2022-06-24 02:25:56.408287
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    changes = load_env_file(lines, write_environ=dict())

    assert changes == collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                               ('THISIS', '.../a/test'),
                                               ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    # Test with an open file
    changes = load_env_file(open('tests/fixtures/envfile/test.env'), write_environ=dict())

    assert changes

# Generated at 2022-06-24 02:26:03.162124
# Unit test for function expand
def test_expand():
    expand_list = {"/home/test": os.path.expanduser("~") + "/test",
                   "~/test": os.path.expanduser("~") + "/test",
                   "$HOME/test": os.environ["HOME"] + "/test",
                   "/home/test/$PWD": os.path.expanduser("~") + "/test/" + os.environ["PWD"],
                   "$HOME": os.environ["HOME"],
                   "~/": os.path.expanduser("~") + "/"}

    for string, value in expand_list.items():
        assert expand(string) == value



# Generated at 2022-06-24 02:26:14.342423
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    #
    # Test empty env file
    #
    lines = []
    assert len(list(parse_env_file_contents(lines))) == 0

    #
    # Test non-empty env file
    #
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    expected = [
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

# Generated at 2022-06-24 02:26:18.743413
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == expand("~")



# Generated at 2022-06-24 02:26:23.668126
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    lines_generator = (line for line in lines)

    result = load_env_file(lines_generator)

    # from pprint import pprint
    # pprint(result)



# Generated at 2022-06-24 02:26:31.576516
# Unit test for function expand
def test_expand():
    testcases = [("$HOME/jean/fils-de-hein", "..."),
                 ("~/jean/fils-de-hein", "..."),
                 ("$HOME/jean/fils-de-hein", "...")]

    for (input, expected) in testcases:
        output = expand(input)
        assert output == expected, "input `%s` expected `%s` but got `%s`"%(input, expected, output)



# Generated at 2022-06-24 02:26:38.772036
# Unit test for function expand
def test_expand():
    assert re.match(r'\A/home/\w+\Z', expand('$HOME'))
    assert re.match(r'\A.+/\w+\Z', expand('${HOME}/a'))
    assert re.match(r'\A.+/\w+\Z', expand('${HOME}/a'))

    assert re.match(r'\A.+/\w+\Z', expand('~/a'))

# Generated at 2022-06-24 02:26:43.650750
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = collections.OrderedDict()
    for k, v in parse_env_file_contents(lines):
        result[k] = v

    expected = collections.OrderedDict()
    expected['TEST'] = '${HOME}/yeee'
    expected['THISIS'] = '~/a/test'
    expected['YOLO'] = '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    assert result == expected



# Generated at 2022-06-24 02:26:51.801472
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = dict(parse_env_file_contents(lines))
    expected = {'TEST': '${HOME}/yeee-$PATH', 'THISIS': '~/a/test',
                'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    assert actual == expected



# Generated at 2022-06-24 02:26:54.616249
# Unit test for function expand
def test_expand():
    assert expand('./test') == os.path.abspath(os.curdir + '/test')
    assert expand('~/test') == expand('{home}/test'.format(home=os.environ['HOME']))



# Generated at 2022-06-24 02:27:00.141696
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
               ) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-24 02:27:03.780703
# Unit test for function expand
def test_expand():
    assert expand('.dotfile') == expand('$HOME') + '/.dotfile'
    assert expand('~/.dotfile') == expand('$HOME') + '/.dotfile'
    assert expand('$HOME/.dotfile') == expand('$HOME') + '/.dotfile'
    assert expand('$HOME/../dotfile') == expand('$HOME') + '/../dotfile'
    assert expand('$HOME/../.dotfile') == expand('$HOME') + '/../.dotfile'
    assert expand('$HOME/../../.dotfile') == expand('$HOME') + '/../../.dotfile'



# Generated at 2022-06-24 02:27:05.422546
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    (failures, _) = doctest.testmod()

    if failures > 0:
        exit(failures)

# Generated at 2022-06-24 02:27:16.740579
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    envs = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', os.path.expanduser(os.environ['HOME'] + '/yeee')), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]
    assert list(parse_env_file_contents(envs)) == expected
    # Verify that non-string iterables are also supported.

# Generated at 2022-06-24 02:27:19.212804
# Unit test for function expand
def test_expand():
    assert '/foo' == expand('$FOO/foo')



# Generated at 2022-06-24 02:27:20.952408
# Unit test for function expand
def test_expand():
    assert expand("~/ok") == expand("$HOME/ok")



# Generated at 2022-06-24 02:27:29.369873
# Unit test for function expand
def test_expand():
    """
    Unit test for function expand
    """
    assert expand("yeee") == "yeee"
    assert expand("~/yeee") == os.path.join(os.environ["HOME"], "yeee")
    assert expand("${HOME}/yeee") == os.path.join(os.environ["HOME"], "yeee")
    assert expand("~/a/test") == os.path.join(os.environ["HOME"], "a", "test")
    assert expand("$HOME/a/test") == os.path.join(os.environ["HOME"], "a", "test")

# Generated at 2022-06-24 02:27:38.136208
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    fp = io.StringIO()
    for line in lines:
        fp.write('{}\n'.format(line))
    fp.seek(0)

    result = parse_env_file_contents(fp)
    result = collections.OrderedDict(result)


# Generated at 2022-06-24 02:27:47.238182
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = collections.OrderedDict(parse_env_file_contents(lines))

    assert len(d) == 3

    assert 'TEST' in d
    assert d['TEST'] == '${HOME}/yeee'

    assert 'THISIS' in d
    assert d['THISIS'] == '~/a/test'

    assert 'YOLO' in d
    assert d['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:27:50.843987
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("$PATH:~/") == (os.path.expandvars("$PATH") + ":" + os.path.expanduser("~"))

# Generated at 2022-06-24 02:27:58.873602
# Unit test for function load_env_file
def test_load_env_file():
    import pytest  # type: ignore

    def _test(lines: typing.Iterable[str], expected: typing.Mapping[str, str]) -> None:
        res = load_env_file(lines, write_environ=d)
        assert res == expected
        assert d == expected

    d = {}
    _test(['TEST=yeee'], {'TEST': 'yeee'})

    d = {}
    _test(['TEST="yeee"'], {'TEST': 'yeee'})

    d = {}
    _test(["TEST='yeee'"], {'TEST': 'yeee'})

    d = {}

# Generated at 2022-06-24 02:28:04.604404
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [
        ("TEST", f"{expand('${HOME}')}/yeee-{expand('$PATH')}"),
        ("THISIS", f"{expand('~')}/a/test"),
        ("YOLO", f"{expand('~')}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    ]



# Generated at 2022-06-24 02:28:15.767975
# Unit test for function load_env_file
def test_load_env_file():
    import dotenv

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # First test to make sure it loads into an environment
    current_env = os.environ.copy()

    new_env = dotenv.load_env_file(lines)

    assert new_env['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee-{}'.format(os.environ['PATH']))
    assert new_env['THISIS'] == '~/a/test'

# Generated at 2022-06-24 02:28:25.348818
# Unit test for function expand
def test_expand():
    import os
    import sys

    old_home = os.environ['HOME']

    try:
        os.environ['HOME'] = '$TEST'

        os.environ['TEST'] = 'value'

        assert expand('$TEST') == 'value'
        assert expand('${HOME}/x') == 'value/x'
        assert expand('~/x') == 'value/x'

    finally:
        os.environ['HOME'] = old_home
        del os.environ['TEST']



# Generated at 2022-06-24 02:28:33.303973
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    return


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:28:42.787755
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output_dict = {x[0]: x[1] for x in parse_env_file_contents(lines)}
    assert output_dict == {
        'TEST': '.../yeee',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-24 02:28:48.682141
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:28:55.984846
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['TEST=${HOME}/yeee'])) == [('TEST', '.../yeee')]
    assert list(parse_env_file_contents(['THISIS=~/a/test'])) == [('THISIS', '.../a/test')]
    assert list(parse_env_file_contents(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == [
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]


# Generated at 2022-06-24 02:29:02.907489
# Unit test for function load_env_file
def test_load_env_file():
    from pathlib import Path
    from pprint import pformat

    dir = Path(__file__).parent.joinpath('fixture').resolve()

    load_env_file_path = dir.joinpath('load_env_file')
    load_env_file_contents = load_env_file_path.read_text().split('\n')

    current_env = dict()

    expected_env = dir.joinpath('load_env_file.expected').read_text()

    load_env_file(load_env_file_contents, current_env)

    assert pformat(current_env) == expected_env

# Generated at 2022-06-24 02:29:13.502767
# Unit test for function expand
def test_expand():
    vars = os.environ.copy()
    vars["HOME"] = "~/"

    assert expand("''") == ""
    assert expand("'a'") == "a"
    assert expand("'$HOME'") == "$HOME"
    assert expand("'${HOME}'") == "~/"
    assert expand("'${HOME}/a'") == "~/a"

    assert expand('""') == ""
    assert expand('"a"') == "a"
    assert expand('"$HOME"') == "$HOME"
    assert expand('"${HOME}"') == "~/"
    assert expand('"${HOME}/a"') == "~/a"

    assert expand("") == ""
    assert expand("a") == "a"
    assert expand("$HOME") == "~/"

# Generated at 2022-06-24 02:29:17.220089
# Unit test for function expand
def test_expand():
    import os

    current_dir = os.getcwd()
    assert expand(".").endswith(current_dir), expand(".")
    assert expand("$HOME").endswith(os.path.expanduser("~")), expand("$HOME")

    assert expand("~") == os.path.expanduser("~")

# Generated at 2022-06-24 02:29:27.252686
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([
        ('TEST', '.../.../yeee-...:...'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])
    assert load_env_file(lines) == expected



# Generated at 2022-06-24 02:29:39.856854
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST='${HOME}/yeee'",
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ]



# Generated at 2022-06-24 02:29:47.370957
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    result = dict(values)

    assert result['TEST'] == os.path.expanduser('~') + '/yeee'
    assert result['THISIS'] == os.path.expanduser('~') + '/a/test'
    assert result['YOLO'] == os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

