

# Generated at 2022-06-24 02:19:49.502904
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("$PATH") != os.path.expandvars("$PATH")
    assert expand("~") != os.path.expandvars("~")



# Generated at 2022-06-24 02:19:59.407342
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    actual = collections.OrderedDict(parse_env_file_contents(lines))

    expected = collections.OrderedDict([('TEST', '.../yeee'),
                                        ('THISIS', '.../a/test'),
                                        ('YOLO',
                                         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    assert actual == expected



# Generated at 2022-06-24 02:20:05.132211
# Unit test for function expand
def test_expand():
    test_cases = [
        ('/home/user', os.path.expanduser('/home/user')),
        ('$HOME', os.path.expanduser('$HOME')),
        ('~user', os.path.expanduser('~user')),
        ('~', os.path.expanduser('~')),
        ('${HOME}', os.path.expanduser('${HOME}')),
    ]
    for val, expected in test_cases:
        assert expected == expand(val)



# Generated at 2022-06-24 02:20:06.526222
# Unit test for function expand
def test_expand():
    assert expand("~/test") == "{}/test".format(os.path.expanduser("~"))



# Generated at 2022-06-24 02:20:14.751658
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Python 3.5.2
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict(HOME=expand('$HOME'), PATH=expand('$PATH'), USER=expand('$USER'))
    load_env_file(lines, write_environ=environ)
    assert environ['TEST'] == '{}/yeee'.format(expand('$HOME'))
    assert environ['THISIS'] == '{}/a/test'.format(expand('$HOME'))

# Generated at 2022-06-24 02:20:25.014407
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    >>> load_env_file(['TEST=a\n'], write_environ={})
    OrderedDict([('TEST', 'a')])
    """
    pass



# Generated at 2022-06-24 02:20:32.378887
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', '{}/yeee-{}'.format(os.getenv('HOME'), os.getenv('PATH')))
    assert next(values) == ('THISIS', os.path.join(os.getenv('HOME'), 'a', 'test'))
    assert next(values) == ('YOLO', os.path.join(os.getenv('HOME'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
   

# Generated at 2022-06-24 02:20:35.770954
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:20:47.492814
# Unit test for function load_env_file
def test_load_env_file():
    """
    Test environment variable setting from env file.
    """

    import tempfile

    env_file = tempfile.NamedTemporaryFile()


# Generated at 2022-06-24 02:20:53.833159
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:21:04.072017
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import pprint

    TEST_ENV_FILE_NAME = "test_env_file1.txt"
    env_file_content_lines = (
        "TEST1=$HOME",
        "TEST2=test value with spaces",
        "TEST3=testvalue",
        "TEST4=testvalue2",
        "TEST5=testvalue3",
        "TEST6=$NONEXISTENT_VAR1",
        "TEST7=$NONEXISTENT_VAR2",
        "TEST8=testvalue4",
        "TEST9='testvalue5'",
        'TEST10="testvalue6"',
        'TEST11="test value"'
    )


# Generated at 2022-06-24 02:21:06.507844
# Unit test for function expand
def test_expand():
    assert expand("~/home/folder") == os.path.expanduser("~/home/folder")
    assert expand("$HOME/home/folder") == os.path.expanduser("$HOME/home/folder")



# Generated at 2022-06-24 02:21:08.319531
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:21:17.819955
# Unit test for function expand
def test_expand():
    assert expand('') == ''
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('$GOROOT') == os.environ['GOROOT']
    assert expand('${GOROOT}') == os.environ['GOROOT']
    assert expand('$GOROOT/') == os.path.join(os.environ['GOROOT'], '')
    assert expand('${GOROOT}/') == os.path.join(os.environ['GOROOT'], '')
    assert expand('$GOPATH/src') == os.path.join(os.environ['GOPATH'], 'src')



# Generated at 2022-06-24 02:21:27.390979
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    home = os.path.expanduser("~")
    path = os.environ.get("PATH", "")

    assert result == collections.OrderedDict([('TEST', '{}/yeee'.format(home)), ('THISIS', '{}/a/test'.format(home)), ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(home))])

# Generated at 2022-06-24 02:21:33.708235
# Unit test for function expand
def test_expand():
    assert expand('$HOME/foo') == os.environ['HOME'] + '/foo'
    assert expand('~/foo') == os.environ['HOME'] + '/foo'
    assert expand('~/foo/$PATH') == os.environ['HOME'] + '/foo/' + os.environ['PATH']



# Generated at 2022-06-24 02:21:41.503983
# Unit test for function expand

# Generated at 2022-06-24 02:21:52.389324
# Unit test for function expand
def test_expand():
    """
    >>> test_expand()
    >>>
    """
    from tempfile import mkdtemp
    from shutil import rmtree
    tmp = mkdtemp()

# Generated at 2022-06-24 02:22:00.283551
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    contents = list(parse_env_file_contents(lines))
    assert contents == [('TEST', '.../yeee'), ('THISIS', '.../a/test'),
                        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:22:07.064083
# Unit test for function expand
def test_expand():
    assert expand('~') == expand('${HOME}')
    assert expand('~') == expand('$HOME')
    assert expand('~') == expand('%HOME%')
    assert expand('~') == expand('%HOME%')

    assert expand('~/test') == expand('${HOME}/test')
    assert expand('~/test') == expand('$HOME/test')
    assert expand('~/test') == expand('%HOME%/test')
    assert expand('~/test') == expand('%HOME%/test')

    assert expand('${PATH}') == expand('$PATH')
    assert expand('${PATH}') == expand('%PATH%')



# Generated at 2022-06-24 02:22:18.277674
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Asserts the following env file:
    # TEST=${HOME}/yeee-$PATH
    # THISIS=~/a/test
    # YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    #
    # Is equal to the following dict:
    env_dict = {
        "TEST": "~/yeee-~/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        "THISIS": "~/a/test",
        "YOLO": "~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }

    env_file_contents = ""

    # Put the env file contents into one string

# Generated at 2022-06-24 02:22:26.279629
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert tuple(parse_env_file_contents(lines)) == (('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-24 02:22:32.647469
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    logging.basicConfig(level=logging.DEBUG)

    f = open('test_env.txt')
    try:
        lines = f.readlines()
    finally:
        f.close()

    contents = parse_env_file_contents(lines)

    # logging.info('contents: %s', contents)
    ok_contents = ''.join(['{}\n'.format(v) for k, v in contents])
    logging.info('-----------------------------------------------------\n%s', ok_contents)

    ok_str = """TEST=/Users/jacob/Downloads/yeee
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
"""
    # logging.info('ok_str: %s', ok

# Generated at 2022-06-24 02:22:41.571066
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO

    s = '''\
TEST=$HOME/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    '''

    lines = load_env_file(StringIO(s))
    assert 'TEST' in lines
    assert f'{os.path.expanduser("~")}/yeee-{os.environ.get("PATH")}' == lines['TEST']
    assert f'{os.path.expanduser("~")}/a/test' == lines['THISIS']
    assert f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:22:47.354337
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'EOF']
    values = list(parse_env_file_contents(lines))

    assert len(values) == 2

    assert values[0][0] == 'TEST'
    assert values[0][1] == '${HOME}/yeee'

    assert values[1][0] == 'THISIS'
    assert values[1][1] == '~/a/test'



# Generated at 2022-06-24 02:22:55.838296
# Unit test for function load_env_file
def test_load_env_file():
    lines = """
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """
    lines = [x.strip() for x in lines.splitlines() if x.strip()]

    expected_output = collections.OrderedDict()
    expected_output['TEST'] = '.../yeee'
    expected_output['THISIS'] = '.../a/test'
    expected_output['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    actual_output = load_env_file(lines, write_environ=None)

    assert expected_output == actual_output



# Generated at 2022-06-24 02:23:04.986772
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = [
        "TEST=$HOME/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    # Fake the env
    _os_real_environ = os.environ
    os.environ = collections.OrderedDict()

    # Write to a temp file
    fp = io.StringIO("\n".join(lines))

    changed = load_env_file(lines)

    assert os.environ is not _os_real_environ

    # Now we restore
    os.environ = _os_real_environ

    assert "HOME" in os.environ
    assert os.environ["HOME"]

    #

# Generated at 2022-06-24 02:23:10.801674
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    [('TEST', .../yeee'), ('THISIS', .../a/test'), ('YOLO', .../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """
    contents = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    parsed_

# Generated at 2022-06-24 02:23:20.300746
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import unittest

    class ParseEnvFileContentsTestCase(unittest.TestCase):
        def test_parse_env_file_contents(self):
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            values = parse_env_file_contents(lines)

            self.assertEqual(len(values), 3)

            keys = (k for k, _ in values)
            self.assertIn('TEST', keys)
            self.assertIn('THISIS', keys)
            self.assertIn('YOLO', keys)

            for k, v in values:
                if k == 'TEST':
                    self.assertTuple

# Generated at 2022-06-24 02:23:29.004297
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', os.path.expanduser('~/yeee')), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(lines)) == expected

    # test for #37
    lines = ['#{}'.format(x) for x in range(5)]
    expected = []
    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-24 02:23:34.742859
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(['TEST=test', 'TEST2=test2']) == {'TEST': 'test', 'TEST2': 'test2'}
    assert load_env_file(['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']) == {
        'TEST': expand('${HOME}/yeee'), 'THISIS': expand('~/a/test'), 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

# Generated at 2022-06-24 02:23:37.734039
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")



# Generated at 2022-06-24 02:23:46.578658
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == dict(TEST=expand('${HOME}/yeee'), THISIS=expand('~/a/test'),
                                                        YOLO=expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    lines = ['TEST:$HOME/yeee']
    assert dict(parse_env_file_contents(lines)) == dict(TEST=expand('$HOME/yeee'))

# Generated at 2022-06-24 02:23:56.755970
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    env = dict(parse_env_file_contents(lines))
    assert re.match(r".*/yeee", env["TEST"])
    assert re.match(r".*/a/test", env["THISIS"])
    assert re.match(r".*/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST", env["YOLO"])

# Generated at 2022-06-24 02:24:00.623313
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Doesn't do much... just tests that the function parses it's self :)
    """
    env_file_lines = ["A=b", "C=d", "E=f"]

    load_env_file(env_file_lines)



# Generated at 2022-06-24 02:24:10.549488
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert len(env) == 3
    assert env['TEST'] == os.path.expandvars('${HOME}/yeee-$PATH')
    assert env['THISIS'] == os.path.expandvars('~/a/test')
    assert env['YOLO'] == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:24:21.725421
# Unit test for function load_env_file
def test_load_env_file():
    assert list(parse_env_file_contents(lines=['TEST=${HOME}/yeee',
                                               'THISIS=~/a/test',
                                               'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) ==\
           [('TEST', os.path.join(os.path.expanduser('~'), 'yeee')),
            ('THISIS', os.path.join(os.path.expanduser('~'), 'a/test')),
            ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))]


# Generated at 2022-06-24 02:24:25.446141
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:24:33.072236
# Unit test for function load_env_file
def test_load_env_file():
    environ = {}
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, environ)

    assert changes['TEST'] == os.path.join(os.environ['HOME'], 'yeee-' + os.environ['PATH'])
    assert changes['THISIS'] == os.path.join(os.environ['HOME'], 'a/test')
    assert changes['YOLO'] == os.path.join(os.environ['HOME'], 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:24:41.299269
# Unit test for function expand
def test_expand():
    before = "~/a/b"
    after = expand(before)
    assert before != after
    assert expand(after) == after

    before = "$HOME/a/b"
    after = expand(before)
    assert before != after
    assert expand(after) == after

    before = "~/a/b"
    after = expand(before)
    assert before != after
    assert expand(after) == after

    before = '${HOME}/a/b'
    after = expand(before)
    assert before != after
    assert expand(after) == after



# Generated at 2022-06-24 02:24:48.141092
# Unit test for function expand
def test_expand():
    assert expand('~/pip') == os.path.expanduser('~/pip')
    assert expand('~/pip') == os.path.expanduser('~/pip')
    assert expand('~/pip') == os.path.expanduser('~/pip')
    assert expand('${HOME}/pip') == os.path.expanduser('${HOME}/pip')
    assert expand('${HOME}/pip') == os.path.expanduser('${HOME}/pip')



# Generated at 2022-06-24 02:24:56.367177
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())

    assert isinstance(environ, collections.OrderedDict)
    assert len(environ) == 3

    # check for changes
    assert 'TEST' in environ
    assert environ['TEST'] == '.../.../yeee-...:...'

    assert 'THISIS' in environ
    assert environ['THISIS'] == '.../a/test'

    assert 'YOLO' in environ

# Generated at 2022-06-24 02:25:06.794212
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = list(parse_env_file_contents(lines))
    assert values == [('TEST', os.path.expanduser('~/yeee-$PATH')), ('THISIS', os.path.expanduser('~/a/test')), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:25:17.242086
# Unit test for function load_env_file
def test_load_env_file():
    try:
        import pytest
    except ImportError:
        pytest = None

    if pytest is None:
        raise ImportError("Unable to import pytest")

    # Note: The actual paths don't matter as long as they are consistent in the test
    # Nor does the path separator matter as long as it is consistent
    test_environ = dict(
        HOME="path/to/home",
        PATH="path_dir:path/dir:another/dir"
    )

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-24 02:25:24.162509
# Unit test for function load_env_file
def test_load_env_file():
    env = load_env_file([
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ])

    assert env == dict(
        TEST='${HOME}/yeee-$PATH',
        THISIS='~/a/test',
        YOLO='~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    )



# Generated at 2022-06-24 02:25:30.109130
# Unit test for function expand
def test_expand():
    vars = parse_env_file_contents(['A=${HOME}/test/${PATH}'])
    for key, value in vars:
        assert key == 'A'
        assert value == expand(value)

# Generated at 2022-06-24 02:25:41.259065
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    for v1, v2 in parse_env_file_contents(['test =test']):
        assert v1 == 'test'
        assert v2 == 'test'

    for v1, v2 in parse_env_file_contents(['test=test']):
        assert v1 == 'test'
        assert v2 == 'test'

    for v1, v2 in parse_env_file_contents(['test = test']):
        assert v1 == 'test'
        assert v2 == 'test'

    for v1, v2 in parse_env_file_contents(['test = test ']):
        assert v1 == 'test'
        assert v2 == 'test'


# Generated at 2022-06-24 02:25:49.073399
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', '.../yeee'),
                                                                                  ('THISIS', '.../a/test'),
                                                                                  ('YOLO',
                                                                                   '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-24 02:25:57.214507
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content_1 = ["TEST=${HOME}/yeee\n", "THISIS=~/a/test\n", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n"]
    content_2 = ["TEST='this is a test'\n", "THISIS=\"a test\"\n", "YOLO='~/this/is/a/test'\n"]
    content_3 = ["TEST=this is a test\n", "THISIS='a test'\n", "YOLO=\"~/this/is/a/test\"\n"]
    content_4 = ["TEST=\"this is a test\"\n", "THISIS='a test'\n", "YOLO='~/this/is/a/test'\n"]

# Generated at 2022-06-24 02:25:58.271456
# Unit test for function expand
def test_expand():
    assert "$HOME" in expand("$HOME")
    assert "~/" in expand("~")



# Generated at 2022-06-24 02:26:04.627223
# Unit test for function load_env_file
def test_load_env_file():
    import io

    os.environ['HOME'] = '...'
    os.environ['PATH'] = '...:...'

    sio = io.StringIO()
    sio.write(''.join(["TEST=${HOME}/yeee-${PATH}", '\n', "THISIS=~/a/test", '\n', "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]))
    sio.seek(0)

    _ = load_env_file(sio, write_environ=None)

    sio.close()



# Generated at 2022-06-24 02:26:06.334036
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(['PATH=/bin', "TEST='This is a test'"])



# Generated at 2022-06-24 02:26:11.277331
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()

    # Test if the function parses correctly
    assert load_env_file(lines, write_environ=environ) == collections.OrderedDict(
        [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    # Test if the write_environ parameter is respected

# Generated at 2022-06-24 02:26:13.091817
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.run_docstring_examples(parse_env_file_contents, globals(), verbose=True)



# Generated at 2022-06-24 02:26:20.795780
# Unit test for function expand
def test_expand():
    """
    >>> expand('~/test')
    '/home/.../test'
    >>> expand('${HOME}')
    '/home/...'
    >>> expand('${HOME}/test')
    '/home/.../test'
    >>> expand('${HOME}/test/${USER}')
    '/home/.../test/...'
    >>> expand('${PATH}')
    '...:...:...:...:...:...:...'
    """
    pass



# Generated at 2022-06-24 02:26:28.540300
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import pytest

    fp = io.StringIO(u"TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

    with pytest.raises(NameError):
        load_env_file(fp, write_environ=dict())


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 02:26:35.195580
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:26:46.165179
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # pylint: disable=unused-variable
    # Only runs during unit tests, not when using the module.
    import unittest
    import textwrap

    class TestParseEnvFileContents(unittest.TestCase):
        def test_example_from_docstring(self):
            # pylint: disable=no-member
            lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            actual = list(parse_env_file_contents(lines))

# Generated at 2022-06-24 02:26:53.756450
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents()) == []
    assert list(parse_env_file_contents([])) == []

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '.../.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]



# Generated at 2022-06-24 02:27:00.990802
# Unit test for function expand

# Generated at 2022-06-24 02:27:05.738621
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    print(doctest.testmod(verbose=True))


if __name__ == "__main__":
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:27:15.824788
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """Unit test for function parse_env_file_contents."""
    s = """\
HOME=~
EXPORT=/usr/local/bin
SINGLE_QUOTE='a single quoted string'
DOUBLE_QUOTE="a double quoted string"
"""
    result = parse_env_file_contents(s.split('\n'))
    expected_result = [
        ('HOME', '~'),
        ('EXPORT', '/usr/local/bin'),
        ('SINGLE_QUOTE', 'a single quoted string'),
        ('DOUBLE_QUOTE', 'a double quoted string'),
    ]
    assert list(result) == expected_result



# Generated at 2022-06-24 02:27:19.104026
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-24 02:27:21.220473
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(verbose=True)  # Print detailed info about tests run



# Generated at 2022-06-24 02:27:29.868980
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import sys

    test_load_env_file()

    print(sys.version)
    print("\nDone!")


# EOF

# Generated at 2022-06-24 02:27:37.227764
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from .test_load_env_file import TEST_ENV_VARS
    from .test_load_env_file import assert_equal

    env_file_contents = TEST_ENV_VARS
    env_parsed = list(parse_env_file_contents(env_file_contents))

    assert_equal(env_parsed, [
        ('TEST', '/home/test/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-24 02:27:47.437071
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO

    lines = StringIO("TEST='${HOME}/yeee-$PATH'\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    od = load_env_file(lines, write_environ=dict())
    assert od is not None
    assert len(od) == 3

    assert od["TEST"].startswith("/")
    assert od["TEST"].endswith("/yeee-")
    assert "$PATH" not in od["TEST"]

    assert od["THISIS"].startswith("/")
    assert od["THISIS"].endswith("/a/test")

    assert od["YOLO"].startswith("/")
   

# Generated at 2022-06-24 02:27:51.188502
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:28:00.253661
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:28:07.458865
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Coverage test for function parse_env_file_contents
    """
    data = [
        'TEST=$HOME/yeee',  # Local path
        'THISIS=~/a/test',  # Local path
        'YOLO=~/swaggins',  # Local path
    ]

    for item in parse_env_file_contents(data):
        pass



# Generated at 2022-06-24 02:28:08.652896
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')
    assert expand('~/a/test') == os.path.expanduser('~/a/test')



# Generated at 2022-06-24 02:28:15.865127
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = parse_env_file_contents(lines)
    res = list(res)
    assert res[0] == ('TEST', os.path.expanduser('~') + '/yeee')
    assert res[1] == ('THISIS', os.path.expanduser('~/a/test'))
    assert res[2] == ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))



# Generated at 2022-06-24 02:28:21.879455
# Unit test for function expand
def test_expand():
    assert os.path.expandvars('$HOME') == expand('$HOME')
    assert os.path.expanduser('~') == expand('~')

# Generated at 2022-06-24 02:28:25.441815
# Unit test for function expand
def test_expand():
    assert expand('~/test/test') == os.path.expanduser('~/test/test')



# Generated at 2022-06-24 02:28:33.046529
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """
    # comment
    TEST=${HOME}/yeee
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.strip().splitlines()

    # Excepted output value
    expect = collections.OrderedDict()
    expect['TEST'] = expand('${HOME}/yeee')
    expect['THISIS'] = expand('~/a/test')
    expect['YOLO'] = expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    assert load_env_file(lines) == expect



# Generated at 2022-06-24 02:28:41.688140
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = dict(parse_env_file_contents(lines))

    assert d['TEST'].endswith('yeee')
    assert d['THISIS'].endswith('a/test')
    assert d['YOLO'].endswith('swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:28:50.916269
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert {k: v for k, v in parse_env_file_contents(lines)} == {
        'TEST': '$HOME/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

# Generated at 2022-06-24 02:29:01.966424
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = (
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    )

    result = {'TEST': '.../yeee', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    for item in parse_env_file_contents(lines):
        assert item[1] == result[item[0]]



# Generated at 2022-06-24 02:29:12.633786
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', f'{os.path.expanduser("~")}/yeee-{os.environ.get("PATH")}'),
        ('THISIS', f'{os.path.expanduser("~")}/a/test'),
        ('YOLO', f'{os.path.expanduser("~")}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-24 02:29:20.051205
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # test that a line with = is successfully parsed
    result_dict = parse_env_file_contents('TEST=${HOME}/yeee-$PATH\n'.splitlines())
    assert tuple(result_dict)[0] == ('TEST', '.../.../yeee-...:...')

    # test that a line with = is successfully parsed with ~
    result_dict = parse_env_file_contents('THISIS=~/a/test\n'.splitlines())
    assert tuple(result_dict)[0] == ('THISIS', '.../a/test')

    # test that a line with = is successfully parsed with $$

# Generated at 2022-06-24 02:29:30.489132
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = [l for l in parse_env_file_contents(lines)]
    assert len(lines) == 3
    assert lines[0] == ("TEST", f"{os.environ['HOME']}/yeee")
    assert lines[1] == ("THISIS", f"{os.environ['HOME']}/a/test")
    assert lines[2] == ("YOLO", f"{os.environ['HOME']}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

# Generated at 2022-06-24 02:29:38.650255
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert len(env) == 3
    assert 'TEST' in env
    assert 'THISIS' in env
    assert 'YOLO' in env
    assert 'HOME' in env['TEST']
    assert 'PATH' in env['TEST']
    assert env['THISIS'].startswith('~/a/test')
    assert env['YOLO'].startswith('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:29:46.465243
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '.../.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]


if __name__ == '__main__':
    import doctest

    doctest.testmod()