

# Generated at 2022-06-24 02:19:44.364213
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file(open('tests/envfile'))



# Generated at 2022-06-24 02:19:51.089151
# Unit test for function expand
def test_expand():
    values_to_expected = {
        "": "",
        "$USER": os.environ.get("USER"),
        "$USER$PWD": os.environ.get("USER") + os.environ.get("PWD"),
        "$USER/herro": os.environ.get("USER") + "/herro",
        "~/herro": os.path.expanduser("~") + "/herro",
    }

    for value, expected in values_to_expected.items():
        assert expected == expand(value)



# Generated at 2022-06-24 02:20:02.288212
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import os
    import contextlib
    import textwrap

    @contextlib.contextmanager
    def get_temp_file(content):
        fd, fname = tempfile.mkstemp()
        os.close(fd)
        with open(fname, 'w') as fp:
            fp.write(content)
            fp.flush()
            yield fname

    @contextlib.contextmanager
    def get_temp_dir():
        temp_dir = tempfile.mkdtemp()
        os.chdir(temp_dir)
        yield temp_dir


# Generated at 2022-06-24 02:20:07.234473
# Unit test for function expand
def test_expand():
    assert expand(r'$HOME') != r'$HOME'
    assert expand('~') != '~'

# Generated at 2022-06-24 02:20:12.184111
# Unit test for function expand
def test_expand():
    assert os.path.expandvars('$HOME') == expand('$HOME')
    assert os.path.expanduser('~') == expand('~')

    if os.path.isfile('/usr/bin/env'):
        assert '/usr/bin/env' == expand('/usr/bin/env')
    else:
        # On windows there is no /usr/bin/env
        pass



# Generated at 2022-06-24 02:20:14.454018
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:20:20.206209
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    x = load_env_file(lines=lines, write_environ=dict())
    assert isinstance(x,  collections.OrderedDict)
    assert x == collections.OrderedDict([('TEST', os.getenv('HOME') + '/yeee'), ('THISIS', os.getenv('HOME') + '/a/test'), ('YOLO', os.getenv('HOME') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-24 02:20:24.287343
# Unit test for function expand
def test_expand():
    val = "/"

    val = expand(val)

    assert val == os.path.abspath("/")

    val = "$HOME"
    val = expand(val)

    assert val == os.path.abspath(os.path.expanduser("~"))



# Generated at 2022-06-24 02:20:24.905113
# Unit test for function expand
def test_expand():
    assert expand("~/hello") == expand("$HOME/hello")



# Generated at 2022-06-24 02:20:26.793484
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 02:20:38.000131
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit test for function `parse_env_file_contents`.
    """
    # Check lines with nothing
    assert list(parse_env_file_contents([])) == []

    assert list(parse_env_file_contents([""])) == []

    # Check lines with just values
    lines = ["key=value", "key2=value2", "key3=value3"]
    assert list(parse_env_file_contents(lines)) == [("key", "value"), ("key2", "value2"), ("key3", "value3")]

    lines = ['"key=value"', "'key2=value2'", 'key3="value3"']

# Generated at 2022-06-24 02:20:39.880819
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:20:43.786495
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> dict(load_env_file(lines, write_environ=dict()))
    {'TEST': '/home/test/yeee', 'THISIS': '/home/test/a/test', 'YOLO': '/home/test/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    """
    pass

# Generated at 2022-06-24 02:20:48.616868
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(['HERE=now', 'THERE=yes'])) == [('HERE', 'now'), ('THERE', 'yes')]



# Generated at 2022-06-24 02:20:57.378916
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee-'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:21:07.931945
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env_file_dict = dict(parse_env_file_contents(lines))
    assert env_file_dict['TEST'] == os.path.expandvars('${HOME}/yeee')
    assert env_file_dict['THISIS'] == os.path.expandvars('~/a/test')
    assert env_file_dict['YOLO'] == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:21:18.407951
# Unit test for function load_env_file
def test_load_env_file():
    options = (
        ("TEST=${HOME}/yeee", rf"TEST={expand('~')}/yeee"),
        ("THISIS=~/a/test", rf"THISIS={expand('~/a/test')}"),
        (rf"YOLO=~/swaggins/$NONEXISTENT", rf"YOLO={expand('~/swaggins/$NONEXISTENT')}"),
        ("EXPORTS=something/that/isnt/expanded", rf"EXPORTS=something/that/isnt/expanded"),
        ("HERE=here", "HERE=here"),
    )

    def _test_load_env_file(lines, readline_index, env_index):
        e = os.environ.copy()
        out = load_env_file

# Generated at 2022-06-24 02:21:20.105049
# Unit test for function expand
def test_expand():
    path1 = "~/a_path"
    path2 = os.path.expanduser(path1)

    assert expand(path1) == path2



# Generated at 2022-06-24 02:21:29.732139
# Unit test for function load_env_file
def test_load_env_file():
    # The .envs contains a '/' to check that path expansion is applied
    with open(os.path.join(os.path.dirname(__file__), ".envs"), "r", newline='\n') as fp:
        lines = fp.readlines()

    test_environ = os.environ.copy()  # copy the current environ
    load_env_file(lines, test_environ)

    assert test_environ["PATH"] == '/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/X11/bin'
    assert test_environ["TEST"] == '/home/georges/yeee-$PATH'
    assert test_environ["THISIS"] == '/home/georges/a/test'

# Generated at 2022-06-24 02:21:36.778472
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/test') == '/home/test'
    assert expand('~/test') == '/home/test'

    assert expand('${PATH}/test') == '/sbin:/bin:/usr/sbin:/usr/bin/test'
    assert expand('${PATH}:test') == '/sbin:/bin:/usr/sbin:/usr/bin:test'



# Generated at 2022-06-24 02:21:40.242946
# Unit test for function expand
def test_expand():
    assert expand('~/foo/bar/baz') == os.path.expanduser('~/foo/bar/baz')



# Generated at 2022-06-24 02:21:51.445447
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    assert result == collections.OrderedDict([
        ('TEST', '{}/yeee'.format(os.path.expanduser('~'))),
        ('THISIS', '{}/a/test'.format(os.path.expanduser('~'))),
        ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(os.path.expanduser('~')))
    ])

# Generated at 2022-06-24 02:22:02.192768
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:22:08.861550
# Unit test for function expand
def test_expand():
    # noqa: D103

    t = "~/a/dir"
    assert expand(t) == '.../a/dir'

    t = "$HOME/a/dir"
    assert expand(t) == '.../a/dir'

    t = "$HOME/a/dir/$HOME"
    assert expand(t) == '.../a/dir/...'

    t = "aaa-$HOME bbb-$PATH"
    assert expand(t) == 'aaa-... bbb-...'

    t = "${HOME}/a/dir"
    assert expand(t) == '.../a/dir'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:22:19.352954
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    A unit test for function parse_env_file_contents
    """

    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)

    assert next(values) == ('TEST', os.path.join(os.getenv('HOME'), 'yeee') + '-' + os.path.pathsep.join(os.getenv('PATH')))
    assert next(values) == ('THISIS', os.path.join(os.getenv('HOME'), 'a', 'test'))

# Generated at 2022-06-24 02:22:29.309589
# Unit test for function expand
def test_expand():
    # Arrange
    lines = [
        'TEST=$HOME/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    # Act
    loaded = load_env_file(lines)

    # Assert
    assert loaded['TEST'] != '$HOME/yeee'
    assert loaded['TEST'].endswith('/yeee')
    assert loaded['THISIS'] != '~/a/test'
    assert loaded['THISIS'].endswith('/a/test')
    assert loaded['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:22:35.381774
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:22:40.346002
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:22:41.676367
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:22:49.516458
# Unit test for function expand
def test_expand():
    assert expand("~/test.env") == os.path.join(os.path.expanduser("~"), "test.env")
    assert expand("$HOME/test.env") == os.path.join(os.path.expanduser("~"), "test.env")
    assert expand("${HOME}/test.env") == os.path.join(os.path.expanduser("~"), "test.env")
    assert expand("${HOMEPATH}/test.env") == os.path.join(os.path.expanduser("~"), "test.env")
    assert expand("$HOMEPATH/test.env") == os.path.join(os.path.expanduser("~"), "test.env")



# Generated at 2022-06-24 02:22:53.763017
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:22:58.645108
# Unit test for function load_env_file
def test_load_env_file():
    from zuper_ipce.test_utils import assert_object_roundtrip

    d = load_env_file(["PATH=$HOME/yeee", "PPP=~/a/test", "P=$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])

    for k, v in d.items():
        assert os.path.exists(expand(v)), (k, v)

    assert_object_roundtrip(d)

# Generated at 2022-06-24 02:23:03.758454
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    k, v = list(parse_env_file_contents(lines))[0]
    assert os.path.basename(v) == 'yeee'



# Generated at 2022-06-24 02:23:10.918163
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:23:15.829897
# Unit test for function expand
def test_expand():
    exp_val = expand('~/a/test')
    assert exp_val == os.getenv('HOME') + '/a/test'



# Generated at 2022-06-24 02:23:26.603362
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function load_env_file
        
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """

# Generated at 2022-06-24 02:23:33.330564
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)



# Generated at 2022-06-24 02:23:34.803618
# Unit test for function expand
def test_expand():
    """
    >>> expand('${USER}')
    '...'
    """



# Generated at 2022-06-24 02:23:37.774971
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:23:46.456551
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines, write_environ=dict())

    assert environ['TEST'] == os.getenv('HOME') + '/yeee'
    assert environ['THISIS'] == os.path.expanduser('~/a/test')
    assert environ['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


# Generated at 2022-06-24 02:23:48.633474
# Unit test for function expand
def test_expand():
    assert expand('~/test') == '.../test'


# Unit tests for function parse_env_file_contents

# Generated at 2022-06-24 02:23:55.343027
# Unit test for function expand
def test_expand():
    # TODO: Add more test cases
    cases = [
        ("~/foo", os.path.expanduser("~/foo")),
        ("$HOME/foo", os.path.expandvars("$HOME/foo"))
    ]

    for case in cases:
        y = expand(case[0])
        assert y == case[1]

    return True



# Generated at 2022-06-24 02:23:58.372608
# Unit test for function expand
def test_expand():
    assert expand("~/path") == os.path.expanduser("~/path")
    assert expand("$HOME/path") == os.path.expanduser("~/path")



# Generated at 2022-06-24 02:24:07.699852
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests function parse_env_file_contents
    """
    l = ["TEST=${HOME}/yeee", "${PATH}", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    assert list(parse_env_file_contents(l)) == [("TEST", expand("${HOME}/yeee")), ("THISIS", expand("~/a/test")),
                                                ("YOLO", expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"))]

# Generated at 2022-06-24 02:24:18.835476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import json
    import pytest

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert json.dumps(list(parse_env_file_contents(lines)), indent=4) == \
        '[\n    [\n        "TEST",\n        ".../yeee"\n    ],\n    [\n        "THISIS",\n        ".../a/test"\n    ],\n    [\n        "YOLO",\n        ".../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"\n    ]\n]'


# Generated at 2022-06-24 02:24:20.555189
# Unit test for function expand
def test_expand():
    assert os.path.exists(expand('~/'))



# Generated at 2022-06-24 02:24:26.842110
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import pprint

    with open('.env') as f:
        lines = [line for line in f.read().splitlines() if line]

    env = load_env_file(lines)
    pprint.pprint(env)
    assert env['TEST'] == os.path.expandvars('${HOME}/yeee-$PATH')
    assert env['THISIS'] == os.path.expandvars('~/a/test')
    assert env['YOLO'] == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:24:29.926204
# Unit test for function load_env_file
def test_load_env_file():
    env_lines = ["ENV1=value1", "ENV2=value2"]

    envs = load_env_file(env_lines, write_environ=dict())

    assert envs["ENV1"] == "value1"
    assert envs["ENV2"] == "value2"



# Generated at 2022-06-24 02:24:32.818962
# Unit test for function load_env_file
def test_load_env_file():
    with open(os.path.expanduser('~/.nbserver.env'), 'r') as file:
        load_env_file(file)



# Generated at 2022-06-24 02:24:43.187427
# Unit test for function expand
def test_expand():
    os.environ['env_1'] = 'env_1_val'
    os.environ['env_2'] = 'env_2_val'

    assert os.path.expandvars('$env_1') == 'env_1_val'
    assert expand('$env_1') == 'env_1_val'

    assert expand('~') == expand('$HOME')
    assert expand('~') == expand('${HOME}')
    assert expand('~') == expand('${HOME}')
    assert expand('~') == expand('${HOME}')
    assert expand('~') == expand('${HOME}')

    assert expand('~$env_1') == expand('$HOME/env_1_val')

    assert expand('~/$env_1') == expand('$HOME/env_1')

# Generated at 2022-06-24 02:24:55.062813
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee-$PATH') == '.../.../yeee-...:...'
    assert expand('~/a/test') == '.../a/test'
    assert expand('~/swaggins/$PATH') == '.../swaggins/$PATH'
    assert expand('~/swaggins/$PATH/test') == '.../swaggins/$PATH/test'
    assert expand('~/swaggins/${HOME}/test') == '.../swaggins/.../test'
    assert expand('~/swaggins/test') == '.../swaggins/test'
    assert expand('~/swaggins/test') == '.../swaggins/test'
    assert expand('~/swaggins/test') == '.../swaggins/test'

# Generated at 2022-06-24 02:25:03.083416
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)
    assert "TEST" in os.environ
    assert "THISIS" in os.environ
    assert "YOLO" in os.environ

# Generated at 2022-06-24 02:25:09.073688
# Unit test for function expand
def test_expand():
    path = '~/swaggins'
    expected = os.path.abspath(os.path.expanduser(path))
    assert expected == expand(path)

    path = '${HOME}/swaggins/'
    expected = os.path.abspath(os.path.expanduser(os.path.expandvars(path)))
    assert expected == expand(path)

    path = '~/swaggins/$PWD'
    expected = os.path.abspath(os.path.expanduser(os.path.expandvars(path)))
    assert expected == expand(path)

    path = '${HOME}/swaggins/$PWD'
    expected = os.path.abspath(os.path.expanduser(os.path.expandvars(path)))

# Generated at 2022-06-24 02:25:17.808879
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = '~'
    os.environ["TEST2"] = '~/foo'

    assert expand("~") == os.path.expanduser("~")
    assert expand("${TEST}/foo") == os.path.expanduser("~/foo")
    assert expand("$TEST2/foo") == os.path.expanduser("~/foo/foo")
    assert expand("${TEST2}/foo") == os.path.expanduser("~/foo/foo")


if __name__ == '__main__':
    test_expand()

# Generated at 2022-06-24 02:25:19.123327
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:25:27.343161
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = parse_env_file_contents(lines)

    for e in actual:
        assert isinstance(e, tuple)
        assert isinstance(e[0], str)
        assert isinstance(e[1], str)


# Generated at 2022-06-24 02:25:35.841098
# Unit test for function load_env_file
def test_load_env_file():
    # Arrange
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    # Act
    data = load_env_file(lines, dict())

    # Assert
    assert data == collections.OrderedDict([
        ('TEST', os.environ['HOME']+'/yeee'),
        ('THISIS', os.path.expanduser('~/a/test')),
        ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

# Generated at 2022-06-24 02:25:37.980477
# Unit test for function expand
def test_expand():
    assert expand('~') == os.path.expanduser('~')


if __name__ == '__main__':
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:25:48.511505
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        "TEST=${HOME}/yeee",
        "THISIS=~/a/test",
        'YOLO=~/swaggins/"$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"',
        "VARIABLE=value",
    ]
    values = parse_env_file_contents(lines)
    assert values
    assert next(values) == ("TEST", os.path.expanduser("~/yeee"))
    assert next(values) == ("THISIS", os.path.expanduser("~/a/test"))
    assert next(values) == ("YOLO", os.path.expanduser('~/swaggins/"$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"'))

# Generated at 2022-06-24 02:25:51.293467
# Unit test for function expand
def test_expand():
    value = expand('$HOME/$PATH')
    assert value is not None
    assert value != '$HOME/$PATH'



# Generated at 2022-06-24 02:25:55.892742
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    sample_input = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    expected_output = [('TEST', os.path.expanduser('~') + '/yeee'), ('THISIS', os.path.expanduser('~') + '/a/test')]
    assert expected_output == list(parse_env_file_contents(sample_input))



# Generated at 2022-06-24 02:26:00.594438
# Unit test for function expand
def test_expand():
    test_vals = {
        '~/thisisfake/butshouldexpand': os.path.expanduser('~/thisisfake/butshouldexpand'),
        '${HOME}/thisisfake/shouldexpand': os.path.expanduser('~/thisisfake/shouldexpand'),
        '$HOME/thisisfake/shouldexpand': os.path.expanduser('~/thisisfake/shouldexpand'),
        'noexpansionneeded': 'noexpansionneeded'
    }

    for val, val_expanded in test_vals.items():
        assert expand(val) == val_expanded

# Generated at 2022-06-24 02:26:10.729120
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestLoadEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            lines = [
                'TEST=$HOME/yeee-$PATH',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
            ]
            actual = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:26:17.620967
# Unit test for function expand
def test_expand():
    mapping = {
        "HOME": "/home/david",
        "ACTUAL_POST_TITLE": "You can also go to $HOME, but you can't come back",
    }

    for key, value in mapping.items():
        os.environ[key] = value

    assert expand("${HOME}") == mapping["HOME"]
    assert expand("~") == mapping["HOME"]
    assert expand("${ACTUAL_POST_TITLE}") == mapping["ACTUAL_POST_TITLE"]
    assert expand("${HOME}/hello") == os.path.join(mapping["HOME"], "hello")
    assert expand("~/hello") == os.path.join(mapping["HOME"], "hello")
    assert expand(mapping["ACTUAL_POST_TITLE"]) == mapping["ACTUAL_POST_TITLE"]
   

# Generated at 2022-06-24 02:26:18.594586
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:26:25.676637
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = """# Comment
    TEST=${HOME}/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """.splitlines()

    expected = [
        ('TEST', f'{os.environ["HOME"]}/yeee-{os.pathsep.join(os.environ["PATH"].split(os.pathsep))}'),
        ('THISIS', f'{os.environ["HOME"]}/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

    assert list(parse_env_file_contents(lines)) == expected


#

# Generated at 2022-06-24 02:26:34.716976
# Unit test for function load_env_file
def test_load_env_file():
    doctest.testmod()
    assert True


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--contents", action="store_true", help="Use stdin to load the file's contents, instead of the file name")
    parser.add_argument("FILE", type=str, help="The file to load.")
    args = parser.parse_args()

    lines = sys.stdin.readlines()

    if args.contents:
        contents = "".join(lines)
        changes = load_env_file(str.splitlines(contents))
    else:
        changes = load_env_file(lines, write_environ=None)


# Generated at 2022-06-24 02:26:37.967048
# Unit test for function expand
def test_expand():
    """
    >>> expand('~/test/${USER}')
    '.../test/...'
    """
    assert expand('~/test/${USER}') == '%s/test/%s' % (os.path.expanduser('~'), os.environ['USER'])

# Generated at 2022-06-24 02:26:42.757318
# Unit test for function load_env_file
def test_load_env_file():
    import os
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w+", prefix="xxx") as f:
        lines = [
            "AAA=test",
            f"BBB={os.environ['PATH']}",
            f"CCC={os.getcwd()}",
            f'DDD={os.path.abspath(__file__)}',
            "EEE=\n",
            "",
            'FFF="\n"\n',
            "GGG='\n'\n",
            "",
            "HHH=${PWD}/hhh\n",
            "",
        ]
        f.writelines(lines)
        f.flush()

        test_environ = load_env_file(lines, write_environ=dict())

        assert test_en

# Generated at 2022-06-24 02:26:46.865476
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    for v in values:
        assert len(v) == 2



# Generated at 2022-06-24 02:26:55.119601
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)
    assert next(values) == ('TEST', f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}')
    assert next(values) == ('THISIS', f'{os.environ["HOME"]}/a/test')
    assert next(values) == ('YOLO', f'{os.environ["HOME"]}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:27:01.289929
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    values = parse_env_file_contents(lines)
    assert values is not None

    d = dict(values)

    assert d is not None
    assert len(d) == 3
    assert d['TEST'] == expand('${HOME}/yeee')
    assert d['THISIS'] == expand('~/a/test')
    assert d['YOLO'] == expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:27:10.183285
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])

# Generated at 2022-06-24 02:27:20.464456
# Unit test for function load_env_file
def test_load_env_file():
    import contextlib
    import io
    import os

    def _test(lines: typing.List[str], environ: typing.Mapping[str, str], expected: typing.Mapping[str, str]) -> None:
        environ = dict(environ)

        with contextlib.ExitStack() as context:
            out = io.StringIO()
            context.enter_context(io.StringIO(newline=""))

            changes = load_env_file(lines, write_environ=environ)

            assert expected == changes

            for key, value in changes.items():
                assert value == environ[key]


# Generated at 2022-06-24 02:27:27.080067
# Unit test for function expand
def test_expand():
    assert expand('abc') == 'abc'
    assert expand('~/abc') == '.../abc'
    assert expand('$HOME') == '...'
    assert expand('$HOME/abc') == '.../abc'



# Generated at 2022-06-24 02:27:33.861978
# Unit test for function expand
def test_expand():
    val = '$HOME/yeee'
    exp = expand(val)

    assert val != exp
    assert exp.startswith('/')
    assert exp.endswith('/yeee')
    assert len(exp) == len(val) + len(os.environ['HOME'])


if __name__ == '__main__':
    lines = ['TEST=$HOME/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines))

# Generated at 2022-06-24 02:27:44.592217
# Unit test for function expand
def test_expand():
    path = '/tmp/'

    val = os.path.expandvars(os.path.expanduser('~/')) + path

    assert expand('~/' + path) == val
    assert expand('${HOME}/' + path) == val

    path = '/tmp/a'
    val = os.path.expandvars(os.path.expanduser('~/')) + path
    assert expand('~/' + path) == val
    assert expand('${HOME}/' + path) == val

    path = '/tmp/a/b/c'
    val = os.path.expandvars(os.path.expanduser('~/')) + path
    assert expand('~/' + path) == val
    assert expand('${HOME}/' + path) == val


# Generated at 2022-06-24 02:27:55.495453
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Unit tests for function parse_env_file_contents.
    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    from io import StringIO

    def mkdummy(l):
        return StringIO("\n".join(l))

    from unittest import TestCase, main

    class TestLoadEnvFile(TestCase):
        def test_parse_env_file_contents(self):
            results = dict(parse_env_file_contents(mkdummy(lines)))

# Generated at 2022-06-24 02:27:57.845442
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME') == os.environ['HOME']
    assert expand('${HOME}') == os.environ['HOME']



# Generated at 2022-06-24 02:28:04.382820
# Unit test for function load_env_file
def test_load_env_file():
    old_path = os.environ['PATH']
    old_home = os.environ['HOME']


# Generated at 2022-06-24 02:28:15.463437
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import contextlib

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    with contextlib.redirect_stdout(io.StringIO()):
        out = load_env_file(lines)

    assert out == collections.OrderedDict([
        ('TEST', os.environ['HOME'] + '/yeee'),
        ('THISIS', os.environ['HOME'] + '/a/test'),
        ('YOLO', os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-24 02:28:24.715142
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    # Create a mock version of the os.environ dict
    write_environ = dict()
    environ = dict(YOLO="yoo")
    write_environ.update(environ)

    # Create string of lines that would be in a .env file
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=${YOLO}']

    # Create a tuple of expected values (key, value)
    expected = (
        ("TEST", ".../yeee"),
        ("THISIS", ".../a/test"),
        ("YOLO", "yoo")
    )

    # Load the env file and compare the result
    result = load_env_file(lines, write_environ=write_environ)

# Generated at 2022-06-24 02:28:31.303604
# Unit test for function expand
def test_expand():
    environ = os.environ.copy()

    os.environ.update({'HOME': '/home/test', 'MYVAR': '/'})

    assert expand('$HOME') == '/home/test'
    assert expand('${HOME}/a') == '/home/test/a'
    assert expand('~/a') == '/home/test/a'
    assert expand('${MYVAR}/a') == '/a'
    assert expand('${NOTSET}/a') == '/a'

    os.environ.update(environ)



# Generated at 2022-06-24 02:28:34.117919
# Unit test for function expand
def test_expand():
    assert expand('${HOME}/foo') == os.path.expanduser('~/foo')
    assert expand('${OTHER_VAR}/foo') == os.path.expandvars('${OTHER_VAR}/foo')

# Generated at 2022-06-24 02:28:39.295177
# Unit test for function load_env_file
def test_load_env_file():
    filename = "test_env_file.env"
    contents = ["TEST=${HOME}/yeee-$PATH", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    with open(filename, "w") as env_file:
        for line in contents:
            env_file.write(line + "\n")

    os.environ["PATH"] = "test_path"
    home = os.path.expanduser("~")

    import_dict = load_env_file([line for line in open(filename)])
    import_dict = collections.OrderedDict((key, value.replace(home, "...")) for key, value in import_dict.items())

# Generated at 2022-06-24 02:28:50.471219
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)
    assert os.environ['TEST'] == os.path.expanduser('~/yeee-{}'.format(os.environ['PATH']))
    assert os.environ['THISIS'] == os.path.expanduser('~/a/test')
    assert os.environ['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    # Test without writing to os.environ

# Generated at 2022-06-24 02:29:02.752212
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    import tempfile

    class TestLoadEnvFile(unittest.TestCase):
        def setUp(self):
            self.env_file_env_var = 'ENV_FILE_TEST_FILE'

            old_env = {
                'HOME': tempfile.gettempdir(),
                'PATH': tempfile.gettempdir()
            }

            old_env = {k: expand(v) for k, v in old_env.items()}

            self._old_env = old_env
            self._current_env = os.environ.copy()

            os.environ.update(old_env)


# Generated at 2022-06-24 02:29:09.910823
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:29:11.948808
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    res = parse_env_file_contents()
    assert isinstance(res, collections.abc.Generator)



# Generated at 2022-06-24 02:29:15.129022
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:29:22.367310
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = {}

    for k, v in parse_env_file_contents(lines):
        values[k] = v

    assert values['TEST'] == os.path.expandvars('${HOME}/yeee-$PATH')
    assert values['THISIS'] == os.path.expandvars('~/a/test')
    assert values['YOLO'] == os.path.expandvars('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:29:30.881906
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    with mock.patch.dict('os.environ', {'HOME': '...', 'PATH': ':...'}):
        environ = load_env_file(lines, write_environ=None)

    assert isinstance(environ, collections.OrderedDict)

    assert environ['TEST'] == '.../.../yeee-...:...'
    assert environ['THISIS'] == '.../a/test'

# Generated at 2022-06-24 02:29:39.460683
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = 'TEST=${HOME}/yeee-$PATH\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    result = load_env_file(io.StringIO(lines))

    assert result['TEST'].startswith('/home/')
    assert result['TEST'].endswith('-')
    assert result['THISIS'].startswith('/home/')
    assert result['YOLO'].startswith('/home/')

# Generated at 2022-06-24 02:29:46.381737
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = list(parse_env_file_contents(lines))

    assert result == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

