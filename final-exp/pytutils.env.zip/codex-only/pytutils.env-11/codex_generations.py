

# Generated at 2022-06-24 02:19:53.311792
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import os
    from os.path import join

    from tempfile import TemporaryDirectory

    from urllib.parse import quote, urlsplit

    import subprocess

    from shutil import copyfile
    from collections import OrderedDict

    # Create dummy env file
    with TemporaryDirectory() as env_file_dir:
        env_file = join(env_file_dir, "test.env")
        invalid_env_file = join(env_file_dir, "invalid.env")
        invalid_env_file2 = join(env_file_dir, "invalid2.env")
        invalid_env_file3 = join(env_file_dir, "invalid3.env")
        invalid_env_file_with_blank_lines = join(env_file_dir, "invalid4.env")

        # content should

# Generated at 2022-06-24 02:20:01.878376
# Unit test for function load_env_file

# Generated at 2022-06-24 02:20:09.144976
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST="~/yeee"', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    filename_home = os.path.abspath(os.path.join(os.path.expanduser('~'), 'a', 'test'))
    filename_yolo = os.path.abspath(os.path.join(os.path.expanduser('~'), 'swaggins', '$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))

    values = parse_env_file_contents(lines)

    for v in values:
        key, value = v
        if key == 'TEST':
            assert value == os.path.expanduser

# Generated at 2022-06-24 02:20:15.271590
# Unit test for function expand
def test_expand():
    assert expand("$HOME/asdf") == os.environ['HOME'] + "/asdf"
    assert expand("~/asdf") == os.environ['HOME'] + "/asdf"



# Generated at 2022-06-24 02:20:26.412953
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    loaded_env_file = load_env_file(lines, write_environ=dict())
    assert loaded_env_file['TEST'] == '{}/yeee'.format(os.environ['HOME'])
    assert loaded_env_file['THISIS'] == '{}/a/test'.format(os.environ['HOME'])

# Generated at 2022-06-24 02:20:33.924330
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    res = load_env_file(lines, write_environ=dict())
    assert res == collections.OrderedDict([('TEST', '.../.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-24 02:20:44.818171
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected_results = collections.OrderedDict()
    expected_results['TEST'] = expand('${HOME}/yeee')
    expected_results['THISIS'] = expand('~/a/test')
    expected_results['YOLO'] = expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    result = collections.OrderedDict(parse_env_file_contents(lines))

    assert expected_results == result, 'Unexpected results:\n' + str(result)



# Generated at 2022-06-24 02:20:52.763449
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # The function returns a generator, so we need to use its `next` method
    # to fetch values.
    #
    # The generator itself is wrapped in a list to be able to use its
    # `assertEqual` method.
    assert list(parse_env_file_contents(["TEST='Double quoted string'"])) == [
        ("TEST", "Double quoted string")]
    assert list(parse_env_file_contents(["TEST='Single quoted string containing spaces'"])) == [
        ("TEST", "Single quoted string containing spaces")]
    assert list(parse_env_file_contents(["TEST=Double quoted string with spaces"])) == [
        ("TEST", "Double quoted string with spaces")]

# Generated at 2022-06-24 02:20:59.000275
# Unit test for function load_env_file
def test_load_env_file():
    try:
        import nose.tools as nt
    except ImportError:
        raise

    new_env = dict()

    test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(test_lines, write_environ=new_env)

# Generated at 2022-06-24 02:21:04.676951
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:21:05.731914
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:21:07.302544
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:21:14.705150
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test for empty file
    lines = []

    result = parse_env_file_contents(lines)

    assert result == []

    # Test for regular values
    lines = [
        'TEST=hi/hi/hi',
        'THISIS=4/4/4',
        'YOLO=3/3/3',
    ]

    result = parse_env_file_contents(lines)

    assert result == [
        ('TEST', 'hi/hi/hi'),
        ('THISIS', '4/4/4'),
        ('YOLO', '3/3/3'),
    ]

    # Test for quotes

# Generated at 2022-06-24 02:21:26.237026
# Unit test for function load_env_file
def test_load_env_file():
    """Checks if load_env_file works as expected."""
    from tempfile import NamedTemporaryFile
    import shutil


# Generated at 2022-06-24 02:21:35.110761
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert parse_env_file_contents(['TEST=${HOME}']) == {'TEST': os.environ['HOME']}
    assert parse_env_file_contents(['TEST="hello\nworld"']) == {'TEST': 'hello\nworld'}
    assert parse_env_file_contents(['TEST="hello\tworld"']) == {'TEST': 'hello\tworld'}
    assert parse_env_file_contents(['TEST=foo\tbar']) == {'TEST': 'foo\tbar'}
    assert parse_env_file_contents(['TEST=foo\\tbar']) == {'TEST': 'foo\\tbar'}


# Generated at 2022-06-24 02:21:42.220364
# Unit test for function expand
def test_expand():
    assert expand('~/a/b/c') == os.path.expanduser('~/a/b/c')
    assert expand('$HOME/a/b/c') == os.path.expanduser('~/a/b/c')
    assert expand('~/a/b/$HOME') == os.path.expanduser('~/a/b/$HOME')
    assert expand('${HOME}/a/b/c') == os.path.expanduser('~/a/b/c')
    assert expand('${HOME}/a/\\$HOME') == os.path.expanduser('~/a/$HOME')
    assert expand('~/a/b/c') == os.path.expanduser('~/a/b/c')


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-24 02:21:50.974895
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output = dict(parse_env_file_contents(lines))
    assert output['TEST'] == '.../yeee'
    assert output['THISIS'] == '.../a/test'
    assert output['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:21:57.083768
# Unit test for function load_env_file
def test_load_env_file():
    lines = yield from '''\
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
'''.splitlines()

    load_env_file(lines, write_environ={})



# Generated at 2022-06-24 02:22:05.200761
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ=dict())
    assert len(env) == 3
    assert env.get('TEST').endswith('/yeee')
    assert env.get('THISIS').endswith('/a/test')
    assert env.get('YOLO').endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:22:17.354297
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content_str = '''
        TEST=${HOME}/yeee-$PATH
        # this is a comment
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        '''

    content = content_str.splitlines(False)
    result = parse_env_file_contents(content)
    expected = [('TEST', '${HOME}/yeee-$PATH'),
                ('THISIS', '~/a/test'),
                ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert list(result) == expected, 'parse_env_file_contents failed'


# Generated at 2022-06-24 02:22:26.737945
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("~") == os.path.expanduser("~")

    # It is likely that we have a MAIL variable
    assert expand("$MAIL") == os.environ["MAIL"]

    # It is unlikely that we have a TEST_VARIABLE_THAT_DOES_NOT_EXIST variable
    assert expand("$TEST_VARIABLE_THAT_DOES_NOT_EXIST") == "$TEST_VARIABLE_THAT_DOES_NOT_EXIST"



# Generated at 2022-06-24 02:22:32.900204
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=\'a string\'',
        'TEST2="a string"',
        'TEST3=a ${TEST} string',
        'TEST4="a ${TEST} string"',
        'TEST5="a ${TEST} string',
        'TEST6="a ${TEST} string',
        'TEST7=a ${TEST} string',
        'TEST8=a ${TEST} string',
    ]

    vals = parse_env_file_contents(lines)

    assert next(vals) == ("TEST", "a string")
    assert next(vals) == ("TEST2", "a string")
    assert next(vals) == ("TEST3", "a a string string")

# Generated at 2022-06-24 02:22:41.663796
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    data = parse_env_file_contents(lines)
    data = list(data)

    assert data[0][0] == 'TEST'
    assert data[0][1] == '${HOME}/yeee-$PATH'
    assert data[1][0] == 'THISIS'
    assert data[1][1] == '~/a/test'
    assert data[2][0] == 'YOLO'
    assert data[2][1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:22:50.007343
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from io import StringIO

    lines = StringIO("""
    TEST=$HOME/yeee-$PATH
    THISIS=~/a/test
    YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
    """)

    variables = parse_env_file_contents(lines)

    assert isinstance(variables, collections.abc.Generator)

    a = list(variables)

    assert a[0][0] == "TEST"
    assert a[1][0] == "THISIS"
    assert a[2][0] == "YOLO"

    # Check that expansion works
    assert a[0][1].startswith(os.path.expanduser(os.path.expandvars("$HOME")))

# Generated at 2022-06-24 02:22:58.019731
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    print("Testing 'parse_env_file_contents'...")

    # Using '__file__' to ensure that this test does not accidentally work
    # for the test file.
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())
    print("Passed.")



# Generated at 2022-06-24 02:23:07.283230
# Unit test for function expand
def test_expand():
    assert expand('~') == os.environ.get('HOME')
    assert expand('~/') == os.environ.get('HOME') + '/'
    assert expand('~/Documents/') == os.environ.get('HOME') + '/Documents/'
    assert expand('${HOME}/Documents/') == os.environ.get('HOME') + '/Documents/'
    assert expand('$HOME/Documents/') == os.environ.get('HOME') + '/Documents/'
    assert expand('~/Documents') == os.environ.get('HOME') + '/Documents'
    assert expand('${HOME}/Documents') == os.environ.get('HOME') + '/Documents'
    assert expand('$HOME/Documents') == os.environ.get('HOME') + '/Documents'

# Generated at 2022-06-24 02:23:13.420677
# Unit test for function load_env_file
def test_load_env_file():
    # TODO: Move tests to test_loader_.py or test_expand_.py

    # TODO: Create a test env file, and use it in tests (don't use the string).

    txt = '''\
EMAIL=root
PASSWORD=root
PORT=80
DATABASE_URL=postgres://${EMAIL}:${PASSWORD}@localhost/${EMAIL}
'''
    environ = dict(EMAIL="username", PASSWORD="password")

    load_env_file(txt.splitlines(), write_environ=environ)

    assert environ == dict(
        EMAIL='username',
        PASSWORD='password',
        PORT='80',
        DATABASE_URL='postgres://username:password@localhost/username')

# Generated at 2022-06-24 02:23:21.451718
# Unit test for function expand
def test_expand():
    vars = [
        ("$HOME/path", os.path.join(os.path.expanduser("~"), "path")),
        ("~/path", os.path.join(os.path.expanduser("~"), "path")),
        ("${HOME}/path", os.path.join(os.path.expanduser("~"), "path")),
    ]
    for i, o in vars:
        assert expand(i) == o



# Generated at 2022-06-24 02:23:28.520155
# Unit test for function expand
def test_expand():
    # Test expansion of ${VAR} and ~
    os.environ["VAR"] = "/foo/bar"
    os.environ["HOME"] = os.path.expanduser("~")
    assert expand("${VAR}") == "/foo/bar"
    assert expand("${VAR}/${HOME}") == "/foo/bar/~"
    assert expand("~") == os.path.expanduser("~")
    assert expand("~/") == os.path.expanduser("~/")
    assert expand("~/workspace") == os.path.expanduser("~/workspace")



# Generated at 2022-06-24 02:23:36.109318
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = load_env_file(lines, write_environ=dict())
    assert isinstance(out, collections.OrderedDict)
    assert isinstance(out['TEST'], str)
    assert isinstance(out['THISIS'], str)
    assert isinstance(out['YOLO'], str)



# Generated at 2022-06-24 02:23:39.639852
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:23:43.733855
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME/test') == os.path.expandvars('$HOME/test')
    assert expand('${HOME}/test') == os.path.expandvars('${HOME}/test')



# Generated at 2022-06-24 02:23:48.434092
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:23:54.742312
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("${HOME}") == os.path.expandvars("${HOME}")


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:24:05.434098
# Unit test for function load_env_file
def test_load_env_file():
    assert {} == load_env_file([])
    assert {'TEST': '.../.../yeee-...:...'} == load_env_file(['TEST=${HOME}/yeee-$PATH'])
    assert {'TEST': '.../.../yeee-...:...', 'THISIS': '.../a/test', 'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'} == load_env_file(
        ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])



# Generated at 2022-06-24 02:24:13.397564
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)

    for k, v in values:
        assert v == expand(v)

    lines = ["""A="multiline
string" """, """B="another
multiline
string" """, "C=singleline"]

    values = list(parse_env_file_contents(lines))

    assert values[0][1] == "multiline\nstring"
    assert values[1][1] == "another\nmultiline\nstring"
    assert values[2][1] == "singleline"



# Generated at 2022-06-24 02:24:24.292560
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function `load_env_file`.
    """
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    r = load_env_file(lines, write_environ=dict())
    assert isinstance(r, collections.OrderedDict)
    assert r['TEST'] == f'{os.environ["HOME"]}/yeee-{os.environ["PATH"]}'
    assert r['THISIS'] == f'{os.environ["HOME"]}/a/test'

# Generated at 2022-06-24 02:24:28.929035
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:24:38.789802
# Unit test for function expand
def test_expand():
    """
    Tests the expand() function.
    """

    assert expand("~/test2") != "~/test2"
    assert expand("~/test2") == os.path.expanduser("~/test2")

    assert expand("${HOME}/test") != "${HOME}/test"
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")

    assert expand("${HOME}/test2") != "${HOME}/test2"
    assert expand("${HOME}/test2") == os.path.expandvars("${HOME}/test2")



# Generated at 2022-06-24 02:24:43.594690
# Unit test for function expand
def test_expand():
    assert expand('$HOME') == os.getenv('HOME')
    assert expand(os.path.expanduser('~')) == os.getenv('HOME')



# Generated at 2022-06-24 02:24:53.586846
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '%(HOME)s/yeee'), ('THISIS', '%(HOME)s/a/test'),
                ('YOLO', '%(HOME)s/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert list(parse_env_file_contents(lines)) == expected



# Generated at 2022-06-24 02:25:05.043007
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test normal case
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list_equal(parse_env_file_contents(lines),
                      [('TEST', expand('${HOME}/yeee')), ('THISIS', expand('~/a/test')),
                       ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    # Test empty case
    assert list_equal(parse_env_file_contents([]), [])

    # Test norma

# Generated at 2022-06-24 02:25:13.293438
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '~/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    actual = list(parse_env_file_contents(lines))

    assert expected == actual



# Generated at 2022-06-24 02:25:18.907293
# Unit test for function expand
def test_expand():
    check = os.path.exists
    if check("test"):
        os.mkdir("test")
    else:
        os.makedirs("test")
    os.environ["TEST"] = "test"

    lines = ["TEST2=~/$TEST"]
    out = load_env_file(lines)
    assert check(out["TEST2"])
    os.removedirs("test")



# Generated at 2022-06-24 02:25:24.166449
# Unit test for function expand
def test_expand():
    assert expand('~/') == os.path.expanduser('~/')
    assert expand('$HOME/') == os.path.expandvars('~/')



# Generated at 2022-06-24 02:25:33.820773
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ], write_environ=dict()) == {
        'TEST': '.../.../yeee-...:...',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }



# Generated at 2022-06-24 02:25:38.594084
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for k, v in parse_env_file_contents(lines):
        assert type(k) == str
        assert type(v) == str


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:25:44.741449
# Unit test for function load_env_file
def test_load_env_file():
    """
    Tests:
      - Single quoted
      - Double quoted
      - Expanded with current environment variables
      - Expanded ~/

    """
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)

# Generated at 2022-06-24 02:25:53.799741
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = dict(parse_env_file_contents(lines))

    assert env['TEST'] == '${HOME}/yeee'
    assert env['THISIS'] == '~/a/test'
    assert env['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


if __name__ == '__main__':
    import sys
    import doctest

    if sys.argv[1:]:
        load_env_file(sys.argv[1:], write_environ=None)
   

# Generated at 2022-06-24 02:26:00.620107
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")



# Generated at 2022-06-24 02:26:04.114652
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()



# Generated at 2022-06-24 02:26:12.473215
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.environ["HOME"]
    assert expand("${HOME}") == os.environ["HOME"]
    assert expand("${HOME}/test") == "%s/test" % os.environ["HOME"]
    assert expand("~/test") == "%s/test" % os.environ["HOME"]


if __name__ == "__main__":
    test_expand()

    for line in ['TEST=${HOME}/yeee', 'THISIS=~/a/test']:
        k, v = parse_env_file_contents([line]).__next__()
        print("%s -> %s" % (k, v))

    print("")
    print("Test loading env file")

# Generated at 2022-06-24 02:26:16.081050
# Unit test for function expand
def test_expand():
    assert expand("${HOME}/blah") == os.path.expanduser("~/blah")
    assert expand("~/blah") == os.path.expanduser("~/blah")



# Generated at 2022-06-24 02:26:20.641208
# Unit test for function expand
def test_expand():
    assert expand('~/.ssh') == '~/.ssh'
    assert expand('$HOME/.ssh') == '$HOME/.ssh'
    assert expand('${HOME}/.ssh') == os.path.expanduser('~/.ssh')



# Generated at 2022-06-24 02:26:22.706721
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:26:33.064352
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Test empty file
    lines = []
    assert list(parse_env_file_contents(lines)) == []

    # Test normal operations
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../.../yeee'),
                                                    ('THISIS', '.../a/test'),
                                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:26:43.646496
# Unit test for function expand
def test_expand():
    os.environ['TEST_ENV_VAR'] = 'Test value from environment'
    os.environ['HOME'] = 'Test home'
    os.environ['PATH'] = 'Test path'

    assert expand('v1') == 'v1'
    assert expand('${HOME}') == 'Test home'
    assert expand('${PATH}') == 'Test path'
    assert expand('${TEST_ENV_VAR}') == 'Test value from environment'
    assert expand('a${HOME}b') == 'aTest homeb'
    assert expand('a${HOME}b${PATH}c') == 'aTest homebTest pathc'

    del os.environ['TEST_ENV_VAR'], os.environ['HOME'], os.environ['PATH']


# Generated at 2022-06-24 02:26:53.866346
# Unit test for function load_env_file
def test_load_env_file():
    # Test 1
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

# Generated at 2022-06-24 02:26:59.832105
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(dict(parse_env_file_contents(lines)))
    assert dict(parse_env_file_contents(lines)) == {'TEST': expand('${HOME}/yeee'),
                                                    'THISIS': expand('~/a/test'),
                                                    'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}

# Generated at 2022-06-24 02:27:09.901335
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = list(parse_env_file_contents(lines))
    assert ('TEST', '${HOME}/yeee-$PATH') in values
    assert ('THISIS', '~/a/test') in values
    assert ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') in values


# res = load_env_file(open(".env_dev"))
# for k, v in res.items():
#     print(k, v)

# Generated at 2022-06-24 02:27:13.524274
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:27:20.464616
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    correct_dict = collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])

    for key, val in parse_env_file_contents(lines):
        assert key in correct_dict
        assert val == correct_dict[key]



# Generated at 2022-06-24 02:27:28.493633
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert dict(parse_env_file_contents(['TEST=${TEST}/yeee'])) == {'TEST': '${TEST}/yeee'}
    assert dict(parse_env_file_contents(['TEST="${TEST}"/yeee'])) == {'TEST': '"${TEST}/yeee"'}

# Generated at 2022-06-24 02:27:38.070417
# Unit test for function load_env_file
def test_load_env_file():
    import unittest.mock

    with unittest.mock.patch.dict(os.environ, clear=True):
        values = [
            'TEST=${HOME}/yeee-$PATH',
            'THISIS=~/a/test',
            'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        ]
        changes = load_env_file(values)

        assert changes == collections.OrderedDict([
            ('TEST', '.../.../yeee-...:...'),
            ('THISIS', '.../a/test'),
            ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        ])


# Generated at 2022-06-24 02:27:45.259732
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = parse_env_file_contents(lines)
    result = next(results)
    assert result[0] == 'TEST' and result[1] == '${HOME}/yeee-$PATH'
    result = next(results)
    assert result[0] == 'THISIS' and result[1] == '~/a/test'
    result = next(results)
    assert result[0] == 'YOLO' and result[1] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    not_

# Generated at 2022-06-24 02:27:55.836866
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"
    ]
    values = parse_env_file_contents(lines)

    for k, v in values:
        if k == "TEST":
            assert os.path.expanduser(v) == os.path.expanduser("~/yeee")
        elif k == "THISIS":
            assert os.path.expanduser(v) == os.path.expanduser("~/a/test")

# Generated at 2022-06-24 02:28:06.072840
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_env_file_content = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = [('TEST', '.../.../yeee-...:...'), ('THISIS', '.../a/test'),
                ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    assert list(parse_env_file_contents(test_env_file_content)) == expected



# Generated at 2022-06-24 02:28:13.804569
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:28:24.468049
# Unit test for function load_env_file
def test_load_env_file():
    import textwrap
    import collections
    import os

    lines = textwrap.dedent("""\
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
        """).splitlines()

    os.environ['HOME'] = os.path.expanduser('~')
    os.environ['PATH'] = os.pathsep.join(os.get_exec_path())

    changes = load_env_file(lines)

    assert isinstance(changes, collections.OrderedDict)

# Generated at 2022-06-24 02:28:25.215248
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:28:26.323276
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:28:34.150098
# Unit test for function load_env_file
def test_load_env_file():
    assert os.environ['PATH'] == load_env_file(['PATH=${HOME}/yeee-$PATH']).get('PATH')
    assert os.environ['PATH'] == load_env_file(['PATH=${HOME}/yeee-$PATH'], dict()).get('PATH')
    assert '~/yeee-' + os.environ['PATH'] == load_env_file(['PATH=~/yeee-$PATH']).get('PATH')
    assert '~/yeee-' + os.environ['PATH'] == load_env_file(['PATH=~/yeee-$PATH'], dict()).get('PATH')
    assert '~/yeee-$PATH' == load_env_file(['PATH=~/yeee-$PATH'], dict())['PATH']

# Generated at 2022-06-24 02:28:46.370747
# Unit test for function load_env_file
def test_load_env_file():
    from .base import ConfigBase
    from .env import EnvConfig
    from .file import File
    from .file_reader import read_file_lines
    from .typing import OptEnvironT

    config = ConfigBase.instance()

    # Add an env config with default environ
    config.add_config(EnvConfig(write_environ=os.environ))

    # Create an in-memory test file with env in it
    test_env_file = File("test.env", read_file_lines=read_file_lines, environ=OptEnvironT(os.environ))


# Generated at 2022-06-24 02:28:55.496825
# Unit test for function expand
def test_expand():
    # Test for expansion of shell variables
    os.environ["TEST_SHELL_VAR"] = "test"

    assert expand("${TEST_SHELL_VAR}") == "test"

    # Test for expansion of home directories
    # Imitation of os.path.expanduser
    # Works as of Python 3.5.2
    import os
    os.environ["HOME"] = "/home/test"
    assert expand("~") == "/home/test"

# Generated at 2022-06-24 02:29:04.209315
# Unit test for function load_env_file
def test_load_env_file():
    import io

    lines = io.StringIO(u"""VAR1=test
                            VAR2=test2
                            VAR3=${VAR1}
                        """)
    changes = load_env_file(lines)

    assert changes == collections.OrderedDict(
        [
            ("VAR1", "test"),
            ("VAR2", "test2"),
            ("VAR3", "test"),
        ]
    )

    lines = io.StringIO(u"""VAR1=test
                            VAR2=test2
                            VAR3=${VAR1}
                        """)
    environ = {}

    changes = load_env_file(lines, environ)


# Generated at 2022-06-24 02:29:09.950696
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:29:15.462634
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:29:21.574714
# Unit test for function load_env_file
def test_load_env_file():
    assert list(load_env_file([
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test'
    ]).items()) == [
        ('TEST', expand('${HOME}/yeee')),
        ('THISIS', expand('~/a/test'))
    ]


if __name__ == '__main__':
    """
    Default "main" for all Python files.
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:29:25.486322
# Unit test for function expand
def test_expand():
    assert expand("$HOME") == os.path.expanduser("~")
    assert expand("$YADDAYADDA") == "$YADDAYADDA"

# Generated at 2022-06-24 02:29:34.212429
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():

    # Python 3.6+
    from collections.abc import Mapping

    # unordered
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    test_output = parse_env_file_contents(lines)

    # ordered
    # test_output = parse_env_file_contents(lines)

    assert isinstance(test_output, type(iter(dict())))

    # Python 3.6+
    assert isinstance(test_output, typing.Generator)


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:29:39.423168
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(parse_env_file_contents(lines)) == dict(
        TEST=expand('${HOME}/yeee'),
        THISIS=expand('~/a/test'),
        YOLO=expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    )



# Generated at 2022-06-24 02:29:46.128525
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]