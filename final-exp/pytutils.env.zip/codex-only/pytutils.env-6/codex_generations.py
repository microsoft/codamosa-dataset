

# Generated at 2022-06-24 02:19:53.002505
# Unit test for function load_env_file
def test_load_env_file():
    import sys

    lines = [
        "test1=1",
        'test2="2"',
        "test3=3",
    ]

    result = load_env_file(lines)

    expected = {
        "test1": "1",
        "test2": "2",
        "test3": "3",
    }

    for key in expected:
        assert result[key] == expected[key]

    result = load_env_file(lines, write_environ=None)

    expected = {
        "test1": "1",
        "test2": "2",
        "test3": "3",
    }

    for key in expected:
        assert result[key] == expected[key]



# Generated at 2022-06-24 02:20:01.263480
# Unit test for function load_env_file
def test_load_env_file():
    from pprint import pformat

    lines = [
        "TEST=${HOME}/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]
    changes = load_env_file(lines)

    expected = pformat(
        {
            "TEST": os.path.expanduser("~/yeee-{}".format(os.environ["PATH"])),
            "THISIS": os.path.expanduser("~/a/test"),
            "YOLO": os.path.expanduser("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
        }
    )


# Generated at 2022-06-24 02:20:02.339451
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:20:05.744742
# Unit test for function expand
def test_expand():
    assert expand('$INVALID') == '$INVALID'
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('${INVALID}/something') == '$INVALID/something'
    assert expand('${HOME}/something') == os.path.expanduser('~/something')



# Generated at 2022-06-24 02:20:14.414414
# Unit test for function load_env_file
def test_load_env_file():
    lines = [
        'TEST=' + os.path.join('${HOME}', 'yeee-${PATH}'),
        'THISIS=' + os.path.join('~', 'a', 'test'),
        'YOLO=' + os.path.join('~', 'swaggins', '${NONEXISTENT_VAR_THAT_DOES_NOT_EXIST}'),
    ]

    r = load_env_file(lines, write_environ=None)  # pylint: disable=redefined-outer-name

# Generated at 2022-06-24 02:20:18.630453
# Unit test for function expand
def test_expand():
    vars = dict()
    vars['test'] = 'test'
    vars['t1'] = '$test'
    vars['t2'] = '${test}'
    vars['t3'] = '${test}foo'
    vars['t4'] = '${none}foo'

    for k, v in vars.items():
        assert expand(v) == vars[k]

    assert expand("~/foo") == os.path.expanduser("~/foo")



# Generated at 2022-06-24 02:20:26.876363
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import tempfile

    envfiles = ('TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    with tempfile.NamedTemporaryFile() as f:
        for line in envfiles:
            f.write(line.encode('utf-8'))
            f.write(b'\n')

        f.flush()
        load_env_file(line.decode('utf-8') for line in envfiles)
        load_env_file(open(f.name))
        assert [line.decode('utf-8') for line in open(f.name) == envfiles]

# Generated at 2022-06-24 02:20:36.483934
# Unit test for function expand
def test_expand():
    assert expand("/test/$TEST") == "/test/$TEST"
    assert expand("/test/") == "/test/"
    assert expand("/test") == "/test"
    assert expand("$TEST") == "$TEST"
    assert expand("$HOME/a/test") != "$HOME/a/test"
    assert expand("$HOME/a/test") != "/test/a/test"
    assert expand("~/a/test") != "$HOME/a/test"
    assert expand("~/a/test") != "~/a/test"
    assert expand("~/a/test") != "/test/a/test"



# Generated at 2022-06-24 02:20:39.880568
# Unit test for function expand
def test_expand():
    assert expand('~/test') == os.path.expanduser('~/test')
    assert expand('$HOME/test') == os.path.expandvars('$HOME/test')



# Generated at 2022-06-24 02:20:42.153251
# Unit test for function expand
def test_expand():
    assert expand('~/yeee') == os.path.join(os.getenv('HOME'), 'yeee')
    assert expand('$PATH') == os.getenv('PATH')
    assert expand('${PATH}') == os.getenv('PATH')

# Generated at 2022-06-24 02:20:51.032930
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    ret = parse_env_file_contents(lines)
    values = collections.OrderedDict(ret)
    assert values['TEST'] is not None
    assert values['YOLO'] is not None
    assert values['THISIS'] is not None

    assert os.path.basename(values['TEST']) == 'yeee'
    assert os.path.basename(values['THISIS']) == 'test'
    assert values['YOLO'] == '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'


# Unit

# Generated at 2022-06-24 02:20:52.921480
# Unit test for function expand
def test_expand():
    home = expand("~")
    assert "home" in home
    assert "/" in home

    assert expand("/test/test/${HOME}") == os.path.join("/test/test", home)

# Generated at 2022-06-24 02:20:59.790892
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile() as fh:
        fh.write(b'TEST=yeee\n')
        fh.flush()
        assert len(load_env_file([f'{fh.name}'])) == 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:10.643058
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import textwrap

    content = """
    PATH=${HOME}
    SOMETHING=${PATH}/yeee
    """
    content = textwrap.dedent(content).strip().split("\n")
    environ = load_env_file(content)

    # Check that dict is ordered dict
    assert isinstance(environ, collections.OrderedDict)

    # Check that dict has the right structure
    assert environ == {
        "PATH": expand("${HOME}"),
        "SOMETHING": expand("${PATH}/yeee"),
    }

    # Check that os.environ is updated
    assert os.environ["PATH"] == expand("${HOME}")
    assert os.environ["SOMETHING"] == expand("${PATH}/yeee")

    # Check that

# Generated at 2022-06-24 02:21:18.761862
# Unit test for function load_env_file
def test_load_env_file():
    import ddt

    @ddt.ddt
    class TestLoadEnvFile(unittest.TestCase):
        def setUp(self):
            self.original_env = os.environ.copy()

        def tearDown(self):
            os.environ.clear()
            os.environ.update(self.original_env)


# Generated at 2022-06-24 02:21:19.222602
# Unit test for function load_env_file
def test_load_env_file():
    pass



# Generated at 2022-06-24 02:21:24.587448
# Unit test for function load_env_file
def test_load_env_file():
    # https://stackoverflow.com/a/16667843/
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:21:33.774278
# Unit test for function load_env_file
def test_load_env_file():
    assert (
        load_env_file(
            [
                'TEST=${HOME}/yeee',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
            ]
        )
        == {
            'TEST': expand('${HOME}/yeee'),
            'THISIS': expand('~/a/test'),
            'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
        }
    )

# Generated at 2022-06-24 02:21:41.528665
# Unit test for function expand
def test_expand():
    home = os.environ.get('HOME', '~')
    test_dir = os.path.join(home, 'test')

    assert expand('~/omg') == os.path.join(home, 'omg')
    assert expand('~/omg:~/yeee') == '{0}/omg:{0}/yeee'.format(home)
    assert expand('$HOME/omg') == '{0}/omg'.format(home)
    assert expand('${HOME}/omg') == '{0}/omg'.format(home)

    os.environ['TEST_DIR'] = test_dir
    assert expand('${TEST_DIR}/haha') == '{0}/haha'.format(test_dir)


# Generated at 2022-06-24 02:21:47.603561
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:21:56.416982
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = parse_env_file_contents(lines)
    dictionary = dict(result)
    assert dictionary == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

# Generated at 2022-06-24 02:22:04.189845
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> parse_env_file_contents(lines)
    <generator object parse_env_file_contents at 0x...>
    >>> list(parse_env_file_contents(lines))
    [('TEST', '.../yeee'), ('THISIS', '.../a/test'), ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    """
    pass



# Generated at 2022-06-24 02:22:14.722784
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = collections.OrderedDict(parse_env_file_contents(lines))
    assert d['TEST'] == os.path.expanduser('~/yeee')
    assert d['THISIS'] == os.path.expanduser('~/a/test')
    assert d['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:22:17.058127
# Unit test for function expand
def test_expand():
    """
    >>> expand("${PATH}:/usr/local/bin")
    '.../...:/usr/local/bin'
    >>> expand("~/test")
    '.../test'
    """



# Generated at 2022-06-24 02:22:19.595626
# Unit test for function expand
def test_expand():
    assert expand('~') == 'module'

# Generated at 2022-06-24 02:22:24.776064
# Unit test for function expand
def test_expand():
    os.environ["TESTVAR"] = "testval"
    assert expand("~") == os.path.expanduser("~")
    assert expand("${TESTVAR}") == "testval"



# Generated at 2022-06-24 02:22:31.331535
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]
    result = parse_env_file_contents(lines)
    expected = [("TEST", f"{os.environ.get('HOME')}/yeee"), ("THISIS", f"{os.environ.get('HOME')}/a/test"),
                ("YOLO", f"{os.environ.get('HOME')}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")]
    for i, el in enumerate(result):
        assert el == expected[i]



# Generated at 2022-06-24 02:22:35.125269
# Unit test for function expand
def test_expand():
    a = "hi there ${HOME}"
    b = expand(a)
    assert b != a
    assert b.startswith(os.environ["HOME"])



# Generated at 2022-06-24 02:22:42.945155
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")
    assert expand("${HOME}/test") == os.path.expandvars("${HOME}/test")



# Generated at 2022-06-24 02:22:50.883371
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test env parsing.
    """
    env_file = """
DF_TEST=blah
VARIABLE=value
VARIABLE2 =value2
VARIABLE3 =  'value3'
VARIABLE4 ="value 4"
VARIABLE5 = "value 5"
VARIABLE6=value ${TEST}
VARIABLE7="value \${TEST}"
VARIABLE8="value ${TEST}"
VARIABLE9="value ${TEST}."
"VARIABLE10"="value ${TEST}."
"VARIABLE11"="value ${TEST}."
HOME=${HOME}
PATH=${PATH}:${HOME}/bin
"BAD VARIABLE"="value"
"BAD VARIABLE2"=value
"""

# Generated at 2022-06-24 02:22:58.828312
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    new_env = load_env_file(lines)

    assert new_env['TEST'] == '.../yeee-...'
    assert new_env['THISIS'] == '.../a/test'
    assert new_env['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:23:01.025296
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:23:09.321949
# Unit test for function expand
def test_expand():
    d = {
        'TEST': '$HOME/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

    EXPECTED = {
        'TEST': os.path.expanduser(os.path.expandvars(d['TEST'])),
        'THISIS': os.path.expanduser(os.path.expandvars(d['THISIS'])),
        'YOLO': os.path.expanduser(os.path.expandvars(d['YOLO']))
    }

    for key in d:
        exp = EXPECTED[key]


# Generated at 2022-06-24 02:23:15.530231
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    dict_ = dict(parse_env_file_contents(lines))
    assert dict_['TEST'] == os.environ['HOME'] + '/yeee'
    assert dict_['THISIS'] == os.environ['HOME'] + '/a/test'
    assert dict_['YOLO'] == os.environ['HOME'] + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:23:26.325688
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    write_environ = dict()

    changes = load_env_file(lines=lines, write_environ=write_environ)

    assert changes['TEST'] == os.path.join(os.environ['HOME'], f'yeee-{os.environ["PATH"]}')
    assert changes['THISIS'] == os.path.join(os.environ['HOME'], 'a', 'test')

# Generated at 2022-06-24 02:23:31.957771
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod(
        name="load_env_file",
        optionflags=doctest.NORMALIZE_WHITESPACE
    )

# Generated at 2022-06-24 02:23:39.583703
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), 'testenv.cfg')
    lines = [line.rstrip('\n') for line in open(filename)]
    environ = load_env_file(lines)
    assert environ is not None


if __name__ == '__main__':
    # Unit test for function load_env_file
    test_load_env_file()

# Generated at 2022-06-24 02:23:43.529495
# Unit test for function expand
def test_expand():
    assert expand('$HOME/a') == expand(os.path.expanduser('~/a'))
    assert expand('~/a') == expand(os.path.expanduser('~/a'))


if __name__ == "__main__":
    pass

# Generated at 2022-06-24 02:23:52.143157
# Unit test for function expand
def test_expand():
    val = "~/very/deep/path"
    val = expand(val)
    assert val == "/home/sebastian/very/deep/path", val

    val = "$HOME/very/deep/path"
    val = expand(val)
    assert val == "/home/sebastian/very/deep/path", val

    val = "$HOME/very/deep/$SOMENONEXISTENTVAR/path"
    val = expand(val)
    assert val == "/home/sebastian/very/deep/$SOMENONEXISTENTVAR/path", val

# Generated at 2022-06-24 02:24:04.138138
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert next(parse_env_file_contents(['TEST=${HOME}/yeee'])) == ('TEST', '.../yeee')
    assert next(parse_env_file_contents(['THISIS=~/a/test'])) == ('THISIS', '.../a/test')
    assert next(parse_env_file_contents(['YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])) == ('YOLO',
                                                                                                       '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:24:09.118119
# Unit test for function expand
def test_expand():
    assert expand('./test_file.txt') == os.path.abspath('./test_file.txt')
    assert expand('~/test_file.txt') == os.path.expanduser('~/test_file.txt')
    assert expand('${HOME}/test_file.txt') == os.path.expandvars('$HOME/test_file.txt')



# Generated at 2022-06-24 02:24:11.296789
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:24:13.811127
# Unit test for function expand
def test_expand():
    assert(expand("$HOME") == os.path.expanduser("$HOME"))
    assert(expand("~") == os.path.expanduser("~"))


# Generated at 2022-06-24 02:24:23.288159
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    res = parse_env_file_contents(lines)
    assert next(res) == ('TEST', '.../yeee')
    assert next(res) == ('THISIS', '.../a/test')
    assert next(res) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    assert len(list(res)) == 0



# Generated at 2022-06-24 02:24:32.063960
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    import shutil

    # Create a temporary folder
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file inside temporary folder
    fd, file_path = tempfile.mkstemp(dir=temp_dir)

    # Write to temporary file
    with open(fd, 'w') as f:
        test_text = '''# This is a comment
        TEST=${HOME}/yeee-$PATH
        THISIS=~/a/test
        YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'''

        f.write(test_text)

    # Clean up
    shutil.rmtree(temp_dir, ignore_errors=True)

    lines = test_text.split('\n')

# Generated at 2022-06-24 02:24:42.657701
# Unit test for function expand
def test_expand():
    # User Home
    assert expand('~') == os.path.expanduser('~')
    assert expand('~/foo') == os.path.expanduser(os.path.join('~', 'foo'))
    assert expand('~/foo/../bar') == os.path.expanduser(os.path.join('~', 'foo', '..', 'bar'))

    # Env Variables
    assert expand('${TEST}') == expand(os.environ['TEST'])
    assert expand('${TEST}/foo') == os.path.join(expand(os.environ['TEST']), 'foo')
    assert expand('${TEST}/foo/../bar') == os.path.join(expand(os.environ['TEST']), 'foo', '..', 'bar')

   

# Generated at 2022-06-24 02:24:54.959739
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_lines = ['TEST=${HOME}/yeee',
                 'THISIS=~/a/test',
                 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
                 'SPACE="A B"',
                 'SPACE2=\'A\ B\'',
                 'QUOTE"=A',
                 'QUOTE\'=B',
                 'ESCAPES="A \\" B"',
                 'ESCAPES2=\'A \\\' B\'']


# Generated at 2022-06-24 02:24:57.548076
# Unit test for function expand
def test_expand():
    # When
    file_path = expand('~/Desktop/')

    # Then
    assert file_path is not None



# Generated at 2022-06-24 02:25:03.397255
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Parse with no values given in env file
    assert parse_env_file_contents([]) == ()

    assert parse_env_file_contents(['TEST=${HOME}/yeee']) == (('TEST', os.path.expandvars('${HOME}/yeee')), )

    assert parse_env_file_contents(['TEST=${HOME}/yeee', 'TEST2=${PATH}']) == (('TEST', os.path.expandvars('${HOME}/yeee')), ('TEST2', os.path.expandvars('${PATH}')))



# Generated at 2022-06-24 02:25:09.292299
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests the functionality of parse_env_file_contents.
    """

    # List of test cases in the form:
    # (input_string_1, input_string_2, input_string_3, output_string_1, output_string_2, output_string_3)

# Generated at 2022-06-24 02:25:18.148049
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Tests function parse_env_file_contents
    """
    # Single line
    lines = ['TEST=${HOME}/yeee']
    result = list(parse_env_file_contents(lines))
    expected = [('TEST', '.../yeee')]
    assert result == expected

    # Multiple lines
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    result = list(parse_env_file_contents(lines))
    expected = [('TEST', '.../yeee'), ('THISIS', '.../a/test')]
    assert result == expected

    # Multiple lines with indented comments

# Generated at 2022-06-24 02:25:22.406511
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:25:29.602664
# Unit test for function load_env_file
def test_load_env_file():
    import io

    file_like = io.StringIO()
    file_like.write("TEST=${HOME}/yeee-$PATH\n")
    file_like.write("THISIS=~/a/test\n")
    file_like.write("YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n")
    file_like.seek(0)
    lines = file_like.readlines()
    write_environ = dict()

# Generated at 2022-06-24 02:25:40.947377
# Unit test for function load_env_file
def test_load_env_file():
    import io
    import os
    import unittest

    class LoadEnvFileTestCase(unittest.TestCase):
        def setUp(self):
            self.home = os.path.expanduser('~')
            self.path = os.path.pathsep.join((self.home, self.home))
            self.old_home = os.environ.get('HOME')
            self.old_path = os.environ.get('PATH')
            os.environ['HOME'] = self.home
            os.environ['PATH'] = self.path

        def tearDown(self):
            if self.old_home is not None:
                os.environ['HOME'] = self.old_home
            else:
                del os.environ['HOME']

# Generated at 2022-06-24 02:25:50.723054
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())

    import re
    import platform
    home_path = os.environ['HOME']
    path_sep = os.pathsep

    hostname = platform.node()

    p = re.compile(fr'.*{home_path}.*{path_sep}.*')
    assert p.match(result['TEST']) is not None

    p = re.compile(fr'.*{home_path}.*/a/test')
    assert p.match(result['THISIS']) is not None



# Generated at 2022-06-24 02:25:58.235802
# Unit test for function load_env_file
def test_load_env_file():
    import unittest
    import sys
    import io

    class TestLoadEnvFile(unittest.TestCase):
        def test_load_env_file(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

            # stdout = sys.stdout
            # sys.stdout = io.StringIO()
            # try:
            actual = load_env_file(lines)
            print(actual)
            # finally:
            #     sys.stdout = stdout

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLoadEnvFile)

# Generated at 2022-06-24 02:26:07.506833
# Unit test for function expand
def test_expand():
    tmp = "./test_expand_tmp.txt"
    try:
        os.putenv("TEST_ENV_VAR", "test_expand")
        f = open(tmp, "w")
        f.write(expand("$TEST_ENV_VAR/$I_DO_NOT_EXIST"))
        f.close

        f = open(tmp, "r")
        assert "test_expand/$I_DO_NOT_EXIST" == f.read()

        f = open(tmp, "w")
        f.write(expand("~/test_expand"))
        f.close()

        f = open(tmp, "r")
        assert expand("~/test_expand") == f.read()

    finally:
        os.remove(tmp)



# Generated at 2022-06-24 02:26:09.106075
# Unit test for function expand
def test_expand():
    val = "$HOME/yeee"
    val_expanded = expand(val)

    assert val_expanded



# Generated at 2022-06-24 02:26:13.866122
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    environ = load_env_file(lines, write_environ=dict())

    assert environ["TEST"] == os.path.join(os.environ["HOME"], "yeee")



# Generated at 2022-06-24 02:26:24.320373
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Simple test
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert (load_env_file(lines, write_environ=dict()) ==
            collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                     ('THISIS', '.../a/test'),
                                     ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]))

    # Test parsing backslashes; C.f. https://github.com/nickstenning/honcho/blob/master/honcho/py27compat.py


# Generated at 2022-06-24 02:26:30.657357
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    for k, v in parse_env_file_contents(lines):
        print(f'{k}={v}')



# Generated at 2022-06-24 02:26:36.254996
# Unit test for function expand
def test_expand():
    # "~"
    assert expand("~") == os.environ["HOME"]
    assert expand('~/') == os.environ['HOME'] + '/'

    # "$"
    assert os.getcwd() in expand('$PWD')
    assert '$' not in expand('{PWD}')

    # "~" + "$"
    assert expand('$HOME') == expand('~')

# Generated at 2022-06-24 02:26:41.446170
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = parse_env_file_contents(lines)
    output = list(output)
    test = [('TEST', '${HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    if output != test:
        raise AssertionError()



# Generated at 2022-06-24 02:26:42.716447
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:26:47.322648
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.abspath(os.path.expanduser('~'))



# Generated at 2022-06-24 02:26:58.080562
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file([]) == {}
    assert load_env_file(['']) == {}

    assert load_env_file(['TEST=value']) == {'TEST': 'value'}
    assert load_env_file(['THIS=value', '']) == {'THIS': 'value'}
    assert load_env_file(['THIS=value', 'nope']) == {'THIS': 'value'}

    assert load_env_file(['THIS=value', '#ignore']) == {'THIS': 'value'}
    assert load_env_file(['THIS=value', ' #ignore']) == {'THIS': 'value'}
    assert load_env_file(['THIS=value', '#ignore', '']) == {'THIS': 'value'}

# Generated at 2022-06-24 02:27:02.372130
# Unit test for function expand
def test_expand():
    """Test function expand."""
    # Test expansion of user home
    os.environ["HOME"] = "/home/user_abc"
    assert expand("~/file1.txt") == "/home/user_abc/file1.txt"
    assert expand("/home/user_abc/file2.txt") == "/home/user_abc/file2.txt"

    # Test expansion of shell variables
    os.environ["SOMEVAR"] = "someval"
    assert expand("$SOMEVAR") == "someval"
    assert expand("${SOMEVAR}") == "someval"

    # Test expansion of shell variables without value
    assert expand("$UNDEFINEDVAR") == ""
    assert expand("${UNDEFINEDVAR}") == ""



# Generated at 2022-06-24 02:27:10.473678
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]

    env_dict = load_env_file(lines, write_environ=None)

    assert env_dict == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ])



# Generated at 2022-06-24 02:27:19.610589
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    d = load_env_file(lines, write_environ=dict())
    assert d == collections.OrderedDict([
        ('TEST', expand('~/yeee')),
        ('THISIS', expand('~/a/test')),
        ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
    ])



# Generated at 2022-06-24 02:27:23.405773
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    env_data = ["key1=value1", "key2=value2"]
    result = parse_env_file_contents(env_data)
    for i, (k, v) in enumerate(result):
        assert k == "_".join(["key", str(i + 1)])
        assert v == "_".join(["value", str(i + 1)])



# Generated at 2022-06-24 02:27:29.241543
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.expandvars('${HOME}')
    assert expand('~') == os.path.expanduser('~')

    # Case insensitive
    assert expand('${HOMe}') == os.path.expandvars('${HOMe}')
    assert expand('~') == os.path.expanduser('~')



# Generated at 2022-06-24 02:27:38.126339
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    changes = load_env_file(lines, write_environ=environ)

    # Check the environ was populated
    assert(environ['TEST'] == changes['TEST'])

    # Check the changes was correct
    assert(changes['TEST'] == os.path.expanduser(os.path.expandvars(lines[0]).split('=')[1]))
    assert(changes['THISIS'] == os.path.expanduser(os.path.expandvars(lines[1]).split('=')[1]))

# Generated at 2022-06-24 02:27:44.382689
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io

    buf = io.StringIO("""
FOO=bar
SPAM="Eggs and bacon"
EGGS='Spam and eggs'
    """.strip())

    data = list(parse_env_file_contents(buf.readlines()))

    assert data == [
        ("FOO", "bar"),
        ("SPAM", "Eggs and bacon"),
        ("EGGS", "Spam and eggs")
    ]



# Generated at 2022-06-24 02:27:55.434998
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pytest import raises
    assert expand(os.getenv('HOME', ''))
    assert expand('~')
    assert expand('~/')
    assert expand('~/a/b/c') == os.path.join(expand('~'), 'a', 'b', 'c')

    assert list(parse_env_file_contents()) == []

    assert list(parse_env_file_contents([])) == []

    with raises(TypeError):
        list(parse_env_file_contents(range(10)))


# Generated at 2022-06-24 02:28:02.394401
# Unit test for function expand
def test_expand():
    assert expand('~/foo') == os.path.expanduser('~/foo')
    assert expand('${HOME}/foo') == os.path.expandvars(os.path.expanduser('~/foo'))
    assert expand('${HOME}') == os.path.expandvars(os.path.expanduser('~'))
    assert expand('~') == os.path.expanduser('~')
    assert expand('~nobody') == os.path.expanduser('~nobody')
    assert expand('~nobody/foo') == os.path.expanduser('~nobody') + '/foo'
    assert expand('${UNKNOWN}') == '${UNKNOWN}'

# Generated at 2022-06-24 02:28:14.866755
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.expanduser('~') + '/yeee'),
        ('THISIS', os.path.expanduser('~') + '/a/test'),
        ('YOLO', os.path.expanduser('~') + '/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    lines = [
        'TEST=${PATH}',
        'TEST2=$PATH'
    ]

# Generated at 2022-06-24 02:28:24.416361
# Unit test for function load_env_file
def test_load_env_file():
    # Specify the content of a env file
    ls = ['TEST=${HOME}/yeee-$PATH']
    # Load env file
    ds = load_env_file(ls, write_environ=os.environ.copy())
    # Verify that ds is a valid mapping type
    assert isinstance(ds, collections.abc.Mapping)
    # Verify that ds is not empty
    assert ds



# Generated at 2022-06-24 02:28:28.429627
# Unit test for function expand
def test_expand():
    assert expand('~/this/is/a/path') == os.path.expanduser('~/this/is/a/path')
    assert expand('${HOME}/yeee') == os.path.expandvars('${HOME}/yeee')

# Generated at 2022-06-24 02:28:33.046196
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, dict())
    print(result)
    assert isinstance(result, collections.OrderedDict)
    assert len(result) == 3

# Generated at 2022-06-24 02:28:33.513607
# Unit test for function load_env_file
def test_load_env_file():
    pass

# Generated at 2022-06-24 02:28:35.070127
# Unit test for function expand
def test_expand():
    assert expand("~") == os.environ["HOME"]
    assert expand("${HOME}") == os.environ["HOME"]



# Generated at 2022-06-24 02:28:47.415973
# Unit test for function load_env_file
def test_load_env_file():
    import re
    import contextlib

    class DummyEnviron(dict):
        def __getitem__(self, key):
            try:
                return dict.__getitem__(self, key)
            except KeyError as e:
                return ""

    environ = DummyEnviron()

    @contextlib.contextmanager
    def dummy_home_directory(path: str):
        environ["HOME"] = path
        yield
        del environ["HOME"]

    def assert_load_env_file(lines: typing.Iterable[str], expected_environ: typing.MutableMapping):
        actual_environ = dict()
        load_env_file(lines, actual_environ)

        assert actual_environ == expected_environ


# Generated at 2022-06-24 02:29:00.375304
# Unit test for function expand
def test_expand():
    import os
    import unittest

    path_home = os.path.expanduser('~')
    path_tmp = os.path.join(path_home, 'tmp')

    TEST = '/tmp'
    path_test = os.path.join(TEST, 'test')

    os.environ['TEST'] = TEST

    t = unittest.TestCase('__init__')

    t.assertEqual(expand('${HOME}'), path_home)
    t.assertEqual(expand('~'), path_home)
    t.assertEqual(expand('/~tmp'), path_tmp)
    t.assertEqual(expand('$TEST'), TEST)
    t.assertEqual(expand('${TEST}/test'), path_test)

# Generated at 2022-06-24 02:29:05.546840
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == {
        'TEST': expand('${HOME}/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    }



# Generated at 2022-06-24 02:29:16.086670
# Unit test for function expand
def test_expand():
    v = 0
    assert v == 0
    # Test that expand works as intended
    os.environ["TEST"] = "Some Value"
    assert expand("$TEST") == "Some Value"
    os.environ["OTHER"] = os.path.abspath("test_parse.py")
    assert expand("$OTHER") == os.path.abspath("test_parse.py")
    assert expand("~") == os.path.expanduser('~')
    assert expand("~/") == os.path.expanduser('~') + '/'
    # Test that expand does nothing if it doesn't exist
    assert expand("NONEXISTENT") == "NONEXISTENT"
    assert expand("${NONEXISTENT}") == "${NONEXISTENT}"

# Generated at 2022-06-24 02:29:21.239501
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    print(load_env_file(lines, write_environ=dict()))


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:29:25.719243
# Unit test for function expand
def test_expand():
    test_string = "foo/bar"
    assert expand(test_string) == os.path.expanduser(os.path.expandvars(test_string))

# Generated at 2022-06-24 02:29:26.509762
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:29:31.032535
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines)
    assert True


if __name__ == '__main__':
    # Unit test for function parse_env_file_contents
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:29:39.737381
# Unit test for function load_env_file
def test_load_env_file():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-24 02:29:45.151344
# Unit test for function load_env_file
def test_load_env_file():
    s = """
DATABASE_URL=${DATABASE_URL_BASE_PROD}/mytest
DATABASE_URL_BASE_PROD=postgres://localhost/test
"""  # nopep8
    load_env_file(s.split(), write_environ=os.environ)

    assert os.environ['DATABASE_URL'] == 'postgres://localhost/test/mytest'

