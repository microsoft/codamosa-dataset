

# Generated at 2022-06-24 02:19:45.435830
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), 'test_env.txt')
    with open(filename, 'r') as file:
        lines = file.readlines()

    load_env_file(lines)

    assert os.environ['TEST_VAR'] == 'test_value_with_equals_sign=yes'
    assert os.environ['MULTILINE_VAR'] == 'multi-line\\nvalue'
    assert os.environ['SINGLE_QUOTED_VAR'] == 'single-quoted value'
    assert os.environ['DOUBLE_QUOTED_VAR'] == 'double quoted value'
    assert os.environ['TRAILING_COMMENT_VAR'] == 'value with trailing comment'


# Generated at 2022-06-24 02:19:47.605422
# Unit test for function expand
def test_expand():
    assert expand('~/a/path') == os.path.join(os.environ['HOME'], 'a', 'path')

# Generated at 2022-06-24 02:19:57.787037
# Unit test for function load_env_file
def test_load_env_file():
    tests = {
        "TEST": "TEST=/home/matt/yeee",
        "THISIS": "THISIS=~/a/test",
        "YOLO": "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    }

    for t in tests:
        m = re.match(r"\A(?P<name>[A-Za-z_0-9]+)=(?P<value>.*)\Z", tests[t])

        pickle_home = expand(os.path.join("~", ".pickle"))


# Generated at 2022-06-24 02:20:06.513666
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [
        ('TEST', os.path.join(os.path.expanduser('~'), 'yeee')),
        ('THISIS', os.path.join(os.path.expanduser('~'), 'a', 'test')),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    ]

# Generated at 2022-06-24 02:20:09.280151
# Unit test for function expand
def test_expand():
    assert expand("~/tmp") == os.path.expanduser("~/tmp")
    assert expand("${HOME}/tmp") == os.path.expandvars("${HOME}/tmp")
    assert expand("$HOME/tmp") == os.path.expandvars("$HOME/tmp")



# Generated at 2022-06-24 02:20:19.436843
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    a = parse_env_file_contents(lines=[
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ])

    b = {k: expand(v) for k, v in a}

    assert b['TEST'] == os.path.join(os.path.expanduser('~'), 'yeee')
    assert b['THISIS'] == os.path.join(os.path.expanduser('~'), 'a', 'test')

# Generated at 2022-06-24 02:20:21.937772
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    content = parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert content

# Generated at 2022-06-24 02:20:23.368108
# Unit test for function expand
def test_expand():
    """
    >>> expand('~')
    '/home/yourname'
    """



# Generated at 2022-06-24 02:20:28.233894
# Unit test for function load_env_file
def test_load_env_file():
    """
    This test ensures that load_env_file is behaving as expected.
    """

    # Test set to compare output from load_env_file
    expected_change_set = {'HOME', 'PATH', 'TEST', 'THISIS', 'YOLO'}
    # Expected changes for load_env_file
    expected_changes = {
        'TEST': '~/yeee-~/anaconda2/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

    # Expected changes for load_env_file on windows

# Generated at 2022-06-24 02:20:36.516807
# Unit test for function expand
def test_expand():
    test_cases = (
        (r'$HOME', os.path.expanduser('~')),
        (r'${HOME}', os.path.expanduser('~')),
        (r'~', os.path.expanduser('~')),
        (r'~/a/test', os.path.expanduser('~/a/test')),
    )

    for test_case in test_cases:
        assert expand(test_case[0]) == test_case[1]



# Generated at 2022-06-24 02:20:46.347878
# Unit test for function expand
def test_expand():
    cwd = os.getcwd()
    os.environ['TEST'] = cwd
    os.environ['TEST_PATH'] = cwd + '/test'
    assert(expand('$TEST') == cwd)
    assert(expand('~') == os.path.expanduser('~'))
    assert(expand('${TEST}/foo') == cwd + '/foo')
    assert(expand('${TEST_PATH}/foo') == cwd + '/test/foo')
    os.environ.pop('TEST')
    os.environ.pop('TEST_PATH')

# Generated at 2022-06-24 02:20:52.919668
# Unit test for function expand
def test_expand():
    TESTS = [
        ("~", os.path.expanduser("~")),
        ("..", os.path.expanduser("..")),
        ("$HOME", os.path.expanduser("$HOME")),
        ("$$", "$$"),
        ("", ""),
    ]

    for val, expected in TESTS:
        assert expand(val) == expected


if __name__ == "__main__":
    lines = [
        "TEST=$HOME/yeee-$PATH",
        "THISIS=~/a/test",
        "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST",
    ]

    print(load_env_file(lines))

# Generated at 2022-06-24 02:20:59.128444
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    env = load_env_file(lines, write_environ=dict())

    assert(len(env) == 3)
    assert(isinstance(env, collections.OrderedDict))
    assert(env['TEST'] != os.path.join(expand('$HOME'), 'yeee-$PATH'))
    assert(env['THISIS'] == os.path.join(expand('~'), 'a', 'test'))

# Generated at 2022-06-24 02:21:01.535362
# Unit test for function expand
def test_expand():
    pass



# Generated at 2022-06-24 02:21:08.398757
# Unit test for function expand
def test_expand():
    test_path = '~/test_path'
    result_path = os.path.expanduser(test_path)
    assert expand(test_path) == result_path

    test_path = '$HOME/test_path'
    result_path = os.path.join(os.path.expanduser('~'), 'test_path')
    assert expand(test_path) == result_path



# Generated at 2022-06-24 02:21:18.554318
# Unit test for function load_env_file
def test_load_env_file():
    fd, path = tempfile.mkstemp()
    os.write(fd, "# a comment\n".encode("ascii"))
    os.write(fd, "TEST=${HOME}/yeee-$PATH\n".encode("ascii"))
    os.write(fd, "THISIS=~/a/test\n".encode("ascii"))
    os.write(fd, "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n".encode("ascii"))
    os.write(fd, "TEST2='fancy hats'\n".encode("ascii"))
    os.write(fd, 'TEST3="fancy\nhats"\n'.encode("ascii"))

# Generated at 2022-06-24 02:21:26.664528
# Unit test for function load_env_file
def test_load_env_file():
    import unittest.mock as mock

    with mock.patch('os.environ') as environ:
        environ.__contains__.side_effect = lambda x: x in {'PATH', 'HOME'}
        environ.__getitem__.side_effect = lambda x: {
            'PATH': '/test/path:/test/test/foo',
            'HOME': '/test/test/test/test'
        }[x]

        lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']


# Generated at 2022-06-24 02:21:33.140730
# Unit test for function expand
def test_expand():
    os.environ["TEST"] = "testtest"

    assert expand("$TEST") == "testtest"
    assert expand("${TEST}") == "testtest"
    assert expand("${TEST}$TEST") == "testtesttesttest"

    with pytest.raises(KeyError):
        expand("${UNEXISTANT_VAR}")

    with pytest.raises(KeyError):
        expand("$UNEXISTANT_VAR")

# Generated at 2022-06-24 02:21:41.309257
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee',
             'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
             ]

    expected = [('TEST', os.path.expanduser('${HOME}') + '/yeee'),
                ('THISIS', os.path.expanduser('~/a/test')),
                ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
                ]

    for item in parse_env_file_contents(lines):
        assert item in expected


if __name__ == "__main__":
    import doctest

    doctest.test

# Generated at 2022-06-24 02:21:46.184914
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == '__main__':
    test_parse_env_file_contents()

# Generated at 2022-06-24 02:21:51.877473
# Unit test for function load_env_file
def test_load_env_file():
    from io import BytesIO

    fp = BytesIO(b"""
# A comment
TEST=${HOME}/yeee-$PATH
THISIS=~/a/test
YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
""")

    # Read file
    fp.seek(0)
    lines = [line for line in fp if line.strip()]

    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:21:54.084536
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)

# Generated at 2022-06-24 02:22:02.954323
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # From honcho.
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    expected = collections.OrderedDict()
    expected['TEST'] = '.../yeee'
    expected['THISIS'] = '.../a/test'
    expected['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    assert (expected['TEST'] == parse_env_file_contents(lines).__next__()[1])
    assert (expected['THISIS'] == parse_env_file_contents(lines).__next__()[1])

# Generated at 2022-06-24 02:22:06.300877
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    parse_env_file_contents(lines)



# Generated at 2022-06-24 02:22:07.705572
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod(verbose=True)



# Generated at 2022-06-24 02:22:10.674508
# Unit test for function expand
def test_expand():
    val = '$HOME'

    ret = expand(val)
    assert '~' not in ret

# Generated at 2022-06-24 02:22:17.362194
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:22:22.808763
# Unit test for function expand
def test_expand():
    # Arrange
    val = "$HOME/yeee"

    # Act
    result = expand(val)

    # Assert
    assert result != "$HOME/yeee"
    assert result != "~/yeee"



# Generated at 2022-06-24 02:22:25.735463
# Unit test for function expand
def test_expand():
    assert (expand('$HOME/yeee') == os.path.expanduser('~/yeee'))
    assert (expand('~/yeee') == os.path.expanduser('~/yeee'))



# Generated at 2022-06-24 02:22:33.061002
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import filecmp

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = load_env_file(lines, write_environ=dict())

    import pprint

    pprint.pprint(out)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:22:37.329046
# Unit test for function expand
def test_expand():
    t = '${PATH}/this${HOME}'
    t2 = os.path.expandvars(t)

    assert t == '${PATH}/this${HOME}'
    assert t2.endswith('this')



# Generated at 2022-06-24 02:22:45.735171
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines) == dict(TEST="$HOME/yeee",
                                        THISIS="~/a/test",
                                        YOLO="~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")

# Generated at 2022-06-24 02:22:50.728866
# Unit test for function expand
def test_expand():
    test_src = [
        ('~/test', '.../test'),
        ('$HOME/test', '.../test'),
        ('$HOME/test/$PATH', '.../test/...:...')
    ]

    for src, dst in test_src:
        assert dst == expand(src)

# Generated at 2022-06-24 02:22:58.798080
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == \
           collections.OrderedDict([('TEST', '.../yeee'),
                                    ('THISIS', '.../a/test'),
                                    ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

# Generated at 2022-06-24 02:23:07.589882
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    '''
    make sure parser works as expected.
    '''

    # single var
    env = parse_env_file_contents(['singlevar=singleval'])
    assert list(env)[0] == ('singlevar', 'singleval')

    # multiple vars
    env = parse_env_file_contents(['multiplevar=multipleval', 'secondvar=secondval'])
    assert list(env)[0] == ('multiplevar', 'multipleval')
    assert list(env)[1] == ('secondvar', 'secondval')

    # single quoted
    env = parse_env_file_contents(["singlequoted='singleval'"])
    assert list(env)[0] == ('singlequoted', 'singleval')

    # double quoted

# Generated at 2022-06-24 02:23:16.261786
# Unit test for function expand
def test_expand():
    import os

    os.environ["TEST"] = "/my/path"
    os.environ["TEST2"] = "other path"
    os.environ["TEST3"] = "/my/path:${TEST2}"

    assert expand("~/some/path") == os.path.join(os.path.expanduser("~"), "some", "path")
    assert expand("${TEST}/some/path") == os.path.join(os.environ["TEST"], "some", "path")
    assert expand("${TEST}/some/path:${TEST2}") == os.path.join(os.environ["TEST"], "some", "path") + ":" + os.environ["TEST2"]
    assert expand("${TEST3}/some/path") == os.path

# Generated at 2022-06-24 02:23:25.413801
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    answer = {'TEST': os.path.expanduser('~/yeee-') + os.environ["PATH"],
              'THISIS': os.path.expanduser('~/a/test'),
              'YOLO': os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')}

    assert load_env_file(lines) == answer

# Generated at 2022-06-24 02:23:31.363621
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict([('TEST', expand('${HOME}/yeee')),
                                                                                  ('THISIS', expand('~/a/test')),
                                                                                  ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])



# Generated at 2022-06-24 02:23:39.914748
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    out = parse_env_file_contents(lines)
    expected_out = dict()
    for key, value in out:
        expected_out[key] = value

    assert expected_out == {'TEST': '${HOME}/yeee', 'THISIS': '~/a/test', 'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}

    env = dict()
    out = load_env_file(lines, write_environ=env)
    expected_out = dict()

# Generated at 2022-06-24 02:23:47.621986
# Unit test for function load_env_file
def test_load_env_file():
    # References:
    #   https://stackoverflow.com/a/2669120/
    #   https://docs.python.org/3/library/io.html#io.StringIO

    # Use StringIO to capture the stdout data
    stdout_capture = io.StringIO()
    with contextlib.redirect_stdout(stdout_capture):
        # Load the env file
        load_env_file(
            lines=[
                'TEST=${HOME}/yeee-$PATH',
                'THISIS=~/a/test',
                'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
            ],
            write_environ=None,
        )

        # Check the results
        assert stdout_capture.getvalue

# Generated at 2022-06-24 02:23:59.507306
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    _parse_env_file_contents_test_case(
        [],
        []
    )

    _parse_env_file_contents_test_case(
        ['foo=bar'],
        [('foo', 'bar')]
    )

    _parse_env_file_contents_test_case(
        ['FOO=BAR'],
        [('FOO', 'BAR')]
    )

    _parse_env_file_contents_test_case(
        ['foo=bar', 'FOO=BAR'],
        [('foo', 'bar'), ('FOO', 'BAR')]
    )


# Generated at 2022-06-24 02:24:08.374531
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    results = load_env_file(lines, write_environ=dict())
    expected = collections.OrderedDict([('TEST', '.../yeee'),
                                        ('THISIS', '.../a/test'),
                                        ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    assert results == expected



# Generated at 2022-06-24 02:24:19.788126
# Unit test for function load_env_file

# Generated at 2022-06-24 02:24:22.630439
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    Test case: an empty string to parse.
    """
    foo = ""
    assert (list(parse_env_file_contents([foo])) == [])



# Generated at 2022-06-24 02:24:31.670597
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THIS=${VAR}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = {'HOME': '...', 'VAR': '...'}
    result = load_env_file(lines, environ)
    assert result == collections.OrderedDict([('TEST', '.../yeee'),
                                       ('THIS', '...'),
                                       ('THISIS', '.../a/test'),
                                       ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])

    # change environ mapping
    environ['YOLO'] = '...'

# Generated at 2022-06-24 02:24:38.394133
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines)

    print("\n", result)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:24:50.381473
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines)

# Generated at 2022-06-24 02:24:56.572087
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    lines = parse_env_file_contents(lines)

    assert next(lines) == ('TEST', '.../yeee')
    assert next(lines) == ('THISIS', '.../a/test')
    assert next(lines) == ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:25:03.851978
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert_equal([('TEST', '.../.../yeee-...'),
                  ('THISIS', '.../a/test'),
                  ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')],
                 list(parse_env_file_contents(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])))


# Generated at 2022-06-24 02:25:11.702191
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = parse_env_file_contents(lines)
    for k, v in values:
        assert expand(v).startswith(os.environ['HOME'])


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:25:13.947154
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    (failure_count, test_count) = doctest.testmod()
    assert failure_count == 0

# Generated at 2022-06-24 02:25:18.438240
# Unit test for function expand
def test_expand():
    assert expand('yolo') == 'yolo'
    assert expand('~/.local/share') == os.path.expanduser('~/.local/share')
    assert expand('$HOME/.local/share') == os.path.expanduser('~/.local/share')


# Unit tests for function load_env_file()

# Generated at 2022-06-24 02:25:28.936532
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    from pathlib import Path
    from io import StringIO
    import sys
    import pytest

    @pytest.fixture
    def test_env_file(tmpdir):
        tmp_file = Path(str(tmpdir) + '/test_env.txt')
        test_data = '''TEST_VAR1=1
TEST_VAR2=2
TEST_VAR3=3
'''
        tmp_file.write_text(test_data)
        tmp_file.chmod(0o644)
        return tmp_file

    def test_env_file_contents(env_file):
        with open(env_file) as f:
            contents = parse_env_file_contents(lines=f)
            assert 'TEST_VAR1' in contents

# Generated at 2022-06-24 02:25:37.919687
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import io
    import os

    good_lines = [
        'DB_HOST=${HOME}/Postgres/data',
        'PG_USER=postgres',
        'PG_PASSWORD=postgres',
        'DB_PORT=5432',
        'DB_NAME=mydb',
        'PG_OPTIONS=--additional-option="-c dynamically_shared_memory_type=mmap"'
    ]

    results = parse_env_file_contents(good_lines)  # type: typing.Tuple[typing.Tuple[str, str]]

    # Check each of the good lines
    for key, value in results:
        assert os.path.exists(expand(value)), f'Bad value: {value}, for key: {key}'


# Generated at 2022-06-24 02:25:46.581562
# Unit test for function load_env_file
def test_load_env_file():

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:25:56.344997
# Unit test for function load_env_file
def test_load_env_file():
    # This function returns an OrderedDict containing the changes that are made to the environment.
    # This is intended for use by other functions for restoring the environment to a previous state,
    # or for logging.
    assert load_env_file([]) == collections.OrderedDict()
    assert load_env_file(['TEST=${HOME}/yeee']) == collections.OrderedDict(TEST=expand('${HOME}') + '/yeee')
    assert load_env_file([' HELLO="world"']) == collections.OrderedDict(HELLO='world')

# Generated at 2022-06-24 02:26:02.937183
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    d = dict(parse_env_file_contents(lines))

    assert d['TEST'] == expand(lines[0].split('=')[1])
    assert d['THISIS'] == expand(lines[1].split('=')[1])
    assert d['YOLO'] == expand(lines[2].split('=')[1])



# Generated at 2022-06-24 02:26:04.020807
# Unit test for function expand
def test_expand():
    assert expand('~/home/swag') == '.../home/swag'

# Generated at 2022-06-24 02:26:05.795608
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.environ['HOME']
    assert expand('~/') == os.environ['HOME'] + '/'



# Generated at 2022-06-24 02:26:14.570110
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines, write_environ={})
    assert isinstance(env, collections.OrderedDict)
    assert len(env) == 3
    assert env['TEST'] == os.path.join(os.getenv('HOME'), 'yeee') + '-...:...'
    assert env['THISIS'] == os.path.join(os.getenv('HOME'), 'a', 'test')

# Generated at 2022-06-24 02:26:24.375269
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict([('TEST', os.path.join(os.path.expanduser('~'), 'yeee-' + os.environ['PATH'])),
                                        ('THISIS', os.path.join(os.path.expanduser('~'), 'a/test')),
                                        ('YOLO', os.path.join(os.path.expanduser('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
                                        ])


# Generated at 2022-06-24 02:26:32.814053
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert dict(parse_env_file_contents(lines)) == {
        'TEST': '${HOME}/yeee-$PATH',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }



# Generated at 2022-06-24 02:26:43.271775
# Unit test for function load_env_file
def test_load_env_file():
    import io
    lines = io.StringIO('TEST=${HOME}/yeee\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST\n')
    env_dict = load_env_file(lines, write_environ=None)
    assert env_dict['TEST'] == os.path.expanduser('~/yeee')
    assert env_dict['THISIS'] == os.path.expanduser('~/a/test')
    assert env_dict['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')



# Generated at 2022-06-24 02:26:47.966493
# Unit test for function load_env_file
def test_load_env_file():
    from pprint import pprint
    from ast import literal_eval


# Generated at 2022-06-24 02:26:56.253616
# Unit test for function expand
def test_expand():
    # FIXME: fix this unit test
    """
    >>> expand('${HOME}/yeee-$PATH') == '.../yeee-...:...'
    True
    >>> expand('~/a/test') == '.../a/test'
    True
    >>> expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST') == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    True
    """
    pass



# Generated at 2022-06-24 02:27:02.815976
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:27:05.719381
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())



# Generated at 2022-06-24 02:27:16.768850
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    temp_file = '/tmp/temp-env-file'

    # Test parse_env_file_contents behaivor
    with open(temp_file, 'w') as f:
        f.write('TEST=${HOME}/yeee\n')
        f.write('THISIS=~/a/test\n')
        f.write('YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    changes = load_env_file(open(temp_file, 'r'))
    assert changes['TEST'] == '.../yeee'
    assert changes['THISIS'] == '.../a/test'

# Generated at 2022-06-24 02:27:22.921833
# Unit test for function expand
def test_expand():
    assert expand("~/yeee") == expand(os.path.expanduser("~/yeee"))
    assert expand("$HOME/yeee") == expand(os.path.expandvars("$HOME/yeee"))
    assert expand("${HOME}/yeee") == expand(os.path.expandvars("${HOME}/yeee"))

# Generated at 2022-06-24 02:27:26.912135
# Unit test for function expand
def test_expand():
    assert expand("${HOME}/yeee-$PATH:$PATH") == os.path.expandvars("${HOME}/yeee-$PATH:$PATH")



# Generated at 2022-06-24 02:27:32.661278
# Unit test for function expand
def test_expand():
    assert expand("~/poo") == os.path.join(os.path.expanduser("~"), "poo")
    assert expand("$BLAH/poo") == os.path.join(os.getenv("BLAH"), "poo")
    assert expand("$NOT_IN_ENV/poo") == os.path.join("$NOT_IN_ENV", "poo")
    assert expand("${HOME}/poo") == os.path.join(os.path.expanduser("~"), "poo")


test_expand()

# Generated at 2022-06-24 02:27:35.023942
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    failures, _ = doctest.testmod()
    assert failures == 0



# Generated at 2022-06-24 02:27:41.195069
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.expandvars('${HOME}')
    assert expand('~') == os.path.expanduser('~')


# Unit tests for function load_env_file

# Generated at 2022-06-24 02:27:46.763844
# Unit test for function expand
def test_expand():
    d1 = {
        "a": "as",
        "b": "${a}df",
        "c": "$b ${b}",
        "d": "$c"}

    d2 = {"a": "as",
          "b": "asdf",
          "c": "asdf asdf",
          "d": "asdf asdf"}

    assert(d2 == expand_value_dict(d1))


# Returns: a dictionary where values (not keys) are expanded.

# Generated at 2022-06-24 02:27:56.912133
# Unit test for function expand
def test_expand():
    old_home = os.environ.get('HOME')

    try:
        os.environ['HOME'] = '~/test/'
        assert expand('$HOME/yeee') == '~/test/yeee'
        assert expand('${HOME}/yeee') == '~/test/yeee'
        assert expand('~/yeee-$PATH') == '~/yeee-...:...'
        assert expand('~/yeee-${PATH}') == '~/yeee-...:...'
        assert expand('~/yeee-${unknown__var}') == '~/yeee-${unknown__var}'
    finally:
        if old_home:
            os.environ['HOME'] = old_home

# Generated at 2022-06-24 02:28:01.095491
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.expandvars(os.path.expanduser('~'))
    assert expand('~') == os.path.expandvars(os.path.expanduser('~'))



# Generated at 2022-06-24 02:28:11.870315
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Example markdown:
    # COMPOSE_FILE=docker-compose.yml:docker-compose.extra.yml
    # ENV_FILE=.env

    # Parse the file:
    lines = [
        'COMPOSE_FILE=docker-compose.yml:docker-compose.extra.yml',
        'ENV_FILE=.env'
    ]
    # print(type(lines))

    # For each line in the file:

# Generated at 2022-06-24 02:28:20.796669
# Unit test for function expand
def test_expand():
    test_pairs = [
        # ($in, $out)
        ('~/path', os.path.join(os.path.expanduser('~'), 'path')),
        ('$HOME/path', os.path.join(os.path.expanduser('~'), 'path')),
        ('$NOTAREALVAR/path', '$NOTAREALVAR/path')
    ]
    for test_pair in test_pairs:
        assert expand(test_pair[0]) == test_pair[1], f"expand({test_pair[0]}) != {test_pair[1]}"



# Generated at 2022-06-24 02:28:29.289424
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = {'TEST': '.../yeee', 'THISIS': '.../a/test',
                'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'}
    result = collections.OrderedDict(parse_env_file_contents(lines))
    assert (expected == result)

# Generated at 2022-06-24 02:28:36.566879
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output = load_env_file(contents, write_environ=dict())
    assert output['TEST'] == '.../.../yeee-...:...'
    assert output['THISIS'] == '.../a/test'
    assert output['YOLO'] == '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

# Generated at 2022-06-24 02:28:45.780501
# Unit test for function expand
def test_expand():
    assert expand("~/test") == os.path.expanduser("~/test")
    assert expand("${HOME}/test") == os.path.join(os.path.expanduser("~"), "test")
    assert expand("/tmp/test/${HOME}/test") == os.path.join("/tmp/test", os.path.expanduser("~"), "test")
    assert expand("/tmp/test/${STUFF}/test") == os.path.join("/tmp/test", os.environ.get("STUFF"), "test")

# Generated at 2022-06-24 02:28:49.299255
# Unit test for function expand
def test_expand():
    # Test os.path.expanduser
    assert expand('~') == os.environ['HOME']

    # Test os.path.expandvars
    assert expand('$HOME') == os.environ['HOME']



# Generated at 2022-06-24 02:29:00.598514
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    expected = collections.OrderedDict(
        [('TEST', '.../yeee'),
         ('THISIS', '.../a/test'),
         ('YOLO', '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    )

    actual = collections.OrderedDict(parse_env_file_contents(lines))

    assert actual == expected



# Generated at 2022-06-24 02:29:06.395747
# Unit test for function parse_env_file_contents

# Generated at 2022-06-24 02:29:16.297032
# Unit test for function expand
def test_expand():
    # Test variables
    var_name = "VARIABLE_EXPAND"
    var_value = "VariableExpandValue"
    os.environ[var_name] = var_value

    # Get user home
    user_home = expand("~")

    # Create directory in user home
    dir_name = "test_expand_directory"
    test_expand_path = os.path.join(user_home, dir_name)

# Generated at 2022-06-24 02:29:17.460891
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 02:29:21.409319
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test']
    values = list(parse_env_file_contents(lines))
    assert len(values) == 2
    assert values[0][0] == 'TEST'

# Generated at 2022-06-24 02:29:29.074807
# Unit test for function expand
def test_expand():
    import os
    import sys

    os.environ['PATH'] = '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games'
    os.environ['HOME'] = '/home/mynick'
    os.environ['NAME'] = 'FOO'
    os.environ['FOO'] = 'BAR'
    os.environ['BAR'] = 'BAZ'

    assert expand('${FOO}') == 'BAR'
    assert expand('${BAR}') == 'BAZ'
    assert expand('${HOME}') == '/home/mynick'



# Generated at 2022-06-24 02:29:31.366281
# Unit test for function expand
def test_expand():
    assert expand('~/swaggins') == os.path.expanduser('~/swaggins')
    assert expand('$HOME/swaggins') == os.path.expandvars('$HOME/swaggins')



# Generated at 2022-06-24 02:29:34.053477
# Unit test for function load_env_file
def test_load_env_file():
    import doctest

    doctest.testmod()


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:29:40.619204
# Unit test for function expand
def test_expand():
    if os.getcwd() == '/':
        return

    assert os.path.expanduser('~') == expand('~')
    assert os.path.expanduser('~') == expand('${HOME}')
    assert os.path.expanduser('~') == expand('${HOME}')
    assert os.path.expanduser('~/') == expand('${HOME}/')
    assert os.path.expanduser('~/swag') == expand('${HOME}/swag')
    assert os.path.expanduser('/root') == expand('/root')
    assert os.path.expanduser('/root') == expand('/root')
    assert os.path.expanduser('/root/') == expand('/root/')
    assert os.path.expanduser('/root/swag')