

# Generated at 2022-06-24 02:19:51.820050
# Unit test for function expand
def test_expand():
    assert expand('~/yolo') == os.path.expanduser('~/yolo')
    assert expand('$HOME') == os.path.expanduser('~')
    assert expand('${HOME}') == os.path.expanduser('~')

    assert expand('~/yolo') == expand(os.path.expanduser('~/yolo'))
    assert expand('$HOME') == expand(os.path.expanduser('~'))
    assert expand('${HOME}') == expand(os.path.expanduser('~'))

# Generated at 2022-06-24 02:20:01.429947
# Unit test for function expand
def test_expand():
    val = '~/test/asdf'
    assert expand(val) in ['.../test/asdf', '...\\test\\asdf']
    val = '${HOME}/test/asdf'
    assert expand(val) in ['.../test/asdf', '...\\test\\asdf']
    val = '${PATH}'
    assert expand(val) in [':...:...:...:...', ';...;...;...;...']
    val = '${PATH}/test'
    assert expand(val) in [
        '.../test',
        '.../test',
        '.../test',
        '.../test',
    ]
    val = '$PATH'
    assert expand(val) in [':...:...:...:...', ';...;...;...;...']
   

# Generated at 2022-06-24 02:20:08.931930
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes_expected = collections.OrderedDict()
    changes_expected['TEST'] = '.../yeee'
    changes_expected['THISIS'] = '.../a/test'
    changes_expected['YOLO'] = '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'

    changes = parse_env_file_contents(lines)
    changes = collections.OrderedDict(changes)

    assert changes == changes_expected, 'Invalid parse of lines in function parse_env_file_contents'


# Unit test

# Generated at 2022-06-24 02:20:14.415278
# Unit test for function load_env_file
def test_load_env_file():
    from io import StringIO

    env_file_contents = ["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"]

    for text in env_file_contents:
        with StringIO(text) as fh:
            values = load_env_file(fh, write_environ=None)
            assert len(values) == 1



# Generated at 2022-06-24 02:20:19.446971
# Unit test for function expand
def test_expand():
    assert expand('$NONEXISTING_VAR_THAT_DOES_NOT_EXIST') == '$NONEXISTING_VAR_THAT_DOES_NOT_EXIST'
    assert expand('${HOME}') != '${HOME}'



# Generated at 2022-06-24 02:20:20.737972
# Unit test for function expand
def test_expand():
    val = '~/test'
    expected = expand(val)
    if not expected:
        print('test_expand fails')



# Generated at 2022-06-24 02:20:27.396333
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    import collections
    import os
    import re

    values = []
    for line in lines:
        m1 = re.match(r'\A([A-Za-z_0-9]+)=(.*)\Z', line)

        if m1:
            key, val = m1.group(1), m1.group(2)

            m2 = re.match(r"\A'(.*)'\Z", val)
            if m2:
                val = m2.group(1)

            m3 = re.match(r'\A"(.*)"\Z', val)

# Generated at 2022-06-24 02:20:33.997516
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    basic_lines = ['TEST=${HOME}/yeee',
                   'THISIS=~/a/test',
                   'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    loaded = load_env_file(basic_lines)

    assert loaded['TEST'] == '/Users/yeee'
    assert loaded['THISIS'] == '/Users/a/test'
    assert loaded['YOLO'] == '/Users/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'



# Generated at 2022-06-24 02:20:36.719490
# Unit test for function expand
def test_expand():
    assert expand('$HOME/yeee') == (os.path.expanduser('~') + '/yeee')
    assert expand('~/yeee') == os.path.expanduser('~') + '/yeee'



# Generated at 2022-06-24 02:20:48.543159
# Unit test for function load_env_file
def test_load_env_file():
    import io

    # Test without writing to os.environ
    lines = io.StringIO(u'TEST=$HOME/yeee\nTHISIS=~/a/test\nYOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    changes = load_env_file(lines)

    assert changes['TEST'] == os.path.expanduser('~/yeee')
    assert changes['THISIS'] == os.path.expanduser('~/a/test')
    assert changes['YOLO'] == os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

    assert changes is not os.environ

    # Test with writing to os.environ
    lines

# Generated at 2022-06-24 02:20:54.536883
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w+", encoding="utf-8") as f:
        f.write(textwrap.dedent(
            """
            # empty line
            TEST=${HOME}/yeee-$PATH
            THISIS=~/a/test
            YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST
            """))
        f.seek(0)

        new_environ = load_env_file(f.readlines(), write_environ=dict())

# Generated at 2022-06-24 02:20:56.969971
# Unit test for function expand
def test_expand():
    """
    Test expand function
    """
    home = expand("~")

    with pytest.raises(FileNotFoundError):
        expand("/this/path/does/not/exist")

    assert expand(home) == os.path.expanduser(home)



# Generated at 2022-06-24 02:20:59.783567
# Unit test for function expand
def test_expand():
    HOME = os.environ["HOME"]
    x = expand("~/a")
    assert x == HOME + "/a"

    X = "abcdef"
    os.environ["X"] = X
    x = expand("$X")
    assert x == X

    x = expand("$X/g")
    assert x == X + "/g"



# Generated at 2022-06-24 02:21:08.889153
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert dict(load_env_file(lines, write_environ=dict())) == {
        'TEST': expand('$HOME/yeee'),
        'THISIS': expand('~/a/test'),
        'YOLO': expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'),
    }



# Generated at 2022-06-24 02:21:17.885355
# Unit test for function expand
def test_expand():
    def assert_expanded(val, expected):
        expanded = expand(val)
        assert expanded == expected, f"{val} -> {expanded} != {expected}"

    assert_expanded("", "")
    assert_expanded("foo", "foo")
    assert_expanded("${HOME}", os.environ["HOME"])
    assert_expanded("~", os.environ["HOME"])
    assert_expanded("~/foo", os.path.join(os.environ["HOME"], "foo"))
    assert_expanded(os.path.join(os.environ["HOME"], "foo"), os.path.join(os.environ["HOME"], "foo"))



# Generated at 2022-06-24 02:21:22.940754
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = [
        "TEST='hello'",
        "THISIS='hello world'",
        "YOLO='hello world again'",
        "SOME='a=b'",
        "SOME2='a=b b=c'",
    ]
    assert list(parse_env_file_contents(contents)) == [
        ("TEST", "hello"),
        ("THISIS", "hello world"),
        ("YOLO", "hello world again"),
        ("SOME", "a=b"),
        ("SOME2", "a=b b=c"),
    ]



# Generated at 2022-06-24 02:21:26.161685
# Unit test for function expand
def test_expand():
    assert expand('') == ''
    assert expand('/tmp/na') == '/tmp/na'
    assert expand('~/na') == os.path.expanduser('~/na')
    assert expand('$HOME/na') == os.path.expanduser('~/na')



# Generated at 2022-06-24 02:21:28.910578
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:21:34.536769
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    env = load_env_file(lines=lines, write_environ=dict())
    assert env['TEST'].endswith('/yeee')
    assert env['THISIS'].endswith('/a/test')
    assert env['YOLO'].endswith('/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')

# Generated at 2022-06-24 02:21:41.578503
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines, write_environ=dict()) == collections.OrderedDict(
        [('TEST', '{}/yeee-{}'.format(expand('~'), expand('$PATH'))),
         ('THISIS', '{}/a/test'.format(expand('~'))),
         ('YOLO', '{}/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'.format(expand('~')))])

# Generated at 2022-06-24 02:21:52.454712
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import pytest

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    output = list(parse_env_file_contents(lines))
    expected_output = [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]

    # Check if outputted correctly from function
    check_output = [x for x in output if x not in expected_output]
    assert not check_output

    # Check if only expected output is outputted
    check

# Generated at 2022-06-24 02:22:01.607800
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    obt = parse_env_file_contents(lines)

    expected_output = [('TEST', '${HOME}/yeee'),
                       ('THISIS', '~/a/test'),
                       ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]

    res = list(obt)
    assert expected_output == res, res



# Generated at 2022-06-24 02:22:05.025835
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    import doctest

    result = doctest.testmod(verbose=True)
    assert result.failed == 0


if __name__ == '__main__':
    print(load_env_file('/'.join(__file__.split('/')[:-1]) + '/test/.env'))

# Generated at 2022-06-24 02:22:17.172512
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=$HOME/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    values = load_env_file(lines, write_environ=dict())
    assert isinstance(values, collections.OrderedDict)

    for k, v in values.items():
        if k == 'TEST':
            assert v == os.path.join(os.environ['HOME'], 'yeee-' + os.environ['PATH'])
        elif k == 'THISIS':
            assert v == os.path.expanduser('~/a/test')

# Generated at 2022-06-24 02:22:28.084719
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    contents = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    parsed = parse_env_file_contents(contents)

    result = dict(parsed)

    if result["TEST"] != os.path.expandvars("${HOME}/yeee-$PATH"):
        raise AssertionError("parse_env_file_contents should expand values with expandvars")

    if result["THISIS"] != os.path.expanduser("~/a/test"):
        raise AssertionError("parse_env_file_contents should expand values with expanduser")


# Generated at 2022-06-24 02:22:33.124179
# Unit test for function expand
def test_expand():
    assert expand('${HOME}') == os.path.expanduser('~')
    assert expand('~/') == os.path.expanduser('~') + '/'



# Generated at 2022-06-24 02:22:38.738126
# Unit test for function load_env_file
def test_load_env_file():
    write_environ = dict()
    load_env_file(('TEST=${HOME}/yeee-${PATH}', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'), write_environ=write_environ)

    print("\nwrite_environ: ", write_environ)



# Generated at 2022-06-24 02:22:39.673192
# Unit test for function expand
def test_expand():
    s = "$HOME/yeee"
    expand(s)



# Generated at 2022-06-24 02:22:46.607027
# Unit test for function expand
def test_expand():
    home_path = os.getenv('HOME')
    with open('test.txt', 'w') as f:
        f.write(home_path)

    assert expand('$HOME/test.txt') == os.path.join(home_path, 'test.txt')
    assert expand('~' + '/test.txt') == os.path.join(home_path, 'test.txt')
    assert expand('~test/test.txt') == os.path.join('~test', 'test.txt')


# Generated at 2022-06-24 02:22:48.027768
# Unit test for function load_env_file
def test_load_env_file():
    assert 1 == 1


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:22:51.285166
# Unit test for function expand
def test_expand():
    assert expand("$HOME/test") == os.environ["HOME"] + "/test"
    assert expand("~/test") == os.environ["HOME"] + "/test"
    assert expand("${HOME}/test") == os.environ["HOME"] + "/test"



# Generated at 2022-06-24 02:22:56.386064
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert tuple(parse_env_file_contents(['test=test'])) == (('test', 'test'),)
    assert tuple(parse_env_file_contents(['test=test', 'test2=test2'])) == (('test', 'test'), ('test2', 'test2'))



# Generated at 2022-06-24 02:23:03.929834
# Unit test for function load_env_file
def test_load_env_file():
    res = load_env_file(['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert res == collections.OrderedDict(
        [
            ('TEST', expand('${HOME}/yeee-$PATH')),
            ('THISIS', expand('~/a/test')),
            ('YOLO', expand('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))
        ]
    )

# Generated at 2022-06-24 02:23:07.140010
# Unit test for function expand
def test_expand():
    assert expand("/tmp/${USER}") == os.path.expandvars("/tmp/${USER}")
    assert expand("~/test") == os.path.expanduser("~/test")


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:23:10.564476
# Unit test for function expand
def test_expand():
    actual = expand('~/test')
    expected = '/home/user/test'
    assert actual == expected

# Generated at 2022-06-24 02:23:20.281412
# Unit test for function load_env_file
def test_load_env_file():
    """
    Test for load_env_file
    """
    env_file = [
        '# Comment test',
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        '# test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    ]
    env = load_env_file(env_file, write_environ=None)

# Generated at 2022-06-24 02:23:24.802622
# Unit test for function load_env_file
def test_load_env_file():
    import unittest

    class TestLoadEnvFile(unittest.TestCase):
        def test_basic(self):
            lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
            write_environ = dict()


# Generated at 2022-06-24 02:23:36.108356
# Unit test for function load_env_file
def test_load_env_file():
    # Just in case this is called while using numpy
    import warnings

    warnings.filterwarnings('ignore', category=ImportWarning, module='numpy')

    try:
        import numpy
        import numpy.testing
    except ImportError:
        raise ImportError('You need to install the numpy package to run the unit tests for py-env-config')

    # First check we can use env vars
    os.environ['TEST'] = 'hello'
    os.environ['TEST2'] = 'world'

    # We need this to be able to expand home directory
    os.environ['HOME'] = '.'

    # We need this to be able to expand PATH
    os.environ['PATH'] = 'hello:world'

    # Test a normal env file with only one variable

# Generated at 2022-06-24 02:23:43.650390
# Unit test for function load_env_file
def test_load_env_file():
    test_lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = load_env_file(test_lines)
    for key, value in result.items():
        if key == 'TEST':
            assert re.fullmatch(r'(.+)/yeee-.+:\S+', value), value
        elif key == 'THISIS':
            assert re.fullmatch(r'(.+)/a/test', value), value

# Generated at 2022-06-24 02:23:51.890595
# Unit test for function expand
def test_expand():

    assert expand('~') == os.path.expanduser('~')

    assert expand('${HOME}') == os.path.expanduser('~')

    assert expand('${HOME}/foo') == os.path.expanduser('~/foo')

    assert expand('/home/user/foo') == '/home/user/foo'

    assert expand('~/foo') == os.path.expanduser('~/foo')

    assert expand('${PATH}') == os.environ.get('PATH')



# Generated at 2022-06-24 02:24:03.496879
# Unit test for function expand
def test_expand():
    home = os.path.expanduser("~")
    var = "HOME"
    path = os.path.join("~", "yeet")
    path_expanded = os.path.join(home, "yeet")

    os.environ[var] = home

    assert expand("$HOME") == home
    assert expand("${HOME}") == home
    assert expand("~") == home
    assert expand("~/") == home
    assert expand("~/yeet") == os.path.join(home, "yeet")
    assert expand("~/yeet/") == os.path.join(home, "yeet")
    assert expand("$HOME/yeet") == os.path.join(home, "yeet")

# Generated at 2022-06-24 02:24:13.614210
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(lines=['TEST=${HOME}/yeee']) == collections.OrderedDict([('TEST', expand('${HOME}/yeee'))])

    # Should expand variables
    assert load_env_file(lines=['TEST=${HOME}/yeee-$PATH']) == collections.OrderedDict([('TEST', expand('${HOME}/yeee-$PATH'))])

    # Should expand "~"
    assert load_env_file(lines=['TEST=~/yeee']) == collections.OrderedDict([('TEST', expand('~/yeee'))])

    # Should expand variables inside other variables

# Generated at 2022-06-24 02:24:17.620771
# Unit test for function expand
def test_expand():
    assert expand("$PATH") == os.environ.get("PATH")
    assert expand("Hello") == "Hello"



# Generated at 2022-06-24 02:24:24.245573
# Unit test for function load_env_file
def test_load_env_file():
    filename = os.path.join(os.path.dirname(__file__), 'test_env_file.env')
    with open(filename, 'r') as f:
        lines = f.readlines()
        expected = load_env_file(lines, write_environ=None)
        assert "HOME" in expected
        assert "PATH" in expected
        assert "SWAGGINS" in expected
        assert "YEEEEE" in expected

# Generated at 2022-06-24 02:24:29.211912
# Unit test for function load_env_file
def test_load_env_file():
    # TODO: More test cases

    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:24:40.670648
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    import textwrap
    from io import StringIO

    from .util import capture_stdout

    lines = [
        '# comment',
        '',
        '',
        'HOME=/home/user',
        'PATH=/bin:/usr/bin:$PATH',
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
        'XDOUBLEQUOTES="x\\\\"',
        "SINGLELINE='with spaces'",
        '',
        '',
    ]

    with capture_stdout() as captured:
        changes = load_env_file(lines, os.environ)


# Generated at 2022-06-24 02:24:43.049020
# Unit test for function load_env_file
def test_load_env_file():
    import ast
    import doctest
    import os

    old_environ = os.environ.copy()

    doctest.testmod()

    assert old_environ == os.environ



# Generated at 2022-06-24 02:24:48.611203
# Unit test for function load_env_file
def test_load_env_file():
    # This is the environment we will use for the test
    test_environ = collections.OrderedDict({
        'HOME': '/Users/thesonofsam'
    })

    # These are the lines that we will use to load the env file
    lines = [
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]


# Generated at 2022-06-24 02:24:52.228708
# Unit test for function load_env_file
def test_load_env_file():
    import sys
    if sys.version_info[0:2] < (3, 6):
        return
    eval(load_env_file.__code__)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:24:58.519786
# Unit test for function expand
def test_expand():
    test_str = """
    $HOME/test
    ~/test
    """
    assert os.path.abspath(expand(test_str)) == os.path.abspath(os.path.expandvars(os.path.expanduser(test_str)))

# Generated at 2022-06-24 02:25:04.330545
# Unit test for function expand
def test_expand():
    import os.path

    # Test if expand can expand os.path.expanduser
    assert os.path.expanduser("~/hello") == expand("~/hello")

    # Test if expand can expand os.path.expandvars
    assert os.path.expandvars("$HOME/hello") == expand("$HOME/hello")



# Generated at 2022-06-24 02:25:08.749646
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    actual = list(parse_env_file_contents(lines))
    expected = [('TEST', '.../yeee'),
                ('THISIS', '.../a/test'),
                ('YOLO',
                 '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]
    assert actual == expected



# Generated at 2022-06-24 02:25:19.528457
# Unit test for function expand
def test_expand():
    assert expand('/home/yeee') == '/home/yeee'
    assert expand('~/a/test') in ['/home/yeee/a/test', 'C:/Users/yeee/a/test']

    assert expand('${TEST}/yeee-$PATH') in ['/home/yeee/.../yeee-...:...', 'C:/Users/yeee/.../yeee-...;...']

# Generated at 2022-06-24 02:25:29.022461
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    # Lines to parse
    lines = [
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    # Expected output
    expected = {
        'TEST': '${HOME}/yeee',
        'THISIS': '~/a/test',
        'YOLO': '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    }

    # Verify output

# Generated at 2022-06-24 02:25:38.570620
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    """
    >>> lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    >>> load_env_file(lines, write_environ=dict())
    OrderedDict([('TEST', '.../yeee'),
             ('THISIS', '.../a/test'),
             ('YOLO',
              '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])
    """
    pass



# Generated at 2022-06-24 02:25:48.942814
# Unit test for function expand
def test_expand():
    oldenv1 = os.environ.get('TESTVAR')
    oldenv2 = os.environ.get('PATH')

    try:
        os.environ['TESTVAR'] = r'~\test'
        os.environ['PATH'] = r'C:\Program Files\Python'

        val = r'$TESTVAR/$PATH'
        val = expand(val)

        assert val == '~/test/C:/Program Files/Python'
    finally:
        if oldenv1:
            os.environ['TESTVAR'] = oldenv1
        else:
            del os.environ['TESTVAR']

        if oldenv2:
            os.environ['PATH'] = oldenv2
        else:
            del os.environ['PATH']

# Generated at 2022-06-24 02:25:52.888246
# Unit test for function expand
def test_expand():
    assert expand('$HOME/test') == os.path.expanduser('~/test')
    assert expand('~/test') == os.path.expanduser('~/test')



# Generated at 2022-06-24 02:25:59.061248
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    result = load_env_file(lines, write_environ=dict())
    print(result)
    assert result == collections.OrderedDict([('TEST', '.../.../yeee-...:...'),
                                              ('THISIS', '.../a/test'),
                                              ('YOLO',
                                               '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')])


__all__ = ["load_env_file"]

# Generated at 2022-06-24 02:26:03.375604
# Unit test for function expand
def test_expand():
    terminal_path_name = "/dev/pts/1"
    terminal_file_name = "test_file.txt"
    command = "echo hello > " + terminal_path_name + '/' + terminal_file_name
    expected_command = "echo hello > " + expand(terminal_path_name) + '/' + terminal_file_name
    assert expand(command) == expected_command



# Generated at 2022-06-24 02:26:10.390622
# Unit test for function expand
def test_expand():
    assert expand("~") == os.path.expanduser("~")
    assert expand("~root") == os.path.expanduser("~root")
    assert expand("$HOME") == os.path.expandvars("$HOME")
    assert expand("${HOME}") == os.path.expandvars("${HOME}")
    assert expand("$HOME/a") == os.path.expandvars("$HOME/a")
    assert expand("${HOME}/a") == os.path.expandvars("${HOME}/a")



# Generated at 2022-06-24 02:26:11.849681
# Unit test for function load_env_file
def test_load_env_file():
    if __name__ == "__main__":
        import doctest

        doctest.testmod()

# Generated at 2022-06-24 02:26:18.498618
# Unit test for function load_env_file
def test_load_env_file():
    filename = None
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = dict()
    sut = load_env_file(lines, write_environ=environ)
    assert sut['TEST'] == expand("${HOME}/yeee-$PATH")
    assert sut['THISIS'] == expand("~/a/test")
    assert sut['YOLO'] == expand("~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST")
    assert environ['TEST'] == expand("${HOME}/yeee-$PATH")
    assert environ['THISIS']

# Generated at 2022-06-24 02:26:20.673375
# Unit test for function expand
def test_expand():
    """
    >>> True
    True
    """
    pass



# Generated at 2022-06-24 02:26:30.632499
# Unit test for function load_env_file
def test_load_env_file():
    # Test for non-existent filename
    try:
        load_env_file(lines=['TEST=${HOME}/tee.st'])
    except FileNotFoundError:
        print('Error loading non-existent file')

    # Test for existing filename
    d = load_env_file(lines=['TEST=${HOME}/test', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'])
    assert len(d) == 3
    assert d['TEST'] == os.path.expanduser('~/test')
    assert d['THISIS'] == os.path.expanduser('~/a/test')

# Generated at 2022-06-24 02:26:39.231424
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile
    tempdir = tempfile.TemporaryDirectory()
    home = os.path.abspath(tempdir.name)
    os.environ['HOME'] = home
    os.makedirs(os.path.join(home, 'a', 'test'), exist_ok=True)
    os.makedirs(os.path.join(home, 'swaggins'), exist_ok=True)
    os.makedirs(os.path.join(home, 'yeee'), exist_ok=True)
    os.makedirs(os.path.join(home, 'a', 'test'))


# Generated at 2022-06-24 02:26:43.387345
# Unit test for function load_env_file
def test_load_env_file():
    env = load_env_file(lines=['TEST=value'], write_environ={})

    assert env['TEST'] == 'value'


if __name__ == '__main__':
    test_load_env_file()

# Generated at 2022-06-24 02:26:49.468487
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())

    assert environ == collections.OrderedDict([
        ('TEST', '.../yeee'),
        ('THISIS', '.../a/test'),
        ('YOLO',
         '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])

# Generated at 2022-06-24 02:26:56.571330
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents([
        'TEST=${HOME}/yeee',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ])) == [
        ('TEST', '${HOME}/yeee'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-24 02:27:01.053429
# Unit test for function load_env_file
def test_load_env_file():
    import tempfile

    lines = ['YOLO=${HOME}/swaggins']

    with tempfile.NamedTemporaryFile(mode='w') as fh:
        fh.writelines(lines)
        fh.flush()

        changes = load_env_file([line.strip() for line in open(fh.name)])

    assert changes['YOLO'].endswith('swaggins')


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 02:27:11.041675
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    output_expanded_correctly = collections.OrderedDict([('TEST', os.path.expanduser('${HOME}/yeee')),
                                                         ('THISIS', os.path.expanduser('~/a/test')),
                                                         ('YOLO', os.path.expanduser('~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'))])

    output = collections.OrderedDict(parse_env_file_contents(lines))

    assert output_expanded_correctly == output

# Unit test

# Generated at 2022-06-24 02:27:12.663536
# Unit test for function expand
def test_expand():
    expected = os.path.expandvars(os.path.expanduser("~")) + "/test"
    assert expand("~/test") == expected

# Generated at 2022-06-24 02:27:20.267982
# Unit test for function load_env_file

# Generated at 2022-06-24 02:27:26.302783
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert list(parse_env_file_contents(lines)) == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'),
                                                    ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:27:27.260377
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:27:31.038602
# Unit test for function expand
def test_expand():
    """
    Test if the function expand expands environment variables.

    The function expand should expand variables.

    >>> os.environ = {'TEST': 'ABC', 'TEST2': 'DEF'}
    >>> test = expand('$TEST/$TEST2')
    >>> assert test == 'ABC/DEF'
    """
    assert True

# Generated at 2022-06-24 02:27:40.662056
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test',
             'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    assert [(k, v) for (k, v) in parse_env_file_contents(lines)] == [
        ('TEST', '{HOME}/yeee-$PATH'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ]



# Generated at 2022-06-24 02:27:45.851576
# Unit test for function expand
def test_expand():
    assert expand('~/swaggins/') == os.path.expanduser('~/swaggins/')
    assert expand('$HOME/swaggins/') == os.path.join(os.environ.get('HOME'), 'swaggins/')
    assert expand('${HOME}/swaggins/') == os.path.join(os.environ.get('HOME'), 'swaggins/')
    assert expand('${PWD}/swaggins/') == os.path.join(os.environ.get('PWD'), 'swaggins/')
    assert expand('${NO_SUCH_VAR}') == '${NO_SUCH_VAR}'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 02:27:56.393172
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    changes = load_env_file(lines, write_environ=dict())

# Generated at 2022-06-24 02:28:05.064104
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    assert list(parse_env_file_contents(["TEST=${HOME}/yeee", "THISIS=~/a/test", "YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"])) == [
        ("TEST", "./yeee"),
        ("THISIS", "./a/test"),
        ("YOLO", "./swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST"),
    ]

# Generated at 2022-06-24 02:28:11.019183
# Unit test for function load_env_file
def test_load_env_file():
    assert load_env_file(lines=None, write_environ=None) == collections.OrderedDict()
    assert load_env_file(lines=[], write_environ=None) == collections.OrderedDict()



# Generated at 2022-06-24 02:28:21.867146
# Unit test for function expand
def test_expand():
    os.environ['VAR'] = 'foo'
    os.environ['FOO'] = '$HOME'
    os.environ['HOME'] = os.path.expanduser('~')
    os.environ['BAR'] = '${VAR}bar'

    assert expand('bar') == 'bar'
    assert expand('${VAR}') == 'foo'
    assert expand('${FOO}') == os.path.expanduser('~')
    assert expand('${BAZ}') == '${BAZ}'
    assert expand('${BAR}') == 'foobar'


if __name__ == '__main__':

    # Unit test for function load_env_file
    test_expand()

# Generated at 2022-06-24 02:28:26.275407
# Unit test for function load_env_file
def test_load_env_file():
    if __name__ == '__main__':
        import sys
        import doctest

        doctest.testmod(sys.modules[__name__])
        print('doctest success')

# Generated at 2022-06-24 02:28:36.030890
# Unit test for function load_env_file
def test_load_env_file():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    loaded = load_env_file(lines, write_environ=dict())
    assert loaded == {
        'TEST': '.../.../yeee-...:...',
        'THISIS': '.../a/test',
        'YOLO': '.../swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST',
    }

# Generated at 2022-06-24 02:28:48.387925
# Unit test for function load_env_file
def test_load_env_file():
    """
    Unit test for function load_env_file
    """
    import doctest
    import json

    lines = [
        'HOME=/Users/jamesor',
        'PATH=/Users/jamesor/miniconda3/bin:/Users/jamesor/miniconda3/condabin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        'TEST=${HOME}/yeee-$PATH',
        'THISIS=~/a/test',
        'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST'
    ]

    before = load_env_file(lines, write_environ=None)


# Generated at 2022-06-24 02:29:01.003995
# Unit test for function load_env_file
def test_load_env_file():
    # TODO: Make this more DRY
    lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    assert load_env_file(lines) == collections.OrderedDict(
        [
            ('TEST', os.path.join(expand('~'), 'yeee')),
            ('THISIS', os.path.join(expand('~'), 'a/test')),
            ('YOLO', os.path.join(expand('~'), 'swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')),
        ]
    )



# Generated at 2022-06-24 02:29:12.554960
# Unit test for function load_env_file
def test_load_env_file():
    # Before running tests, make sure that vars are not already defined, as this would make the tests fail
    if "TEST" in os.environ:
        del os.environ["TEST"]

    if "THISIS" in os.environ:
        del os.environ["THISIS"]

    if "YOLO" in os.environ:
        del os.environ["YOLO"]

    # Run tests
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    environ = load_env_file(lines, write_environ=dict())

    assert len(lines) == len(environ)

# Generated at 2022-06-24 02:29:20.364591
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    test_lines = ['TEST=${HOME}/yeee', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']
    lines = list(parse_env_file_contents(test_lines))
    assert lines == [('TEST', '${HOME}/yeee'), ('THISIS', '~/a/test'), ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')]



# Generated at 2022-06-24 02:29:25.654482
# Unit test for function expand
def test_expand():
    assert expand('~/path') == os.path.expanduser('~/path')
    assert expand('$HOME/path') == os.path.expandvars('$HOME/path')

# Generated at 2022-06-24 02:29:26.446865
# Unit test for function load_env_file
def test_load_env_file():
    load_env_file()



# Generated at 2022-06-24 02:29:32.121501
# Unit test for function parse_env_file_contents
def test_parse_env_file_contents():
    lines = ['TEST=${HOME}/yeee-$PATH', 'THISIS=~/a/test', 'YOLO=~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST']

    result = parse_env_file_contents(lines)
    result = collections.OrderedDict(result)

    expected_result = collections.OrderedDict([
        ('TEST', '${HOME}/yeee-$PATH'),
        ('THISIS', '~/a/test'),
        ('YOLO', '~/swaggins/$NONEXISTENT_VAR_THAT_DOES_NOT_EXIST')
    ])
    assert result == expected_result



# Generated at 2022-06-24 02:29:35.457400
# Unit test for function load_env_file
def test_load_env_file():
    import doctest
    doctest.testmod()
    print("All tests successful for {}\n".format(__file__))


if __name__ == "__main__":
    test_load_env_file()

# Generated at 2022-06-24 02:29:40.544816
# Unit test for function expand
def test_expand():
    assert expand(r'$HOME/a') == os.path.join(os.path.expanduser('~'), 'a')



# Generated at 2022-06-24 02:29:47.132456
# Unit test for function load_env_file
def test_load_env_file():
    filename = 'tests/fixtures/env.txt'
    load_env_file([filename])

    values = parse_env_file_contents([filename])


if __name__ == '__main__':
    test_load_env_file()